/*     */ package inetsoft.report.lens;
/*     */ 
/*     */ import inetsoft.report.SectionBand;
/*     */ import inetsoft.report.SectionLens;
/*     */ import inetsoft.report.StyleSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSectionLens
/*     */   implements SectionLens
/*     */ {
/*     */   SectionBand header;
/*     */   SectionBand footer;
/*     */   Object content;
/*     */   
/*     */   public DefaultSectionLens() {}
/*     */   
/*  36 */   public DefaultSectionLens(StyleSheet paramStyleSheet) { this(new SectionBand(paramStyleSheet), new SectionBand(paramStyleSheet), new SectionBand(paramStyleSheet)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultSectionLens(SectionBand paramSectionBand1, SectionBand paramSectionBand2, SectionBand paramSectionBand3) {
/*  45 */     this.header = paramSectionBand1;
/*  46 */     this.content = paramSectionBand2;
/*  47 */     this.footer = paramSectionBand3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultSectionLens(SectionBand paramSectionBand1, SectionLens paramSectionLens, SectionBand paramSectionBand2) {
/*  55 */     this.header = paramSectionBand1;
/*  56 */     this.content = paramSectionLens;
/*  57 */     this.footer = paramSectionBand2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public SectionBand getSectionHeader() { return this.header; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public void setSectionHeader(SectionBand paramSectionBand) { this.header = paramSectionBand; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public Object getSectionContent() { return this.content; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public void setSectionContent(SectionBand paramSectionBand) { this.content = paramSectionBand; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public void setSectionContent(SectionLens paramSectionLens) { this.content = paramSectionLens; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public SectionBand getSectionFooter() { return this.footer; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void setSectionFooter(SectionBand paramSectionBand) { this.footer = paramSectionBand; }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 114 */     DefaultSectionLens defaultSectionLens = (DefaultSectionLens)super.clone();
/* 115 */     defaultSectionLens.header = (SectionBand)this.header.clone();
/* 116 */     defaultSectionLens.footer = (SectionBand)this.footer.clone();
/*     */     
/* 118 */     if (this.content instanceof SectionBand) {
/* 119 */       defaultSectionLens.content = ((SectionBand)this.content).clone();
/*     */     }
/* 121 */     else if (this.content instanceof SectionLens) {
/* 122 */       defaultSectionLens.content = ((SectionLens)this.content).clone();
/*     */     } 
/*     */     
/* 125 */     return defaultSectionLens;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultSectionLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */