package inetsoft.report.lens;

import inetsoft.report.SectionBand;
import inetsoft.report.SectionLens;
import inetsoft.report.StyleSheet;

public class DefaultSectionLens implements SectionLens {
  SectionBand header;
  
  SectionBand footer;
  
  Object content;
  
  public DefaultSectionLens() {}
  
  public DefaultSectionLens(StyleSheet paramStyleSheet) { this(new SectionBand(paramStyleSheet), new SectionBand(paramStyleSheet), new SectionBand(paramStyleSheet)); }
  
  public DefaultSectionLens(SectionBand paramSectionBand1, SectionBand paramSectionBand2, SectionBand paramSectionBand3) {
    this.header = paramSectionBand1;
    this.content = paramSectionBand2;
    this.footer = paramSectionBand3;
  }
  
  public DefaultSectionLens(SectionBand paramSectionBand1, SectionLens paramSectionLens, SectionBand paramSectionBand2) {
    this.header = paramSectionBand1;
    this.content = paramSectionLens;
    this.footer = paramSectionBand2;
  }
  
  public SectionBand getSectionHeader() { return this.header; }
  
  public void setSectionHeader(SectionBand paramSectionBand) { this.header = paramSectionBand; }
  
  public Object getSectionContent() { return this.content; }
  
  public void setSectionContent(SectionBand paramSectionBand) { this.content = paramSectionBand; }
  
  public void setSectionContent(SectionLens paramSectionLens) { this.content = paramSectionLens; }
  
  public SectionBand getSectionFooter() { return this.footer; }
  
  public void setSectionFooter(SectionBand paramSectionBand) { this.footer = paramSectionBand; }
  
  public Object clone() {
    DefaultSectionLens defaultSectionLens = (DefaultSectionLens)super.clone();
    defaultSectionLens.header = (SectionBand)this.header.clone();
    defaultSectionLens.footer = (SectionBand)this.footer.clone();
    if (this.content instanceof SectionBand) {
      defaultSectionLens.content = ((SectionBand)this.content).clone();
    } else if (this.content instanceof SectionLens) {
      defaultSectionLens.content = ((SectionLens)this.content).clone();
    } 
    return defaultSectionLens;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\lens\DefaultSectionLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */