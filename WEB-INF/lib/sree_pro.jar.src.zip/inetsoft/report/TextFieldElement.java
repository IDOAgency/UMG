package inetsoft.report;

public interface TextFieldElement extends FieldElement {
  String getText();
  
  void setText(String paramString);
  
  int getCols();
  
  void setCols(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TextFieldElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */