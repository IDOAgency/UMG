/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Simple2
/*     */   extends TableStyle
/*     */ {
/*     */   public Simple2() {}
/*     */   
/*  45 */   public Simple2(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final Simple2 this$0;
/*     */     
/*  59 */     Style(Simple2 this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowBorder(int param1Int1, int param1Int2) {
/*  90 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/*  91 */         return 4098;
/*     */       }
/*     */       
/*  94 */       if (this.this$0.isFormatLastRow() && param1Int1 == lastRow() - 1) {
/*  95 */         return this.this$0.isHeaderColFormat(param1Int2) ? 0 : 4097;
/*     */       }
/*     */       
/*  98 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getColBorder(int param1Int1, int param1Int2) {
/* 111 */       if (this.this$0.isHeaderColFormat(param1Int2)) {
/* 112 */         return 4098;
/*     */       }
/*     */       
/* 115 */       if (this.this$0.isFormatLastCol() && param1Int2 == lastCol() - 1) {
/* 116 */         return this.this$0.isHeaderRowFormat(param1Int1) ? 0 : 4097;
/*     */       }
/*     */       
/* 119 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 139 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/*     */       
/* 141 */       if (this.this$0.isHeaderRowFormat(param1Int1) || this.this$0.isHeaderColFormat(param1Int2) || (this.this$0.isFormatLastRow() && param1Int1 == lastRow()) || (this.this$0.isFormatLastCol() && param1Int2 == lastCol()))
/*     */       {
/*     */         
/* 144 */         return this.this$0.createFont(font, 1);
/*     */       }
/*     */       
/* 147 */       return font;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Simple2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */