package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;

public class LedgerOpen extends TableStyle {
  public LedgerOpen() {}
  
  public LedgerOpen(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final LedgerOpen this$0;
    
    Style(LedgerOpen this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (this.this$0.isHeaderRowFormat(param1Int1) || (param1Int1 == lastRow() - 1 && this.this$0.isFormatLastRow())) ? 4098 : ((param1Int1 >= 0 && param1Int1 < lastRow()) ? 4097 : 0); }
    
    public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 >= 0 && param1Int2 < lastCol()) ? 4097 : 0; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 17; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\LedgerOpen.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */