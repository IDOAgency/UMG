/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Effect3D3
/*     */   extends TableStyle
/*     */ {
/*     */   public Effect3D3() {}
/*     */   
/*  44 */   public Effect3D3(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final Effect3D3 this$0;
/*     */     
/*  58 */     Style(Effect3D3 this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return (param1Int1 % 2 == 0 && param1Int1 < this.this$0.table.getRowCount() - 1 && param1Int2 > 0) ? Color.gray : Color.lightGray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return (param1Int2 == 0 && param1Int1 % 2 == 1 && param1Int1 < this.this$0.table.getRowCount() - 1) ? Color.gray : Color.lightGray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 < this.this$0.table.getRowCount() - 1 && param1Int1 >= 0 && param1Int2 > 0) ? 4097 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     public int getColBorder(int param1Int1, int param1Int2) { return ((this.this$0.isHeaderColFormat(param1Int2) || (param1Int2 == lastCol() && this.this$0.isFormatLastCol())) && param1Int1 % 2 == 1 && param1Int1 < lastRow()) ? 4097 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 127 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/* 128 */       return (this.this$0.isHeaderRowFormat(param1Int1) || (param1Int1 == lastRow() && this.this$0.isHeaderColFormat(param1Int2))) ? this.this$0.createFont(font, 1) : font;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     public Color getBackground(int param1Int1, int param1Int2) { return (param1Int2 % 2 == 1) ? new Color(220, 220, 220) : null; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Effect3D3.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */