package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;

public class GreenStrip extends TableStyle {
  public GreenStrip() {}
  
  public GreenStrip(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final GreenStrip this$0;
    
    Style(GreenStrip this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return 0; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 0; }
    
    public Color getBackground(int param1Int1, int param1Int2) { return (param1Int1 % 2 == 0) ? new Color(120, 230, 120) : null; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\GreenStrip.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */