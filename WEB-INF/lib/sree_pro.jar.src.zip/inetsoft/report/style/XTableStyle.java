package inetsoft.report.style;

import inetsoft.report.StyleFont;
import inetsoft.report.TableLens;
import inetsoft.report.internal.XMLException;
import inetsoft.report.internal.XMLTokenStream;
import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;

public class XTableStyle extends TableStyle {
  Style style;
  
  String name;
  
  Hashtable attrmap;
  
  public XTableStyle(TableLens paramTableLens) {
    this.name = "XTableStyle";
    this.attrmap = new Hashtable();
    setTable(paramTableLens);
  }
  
  public XTableStyle(TableLens paramTableLens, InputStream paramInputStream) throws IOException, XMLException {
    this.name = "XTableStyle";
    this.attrmap = new Hashtable();
    this.style = new Style(this, paramInputStream);
    setTable(paramTableLens);
  }
  
  public XTableStyle(TableLens paramTableLens, File paramFile) throws IOException, XMLException {
    this.name = "XTableStyle";
    this.attrmap = new Hashtable();
    FileInputStream fileInputStream = new FileInputStream(paramFile);
    this.style = new Style(this, fileInputStream);
    fileInputStream.close();
    setTable(paramTableLens);
  }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public void put(String paramString, Object paramObject) { this.style.put(paramString, paramObject); }
  
  public Object get(String paramString) { return this.style.get(paramString); }
  
  public void clear() { this.attrmap.clear(); }
  
  public void parse(InputStream paramInputStream) throws XMLException, IOException { this.style = new Style(this, paramInputStream); }
  
  public void parse(XMLTokenStream paramXMLTokenStream) throws XMLException, IOException { this.style = new Style(this, paramXMLTokenStream); }
  
  public void export(OutputStream paramOutputStream) {
    String[] arrayOfString1 = { "top-border", "bottom-border", "left-border", "right-border", "header-row", "header-col", "trailer-row", "trailer-col", "body" };
    String[] arrayOfString2 = { 
        "border", "color", "bcolor", "foreground", "background", "font", "alignment", "row-border", "rcolor", "col-border", 
        "ccolor" };
    PrintWriter printWriter = new PrintWriter(new OutputStreamWriter(paramOutputStream));
    if (this.name == null) {
      printWriter.println("<table-style>");
    } else {
      printWriter.println("<table-style name=\"" + this.name + '"' + ">");
    } 
    for (byte b = 0; b < arrayOfString1.length; b++) {
      printWriter.print("<" + arrayOfString1[b] + " ");
      for (byte b1 = 0; b1 < arrayOfString2.length; b1++) {
        Object object = get(arrayOfString1[b] + "." + arrayOfString2[b1]);
        if (object != null)
          if (object instanceof Integer) {
            printWriter.print(" " + arrayOfString2[b1] + "=\"" + ((Integer)object).intValue() + "\"");
          } else if (object instanceof Color) {
            printWriter.print(" " + arrayOfString2[b1] + "=\"" + ((Color)object).getRGB() + "\"");
          } else if (object instanceof Font) {
            printWriter.print(" " + arrayOfString2[b1] + "=\"" + StyleFont.toString((Font)object) + '"');
          } else {
            printWriter.print(" " + arrayOfString2[b1] + "=" + '"' + object + '"');
          }  
      } 
      printWriter.println(">");
      printWriter.println("</" + arrayOfString1[b] + ">");
    } 
    printWriter.println("</table-style>");
    printWriter.flush();
  }
  
  protected TableLens createStyle(TableLens paramTableLens) { return (this.style == null) ? (this.style = new Style(this)) : this.style; }
  
  class Style extends TableStyle.Transparent {
    private final XTableStyle this$0;
    
    public Style(XTableStyle this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Style(XTableStyle this$0, InputStream param1InputStream) throws IOException, XMLException { this(this$0, new XMLTokenStream(param1InputStream)); }
    
    public Style(XTableStyle this$0, XMLTokenStream param1XMLTokenStream) throws IOException, XMLException {
      super(this$0);
      this.this$0 = this$0;
      Object object;
      while ((object = param1XMLTokenStream.getToken()) != null) {
        if (object instanceof XMLTokenStream.Tag) {
          XMLTokenStream.Tag tag = (XMLTokenStream.Tag)object;
          if (tag.getName().equals("TABLE-STYLE")) {
            this$0.name = tag.get("NAME");
            continue;
          } 
          if (tag.getName().equals("/TABLE-STYLE"))
            break; 
          Enumeration enumeration = tag.getAttributes();
          while (enumeration.hasMoreElements()) {
            String str1 = (String)enumeration.nextElement();
            String str2 = tag.get(str1);
            if (str1.equals("BORDER") || str1.equals("ROW-BORDER") || str1.equals("COL-BORDER")) {
              int i = StyleFont.decodeLineStyle(str2);
              if (i < 0)
                throw new XMLException("Unknow border style: " + str2); 
              put(tag.getName() + "." + str1, new Integer(i));
              continue;
            } 
            if (str1.equals("COLOR") || str1.equals("BCOLOR") || str1.equals("RCOLOR") || str1.equals("CCOLOR") || str1.equals("FOREGROUND") || str1.equals("BACKGROUND"))
              try {
                put(tag.getName() + "." + str1, new Color(Integer.decode(str2).intValue()));
                continue;
              } catch (Exception exception) {
                exception.printStackTrace();
                throw new XMLException("Color format error: " + str2);
              }  
            if (str1.equals("FONT")) {
              Font font = StyleFont.decode(str2);
              if (font == null)
                throw new XMLException("Font format error: " + str2); 
              put(tag.getName() + "." + str1, font);
              continue;
            } 
            if (str1.equals("ALIGNMENT")) {
              int i = 0;
              if (Character.isDigit(str2.charAt(0))) {
                i = Integer.decode(str2).intValue();
              } else {
                if (str2.indexOf("H_LEFT") >= 0) {
                  i |= 0x1;
                } else if (str2.indexOf("H_CENTER") >= 0) {
                  i |= 0x2;
                } else if (str2.indexOf("H_RIGHT") >= 0) {
                  i |= 0x4;
                } 
                if (str2.indexOf("V_TOP") >= 0) {
                  i |= 0x8;
                } else if (str2.indexOf("V_CENTER") >= 0) {
                  i |= 0x10;
                } else if (str2.indexOf("V_BOTTOM") >= 0) {
                  i |= 0x20;
                } 
              } 
              put(tag.getName() + "." + str1, new Integer(i));
            } 
          } 
        } 
      } 
    }
    
    public Object get(String param1String) { return this.this$0.attrmap.get(param1String.toUpperCase()); }
    
    public void put(String param1String, Object param1Object) { this.this$0.attrmap.put(param1String.toUpperCase(), param1Object); }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) {
      Object object;
      if ((param1Int1 == -1 && (object = get("top-border.color")) != null) || (param1Int1 == lastRow() && (object = get("bottom-border.color")) != null) || (this.this$0.isHeaderRowFormat(param1Int1) && (object = get("header-row.bcolor")) != null) || (param1Int1 == lastRow() - 1 && (object = get("trailer-row.bcolor")) != null) || (object = get("body.rcolor")) != null)
        return (Color)object; 
      return super.getRowBorderColor(param1Int1, param1Int2);
    }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) {
      Object object;
      if ((param1Int2 == -1 && (object = get("left-border.color")) != null) || (param1Int2 == lastCol() && (object = get("right-border.color")) != null) || (this.this$0.isHeaderColFormat(param1Int2) && (object = get("header-col.bcolor")) != null) || (param1Int2 == lastCol() - 1 && (object = get("trailer-col.bcolor")) != null) || (object = get("body.ccolor")) != null)
        return (Color)object; 
      return super.getColBorderColor(param1Int1, param1Int2);
    }
    
    public int getRowBorder(int param1Int1, int param1Int2) {
      Object object;
      if ((param1Int1 == -1 && (object = get("top-border.border")) != null) || (param1Int1 == lastRow() && (object = get("bottom-border.border")) != null) || (this.this$0.isHeaderRowFormat(param1Int1) && (object = get("header-row.border")) != null) || (param1Int1 == lastRow() - 1 && (object = get("trailer-row.border")) != null) || (object = get("body.row-border")) != null)
        return ((Integer)object).intValue(); 
      return super.getRowBorder(param1Int1, param1Int2);
    }
    
    public int getColBorder(int param1Int1, int param1Int2) {
      Object object;
      if ((param1Int2 == -1 && (object = get("left-border.border")) != null) || (param1Int2 == lastCol() && (object = get("right-border.border")) != null) || (this.this$0.isHeaderColFormat(param1Int2) && (object = get("header-col.border")) != null) || (param1Int2 == lastCol() - 1 && (object = get("trailer-col.border")) != null) || (object = get("body.col-border")) != null)
        return ((Integer)object).intValue(); 
      return super.getColBorder(param1Int1, param1Int2);
    }
    
    public int getAlignment(int param1Int1, int param1Int2) {
      Object object;
      if ((param1Int1 == lastRow() && (object = get("trailer-row.alignment")) != null) || (this.this$0.isHeaderRowFormat(param1Int1) && (object = get("header-row.alignment")) != null) || (param1Int2 == lastCol() && (object = get("trailer-col.alignment")) != null) || (this.this$0.isHeaderColFormat(param1Int2) && (object = get("header-col.alignment")) != null) || (object = get("body.alignment")) != null)
        return ((Integer)object).intValue(); 
      return super.getAlignment(param1Int1, param1Int2);
    }
    
    public Font getFont(int param1Int1, int param1Int2) {
      Object object;
      if ((param1Int1 == lastRow() && (object = get("trailer-row.font")) != null) || (this.this$0.isHeaderRowFormat(param1Int1) && (object = get("header-row.font")) != null) || (param1Int2 == lastCol() && (object = get("trailer-col.font")) != null) || (this.this$0.isHeaderColFormat(param1Int2) && (object = get("header-col.font")) != null) || (object = get("body.font")) != null)
        return (Font)object; 
      return super.getFont(param1Int1, param1Int2);
    }
    
    public Color getForeground(int param1Int1, int param1Int2) {
      Object object;
      if ((param1Int1 == lastRow() && (object = get("trailer-row.foreground")) != null) || (this.this$0.isHeaderRowFormat(param1Int1) && (object = get("header-row.foreground")) != null) || (param1Int2 == lastCol() && (object = get("trailer-col.foreground")) != null) || (this.this$0.isHeaderColFormat(param1Int2) && (object = get("header-col.foreground")) != null) || (object = get("body.foreground")) != null)
        return (Color)object; 
      return super.getForeground(param1Int1, param1Int2);
    }
    
    public Color getBackground(int param1Int1, int param1Int2) {
      Object object;
      if ((param1Int1 == lastRow() && (object = get("trailer-row.background")) != null) || (this.this$0.isHeaderRowFormat(param1Int1) && (object = get("header-row.background")) != null) || (param1Int2 == lastCol() && (object = get("trailer-col.background")) != null) || (this.this$0.isHeaderColFormat(param1Int2) && (object = get("header-col.background")) != null) || (object = get("body.background")) != null)
        return (Color)object; 
      return super.getBackground(param1Int1, param1Int2);
    }
  }
  
  public Object clone() {
    XTableStyle xTableStyle = new XTableStyle(getTable());
    xTableStyle.name = new String(this.name);
    xTableStyle.attrmap = (Hashtable)this.attrmap.clone();
    xTableStyle.headerRF = this.headerRF;
    xTableStyle.headerCF = this.headerCF;
    xTableStyle.widthF = this.widthF;
    xTableStyle.heightF = this.heightF;
    xTableStyle.rowBorderCF = this.rowBorderCF;
    xTableStyle.colBorderCF = this.colBorderCF;
    xTableStyle.rowBorderF = this.rowBorderF;
    xTableStyle.colBorderF = this.colBorderF;
    xTableStyle.insetsF = this.insetsF;
    xTableStyle.spanF = this.spanF;
    xTableStyle.alignF = this.alignF;
    xTableStyle.fontF = this.fontF;
    xTableStyle.wrapF = this.wrapF;
    xTableStyle.foregroundF = this.foregroundF;
    xTableStyle.backgroundF = this.backgroundF;
    xTableStyle.presenterF = this.presenterF;
    xTableStyle.firstRow = this.firstRow;
    xTableStyle.firstCol = this.firstCol;
    xTableStyle.lastRow = this.lastRow;
    xTableStyle.lastCol = this.lastCol;
    return xTableStyle;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\XTableStyle.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */