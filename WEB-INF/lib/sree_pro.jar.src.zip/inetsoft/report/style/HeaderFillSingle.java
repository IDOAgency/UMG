package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;

public class HeaderFillSingle extends TableStyle {
  public HeaderFillSingle() {}
  
  public HeaderFillSingle(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final HeaderFillSingle this$0;
    
    Style(HeaderFillSingle this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 17; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\HeaderFillSingle.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */