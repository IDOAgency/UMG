/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoubleLineGrid
/*     */   extends TableStyle
/*     */ {
/*     */   public DoubleLineGrid() {}
/*     */   
/*  44 */   public DoubleLineGrid(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final DoubleLineGrid this$0;
/*     */     
/*  58 */     Style(DoubleLineGrid this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.darkGray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.darkGray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     public int getRowBorder(int param1Int1, int param1Int2) { return 8195; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     public int getColBorder(int param1Int1, int param1Int2) { return 8195; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     public int getAlignment(int param1Int1, int param1Int2) { return this.this$0.table.getAlignment(param1Int1, param1Int2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     public Font getFont(int param1Int1, int param1Int2) { return this.this$0.table.getFont(param1Int1, param1Int2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     public Color getForeground(int param1Int1, int param1Int2) { return this.this$0.table.getForeground(param1Int1, param1Int2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     public Color getBackground(int param1Int1, int param1Int2) { return this.this$0.table.getBackground(param1Int1, param1Int2); }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\DoubleLineGrid.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */