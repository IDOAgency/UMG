package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Font;

public class Accounting3 extends TableStyle {
  public Accounting3() {}
  
  public Accounting3(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final Accounting3 this$0;
    
    Style(Accounting3 this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? new Color(0, 64, 128) : Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 == 0) ? 4098 : ((param1Int2 > 0 && param1Int1 == this.this$0.table.getRowCount() - 1) ? 8195 : ((param1Int2 > 0 && param1Int1 == this.this$0.table.getRowCount() - 2) ? 4097 : 0)); }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 0; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return (param1Int2 == 0) ? 17 : 20; }
    
    public Font getFont(int param1Int1, int param1Int2) {
      Font font = this.this$0.table.getFont(param1Int1, param1Int2);
      return (param1Int1 == 0 && param1Int2 == this.this$0.table.getColCount() - 1) ? this.this$0.createFont(font, 3) : (((param1Int1 == 0 && param1Int2 < this.this$0.table.getColCount() - 1) || (param1Int2 == 0 && param1Int1 < this.this$0.table.getRowCount() - 1)) ? this.this$0.createFont(font, 2) : ((param1Int2 == 0 && param1Int1 == this.this$0.table.getRowCount() - 1) ? this.this$0.createFont(font, 1) : font));
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Accounting3.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */