/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Classic4
/*     */   extends TableStyle
/*     */ {
/*     */   public Classic4() {}
/*     */   
/*  44 */   public Classic4(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final Classic4 this$0;
/*     */     
/*  58 */     Style(Classic4 this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowBorder(int param1Int1, int param1Int2) {
/*  89 */       if (param1Int1 == -1 || param1Int1 == lastRow()) {
/*  90 */         return 4098;
/*     */       }
/*     */       
/*  93 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/*  94 */         return 4097;
/*     */       }
/*     */       
/*  97 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 == -1 || param1Int2 == lastCol()) ? 4097 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 130 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/*     */       
/* 132 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 133 */         return this.this$0.createFont(font, 3);
/*     */       }
/*     */       
/* 136 */       if (this.this$0.isHeaderColFormat(param1Int2)) {
/* 137 */         return this.this$0.createFont(font, 1);
/*     */       }
/*     */       
/* 140 */       return font;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getForeground(int param1Int1, int param1Int2) {
/* 151 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 152 */         return Color.white;
/*     */       }
/*     */       
/* 155 */       if (this.this$0.isFormatLastRow() && param1Int1 == lastRow()) {
/* 156 */         return Color.blue;
/*     */       }
/*     */       
/* 159 */       return Color.black;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getBackground(int param1Int1, int param1Int2) {
/* 170 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 171 */         return Color.lightGray.darker();
/*     */       }
/*     */       
/* 174 */       if (this.this$0.isFormatLastRow() && param1Int1 == lastRow()) {
/* 175 */         return Color.lightGray;
/*     */       }
/*     */       
/* 178 */       return Color.white;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Classic4.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */