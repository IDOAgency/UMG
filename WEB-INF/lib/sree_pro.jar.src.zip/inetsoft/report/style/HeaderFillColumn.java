package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Font;

public class HeaderFillColumn extends TableStyle {
  public HeaderFillColumn() {}
  
  public HeaderFillColumn(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final HeaderFillColumn this$0;
    
    Style(HeaderFillColumn this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 < 0 || param1Int1 == lastRow() || this.this$0.isHeaderRowFormat(param1Int1)) ? 8195 : 0; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 < 0 || param1Int2 == lastCol()) ? 8195 : 4097; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 18; }
    
    public Font getFont(int param1Int1, int param1Int2) {
      Font font = this.this$0.table.getFont(param1Int1, param1Int2);
      return (this.this$0.isHeaderRowFormat(param1Int1) || this.this$0.isHeaderColFormat(param1Int2)) ? this.this$0.createFont(font, 1) : font;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\HeaderFillColumn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */