/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoLinesSingle
/*     */   extends TableStyle
/*     */ {
/*     */   public NoLinesSingle() {}
/*     */   
/*  44 */   public NoLinesSingle(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final NoLinesSingle this$0;
/*     */     
/*  58 */     Style(NoLinesSingle this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 < 0 || param1Int1 == this.this$0.table.getRowCount() - 1) ? 4097 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 < 0 || param1Int2 == this.this$0.table.getColCount() - 1) ? 4097 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\NoLinesSingle.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */