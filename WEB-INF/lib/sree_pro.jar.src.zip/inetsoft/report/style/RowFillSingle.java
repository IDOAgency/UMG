package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;

public class RowFillSingle extends TableStyle {
  public RowFillSingle() {}
  
  public RowFillSingle(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final RowFillSingle this$0;
    
    Style(RowFillSingle this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 17; }
    
    public Color getBackground(int param1Int1, int param1Int2) { return (param1Int1 % 2 == 0) ? new Color(220, 220, 220) : null; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\RowFillSingle.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */