package inetsoft.report.style;

import inetsoft.report.Presenter;
import inetsoft.report.TableLens;
import inetsoft.report.painter.ButtonPresenter;
import inetsoft.report.painter.PresenterPainter;
import java.awt.Color;
import java.awt.Insets;

public class ButtonHeaderGrid extends TableStyle {
  Presenter button;
  
  public ButtonHeaderGrid() {
    setApplyAlignment(true);
    this.button = new ButtonPresenter();
  }
  
  public ButtonHeaderGrid(TableLens paramTableLens) {
    super(paramTableLens);
    setApplyAlignment(true);
    this.button = new ButtonPresenter();
  }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final ButtonHeaderGrid this$0;
    
    Style(ButtonHeaderGrid this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 4097; }
    
    public Insets getInsets(int param1Int1, int param1Int2) {
      if (this.this$0.isHeaderRowFormat(param1Int1) || this.this$0.isHeaderColFormat(param1Int2))
        return new Insets(0, 0, 0, 0); 
      return super.getInsets(param1Int1, param1Int2);
    }
    
    public int getAlignment(int param1Int1, int param1Int2) { return (this.this$0.isHeaderRowFormat(param1Int1) || this.this$0.isHeaderColFormat(param1Int2)) ? 0 : this.this$0.table.getAlignment(param1Int1, param1Int2); }
    
    public Object getObject(int param1Int1, int param1Int2) {
      Object object = this.this$0.table.getObject(param1Int1, param1Int2);
      if ((this.this$0.isHeaderRowFormat(param1Int1) || this.this$0.isHeaderColFormat(param1Int2)) && object instanceof String)
        return new PresenterPainter(object, this.this$0.button); 
      return object;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\ButtonHeaderGrid.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */