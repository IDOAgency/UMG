/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Classic3
/*     */   extends TableStyle
/*     */ {
/*     */   public Classic3() {}
/*     */   
/*  44 */   public Classic3(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final Classic3 this$0;
/*     */     
/*  58 */     Style(Classic3 this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowBorder(int param1Int1, int param1Int2) {
/*  89 */       if (param1Int1 == -1 || param1Int1 == this.this$0.table.getRowCount() - 1) {
/*  90 */         return 4098;
/*     */       }
/*     */       
/*  93 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/*  94 */         return 4097;
/*     */       }
/*     */       
/*  97 */       if (this.this$0.isFormatLastRow() && param1Int1 == lastRow() - 1) {
/*  98 */         return 4098;
/*     */       }
/*     */       
/* 101 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 == -1 || param1Int2 == lastCol()) ? 4098 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 134 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/*     */       
/* 136 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 137 */         return this.this$0.createFont(font, 3);
/*     */       }
/*     */       
/* 140 */       if (this.this$0.isHeaderColFormat(param1Int2) || (this.this$0.isFormatLastRow() && param1Int1 == lastRow() && param1Int2 == 0))
/*     */       {
/* 142 */         return this.this$0.createFont(font, 1);
/*     */       }
/*     */       
/* 145 */       return font;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getForeground(int param1Int1, int param1Int2) {
/* 156 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 157 */         return Color.white;
/*     */       }
/*     */       
/* 160 */       if (this.this$0.isHeaderColFormat(param1Int2) || (this.this$0.isFormatLastRow() && param1Int1 == lastRow() && param1Int2 == 0))
/*     */       {
/* 162 */         return Color.black;
/*     */       }
/*     */       
/* 165 */       return Color.blue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getBackground(int param1Int1, int param1Int2) {
/* 176 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 177 */         return Color.blue;
/*     */       }
/*     */       
/* 180 */       if (this.this$0.isFormatLastRow() && param1Int1 == lastRow()) {
/* 181 */         return Color.white;
/*     */       }
/*     */       
/* 184 */       return Color.lightGray;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Classic3.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */