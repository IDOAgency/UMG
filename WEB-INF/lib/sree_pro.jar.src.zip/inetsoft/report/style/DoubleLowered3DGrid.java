package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Font;

public class DoubleLowered3DGrid extends TableStyle {
  public DoubleLowered3DGrid() {}
  
  public DoubleLowered3DGrid(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final DoubleLowered3DGrid this$0;
    
    Style(DoubleLowered3DGrid this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.gray; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return 40963; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 40963; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return this.this$0.table.getAlignment(param1Int1, param1Int2); }
    
    public Font getFont(int param1Int1, int param1Int2) { return this.this$0.table.getFont(param1Int1, param1Int2); }
    
    public Color getForeground(int param1Int1, int param1Int2) { return this.this$0.table.getForeground(param1Int1, param1Int2); }
    
    public Color getBackground(int param1Int1, int param1Int2) { return this.this$0.table.getBackground(param1Int1, param1Int2); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\DoubleLowered3DGrid.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */