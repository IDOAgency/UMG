/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FancyLabels
/*     */   extends TableStyle
/*     */ {
/*     */   public FancyLabels() {}
/*     */   
/*  44 */   public FancyLabels(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final FancyLabels this$0;
/*     */     
/*  58 */     Style(FancyLabels this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 < 0 || param1Int1 == lastRow() || this.this$0.isHeaderRowFormat(param1Int1) || (param1Int1 == lastRow() - 1 && this.this$0.isFormatLastRow())) ? 4097 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 < 0 || param1Int2 == lastCol() || (param1Int2 == lastCol() - 1 && this.this$0.isFormatLastCol())) ? 4097 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     public int getAlignment(int param1Int1, int param1Int2) { return 20; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 125 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/* 126 */       return (this.this$0.isHeaderRowFormat(param1Int1) || (param1Int1 == lastRow() && this.this$0.isFormatLastRow()) || this.this$0.isHeaderColFormat(param1Int2) || (param1Int2 == lastCol() && this.this$0.isFormatLastCol())) ? this.this$0.createFont(font, 1) : font;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     public Color getForeground(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     public Color getBackground(int param1Int1, int param1Int2) { return this.this$0.isHeaderRowFormat(param1Int1) ? new Color(0, 150, 80) : (this.this$0.isHeaderColFormat(param1Int2) ? new Color(128, 255, 128) : new Color(128, 255, 255)); }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\FancyLabels.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */