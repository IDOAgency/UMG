package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Font;

public class Colorful1 extends TableStyle {
  public Colorful1() {}
  
  public Colorful1(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final Colorful1 this$0;
    
    Style(Colorful1 this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return (param1Int1 == -1 || param1Int1 == lastRow()) ? new Color(0, 128, 128) : Color.cyan; }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return (param1Int2 == -1 || param1Int2 == lastCol()) ? new Color(0, 128, 128) : Color.cyan; }
    
    public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 == -1 || param1Int1 == lastRow()) ? 4098 : 4097; }
    
    public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 == -1 || param1Int2 == lastCol()) ? 4098 : 0; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 17; }
    
    public Font getFont(int param1Int1, int param1Int2) {
      Font font = this.this$0.table.getFont(param1Int1, param1Int2);
      if (this.this$0.isFormatLastRow() && param1Int1 == lastRow() && param1Int2 == 0)
        return this.this$0.createFont(font, 1); 
      if (this.this$0.isHeaderRowFormat(param1Int1) || this.this$0.isHeaderColFormat(param1Int2))
        return this.this$0.createFont(font, 3); 
      return font;
    }
    
    public Color getForeground(int param1Int1, int param1Int2) { return Color.white; }
    
    public Color getBackground(int param1Int1, int param1Int2) {
      if (this.this$0.isHeaderRowFormat(param1Int1))
        return Color.black; 
      if (this.this$0.isHeaderColFormat(param1Int2))
        return Color.blue; 
      return new Color(0, 128, 128);
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Colorful1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */