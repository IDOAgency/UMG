/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Columns1
/*     */   extends TableStyle
/*     */ {
/*     */   public Columns1() {}
/*     */   
/*  44 */   public Columns1(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final Columns1 this$0;
/*     */     
/*  58 */     Style(Columns1 this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowBorder(int param1Int1, int param1Int2) {
/*  89 */       if (param1Int1 < 0 || param1Int1 == lastRow()) {
/*  90 */         return 4098;
/*     */       }
/*     */       
/*  93 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/*  94 */         return 8195;
/*     */       }
/*     */       
/*  97 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 < 0 || param1Int2 == lastCol()) ? 4098 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 130 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/* 131 */       boolean bool = true;
/*     */       
/* 133 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 134 */         bool = !bool ? 1 : 0;
/*     */       }
/*     */       
/* 137 */       if (this.this$0.isHeaderColFormat(param1Int2)) {
/* 138 */         bool = !bool ? 1 : 0;
/*     */       }
/*     */       
/* 141 */       if (this.this$0.isFormatLastRow() && param1Int1 == lastRow()) {
/* 142 */         bool = !bool ? 1 : 0;
/*     */       }
/*     */       
/* 145 */       if (this.this$0.isFormatLastCol() && param1Int2 == lastCol()) {
/* 146 */         bool = !bool ? 1 : 0;
/*     */       }
/*     */       
/* 149 */       return this.this$0.createFont(font, bool ? 1 : 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 160 */     public Color getBackground(int param1Int1, int param1Int2) { return (param1Int2 % 2 == 1) ? new Color(255, 255, 128) : null; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Columns1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */