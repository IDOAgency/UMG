/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Colorful2
/*     */   extends TableStyle
/*     */ {
/*     */   public Colorful2() {}
/*     */   
/*  44 */   public Colorful2(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final Colorful2 this$0;
/*     */     
/*  58 */     Style(Colorful2 this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowBorder(int param1Int1, int param1Int2) {
/*  89 */       if (param1Int1 == lastRow() || this.this$0.isHeaderRowFormat(param1Int1)) {
/*  90 */         return 4098;
/*     */       }
/*     */       
/*  93 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     public int getColBorder(int param1Int1, int param1Int2) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 126 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/*     */       
/* 128 */       if (this.this$0.isFormatLastRow() && param1Int1 == lastRow() && param1Int2 == 0) {
/* 129 */         return this.this$0.createFont(font, 1);
/*     */       }
/*     */       
/* 132 */       if (this.this$0.isHeaderRowFormat(param1Int1) || this.this$0.isHeaderColFormat(param1Int2)) {
/* 133 */         return this.this$0.createFont(font, 3);
/*     */       }
/*     */       
/* 136 */       return font;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getForeground(int param1Int1, int param1Int2) {
/* 147 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 148 */         return Color.white;
/*     */       }
/*     */       
/* 151 */       return Color.black;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Color getBackground(int param1Int1, int param1Int2) {
/* 162 */       if (this.this$0.isHeaderRowFormat(param1Int1)) {
/* 163 */         return new Color(128, 0, 0);
/*     */       }
/*     */       
/* 166 */       if (this.this$0.isFormatLastCol() && param1Int2 == lastCol()) {
/* 167 */         return Color.white;
/*     */       }
/*     */       
/* 170 */       return new Color(255, 255, 128);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Colorful2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */