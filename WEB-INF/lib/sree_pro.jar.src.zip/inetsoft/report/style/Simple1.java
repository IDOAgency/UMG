package inetsoft.report.style;

import inetsoft.report.TableLens;
import java.awt.Color;

public class Simple1 extends TableStyle {
  public Simple1() {}
  
  public Simple1(TableLens paramTableLens) { super(paramTableLens); }
  
  protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
  
  class Style extends TableStyle.Transparent {
    private final Simple1 this$0;
    
    Style(Simple1 this$0) { super(this$0);
      this.this$0 = this$0; }
    
    public Color getRowBorderColor(int param1Int1, int param1Int2) { return new Color(0, 128, 0); }
    
    public Color getColBorderColor(int param1Int1, int param1Int2) { return new Color(0, 128, 0); }
    
    public int getRowBorder(int param1Int1, int param1Int2) {
      if (this.this$0.isHeaderRowFormat(param1Int1))
        return 4097; 
      if (this.this$0.isFormatLastRow() && param1Int1 == lastRow() - 1)
        return 4097; 
      return (param1Int1 < 0 || param1Int1 == lastRow()) ? 4098 : 0;
    }
    
    public int getColBorder(int param1Int1, int param1Int2) { return 0; }
    
    public int getAlignment(int param1Int1, int param1Int2) { return 17; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\Simple1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */