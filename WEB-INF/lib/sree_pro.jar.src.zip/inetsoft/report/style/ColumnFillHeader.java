/*     */ package inetsoft.report.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColumnFillHeader
/*     */   extends TableStyle
/*     */ {
/*     */   public ColumnFillHeader() {}
/*     */   
/*  44 */   public ColumnFillHeader(TableLens paramTableLens) { super(paramTableLens); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final ColumnFillHeader this$0;
/*     */     
/*  58 */     Style(ColumnFillHeader this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getRowBorder(int param1Int1, int param1Int2) {
/*  89 */       if (param1Int1 < 0 || param1Int1 == lastRow() || this.this$0.isHeaderRowFormat(param1Int1)) {
/*  90 */         return 4097;
/*     */       }
/*     */       
/*  93 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     public int getColBorder(int param1Int1, int param1Int2) { return (param1Int2 < 0 || param1Int2 == lastCol()) ? 4097 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 126 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/* 127 */       return (this.this$0.isHeaderRowFormat(param1Int1) || this.this$0.isHeaderColFormat(param1Int2)) ? this.this$0.createFont(font, 1) : font;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     public Color getBackground(int param1Int1, int param1Int2) { return (param1Int2 % 2 == 0) ? new Color(200, 200, 200) : null; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\ColumnFillHeader.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */