/*      */ package inetsoft.report.style;
/*      */ 
/*      */ import inetsoft.report.StyleFont;
/*      */ import inetsoft.report.TableFilter;
/*      */ import inetsoft.report.TableLens;
/*      */ import inetsoft.report.lens.AbstractTableLens;
/*      */ import inetsoft.report.lens.AttributeTableLens;
/*      */ import java.awt.Color;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Insets;
/*      */ import java.util.Hashtable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TableStyle
/*      */   extends AttributeTableLens
/*      */   implements Cloneable
/*      */ {
/*      */   public TableLens table;
/*      */   TableLens style;
/*      */   boolean headerRF;
/*      */   boolean headerCF;
/*      */   boolean widthF;
/*      */   boolean heightF;
/*      */   boolean rowBorderCF;
/*      */   boolean colBorderCF;
/*      */   boolean rowBorderF;
/*      */   boolean colBorderF;
/*      */   boolean insetsF;
/*      */   boolean spanF;
/*      */   boolean alignF;
/*      */   boolean fontF;
/*      */   boolean wrapF;
/*      */   boolean foregroundF;
/*      */   boolean backgroundF;
/*      */   boolean presenterF;
/*      */   Boolean firstRow;
/*      */   Boolean firstCol;
/*      */   boolean lastRow;
/*      */   boolean lastCol;
/*      */   Hashtable fnmap;
/*      */   protected Font defFont;
/*      */   
/*      */   protected TableStyle() {
/*  979 */     this.headerRF = true;
/*  980 */     this.headerCF = true;
/*  981 */     this.widthF = false;
/*  982 */     this.heightF = false;
/*  983 */     this.rowBorderCF = true;
/*  984 */     this.colBorderCF = true;
/*  985 */     this.rowBorderF = true;
/*  986 */     this.colBorderF = true;
/*  987 */     this.insetsF = false;
/*  988 */     this.spanF = false;
/*  989 */     this.alignF = false;
/*  990 */     this.fontF = true;
/*  991 */     this.wrapF = false;
/*  992 */     this.foregroundF = true;
/*  993 */     this.backgroundF = true;
/*  994 */     this.presenterF = true;
/*  995 */     this.firstRow = Boolean.TRUE;
/*  996 */     this.firstCol = null;
/*  997 */     this.lastRow = false;
/*  998 */     this.lastCol = false;
/*  999 */     this.fnmap = new Hashtable();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1004 */     this.defFont = new Font("Dialog", 0, 10); super.setTable(new StyleApplicator(this)); } public TableStyle(TableLens paramTableLens) { this.headerRF = true; this.headerCF = true; this.widthF = false; this.heightF = false; this.rowBorderCF = true; this.colBorderCF = true; this.rowBorderF = true; this.colBorderF = true; this.insetsF = false; this.spanF = false; this.alignF = false; this.fontF = true; this.wrapF = false; this.foregroundF = true; this.backgroundF = true; this.presenterF = true; this.firstRow = Boolean.TRUE; this.firstCol = null; this.lastRow = false; this.lastCol = false; this.fnmap = new Hashtable(); this.defFont = new Font("Dialog", 0, 10); setTable(paramTableLens); } public TableStyle(TableLens paramTableLens1, TableLens paramTableLens2) { this.headerRF = true; this.headerCF = true; this.widthF = false; this.heightF = false; this.rowBorderCF = true; this.colBorderCF = true; this.rowBorderF = true; this.colBorderF = true; this.insetsF = false; this.spanF = false; this.alignF = false; this.fontF = true; this.wrapF = false; this.foregroundF = true; this.backgroundF = true; this.presenterF = true; this.firstRow = Boolean.TRUE; this.firstCol = null; this.lastRow = false; this.lastCol = false; this.fnmap = new Hashtable(); this.defFont = new Font("Dialog", 0, 10);
/*      */     setTable(paramTableLens1);
/*      */     this.style = paramTableLens2; }
/*      */ 
/*      */   
/*      */   public String getName() {
/*      */     String str = getClass().getName();
/*      */     int i = str.lastIndexOf(".");
/*      */     return (i > 0) ? str.substring(i + 1) : str;
/*      */   }
/*      */   
/*      */   protected TableLens createStyle(TableLens paramTableLens) { return new Transparent(this); }
/*      */   
/*      */   protected boolean isHeaderRowFormat(int paramInt) { return (isFormatFirstRow() && paramInt >= 0 && paramInt < getHeaderRowCount()); }
/*      */   
/*      */   protected boolean isHeaderColFormat(int paramInt) { return (isFormatFirstCol() && paramInt >= 0 && paramInt < getHeaderColCount()); }
/*      */   
/*      */   public void setTable(TableLens paramTableLens) {
/*      */     this.table = paramTableLens;
/*      */     this.style = createStyle(paramTableLens);
/*      */     super.setTable(new StyleApplicator(this));
/*      */   }
/*      */   
/*      */   public TableLens getTable() { return this.table; }
/*      */   
/*      */   class StyleApplicator implements TableFilter {
/*      */     private final TableStyle this$0;
/*      */     
/*      */     StyleApplicator(TableStyle this$0) { this.this$0 = this$0; }
/*      */     
/*      */     public TableLens getTable() { return this.this$0.table; }
/*      */     
/*      */     public void refresh() {
/*      */       if (this.this$0.table instanceof TableFilter)
/*      */         ((TableFilter)this.this$0.table).refresh(); 
/*      */     }
/*      */     
/*      */     public int getRowCount() { return this.this$0.table.getRowCount(); }
/*      */     
/*      */     public int getColCount() { return this.this$0.table.getColCount(); }
/*      */     
/*      */     public int getHeaderRowCount() { return this.this$0.headerRF ? this.this$0.style.getHeaderRowCount() : this.this$0.table.getHeaderRowCount(); }
/*      */     
/*      */     public int getHeaderColCount() { return this.this$0.headerCF ? this.this$0.style.getHeaderColCount() : this.this$0.table.getHeaderColCount(); }
/*      */     
/*      */     public int getRowHeight(int param1Int) { return this.this$0.heightF ? this.this$0.style.getRowHeight(param1Int) : this.this$0.table.getRowHeight(param1Int); }
/*      */     
/*      */     public int getColWidth(int param1Int) { return this.this$0.widthF ? this.this$0.style.getColWidth(param1Int) : this.this$0.table.getColWidth(param1Int); }
/*      */     
/*      */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return this.this$0.rowBorderCF ? this.this$0.style.getRowBorderColor(param1Int1, param1Int2) : this.this$0.table.getRowBorderColor(param1Int1, param1Int2); }
/*      */     
/*      */     public Color getColBorderColor(int param1Int1, int param1Int2) { return this.this$0.colBorderCF ? this.this$0.style.getColBorderColor(param1Int1, param1Int2) : this.this$0.table.getColBorderColor(param1Int1, param1Int2); }
/*      */     
/*      */     public int getRowBorder(int param1Int1, int param1Int2) {
/*      */       int i = this.this$0.table.getRowBorder(param1Int1, param1Int2);
/*      */       if (this.this$0.rowBorderF) {
/*      */         int j = this.this$0.style.getRowBorder(param1Int1, param1Int2);
/*      */         i = ((i & 0x1000000) != 0) ? (j | 0x1000000) : j;
/*      */       } 
/*      */       return i;
/*      */     }
/*      */     
/*      */     public int getColBorder(int param1Int1, int param1Int2) { return this.this$0.colBorderF ? this.this$0.style.getColBorder(param1Int1, param1Int2) : this.this$0.table.getColBorder(param1Int1, param1Int2); }
/*      */     
/*      */     public Insets getInsets(int param1Int1, int param1Int2) { return this.this$0.insetsF ? this.this$0.style.getInsets(param1Int1, param1Int2) : this.this$0.table.getInsets(param1Int1, param1Int2); }
/*      */     
/*      */     public Dimension getSpan(int param1Int1, int param1Int2) { return this.this$0.spanF ? this.this$0.style.getSpan(param1Int1, param1Int2) : this.this$0.table.getSpan(param1Int1, param1Int2); }
/*      */     
/*      */     public int getAlignment(int param1Int1, int param1Int2) { return this.this$0.alignF ? this.this$0.style.getAlignment(param1Int1, param1Int2) : this.this$0.table.getAlignment(param1Int1, param1Int2); }
/*      */     
/*      */     public Font getFont(int param1Int1, int param1Int2) { return this.this$0.fontF ? this.this$0.style.getFont(param1Int1, param1Int2) : this.this$0.table.getFont(param1Int1, param1Int2); }
/*      */     
/*      */     public boolean isLineWrap(int param1Int1, int param1Int2) { return this.this$0.wrapF ? this.this$0.style.isLineWrap(param1Int1, param1Int2) : this.this$0.table.isLineWrap(param1Int1, param1Int2); }
/*      */     
/*      */     public Color getForeground(int param1Int1, int param1Int2) { return this.this$0.foregroundF ? this.this$0.style.getForeground(param1Int1, param1Int2) : this.this$0.table.getForeground(param1Int1, param1Int2); }
/*      */     
/*      */     public Color getBackground(int param1Int1, int param1Int2) { return this.this$0.backgroundF ? this.this$0.style.getBackground(param1Int1, param1Int2) : this.this$0.table.getBackground(param1Int1, param1Int2); }
/*      */     
/*      */     public Object getObject(int param1Int1, int param1Int2) { return this.this$0.presenterF ? this.this$0.style.getObject(param1Int1, param1Int2) : this.this$0.table.getObject(param1Int1, param1Int2); }
/*      */   }
/*      */   
/*      */   public class Transparent extends AbstractTableLens {
/*      */     private final TableStyle this$0;
/*      */     
/*      */     public Transparent(TableStyle this$0) { this.this$0 = this$0; }
/*      */     
/*      */     public int getRowCount() { return this.this$0.table.getRowCount(); }
/*      */     
/*      */     public int getColCount() { return this.this$0.table.getColCount(); }
/*      */     
/*      */     public int getRowHeight(int param1Int) { return this.this$0.table.getRowHeight(param1Int); }
/*      */     
/*      */     public int getColWidth(int param1Int) { return this.this$0.table.getColWidth(param1Int); }
/*      */     
/*      */     public Object getObject(int param1Int1, int param1Int2) { return this.this$0.table.getObject(param1Int1, param1Int2); }
/*      */     
/*      */     public int getHeaderRowCount() { return this.this$0.table.getHeaderRowCount(); }
/*      */     
/*      */     public int getHeaderColCount() { return this.this$0.table.getHeaderColCount(); }
/*      */     
/*      */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return this.this$0.table.getRowBorderColor(param1Int1, param1Int2); }
/*      */     
/*      */     public Color getColBorderColor(int param1Int1, int param1Int2) { return this.this$0.table.getColBorderColor(param1Int1, param1Int2); }
/*      */     
/*      */     public int getRowBorder(int param1Int1, int param1Int2) { return this.this$0.table.getRowBorder(param1Int1, param1Int2); }
/*      */     
/*      */     public int getColBorder(int param1Int1, int param1Int2) { return this.this$0.table.getColBorder(param1Int1, param1Int2); }
/*      */     
/*      */     public Insets getInsets(int param1Int1, int param1Int2) { return this.this$0.table.getInsets(param1Int1, param1Int2); }
/*      */     
/*      */     public Dimension getSpan(int param1Int1, int param1Int2) { return this.this$0.table.getSpan(param1Int1, param1Int2); }
/*      */     
/*      */     public int getAlignment(int param1Int1, int param1Int2) { return this.this$0.table.getAlignment(param1Int1, param1Int2); }
/*      */     
/*      */     public Font getFont(int param1Int1, int param1Int2) { return this.this$0.table.getFont(param1Int1, param1Int2); }
/*      */     
/*      */     public boolean isLineWrap(int param1Int1, int param1Int2) { return this.this$0.table.isLineWrap(param1Int1, param1Int2); }
/*      */     
/*      */     public Color getForeground(int param1Int1, int param1Int2) { return this.this$0.table.getForeground(param1Int1, param1Int2); }
/*      */     
/*      */     public Color getBackground(int param1Int1, int param1Int2) { return this.this$0.table.getBackground(param1Int1, param1Int2); }
/*      */     
/*      */     protected int lastRow() { return this.this$0.table.getRowCount() - 1; }
/*      */     
/*      */     protected int lastCol() { return this.this$0.table.getColCount() - 1; }
/*      */   }
/*      */   
/*      */   public void setApplyHeaderRowCount(boolean paramBoolean) { this.headerRF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyHeaderRowCount() { return this.headerRF; }
/*      */   
/*      */   public void setApplyHeaderColCount(boolean paramBoolean) { this.headerCF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyHeaderColCount() { return this.headerCF; }
/*      */   
/*      */   public void setApplyColWidth(boolean paramBoolean) { this.widthF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyColWidth() { return this.widthF; }
/*      */   
/*      */   public void setApplyRowHeight(boolean paramBoolean) { this.heightF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyRowHeight() { return this.heightF; }
/*      */   
/*      */   public void setApplyRowBorderColor(boolean paramBoolean) { this.rowBorderCF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyRowBorderColor() { return this.rowBorderCF; }
/*      */   
/*      */   public void setApplyColBorderColor(boolean paramBoolean) { this.colBorderCF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyColBorderColor() { return this.colBorderCF; }
/*      */   
/*      */   public void setApplyRowBorder(boolean paramBoolean) { this.rowBorderF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyRowBorder() { return this.rowBorderF; }
/*      */   
/*      */   public void setApplyColBorder(boolean paramBoolean) { this.colBorderF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyColBorder() { return this.colBorderF; }
/*      */   
/*      */   public void setApplyInsets(boolean paramBoolean) { this.insetsF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyInsets() { return this.insetsF; }
/*      */   
/*      */   public void setApplySpan(boolean paramBoolean) { this.spanF = paramBoolean; }
/*      */   
/*      */   public boolean isApplySpan() { return this.spanF; }
/*      */   
/*      */   public void setApplyAlignment(boolean paramBoolean) { this.alignF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyAlignment() { return this.alignF; }
/*      */   
/*      */   public void setApplyFont(boolean paramBoolean) { this.fontF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyFont() { return this.fontF; }
/*      */   
/*      */   public void setApplyLineWrap(boolean paramBoolean) { this.wrapF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyLineWrap() { return this.wrapF; }
/*      */   
/*      */   public void setApplyForeground(boolean paramBoolean) { this.foregroundF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyForeground() { return this.foregroundF; }
/*      */   
/*      */   public void setApplyBackground(boolean paramBoolean) { this.backgroundF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyBackground() { return this.backgroundF; }
/*      */   
/*      */   public void setApplyPresenter(boolean paramBoolean) { this.presenterF = paramBoolean; }
/*      */   
/*      */   public boolean isApplyPresenter() { return this.presenterF; }
/*      */   
/*      */   public void setFormatFirstRow(boolean paramBoolean) { this.firstRow = new Boolean(paramBoolean); }
/*      */   
/*      */   public boolean isFormatFirstRow() { return (this.firstRow == null) ? ((this.table.getHeaderRowCount() >= 1)) : this.firstRow.booleanValue(); }
/*      */   
/*      */   public void setFormatFirstCol(boolean paramBoolean) { this.firstCol = new Boolean(paramBoolean); }
/*      */   
/*      */   public boolean isFormatFirstCol() { return (this.firstCol == null) ? ((this.table.getHeaderColCount() >= 1)) : this.firstCol.booleanValue(); }
/*      */   
/*      */   public void setFormatLastRow(boolean paramBoolean) { this.lastRow = paramBoolean; }
/*      */   
/*      */   public boolean isFormatLastRow() { return this.lastRow; }
/*      */   
/*      */   public void setFormatLastCol(boolean paramBoolean) { this.lastCol = paramBoolean; }
/*      */   
/*      */   public boolean isFormatLastCol() { return this.lastCol; }
/*      */   
/*      */   public Font createFont(Font paramFont, int paramInt) {
/*      */     if (paramFont == null)
/*      */       paramFont = this.defFont; 
/*      */     Font font = (Font)this.fnmap.get(paramFont);
/*      */     if (font != null && font.getStyle() == paramInt)
/*      */       return font; 
/*      */     StyleFont styleFont = (paramFont instanceof StyleFont) ? new StyleFont(paramFont.getName(), paramInt | ((StyleFont)paramFont).getStyle() & 0xFFF0, paramFont.getSize(), ((StyleFont)paramFont).getLineStyle()) : new Font(paramFont.getName(), paramInt, paramFont.getSize());
/*      */     this.fnmap.put(paramFont, styleFont);
/*      */     return styleFont;
/*      */   }
/*      */   
/*      */   public Font createFont(Font paramFont, int paramInt1, int paramInt2) {
/*      */     if (paramFont == null)
/*      */       paramFont = this.defFont; 
/*      */     return (paramFont instanceof StyleFont) ? new StyleFont(paramFont.getName(), paramInt1 | ((StyleFont)paramFont).getStyle() & 0xFFF0, paramInt2, ((StyleFont)paramFont).getLineStyle()) : new Font(paramFont.getName(), paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */   public Object clone() {
/*      */     try {
/*      */       TableStyle tableStyle = (TableStyle)super.clone();
/*      */       tableStyle.setTable(tableStyle.table);
/*      */       return tableStyle;
/*      */     } catch (Exception exception) {
/*      */       return null;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\style\TableStyle.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */