package inetsoft.report;

import java.awt.Insets;
import java.awt.Point;
import java.text.Format;

public interface TableElement extends ReportElement {
  Presenter getPresenter(Class paramClass);
  
  void addPresenter(Class paramClass, Presenter paramPresenter);
  
  Format getFormat(Class paramClass);
  
  void addFormat(Class paramClass, Format paramFormat);
  
  double getTableWidth();
  
  void setTableWidth(double paramDouble);
  
  int[] getFixedWidths();
  
  void setFixedWidths(int[] paramArrayOfInt);
  
  int getLayout();
  
  void setLayout(int paramInt);
  
  Insets getPadding();
  
  void setPadding(Insets paramInsets);
  
  int getTableAdvance();
  
  void setTableAdvance(int paramInt);
  
  TableLens getTable();
  
  void setTable(TableLens paramTableLens);
  
  float getColWidth(int paramInt);
  
  void setOrphanControl(boolean paramBoolean);
  
  boolean isOrphanControl();
  
  void setOnClickRange(Point[] paramArrayOfPoint);
  
  Point[] getOnClickRange();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TableElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */