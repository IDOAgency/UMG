package inetsoft.report;

public interface FieldElement extends PainterElement {
  String getName();
  
  void setName(String paramString);
  
  String getForm();
  
  void setForm(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\FieldElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */