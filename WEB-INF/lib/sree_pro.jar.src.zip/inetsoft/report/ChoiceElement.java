package inetsoft.report;

public interface ChoiceElement extends FieldElement {
  Object[] getChoices();
  
  void setChoices(Object[] paramArrayOfObject);
  
  Object getSelectedItem();
  
  void setSelectedItem(Object paramObject);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ChoiceElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */