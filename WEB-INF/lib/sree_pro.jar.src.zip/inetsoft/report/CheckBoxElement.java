package inetsoft.report;

public interface CheckBoxElement extends FieldElement {
  String getText();
  
  void setText(String paramString);
  
  boolean isSelected();
  
  void setSelected(boolean paramBoolean);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\CheckBoxElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */