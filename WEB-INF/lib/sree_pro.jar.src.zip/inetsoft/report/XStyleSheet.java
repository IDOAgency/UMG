/*     */ package inetsoft.report;
/*     */ 
/*     */ import inetsoft.report.internal.TableXElement;
/*     */ import inetsoft.report.internal.TextBased;
/*     */ import inetsoft.report.internal.Util;
/*     */ import inetsoft.report.lens.AttributeChartLens;
/*     */ import inetsoft.report.lens.AttributeFormLens;
/*     */ import inetsoft.report.style.TableStyle;
/*     */ import java.text.Format;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XStyleSheet
/*     */   extends StyleSheet
/*     */ {
/*     */   public void setElement(String paramString, Object paramObject) throws NoSuchElementException, IllegalArgumentException {
/* 104 */     ReportElement reportElement = getElement(paramString);
/* 105 */     if (reportElement == null) {
/* 106 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 109 */     setValue(reportElement, paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeInto(String paramString, TableLens paramTableLens) throws NoSuchElementException, IllegalArgumentException {
/* 128 */     ReportElement reportElement = getElement(paramString);
/* 129 */     if (reportElement == null) {
/* 130 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 133 */     if (reportElement instanceof TableElement) {
/* 134 */       TableLens tableLens = ((TableElement)reportElement).getTable();
/* 135 */       ((TableElement)reportElement).setTable(Util.merge(tableLens, paramTableLens));
/*     */     } else {
/*     */       
/* 138 */       throw new IllegalArgumentException(reportElement + ":" + paramTableLens);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableStyle getTableStyle(String paramString) {
/* 151 */     ReportElement reportElement = getElement(paramString);
/* 152 */     if (reportElement == null || !(reportElement instanceof TableElement)) {
/* 153 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 156 */     if (reportElement instanceof TableXElement) {
/* 157 */       return ((TableXElement)reportElement).getStyle();
/*     */     }
/*     */     
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableStyle(String paramString, TableStyle paramTableStyle) {
/* 172 */     ReportElement reportElement = getElement(paramString);
/* 173 */     if (reportElement == null || !(reportElement instanceof TableElement)) {
/* 174 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 177 */     ((TableXElement)reportElement).setStyle(paramTableStyle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableLens getTable(String paramString) {
/* 188 */     ReportElement reportElement = getElement(paramString);
/* 189 */     if (reportElement == null || !(reportElement instanceof TableElement)) {
/* 190 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 193 */     return ((TableXElement)reportElement).getTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeChartLens getChart(String paramString) {
/* 208 */     ReportElement reportElement = getElement(paramString);
/* 209 */     if (reportElement == null || !(reportElement instanceof inetsoft.report.internal.ChartXElement)) {
/* 210 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 213 */     ChartLens chartLens = ((ChartElement)reportElement).getChart();
/*     */     try {
/* 215 */       return (AttributeChartLens)chartLens;
/* 216 */     } catch (Exception exception) {
/*     */ 
/*     */       
/* 219 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttributeFormLens getForm(String paramString) {
/* 232 */     ReportElement reportElement = getElement(paramString);
/* 233 */     if (reportElement == null || !(reportElement instanceof inetsoft.report.internal.FormXElement)) {
/* 234 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 237 */     return (AttributeFormLens)((FormElement)reportElement).getForm();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText(String paramString) {
/* 246 */     ReportElement reportElement = getElement(paramString);
/* 247 */     if (reportElement == null || !(reportElement instanceof TextBased)) {
/* 248 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 251 */     return ((TextBased)reportElement).getText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPresenter(String paramString, Class paramClass, Presenter paramPresenter) {
/* 263 */     ReportElement reportElement = getElement(paramString);
/* 264 */     if (reportElement == null || !(reportElement instanceof TableElement)) {
/* 265 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 268 */     ((TableElement)reportElement).addPresenter(paramClass, paramPresenter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFormat(String paramString, Class paramClass, Format paramFormat) {
/* 280 */     ReportElement reportElement = getElement(paramString);
/* 281 */     if (reportElement == null || !(reportElement instanceof TableElement)) {
/* 282 */       throw new NoSuchElementException(paramString);
/*     */     }
/*     */     
/* 285 */     ((TableElement)reportElement).addFormat(paramClass, paramFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirectory(String paramString) {
/* 294 */     this.topdir = paramString;
/* 295 */     if (paramString.indexOf(":\\") > 0) {
/* 296 */       this.topdir = paramString.toLowerCase();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 304 */   public String getDirectory() { return this.topdir; }
/*     */ 
/*     */ 
/*     */   
/* 308 */   public String toString() { return "Report Template [[header:" + getHeaderElementCount() + "] [body:" + getElementCount() + "] [footer:" + getFooterElementCount() + "]]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 313 */   protected String topdir = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\XStyleSheet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */