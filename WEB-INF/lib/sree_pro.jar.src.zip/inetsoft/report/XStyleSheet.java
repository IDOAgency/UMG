package inetsoft.report;

import inetsoft.report.internal.TableXElement;
import inetsoft.report.internal.TextBased;
import inetsoft.report.internal.Util;
import inetsoft.report.lens.AttributeChartLens;
import inetsoft.report.lens.AttributeFormLens;
import inetsoft.report.style.TableStyle;
import java.text.Format;
import java.util.NoSuchElementException;

public class XStyleSheet extends StyleSheet {
  public void setElement(String paramString, Object paramObject) throws NoSuchElementException, IllegalArgumentException {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null)
      throw new NoSuchElementException(paramString); 
    setValue(reportElement, paramObject);
  }
  
  public void mergeInto(String paramString, TableLens paramTableLens) throws NoSuchElementException, IllegalArgumentException {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null)
      throw new NoSuchElementException(paramString); 
    if (reportElement instanceof TableElement) {
      TableLens tableLens = ((TableElement)reportElement).getTable();
      ((TableElement)reportElement).setTable(Util.merge(tableLens, paramTableLens));
    } else {
      throw new IllegalArgumentException(reportElement + ":" + paramTableLens);
    } 
  }
  
  public TableStyle getTableStyle(String paramString) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null || !(reportElement instanceof TableElement))
      throw new NoSuchElementException(paramString); 
    if (reportElement instanceof TableXElement)
      return ((TableXElement)reportElement).getStyle(); 
    return null;
  }
  
  public void setTableStyle(String paramString, TableStyle paramTableStyle) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null || !(reportElement instanceof TableElement))
      throw new NoSuchElementException(paramString); 
    ((TableXElement)reportElement).setStyle(paramTableStyle);
  }
  
  public TableLens getTable(String paramString) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null || !(reportElement instanceof TableElement))
      throw new NoSuchElementException(paramString); 
    return ((TableXElement)reportElement).getTable();
  }
  
  public AttributeChartLens getChart(String paramString) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null || !(reportElement instanceof inetsoft.report.internal.ChartXElement))
      throw new NoSuchElementException(paramString); 
    ChartLens chartLens = ((ChartElement)reportElement).getChart();
    try {
      return (AttributeChartLens)chartLens;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public AttributeFormLens getForm(String paramString) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null || !(reportElement instanceof inetsoft.report.internal.FormXElement))
      throw new NoSuchElementException(paramString); 
    return (AttributeFormLens)((FormElement)reportElement).getForm();
  }
  
  public String getText(String paramString) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null || !(reportElement instanceof TextBased))
      throw new NoSuchElementException(paramString); 
    return ((TextBased)reportElement).getText();
  }
  
  public void addPresenter(String paramString, Class paramClass, Presenter paramPresenter) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null || !(reportElement instanceof TableElement))
      throw new NoSuchElementException(paramString); 
    ((TableElement)reportElement).addPresenter(paramClass, paramPresenter);
  }
  
  public void addFormat(String paramString, Class paramClass, Format paramFormat) {
    ReportElement reportElement = getElement(paramString);
    if (reportElement == null || !(reportElement instanceof TableElement))
      throw new NoSuchElementException(paramString); 
    ((TableElement)reportElement).addFormat(paramClass, paramFormat);
  }
  
  public void setDirectory(String paramString) {
    this.topdir = paramString;
    if (paramString.indexOf(":\\") > 0)
      this.topdir = paramString.toLowerCase(); 
  }
  
  public String getDirectory() { return this.topdir; }
  
  public String toString() { return "Report Template [[header:" + getHeaderElementCount() + "] [body:" + getElementCount() + "] [footer:" + getFooterElementCount() + "]]"; }
  
  protected String topdir = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\XStyleSheet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */