/*      */ package inetsoft.report.io;
/*      */ import inetsoft.report.ChartDescriptor;
/*      */ import inetsoft.report.ChartElement;
/*      */ import inetsoft.report.ChartLens;
/*      */ import inetsoft.report.FixedContainer;
/*      */ import inetsoft.report.FormLens;
/*      */ import inetsoft.report.HeadingElement;
/*      */ import inetsoft.report.PageArea;
/*      */ import inetsoft.report.PainterElement;
/*      */ import inetsoft.report.ReportElement;
/*      */ import inetsoft.report.SectionBand;
/*      */ import inetsoft.report.SectionLens;
/*      */ import inetsoft.report.StyleSheet;
/*      */ import inetsoft.report.TableElement;
/*      */ import inetsoft.report.TableLens;
/*      */ import inetsoft.report.TextBoxElement;
/*      */ import inetsoft.report.TextElement;
/*      */ import inetsoft.report.internal.BaseElement;
/*      */ import inetsoft.report.internal.CheckBoxElementDef;
/*      */ import inetsoft.report.internal.ChoiceElementDef;
/*      */ import inetsoft.report.internal.FormXElement;
/*      */ import inetsoft.report.internal.ImageXElement;
/*      */ import inetsoft.report.internal.RadioButtonElementDef;
/*      */ import inetsoft.report.internal.TableAttr;
/*      */ import inetsoft.report.internal.TableXElement;
/*      */ import inetsoft.report.internal.TextAreaElementDef;
/*      */ import inetsoft.report.style.TableStyle;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.Enumeration;
/*      */ 
/*      */ class TemplateFormatter implements Formatter {
/*      */   public TemplateFormatter(OutputStream paramOutputStream) {
/*      */     try {
/*   39 */       this.writer = new PrintWriter(new OutputStreamWriter(this.output = paramOutputStream, "UTF8"));
/*      */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */       
/*   42 */       unsupportedEncodingException.printStackTrace();
/*      */     } 
/*      */   }
/*      */   protected PrintWriter writer;
/*      */   protected OutputStream output;
/*      */   protected StyleSheet sheet;
/*      */   
/*      */   public void prolog(StyleSheet paramStyleSheet) {
/*   50 */     this.sheet = paramStyleSheet;
/*      */     
/*   52 */     this.writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*      */     
/*   54 */     Margin margin = paramStyleSheet.getMargin();
/*   55 */     this.writer.print("<Report Top=\"" + margin.top + "\" Left=\"" + margin.left + "\" Bottom=\"" + margin.bottom + "\" Right=\"" + margin.right + "\" HeaderFromEdge=\"" + paramStyleSheet.getHeaderFromEdge() + "\" FooterFromEdge=\"" + paramStyleSheet.getFooterFromEdge() + "\" PageNumbering=\"" + paramStyleSheet.getPageNumberingStart() + "\" HorizontalWrap=\"" + paramStyleSheet.isHorizontalWrap() + "\"");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   63 */     this.writer.print(" TabStops=\"");
/*   64 */     double[] arrayOfDouble = paramStyleSheet.getCurrentTabStops();
/*   65 */     for (byte b = 0; b < arrayOfDouble.length; b++) {
/*   66 */       if (b) {
/*   67 */         this.writer.print(",");
/*      */       }
/*      */       
/*   70 */       this.writer.print(arrayOfDouble[b]);
/*      */     } 
/*      */     
/*   73 */     this.writer.println("\">");
/*      */     
/*   75 */     if (paramStyleSheet.getBackgroundImageLocation() != null) {
/*   76 */       ImageLocation imageLocation = paramStyleSheet.getBackgroundImageLocation();
/*   77 */       this.writer.println("<Background Path=\"" + imageLocation.getPath() + "\" PathType=\"" + imageLocation.getPathType() + "\" Embedded=\"" + imageLocation.isEmbedded() + "\">");
/*      */ 
/*      */ 
/*      */       
/*   81 */       if (imageLocation.isEmbedded()) {
/*   82 */         write((Image)paramStyleSheet.getBackground(), null);
/*      */       }
/*      */       
/*   85 */       this.writer.println("</Background>");
/*      */     }
/*   87 */     else if (paramStyleSheet.getBackground() instanceof Image) {
/*   88 */       this.writer.println("<Background>");
/*   89 */       write((Image)paramStyleSheet.getBackground(), null);
/*   90 */       this.writer.println("</Background>");
/*      */     }
/*   92 */     else if (paramStyleSheet.getBackground() instanceof Color) {
/*   93 */       Color color = (Color)paramStyleSheet.getBackground();
/*   94 */       this.writer.println("<Background Color=\"" + color.getRGB() + "\"/>");
/*      */     } 
/*      */     
/*   97 */     if (paramStyleSheet.getOnPageBreak() != null) {
/*   98 */       this.writer.println("<onPageBreak><![CDATA[" + paramStyleSheet.getOnPageBreak() + "]]></onPageBreak>");
/*      */     }
/*      */ 
/*      */     
/*  102 */     if (paramStyleSheet.getOnLoad() != null) {
/*  103 */       this.writer.println("<onLoad><![CDATA[" + paramStyleSheet.getOnLoad() + "]]></onLoad>");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  108 */     Properties properties = paramStyleSheet.getProperties();
/*  109 */     if (properties.size() > 0) {
/*  110 */       Enumeration enumeration1 = properties.propertyNames();
/*  111 */       this.writer.print("<Property");
/*      */       
/*  113 */       for (byte b1 = 0; enumeration1.hasMoreElements(); b1++) {
/*  114 */         String str = (String)enumeration1.nextElement();
/*  115 */         this.writer.print(" Name" + b1 + "=\"" + str + "\"" + " Value" + b1 + "=\"" + properties.getProperty(str) + "\"");
/*      */       } 
/*      */ 
/*      */       
/*  119 */       this.writer.println(">");
/*  120 */       this.writer.println("</Property>");
/*      */     } 
/*      */ 
/*      */     
/*  124 */     Hashtable hashtable = paramStyleSheet.getElementAreas();
/*  125 */     Enumeration enumeration = hashtable.keys();
/*  126 */     while (enumeration.hasMoreElements()) {
/*  127 */       String str = (String)enumeration.nextElement();
/*  128 */       PageArea[] arrayOfPageArea = (PageArea[])hashtable.get(str);
/*      */       
/*  130 */       this.writer.println("<PageLayout ID=\"" + str + "\" Count=\"" + arrayOfPageArea.length + "\">");
/*      */       
/*  132 */       writePageAreas(arrayOfPageArea);
/*  133 */       this.writer.println("</PageLayout>");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  142 */   public void startHeader(int paramInt) { this.writer.println("<Header Type=\"" + paramInt + "\">"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   public void startHeader(String paramString, boolean paramBoolean) { this.writer.println("<Header Type=\"Element\" ID=\"" + paramString + "\" Header=\"" + paramBoolean + "\">"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  159 */   public void endHeader() { this.writer.println("</Header>"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(XTableStyle paramXTableStyle) {
/*  166 */     this.writer.flush();
/*  167 */     paramXTableStyle.export(this.output);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(TextElement paramTextElement) {
/*  174 */     this.writer.print("<TextElement ");
/*  175 */     writeElementAttributes(paramTextElement);
/*  176 */     writeTabAttributes((TabSupport)paramTextElement);
/*  177 */     this.writer.print(" Justify=\"" + paramTextElement.isJustify() + "\"");
/*  178 */     this.writer.print(" Orphan=\"" + paramTextElement.isOrphanControl() + "\"");
/*  179 */     this.writer.println(" TextAdvance=\"" + paramTextElement.getTextAdvance() + "\">");
/*  180 */     writeElementProperties(paramTextElement);
/*  181 */     this.writer.println("<![CDATA[" + paramTextElement.getText() + "]]>");
/*  182 */     this.writer.println("</TextElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(HeadingElement paramHeadingElement) {
/*  189 */     this.writer.print("<HeadingElement ");
/*  190 */     writeElementAttributes(paramHeadingElement);
/*  191 */     this.writer.print(" Level=\"" + paramHeadingElement.getLevel() + "\" ");
/*  192 */     this.writer.print(" Justify=\"" + paramHeadingElement.isJustify() + "\"");
/*  193 */     this.writer.print(" Orphan=\"" + paramHeadingElement.isOrphanControl() + "\"");
/*  194 */     this.writer.println(" TextAdvance=\"" + paramHeadingElement.getTextAdvance() + "\">");
/*  195 */     writeElementProperties(paramHeadingElement);
/*  196 */     this.writer.println("<![CDATA[" + paramHeadingElement.getText() + "]]>");
/*  197 */     this.writer.println("</HeadingElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(TableElement paramTableElement) {
/*  204 */     TableXElement tableXElement = (TableXElement)paramTableElement;
/*  205 */     TableLens tableLens = tableXElement.getTable();
/*      */     
/*  207 */     this.writer.print("<TableElement ");
/*  208 */     writeElementAttributes(paramTableElement);
/*  209 */     this.writer.print(" TableWidth=\"" + paramTableElement.getTableWidth() + "\"");
/*      */     
/*  211 */     if (tableXElement.isEmbedWidth()) {
/*  212 */       int[] arrayOfInt = paramTableElement.getFixedWidths();
/*  213 */       if (arrayOfInt != null) {
/*  214 */         this.writer.print(" FixedWidths=\"");
/*  215 */         for (byte b = 0; b < arrayOfInt.length; b++) {
/*  216 */           if (b) {
/*  217 */             this.writer.print(",");
/*      */           }
/*      */           
/*  220 */           this.writer.print(arrayOfInt[b]);
/*      */         } 
/*  222 */         this.writer.print("\" ");
/*      */       } 
/*      */     } 
/*      */     
/*  226 */     this.writer.print(" Layout=\"" + paramTableElement.getLayout() + "\"");
/*  227 */     this.writer.print(" TableAdvance=\"" + paramTableElement.getTableAdvance() + "\"");
/*  228 */     this.writer.print(" OrphanControl=\"" + paramTableElement.isOrphanControl() + "\"");
/*      */     
/*  230 */     Insets insets = paramTableElement.getPadding();
/*  231 */     if (insets != null) {
/*  232 */       this.writer.print(" Padding=\"" + insets.top + "," + insets.left + "," + insets.bottom + "," + insets.right + "\"");
/*      */     }
/*      */ 
/*      */     
/*  236 */     TableStyle tableStyle = tableXElement.getStyle();
/*  237 */     if (tableStyle != null) {
/*  238 */       this.writer.print(" Style=\"" + tableStyle.getName() + "\"");
/*      */     }
/*      */     
/*  241 */     this.writer.println(" EmbedWidth=\"" + tableXElement.isEmbedWidth() + "\" Embedded=\"" + tableXElement.isEmbedded() + "\">");
/*      */ 
/*      */     
/*  244 */     writeElementProperties(paramTableElement);
/*      */     
/*  246 */     Point[] arrayOfPoint = tableXElement.getOnClickRange();
/*  247 */     if (arrayOfPoint != null) {
/*  248 */       for (byte b = 0; b < arrayOfPoint.length; b++) {
/*  249 */         this.writer.println("<onClickRange Row=\"" + (arrayOfPoint[b]).y + "\" Col=\"" + (arrayOfPoint[b]).x + "\"/>");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  254 */     if (tableStyle != null) {
/*  255 */       this.writer.print("<Style");
/*  256 */       this.writer.println(" RowBorderC=\"" + tableStyle.isApplyRowBorderColor() + "\" ColBorderC=\"" + tableStyle.isApplyColBorderColor() + "\" RowBorder=\"" + tableStyle.isApplyRowBorder() + "\" ColBorder=\"" + tableStyle.isApplyColBorder() + "\" Insets=\"" + tableStyle.isApplyInsets() + "\" Alignment=\"" + tableStyle.isApplyAlignment() + "\" Font=\"" + tableStyle.isApplyFont() + "\" LineWrap=\"" + tableStyle.isApplyLineWrap() + "\" Foreground=\"" + tableStyle.isApplyForeground() + "\" Background=\"" + tableStyle.isApplyBackground() + "\" FirstRow=\"" + tableStyle.isFormatFirstRow() + "\" FirstCol=\"" + tableStyle.isFormatFirstCol() + "\" LastRow=\"" + tableStyle.isFormatLastRow() + "\" LastCol=\"" + tableStyle.isFormatLastCol() + "\"/>");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  273 */     this.writer.println("<RowGroup>");
/*  274 */     Enumeration enumeration1 = tableXElement.getAttributeRows();
/*  275 */     while (enumeration1.hasMoreElements()) {
/*  276 */       int i = ((Integer)enumeration1.nextElement()).intValue();
/*      */ 
/*      */       
/*  279 */       if (tableLens != null && i >= tableLens.getRowCount()) {
/*      */         continue;
/*      */       }
/*      */       
/*  283 */       TableAttr tableAttr = tableXElement.getRowAttribute(i);
/*      */       
/*  285 */       this.writer.print("<Row index=\"" + i + "\"");
/*      */       
/*  287 */       if (tableAttr.alignment != null) {
/*  288 */         this.writer.print(" alignment=\"" + tableAttr.alignment + "\"");
/*      */       }
/*      */       
/*  291 */       if (tableAttr.format != null) {
/*  292 */         this.writer.print(" format=\"" + tableAttr.format + "\"");
/*      */       }
/*      */       
/*  295 */       if (tableAttr.format_spec != null) {
/*  296 */         this.writer.print(" format_spec=\"" + tableAttr.format_spec + "\"");
/*      */       }
/*      */       
/*  299 */       if (tableAttr.presenter != null) {
/*  300 */         this.writer.print(" presenter=\"" + tableAttr.presenter + "\"");
/*      */       }
/*      */       
/*  303 */       if (tableAttr.linewrap != null) {
/*  304 */         this.writer.print(" linewrap=\"" + tableAttr.presenter + "\"");
/*      */       }
/*      */       
/*  307 */       this.writer.println(">");
/*      */     } 
/*  309 */     this.writer.println("</RowGroup>");
/*      */     
/*  311 */     this.writer.println("<ColGroup>");
/*  312 */     Enumeration enumeration2 = tableXElement.getAttributeCols();
/*  313 */     while (enumeration2.hasMoreElements()) {
/*  314 */       int i = ((Integer)enumeration2.nextElement()).intValue();
/*      */ 
/*      */ 
/*      */       
/*  318 */       if (tableLens != null && i >= tableLens.getRowCount()) {
/*      */         continue;
/*      */       }
/*      */       
/*  322 */       TableAttr tableAttr = tableXElement.getColAttribute(i);
/*      */       
/*  324 */       this.writer.print("<Col index=\"" + i + "\"");
/*      */       
/*  326 */       if (tableAttr.alignment != null) {
/*  327 */         this.writer.print(" alignment=\"" + tableAttr.alignment + "\"");
/*      */       }
/*      */       
/*  330 */       if (tableAttr.format != null) {
/*  331 */         this.writer.print(" format=\"" + tableAttr.format + "\"");
/*      */       }
/*      */       
/*  334 */       if (tableAttr.format_spec != null) {
/*  335 */         this.writer.print(" format_spec=\"" + tableAttr.format_spec + "\"");
/*      */       }
/*      */       
/*  338 */       if (tableAttr.presenter != null) {
/*  339 */         this.writer.print(" presenter=\"" + tableAttr.presenter + "\"");
/*      */       }
/*      */       
/*  342 */       if (tableAttr.linewrap != null) {
/*  343 */         this.writer.print(" linewrap=\"" + tableAttr.presenter + "\"");
/*      */       }
/*      */       
/*  346 */       this.writer.println(">");
/*      */     } 
/*  348 */     this.writer.println("</ColGroup>");
/*      */     
/*  350 */     if (tableXElement.getFilter() != null) {
/*  351 */       tableXElement.getFilter().writeXML(this.writer);
/*      */     }
/*      */     
/*  354 */     if (tableXElement.isEmbedded()) {
/*  355 */       write(tableLens);
/*      */     }
/*      */     
/*  358 */     this.writer.println("</TableElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(FormElement paramFormElement) {
/*  365 */     FormXElement formXElement = (FormXElement)paramFormElement;
/*  366 */     FormLens formLens = formXElement.getForm();
/*      */     
/*  368 */     this.writer.print("<FormElement ");
/*  369 */     writeElementAttributes(paramFormElement);
/*      */     
/*  371 */     this.writer.print(" FieldPerRow=\"" + formLens.getFieldPerRow() + "\"");
/*      */     
/*  373 */     if (formLens.getLabelFont(false) != null) {
/*  374 */       this.writer.print(" LabelFont=\"" + StyleFont.toString(formLens.getLabelFont(0)) + "\"");
/*      */     }
/*      */ 
/*      */     
/*  378 */     if (formLens.getLabelForeground(false) != null) {
/*  379 */       this.writer.print(" LabelForeground=\"" + formLens.getLabelForeground(0).getRGB() + "\"");
/*      */     }
/*      */ 
/*      */     
/*  383 */     if (formLens.getLabelBackground(false) != null) {
/*  384 */       this.writer.print(" LabelBackground=\"" + formLens.getLabelBackground(0).getRGB() + "\"");
/*      */     }
/*      */ 
/*      */     
/*  388 */     if (formLens.getFont(false) != null) {
/*  389 */       this.writer.print(" FieldFont=\"" + StyleFont.toString(formLens.getFont(0)) + "\"");
/*      */     }
/*      */ 
/*      */     
/*  393 */     if (formLens.getForeground(false) != null) {
/*  394 */       this.writer.print(" FieldForeground=\"" + formLens.getForeground(0).getRGB() + "\"");
/*      */     }
/*      */ 
/*      */     
/*  398 */     if (formLens.getBackground(false) != null) {
/*  399 */       this.writer.print(" FieldBackground=\"" + formLens.getBackground(0).getRGB() + "\"");
/*      */     }
/*      */ 
/*      */     
/*  403 */     this.writer.print(" Underline=\"" + formLens.getUnderline() + "\"");
/*      */     
/*  405 */     this.writer.print(" EmbedWidth=\"" + formXElement.isEmbedWidth() + "\" Embedded=\"" + formXElement.isEmbedded() + "\"");
/*      */ 
/*      */     
/*  408 */     if (formXElement.isEmbedWidth()) {
/*  409 */       int[] arrayOfInt = paramFormElement.getFixedWidths();
/*  410 */       if (arrayOfInt != null) {
/*  411 */         this.writer.print(" FixedWidths=\"");
/*  412 */         for (byte b = 0; b < arrayOfInt.length; b++) {
/*  413 */           if (b) {
/*  414 */             this.writer.print(",");
/*      */           }
/*      */           
/*  417 */           this.writer.print(arrayOfInt[b]);
/*      */         } 
/*  419 */         this.writer.print("\" ");
/*      */       } 
/*      */     } 
/*  422 */     this.writer.println(">");
/*      */     
/*  424 */     writeElementProperties(paramFormElement);
/*      */     
/*  426 */     if (formXElement.isEmbedded()) {
/*  427 */       write(formXElement.getForm());
/*      */     }
/*      */     
/*  430 */     this.writer.println("</FormElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(PainterElement paramPainterElement) {
/*  437 */     if (paramPainterElement instanceof ImageXElement) {
/*  438 */       ImageXElement imageXElement = (ImageXElement)paramPainterElement;
/*      */       
/*  440 */       this.writer.print("<ImageElement ");
/*  441 */       writeElementAttributes(paramPainterElement);
/*  442 */       writePainterAttributes(paramPainterElement);
/*  443 */       this.writer.println(" PathType=\"" + imageXElement.getPathType() + "\" Path=\"" + imageXElement.getAdjustedPath() + "\" " + "Embedded=\"" + imageXElement.isEmbedded() + "\">");
/*      */ 
/*      */ 
/*      */       
/*  447 */       writeElementProperties(paramPainterElement);
/*      */       
/*  449 */       if (imageXElement.isEmbedded()) {
/*  450 */         write(imageXElement.getPainter(), imageXElement);
/*      */       }
/*      */       
/*  453 */       this.writer.println("</ImageElement>");
/*      */     }
/*  455 */     else if (paramPainterElement instanceof ButtonElementDef) {
/*  456 */       ButtonElementDef buttonElementDef = (ButtonElementDef)paramPainterElement;
/*  457 */       this.writer.print("<ButtonElement ");
/*  458 */       writeElementAttributes(paramPainterElement);
/*  459 */       writePainterAttributes(paramPainterElement);
/*  460 */       this.writer.println(" Name=\"" + buttonElementDef.getName() + "\"" + " Form=\"" + buttonElementDef.getForm() + "\"" + " Text=\"" + buttonElementDef.getText() + "\">");
/*      */ 
/*      */       
/*  463 */       writeElementProperties(paramPainterElement);
/*  464 */       this.writer.println("</ButtonElement>");
/*      */     }
/*  466 */     else if (paramPainterElement instanceof ImageButtonElementDef) {
/*  467 */       ImageButtonElementDef imageButtonElementDef = (ImageButtonElementDef)paramPainterElement;
/*  468 */       this.writer.print("<ImageButtonElement ");
/*  469 */       writeElementAttributes(paramPainterElement);
/*  470 */       writePainterAttributes(paramPainterElement);
/*  471 */       this.writer.println(" Name=\"" + imageButtonElementDef.getName() + "\"" + " Form=\"" + imageButtonElementDef.getForm() + "\"" + " Resource=\"" + imageButtonElementDef.getResource() + "\">");
/*      */ 
/*      */       
/*  474 */       writeElementProperties(paramPainterElement);
/*  475 */       this.writer.println("</ImageButtonElement>");
/*      */     }
/*  477 */     else if (paramPainterElement instanceof RadioButtonElementDef) {
/*  478 */       RadioButtonElementDef radioButtonElementDef = (RadioButtonElementDef)paramPainterElement;
/*  479 */       this.writer.print("<RadioButtonElement ");
/*  480 */       writeElementAttributes(paramPainterElement);
/*  481 */       writePainterAttributes(paramPainterElement);
/*  482 */       this.writer.println(" Name=\"" + radioButtonElementDef.getName() + "\"" + " Form=\"" + radioButtonElementDef.getForm() + "\"" + " Text=\"" + radioButtonElementDef.getText() + "\"" + " Selected=\"" + radioButtonElementDef.isSelected() + "\"" + " Group=\"" + radioButtonElementDef.getGroup() + "\">");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  487 */       writeElementProperties(paramPainterElement);
/*  488 */       this.writer.println("</RadioButtonElement>");
/*      */     }
/*  490 */     else if (paramPainterElement instanceof CheckBoxElementDef) {
/*  491 */       CheckBoxElementDef checkBoxElementDef = (CheckBoxElementDef)paramPainterElement;
/*  492 */       this.writer.print("<CheckBoxElement ");
/*  493 */       writeElementAttributes(paramPainterElement);
/*  494 */       writePainterAttributes(paramPainterElement);
/*  495 */       this.writer.println(" Name=\"" + checkBoxElementDef.getName() + "\"" + " Form=\"" + checkBoxElementDef.getForm() + "\"" + " Text=\"" + checkBoxElementDef.getText() + "\"" + " Selected=\"" + checkBoxElementDef.isSelected() + "\">");
/*      */ 
/*      */ 
/*      */       
/*  499 */       writeElementProperties(paramPainterElement);
/*  500 */       this.writer.println("</CheckBoxElement>");
/*      */     }
/*  502 */     else if (paramPainterElement instanceof ChoiceElementDef) {
/*  503 */       ChoiceElementDef choiceElementDef = (ChoiceElementDef)paramPainterElement;
/*  504 */       this.writer.print("<ChoiceElement ");
/*  505 */       writeElementAttributes(paramPainterElement);
/*  506 */       writePainterAttributes(paramPainterElement);
/*  507 */       this.writer.print(" Name=\"" + choiceElementDef.getName() + "\"" + " Form=\"" + choiceElementDef.getForm() + "\"");
/*      */ 
/*      */       
/*  510 */       if (choiceElementDef.getSelectedItem() != null) {
/*  511 */         this.writer.print(" SelectedItem=\"" + choiceElementDef.getSelectedItem() + "\"");
/*      */       }
/*      */       
/*  514 */       this.writer.println(">");
/*  515 */       writeElementProperties(paramPainterElement);
/*      */       
/*  517 */       Object[] arrayOfObject = choiceElementDef.getChoices();
/*  518 */       for (byte b = 0; b < arrayOfObject.length; b++) {
/*  519 */         this.writer.println("<Choice>\"" + arrayOfObject[b] + "\"</Choice>");
/*      */       }
/*      */       
/*  522 */       this.writer.println("</ChoiceElement>");
/*      */     }
/*  524 */     else if (paramPainterElement instanceof TextFieldElementDef) {
/*  525 */       TextFieldElementDef textFieldElementDef = (TextFieldElementDef)paramPainterElement;
/*  526 */       this.writer.print("<TextFieldElement ");
/*  527 */       writeElementAttributes(paramPainterElement);
/*  528 */       writePainterAttributes(paramPainterElement);
/*  529 */       this.writer.println(" Name=\"" + textFieldElementDef.getName() + "\"" + " Form=\"" + textFieldElementDef.getForm() + "\"" + " Text=\"" + textFieldElementDef.getText() + "\"" + " Cols=\"" + textFieldElementDef.getCols() + "\">");
/*      */ 
/*      */ 
/*      */       
/*  533 */       writeElementProperties(paramPainterElement);
/*  534 */       this.writer.println("</TextFieldElement>");
/*      */     }
/*  536 */     else if (paramPainterElement instanceof TextAreaElementDef) {
/*  537 */       TextAreaElementDef textAreaElementDef = (TextAreaElementDef)paramPainterElement;
/*  538 */       this.writer.print("<TextAreaElement ");
/*  539 */       writeElementAttributes(paramPainterElement);
/*  540 */       writePainterAttributes(paramPainterElement);
/*  541 */       this.writer.println(" Name=\"" + textAreaElementDef.getName() + "\"" + " Form=\"" + textAreaElementDef.getForm() + "\"" + " Text=\"" + textAreaElementDef.getText() + "\"" + " Cols=\"" + textAreaElementDef.getCols() + "\"" + " Rows=\"" + textAreaElementDef.getRows() + "\">");
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  546 */       writeElementProperties(paramPainterElement);
/*  547 */       this.writer.println("</TextAreaElement>");
/*      */     } else {
/*      */       
/*  550 */       this.writer.print("<PainterElement ");
/*  551 */       writeElementAttributes(paramPainterElement);
/*  552 */       writePainterAttributes(paramPainterElement);
/*      */       
/*  554 */       if (paramPainterElement.getPainter() instanceof inetsoft.report.painter.BulletPainter) {
/*  555 */         this.writer.print(" Painter=\"bullet\"");
/*      */       }
/*      */       
/*  558 */       this.writer.println(">");
/*  559 */       writeElementProperties(paramPainterElement);
/*  560 */       this.writer.println("</PainterElement>");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(ChartElement paramChartElement) {
/*  568 */     ChartXElement chartXElement = (ChartXElement)paramChartElement;
/*      */     
/*  570 */     this.writer.print("<ChartElement ");
/*  571 */     writeElementAttributes(paramChartElement);
/*  572 */     writePainterAttributes(paramChartElement);
/*  573 */     this.writer.println(" Embedded=\"" + chartXElement.isEmbedded() + "\">");
/*      */     
/*  575 */     writeElementProperties(paramChartElement);
/*      */     
/*  577 */     ChartDescriptor chartDescriptor = paramChartElement.getChartDescriptor();
/*  578 */     if (chartDescriptor != null) {
/*  579 */       writeChartDescriptor(chartDescriptor);
/*      */     }
/*      */     
/*  582 */     if (chartXElement.getDataset() != null) {
/*  583 */       chartXElement.getDataset().writeXML(this.writer);
/*      */     }
/*      */     
/*  586 */     write(paramChartElement.getChart(), chartXElement.isEmbedded());
/*      */     
/*  588 */     this.writer.println("</ChartElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeChartDescriptor(ChartDescriptor paramChartDescriptor) {
/*  595 */     this.writer.print("<ChartDescriptor");
/*      */     
/*  597 */     DecimalFormat decimalFormat = (DecimalFormat)paramChartDescriptor.getValueFormat();
/*  598 */     if (decimalFormat != null) {
/*  599 */       this.writer.print(" ValueFormat=\"" + decimalFormat.toPattern() + "\"");
/*      */     }
/*      */     
/*  602 */     decimalFormat = (DecimalFormat)paramChartDescriptor.getYAxisFormat();
/*  603 */     if (decimalFormat != null) {
/*  604 */       this.writer.print(" YAxisFormat=\"" + decimalFormat.toPattern() + "\"");
/*      */     }
/*      */     
/*  607 */     decimalFormat = (DecimalFormat)paramChartDescriptor.getSecondaryYAxisFormat();
/*  608 */     if (decimalFormat != null) {
/*  609 */       this.writer.print(" SecondaryYAxisFormat=\"" + decimalFormat.toPattern() + "\"");
/*      */     }
/*      */     
/*  612 */     this.writer.print(" PointStyle=\"");
/*  613 */     for (byte b = 0; b < 8; b++) {
/*  614 */       if (b) {
/*  615 */         this.writer.print(",");
/*      */       }
/*      */       
/*  618 */       this.writer.print(paramChartDescriptor.getPointStyle(b));
/*      */     } 
/*  620 */     this.writer.print("\"");
/*      */     
/*  622 */     this.writer.print(" FirstDatasetOfSecondaryAxis=\"" + paramChartDescriptor.getFirstDatasetOfSecondaryAxis() + "\"");
/*      */     
/*  624 */     this.writer.print(" VerticalGridStyle=\"" + paramChartDescriptor.getVerticalGridStyle() + "\"");
/*      */     
/*  626 */     this.writer.print(" LogarithmicYScale=\"" + paramChartDescriptor.isLogarithmicYScale() + "\"");
/*      */     
/*  628 */     this.writer.print(" SecondaryLogarithmicYScale=\"" + paramChartDescriptor.isSecondaryLogarithmicYScale() + "\"");
/*      */ 
/*      */     
/*  631 */     if (paramChartDescriptor.getSecondaryMaximum() != null) {
/*  632 */       this.writer.print(" SecondaryMaximum=\"" + paramChartDescriptor.getSecondaryMaximum() + "\"");
/*      */     }
/*      */ 
/*      */     
/*  636 */     if (paramChartDescriptor.getSecondaryMinimum() != null) {
/*  637 */       this.writer.print(" SecondaryMinimum=\"" + paramChartDescriptor.getSecondaryMinimum() + "\"");
/*      */     }
/*      */ 
/*      */     
/*  641 */     if (paramChartDescriptor.getSecondaryIncrement() != null) {
/*  642 */       this.writer.print(" SecondaryIncrement=\"" + paramChartDescriptor.getSecondaryIncrement() + "\"");
/*      */     }
/*      */ 
/*      */     
/*  646 */     if (paramChartDescriptor.getSecondaryMinorIncrement() != null) {
/*  647 */       this.writer.print(" SecondaryMinorIncrement=\"" + paramChartDescriptor.getSecondaryMinorIncrement() + "\"");
/*      */     }
/*      */ 
/*      */     
/*  651 */     if (paramChartDescriptor.getSecondaryYTitle() != null) {
/*  652 */       this.writer.print(" SecondaryYTitle=\"" + paramChartDescriptor.getSecondaryYTitle() + "\"");
/*      */     }
/*      */     
/*  655 */     this.writer.println(" LineWidth=\"" + paramChartDescriptor.getLineChartLineWidth() + "\" PointSize=\"" + paramChartDescriptor.getPointSize() + "\" XLabelRotation=\"" + paramChartDescriptor.getXLabelRotation() + "\" BarBorder=\"" + paramChartDescriptor.isBarBorder() + "\"/>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(TextBoxElement paramTextBoxElement) {
/*  665 */     this.writer.print("<TextBoxElement ");
/*  666 */     writeElementAttributes(paramTextBoxElement);
/*  667 */     writePainterAttributes(paramTextBoxElement);
/*      */     
/*  669 */     this.writer.print(" Border=\"" + paramTextBoxElement.getBorder() + "\" Shape=\"" + paramTextBoxElement.getShape() + "\" Justify=\"" + paramTextBoxElement.isJustify() + "\" TextAlignment=\"" + paramTextBoxElement.getTextAlignment() + "\"");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  674 */     Insets insets1 = paramTextBoxElement.getPadding();
/*  675 */     if (insets1 != null) {
/*  676 */       this.writer.print(" Padding=\"" + insets1.top + "," + insets1.left + "," + insets1.bottom + "," + insets1.right + "\"");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  681 */     Insets insets2 = paramTextBoxElement.getBorders();
/*  682 */     if (insets2 != null) {
/*  683 */       this.writer.print(" Borders=\"" + insets2.top + "," + insets2.left + "," + insets2.bottom + "," + insets2.right + "\"");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  688 */     this.writer.println(">");
/*  689 */     writeElementProperties(paramTextBoxElement);
/*  690 */     this.writer.println("<![CDATA[" + paramTextBoxElement.getText() + "]]>");
/*  691 */     this.writer.println("</TextBoxElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(TabElement paramTabElement) {
/*  698 */     this.writer.print("<TabElement ");
/*  699 */     writeElementAttributes(paramTabElement);
/*  700 */     writeTabAttributes((TabSupport)paramTabElement);
/*  701 */     this.writer.println(" RightTab=\"" + paramTabElement.isRightTab() + "\">");
/*  702 */     writeElementProperties(paramTabElement);
/*  703 */     this.writer.println("</TabElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeTabAttributes(TabSupport paramTabSupport) {
/*  710 */     this.writer.print(" FillStyle=\"" + paramTabSupport.getFillStyle() + "\" TabStops=\"");
/*      */ 
/*      */     
/*  713 */     double[] arrayOfDouble = paramTabSupport.getTabStops();
/*  714 */     for (byte b = 0; b < arrayOfDouble.length; b++) {
/*  715 */       if (b) {
/*  716 */         this.writer.print(",");
/*      */       }
/*      */       
/*  719 */       this.writer.print(arrayOfDouble[b]);
/*      */     } 
/*  721 */     this.writer.print("\"");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(NewlineElement paramNewlineElement) {
/*  728 */     this.writer.print("<NewlineElement ");
/*  729 */     writeElementAttributes(paramNewlineElement);
/*  730 */     this.writer.println(" Count=\"" + paramNewlineElement.getCount() + "\">");
/*  731 */     writeElementProperties(paramNewlineElement);
/*  732 */     this.writer.println("</NewlineElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(AreaBreakElement paramAreaBreakElement) {
/*  739 */     this.writer.print("<AreaBreakElement ");
/*  740 */     writeElementAttributes(paramAreaBreakElement);
/*  741 */     this.writer.println(">");
/*  742 */     writeElementProperties(paramAreaBreakElement);
/*  743 */     this.writer.println("</AreaBreakElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(PageBreakElement paramPageBreakElement) {
/*  750 */     this.writer.print("<PageBreakElement ");
/*  751 */     writeElementAttributes(paramPageBreakElement);
/*  752 */     this.writer.println(">");
/*  753 */     writeElementProperties(paramPageBreakElement);
/*  754 */     this.writer.println("</PageBreakElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(SectionElement paramSectionElement) {
/*  761 */     this.writer.print("<SectionElement ");
/*  762 */     writeElementAttributes(paramSectionElement);
/*  763 */     this.writer.println(">");
/*  764 */     writeElementProperties(paramSectionElement);
/*      */     
/*  766 */     if (paramSectionElement instanceof SectionXElement) {
/*  767 */       SectionXElement sectionXElement = (SectionXElement)paramSectionElement;
/*  768 */       if (sectionXElement.getFilter() != null) {
/*  769 */         sectionXElement.getFilter().writeXML(this.writer);
/*      */       }
/*      */     } 
/*      */     
/*  773 */     writeSection(paramSectionElement.getSection());
/*      */     
/*  775 */     this.writer.println("</SectionElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeSection(SectionLens paramSectionLens) {
/*  782 */     if (paramSectionLens == null) {
/*      */       return;
/*      */     }
/*      */     
/*  786 */     this.writer.println("<Section>");
/*      */     
/*  788 */     if (paramSectionLens.getSectionHeader() != null) {
/*  789 */       this.writer.println("<SectionHeader>");
/*  790 */       writeSectionBand(paramSectionLens.getSectionHeader());
/*  791 */       this.writer.println("</SectionHeader>");
/*      */     } 
/*      */     
/*  794 */     if (paramSectionLens.getSectionContent() instanceof SectionLens) {
/*  795 */       this.writer.println("<SectionContent>");
/*  796 */       writeSection((SectionLens)paramSectionLens.getSectionContent());
/*  797 */       this.writer.println("</SectionContent>");
/*      */     }
/*  799 */     else if (paramSectionLens.getSectionContent() instanceof SectionBand) {
/*  800 */       this.writer.println("<SectionContent>");
/*  801 */       writeSectionBand((SectionBand)paramSectionLens.getSectionContent());
/*  802 */       this.writer.println("</SectionContent>");
/*      */     } 
/*      */     
/*  805 */     if (paramSectionLens.getSectionFooter() != null) {
/*  806 */       this.writer.println("<SectionFooter>");
/*  807 */       writeSectionBand(paramSectionLens.getSectionFooter());
/*  808 */       this.writer.println("</SectionFooter>");
/*      */     } 
/*      */     
/*  811 */     this.writer.println("</Section>");
/*      */   }
/*      */   
/*      */   protected void writeSectionBand(SectionBand paramSectionBand) {
/*  815 */     if (paramSectionBand == null) {
/*      */       return;
/*      */     }
/*      */     
/*  819 */     this.writer.print("<SectionBand Height=\"" + paramSectionBand.getHeight() + "\"");
/*  820 */     this.writer.print(" Visible=\"" + paramSectionBand.isVisible() + "\" ShrinkToFit=\"" + paramSectionBand.isShrinkToFit() + "\" PageBefore=\"" + paramSectionBand.isPageBefore() + "\" PageAfter=\"" + paramSectionBand.isPageAfter() + "\" TopBorder=\"" + paramSectionBand.getTopBorder() + "\" LeftBorder=\"" + paramSectionBand.getLeftBorder() + "\" BottomBorder=\"" + paramSectionBand.getBottomBorder() + "\" RightBorder=\"" + paramSectionBand.getRightBorder() + "\"");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  828 */     this.writer.println(" Elements=\"" + paramSectionBand.getElementCount() + "\">");
/*      */     
/*  830 */     for (byte b = 0; b < paramSectionBand.getElementCount(); b++) {
/*  831 */       Rectangle rectangle = paramSectionBand.getBounds(b);
/*  832 */       ReportElement reportElement = paramSectionBand.getElement(b);
/*  833 */       Builder.write(this, reportElement);
/*      */       
/*  835 */       this.writer.print("<FieldProperty X=\"" + rectangle.x + "\" Y=\"" + rectangle.y + "\" Width=\"" + rectangle.width + "\" Height=\"" + rectangle.height + "\"");
/*      */ 
/*      */ 
/*      */       
/*  839 */       String str = paramSectionBand.getBinding(reportElement.getID());
/*  840 */       if (str != null) {
/*  841 */         this.writer.print(" Binding=\"" + str + "\"");
/*      */       }
/*      */       
/*  844 */       this.writer.println("/>");
/*      */     } 
/*      */     
/*  847 */     this.writer.println("</SectionBand>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(PageLayoutElement paramPageLayoutElement) {
/*  854 */     PageArea[] arrayOfPageArea = paramPageLayoutElement.getPageAreas();
/*      */     
/*  856 */     this.writer.print("<PageLayoutElement Count=\"" + arrayOfPageArea.length + "\" ");
/*  857 */     writeElementAttributes(paramPageLayoutElement);
/*  858 */     this.writer.println(">");
/*  859 */     writeElementProperties(paramPageLayoutElement);
/*  860 */     writePageAreas(arrayOfPageArea);
/*      */     
/*  862 */     this.writer.println("</PageLayoutElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writePageAreas(PageArea[] paramArrayOfPageArea) {
/*  869 */     for (byte b = 0; b < paramArrayOfPageArea.length; b++) {
/*  870 */       FixedContainer fixedContainer = paramArrayOfPageArea[b].getElements();
/*      */       
/*  872 */       this.writer.print("<Area X=\"" + (paramArrayOfPageArea[b]).x + "\" Y=\"" + (paramArrayOfPageArea[b]).y + "\" Width=\"" + (paramArrayOfPageArea[b]).width + "\" Height=\"" + (paramArrayOfPageArea[b]).height + "\" Relative=\"" + paramArrayOfPageArea[b].isRelative() + "\" Flow=\"" + paramArrayOfPageArea[b].isFlow() + "\" Repeat=\"" + paramArrayOfPageArea[b].isRepeat() + "\" Border=\"" + paramArrayOfPageArea[b].getBorder() + "\" BorderColor=\"" + paramArrayOfPageArea[b].getBorderColor().getRGB() + "\" Insets=\"" + (paramArrayOfPageArea[b].getInsets()).top + "," + (paramArrayOfPageArea[b].getInsets()).left + "," + (paramArrayOfPageArea[b].getInsets()).bottom + "," + (paramArrayOfPageArea[b].getInsets()).right + "\"");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  883 */       if (fixedContainer != null) {
/*  884 */         this.writer.print(" Elements=\"" + fixedContainer.getElementCount() + "\"");
/*      */       }
/*      */       
/*  887 */       this.writer.println(">");
/*      */ 
/*      */       
/*  890 */       if (fixedContainer != null) {
/*  891 */         for (byte b1 = 0; b1 < fixedContainer.getElementCount(); b1++) {
/*  892 */           Rectangle rectangle = fixedContainer.getBounds(b1);
/*  893 */           Builder.write(this, fixedContainer.getElement(b1));
/*      */           
/*  895 */           this.writer.println("<Bounds X=\"" + rectangle.x + "\" Y=\"" + rectangle.y + "\" Width=\"" + rectangle.width + "\" Height=\"" + rectangle.height + "\"/>");
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  901 */       this.writer.println("</Area>");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(CondPageBreakElement paramCondPageBreakElement) {
/*  909 */     this.writer.print("<CondPageBreakElement ");
/*  910 */     writeElementAttributes(paramCondPageBreakElement);
/*  911 */     this.writer.println(" CondHeight=\"" + paramCondPageBreakElement.getCondHeight() + "\">");
/*  912 */     writeElementProperties(paramCondPageBreakElement);
/*  913 */     this.writer.println("</CondPageBreakElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(SpaceElement paramSpaceElement) {
/*  920 */     this.writer.print("<SpaceElement ");
/*  921 */     writeElementAttributes(paramSpaceElement);
/*  922 */     this.writer.println(" Space=\"" + paramSpaceElement.getSpace() + "\">");
/*  923 */     writeElementProperties(paramSpaceElement);
/*  924 */     this.writer.println("</SpaceElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(SeparatorElement paramSeparatorElement) {
/*  931 */     this.writer.print("<SeparatorElement ");
/*  932 */     writeElementAttributes(paramSeparatorElement);
/*  933 */     this.writer.println(" Style=\"" + paramSeparatorElement.getStyle() + "\" SeparatorAdvance=\"" + paramSeparatorElement.getSeparatorAdvance() + "\">");
/*      */     
/*  935 */     writeElementProperties(paramSeparatorElement);
/*  936 */     this.writer.println("</SeparatorElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(TOCElement paramTOCElement) {
/*  943 */     this.writer.print("<TOCElement ");
/*  944 */     writeElementAttributes(paramTOCElement);
/*  945 */     this.writer.println(" Style=\"" + paramTOCElement.getTOC().getClass().getName() + "\">");
/*  946 */     writeElementProperties(paramTOCElement);
/*  947 */     this.writer.println("</TOCElement>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(CompositeElement paramCompositeElement) {
/*  954 */     if (paramCompositeElement.getComposite() instanceof inetsoft.report.internal.EmptyContainer) {
/*  955 */       this.writer.println("<CompositeElement ID=\"" + paramCompositeElement.getID() + "\"/>");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void end() {
/*  963 */     this.writer.println("</Report>");
/*  964 */     this.writer.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeElementAttributes(ReportElement paramReportElement) {
/*  971 */     BaseElement baseElement = (BaseElement)paramReportElement;
/*  972 */     if (baseElement.getID() != null) {
/*  973 */       this.writer.print("ID=\"" + baseElement.getID() + "\" ");
/*      */     }
/*      */     
/*  976 */     this.writer.print("Alignment=\"" + baseElement.getAlignment() + "\" Indent=\"" + baseElement.getIndent() + "\" Hindent=\"" + baseElement.getHindent() + "\" Font=\"" + StyleFont.toString(baseElement.getFont()) + "\" Foreground=\"" + baseElement.getForeground().getRGB() + "\" Spacing=\"" + baseElement.getSpacing() + "\" Block=\"" + baseElement.isBlock() + "\" Continuation=\"" + baseElement.isContinuation() + "\" Visible=\"" + baseElement.isVisible() + "\" KeepWithNext=\"" + baseElement.isKeepWithNext() + "\"");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  985 */     if (baseElement.getBackground() != null) {
/*  986 */       this.writer.print(" Background=\"" + baseElement.getBackground().getRGB() + "\"");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeElementProperties(ReportElement paramReportElement) {
/*  994 */     BaseElement baseElement = (BaseElement)paramReportElement;
/*  995 */     Enumeration enumeration = baseElement.getPropertyNames();
/*      */     
/*  997 */     while (enumeration.hasMoreElements()) {
/*  998 */       String str = (String)enumeration.nextElement();
/*  999 */       this.writer.println("<property><name><![CDATA[" + str + "]]></name><value><![CDATA[" + baseElement.getProperty(str) + "]]></value></property>");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1004 */     if (paramReportElement.getScript() != null) {
/* 1005 */       this.writer.println("<script><![CDATA[" + paramReportElement.getScript() + "]]></script>");
/*      */     }
/*      */ 
/*      */     
/* 1009 */     if (paramReportElement.getOnClick() != null) {
/* 1010 */       this.writer.println("<onClick><![CDATA[" + paramReportElement.getOnClick() + "]]></onClick>");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writePainterAttributes(PainterElement paramPainterElement) {
/* 1019 */     this.writer.print(" Layout=\"" + paramPainterElement.getLayout() + "\" Wrapping=\"" + paramPainterElement.getWrapping() + "\"");
/*      */ 
/*      */     
/* 1022 */     Position position = paramPainterElement.getAnchor();
/* 1023 */     if (position != null) {
/* 1024 */       this.writer.print(" Anchor=\"" + position.x + "," + position.y + "\"");
/*      */     }
/*      */     
/* 1027 */     Size size = paramPainterElement.getSize();
/* 1028 */     if (size != null) {
/* 1029 */       this.writer.print(" Size=\"" + size.width + "x" + size.height + "\"");
/*      */     }
/*      */     
/* 1032 */     Insets insets = paramPainterElement.getMargin();
/* 1033 */     if (insets != null) {
/* 1034 */       this.writer.print(" Margin=\"" + insets.top + "," + insets.left + "," + insets.bottom + "," + insets.right + "\"");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void write(TableLens paramTableLens) {
/* 1043 */     this.writer.println("<Table Rows=\"" + paramTableLens.getRowCount() + "\" Cols=\"" + paramTableLens.getColCount() + "\" HeaderRow=\"" + paramTableLens.getHeaderRowCount() + "\" HeaderCol=\"" + paramTableLens.getHeaderColCount() + "\">");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1048 */     for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
/* 1049 */       this.writer.println("<TR>");
/*      */       
/* 1051 */       for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++) {
/* 1052 */         this.writer.print("<TD>\"");
/* 1053 */         this.writer.print(String.valueOf(paramTableLens.getObject(b, b1)));
/* 1054 */         this.writer.print("\"</TD>");
/*      */       } 
/*      */       
/* 1057 */       this.writer.println("</TR>");
/*      */     } 
/*      */     
/* 1060 */     this.writer.println("</Table>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void write(FormLens paramFormLens) {
/* 1084 */     this.writer.println("<Form Fields=\"" + paramFormLens.getFieldCount() + "\">");
/* 1085 */     this.writer.print("<![CDATA[");
/*      */     
/* 1087 */     for (byte b = 0; b < paramFormLens.getFieldCount(); b++) {
/* 1088 */       this.writer.println(toString(paramFormLens.getLabel(b)) + "|" + toString(paramFormLens.getField(b)));
/*      */     }
/*      */ 
/*      */     
/* 1092 */     this.writer.println("]]></Form>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void write(ChartLens paramChartLens, boolean paramBoolean) {
/* 1099 */     this.writer.print("<Chart Datasets=\"" + paramChartLens.getDatasetCount() + "\" Size=\"" + paramChartLens.getDatasetSize() + "\"");
/*      */     
/* 1101 */     this.writer.print(" Style=\"" + paramChartLens.getStyle() + "\"");
/*      */     
/* 1103 */     if (paramChartLens.getMaximum() != null) {
/* 1104 */       this.writer.print(" Maximum=\"" + paramChartLens.getMaximum() + "\"");
/*      */     }
/*      */     
/* 1107 */     if (paramChartLens.getMinimum() != null) {
/* 1108 */       this.writer.print(" Minimum=\"" + paramChartLens.getMinimum() + "\"");
/*      */     }
/*      */     
/* 1111 */     if (paramChartLens.getIncrement() != null) {
/* 1112 */       this.writer.print(" Increment=\"" + paramChartLens.getIncrement() + "\"");
/*      */     }
/*      */     
/* 1115 */     if (paramChartLens.getMinorIncrement() != null) {
/* 1116 */       this.writer.print(" MinorIncrement=\"" + paramChartLens.getMinorIncrement() + "\"");
/*      */     }
/*      */     
/* 1119 */     this.writer.print(" Gap=\"" + paramChartLens.getGap() + "\"");
/*      */     
/* 1121 */     if (paramChartLens.getXTitle() != null) {
/* 1122 */       this.writer.print(" XTitle=\"" + paramChartLens.getXTitle() + '"');
/*      */     }
/*      */     
/* 1125 */     if (paramChartLens.getYTitle() != null) {
/* 1126 */       this.writer.print(" YTitle=\"" + paramChartLens.getYTitle() + '"');
/*      */     }
/*      */     
/* 1129 */     if (paramChartLens.getTitleFont() != null) {
/* 1130 */       this.writer.print(" TitleFont=\"" + StyleFont.toString(paramChartLens.getTitleFont()) + "\"");
/*      */     }
/*      */ 
/*      */     
/* 1134 */     if (paramChartLens instanceof AttributeChartLens) {
/* 1135 */       this.writer.print(" BlackWhite=\"" + ((AttributeChartLens)paramChartLens).isBlackWhite() + "\"");
/*      */     }
/*      */ 
/*      */     
/* 1139 */     this.writer.print(" Styles=\"");
/* 1140 */     for (byte b1 = 0; b1 < 8; b1++) {
/* 1141 */       if (b1) {
/* 1142 */         this.writer.print(",");
/*      */       }
/*      */       
/* 1145 */       this.writer.print(paramChartLens.getStyle(b1));
/*      */     } 
/* 1147 */     this.writer.print("\"");
/*      */     
/* 1149 */     this.writer.print(" Colors=\"");
/* 1150 */     for (byte b2 = 0; b2 < 12; b2++) {
/* 1151 */       if (b2) {
/* 1152 */         this.writer.print(",");
/*      */       }
/*      */       
/* 1155 */       Object object = paramChartLens.getColor(b2);
/* 1156 */       this.writer.print((object instanceof Color) ? ((Color)object).getRGB() : 1052688);
/*      */     } 
/*      */     
/* 1159 */     this.writer.print("\"");
/*      */     
/* 1161 */     this.writer.println(" GridStyle=\"" + paramChartLens.getGridStyle() + "\" BorderStyle=\"" + paramChartLens.getBorderStyle() + "\" ShowValue=\"" + paramChartLens.isShowValue() + "\" Precision=\"" + paramChartLens.getPrecision() + "\" LegendPosition=\"" + paramChartLens.getLegendPosition() + "\">");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1167 */     this.writer.print("<![CDATA[");
/*      */     
/* 1169 */     for (byte b3 = 0; b3 < paramChartLens.getDatasetCount(); b3++) {
/* 1170 */       if (b3) {
/* 1171 */         this.writer.print("|");
/*      */       }
/*      */       
/* 1174 */       this.writer.print(toString(paramChartLens.getDatasetLabel(b3)));
/*      */     } 
/* 1176 */     this.writer.println("|");
/*      */     
/* 1178 */     for (byte b4 = 0; b4 < paramChartLens.getDatasetSize(); b4++) {
/* 1179 */       if (b4) {
/* 1180 */         this.writer.print("|");
/*      */       }
/*      */       
/* 1183 */       this.writer.print(toString(paramChartLens.getLabel(b4)));
/*      */     } 
/* 1185 */     this.writer.println("|");
/*      */     
/* 1187 */     for (byte b5 = 0; b5 < paramChartLens.getDatasetCount(); b5++) {
/* 1188 */       for (byte b = 0; b < paramChartLens.getDatasetSize(); b++) {
/* 1189 */         if (b) {
/* 1190 */           this.writer.print("|");
/*      */         }
/*      */         
/* 1193 */         this.writer.print(toString(paramChartLens.getData(b5, b)));
/*      */       } 
/* 1195 */       this.writer.println("");
/*      */     } 
/*      */     
/* 1198 */     this.writer.println("]]></Chart>");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void write(Painter paramPainter, ReportElement paramReportElement) {
/* 1205 */     Dimension dimension = paramPainter.getPreferredSize();
/* 1206 */     Image image = Common.createImage(dimension.width, dimension.height);
/* 1207 */     Graphics graphics = image.getGraphics();
/*      */     
/* 1209 */     if (paramReportElement != null && paramReportElement.getBackground() != null) {
/* 1210 */       graphics.setColor(paramReportElement.getBackground());
/* 1211 */       graphics.fillRect(0, 0, dimension.width, dimension.height);
/*      */     } 
/*      */     
/* 1214 */     graphics.setColor((paramReportElement != null) ? paramReportElement.getForeground() : Color.black);
/* 1215 */     paramPainter.paint(graphics, 0, 0, dimension.width, dimension.height);
/* 1216 */     graphics.dispose();
/*      */     
/* 1218 */     write(image, dimension);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void write(Image paramImage, Dimension paramDimension) {
/* 1225 */     if (paramDimension == null) {
/* 1226 */       paramDimension = new Dimension(paramImage.getWidth(null), paramImage.getHeight(null));
/*      */     }
/*      */     
/* 1229 */     byte[] arrayOfByte = Encoder.encodeAscii85(Encoder.deflate(Encoder.encodeImage(paramImage)));
/*      */     
/* 1231 */     this.writer.println("<Image Width=\"" + paramDimension.width + "\" Height=\"" + paramDimension.height + "\">");
/*      */ 
/*      */     
/* 1234 */     String str = new String(arrayOfByte);
/*      */     
/* 1236 */     for (int i = 0; i < arrayOfByte.length; i += 80) {
/*      */       try {
/* 1238 */         String str1 = str.substring(i, i + Math.min(arrayOfByte.length - i, 80));
/* 1239 */         this.writer.println(XMLTokenStream.encodeXML(str1));
/*      */       } catch (Exception exception) {
/* 1241 */         exception.printStackTrace();
/*      */       } 
/*      */     } 
/*      */     
/* 1245 */     this.writer.println("</Image>");
/*      */   }
/*      */ 
/*      */   
/* 1249 */   protected static String toString(Object paramObject) { return (paramObject == null) ? "" : paramObject.toString(); }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\TemplateFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */