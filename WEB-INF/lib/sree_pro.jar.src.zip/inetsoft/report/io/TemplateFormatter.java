package inetsoft.report.io;

import inetsoft.report.AreaBreakElement;
import inetsoft.report.ChartDescriptor;
import inetsoft.report.ChartElement;
import inetsoft.report.ChartLens;
import inetsoft.report.Common;
import inetsoft.report.CompositeElement;
import inetsoft.report.CondPageBreakElement;
import inetsoft.report.FixedContainer;
import inetsoft.report.FormElement;
import inetsoft.report.FormLens;
import inetsoft.report.HeadingElement;
import inetsoft.report.Margin;
import inetsoft.report.NewlineElement;
import inetsoft.report.PageArea;
import inetsoft.report.PageBreakElement;
import inetsoft.report.PageLayoutElement;
import inetsoft.report.Painter;
import inetsoft.report.PainterElement;
import inetsoft.report.Position;
import inetsoft.report.ReportElement;
import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.SectionLens;
import inetsoft.report.SeparatorElement;
import inetsoft.report.Size;
import inetsoft.report.SpaceElement;
import inetsoft.report.StyleFont;
import inetsoft.report.StyleSheet;
import inetsoft.report.TOCElement;
import inetsoft.report.TabElement;
import inetsoft.report.TableElement;
import inetsoft.report.TableLens;
import inetsoft.report.TextBoxElement;
import inetsoft.report.TextElement;
import inetsoft.report.internal.BaseElement;
import inetsoft.report.internal.ButtonElementDef;
import inetsoft.report.internal.ChartXElement;
import inetsoft.report.internal.CheckBoxElementDef;
import inetsoft.report.internal.ChoiceElementDef;
import inetsoft.report.internal.Encoder;
import inetsoft.report.internal.FormXElement;
import inetsoft.report.internal.ImageButtonElementDef;
import inetsoft.report.internal.ImageLocation;
import inetsoft.report.internal.ImageXElement;
import inetsoft.report.internal.RadioButtonElementDef;
import inetsoft.report.internal.SectionXElement;
import inetsoft.report.internal.TabSupport;
import inetsoft.report.internal.TableAttr;
import inetsoft.report.internal.TableXElement;
import inetsoft.report.internal.TextAreaElementDef;
import inetsoft.report.internal.TextFieldElementDef;
import inetsoft.report.internal.XMLTokenStream;
import inetsoft.report.lens.AttributeChartLens;
import inetsoft.report.style.TableStyle;
import inetsoft.report.style.XTableStyle;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

class TemplateFormatter implements Formatter {
  protected PrintWriter writer;
  
  protected OutputStream output;
  
  protected StyleSheet sheet;
  
  public TemplateFormatter(OutputStream paramOutputStream) {
    try {
      this.writer = new PrintWriter(new OutputStreamWriter(this.output = paramOutputStream, "UTF8"));
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      unsupportedEncodingException.printStackTrace();
    } 
  }
  
  public void prolog(StyleSheet paramStyleSheet) {
    this.sheet = paramStyleSheet;
    this.writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    Margin margin = paramStyleSheet.getMargin();
    this.writer.print("<Report Top=\"" + margin.top + "\" Left=\"" + margin.left + "\" Bottom=\"" + margin.bottom + "\" Right=\"" + margin.right + "\" HeaderFromEdge=\"" + paramStyleSheet.getHeaderFromEdge() + "\" FooterFromEdge=\"" + paramStyleSheet.getFooterFromEdge() + "\" PageNumbering=\"" + paramStyleSheet.getPageNumberingStart() + "\" HorizontalWrap=\"" + paramStyleSheet.isHorizontalWrap() + "\"");
    this.writer.print(" TabStops=\"");
    double[] arrayOfDouble = paramStyleSheet.getCurrentTabStops();
    for (byte b = 0; b < arrayOfDouble.length; b++) {
      if (b)
        this.writer.print(","); 
      this.writer.print(arrayOfDouble[b]);
    } 
    this.writer.println("\">");
    if (paramStyleSheet.getBackgroundImageLocation() != null) {
      ImageLocation imageLocation = paramStyleSheet.getBackgroundImageLocation();
      this.writer.println("<Background Path=\"" + imageLocation.getPath() + "\" PathType=\"" + imageLocation.getPathType() + "\" Embedded=\"" + imageLocation.isEmbedded() + "\">");
      if (imageLocation.isEmbedded())
        write((Image)paramStyleSheet.getBackground(), null); 
      this.writer.println("</Background>");
    } else if (paramStyleSheet.getBackground() instanceof Image) {
      this.writer.println("<Background>");
      write((Image)paramStyleSheet.getBackground(), null);
      this.writer.println("</Background>");
    } else if (paramStyleSheet.getBackground() instanceof Color) {
      Color color = (Color)paramStyleSheet.getBackground();
      this.writer.println("<Background Color=\"" + color.getRGB() + "\"/>");
    } 
    if (paramStyleSheet.getOnPageBreak() != null)
      this.writer.println("<onPageBreak><![CDATA[" + paramStyleSheet.getOnPageBreak() + "]]></onPageBreak>"); 
    if (paramStyleSheet.getOnLoad() != null)
      this.writer.println("<onLoad><![CDATA[" + paramStyleSheet.getOnLoad() + "]]></onLoad>"); 
    Properties properties = paramStyleSheet.getProperties();
    if (properties.size() > 0) {
      Enumeration enumeration1 = properties.propertyNames();
      this.writer.print("<Property");
      for (byte b1 = 0; enumeration1.hasMoreElements(); b1++) {
        String str = (String)enumeration1.nextElement();
        this.writer.print(" Name" + b1 + "=\"" + str + "\"" + " Value" + b1 + "=\"" + properties.getProperty(str) + "\"");
      } 
      this.writer.println(">");
      this.writer.println("</Property>");
    } 
    Hashtable hashtable = paramStyleSheet.getElementAreas();
    Enumeration enumeration = hashtable.keys();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      PageArea[] arrayOfPageArea = (PageArea[])hashtable.get(str);
      this.writer.println("<PageLayout ID=\"" + str + "\" Count=\"" + arrayOfPageArea.length + "\">");
      writePageAreas(arrayOfPageArea);
      this.writer.println("</PageLayout>");
    } 
  }
  
  public void startHeader(int paramInt) { this.writer.println("<Header Type=\"" + paramInt + "\">"); }
  
  public void startHeader(String paramString, boolean paramBoolean) { this.writer.println("<Header Type=\"Element\" ID=\"" + paramString + "\" Header=\"" + paramBoolean + "\">"); }
  
  public void endHeader() { this.writer.println("</Header>"); }
  
  public void write(XTableStyle paramXTableStyle) {
    this.writer.flush();
    paramXTableStyle.export(this.output);
  }
  
  public void write(TextElement paramTextElement) {
    this.writer.print("<TextElement ");
    writeElementAttributes(paramTextElement);
    writeTabAttributes((TabSupport)paramTextElement);
    this.writer.print(" Justify=\"" + paramTextElement.isJustify() + "\"");
    this.writer.print(" Orphan=\"" + paramTextElement.isOrphanControl() + "\"");
    this.writer.println(" TextAdvance=\"" + paramTextElement.getTextAdvance() + "\">");
    writeElementProperties(paramTextElement);
    this.writer.println("<![CDATA[" + paramTextElement.getText() + "]]>");
    this.writer.println("</TextElement>");
  }
  
  public void write(HeadingElement paramHeadingElement) {
    this.writer.print("<HeadingElement ");
    writeElementAttributes(paramHeadingElement);
    this.writer.print(" Level=\"" + paramHeadingElement.getLevel() + "\" ");
    this.writer.print(" Justify=\"" + paramHeadingElement.isJustify() + "\"");
    this.writer.print(" Orphan=\"" + paramHeadingElement.isOrphanControl() + "\"");
    this.writer.println(" TextAdvance=\"" + paramHeadingElement.getTextAdvance() + "\">");
    writeElementProperties(paramHeadingElement);
    this.writer.println("<![CDATA[" + paramHeadingElement.getText() + "]]>");
    this.writer.println("</HeadingElement>");
  }
  
  public void write(TableElement paramTableElement) {
    TableXElement tableXElement = (TableXElement)paramTableElement;
    TableLens tableLens = tableXElement.getTable();
    this.writer.print("<TableElement ");
    writeElementAttributes(paramTableElement);
    this.writer.print(" TableWidth=\"" + paramTableElement.getTableWidth() + "\"");
    if (tableXElement.isEmbedWidth()) {
      int[] arrayOfInt = paramTableElement.getFixedWidths();
      if (arrayOfInt != null) {
        this.writer.print(" FixedWidths=\"");
        for (byte b = 0; b < arrayOfInt.length; b++) {
          if (b)
            this.writer.print(","); 
          this.writer.print(arrayOfInt[b]);
        } 
        this.writer.print("\" ");
      } 
    } 
    this.writer.print(" Layout=\"" + paramTableElement.getLayout() + "\"");
    this.writer.print(" TableAdvance=\"" + paramTableElement.getTableAdvance() + "\"");
    this.writer.print(" OrphanControl=\"" + paramTableElement.isOrphanControl() + "\"");
    Insets insets = paramTableElement.getPadding();
    if (insets != null)
      this.writer.print(" Padding=\"" + insets.top + "," + insets.left + "," + insets.bottom + "," + insets.right + "\""); 
    TableStyle tableStyle = tableXElement.getStyle();
    if (tableStyle != null)
      this.writer.print(" Style=\"" + tableStyle.getName() + "\""); 
    this.writer.println(" EmbedWidth=\"" + tableXElement.isEmbedWidth() + "\" Embedded=\"" + tableXElement.isEmbedded() + "\">");
    writeElementProperties(paramTableElement);
    Point[] arrayOfPoint = tableXElement.getOnClickRange();
    if (arrayOfPoint != null)
      for (byte b = 0; b < arrayOfPoint.length; b++)
        this.writer.println("<onClickRange Row=\"" + (arrayOfPoint[b]).y + "\" Col=\"" + (arrayOfPoint[b]).x + "\"/>");  
    if (tableStyle != null) {
      this.writer.print("<Style");
      this.writer.println(" RowBorderC=\"" + tableStyle.isApplyRowBorderColor() + "\" ColBorderC=\"" + tableStyle.isApplyColBorderColor() + "\" RowBorder=\"" + tableStyle.isApplyRowBorder() + "\" ColBorder=\"" + tableStyle.isApplyColBorder() + "\" Insets=\"" + tableStyle.isApplyInsets() + "\" Alignment=\"" + tableStyle.isApplyAlignment() + "\" Font=\"" + tableStyle.isApplyFont() + "\" LineWrap=\"" + tableStyle.isApplyLineWrap() + "\" Foreground=\"" + tableStyle.isApplyForeground() + "\" Background=\"" + tableStyle.isApplyBackground() + "\" FirstRow=\"" + tableStyle.isFormatFirstRow() + "\" FirstCol=\"" + tableStyle.isFormatFirstCol() + "\" LastRow=\"" + tableStyle.isFormatLastRow() + "\" LastCol=\"" + tableStyle.isFormatLastCol() + "\"/>");
    } 
    this.writer.println("<RowGroup>");
    Enumeration enumeration1 = tableXElement.getAttributeRows();
    while (enumeration1.hasMoreElements()) {
      int i = ((Integer)enumeration1.nextElement()).intValue();
      if (tableLens != null && i >= tableLens.getRowCount())
        continue; 
      TableAttr tableAttr = tableXElement.getRowAttribute(i);
      this.writer.print("<Row index=\"" + i + "\"");
      if (tableAttr.alignment != null)
        this.writer.print(" alignment=\"" + tableAttr.alignment + "\""); 
      if (tableAttr.format != null)
        this.writer.print(" format=\"" + tableAttr.format + "\""); 
      if (tableAttr.format_spec != null)
        this.writer.print(" format_spec=\"" + tableAttr.format_spec + "\""); 
      if (tableAttr.presenter != null)
        this.writer.print(" presenter=\"" + tableAttr.presenter + "\""); 
      if (tableAttr.linewrap != null)
        this.writer.print(" linewrap=\"" + tableAttr.presenter + "\""); 
      this.writer.println(">");
    } 
    this.writer.println("</RowGroup>");
    this.writer.println("<ColGroup>");
    Enumeration enumeration2 = tableXElement.getAttributeCols();
    while (enumeration2.hasMoreElements()) {
      int i = ((Integer)enumeration2.nextElement()).intValue();
      if (tableLens != null && i >= tableLens.getRowCount())
        continue; 
      TableAttr tableAttr = tableXElement.getColAttribute(i);
      this.writer.print("<Col index=\"" + i + "\"");
      if (tableAttr.alignment != null)
        this.writer.print(" alignment=\"" + tableAttr.alignment + "\""); 
      if (tableAttr.format != null)
        this.writer.print(" format=\"" + tableAttr.format + "\""); 
      if (tableAttr.format_spec != null)
        this.writer.print(" format_spec=\"" + tableAttr.format_spec + "\""); 
      if (tableAttr.presenter != null)
        this.writer.print(" presenter=\"" + tableAttr.presenter + "\""); 
      if (tableAttr.linewrap != null)
        this.writer.print(" linewrap=\"" + tableAttr.presenter + "\""); 
      this.writer.println(">");
    } 
    this.writer.println("</ColGroup>");
    if (tableXElement.getFilter() != null)
      tableXElement.getFilter().writeXML(this.writer); 
    if (tableXElement.isEmbedded())
      write(tableLens); 
    this.writer.println("</TableElement>");
  }
  
  public void write(FormElement paramFormElement) {
    FormXElement formXElement = (FormXElement)paramFormElement;
    FormLens formLens = formXElement.getForm();
    this.writer.print("<FormElement ");
    writeElementAttributes(paramFormElement);
    this.writer.print(" FieldPerRow=\"" + formLens.getFieldPerRow() + "\"");
    if (formLens.getLabelFont(false) != null)
      this.writer.print(" LabelFont=\"" + StyleFont.toString(formLens.getLabelFont(0)) + "\""); 
    if (formLens.getLabelForeground(false) != null)
      this.writer.print(" LabelForeground=\"" + formLens.getLabelForeground(0).getRGB() + "\""); 
    if (formLens.getLabelBackground(false) != null)
      this.writer.print(" LabelBackground=\"" + formLens.getLabelBackground(0).getRGB() + "\""); 
    if (formLens.getFont(false) != null)
      this.writer.print(" FieldFont=\"" + StyleFont.toString(formLens.getFont(0)) + "\""); 
    if (formLens.getForeground(false) != null)
      this.writer.print(" FieldForeground=\"" + formLens.getForeground(0).getRGB() + "\""); 
    if (formLens.getBackground(false) != null)
      this.writer.print(" FieldBackground=\"" + formLens.getBackground(0).getRGB() + "\""); 
    this.writer.print(" Underline=\"" + formLens.getUnderline() + "\"");
    this.writer.print(" EmbedWidth=\"" + formXElement.isEmbedWidth() + "\" Embedded=\"" + formXElement.isEmbedded() + "\"");
    if (formXElement.isEmbedWidth()) {
      int[] arrayOfInt = paramFormElement.getFixedWidths();
      if (arrayOfInt != null) {
        this.writer.print(" FixedWidths=\"");
        for (byte b = 0; b < arrayOfInt.length; b++) {
          if (b)
            this.writer.print(","); 
          this.writer.print(arrayOfInt[b]);
        } 
        this.writer.print("\" ");
      } 
    } 
    this.writer.println(">");
    writeElementProperties(paramFormElement);
    if (formXElement.isEmbedded())
      write(formXElement.getForm()); 
    this.writer.println("</FormElement>");
  }
  
  public void write(PainterElement paramPainterElement) {
    if (paramPainterElement instanceof ImageXElement) {
      ImageXElement imageXElement = (ImageXElement)paramPainterElement;
      this.writer.print("<ImageElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      this.writer.println(" PathType=\"" + imageXElement.getPathType() + "\" Path=\"" + imageXElement.getAdjustedPath() + "\" " + "Embedded=\"" + imageXElement.isEmbedded() + "\">");
      writeElementProperties(paramPainterElement);
      if (imageXElement.isEmbedded())
        write(imageXElement.getPainter(), imageXElement); 
      this.writer.println("</ImageElement>");
    } else if (paramPainterElement instanceof ButtonElementDef) {
      ButtonElementDef buttonElementDef = (ButtonElementDef)paramPainterElement;
      this.writer.print("<ButtonElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      this.writer.println(" Name=\"" + buttonElementDef.getName() + "\"" + " Form=\"" + buttonElementDef.getForm() + "\"" + " Text=\"" + buttonElementDef.getText() + "\">");
      writeElementProperties(paramPainterElement);
      this.writer.println("</ButtonElement>");
    } else if (paramPainterElement instanceof ImageButtonElementDef) {
      ImageButtonElementDef imageButtonElementDef = (ImageButtonElementDef)paramPainterElement;
      this.writer.print("<ImageButtonElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      this.writer.println(" Name=\"" + imageButtonElementDef.getName() + "\"" + " Form=\"" + imageButtonElementDef.getForm() + "\"" + " Resource=\"" + imageButtonElementDef.getResource() + "\">");
      writeElementProperties(paramPainterElement);
      this.writer.println("</ImageButtonElement>");
    } else if (paramPainterElement instanceof RadioButtonElementDef) {
      RadioButtonElementDef radioButtonElementDef = (RadioButtonElementDef)paramPainterElement;
      this.writer.print("<RadioButtonElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      this.writer.println(" Name=\"" + radioButtonElementDef.getName() + "\"" + " Form=\"" + radioButtonElementDef.getForm() + "\"" + " Text=\"" + radioButtonElementDef.getText() + "\"" + " Selected=\"" + radioButtonElementDef.isSelected() + "\"" + " Group=\"" + radioButtonElementDef.getGroup() + "\">");
      writeElementProperties(paramPainterElement);
      this.writer.println("</RadioButtonElement>");
    } else if (paramPainterElement instanceof CheckBoxElementDef) {
      CheckBoxElementDef checkBoxElementDef = (CheckBoxElementDef)paramPainterElement;
      this.writer.print("<CheckBoxElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      this.writer.println(" Name=\"" + checkBoxElementDef.getName() + "\"" + " Form=\"" + checkBoxElementDef.getForm() + "\"" + " Text=\"" + checkBoxElementDef.getText() + "\"" + " Selected=\"" + checkBoxElementDef.isSelected() + "\">");
      writeElementProperties(paramPainterElement);
      this.writer.println("</CheckBoxElement>");
    } else if (paramPainterElement instanceof ChoiceElementDef) {
      ChoiceElementDef choiceElementDef = (ChoiceElementDef)paramPainterElement;
      this.writer.print("<ChoiceElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      this.writer.print(" Name=\"" + choiceElementDef.getName() + "\"" + " Form=\"" + choiceElementDef.getForm() + "\"");
      if (choiceElementDef.getSelectedItem() != null)
        this.writer.print(" SelectedItem=\"" + choiceElementDef.getSelectedItem() + "\""); 
      this.writer.println(">");
      writeElementProperties(paramPainterElement);
      Object[] arrayOfObject = choiceElementDef.getChoices();
      for (byte b = 0; b < arrayOfObject.length; b++)
        this.writer.println("<Choice>\"" + arrayOfObject[b] + "\"</Choice>"); 
      this.writer.println("</ChoiceElement>");
    } else if (paramPainterElement instanceof TextFieldElementDef) {
      TextFieldElementDef textFieldElementDef = (TextFieldElementDef)paramPainterElement;
      this.writer.print("<TextFieldElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      this.writer.println(" Name=\"" + textFieldElementDef.getName() + "\"" + " Form=\"" + textFieldElementDef.getForm() + "\"" + " Text=\"" + textFieldElementDef.getText() + "\"" + " Cols=\"" + textFieldElementDef.getCols() + "\">");
      writeElementProperties(paramPainterElement);
      this.writer.println("</TextFieldElement>");
    } else if (paramPainterElement instanceof TextAreaElementDef) {
      TextAreaElementDef textAreaElementDef = (TextAreaElementDef)paramPainterElement;
      this.writer.print("<TextAreaElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      this.writer.println(" Name=\"" + textAreaElementDef.getName() + "\"" + " Form=\"" + textAreaElementDef.getForm() + "\"" + " Text=\"" + textAreaElementDef.getText() + "\"" + " Cols=\"" + textAreaElementDef.getCols() + "\"" + " Rows=\"" + textAreaElementDef.getRows() + "\">");
      writeElementProperties(paramPainterElement);
      this.writer.println("</TextAreaElement>");
    } else {
      this.writer.print("<PainterElement ");
      writeElementAttributes(paramPainterElement);
      writePainterAttributes(paramPainterElement);
      if (paramPainterElement.getPainter() instanceof inetsoft.report.painter.BulletPainter)
        this.writer.print(" Painter=\"bullet\""); 
      this.writer.println(">");
      writeElementProperties(paramPainterElement);
      this.writer.println("</PainterElement>");
    } 
  }
  
  public void write(ChartElement paramChartElement) {
    ChartXElement chartXElement = (ChartXElement)paramChartElement;
    this.writer.print("<ChartElement ");
    writeElementAttributes(paramChartElement);
    writePainterAttributes(paramChartElement);
    this.writer.println(" Embedded=\"" + chartXElement.isEmbedded() + "\">");
    writeElementProperties(paramChartElement);
    ChartDescriptor chartDescriptor = paramChartElement.getChartDescriptor();
    if (chartDescriptor != null)
      writeChartDescriptor(chartDescriptor); 
    if (chartXElement.getDataset() != null)
      chartXElement.getDataset().writeXML(this.writer); 
    write(paramChartElement.getChart(), chartXElement.isEmbedded());
    this.writer.println("</ChartElement>");
  }
  
  public void writeChartDescriptor(ChartDescriptor paramChartDescriptor) {
    this.writer.print("<ChartDescriptor");
    DecimalFormat decimalFormat = (DecimalFormat)paramChartDescriptor.getValueFormat();
    if (decimalFormat != null)
      this.writer.print(" ValueFormat=\"" + decimalFormat.toPattern() + "\""); 
    decimalFormat = (DecimalFormat)paramChartDescriptor.getYAxisFormat();
    if (decimalFormat != null)
      this.writer.print(" YAxisFormat=\"" + decimalFormat.toPattern() + "\""); 
    decimalFormat = (DecimalFormat)paramChartDescriptor.getSecondaryYAxisFormat();
    if (decimalFormat != null)
      this.writer.print(" SecondaryYAxisFormat=\"" + decimalFormat.toPattern() + "\""); 
    this.writer.print(" PointStyle=\"");
    for (byte b = 0; b < 8; b++) {
      if (b)
        this.writer.print(","); 
      this.writer.print(paramChartDescriptor.getPointStyle(b));
    } 
    this.writer.print("\"");
    this.writer.print(" FirstDatasetOfSecondaryAxis=\"" + paramChartDescriptor.getFirstDatasetOfSecondaryAxis() + "\"");
    this.writer.print(" VerticalGridStyle=\"" + paramChartDescriptor.getVerticalGridStyle() + "\"");
    this.writer.print(" LogarithmicYScale=\"" + paramChartDescriptor.isLogarithmicYScale() + "\"");
    this.writer.print(" SecondaryLogarithmicYScale=\"" + paramChartDescriptor.isSecondaryLogarithmicYScale() + "\"");
    if (paramChartDescriptor.getSecondaryMaximum() != null)
      this.writer.print(" SecondaryMaximum=\"" + paramChartDescriptor.getSecondaryMaximum() + "\""); 
    if (paramChartDescriptor.getSecondaryMinimum() != null)
      this.writer.print(" SecondaryMinimum=\"" + paramChartDescriptor.getSecondaryMinimum() + "\""); 
    if (paramChartDescriptor.getSecondaryIncrement() != null)
      this.writer.print(" SecondaryIncrement=\"" + paramChartDescriptor.getSecondaryIncrement() + "\""); 
    if (paramChartDescriptor.getSecondaryMinorIncrement() != null)
      this.writer.print(" SecondaryMinorIncrement=\"" + paramChartDescriptor.getSecondaryMinorIncrement() + "\""); 
    if (paramChartDescriptor.getSecondaryYTitle() != null)
      this.writer.print(" SecondaryYTitle=\"" + paramChartDescriptor.getSecondaryYTitle() + "\""); 
    this.writer.println(" LineWidth=\"" + paramChartDescriptor.getLineChartLineWidth() + "\" PointSize=\"" + paramChartDescriptor.getPointSize() + "\" XLabelRotation=\"" + paramChartDescriptor.getXLabelRotation() + "\" BarBorder=\"" + paramChartDescriptor.isBarBorder() + "\"/>");
  }
  
  public void write(TextBoxElement paramTextBoxElement) {
    this.writer.print("<TextBoxElement ");
    writeElementAttributes(paramTextBoxElement);
    writePainterAttributes(paramTextBoxElement);
    this.writer.print(" Border=\"" + paramTextBoxElement.getBorder() + "\" Shape=\"" + paramTextBoxElement.getShape() + "\" Justify=\"" + paramTextBoxElement.isJustify() + "\" TextAlignment=\"" + paramTextBoxElement.getTextAlignment() + "\"");
    Insets insets1 = paramTextBoxElement.getPadding();
    if (insets1 != null)
      this.writer.print(" Padding=\"" + insets1.top + "," + insets1.left + "," + insets1.bottom + "," + insets1.right + "\""); 
    Insets insets2 = paramTextBoxElement.getBorders();
    if (insets2 != null)
      this.writer.print(" Borders=\"" + insets2.top + "," + insets2.left + "," + insets2.bottom + "," + insets2.right + "\""); 
    this.writer.println(">");
    writeElementProperties(paramTextBoxElement);
    this.writer.println("<![CDATA[" + paramTextBoxElement.getText() + "]]>");
    this.writer.println("</TextBoxElement>");
  }
  
  public void write(TabElement paramTabElement) {
    this.writer.print("<TabElement ");
    writeElementAttributes(paramTabElement);
    writeTabAttributes((TabSupport)paramTabElement);
    this.writer.println(" RightTab=\"" + paramTabElement.isRightTab() + "\">");
    writeElementProperties(paramTabElement);
    this.writer.println("</TabElement>");
  }
  
  protected void writeTabAttributes(TabSupport paramTabSupport) {
    this.writer.print(" FillStyle=\"" + paramTabSupport.getFillStyle() + "\" TabStops=\"");
    double[] arrayOfDouble = paramTabSupport.getTabStops();
    for (byte b = 0; b < arrayOfDouble.length; b++) {
      if (b)
        this.writer.print(","); 
      this.writer.print(arrayOfDouble[b]);
    } 
    this.writer.print("\"");
  }
  
  public void write(NewlineElement paramNewlineElement) {
    this.writer.print("<NewlineElement ");
    writeElementAttributes(paramNewlineElement);
    this.writer.println(" Count=\"" + paramNewlineElement.getCount() + "\">");
    writeElementProperties(paramNewlineElement);
    this.writer.println("</NewlineElement>");
  }
  
  public void write(AreaBreakElement paramAreaBreakElement) {
    this.writer.print("<AreaBreakElement ");
    writeElementAttributes(paramAreaBreakElement);
    this.writer.println(">");
    writeElementProperties(paramAreaBreakElement);
    this.writer.println("</AreaBreakElement>");
  }
  
  public void write(PageBreakElement paramPageBreakElement) {
    this.writer.print("<PageBreakElement ");
    writeElementAttributes(paramPageBreakElement);
    this.writer.println(">");
    writeElementProperties(paramPageBreakElement);
    this.writer.println("</PageBreakElement>");
  }
  
  public void write(SectionElement paramSectionElement) {
    this.writer.print("<SectionElement ");
    writeElementAttributes(paramSectionElement);
    this.writer.println(">");
    writeElementProperties(paramSectionElement);
    if (paramSectionElement instanceof SectionXElement) {
      SectionXElement sectionXElement = (SectionXElement)paramSectionElement;
      if (sectionXElement.getFilter() != null)
        sectionXElement.getFilter().writeXML(this.writer); 
    } 
    writeSection(paramSectionElement.getSection());
    this.writer.println("</SectionElement>");
  }
  
  protected void writeSection(SectionLens paramSectionLens) {
    if (paramSectionLens == null)
      return; 
    this.writer.println("<Section>");
    if (paramSectionLens.getSectionHeader() != null) {
      this.writer.println("<SectionHeader>");
      writeSectionBand(paramSectionLens.getSectionHeader());
      this.writer.println("</SectionHeader>");
    } 
    if (paramSectionLens.getSectionContent() instanceof SectionLens) {
      this.writer.println("<SectionContent>");
      writeSection((SectionLens)paramSectionLens.getSectionContent());
      this.writer.println("</SectionContent>");
    } else if (paramSectionLens.getSectionContent() instanceof SectionBand) {
      this.writer.println("<SectionContent>");
      writeSectionBand((SectionBand)paramSectionLens.getSectionContent());
      this.writer.println("</SectionContent>");
    } 
    if (paramSectionLens.getSectionFooter() != null) {
      this.writer.println("<SectionFooter>");
      writeSectionBand(paramSectionLens.getSectionFooter());
      this.writer.println("</SectionFooter>");
    } 
    this.writer.println("</Section>");
  }
  
  protected void writeSectionBand(SectionBand paramSectionBand) {
    if (paramSectionBand == null)
      return; 
    this.writer.print("<SectionBand Height=\"" + paramSectionBand.getHeight() + "\"");
    this.writer.print(" Visible=\"" + paramSectionBand.isVisible() + "\" ShrinkToFit=\"" + paramSectionBand.isShrinkToFit() + "\" PageBefore=\"" + paramSectionBand.isPageBefore() + "\" PageAfter=\"" + paramSectionBand.isPageAfter() + "\" TopBorder=\"" + paramSectionBand.getTopBorder() + "\" LeftBorder=\"" + paramSectionBand.getLeftBorder() + "\" BottomBorder=\"" + paramSectionBand.getBottomBorder() + "\" RightBorder=\"" + paramSectionBand.getRightBorder() + "\"");
    this.writer.println(" Elements=\"" + paramSectionBand.getElementCount() + "\">");
    for (byte b = 0; b < paramSectionBand.getElementCount(); b++) {
      Rectangle rectangle = paramSectionBand.getBounds(b);
      ReportElement reportElement = paramSectionBand.getElement(b);
      Builder.write(this, reportElement);
      this.writer.print("<FieldProperty X=\"" + rectangle.x + "\" Y=\"" + rectangle.y + "\" Width=\"" + rectangle.width + "\" Height=\"" + rectangle.height + "\"");
      String str = paramSectionBand.getBinding(reportElement.getID());
      if (str != null)
        this.writer.print(" Binding=\"" + str + "\""); 
      this.writer.println("/>");
    } 
    this.writer.println("</SectionBand>");
  }
  
  public void write(PageLayoutElement paramPageLayoutElement) {
    PageArea[] arrayOfPageArea = paramPageLayoutElement.getPageAreas();
    this.writer.print("<PageLayoutElement Count=\"" + arrayOfPageArea.length + "\" ");
    writeElementAttributes(paramPageLayoutElement);
    this.writer.println(">");
    writeElementProperties(paramPageLayoutElement);
    writePageAreas(arrayOfPageArea);
    this.writer.println("</PageLayoutElement>");
  }
  
  protected void writePageAreas(PageArea[] paramArrayOfPageArea) {
    for (byte b = 0; b < paramArrayOfPageArea.length; b++) {
      FixedContainer fixedContainer = paramArrayOfPageArea[b].getElements();
      this.writer.print("<Area X=\"" + (paramArrayOfPageArea[b]).x + "\" Y=\"" + (paramArrayOfPageArea[b]).y + "\" Width=\"" + (paramArrayOfPageArea[b]).width + "\" Height=\"" + (paramArrayOfPageArea[b]).height + "\" Relative=\"" + paramArrayOfPageArea[b].isRelative() + "\" Flow=\"" + paramArrayOfPageArea[b].isFlow() + "\" Repeat=\"" + paramArrayOfPageArea[b].isRepeat() + "\" Border=\"" + paramArrayOfPageArea[b].getBorder() + "\" BorderColor=\"" + paramArrayOfPageArea[b].getBorderColor().getRGB() + "\" Insets=\"" + (paramArrayOfPageArea[b].getInsets()).top + "," + (paramArrayOfPageArea[b].getInsets()).left + "," + (paramArrayOfPageArea[b].getInsets()).bottom + "," + (paramArrayOfPageArea[b].getInsets()).right + "\"");
      if (fixedContainer != null)
        this.writer.print(" Elements=\"" + fixedContainer.getElementCount() + "\""); 
      this.writer.println(">");
      if (fixedContainer != null)
        for (byte b1 = 0; b1 < fixedContainer.getElementCount(); b1++) {
          Rectangle rectangle = fixedContainer.getBounds(b1);
          Builder.write(this, fixedContainer.getElement(b1));
          this.writer.println("<Bounds X=\"" + rectangle.x + "\" Y=\"" + rectangle.y + "\" Width=\"" + rectangle.width + "\" Height=\"" + rectangle.height + "\"/>");
        }  
      this.writer.println("</Area>");
    } 
  }
  
  public void write(CondPageBreakElement paramCondPageBreakElement) {
    this.writer.print("<CondPageBreakElement ");
    writeElementAttributes(paramCondPageBreakElement);
    this.writer.println(" CondHeight=\"" + paramCondPageBreakElement.getCondHeight() + "\">");
    writeElementProperties(paramCondPageBreakElement);
    this.writer.println("</CondPageBreakElement>");
  }
  
  public void write(SpaceElement paramSpaceElement) {
    this.writer.print("<SpaceElement ");
    writeElementAttributes(paramSpaceElement);
    this.writer.println(" Space=\"" + paramSpaceElement.getSpace() + "\">");
    writeElementProperties(paramSpaceElement);
    this.writer.println("</SpaceElement>");
  }
  
  public void write(SeparatorElement paramSeparatorElement) {
    this.writer.print("<SeparatorElement ");
    writeElementAttributes(paramSeparatorElement);
    this.writer.println(" Style=\"" + paramSeparatorElement.getStyle() + "\" SeparatorAdvance=\"" + paramSeparatorElement.getSeparatorAdvance() + "\">");
    writeElementProperties(paramSeparatorElement);
    this.writer.println("</SeparatorElement>");
  }
  
  public void write(TOCElement paramTOCElement) {
    this.writer.print("<TOCElement ");
    writeElementAttributes(paramTOCElement);
    this.writer.println(" Style=\"" + paramTOCElement.getTOC().getClass().getName() + "\">");
    writeElementProperties(paramTOCElement);
    this.writer.println("</TOCElement>");
  }
  
  public void write(CompositeElement paramCompositeElement) {
    if (paramCompositeElement.getComposite() instanceof inetsoft.report.internal.EmptyContainer)
      this.writer.println("<CompositeElement ID=\"" + paramCompositeElement.getID() + "\"/>"); 
  }
  
  public void end() {
    this.writer.println("</Report>");
    this.writer.flush();
  }
  
  protected void writeElementAttributes(ReportElement paramReportElement) {
    BaseElement baseElement = (BaseElement)paramReportElement;
    if (baseElement.getID() != null)
      this.writer.print("ID=\"" + baseElement.getID() + "\" "); 
    this.writer.print("Alignment=\"" + baseElement.getAlignment() + "\" Indent=\"" + baseElement.getIndent() + "\" Hindent=\"" + baseElement.getHindent() + "\" Font=\"" + StyleFont.toString(baseElement.getFont()) + "\" Foreground=\"" + baseElement.getForeground().getRGB() + "\" Spacing=\"" + baseElement.getSpacing() + "\" Block=\"" + baseElement.isBlock() + "\" Continuation=\"" + baseElement.isContinuation() + "\" Visible=\"" + baseElement.isVisible() + "\" KeepWithNext=\"" + baseElement.isKeepWithNext() + "\"");
    if (baseElement.getBackground() != null)
      this.writer.print(" Background=\"" + baseElement.getBackground().getRGB() + "\""); 
  }
  
  protected void writeElementProperties(ReportElement paramReportElement) {
    BaseElement baseElement = (BaseElement)paramReportElement;
    Enumeration enumeration = baseElement.getPropertyNames();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      this.writer.println("<property><name><![CDATA[" + str + "]]></name><value><![CDATA[" + baseElement.getProperty(str) + "]]></value></property>");
    } 
    if (paramReportElement.getScript() != null)
      this.writer.println("<script><![CDATA[" + paramReportElement.getScript() + "]]></script>"); 
    if (paramReportElement.getOnClick() != null)
      this.writer.println("<onClick><![CDATA[" + paramReportElement.getOnClick() + "]]></onClick>"); 
  }
  
  protected void writePainterAttributes(PainterElement paramPainterElement) {
    this.writer.print(" Layout=\"" + paramPainterElement.getLayout() + "\" Wrapping=\"" + paramPainterElement.getWrapping() + "\"");
    Position position = paramPainterElement.getAnchor();
    if (position != null)
      this.writer.print(" Anchor=\"" + position.x + "," + position.y + "\""); 
    Size size = paramPainterElement.getSize();
    if (size != null)
      this.writer.print(" Size=\"" + size.width + "x" + size.height + "\""); 
    Insets insets = paramPainterElement.getMargin();
    if (insets != null)
      this.writer.print(" Margin=\"" + insets.top + "," + insets.left + "," + insets.bottom + "," + insets.right + "\""); 
  }
  
  protected void write(TableLens paramTableLens) {
    this.writer.println("<Table Rows=\"" + paramTableLens.getRowCount() + "\" Cols=\"" + paramTableLens.getColCount() + "\" HeaderRow=\"" + paramTableLens.getHeaderRowCount() + "\" HeaderCol=\"" + paramTableLens.getHeaderColCount() + "\">");
    for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
      this.writer.println("<TR>");
      for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++) {
        this.writer.print("<TD>\"");
        this.writer.print(String.valueOf(paramTableLens.getObject(b, b1)));
        this.writer.print("\"</TD>");
      } 
      this.writer.println("</TR>");
    } 
    this.writer.println("</Table>");
  }
  
  protected void write(FormLens paramFormLens) {
    this.writer.println("<Form Fields=\"" + paramFormLens.getFieldCount() + "\">");
    this.writer.print("<![CDATA[");
    for (byte b = 0; b < paramFormLens.getFieldCount(); b++)
      this.writer.println(toString(paramFormLens.getLabel(b)) + "|" + toString(paramFormLens.getField(b))); 
    this.writer.println("]]></Form>");
  }
  
  protected void write(ChartLens paramChartLens, boolean paramBoolean) {
    this.writer.print("<Chart Datasets=\"" + paramChartLens.getDatasetCount() + "\" Size=\"" + paramChartLens.getDatasetSize() + "\"");
    this.writer.print(" Style=\"" + paramChartLens.getStyle() + "\"");
    if (paramChartLens.getMaximum() != null)
      this.writer.print(" Maximum=\"" + paramChartLens.getMaximum() + "\""); 
    if (paramChartLens.getMinimum() != null)
      this.writer.print(" Minimum=\"" + paramChartLens.getMinimum() + "\""); 
    if (paramChartLens.getIncrement() != null)
      this.writer.print(" Increment=\"" + paramChartLens.getIncrement() + "\""); 
    if (paramChartLens.getMinorIncrement() != null)
      this.writer.print(" MinorIncrement=\"" + paramChartLens.getMinorIncrement() + "\""); 
    this.writer.print(" Gap=\"" + paramChartLens.getGap() + "\"");
    if (paramChartLens.getXTitle() != null)
      this.writer.print(" XTitle=\"" + paramChartLens.getXTitle() + '"'); 
    if (paramChartLens.getYTitle() != null)
      this.writer.print(" YTitle=\"" + paramChartLens.getYTitle() + '"'); 
    if (paramChartLens.getTitleFont() != null)
      this.writer.print(" TitleFont=\"" + StyleFont.toString(paramChartLens.getTitleFont()) + "\""); 
    if (paramChartLens instanceof AttributeChartLens)
      this.writer.print(" BlackWhite=\"" + ((AttributeChartLens)paramChartLens).isBlackWhite() + "\""); 
    this.writer.print(" Styles=\"");
    for (byte b1 = 0; b1 < 8; b1++) {
      if (b1)
        this.writer.print(","); 
      this.writer.print(paramChartLens.getStyle(b1));
    } 
    this.writer.print("\"");
    this.writer.print(" Colors=\"");
    for (byte b2 = 0; b2 < 12; b2++) {
      if (b2)
        this.writer.print(","); 
      Object object = paramChartLens.getColor(b2);
      this.writer.print((object instanceof Color) ? ((Color)object).getRGB() : 1052688);
    } 
    this.writer.print("\"");
    this.writer.println(" GridStyle=\"" + paramChartLens.getGridStyle() + "\" BorderStyle=\"" + paramChartLens.getBorderStyle() + "\" ShowValue=\"" + paramChartLens.isShowValue() + "\" Precision=\"" + paramChartLens.getPrecision() + "\" LegendPosition=\"" + paramChartLens.getLegendPosition() + "\">");
    this.writer.print("<![CDATA[");
    for (byte b3 = 0; b3 < paramChartLens.getDatasetCount(); b3++) {
      if (b3)
        this.writer.print("|"); 
      this.writer.print(toString(paramChartLens.getDatasetLabel(b3)));
    } 
    this.writer.println("|");
    for (byte b4 = 0; b4 < paramChartLens.getDatasetSize(); b4++) {
      if (b4)
        this.writer.print("|"); 
      this.writer.print(toString(paramChartLens.getLabel(b4)));
    } 
    this.writer.println("|");
    for (byte b5 = 0; b5 < paramChartLens.getDatasetCount(); b5++) {
      for (byte b = 0; b < paramChartLens.getDatasetSize(); b++) {
        if (b)
          this.writer.print("|"); 
        this.writer.print(toString(paramChartLens.getData(b5, b)));
      } 
      this.writer.println("");
    } 
    this.writer.println("]]></Chart>");
  }
  
  protected void write(Painter paramPainter, ReportElement paramReportElement) {
    Dimension dimension = paramPainter.getPreferredSize();
    Image image = Common.createImage(dimension.width, dimension.height);
    Graphics graphics = image.getGraphics();
    if (paramReportElement != null && paramReportElement.getBackground() != null) {
      graphics.setColor(paramReportElement.getBackground());
      graphics.fillRect(0, 0, dimension.width, dimension.height);
    } 
    graphics.setColor((paramReportElement != null) ? paramReportElement.getForeground() : Color.black);
    paramPainter.paint(graphics, 0, 0, dimension.width, dimension.height);
    graphics.dispose();
    write(image, dimension);
  }
  
  protected void write(Image paramImage, Dimension paramDimension) {
    if (paramDimension == null)
      paramDimension = new Dimension(paramImage.getWidth(null), paramImage.getHeight(null)); 
    byte[] arrayOfByte = Encoder.encodeAscii85(Encoder.deflate(Encoder.encodeImage(paramImage)));
    this.writer.println("<Image Width=\"" + paramDimension.width + "\" Height=\"" + paramDimension.height + "\">");
    String str = new String(arrayOfByte);
    for (int i = 0; i < arrayOfByte.length; i += 80) {
      try {
        String str1 = str.substring(i, i + Math.min(arrayOfByte.length - i, 80));
        this.writer.println(XMLTokenStream.encodeXML(str1));
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
    this.writer.println("</Image>");
  }
  
  protected static String toString(Object paramObject) { return (paramObject == null) ? "" : paramObject.toString(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\TemplateFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */