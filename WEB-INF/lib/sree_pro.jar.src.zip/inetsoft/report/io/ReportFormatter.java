/*     */ package inetsoft.report.io;
/*     */ 
/*     */ import inetsoft.report.ChartDescriptor;
/*     */ import inetsoft.report.ChartElement;
/*     */ import inetsoft.report.CompositeElement;
/*     */ import inetsoft.report.CompositeLens;
/*     */ import inetsoft.report.Context;
/*     */ import inetsoft.report.FormElement;
/*     */ import inetsoft.report.FormLens;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.PainterElement;
/*     */ import inetsoft.report.Presenter;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StyleFont;
/*     */ import inetsoft.report.TOCElement;
/*     */ import inetsoft.report.TableElement;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.painter.ComponentPainter;
/*     */ import inetsoft.report.painter.ImagePainter;
/*     */ import inetsoft.report.painter.PresenterPainter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.io.OutputStream;
/*     */ import java.text.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReportFormatter
/*     */   extends TemplateFormatter
/*     */ {
/*  36 */   public ReportFormatter(OutputStream paramOutputStream) { super(paramOutputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(TableElement paramTableElement) {
/*  43 */     this.writer.print("<TableElement ");
/*  44 */     writeElementAttributes(paramTableElement);
/*  45 */     this.writer.print(" TableWidth=\"" + paramTableElement.getTableWidth() + "\"");
/*     */     
/*  47 */     if (paramTableElement.getFixedWidths() != null) {
/*  48 */       int[] arrayOfInt = paramTableElement.getFixedWidths();
/*  49 */       this.writer.print(" FixedWidths=\"");
/*  50 */       for (byte b = 0; b < arrayOfInt.length; b++) {
/*  51 */         if (b) {
/*  52 */           this.writer.print(",");
/*     */         }
/*     */         
/*  55 */         this.writer.print(arrayOfInt[b]);
/*     */       } 
/*  57 */       this.writer.print("\" ");
/*     */     } 
/*     */     
/*  60 */     this.writer.print(" Layout=\"" + paramTableElement.getLayout() + "\"");
/*  61 */     this.writer.print(" TableAdvance=\"" + paramTableElement.getTableAdvance() + "\"");
/*  62 */     this.writer.print(" OrphanControl=\"" + paramTableElement.isOrphanControl() + "\"");
/*     */     
/*  64 */     Insets insets = paramTableElement.getPadding();
/*  65 */     if (insets != null) {
/*  66 */       this.writer.print(" Padding=\"" + insets.top + "," + insets.left + "," + insets.bottom + "," + insets.right + "\"");
/*     */     }
/*     */ 
/*     */     
/*  70 */     this.writer.println(">");
/*  71 */     writeElementProperties(paramTableElement);
/*     */     
/*  73 */     Point[] arrayOfPoint = paramTableElement.getOnClickRange();
/*  74 */     if (arrayOfPoint != null) {
/*  75 */       for (byte b = 0; b < arrayOfPoint.length; b++) {
/*  76 */         this.writer.println("<onClickRange Row=\"" + (arrayOfPoint[b]).y + "\" Col=\"" + (arrayOfPoint[b]).x + "\"/>");
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*  81 */     write(paramTableElement.getTable(), paramTableElement);
/*  82 */     this.writer.println("</TableElement>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(FormElement paramFormElement) {
/*  89 */     FormLens formLens = paramFormElement.getForm();
/*     */     
/*  91 */     this.writer.print("<FormElement ");
/*  92 */     writeElementAttributes(paramFormElement);
/*     */     
/*  94 */     this.writer.print(" FieldPerRow=\"" + formLens.getFieldPerRow() + "\"");
/*     */     
/*  96 */     if (formLens.getLabelFont(false) != null) {
/*  97 */       this.writer.print(" LabelFont=\"" + StyleFont.toString(formLens.getLabelFont(0)) + "\"");
/*     */     }
/*     */ 
/*     */     
/* 101 */     if (formLens.getLabelForeground(false) != null) {
/* 102 */       this.writer.print(" LabelForeground=\"" + formLens.getLabelForeground(0).getRGB() + "\"");
/*     */     }
/*     */ 
/*     */     
/* 106 */     if (formLens.getLabelBackground(false) != null) {
/* 107 */       this.writer.print(" LabelBackground=\"" + formLens.getLabelBackground(0).getRGB() + "\"");
/*     */     }
/*     */ 
/*     */     
/* 111 */     if (formLens.getFont(false) != null) {
/* 112 */       this.writer.print(" FieldFont=\"" + StyleFont.toString(formLens.getFont(0)) + "\"");
/*     */     }
/*     */ 
/*     */     
/* 116 */     if (formLens.getForeground(false) != null) {
/* 117 */       this.writer.print(" FieldForeground=\"" + formLens.getForeground(0).getRGB() + "\"");
/*     */     }
/*     */ 
/*     */     
/* 121 */     if (formLens.getBackground(false) != null) {
/* 122 */       this.writer.print(" FieldBackground=\"" + formLens.getBackground(0).getRGB() + "\"");
/*     */     }
/*     */ 
/*     */     
/* 126 */     this.writer.print(" Underline=\"" + formLens.getUnderline() + "\"");
/*     */     
/* 128 */     if (paramFormElement.getFixedWidths() != null) {
/* 129 */       int[] arrayOfInt = paramFormElement.getFixedWidths();
/* 130 */       this.writer.print(" FixedWidths=\"");
/* 131 */       for (byte b = 0; b < arrayOfInt.length; b++) {
/* 132 */         if (b) {
/* 133 */           this.writer.print(",");
/*     */         }
/*     */         
/* 136 */         this.writer.print(arrayOfInt[b]);
/*     */       } 
/* 138 */       this.writer.print("\" ");
/*     */     } 
/* 140 */     this.writer.println(">");
/*     */     
/* 142 */     writeElementProperties(paramFormElement);
/* 143 */     write(formLens);
/*     */     
/* 145 */     this.writer.println("</FormElement>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(PainterElement paramPainterElement) {
/* 152 */     if (paramPainterElement instanceof inetsoft.report.internal.FieldElementDef) {
/* 153 */       super.write(paramPainterElement);
/*     */       
/*     */       return;
/*     */     } 
/* 157 */     this.writer.print("<PainterElement ");
/* 158 */     writeElementAttributes(paramPainterElement);
/* 159 */     this.writer.print(" ");
/* 160 */     writePainterAttributes(paramPainterElement);
/*     */     
/* 162 */     if (paramPainterElement.getPainter() instanceof inetsoft.report.painter.BulletPainter) {
/* 163 */       this.writer.print(" Painter=\"bullet\"");
/*     */     }
/*     */     
/* 166 */     this.writer.println(">");
/*     */     
/* 168 */     writeElementProperties(paramPainterElement);
/*     */     
/* 170 */     write(paramPainterElement.getPainter(), paramPainterElement);
/* 171 */     this.writer.println("</PainterElement>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ChartElement paramChartElement) {
/* 178 */     this.writer.print("<ChartElement ");
/* 179 */     writeElementAttributes(paramChartElement);
/* 180 */     this.writer.print(" ");
/* 181 */     writePainterAttributes(paramChartElement);
/* 182 */     this.writer.println(">");
/*     */     
/* 184 */     writeElementProperties(paramChartElement);
/*     */     
/* 186 */     ChartDescriptor chartDescriptor = paramChartElement.getChartDescriptor();
/* 187 */     if (chartDescriptor != null) {
/* 188 */       writeChartDescriptor(chartDescriptor);
/*     */     }
/*     */     
/* 191 */     write(paramChartElement.getChart(), true);
/* 192 */     this.writer.println("</ChartElement>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   public void write(TOCElement paramTOCElement) { write(paramTOCElement); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(CompositeElement paramCompositeElement) {
/* 207 */     Context context = new Context(this.sheet);
/* 208 */     CompositeLens compositeLens = paramCompositeElement.getComposite();
/*     */     
/* 210 */     compositeLens.reset(); Object object; for (; (object = compositeLens.nextElement(context)) != null; 
/* 211 */       context = new Context(this.sheet)) {
/* 212 */       ReportElement reportElement = this.sheet.getCompositeElement(paramCompositeElement.getID(), object, context);
/*     */ 
/*     */       
/* 215 */       if (reportElement != null) {
/* 216 */         reportElement.setContext(context);
/* 217 */         Builder.write(this, reportElement);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void write(TableLens paramTableLens, TableElement paramTableElement) {
/* 226 */     this.writer.println("<Table Rows=\"" + paramTableLens.getRowCount() + "\" Cols=\"" + paramTableLens.getColCount() + "\" HeaderRow=\"" + paramTableLens.getHeaderRowCount() + "\" HeaderCol=\"" + paramTableLens.getHeaderColCount() + "\">");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
/* 232 */       this.writer.println("<TR Height=\"" + paramTableLens.getRowHeight(b) + "\">");
/*     */       
/* 234 */       for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++) {
/* 235 */         this.writer.print("<TD");
/*     */ 
/*     */         
/* 238 */         if (b == 0) {
/* 239 */           this.writer.print(" Width=\"" + paramTableLens.getColWidth(b1) + "\"");
/* 240 */           Color color1 = paramTableLens.getRowBorderColor(-1, b1);
/* 241 */           if (color1 != null) {
/* 242 */             this.writer.print(" Row0BorderColor=\"" + color1.getRGB() + "\" Row0Border=\"" + paramTableLens.getRowBorder(-1, b1) + "\"");
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 249 */         if (b1 == 0) {
/* 250 */           Color color1 = paramTableLens.getColBorderColor(b, -1);
/* 251 */           if (color1 != null) {
/* 252 */             this.writer.print(" Col0BorderColor=\"" + color1.getRGB() + "\"");
/*     */           }
/*     */           
/* 255 */           this.writer.print(" Col0Border=\"" + paramTableLens.getColBorder(b, -1) + "\"");
/*     */         } 
/*     */ 
/*     */         
/* 259 */         Color color = paramTableLens.getRowBorderColor(b, b1);
/* 260 */         if (color != null) {
/* 261 */           this.writer.print(" RowBorderColor=\"" + color.getRGB() + "\"");
/*     */         }
/*     */         
/* 264 */         color = paramTableLens.getColBorderColor(b, b1);
/* 265 */         if (color != null) {
/* 266 */           this.writer.print(" ColBorderColor=\"" + color.getRGB() + "\"");
/*     */         }
/*     */         
/* 269 */         this.writer.print(" RowBorder=\"" + paramTableLens.getRowBorder(b, b1) + "\" ColBorder=\"" + paramTableLens.getColBorder(b, b1) + "\"");
/*     */ 
/*     */         
/* 272 */         Insets insets = paramTableLens.getInsets(b, b1);
/* 273 */         if (insets != null) {
/* 274 */           this.writer.print(" Insets=\"" + insets.top + "," + insets.left + "," + insets.bottom + "," + insets.right + "\"");
/*     */         }
/*     */ 
/*     */         
/* 278 */         Dimension dimension = paramTableLens.getSpan(b, b1);
/* 279 */         if (dimension != null) {
/* 280 */           this.writer.print(" Span=\"" + dimension.width + "x" + dimension.height + "\"");
/*     */         }
/*     */         
/* 283 */         this.writer.print(" Alignment=\"" + paramTableLens.getAlignment(b, b1) + "\"");
/*     */         
/* 285 */         Font font = paramTableLens.getFont(b, b1);
/* 286 */         if (font != null) {
/* 287 */           this.writer.print(" Font=\"" + StyleFont.toString(font) + "\"");
/*     */         }
/*     */         
/* 290 */         this.writer.print(" LineWrap=\"" + paramTableLens.isLineWrap(b, b1) + "\"");
/*     */         
/* 292 */         color = paramTableLens.getForeground(b, b1);
/* 293 */         if (color != null) {
/* 294 */           this.writer.print(" Foreground=\"" + color.getRGB() + "\"");
/*     */         }
/*     */         
/* 297 */         color = paramTableLens.getBackground(b, b1);
/* 298 */         if (color != null) {
/* 299 */           this.writer.print(" Background=\"" + color.getRGB() + "\"");
/*     */         }
/*     */         
/* 302 */         this.writer.println(">");
/*     */         
/* 304 */         Object object = paramTableLens.getObject(b, b1);
/* 305 */         if (object != null) {
/* 306 */           Presenter presenter = paramTableElement.getPresenter(object.getClass());
/*     */           
/* 308 */           if (presenter != null) {
/* 309 */             write(new PresenterPainter(object, presenter), paramTableElement);
/*     */           }
/* 311 */           else if (object instanceof Image) {
/* 312 */             write(new ImagePainter((Image)object), paramTableElement);
/*     */           }
/* 314 */           else if (object instanceof Component) {
/* 315 */             write(new ComponentPainter((Component)object), paramTableElement);
/*     */           }
/* 317 */           else if (object instanceof Painter) {
/* 318 */             write((Painter)object, paramTableElement);
/*     */           } else {
/*     */             
/* 321 */             Format format = paramTableElement.getFormat(object.getClass());
/* 322 */             if (format != null) {
/* 323 */               object = format.format(object);
/*     */             }
/*     */             
/* 326 */             this.writer.println("<![CDATA[" + object + "]]>");
/*     */           } 
/*     */         } 
/*     */         
/* 330 */         this.writer.print("</TD>");
/*     */       } 
/*     */       
/* 333 */       this.writer.println("</TR>");
/*     */     } 
/*     */     
/* 336 */     this.writer.println("</Table>");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\ReportFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */