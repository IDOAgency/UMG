package inetsoft.report.io;

import inetsoft.report.ChartDescriptor;
import inetsoft.report.ChartElement;
import inetsoft.report.CompositeElement;
import inetsoft.report.CompositeLens;
import inetsoft.report.Context;
import inetsoft.report.FormElement;
import inetsoft.report.FormLens;
import inetsoft.report.Painter;
import inetsoft.report.PainterElement;
import inetsoft.report.Presenter;
import inetsoft.report.ReportElement;
import inetsoft.report.StyleFont;
import inetsoft.report.TOCElement;
import inetsoft.report.TableElement;
import inetsoft.report.TableLens;
import inetsoft.report.painter.ComponentPainter;
import inetsoft.report.painter.ImagePainter;
import inetsoft.report.painter.PresenterPainter;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.io.OutputStream;
import java.text.Format;

class ReportFormatter extends TemplateFormatter {
  public ReportFormatter(OutputStream paramOutputStream) { super(paramOutputStream); }
  
  public void write(TableElement paramTableElement) {
    this.writer.print("<TableElement ");
    writeElementAttributes(paramTableElement);
    this.writer.print(" TableWidth=\"" + paramTableElement.getTableWidth() + "\"");
    if (paramTableElement.getFixedWidths() != null) {
      int[] arrayOfInt = paramTableElement.getFixedWidths();
      this.writer.print(" FixedWidths=\"");
      for (byte b = 0; b < arrayOfInt.length; b++) {
        if (b)
          this.writer.print(","); 
        this.writer.print(arrayOfInt[b]);
      } 
      this.writer.print("\" ");
    } 
    this.writer.print(" Layout=\"" + paramTableElement.getLayout() + "\"");
    this.writer.print(" TableAdvance=\"" + paramTableElement.getTableAdvance() + "\"");
    this.writer.print(" OrphanControl=\"" + paramTableElement.isOrphanControl() + "\"");
    Insets insets = paramTableElement.getPadding();
    if (insets != null)
      this.writer.print(" Padding=\"" + insets.top + "," + insets.left + "," + insets.bottom + "," + insets.right + "\""); 
    this.writer.println(">");
    writeElementProperties(paramTableElement);
    Point[] arrayOfPoint = paramTableElement.getOnClickRange();
    if (arrayOfPoint != null)
      for (byte b = 0; b < arrayOfPoint.length; b++)
        this.writer.println("<onClickRange Row=\"" + (arrayOfPoint[b]).y + "\" Col=\"" + (arrayOfPoint[b]).x + "\"/>");  
    write(paramTableElement.getTable(), paramTableElement);
    this.writer.println("</TableElement>");
  }
  
  public void write(FormElement paramFormElement) {
    FormLens formLens = paramFormElement.getForm();
    this.writer.print("<FormElement ");
    writeElementAttributes(paramFormElement);
    this.writer.print(" FieldPerRow=\"" + formLens.getFieldPerRow() + "\"");
    if (formLens.getLabelFont(false) != null)
      this.writer.print(" LabelFont=\"" + StyleFont.toString(formLens.getLabelFont(0)) + "\""); 
    if (formLens.getLabelForeground(false) != null)
      this.writer.print(" LabelForeground=\"" + formLens.getLabelForeground(0).getRGB() + "\""); 
    if (formLens.getLabelBackground(false) != null)
      this.writer.print(" LabelBackground=\"" + formLens.getLabelBackground(0).getRGB() + "\""); 
    if (formLens.getFont(false) != null)
      this.writer.print(" FieldFont=\"" + StyleFont.toString(formLens.getFont(0)) + "\""); 
    if (formLens.getForeground(false) != null)
      this.writer.print(" FieldForeground=\"" + formLens.getForeground(0).getRGB() + "\""); 
    if (formLens.getBackground(false) != null)
      this.writer.print(" FieldBackground=\"" + formLens.getBackground(0).getRGB() + "\""); 
    this.writer.print(" Underline=\"" + formLens.getUnderline() + "\"");
    if (paramFormElement.getFixedWidths() != null) {
      int[] arrayOfInt = paramFormElement.getFixedWidths();
      this.writer.print(" FixedWidths=\"");
      for (byte b = 0; b < arrayOfInt.length; b++) {
        if (b)
          this.writer.print(","); 
        this.writer.print(arrayOfInt[b]);
      } 
      this.writer.print("\" ");
    } 
    this.writer.println(">");
    writeElementProperties(paramFormElement);
    write(formLens);
    this.writer.println("</FormElement>");
  }
  
  public void write(PainterElement paramPainterElement) {
    if (paramPainterElement instanceof inetsoft.report.internal.FieldElementDef) {
      super.write(paramPainterElement);
      return;
    } 
    this.writer.print("<PainterElement ");
    writeElementAttributes(paramPainterElement);
    this.writer.print(" ");
    writePainterAttributes(paramPainterElement);
    if (paramPainterElement.getPainter() instanceof inetsoft.report.painter.BulletPainter)
      this.writer.print(" Painter=\"bullet\""); 
    this.writer.println(">");
    writeElementProperties(paramPainterElement);
    write(paramPainterElement.getPainter(), paramPainterElement);
    this.writer.println("</PainterElement>");
  }
  
  public void write(ChartElement paramChartElement) {
    this.writer.print("<ChartElement ");
    writeElementAttributes(paramChartElement);
    this.writer.print(" ");
    writePainterAttributes(paramChartElement);
    this.writer.println(">");
    writeElementProperties(paramChartElement);
    ChartDescriptor chartDescriptor = paramChartElement.getChartDescriptor();
    if (chartDescriptor != null)
      writeChartDescriptor(chartDescriptor); 
    write(paramChartElement.getChart(), true);
    this.writer.println("</ChartElement>");
  }
  
  public void write(TOCElement paramTOCElement) { write(paramTOCElement); }
  
  public void write(CompositeElement paramCompositeElement) {
    Context context = new Context(this.sheet);
    CompositeLens compositeLens = paramCompositeElement.getComposite();
    compositeLens.reset();
    Object object;
    for (; (object = compositeLens.nextElement(context)) != null; 
      context = new Context(this.sheet)) {
      ReportElement reportElement = this.sheet.getCompositeElement(paramCompositeElement.getID(), object, context);
      if (reportElement != null) {
        reportElement.setContext(context);
        Builder.write(this, reportElement);
      } 
    } 
  }
  
  protected void write(TableLens paramTableLens, TableElement paramTableElement) {
    this.writer.println("<Table Rows=\"" + paramTableLens.getRowCount() + "\" Cols=\"" + paramTableLens.getColCount() + "\" HeaderRow=\"" + paramTableLens.getHeaderRowCount() + "\" HeaderCol=\"" + paramTableLens.getHeaderColCount() + "\">");
    for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
      this.writer.println("<TR Height=\"" + paramTableLens.getRowHeight(b) + "\">");
      for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++) {
        this.writer.print("<TD");
        if (b == 0) {
          this.writer.print(" Width=\"" + paramTableLens.getColWidth(b1) + "\"");
          Color color1 = paramTableLens.getRowBorderColor(-1, b1);
          if (color1 != null)
            this.writer.print(" Row0BorderColor=\"" + color1.getRGB() + "\" Row0Border=\"" + paramTableLens.getRowBorder(-1, b1) + "\""); 
        } 
        if (b1 == 0) {
          Color color1 = paramTableLens.getColBorderColor(b, -1);
          if (color1 != null)
            this.writer.print(" Col0BorderColor=\"" + color1.getRGB() + "\""); 
          this.writer.print(" Col0Border=\"" + paramTableLens.getColBorder(b, -1) + "\"");
        } 
        Color color = paramTableLens.getRowBorderColor(b, b1);
        if (color != null)
          this.writer.print(" RowBorderColor=\"" + color.getRGB() + "\""); 
        color = paramTableLens.getColBorderColor(b, b1);
        if (color != null)
          this.writer.print(" ColBorderColor=\"" + color.getRGB() + "\""); 
        this.writer.print(" RowBorder=\"" + paramTableLens.getRowBorder(b, b1) + "\" ColBorder=\"" + paramTableLens.getColBorder(b, b1) + "\"");
        Insets insets = paramTableLens.getInsets(b, b1);
        if (insets != null)
          this.writer.print(" Insets=\"" + insets.top + "," + insets.left + "," + insets.bottom + "," + insets.right + "\""); 
        Dimension dimension = paramTableLens.getSpan(b, b1);
        if (dimension != null)
          this.writer.print(" Span=\"" + dimension.width + "x" + dimension.height + "\""); 
        this.writer.print(" Alignment=\"" + paramTableLens.getAlignment(b, b1) + "\"");
        Font font = paramTableLens.getFont(b, b1);
        if (font != null)
          this.writer.print(" Font=\"" + StyleFont.toString(font) + "\""); 
        this.writer.print(" LineWrap=\"" + paramTableLens.isLineWrap(b, b1) + "\"");
        color = paramTableLens.getForeground(b, b1);
        if (color != null)
          this.writer.print(" Foreground=\"" + color.getRGB() + "\""); 
        color = paramTableLens.getBackground(b, b1);
        if (color != null)
          this.writer.print(" Background=\"" + color.getRGB() + "\""); 
        this.writer.println(">");
        Object object = paramTableLens.getObject(b, b1);
        if (object != null) {
          Presenter presenter = paramTableElement.getPresenter(object.getClass());
          if (presenter != null) {
            write(new PresenterPainter(object, presenter), paramTableElement);
          } else if (object instanceof Image) {
            write(new ImagePainter((Image)object), paramTableElement);
          } else if (object instanceof Component) {
            write(new ComponentPainter((Component)object), paramTableElement);
          } else if (object instanceof Painter) {
            write((Painter)object, paramTableElement);
          } else {
            Format format = paramTableElement.getFormat(object.getClass());
            if (format != null)
              object = format.format(object); 
            this.writer.println("<![CDATA[" + object + "]]>");
          } 
        } 
        this.writer.print("</TD>");
      } 
      this.writer.println("</TR>");
    } 
    this.writer.println("</Table>");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\ReportFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */