package inetsoft.report.io;

import inetsoft.report.AreaBreakElement;
import inetsoft.report.ChartElement;
import inetsoft.report.CompositeElement;
import inetsoft.report.CondPageBreakElement;
import inetsoft.report.FormElement;
import inetsoft.report.HeadingElement;
import inetsoft.report.NewlineElement;
import inetsoft.report.PageBreakElement;
import inetsoft.report.PageLayoutElement;
import inetsoft.report.PainterElement;
import inetsoft.report.SectionElement;
import inetsoft.report.SeparatorElement;
import inetsoft.report.SpaceElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.TOCElement;
import inetsoft.report.TabElement;
import inetsoft.report.TableElement;
import inetsoft.report.TextBoxElement;
import inetsoft.report.TextElement;
import inetsoft.report.style.XTableStyle;

public interface Formatter {
  void prolog(StyleSheet paramStyleSheet);
  
  void startHeader(int paramInt);
  
  void startHeader(String paramString, boolean paramBoolean);
  
  void endHeader();
  
  void write(XTableStyle paramXTableStyle);
  
  void write(TextElement paramTextElement);
  
  void write(HeadingElement paramHeadingElement);
  
  void write(TableElement paramTableElement);
  
  void write(SectionElement paramSectionElement);
  
  void write(FormElement paramFormElement);
  
  void write(PainterElement paramPainterElement);
  
  void write(ChartElement paramChartElement);
  
  void write(TextBoxElement paramTextBoxElement);
  
  void write(TabElement paramTabElement);
  
  void write(NewlineElement paramNewlineElement);
  
  void write(AreaBreakElement paramAreaBreakElement);
  
  void write(PageBreakElement paramPageBreakElement);
  
  void write(PageLayoutElement paramPageLayoutElement);
  
  void write(CondPageBreakElement paramCondPageBreakElement);
  
  void write(SpaceElement paramSpaceElement);
  
  void write(SeparatorElement paramSeparatorElement);
  
  void write(TOCElement paramTOCElement);
  
  void write(CompositeElement paramCompositeElement);
  
  void end();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\Formatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */