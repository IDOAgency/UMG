package inetsoft.report.io;

import inetsoft.report.ChartDescriptor;
import inetsoft.report.Common;
import inetsoft.report.StyleFont;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.ChartElementDef;
import inetsoft.report.internal.EmptyPainter;
import inetsoft.report.internal.FormElementDef;
import inetsoft.report.internal.PainterElementDef;
import inetsoft.report.internal.TableElementDef;
import inetsoft.report.internal.Util;
import inetsoft.report.internal.XMLException;
import inetsoft.report.internal.XMLTokenStream;
import inetsoft.report.lens.DefaultChartLens;
import inetsoft.report.lens.DefaultFormLens;
import inetsoft.report.lens.DefaultTableLens;
import inetsoft.report.painter.BulletPainter;
import inetsoft.report.painter.ImagePainter;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.StringTokenizer;
import java.util.Vector;

public class ReportParser extends TemplateParser {
  public ReportParser(InputStream paramInputStream) { super(paramInputStream); }
  
  public StyleSheet createSheet(String paramString) {
    this.sheet = Common.createStyleSheet();
    return this.sheet;
  }
  
  protected Object readTable(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
    DefaultTableLens defaultTableLens = new DefaultTableLens(5, 5);
    TableElementDef tableElementDef = new TableElementDef(this.sheet, defaultTableLens);
    setElementAttributes(tableElementDef, paramTag);
    String str;
    if ((str = paramTag.get("TableWidth")) != null)
      tableElementDef.setTableWidth(Double.valueOf(str).doubleValue()); 
    if ((str = paramTag.get("FixedWidths")) != null) {
      String[] arrayOfString = Util.split(str, ',');
      int[] arrayOfInt = new int[arrayOfString.length];
      for (byte b = 0; b < arrayOfInt.length; b++)
        arrayOfInt[b] = Integer.parseInt(arrayOfString[b]); 
      tableElementDef.setFixedWidths(arrayOfInt);
    } 
    if ((str = paramTag.get("Layout")) != null)
      tableElementDef.setLayout(Integer.parseInt(str)); 
    if ((str = paramTag.get("TableAdvance")) != null)
      tableElementDef.setTableAdvance(Integer.parseInt(str)); 
    if ((str = paramTag.get("OrphanControl")) != null)
      tableElementDef.setOrphanControl(str.equalsIgnoreCase("true")); 
    if ((str = paramTag.get("Padding")) != null) {
      String[] arrayOfString = Util.split(str, ',');
      tableElementDef.setPadding(new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
    } 
    Vector vector = new Vector();
    for (paramTag = (XMLTokenStream.Tag)readProperties(tableElementDef); paramTag != null; 
      paramTag = (XMLTokenStream.Tag)this.xml.getToken()) {
      if (paramTag.getName().equals("TABLE")) {
        defaultTableLens.setRowCount(Integer.parseInt(paramTag.get("Rows")));
        defaultTableLens.setColCount(Integer.parseInt(paramTag.get("Cols")));
        defaultTableLens.setHeaderRowCount(Integer.parseInt(paramTag.get("HeaderRow")));
        defaultTableLens.setHeaderColCount(Integer.parseInt(paramTag.get("HeaderCol")));
        byte b = -1;
        byte b1 = 0;
        Object object;
        while ((object = this.xml.getToken()) != null) {
          if (!(object instanceof XMLTokenStream.Tag))
            continue; 
          paramTag = (XMLTokenStream.Tag)object;
          if (paramTag.getName().equals("TD")) {
            if ((str = paramTag.get("Width")) != null)
              defaultTableLens.setColWidth(b1, Integer.parseInt(str)); 
            if ((str = paramTag.get("Row0BorderColor")) != null)
              defaultTableLens.setRowBorderColor(-1, b1, new Color(Integer.parseInt(str))); 
            if ((str = paramTag.get("Row0Border")) != null)
              defaultTableLens.setRowBorder(-1, b1, Integer.parseInt(str)); 
            if ((str = paramTag.get("Col0BorderColor")) != null)
              defaultTableLens.setColBorderColor(b, -1, new Color(Integer.parseInt(str))); 
            if ((str = paramTag.get("Col0Border")) != null)
              defaultTableLens.setColBorder(b, -1, Integer.parseInt(str)); 
            if ((str = paramTag.get("RowBorderColor")) != null)
              defaultTableLens.setRowBorderColor(b, b1, new Color(Integer.parseInt(str))); 
            if ((str = paramTag.get("RowBorder")) != null)
              defaultTableLens.setRowBorder(b, b1, Integer.parseInt(str)); 
            if ((str = paramTag.get("ColBorderColor")) != null)
              defaultTableLens.setColBorderColor(b, b1, new Color(Integer.parseInt(str))); 
            if ((str = paramTag.get("ColBorder")) != null)
              defaultTableLens.setColBorder(b, b1, Integer.parseInt(str)); 
            if ((str = paramTag.get("Insets")) != null) {
              String[] arrayOfString = Util.split(str, ',');
              defaultTableLens.setInsets(b, b1, new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
            } 
            if ((str = paramTag.get("Span")) != null) {
              String[] arrayOfString = Util.split(str, 'x');
              defaultTableLens.setSpan(b, b1, new Dimension(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1])));
            } 
            if ((str = paramTag.get("Alignment")) != null)
              defaultTableLens.setAlignment(b, b1, Integer.parseInt(str)); 
            if ((str = paramTag.get("Font")) != null)
              defaultTableLens.setFont(b, b1, StyleFont.decode(str)); 
            if ((str = paramTag.get("LineWrap")) != null)
              defaultTableLens.setLineWrap(b, b1, Boolean.valueOf(str).booleanValue()); 
            if ((str = paramTag.get("Foreground")) != null)
              defaultTableLens.setForeground(b, b1, new Color(Integer.parseInt(str))); 
            if ((str = paramTag.get("Background")) != null)
              defaultTableLens.setBackground(b, b1, new Color(Integer.parseInt(str))); 
            object = this.xml.getToken();
            if (object instanceof String) {
              defaultTableLens.setObject(b, b1, object.equals("null") ? null : object);
            } else {
              paramTag = (XMLTokenStream.Tag)object;
              if (paramTag.getName().equals("IMAGE"))
                defaultTableLens.setObject(b, b1, readImageData(paramTag)); 
            } 
            b1++;
            continue;
          } 
          if (paramTag.getName().equals("TR")) {
            b++;
            b1 = 0;
            if ((str = paramTag.get("Height")) != null)
              defaultTableLens.setRowHeight(b, Integer.parseInt(str)); 
            continue;
          } 
          if (paramTag.getName().equals("/TABLE"))
            break; 
        } 
        tableElementDef.setTable(defaultTableLens);
      } else if (paramTag.getName().equals("ONCLICKRANGE")) {
        Point point = new Point(Integer.parseInt(paramTag.get("Col")), Integer.parseInt(paramTag.get("Row")));
        vector.addElement(point);
        paramTag = (XMLTokenStream.Tag)this.xml.getToken();
        while (!paramTag.getName().equals("/ONCLICKRANGE"))
          paramTag = (XMLTokenStream.Tag)this.xml.getToken(); 
      } else if (paramTag.getName().equals("/TABLEELEMENT")) {
        break;
      } 
    } 
    if (vector.size() > 0) {
      Point[] arrayOfPoint = new Point[vector.size()];
      vector.copyInto(arrayOfPoint);
      tableElementDef.setOnClickRange(arrayOfPoint);
    } 
    return tableElementDef;
  }
  
  protected Object readForm(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
    DefaultFormLens defaultFormLens = new DefaultFormLens();
    FormElementDef formElementDef = new FormElementDef(this.sheet, defaultFormLens);
    setElementAttributes(formElementDef, paramTag);
    String str;
    if ((str = paramTag.get("FieldPerRow")) != null)
      defaultFormLens.setFieldPerRow(Integer.parseInt(str)); 
    if ((str = paramTag.get("LabelFont")) != null)
      defaultFormLens.setLabelFont(StyleFont.decode(str)); 
    if ((str = paramTag.get("LabelForeground")) != null)
      defaultFormLens.setLabelForeground(new Color(Integer.parseInt(str))); 
    if ((str = paramTag.get("LabelBackground")) != null)
      defaultFormLens.setLabelBackground(new Color(Integer.parseInt(str))); 
    if ((str = paramTag.get("FieldFont")) != null)
      defaultFormLens.setFont(StyleFont.decode(str)); 
    if ((str = paramTag.get("FieldForeground")) != null)
      defaultFormLens.setForeground(new Color(Integer.parseInt(str))); 
    if ((str = paramTag.get("FieldBackground")) != null)
      defaultFormLens.setBackground(new Color(Integer.parseInt(str))); 
    if ((str = paramTag.get("Underline")) != null)
      defaultFormLens.setUnderline(Integer.parseInt(str)); 
    if ((str = paramTag.get("FixedWidths")) != null) {
      String[] arrayOfString = Util.split(str, ',');
      int[] arrayOfInt = new int[arrayOfString.length];
      for (byte b1 = 0; b1 < arrayOfInt.length; b1++)
        arrayOfInt[b1] = Integer.parseInt(arrayOfString[b1]); 
      formElementDef.setFixedWidths(arrayOfInt);
    } 
    paramTag = (XMLTokenStream.Tag)readProperties(formElementDef);
    defaultFormLens.setFieldCount(Integer.parseInt(paramTag.get("Fields")));
    StringTokenizer stringTokenizer = new StringTokenizer((String)this.xml.getToken(), "\n\r");
    for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
      String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
      defaultFormLens.setLabel(b, arrayOfString[0]);
      defaultFormLens.setField(b, arrayOfString[1]);
    } 
    return formElementDef;
  }
  
  protected Object readPainter(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
    PainterElementDef painterElementDef = new PainterElementDef(this.sheet, new EmptyPainter());
    setElementAttributes(painterElementDef, paramTag);
    setPainterAttributes(painterElementDef, paramTag);
    String str;
    if ((str = paramTag.get("Painter")) != null && 
      str.equals("bullet"))
      painterElementDef.setPainter(new BulletPainter()); 
    paramTag = (XMLTokenStream.Tag)readProperties(painterElementDef);
    Image image = readImageData(paramTag);
    painterElementDef.setPainter(new ImagePainter(image));
    return painterElementDef;
  }
  
  protected Object readChart(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
    DefaultChartLens defaultChartLens = new DefaultChartLens();
    ChartElementDef chartElementDef = new ChartElementDef(this.sheet, defaultChartLens);
    setElementAttributes(chartElementDef, paramTag);
    setPainterAttributes(chartElementDef, paramTag);
    for (paramTag = (XMLTokenStream.Tag)readProperties(chartElementDef); paramTag != null; ) {
      if (paramTag.getName().equals("CHARTDESCRIPTOR")) {
        ChartDescriptor chartDescriptor = new ChartDescriptor();
        chartElementDef.setChartDescriptor(chartDescriptor);
        String str;
        if ((str = paramTag.get("ValueFormat")) != null)
          chartDescriptor.setValueFormat(new DecimalFormat(str)); 
        if ((str = paramTag.get("YAxisFormat")) != null)
          chartDescriptor.setYAxisFormat(new DecimalFormat(str)); 
        if ((str = paramTag.get("SecondaryYAxisFormat")) != null)
          chartDescriptor.setSecondaryYAxisFormat(new DecimalFormat(str)); 
        if ((str = paramTag.get("LineWidth")) != null)
          chartDescriptor.setLineChartLineWidth(Float.valueOf(str).floatValue()); 
        if ((str = paramTag.get("PointSize")) != null)
          chartDescriptor.setPointSize(Float.valueOf(str).floatValue()); 
        if ((str = paramTag.get("XLabelRotation")) != null)
          chartDescriptor.setXLabelRotation(Double.valueOf(str).doubleValue()); 
        if ((str = paramTag.get("BarBorder")) != null)
          chartDescriptor.setBarBorder(Boolean.valueOf(str).booleanValue()); 
        if ((str = paramTag.get("PointStyle")) != null) {
          String[] arrayOfString = Util.split(str, ',');
          for (byte b1 = 0; b1 < arrayOfString.length; b1++)
            chartDescriptor.setPointStyle(b1, Integer.parseInt(arrayOfString[b1])); 
        } 
        if ((str = paramTag.get("FirstDatasetOfSecondaryAxis")) != null)
          chartDescriptor.setFirstDatasetOfSecondaryAxis(Integer.parseInt(str)); 
        if ((str = paramTag.get("VerticalGridStyle")) != null)
          chartDescriptor.setVerticalGridStyle(Integer.parseInt(str)); 
        if ((str = paramTag.get("LogarithmicYScale")) != null)
          chartDescriptor.setLogarithmicYScale(Boolean.valueOf(str).booleanValue()); 
        if ((str = paramTag.get("SecondaryLogarithmicYScale")) != null)
          chartDescriptor.setSecondaryLogarithmicYScale(Boolean.valueOf(str).booleanValue()); 
        if ((str = paramTag.get("SecondaryMaximum")) != null)
          chartDescriptor.setSecondaryMaximum(Double.valueOf(str)); 
        if ((str = paramTag.get("SecondaryMinimum")) != null)
          chartDescriptor.setSecondaryMinimum(Double.valueOf(str)); 
        if ((str = paramTag.get("SecondaryIncrement")) != null)
          chartDescriptor.setSecondaryIncrement(Double.valueOf(str)); 
        if ((str = paramTag.get("SecondaryMinorIncrement")) != null)
          chartDescriptor.setSecondaryMinorIncrement(Double.valueOf(str)); 
        if ((str = paramTag.get("SecondaryYTitle")) != null)
          chartDescriptor.setSecondaryYTitle(str); 
        do {
        
        } while ((paramTag = (XMLTokenStream.Tag)this.xml.getToken()) != null && !paramTag.getName().equals("/CHARTDESCRIPTOR"));
        paramTag = (XMLTokenStream.Tag)this.xml.getToken();
      } 
      break;
    } 
    if (paramTag.getName().equals("CHART")) {
      defaultChartLens.setDatasetCount(Integer.parseInt(paramTag.get("Datasets")));
      defaultChartLens.setDatasetSize(Integer.parseInt(paramTag.get("Size")));
      String str;
      if ((str = paramTag.get("Style")) != null)
        defaultChartLens.setStyle(Integer.parseInt(str)); 
      if ((str = paramTag.get("Maximum")) != null)
        defaultChartLens.setMaximum(Double.valueOf(str)); 
      if ((str = paramTag.get("Minimum")) != null)
        defaultChartLens.setMinimum(Double.valueOf(str)); 
      if ((str = paramTag.get("Increment")) != null)
        defaultChartLens.setIncrement(Double.valueOf(str)); 
      if ((str = paramTag.get("MinorIncrement")) != null)
        defaultChartLens.setMinorIncrement(Double.valueOf(str)); 
      if ((str = paramTag.get("Gap")) != null)
        defaultChartLens.setGap(Integer.parseInt(str)); 
      if ((str = paramTag.get("XTitle")) != null)
        defaultChartLens.setXTitle(str); 
      if ((str = paramTag.get("YTitle")) != null)
        defaultChartLens.setYTitle(str); 
      if ((str = paramTag.get("TitleFont")) != null)
        defaultChartLens.setTitleFont(StyleFont.decode(str)); 
      if ((str = paramTag.get("GridStyle")) != null)
        defaultChartLens.setGridStyle(Integer.parseInt(str)); 
      if ((str = paramTag.get("BorderStyle")) != null)
        defaultChartLens.setBorderStyle(Integer.parseInt(str)); 
      if ((str = paramTag.get("ShowValue")) != null)
        defaultChartLens.setShowValue(Boolean.valueOf(str).booleanValue()); 
      if ((str = paramTag.get("Precision")) != null)
        defaultChartLens.setPrecision(Integer.parseInt(str)); 
      if ((str = paramTag.get("LegendPosition")) != null)
        defaultChartLens.setLegendPosition(Integer.parseInt(str)); 
      if ((str = paramTag.get("BlackWhite")) != null)
        defaultChartLens.setBlackWhite(Boolean.valueOf(str).booleanValue()); 
    } 
    chartElementDef.setChart(defaultChartLens);
    StringTokenizer stringTokenizer = new StringTokenizer((String)this.xml.getToken(), "\n\r");
    if (stringTokenizer.hasMoreTokens()) {
      String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
      for (byte b1 = 0; b1 < arrayOfString.length && b1 < defaultChartLens.getDatasetCount(); b1++)
        defaultChartLens.setDatasetLabel(b1, arrayOfString[b1]); 
    } 
    if (stringTokenizer.hasMoreTokens()) {
      String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
      for (byte b1 = 0; b1 < arrayOfString.length && b1 < defaultChartLens.getDatasetSize(); b1++)
        defaultChartLens.setLabel(b1, arrayOfString[b1]); 
    } 
    for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
      String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
      for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
        if (arrayOfString[b1].length() > 0)
          defaultChartLens.setData(b, b1, Double.valueOf(arrayOfString[b1])); 
      } 
    } 
    return chartElementDef;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\ReportParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */