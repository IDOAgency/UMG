/*     */ package inetsoft.report.io;
/*     */ 
/*     */ import inetsoft.report.ChartDescriptor;
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.StyleFont;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.ChartElementDef;
/*     */ import inetsoft.report.internal.EmptyPainter;
/*     */ import inetsoft.report.internal.FormElementDef;
/*     */ import inetsoft.report.internal.PainterElementDef;
/*     */ import inetsoft.report.internal.TableElementDef;
/*     */ import inetsoft.report.internal.Util;
/*     */ import inetsoft.report.internal.XMLException;
/*     */ import inetsoft.report.internal.XMLTokenStream;
/*     */ import inetsoft.report.lens.DefaultChartLens;
/*     */ import inetsoft.report.lens.DefaultFormLens;
/*     */ import inetsoft.report.lens.DefaultTableLens;
/*     */ import inetsoft.report.painter.BulletPainter;
/*     */ import inetsoft.report.painter.ImagePainter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReportParser
/*     */   extends TemplateParser
/*     */ {
/*  38 */   public ReportParser(InputStream paramInputStream) { super(paramInputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StyleSheet createSheet(String paramString) {
/*  46 */     this.sheet = Common.createStyleSheet();
/*  47 */     return this.sheet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readTable(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*  56 */     DefaultTableLens defaultTableLens = new DefaultTableLens(5, 5);
/*  57 */     TableElementDef tableElementDef = new TableElementDef(this.sheet, defaultTableLens);
/*     */     
/*  59 */     setElementAttributes(tableElementDef, paramTag);
/*     */     String str;
/*  61 */     if ((str = paramTag.get("TableWidth")) != null) {
/*  62 */       tableElementDef.setTableWidth(Double.valueOf(str).doubleValue());
/*     */     }
/*     */     
/*  65 */     if ((str = paramTag.get("FixedWidths")) != null) {
/*  66 */       String[] arrayOfString = Util.split(str, ',');
/*  67 */       int[] arrayOfInt = new int[arrayOfString.length];
/*     */       
/*  69 */       for (byte b = 0; b < arrayOfInt.length; b++) {
/*  70 */         arrayOfInt[b] = Integer.parseInt(arrayOfString[b]);
/*     */       }
/*  72 */       tableElementDef.setFixedWidths(arrayOfInt);
/*     */     } 
/*     */     
/*  75 */     if ((str = paramTag.get("Layout")) != null) {
/*  76 */       tableElementDef.setLayout(Integer.parseInt(str));
/*     */     }
/*     */     
/*  79 */     if ((str = paramTag.get("TableAdvance")) != null) {
/*  80 */       tableElementDef.setTableAdvance(Integer.parseInt(str));
/*     */     }
/*     */     
/*  83 */     if ((str = paramTag.get("OrphanControl")) != null) {
/*  84 */       tableElementDef.setOrphanControl(str.equalsIgnoreCase("true"));
/*     */     }
/*     */     
/*  87 */     if ((str = paramTag.get("Padding")) != null) {
/*  88 */       String[] arrayOfString = Util.split(str, ',');
/*  89 */       tableElementDef.setPadding(new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     Vector vector = new Vector();
/*     */ 
/*     */     
/*  98 */     for (paramTag = (XMLTokenStream.Tag)readProperties(tableElementDef); paramTag != null; 
/*  99 */       paramTag = (XMLTokenStream.Tag)this.xml.getToken()) {
/* 100 */       if (paramTag.getName().equals("TABLE")) {
/* 101 */         defaultTableLens.setRowCount(Integer.parseInt(paramTag.get("Rows")));
/* 102 */         defaultTableLens.setColCount(Integer.parseInt(paramTag.get("Cols")));
/* 103 */         defaultTableLens.setHeaderRowCount(Integer.parseInt(paramTag.get("HeaderRow")));
/* 104 */         defaultTableLens.setHeaderColCount(Integer.parseInt(paramTag.get("HeaderCol")));
/*     */         
/* 106 */         byte b = -1; byte b1 = 0;
/*     */         
/*     */         Object object;
/* 109 */         while ((object = this.xml.getToken()) != null) {
/* 110 */           if (!(object instanceof XMLTokenStream.Tag)) {
/*     */             continue;
/*     */           }
/*     */           
/* 114 */           paramTag = (XMLTokenStream.Tag)object;
/*     */           
/* 116 */           if (paramTag.getName().equals("TD")) {
/* 117 */             if ((str = paramTag.get("Width")) != null) {
/* 118 */               defaultTableLens.setColWidth(b1, Integer.parseInt(str));
/*     */             }
/*     */             
/* 121 */             if ((str = paramTag.get("Row0BorderColor")) != null) {
/* 122 */               defaultTableLens.setRowBorderColor(-1, b1, new Color(Integer.parseInt(str)));
/*     */             }
/*     */ 
/*     */             
/* 126 */             if ((str = paramTag.get("Row0Border")) != null) {
/* 127 */               defaultTableLens.setRowBorder(-1, b1, Integer.parseInt(str));
/*     */             }
/*     */             
/* 130 */             if ((str = paramTag.get("Col0BorderColor")) != null) {
/* 131 */               defaultTableLens.setColBorderColor(b, -1, new Color(Integer.parseInt(str)));
/*     */             }
/*     */ 
/*     */             
/* 135 */             if ((str = paramTag.get("Col0Border")) != null) {
/* 136 */               defaultTableLens.setColBorder(b, -1, Integer.parseInt(str));
/*     */             }
/*     */             
/* 139 */             if ((str = paramTag.get("RowBorderColor")) != null) {
/* 140 */               defaultTableLens.setRowBorderColor(b, b1, new Color(Integer.parseInt(str)));
/*     */             }
/*     */ 
/*     */             
/* 144 */             if ((str = paramTag.get("RowBorder")) != null) {
/* 145 */               defaultTableLens.setRowBorder(b, b1, Integer.parseInt(str));
/*     */             }
/*     */             
/* 148 */             if ((str = paramTag.get("ColBorderColor")) != null) {
/* 149 */               defaultTableLens.setColBorderColor(b, b1, new Color(Integer.parseInt(str)));
/*     */             }
/*     */ 
/*     */             
/* 153 */             if ((str = paramTag.get("ColBorder")) != null) {
/* 154 */               defaultTableLens.setColBorder(b, b1, Integer.parseInt(str));
/*     */             }
/*     */             
/* 157 */             if ((str = paramTag.get("Insets")) != null) {
/* 158 */               String[] arrayOfString = Util.split(str, ',');
/* 159 */               defaultTableLens.setInsets(b, b1, new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 165 */             if ((str = paramTag.get("Span")) != null) {
/* 166 */               String[] arrayOfString = Util.split(str, 'x');
/* 167 */               defaultTableLens.setSpan(b, b1, new Dimension(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1])));
/*     */             } 
/*     */ 
/*     */             
/* 171 */             if ((str = paramTag.get("Alignment")) != null) {
/* 172 */               defaultTableLens.setAlignment(b, b1, Integer.parseInt(str));
/*     */             }
/*     */             
/* 175 */             if ((str = paramTag.get("Font")) != null) {
/* 176 */               defaultTableLens.setFont(b, b1, StyleFont.decode(str));
/*     */             }
/*     */             
/* 179 */             if ((str = paramTag.get("LineWrap")) != null) {
/* 180 */               defaultTableLens.setLineWrap(b, b1, Boolean.valueOf(str).booleanValue());
/*     */             }
/*     */ 
/*     */             
/* 184 */             if ((str = paramTag.get("Foreground")) != null) {
/* 185 */               defaultTableLens.setForeground(b, b1, new Color(Integer.parseInt(str)));
/*     */             }
/*     */             
/* 188 */             if ((str = paramTag.get("Background")) != null) {
/* 189 */               defaultTableLens.setBackground(b, b1, new Color(Integer.parseInt(str)));
/*     */             }
/*     */             
/* 192 */             object = this.xml.getToken();
/*     */             
/* 194 */             if (object instanceof String) {
/* 195 */               defaultTableLens.setObject(b, b1, object.equals("null") ? null : object);
/*     */             } else {
/*     */               
/* 198 */               paramTag = (XMLTokenStream.Tag)object;
/*     */               
/* 200 */               if (paramTag.getName().equals("IMAGE")) {
/* 201 */                 defaultTableLens.setObject(b, b1, readImageData(paramTag));
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 206 */             b1++; continue;
/*     */           } 
/* 208 */           if (paramTag.getName().equals("TR")) {
/*     */             
/* 210 */             b++;
/* 211 */             b1 = 0;
/*     */             
/* 213 */             if ((str = paramTag.get("Height")) != null)
/* 214 */               defaultTableLens.setRowHeight(b, Integer.parseInt(str)); 
/*     */             continue;
/*     */           } 
/* 217 */           if (paramTag.getName().equals("/TABLE")) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */         
/* 222 */         tableElementDef.setTable(defaultTableLens);
/*     */       }
/* 224 */       else if (paramTag.getName().equals("ONCLICKRANGE")) {
/* 225 */         Point point = new Point(Integer.parseInt(paramTag.get("Col")), Integer.parseInt(paramTag.get("Row")));
/*     */         
/* 227 */         vector.addElement(point);
/*     */         
/* 229 */         paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/* 230 */         while (!paramTag.getName().equals("/ONCLICKRANGE")) {
/* 231 */           paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*     */         }
/*     */       }
/* 234 */       else if (paramTag.getName().equals("/TABLEELEMENT")) {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 239 */     if (vector.size() > 0) {
/* 240 */       Point[] arrayOfPoint = new Point[vector.size()];
/* 241 */       vector.copyInto(arrayOfPoint);
/* 242 */       tableElementDef.setOnClickRange(arrayOfPoint);
/*     */     } 
/*     */     
/* 245 */     return tableElementDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readForm(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/* 254 */     DefaultFormLens defaultFormLens = new DefaultFormLens();
/* 255 */     FormElementDef formElementDef = new FormElementDef(this.sheet, defaultFormLens);
/* 256 */     setElementAttributes(formElementDef, paramTag);
/*     */     String str;
/* 258 */     if ((str = paramTag.get("FieldPerRow")) != null) {
/* 259 */       defaultFormLens.setFieldPerRow(Integer.parseInt(str));
/*     */     }
/*     */     
/* 262 */     if ((str = paramTag.get("LabelFont")) != null) {
/* 263 */       defaultFormLens.setLabelFont(StyleFont.decode(str));
/*     */     }
/*     */     
/* 266 */     if ((str = paramTag.get("LabelForeground")) != null) {
/* 267 */       defaultFormLens.setLabelForeground(new Color(Integer.parseInt(str)));
/*     */     }
/*     */     
/* 270 */     if ((str = paramTag.get("LabelBackground")) != null) {
/* 271 */       defaultFormLens.setLabelBackground(new Color(Integer.parseInt(str)));
/*     */     }
/*     */     
/* 274 */     if ((str = paramTag.get("FieldFont")) != null) {
/* 275 */       defaultFormLens.setFont(StyleFont.decode(str));
/*     */     }
/*     */     
/* 278 */     if ((str = paramTag.get("FieldForeground")) != null) {
/* 279 */       defaultFormLens.setForeground(new Color(Integer.parseInt(str)));
/*     */     }
/*     */     
/* 282 */     if ((str = paramTag.get("FieldBackground")) != null) {
/* 283 */       defaultFormLens.setBackground(new Color(Integer.parseInt(str)));
/*     */     }
/*     */     
/* 286 */     if ((str = paramTag.get("Underline")) != null) {
/* 287 */       defaultFormLens.setUnderline(Integer.parseInt(str));
/*     */     }
/*     */     
/* 290 */     if ((str = paramTag.get("FixedWidths")) != null) {
/* 291 */       String[] arrayOfString = Util.split(str, ',');
/* 292 */       int[] arrayOfInt = new int[arrayOfString.length];
/*     */       
/* 294 */       for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/* 295 */         arrayOfInt[b1] = Integer.parseInt(arrayOfString[b1]);
/*     */       }
/* 297 */       formElementDef.setFixedWidths(arrayOfInt);
/*     */     } 
/*     */     
/* 300 */     paramTag = (XMLTokenStream.Tag)readProperties(formElementDef);
/* 301 */     defaultFormLens.setFieldCount(Integer.parseInt(paramTag.get("Fields")));
/*     */     
/* 303 */     StringTokenizer stringTokenizer = new StringTokenizer((String)this.xml.getToken(), "\n\r");
/*     */ 
/*     */     
/* 306 */     for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
/* 307 */       String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
/* 308 */       defaultFormLens.setLabel(b, arrayOfString[0]);
/* 309 */       defaultFormLens.setField(b, arrayOfString[1]);
/*     */     } 
/*     */     
/* 312 */     return formElementDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readPainter(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/* 321 */     PainterElementDef painterElementDef = new PainterElementDef(this.sheet, new EmptyPainter());
/*     */     
/* 323 */     setElementAttributes(painterElementDef, paramTag);
/* 324 */     setPainterAttributes(painterElementDef, paramTag);
/*     */     String str;
/* 326 */     if ((str = paramTag.get("Painter")) != null && 
/* 327 */       str.equals("bullet")) {
/* 328 */       painterElementDef.setPainter(new BulletPainter());
/*     */     }
/*     */ 
/*     */     
/* 332 */     paramTag = (XMLTokenStream.Tag)readProperties(painterElementDef);
/* 333 */     Image image = readImageData(paramTag);
/* 334 */     painterElementDef.setPainter(new ImagePainter(image));
/*     */     
/* 336 */     return painterElementDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readChart(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/* 345 */     DefaultChartLens defaultChartLens = new DefaultChartLens();
/* 346 */     ChartElementDef chartElementDef = new ChartElementDef(this.sheet, defaultChartLens);
/*     */     
/* 348 */     setElementAttributes(chartElementDef, paramTag);
/* 349 */     setPainterAttributes(chartElementDef, paramTag);
/*     */ 
/*     */     
/* 352 */     for (paramTag = (XMLTokenStream.Tag)readProperties(chartElementDef); paramTag != null; ) {
/*     */       
/* 354 */       if (paramTag.getName().equals("CHARTDESCRIPTOR")) {
/* 355 */         ChartDescriptor chartDescriptor = new ChartDescriptor();
/* 356 */         chartElementDef.setChartDescriptor(chartDescriptor);
/*     */         String str;
/* 358 */         if ((str = paramTag.get("ValueFormat")) != null) {
/* 359 */           chartDescriptor.setValueFormat(new DecimalFormat(str));
/*     */         }
/*     */         
/* 362 */         if ((str = paramTag.get("YAxisFormat")) != null) {
/* 363 */           chartDescriptor.setYAxisFormat(new DecimalFormat(str));
/*     */         }
/*     */         
/* 366 */         if ((str = paramTag.get("SecondaryYAxisFormat")) != null) {
/* 367 */           chartDescriptor.setSecondaryYAxisFormat(new DecimalFormat(str));
/*     */         }
/*     */         
/* 370 */         if ((str = paramTag.get("LineWidth")) != null) {
/* 371 */           chartDescriptor.setLineChartLineWidth(Float.valueOf(str).floatValue());
/*     */         }
/*     */         
/* 374 */         if ((str = paramTag.get("PointSize")) != null) {
/* 375 */           chartDescriptor.setPointSize(Float.valueOf(str).floatValue());
/*     */         }
/*     */         
/* 378 */         if ((str = paramTag.get("XLabelRotation")) != null) {
/* 379 */           chartDescriptor.setXLabelRotation(Double.valueOf(str).doubleValue());
/*     */         }
/*     */         
/* 382 */         if ((str = paramTag.get("BarBorder")) != null) {
/* 383 */           chartDescriptor.setBarBorder(Boolean.valueOf(str).booleanValue());
/*     */         }
/*     */         
/* 386 */         if ((str = paramTag.get("PointStyle")) != null) {
/* 387 */           String[] arrayOfString = Util.split(str, ',');
/* 388 */           for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 389 */             chartDescriptor.setPointStyle(b1, Integer.parseInt(arrayOfString[b1]));
/*     */           }
/*     */         } 
/*     */         
/* 393 */         if ((str = paramTag.get("FirstDatasetOfSecondaryAxis")) != null) {
/* 394 */           chartDescriptor.setFirstDatasetOfSecondaryAxis(Integer.parseInt(str));
/*     */         }
/*     */         
/* 397 */         if ((str = paramTag.get("VerticalGridStyle")) != null) {
/* 398 */           chartDescriptor.setVerticalGridStyle(Integer.parseInt(str));
/*     */         }
/*     */         
/* 401 */         if ((str = paramTag.get("LogarithmicYScale")) != null) {
/* 402 */           chartDescriptor.setLogarithmicYScale(Boolean.valueOf(str).booleanValue());
/*     */         }
/*     */         
/* 405 */         if ((str = paramTag.get("SecondaryLogarithmicYScale")) != null) {
/* 406 */           chartDescriptor.setSecondaryLogarithmicYScale(Boolean.valueOf(str).booleanValue());
/*     */         }
/*     */ 
/*     */         
/* 410 */         if ((str = paramTag.get("SecondaryMaximum")) != null) {
/* 411 */           chartDescriptor.setSecondaryMaximum(Double.valueOf(str));
/*     */         }
/*     */         
/* 414 */         if ((str = paramTag.get("SecondaryMinimum")) != null) {
/* 415 */           chartDescriptor.setSecondaryMinimum(Double.valueOf(str));
/*     */         }
/*     */         
/* 418 */         if ((str = paramTag.get("SecondaryIncrement")) != null) {
/* 419 */           chartDescriptor.setSecondaryIncrement(Double.valueOf(str));
/*     */         }
/*     */         
/* 422 */         if ((str = paramTag.get("SecondaryMinorIncrement")) != null) {
/* 423 */           chartDescriptor.setSecondaryMinorIncrement(Double.valueOf(str));
/*     */         }
/*     */         
/* 426 */         if ((str = paramTag.get("SecondaryYTitle")) != null)
/* 427 */           chartDescriptor.setSecondaryYTitle(str); 
/*     */         do {
/*     */         
/* 430 */         } while ((paramTag = (XMLTokenStream.Tag)this.xml.getToken()) != null && !paramTag.getName().equals("/CHARTDESCRIPTOR"));
/*     */ 
/*     */         
/*     */         paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*     */       } 
/*     */ 
/*     */       
/*     */       break;
/*     */     } 
/*     */     
/* 440 */     if (paramTag.getName().equals("CHART")) {
/* 441 */       defaultChartLens.setDatasetCount(Integer.parseInt(paramTag.get("Datasets")));
/* 442 */       defaultChartLens.setDatasetSize(Integer.parseInt(paramTag.get("Size")));
/*     */       String str;
/* 444 */       if ((str = paramTag.get("Style")) != null) {
/* 445 */         defaultChartLens.setStyle(Integer.parseInt(str));
/*     */       }
/*     */       
/* 448 */       if ((str = paramTag.get("Maximum")) != null) {
/* 449 */         defaultChartLens.setMaximum(Double.valueOf(str));
/*     */       }
/*     */       
/* 452 */       if ((str = paramTag.get("Minimum")) != null) {
/* 453 */         defaultChartLens.setMinimum(Double.valueOf(str));
/*     */       }
/*     */       
/* 456 */       if ((str = paramTag.get("Increment")) != null) {
/* 457 */         defaultChartLens.setIncrement(Double.valueOf(str));
/*     */       }
/*     */       
/* 460 */       if ((str = paramTag.get("MinorIncrement")) != null) {
/* 461 */         defaultChartLens.setMinorIncrement(Double.valueOf(str));
/*     */       }
/*     */       
/* 464 */       if ((str = paramTag.get("Gap")) != null) {
/* 465 */         defaultChartLens.setGap(Integer.parseInt(str));
/*     */       }
/*     */       
/* 468 */       if ((str = paramTag.get("XTitle")) != null) {
/* 469 */         defaultChartLens.setXTitle(str);
/*     */       }
/*     */       
/* 472 */       if ((str = paramTag.get("YTitle")) != null) {
/* 473 */         defaultChartLens.setYTitle(str);
/*     */       }
/*     */       
/* 476 */       if ((str = paramTag.get("TitleFont")) != null) {
/* 477 */         defaultChartLens.setTitleFont(StyleFont.decode(str));
/*     */       }
/*     */       
/* 480 */       if ((str = paramTag.get("GridStyle")) != null) {
/* 481 */         defaultChartLens.setGridStyle(Integer.parseInt(str));
/*     */       }
/*     */       
/* 484 */       if ((str = paramTag.get("BorderStyle")) != null) {
/* 485 */         defaultChartLens.setBorderStyle(Integer.parseInt(str));
/*     */       }
/*     */       
/* 488 */       if ((str = paramTag.get("ShowValue")) != null) {
/* 489 */         defaultChartLens.setShowValue(Boolean.valueOf(str).booleanValue());
/*     */       }
/*     */ 
/*     */       
/* 493 */       if ((str = paramTag.get("Precision")) != null) {
/* 494 */         defaultChartLens.setPrecision(Integer.parseInt(str));
/*     */       }
/*     */       
/* 497 */       if ((str = paramTag.get("LegendPosition")) != null) {
/* 498 */         defaultChartLens.setLegendPosition(Integer.parseInt(str));
/*     */       }
/*     */       
/* 501 */       if ((str = paramTag.get("BlackWhite")) != null) {
/* 502 */         defaultChartLens.setBlackWhite(Boolean.valueOf(str).booleanValue());
/*     */       }
/*     */     } 
/*     */     
/* 506 */     chartElementDef.setChart(defaultChartLens);
/*     */     
/* 508 */     StringTokenizer stringTokenizer = new StringTokenizer((String)this.xml.getToken(), "\n\r");
/*     */ 
/*     */ 
/*     */     
/* 512 */     if (stringTokenizer.hasMoreTokens()) {
/* 513 */       String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
/* 514 */       for (byte b1 = 0; b1 < arrayOfString.length && b1 < defaultChartLens.getDatasetCount(); b1++) {
/* 515 */         defaultChartLens.setDatasetLabel(b1, arrayOfString[b1]);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 520 */     if (stringTokenizer.hasMoreTokens()) {
/* 521 */       String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
/* 522 */       for (byte b1 = 0; b1 < arrayOfString.length && b1 < defaultChartLens.getDatasetSize(); b1++) {
/* 523 */         defaultChartLens.setLabel(b1, arrayOfString[b1]);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 528 */     for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
/* 529 */       String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
/*     */       
/* 531 */       for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 532 */         if (arrayOfString[b1].length() > 0) {
/* 533 */           defaultChartLens.setData(b, b1, Double.valueOf(arrayOfString[b1]));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 538 */     return chartElementDef;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\ReportParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */