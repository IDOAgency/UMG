package inetsoft.report.io;

import inetsoft.report.StyleSheet;
import java.io.IOException;

public interface Parser {
  Object read() throws IOException;
  
  StyleSheet createSheet(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\Parser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */