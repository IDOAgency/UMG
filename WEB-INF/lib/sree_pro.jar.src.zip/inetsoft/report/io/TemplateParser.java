/*      */ package inetsoft.report.io;
/*      */ 
/*      */ import inetsoft.report.ChartDescriptor;
/*      */ import inetsoft.report.FixedContainer;
/*      */ import inetsoft.report.Margin;
/*      */ import inetsoft.report.PageArea;
/*      */ import inetsoft.report.PainterElement;
/*      */ import inetsoft.report.Position;
/*      */ import inetsoft.report.ReportElement;
/*      */ import inetsoft.report.ReportEnv;
/*      */ import inetsoft.report.SectionBand;
/*      */ import inetsoft.report.SectionLens;
/*      */ import inetsoft.report.Size;
/*      */ import inetsoft.report.StyleFont;
/*      */ import inetsoft.report.StyleSheet;
/*      */ import inetsoft.report.TOC;
/*      */ import inetsoft.report.XStyleSheet;
/*      */ import inetsoft.report.internal.AreaBreakElementDef;
/*      */ import inetsoft.report.internal.BaseElement;
/*      */ import inetsoft.report.internal.ButtonElementDef;
/*      */ import inetsoft.report.internal.ChartXElement;
/*      */ import inetsoft.report.internal.CheckBoxElementDef;
/*      */ import inetsoft.report.internal.ChoiceElementDef;
/*      */ import inetsoft.report.internal.CompositeElementDef;
/*      */ import inetsoft.report.internal.CondPageBreakElementDef;
/*      */ import inetsoft.report.internal.DatasetAttr;
/*      */ import inetsoft.report.internal.EmptyContainer;
/*      */ import inetsoft.report.internal.EmptyPainter;
/*      */ import inetsoft.report.internal.Encoder;
/*      */ import inetsoft.report.internal.FilterAttr;
/*      */ import inetsoft.report.internal.FormXElement;
/*      */ import inetsoft.report.internal.HeadingElementDef;
/*      */ import inetsoft.report.internal.ImageButtonElementDef;
/*      */ import inetsoft.report.internal.ImageLocation;
/*      */ import inetsoft.report.internal.ImageXElement;
/*      */ import inetsoft.report.internal.NewlineElementDef;
/*      */ import inetsoft.report.internal.PageBreakElementDef;
/*      */ import inetsoft.report.internal.PageLayoutElementDef;
/*      */ import inetsoft.report.internal.PainterElementDef;
/*      */ import inetsoft.report.internal.RadioButtonElementDef;
/*      */ import inetsoft.report.internal.SectionXElement;
/*      */ import inetsoft.report.internal.SeparatorElementDef;
/*      */ import inetsoft.report.internal.SpaceElementDef;
/*      */ import inetsoft.report.internal.TOCElementDef;
/*      */ import inetsoft.report.internal.TabElementDef;
/*      */ import inetsoft.report.internal.TabSupport;
/*      */ import inetsoft.report.internal.TableXElement;
/*      */ import inetsoft.report.internal.TextAreaElementDef;
/*      */ import inetsoft.report.internal.TextBoxElementDef;
/*      */ import inetsoft.report.internal.TextElementDef;
/*      */ import inetsoft.report.internal.TextFieldElementDef;
/*      */ import inetsoft.report.internal.Util;
/*      */ import inetsoft.report.internal.XMLException;
/*      */ import inetsoft.report.internal.XMLTokenStream;
/*      */ import inetsoft.report.lens.AttributeChartLens;
/*      */ import inetsoft.report.lens.AttributeFormLens;
/*      */ import inetsoft.report.lens.DefaultFormLens;
/*      */ import inetsoft.report.lens.DefaultHeadingLens;
/*      */ import inetsoft.report.lens.DefaultSectionLens;
/*      */ import inetsoft.report.lens.DefaultTableLens;
/*      */ import inetsoft.report.lens.DefaultTextLens;
/*      */ import inetsoft.report.painter.BulletPainter;
/*      */ import inetsoft.report.painter.ImagePainter;
/*      */ import inetsoft.report.style.TableStyle;
/*      */ import inetsoft.report.style.XTableStyle;
/*      */ import java.awt.Color;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.Hashtable;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TemplateParser
/*      */   implements Parser
/*      */ {
/*      */   protected XMLTokenStream xml;
/*      */   Hashtable stylemap;
/*      */   protected XStyleSheet xsheet;
/*      */   protected StyleSheet sheet;
/*      */   
/*      */   public TemplateParser(InputStream paramInputStream) {
/* 1786 */     this.stylemap = new Hashtable();
/*      */     this.xml = new XMLTokenStream(paramInputStream);
/*      */   }
/*      */   
/*      */   public StyleSheet createSheet(String paramString) {
/*      */     this.sheet = this.xsheet = new XStyleSheet();
/*      */     if (paramString == null) {
/*      */       try {
/*      */         paramString = ReportEnv.getProperty("user.dir");
/*      */       } catch (Exception exception) {}
/*      */       if (paramString == null)
/*      */         paramString = "."; 
/*      */     } 
/*      */     this.xsheet.setDirectory(paramString);
/*      */     return this.xsheet;
/*      */   }
/*      */   
/*      */   public Object read() throws IOException {
/*      */     try {
/*      */       Object object;
/*      */       while ((object = this.xml.getToken()) != null) {
/*      */         if (object instanceof XMLTokenStream.Tag) {
/*      */           XMLTokenStream.Tag tag = (XMLTokenStream.Tag)object;
/*      */           if (tag.getName().equals("REPORT")) {
/*      */             Margin margin = new Margin(0.0D, 0.0D, 0.0D, 0.0D);
/*      */             try {
/*      */               margin.top = Double.valueOf(tag.get("Top")).doubleValue();
/*      */               margin.left = Double.valueOf(tag.get("Left")).doubleValue();
/*      */               margin.bottom = Double.valueOf(tag.get("Bottom")).doubleValue();
/*      */               margin.right = Double.valueOf(tag.get("Right")).doubleValue();
/*      */               this.sheet.setMargin(margin);
/*      */             } catch (NullPointerException nullPointerException) {}
/*      */             try {
/*      */               this.sheet.setHeaderFromEdge(Double.valueOf(tag.get("HeaderFromEdge")).doubleValue());
/*      */               this.sheet.setFooterFromEdge(Double.valueOf(tag.get("FooterFromEdge")).doubleValue());
/*      */             } catch (NullPointerException nullPointerException) {}
/*      */             String str;
/*      */             if ((str = tag.get("HorizontalWrap")) != null)
/*      */               this.sheet.setHorizontalWrap(str.equalsIgnoreCase("true")); 
/*      */             if ((str = tag.get("TabStops")) != null) {
/*      */               String[] arrayOfString = Util.split(str, ',');
/*      */               double[] arrayOfDouble = new double[arrayOfString.length];
/*      */               for (byte b = 0; b < arrayOfDouble.length; b++) {
/*      */                 try {
/*      */                   arrayOfDouble[b] = Double.valueOf(arrayOfString[b]).doubleValue();
/*      */                 } catch (Exception exception) {
/*      */                   exception.printStackTrace();
/*      */                   arrayOfDouble[b] = b ? arrayOfDouble[b - true] : 0.0D;
/*      */                 } 
/*      */               } 
/*      */               this.sheet.setCurrentTabStops(arrayOfDouble);
/*      */             } 
/*      */             continue;
/*      */           } 
/*      */           if (tag.getName().equals("BACKGROUND")) {
/*      */             readBackground(tag);
/*      */             continue;
/*      */           } 
/*      */           if (tag.getName().equals("ONPAGEBREAK")) {
/*      */             Object object1 = this.xml.getToken();
/*      */             for (; !object1.equals("/ONPAGEBREAK"); object1 = this.xml.getToken())
/*      */               this.sheet.setOnPageBreak((String)object1); 
/*      */             continue;
/*      */           } 
/*      */           if (tag.getName().equals("ONLOAD")) {
/*      */             Object object1 = this.xml.getToken();
/*      */             for (; !object1.equals("/ONLOAD"); object1 = this.xml.getToken())
/*      */               this.sheet.setOnLoad((String)object1); 
/*      */             continue;
/*      */           } 
/*      */           if (tag.getName().equals("PROPERTY")) {
/*      */             String str;
/*      */             for (byte b = 0; (str = tag.get("Name" + b)) != null; b++)
/*      */               this.sheet.setProperty(str, tag.get("Value" + b)); 
/*      */             continue;
/*      */           } 
/*      */           if (tag.getName().equals("HEADER")) {
/*      */             String str1 = tag.get("ID");
/*      */             String str2 = tag.get("Header");
/*      */             str2 = (str2 != null && str2.equals("false")) ? "footer." : "header.";
/*      */             return (str1 == null) ? Integer.valueOf(tag.get("Type")) : (str2 + str1);
/*      */           } 
/*      */           if (tag.getName().equals("/HEADER"))
/*      */             return new Integer(0); 
/*      */           if (tag.getName().equals("PAGELAYOUT"))
/*      */             return readElementAreas(tag); 
/*      */           if (tag.getName().equals("SECTIONELEMENT"))
/*      */             return readSection(tag); 
/*      */           if (tag.getName().equals("TEXTELEMENT"))
/*      */             return readText(tag); 
/*      */           if (tag.getName().equals("HEADINGELEMENT"))
/*      */             return readHeading(tag); 
/*      */           if (tag.getName().equals("TABLEELEMENT"))
/*      */             return readTable(tag); 
/*      */           if (tag.getName().equals("FORMELEMENT"))
/*      */             return readForm(tag); 
/*      */           if (tag.getName().equals("IMAGEELEMENT"))
/*      */             return readImage(tag); 
/*      */           if (tag.getName().equals("PAINTERELEMENT"))
/*      */             return readPainter(tag); 
/*      */           if (tag.getName().equals("CHARTELEMENT"))
/*      */             return readChart(tag); 
/*      */           if (tag.getName().equals("TEXTBOXELEMENT"))
/*      */             return readTextBox(tag); 
/*      */           if (tag.getName().equals("TABELEMENT"))
/*      */             return readTab(tag); 
/*      */           if (tag.getName().equals("NEWLINEELEMENT"))
/*      */             return readNewline(tag); 
/*      */           if (tag.getName().equals("AREABREAKELEMENT"))
/*      */             return readAreaBreak(tag); 
/*      */           if (tag.getName().equals("PAGEBREAKELEMENT"))
/*      */             return readPageBreak(tag); 
/*      */           if (tag.getName().equals("PAGELAYOUTELEMENT"))
/*      */             return readPageLayout(tag); 
/*      */           if (tag.getName().equals("CONDPAGEBREAKELEMENT"))
/*      */             return readCondPageBreak(tag); 
/*      */           if (tag.getName().equals("SPACEELEMENT"))
/*      */             return readSpace(tag); 
/*      */           if (tag.getName().equals("SEPARATORELEMENT"))
/*      */             return readSeparator(tag); 
/*      */           if (tag.getName().equals("TOCELEMENT"))
/*      */             return readTOC(tag); 
/*      */           if (tag.getName().equals("COMPOSITEELEMENT"))
/*      */             return readComposite(tag); 
/*      */           if (tag.getName().equals("BUTTONELEMENT"))
/*      */             return readButton(tag); 
/*      */           if (tag.getName().equals("IMAGEBUTTONELEMENT"))
/*      */             return readImageButton(tag); 
/*      */           if (tag.getName().equals("CHECKBOXELEMENT"))
/*      */             return readCheckBox(tag); 
/*      */           if (tag.getName().equals("RADIOBUTTONELEMENT"))
/*      */             return readRadioButton(tag); 
/*      */           if (tag.getName().equals("CHOICEELEMENT"))
/*      */             return readChoice(tag); 
/*      */           if (tag.getName().equals("TEXTFIELDELEMENT"))
/*      */             return readTextField(tag); 
/*      */           if (tag.getName().equals("TEXTAREAELEMENT"))
/*      */             return readTextArea(tag); 
/*      */           if (tag.getName().equals("TABLE-STYLE")) {
/*      */             XTableStyle xTableStyle = new XTableStyle(new DefaultTableLens(1, 1));
/*      */             xTableStyle.parse(this.xml);
/*      */             xTableStyle.setName(tag.get("Name"));
/*      */             this.stylemap.put(xTableStyle.getName(), xTableStyle);
/*      */             return xTableStyle;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       exception.printStackTrace();
/*      */       throw new IOException(exception.toString());
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   
/*      */   protected void readBackground(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     String str;
/*      */     if ((str = paramTag.get("Color")) != null) {
/*      */       this.sheet.setBackground(new Color(Integer.parseInt(str)));
/*      */     } else {
/*      */       if ((str = paramTag.get("Path")) != null) {
/*      */         ImageLocation imageLocation = new ImageLocation(this.xsheet.getDirectory());
/*      */         imageLocation.setPath(str);
/*      */         if ((str = paramTag.get("PathType")) != null)
/*      */           imageLocation.setPathType(Integer.parseInt(str)); 
/*      */         if ((str = paramTag.get("Embedded")) != null)
/*      */           imageLocation.setEmbedded(str.equalsIgnoreCase("true")); 
/*      */         this.sheet.setBackgroundImageLocation(imageLocation);
/*      */       } 
/*      */       while ((paramTag = (XMLTokenStream.Tag)this.xml.getToken()) != null && !paramTag.getName().equals("/BACKGROUND")) {
/*      */         if (paramTag.getName().equals("IMAGE")) {
/*      */           this.sheet.setBackground(readImageData(paramTag));
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected Object readText(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     DefaultTextLens defaultTextLens = new DefaultTextLens();
/*      */     TextElementDef textElementDef = new TextElementDef(this.sheet, defaultTextLens);
/*      */     setElementAttributes(textElementDef, paramTag);
/*      */     setTabAttributes(textElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Justify")) != null)
/*      */       textElementDef.setJustify(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("Orphan")) != null)
/*      */       textElementDef.setOrphanControl(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("TextAdvance")) != null)
/*      */       textElementDef.setTextAdvance(Integer.parseInt(str)); 
/*      */     Object object = readProperties(textElementDef);
/*      */     defaultTextLens.setText((String)object);
/*      */     return textElementDef;
/*      */   }
/*      */   
/*      */   protected Object readHeading(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     DefaultHeadingLens defaultHeadingLens = new DefaultHeadingLens("", 1);
/*      */     HeadingElementDef headingElementDef = new HeadingElementDef(this.sheet, defaultHeadingLens);
/*      */     setElementAttributes(headingElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Justify")) != null)
/*      */       headingElementDef.setJustify(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("Orphan")) != null)
/*      */       headingElementDef.setOrphanControl(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("TextAdvance")) != null)
/*      */       headingElementDef.setTextAdvance(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Level")) != null)
/*      */       headingElementDef.setLevel(Integer.parseInt(str)); 
/*      */     Object object = readProperties(headingElementDef);
/*      */     defaultHeadingLens.setText((String)object);
/*      */     return headingElementDef;
/*      */   }
/*      */   
/*      */   protected Object readTable(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     DefaultTableLens defaultTableLens = new DefaultTableLens(5, 5);
/*      */     TableXElement tableXElement = new TableXElement(this.sheet, defaultTableLens);
/*      */     setElementAttributes(tableXElement, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("TableWidth")) != null)
/*      */       tableXElement.setTableWidth(Double.valueOf(str).doubleValue()); 
/*      */     if ((str = paramTag.get("FixedWidths")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       int[] arrayOfInt = new int[arrayOfString.length];
/*      */       for (byte b = 0; b < arrayOfInt.length; b++)
/*      */         arrayOfInt[b] = Integer.parseInt(arrayOfString[b]); 
/*      */       tableXElement.setFixedWidths(arrayOfInt);
/*      */     } 
/*      */     if ((str = paramTag.get("Layout")) != null)
/*      */       tableXElement.setLayout(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("TableAdvance")) != null)
/*      */       tableXElement.setTableAdvance(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("OrphanControl")) != null)
/*      */       tableXElement.setOrphanControl(str.equalsIgnoreCase("true")); 
/*      */     if ((str = paramTag.get("Padding")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       tableXElement.setPadding(new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
/*      */     } 
/*      */     TableStyle tableStyle = null;
/*      */     if ((str = paramTag.get("Style")) != null)
/*      */       tableXElement.setStyle(tableStyle = getStyle(str)); 
/*      */     if ((str = paramTag.get("EmbedWidth")) != null)
/*      */       tableXElement.setEmbedWidth(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("Embedded")) != null)
/*      */       tableXElement.setEmbedded(Boolean.valueOf(str).booleanValue()); 
/*      */     Vector vector = new Vector();
/*      */     for (paramTag = (XMLTokenStream.Tag)readProperties(tableXElement); paramTag != null; paramTag = (XMLTokenStream.Tag)this.xml.getToken()) {
/*      */       if (paramTag.getName().equals("TABLE")) {
/*      */         defaultTableLens.setRowCount(Integer.parseInt(paramTag.get("Rows")));
/*      */         defaultTableLens.setColCount(Integer.parseInt(paramTag.get("Cols")));
/*      */         defaultTableLens.setHeaderRowCount(Integer.parseInt(paramTag.get("HeaderRow")));
/*      */         defaultTableLens.setHeaderColCount(Integer.parseInt(paramTag.get("HeaderCol")));
/*      */         Object object = this.xml.getToken();
/*      */         if (object instanceof String) {
/*      */           String str1 = (String)object;
/*      */           StringTokenizer stringTokenizer = new StringTokenizer(str1, "\n\r");
/*      */           for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
/*      */             String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
/*      */             for (byte b1 = 0; b1 < arrayOfString.length; b1++)
/*      */               defaultTableLens.setObject(b, b1, arrayOfString[b1]); 
/*      */           } 
/*      */         } else {
/*      */           byte b = -1;
/*      */           byte b1 = 0;
/*      */           paramTag = (XMLTokenStream.Tag)object;
/*      */           for (; !paramTag.getName().equals("/TABLE"); paramTag = (XMLTokenStream.Tag)this.xml.getToken()) {
/*      */             if (paramTag.getName().equals("TR")) {
/*      */               b++;
/*      */               b1 = 0;
/*      */             } else if (paramTag.getName().equals("TD")) {
/*      */               if (object = this.xml.getToken() instanceof String)
/*      */                 defaultTableLens.setObject(b, b1, object.equals("null") ? null : object); 
/*      */               b1++;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         tableXElement.setData(defaultTableLens);
/*      */       } else if (paramTag.getName().equals("STYLE") && tableStyle != null) {
/*      */         tableStyle.setApplyRowBorderColor(Boolean.valueOf(paramTag.get("RowBorderC")).booleanValue());
/*      */         tableStyle.setApplyColBorderColor(Boolean.valueOf(paramTag.get("ColBorderC")).booleanValue());
/*      */         tableStyle.setApplyRowBorder(Boolean.valueOf(paramTag.get("RowBorder")).booleanValue());
/*      */         tableStyle.setApplyColBorder(Boolean.valueOf(paramTag.get("ColBorder")).booleanValue());
/*      */         tableStyle.setApplyInsets(Boolean.valueOf(paramTag.get("Insets")).booleanValue());
/*      */         tableStyle.setApplyAlignment(Boolean.valueOf(paramTag.get("Alignment")).booleanValue());
/*      */         tableStyle.setApplyFont(Boolean.valueOf(paramTag.get("Font")).booleanValue());
/*      */         tableStyle.setApplyLineWrap(Boolean.valueOf(paramTag.get("LineWrap")).booleanValue());
/*      */         tableStyle.setApplyForeground(Boolean.valueOf(paramTag.get("Foreground")).booleanValue());
/*      */         tableStyle.setApplyBackground(Boolean.valueOf(paramTag.get("Background")).booleanValue());
/*      */         tableStyle.setFormatFirstRow(Boolean.valueOf(paramTag.get("FirstRow")).booleanValue());
/*      */         tableStyle.setFormatFirstCol(Boolean.valueOf(paramTag.get("FirstCol")).booleanValue());
/*      */         tableStyle.setFormatLastRow(Boolean.valueOf(paramTag.get("LastRow")).booleanValue());
/*      */         tableStyle.setFormatLastCol(Boolean.valueOf(paramTag.get("LastCol")).booleanValue());
/*      */       } else if (paramTag.getName().equals("ROWGROUP")) {
/*      */         paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*      */         for (; !paramTag.getName().equals("/ROWGROUP"); paramTag = (XMLTokenStream.Tag)this.xml.getToken()) {
/*      */           if (paramTag.getName().equals("ROW")) {
/*      */             int i = Integer.parseInt(paramTag.get("index"));
/*      */             String str1 = paramTag.get("alignment");
/*      */             if (str1 != null)
/*      */               tableXElement.setRowAlignment(i, Integer.parseInt(str1)); 
/*      */             str1 = paramTag.get("linewrap");
/*      */             if (str1 != null)
/*      */               tableXElement.setRowLineWrap(i, str1.equalsIgnoreCase("true")); 
/*      */             tableXElement.setRowFormat(i, paramTag.get("format"), paramTag.get("format_spec"));
/*      */             tableXElement.setRowPresenter(i, paramTag.get("presenter"));
/*      */           } 
/*      */         } 
/*      */       } else if (paramTag.getName().equals("COLGROUP")) {
/*      */         paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*      */         for (; !paramTag.getName().equals("/COLGROUP"); paramTag = (XMLTokenStream.Tag)this.xml.getToken()) {
/*      */           if (paramTag.getName().equals("COL")) {
/*      */             int i = Integer.parseInt(paramTag.get("index"));
/*      */             String str1 = paramTag.get("alignment");
/*      */             if (str1 != null)
/*      */               tableXElement.setColAlignment(i, Integer.parseInt(str1)); 
/*      */             str1 = paramTag.get("linewrap");
/*      */             if (str1 != null)
/*      */               tableXElement.setColLineWrap(i, str1.equalsIgnoreCase("true")); 
/*      */             tableXElement.setColFormat(i, paramTag.get("format"), paramTag.get("format_spec"));
/*      */             tableXElement.setColPresenter(i, paramTag.get("presenter"));
/*      */           } 
/*      */         } 
/*      */       } else if (paramTag.getName().equals("ONCLICKRANGE")) {
/*      */         Point point = new Point(Integer.parseInt(paramTag.get("Col")), Integer.parseInt(paramTag.get("Row")));
/*      */         vector.addElement(point);
/*      */         paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*      */         while (!paramTag.getName().equals("/ONCLICKRANGE"))
/*      */           paramTag = (XMLTokenStream.Tag)this.xml.getToken(); 
/*      */       } else if (paramTag.getName().equals("FILTER")) {
/*      */         tableXElement.setFilter(FilterAttr.parse(paramTag, this.xml));
/*      */       } else if (paramTag.getName().equals("/TABLEELEMENT")) {
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     if (vector.size() > 0) {
/*      */       Point[] arrayOfPoint = new Point[vector.size()];
/*      */       vector.copyInto(arrayOfPoint);
/*      */       tableXElement.setOnClickRange(arrayOfPoint);
/*      */     } 
/*      */     return tableXElement;
/*      */   }
/*      */   
/*      */   protected Object readForm(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     DefaultFormLens defaultFormLens = new DefaultFormLens();
/*      */     FormXElement formXElement = new FormXElement(this.sheet);
/*      */     AttributeFormLens attributeFormLens = (AttributeFormLens)formXElement.getForm();
/*      */     setElementAttributes(formXElement, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("FieldPerRow")) != null)
/*      */       attributeFormLens.setFieldPerRow(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("LabelFont")) != null)
/*      */       attributeFormLens.setLabelFont(StyleFont.decode(str)); 
/*      */     if ((str = paramTag.get("LabelForeground")) != null)
/*      */       attributeFormLens.setLabelForeground(new Color(Integer.parseInt(str))); 
/*      */     if ((str = paramTag.get("LabelBackground")) != null)
/*      */       attributeFormLens.setLabelBackground(new Color(Integer.parseInt(str))); 
/*      */     if ((str = paramTag.get("FieldFont")) != null)
/*      */       attributeFormLens.setFont(StyleFont.decode(str)); 
/*      */     if ((str = paramTag.get("FieldForeground")) != null)
/*      */       attributeFormLens.setForeground(new Color(Integer.parseInt(str))); 
/*      */     if ((str = paramTag.get("FieldBackground")) != null)
/*      */       attributeFormLens.setBackground(new Color(Integer.parseInt(str))); 
/*      */     if ((str = paramTag.get("Underline")) != null)
/*      */       attributeFormLens.setUnderline(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("EmbedWidth")) != null)
/*      */       formXElement.setEmbedWidth(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("Embedded")) != null)
/*      */       formXElement.setEmbedded(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("FixedWidths")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       int[] arrayOfInt = new int[arrayOfString.length];
/*      */       for (byte b = 0; b < arrayOfInt.length; b++)
/*      */         arrayOfInt[b] = Integer.parseInt(arrayOfString[b]); 
/*      */       formXElement.setFixedWidths(arrayOfInt);
/*      */     } 
/*      */     paramTag = (XMLTokenStream.Tag)readProperties(formXElement);
/*      */     if (formXElement.isEmbedded()) {
/*      */       defaultFormLens.setFieldCount(Integer.parseInt(paramTag.get("Fields")));
/*      */       StringTokenizer stringTokenizer = new StringTokenizer((String)this.xml.getToken(), "\n\r");
/*      */       for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
/*      */         String[] arrayOfString = Util.split(stringTokenizer.nextToken(), '|');
/*      */         defaultFormLens.setLabel(b, arrayOfString[0]);
/*      */         defaultFormLens.setField(b, arrayOfString[1]);
/*      */       } 
/*      */       formXElement.setForm(defaultFormLens);
/*      */     } 
/*      */     return formXElement;
/*      */   }
/*      */   
/*      */   protected Object readImage(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     ImageXElement imageXElement = new ImageXElement(this.sheet);
/*      */     setElementAttributes(imageXElement, paramTag);
/*      */     setPainterAttributes(imageXElement, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("PathType")) != null)
/*      */       try {
/*      */         imageXElement.setPathType(Integer.parseInt(str));
/*      */       } catch (Exception exception) {
/*      */         System.err.println(exception);
/*      */       }  
/*      */     if ((str = paramTag.get("Path")) != null)
/*      */       try {
/*      */         imageXElement.setPath(str);
/*      */       } catch (Exception exception) {
/*      */         System.err.println(exception);
/*      */       }  
/*      */     if ((str = paramTag.get("Embedded")) != null)
/*      */       imageXElement.setEmbedded(str.equals("true")); 
/*      */     paramTag = (XMLTokenStream.Tag)readProperties(imageXElement);
/*      */     if (imageXElement.isEmbedded()) {
/*      */       Image image = readImageData(paramTag);
/*      */       imageXElement.setPainter(new ImagePainter(image));
/*      */     } 
/*      */     return imageXElement;
/*      */   }
/*      */   
/*      */   protected Object readPainter(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     PainterElementDef painterElementDef = new PainterElementDef(this.sheet, new EmptyPainter());
/*      */     setElementAttributes(painterElementDef, paramTag);
/*      */     setPainterAttributes(painterElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Painter")) != null && str.equals("bullet"))
/*      */       painterElementDef.setPainter(new BulletPainter()); 
/*      */     readProperties(painterElementDef);
/*      */     return painterElementDef;
/*      */   }
/*      */   
/*      */   protected Object readChart(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     DefaultTableLens defaultTableLens = new DefaultTableLens(5, 5);
/*      */     ChartXElement chartXElement = new ChartXElement(this.sheet);
/*      */     AttributeChartLens attributeChartLens = (AttributeChartLens)chartXElement.getChart();
/*      */     setElementAttributes(chartXElement, paramTag);
/*      */     setPainterAttributes(chartXElement, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Embedded")) != null)
/*      */       chartXElement.setEmbedded(Boolean.valueOf(str).booleanValue()); 
/*      */     for (paramTag = (XMLTokenStream.Tag)readProperties(chartXElement); paramTag != null; paramTag = (XMLTokenStream.Tag)this.xml.getToken()) {
/*      */       if (paramTag.getName().equals("CHARTDESCRIPTOR")) {
/*      */         ChartDescriptor chartDescriptor = new ChartDescriptor();
/*      */         chartXElement.setChartDescriptor(chartDescriptor);
/*      */         if ((str = paramTag.get("ValueFormat")) != null)
/*      */           chartDescriptor.setValueFormat(new DecimalFormat(str)); 
/*      */         if ((str = paramTag.get("YAxisFormat")) != null)
/*      */           chartDescriptor.setYAxisFormat(new DecimalFormat(str)); 
/*      */         if ((str = paramTag.get("SecondaryYAxisFormat")) != null)
/*      */           chartDescriptor.setSecondaryYAxisFormat(new DecimalFormat(str)); 
/*      */         if ((str = paramTag.get("LineWidth")) != null)
/*      */           chartDescriptor.setLineChartLineWidth(Float.valueOf(str).floatValue()); 
/*      */         if ((str = paramTag.get("PointSize")) != null)
/*      */           chartDescriptor.setPointSize(Float.valueOf(str).floatValue()); 
/*      */         if ((str = paramTag.get("XLabelRotation")) != null)
/*      */           chartDescriptor.setXLabelRotation(Double.valueOf(str).doubleValue()); 
/*      */         if ((str = paramTag.get("BarBorder")) != null)
/*      */           chartDescriptor.setBarBorder(Boolean.valueOf(str).booleanValue()); 
/*      */         if ((str = paramTag.get("PointStyle")) != null) {
/*      */           String[] arrayOfString = Util.split(str, ',');
/*      */           for (byte b = 0; b < arrayOfString.length; b++)
/*      */             chartDescriptor.setPointStyle(b, Integer.parseInt(arrayOfString[b])); 
/*      */         } 
/*      */         if ((str = paramTag.get("FirstDatasetOfSecondaryAxis")) != null)
/*      */           chartDescriptor.setFirstDatasetOfSecondaryAxis(Integer.parseInt(str)); 
/*      */         if ((str = paramTag.get("VerticalGridStyle")) != null)
/*      */           chartDescriptor.setVerticalGridStyle(Integer.parseInt(str)); 
/*      */         if ((str = paramTag.get("LogarithmicYScale")) != null)
/*      */           chartDescriptor.setLogarithmicYScale(Boolean.valueOf(str).booleanValue()); 
/*      */         if ((str = paramTag.get("SecondaryLogarithmicYScale")) != null)
/*      */           chartDescriptor.setSecondaryLogarithmicYScale(Boolean.valueOf(str).booleanValue()); 
/*      */         if ((str = paramTag.get("SecondaryMaximum")) != null)
/*      */           chartDescriptor.setSecondaryMaximum(Double.valueOf(str)); 
/*      */         if ((str = paramTag.get("SecondaryMinimum")) != null)
/*      */           chartDescriptor.setSecondaryMinimum(Double.valueOf(str)); 
/*      */         if ((str = paramTag.get("SecondaryIncrement")) != null)
/*      */           chartDescriptor.setSecondaryIncrement(Double.valueOf(str)); 
/*      */         if ((str = paramTag.get("SecondaryMinorIncrement")) != null)
/*      */           chartDescriptor.setSecondaryMinorIncrement(Double.valueOf(str)); 
/*      */         if ((str = paramTag.get("SecondaryYTitle")) != null)
/*      */           chartDescriptor.setSecondaryYTitle(str); 
/*      */         do {
/*      */         
/*      */         } while ((paramTag = (XMLTokenStream.Tag)this.xml.getToken()) != null && !paramTag.getName().equals("/CHARTDESCRIPTOR"));
/*      */       } else if (paramTag.getName().equals("FILTER")) {
/*      */         chartXElement.setDataset((DatasetAttr)FilterAttr.parse(paramTag, this.xml));
/*      */       } else {
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     if (paramTag.getName().equals("CHART")) {
/*      */       defaultTableLens.setRowCount(Integer.parseInt(paramTag.get("Datasets")) + 1);
/*      */       defaultTableLens.setColCount(Integer.parseInt(paramTag.get("Size")) + 1);
/*      */       defaultTableLens.setHeaderRowCount(1);
/*      */       defaultTableLens.setHeaderColCount(1);
/*      */       if ((str = paramTag.get("Style")) != null)
/*      */         attributeChartLens.setStyle(Integer.parseInt(str)); 
/*      */       if ((str = paramTag.get("Styles")) != null) {
/*      */         String[] arrayOfString = Util.split(str, ',');
/*      */         for (byte b = 0; b < arrayOfString.length; b++)
/*      */           attributeChartLens.setStyle(b, Integer.parseInt(arrayOfString[b])); 
/*      */       } 
/*      */       if ((str = paramTag.get("Colors")) != null) {
/*      */         String[] arrayOfString = Util.split(str, ',');
/*      */         for (byte b = 0; b < arrayOfString.length; b++)
/*      */           attributeChartLens.setColor(b, new Color(Integer.parseInt(arrayOfString[b]))); 
/*      */       } 
/*      */       if ((str = paramTag.get("Maximum")) != null)
/*      */         attributeChartLens.setMaximum(Double.valueOf(str)); 
/*      */       if ((str = paramTag.get("Minimum")) != null)
/*      */         attributeChartLens.setMinimum(Double.valueOf(str)); 
/*      */       if ((str = paramTag.get("Increment")) != null)
/*      */         attributeChartLens.setIncrement(Double.valueOf(str)); 
/*      */       if ((str = paramTag.get("MinorIncrement")) != null)
/*      */         attributeChartLens.setMinorIncrement(Double.valueOf(str)); 
/*      */       if ((str = paramTag.get("Gap")) != null)
/*      */         attributeChartLens.setGap(Integer.parseInt(str)); 
/*      */       if ((str = paramTag.get("XTitle")) != null)
/*      */         attributeChartLens.setXTitle(str); 
/*      */       if ((str = paramTag.get("YTitle")) != null)
/*      */         attributeChartLens.setYTitle(str); 
/*      */       if ((str = paramTag.get("TitleFont")) != null)
/*      */         attributeChartLens.setTitleFont(StyleFont.decode(str)); 
/*      */       if ((str = paramTag.get("GridStyle")) != null)
/*      */         attributeChartLens.setGridStyle(Integer.parseInt(str)); 
/*      */       if ((str = paramTag.get("BorderStyle")) != null)
/*      */         attributeChartLens.setBorderStyle(Integer.parseInt(str)); 
/*      */       if ((str = paramTag.get("ShowValue")) != null)
/*      */         attributeChartLens.setShowValue(Boolean.valueOf(str).booleanValue()); 
/*      */       if ((str = paramTag.get("Precision")) != null)
/*      */         attributeChartLens.setPrecision(Integer.parseInt(str)); 
/*      */       if ((str = paramTag.get("LegendPosition")) != null)
/*      */         attributeChartLens.setLegendPosition(Integer.parseInt(str)); 
/*      */       if ((str = paramTag.get("BlackWhite")) != null)
/*      */         attributeChartLens.setBlackWhite(Boolean.valueOf(str).booleanValue()); 
/*      */     } 
/*      */     chartXElement.setChart(attributeChartLens);
/*      */     String[] arrayOfString1 = Util.split((String)this.xml.getToken(), "\n\r");
/*      */     String[] arrayOfString2 = Util.split(arrayOfString1[0], '|');
/*      */     for (byte b1 = 0; b1 < arrayOfString2.length && b1 < defaultTableLens.getRowCount() - 1; b1++)
/*      */       defaultTableLens.setObject(b1 + true, 0, arrayOfString2[b1]); 
/*      */     arrayOfString2 = Util.split(arrayOfString1[1], '|');
/*      */     for (byte b2 = 0; b2 < arrayOfString2.length && b2 < defaultTableLens.getColCount() - 1; b2++)
/*      */       defaultTableLens.setObject(0, b2 + true, arrayOfString2[b2]); 
/*      */     for (byte b3 = 0, b4 = 2; b4 < arrayOfString1.length; b3++, b4++) {
/*      */       arrayOfString2 = Util.split(arrayOfString1[b4], '|');
/*      */       for (byte b = 0; b < arrayOfString2.length; b++)
/*      */         defaultTableLens.setObject(b3 + true, b + true, arrayOfString2[b]); 
/*      */     } 
/*      */     defaultTableLens.setHeaderRowCount(1);
/*      */     defaultTableLens.setHeaderColCount(1);
/*      */     chartXElement.setData(defaultTableLens);
/*      */     return chartXElement;
/*      */   }
/*      */   
/*      */   protected Object readTextBox(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     DefaultTextLens defaultTextLens = new DefaultTextLens();
/*      */     TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this.sheet, defaultTextLens);
/*      */     setElementAttributes(textBoxElementDef, paramTag);
/*      */     setPainterAttributes(textBoxElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Border")) != null)
/*      */       textBoxElementDef.setBorder(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Shape")) != null)
/*      */       textBoxElementDef.setShape(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Justify")) != null)
/*      */       textBoxElementDef.setJustify(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("TextAlignment")) != null)
/*      */       textBoxElementDef.setTextAlignment(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Padding")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       textBoxElementDef.setPadding(new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
/*      */     } 
/*      */     if ((str = paramTag.get("Borders")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       textBoxElementDef.setBorders(new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
/*      */     } 
/*      */     Object object = readProperties(textBoxElementDef);
/*      */     defaultTextLens.setText((String)object);
/*      */     return textBoxElementDef;
/*      */   }
/*      */   
/*      */   protected Object readTab(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     TabElementDef tabElementDef = new TabElementDef(this.sheet, 0);
/*      */     setElementAttributes(tabElementDef, paramTag);
/*      */     setTabAttributes(tabElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("RightTab")) != null)
/*      */       tabElementDef.setRightTab(str.equalsIgnoreCase("true")); 
/*      */     readProperties(tabElementDef);
/*      */     return tabElementDef;
/*      */   }
/*      */   
/*      */   protected void setTabAttributes(TabSupport paramTabSupport, XMLTokenStream.Tag paramTag) {
/*      */     String str;
/*      */     if ((str = paramTag.get("FillStyle")) != null)
/*      */       paramTabSupport.setFillStyle(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("TabStops")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       double[] arrayOfDouble = new double[arrayOfString.length];
/*      */       for (byte b = 0; b < arrayOfDouble.length; b++) {
/*      */         try {
/*      */           arrayOfDouble[b] = Double.valueOf(arrayOfString[b]).doubleValue();
/*      */         } catch (Exception exception) {
/*      */           exception.printStackTrace();
/*      */           arrayOfDouble[b] = b ? arrayOfDouble[b - true] : 0.0D;
/*      */         } 
/*      */       } 
/*      */       paramTabSupport.setTabStops(arrayOfDouble);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected Object readNewline(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     NewlineElementDef newlineElementDef = new NewlineElementDef(this.sheet, 1, false);
/*      */     setElementAttributes(newlineElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Count")) != null)
/*      */       newlineElementDef.setCount(Integer.parseInt(str)); 
/*      */     return newlineElementDef;
/*      */   }
/*      */   
/*      */   protected Object readAreaBreak(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     AreaBreakElementDef areaBreakElementDef = new AreaBreakElementDef(this.sheet);
/*      */     setElementAttributes(areaBreakElementDef, paramTag);
/*      */     return areaBreakElementDef;
/*      */   }
/*      */   
/*      */   protected Object readPageBreak(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     PageBreakElementDef pageBreakElementDef = new PageBreakElementDef(this.sheet);
/*      */     setElementAttributes(pageBreakElementDef, paramTag);
/*      */     return pageBreakElementDef;
/*      */   }
/*      */   
/*      */   protected Object readSection(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     SectionXElement sectionXElement = new SectionXElement(this.sheet, null);
/*      */     setElementAttributes(sectionXElement, paramTag);
/*      */     paramTag = (XMLTokenStream.Tag)readProperties(sectionXElement);
/*      */     if (paramTag.getName().equals("FILTER")) {
/*      */       sectionXElement.setFilter(FilterAttr.parse(paramTag, this.xml));
/*      */       paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*      */     } 
/*      */     sectionXElement.setSection(readSectionLens(paramTag));
/*      */     return sectionXElement;
/*      */   }
/*      */   
/*      */   protected SectionLens readSectionLens(XMLTokenStream.Tag paramTag) {
/*      */     if (!paramTag.getName().equals("SECTION"))
/*      */       return null; 
/*      */     DefaultSectionLens defaultSectionLens = new DefaultSectionLens();
/*      */     Object object = null;
/*      */     try {
/*      */       while ((object = this.xml.getToken()) != null && object instanceof XMLTokenStream.Tag) {
/*      */         paramTag = (XMLTokenStream.Tag)object;
/*      */         if (paramTag.getName().equals("/SECTION"))
/*      */           break; 
/*      */         if (paramTag.getName().equals("SECTIONHEADER")) {
/*      */           defaultSectionLens.setSectionHeader(readSectionBand((XMLTokenStream.Tag)this.xml.getToken()));
/*      */           continue;
/*      */         } 
/*      */         if (paramTag.getName().equals("SECTIONCONTENT")) {
/*      */           paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*      */           if (paramTag.getName().equals("SECTION")) {
/*      */             defaultSectionLens.setSectionContent(readSectionLens(paramTag));
/*      */             continue;
/*      */           } 
/*      */           if (paramTag.getName().equals("SECTIONBAND"))
/*      */             defaultSectionLens.setSectionContent(readSectionBand(paramTag)); 
/*      */           continue;
/*      */         } 
/*      */         if (paramTag.getName().equals("SECTIONFOOTER"))
/*      */           defaultSectionLens.setSectionFooter(readSectionBand((XMLTokenStream.Tag)this.xml.getToken())); 
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       exception.printStackTrace();
/*      */     } 
/*      */     return defaultSectionLens;
/*      */   }
/*      */   
/*      */   protected SectionBand readSectionBand(XMLTokenStream.Tag paramTag) {
/*      */     if (!paramTag.getName().equals("SECTIONBAND"))
/*      */       return null; 
/*      */     SectionBand sectionBand = new SectionBand(this.sheet);
/*      */     String str;
/*      */     if ((str = paramTag.get("Height")) != null)
/*      */       sectionBand.setHeight(Float.valueOf(str).floatValue()); 
/*      */     if ((str = paramTag.get("Visible")) != null)
/*      */       sectionBand.setVisible(str.equalsIgnoreCase("true")); 
/*      */     if ((str = paramTag.get("ShrinkToFit")) != null)
/*      */       sectionBand.setShrinkToFit(str.equalsIgnoreCase("true")); 
/*      */     if ((str = paramTag.get("PageBefore")) != null)
/*      */       sectionBand.setPageBefore(str.equalsIgnoreCase("true")); 
/*      */     if ((str = paramTag.get("PageAfter")) != null)
/*      */       sectionBand.setPageAfter(str.equalsIgnoreCase("true")); 
/*      */     if ((str = paramTag.get("TopBorder")) != null)
/*      */       sectionBand.setTopBorder(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("LeftBorder")) != null)
/*      */       sectionBand.setLeftBorder(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("BottomBorder")) != null)
/*      */       sectionBand.setBottomBorder(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("RightBorder")) != null)
/*      */       sectionBand.setRightBorder(Integer.parseInt(str)); 
/*      */     boolean bool = ((str = paramTag.get("Elements")) == null) ? 0 : Integer.parseInt(str);
/*      */     try {
/*      */       byte b = 0;
/*      */       ReportElement reportElement;
/*      */       while (b < bool && (reportElement = (ReportElement)read()) != null) {
/*      */         do {
/*      */         
/*      */         } while ((paramTag = (XMLTokenStream.Tag)this.xml.getToken()) != null && !paramTag.getName().equals("FIELDPROPERTY"));
/*      */         Rectangle rectangle = new Rectangle();
/*      */         rectangle.x = Integer.parseInt(paramTag.get("X"));
/*      */         rectangle.y = Integer.parseInt(paramTag.get("Y"));
/*      */         rectangle.width = Integer.parseInt(paramTag.get("Width"));
/*      */         rectangle.height = Integer.parseInt(paramTag.get("Height"));
/*      */         if ((str = paramTag.get("Binding")) != null)
/*      */           sectionBand.setBinding(reportElement.getID(), str); 
/*      */         sectionBand.addElement(reportElement, rectangle);
/*      */         paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*      */         b++;
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       exception.printStackTrace();
/*      */     } 
/*      */     return sectionBand;
/*      */   }
/*      */   
/*      */   protected Object readPageLayout(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     PageLayoutElementDef pageLayoutElementDef = new PageLayoutElementDef(this.sheet, null);
/*      */     setElementAttributes(pageLayoutElementDef, paramTag);
/*      */     int i = Integer.parseInt(paramTag.get("Count"));
/*      */     PageArea[] arrayOfPageArea = new PageArea[i];
/*      */     for (byte b = 0; b < i; b++)
/*      */       arrayOfPageArea[b] = readPageArea((XMLTokenStream.Tag)this.xml.getToken()); 
/*      */     pageLayoutElementDef.setPageAreas(arrayOfPageArea);
/*      */     return pageLayoutElementDef;
/*      */   }
/*      */   
/*      */   protected PageArea[] readElementAreas(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     String str = paramTag.get("ID");
/*      */     int i = Integer.parseInt(paramTag.get("Count"));
/*      */     PageArea[] arrayOfPageArea = new PageArea[i];
/*      */     for (byte b = 0; b < i; b++)
/*      */       arrayOfPageArea[b] = readPageArea((XMLTokenStream.Tag)this.xml.getToken()); 
/*      */     this.sheet.setPageAreas(arrayOfPageArea, str);
/*      */     return arrayOfPageArea;
/*      */   }
/*      */   
/*      */   protected PageArea readPageArea(XMLTokenStream.Tag paramTag) {
/*      */     try {
/*      */       while (paramTag != null && !paramTag.getName().equals("AREA"))
/*      */         paramTag = (XMLTokenStream.Tag)this.xml.getToken(); 
/*      */     } catch (Exception exception) {
/*      */       exception.printStackTrace();
/*      */     } 
/*      */     PageArea pageArea = new PageArea(0.0D, 0.0D, 0.0D, 0.0D);
/*      */     pageArea.x = Double.valueOf(paramTag.get("X")).doubleValue();
/*      */     pageArea.y = Double.valueOf(paramTag.get("Y")).doubleValue();
/*      */     pageArea.width = Double.valueOf(paramTag.get("Width")).doubleValue();
/*      */     pageArea.height = Double.valueOf(paramTag.get("Height")).doubleValue();
/*      */     pageArea.setRelative(Boolean.valueOf(paramTag.get("Relative")).booleanValue());
/*      */     pageArea.setBorder(Integer.parseInt(paramTag.get("Border")));
/*      */     String str = paramTag.get("Flow");
/*      */     if (str != null)
/*      */       pageArea.setFlow(Boolean.valueOf(str).booleanValue()); 
/*      */     str = paramTag.get("Repeat");
/*      */     if (str != null)
/*      */       pageArea.setRepeat(Boolean.valueOf(str).booleanValue()); 
/*      */     str = paramTag.get("BorderColor");
/*      */     if (str != null)
/*      */       pageArea.setBorderColor(new Color(Integer.parseInt(str))); 
/*      */     if ((str = paramTag.get("Insets")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       pageArea.setInsets(new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
/*      */     } 
/*      */     boolean bool = ((str = paramTag.get("Elements")) == null) ? 0 : Integer.parseInt(str);
/*      */     try {
/*      */       FixedContainer fixedContainer = new FixedContainer(this.sheet);
/*      */       byte b = 0;
/*      */       ReportElement reportElement;
/*      */       while (b < bool && (reportElement = (ReportElement)read()) != null) {
/*      */         do {
/*      */         
/*      */         } while ((paramTag = (XMLTokenStream.Tag)this.xml.getToken()) != null && !paramTag.getName().equals("BOUNDS"));
/*      */         Rectangle rectangle = new Rectangle();
/*      */         rectangle.x = Integer.parseInt(paramTag.get("X"));
/*      */         rectangle.y = Integer.parseInt(paramTag.get("Y"));
/*      */         rectangle.width = Integer.parseInt(paramTag.get("Width"));
/*      */         rectangle.height = Integer.parseInt(paramTag.get("Height"));
/*      */         fixedContainer.addElement(reportElement, rectangle);
/*      */         paramTag = (XMLTokenStream.Tag)this.xml.getToken();
/*      */         b++;
/*      */       } 
/*      */       if (fixedContainer.getElementCount() > 0)
/*      */         pageArea.setElements(fixedContainer); 
/*      */     } catch (Exception exception) {
/*      */       exception.printStackTrace();
/*      */     } 
/*      */     return pageArea;
/*      */   }
/*      */   
/*      */   protected Object readCondPageBreak(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     CondPageBreakElementDef condPageBreakElementDef = new CondPageBreakElementDef(this.sheet, 1);
/*      */     setElementAttributes(condPageBreakElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("CondHeight")) != null)
/*      */       condPageBreakElementDef.setCondHeight(Double.valueOf(str).doubleValue()); 
/*      */     return condPageBreakElementDef;
/*      */   }
/*      */   
/*      */   protected Object readSpace(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     SpaceElementDef spaceElementDef = new SpaceElementDef(this.sheet, 10);
/*      */     setElementAttributes(spaceElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Space")) != null)
/*      */       spaceElementDef.setSpace(Integer.parseInt(str)); 
/*      */     return spaceElementDef;
/*      */   }
/*      */   
/*      */   protected Object readSeparator(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     SeparatorElementDef separatorElementDef = new SeparatorElementDef(this.sheet, 0);
/*      */     setElementAttributes(separatorElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Style")) != null)
/*      */       separatorElementDef.setStyle(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("SeparatorAdvance")) != null)
/*      */       separatorElementDef.setSeparatorAdvance(Integer.parseInt(str)); 
/*      */     return separatorElementDef;
/*      */   }
/*      */   
/*      */   protected Object readTOC(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     TOCElementDef tOCElementDef = new TOCElementDef(this.sheet, TOC.DEFAULT);
/*      */     setElementAttributes(tOCElementDef, paramTag);
/*      */     String str;
/*      */     if ((str = paramTag.get("Style")) != null)
/*      */       try {
/*      */         tOCElementDef.setTOC((TOC)Class.forName(str).newInstance());
/*      */       } catch (Exception exception) {
/*      */         throw new IOException("Class " + str + " not found");
/*      */       }  
/*      */     return tOCElementDef;
/*      */   }
/*      */   
/*      */   protected Object readComposite(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     CompositeElementDef compositeElementDef = new CompositeElementDef(this.sheet, new EmptyContainer());
/*      */     String str;
/*      */     if ((str = paramTag.get("ID")) != null)
/*      */       compositeElementDef.setID(str); 
/*      */     return compositeElementDef;
/*      */   }
/*      */   
/*      */   protected Object readButton(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     ButtonElementDef buttonElementDef = new ButtonElementDef(this.sheet, null, null, null);
/*      */     setElementAttributes(buttonElementDef, paramTag);
/*      */     setPainterAttributes(buttonElementDef, paramTag);
/*      */     buttonElementDef.setName(paramTag.get("Name"));
/*      */     buttonElementDef.setForm(paramTag.get("Form"));
/*      */     buttonElementDef.setText(paramTag.get("Text"));
/*      */     readProperties(buttonElementDef);
/*      */     return buttonElementDef;
/*      */   }
/*      */   
/*      */   protected Object readImageButton(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     ImageButtonElementDef imageButtonElementDef = new ImageButtonElementDef(this.sheet, null, null);
/*      */     setElementAttributes(imageButtonElementDef, paramTag);
/*      */     setPainterAttributes(imageButtonElementDef, paramTag);
/*      */     imageButtonElementDef.setName(paramTag.get("Name"));
/*      */     imageButtonElementDef.setForm(paramTag.get("Form"));
/*      */     imageButtonElementDef.setResource(paramTag.get("Resource"));
/*      */     readProperties(imageButtonElementDef);
/*      */     return imageButtonElementDef;
/*      */   }
/*      */   
/*      */   protected Object readCheckBox(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     CheckBoxElementDef checkBoxElementDef = new CheckBoxElementDef(this.sheet, null, null, null, false);
/*      */     setElementAttributes(checkBoxElementDef, paramTag);
/*      */     setPainterAttributes(checkBoxElementDef, paramTag);
/*      */     checkBoxElementDef.setName(paramTag.get("Name"));
/*      */     checkBoxElementDef.setForm(paramTag.get("Form"));
/*      */     checkBoxElementDef.setText(paramTag.get("Text"));
/*      */     String str;
/*      */     checkBoxElementDef.setSelected(((str = paramTag.get("Selected")) != null && str.equalsIgnoreCase("true")));
/*      */     readProperties(checkBoxElementDef);
/*      */     return checkBoxElementDef;
/*      */   }
/*      */   
/*      */   protected Object readRadioButton(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     RadioButtonElementDef radioButtonElementDef = new RadioButtonElementDef(this.sheet, null, null, null, false, null);
/*      */     setElementAttributes(radioButtonElementDef, paramTag);
/*      */     setPainterAttributes(radioButtonElementDef, paramTag);
/*      */     radioButtonElementDef.setName(paramTag.get("Name"));
/*      */     radioButtonElementDef.setForm(paramTag.get("Form"));
/*      */     radioButtonElementDef.setText(paramTag.get("Text"));
/*      */     radioButtonElementDef.setGroup(paramTag.get("Group"));
/*      */     String str;
/*      */     radioButtonElementDef.setSelected(((str = paramTag.get("Selected")) != null && str.equalsIgnoreCase("true")));
/*      */     readProperties(radioButtonElementDef);
/*      */     return radioButtonElementDef;
/*      */   }
/*      */   
/*      */   protected Object readChoice(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     ChoiceElementDef choiceElementDef = new ChoiceElementDef(this.sheet, null, null, null, null);
/*      */     setElementAttributes(choiceElementDef, paramTag);
/*      */     setPainterAttributes(choiceElementDef, paramTag);
/*      */     choiceElementDef.setName(paramTag.get("Name"));
/*      */     choiceElementDef.setForm(paramTag.get("Form"));
/*      */     choiceElementDef.setSelectedItem(paramTag.get("SelectedItem"));
/*      */     Vector vector = new Vector();
/*      */     paramTag = (XMLTokenStream.Tag)readProperties(choiceElementDef);
/*      */     for (; paramTag != null && !paramTag.getName().equals("/CHOICEELEMENT"); paramTag = (XMLTokenStream.Tag)this.xml.getToken()) {
/*      */       if (paramTag.getName().equals("CHOICE")) {
/*      */         Object object = this.xml.getToken();
/*      */         if (object instanceof String) {
/*      */           vector.addElement(object);
/*      */           this.xml.getToken();
/*      */         } 
/*      */       } else {
/*      */         throw new IOException("ChoiceElement missing Choice: " + paramTag);
/*      */       } 
/*      */     } 
/*      */     String[] arrayOfString = new String[vector.size()];
/*      */     vector.copyInto(arrayOfString);
/*      */     choiceElementDef.setChoices(arrayOfString);
/*      */     return choiceElementDef;
/*      */   }
/*      */   
/*      */   protected Object readTextField(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     TextFieldElementDef textFieldElementDef = new TextFieldElementDef(this.sheet, null, null, null);
/*      */     setElementAttributes(textFieldElementDef, paramTag);
/*      */     setPainterAttributes(textFieldElementDef, paramTag);
/*      */     textFieldElementDef.setName(paramTag.get("Name"));
/*      */     textFieldElementDef.setForm(paramTag.get("Form"));
/*      */     textFieldElementDef.setText(paramTag.get("Text"));
/*      */     String str = paramTag.get("Cols");
/*      */     if (str != null)
/*      */       textFieldElementDef.setCols(Integer.parseInt(str)); 
/*      */     readProperties(textFieldElementDef);
/*      */     return textFieldElementDef;
/*      */   }
/*      */   
/*      */   protected Object readTextArea(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     TextAreaElementDef textAreaElementDef = new TextAreaElementDef(this.sheet, null, null, null);
/*      */     setElementAttributes(textAreaElementDef, paramTag);
/*      */     setPainterAttributes(textAreaElementDef, paramTag);
/*      */     textAreaElementDef.setName(paramTag.get("Name"));
/*      */     textAreaElementDef.setForm(paramTag.get("Form"));
/*      */     textAreaElementDef.setText(paramTag.get("Text"));
/*      */     String str = paramTag.get("Cols");
/*      */     if (str != null)
/*      */       textAreaElementDef.setCols(Integer.parseInt(str)); 
/*      */     str = paramTag.get("Rows");
/*      */     if (str != null)
/*      */       textAreaElementDef.setRows(Integer.parseInt(str)); 
/*      */     readProperties(textAreaElementDef);
/*      */     return textAreaElementDef;
/*      */   }
/*      */   
/*      */   protected void setElementAttributes(ReportElement paramReportElement, XMLTokenStream.Tag paramTag) {
/*      */     BaseElement baseElement = (BaseElement)paramReportElement;
/*      */     String str;
/*      */     if ((str = paramTag.get("ID")) != null)
/*      */       baseElement.setID(str); 
/*      */     if ((str = paramTag.get("Alignment")) != null)
/*      */       baseElement.setAlignment(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Indent")) != null)
/*      */       baseElement.setIndent(Double.valueOf(str).doubleValue()); 
/*      */     if ((str = paramTag.get("Hindent")) != null)
/*      */       baseElement.setHindent(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Font")) != null)
/*      */       baseElement.setFont(StyleFont.decode(str)); 
/*      */     if ((str = paramTag.get("Foreground")) != null)
/*      */       baseElement.setForeground(new Color(Integer.parseInt(str))); 
/*      */     if ((str = paramTag.get("Background")) != null) {
/*      */       baseElement.setBackground(new Color(Integer.parseInt(str)));
/*      */     } else {
/*      */       baseElement.setBackground(null);
/*      */     } 
/*      */     if ((str = paramTag.get("Spacing")) != null)
/*      */       baseElement.setSpacing(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Block")) != null)
/*      */       baseElement.setBlock(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("Continuation")) != null)
/*      */       baseElement.setContinuation(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("Visible")) != null)
/*      */       baseElement.setVisible(Boolean.valueOf(str).booleanValue()); 
/*      */     if ((str = paramTag.get("KeepWithNext")) != null)
/*      */       baseElement.setKeepWithNext(Boolean.valueOf(str).booleanValue()); 
/*      */   }
/*      */   
/*      */   protected void setPainterAttributes(PainterElement paramPainterElement, XMLTokenStream.Tag paramTag) {
/*      */     String str;
/*      */     if ((str = paramTag.get("Layout")) != null)
/*      */       paramPainterElement.setLayout(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Wrapping")) != null)
/*      */       paramPainterElement.setWrapping(Integer.parseInt(str)); 
/*      */     if ((str = paramTag.get("Anchor")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       paramPainterElement.setAnchor(new Position(Float.valueOf(arrayOfString[0]).floatValue(), Float.valueOf(arrayOfString[1]).floatValue()));
/*      */     } 
/*      */     if ((str = paramTag.get("Size")) != null) {
/*      */       String[] arrayOfString = Util.split(str, 'x');
/*      */       paramPainterElement.setSize(new Size(Float.valueOf(arrayOfString[0]).floatValue(), Float.valueOf(arrayOfString[1]).floatValue()));
/*      */     } 
/*      */     if ((str = paramTag.get("Margin")) != null) {
/*      */       String[] arrayOfString = Util.split(str, ',');
/*      */       paramPainterElement.setMargin(new Insets(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1]), Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3])));
/*      */     } 
/*      */   }
/*      */   
/*      */   public TableStyle getStyle(String paramString) {
/*      */     TableStyle tableStyle = (TableStyle)this.stylemap.get(paramString);
/*      */     if (tableStyle == null)
/*      */       try {
/*      */         paramString = "inetsoft.report.style." + paramString;
/*      */         tableStyle = (TableStyle)Class.forName(paramString).newInstance();
/*      */         this.stylemap.put(paramString, tableStyle);
/*      */       } catch (Exception exception) {} 
/*      */     return (tableStyle != null) ? (TableStyle)tableStyle.clone() : null;
/*      */   }
/*      */   
/*      */   protected Image readImageData(XMLTokenStream.Tag paramTag) throws IOException, XMLException {
/*      */     int i = Integer.parseInt(paramTag.get("Width"));
/*      */     int j = Integer.parseInt(paramTag.get("Height"));
/*      */     String str = (String)this.xml.getToken();
/*      */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*      */     for (byte b = 0; b < str.length(); b++) {
/*      */       char c = str.charAt(b);
/*      */       if (!Character.isWhitespace(c))
/*      */         byteArrayOutputStream.write((byte)c); 
/*      */     } 
/*      */     return Encoder.decodeImage(i, j, Encoder.inflate(Encoder.decodeAscii85(byteArrayOutputStream.toByteArray())));
/*      */   }
/*      */   
/*      */   protected Object readProperties(ReportElement paramReportElement) throws XMLException, IOException {
/*      */     Object object = null;
/*      */     while ((object = this.xml.getToken()) != null && object instanceof XMLTokenStream.Tag) {
/*      */       if (((XMLTokenStream.Tag)object).getName().equals("SCRIPT")) {
/*      */         for (object = this.xml.getToken(); !object.equals("/SCRIPT"); object = this.xml.getToken())
/*      */           paramReportElement.setScript((String)object); 
/*      */         continue;
/*      */       } 
/*      */       if (((XMLTokenStream.Tag)object).getName().equals("ONCLICK")) {
/*      */         for (object = this.xml.getToken(); !object.equals("/ONCLICK"); object = this.xml.getToken())
/*      */           paramReportElement.setOnClick((String)object); 
/*      */         continue;
/*      */       } 
/*      */       if (!object.equals("PROPERTY"))
/*      */         break; 
/*      */       String str1 = null, str2 = null;
/*      */       object = this.xml.getToken();
/*      */       while (object != null) {
/*      */         if (object instanceof XMLTokenStream.Tag) {
/*      */           XMLTokenStream.Tag tag = (XMLTokenStream.Tag)object;
/*      */           if (tag.getName().equals("/PROPERTY")) {
/*      */             if (str1 != null && str2 != null)
/*      */               paramReportElement.setProperty(str1, str2); 
/*      */             break;
/*      */           } 
/*      */           if (tag.getName().equals("NAME")) {
/*      */             object = this.xml.getToken();
/*      */             if (!(object instanceof XMLTokenStream.Tag)) {
/*      */               str1 = (String)object;
/*      */               object = this.xml.getToken();
/*      */             } 
/*      */             continue;
/*      */           } 
/*      */           if (tag.getName().equals("VALUE")) {
/*      */             object = this.xml.getToken();
/*      */             if (!(object instanceof XMLTokenStream.Tag)) {
/*      */               str2 = (String)object;
/*      */               object = this.xml.getToken();
/*      */             } 
/*      */             continue;
/*      */           } 
/*      */           object = this.xml.getToken();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     return object;
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\TemplateParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */