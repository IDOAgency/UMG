/*      */ package inetsoft.report.io;
/*      */ 
/*      */ import inetsoft.report.AreaBreakElement;
/*      */ import inetsoft.report.ChartElement;
/*      */ import inetsoft.report.Common;
/*      */ import inetsoft.report.CompositeElement;
/*      */ import inetsoft.report.CompositeLens;
/*      */ import inetsoft.report.CondPageBreakElement;
/*      */ import inetsoft.report.Context;
/*      */ import inetsoft.report.FormElement;
/*      */ import inetsoft.report.HeadingElement;
/*      */ import inetsoft.report.Margin;
/*      */ import inetsoft.report.NewlineElement;
/*      */ import inetsoft.report.PageBreakElement;
/*      */ import inetsoft.report.PageLayoutElement;
/*      */ import inetsoft.report.Painter;
/*      */ import inetsoft.report.PainterElement;
/*      */ import inetsoft.report.Presenter;
/*      */ import inetsoft.report.ReportElement;
/*      */ import inetsoft.report.ScaledPainter;
/*      */ import inetsoft.report.SectionBand;
/*      */ import inetsoft.report.SectionElement;
/*      */ import inetsoft.report.SeparatorElement;
/*      */ import inetsoft.report.Size;
/*      */ import inetsoft.report.SpaceElement;
/*      */ import inetsoft.report.StyleFont;
/*      */ import inetsoft.report.StyleSheet;
/*      */ import inetsoft.report.TOCElement;
/*      */ import inetsoft.report.TabElement;
/*      */ import inetsoft.report.TableElement;
/*      */ import inetsoft.report.TableLens;
/*      */ import inetsoft.report.TextBoxElement;
/*      */ import inetsoft.report.TextElement;
/*      */ import inetsoft.report.internal.HTextLens;
/*      */ import inetsoft.report.internal.PainterElementDef;
/*      */ import inetsoft.report.internal.PixelConsumer;
/*      */ import inetsoft.report.internal.SectionElementDef;
/*      */ import inetsoft.report.internal.TableElementDef;
/*      */ import inetsoft.report.internal.TextBoxElementDef;
/*      */ import inetsoft.report.internal.TextElementDef;
/*      */ import inetsoft.report.internal.Util;
/*      */ import inetsoft.report.painter.ComponentPainter;
/*      */ import inetsoft.report.painter.ImagePainter;
/*      */ import inetsoft.report.painter.PresenterPainter;
/*      */ import inetsoft.report.style.XTableStyle;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.text.Format;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class RTFFormatter
/*      */   extends BaseFormatter
/*      */ {
/*      */   protected PrintWriter writer;
/*      */   protected OutputStream output;
/*      */   Hashtable fontmap;
/*      */   Hashtable colormap;
/*      */   Dimension pagesize;
/*      */   int pagewidth;
/*      */   double currX;
/*      */   double floatH;
/*      */   boolean inHeader;
/*      */   boolean ignore;
/*      */   int currentHeaderType;
/*      */   int currentHeaderAlignment;
/*      */   String[][] headerText;
/*      */   
/*      */   public RTFFormatter(OutputStream paramOutputStream) {
/* 1375 */     this.fontmap = new Hashtable();
/* 1376 */     this.colormap = new Hashtable();
/* 1377 */     this.pagesize = new Dimension(12240, 15840);
/*      */     
/* 1379 */     this.currX = 0.0D; this.floatH = 0.0D;
/* 1380 */     this.inHeader = false;
/* 1381 */     this.ignore = false;
/*      */ 
/*      */     
/* 1384 */     this.currentHeaderAlignment = 0;
/* 1385 */     this.headerText = new String[20][3];
/*      */ 
/*      */ 
/*      */     
/* 1389 */     fontnames.put("dialog", "Helvetica");
/* 1390 */     fontnames.put("dialoginput", "Courier");
/* 1391 */     fontnames.put("serif", "Times");
/* 1392 */     fontnames.put("sansserif", "Helvetica");
/* 1393 */     fontnames.put("monospaced", "Courier");
/* 1394 */     fontnames.put("timesroman", "Times");
/* 1395 */     fontnames.put("courier", "Courier");
/* 1396 */     fontnames.put("helvetica", "Helvetica");
/*      */     this.writer = new PrintWriter(this.output = paramOutputStream);
/*      */   }
/*      */   
/*      */   public void setPageSize(double paramDouble1, double paramDouble2) { this.pagesize = new Dimension((int)(paramDouble1 * 1440.0D), (int)(paramDouble2 * 1440.0D)); }
/*      */   
/*      */   public void setPageSize(Size paramSize) { setPageSize(paramSize.width, paramSize.height); }
/*      */   
/*      */   public void prolog(StyleSheet paramStyleSheet) {
/*      */     this.sheet = paramStyleSheet;
/*      */     this.pagewidth = (int)(this.pagesize.width - (paramStyleSheet.getMargin()).left * 1440.0D - (paramStyleSheet.getMargin()).right * 1440.0D);
/*      */     this.writer.print("{\\rtf1\\ansi\\ansicpg1252\\uc1 \\deff0");
/*      */     this.writer.print("\\deflang1033\\deflangfe1033{\\fonttbl");
/*      */     Vector[] arrayOfVector = { paramStyleSheet.getElements(256), paramStyleSheet.getElements(257), paramStyleSheet.getElements(258), paramStyleSheet.getElements(259), paramStyleSheet.getElements(512), paramStyleSheet.getElements(513), paramStyleSheet.getElements(514), paramStyleSheet.getElements(515), paramStyleSheet.getElements(0) };
/*      */     byte b1 = 1;
/*      */     for (byte b2 = 0; b2 < arrayOfVector.length; b2++) {
/*      */       if (arrayOfVector[b2] != null)
/*      */         for (byte b = 0; b < arrayOfVector[b2].size(); b++, b1++) {
/*      */           ReportElement reportElement = (ReportElement)arrayOfVector[b2].elementAt(b);
/*      */           if (this.fontmap.get(reportElement.getFont()) == null) {
/*      */             this.fontmap.put(reportElement.getFont(), new Integer(b1));
/*      */             this.writer.print("{\\f" + b1 + "\\fcharset0\\fprq2 " + reportElement.getFont().getName() + ";}");
/*      */           } 
/*      */         }  
/*      */     } 
/*      */     this.writer.print("}");
/*      */     this.writer.print("{\\colortbl;");
/*      */     for (byte b3 = 0; b3 < arrayOfVector.length; b3++) {
/*      */       if (arrayOfVector[b3] != null)
/*      */         for (byte b = 0; b < arrayOfVector[b3].size(); b++) {
/*      */           ReportElement reportElement = (ReportElement)arrayOfVector[b3].elementAt(b);
/*      */           writeColorTable(reportElement.getForeground());
/*      */           writeColorTable(reportElement.getBackground());
/*      */           if (reportElement instanceof TableElement) {
/*      */             TableLens tableLens = ((TableElement)reportElement).getTable();
/*      */             for (byte b4 = -1; b4 < tableLens.getRowCount(); b4++) {
/*      */               for (byte b5 = -1; b5 < tableLens.getColCount(); b5++) {
/*      */                 writeColorTable(tableLens.getRowBorderColor(b4, b5));
/*      */                 writeColorTable(tableLens.getColBorderColor(b4, b5));
/*      */                 if (b4 >= 0 && b5 >= 0) {
/*      */                   writeColorTable(tableLens.getForeground(b4, b5));
/*      */                   writeColorTable(tableLens.getBackground(b4, b5));
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }  
/*      */     } 
/*      */     this.writer.print("}");
/*      */     this.writer.print("\\widowctrl\\ftnbj\\aenddoc\\formshade\\viewkind1\\viewscale100\\pgbrdrhead\\pgbrdrfoot \\fet0\\sectd \\linex0\\endnhere");
/*      */     Margin margin = paramStyleSheet.getMargin();
/*      */     this.writer.print("\\paperw" + this.pagesize.width + "\\paperh" + this.pagesize.height + "\\margl" + (int)(margin.left * 1440.0D) + "\\margr" + (int)(margin.right * 1440.0D) + "\\margt" + (int)(margin.top * 1440.0D) + "\\margb" + (int)(margin.bottom * 1440.0D));
/*      */     this.writer.print("\\headery" + (int)(paramStyleSheet.getHeaderFromEdge() * 1440.0D) + "\\footery" + (int)(paramStyleSheet.getFooterFromEdge() * 1440.0D));
/*      */     this.writer.println("");
/*      */   }
/*      */   
/*      */   public void startHeader(int paramInt) {
/*      */     switch (paramInt) {
/*      */       case 256:
/*      */         this.writer.println("{\\header");
/*      */         break;
/*      */       case 257:
/*      */         this.writer.println("{\\headerf");
/*      */         break;
/*      */       case 259:
/*      */         this.writer.println("{\\headerr");
/*      */         break;
/*      */       case 258:
/*      */         this.writer.println("{\\headerl");
/*      */         break;
/*      */       case 512:
/*      */         this.writer.println("{\\footer");
/*      */         break;
/*      */       case 513:
/*      */         this.writer.println("{\\footerf");
/*      */         break;
/*      */       case 515:
/*      */         this.writer.println("{\\footerr");
/*      */         break;
/*      */       case 514:
/*      */         this.writer.println("{\\footerl");
/*      */         break;
/*      */     } 
/*      */     this.writer.println("\\pard \\widctlpar\\tqc\\tx4320\\tqr\\tx8640");
/*      */     this.inHeader = true;
/*      */     if (paramInt >= 512) {
/*      */       this.currentHeaderType = paramInt - 512 + 10;
/*      */     } else {
/*      */       this.currentHeaderType = paramInt - 256;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void startHeader(String paramString, boolean paramBoolean) { this.ignore = true; }
/*      */   
/*      */   public void endHeader() {
/*      */     if (this.headerText[this.currentHeaderType][false] != null)
/*      */       this.writer.print(this.headerText[this.currentHeaderType][0] + " "); 
/*      */     if (this.headerText[this.currentHeaderType][true] != null)
/*      */       this.writer.print("\\tab " + this.headerText[this.currentHeaderType][1] + " "); 
/*      */     if (this.headerText[this.currentHeaderType][2] != null) {
/*      */       if (this.headerText[this.currentHeaderType][true] == null)
/*      */         this.writer.print("\\tab "); 
/*      */       this.writer.print("\\tab " + this.headerText[this.currentHeaderType][2] + " ");
/*      */     } 
/*      */     this.writer.println("{\\par}}");
/*      */     this.inHeader = false;
/*      */     this.ignore = false;
/*      */   }
/*      */   
/*      */   public void write(XTableStyle paramXTableStyle) {}
/*      */   
/*      */   public void write(HeadingElement paramHeadingElement) {
/*      */     this.writer.print("{\\*\\bkmkstart " + paramHeadingElement.getID() + "}");
/*      */     this.writer.print("\\outlinelevel" + paramHeadingElement.getLevel());
/*      */     write(paramHeadingElement);
/*      */     this.writer.print("{\\*\\bkmkend " + paramHeadingElement.getID() + "}");
/*      */   }
/*      */   
/*      */   public void write(TextElement paramTextElement) {
/*      */     TextElementDef textElementDef = (TextElementDef)paramTextElement;
/*      */     if (this.ignore || !textElementDef.isVisible())
/*      */       return; 
/*      */     if (textElementDef.isJustify())
/*      */       this.writer.print("\\qj "); 
/*      */     writeAlignment(textElementDef.getAlignment());
/*      */     if (textElementDef.getIndent() > 0.0D)
/*      */       this.writer.print("\\li" + (int)(textElementDef.getIndent() * 1440.0D) + " "); 
/*      */     if (textElementDef.getSpacing() > 0)
/*      */       this.writer.print("\\sa" + (textElementDef.getSpacing() * 20) + " "); 
/*      */     String str = textElementDef.getText();
/*      */     if (this.inHeader) {
/*      */       String str1 = "{\\field{\\*\\fldinst {\\cs17  PAGE }}{\\fldrslt {\\cs17\\lang1024 1}}}";
/*      */       String str2 = "{\\field{\\*\\fldinst {\\cs17  NUMPAGES }}{\\fldrslt {\\cs17\\lang1024 1}}}";
/*      */       String str3 = "{\\field{\\*\\fldinst {\\cs17  DATE \\\\@ \"";
/*      */       String str4 = "MM/dd/yy";
/*      */       String str5 = "\" }}{\\fldrslt {\\cs17\\lang1024 04/15/99}}}";
/*      */       String str6 = "{\\field{\\*\\fldinst {\\cs17  TIME \\\\@ \"";
/*      */       String str7 = "h:mm AM/PM";
/*      */       String str8 = "\"}}{\\fldrslt {\\cs17\\lang1024 12:08 PM}}}";
/*      */       for (int i = 0; (i = str.indexOf("{P", i)) >= 0; ) {
/*      */         int n = str.indexOf("}", i);
/*      */         str = str.substring(0, i) + str1 + str.substring(n + 1);
/*      */         i += str1.length();
/*      */       } 
/*      */       for (int j = 0; (j = str.indexOf("{N", j)) >= 0; ) {
/*      */         int n = str.indexOf("}", j);
/*      */         str = str.substring(0, j) + str2 + str.substring(n + 1);
/*      */         j += str2.length();
/*      */       } 
/*      */       for (int k = 0; (k = str.indexOf("{D", k)) >= 0; ) {
/*      */         String str9 = str4;
/*      */         int n = str.indexOf(",", k);
/*      */         int i1 = str.indexOf("}", k);
/*      */         if (n >= 0)
/*      */           str9 = str.substring(n + 1, i1); 
/*      */         str = str.substring(0, k) + str3 + str9 + str5 + str.substring(i1 + 1);
/*      */         k = k + str3.length() + str9.length() + str5.length();
/*      */       } 
/*      */       for (int m = 0; (m = str.indexOf("{T", m)) >= 0; ) {
/*      */         String str9 = str7;
/*      */         int n = str.indexOf(",", m);
/*      */         int i1 = str.indexOf("}", m);
/*      */         if (n >= 0)
/*      */           str9 = str.substring(n + 1, i1); 
/*      */         str = str.substring(0, m) + str6 + str9 + str8 + str.substring(i1 + 1);
/*      */         m = m + str6.length() + str9.length() + str8.length();
/*      */       } 
/*      */       if (this.headerText[this.currentHeaderType][this.currentHeaderAlignment] != null) {
/*      */         this.headerText[this.currentHeaderType][this.currentHeaderAlignment] = this.headerText[this.currentHeaderType][this.currentHeaderAlignment] + str;
/*      */       } else {
/*      */         this.headerText[this.currentHeaderType][this.currentHeaderAlignment] = str;
/*      */       } 
/*      */       return;
/*      */     } 
/*      */     if (textElementDef.getTextLens() instanceof HTextLens) {
/*      */       HTextLens hTextLens = (HTextLens)textElementDef.getTextLens();
/*      */       this.writer.print("{\\field{\\*\\fldinst {\\lang1024  PAGEREF " + hTextLens.getHeadingElement().getID() + " \\\\h }}{\\fldrslt {\\lang1024 1}}}");
/*      */       return;
/*      */     } 
/*      */     str = textElementDef.getDisplayText();
/*      */     this.writer.print("{");
/*      */     if (textElementDef.isNewline())
/*      */       this.writer.print("\\par "); 
/*      */     writeParagraph(str, textElementDef.getFont(), textElementDef.getForeground());
/*      */     if (textElementDef.isLastOnLine())
/*      */       this.writer.print("\\par"); 
/*      */     this.writer.println("}");
/*      */     if (textElementDef.isLastOnLine()) {
/*      */       newline();
/*      */       this.writer.print("\\pard{\\par}");
/*      */     } else {
/*      */       this.currX += (textElementDef.getPreferredSize()).width;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void write(SectionElement paramSectionElement) {
/*      */     SectionElementDef sectionElementDef = (SectionElementDef)paramSectionElement;
/*      */     if (this.ignore || !sectionElementDef.isVisible())
/*      */       return; 
/*      */     newline();
/*      */     writeSection(sectionElementDef);
/*      */   }
/*      */   
/*      */   protected void printBand(SectionBand paramSectionBand) {
/*      */     this.writer.print("{\\par}");
/*      */     for (byte b = 0; b < paramSectionBand.getElementCount(); b++) {
/*      */       Builder.write(this, paramSectionBand.getElement(b));
/*      */       this.writer.print("{  }");
/*      */     } 
/*      */     this.writer.print("{\\par}");
/*      */     this.currX = 0.0D;
/*      */   }
/*      */   
/*      */   public void write(TableElement paramTableElement) {
/*      */     TableElementDef tableElementDef = (TableElementDef)paramTableElement;
/*      */     if (this.ignore || !tableElementDef.isVisible())
/*      */       return; 
/*      */     newline();
/*      */     this.writer.println("{\\par}");
/*      */     TableLens tableLens = tableElementDef.getTable();
/*      */     Font font = tableElementDef.getFont();
/*      */     int i = (int)(tableElementDef.getIndent() * 1440.0D);
/*      */     int j = tableElementDef.getLayout();
/*      */     int[] arrayOfInt1 = new int[tableLens.getColCount()];
/*      */     int[] arrayOfInt2 = tableElementDef.getFixedWidths();
/*      */     int k = this.pagewidth / arrayOfInt1.length;
/*      */     if (arrayOfInt2 != null) {
/*      */       for (byte b1 = 0; b1 < arrayOfInt2.length; b1++)
/*      */         arrayOfInt1[b1] = arrayOfInt2[b1] * 20; 
/*      */     } else if (j == 2) {
/*      */       for (byte b1 = 0; b1 < arrayOfInt1.length; b1++)
/*      */         arrayOfInt1[b1] = k; 
/*      */     } else {
/*      */       float[][] arrayOfFloat = tableElementDef.calcColWidth(k);
/*      */       int m = 0;
/*      */       int n = 0;
/*      */       for (byte b1 = 0; b1 < arrayOfFloat.length; b1++) {
/*      */         if (arrayOfFloat[b1][0] != 0.0F) {
/*      */           arrayOfInt1[b1] = (int)(arrayOfFloat[b1][0] * 20.0F);
/*      */           m += arrayOfInt1[b1];
/*      */         } else {
/*      */           n++;
/*      */         } 
/*      */       } 
/*      */       if (n > 0) {
/*      */         int i1 = (this.pagewidth - m) / n;
/*      */         for (byte b2 = 0; b2 < arrayOfFloat.length; b2++) {
/*      */           if (arrayOfFloat[b2][0] == 0.0F)
/*      */             arrayOfInt1[b2] = i1; 
/*      */         } 
/*      */       } 
/*      */       if (j == 1) {
/*      */         m = 0;
/*      */         for (byte b2 = 0; b2 < arrayOfInt1.length; b2++)
/*      */           m += arrayOfInt1[b2]; 
/*      */         for (byte b3 = 0; b3 < arrayOfInt1.length; b3++)
/*      */           arrayOfInt1[b3] = arrayOfInt1[b3] * this.pagewidth / Math.max(m, 1); 
/*      */       } 
/*      */     } 
/*      */     Hashtable hashtable = new Hashtable();
/*      */     for (byte b = 0; b < tableLens.getRowCount(); b++) {
/*      */       this.writer.print("\\trowd\\trgaph108\\trleft" + i);
/*      */       if (b < tableLens.getHeaderRowCount())
/*      */         this.writer.print("\\trhdr"); 
/*      */       for (int m = 0; m < tableLens.getColCount(); m++) {
/*      */         int n = 1;
/*      */         Dimension dimension = tableLens.getSpan(b, m);
/*      */         if (dimension != null && (dimension.height > 1 || dimension.width > 1)) {
/*      */           if (dimension.height > 1)
/*      */             this.writer.print("\\clvmgf"); 
/*      */           for (int i5 = 0; i5 < dimension.height; i5++) {
/*      */             for (int i6 = 0; i6 < dimension.width; i6++)
/*      */               hashtable.put(new Point(m + i6, b + i5), new Rectangle(-i6, -i5, dimension.width - i6, dimension.height - i5)); 
/*      */           } 
/*      */           n = dimension.width;
/*      */         } else if (hashtable.get(new Point(m, b)) != null) {
/*      */           Rectangle rectangle = (Rectangle)hashtable.get(new Point(m, b));
/*      */           if (rectangle.y == 0 || rectangle.width > 1)
/*      */             continue; 
/*      */           if (rectangle.y < 0)
/*      */             this.writer.print("\\clvmrg"); 
/*      */         } 
/*      */         if (b == 0) {
/*      */           int i5 = tableLens.getRowBorder(b - 1, m);
/*      */           if (i5 != 0) {
/*      */             Color color = tableLens.getRowBorderColor(b - 1, m);
/*      */             if (color != null)
/*      */               this.writer.print("\\clbrdrt" + getBorder(i5) + "\\brdrcf" + this.colormap.get(color)); 
/*      */           } 
/*      */         } 
/*      */         if (m == 0) {
/*      */           int i5 = tableLens.getColBorder(b, m - 1);
/*      */           if (i5 != 0) {
/*      */             Color color = tableLens.getColBorderColor(b, m - 1);
/*      */             if (color != null)
/*      */               this.writer.print("\\clbrdrl" + getBorder(i5) + "\\brdrcf" + this.colormap.get(color)); 
/*      */           } 
/*      */         } 
/*      */         int i1 = tableLens.getRowBorder(b + ((dimension == null) ? 0 : (dimension.height - 1)), m);
/*      */         if (i1 != 0) {
/*      */           Color color = tableLens.getRowBorderColor(b, m);
/*      */           if (color != null)
/*      */             this.writer.print("\\clbrdrb" + getBorder(i1) + "\\brdrcf" + this.colormap.get(color)); 
/*      */         } 
/*      */         int i2 = tableLens.getColBorder(b, m + ((dimension == null) ? 0 : (dimension.width - 1)));
/*      */         if (i2 != 0) {
/*      */           Color color = tableLens.getColBorderColor(b, m);
/*      */           if (color != null)
/*      */             this.writer.print("\\clbrdrr" + getBorder(i2) + "\\brdrcf" + this.colormap.get(color)); 
/*      */         } 
/*      */         Color color1 = tableLens.getBackground(b, m);
/*      */         if (color1 != null && color1 != Color.white)
/*      */           this.writer.print("\\clcbpat" + this.colormap.get(color1)); 
/*      */         int i3 = tableLens.getAlignment(b, m);
/*      */         if ((i3 & 0x8) != 0) {
/*      */           this.writer.print("\\clvertalt ");
/*      */         } else if ((i3 & 0x10) != 0) {
/*      */           this.writer.print("\\clvertalc ");
/*      */         } else if ((i3 & 0x20) != 0) {
/*      */           this.writer.print("\\clvertalb ");
/*      */         } 
/*      */         writeAlignment(i3);
/*      */         int i4 = 0;
/*      */         for (byte b1 = 0; b1 < m + n; b1++)
/*      */           i4 += arrayOfInt1[b1]; 
/*      */         this.writer.print("\\intbl\\cellx" + i4);
/*      */         this.writer.print("{");
/*      */         Object object = tableLens.getObject(b, m);
/*      */         Color color2 = tableLens.getForeground(b, m);
/*      */         if (object != null) {
/*      */           Presenter presenter = tableElementDef.getPresenter(object.getClass());
/*      */           if (presenter != null) {
/*      */             object = new PresenterPainter(object, presenter);
/*      */           } else {
/*      */             Format format = tableElementDef.getFormat(object.getClass());
/*      */             if (format != null)
/*      */               object = format.format(object); 
/*      */           } 
/*      */         } 
/*      */         if (object instanceof Component) {
/*      */           writePainter(new ComponentPainter((Component)object), null, color2, color1);
/*      */         } else if (object instanceof Image) {
/*      */           writePainter(new ImagePainter((Image)object), null, color2, color1);
/*      */         } else if (object instanceof Painter) {
/*      */           writePainter((Painter)object, null, color2, color1);
/*      */         } else if (object != null) {
/*      */           Font font1 = tableLens.getFont(b, m);
/*      */           writeParagraph(object, (font1 == null) ? font : font1, color2);
/*      */         } 
/*      */         this.writer.print("\\cell}");
/*      */         continue;
/*      */       } 
/*      */       this.writer.println("{\\row}");
/*      */     } 
/*      */     newline();
/*      */     this.writer.print("\\pard{\\par}");
/*      */   }
/*      */   
/*      */   public void write(FormElement paramFormElement) { write(paramFormElement); }
/*      */   
/*      */   public void write(PainterElement paramPainterElement) {
/*      */     PainterElementDef painterElementDef = (PainterElementDef)paramPainterElement;
/*      */     if (this.ignore || !painterElementDef.isVisible())
/*      */       return; 
/*      */     Painter painter = painterElementDef.getPainter();
/*      */     writeAlignment(painterElementDef.getAlignment());
/*      */     writeWrapSpace(painterElementDef.getMargin());
/*      */     if (painterElementDef.getAnchor() != null) {
/*      */       double d = ((painterElementDef.getAnchor()).x * 1440.0F);
/*      */       if (d < 0.0D)
/*      */         d += this.pagewidth; 
/*      */       this.writer.print("\\li" + (int)d + " ");
/*      */     } else if (painterElementDef.getIndent() > 0.0D) {
/*      */       this.writer.print("\\li" + (int)(painterElementDef.getIndent() * 1440.0D) + " ");
/*      */     } 
/*      */     writePainter(painter, painterElementDef.getPreferredSize(), painterElementDef.getForeground(), painterElementDef.getBackground());
/*      */     if (painterElementDef.isLastOnLine()) {
/*      */       newline();
/*      */       this.writer.print("\\pard{\\par}");
/*      */     } else {
/*      */       this.currX += (painterElementDef.getPreferredSize()).width;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void write(ChartElement paramChartElement) { write(paramChartElement); }
/*      */   
/*      */   public void write(TOCElement paramTOCElement) {
/*      */     if (this.ignore || !paramTOCElement.isVisible())
/*      */       return; 
/*      */     newline();
/*      */     Context context = new Context(this.sheet);
/*      */     CompositeLens compositeLens = paramTOCElement.getComposite();
/*      */     compositeLens.reset();
/*      */     Object object;
/*      */     for (; (object = compositeLens.nextElement(context)) != null; context = new Context(this.sheet)) {
/*      */       ReportElement reportElement = this.sheet.getCompositeElement(paramTOCElement.getID(), object, context);
/*      */       if (reportElement != null) {
/*      */         reportElement.setContext(context);
/*      */         Builder.write(this, reportElement);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void write(CompositeElement paramCompositeElement) {
/*      */     Context context = new Context(this.sheet);
/*      */     CompositeLens compositeLens = paramCompositeElement.getComposite();
/*      */     compositeLens.reset();
/*      */     Object object;
/*      */     for (; (object = compositeLens.nextElement(context)) != null; context = new Context(this.sheet)) {
/*      */       ReportElement reportElement = null;
/*      */       if (object instanceof ReportElement) {
/*      */         reportElement = (ReportElement)object;
/*      */       } else {
/*      */         reportElement = this.sheet.getCompositeElement(paramCompositeElement.getID(), object, context);
/*      */       } 
/*      */       if (reportElement != null) {
/*      */         reportElement.setContext(context);
/*      */         Builder.write(this, reportElement);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void write(TextBoxElement paramTextBoxElement) {
/*      */     TextBoxElementDef textBoxElementDef = (TextBoxElementDef)paramTextBoxElement;
/*      */     if (this.ignore || !textBoxElementDef.isVisible())
/*      */       return; 
/*      */     Point point = (textBoxElementDef.getAnchor() == null) ? new Point((int)(this.currX * 20.0D), 0) : new Point((int)((textBoxElementDef.getAnchor()).x * 1440.0F), (int)((textBoxElementDef.getAnchor()).y * 1440.0F));
/*      */     if (point.x < 0)
/*      */       point.x += this.pagewidth; 
/*      */     Size size = textBoxElementDef.getPreferredSize();
/*      */     Dimension dimension = new Dimension((int)(size.width * 20.0F), (int)(size.height * 20.0F));
/*      */     this.writer.print("{\\shp{\\*\\shpinst");
/*      */     this.writer.print("\\shpleft" + point.x + "\\shptop" + point.y + "\\shpright" + (point.x + dimension.width) + "\\shpbottom" + (point.y + dimension.height) + "\\shpbxcolumn\\shpbypara");
/*      */     switch (textBoxElementDef.getWrapping()) {
/*      */       case 0:
/*      */         this.writer.print("\\shpwr3");
/*      */         break;
/*      */       case 1:
/*      */         this.writer.print("\\shpwr2\\shpwrk1");
/*      */         break;
/*      */       case 2:
/*      */         this.writer.print("\\shpwr2\\shpwrk2");
/*      */         break;
/*      */       case 3:
/*      */         this.writer.print("\\shpwr2\\shpwrk0");
/*      */         break;
/*      */       case 256:
/*      */         this.writer.print("\\shpwr1");
/*      */         break;
/*      */     } 
/*      */     this.writer.print("{\\sp{\\sn shapeType}{\\sv 202}}");
/*      */     this.writer.print("{\\sp{\\sn lineType}{\\sv 0}}");
/*      */     Insets insets = textBoxElementDef.getPadding();
/*      */     if (insets != null) {
/*      */       this.writer.print("{\\sp{\\sn dyTextTop}{\\sv " + (insets.top * 12700) + "}}");
/*      */       this.writer.print("{\\sp{\\sn dxTextLeft}{\\sv " + (insets.left * 12700) + "}}");
/*      */       this.writer.print("{\\sp{\\sn dyTextBottom}{\\sv " + (insets.bottom * 12700) + "}}");
/*      */       this.writer.print("{\\sp{\\sn dxTextRight}{\\sv " + (insets.right * 12700) + "}}");
/*      */     } 
/*      */     writeWrapSpace(textBoxElementDef.getMargin());
/*      */     this.writer.print(getLineProperty(textBoxElementDef.getBorder()));
/*      */     this.writer.print("{\\shptxt\\pard");
/*      */     writeAlignment(textBoxElementDef.getTextAlignment());
/*      */     this.writer.print("{");
/*      */     writeParagraph(textBoxElementDef.getText() + "\n", textBoxElementDef.getFont(), textBoxElementDef.getForeground());
/*      */     this.writer.print("}}}}");
/*      */     this.floatH = Math.max(this.floatH, (size.height + (point.y / 20)));
/*      */     if (textBoxElementDef.isLastOnLine()) {
/*      */       newline();
/*      */       this.writer.print("\\pard{\\par}");
/*      */     } else {
/*      */       this.currX += size.width;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void write(TabElement paramTabElement) {
/*      */     if (this.ignore || !paramTabElement.isVisible())
/*      */       return; 
/*      */     double[] arrayOfDouble = paramTabElement.getTabStops();
/*      */     int i = 0;
/*      */     for (byte b = 0; b < arrayOfDouble.length; b++) {
/*      */       if (arrayOfDouble[b] * 72.0D > this.currX) {
/*      */         this.currX = arrayOfDouble[b] * 72.0D;
/*      */         i = (int)(this.currX * 20.0D);
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     if (i == 0)
/*      */       return; 
/*      */     switch (paramTabElement.getFillStyle()) {
/*      */       case 4097:
/*      */       case 266240:
/*      */       case 528384:
/*      */         this.writer.print("\\tlul");
/*      */         break;
/*      */       case 4098:
/*      */       case 4099:
/*      */       case 24578:
/*      */       case 40962:
/*      */         this.writer.print("\\tlth");
/*      */         break;
/*      */       case 8195:
/*      */       case 24579:
/*      */       case 40963:
/*      */         this.writer.print("\\tlul");
/*      */         break;
/*      */       case 4113:
/*      */         this.writer.print("\\tldot");
/*      */         break;
/*      */       case 4145:
/*      */       case 4193:
/*      */       case 4241:
/*      */         this.writer.print("\\tlhyph");
/*      */         break;
/*      */     } 
/*      */     this.writer.print("\\tx" + i + "{\\tab}");
/*      */   }
/*      */   
/*      */   public void write(NewlineElement paramNewlineElement) {
/*      */     if (this.ignore || !paramNewlineElement.isVisible())
/*      */       return; 
/*      */     for (byte b = 0; b < paramNewlineElement.getCount(); b++)
/*      */       this.writer.print("{\\par}"); 
/*      */     newline();
/*      */     this.writer.print("\\pard");
/*      */   }
/*      */   
/*      */   public void write(AreaBreakElement paramAreaBreakElement) {
/*      */     if (this.ignore || !paramAreaBreakElement.isVisible())
/*      */       return; 
/*      */     newline();
/*      */     this.writer.print("{\\column\\par}\\pard");
/*      */   }
/*      */   
/*      */   public void write(PageBreakElement paramPageBreakElement) {
/*      */     if (this.ignore || !paramPageBreakElement.isVisible())
/*      */       return; 
/*      */     newline();
/*      */     this.writer.print("{\\page\\par}\\pard");
/*      */   }
/*      */   
/*      */   public void write(PageLayoutElement paramPageLayoutElement) {
/*      */     if (this.ignore || !paramPageLayoutElement.isVisible())
/*      */       return; 
/*      */     newline();
/*      */     this.writer.print("\\pard{\\par}");
/*      */   }
/*      */   
/*      */   public void write(CondPageBreakElement paramCondPageBreakElement) {
/*      */     if (this.ignore || !paramCondPageBreakElement.isVisible())
/*      */       return; 
/*      */     newline();
/*      */     this.writer.print("\\pard{\\par}");
/*      */   }
/*      */   
/*      */   public void write(SpaceElement paramSpaceElement) {
/*      */     if (this.ignore || !paramSpaceElement.isVisible())
/*      */       return; 
/*      */     int i = paramSpaceElement.getSpace() / 8;
/*      */     this.writer.print("{");
/*      */     for (byte b = 0; b < i; b++)
/*      */       this.writer.print(" "); 
/*      */     this.writer.print("}");
/*      */   }
/*      */   
/*      */   public void write(SeparatorElement paramSeparatorElement) {
/*      */     if (this.ignore || !paramSeparatorElement.isVisible())
/*      */       return; 
/*      */     newline();
/*      */     this.writer.print("{\\par}{\\shp{\\*\\shpinst\\shpleft0\\shptop0");
/*      */     this.writer.print("\\shpright" + this.pagewidth + "\\shpbottom0\\shpwr1");
/*      */     this.writer.print("\\shpbxcolumn\\shpbypara{\\sp{\\sn shapeType}{\\sv 20}}");
/*      */     this.writer.print("{\\sp{\\sn shapePath}{\\sv 4}}}");
/*      */     this.writer.print(getLineProperty(paramSeparatorElement.getStyle()));
/*      */     this.writer.print("{\\shprslt{\\*\\do\\dobxcolumn\\dobypara");
/*      */     this.writer.print("\\dodhgt8192\\dpline\\dpptx0\\dppty0");
/*      */     this.writer.print("\\dpx0\\dpy0\\dpxsize" + this.pagewidth + "\\dpysize30");
/*      */     this.writer.print("\\dplinecor0\\dplinecog0\\dplinecob0}}}");
/*      */     newline();
/*      */     this.writer.print("\\pard{\\par}");
/*      */   }
/*      */   
/*      */   public void end() {
/*      */     this.writer.println("}");
/*      */     this.writer.flush();
/*      */   }
/*      */   
/*      */   protected String getFontName(Font paramFont) {
/*      */     String str = paramFont.getName();
/*      */     Object object = fontnames.get(str.toLowerCase());
/*      */     return (object == null) ? str : object.toString();
/*      */   }
/*      */   
/*      */   protected String getBorder(int paramInt) {
/*      */     switch (paramInt) {
/*      */       case 4097:
/*      */       case 266240:
/*      */       case 528384:
/*      */         return "\\brdrs";
/*      */       case 4098:
/*      */       case 4099:
/*      */         return "\\brdrth";
/*      */       case 24578:
/*      */       case 24579:
/*      */       case 40962:
/*      */       case 40963:
/*      */         return "\\brdrsh";
/*      */       case 8195:
/*      */         return "\\brdrdb";
/*      */       case 4113:
/*      */         return "\\brdrdot";
/*      */       case 4145:
/*      */       case 4193:
/*      */       case 4241:
/*      */         return "\\brdrdash";
/*      */     } 
/*      */     return "\\brdrs";
/*      */   }
/*      */   
/*      */   protected String getLineProperty(int paramInt) {
/*      */     switch (paramInt) {
/*      */       case 0:
/*      */         return "{\\sp{\\sn fLine}{\\sv 0}}";
/*      */       case 266240:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 3275}}{\\sp{\\sn lineStyle}{\\sv 0}}";
/*      */       case 528384:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 6350}}{\\sp{\\sn lineStyle}{\\sv 0}}";
/*      */       case 4097:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 12700}}{\\sp{\\sn lineStyle}{\\sv 0}}";
/*      */       case 4098:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 25400}}{\\sp{\\sn lineStyle}{\\sv 0}}";
/*      */       case 4099:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 38100}}{\\sp{\\sn lineStyle}{\\sv 0}}";
/*      */       case 24578:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 25400}}{\\sp{\\sn lineStyle}{\\sv 3}}";
/*      */       case 24579:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 38100}}{\\sp{\\sn lineStyle}{\\sv 3}}";
/*      */       case 40962:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 25400}}{\\sp{\\sn lineStyle}{\\sv 2}}";
/*      */       case 40963:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 38100}}{\\sp{\\sn lineStyle}{\\sv 2}}";
/*      */       case 8195:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 38100}}{\\sp{\\sn lineStyle}{\\sv 1}}";
/*      */       case 4113:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 12700}}{\\sp{\\sn lineStyle}{\\sv 0}}{\\sp{\\sn lineDashing}{\\sv 2}}";
/*      */       case 4145:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 12700}}{\\sp{\\sn lineStyle}{\\sv 0}}{\\sp{\\sn lineDashing}{\\sv 1}}";
/*      */       case 4193:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 12700}}{\\sp{\\sn lineStyle}{\\sv 0}}{\\sp{\\sn lineDashing}{\\sv 10}}";
/*      */       case 4241:
/*      */         return "{\\sp{\\sn lineWidth}{\\sv 12700}}{\\sp{\\sn lineStyle}{\\sv 0}}{\\sp{\\sn lineDashing}{\\sv 8}}";
/*      */     } 
/*      */     return "";
/*      */   }
/*      */   
/*      */   protected void writeColorTable(Color paramColor) {
/*      */     if (paramColor != null && this.colormap.get(paramColor) == null) {
/*      */       this.colormap.put(paramColor, new Integer(this.colormap.size() + 1));
/*      */       this.writer.print("\\red" + paramColor.getRed() + "\\green" + paramColor.getGreen() + "\\blue" + paramColor.getBlue() + ";");
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void writeParagraph(Object paramObject, Font paramFont, Color paramColor) {
/*      */     String str1 = "";
/*      */     if (paramFont != null) {
/*      */       this.writer.print("\\f" + this.fontmap.get(paramFont) + "\\fs" + (paramFont.getSize() * 2));
/*      */       if ((paramFont.getStyle() & true) != 0)
/*      */         this.writer.print("\\b"); 
/*      */       if ((paramFont.getStyle() & 0x2) != 0)
/*      */         this.writer.print("\\i"); 
/*      */       if ((paramFont.getStyle() & 0x10) != 0)
/*      */         switch (((StyleFont)paramFont).getLineStyle()) {
/*      */           case 8195:
/*      */             this.writer.print("\\uldb");
/*      */             break;
/*      */           case 4113:
/*      */             this.writer.print("\\uld");
/*      */             break;
/*      */           case 4098:
/*      */           case 4099:
/*      */             this.writer.print("\\ulth");
/*      */             break;
/*      */           case 4145:
/*      */           case 4193:
/*      */           case 4241:
/*      */             this.writer.print("\\uldash");
/*      */             break;
/*      */           default:
/*      */             this.writer.print("\\ul");
/*      */             break;
/*      */         }  
/*      */       if ((paramFont.getStyle() & 0x20) != 0)
/*      */         switch (((StyleFont)paramFont).getLineStyle()) {
/*      */           case 8195:
/*      */             this.writer.print("\\striked1");
/*      */             break;
/*      */           default:
/*      */             this.writer.print("\\strike");
/*      */             break;
/*      */         }  
/*      */       if ((paramFont.getStyle() & 0x40) != 0)
/*      */         this.writer.print("\\super"); 
/*      */       if ((paramFont.getStyle() & 0x80) != 0)
/*      */         this.writer.print("\\sub"); 
/*      */       if ((paramFont.getStyle() & 0x100) != 0)
/*      */         this.writer.print("\\shad"); 
/*      */       if ((paramFont.getStyle() & 0x200) != 0)
/*      */         this.writer.print("\\scaps"); 
/*      */       if ((paramFont.getStyle() & 0x400) != 0)
/*      */         this.writer.print("\\caps"); 
/*      */       str1 = " ";
/*      */     } 
/*      */     if (paramColor != null && paramColor != Color.black) {
/*      */       this.writer.print("\\cf" + this.colormap.get(paramColor));
/*      */       str1 = " ";
/*      */     } 
/*      */     this.writer.print(str1);
/*      */     String str2 = paramObject.toString();
/*      */     for (int i = 0; (i = str2.indexOf('\n')) >= 0; ) {
/*      */       this.writer.print(str2.substring(0, i));
/*      */       this.writer.print("\\par ");
/*      */       str2 = str2.substring(i + 1);
/*      */     } 
/*      */     this.writer.print(str2);
/*      */   }
/*      */   
/*      */   protected void writeAlignment(int paramInt) {
/*      */     boolean bool = false;
/*      */     if (this.inHeader) {
/*      */       if ((paramInt & true) != 0) {
/*      */         this.currentHeaderAlignment = 0;
/*      */       } else if ((paramInt & 0x2) != 0) {
/*      */         this.currentHeaderAlignment = 1;
/*      */       } else if ((paramInt & 0x4) != 0) {
/*      */         this.currentHeaderAlignment = 2;
/*      */       } 
/*      */       return;
/*      */     } 
/*      */     if ((paramInt & true) != 0) {
/*      */       this.writer.print("\\ql ");
/*      */     } else if ((paramInt & 0x2) != 0) {
/*      */       this.writer.print("\\qc ");
/*      */     } else if ((paramInt & 0x4) != 0) {
/*      */       this.writer.print("\\qr ");
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void writeWrapSpace(Insets paramInsets) {
/*      */     if (paramInsets == null)
/*      */       return; 
/*      */     this.writer.print("{\\sp{\\sn dyWrapDistTop}{\\sv " + (paramInsets.top * 12700) + "}}");
/*      */     this.writer.print("{\\sp{\\sn dxWrapDistLeft}{\\sv " + (paramInsets.left * 12700) + "}}");
/*      */     this.writer.print("{\\sp{\\sn dyWrapDistBottom}{\\sv " + (paramInsets.bottom * 12700) + "}}");
/*      */     this.writer.print("{\\sp{\\sn dxWrapDistRight}{\\sv " + (paramInsets.right * 12700) + "}}");
/*      */   }
/*      */   
/*      */   protected void writePainter(Painter paramPainter, Size paramSize, Color paramColor1, Color paramColor2) {
/*      */     Dimension dimension1 = paramPainter.getPreferredSize();
/*      */     Dimension dimension2 = null;
/*      */     if (paramPainter instanceof ScaledPainter)
/*      */       dimension2 = new Dimension((int)((((ScaledPainter)paramPainter).getSize()).width * 1440.0F), (int)((((ScaledPainter)paramPainter).getSize()).width * 1440.0F)); 
/*      */     if (dimension1.width < 0)
/*      */       dimension1.width = (int)(-dimension1.width * 468.0D / 1000.0D); 
/*      */     if (dimension1.height < 0)
/*      */       dimension1.height = (int)(-dimension1.height * 468.0D / 1000.0D); 
/*      */     Image image = Common.createImage(dimension1.width, dimension1.height);
/*      */     Graphics graphics = image.getGraphics();
/*      */     graphics.setColor(paramColor2);
/*      */     graphics.fillRect(0, 0, dimension1.width, dimension1.height);
/*      */     graphics.setColor(paramColor1);
/*      */     paramPainter.paint(graphics, 0, 0, dimension1.width, dimension1.height);
/*      */     graphics.dispose();
/*      */     this.writer.println("{\\pict\\dibitmap0\\wbmbitspixel24\\wbmplanes1\\wbmwidthbytes" + ((int)Math.ceil((dimension1.width * 3) / 2.0D) * 2));
/*      */     this.writer.print("\\picw" + dimension1.width + "\\pich" + dimension1.height);
/*      */     if (paramSize != null && paramSize.width > 0.0F && paramSize.height > 0.0F)
/*      */       this.writer.print("\\picscalex" + (int)(paramSize.width * 100.0F / dimension1.width) + "\\picscaley" + (int)(paramSize.height * 100.0F / dimension1.height)); 
/*      */     if (dimension2 != null)
/*      */       this.writer.print("\\picwgoal" + dimension2.width + "\\pichgoal" + dimension2.height); 
/*      */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*      */     write(byteArrayOutputStream, 40, 4);
/*      */     write(byteArrayOutputStream, dimension1.width, 4);
/*      */     write(byteArrayOutputStream, dimension1.height, 4);
/*      */     write(byteArrayOutputStream, 1, 2);
/*      */     write(byteArrayOutputStream, 24, 2);
/*      */     write(byteArrayOutputStream, 0, 4);
/*      */     write(byteArrayOutputStream, dimension1.width * dimension1.height * 3, 4);
/*      */     write(byteArrayOutputStream, 0, 4);
/*      */     write(byteArrayOutputStream, 0, 4);
/*      */     write(byteArrayOutputStream, 0, 4);
/*      */     write(byteArrayOutputStream, 0, 4);
/*      */     try {
/*      */       byteArrayOutputStream.write(Util.getImageBytesRGB(new PixelConsumer(image), Color.white));
/*      */     } catch (Exception exception) {
/*      */       exception.printStackTrace();
/*      */     } 
/*      */     byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/*      */     StringBuffer stringBuffer = new StringBuffer();
/*      */     for (byte b = 0; b < arrayOfByte.length; b++) {
/*      */       short s = 240;
/*      */       for (byte b1 = 0; b1 < 2; b1++) {
/*      */         byte b2 = (arrayOfByte[b] & s) >> (true - b1) * 4;
/*      */         stringBuffer.append((b2 < 10) ? (char)(48 + b2) : (char)(97 + b2 - 10));
/*      */         s >>= 4;
/*      */       } 
/*      */     } 
/*      */     String str = stringBuffer.toString();
/*      */     for (int i = 0; i < str.length(); i += 80) {
/*      */       try {
/*      */         this.writer.println("");
/*      */         String str1 = str.substring(i, i + Math.min(str.length() - i, 80));
/*      */         this.writer.print(str1);
/*      */       } catch (Exception exception) {
/*      */         exception.printStackTrace();
/*      */       } 
/*      */     } 
/*      */     this.writer.println("}");
/*      */   }
/*      */   
/*      */   protected void write(OutputStream paramOutputStream, int paramInt1, int paramInt2) {
/*      */     int i = 255;
/*      */     for (byte b = 0; b < paramInt2; b++) {
/*      */       try {
/*      */         paramOutputStream.write((paramInt1 & i) >> b * 8);
/*      */       } catch (Exception exception) {
/*      */         exception.printStackTrace();
/*      */       } 
/*      */       i <<= 8;
/*      */     } 
/*      */   }
/*      */   
/*      */   void newline() {
/*      */     if (this.currX != 0.0D) {
/*      */       if (4.0D < this.floatH) {
/*      */         this.writer.print("\\sa0\\f1\\fs8 {");
/*      */         for (byte b = 4; b < this.floatH; b += 4)
/*      */           this.writer.print("\\par "); 
/*      */         this.writer.print("}\\pard");
/*      */       } 
/*      */       this.currX = 0.0D;
/*      */       this.floatH = 0.0D;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Hashtable fontnames = new Hashtable();
/*      */   private static final int EMU = 12700;
/*      */   protected StyleSheet sheet;
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\RTFFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */