/*     */ package inetsoft.report.io;
/*     */ 
/*     */ import inetsoft.report.AreaBreakElement;
/*     */ import inetsoft.report.ChartElement;
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.CompositeElement;
/*     */ import inetsoft.report.CompositeLens;
/*     */ import inetsoft.report.CondPageBreakElement;
/*     */ import inetsoft.report.Context;
/*     */ import inetsoft.report.FormElement;
/*     */ import inetsoft.report.FormLens;
/*     */ import inetsoft.report.HeadingElement;
/*     */ import inetsoft.report.NewlineElement;
/*     */ import inetsoft.report.PageBreakElement;
/*     */ import inetsoft.report.PageLayoutElement;
/*     */ import inetsoft.report.Painter;
/*     */ import inetsoft.report.PainterElement;
/*     */ import inetsoft.report.Presenter;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.SectionBand;
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.SeparatorElement;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.SpaceElement;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TOCElement;
/*     */ import inetsoft.report.TabElement;
/*     */ import inetsoft.report.TableElement;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.TextBoxElement;
/*     */ import inetsoft.report.TextElement;
/*     */ import inetsoft.report.internal.FormElementDef;
/*     */ import inetsoft.report.internal.ImageXElement;
/*     */ import inetsoft.report.internal.PainterElementDef;
/*     */ import inetsoft.report.internal.SectionElementDef;
/*     */ import inetsoft.report.internal.TableElementDef;
/*     */ import inetsoft.report.internal.TextElementDef;
/*     */ import inetsoft.report.internal.Util;
/*     */ import inetsoft.report.painter.ComponentPainter;
/*     */ import inetsoft.report.painter.ImagePainter;
/*     */ import inetsoft.report.painter.PresenterPainter;
/*     */ import inetsoft.report.style.XTableStyle;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.Format;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLFormatter
/*     */   extends BaseFormatter
/*     */ {
/*     */   protected String dir;
/*     */   protected PrintWriter writer;
/*     */   protected OutputStream output;
/*     */   protected Vector leftV;
/*     */   protected Vector centerV;
/*     */   protected Vector rightV;
/*     */   protected int currAlign;
/*     */   protected boolean inHeader;
/*     */   protected String prefix;
/*     */   protected StyleSheet sheet;
/*     */   private static final int PAGEWIDTH = 468;
/*     */   
/*     */   public HTMLFormatter(OutputStream paramOutputStream, String paramString) {
/* 790 */     this.leftV = new Vector();
/* 791 */     this.centerV = new Vector();
/* 792 */     this.rightV = new Vector();
/* 793 */     this.currAlign = 1;
/* 794 */     this.inHeader = false;
/* 795 */     this.prefix = "image";
/* 796 */     this.sheet = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 802 */     fontnames.put("dialog", "Helvetica");
/* 803 */     fontnames.put("dialoginput", "Courier");
/* 804 */     fontnames.put("serif", "Times");
/* 805 */     fontnames.put("sansserif", "Helvetica");
/* 806 */     fontnames.put("monospaced", "Courier");
/* 807 */     fontnames.put("timesroman", "Times");
/* 808 */     fontnames.put("courier", "Courier");
/* 809 */     fontnames.put("helvetica", "Helvetica");
/*     */     this.writer = new PrintWriter(this.output = paramOutputStream);
/*     */     this.dir = paramString;
/*     */   }
/*     */   
/*     */   public void setJPEGPrefix(String paramString) { this.prefix = paramString; }
/*     */   
/*     */   public void prolog(StyleSheet paramStyleSheet) {
/*     */     this.sheet = paramStyleSheet;
/*     */     this.writer.println("<HTML>");
/*     */     this.writer.println("<HEAD>");
/*     */     this.writer.println("<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html\">");
/*     */     this.writer.println("<META NAME=\"Generator\" CONTENT=\"StyleReport\">");
/*     */     this.writer.println("<TITLE>Report</TITLE>");
/*     */     this.writer.println("</HEAD>");
/*     */     this.writer.println("<BODY>");
/*     */   }
/*     */   
/*     */   public void startHeader(int paramInt) { this.inHeader = true; }
/*     */   
/*     */   public void startHeader(String paramString, boolean paramBoolean) { this.inHeader = true; }
/*     */   
/*     */   public void endHeader() { this.inHeader = false; }
/*     */   
/*     */   public void write(XTableStyle paramXTableStyle) {}
/*     */   
/*     */   public void write(HeadingElement paramHeadingElement) { write(paramHeadingElement); }
/*     */   
/*     */   public void write(TextElement paramTextElement) {
/*     */     TextElementDef textElementDef = (TextElementDef)paramTextElement;
/*     */     if (this.inHeader || !textElementDef.isVisible())
/*     */       return; 
/*     */     addElement(textElementDef);
/*     */     if (textElementDef.isLastOnLine())
/*     */       flushElements(); 
/*     */   }
/*     */   
/*     */   public void write(SectionElement paramSectionElement) {
/*     */     SectionElementDef sectionElementDef = (SectionElementDef)paramSectionElement;
/*     */     if (this.inHeader || !sectionElementDef.isVisible())
/*     */       return; 
/*     */     flushElements();
/*     */     writeSection(sectionElementDef);
/*     */   }
/*     */   
/*     */   protected void printBand(SectionBand paramSectionBand) {
/*     */     this.writer.println("<TABLE border=0><TR>");
/*     */     for (byte b = 0; b < paramSectionBand.getElementCount(); b++) {
/*     */       this.writer.print("<TD>");
/*     */       Builder.write(this, paramSectionBand.getElement(b));
/*     */       flushElements();
/*     */       this.writer.println("</TD>");
/*     */     } 
/*     */     this.writer.println("</TR></TABLE>");
/*     */   }
/*     */   
/*     */   public void write(TableElement paramTableElement) {
/*     */     TableElementDef tableElementDef = (TableElementDef)paramTableElement;
/*     */     if (this.inHeader || !tableElementDef.isVisible())
/*     */       return; 
/*     */     flushElements();
/*     */     TableLens tableLens = tableElementDef.getTable();
/*     */     Hashtable hashtable = new Hashtable();
/*     */     byte b1 = 0;
/*     */     for (byte b2 = 0; b2 < tableLens.getRowCount(); b2++) {
/*     */       for (byte b = 0; b < tableLens.getColCount(); b++) {
/*     */         if (tableLens.getRowBorder(b2, b) != 0 || tableLens.getColBorder(b2, b) != 0) {
/*     */           b1 = 1;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     this.writer.print("<TABLE BORDER=" + b1 + " CELLSPACING=0 CELLPADDING=0");
/*     */     if (tableElementDef.getLayout() != 0)
/*     */       this.writer.print(" WIDTH=\"100%\""); 
/*     */     this.writer.println(">");
/*     */     for (byte b3 = 0; b3 < tableLens.getRowCount(); b3++) {
/*     */       this.writer.println("<TR>");
/*     */       String str = "TD";
/*     */       if (b3 < tableLens.getHeaderRowCount())
/*     */         str = "TH"; 
/*     */       for (byte b = 0; b < tableLens.getColCount(); b++) {
/*     */         Dimension dimension = tableLens.getSpan(b3, b);
/*     */         if (dimension != null && dimension.height >= 1) {
/*     */           for (byte b4 = 0; b4 < dimension.height; b4++) {
/*     */             for (byte b5 = 0; b5 < dimension.width; b5++)
/*     */               hashtable.put(new Point(b + b5, b3 + b4), "span"); 
/*     */           } 
/*     */           this.writer.print("<" + str);
/*     */           this.writer.print(" ROWSPAN=" + dimension.height + " COLSPAN=" + dimension.width);
/*     */         } else {
/*     */           if (hashtable.get(new Point(b, b3)) != null)
/*     */             continue; 
/*     */           this.writer.print("<" + str);
/*     */         } 
/*     */         Color color1 = tableLens.getBackground(b3, b);
/*     */         if (color1 != null && color1 != Color.white)
/*     */           this.writer.print(" BGCOLOR=\"#" + toString(color1) + "\""); 
/*     */         int i = tableLens.getAlignment(b3, b);
/*     */         if ((i & 0x8) != 0) {
/*     */           this.writer.print(" VALIGN=TOP");
/*     */         } else if ((i & 0x10) != 0) {
/*     */           this.writer.print(" VALIGN=MIDDLE");
/*     */         } else if ((i & 0x20) != 0) {
/*     */           this.writer.print(" VALIGN=BOTTOM");
/*     */         } 
/*     */         this.writer.print(">");
/*     */         writeAlignment(i);
/*     */         Object object = tableLens.getObject(b3, b);
/*     */         Color color2 = tableLens.getForeground(b3, b);
/*     */         if (object != null) {
/*     */           Presenter presenter = tableElementDef.getPresenter(object.getClass());
/*     */           if (presenter != null) {
/*     */             object = new PresenterPainter(object, presenter);
/*     */           } else {
/*     */             Format format = tableElementDef.getFormat(object.getClass());
/*     */             if (format != null)
/*     */               object = format.format(object); 
/*     */           } 
/*     */         } 
/*     */         if (object instanceof Component) {
/*     */           writePainter(new ComponentPainter((Component)object), null, color2, color1, i, null, null);
/*     */         } else if (object instanceof Image) {
/*     */           writePainter(new ImagePainter((Image)object), null, color2, color1, i, null, null);
/*     */         } else if (object instanceof Painter) {
/*     */           writePainter((Painter)object, null, color2, color1, i, null, null);
/*     */         } else if (object != null) {
/*     */           writeText(object, tableLens.getFont(b3, b), color2, null);
/*     */         } 
/*     */         this.writer.println("</" + str + ">");
/*     */         continue;
/*     */       } 
/*     */       this.writer.println("</TR>");
/*     */     } 
/*     */     this.writer.println("</TABLE>");
/*     */   }
/*     */   
/*     */   public void write(FormElement paramFormElement) {
/*     */     FormElementDef formElementDef = (FormElementDef)paramFormElement;
/*     */     if (this.inHeader || !formElementDef.isVisible())
/*     */       return; 
/*     */     flushElements();
/*     */     FormLens formLens = formElementDef.getForm();
/*     */     int i = formLens.getFieldPerRow();
/*     */     this.writer.println("<TABLE BORDER=0 COLS=" + (i * 2) + " WIDTH=\"100%\">");
/*     */     for (int j = 0; j < formLens.getFieldCount(); j++) {
/*     */       if (j % i == 0) {
/*     */         if (j > 0)
/*     */           this.writer.println("</TR>"); 
/*     */         this.writer.println("<TR>");
/*     */       } 
/*     */       this.writer.println("<TD>");
/*     */       writeAlignment(4);
/*     */       writeText(formLens.getLabel(j), formLens.getLabelFont(j), formLens.getLabelForeground(j), formLens.getLabelBackground(j));
/*     */       this.writer.println("</TD>");
/*     */       this.writer.println("<TD><U>");
/*     */       writeAlignment(1);
/*     */       writeText(formLens.getField(j), formLens.getFont(j), formLens.getForeground(j), formLens.getBackground(j));
/*     */       this.writer.println("</U></TD>");
/*     */     } 
/*     */     this.writer.println("</TABLE>");
/*     */   }
/*     */   
/*     */   public void write(PainterElement paramPainterElement) {
/*     */     PainterElementDef painterElementDef = (PainterElementDef)paramPainterElement;
/*     */     if (this.inHeader || !painterElementDef.isVisible())
/*     */       return; 
/*     */     if (painterElementDef.isNewline())
/*     */       flushElements(); 
/*     */     addElement(painterElementDef);
/*     */     if (painterElementDef.isLastOnLine())
/*     */       flushElements(); 
/*     */   }
/*     */   
/*     */   private void writePainter(PainterElement paramPainterElement) {
/*     */     PainterElementDef painterElementDef = (PainterElementDef)paramPainterElement;
/*     */     String str = null;
/*     */     if (painterElementDef instanceof ImageXElement && ((ImageXElement)painterElementDef).getPathType() == 4)
/*     */       str = ((ImageXElement)painterElementDef).getPath(); 
/*     */     Painter painter = painterElementDef.getPainter();
/*     */     Size size = painterElementDef.getPreferredSize();
/*     */     Dimension dimension = new Dimension((int)size.width, (int)size.height);
/*     */     writePainter(painter, str, painterElementDef.getForeground(), painterElementDef.getBackground(), painterElementDef.getAlignment(), painterElementDef.getMargin(), dimension);
/*     */   }
/*     */   
/*     */   public void write(ChartElement paramChartElement) { write(paramChartElement); }
/*     */   
/*     */   public void write(TextBoxElement paramTextBoxElement) { write(paramTextBoxElement); }
/*     */   
/*     */   public void write(TabElement paramTabElement) {
/*     */     if (this.inHeader || !paramTabElement.isVisible())
/*     */       return; 
/*     */     addElement(paramTabElement);
/*     */   }
/*     */   
/*     */   public void write(NewlineElement paramNewlineElement) {
/*     */     if (this.inHeader || !paramNewlineElement.isVisible())
/*     */       return; 
/*     */     flushElements();
/*     */     for (byte b = 1; b < paramNewlineElement.getCount(); b++)
/*     */       this.writer.println("<P>"); 
/*     */   }
/*     */   
/*     */   public void write(AreaBreakElement paramAreaBreakElement) { flushElements(); }
/*     */   
/*     */   public void write(PageBreakElement paramPageBreakElement) { flushElements(); }
/*     */   
/*     */   public void write(PageLayoutElement paramPageLayoutElement) { flushElements(); }
/*     */   
/*     */   public void write(CondPageBreakElement paramCondPageBreakElement) { flushElements(); }
/*     */   
/*     */   public void write(SpaceElement paramSpaceElement) {
/*     */     if (this.inHeader || !paramSpaceElement.isVisible())
/*     */       return; 
/*     */     addElement(paramSpaceElement);
/*     */   }
/*     */   
/*     */   private void writeSpace(int paramInt) { this.writer.println("<SPACER TYPE=HORIZONTAL SIZE=" + paramInt + ">"); }
/*     */   
/*     */   public void write(SeparatorElement paramSeparatorElement) {
/*     */     if (this.inHeader || !paramSeparatorElement.isVisible())
/*     */       return; 
/*     */     flushElements();
/*     */     this.writer.println("<HR>");
/*     */   }
/*     */   
/*     */   public void write(TOCElement paramTOCElement) {}
/*     */   
/*     */   public void write(CompositeElement paramCompositeElement) {
/*     */     Context context = new Context(this.sheet);
/*     */     CompositeLens compositeLens = paramCompositeElement.getComposite();
/*     */     compositeLens.reset();
/*     */     Object object;
/*     */     for (; (object = compositeLens.nextElement(context)) != null; context = new Context(this.sheet)) {
/*     */       ReportElement reportElement = null;
/*     */       if (object instanceof ReportElement) {
/*     */         reportElement = (ReportElement)object;
/*     */       } else {
/*     */         reportElement = this.sheet.getCompositeElement(paramCompositeElement.getID(), object, context);
/*     */       } 
/*     */       if (reportElement != null) {
/*     */         reportElement.setContext(context);
/*     */         Builder.write(this, reportElement);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void end() {
/*     */     flushElements();
/*     */     this.writer.println("</BODY>");
/*     */     this.writer.println("</HTML>");
/*     */     this.writer.flush();
/*     */   }
/*     */   
/*     */   protected String getFontName(Font paramFont) {
/*     */     String str = paramFont.getName();
/*     */     Object object = fontnames.get(str.toLowerCase());
/*     */     return (object == null) ? str : object.toString();
/*     */   }
/*     */   
/*     */   protected void writeText(Object paramObject, Font paramFont, Color paramColor1, Color paramColor2) {
/*     */     if (paramObject == null)
/*     */       return; 
/*     */     String str1 = "";
/*     */     String str2 = paramObject.toString();
/*     */     if (paramFont != null || paramColor1 != null) {
/*     */       this.writer.print("<FONT ");
/*     */       if (paramColor1 != null)
/*     */         this.writer.print("COLOR=\"#" + toString(paramColor1) + "\" "); 
/*     */       if (paramFont != null) {
/*     */         this.writer.print("FACE=\"" + getFontName(paramFont) + "\">");
/*     */         str1 = "</FONT>" + str1;
/*     */         this.writer.print("<SPAN STYLE=\"Font-Size: " + paramFont.getSize() + "pt\"");
/*     */         if (paramColor2 != null)
/*     */           this.writer.print("; Background-Color: \"#" + toString(paramColor2) + "\""); 
/*     */         this.writer.print(">");
/*     */         str1 = "</SPAN>" + str1;
/*     */         if ((paramFont.getStyle() & true) != 0) {
/*     */           this.writer.print("<B>");
/*     */           str1 = "</B>" + str1;
/*     */         } 
/*     */         if ((paramFont.getStyle() & 0x2) != 0) {
/*     */           this.writer.print("<I>");
/*     */           str1 = "</I>" + str1;
/*     */         } 
/*     */         if ((paramFont.getStyle() & 0x10) != 0) {
/*     */           this.writer.print("<U>");
/*     */           str1 = "</U>" + str1;
/*     */         } 
/*     */         if ((paramFont.getStyle() & 0x20) != 0) {
/*     */           this.writer.print("<STRIKE>");
/*     */           str1 = "</STRIKE>" + str1;
/*     */         } 
/*     */         if ((paramFont.getStyle() & 0x40) != 0) {
/*     */           this.writer.print("<SUP>");
/*     */           str1 = "</SUP>" + str1;
/*     */         } 
/*     */         if ((paramFont.getStyle() & 0x80) != 0) {
/*     */           this.writer.print("<SUB>");
/*     */           str1 = "</SUB>" + str1;
/*     */         } 
/*     */         if ((paramFont.getStyle() & 0x200) != 0 || (paramFont.getStyle() & 0x400) != 0)
/*     */           str2 = str2.toUpperCase(); 
/*     */       } else {
/*     */         this.writer.print(">");
/*     */       } 
/*     */     } 
/*     */     if (str2.length() == 0) {
/*     */       str2 = "&nbsp;";
/*     */     } else {
/*     */       str2 = Util.replace(str2, "\n", "<br>");
/*     */     } 
/*     */     this.writer.println(str2 + str1);
/*     */   }
/*     */   
/*     */   protected void writeAlignment(int paramInt) {
/*     */     if ((paramInt & true) != 0) {
/*     */       this.writer.print("<P ALIGN=LEFT>");
/*     */     } else if ((paramInt & 0x2) != 0) {
/*     */       this.writer.print("<P ALIGN=CENTER>");
/*     */     } else if ((paramInt & 0x4) != 0) {
/*     */       this.writer.print("<P ALIGN=RIGHT>");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void writePainter(Painter paramPainter, String paramString, Color paramColor1, Color paramColor2, int paramInt, Insets paramInsets, Dimension paramDimension) {
/*     */     Dimension dimension = paramPainter.getPreferredSize();
/*     */     if (paramDimension == null || paramDimension.width == 0 || paramDimension.height == 0)
/*     */       paramDimension = dimension; 
/*     */     if (paramString != null) {
/*     */       this.writer.print("<IMG SRC=\"" + paramString + "\"");
/*     */     } else {
/*     */       String str = writeImage(paramPainter, dimension, paramColor1, paramColor2);
/*     */       this.writer.print("<IMG SRC=\"" + str + "\"");
/*     */     } 
/*     */     if (paramDimension != null)
/*     */       this.writer.print(" WIDTH=" + paramDimension.width + " HEIGHT=" + paramDimension.height); 
/*     */     if ((paramInt & 0x8) != 0) {
/*     */       this.writer.print(" ALIGN=TOP");
/*     */     } else if ((paramInt & 0x10) != 0) {
/*     */       this.writer.print(" ALIGN=MIDDLE");
/*     */     } else if ((paramInt & 0x20) != 0) {
/*     */       this.writer.print(" ALIGN=BOTTOM");
/*     */     } 
/*     */     if (paramInsets != null)
/*     */       this.writer.print(" HSPACE=" + Math.max(paramInsets.left, paramInsets.right) + " VSPACE=" + Math.max(paramInsets.top, paramInsets.bottom)); 
/*     */     this.writer.println(">");
/*     */   }
/*     */   
/*     */   protected String writeImage(Painter paramPainter, Dimension paramDimension, Color paramColor1, Color paramColor2) {
/*     */     if (paramDimension.width < 0)
/*     */       paramDimension.width = -paramDimension.width * 468 / 1000; 
/*     */     if (paramDimension.height < 0)
/*     */       paramDimension.height = -paramDimension.height * 468 / 1000; 
/*     */     Image image = Common.createImage(paramDimension.width, paramDimension.height);
/*     */     Graphics graphics = image.getGraphics();
/*     */     graphics.setColor(paramColor1);
/*     */     paramPainter.paint(graphics, 0, 0, paramDimension.width, paramDimension.height);
/*     */     graphics.dispose();
/*     */     String str = null;
/*     */     File file = null;
/*     */     for (byte b = 1;; b++) {
/*     */       str = this.prefix + b + ".jpg";
/*     */       file = new File(this.dir, str);
/*     */       if (!file.exists())
/*     */         break; 
/*     */     } 
/*     */     try {
/*     */       FileOutputStream fileOutputStream = new FileOutputStream(file);
/*     */       Common.writeJPEG(image, fileOutputStream);
/*     */       fileOutputStream.close();
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */     } 
/*     */     return str;
/*     */   }
/*     */   
/*     */   protected String toString(Color paramColor) {
/*     */     String str = "000000" + Integer.toString(paramColor.getRGB() & 0xFFFFFF, 16);
/*     */     return str.substring(str.length() - 6);
/*     */   }
/*     */   
/*     */   protected void addElement(ReportElement paramReportElement) {
/*     */     int i = paramReportElement.getAlignment() & 0x7;
/*     */     if (i < this.currAlign) {
/*     */       flushElements();
/*     */       addElement(paramReportElement);
/*     */       return;
/*     */     } 
/*     */     this.currAlign = i;
/*     */     switch (i) {
/*     */       case 1:
/*     */         this.leftV.addElement(paramReportElement);
/*     */         break;
/*     */       case 2:
/*     */         this.centerV.addElement(paramReportElement);
/*     */         break;
/*     */       case 4:
/*     */         this.rightV.addElement(paramReportElement);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void flushElements() {
/*     */     if (this.centerV.size() == 0 && this.rightV.size() == 0) {
/*     */       writeParagraph(this.leftV, 1);
/*     */     } else {
/*     */       this.writer.println("<TABLE BORDER=0 WIDTH=\"100%\"><TR>");
/*     */       this.writer.println("<TD>");
/*     */       writeParagraph(this.leftV, 1);
/*     */       this.writer.println("</TD>");
/*     */       this.writer.println("<TD>");
/*     */       writeParagraph(this.centerV, 2);
/*     */       this.writer.println("</TD>");
/*     */       this.writer.println("<TD>");
/*     */       writeParagraph(this.rightV, 4);
/*     */       this.writer.println("</TD>");
/*     */       this.writer.println("</TR></TABLE>");
/*     */     } 
/*     */     this.leftV.removeAllElements();
/*     */     this.centerV.removeAllElements();
/*     */     this.rightV.removeAllElements();
/*     */     this.currAlign = 1;
/*     */   }
/*     */   
/*     */   protected void writeParagraph(Vector paramVector, int paramInt) {
/*     */     int i = 0;
/*     */     writeAlignment(paramInt);
/*     */     for (byte b = 0; b < paramVector.size(); b++) {
/*     */       ReportElement reportElement = (ReportElement)paramVector.elementAt(b);
/*     */       if (reportElement instanceof TextElement) {
/*     */         TextElement textElement = (TextElement)reportElement;
/*     */         writeText(textElement.getText(), textElement.getFont(), textElement.getForeground(), textElement.getBackground());
/*     */         i += (int)Common.stringWidth(textElement.getText(), textElement.getFont());
/*     */       } else if (reportElement instanceof PainterElement) {
/*     */         writePainter((PainterElement)reportElement);
/*     */         i += (int)(((PainterElementDef)reportElement).getPreferredSize()).width;
/*     */       } else if (reportElement instanceof TabElement) {
/*     */         double[] arrayOfDouble = ((TabElement)reportElement).getTabStops();
/*     */         int j = 0;
/*     */         for (byte b1 = 0; b1 < arrayOfDouble.length; b1++) {
/*     */           j = (int)(arrayOfDouble[b1] * 72.0D);
/*     */           if (i < j)
/*     */             break; 
/*     */         } 
/*     */         writeSpace(j - i);
/*     */       } else if (reportElement instanceof SpaceElement) {
/*     */         int j = ((SpaceElement)reportElement).getSpace();
/*     */         writeSpace(j);
/*     */         i += j;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Hashtable fontnames = new Hashtable();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\HTMLFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */