/*     */ package inetsoft.report.io;
/*     */ 
/*     */ import inetsoft.report.AreaBreakElement;
/*     */ import inetsoft.report.ChartElement;
/*     */ import inetsoft.report.CompositeElement;
/*     */ import inetsoft.report.CompositeLens;
/*     */ import inetsoft.report.CondPageBreakElement;
/*     */ import inetsoft.report.Context;
/*     */ import inetsoft.report.FormElement;
/*     */ import inetsoft.report.HeadingElement;
/*     */ import inetsoft.report.NewlineElement;
/*     */ import inetsoft.report.PageBreakElement;
/*     */ import inetsoft.report.PageLayoutElement;
/*     */ import inetsoft.report.PainterElement;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.SeparatorElement;
/*     */ import inetsoft.report.SpaceElement;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TOCElement;
/*     */ import inetsoft.report.TabElement;
/*     */ import inetsoft.report.TableElement;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.TextBoxElement;
/*     */ import inetsoft.report.TextElement;
/*     */ import inetsoft.report.style.XTableStyle;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.text.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelimitedFormatter
/*     */   implements Formatter
/*     */ {
/*     */   protected PrintWriter writer;
/*     */   protected OutputStream output;
/*     */   protected String delim;
/*     */   protected String quote;
/*     */   protected StyleSheet sheet;
/*     */   
/*     */   public DelimitedFormatter(OutputStream paramOutputStream) {
/* 311 */     this.delim = ",";
/* 312 */     this.quote = null;
/*     */     this.writer = new PrintWriter(this.output = paramOutputStream);
/*     */     String str = ReportEnv.getProperty("export.csv.delimiter");
/*     */     if (str != null)
/*     */       this.delim = str; 
/*     */     str = ReportEnv.getProperty("export.csv.quote");
/*     */     if (str != null)
/*     */       this.quote = str; 
/*     */   }
/*     */   
/*     */   public void setDelimiter(String paramString) { this.delim = paramString; }
/*     */   
/*     */   public String getDelimiter() { return this.delim; }
/*     */   
/*     */   public void setQuote(String paramString) { this.quote = paramString; }
/*     */   
/*     */   public String getQuote() { return this.quote; }
/*     */   
/*     */   public void prolog(StyleSheet paramStyleSheet) { this.sheet = paramStyleSheet; }
/*     */   
/*     */   public void startHeader(int paramInt) {}
/*     */   
/*     */   public void startHeader(String paramString, boolean paramBoolean) {}
/*     */   
/*     */   public void endHeader() {}
/*     */   
/*     */   public void write(XTableStyle paramXTableStyle) {}
/*     */   
/*     */   public void write(HeadingElement paramHeadingElement) {}
/*     */   
/*     */   public void write(TextElement paramTextElement) {}
/*     */   
/*     */   public void write(SectionElement paramSectionElement) {
/*     */     if (!paramSectionElement.isVisible())
/*     */       return; 
/*     */     TableLens tableLens = paramSectionElement.getTable();
/*     */     for (byte b = 0; b < tableLens.getRowCount(); b++) {
/*     */       for (byte b1 = 0; b1 < tableLens.getColCount(); b1++) {
/*     */         if (b1)
/*     */           this.writer.print(this.delim); 
/*     */         Object object = tableLens.getObject(b, b1);
/*     */         if (object == null)
/*     */           object = ""; 
/*     */         Format format = paramSectionElement.getFormat(object.getClass());
/*     */         if (format != null)
/*     */           object = format.format(object); 
/*     */         this.writer.print(((this.quote != null) ? this.quote : "") + object.toString() + ((this.quote != null) ? this.quote : ""));
/*     */       } 
/*     */       this.writer.println("");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write(TableElement paramTableElement) {
/*     */     if (!paramTableElement.isVisible())
/*     */       return; 
/*     */     TableLens tableLens = paramTableElement.getTable();
/*     */     for (byte b = 0; b < tableLens.getRowCount(); b++) {
/*     */       for (byte b1 = 0; b1 < tableLens.getColCount(); b1++) {
/*     */         if (b1)
/*     */           this.writer.print(this.delim); 
/*     */         Object object = tableLens.getObject(b, b1);
/*     */         if (object == null)
/*     */           object = ""; 
/*     */         Format format = paramTableElement.getFormat(object.getClass());
/*     */         if (format != null)
/*     */           object = format.format(object); 
/*     */         this.writer.print(((this.quote != null) ? this.quote : "") + object.toString() + ((this.quote != null) ? this.quote : ""));
/*     */       } 
/*     */       this.writer.println("");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write(FormElement paramFormElement) { write(paramFormElement); }
/*     */   
/*     */   public void write(PainterElement paramPainterElement) {}
/*     */   
/*     */   public void write(ChartElement paramChartElement) {}
/*     */   
/*     */   public void write(TextBoxElement paramTextBoxElement) {}
/*     */   
/*     */   public void write(TabElement paramTabElement) {}
/*     */   
/*     */   public void write(NewlineElement paramNewlineElement) {}
/*     */   
/*     */   public void write(AreaBreakElement paramAreaBreakElement) {}
/*     */   
/*     */   public void write(PageBreakElement paramPageBreakElement) {}
/*     */   
/*     */   public void write(PageLayoutElement paramPageLayoutElement) {}
/*     */   
/*     */   public void write(CondPageBreakElement paramCondPageBreakElement) {}
/*     */   
/*     */   public void write(SpaceElement paramSpaceElement) {}
/*     */   
/*     */   public void write(SeparatorElement paramSeparatorElement) {}
/*     */   
/*     */   public void write(TOCElement paramTOCElement) {}
/*     */   
/*     */   public void write(CompositeElement paramCompositeElement) {
/*     */     Context context = new Context(this.sheet);
/*     */     CompositeLens compositeLens = paramCompositeElement.getComposite();
/*     */     compositeLens.reset();
/*     */     Object object;
/*     */     for (; (object = compositeLens.nextElement(context)) != null; context = new Context(this.sheet)) {
/*     */       ReportElement reportElement = this.sheet.getCompositeElement(paramCompositeElement.getID(), object, context);
/*     */       if (reportElement != null) {
/*     */         reportElement.setContext(context);
/*     */         Builder.write(this, reportElement);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void end() { this.writer.flush(); }
/*     */   
/*     */   protected static String toString(Object paramObject) { return (paramObject == null) ? "" : paramObject.toString(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\DelimitedFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */