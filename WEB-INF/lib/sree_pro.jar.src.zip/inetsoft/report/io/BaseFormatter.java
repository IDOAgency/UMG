/*     */ package inetsoft.report.io;
/*     */ 
/*     */ import inetsoft.report.AreaBreakElement;
/*     */ import inetsoft.report.ChartElement;
/*     */ import inetsoft.report.CompositeElement;
/*     */ import inetsoft.report.CondPageBreakElement;
/*     */ import inetsoft.report.FormElement;
/*     */ import inetsoft.report.HeadingElement;
/*     */ import inetsoft.report.NewlineElement;
/*     */ import inetsoft.report.PageBreakElement;
/*     */ import inetsoft.report.PageLayoutElement;
/*     */ import inetsoft.report.PainterElement;
/*     */ import inetsoft.report.SectionBand;
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.SectionLens;
/*     */ import inetsoft.report.SeparatorElement;
/*     */ import inetsoft.report.SpaceElement;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TOCElement;
/*     */ import inetsoft.report.TabElement;
/*     */ import inetsoft.report.TableElement;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.TextBoxElement;
/*     */ import inetsoft.report.TextElement;
/*     */ import inetsoft.report.filter.GroupFilter;
/*     */ import inetsoft.report.internal.SectionElementDef;
/*     */ import inetsoft.report.style.XTableStyle;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseFormatter
/*     */   implements Formatter
/*     */ {
/*     */   protected void writeSection(SectionElementDef paramSectionElementDef) {
/*  36 */     TableLens tableLens = paramSectionElementDef.getTable();
/*  37 */     Hashtable hashtable = new Hashtable();
/*  38 */     SectionLens sectionLens = paramSectionElementDef.getSection();
/*     */ 
/*     */     
/*  41 */     if (sectionLens == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  46 */     boolean bool = (sectionLens.getSectionContent() instanceof SectionLens && tableLens instanceof GroupFilter) ? 1 : 0;
/*     */ 
/*     */     
/*  49 */     SectionBand sectionBand1 = sectionLens.getSectionFooter();
/*  50 */     byte b = 1;
/*  51 */     int i = 0;
/*  52 */     int j = 0;
/*     */ 
/*     */     
/*  55 */     if (tableLens != null) {
/*  56 */       for (byte b1 = 0; b1 < tableLens.getColCount(); b1++) {
/*  57 */         Object object = tableLens.getObject(0, b1);
/*  58 */         hashtable.put((object == null) ? Integer.toString(b1) : object, new Integer(b1));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  63 */     SectionBand sectionBand2 = sectionLens.getSectionHeader();
/*     */     
/*  65 */     if (sectionBand2 != null && sectionBand2.isVisible()) {
/*  66 */       if (tableLens != null) {
/*  67 */         paramSectionElementDef.bind(sectionBand2, tableLens, (b < tableLens.getRowCount()) ? b : (b - true), hashtable);
/*     */       }
/*     */ 
/*     */       
/*  71 */       printBand(sectionBand2);
/*     */     } 
/*     */     
/*  74 */     if (bool) {
/*  75 */       GroupFilter groupFilter = (GroupFilter)tableLens;
/*     */       
/*  77 */       groupFilter.setAddGroupHeader(true);
/*  78 */       groupFilter.setGroupHeaderStyle(4098);
/*     */       
/*  80 */       int k = groupFilter.hasGrandSummary() ? 1 : 0;
/*  81 */       int m = groupFilter.getGroupColCount();
/*     */       
/*  83 */       while (b < groupFilter.getRowCount() - k) {
/*  84 */         boolean bool1 = false;
/*  85 */         boolean bool2 = false;
/*     */ 
/*     */         
/*  88 */         if (groupFilter.isGroupHeaderCell(b, groupFilter.getGroupColCount() - 1)) {
/*  89 */           int n = groupFilter.getGroupLevel(b) + 1;
/*     */ 
/*     */           
/*  92 */           if (i < m) {
/*     */ 
/*     */             
/*  95 */             if (n < j) {
/*     */               
/*  97 */               bool2 = true;
/*     */             } else {
/*     */               
/* 100 */               bool1 = true;
/*     */             } 
/*     */           } else {
/*     */             
/* 104 */             i = n;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 109 */         if (bool1) {
/* 110 */           SectionLens sectionLens1 = paramSectionElementDef.getSection(sectionLens, i + 1);
/* 111 */           sectionBand2 = sectionLens1.getSectionHeader();
/*     */           
/* 113 */           if (sectionBand2 != null && sectionBand2.isVisible()) {
/* 114 */             paramSectionElementDef.bind(sectionBand2, groupFilter, b, hashtable);
/* 115 */             printBand(sectionBand2);
/*     */           } 
/*     */           
/* 118 */           i++;
/* 119 */           j = Math.max(i, j);
/*     */ 
/*     */           
/* 122 */           if (groupFilter.isGroupHeaderRow(b)) {
/* 123 */             b++;
/*     */           }
/*     */           continue;
/*     */         } 
/* 127 */         if (bool2 || groupFilter.isSummaryRow(b)) {
/* 128 */           SectionLens sectionLens1 = paramSectionElementDef.getSection(sectionLens, j);
/* 129 */           sectionBand2 = sectionLens1.getSectionFooter();
/*     */           
/* 131 */           if (sectionBand2 != null && sectionBand2.isVisible()) {
/* 132 */             paramSectionElementDef.bind(sectionBand2, groupFilter, b, hashtable);
/* 133 */             printBand(sectionBand2);
/*     */           } 
/*     */           
/* 136 */           j--;
/*     */ 
/*     */           
/* 139 */           if (!bool2) {
/* 140 */             b++;
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 145 */         sectionBand2 = paramSectionElementDef.getSectionBand(sectionLens);
/* 146 */         j = m;
/*     */         
/* 148 */         if (sectionBand2 != null && sectionBand2.isVisible()) {
/* 149 */           paramSectionElementDef.bind(sectionBand2, groupFilter, b, hashtable);
/* 150 */           printBand(sectionBand2);
/*     */         } 
/*     */ 
/*     */         
/* 154 */         b++;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 159 */       if (k > 0 && b == groupFilter.getRowCount() - 1) {
/* 160 */         paramSectionElementDef.bind(sectionBand1, groupFilter, b, hashtable);
/*     */       }
/*     */     }
/* 163 */     else if (sectionLens.getSectionContent() instanceof SectionBand) {
/* 164 */       sectionBand2 = (SectionBand)sectionLens.getSectionContent();
/*     */ 
/*     */ 
/*     */       
/* 168 */       while ((tableLens == null && b <= 1) || (tableLens != null && b < tableLens.getRowCount())) {
/* 169 */         if (sectionBand2.isVisible()) {
/* 170 */           if (tableLens != null) {
/* 171 */             paramSectionElementDef.bind(sectionBand2, tableLens, b, hashtable);
/*     */           }
/*     */           
/* 174 */           printBand(sectionBand2);
/*     */         } 
/*     */         
/* 177 */         b++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 182 */     for (; j > 0; j--) {
/* 183 */       SectionLens sectionLens1 = paramSectionElementDef.getSection(sectionLens, j);
/* 184 */       sectionBand2 = sectionLens1.getSectionFooter();
/*     */       
/* 186 */       if (sectionBand2 != null && sectionBand2.isVisible()) {
/* 187 */         printBand(sectionBand2);
/*     */       }
/*     */       
/* 190 */       j--;
/*     */     } 
/*     */ 
/*     */     
/* 194 */     if (sectionBand1 != null && sectionBand1.isVisible())
/* 195 */       printBand(sectionBand1); 
/*     */   }
/*     */   
/*     */   protected abstract void printBand(SectionBand paramSectionBand);
/*     */   
/*     */   public abstract void end();
/*     */   
/*     */   public abstract void write(CompositeElement paramCompositeElement);
/*     */   
/*     */   public abstract void write(TOCElement paramTOCElement);
/*     */   
/*     */   public abstract void write(SeparatorElement paramSeparatorElement);
/*     */   
/*     */   public abstract void write(SpaceElement paramSpaceElement);
/*     */   
/*     */   public abstract void write(CondPageBreakElement paramCondPageBreakElement);
/*     */   
/*     */   public abstract void write(PageLayoutElement paramPageLayoutElement);
/*     */   
/*     */   public abstract void write(PageBreakElement paramPageBreakElement);
/*     */   
/*     */   public abstract void write(AreaBreakElement paramAreaBreakElement);
/*     */   
/*     */   public abstract void write(NewlineElement paramNewlineElement);
/*     */   
/*     */   public abstract void write(TabElement paramTabElement);
/*     */   
/*     */   public abstract void write(TextBoxElement paramTextBoxElement);
/*     */   
/*     */   public abstract void write(ChartElement paramChartElement);
/*     */   
/*     */   public abstract void write(PainterElement paramPainterElement);
/*     */   
/*     */   public abstract void write(FormElement paramFormElement);
/*     */   
/*     */   public abstract void write(SectionElement paramSectionElement);
/*     */   
/*     */   public abstract void write(TableElement paramTableElement);
/*     */   
/*     */   public abstract void write(HeadingElement paramHeadingElement);
/*     */   
/*     */   public abstract void write(TextElement paramTextElement);
/*     */   
/*     */   public abstract void write(XTableStyle paramXTableStyle);
/*     */   
/*     */   public abstract void endHeader();
/*     */   
/*     */   public abstract void startHeader(String paramString, boolean paramBoolean);
/*     */   
/*     */   public abstract void startHeader(int paramInt);
/*     */   
/*     */   public abstract void prolog(StyleSheet paramStyleSheet);
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\BaseFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */