package inetsoft.report.io;

import inetsoft.report.AreaBreakElement;
import inetsoft.report.ChartElement;
import inetsoft.report.CompositeElement;
import inetsoft.report.CondPageBreakElement;
import inetsoft.report.FormElement;
import inetsoft.report.HeadingElement;
import inetsoft.report.NewlineElement;
import inetsoft.report.PageBreakElement;
import inetsoft.report.PageLayoutElement;
import inetsoft.report.PainterElement;
import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.SectionLens;
import inetsoft.report.SeparatorElement;
import inetsoft.report.SpaceElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.TOCElement;
import inetsoft.report.TabElement;
import inetsoft.report.TableElement;
import inetsoft.report.TableLens;
import inetsoft.report.TextBoxElement;
import inetsoft.report.TextElement;
import inetsoft.report.filter.GroupFilter;
import inetsoft.report.internal.SectionElementDef;
import inetsoft.report.style.XTableStyle;
import java.util.Hashtable;

public abstract class BaseFormatter implements Formatter {
  protected void writeSection(SectionElementDef paramSectionElementDef) {
    TableLens tableLens = paramSectionElementDef.getTable();
    Hashtable hashtable = new Hashtable();
    SectionLens sectionLens = paramSectionElementDef.getSection();
    if (sectionLens == null)
      return; 
    boolean bool = (sectionLens.getSectionContent() instanceof SectionLens && tableLens instanceof GroupFilter) ? 1 : 0;
    SectionBand sectionBand1 = sectionLens.getSectionFooter();
    byte b = 1;
    int i = 0;
    int j = 0;
    if (tableLens != null)
      for (byte b1 = 0; b1 < tableLens.getColCount(); b1++) {
        Object object = tableLens.getObject(0, b1);
        hashtable.put((object == null) ? Integer.toString(b1) : object, new Integer(b1));
      }  
    SectionBand sectionBand2 = sectionLens.getSectionHeader();
    if (sectionBand2 != null && sectionBand2.isVisible()) {
      if (tableLens != null)
        paramSectionElementDef.bind(sectionBand2, tableLens, (b < tableLens.getRowCount()) ? b : (b - true), hashtable); 
      printBand(sectionBand2);
    } 
    if (bool) {
      GroupFilter groupFilter = (GroupFilter)tableLens;
      groupFilter.setAddGroupHeader(true);
      groupFilter.setGroupHeaderStyle(4098);
      int k = groupFilter.hasGrandSummary() ? 1 : 0;
      int m = groupFilter.getGroupColCount();
      while (b < groupFilter.getRowCount() - k) {
        boolean bool1 = false;
        boolean bool2 = false;
        if (groupFilter.isGroupHeaderCell(b, groupFilter.getGroupColCount() - 1)) {
          int n = groupFilter.getGroupLevel(b) + 1;
          if (i < m) {
            if (n < j) {
              bool2 = true;
            } else {
              bool1 = true;
            } 
          } else {
            i = n;
          } 
        } 
        if (bool1) {
          SectionLens sectionLens1 = paramSectionElementDef.getSection(sectionLens, i + 1);
          sectionBand2 = sectionLens1.getSectionHeader();
          if (sectionBand2 != null && sectionBand2.isVisible()) {
            paramSectionElementDef.bind(sectionBand2, groupFilter, b, hashtable);
            printBand(sectionBand2);
          } 
          i++;
          j = Math.max(i, j);
          if (groupFilter.isGroupHeaderRow(b))
            b++; 
          continue;
        } 
        if (bool2 || groupFilter.isSummaryRow(b)) {
          SectionLens sectionLens1 = paramSectionElementDef.getSection(sectionLens, j);
          sectionBand2 = sectionLens1.getSectionFooter();
          if (sectionBand2 != null && sectionBand2.isVisible()) {
            paramSectionElementDef.bind(sectionBand2, groupFilter, b, hashtable);
            printBand(sectionBand2);
          } 
          j--;
          if (!bool2)
            b++; 
          continue;
        } 
        sectionBand2 = paramSectionElementDef.getSectionBand(sectionLens);
        j = m;
        if (sectionBand2 != null && sectionBand2.isVisible()) {
          paramSectionElementDef.bind(sectionBand2, groupFilter, b, hashtable);
          printBand(sectionBand2);
        } 
        b++;
      } 
      if (k > 0 && b == groupFilter.getRowCount() - 1)
        paramSectionElementDef.bind(sectionBand1, groupFilter, b, hashtable); 
    } else if (sectionLens.getSectionContent() instanceof SectionBand) {
      sectionBand2 = (SectionBand)sectionLens.getSectionContent();
      while ((tableLens == null && b <= 1) || (tableLens != null && b < tableLens.getRowCount())) {
        if (sectionBand2.isVisible()) {
          if (tableLens != null)
            paramSectionElementDef.bind(sectionBand2, tableLens, b, hashtable); 
          printBand(sectionBand2);
        } 
        b++;
      } 
    } 
    for (; j > 0; j--) {
      SectionLens sectionLens1 = paramSectionElementDef.getSection(sectionLens, j);
      sectionBand2 = sectionLens1.getSectionFooter();
      if (sectionBand2 != null && sectionBand2.isVisible())
        printBand(sectionBand2); 
      j--;
    } 
    if (sectionBand1 != null && sectionBand1.isVisible())
      printBand(sectionBand1); 
  }
  
  protected abstract void printBand(SectionBand paramSectionBand);
  
  public abstract void end();
  
  public abstract void write(CompositeElement paramCompositeElement);
  
  public abstract void write(TOCElement paramTOCElement);
  
  public abstract void write(SeparatorElement paramSeparatorElement);
  
  public abstract void write(SpaceElement paramSpaceElement);
  
  public abstract void write(CondPageBreakElement paramCondPageBreakElement);
  
  public abstract void write(PageLayoutElement paramPageLayoutElement);
  
  public abstract void write(PageBreakElement paramPageBreakElement);
  
  public abstract void write(AreaBreakElement paramAreaBreakElement);
  
  public abstract void write(NewlineElement paramNewlineElement);
  
  public abstract void write(TabElement paramTabElement);
  
  public abstract void write(TextBoxElement paramTextBoxElement);
  
  public abstract void write(ChartElement paramChartElement);
  
  public abstract void write(PainterElement paramPainterElement);
  
  public abstract void write(FormElement paramFormElement);
  
  public abstract void write(SectionElement paramSectionElement);
  
  public abstract void write(TableElement paramTableElement);
  
  public abstract void write(HeadingElement paramHeadingElement);
  
  public abstract void write(TextElement paramTextElement);
  
  public abstract void write(XTableStyle paramXTableStyle);
  
  public abstract void endHeader();
  
  public abstract void startHeader(String paramString, boolean paramBoolean);
  
  public abstract void startHeader(int paramInt);
  
  public abstract void prolog(StyleSheet paramStyleSheet);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\BaseFormatter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */