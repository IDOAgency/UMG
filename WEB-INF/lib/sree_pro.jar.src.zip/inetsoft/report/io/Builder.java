package inetsoft.report.io;

import inetsoft.report.AreaBreakElement;
import inetsoft.report.ChartElement;
import inetsoft.report.CompositeElement;
import inetsoft.report.CondPageBreakElement;
import inetsoft.report.FormElement;
import inetsoft.report.HeadingElement;
import inetsoft.report.NewlineElement;
import inetsoft.report.PageBreakElement;
import inetsoft.report.PageLayoutElement;
import inetsoft.report.PainterElement;
import inetsoft.report.ReportElement;
import inetsoft.report.SectionElement;
import inetsoft.report.SeparatorElement;
import inetsoft.report.SpaceElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.TOCElement;
import inetsoft.report.TabElement;
import inetsoft.report.TableElement;
import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.TextBoxElement;
import inetsoft.report.TextElement;
import inetsoft.report.internal.Util;
import inetsoft.report.style.XTableStyle;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Builder {
  public static final int TEMPLATE = 1;
  
  public static final int REPORT = 2;
  
  public static final int CSV = 3;
  
  public static final int RTF = 4;
  
  public static final int HTML = 5;
  
  Formatter format;
  
  Parser parser;
  
  Vector styles;
  
  static URL baseurl;
  
  public static Builder getBuilder(int paramInt, OutputStream paramOutputStream) { return getBuilder(paramInt, paramOutputStream, "."); }
  
  public static Builder getBuilder(int paramInt, OutputStream paramOutputStream, Object paramObject) {
    switch (paramInt) {
      case 1:
        return new Builder(new TemplateFormatter(paramOutputStream));
      case 2:
        return new Builder(new ReportFormatter(paramOutputStream));
      case 3:
        return new Builder(new DelimitedFormatter(paramOutputStream));
      case 4:
        return new Builder(new RTFFormatter(paramOutputStream));
      case 5:
        try {
          Class clazz = Class.forName("inetsoft.report.io.HTMLFormatter");
          Constructor constructor = clazz.getConstructor(new Class[] { OutputStream.class, String.class });
          return new Builder((Formatter)constructor.newInstance(new Object[] { paramOutputStream, paramObject }));
        } catch (Throwable throwable) {
          throw new RuntimeException("HTML exporting not available in this product!");
        } 
    } 
    return null;
  }
  
  public static Builder getBuilder(int paramInt, InputStream paramInputStream) {
    switch (paramInt) {
      case 1:
        return new Builder(new TemplateParser(paramInputStream));
      case 2:
        return new Builder(new ReportParser(paramInputStream));
    } 
    return null;
  }
  
  public static int getType(String paramString) {
    paramString = paramString.toLowerCase();
    if (paramString.equals("xml"))
      return 1; 
    if (paramString.equals("template"))
      return 1; 
    if (paramString.equals("report"))
      return 2; 
    if (paramString.equals("csv"))
      return 3; 
    if (paramString.equals("rtf"))
      return 4; 
    if (paramString.equals("html"))
      return 5; 
    return 2;
  }
  
  public static void setBaseURL(URL paramURL) { baseurl = paramURL; }
  
  public static URL getBaseURL() { return baseurl; }
  
  public Builder(Formatter paramFormatter) {
    this.styles = new Vector();
    this.format = paramFormatter;
  }
  
  public Builder(Parser paramParser) {
    this.styles = new Vector();
    this.parser = paramParser;
  }
  
  public Formatter getFormatter() { return this.format; }
  
  public Parser getParser() { return this.parser; }
  
  public void write(StyleSheet paramStyleSheet) throws IOException {
    this.format.prolog(paramStyleSheet);
    if (this.format instanceof TemplateFormatter) {
      String str = Util.findDuplicate(paramStyleSheet, false);
      if (str != null)
        throw new IOException("Duplicated element ID: " + str); 
    } 
    for (byte b1 = 0; b1 < this.styles.size(); b1++)
      this.format.write((XTableStyle)this.styles.elementAt(b1)); 
    int[] arrayOfInt = { 256, 257, 258, 259, 512, 513, 514, 515 };
    for (byte b2 = 0; b2 < arrayOfInt.length; b2++) {
      boolean bool = ((arrayOfInt[b2] & 0x100) != 0) ? 1 : 0;
      if (bool) {
        paramStyleSheet.setCurrentHeader(arrayOfInt[b2]);
      } else {
        paramStyleSheet.setCurrentFooter(arrayOfInt[b2]);
      } 
      int i = bool ? paramStyleSheet.getHeaderElementCount() : paramStyleSheet.getFooterElementCount();
      if (i != 0) {
        this.format.startHeader(arrayOfInt[b2]);
        for (byte b = 0; b < i; b++) {
          if (bool) {
            write(this.format, paramStyleSheet.getHeaderElement(b));
          } else {
            write(this.format, paramStyleSheet.getFooterElement(b));
          } 
        } 
        this.format.endHeader();
      } 
    } 
    Hashtable hashtable = paramStyleSheet.getElementHeaders();
    Enumeration enumeration = hashtable.keys();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      this.format.startHeader(str, true);
      Vector vector = (Vector)hashtable.get(str);
      for (byte b = 0; b < vector.size(); b++)
        write(this.format, (ReportElement)vector.elementAt(b)); 
      this.format.endHeader();
    } 
    hashtable = paramStyleSheet.getElementFooters();
    enumeration = hashtable.keys();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      this.format.startHeader(str, false);
      Vector vector = (Vector)hashtable.get(str);
      for (byte b = 0; b < vector.size(); b++)
        write(this.format, (ReportElement)vector.elementAt(b)); 
      this.format.endHeader();
    } 
    for (byte b3 = 0; b3 < paramStyleSheet.getElementCount(); b3++) {
      ReportElement reportElement = paramStyleSheet.getElement(b3);
      write(this.format, reportElement);
    } 
    this.format.end();
    paramStyleSheet.setCurrentHeader(256);
    paramStyleSheet.setCurrentFooter(512);
  }
  
  public static void write(Formatter paramFormatter, ReportElement paramReportElement) {
    if (paramReportElement instanceof HeadingElement) {
      paramFormatter.write((HeadingElement)paramReportElement);
    } else if (paramReportElement instanceof TextElement) {
      paramFormatter.write((TextElement)paramReportElement);
    } else if (paramReportElement instanceof FormElement) {
      paramFormatter.write((FormElement)paramReportElement);
    } else if (paramReportElement instanceof TableElement) {
      TableElement tableElement = (TableElement)paramReportElement;
      TableLens tableLens = tableElement.getTable();
      if (tableLens instanceof TableFilter)
        ((TableFilter)tableLens).refresh(); 
      paramFormatter.write(tableElement);
    } else if (paramReportElement instanceof SectionElement) {
      paramFormatter.write((SectionElement)paramReportElement);
    } else if (paramReportElement instanceof TextBoxElement) {
      paramFormatter.write((TextBoxElement)paramReportElement);
    } else if (paramReportElement instanceof ChartElement) {
      paramFormatter.write((ChartElement)paramReportElement);
    } else if (paramReportElement instanceof PainterElement) {
      paramFormatter.write((PainterElement)paramReportElement);
    } else if (paramReportElement instanceof NewlineElement) {
      paramFormatter.write((NewlineElement)paramReportElement);
    } else if (paramReportElement instanceof PageBreakElement) {
      paramFormatter.write((PageBreakElement)paramReportElement);
    } else if (paramReportElement instanceof AreaBreakElement) {
      paramFormatter.write((AreaBreakElement)paramReportElement);
    } else if (paramReportElement instanceof PageLayoutElement) {
      paramFormatter.write((PageLayoutElement)paramReportElement);
    } else if (paramReportElement instanceof CondPageBreakElement) {
      paramFormatter.write((CondPageBreakElement)paramReportElement);
    } else if (paramReportElement instanceof SpaceElement) {
      paramFormatter.write((SpaceElement)paramReportElement);
    } else if (paramReportElement instanceof TabElement) {
      paramFormatter.write((TabElement)paramReportElement);
    } else if (paramReportElement instanceof SeparatorElement) {
      paramFormatter.write((SeparatorElement)paramReportElement);
    } else if (paramReportElement instanceof TOCElement) {
      paramFormatter.write((TOCElement)paramReportElement);
    } else if (paramReportElement instanceof CompositeElement) {
      paramFormatter.write((CompositeElement)paramReportElement);
    } 
  }
  
  public StyleSheet read(String paramString) throws IOException {
    StyleSheet styleSheet = this.parser.createSheet(paramString);
    int i = 0;
    String str = null;
    this.styles.removeAllElements();
    Object object;
    while ((object = this.parser.read()) != null) {
      if (object instanceof Integer) {
        i = ((Integer)object).intValue();
        if ((i & 0x100) != 0) {
          styleSheet.setCurrentHeader(i);
        } else {
          styleSheet.setCurrentFooter(i);
        } 
        if (i == 0)
          str = null; 
        continue;
      } 
      if (i != 0) {
        if ((i & 0x100) != 0) {
          styleSheet.addHeaderElement((ReportElement)object);
          continue;
        } 
        styleSheet.addFooterElement((ReportElement)object);
        continue;
      } 
      if (object instanceof String) {
        String str1 = (String)object;
        if (str1.startsWith("header.")) {
          str = str1.substring(7);
          styleSheet.setCurrentHeader(str);
          i = 256;
          continue;
        } 
        if (str1.startsWith("footer.")) {
          str = str1.substring(7);
          styleSheet.setCurrentFooter(str);
          i = 512;
        } 
        continue;
      } 
      if (object instanceof ReportElement) {
        styleSheet.addElement((ReportElement)object);
        continue;
      } 
      if (object instanceof XTableStyle)
        this.styles.addElement(object); 
    } 
    styleSheet.setCurrentHeader(256);
    styleSheet.setCurrentFooter(512);
    return styleSheet;
  }
  
  public void setEmbeddedStyles(Vector paramVector) { this.styles = paramVector; }
  
  public Vector getEmbeddedStyles() { return this.styles; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\io\Builder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */