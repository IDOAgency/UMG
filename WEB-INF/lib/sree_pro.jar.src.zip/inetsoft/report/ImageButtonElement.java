package inetsoft.report;

public interface ImageButtonElement extends FieldElement {
  String getResource();
  
  void setResource(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ImageButtonElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */