package inetsoft.report;

import java.awt.Dimension;
import java.awt.Graphics;
import java.io.Serializable;

public interface Presenter extends Serializable {
  void paint(Graphics paramGraphics, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  Dimension getPreferredSize(Object paramObject);
  
  boolean isPresenterOf(Class paramClass);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Presenter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */