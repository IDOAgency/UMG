package inetsoft.report.j2d;

import inetsoft.report.Margin;
import inetsoft.report.ReportEnv;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.j2d.PSGraphics2D;
import inetsoft.report.internal.j2d.PrintDialog;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class PSPrinterJob extends PrinterJob {
  PSGraphics2D psg = PSGraphics2D.getGraphics();
  
  public PSPrinterJob() {
    if (this.psg == null)
      throw new RuntimeException("Unable to initialize PSGraphics2D"); 
    this.psg.setPrinterJob(this);
  }
  
  public void setCompressImage(boolean paramBoolean) { this.psg.setCompressImage(paramBoolean); }
  
  public boolean isCompressImage() { return this.psg.isCompressImage(); }
  
  public void setPrintable(Printable paramPrintable) { this.painter = paramPrintable; }
  
  public void setPrintable(Printable paramPrintable, PageFormat paramPageFormat) {
    setPrintable(paramPrintable);
    this.format = paramPageFormat;
  }
  
  public void setPageable(Pageable paramPageable) throws NullPointerException { this.book = paramPageable; }
  
  public boolean printDialog() {
    PrintDialog printDialog = new PrintDialog();
    printDialog.setCopies(this.copies);
    printDialog.setPrinter(this.printer);
    printDialog.setFile(this.file);
    printDialog.setPrintToFile(this.toFile);
    printDialog.setPrintOption(this.printOption);
    printDialog.setTitle(this.jobname);
    printDialog.pack();
    printDialog.setVisible(true);
    boolean bool = printDialog.isOK();
    if (bool) {
      this.copies = printDialog.getCopies();
      this.printer = printDialog.getPrinter();
      this.file = printDialog.getFile();
      this.toFile = printDialog.isPrintToFile();
      this.printOption = printDialog.getPrintOption();
      this.jobname = printDialog.getTitle();
    } 
    return bool;
  }
  
  public PageFormat pageDialog(PageFormat paramPageFormat) { return this.defJob.pageDialog(paramPageFormat); }
  
  public PageFormat defaultPage(PageFormat paramPageFormat) { return (PageFormat)paramPageFormat.clone(); }
  
  public PageFormat validatePage(PageFormat paramPageFormat) { return paramPageFormat; }
  
  public void print() {
    OutputStream outputStream = null;
    Process process = null;
    try {
      if (this.toFile) {
        outputStream = new FileOutputStream(this.file);
      } else {
        String str = "lp -n" + getCopies();
        if (getPrinter() != null && getPrinter().length() > 0)
          str = str + " -d\"" + getPrinter() + "\""; 
        if (this.printOption != null && this.printOption.length() > 0)
          str = str + " " + this.printOption; 
        process = Runtime.getRuntime().exec(str);
        outputStream = process.getOutputStream();
      } 
    } catch (Exception exception) {
      throw new PrinterException(exception.toString());
    } 
    synchronized (StyleSheet.class) {
      Margin margin = StyleSheet.getPrinterMargin();
      if (this.book != null) {
        if (this.book instanceof StyleBook)
          StyleSheet.setPrinterMargin(((StyleBook)this.book).getMargin()); 
        boolean bool = true;
        int i = this.book.getNumberOfPages();
        for (byte b = bool; b <= i; b++) {
          byte b1 = b - true;
          PageFormat pageFormat = this.book.getPageFormat(b1);
          if (pageFormat.getOrientation() == 0) {
            this.psg.setPageSize(pageFormat.getPaper().getHeight() / 72.0D, pageFormat.getPaper().getWidth() / 72.0D);
          } else {
            this.psg.setPageSize(pageFormat.getPaper().getWidth() / 72.0D, pageFormat.getPaper().getHeight() / 72.0D);
          } 
          this.psg.setOrientation(pageFormat.getOrientation());
          if (b == bool)
            this.psg.startDoc(outputStream); 
          this.psg.reset();
          this.book.getPrintable(b1).print(this.psg, pageFormat, b);
          this.psg.dispose();
        } 
      } else if (this.painter != null) {
        if (this.painter instanceof StylePrintable)
          StyleSheet.setPrinterMargin(((StylePrintable)this.painter).getMargin()); 
        if (this.format.getOrientation() == 0) {
          this.psg.setPageSize(this.format.getPaper().getHeight() / 72.0D, this.format.getPaper().getWidth() / 72.0D);
        } else {
          this.psg.setPageSize(this.format.getPaper().getWidth() / 72.0D, this.format.getPaper().getHeight() / 72.0D);
        } 
        this.psg.setOrientation(this.format.getOrientation());
        this.psg.startDoc(outputStream);
        for (byte b = 0;; b++) {
          this.psg.reset();
          if (this.painter.print(this.psg, this.format, b) == 1)
            break; 
          this.psg.dispose();
        } 
      } 
      StyleSheet.setPrinterMargin(margin);
      this.psg.close();
    } 
    if (process != null)
      try {
        process.waitFor();
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
  }
  
  public void setCopies(int paramInt) { this.copies = paramInt; }
  
  public int getCopies() { return this.copies; }
  
  public String getUserName() {
    try {
      return ReportEnv.getProperty("user.name");
    } catch (Exception exception) {
      return "Unknown";
    } 
  }
  
  public void setJobName(String paramString) { this.jobname = paramString; }
  
  public String getJobName() { return this.jobname; }
  
  public void setFile(String paramString) { this.file = paramString; }
  
  public String getFile() { return this.file; }
  
  public void setPrintToFile(boolean paramBoolean) { this.toFile = paramBoolean; }
  
  public boolean isPrintToFile() { return this.toFile; }
  
  public void setPrinter(String paramString) { this.printer = paramString; }
  
  public String getPrinter() { return this.printer; }
  
  public void cancel() { this.cancelled = true; }
  
  public boolean isCancelled() { return this.cancelled; }
  
  Printable painter = null;
  
  Pageable book = null;
  
  PageFormat format = new PageFormat();
  
  int copies = 1;
  
  String jobname = "Report";
  
  String printer = "";
  
  String printOption = "";
  
  String file = "report.ps";
  
  boolean toFile = false;
  
  boolean cancelled = false;
  
  PrinterJob defJob = PrinterJob.getPrinterJob();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\PSPrinterJob.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */