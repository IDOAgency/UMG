/*     */ package inetsoft.report.j2d;
/*     */ 
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.j2d.PSGraphics2D;
/*     */ import inetsoft.report.internal.j2d.PrintDialog;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Pageable;
/*     */ import java.awt.print.Printable;
/*     */ import java.awt.print.PrinterException;
/*     */ import java.awt.print.PrinterJob;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PSPrinterJob
/*     */   extends PrinterJob
/*     */ {
/*  35 */   PSGraphics2D psg = PSGraphics2D.getGraphics();
/*     */   public PSPrinterJob() {
/*  37 */     if (this.psg == null) {
/*  38 */       throw new RuntimeException("Unable to initialize PSGraphics2D");
/*     */     }
/*     */     
/*  41 */     this.psg.setPrinterJob(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public void setCompressImage(boolean paramBoolean) { this.psg.setCompressImage(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public boolean isCompressImage() { return this.psg.isCompressImage(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public void setPrintable(Printable paramPrintable) { this.painter = paramPrintable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrintable(Printable paramPrintable, PageFormat paramPageFormat) {
/*  87 */     setPrintable(paramPrintable);
/*  88 */     this.format = paramPageFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public void setPageable(Pageable paramPageable) throws NullPointerException { this.book = paramPageable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean printDialog() {
/* 114 */     PrintDialog printDialog = new PrintDialog();
/*     */     
/* 116 */     printDialog.setCopies(this.copies);
/* 117 */     printDialog.setPrinter(this.printer);
/* 118 */     printDialog.setFile(this.file);
/* 119 */     printDialog.setPrintToFile(this.toFile);
/* 120 */     printDialog.setPrintOption(this.printOption);
/* 121 */     printDialog.setTitle(this.jobname);
/*     */     
/* 123 */     printDialog.pack();
/* 124 */     printDialog.setVisible(true);
/*     */     
/* 126 */     boolean bool = printDialog.isOK();
/*     */     
/* 128 */     if (bool) {
/* 129 */       this.copies = printDialog.getCopies();
/* 130 */       this.printer = printDialog.getPrinter();
/* 131 */       this.file = printDialog.getFile();
/* 132 */       this.toFile = printDialog.isPrintToFile();
/* 133 */       this.printOption = printDialog.getPrintOption();
/* 134 */       this.jobname = printDialog.getTitle();
/*     */     } 
/*     */     
/* 137 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public PageFormat pageDialog(PageFormat paramPageFormat) { return this.defJob.pageDialog(paramPageFormat); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public PageFormat defaultPage(PageFormat paramPageFormat) { return (PageFormat)paramPageFormat.clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 185 */   public PageFormat validatePage(PageFormat paramPageFormat) { return paramPageFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print() {
/* 194 */     OutputStream outputStream = null;
/* 195 */     Process process = null;
/*     */     
/*     */     try {
/* 198 */       if (this.toFile) {
/* 199 */         outputStream = new FileOutputStream(this.file);
/*     */       } else {
/*     */         
/* 202 */         String str = "lp -n" + getCopies();
/*     */         
/* 204 */         if (getPrinter() != null && getPrinter().length() > 0) {
/* 205 */           str = str + " -d\"" + getPrinter() + "\"";
/*     */         }
/*     */         
/* 208 */         if (this.printOption != null && this.printOption.length() > 0) {
/* 209 */           str = str + " " + this.printOption;
/*     */         }
/*     */         
/* 212 */         process = Runtime.getRuntime().exec(str);
/* 213 */         outputStream = process.getOutputStream();
/*     */       } 
/*     */     } catch (Exception exception) {
/* 216 */       throw new PrinterException(exception.toString());
/*     */     } 
/*     */     
/* 219 */     synchronized (StyleSheet.class) {
/* 220 */       Margin margin = StyleSheet.getPrinterMargin();
/*     */       
/* 222 */       if (this.book != null) {
/* 223 */         if (this.book instanceof StyleBook) {
/* 224 */           StyleSheet.setPrinterMargin(((StyleBook)this.book).getMargin());
/*     */         }
/*     */         
/* 227 */         boolean bool = true;
/* 228 */         int i = this.book.getNumberOfPages();
/*     */         
/* 230 */         for (byte b = bool; b <= i; b++) {
/* 231 */           byte b1 = b - true;
/* 232 */           PageFormat pageFormat = this.book.getPageFormat(b1);
/*     */           
/* 234 */           if (pageFormat.getOrientation() == 0) {
/* 235 */             this.psg.setPageSize(pageFormat.getPaper().getHeight() / 72.0D, pageFormat.getPaper().getWidth() / 72.0D);
/*     */           }
/*     */           else {
/*     */             
/* 239 */             this.psg.setPageSize(pageFormat.getPaper().getWidth() / 72.0D, pageFormat.getPaper().getHeight() / 72.0D);
/*     */           } 
/*     */ 
/*     */           
/* 243 */           this.psg.setOrientation(pageFormat.getOrientation());
/*     */           
/* 245 */           if (b == bool) {
/* 246 */             this.psg.startDoc(outputStream);
/*     */           }
/*     */           
/* 249 */           this.psg.reset();
/* 250 */           this.book.getPrintable(b1).print(this.psg, pageFormat, b);
/* 251 */           this.psg.dispose();
/*     */         }
/*     */       
/* 254 */       } else if (this.painter != null) {
/* 255 */         if (this.painter instanceof StylePrintable) {
/* 256 */           StyleSheet.setPrinterMargin(((StylePrintable)this.painter).getMargin());
/*     */         }
/*     */ 
/*     */         
/* 260 */         if (this.format.getOrientation() == 0) {
/* 261 */           this.psg.setPageSize(this.format.getPaper().getHeight() / 72.0D, this.format.getPaper().getWidth() / 72.0D);
/*     */         }
/*     */         else {
/*     */           
/* 265 */           this.psg.setPageSize(this.format.getPaper().getWidth() / 72.0D, this.format.getPaper().getHeight() / 72.0D);
/*     */         } 
/*     */ 
/*     */         
/* 269 */         this.psg.setOrientation(this.format.getOrientation());
/* 270 */         this.psg.startDoc(outputStream);
/*     */         
/* 272 */         for (byte b = 0;; b++) {
/* 273 */           this.psg.reset();
/*     */           
/* 275 */           if (this.painter.print(this.psg, this.format, b) == 1) {
/*     */             break;
/*     */           }
/*     */           
/* 279 */           this.psg.dispose();
/*     */         } 
/*     */       } 
/*     */       
/* 283 */       StyleSheet.setPrinterMargin(margin);
/* 284 */       this.psg.close();
/*     */     } 
/*     */ 
/*     */     
/* 288 */     if (process != null) {
/*     */       try {
/* 290 */         process.waitFor();
/*     */       } catch (Exception exception) {
/* 292 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 302 */   public void setCopies(int paramInt) { this.copies = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 310 */   public int getCopies() { return this.copies; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserName() {
/*     */     try {
/* 319 */       return ReportEnv.getProperty("user.name");
/* 320 */     } catch (Exception exception) {
/*     */ 
/*     */       
/* 323 */       return "Unknown";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 332 */   public void setJobName(String paramString) { this.jobname = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 340 */   public String getJobName() { return this.jobname; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 348 */   public void setFile(String paramString) { this.file = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 356 */   public String getFile() { return this.file; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 364 */   public void setPrintToFile(boolean paramBoolean) { this.toFile = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 372 */   public boolean isPrintToFile() { return this.toFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 380 */   public void setPrinter(String paramString) { this.printer = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 388 */   public String getPrinter() { return this.printer; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 400 */   public void cancel() { this.cancelled = true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 412 */   public boolean isCancelled() { return this.cancelled; }
/*     */ 
/*     */ 
/*     */   
/* 416 */   Printable painter = null;
/* 417 */   Pageable book = null;
/* 418 */   PageFormat format = new PageFormat();
/*     */ 
/*     */   
/* 421 */   int copies = 1;
/* 422 */   String jobname = "Report";
/* 423 */   String printer = "";
/* 424 */   String printOption = "";
/* 425 */   String file = "report.ps";
/*     */   
/*     */   boolean toFile = false;
/*     */   boolean cancelled = false;
/* 429 */   PrinterJob defJob = PrinterJob.getPrinterJob();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\PSPrinterJob.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */