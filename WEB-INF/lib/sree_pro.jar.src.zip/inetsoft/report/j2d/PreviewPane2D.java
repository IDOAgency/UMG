/*    */ package inetsoft.report.j2d;
/*    */ 
/*    */ import inetsoft.report.PreviewPage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreviewPane2D
/*    */   extends JPreviewPane
/*    */ {
/* 40 */   protected PreviewPage createPage(double paramDouble1, double paramDouble2, int paramInt) { return new PreviewPage2D(paramDouble1, paramDouble2, paramInt); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\PreviewPane2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */