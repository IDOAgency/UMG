/*     */ package inetsoft.report.j2d;
/*     */ 
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.j2d.Win32Graphics2D;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Pageable;
/*     */ import java.awt.print.Printable;
/*     */ import java.awt.print.PrinterJob;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Win32PrinterJob
/*     */   extends PrinterJob
/*     */ {
/*     */   Win32Graphics2D wing;
/*     */   
/*     */   public Win32PrinterJob() {
/*  33 */     this.wing = Win32Graphics2D.getGraphics(null);
/*  34 */     if (this.wing == null) {
/*  35 */       throw new RuntimeException("Unable to initialize Win32Graphics2D");
/*     */     }
/*     */     
/*  38 */     this.wing.setPrinterJob(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Win32PrinterJob(String paramString) {
/*  46 */     this.wing = Win32Graphics2D.getGraphics(paramString);
/*  47 */     if (this.wing == null) {
/*  48 */       throw new RuntimeException("Unable to initialize Win32Graphics2D");
/*     */     }
/*     */     
/*  51 */     this.wing.setPrinterJob(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public void setDuplex(boolean paramBoolean) { this.wing.setDuplex(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public boolean isDuplex() { return this.wing.isDuplex(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public void setTray(int paramInt) { this.wing.setTray(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void setPrintable(Printable paramPrintable) { this.painter = paramPrintable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrintable(Printable paramPrintable, PageFormat paramPageFormat) {
/* 104 */     setPrintable(paramPrintable);
/* 105 */     this.format = paramPageFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public void setPageable(Pageable paramPageable) throws NullPointerException { this.book = paramPageable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean printDialog() {
/* 131 */     int i = -1;
/* 132 */     if (this.book != null) {
/* 133 */       i = this.book.getNumberOfPages();
/*     */     }
/*     */     
/* 136 */     boolean bool = this.wing.printDialog(i);
/* 137 */     if (bool) {
/* 138 */       this.copies = this.wing.getCopies();
/*     */     }
/*     */     
/* 141 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public PageFormat pageDialog(PageFormat paramPageFormat) { return this.defJob.pageDialog(paramPageFormat); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public PageFormat defaultPage(PageFormat paramPageFormat) { return (PageFormat)paramPageFormat.clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public PageFormat validatePage(PageFormat paramPageFormat) { return paramPageFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print() {
/* 201 */     this.wing.startDoc(getJobName());
/*     */     
/* 203 */     synchronized (StyleSheet.class) {
/* 204 */       Margin margin = StyleSheet.getPrinterMargin();
/*     */       
/* 206 */       if (this.book != null) {
/* 207 */         if (this.book instanceof StyleBook) {
/* 208 */           StyleSheet.setPrinterMargin(((StyleBook)this.book).getMargin());
/*     */         }
/*     */         
/* 211 */         int i = this.wing.isPages() ? this.wing.getFromPage() : 1;
/* 212 */         int j = this.wing.isPages() ? this.wing.getToPage() : this.book.getNumberOfPages();
/*     */         
/* 214 */         for (int k = Math.max(1, i); k <= j; k++) {
/* 215 */           PageFormat pageFormat = this.book.getPageFormat(k - 1);
/* 216 */           this.wing.setOrientation(pageFormat.getOrientation());
/*     */           
/* 218 */           this.wing.startPage();
/* 219 */           this.book.getPrintable(k - 1).print(this.wing, pageFormat, k);
/* 220 */           this.wing.dispose();
/*     */         }
/*     */       
/* 223 */       } else if (this.painter != null) {
/* 224 */         this.wing.setOrientation(this.format.getOrientation());
/*     */         
/* 226 */         if (this.painter instanceof StylePrintable) {
/* 227 */           StyleSheet.setPrinterMargin(((StylePrintable)this.painter).getMargin());
/*     */         }
/*     */ 
/*     */         
/* 231 */         for (byte b = 0;; b++) {
/* 232 */           this.wing.startPage();
/* 233 */           if (this.painter.print(this.wing, this.format, b) == 1) {
/* 234 */             this.wing.dispose();
/*     */             break;
/*     */           } 
/* 237 */           this.wing.dispose();
/*     */         } 
/*     */       } 
/*     */       
/* 241 */       StyleSheet.setPrinterMargin(margin);
/* 242 */       this.wing.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCopies(int paramInt) {
/* 251 */     this.copies = paramInt;
/* 252 */     this.wing.setCopies(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public int getCopies() { return this.copies; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserName() {
/*     */     try {
/* 269 */       return ReportEnv.getProperty("user.name");
/* 270 */     } catch (Exception exception) {
/*     */ 
/*     */       
/* 273 */       return "Unknown";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   public void setJobName(String paramString) { this.jobname = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   public String getJobName() { return this.jobname; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 302 */   public void cancel() { this.cancelled = true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 314 */   public boolean isCancelled() { return this.cancelled; }
/*     */ 
/*     */ 
/*     */   
/* 318 */   Printable painter = null;
/* 319 */   Pageable book = null;
/* 320 */   PageFormat format = new PageFormat();
/* 321 */   int copies = 1;
/* 322 */   String jobname = "Report";
/*     */   boolean cancelled = false;
/* 324 */   PrinterJob defJob = PrinterJob.getPrinterJob();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\Win32PrinterJob.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */