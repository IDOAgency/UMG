package inetsoft.report.j2d;

import inetsoft.report.Margin;
import inetsoft.report.ReportEnv;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.j2d.Win32Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;

public class Win32PrinterJob extends PrinterJob {
  Win32Graphics2D wing;
  
  public Win32PrinterJob() {
    this.wing = Win32Graphics2D.getGraphics(null);
    if (this.wing == null)
      throw new RuntimeException("Unable to initialize Win32Graphics2D"); 
    this.wing.setPrinterJob(this);
  }
  
  public Win32PrinterJob(String paramString) {
    this.wing = Win32Graphics2D.getGraphics(paramString);
    if (this.wing == null)
      throw new RuntimeException("Unable to initialize Win32Graphics2D"); 
    this.wing.setPrinterJob(this);
  }
  
  public void setDuplex(boolean paramBoolean) { this.wing.setDuplex(paramBoolean); }
  
  public boolean isDuplex() { return this.wing.isDuplex(); }
  
  public void setTray(int paramInt) { this.wing.setTray(paramInt); }
  
  public void setPrintable(Printable paramPrintable) { this.painter = paramPrintable; }
  
  public void setPrintable(Printable paramPrintable, PageFormat paramPageFormat) {
    setPrintable(paramPrintable);
    this.format = paramPageFormat;
  }
  
  public void setPageable(Pageable paramPageable) throws NullPointerException { this.book = paramPageable; }
  
  public boolean printDialog() {
    int i = -1;
    if (this.book != null)
      i = this.book.getNumberOfPages(); 
    boolean bool = this.wing.printDialog(i);
    if (bool)
      this.copies = this.wing.getCopies(); 
    return bool;
  }
  
  public PageFormat pageDialog(PageFormat paramPageFormat) { return this.defJob.pageDialog(paramPageFormat); }
  
  public PageFormat defaultPage(PageFormat paramPageFormat) { return (PageFormat)paramPageFormat.clone(); }
  
  public PageFormat validatePage(PageFormat paramPageFormat) { return paramPageFormat; }
  
  public void print() {
    this.wing.startDoc(getJobName());
    synchronized (StyleSheet.class) {
      Margin margin = StyleSheet.getPrinterMargin();
      if (this.book != null) {
        if (this.book instanceof StyleBook)
          StyleSheet.setPrinterMargin(((StyleBook)this.book).getMargin()); 
        int i = this.wing.isPages() ? this.wing.getFromPage() : 1;
        int j = this.wing.isPages() ? this.wing.getToPage() : this.book.getNumberOfPages();
        for (int k = Math.max(1, i); k <= j; k++) {
          PageFormat pageFormat = this.book.getPageFormat(k - 1);
          this.wing.setOrientation(pageFormat.getOrientation());
          this.wing.startPage();
          this.book.getPrintable(k - 1).print(this.wing, pageFormat, k);
          this.wing.dispose();
        } 
      } else if (this.painter != null) {
        this.wing.setOrientation(this.format.getOrientation());
        if (this.painter instanceof StylePrintable)
          StyleSheet.setPrinterMargin(((StylePrintable)this.painter).getMargin()); 
        for (byte b = 0;; b++) {
          this.wing.startPage();
          if (this.painter.print(this.wing, this.format, b) == 1) {
            this.wing.dispose();
            break;
          } 
          this.wing.dispose();
        } 
      } 
      StyleSheet.setPrinterMargin(margin);
      this.wing.close();
    } 
  }
  
  public void setCopies(int paramInt) {
    this.copies = paramInt;
    this.wing.setCopies(paramInt);
  }
  
  public int getCopies() { return this.copies; }
  
  public String getUserName() {
    try {
      return ReportEnv.getProperty("user.name");
    } catch (Exception exception) {
      return "Unknown";
    } 
  }
  
  public void setJobName(String paramString) { this.jobname = paramString; }
  
  public String getJobName() { return this.jobname; }
  
  public void cancel() { this.cancelled = true; }
  
  public boolean isCancelled() { return this.cancelled; }
  
  Printable painter = null;
  
  Pageable book = null;
  
  PageFormat format = new PageFormat();
  
  int copies = 1;
  
  String jobname = "Report";
  
  boolean cancelled = false;
  
  PrinterJob defJob = PrinterJob.getPrinterJob();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\Win32PrinterJob.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */