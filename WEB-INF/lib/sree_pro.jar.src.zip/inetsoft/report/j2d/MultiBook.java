package inetsoft.report.j2d;

import inetsoft.report.StyleSheet;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;

public class MultiBook implements Pageable {
  Pageable[] books;
  
  public MultiBook(StyleSheet[] paramArrayOfStyleSheet, PageFormat paramPageFormat) {
    this.books = new StyleBook[paramArrayOfStyleSheet.length];
    byte b;
    int i;
    for (b = 0, i = 0; b < paramArrayOfStyleSheet.length; b++) {
      paramArrayOfStyleSheet[b].setPageNumberingStart(i + true);
      this.books[b] = new StyleBook(paramArrayOfStyleSheet[b], paramPageFormat);
      i += this.books[b].getNumberOfPages();
    } 
  }
  
  public MultiBook(StyleSheet[] paramArrayOfStyleSheet, PageFormat[] paramArrayOfPageFormat) {
    this.books = new StyleBook[paramArrayOfStyleSheet.length];
    for (int i = 0, j = 0; i < paramArrayOfStyleSheet.length; i++) {
      paramArrayOfStyleSheet[i].setPageNumberingStart(j + true);
      this.books[i] = new StyleBook(paramArrayOfStyleSheet[i], paramArrayOfPageFormat[i % paramArrayOfPageFormat.length]);
      j += this.books[i].getNumberOfPages();
    } 
  }
  
  public MultiBook(Pageable[] paramArrayOfPageable) { this.books = paramArrayOfPageable; }
  
  public int getNumberOfPages() {
    int i = 0;
    for (byte b = 0; b < this.books.length; b++)
      i += this.books[b].getNumberOfPages(); 
    return i;
  }
  
  public PageFormat getPageFormat(int paramInt) throws IndexOutOfBoundsException {
    Index index = getBookIndex(paramInt);
    if (index == null)
      throw new IndexOutOfBoundsException(); 
    return this.books[index.bookIndex].getPageFormat(index.pageIndex);
  }
  
  public Printable getPrintable(int paramInt) throws IndexOutOfBoundsException {
    Index index = getBookIndex(paramInt);
    if (index == null)
      throw new IndexOutOfBoundsException(); 
    return this.books[index.bookIndex].getPrintable(index.pageIndex);
  }
  
  public static class Index {
    public int bookIndex;
    
    public int pageIndex;
    
    public Index(int param1Int1, int param1Int2) {
      this.bookIndex = param1Int1;
      this.pageIndex = param1Int2;
    }
  }
  
  public Index getBookIndex(int paramInt) {
    for (byte b = 0; b < this.books.length; b++) {
      int i = this.books[b].getNumberOfPages();
      if (paramInt < i)
        return new Index(b, paramInt); 
      paramInt -= i;
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\MultiBook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */