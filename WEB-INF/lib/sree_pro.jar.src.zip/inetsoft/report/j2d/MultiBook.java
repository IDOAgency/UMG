/*     */ package inetsoft.report.j2d;
/*     */ 
/*     */ import inetsoft.report.StyleSheet;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Pageable;
/*     */ import java.awt.print.Printable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiBook
/*     */   implements Pageable
/*     */ {
/*     */   Pageable[] books;
/*     */   
/*     */   public MultiBook(StyleSheet[] paramArrayOfStyleSheet, PageFormat paramPageFormat) {
/*  36 */     this.books = new StyleBook[paramArrayOfStyleSheet.length]; byte b;
/*     */     int i;
/*  38 */     for (b = 0, i = 0; b < paramArrayOfStyleSheet.length; b++) {
/*  39 */       paramArrayOfStyleSheet[b].setPageNumberingStart(i + true);
/*  40 */       this.books[b] = new StyleBook(paramArrayOfStyleSheet[b], paramPageFormat);
/*  41 */       i += this.books[b].getNumberOfPages();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiBook(StyleSheet[] paramArrayOfStyleSheet, PageFormat[] paramArrayOfPageFormat) {
/*  52 */     this.books = new StyleBook[paramArrayOfStyleSheet.length];
/*     */     
/*  54 */     for (int i = 0, j = 0; i < paramArrayOfStyleSheet.length; i++) {
/*  55 */       paramArrayOfStyleSheet[i].setPageNumberingStart(j + true);
/*  56 */       this.books[i] = new StyleBook(paramArrayOfStyleSheet[i], paramArrayOfPageFormat[i % paramArrayOfPageFormat.length]);
/*  57 */       j += this.books[i].getNumberOfPages();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public MultiBook(Pageable[] paramArrayOfPageable) { this.books = paramArrayOfPageable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfPages() {
/*  74 */     int i = 0;
/*     */     
/*  76 */     for (byte b = 0; b < this.books.length; b++) {
/*  77 */       i += this.books[b].getNumberOfPages();
/*     */     }
/*     */     
/*  80 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageFormat getPageFormat(int paramInt) throws IndexOutOfBoundsException {
/*  91 */     Index index = getBookIndex(paramInt);
/*  92 */     if (index == null) {
/*  93 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/*  96 */     return this.books[index.bookIndex].getPageFormat(index.pageIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Printable getPrintable(int paramInt) throws IndexOutOfBoundsException {
/* 107 */     Index index = getBookIndex(paramInt);
/* 108 */     if (index == null) {
/* 109 */       throw new IndexOutOfBoundsException();
/*     */     }
/*     */     
/* 112 */     return this.books[index.bookIndex].getPrintable(index.pageIndex);
/*     */   }
/*     */   
/*     */   public static class Index {
/*     */     public int bookIndex;
/*     */     public int pageIndex;
/*     */     
/*     */     public Index(int param1Int1, int param1Int2) {
/* 120 */       this.bookIndex = param1Int1;
/* 121 */       this.pageIndex = param1Int2;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Index getBookIndex(int paramInt) {
/* 133 */     for (byte b = 0; b < this.books.length; b++) {
/* 134 */       int i = this.books[b].getNumberOfPages();
/*     */       
/* 136 */       if (paramInt < i) {
/* 137 */         return new Index(b, paramInt);
/*     */       }
/*     */       
/* 140 */       paramInt -= i;
/*     */     } 
/*     */     
/* 143 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\MultiBook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */