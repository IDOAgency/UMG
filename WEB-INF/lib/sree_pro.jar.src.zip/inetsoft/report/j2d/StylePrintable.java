/*    */ package inetsoft.report.j2d;
/*    */ 
/*    */ import inetsoft.report.Margin;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.print.Book;
/*    */ import java.awt.print.PageFormat;
/*    */ import java.awt.print.Printable;
/*    */ import java.awt.print.PrinterException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StylePrintable
/*    */   implements Printable
/*    */ {
/*    */   Book book;
/*    */   
/* 31 */   public StylePrintable(Book paramBook) { this.book = paramBook; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int print(Graphics paramGraphics, PageFormat paramPageFormat, int paramInt) throws PrinterException {
/* 40 */     if (paramInt < this.book.getNumberOfPages()) {
/* 41 */       return this.book.getPrintable(paramInt).print(paramGraphics, paramPageFormat, paramInt);
/*    */     }
/*    */     
/* 44 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   public Margin getMargin() { return (this.book instanceof StyleBook) ? ((StyleBook)this.book).getMargin() : StyleSheet.getPrinterMargin(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\StylePrintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */