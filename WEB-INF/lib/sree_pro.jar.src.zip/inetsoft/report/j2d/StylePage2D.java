package inetsoft.report.j2d;

import inetsoft.report.StylePage;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.print.PageFormat;
import java.awt.print.Printable;

public class StylePage2D extends StylePage implements Printable {
  public StylePage2D(PageFormat paramPageFormat) { super(new Dimension((int)paramPageFormat.getWidth(), (int)paramPageFormat.getHeight()), 72); }
  
  public int print(Graphics paramGraphics, PageFormat paramPageFormat, int paramInt) {
    print(paramGraphics);
    return 0;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\StylePage2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */