package inetsoft.report.j2d;

import inetsoft.report.Margin;
import inetsoft.report.PreviewPane;
import inetsoft.report.StyleSheet;
import inetsoft.report.io.Builder;
import inetsoft.report.locale.Catalog;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.PrinterJob;
import java.io.FileInputStream;

public class Previewer2D extends JPreviewer {
  PrinterJob printjob2D;
  
  Margin pmargin;
  
  public Previewer2D() {
    super(Catalog.getString("Print Preview"));
    this.pmargin = StyleSheet.getPrinterMargin();
  }
  
  public Previewer2D(String paramString, boolean paramBoolean) {
    super(paramString, paramBoolean);
    this.pmargin = StyleSheet.getPrinterMargin();
  }
  
  public Previewer2D(String paramString, PrinterJob paramPrinterJob, boolean paramBoolean) {
    super(paramString, paramBoolean);
    this.pmargin = StyleSheet.getPrinterMargin();
    this.printjob2D = paramPrinterJob;
    PageFormat pageFormat = paramPrinterJob.defaultPage();
    setPageWidth(pageFormat.getWidth() / 72.0D);
    setPageHeight(pageFormat.getHeight() / 72.0D);
    setPageResolution(72);
  }
  
  public Previewer2D(String paramString) {
    super(paramString);
    this.pmargin = StyleSheet.getPrinterMargin();
  }
  
  public Previewer2D(String paramString, int paramInt1, int paramInt2) {
    super(paramString, paramInt1, paramInt2);
    this.pmargin = StyleSheet.getPrinterMargin();
  }
  
  protected PreviewPane createPane() { return new PreviewPane2D(); }
  
  public void printAction() {
    if (this.sheet == null)
      return; 
    PrinterJob printerJob = this.printjob2D;
    if (printerJob == null)
      printerJob = StylePrinter.getPrinterJob(); 
    Paper paper = new Paper();
    PageFormat pageFormat = printerJob.defaultPage();
    if (getOrientation() == 1) {
      paper.setSize(getPageWidth() * 72.0D, getPageHeight() * 72.0D);
    } else {
      paper.setSize(getPageHeight() * 72.0D, getPageWidth() * 72.0D);
    } 
    paper.setImageableArea(this.pmargin.left * 72.0D, this.pmargin.top * 72.0D, paper.getWidth() - (this.pmargin.left + this.pmargin.right) * 72.0D, paper.getHeight() - (this.pmargin.top + this.pmargin.bottom) * 72.0D);
    pageFormat.setOrientation(getOrientation());
    pageFormat.setPaper(paper);
    printerJob.setPageable(new StyleBook(this.sheet, pageFormat));
    if (printerJob.printDialog()) {
      PrinterJob printerJob1 = printerJob;
      (new Thread(this, printerJob1) {
          private final PrinterJob val$thejob;
          
          private final Previewer2D this$0;
          
          public void run() {
            try {
              this.this$0.pane.showStatus(Catalog.getString("Printing") + "...");
              this.val$thejob.print();
              this.this$0.pane.showStatus("");
            } catch (Exception exception) {
              exception.printStackTrace();
            } 
          }
        }).start();
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    if (paramArrayOfString.length < 1) {
      System.err.println("Usage: java inetsoft.report.j2d.Previewer2D report-file");
      System.exit(1);
    } 
    try {
      FileInputStream fileInputStream = new FileInputStream(paramArrayOfString[0]);
      Builder builder = Builder.getBuilder(2, fileInputStream);
      StyleSheet styleSheet = builder.read(".");
      fileInputStream.close();
      Previewer2D previewer2D = new Previewer2D();
      previewer2D.setExitOnClose(true);
      previewer2D.pack();
      previewer2D.setVisible(true);
      previewer2D.print(styleSheet);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\Previewer2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */