package inetsoft.report.j2d;

import inetsoft.report.Common;
import inetsoft.report.PreviewPane;
import inetsoft.report.Size;
import inetsoft.report.internal.Util;
import inetsoft.report.locale.Catalog;
import java.awt.Adjustable;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentListener;
import javax.swing.BoundedRangeModel;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.plaf.ScrollBarUI;

public class JPreviewPane extends PreviewPane {
  protected StatusScrollPane scroller;
  
  protected Container createScrollPane() {
    this.scroller = new StatusScrollPane(this);
    this.scroller.bar.pageB.addActionListener(new ActionListener(this) {
          private final JPreviewPane this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.gotoPage(); }
        });
    this.scroller.getVerticalScrollBar().setUnitIncrement(18);
    this.scroller.getHorizontalScrollBar().setUnitIncrement(18);
    this.scroller.getHorizontalScrollBar().setBlockIncrement(200);
    return this.scroller;
  }
  
  protected void addToScrollPane(Component paramComponent) { ((JScrollPane)this.scrollpane).setViewportView(paramComponent); }
  
  protected Container getViewport() { return ((JScrollPane)this.scrollpane).getViewport(); }
  
  protected int getBlockIncrement(Adjustable paramAdjustable) { return ((JScrollBar)paramAdjustable).getBlockIncrement(1); }
  
  public Dimension getViewportSize() { return ((JScrollPane)this.scrollpane).getViewport().getSize(); }
  
  public Adjustable getVAdjustable() { return ((JScrollPane)this.scrollpane).getVerticalScrollBar(); }
  
  public Adjustable getHAdjustable() { return ((JScrollPane)this.scrollpane).getHorizontalScrollBar(); }
  
  protected void syncScrollPane() {}
  
  public void showPageNumber(int paramInt) { this.scroller.bar.pageB.setLabel(Catalog.getString("Page") + " " + paramInt + " " + Catalog.getString("of") + " " + getPageCount()); }
  
  public void showPageSize(Size paramSize) { this.scroller.bar.sizeB.setLabel(paramSize.width + " x " + paramSize.height + " in"); }
  
  public void showStatus(String paramString) { this.scroller.bar.statusF.setLabel(paramString); }
  
  public void gotoPage() {
    JDialog jDialog = new JDialog(Util.findFrame(this), Catalog.getString("Go To Page"));
    JTextField jTextField = new JTextField(8);
    jDialog.getContentPane().setLayout(new BorderLayout(20, 20));
    jDialog.getContentPane().add(new Component(this) {
          private final JPreviewPane this$0;
        },  "North");
    JPanel jPanel = new JPanel();
    jPanel.add(new JLabel(Catalog.getString("Page") + ":"));
    jPanel.add(jTextField);
    jPanel.add(new JLabel(Catalog.getString("of") + " " + getPageCount()));
    jDialog.getContentPane().add(jPanel, "Center");
    jPanel = new JPanel();
    ActionListener actionListener = new ActionListener(this, jTextField, jDialog) {
        private final JTextField val$pgnumTF;
        
        private final JDialog val$win;
        
        private final JPreviewPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            this.this$0.gotoPage(Integer.parseInt(this.val$pgnumTF.getText()));
            this.val$win.dispose();
          } catch (NumberFormatException numberFormatException) {
            this.val$pgnumTF.setText("");
          } 
        }
      };
    JButton jButton = new JButton("     " + Catalog.getString("OK") + "     ");
    jButton.addActionListener(actionListener);
    jPanel.add(jButton);
    jButton = new JButton("   " + Catalog.getString("Cancel") + "   ");
    jButton.addActionListener(new ActionListener(this, jDialog) {
          private final JDialog val$win;
          
          private final JPreviewPane this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.val$win.dispose(); }
        });
    jPanel.add(jButton);
    jDialog.getContentPane().add(jPanel, "South");
    jTextField.setText("" + getPageNumber());
    jTextField.selectAll();
    jTextField.addActionListener(actionListener);
    Point point = getLocationOnScreen();
    Dimension dimension = getSize();
    jDialog.setLocation(point.x + dimension.width / 2 - 100, point.y + dimension.height / 2 - 80);
    jDialog.setModal(true);
    jDialog.pack();
    jDialog.setVisible(true);
  }
  
  protected class StatusScrollPane extends JScrollPane {
    JPreviewPane.StatusScrollBar bar;
    
    private final JPreviewPane this$0;
    
    public StatusScrollPane(JPreviewPane this$0) {
      this.this$0 = this$0;
      setHorizontalScrollBarPolicy(32);
    }
    
    public JScrollBar createHorizontalScrollBar() { return this.bar = new JPreviewPane.StatusScrollBar(this.this$0); }
    
    public JPreviewPane.StatusScrollBar getScrollBar() { return this.bar; }
  }
  
  protected class StatusScrollBar extends JScrollBar {
    JScrollBar scrollbar;
    
    JButton pageB;
    
    JButton sizeB;
    
    JPanel statusPane;
    
    JButton statusF;
    
    private final JPreviewPane this$0;
    
    public StatusScrollBar(JPreviewPane this$0) {
      super(0);
      this.this$0 = this$0;
      this.scrollbar = null;
      this.pageB = new SmallButton(this, "Page 1 of 1");
      this.sizeB = new SmallButton(this, "8.5 x 11 in");
      this.statusPane = new JPanel();
      this.statusF = new JPreviewPane$5(this);
      setLayout(new BoxLayout(this, 0));
      checkInit();
      add(this.pageB);
      this.pageB.setMargin(new Insets(0, 15, 0, 15));
      Image image = Common.getImage(this, "/inetsoft/report/images/smallpage.gif");
      this.pageB.setIcon(new ImageIcon(image));
      add(this.sizeB);
      this.sizeB.setMargin(new Insets(0, 15, 0, 15));
      image = Common.getImage(this, "/inetsoft/report/images/smallpaper.gif");
      this.sizeB.setIcon(new ImageIcon(image));
      this.statusPane.setLayout(new BoxLayout(this.statusPane, 0));
      this.statusPane.add(this.statusF);
      add(this.statusPane);
      add(this.scrollbar);
    }
    
    public void clearStatus() {
      while (this.statusPane.getComponentCount() > 0)
        this.statusPane.remove(0); 
    }
    
    public void addStatus(Component param1Component) { this.statusPane.add(param1Component); }
    
    public ScrollBarUI getUI() { return this.scrollbar.getUI(); }
    
    public void updateUI() {
      checkInit();
      this.scrollbar.updateUI();
    }
    
    public String getUIClassID() { return this.scrollbar.getUIClassID(); }
    
    public int getOrientation() { return this.scrollbar.getOrientation(); }
    
    public void setOrientation(int param1Int) { this.scrollbar.setOrientation(param1Int); }
    
    public BoundedRangeModel getModel() { return this.scrollbar.getModel(); }
    
    public void setModel(BoundedRangeModel param1BoundedRangeModel) { this.scrollbar.setModel(param1BoundedRangeModel); }
    
    public int getUnitIncrement(int param1Int) { return this.scrollbar.getUnitIncrement(param1Int); }
    
    public void setUnitIncrement(int param1Int) { this.scrollbar.setUnitIncrement(param1Int); }
    
    public int getBlockIncrement(int param1Int) { return this.scrollbar.getBlockIncrement(param1Int); }
    
    public void setBlockIncrement(int param1Int) { this.scrollbar.setBlockIncrement(param1Int); }
    
    public int getUnitIncrement() { return this.scrollbar.getUnitIncrement(); }
    
    public int getBlockIncrement() { return this.scrollbar.getBlockIncrement(); }
    
    public int getValue() { return this.scrollbar.getValue(); }
    
    public void setValue(int param1Int) { this.scrollbar.setValue(param1Int); }
    
    public int getVisibleAmount() { return this.scrollbar.getVisibleAmount(); }
    
    public void setVisibleAmount(int param1Int) { this.scrollbar.setVisibleAmount(param1Int); }
    
    public int getMinimum() { return this.scrollbar.getMinimum(); }
    
    public void setMinimum(int param1Int) { this.scrollbar.setMinimum(param1Int); }
    
    public int getMaximum() { return this.scrollbar.getMaximum(); }
    
    public void setMaximum(int param1Int) { this.scrollbar.setMaximum(param1Int); }
    
    public boolean getValueIsAdjusting() { return this.scrollbar.getValueIsAdjusting(); }
    
    public void setValueIsAdjusting(boolean param1Boolean) { this.scrollbar.setValueIsAdjusting(param1Boolean); }
    
    public void setValues(int param1Int1, int param1Int2, int param1Int3, int param1Int4) { this.scrollbar.setValues(param1Int1, param1Int2, param1Int3, param1Int4); }
    
    public void addAdjustmentListener(AdjustmentListener param1AdjustmentListener) { this.scrollbar.addAdjustmentListener(param1AdjustmentListener); }
    
    public void removeAdjustmentListener(AdjustmentListener param1AdjustmentListener) { this.scrollbar.removeAdjustmentListener(param1AdjustmentListener); }
    
    public void setEnabled(boolean param1Boolean) { this.scrollbar.setEnabled(param1Boolean); }
    
    private void checkInit() {
      if (this.scrollbar == null)
        this.scrollbar = new JScrollBar(0); 
    }
    
    class SmallButton extends JButton {
      private final JPreviewPane.StatusScrollBar this$1;
      
      public SmallButton(JPreviewPane.StatusScrollBar this$0, String param2String) {
        super(param2String);
        this.this$1 = this$0;
      }
      
      public Dimension getPreferredSize() { return new Dimension((super.getPreferredSize()).width, (this.this$1.scrollbar.getPreferredSize()).height); }
      
      public Dimension getMinimumSize() { return new Dimension((super.getMinimumSize()).width, (this.this$1.scrollbar.getMinimumSize()).height); }
      
      public Dimension getMaximumSize() { return new Dimension((super.getMaximumSize()).width, (this.this$1.scrollbar.getMaximumSize()).height); }
      
      public float getAlignmentY() { return this.this$1.scrollbar.getAlignmentY(); }
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\JPreviewPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */