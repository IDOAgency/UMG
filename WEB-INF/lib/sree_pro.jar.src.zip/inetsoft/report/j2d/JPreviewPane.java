/*     */ package inetsoft.report.j2d;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.PreviewPane;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.internal.Util;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Adjustable;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.AdjustmentListener;
/*     */ import javax.swing.BoundedRangeModel;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.plaf.ScrollBarUI;
/*     */ 
/*     */ 
/*     */ public class JPreviewPane
/*     */   extends PreviewPane
/*     */ {
/*     */   protected StatusScrollPane scroller;
/*     */   
/*     */   protected Container createScrollPane() {
/*  38 */     this.scroller = new StatusScrollPane(this);
/*     */     
/*  40 */     this.scroller.bar.pageB.addActionListener(new ActionListener(this) { private final JPreviewPane this$0;
/*     */           
/*  42 */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.gotoPage(); }
/*     */            }
/*     */       );
/*     */     
/*  46 */     this.scroller.getVerticalScrollBar().setUnitIncrement(18);
/*  47 */     this.scroller.getHorizontalScrollBar().setUnitIncrement(18);
/*  48 */     this.scroller.getHorizontalScrollBar().setBlockIncrement(200);
/*     */     
/*  50 */     return this.scroller;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   protected void addToScrollPane(Component paramComponent) { ((JScrollPane)this.scrollpane).setViewportView(paramComponent); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected Container getViewport() { return ((JScrollPane)this.scrollpane).getViewport(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   protected int getBlockIncrement(Adjustable paramAdjustable) { return ((JScrollBar)paramAdjustable).getBlockIncrement(1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public Dimension getViewportSize() { return ((JScrollPane)this.scrollpane).getViewport().getSize(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public Adjustable getVAdjustable() { return ((JScrollPane)this.scrollpane).getVerticalScrollBar(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public Adjustable getHAdjustable() { return ((JScrollPane)this.scrollpane).getHorizontalScrollBar(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void syncScrollPane() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public void showPageNumber(int paramInt) { this.scroller.bar.pageB.setLabel(Catalog.getString("Page") + " " + paramInt + " " + Catalog.getString("of") + " " + getPageCount()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public void showPageSize(Size paramSize) { this.scroller.bar.sizeB.setLabel(paramSize.width + " x " + paramSize.height + " in"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public void showStatus(String paramString) { this.scroller.bar.statusF.setLabel(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gotoPage() {
/* 136 */     JDialog jDialog = new JDialog(Util.findFrame(this), Catalog.getString("Go To Page"));
/*     */     
/* 138 */     JTextField jTextField = new JTextField(8);
/*     */     
/* 140 */     jDialog.getContentPane().setLayout(new BorderLayout(20, 20));
/* 141 */     jDialog.getContentPane().add(new Component(this) { private final JPreviewPane this$0; }, "North");
/*     */     
/* 143 */     JPanel jPanel = new JPanel();
/* 144 */     jPanel.add(new JLabel(Catalog.getString("Page") + ":"));
/* 145 */     jPanel.add(jTextField);
/* 146 */     jPanel.add(new JLabel(Catalog.getString("of") + " " + getPageCount()));
/* 147 */     jDialog.getContentPane().add(jPanel, "Center");
/*     */     
/* 149 */     jPanel = new JPanel();
/*     */     
/* 151 */     ActionListener actionListener = new ActionListener(this, jTextField, jDialog) { private final JTextField val$pgnumTF; private final JDialog val$win; private final JPreviewPane this$0;
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */           try {
/* 154 */             this.this$0.gotoPage(Integer.parseInt(this.val$pgnumTF.getText()));
/* 155 */             this.val$win.dispose();
/*     */           } catch (NumberFormatException numberFormatException) {
/* 157 */             this.val$pgnumTF.setText("");
/*     */           } 
/*     */         } }
/*     */       ;
/*     */     
/* 162 */     JButton jButton = new JButton("     " + Catalog.getString("OK") + "     ");
/* 163 */     jButton.addActionListener(actionListener);
/* 164 */     jPanel.add(jButton);
/*     */     
/* 166 */     jButton = new JButton("   " + Catalog.getString("Cancel") + "   ");
/* 167 */     jButton.addActionListener(new ActionListener(this, jDialog) { private final JDialog val$win; private final JPreviewPane this$0;
/*     */           
/* 169 */           public void actionPerformed(ActionEvent param1ActionEvent) { this.val$win.dispose(); }
/*     */            }
/*     */       );
/* 172 */     jPanel.add(jButton);
/*     */     
/* 174 */     jDialog.getContentPane().add(jPanel, "South");
/*     */     
/* 176 */     jTextField.setText("" + getPageNumber());
/* 177 */     jTextField.selectAll();
/* 178 */     jTextField.addActionListener(actionListener);
/*     */     
/* 180 */     Point point = getLocationOnScreen();
/* 181 */     Dimension dimension = getSize();
/* 182 */     jDialog.setLocation(point.x + dimension.width / 2 - 100, point.y + dimension.height / 2 - 80);
/* 183 */     jDialog.setModal(true);
/* 184 */     jDialog.pack();
/* 185 */     jDialog.setVisible(true);
/*     */   }
/*     */   protected class StatusScrollPane extends JScrollPane { JPreviewPane.StatusScrollBar bar; private final JPreviewPane this$0;
/*     */     public StatusScrollPane(JPreviewPane this$0) {
/* 189 */       this.this$0 = this$0;
/* 190 */       setHorizontalScrollBarPolicy(32);
/*     */     }
/*     */ 
/*     */     
/* 194 */     public JScrollBar createHorizontalScrollBar() { return this.bar = new JPreviewPane.StatusScrollBar(this.this$0); }
/*     */ 
/*     */ 
/*     */     
/* 198 */     public JPreviewPane.StatusScrollBar getScrollBar() { return this.bar; } }
/*     */   protected class StatusScrollBar extends JScrollBar { JScrollBar scrollbar;
/*     */     JButton pageB;
/*     */     JButton sizeB;
/*     */     JPanel statusPane;
/*     */     JButton statusF;
/*     */     private final JPreviewPane this$0;
/*     */     
/* 206 */     public StatusScrollBar(JPreviewPane this$0) { super(0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 353 */       this.scrollbar = null;
/* 354 */       this.pageB = new SmallButton(this, "Page 1 of 1");
/* 355 */       this.sizeB = new SmallButton(this, "8.5 x 11 in");
/* 356 */       this.statusPane = new JPanel();
/* 357 */       this.statusF = new JPreviewPane$5(this);
/*     */       setLayout(new BoxLayout(this, 0));
/*     */       checkInit();
/*     */       add(this.pageB);
/*     */       this.pageB.setMargin(new Insets(0, 15, 0, 15));
/*     */       Image image = Common.getImage(this, "/inetsoft/report/images/smallpage.gif");
/*     */       this.pageB.setIcon(new ImageIcon(image));
/*     */       add(this.sizeB);
/*     */       this.sizeB.setMargin(new Insets(0, 15, 0, 15));
/*     */       image = Common.getImage(this, "/inetsoft/report/images/smallpaper.gif");
/*     */       this.sizeB.setIcon(new ImageIcon(image));
/*     */       this.statusPane.setLayout(new BoxLayout(this.statusPane, 0));
/*     */       this.statusPane.add(this.statusF);
/*     */       add(this.statusPane);
/*     */       add(this.scrollbar); } public void clearStatus() { while (this.statusPane.getComponentCount() > 0)
/*     */         this.statusPane.remove(0);  } public void addStatus(Component param1Component) { this.statusPane.add(param1Component); } public ScrollBarUI getUI() { return this.scrollbar.getUI(); } public void updateUI() { checkInit();
/*     */       this.scrollbar.updateUI(); } public String getUIClassID() { return this.scrollbar.getUIClassID(); } public int getOrientation() { return this.scrollbar.getOrientation(); } public void setOrientation(int param1Int) { this.scrollbar.setOrientation(param1Int); } public BoundedRangeModel getModel() { return this.scrollbar.getModel(); } public void setModel(BoundedRangeModel param1BoundedRangeModel) { this.scrollbar.setModel(param1BoundedRangeModel); } public int getUnitIncrement(int param1Int) { return this.scrollbar.getUnitIncrement(param1Int); } public void setUnitIncrement(int param1Int) { this.scrollbar.setUnitIncrement(param1Int); } public int getBlockIncrement(int param1Int) { return this.scrollbar.getBlockIncrement(param1Int); } public void setBlockIncrement(int param1Int) { this.scrollbar.setBlockIncrement(param1Int); } public int getUnitIncrement() { return this.scrollbar.getUnitIncrement(); } public int getBlockIncrement() { return this.scrollbar.getBlockIncrement(); } public int getValue() { return this.scrollbar.getValue(); } public void setValue(int param1Int) { this.scrollbar.setValue(param1Int); } public int getVisibleAmount() { return this.scrollbar.getVisibleAmount(); } public void setVisibleAmount(int param1Int) { this.scrollbar.setVisibleAmount(param1Int); } public int getMinimum() { return this.scrollbar.getMinimum(); } public void setMinimum(int param1Int) { this.scrollbar.setMinimum(param1Int); } public int getMaximum() { return this.scrollbar.getMaximum(); } public void setMaximum(int param1Int) { this.scrollbar.setMaximum(param1Int); } public boolean getValueIsAdjusting() { return this.scrollbar.getValueIsAdjusting(); } public void setValueIsAdjusting(boolean param1Boolean) { this.scrollbar.setValueIsAdjusting(param1Boolean); } public void setValues(int param1Int1, int param1Int2, int param1Int3, int param1Int4) { this.scrollbar.setValues(param1Int1, param1Int2, param1Int3, param1Int4); } public void addAdjustmentListener(AdjustmentListener param1AdjustmentListener) { this.scrollbar.addAdjustmentListener(param1AdjustmentListener); } public void removeAdjustmentListener(AdjustmentListener param1AdjustmentListener) { this.scrollbar.removeAdjustmentListener(param1AdjustmentListener); } public void setEnabled(boolean param1Boolean) { this.scrollbar.setEnabled(param1Boolean); } private void checkInit() {
/*     */       if (this.scrollbar == null)
/*     */         this.scrollbar = new JScrollBar(0); 
/*     */     } class SmallButton extends JButton
/*     */     {
/*     */       public SmallButton(JPreviewPane.StatusScrollBar this$0, String param2String) {
/* 379 */         super(param2String);
/*     */         this.this$1 = this$0;
/*     */       }
/*     */       private final JPreviewPane.StatusScrollBar this$1;
/* 383 */       public Dimension getPreferredSize() { return new Dimension((super.getPreferredSize()).width, (this.this$1.scrollbar.getPreferredSize()).height); }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 388 */       public Dimension getMinimumSize() { return new Dimension((super.getMinimumSize()).width, (this.this$1.scrollbar.getMinimumSize()).height); }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 393 */       public Dimension getMaximumSize() { return new Dimension((super.getMaximumSize()).width, (this.this$1.scrollbar.getMaximumSize()).height); }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 398 */       public float getAlignmentY() { return this.this$1.scrollbar.getAlignmentY(); }
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\JPreviewPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */