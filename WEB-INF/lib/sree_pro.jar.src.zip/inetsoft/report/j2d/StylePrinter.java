/*     */ package inetsoft.report.j2d;
/*     */ 
/*     */ import inetsoft.report.ReportEnv;
/*     */ import java.awt.print.PrinterJob;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StylePrinter
/*     */ {
/*     */   public static PrinterJob getPrinterJob() {
/*  51 */     String str = null;
/*     */     try {
/*  53 */       str = ReportEnv.getProperty("StyleReport.useCustomDriver");
/*  54 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/*  57 */     if (str != null) {
/*     */       try {
/*  59 */         if (str.equalsIgnoreCase("true") && (ReportEnv.getProperty("os.name").startsWith("Windows NT") || ReportEnv.getProperty("os.name").startsWith("Windows 2")) && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0)
/*     */         {
/*     */ 
/*     */           
/*  63 */           return new Win32PrinterJob();
/*     */         }
/*  65 */         if (str.equalsIgnoreCase("win9x") || (str.equalsIgnoreCase("true") && ReportEnv.getProperty("os.name").startsWith("Windows 9") && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0))
/*     */         {
/*     */ 
/*     */           
/*  69 */           return new Win9xPrinterJob();
/*     */         }
/*  71 */         if (str.equalsIgnoreCase("postscript") || (str.equalsIgnoreCase("true") && (ReportEnv.getProperty("os.name").startsWith("Solaris") || ReportEnv.getProperty("os.name").startsWith("SunOS")) && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*  76 */           return new PSPrinterJob();
/*     */         }
/*     */         
/*  79 */         if (str.startsWith("class:")) {
/*  80 */           return (PrinterJob)Class.forName(str.substring(6).trim()).newInstance();
/*     */         
/*     */         }
/*     */       }
/*     */       catch (Exception exception) {
/*     */         
/*  86 */         if (exception.getMessage() == null || !exception.getMessage().startsWith("Unable to initialize"))
/*     */         {
/*  88 */           exception.printStackTrace();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*  93 */     return PrinterJob.getPrinterJob();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PrinterJob getPrinterJob(String paramString) {
/* 104 */     String str = null;
/*     */     try {
/* 106 */       str = ReportEnv.getProperty("StyleReport.useCustomDriver");
/* 107 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 110 */     if (str != null) {
/*     */       try {
/* 112 */         if (str.equalsIgnoreCase("true") && ReportEnv.getProperty("os.name").startsWith("Windows NT") && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0)
/*     */         {
/*     */           
/* 115 */           return new Win32PrinterJob(paramString);
/*     */         }
/* 117 */         if (str.equalsIgnoreCase("win9x") || (str.equalsIgnoreCase("true") && ReportEnv.getProperty("os.name").startsWith("Windows 9") && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0))
/*     */         {
/*     */ 
/*     */           
/* 121 */           return new Win9xPrinterJob(paramString);
/*     */         }
/* 123 */         if (str.equalsIgnoreCase("postscript") || (str.equalsIgnoreCase("true") && (ReportEnv.getProperty("os.name").startsWith("Solaris") || ReportEnv.getProperty("os.name").startsWith("SunOS")) && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0)) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 128 */           PSPrinterJob pSPrinterJob = new PSPrinterJob();
/* 129 */           pSPrinterJob.setPrinter(paramString);
/* 130 */           pSPrinterJob.setPrintToFile(false);
/*     */           
/* 132 */           return pSPrinterJob;
/*     */         } 
/* 134 */         if (str.startsWith("class:")) {
/* 135 */           Class clazz = Class.forName(str.substring(6).trim());
/* 136 */           Constructor constructor = null;
/* 137 */           FileOutputStream fileOutputStream = paramString;
/*     */           
/*     */           try {
/* 140 */             constructor = clazz.getConstructor(new Class[] { String.class });
/* 141 */           } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */           
/* 145 */           if (constructor == null) {
/*     */             try {
/* 147 */               constructor = clazz.getConstructor(new Class[] { java.io.OutputStream.class });
/* 148 */               fileOutputStream = new FileOutputStream(new File(paramString));
/* 149 */             } catch (Exception exception) {}
/*     */           }
/*     */ 
/*     */           
/* 153 */           return (constructor == null) ? (PrinterJob)clazz.newInstance() : (PrinterJob)constructor.newInstance(new Object[] { fileOutputStream });
/*     */         }
/*     */       
/*     */       }
/* 157 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 162 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\StylePrinter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */