package inetsoft.report.j2d;

import inetsoft.report.ReportEnv;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Constructor;

public class StylePrinter {
  public static PrinterJob getPrinterJob() {
    String str = null;
    try {
      str = ReportEnv.getProperty("StyleReport.useCustomDriver");
    } catch (Exception exception) {}
    if (str != null)
      try {
        if (str.equalsIgnoreCase("true") && (ReportEnv.getProperty("os.name").startsWith("Windows NT") || ReportEnv.getProperty("os.name").startsWith("Windows 2")) && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0)
          return new Win32PrinterJob(); 
        if (str.equalsIgnoreCase("win9x") || (str.equalsIgnoreCase("true") && ReportEnv.getProperty("os.name").startsWith("Windows 9") && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0))
          return new Win9xPrinterJob(); 
        if (str.equalsIgnoreCase("postscript") || (str.equalsIgnoreCase("true") && (ReportEnv.getProperty("os.name").startsWith("Solaris") || ReportEnv.getProperty("os.name").startsWith("SunOS")) && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0))
          return new PSPrinterJob(); 
        if (str.startsWith("class:"))
          return (PrinterJob)Class.forName(str.substring(6).trim()).newInstance(); 
      } catch (Exception exception) {
        if (exception.getMessage() == null || !exception.getMessage().startsWith("Unable to initialize"))
          exception.printStackTrace(); 
      }  
    return PrinterJob.getPrinterJob();
  }
  
  public static PrinterJob getPrinterJob(String paramString) {
    String str = null;
    try {
      str = ReportEnv.getProperty("StyleReport.useCustomDriver");
    } catch (Exception exception) {}
    if (str != null)
      try {
        if (str.equalsIgnoreCase("true") && ReportEnv.getProperty("os.name").startsWith("Windows NT") && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0)
          return new Win32PrinterJob(paramString); 
        if (str.equalsIgnoreCase("win9x") || (str.equalsIgnoreCase("true") && ReportEnv.getProperty("os.name").startsWith("Windows 9") && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0))
          return new Win9xPrinterJob(paramString); 
        if (str.equalsIgnoreCase("postscript") || (str.equalsIgnoreCase("true") && (ReportEnv.getProperty("os.name").startsWith("Solaris") || ReportEnv.getProperty("os.name").startsWith("SunOS")) && ReportEnv.getProperty("java.version").compareTo("1.2") >= 0)) {
          PSPrinterJob pSPrinterJob = new PSPrinterJob();
          pSPrinterJob.setPrinter(paramString);
          pSPrinterJob.setPrintToFile(false);
          return pSPrinterJob;
        } 
        if (str.startsWith("class:")) {
          Class clazz = Class.forName(str.substring(6).trim());
          Constructor constructor = null;
          FileOutputStream fileOutputStream = paramString;
          try {
            constructor = clazz.getConstructor(new Class[] { String.class });
          } catch (Exception exception) {}
          if (constructor == null)
            try {
              constructor = clazz.getConstructor(new Class[] { java.io.OutputStream.class });
              fileOutputStream = new FileOutputStream(new File(paramString));
            } catch (Exception exception) {} 
          return (constructor == null) ? (PrinterJob)clazz.newInstance() : (PrinterJob)constructor.newInstance(new Object[] { fileOutputStream });
        } 
      } catch (Exception exception) {} 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\StylePrinter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */