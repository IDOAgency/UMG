package inetsoft.report.j2d;

import inetsoft.report.Margin;
import inetsoft.report.PreviewPage;
import inetsoft.report.StyleSheet;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.PrintJob;

public class PreviewPage2D extends PreviewPage {
  public PreviewPage2D(double paramDouble1, double paramDouble2) { super(paramDouble1, paramDouble2); }
  
  public PreviewPage2D(PrintJob paramPrintJob) { super(paramPrintJob); }
  
  public PreviewPage2D(double paramDouble1, double paramDouble2, int paramInt) { super(paramDouble1, paramDouble2, paramInt); }
  
  public void paint(Graphics paramGraphics) { paintPage(paramGraphics, this); }
  
  public static void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) {
    Dimension dimension = paramPreviewPage.getSize();
    Graphics2D graphics2D = (Graphics2D)paramGraphics.create();
    graphics2D.setFont(new Font("Arial", 0, 8));
    graphics2D.drawString("|", 10, 10);
    graphics2D.setClip(paramGraphics.getClip());
    graphics2D.setColor(Color.white);
    graphics2D.fillRect(0, 0, dimension.width, dimension.height);
    paramPreviewPage.paintBG(graphics2D);
    graphics2D.setColor(Color.black);
    if (paramPreviewPage.isDrawBorder())
      graphics2D.drawRect(0, 0, dimension.width - 1, dimension.height - 1); 
    Margin margin = StyleSheet.getPrinterMargin();
    graphics2D.scale(dimension.width / (paramPreviewPage.getPageSize()).width, dimension.height / (paramPreviewPage.getPageSize()).height);
    graphics2D.translate((int)(margin.left * 72.0D), (int)(margin.top * 72.0D));
    if (paramPreviewPage.getStylePage() != null)
      paramPreviewPage.getStylePage().print(graphics2D); 
    graphics2D.dispose();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\PreviewPage2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */