/*     */ package inetsoft.report.j2d;
/*     */ 
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.PreviewPage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.PrintJob;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreviewPage2D
/*     */   extends PreviewPage
/*     */ {
/*  41 */   public PreviewPage2D(double paramDouble1, double paramDouble2) { super(paramDouble1, paramDouble2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public PreviewPage2D(PrintJob paramPrintJob) { super(paramPrintJob); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public PreviewPage2D(double paramDouble1, double paramDouble2, int paramInt) { super(paramDouble1, paramDouble2, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public void paint(Graphics paramGraphics) { paintPage(paramGraphics, this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void paintPage(Graphics paramGraphics, PreviewPage paramPreviewPage) {
/*  77 */     Dimension dimension = paramPreviewPage.getSize();
/*     */     
/*  79 */     Graphics2D graphics2D = (Graphics2D)paramGraphics.create();
/*     */ 
/*     */ 
/*     */     
/*  83 */     graphics2D.setFont(new Font("Arial", 0, 8));
/*  84 */     graphics2D.drawString("|", 10, 10);
/*     */     
/*  86 */     graphics2D.setClip(paramGraphics.getClip());
/*  87 */     graphics2D.setColor(Color.white);
/*  88 */     graphics2D.fillRect(0, 0, dimension.width, dimension.height);
/*     */     
/*  90 */     paramPreviewPage.paintBG(graphics2D);
/*  91 */     graphics2D.setColor(Color.black);
/*     */     
/*  93 */     if (paramPreviewPage.isDrawBorder()) {
/*  94 */       graphics2D.drawRect(0, 0, dimension.width - 1, dimension.height - 1);
/*     */     }
/*     */     
/*  97 */     Margin margin = StyleSheet.getPrinterMargin();
/*  98 */     graphics2D.scale(dimension.width / (paramPreviewPage.getPageSize()).width, dimension.height / (paramPreviewPage.getPageSize()).height);
/*     */     
/* 100 */     graphics2D.translate((int)(margin.left * 72.0D), (int)(margin.top * 72.0D));
/*     */     
/* 102 */     if (paramPreviewPage.getStylePage() != null) {
/* 103 */       paramPreviewPage.getStylePage().print(graphics2D);
/*     */     }
/*     */     
/* 106 */     graphics2D.dispose();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\PreviewPage2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */