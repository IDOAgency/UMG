package inetsoft.report.j2d;

import inetsoft.report.Margin;
import inetsoft.report.StyleSheet;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.util.Vector;

public class StyleBook extends Book {
  Margin pmargin;
  
  public StyleBook(StyleSheet paramStyleSheet) { this(paramStyleSheet, new PageFormat()); }
  
  public StyleBook(StyleSheet paramStyleSheet, PageFormat paramPageFormat) {
    Vector vector = new Vector();
    boolean bool = true;
    Paper paper = paramPageFormat.getPaper();
    Margin margin = StyleSheet.getPrinterMargin();
    this.pmargin = new Margin(margin);
    synchronized (StyleSheet.class) {
      if (paramPageFormat.getOrientation() == 0) {
        this.pmargin.left *= -1.0D;
        StyleSheet.setPrinterMargin(this.pmargin);
      } 
      paper.setImageableArea(paper.getImageableX() - margin.left * 72.0D, 0.0D, paper.getImageableWidth(), paper.getHeight());
      paramPageFormat.setPaper(paper);
      paramStyleSheet.reset();
      for (byte b = 0; bool; b++) {
        StylePage2D stylePage2D = new StylePage2D(paramPageFormat);
        bool = paramStyleSheet.printNext(stylePage2D);
        vector.addElement(stylePage2D);
        append(stylePage2D, paramPageFormat);
      } 
      StyleSheet.setPrinterMargin(margin);
    } 
  }
  
  public Margin getMargin() { return this.pmargin; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\StyleBook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */