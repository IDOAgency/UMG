/*    */ package inetsoft.report.j2d;
/*    */ 
/*    */ import inetsoft.report.Margin;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import java.awt.print.Book;
/*    */ import java.awt.print.PageFormat;
/*    */ import java.awt.print.Paper;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StyleBook
/*    */   extends Book
/*    */ {
/*    */   Margin pmargin;
/*    */   
/* 37 */   public StyleBook(StyleSheet paramStyleSheet) { this(paramStyleSheet, new PageFormat()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public StyleBook(StyleSheet paramStyleSheet, PageFormat paramPageFormat) {
/* 44 */     Vector vector = new Vector();
/* 45 */     boolean bool = true;
/*    */ 
/*    */ 
/*    */     
/* 49 */     Paper paper = paramPageFormat.getPaper();
/* 50 */     Margin margin = StyleSheet.getPrinterMargin();
/* 51 */     this.pmargin = new Margin(margin);
/*    */     
/* 53 */     synchronized (StyleSheet.class) {
/* 54 */       if (paramPageFormat.getOrientation() == 0) {
/* 55 */         this.pmargin.left *= -1.0D;
/* 56 */         StyleSheet.setPrinterMargin(this.pmargin);
/*    */       } 
/*    */ 
/*    */       
/* 60 */       paper.setImageableArea(paper.getImageableX() - margin.left * 72.0D, 0.0D, paper.getImageableWidth(), paper.getHeight());
/*    */       
/* 62 */       paramPageFormat.setPaper(paper);
/*    */       
/* 64 */       paramStyleSheet.reset();
/*    */       
/* 66 */       for (byte b = 0; bool; b++) {
/* 67 */         StylePage2D stylePage2D = new StylePage2D(paramPageFormat);
/* 68 */         bool = paramStyleSheet.printNext(stylePage2D);
/* 69 */         vector.addElement(stylePage2D);
/* 70 */         append(stylePage2D, paramPageFormat);
/*    */       } 
/*    */       
/* 73 */       StyleSheet.setPrinterMargin(margin);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 81 */   public Margin getMargin() { return this.pmargin; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\StyleBook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */