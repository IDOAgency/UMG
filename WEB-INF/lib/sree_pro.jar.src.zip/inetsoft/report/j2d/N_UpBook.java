/*     */ package inetsoft.report.j2d;
/*     */ 
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.print.Book;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Paper;
/*     */ import java.awt.print.Printable;
/*     */ import java.awt.print.PrinterException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class N_UpBook
/*     */   extends Book
/*     */ {
/*     */   private static final int ROTATE = 256;
/*     */   private static final int UPMASK = 255;
/*     */   public static final int N_2_UP = 258;
/*     */   public static final int N_4_UP = 4;
/*     */   public static final int N_6_UP = 262;
/*     */   public static final int N_9_UP = 9;
/*     */   public static final int N_16_UP = 16;
/*     */   double w;
/*     */   double h;
/*     */   int nrow;
/*     */   int ncol;
/*     */   int nup;
/*     */   double scale;
/*     */   StyleBook book;
/*     */   
/*     */   public N_UpBook(StyleSheet paramStyleSheet, PageFormat paramPageFormat, int paramInt) {
/*  62 */     this.nup = paramInt;
/*     */ 
/*     */     
/*  65 */     paramPageFormat.setOrientation(1);
/*     */     
/*  67 */     PageFormat pageFormat = (PageFormat)paramPageFormat.clone();
/*  68 */     pageFormat.setOrientation(((paramInt & 0x100) != 0) ? 0 : 1);
/*     */ 
/*     */     
/*  71 */     double d1 = pageFormat.getImageableWidth();
/*  72 */     double d2 = pageFormat.getImageableHeight();
/*  73 */     double d3 = pageFormat.getImageableX();
/*  74 */     double d4 = pageFormat.getImageableY();
/*     */ 
/*     */     
/*  77 */     switch (paramInt) {
/*     */       case 258:
/*  79 */         this.nrow = 1;
/*  80 */         this.ncol = 2;
/*     */         break;
/*     */       case 4:
/*  83 */         this.nrow = this.ncol = 2;
/*     */         break;
/*     */       case 262:
/*  86 */         this.nrow = 2;
/*  87 */         this.ncol = 3;
/*     */         break;
/*     */       case 9:
/*  90 */         this.nrow = this.ncol = 3;
/*     */         break;
/*     */       case 16:
/*  93 */         this.nrow = this.ncol = 4;
/*     */         break;
/*     */       default:
/*  96 */         throw new UnsupportedOperationException("N-Up operation not supported: " + paramInt);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     d3 /= this.ncol;
/* 103 */     d4 /= this.nrow;
/*     */     
/* 105 */     this.w = (d1 - (this.ncol - 1) * d3) / this.ncol;
/* 106 */     this.h = (d2 - (this.nrow - 1) * d4) / this.nrow;
/*     */ 
/*     */     
/* 109 */     this.scale = Math.min(this.w / d1, this.h / d2);
/* 110 */     this.w = this.scale * paramPageFormat.getWidth();
/* 111 */     this.h = this.scale * paramPageFormat.getHeight();
/*     */ 
/*     */     
/* 114 */     this.book = new StyleBook(paramStyleSheet, paramPageFormat);
/*     */ 
/*     */     
/* 117 */     Paper paper = pageFormat.getPaper();
/* 118 */     paper.setImageableArea(0.0D, 0.0D, paper.getWidth(), paper.getHeight());
/* 119 */     pageFormat.setPaper(paper);
/*     */     
/* 121 */     int i = (int)Math.ceil((this.book.getNumberOfPages() / (paramInt & 0xFF)));
/* 122 */     for (byte b = 0; b < i; b++)
/* 123 */       append(new NupPage(this, b), pageFormat); 
/*     */   }
/*     */   
/*     */   class NupPage implements Printable {
/*     */     public NupPage(N_UpBook this$0, int param1Int) {
/* 128 */       this.this$0 = this$0;
/* 129 */       this.pi = param1Int * (this$0.nup & 0xFF);
/*     */     }
/*     */     
/*     */     int pi;
/*     */     
/*     */     public int print(Graphics param1Graphics, PageFormat param1PageFormat, int param1Int) throws PrinterException {
/* 135 */       Graphics2D graphics2D = (Graphics2D)param1Graphics;
/*     */ 
/*     */       
/* 138 */       double d1 = param1PageFormat.getImageableWidth() / this.this$0.ncol;
/* 139 */       double d2 = param1PageFormat.getImageableHeight() / this.this$0.nrow;
/*     */ 
/*     */ 
/*     */       
/* 143 */       double d3 = (d1 - this.this$0.w) / 2.0D + param1PageFormat.getImageableX();
/* 144 */       double d4 = (d2 - this.this$0.h) / 2.0D + param1PageFormat.getImageableY();
/*     */ 
/*     */       
/* 147 */       Margin margin = this.this$0.book.getMargin();
/* 148 */       if ((this.this$0.nup & 0x100) != 0) {
/* 149 */         d3 -= margin.top * 72.0D * (1.0D - this.this$0.scale);
/* 150 */         d4 -= margin.left * 72.0D * (1.0D - this.this$0.scale);
/*     */       } else {
/*     */         
/* 153 */         d3 -= margin.left * 72.0D * (1.0D - this.this$0.scale);
/* 154 */         d4 -= margin.top * 72.0D * (1.0D - this.this$0.scale);
/*     */       } 
/*     */ 
/*     */       
/* 158 */       for (int i = 0; i < (this.this$0.nup & 0xFF) && this.pi + i < this.this$0.book.getNumberOfPages(); 
/* 159 */         i++) {
/* 160 */         int j = i / this.this$0.ncol;
/* 161 */         int k = i % this.this$0.ncol;
/* 162 */         Rectangle2D.Double double = new Rectangle2D.Double(k * d1 + d3, j * d2 + d4, this.this$0.w, this.this$0.h);
/*     */ 
/*     */         
/* 165 */         Graphics2D graphics2D1 = (Graphics2D)param1Graphics.create();
/* 166 */         graphics2D1.clip(double);
/* 167 */         graphics2D1.translate(double.getX(), double.getY());
/* 168 */         graphics2D1.scale(this.this$0.scale, this.this$0.scale);
/*     */         
/* 170 */         this.this$0.book.getPrintable(this.pi + i).print(graphics2D1, param1PageFormat, this.pi + i);
/* 171 */         graphics2D1.dispose();
/*     */       } 
/*     */       
/* 174 */       return 0;
/*     */     }
/*     */     
/*     */     private final N_UpBook this$0;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\N_UpBook.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */