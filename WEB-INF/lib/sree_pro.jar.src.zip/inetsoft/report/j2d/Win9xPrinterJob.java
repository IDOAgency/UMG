/*     */ package inetsoft.report.j2d;
/*     */ 
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.j2d.Win9xGraphics2D;
/*     */ import java.awt.print.PageFormat;
/*     */ import java.awt.print.Pageable;
/*     */ import java.awt.print.Printable;
/*     */ import java.awt.print.PrinterJob;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Win9xPrinterJob
/*     */   extends PrinterJob
/*     */ {
/*     */   Win9xGraphics2D wing;
/*     */   
/*     */   public Win9xPrinterJob() {
/*  35 */     this.wing = Win9xGraphics2D.getGraphics(null);
/*  36 */     if (this.wing == null) {
/*  37 */       throw new RuntimeException("Unable to initialize Win9xGraphics2D");
/*     */     }
/*     */     
/*  40 */     this.wing.setPrinterJob(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Win9xPrinterJob(String paramString) {
/*  48 */     this.wing = Win9xGraphics2D.getGraphics(paramString);
/*  49 */     if (this.wing == null) {
/*  50 */       throw new RuntimeException("Unable to initialize Win9xGraphics2D");
/*     */     }
/*     */     
/*  53 */     this.wing.setPrinterJob(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void setDuplex(boolean paramBoolean) { this.wing.setDuplex(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public boolean isDuplex() { return this.wing.isDuplex(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public void setTray(int paramInt) { this.wing.setTray(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void setPrintable(Printable paramPrintable) { this.painter = paramPrintable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrintable(Printable paramPrintable, PageFormat paramPageFormat) {
/* 106 */     setPrintable(paramPrintable);
/* 107 */     this.format = paramPageFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public void setPageable(Pageable paramPageable) throws NullPointerException { this.book = paramPageable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean printDialog() {
/* 133 */     int i = -1;
/* 134 */     if (this.book != null) {
/* 135 */       i = this.book.getNumberOfPages();
/*     */     }
/*     */     
/* 138 */     boolean bool = this.wing.printDialog(i);
/* 139 */     if (bool) {
/* 140 */       this.copies = this.wing.getCopies();
/*     */     }
/*     */     
/* 143 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public PageFormat pageDialog(PageFormat paramPageFormat) { return this.defJob.pageDialog(paramPageFormat); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   public PageFormat defaultPage(PageFormat paramPageFormat) { return (PageFormat)paramPageFormat.clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public PageFormat validatePage(PageFormat paramPageFormat) { return paramPageFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print() {
/* 203 */     synchronized (StyleSheet.class) {
/* 204 */       this.wing.startDoc(getJobName());
/* 205 */       Margin margin = StyleSheet.getPrinterMargin();
/*     */       
/* 207 */       if (this.book != null) {
/* 208 */         if (this.book instanceof StyleBook) {
/* 209 */           StyleSheet.setPrinterMargin(((StyleBook)this.book).getMargin());
/*     */         }
/*     */         
/* 212 */         int i = this.wing.isPages() ? this.wing.getFromPage() : 1;
/* 213 */         int j = this.wing.isPages() ? this.wing.getToPage() : this.book.getNumberOfPages();
/*     */         
/* 215 */         for (int k = Math.max(1, i); k <= j; k++) {
/* 216 */           int m = k - 1;
/* 217 */           PageFormat pageFormat = this.book.getPageFormat(m);
/*     */           
/* 219 */           this.wing.setOrientation(pageFormat.getOrientation());
/* 220 */           this.wing.startPage();
/*     */           
/* 222 */           this.book.getPrintable(m).print(this.wing, pageFormat, k);
/* 223 */           this.wing.dispose();
/*     */         }
/*     */       
/* 226 */       } else if (this.painter != null) {
/* 227 */         this.wing.setOrientation(this.format.getOrientation());
/*     */         
/* 229 */         if (this.painter instanceof StylePrintable) {
/* 230 */           StyleSheet.setPrinterMargin(((StylePrintable)this.painter).getMargin());
/*     */         }
/*     */ 
/*     */         
/* 234 */         byte b = 0;
/* 235 */         for (; this.painter.print(this.wing, this.format, b) != 1; b++) {
/* 236 */           this.wing.dispose();
/*     */         }
/*     */       } 
/*     */       
/* 240 */       StyleSheet.setPrinterMargin(margin);
/* 241 */       this.wing.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCopies(int paramInt) {
/* 250 */     this.copies = paramInt;
/* 251 */     this.wing.setCopies(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 259 */   public int getCopies() { return this.copies; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserName() {
/*     */     try {
/* 268 */       return ReportEnv.getProperty("user.name");
/* 269 */     } catch (Exception exception) {
/*     */ 
/*     */       
/* 272 */       return "Unknown";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public void setJobName(String paramString) { this.jobname = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 289 */   public String getJobName() { return this.jobname; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 301 */   public void cancel() { this.cancelled = true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 313 */   public boolean isCancelled() { return this.cancelled; }
/*     */ 
/*     */ 
/*     */   
/* 317 */   Printable painter = null;
/* 318 */   Pageable book = null;
/* 319 */   PageFormat format = new PageFormat();
/* 320 */   int copies = 1;
/* 321 */   String jobname = "Report";
/*     */   boolean cancelled = false;
/* 323 */   PrinterJob defJob = PrinterJob.getPrinterJob();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\Win9xPrinterJob.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */