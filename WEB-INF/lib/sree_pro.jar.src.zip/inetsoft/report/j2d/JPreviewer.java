/*     */ package inetsoft.report.j2d;
/*     */ import inetsoft.report.PreviewPane;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.event.SelectionListener;
/*     */ import inetsoft.report.internal.PagesMenu;
/*     */ import inetsoft.report.internal.j2d.Common2D;
/*     */ import inetsoft.report.io.Builder;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.PrintJob;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.FileInputStream;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.JToolBar;
/*     */ 
/*     */ public class JPreviewer extends JFrame implements PreviewView, ActionListener {
/*     */   ItemListener zoomListener;
/*     */   protected StyleSheet sheet;
/*     */   protected PreviewPane pane;
/*     */   JButton printerB;
/*     */   JButton onepageB;
/*     */   JButton fullscrB;
/*     */   JButton closeB;
/*     */   JToggleButton npageB;
/*     */   PagesMenu menu;
/*     */   Dimension psize;
/*     */   JComboBox zoomChoice;
/*     */   PrintJob printjob;
/*     */   boolean exitit;
/*     */   int fsCount;
/*     */   Dimension frameSize;
/*     */   protected JToolBar toolbar;
/*     */   
/*  46 */   public JPreviewer() { this(Catalog.getString("Print Preview")); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JPreviewer(String paramString, boolean paramBoolean) {
/*  57 */     this(paramString);
/*     */     
/*  59 */     if (paramBoolean) {
/*  60 */       this.zoomChoice.setSelectedItem(Catalog.getString("Whole Page"));
/*  61 */       this.zoomListener.itemStateChanged(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JPreviewer(String paramString, PrintJob paramPrintJob, boolean paramBoolean) {
/*  79 */     this(paramString, paramBoolean);
/*  80 */     this.printjob = paramPrintJob;
/*     */     
/*  82 */     Dimension dimension = paramPrintJob.getPageDimension();
/*     */     
/*  84 */     setPageWidth(dimension.width / 72.0D);
/*  85 */     setPageHeight(dimension.height / 72.0D);
/*  86 */     setPageResolution(72);
/*     */   }
/*     */   public JPreviewer(String paramString, int paramInt1, int paramInt2) { this(paramString); this.psize = new Dimension(paramInt1, paramInt2); }
/*     */   protected PreviewPane createPane() { return new JPreviewPane(); } public Dimension getPreferredSize() { if (this.psize != null) return this.psize;  Dimension dimension = new Dimension(getToolkit().getScreenSize()); dimension.width = Math.min(dimension.width, 800); dimension.height = Math.min(dimension.height, 800); return dimension; } public void setPreferredSize(Dimension paramDimension) { this.psize = new Dimension(paramDimension); } public void setToolbarButtons(int paramInt) { this.toolbar.remove(this.printerB); this.toolbar.remove(this.onepageB); this.toolbar.remove(this.npageB); this.toolbar.remove(this.fullscrB); this.toolbar.remove(this.zoomChoice); this.toolbar.remove(this.closeB); byte b = 0; if ((paramInt & true) != 0) this.toolbar.add(this.printerB, b++);  if ((paramInt & 0x2) != 0)
/*     */       this.toolbar.add(this.onepageB, b++);  if ((paramInt & 0x4) != 0)
/*     */       this.toolbar.add(this.npageB, b++);  if ((paramInt & 0x8) != 0)
/*     */       this.toolbar.add(this.fullscrB, b++);  if ((paramInt & 0x10) != 0)
/*     */       this.toolbar.add(this.zoomChoice, b++);  if ((paramInt & 0x20) != 0)
/*  94 */       this.toolbar.add(this.closeB, b++);  } public void addToolbarComponent(Component paramComponent) { this.toolbar.add(paramComponent); } public void setPageWidth(double paramDouble) { this.pane.setPageWidth(paramDouble); } public double getPageWidth() { return this.pane.getPageWidth(); } public void setPageHeight(double paramDouble) { this.pane.setPageHeight(paramDouble); } public JPreviewer(String paramString) { super(paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 409 */     this.zoomListener = new ItemListener(this) { private final JPreviewer this$0;
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 411 */           int i = this.this$0.zoomChoice.getSelectedIndex();
/* 412 */           if (i >= 0) {
/* 413 */             this.this$0.pane.zoom(JPreviewer.zoomperc[i]);
/*     */           }
/*     */         } }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 503 */     this.menu = null;
/*     */ 
/*     */ 
/*     */     
/* 507 */     this.exitit = false;
/* 508 */     this.fsCount = 0;
/*     */ 
/*     */ 
/*     */     
/* 512 */     this.toolbar = new JToolBar(); getContentPane().setLayout(new BorderLayout()); this.printerB = Common2D.createToolButton(null, "/inetsoft/report/images/printer.gif"); this.toolbar.add(this.printerB); this.printerB.setToolTipText(Catalog.getString("Print")); this.printerB.addActionListener(this); this.toolbar.addSeparator(); this.onepageB = Common2D.createToolButton(null, "/inetsoft/report/images/onepage.gif"); this.toolbar.add(this.onepageB); this.onepageB.setToolTipText(Catalog.getString("One Page")); this.onepageB.addActionListener(new ActionListener(this) { private final JPreviewer this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.zoomChoice.setSelectedItem(Catalog.getString("Whole Page")); this.this$0.zoomListener.itemStateChanged(null); } }
/*     */       ); this.npageB = Common2D.createToolButton(null, "/inetsoft/report/images/npage.gif", false); this.toolbar.add(this.npageB); this.npageB.setToolTipText(Catalog.getString("Multiple Pages")); this.npageB.addActionListener(new ActionListener(this) { private final JPreviewer this$0; public void actionPerformed(ActionEvent param1ActionEvent) { if (this.this$0.npageB.isSelected()) { this.this$0.menu = new PagesMenu(this.this$0); Point point = this.this$0.npageB.getLocationOnScreen(); point.y += (this.this$0.npageB.getSize()).height; this.this$0.menu.pack(); this.this$0.menu.setLocation(point); this.this$0.menu.setVisible(true); this.this$0.menu.setLocation(point); this.this$0.menu.addWindowListener(new JPreviewer$3(this)); this.this$0.menu.addActionListener(new JPreviewer$4(this)); } else if (this.this$0.menu != null) { this.this$0.menu.dispose(); this.this$0.menu = null; }  } }
/*     */       ); this.toolbar.addSeparator(); this.toolbar.add(this.zoomChoice = new JComboBox()); for (byte b = 0; b < zoomname.length; b++) this.zoomChoice.addItem(zoomname[b]);  this.zoomChoice.setSelectedItem(Catalog.getString("100%")); this.zoomChoice.setMaximumSize(new Dimension(100, 25)); this.zoomChoice.setToolTipText(Catalog.getString("Zoom")); this.zoomChoice.addItemListener(this.zoomListener); this.toolbar.addSeparator(); this.fullscrB = Common2D.createToolButton(null, "/inetsoft/report/images/fullscr.gif"); this.toolbar.add(this.fullscrB); this.fullscrB.setToolTipText(Catalog.getString("Full Screen")); this.fullscrB.addActionListener(new ActionListener(this) { private final JPreviewer this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.fsCount++; if (this.this$0.fsCount % 2 == 1) { this.this$0.frameSize = this.this$0.getSize(); this.this$0.psize = Toolkit.getDefaultToolkit().getScreenSize(); this.this$0.pack(); this.this$0.setLocation(0, 0); } else { this.this$0.psize = this.this$0.frameSize; this.this$0.pack(); }  } }
/* 515 */       ); this.toolbar.addSeparator(); this.toolbar.add(this.closeB = new JButton(" " + Catalog.getString("Close") + " ")); this.closeB.setMargin(new Insets(1, 1, 1, 1)); this.closeB.setAlignmentY(0.5F); this.closeB.setToolTipText(Catalog.getString("Close Preview")); this.closeB.addActionListener(new ActionListener(this) { private final JPreviewer this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); } }); getContentPane().add(this.toolbar, "North"); this.pane = createPane(); getContentPane().add(this.pane, "Center"); addWindowListener(new WindowAdapter(this) { private final JPreviewer this$0; public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.dispose(); } }); Util.registerKeyListener(this, this.pane.getScrollListener()); addNotify(); } public double getPageHeight() { return this.pane.getPageHeight(); } public void setOrientation(int paramInt) { this.pane.setOrientation(paramInt); } static final String[] zoomname = { Catalog.getString("500%"), Catalog.getString("200%"), Catalog.getString("150%"), Catalog.getString("100%"), Catalog.getString("75%"), Catalog.getString("50%"), Catalog.getString("25%"), Catalog.getString("10%"), Catalog.getString("Page Width"), Catalog.getString("Whole Page"), Catalog.getString("Two Pages") }; public int getOrientation() { return this.pane.getOrientation(); } public void setPageResolution(int paramInt) { this.pane.setPageResolution(paramInt); } public int getPageResolution() { return this.pane.getPageResolution(); } public void print(StyleSheet paramStyleSheet) { this.pane.print(this.sheet = paramStyleSheet); } public void zoom(double paramDouble) { this.pane.zoom(paramDouble); for (byte b = 0; b < zoomperc.length; b++) { if (Math.abs(zoomperc[b] - paramDouble) < 0.05D) { this.zoomChoice.setSelectedIndex(b); break; }
/*     */        }
/*     */      } public void setExitOnClose(boolean paramBoolean) { this.exitit = paramBoolean; } public void addSelectionListener(SelectionListener paramSelectionListener) { this.pane.addSelectionListener(paramSelectionListener); } public void removeSelectionListener(SelectionListener paramSelectionListener) { this.pane.removeSelectionListener(paramSelectionListener); } public void setPages(int paramInt1, int paramInt2) { this.pane.setPages(paramInt1, paramInt2); } public void dispose() { super.dispose(); if (this.exitit)
/*     */       System.exit(0);  } public void printAction() { if (this.sheet == null)
/*     */       return;  PrintJob printJob = this.printjob; if (printJob == null)
/*     */       printJob = getToolkit().getPrintJob(this, Catalog.getString("Previewer"), null);  if (printJob == null)
/*     */       return;  this.sheet.print(printJob); printJob.end(); Dimension dimension = printJob.getPageDimension(); if (dimension.width != getPageWidth() || dimension.height != getPageHeight()) { this.sheet.reset(); print(this.sheet); }
/*     */      }
/*     */   public void actionPerformed(ActionEvent paramActionEvent) { (new Thread(this) { private final JPreviewer this$0;
/*     */         public void run() { this.this$0.printAction(); } }
/*     */       ).start(); } static final double[] zoomperc = { 
/* 526 */       5.0D, 2.0D, 1.5D, 1.0D, 0.75D, 0.5D, 0.25D, 0.1D, -1.0D, -2.0D, -3.0D };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 539 */     if (paramArrayOfString.length < 1) {
/* 540 */       System.err.println("Usage: java inetsoft.report.j2d.JPreviewer report-file");
/*     */       
/* 542 */       System.exit(1);
/*     */     } 
/*     */     
/*     */     try {
/* 546 */       FileInputStream fileInputStream = new FileInputStream(paramArrayOfString[0]);
/* 547 */       Builder builder = Builder.getBuilder(2, fileInputStream);
/* 548 */       StyleSheet styleSheet = builder.read(".");
/* 549 */       fileInputStream.close();
/*     */       
/* 551 */       JPreviewer jPreviewer = new JPreviewer();
/* 552 */       jPreviewer.setExitOnClose(true);
/*     */       
/* 554 */       jPreviewer.pack();
/* 555 */       jPreviewer.setVisible(true);
/*     */       
/* 557 */       jPreviewer.print(styleSheet);
/*     */     } catch (Exception exception) {
/* 559 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\JPreviewer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */