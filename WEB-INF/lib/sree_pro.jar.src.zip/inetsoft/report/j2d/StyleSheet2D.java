package inetsoft.report.j2d;

import inetsoft.report.StyleSheet;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;

public class StyleSheet2D extends StyleSheet {
  public void print(PrinterJob paramPrinterJob) {
    Book book = printBook(paramPrinterJob.defaultPage());
    paramPrinterJob.setPageable(book);
    try {
      paramPrinterJob.print();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public Printable printPages(PageFormat paramPageFormat) { return new StylePrintable(printBook(paramPageFormat)); }
  
  public Book printBook(PageFormat paramPageFormat) { return new StyleBook(this, paramPageFormat); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\j2d\StyleSheet2D.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */