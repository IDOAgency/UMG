/*     */ package inetsoft.report;
/*     */ 
/*     */ import inetsoft.report.internal.BaseElement;
/*     */ import inetsoft.report.internal.ChartElementDef;
/*     */ import inetsoft.report.internal.FormElementDef;
/*     */ import inetsoft.report.internal.HeadingElementDef;
/*     */ import inetsoft.report.internal.PainterElementDef;
/*     */ import inetsoft.report.internal.SeparatorElementDef;
/*     */ import inetsoft.report.internal.TOCElementDef;
/*     */ import inetsoft.report.internal.TabElementDef;
/*     */ import inetsoft.report.internal.TableElementDef;
/*     */ import inetsoft.report.internal.TextBoxElementDef;
/*     */ import inetsoft.report.internal.TextElementDef;
/*     */ import inetsoft.report.lens.DefaultTextLens;
/*     */ import inetsoft.report.painter.BulletPainter;
/*     */ import inetsoft.report.painter.ComponentPainter;
/*     */ import inetsoft.report.painter.ImagePainter;
/*     */ import java.awt.Component;
/*     */ import java.awt.Image;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.Serializable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedContainer
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   protected StyleSheet parent;
/*     */   Vector elements;
/*     */   Vector boxes;
/*     */   Rectangle box;
/*     */   
/*     */   public FixedContainer(StyleSheet paramStyleSheet) {
/* 394 */     this.parent = null;
/* 395 */     this.elements = new Vector();
/*     */     
/* 397 */     this.boxes = new Vector();
/*     */     this.parent = paramStyleSheet;
/*     */   }
/*     */   
/*     */   public StyleSheet getStyleSheet() { return this.parent; }
/*     */   
/*     */   public void setStyleSheet(StyleSheet paramStyleSheet) {
/*     */     this.parent = paramStyleSheet;
/*     */     for (byte b = 0; b < getElementCount(); b++)
/*     */       ((BaseElement)getElement(b)).setStyleSheet(paramStyleSheet); 
/*     */   }
/*     */   
/*     */   public String addText(String paramString, Rectangle paramRectangle) { return addText(new DefaultTextLens(paramString), paramRectangle); }
/*     */   
/*     */   public String addText(TextLens paramTextLens, Rectangle paramRectangle) {
/*     */     if (paramTextLens instanceof HeadingLens)
/*     */       return addElement(new HeadingElementDef(this.parent, (HeadingLens)paramTextLens), paramRectangle); 
/*     */     return addElement(new TextElementDef(this.parent, paramTextLens), paramRectangle);
/*     */   }
/*     */   
/*     */   public String addTextBox(TextLens paramTextLens, Rectangle paramRectangle) { return addElement(new TextBoxElementDef(this.parent, paramTextLens), paramRectangle); }
/*     */   
/*     */   public String addTextBox(TextLens paramTextLens, int paramInt1, int paramInt2, Rectangle paramRectangle) {
/*     */     TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this.parent, paramTextLens);
/*     */     textBoxElementDef.setBorder(paramInt1);
/*     */     textBoxElementDef.setTextAlignment(paramInt2);
/*     */     return addElement(textBoxElementDef, paramRectangle);
/*     */   }
/*     */   
/*     */   public String addTextBox(String paramString, int paramInt1, int paramInt2, Rectangle paramRectangle) { return addTextBox(new DefaultTextLens(paramString), paramInt1, paramInt2, paramRectangle); }
/*     */   
/*     */   public String addPainter(Painter paramPainter, Rectangle paramRectangle) { return addElement(new PainterElementDef(this.parent, paramPainter), paramRectangle); }
/*     */   
/*     */   public String addChart(ChartLens paramChartLens, Rectangle paramRectangle) { return addElement(new ChartElementDef(this.parent, paramChartLens), paramRectangle); }
/*     */   
/*     */   public String addComponent(Component paramComponent, Rectangle paramRectangle) { return addPainter(new ComponentPainter(paramComponent), paramRectangle); }
/*     */   
/*     */   public String addImage(Image paramImage, Rectangle paramRectangle) { return addPainter(new ImagePainter(paramImage), paramRectangle); }
/*     */   
/*     */   public String addBullet(Rectangle paramRectangle) {
/*     */     BulletPainter bulletPainter = new BulletPainter();
/*     */     return addPainter(bulletPainter, paramRectangle);
/*     */   }
/*     */   
/*     */   public String addBullet(Image paramImage, Rectangle paramRectangle) {
/*     */     BulletPainter bulletPainter = new BulletPainter(paramImage);
/*     */     return addPainter(bulletPainter, paramRectangle);
/*     */   }
/*     */   
/*     */   public String addSeparator(int paramInt, Rectangle paramRectangle) { return addElement(new SeparatorElementDef(this.parent, paramInt), paramRectangle); }
/*     */   
/*     */   public String addTab(int paramInt, Rectangle paramRectangle) { return addElement(new TabElementDef(this.parent, paramInt), paramRectangle); }
/*     */   
/*     */   public String addTable(TableLens paramTableLens, Rectangle paramRectangle) { return addElement(new TableElementDef(this.parent, paramTableLens), paramRectangle); }
/*     */   
/*     */   public String addForm(FormLens paramFormLens, Rectangle paramRectangle) { return addElement(new FormElementDef(this.parent, paramFormLens), paramRectangle); }
/*     */   
/*     */   public String addTOC(TOC paramTOC, Rectangle paramRectangle) { return addElement(new TOCElementDef(this.parent, paramTOC), paramRectangle); }
/*     */   
/*     */   public String addElement(ReportElement paramReportElement, Rectangle paramRectangle) {
/*     */     ((BaseElement)paramReportElement).setParent(this);
/*     */     this.elements.addElement(paramReportElement);
/*     */     this.boxes.addElement(paramRectangle);
/*     */     return paramReportElement.getID();
/*     */   }
/*     */   
/*     */   public int getElementCount() { return this.elements.size(); }
/*     */   
/*     */   public ReportElement getElement(int paramInt) { return (ReportElement)this.elements.elementAt(paramInt); }
/*     */   
/*     */   public ReportElement getElement(String paramString) {
/*     */     for (byte b = 0; b < getElementCount(); b++) {
/*     */       if (getElement(b).getID().equals(paramString))
/*     */         return getElement(b); 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public void removeElement(int paramInt) {
/*     */     this.elements.removeElementAt(paramInt);
/*     */     this.boxes.removeElementAt(paramInt);
/*     */   }
/*     */   
/*     */   public void removeAllElements() {
/*     */     this.elements.removeAllElements();
/*     */     this.boxes.removeAllElements();
/*     */   }
/*     */   
/*     */   public int getElementIndex(ReportElement paramReportElement) { return this.elements.indexOf(paramReportElement, 0); }
/*     */   
/*     */   public Enumeration elements() { return this.elements.elements(); }
/*     */   
/*     */   public Rectangle getBounds(int paramInt) { return new Rectangle((Rectangle)this.boxes.elementAt(paramInt)); }
/*     */   
/*     */   public void setBounds(int paramInt, Rectangle paramRectangle) { this.boxes.setElementAt(paramRectangle, paramInt); }
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/*     */     FixedContainer fixedContainer = (FixedContainer)super.clone();
/*     */     fixedContainer.elements = new Vector(this.elements.size());
/*     */     fixedContainer.boxes = (Vector)this.boxes.clone();
/*     */     for (byte b = 0; b < this.elements.size(); b++) {
/*     */       BaseElement baseElement = (BaseElement)getElement(b).clone();
/*     */       baseElement.setParent(fixedContainer);
/*     */       fixedContainer.elements.addElement(baseElement);
/*     */     } 
/*     */     return fixedContainer;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\FixedContainer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */