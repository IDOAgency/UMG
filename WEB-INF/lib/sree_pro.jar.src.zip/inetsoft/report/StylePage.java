package inetsoft.report;

import inetsoft.report.internal.Encoder;
import inetsoft.report.internal.MetaImage;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

public class StylePage implements Serializable {
  public StylePage(Dimension paramDimension, int paramInt) {
    this.font = new Font("Serif", 0, 10);
    this.color = Color.black;
    this.items = new Vector();
    this.size = paramDimension;
    this.resolution = paramInt;
  }
  
  public void print(Graphics paramGraphics) {
    Common.startPage(paramGraphics, this);
    if (this.bg instanceof Color) {
      paramGraphics.setColor((Color)this.bg);
      paramGraphics.fillRect(0, 0, this.size.width, this.size.height);
      paramGraphics.setColor(Color.black);
    } else if (this.bg instanceof Image) {
      Image image = (Image)this.bg;
      if (image instanceof MetaImage)
        image = ((MetaImage)image).getImage(); 
      int i = image.getWidth(null);
      int j = image.getHeight(null);
      if (i > 0 && j > 0)
        for (int k = 0; k < this.size.height; k += j) {
          for (int m = 0; m < this.size.width; m += i)
            paramGraphics.drawImage(image, m, k, null); 
        }  
    } 
    Rectangle rectangle = paramGraphics.getClipBounds();
    for (byte b = 0; b < this.items.size(); b++) {
      Paintable paintable = (Paintable)this.items.elementAt(b);
      if (rectangle == null || rectangle.intersects(paintable.getBounds()))
        paintable.paint(paramGraphics); 
    } 
  }
  
  public void addPaintable(Paintable paramPaintable) { this.items.addElement(paramPaintable); }
  
  public int getPaintableCount() { return this.items.size(); }
  
  public Paintable getPaintable(int paramInt) { return (Paintable)this.items.elementAt(paramInt); }
  
  public void removePaintable(int paramInt) { this.items.removeElementAt(paramInt); }
  
  public void reset() {
    this.items.removeAllElements();
    this.areas = null;
  }
  
  public Dimension getPageDimension() { return this.size; }
  
  public void setPageDimension(Dimension paramDimension) { this.size = paramDimension; }
  
  public int getPageResolution() { return this.resolution; }
  
  public Font getFont() { return this.font; }
  
  public void setFont(Font paramFont) { this.font = paramFont; }
  
  public Color getForeground() { return this.color; }
  
  public void setForeground(Color paramColor) { this.color = paramColor; }
  
  public Object getBackground() { return this.bg; }
  
  public void setBackground(Object paramObject) { this.bg = paramObject; }
  
  public PageArea[] getPageAreas() { return this.areas; }
  
  public void setPageAreas(PageArea[] paramArrayOfPageArea) { this.areas = paramArrayOfPageArea; }
  
  public void finalize() {
    this.items.removeAllElements();
    this.items = null;
    this.areas = null;
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    if (compress) {
      Inflater inflater = new Inflater();
      InflaterInputStream inflaterInputStream = new InflaterInputStream(paramObjectInputStream, inflater);
      paramObjectInputStream = new ObjectInputStream(inflaterInputStream);
    } 
    this.items = (Vector)paramObjectInputStream.readObject();
    this.areas = (PageArea[])paramObjectInputStream.readObject();
    char c = paramObjectInputStream.readChar();
    if (c == 'I') {
      byte[] arrayOfByte = (byte[])paramObjectInputStream.readObject();
      if (arrayOfByte != null) {
        int i = paramObjectInputStream.readInt();
        int j = paramObjectInputStream.readInt();
        this.bg = Encoder.decodeImage(i, j, arrayOfByte);
      } 
    } else {
      this.bg = paramObjectInputStream.readObject();
    } 
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
    DeflaterOutputStream deflaterOutputStream = null;
    paramObjectOutputStream.defaultWriteObject();
    if (compress) {
      Deflater deflater = new Deflater(1);
      deflaterOutputStream = new DeflaterOutputStream(paramObjectOutputStream, deflater);
      paramObjectOutputStream = new ObjectOutputStream(deflaterOutputStream);
    } 
    paramObjectOutputStream.writeObject(this.items);
    paramObjectOutputStream.writeObject(this.areas);
    if (this.bg instanceof Image) {
      paramObjectOutputStream.writeChar(73);
      Image image = (Image)this.bg;
      byte[] arrayOfByte = Encoder.encodeImage(image);
      paramObjectOutputStream.writeObject(arrayOfByte);
      if (arrayOfByte != null) {
        paramObjectOutputStream.writeInt(image.getWidth(null));
        paramObjectOutputStream.writeInt(image.getHeight(null));
      } 
    } else {
      paramObjectOutputStream.writeChar(79);
      paramObjectOutputStream.writeObject(this.bg);
    } 
    paramObjectOutputStream.flush();
    if (deflaterOutputStream != null) {
      deflaterOutputStream.flush();
      deflaterOutputStream.finish();
    } 
  }
  
  static boolean compress = true;
  
  Dimension size;
  
  int resolution;
  
  Font font;
  
  Color color;
  
  Vector items;
  
  PageArea[] areas;
  
  Object bg;
  
  static  {
    compress = ReportEnv.getProperty("replet.optimize.network", "false").equals("true");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\StylePage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */