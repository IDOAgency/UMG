package inetsoft.report;

import java.awt.Font;

public interface ChartLens extends StyleConstants, Cloneable {
  int getDatasetCount();
  
  int getDatasetSize();
  
  String getLabel(int paramInt);
  
  String getDatasetLabel(int paramInt);
  
  Number getData(int paramInt1, int paramInt2);
  
  int getStyle();
  
  Number getMaximum();
  
  Number getMinimum();
  
  Number getIncrement();
  
  Number getMinorIncrement();
  
  int getGap();
  
  Object getColor(int paramInt);
  
  String getXTitle();
  
  String getYTitle();
  
  Font getTitleFont();
  
  int getGridStyle();
  
  int getBorderStyle();
  
  boolean isShowValue();
  
  int getPrecision();
  
  int getLegendPosition();
  
  int getStyle(int paramInt);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ChartLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */