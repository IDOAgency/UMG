package inetsoft.report;

import inetsoft.report.event.PageBreakListener;
import inetsoft.report.internal.StyleCore;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Rectangle;
import java.lang.reflect.Method;
import java.net.URL;
import java.text.Format;
import java.util.Vector;

public class CompositeSheet extends StyleSheet {
  StyleSheet[] sheets;
  
  StyleSheet lastS;
  
  int currSheet;
  
  int[] pagecnts;
  
  boolean first;
  
  static Method marginMethod;
  
  static Method headerFromEdgeMethod;
  
  static Method footerFromEdgeMethod;
  
  static Method alignmentMethod;
  
  static Method indentMethod;
  
  static Method tabStopsMethod;
  
  static Method wrappingMethod;
  
  static Method lineSpacingMethod;
  
  static Method fontMethod;
  
  static Method foregroundMethod;
  
  static Method backgroundMethod;
  
  static Method tableLayoutMethod;
  
  static Method painterLayoutMethod;
  
  static Method painterMarginMethod;
  
  static Method chartDescriptorMethod;
  
  static Method cellPaddingMethod;
  
  static Method tableWidthMethod;
  
  static Method headerMethod;
  
  static Method footerMethod;
  
  static Method justifyMethod;
  
  static Method textAdvanceMethod;
  
  static Method tableAdvanceMethod;
  
  static Method orphanControlMethod;
  
  static Method tableOrphanControlMethod;
  
  static Method addPresenterMethod;
  
  static Method removePresenterMethod;
  
  static Method clearPresenterMethod;
  
  static Method addFormatMethod;
  
  static Method removeFormatMethod;
  
  static Method clearFormatMethod;
  
  static Method addPageBreakListenerMethod;
  
  static Method removePageBreakListenerMethod;
  
  static Method clearMethod;
  
  static Method resetMethod;
  
  static Class array$D;
  
  public CompositeSheet(StyleSheet[] paramArrayOfStyleSheet) {
    this.currSheet = 0;
    this.first = true;
    this.sheets = paramArrayOfStyleSheet;
    if (paramArrayOfStyleSheet.length == 0)
      throw new RuntimeException("CompositeSheet must container one or more StyleSheets"); 
    this.lastS = paramArrayOfStyleSheet[paramArrayOfStyleSheet.length - 1];
    this.pagecnts = new int[paramArrayOfStyleSheet.length];
  }
  
  public void setMargin(Margin paramMargin) { invoke(marginMethod, paramMargin); }
  
  public Margin getMargin() { return this.sheets[0].getMargin(); }
  
  public void setHeaderFromEdge(double paramDouble) { invoke(headerFromEdgeMethod, new Double(paramDouble)); }
  
  public double getHeaderFromEdge() { return this.sheets[0].getHeaderFromEdge(); }
  
  public void setFooterFromEdge(double paramDouble) { invoke(footerFromEdgeMethod, new Double(paramDouble)); }
  
  public double getFooterFromEdge() { return this.sheets[0].getFooterFromEdge(); }
  
  public Rectangle getHeaderBounds(Dimension paramDimension, int paramInt) { return this.sheets[0].getHeaderBounds(paramDimension, paramInt); }
  
  public Rectangle getFooterBounds(Dimension paramDimension, int paramInt) { return this.sheets[0].getFooterBounds(paramDimension, paramInt); }
  
  public String setPageAreas(PageArea[] paramArrayOfPageArea, ReportElement paramReportElement) {
    if (paramReportElement == null)
      return this.lastS.setPageAreas(paramArrayOfPageArea, paramReportElement); 
    if (paramReportElement instanceof PageLayoutElement) {
      ((PageLayoutElement)paramReportElement).setPageAreas(paramArrayOfPageArea);
      return paramReportElement.getID();
    } 
    return findSheet(paramReportElement).setPageAreas(paramArrayOfPageArea, paramReportElement);
  }
  
  public void setPageAreas(PageArea[] paramArrayOfPageArea, String paramString) { findSheet(paramString).setPageAreas(paramArrayOfPageArea, paramString); }
  
  public void setCurrentAlignment(int paramInt) { invoke(alignmentMethod, new Integer(paramInt)); }
  
  public int getCurrentAlignment() { return this.sheets[0].getCurrentAlignment(); }
  
  public void setCurrentIndent(double paramDouble) { invoke(indentMethod, new Double(paramDouble)); }
  
  public double getCurrentIndent() { return this.sheets[0].getCurrentIndent(); }
  
  public void setCurrentTabStops(double[] paramArrayOfDouble) { invoke(tabStopsMethod, paramArrayOfDouble); }
  
  public double[] getCurrentTabStops() { return this.sheets[0].getCurrentTabStops(); }
  
  public void setCurrentWrapping(int paramInt) { invoke(wrappingMethod, new Integer(paramInt)); }
  
  public int getCurrentWrapping() { return this.sheets[0].getCurrentWrapping(); }
  
  public void moveAnchor(Position paramPosition) { this.lastS.moveAnchor(paramPosition); }
  
  public void setCurrentLineSpacing(int paramInt) { invoke(lineSpacingMethod, new Integer(paramInt)); }
  
  public int getCurrentLineSpacing() { return this.sheets[0].getCurrentLineSpacing(); }
  
  public void setCurrentFont(Font paramFont) { invoke(fontMethod, paramFont); }
  
  public Font getCurrentFont() { return this.sheets[0].getCurrentFont(); }
  
  public void setCurrentForeground(Color paramColor) { invoke(foregroundMethod, paramColor); }
  
  public Color getCurrentForeground() { return this.sheets[0].getCurrentForeground(); }
  
  public void setCurrentBackground(Color paramColor) { invoke(backgroundMethod, paramColor); }
  
  public Color getCurrentBackground() { return this.sheets[0].getCurrentBackground(); }
  
  public void setCurrentTableLayout(int paramInt) { invoke(tableLayoutMethod, new Integer(paramInt)); }
  
  public int getCurrentTableLayout() { return this.sheets[0].getCurrentTableLayout(); }
  
  public void setCurrentPainterLayout(int paramInt) { invoke(painterLayoutMethod, new Integer(paramInt)); }
  
  public int getCurrentPainterLayout() { return this.sheets[0].getCurrentPainterLayout(); }
  
  public void setCurrentPainterMargin(Insets paramInsets) { invoke(painterMarginMethod, paramInsets); }
  
  public Insets getCurrentPainterMargin() { return this.sheets[0].getCurrentPainterMargin(); }
  
  public void setCurrentChartDescriptor(ChartDescriptor paramChartDescriptor) { invoke(chartDescriptorMethod, paramChartDescriptor); }
  
  public ChartDescriptor getCurrentChartDescriptor() { return this.sheets[0].getCurrentChartDescriptor(); }
  
  public void setCurrentCellPadding(Insets paramInsets) { invoke(cellPaddingMethod, paramInsets); }
  
  public Insets getCurrentCellPadding() { return this.sheets[0].getCurrentCellPadding(); }
  
  public void setCurrentTableWidth(double paramDouble) { invoke(tableWidthMethod, new Double(paramDouble)); }
  
  public double getCurrentTableWidth() { return this.sheets[0].getCurrentTableWidth(); }
  
  public void addPresenter(Class paramClass, Presenter paramPresenter) { invoke(addPresenterMethod, paramClass, paramPresenter); }
  
  public Presenter getPresenter(Class paramClass) { false;
    return StyleCore.getPresenter(this.presentermap, paramClass); }
  
  public void removePresenter(Class paramClass) { invoke(removePresenterMethod, paramClass); }
  
  public void clearPresenter() { invoke(clearPresenterMethod); }
  
  public void addFormat(Class paramClass, Format paramFormat) { invoke(addFormatMethod, paramClass, paramFormat); }
  
  public Format getFormat(Class paramClass) {
    Format format = null;
    byte b = 0;
    while (b < this.sheets.length && paramClass != null && (format = this.sheets[b].getFormat(paramClass)) == null)
      b++; 
    return format;
  }
  
  public void removeFormat(Class paramClass) { invoke(removeFormatMethod, paramClass); }
  
  public void clearFormat() { invoke(clearFormatMethod); }
  
  public String addObject(Object paramObject) { return this.lastS.addObject(paramObject); }
  
  public String addText(String paramString) { return this.lastS.addText(paramString); }
  
  public String addText(TextLens paramTextLens) { return this.lastS.addText(paramTextLens); }
  
  public String addTextBox(TextLens paramTextLens) { return this.lastS.addTextBox(paramTextLens); }
  
  public String addTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) { return this.lastS.addTextBox(paramTextLens, paramInt1, paramDouble1, paramDouble2, paramInt2); }
  
  public String addTextBox(String paramString, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) { return this.lastS.addTextBox(paramString, paramInt1, paramDouble1, paramDouble2, paramInt2); }
  
  public String addPainter(Painter paramPainter) { return this.lastS.addPainter(paramPainter); }
  
  public String addPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return this.lastS.addPainter(paramPainter, paramDouble1, paramDouble2); }
  
  public String addChart(ChartLens paramChartLens) { return this.lastS.addChart(paramChartLens); }
  
  public String addChart(ChartLens paramChartLens, double paramDouble1, double paramDouble2) { return this.lastS.addChart(paramChartLens, paramDouble1, paramDouble2); }
  
  public String addComponent(Component paramComponent) { return this.lastS.addComponent(paramComponent); }
  
  public String addComponent(Component paramComponent, double paramDouble1, double paramDouble2) { return this.lastS.addComponent(paramComponent, paramDouble1, paramDouble2); }
  
  public String addImage(Image paramImage) { return this.lastS.addImage(paramImage); }
  
  public String addImage(Image paramImage, double paramDouble1, double paramDouble2) { return this.lastS.addImage(paramImage, paramDouble1, paramDouble2); }
  
  public String addImage(URL paramURL) { return this.lastS.addImage(paramURL); }
  
  public String addBullet() { return this.lastS.addBullet(); }
  
  public String addBullet(Image paramImage) { return this.lastS.addBullet(paramImage); }
  
  public String addSpace(int paramInt) { return this.lastS.addSpace(paramInt); }
  
  public String addNewline(int paramInt) { return this.lastS.addNewline(paramInt); }
  
  public String addBreak() { return this.lastS.addBreak(); }
  
  public String addPageBreak() { return this.lastS.addPageBreak(); }
  
  public String addAreaBreak() { return this.lastS.addAreaBreak(); }
  
  public String addConditionalPageBreak(int paramInt) { return this.lastS.addConditionalPageBreak(paramInt); }
  
  public String addConditionalPageBreak(double paramDouble) { return this.lastS.addConditionalPageBreak(paramDouble); }
  
  public String addSeparator(int paramInt) { return this.lastS.addSeparator(paramInt); }
  
  public String addTab(int paramInt) { return this.lastS.addTab(paramInt); }
  
  public String addTable(TableLens paramTableLens) { return this.lastS.addTable(paramTableLens); }
  
  public String addForm(FormLens paramFormLens) { return this.lastS.addForm(paramFormLens); }
  
  public String addTOC(TOC paramTOC) { return this.lastS.addTOC(paramTOC); }
  
  public void setCurrentHeader(int paramInt) { invoke(headerMethod, new Integer(paramInt)); }
  
  public void setCurrentHeader(String paramString) { findSheet(paramString).setCurrentHeader(paramString); }
  
  public void setCurrentFooter(int paramInt) { invoke(footerMethod, new Integer(paramInt)); }
  
  public void setCurrentFooter(String paramString) { findSheet(paramString).setCurrentFooter(paramString); }
  
  public void setCurrentJustify(boolean paramBoolean) { invoke(justifyMethod, new Boolean(paramBoolean)); }
  
  public boolean isCurrentJustify() { return this.sheets[0].isCurrentJustify(); }
  
  public void setCurrentTextAdvance(int paramInt) { invoke(textAdvanceMethod, new Integer(paramInt)); }
  
  public int getCurrentTextAdvance() { return this.sheets[0].getCurrentTextAdvance(); }
  
  public void setCurrentTableAdvance(int paramInt) { invoke(tableAdvanceMethod, new Integer(paramInt)); }
  
  public int getCurrentTableAdvance() { return this.sheets[0].getCurrentTableAdvance(); }
  
  public void setCurrentTableOrphanControl(boolean paramBoolean) { invoke(tableOrphanControlMethod, new Boolean(paramBoolean)); }
  
  public boolean isCurrentTableOrphanControl() { return this.sheets[0].isCurrentTableOrphanControl(); }
  
  public void setCurrentOrphanControl(boolean paramBoolean) { invoke(orphanControlMethod, new Boolean(paramBoolean)); }
  
  public boolean isCurrentOrphanControl() { return this.sheets[0].isCurrentOrphanControl(); }
  
  public String addHeaderObject(Object paramObject) { return this.lastS.addHeaderObject(paramObject); }
  
  public String addHeaderText(String paramString) { return this.lastS.addHeaderText(paramString); }
  
  public String addHeaderText(TextLens paramTextLens) { return this.lastS.addHeaderText(paramTextLens); }
  
  public String addHeaderTextBox(TextLens paramTextLens) { return this.lastS.addHeaderTextBox(paramTextLens); }
  
  public String addHeaderTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) { return this.lastS.addHeaderTextBox(paramTextLens, paramInt1, paramDouble1, paramDouble2, paramInt2); }
  
  public String addHeaderPainter(Painter paramPainter) { return this.lastS.addHeaderPainter(paramPainter); }
  
  public String addHeaderPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return this.lastS.addHeaderPainter(paramPainter, paramDouble1, paramDouble2); }
  
  public String addHeaderImage(Image paramImage) { return this.lastS.addHeaderImage(paramImage); }
  
  public String addHeaderImage(Image paramImage, double paramDouble1, double paramDouble2) { return this.lastS.addHeaderImage(paramImage, paramDouble1, paramDouble2); }
  
  public String addHeaderImage(URL paramURL) { return this.lastS.addHeaderImage(paramURL); }
  
  public String addHeaderSpace(int paramInt) { return this.lastS.addHeaderSpace(paramInt); }
  
  public String addHeaderNewline(int paramInt) { return this.lastS.addHeaderNewline(paramInt); }
  
  public String addHeaderBreak() { return this.lastS.addHeaderBreak(); }
  
  public String addHeaderSeparator(int paramInt) { return this.lastS.addHeaderSeparator(paramInt); }
  
  public String addHeaderTab(int paramInt) { return this.lastS.addHeaderTab(paramInt); }
  
  public String addHeaderTable(TableLens paramTableLens) { return this.lastS.addHeaderTable(paramTableLens); }
  
  public String addFooterObject(Object paramObject) { return this.lastS.addFooterObject(paramObject); }
  
  public String addFooterText(String paramString) { return this.lastS.addFooterText(paramString); }
  
  public String addFooterText(TextLens paramTextLens) { return this.lastS.addFooterText(paramTextLens); }
  
  public String addFooterTextBox(TextLens paramTextLens) { return this.lastS.addFooterTextBox(paramTextLens); }
  
  public String addFooterTextBox(TextLens paramTextLens, int paramInt1, double paramDouble1, double paramDouble2, int paramInt2) { return this.lastS.addFooterTextBox(paramTextLens, paramInt1, paramDouble1, paramDouble2, paramInt2); }
  
  public String addFooterPainter(Painter paramPainter) { return this.lastS.addFooterPainter(paramPainter); }
  
  public String addFooterPainter(Painter paramPainter, double paramDouble1, double paramDouble2) { return this.lastS.addFooterPainter(paramPainter, paramDouble1, paramDouble2); }
  
  public String addFooterImage(Image paramImage) { return this.lastS.addFooterImage(paramImage); }
  
  public String addFooterImage(Image paramImage, double paramDouble1, double paramDouble2) { return this.lastS.addFooterImage(paramImage, paramDouble1, paramDouble2); }
  
  public String addFooterImage(URL paramURL) { return this.lastS.addFooterImage(paramURL); }
  
  public String addFooterSpace(int paramInt) { return this.lastS.addFooterSpace(paramInt); }
  
  public String addFooterNewline(int paramInt) { return this.lastS.addFooterNewline(paramInt); }
  
  public String addFooterBreak() { return this.lastS.addFooterBreak(); }
  
  public String addFooterSeparator(int paramInt) { return this.lastS.addFooterSeparator(paramInt); }
  
  public String addFooterTab(int paramInt) { return this.lastS.addFooterTab(paramInt); }
  
  public String addFooterTable(TableLens paramTableLens) { return this.lastS.addFooterTable(paramTableLens); }
  
  public ReportElement getElement(String paramString) {
    for (byte b = 0; b < this.sheets.length; b++) {
      ReportElement reportElement = this.sheets[b].getElement(paramString);
      if (reportElement != null)
        return reportElement; 
    } 
    return null;
  }
  
  public String addElement(ReportElement paramReportElement) { return this.lastS.addElement(paramReportElement); }
  
  public int getElementCount() {
    int i = 0;
    for (byte b = 0; b < this.sheets.length; b++)
      i += this.sheets[b].getElementCount(); 
    return i;
  }
  
  public ReportElement getElement(int paramInt) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getElementCount())
        return this.sheets[b].getElement(paramInt); 
      paramInt -= this.sheets[b].getElementCount();
    } 
    return null;
  }
  
  public int getElementIndex(ReportElement paramReportElement) {
    int i = 0;
    for (byte b = 0; b < this.sheets.length; b++) {
      int j = this.sheets[b].getElementIndex(paramReportElement);
      if (j >= 0)
        return j + i; 
      i += this.sheets[b].getElementCount();
    } 
    return -1;
  }
  
  public void removeElement(int paramInt) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getElementCount()) {
        this.sheets[b].removeElement(paramInt);
        return;
      } 
      paramInt -= this.sheets[b].getElementCount();
    } 
  }
  
  public String insertElement(int paramInt, ReportElement paramReportElement) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getElementCount())
        return this.sheets[b].insertElement(paramInt, paramReportElement); 
      paramInt -= this.sheets[b].getElementCount();
    } 
    return this.lastS.insertElement(paramInt, paramReportElement);
  }
  
  public String addHeaderElement(ReportElement paramReportElement) { return this.lastS.addHeaderElement(paramReportElement); }
  
  public int getHeaderElementCount() {
    int i = 0;
    for (byte b = 0; b < this.sheets.length; b++)
      i += this.sheets[b].getHeaderElementCount(); 
    return i;
  }
  
  public ReportElement getHeaderElement(int paramInt) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getHeaderElementCount())
        return this.sheets[b].getHeaderElement(paramInt); 
      paramInt -= this.sheets[b].getHeaderElementCount();
    } 
    return null;
  }
  
  public int getHeaderElementIndex(ReportElement paramReportElement) {
    int i = 0;
    for (byte b = 0; b < this.sheets.length; b++) {
      int j = this.sheets[b].getHeaderElementIndex(paramReportElement);
      if (j >= 0)
        return j + i; 
      i += this.sheets[b].getHeaderElementCount();
    } 
    return -1;
  }
  
  public void removeHeaderElement(int paramInt) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getHeaderElementCount()) {
        this.sheets[b].removeHeaderElement(paramInt);
        return;
      } 
      paramInt -= this.sheets[b].getHeaderElementCount();
    } 
  }
  
  public void insertHeaderElement(int paramInt, ReportElement paramReportElement) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getHeaderElementCount())
        this.sheets[b].insertHeaderElement(paramInt, paramReportElement); 
      paramInt -= this.sheets[b].getHeaderElementCount();
    } 
  }
  
  public String addFooterElement(ReportElement paramReportElement) { return this.lastS.addFooterElement(paramReportElement); }
  
  public int getFooterElementCount() {
    int i = 0;
    for (byte b = 0; b < this.sheets.length; b++)
      i += this.sheets[b].getFooterElementCount(); 
    return i;
  }
  
  public ReportElement getFooterElement(int paramInt) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getFooterElementCount())
        return this.sheets[b].getFooterElement(paramInt); 
      paramInt -= this.sheets[b].getFooterElementCount();
    } 
    return null;
  }
  
  public int getFooterElementIndex(ReportElement paramReportElement) {
    int i = 0;
    for (byte b = 0; b < this.sheets.length; b++) {
      int j = this.sheets[b].getFooterElementIndex(paramReportElement);
      if (j >= 0)
        return j + i; 
      i += this.sheets[b].getFooterElementCount();
    } 
    return -1;
  }
  
  public void removeFooterElement(int paramInt) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getFooterElementCount()) {
        this.sheets[b].removeFooterElement(paramInt);
        return;
      } 
      paramInt -= this.sheets[b].getFooterElementCount();
    } 
  }
  
  public void insertFooterElement(int paramInt, ReportElement paramReportElement) {
    for (byte b = 0; b < this.sheets.length; b++) {
      if (paramInt < this.sheets[b].getFooterElementCount())
        this.sheets[b].insertFooterElement(paramInt, paramReportElement); 
      paramInt -= this.sheets[b].getFooterElementCount();
    } 
  }
  
  public Vector getElements(int paramInt) {
    Vector vector = new Vector();
    for (byte b = 0; b < this.sheets.length; b++) {
      Vector vector1 = this.sheets[b].getElements(paramInt);
      for (byte b1 = 0; b1 < vector1.size(); b1++)
        vector.addElement(vector1.elementAt(b1)); 
    } 
    return vector;
  }
  
  public boolean printNext(StylePage paramStylePage) {
    if (this.currSheet < this.sheets.length) {
      boolean bool = this.sheets[this.currSheet].printNext(paramStylePage);
      this.pagecnts[this.currSheet] = this.pagecnts[this.currSheet] + 1;
      if (this.first) {
        this.first = false;
        for (byte b = 1; b < this.sheets.length; b++)
          this.sheets[b].setHFTextFormatter(this.sheets[0].getHFTextFormatter()); 
      } 
      if (!bool) {
        this.currSheet++;
      } else {
        return true;
      } 
    } 
    return (this.currSheet < this.sheets.length);
  }
  
  public void addPageBreakListener(PageBreakListener paramPageBreakListener) { invoke(addPageBreakListenerMethod, paramPageBreakListener); }
  
  public void removePageBreakListener(PageBreakListener paramPageBreakListener) { invoke(removePageBreakListenerMethod, paramPageBreakListener); }
  
  protected void printHeaderFooter(StylePage paramStylePage) {
    int i = this.first ? 0 : this.sheets[0].getHFTextFormatter().getPageIndex();
    for (byte b = 0; b < this.sheets.length; b++) {
      if (i < this.pagecnts[b]) {
        this.sheets[b].printHeaderFooter(paramStylePage);
        return;
      } 
      i -= this.pagecnts[b];
    } 
  }
  
  public void clear() { invoke(clearMethod); }
  
  public void reset() {
    this.currSheet = 0;
    this.first = true;
    this.pagecnts = new int[this.sheets.length];
    invoke(resetMethod);
  }
  
  public void setVisible(String paramString, boolean paramBoolean) { findSheet(paramString).setVisible(paramString, paramBoolean); }
  
  public String getProperty(String paramString) {
    for (byte b = 0; b < this.sheets.length; b++) {
      String str = this.sheets[b].getProperty(paramString);
      if (str != null)
        return str; 
    } 
    return null;
  }
  
  public void setProperty(String paramString1, String paramString2) { this.sheets[0].setProperty(paramString1, paramString2); }
  
  private void invoke(Method paramMethod, Object paramObject) {
    for (byte b = 0; b < this.sheets.length; b++) {
      try {
        paramMethod.invoke(this.sheets[b], new Object[] { paramObject });
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  private void invoke(Method paramMethod) {
    for (byte b = 0; b < this.sheets.length; b++) {
      try {
        paramMethod.invoke(this.sheets[b], new Object[0]);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  private void invoke(Method paramMethod, Object paramObject1, Object paramObject2) {
    for (byte b = 0; b < this.sheets.length; b++) {
      try {
        paramMethod.invoke(this.sheets[b], new Object[] { paramObject1, paramObject2 });
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  private StyleSheet findSheet(String paramString) {
    for (byte b = 0; b < this.sheets.length; b++) {
      ReportElement reportElement = this.sheets[b].getElement(paramString);
      if (reportElement != null)
        return this.sheets[b]; 
    } 
    return this.lastS;
  }
  
  private StyleSheet findSheet(ReportElement paramReportElement) {
    for (byte b = 0; b < this.sheets.length; b++) {
      int i = this.sheets[b].getElementIndex(paramReportElement);
      if (i >= 0)
        return this.sheets[b]; 
    } 
    return this.lastS;
  }
  
  static  {
    try {
      marginMethod = StyleSheet.class.getMethod("setMargin", new Class[] { Margin.class });
      headerFromEdgeMethod = StyleSheet.class.getMethod("setHeaderFromEdge", new Class[] { double.class });
      footerFromEdgeMethod = StyleSheet.class.getMethod("setFooterFromEdge", new Class[] { double.class });
      alignmentMethod = StyleSheet.class.getMethod("setCurrentAlignment", new Class[] { int.class });
      indentMethod = StyleSheet.class.getMethod("setCurrentIndent", new Class[] { double.class });
      tabStopsMethod = StyleSheet.class.getMethod("setCurrentTabStops", new Class[] { (array$D == null) ? (array$D = class$("[D")) : array$D });
      wrappingMethod = StyleSheet.class.getMethod("setCurrentWrapping", new Class[] { int.class });
      lineSpacingMethod = StyleSheet.class.getMethod("setCurrentLineSpacing", new Class[] { int.class });
      fontMethod = StyleSheet.class.getMethod("setCurrentFont", new Class[] { Font.class });
      foregroundMethod = StyleSheet.class.getMethod("setCurrentForeground", new Class[] { Color.class });
      backgroundMethod = StyleSheet.class.getMethod("setCurrentBackground", new Class[] { Color.class });
      tableLayoutMethod = StyleSheet.class.getMethod("setCurrentTableLayout", new Class[] { int.class });
      painterLayoutMethod = StyleSheet.class.getMethod("setCurrentPainterLayout", new Class[] { int.class });
      painterMarginMethod = StyleSheet.class.getMethod("setCurrentPainterMargin", new Class[] { Insets.class });
      chartDescriptorMethod = StyleSheet.class.getMethod("setCurrentChartDescriptor", new Class[] { ChartDescriptor.class });
      cellPaddingMethod = StyleSheet.class.getMethod("setCurrentCellPadding", new Class[] { Insets.class });
      tableWidthMethod = StyleSheet.class.getMethod("setCurrentTableWidth", new Class[] { double.class });
      headerMethod = StyleSheet.class.getMethod("setCurrentHeader", new Class[] { int.class });
      footerMethod = StyleSheet.class.getMethod("setCurrentFooter", new Class[] { int.class });
      justifyMethod = StyleSheet.class.getMethod("setCurrentJustify", new Class[] { boolean.class });
      textAdvanceMethod = StyleSheet.class.getMethod("setCurrentTextAdvance", new Class[] { int.class });
      tableAdvanceMethod = StyleSheet.class.getMethod("setCurrentTableAdvance", new Class[] { int.class });
      orphanControlMethod = StyleSheet.class.getMethod("setCurrentOrphanControl", new Class[] { boolean.class });
      tableOrphanControlMethod = StyleSheet.class.getMethod("setCurrentTableOrphanControl", new Class[] { boolean.class });
      addPresenterMethod = StyleSheet.class.getMethod("addPresenter", new Class[] { Class.class, Presenter.class });
      removePresenterMethod = StyleSheet.class.getMethod("removePresenter", new Class[] { Class.class });
      clearPresenterMethod = StyleSheet.class.getMethod("clearPresenter", new Class[0]);
      addFormatMethod = StyleSheet.class.getMethod("addFormat", new Class[] { Class.class, Format.class });
      removeFormatMethod = StyleSheet.class.getMethod("removeFormat", new Class[] { Class.class });
      clearFormatMethod = StyleSheet.class.getMethod("clearFormat", new Class[0]);
      addPageBreakListenerMethod = StyleSheet.class.getMethod("addPageBreakListener", new Class[] { PageBreakListener.class });
      removePageBreakListenerMethod = StyleSheet.class.getMethod("removePageBreakListener", new Class[] { PageBreakListener.class });
      clearMethod = StyleSheet.class.getMethod("clear", new Class[0]);
      resetMethod = StyleSheet.class.getMethod("reset", new Class[0]);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\CompositeSheet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */