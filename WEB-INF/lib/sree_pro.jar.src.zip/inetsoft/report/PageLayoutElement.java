package inetsoft.report;

public interface PageLayoutElement extends ReportElement {
  PageArea[] getPageAreas();
  
  void setPageAreas(PageArea[] paramArrayOfPageArea);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\PageLayoutElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */