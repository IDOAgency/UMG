package inetsoft.report;

import inetsoft.report.event.SelectionListener;
import java.awt.Component;
import java.awt.Dimension;

public interface PreviewView {
  public static final int PRINT_BUTTON = 1;
  
  public static final int ONE_PAGE_BUTTON = 2;
  
  public static final int N_PAGE_BUTTON = 4;
  
  public static final int FULL_SCREEN_BUTTON = 8;
  
  public static final int ZOOM_BUTTON = 16;
  
  public static final int CLOSE_BUTTON = 32;
  
  void setTitle(String paramString);
  
  void setToolbarButtons(int paramInt);
  
  void addToolbarComponent(Component paramComponent);
  
  void setPageWidth(double paramDouble);
  
  double getPageWidth();
  
  void setPageHeight(double paramDouble);
  
  double getPageHeight();
  
  void setOrientation(int paramInt);
  
  int getOrientation();
  
  void setPageResolution(int paramInt);
  
  int getPageResolution();
  
  void print(StyleSheet paramStyleSheet);
  
  void zoom(double paramDouble);
  
  void printAction();
  
  void addSelectionListener(SelectionListener paramSelectionListener);
  
  void removeSelectionListener(SelectionListener paramSelectionListener);
  
  void setExitOnClose(boolean paramBoolean);
  
  void setPreferredSize(Dimension paramDimension);
  
  void pack();
  
  void setVisible(boolean paramBoolean);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\PreviewView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */