package inetsoft.report;

import inetsoft.report.event.SectionSelectionEvent;
import inetsoft.report.event.SelectionEvent;
import inetsoft.report.event.SelectionListener;
import inetsoft.report.internal.BasePaintable;
import inetsoft.report.internal.PainterPaintable;
import inetsoft.report.internal.PaperSize;
import inetsoft.report.internal.SectionInfo;
import inetsoft.report.internal.TablePaintable;
import inetsoft.report.internal.TextElementDef;
import inetsoft.report.internal.TextPaintable;
import inetsoft.report.internal.TextPainter;
import inetsoft.report.internal.Util;
import inetsoft.report.io.Builder;
import inetsoft.report.locale.Catalog;
import inetsoft.report.painter.ComponentPainter;
import inetsoft.report.painter.ImagePainter;
import java.awt.Adjustable;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Scrollbar;
import java.awt.TextComponent;
import java.awt.TextField;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileOutputStream;
import java.util.Vector;

public class PreviewPane extends SContainer {
  public static final int PAGE_WIDTH = -1;
  
  public static final int WHOLE_PAGE = -2;
  
  public static final int TWO_PAGES = -3;
  
  Vector listeners;
  
  KeyListener scrollListener;
  
  AdjustmentListener pagingListener;
  
  Container pages;
  
  GridLayout grid;
  
  double pageWidth;
  
  double pageHeight;
  
  int resolution;
  
  int pgnum;
  
  int numpage;
  
  boolean ruler;
  
  double zoomperc;
  
  int orientation;
  
  StatusScrollPane scroller;
  
  Margin pmargin;
  
  int currpage;
  
  Container toppane;
  
  HorizontalRuler hruler;
  
  VerticalRuler vruler;
  
  protected StyleSheet sheet;
  
  protected Container scrollpane;
  
  static final int margin = 20;
  
  static final int w16 = 4;
  
  static final int w8 = 5;
  
  static final int w4 = 3;
  
  static final int w2 = 2;
  
  static final int wother = 1;
  
  public PreviewPane() {
    this.listeners = new Vector();
    this.scrollListener = new KeyAdapter(this) {
        private final PreviewPane this$0;
        
        public void keyPressed(KeyEvent param1KeyEvent) {
          if (param1KeyEvent.isConsumed())
            return; 
          Adjustable adjustable = this.this$0.getVAdjustable();
          switch (param1KeyEvent.getKeyCode()) {
            case 33:
              adjustable.setValue(adjustable.getValue() - this.this$0.getBlockIncrement(adjustable));
              break;
            case 34:
              adjustable.setValue(adjustable.getValue() + this.this$0.getBlockIncrement(adjustable));
              break;
            case 38:
              adjustable.setValue(adjustable.getValue() - adjustable.getUnitIncrement());
              break;
            case 40:
              adjustable.setValue(adjustable.getValue() + adjustable.getUnitIncrement());
              break;
            case 83:
              if (param1KeyEvent.isControlDown() && param1KeyEvent.isShiftDown() && param1KeyEvent.isAltDown()) {
                FileDialog fileDialog = new FileDialog(Util.findFrame(this.this$0), Catalog.getString("Save Report"), 1);
                fileDialog.setVisible(true);
                if (fileDialog.getFile() != null)
                  try {
                    String str = fileDialog.getDirectory() + fileDialog.getFile();
                    FileOutputStream fileOutputStream = new FileOutputStream(str);
                    Builder builder = Builder.getBuilder(2, fileOutputStream);
                    builder.write(this.this$0.sheet);
                    fileOutputStream.close();
                  } catch (Exception exception) {
                    exception.printStackTrace();
                  }  
              } 
            case 81:
            case 115:
              if ((param1KeyEvent.getKeyCode() == 115 && param1KeyEvent.isAltDown()) || (param1KeyEvent.getKeyCode() == 81 && param1KeyEvent.isControlDown())) {
                Window window = Util.findWindow(this.this$0);
                if (window != null)
                  window.dispose(); 
              } 
              break;
          } 
          ((Component)adjustable).dispatchEvent(new AdjustmentEvent(adjustable, 601, 0, adjustable.getValue()));
        }
      };
    this.pagingListener = new AdjustmentListener(this) {
        private final PreviewPane this$0;
        
        public void adjustmentValueChanged(AdjustmentEvent param1AdjustmentEvent) {
          Adjustable adjustable = param1AdjustmentEvent.getAdjustable();
          this.this$0.pgnum = adjustable.getValue() * this.this$0.getPageCount() / adjustable.getMaximum() + 1;
          this.this$0.showPageNumber(this.this$0.pgnum);
        }
      };
    this.pages = new SContainer(true);
    this.grid = new GridLayout(0, 1, 10, 10);
    this.pageWidth = 8.5D;
    this.pageHeight = 11.0D;
    this.resolution = 72;
    this.pgnum = 1;
    this.numpage = 1;
    this.ruler = false;
    this.zoomperc = 1.0D;
    this.orientation = 1;
    this.pmargin = StyleSheet.getPrinterMargin();
    this.currpage = 0;
    this.toppane = new SContainer(true);
    this.hruler = new HorizontalRuler(this);
    this.vruler = new VerticalRuler(this);
    this.sheet = null;
    setLayout(new BorderLayout());
    this.scrollpane = createScrollPane();
    addKeyListener(this.scrollListener);
    this.scrollpane.addKeyListener(this.scrollListener);
    getVAdjustable().addAdjustmentListener(this.pagingListener);
    SContainer sContainer = new SContainer(true);
    sContainer.setLayout(new FlowLayout());
    this.pages.setLayout(this.grid);
    sContainer.add(this.pages);
    this.toppane.setLayout(new BorderLayout());
    this.toppane.add(this.vruler, "West");
    this.toppane.add(this.hruler, "North");
    this.toppane.add(sContainer, "Center");
    add(this.scrollpane, "Center");
    addToScrollPane(this.toppane);
    getViewport().setBackground(new Color(150, 150, 150));
  }
  
  public void setPageWidth(double paramDouble) {
    this.pageWidth = paramDouble;
    showPageSize(new Size(this.pageWidth, this.pageHeight));
  }
  
  public double getPageWidth() { return this.pageWidth; }
  
  public void setPageHeight(double paramDouble) {
    this.pageHeight = paramDouble;
    showPageSize(new Size(this.pageWidth, this.pageHeight));
  }
  
  public double getPageHeight() { return this.pageHeight; }
  
  public void setPageSize(Size paramSize) {
    this.pageWidth = paramSize.width;
    this.pageHeight = paramSize.height;
    showPageSize(paramSize);
  }
  
  public void setOrientation(int paramInt) { this.orientation = paramInt; }
  
  public int getOrientation() { return this.orientation; }
  
  public void setPageResolution(int paramInt) { this.resolution = paramInt; }
  
  public int getPageResolution() { return this.resolution; }
  
  public void setShowRuler(boolean paramBoolean) {
    this.ruler = paramBoolean;
    repaint();
  }
  
  public boolean isShowRuler() { return this.ruler; }
  
  public Container getScrollPane() { return this.scrollpane; }
  
  public StyleSheet getStyleSheet() { return this.sheet; }
  
  public void print(StyleSheet paramStyleSheet) {
    this.sheet = paramStyleSheet;
    Size size = PaperSize.getSize(paramStyleSheet.getProperty("PageSize"));
    int i = PaperSize.getOrientation(paramStyleSheet.getProperty("Orientation"));
    if (size != null) {
      setOrientation(i);
      setPageWidth((i == 1) ? size.width : size.height);
      setPageHeight((i == 1) ? size.height : size.width);
    } 
    for (int j = this.pages.getComponentCount() - 1; j >= 0; j--)
      this.pages.remove(j); 
    synchronized (paramStyleSheet) {
      Vector vector = new Vector();
      paramStyleSheet.reset();
      try {
        boolean bool;
        do {
          PreviewPage previewPage = createPage(this.pageWidth, this.pageHeight, this.resolution);
          previewPage.setPageIndex(vector.size());
          previewPage.addMouseListener(new MListener(this, previewPage));
          this.pages.add(previewPage);
          previewPage.addKeyListener(this.scrollListener);
          bool = paramStyleSheet.printNext(previewPage.getStylePage());
          vector.addElement(previewPage.getStylePage());
        } while (bool);
      } catch (OutOfMemoryError outOfMemoryError) {
        outOfMemoryError.printStackTrace();
      } 
      this.numpage = vector.size();
    } 
    if (this.zoomperc == 1.0D) {
      validate();
    } else {
      zoom(this.zoomperc);
    } 
    showPageNumber(this.pgnum = 1);
    repaint();
  }
  
  public int getPageCount() { return this.numpage; }
  
  public PreviewPage getPage(int paramInt) { return (PreviewPage)((paramInt < this.pages.getComponentCount()) ? this.pages.getComponent(paramInt) : null); }
  
  public void showPageNumber(int paramInt) { this.scroller.bar.pageB.setLabel(Catalog.getString("Page") + " " + paramInt + " " + Catalog.getString("of") + " " + getPageCount()); }
  
  public void showPageSize(Size paramSize) { this.scroller.bar.sizeB.setLabel(paramSize.width + " x " + paramSize.height + " in"); }
  
  public void showStatus(String paramString) { this.scroller.bar.statusF.setLabel(paramString); }
  
  protected PreviewPage createPage(double paramDouble1, double paramDouble2, int paramInt) { return new PreviewPage(paramDouble1, paramDouble2, paramInt); }
  
  protected void setPageCount(int paramInt) {
    for (int i = this.pages.getComponentCount() - 1; i >= paramInt; i--)
      this.pages.remove(i); 
    for (int j = this.pages.getComponentCount(); j < paramInt; j++) {
      PreviewPage previewPage = createPage(this.pageWidth, this.pageHeight, this.resolution);
      previewPage.setPageIndex(j);
      previewPage.addMouseListener(new MListener(this, previewPage));
      this.pages.add(previewPage);
      previewPage.addKeyListener(this.scrollListener);
    } 
    this.numpage = paramInt;
  }
  
  protected Container createScrollPane() {
    this.scroller = new StatusScrollPane(this);
    this.scroller.bar.pageB.addActionListener(new ActionListener(this) {
          private final PreviewPane this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.gotoPage(); }
        });
    MouseAdapter mouseAdapter = new MouseAdapter(this) {
        private final PreviewPane this$0;
        
        public void mouseClicked(MouseEvent param1MouseEvent) { this.this$0.requestFocus(); }
      };
    this.scroller.bar.pageB.addMouseListener(mouseAdapter);
    this.scroller.bar.sizeB.addMouseListener(mouseAdapter);
    this.scroller.bar.statusF.addMouseListener(mouseAdapter);
    return this.scroller;
  }
  
  protected void addToScrollPane(Component paramComponent) { this.scrollpane.add(paramComponent); }
  
  protected Container getViewport() { return ((pScrollPane)this.scrollpane).getViewport(); }
  
  protected int getBlockIncrement(Adjustable paramAdjustable) { return paramAdjustable.getBlockIncrement(); }
  
  public Dimension getViewportSize() { return ((pScrollPane)this.scrollpane).getViewportSize(); }
  
  public Adjustable getVAdjustable() { return ((pScrollPane)this.scrollpane).getVAdjustable(); }
  
  public Adjustable getHAdjustable() { return ((pScrollPane)this.scrollpane).getHAdjustable(); }
  
  protected void syncScrollPane() { ((pScrollPane)this.scrollpane).sync(); }
  
  public void setPages(int paramInt1, int paramInt2) {
    Dimension dimension = getViewportSize();
    dimension.width -= 40;
    dimension.height -= 40;
    double d = -1.0D;
    for (byte b = 0; b < this.pages.getComponentCount(); b++) {
      PreviewPage previewPage = (PreviewPage)this.pages.getComponent(b);
      if (d < 0.0D) {
        Dimension dimension1 = previewPage.getPageSize();
        d = dimension.width / dimension1.width / paramInt2;
        d = Math.min(d, dimension.height / dimension1.height / paramInt1);
      } 
      previewPage.setZoom(d);
    } 
    this.grid.setColumns(paramInt2);
    validate();
  }
  
  public void zoom(double paramDouble) {
    this.zoomperc = paramDouble;
    this.grid.setColumns(1);
    for (byte b = 0; b < this.pages.getComponentCount(); b++) {
      PreviewPage previewPage = (PreviewPage)this.pages.getComponent(b);
      if (paramDouble < 0.0D) {
        Dimension dimension1 = getViewportSize();
        dimension1.width -= 40;
        dimension1.height -= 40;
        Dimension dimension2 = previewPage.getPageSize();
        if (paramDouble == -1.0D) {
          paramDouble = dimension1.width / dimension2.width;
        } else if (paramDouble == -2.0D) {
          paramDouble = dimension1.height / dimension2.height;
        } else if (paramDouble == -3.0D) {
          setPages(1, 2);
          return;
        } 
      } 
      previewPage.setZoom(paramDouble);
    } 
    validate();
  }
  
  public void gotoPage() {
    Dialog dialog = new Dialog(Util.findFrame(this), Catalog.getString("Go To Page"));
    TextField textField = new TextField(8);
    dialog.setLayout(new BorderLayout(20, 20));
    dialog.add(new Component(this) {
          private final PreviewPane this$0;
        },  "North");
    Panel panel = new Panel();
    panel.add(new Label(Catalog.getString("Page") + ":"));
    panel.add(textField);
    panel.add(new Label(Catalog.getString("of") + " " + getPageCount()));
    dialog.add(panel, "Center");
    panel = new Panel();
    ActionListener actionListener = new ActionListener(this, textField, dialog) {
        private final TextComponent val$pgnumTF;
        
        private final Window val$win;
        
        private final PreviewPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            this.this$0.gotoPage(Integer.parseInt(this.val$pgnumTF.getText()));
            this.val$win.dispose();
          } catch (NumberFormatException numberFormatException) {
            this.val$pgnumTF.setText("");
          } 
        }
      };
    Button button = new Button("     " + Catalog.getString("OK") + "     ");
    button.addActionListener(actionListener);
    panel.add(button);
    button = new Button("   " + Catalog.getString("Cancel") + "   ");
    button.addActionListener(new ActionListener(this, dialog) {
          private final Window val$win;
          
          private final PreviewPane this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.val$win.dispose(); }
        });
    panel.add(button);
    dialog.add(panel, "South");
    textField.setText("" + this.pgnum);
    textField.selectAll();
    ((TextField)textField).addActionListener(actionListener);
    Point point = getLocationOnScreen();
    Dimension dimension = getSize();
    dialog.setLocation(point.x + dimension.width / 2 - 100, point.y + dimension.height / 2 - 80);
    ((Dialog)dialog).setModal(true);
    dialog.pack();
    dialog.setVisible(true);
  }
  
  public void gotoPage(int paramInt) {
    this.pgnum = paramInt;
    Adjustable adjustable = getVAdjustable();
    adjustable.setValue((paramInt - 1) * adjustable.getMaximum() / getPageCount());
    syncScrollPane();
    showPageNumber(this.pgnum);
  }
  
  public int getPageNumber() { return this.pgnum; }
  
  public void setFocusPage(int paramInt) {
    this.currpage = paramInt;
    this.vruler.repaint();
  }
  
  public void addSelectionListener(SelectionListener paramSelectionListener) { this.listeners.addElement(paramSelectionListener); }
  
  public void removeSelectionListener(SelectionListener paramSelectionListener) { this.listeners.removeElement(paramSelectionListener); }
  
  public void fireSelectionChange(Object paramObject1, String paramString, Object paramObject2, MouseEvent paramMouseEvent, Object paramObject3) {
    try {
      Vector vector = (Vector)this.listeners.clone();
      SelectionEvent selectionEvent = null;
      if (paramObject3 instanceof SectionInfo) {
        SectionInfo sectionInfo = (SectionInfo)paramObject3;
        selectionEvent = new SectionSelectionEvent((paramObject1 == null) ? paramString : paramObject1, paramString, paramObject2, paramMouseEvent.getClickCount(), paramMouseEvent, sectionInfo.row);
      } else {
        selectionEvent = new SelectionEvent((paramObject1 == null) ? paramString : paramObject1, paramString, paramObject2, paramMouseEvent.getClickCount(), paramMouseEvent);
      } 
      for (int i = vector.size() - 1; i >= 0; i--)
        ((SelectionListener)vector.elementAt(i)).valueChanged(selectionEvent); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  class Holder extends Component {
    private Dimension psize;
    
    private final PreviewPane this$0;
    
    public Holder(PreviewPane this$0, int param1Int1, int param1Int2) {
      this.this$0 = this$0;
      this.psize = new Dimension(param1Int1, param1Int2);
    }
    
    public Dimension getPreferredSize() { return this.psize; }
  }
  
  public KeyListener getScrollListener() { return this.scrollListener; }
  
  private Rectangle getTopBounds(PreviewPage paramPreviewPage) {
    Rectangle rectangle = paramPreviewPage.getBounds();
    for (PreviewPage previewPage = paramPreviewPage; previewPage.getParent() != this.toppane; ) {
      Container container = previewPage.getParent();
      Point point = container.getLocation();
      rectangle.x += point.x;
      rectangle.y += point.y;
    } 
    Insets insets = paramPreviewPage.getInsets();
    rectangle.x += insets.left;
    rectangle.y += insets.top;
    rectangle.width -= insets.left + insets.right;
    rectangle.height -= insets.top + insets.bottom;
    return rectangle;
  }
  
  class VerticalRuler extends Container {
    private final PreviewPane this$0;
    
    VerticalRuler(PreviewPane this$0) { this.this$0 = this$0; }
    
    public Dimension getPreferredSize() {
      Dimension dimension = this.this$0.pages.getPreferredSize();
      return this.this$0.ruler ? new Dimension(16, dimension.height) : new Dimension(0, 0);
    }
    
    public void paint(Graphics param1Graphics) {
      if (!this.this$0.ruler)
        return; 
      Dimension dimension = getSize();
      PreviewPage previewPage = this.this$0.getPage(this.this$0.currpage);
      if (previewPage == null)
        return; 
      Rectangle rectangle = this.this$0.getTopBounds(previewPage);
      Size size = previewPage.getPageSizeInch();
      rectangle.y -= (this.this$0.hruler.getSize()).height;
      param1Graphics.setFont(new Font("SansSerif", 0, 8));
      param1Graphics.setColor(Color.lightGray);
      param1Graphics.fillRect(0, 0, dimension.width, dimension.height);
      param1Graphics.setColor(new Color(40, 40, 40));
      double d1 = (rectangle.height / size.height);
      byte b = 0;
      for (double d2 = 0.0D; d2 < size.height; d2 += 0.0625D) {
        byte b1 = 4;
        if (b % 16 == 0) {
          b1 = 4;
        } else if (b % 8 == 0) {
          b1 = 5;
        } else if (b % 4 == 0) {
          b1 = 3;
        } else if (b % 2 == 0) {
          b1 = 2;
        } else {
          b1 = 1;
        } 
        b++;
        int i = rectangle.y + (int)(d2 * d1);
        param1Graphics.drawLine(0, i, b1, i);
        if (b1 == 4) {
          FontMetrics fontMetrics = param1Graphics.getFontMetrics();
          param1Graphics.drawString(Integer.toString(b / 16), b1 + 1, i + (fontMetrics.getAscent() - fontMetrics.getDescent()) / 2);
        } 
      } 
      super.paint(param1Graphics);
    }
    
    public void update(Graphics param1Graphics) { paint(param1Graphics); }
  }
  
  class HorizontalRuler extends Container {
    private final PreviewPane this$0;
    
    HorizontalRuler(PreviewPane this$0) { this.this$0 = this$0; }
    
    public Dimension getPreferredSize() {
      Dimension dimension = this.this$0.pages.getPreferredSize();
      return this.this$0.ruler ? new Dimension(dimension.width, 16) : new Dimension(0, 0);
    }
    
    public void paint(Graphics param1Graphics) {
      if (!this.this$0.ruler)
        return; 
      Dimension dimension = getSize();
      PreviewPage previewPage = this.this$0.getPage(this.this$0.currpage);
      if (previewPage == null)
        return; 
      Rectangle rectangle = this.this$0.getTopBounds(previewPage);
      Size size = previewPage.getPageSizeInch();
      param1Graphics.setFont(new Font("SansSerif", 0, 8));
      param1Graphics.setColor(Color.lightGray);
      param1Graphics.fillRect(0, 0, dimension.width, dimension.height);
      param1Graphics.setColor(new Color(40, 40, 40));
      double d1 = (rectangle.height / size.height);
      byte b = 0;
      for (double d2 = 0.0D; d2 < size.width; d2 += 0.0625D) {
        int i = 4;
        if (b % 16 == 0) {
          i = 4;
        } else if (b % 8 == 0) {
          i = 5;
        } else if (b % 4 == 0) {
          i = 3;
        } else if (b % 2 == 0) {
          i = 2;
        } else {
          i = 1;
        } 
        b++;
        int j = rectangle.x + (int)(d2 * d1);
        param1Graphics.drawLine(j, 0, j, i);
        if (i == 4) {
          FontMetrics fontMetrics = param1Graphics.getFontMetrics();
          String str = Integer.toString(b / 16);
          param1Graphics.drawString(str, j - fontMetrics.stringWidth(str) / 2, i + fontMetrics.getAscent());
        } 
      } 
      super.paint(param1Graphics);
    }
    
    public void update(Graphics param1Graphics) { paint(param1Graphics); }
  }
  
  class MListener extends MouseAdapter {
    PreviewPage pg;
    
    private final PreviewPane this$0;
    
    public MListener(PreviewPane this$0, PreviewPage param1PreviewPage) {
      this.this$0 = this$0;
      this.pg = param1PreviewPage;
    }
    
    public void mousePressed(MouseEvent param1MouseEvent) {
      StylePage stylePage = this.pg.getStylePage();
      if (this.this$0.listeners.size() > 0 && stylePage != null)
        for (byte b = 0; b < stylePage.getPaintableCount(); b++) {
          Paintable paintable = stylePage.getPaintable(b);
          Rectangle rectangle = paintable.getBounds();
          int i = (int)((param1MouseEvent.getX() - this.this$0.pmargin.left * this.this$0.resolution) / this.this$0.zoomperc);
          int j = (int)((param1MouseEvent.getY() - this.this$0.pmargin.top * this.this$0.resolution) / this.this$0.zoomperc);
          if (rectangle.contains(i, j)) {
            ReportElement reportElement = paintable.getElement();
            Object object = ((BasePaintable)paintable).getUserObject();
            if (reportElement.getType().equals("Chart")) {
              ChartPainter chartPainter = (ChartPainter)((PainterPaintable)paintable).getPainter();
              Point point = chartPainter.locate(i - rectangle.x, j - rectangle.y);
              ChartLens chartLens = null;
              try {
                chartLens = ((ChartElement)reportElement).getChart();
              } catch (Exception exception) {}
              if (point != null)
                this.this$0.fireSelectionChange(chartLens, reportElement.getID(), point, param1MouseEvent, object); 
            } else if (reportElement.getType().equals("Table")) {
              Point point = ((TablePaintable)paintable).locate(i, j);
              TableLens tableLens = null;
              try {
                tableLens = ((TableElement)reportElement).getTable();
              } catch (Exception exception) {}
              if (point != null)
                this.this$0.fireSelectionChange(tableLens, reportElement.getID(), point, param1MouseEvent, object); 
            } else if (reportElement.getType().equals("Text")) {
              String str = ((TextPaintable)paintable).getText();
              TextLens textLens = null;
              try {
                textLens = ((TextElementDef)reportElement).getTextLens();
              } catch (Exception exception) {}
              this.this$0.fireSelectionChange(textLens, reportElement.getID(), str, param1MouseEvent, object);
            } else if (reportElement.getType().equals("TextBox")) {
              TextPainter textPainter = (TextPainter)((PainterPaintable)paintable).getPainter();
              this.this$0.fireSelectionChange(textPainter.getTextLens(), reportElement.getID(), textPainter.getText(), param1MouseEvent, object);
            } else if (reportElement.getType().equals("Painter")) {
              Painter painter = ((PainterPaintable)paintable).getPainter();
              if (painter instanceof ComponentPainter) {
                this.this$0.fireSelectionChange(painter, reportElement.getID(), ((ComponentPainter)painter).getComponent(), param1MouseEvent, object);
              } else if (painter instanceof ImagePainter) {
                this.this$0.fireSelectionChange(painter, reportElement.getID(), ((ImagePainter)painter).getImage(), param1MouseEvent, object);
              } else {
                this.this$0.fireSelectionChange(painter, reportElement.getID(), painter, param1MouseEvent, object);
              } 
            } 
          } 
        }  
    }
  }
  
  protected class StatusScrollPane extends pScrollPane {
    PreviewPane.StatusScrollBar bar;
    
    private final PreviewPane this$0;
    
    public StatusScrollPane(PreviewPane this$0) {
      this.this$0 = this$0;
      setForce(true);
    }
    
    public Adjustable createHorizontalScrollBar() { return this.bar = new PreviewPane.StatusScrollBar(this.this$0); }
  }
  
  protected class StatusScrollBar extends Container implements Adjustable {
    Scrollbar scrollbar;
    
    Button pageB;
    
    Button sizeB;
    
    Button statusF;
    
    private final PreviewPane this$0;
    
    public StatusScrollBar(PreviewPane this$0) {
      this.this$0 = this$0;
      this.scrollbar = new Scrollbar(0);
      setLayout(new BorderLayout());
      this.pageB = new SmallButton(this, "Page 1 of 1");
      this.sizeB = new SmallButton(this, "8.5 x 11 in");
      this.statusF = new StatusButton(this);
      PreviewPane$8 previewPane$8 = new PreviewPane$8(this);
      previewPane$8.setLayout(new BorderLayout());
      previewPane$8.add(this.pageB, "West");
      previewPane$8.add(this.sizeB, "Center");
      previewPane$8.add(this.statusF, "East");
      add(previewPane$8, "West");
      add(this.scrollbar, "Center");
    }
    
    public int getOrientation() { return this.scrollbar.getOrientation(); }
    
    public void setOrientation(int param1Int) { this.scrollbar.setOrientation(param1Int); }
    
    public int getUnitIncrement(int param1Int) { return this.scrollbar.getUnitIncrement(); }
    
    public void setUnitIncrement(int param1Int) { this.scrollbar.setUnitIncrement(param1Int); }
    
    public int getBlockIncrement(int param1Int) { return this.scrollbar.getBlockIncrement(); }
    
    public void setBlockIncrement(int param1Int) { this.scrollbar.setBlockIncrement(param1Int); }
    
    public int getUnitIncrement() { return this.scrollbar.getUnitIncrement(); }
    
    public int getBlockIncrement() { return this.scrollbar.getBlockIncrement(); }
    
    public int getValue() { return this.scrollbar.getValue(); }
    
    public void setValue(int param1Int) { this.scrollbar.setValue(param1Int); }
    
    public int getVisibleAmount() { return this.scrollbar.getVisibleAmount(); }
    
    public void setVisibleAmount(int param1Int) { this.scrollbar.setVisibleAmount(param1Int); }
    
    public int getMinimum() { return this.scrollbar.getMinimum(); }
    
    public void setMinimum(int param1Int) { this.scrollbar.setMinimum(param1Int); }
    
    public int getMaximum() { return this.scrollbar.getMaximum(); }
    
    public void setMaximum(int param1Int) { this.scrollbar.setMaximum(param1Int); }
    
    public void addAdjustmentListener(AdjustmentListener param1AdjustmentListener) { this.scrollbar.addAdjustmentListener(param1AdjustmentListener); }
    
    public void removeAdjustmentListener(AdjustmentListener param1AdjustmentListener) { this.scrollbar.removeAdjustmentListener(param1AdjustmentListener); }
    
    public void setEnabled(boolean param1Boolean) { this.scrollbar.setEnabled(param1Boolean); }
    
    public boolean equals(Object param1Object) { return (param1Object instanceof Scrollbar) ? ((param1Object == this.scrollbar)) : super.equals(param1Object); }
    
    class StatusButton extends Button {
      private final PreviewPane.StatusScrollBar this$1;
      
      StatusButton(PreviewPane.StatusScrollBar this$0) {
        this.this$1 = this$0;
        setFont(new Font("Serif", 0, 10));
      }
      
      public Dimension getPreferredSize() { return new Dimension(120, (this.this$1.scrollbar.getPreferredSize()).height); }
      
      public Dimension getMaximumSize() { return new Dimension(120, (this.this$1.scrollbar.getMaximumSize()).height); }
      
      public Dimension getMinimumSize() { return new Dimension(120, (this.this$1.scrollbar.getMinimumSize()).height); }
      
      public float getAlignmentY() { return this.this$1.scrollbar.getAlignmentY(); }
    }
    
    class SmallButton extends Button {
      private final PreviewPane.StatusScrollBar this$1;
      
      public SmallButton(PreviewPane.StatusScrollBar this$0, String param2String) {
        super(param2String);
        this.this$1 = this$0;
        setFont(new Font("Serif", 0, 10));
      }
      
      public Dimension getPreferredSize() { return new Dimension((super.getPreferredSize()).width + 20, (this.this$1.scrollbar.getPreferredSize()).height); }
      
      public Dimension getMinimumSize() { return new Dimension((super.getMinimumSize()).width, (this.this$1.scrollbar.getMinimumSize()).height); }
      
      public Dimension getMaximumSize() { return new Dimension((super.getMaximumSize()).width, (this.this$1.scrollbar.getMaximumSize()).height); }
      
      public float getAlignmentY() { return this.this$1.scrollbar.getAlignmentY(); }
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\PreviewPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */