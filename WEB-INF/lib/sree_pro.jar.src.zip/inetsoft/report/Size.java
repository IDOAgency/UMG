/*    */ package inetsoft.report;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Size
/*    */   implements Serializable
/*    */ {
/*    */   public float width;
/*    */   public float height;
/*    */   
/* 29 */   public Size() { this(0.0F, 0.0F); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Size(float paramFloat1, float paramFloat2) {
/* 38 */     this.width = paramFloat1;
/* 39 */     this.height = paramFloat2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public Size(double paramDouble1, double paramDouble2) { this((float)paramDouble1, (float)paramDouble2); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   public Size(Dimension paramDimension) { this(paramDimension.width, paramDimension.height); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Size(int paramInt1, int paramInt2, int paramInt3) {
/* 67 */     this.width = paramInt1 / paramInt3;
/* 68 */     this.height = paramInt2 / paramInt3;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 76 */   public Size rotate() { return new Size(this.height, this.width); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 83 */   public Dimension getDimension() { return new Dimension((int)this.width, (int)this.height); }
/*    */ 
/*    */ 
/*    */   
/* 87 */   public String toString() { return this.width + "x" + this.height; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Size.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */