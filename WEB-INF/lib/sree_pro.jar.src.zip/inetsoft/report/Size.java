package inetsoft.report;

import java.awt.Dimension;
import java.io.Serializable;

public class Size implements Serializable {
  public float width;
  
  public float height;
  
  public Size() { this(0.0F, 0.0F); }
  
  public Size(float paramFloat1, float paramFloat2) {
    this.width = paramFloat1;
    this.height = paramFloat2;
  }
  
  public Size(double paramDouble1, double paramDouble2) { this((float)paramDouble1, (float)paramDouble2); }
  
  public Size(Dimension paramDimension) { this(paramDimension.width, paramDimension.height); }
  
  public Size(int paramInt1, int paramInt2, int paramInt3) {
    this.width = paramInt1 / paramInt3;
    this.height = paramInt2 / paramInt3;
  }
  
  public Size rotate() { return new Size(this.height, this.width); }
  
  public Dimension getDimension() { return new Dimension((int)this.width, (int)this.height); }
  
  public String toString() { return this.width + "x" + this.height; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Size.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */