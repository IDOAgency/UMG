package inetsoft.report;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.Serializable;

public interface Paintable extends Serializable {
  void paint(Graphics paramGraphics);
  
  Rectangle getBounds();
  
  void setLocation(Point paramPoint);
  
  ReportElement getElement();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Paintable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */