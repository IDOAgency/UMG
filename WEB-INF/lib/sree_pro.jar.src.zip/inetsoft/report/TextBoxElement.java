package inetsoft.report;

import java.awt.Insets;

public interface TextBoxElement extends PainterElement {
  void setBorder(int paramInt);
  
  int getBorder();
  
  void setBorders(Insets paramInsets);
  
  Insets getBorders();
  
  void setShape(int paramInt);
  
  int getShape();
  
  boolean isJustify();
  
  void setJustify(boolean paramBoolean);
  
  String getText();
  
  void setText(String paramString);
  
  void setText(TextLens paramTextLens);
  
  int getTextAlignment();
  
  void setTextAlignment(int paramInt);
  
  Insets getPadding();
  
  void setPadding(Insets paramInsets);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TextBoxElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */