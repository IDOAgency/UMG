package inetsoft.report;

import inetsoft.report.internal.AFManager;
import inetsoft.report.internal.Encoder;
import inetsoft.report.internal.FitCurves;
import inetsoft.report.internal.FitCurves.Point2;
import inetsoft.report.internal.PixelConsumer;
import inetsoft.report.internal.SymbolMapper;
import inetsoft.report.internal.Util;
import inetsoft.report.pdf.PDFDevice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.PrintJob;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.ImageObserver;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.text.AttributedCharacterIterator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class PDFPrinter extends Graphics implements PDFDevice {
  protected int pageheight;
  
  protected int pagewidth;
  
  public static final int RESOLUTION = 72;
  
  static final char[] hd = { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'A', 'B', 'C', 'D', 'E', 'F' };
  
  static final int charsPerRow = 72;
  
  CountWriter os;
  
  Color clr;
  
  Color backClr;
  
  Rectangle default_cliprect;
  
  private Vector oblique;
  
  protected Hashtable fontmap;
  
  ByteArrayOutputStream othersBuf;
  
  ByteArrayOutputStream pgBuf;
  
  protected Font font;
  
  protected FontMetrics fm;
  
  protected FontMetrics afm;
  
  protected CountWriter pg;
  
  protected CountWriter others;
  
  protected String psFontName;
  
  protected Hashtable fontFn;
  
  protected Vector fnList;
  
  protected Hashtable fontObj;
  
  protected Vector pageIds;
  
  protected String outlines;
  
  protected Rectangle clippingRect;
  
  private int objId;
  
  private int fontIdx;
  
  boolean started;
  
  int lengthId;
  
  int pagesId;
  
  int contentId;
  
  int resourceId;
  
  int egsId;
  
  Hashtable xrefs;
  
  boolean inited;
  
  Vector imgList;
  
  protected Point center;
  
  boolean textObj;
  
  PDFPrinter cloned;
  
  int savelevel;
  
  boolean closed;
  
  Margin pmargin;
  
  Hashtable imgmap;
  
  boolean compressText;
  
  boolean compressImg;
  
  boolean ascii;
  
  boolean mapSymbol;
  
  Printer job;
  
  public PDFPrinter() {
    this.pageheight = 792;
    this.pagewidth = 612;
    this.clr = Color.black;
    this.backClr = Color.white;
    this.default_cliprect = new Rectangle(0, 0, this.pagewidth, this.pageheight);
    this.oblique = new Vector();
    this.fontmap = new Hashtable();
    this.fontmap.put("dialog", "Helvetica");
    this.fontmap.put("dialoginput", "Courier");
    this.fontmap.put("serif", "Times");
    this.fontmap.put("sansserif", "Helvetica");
    this.fontmap.put("monospaced", "Courier");
    this.fontmap.put("timesroman", "Times");
    this.fontmap.put("courier", "Courier");
    this.fontmap.put("helvetica", "Helvetica");
    this.oblique.addElement("Courier");
    this.oblique.addElement("Helvetica");
    this.oblique.addElement("Courier");
    this.othersBuf = new ByteArrayOutputStream(8102);
    this.pgBuf = new ByteArrayOutputStream(8102);
    this.font = new Font("Helvetica", 0, 10);
    this.fm = null;
    this.afm = null;
    this.pg = new CountWriter(this, this.pgBuf);
    this.others = new CountWriter(this, this.othersBuf);
    this.psFontName = null;
    this.fontFn = new Hashtable();
    this.fnList = new Vector();
    this.fontObj = new Hashtable();
    this.pageIds = new Vector();
    this.outlines = null;
    this.clippingRect = this.default_cliprect;
    this.objId = 2;
    this.fontIdx = 1;
    this.started = false;
    this.lengthId = 0;
    this.pagesId = 1;
    this.contentId = 0;
    this.resourceId = 0;
    this.egsId = 0;
    this.xrefs = new Hashtable();
    this.inited = false;
    this.imgList = new Vector();
    this.center = new Point(0, 0);
    this.textObj = false;
    this.cloned = null;
    this.savelevel = 0;
    this.closed = false;
    this.pmargin = new Margin();
    this.imgmap = new Hashtable();
    this.compressText = true;
    this.compressImg = true;
    this.ascii = false;
    this.mapSymbol = false;
  }
  
  public PDFPrinter(File paramFile) throws IOException { this(new FileOutputStream(paramFile)); }
  
  public PDFPrinter(OutputStream paramOutputStream) {
    this();
    setOutput(paramOutputStream);
    startDoc();
  }
  
  public void setOutput(OutputStream paramOutputStream) {
    this.os = new CountWriter(this, paramOutputStream);
    this.started = false;
  }
  
  public void setCompressText(boolean paramBoolean) { this.compressText = paramBoolean; }
  
  public boolean isCompressText() { return this.compressText; }
  
  public void setAsciiOnly(boolean paramBoolean) { this.ascii = paramBoolean; }
  
  public boolean isAsciiOnly() { return this.ascii; }
  
  public void setCompressImage(boolean paramBoolean) { this.compressImg = paramBoolean; }
  
  public boolean isCompressImage() { return this.compressImg; }
  
  public void setMapSymbols(boolean paramBoolean) { this.mapSymbol = paramBoolean; }
  
  public boolean isMapSymbols() { return this.mapSymbol; }
  
  public Size getPageSize() { return new Size(this.pagewidth / 72.0D, this.pageheight / 72.0D); }
  
  public void setPageSize(double paramDouble1, double paramDouble2) {
    this.pagewidth = (int)(72.0D * paramDouble1);
    this.pageheight = (int)(72.0D * paramDouble2);
    this.default_cliprect = new Rectangle(0, 0, this.pagewidth, this.pageheight);
    this.clippingRect = this.default_cliprect;
  }
  
  public void setPageSize(Size paramSize) { setPageSize(paramSize.width, paramSize.height); }
  
  public String getFontName(Font paramFont) {
    String str1 = paramFont.getName().toLowerCase();
    String str2 = (String)this.fontmap.get(str1);
    if (isBase14Font(str1)) {
      str2 = paramFont.getName();
    } else if (str2 == null) {
      int j = str1.indexOf('.');
      if (j > 0)
        str2 = (String)this.fontmap.get(str1.substring(0, j)); 
    } 
    String str3 = (str2 == null) ? "Courier" : str2;
    int i = paramFont.getStyle();
    if ((i & true) != 0 && (i & 0x2) != 0) {
      str3 = str3 + (this.oblique.contains(str3) ? "-BoldOblique" : "-BoldItalic");
    } else if ((i & true) != 0) {
      str3 = str3 + "-Bold";
    } else if ((i & 0x2) != 0) {
      str3 = str3 + (this.oblique.contains(str3) ? "-Oblique" : "-Italic");
    } else if (str3.equals("Times")) {
      str3 = str3 + "-Roman";
    } 
    return str3;
  }
  
  public void putFontName(String paramString1, String paramString2) { this.fontmap.put(paramString1.toLowerCase(), paramString2); }
  
  public int getOutputSize() { return this.os.getOffset(); }
  
  public PrintJob getPrintJob() {
    if (this.job == null)
      this.job = new Printer(this); 
    return this.job;
  }
  
  class Printer extends PrintJob implements Serializable {
    private final PDFPrinter this$0;
    
    Printer(PDFPrinter this$0) { this.this$0 = this$0; }
    
    public Graphics getGraphics() { return this.this$0; }
    
    public Dimension getPageDimension() { return new Dimension(this.this$0.pagewidth, this.this$0.pageheight); }
    
    public int getPageResolution() { return 72; }
    
    public boolean lastPageFirst() { return false; }
    
    public void end() { this.this$0.close(); }
  }
  
  public Graphics create() {
    try {
      startPage();
      debug(this.pg, "%create");
      PDFPrinter pDFPrinter = (PDFPrinter)clone();
      pDFPrinter.center = new Point(this.center);
      pDFPrinter.savelevel = 0;
      pDFPrinter.cloned = this;
      pDFPrinter.inited = true;
      pDFPrinter.gsave();
      pDFPrinter.gsave();
      return pDFPrinter;
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public Graphics create(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Graphics graphics = create();
    graphics.setClip(paramInt1, paramInt2, paramInt3, paramInt4);
    graphics.translate(paramInt1, paramInt2);
    return graphics;
  }
  
  public void translate(int paramInt1, int paramInt2) {
    startPage();
    debug(this.pg, "%translate");
    this.center.x += paramInt1;
    this.center.y += paramInt2;
  }
  
  public Color getColor() { return (this.clr == null) ? Color.black : this.clr; }
  
  public void setBackground(Color paramColor) { this.backClr = paramColor; }
  
  public void setColor(Color paramColor) {
    startPage();
    debug(this.pg, "%setColor");
    if (paramColor != null) {
      this.clr = paramColor;
      double d1 = this.clr.getRed() / 255.0D;
      double d2 = this.clr.getGreen() / 255.0D;
      double d3 = this.clr.getBlue() / 255.0D;
      if (d1 == d2 && d2 == d3) {
        this.pg.println(Util.toString(d1, 3) + " g");
        this.pg.println(Util.toString(d1, 3) + " G");
      } else {
        this.pg.println(Util.toString(d1, 3) + " " + Util.toString(d2, 3) + " " + Util.toString(d3, 3) + " rg");
        this.pg.println(Util.toString(d1, 3) + " " + Util.toString(d2, 3) + " " + Util.toString(d3, 3) + " RG");
      } 
    } 
  }
  
  public void setPaintMode() {}
  
  public void setXORMode(Color paramColor) { System.err.println("XOR Mode Not supported"); }
  
  public Font getFont() { return this.font; }
  
  public void setFont(Font paramFont) {
    this.font = paramFont;
    this.fm = null;
    this.afm = null;
    if (isTextObj()) {
      emitFont(this.font);
    } else {
      this.psFontName = null;
    } 
  }
  
  protected void emitFont(Font paramFont) {
    startPage();
    debug(this.pg, "%setFont");
    this.psFontName = getFontName(paramFont);
    String str = (String)this.fontFn.get(this.psFontName);
    if (str == null) {
      str = "F" + getNextFontIndex();
      String str1 = (String)this.fontObj.get(this.psFontName);
      if (str1 == null) {
        int i = getNextObjectID();
        str1 = i + " 0 R";
        this.fontObj.put(this.psFontName, str1);
        this.others.markObject(i);
        this.others.println(i + " 0 obj");
        this.others.println("<<");
        this.others.println("/Type /Font");
        this.others.println("/Subtype /Type1");
        this.others.println("/Name /" + str);
        this.others.println("/BaseFont /" + this.psFontName);
        String str2 = this.psFontName.equals("Symbol") ? "PDFDocEncoding" : "WinAnsiEncoding";
        this.others.println("/Encoding /" + str2);
        this.others.println(">>");
        this.others.println("endobj");
      } 
      this.fnList.addElement("/" + str + " " + str1 + " ");
    } 
    this.pg.println("/" + str + " " + paramFont.getSize() + " Tf");
    this.fontFn.put(this.psFontName, str);
  }
  
  public FontMetrics getFontMetrics() { return (this.fm == null) ? (this.fm = getFontMetrics(getFont())) : this.fm; }
  
  public FontMetrics getFontMetrics(Font paramFont) { return Common.getFontMetrics(paramFont); }
  
  public Rectangle getClipBounds() { return new Rectangle(this.clippingRect.x - this.center.x, this.clippingRect.y - this.center.y, this.clippingRect.width, this.clippingRect.height); }
  
  public Shape getClip() { return getClipBounds(); }
  
  public void clipRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clipRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clipRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    startPage();
    debug(this.pg, "%clipRect");
    checkTextObj(false);
    gsave(4);
    this.clippingRect = this.clippingRect.intersection(new Rectangle((int)paramDouble1 + this.center.x, (int)paramDouble2 + this.center.y, (int)paramDouble3, (int)paramDouble4));
    emitClip(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  public void setClip(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { setClip(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void setClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    startPage();
    debug(this.pg, "%setClip");
    checkTextObj(false);
    grestore(4);
    this.clippingRect = new Rectangle((int)paramDouble1 + this.center.x, (int)paramDouble2 + this.center.y, (int)paramDouble3, (int)paramDouble4);
    gsave(4);
    emitClip(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
  }
  
  protected void emitClip(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    paramDouble2 = transformY(paramDouble2);
    paramDouble1 = transformX(paramDouble1);
    this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2) + " " + toString(paramDouble3) + " " + toString(-paramDouble4) + " re");
    this.pg.println("W* n");
  }
  
  public void setClip(Shape paramShape) {
    Rectangle rectangle = (Rectangle)paramShape;
    setClip(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
  }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { throw new RuntimeException("copyArea not supported"); }
  
  public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawLine(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawLine(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    startPage();
    debug(this.pg, "%drawLine");
    double d1 = 0.5D;
    double d2 = paramDouble3 - paramDouble1, d3 = paramDouble4 - paramDouble2;
    double d4 = Math.sqrt(d2 * d2 + d3 * d3);
    double d5 = (d4 > 0.0D) ? (d1 * Math.abs(d3) / d4) : 0.0D;
    double d6 = (d4 > 0.0D) ? (d1 * Math.abs(d2) / d4) : 0.0D;
    if (paramDouble1 == paramDouble3 && paramDouble2 == paramDouble4) {
      paramDouble3 += 0.5D;
      paramDouble2 = paramDouble4 = paramDouble2 + 0.5D;
    } 
    paramDouble2 = transformY(paramDouble2 + d6);
    paramDouble4 = transformY(paramDouble4 + d6);
    paramDouble1 = transformX(paramDouble1 + d5);
    paramDouble3 = transformX(paramDouble3 + d5);
    checkTextObj(false);
    this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2) + " m");
    this.pg.println(toString(paramDouble3) + " " + toString(paramDouble4) + " l");
    this.pg.println("S");
  }
  
  public void drawPolyline(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
    for (byte b = 1; b < paramInt; b++)
      drawLine(paramArrayOfInt1[b - true], paramArrayOfInt2[b - true], paramArrayOfInt1[b], paramArrayOfInt2[b]); 
  }
  
  void doRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
    startPage();
    debug(this.pg, "%doRect");
    paramDouble2 = transformY(paramDouble2);
    paramDouble1 = transformX(paramDouble1);
    checkTextObj(false);
    if (paramBoolean) {
      this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2) + " " + toString(paramDouble3) + " -" + toString(paramDouble4) + " re");
      this.pg.println("f*");
    } else {
      this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2) + " m");
      this.pg.println(toString(paramDouble1 + paramDouble3) + " " + toString(paramDouble2) + " l");
      this.pg.println(toString(paramDouble1 + paramDouble3) + " " + toString(paramDouble2 - paramDouble4) + " l");
      this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2 - paramDouble4) + " l");
      this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2) + " l");
      this.pg.println("S");
    } 
  }
  
  public void fillRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { fillRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    debug(this.pg, "%fillRect");
    doRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, true);
  }
  
  public void drawRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    debug(this.pg, "%drawRect");
    doRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, false);
  }
  
  public void clearRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { clearRect(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void clearRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    startPage();
    debug(this.pg, "%clearRect");
    checkTextObj(false);
    Color color = getColor();
    setColor(this.backClr);
    doRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, true);
    setColor(color);
  }
  
  private void doRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, boolean paramBoolean) {
    startPage();
    debug(this.pg, "%doRoundRect");
    paramDouble2 = transformY(paramDouble2);
    paramDouble1 = transformX(paramDouble1);
    double d1 = paramDouble1 + paramDouble3, d2 = paramDouble2 - paramDouble4;
    checkTextObj(false);
    this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2 - paramDouble6) + " m");
    this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2) + " " + toString(paramDouble1) + " " + toString(paramDouble2) + " " + toString(paramDouble1 + paramDouble5) + " " + toString(paramDouble2) + " c");
    this.pg.println(toString(d1 - paramDouble5) + " " + toString(paramDouble2) + " l");
    this.pg.println(toString(d1) + " " + toString(paramDouble2) + " " + toString(d1) + " " + toString(paramDouble2) + " " + toString(d1) + " " + toString(paramDouble2 - paramDouble6) + " c");
    this.pg.println(toString(d1) + " " + toString(d2 + paramDouble6) + " l");
    this.pg.println(toString(d1) + " " + toString(d2) + " " + toString(d1) + " " + toString(d2) + " " + toString(d1 - paramDouble5) + " " + toString(d2) + " c");
    this.pg.println(toString(paramDouble1 + paramDouble5) + " " + toString(d2) + " l");
    this.pg.println(toString(paramDouble1) + " " + toString(d2) + " " + toString(paramDouble1) + " " + toString(d2) + " " + toString(paramDouble1) + " " + toString(d2 + paramDouble6) + " c");
    this.pg.println(toString(paramDouble1) + " " + toString(paramDouble2 + paramDouble6) + " l");
    if (paramBoolean) {
      this.pg.println("f*");
    } else {
      this.pg.println("S");
    } 
  }
  
  public void drawRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { drawRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    debug(this.pg, "%drawRoundRect");
    doRoundRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, false);
  }
  
  public void fillRoundRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { fillRoundRect(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillRoundRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    debug(this.pg, "%fillRoundRect");
    doRoundRect(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, true);
  }
  
  public void draw3DRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) { draw3DRect(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean); }
  
  public void draw3DRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
    startPage();
    debug(this.pg, "%draw3DRect");
    Color color1 = getColor();
    Color color2 = color1.brighter();
    Color color3 = color1.darker();
    setColor(paramBoolean ? color2 : color3);
    drawLine(paramDouble1, paramDouble2, paramDouble1, paramDouble2 + paramDouble4);
    drawLine(paramDouble1 + 1.0D, paramDouble2, paramDouble1 + paramDouble3 - 1.0D, paramDouble2);
    setColor(paramBoolean ? color3 : color2);
    drawLine(paramDouble1 + 1.0D, paramDouble2 + paramDouble4, paramDouble1 + paramDouble3, paramDouble2 + paramDouble4);
    drawLine(paramDouble1 + paramDouble3, paramDouble2, paramDouble1 + paramDouble3, paramDouble2 + paramDouble4);
    setColor(color1);
  }
  
  public void fill3DRect(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) { fill3DRect(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean); }
  
  public void fill3DRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) {
    startPage();
    debug(this.pg, "%fill3DRect");
    Color color1 = getColor();
    Color color2 = color1.brighter();
    Color color3 = color1.darker();
    if (!paramBoolean)
      setColor(color3); 
    fillRect(paramDouble1 + 1.0D, paramDouble2 + 1.0D, paramDouble3 - 2.0D, paramDouble4 - 2.0D);
    setColor(paramBoolean ? color2 : color3);
    drawLine(paramDouble1, paramDouble2, paramDouble1, paramDouble2 + paramDouble4 - 1.0D);
    drawLine(paramDouble1 + 1.0D, paramDouble2, paramDouble1 + paramDouble3 - 2.0D, paramDouble2);
    setColor(paramBoolean ? color3 : color2);
    drawLine(paramDouble1 + 1.0D, paramDouble2 + paramDouble4 - 1.0D, paramDouble1 + paramDouble3 - 1.0D, paramDouble2 + paramDouble4 - 1.0D);
    drawLine(paramDouble1 + paramDouble3 - 1.0D, paramDouble2, paramDouble1 + paramDouble3 - 1.0D, paramDouble2 + paramDouble4 - 1.0D);
    setColor(color1);
  }
  
  public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { drawOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void drawOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    debug(this.pg, "%drawOval");
    doArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, 0.0D, 360.0D, false);
  }
  
  public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { fillOval(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void fillOval(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    debug(this.pg, "%fillOval");
    doArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, 0.0D, 360.0D, true);
  }
  
  private void doArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, boolean paramBoolean) {
    startPage();
    debug(this.pg, "%doArc");
    if (paramDouble6 == 0.0D)
      return; 
    paramDouble2 = transformY(paramDouble2);
    paramDouble1 = transformX(paramDouble1);
    checkTextObj(false);
    boolean bool = true;
    double d1 = paramDouble5 + paramDouble6;
    double d2 = Math.min(3.0D, paramDouble6 / 4.0D);
    Vector vector1 = new Vector();
    for (double d3 = paramDouble5; d3 < d1; d3 += d2)
      vector1.addElement(getArcPoint(paramDouble1, paramDouble2, paramDouble3, paramDouble4, d3)); 
    vector1.addElement(getArcPoint(paramDouble1, paramDouble2, paramDouble3, paramDouble4, d1));
    FitCurves.Point2[] arrayOfPoint2 = new FitCurves.Point2[vector1.size()];
    vector1.copyInto(arrayOfPoint2);
    FitCurves fitCurves = new FitCurves(arrayOfPoint2, 4.0D);
    Vector vector2 = fitCurves.getCurves();
    for (byte b = 0; b < vector2.size(); b++) {
      Point2[] arrayOfPoint21 = (Point2[])vector2.elementAt(b);
      if (paramBoolean)
        this.pg.println(toString(paramDouble1 + paramDouble3 / 2.0D) + " " + toString(paramDouble2 - paramDouble4 / 2.0D) + " m"); 
      this.pg.println(toString((arrayOfPoint21[0]).x) + " " + toString((arrayOfPoint21[0]).y) + (paramBoolean ? " l" : " m"));
      this.pg.println(toString((arrayOfPoint21[1]).x) + " " + toString((arrayOfPoint21[1]).y) + " " + toString((arrayOfPoint21[2]).x) + " " + toString((arrayOfPoint21[2]).y) + " " + toString((arrayOfPoint21[3]).x) + " " + toString((arrayOfPoint21[3]).y) + " c");
    } 
    if (paramBoolean) {
      this.pg.println("f*");
    } else {
      this.pg.println("S");
    } 
  }
  
  public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { drawArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void drawArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    debug(this.pg, "%drawArc");
    doArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, false);
  }
  
  public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { fillArc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6); }
  
  public void fillArc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
    debug(this.pg, "%fillArc");
    doArc(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, true);
  }
  
  private void doPoly(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt, boolean paramBoolean) {
    startPage();
    if (paramInt < 2)
      return; 
    checkTextObj(false);
    double[] arrayOfDouble1 = new double[paramInt];
    double[] arrayOfDouble2 = new double[paramInt];
    for (byte b1 = 0; b1 < paramInt; b1++)
      arrayOfDouble1[b1] = transformY(paramArrayOfInt2[b1]); 
    for (byte b2 = 0; b2 < paramInt; b2++)
      arrayOfDouble2[b2] = transformX(paramArrayOfInt1[b2]); 
    this.pg.print(toString(arrayOfDouble2[0]) + " " + toString(arrayOfDouble1[0]) + " m ");
    for (byte b3 = 1; b3 < paramInt; b3++)
      this.pg.println(toString(arrayOfDouble2[b3]) + " " + toString(arrayOfDouble1[b3]) + " l"); 
    this.pg.print(toString(arrayOfDouble2[0]) + " " + toString(arrayOfDouble1[0]) + " l ");
    if (paramBoolean) {
      this.pg.println("f*");
    } else {
      this.pg.println("S");
    } 
  }
  
  public void drawPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
    debug(this.pg, "%drawPoly");
    doPoly(paramArrayOfInt1, paramArrayOfInt2, paramInt, false);
  }
  
  public void drawPolygon(Polygon paramPolygon) {
    debug(this.pg, "%drawPoly");
    doPoly(paramPolygon.xpoints, paramPolygon.ypoints, paramPolygon.npoints, false);
  }
  
  public void fillPolygon(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt) {
    debug(this.pg, "%fillPoly");
    doPoly(paramArrayOfInt1, paramArrayOfInt2, paramInt, true);
  }
  
  public void fillPolygon(Polygon paramPolygon) {
    debug(this.pg, "%fillPoly");
    doPoly(paramPolygon.xpoints, paramPolygon.ypoints, paramPolygon.npoints, true);
  }
  
  public void drawString(String paramString, int paramInt1, int paramInt2) { drawString(paramString, paramInt1, paramInt2); }
  
  public void drawString(String paramString, double paramDouble1, double paramDouble2) {
    if (paramString == null || paramString.length() == 0)
      return; 
    startPage();
    debug(this.pg, "%drawString");
    checkTextObj(true);
    double d1 = transformY(paramDouble2);
    double d2 = transformX(paramDouble1);
    FontMetrics fontMetrics = Common.getFontMetrics(getFont());
    double d3 = Common.stringWidth(paramString, getFont(), fontMetrics);
    double d4 = stringWidth(paramString);
    double d5 = d3 / d4;
    String[] arrayOfString = splitWords(paramString);
    double[] arrayOfDouble = new double[arrayOfString.length];
    double d6 = 0.0D;
    for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
      arrayOfDouble[b1] = stringWidth(arrayOfString[b1]);
      d6 += arrayOfDouble[b1];
    } 
    double d7 = (paramString.length() > 1) ? ((d3 - d4) / (paramString.length() - 1)) : 0.0D;
    double d8 = (arrayOfString.length > 1) ? ((d4 - d6) * d5 / (arrayOfString.length - 1)) : 0.0D;
    this.pg.println(toString(d7) + " Tc");
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      if (arrayOfString[b2].length() > 0 && arrayOfString[b2].charAt(0) != ' ') {
        this.pg.println("1 0 0 1 " + toString(d2) + " " + toString(d1) + " Tm");
        emitTj(arrayOfString[b2]);
      } 
      d2 += arrayOfDouble[b2] * d5 + d8;
    } 
  }
  
  protected void emitTj(String paramString) {
    if (this.mapSymbol) {
      char[] arrayOfChar = new char[paramString.length() + 1];
      byte b1 = 0;
      boolean bool = false;
      Font font1 = this.font;
      Font font2 = new Font("Symbol", this.font.getStyle(), this.font.getSize());
      for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
        arrayOfChar[b2] = (b2 < paramString.length()) ? SymbolMapper.map(paramString.charAt(b2)) : (bool ? Character.MIN_VALUE : 'a');
        if (bool != ((arrayOfChar[b2] != '\000') ? 1 : 0)) {
          if (b2 > b1) {
            if (bool) {
              setFont(font2);
              this.pg.println("(" + escapeString(new String(arrayOfChar, b1, b2 - b1)) + ") Tj");
            } else {
              setFont(font1);
              this.pg.println("(" + escapeString(paramString.substring(b1, b2)) + ") Tj");
            } 
            b1 = b2;
          } 
          bool = (arrayOfChar[b2] != '\000') ? 1 : 0;
        } 
      } 
    } else {
      this.pg.println("(" + escapeString(paramString) + ") Tj");
    } 
  }
  
  protected int stringWidth(String paramString) {
    if (this.afm == null) {
      this.afm = AFManager.getFontMetrics(getFontName(this.font), this.font.getSize());
      if (this.afm == null)
        this.afm = Common.getFontMetrics(this.font); 
    } 
    return this.afm.stringWidth(paramString);
  }
  
  public void drawString(AttributedCharacterIterator paramAttributedCharacterIterator, int paramInt1, int paramInt2) {}
  
  public void drawChars(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    debug(this.pg, "%drawChars");
    drawString(new String(paramArrayOfChar, paramInt1, paramInt2), paramInt3, paramInt4);
  }
  
  public void drawBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    debug(this.pg, "%drawBytes");
    drawString(new String(paramArrayOfByte, paramInt1, paramInt2), paramInt3, paramInt4);
  }
  
  public boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
    PixelConsumer pixelConsumer = new PixelConsumer(paramImage);
    return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
  }
  
  public boolean doImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver, Color paramColor) {
    PixelConsumer pixelConsumer = new PixelConsumer(paramImage, paramInt5, paramInt6, paramInt7, paramInt8);
    return doImage(pixelConsumer, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
  }
  
  boolean doImage(PixelConsumer paramPixelConsumer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver, Color paramColor) {
    startPage();
    debug(this.pg, "%doImage");
    paramInt2 = (int)transformY(paramInt2);
    paramInt1 = (int)transformX(paramInt1);
    paramPixelConsumer.produce();
    if (paramPixelConsumer.width == 0 || paramPixelConsumer.height == 0)
      return true; 
    checkTextObj(false);
    if (paramInt4 == 0 || paramInt3 == 0) {
      paramInt4 = paramPixelConsumer.height;
      paramInt3 = paramPixelConsumer.width;
    } 
    Integer integer = (Integer)this.imgmap.get(paramPixelConsumer.getKey());
    int i = 1;
    if (integer != null) {
      i = integer.intValue();
    } else {
      i = getNextObjectID();
      paramPixelConsumer.produce();
      if (this.imgmap.size() < 10)
        this.imgmap.put(paramPixelConsumer.getKey(), new Integer(i)); 
    } 
    if (integer == null) {
      byte[] arrayOfByte;
      int j = getNextObjectID();
      this.imgList.addElement("/Im" + i + " " + i + " 0 R");
      this.others.markObject(i);
      this.others.println(i + " 0 obj");
      this.others.println("<<");
      this.others.println("/Type /XObject");
      this.others.println("/Subtype /Image");
      this.others.println("/Name /Im" + i);
      this.others.println("/Width " + paramPixelConsumer.width);
      this.others.println("/Height " + paramPixelConsumer.height);
      this.others.println("/BitsPerComponent 8");
      this.others.println("/ColorSpace /DeviceRGB");
      if (this.compressImg) {
        if (this.ascii) {
          this.others.println("/Filter [ /ASCII85Decode /FlateDecode ]");
        } else {
          this.others.println("/Filter [ /FlateDecode ]");
        } 
      } else if (this.ascii) {
        this.others.println("/Filter /ASCII85Decode");
      } 
      this.others.println("/Length " + j + " 0 R");
      this.others.println(">>");
      this.others.println("stream");
      int k = this.others.getOffset();
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      for (int m = paramPixelConsumer.height - 1; m >= 0; m--) {
        for (byte b = 0; b < paramPixelConsumer.width; b++) {
          int i1 = paramPixelConsumer.pix[b][m];
          if ((i1 & 0xFF000000) == 0)
            i1 = (paramColor == null) ? 16777215 : paramColor.getRGB(); 
          byteArrayOutputStream.write((byte)((i1 & 0xFF0000) >> 16));
          byteArrayOutputStream.write((byte)((i1 & 0xFF00) >> 8));
          byteArrayOutputStream.write((byte)(i1 & 0xFF));
        } 
      } 
      if (this.compressImg) {
        if (this.ascii) {
          arrayOfByte = Encoder.encodeAscii85(Encoder.deflate(byteArrayOutputStream.toByteArray()));
        } else {
          arrayOfByte = Encoder.deflate(byteArrayOutputStream.toByteArray());
        } 
      } else if (this.ascii) {
        arrayOfByte = Encoder.encodeAscii85(byteArrayOutputStream.toByteArray());
      } else {
        arrayOfByte = byteArrayOutputStream.toByteArray();
      } 
      if (this.ascii) {
        for (int i1 = 0; i1 < arrayOfByte.length; i1 += 72) {
          if (i1)
            this.others.println(""); 
          try {
            this.others.write(arrayOfByte, i1, Math.min(arrayOfByte.length - i1, 72));
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
        } 
      } else {
        try {
          this.others.write(arrayOfByte);
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
      } 
      if (this.ascii)
        this.others.println("~>"); 
      int n = this.others.getOffset() - k;
      this.others.println("endstream");
      this.others.println("endobj");
      this.others.markObject(j);
      this.others.println(j + " 0 obj");
      this.others.println(n + "");
      this.others.println("endobj");
    } 
    gsave();
    this.pg.println(paramInt3 + " 0 0 -" + paramInt4 + " " + paramInt1 + " " + paramInt2 + " cm");
    this.pg.println("/Im" + i + " Do");
    grestore();
    return true;
  }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, ImageObserver paramImageObserver) {
    debug(this.pg, "%drawImage-1");
    return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, null);
  }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ImageObserver paramImageObserver) {
    debug(this.pg, "%drawImage-2");
    return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, null);
  }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, Color paramColor, ImageObserver paramImageObserver) {
    debug(this.pg, "%drawImage-3");
    return doImage(paramImage, paramInt1, paramInt2, 0, 0, paramImageObserver, paramColor);
  }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, ImageObserver paramImageObserver) {
    debug(this.pg, "%drawImage-4");
    return doImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramImageObserver, paramColor);
  }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, ImageObserver paramImageObserver) {
    debug(this.pg, "%drawImage-5");
    return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, null);
  }
  
  public boolean drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, Color paramColor, ImageObserver paramImageObserver) {
    debug(this.pg, "%drawImage-6");
    return doImage(paramImage, paramInt1, paramInt2, paramInt3 - paramInt1 + 1, paramInt4 - paramInt2 + 1, paramInt5, paramInt6, paramInt7, paramInt8, paramImageObserver, paramColor);
  }
  
  public void dispose() {
    if (!this.inited)
      return; 
    checkTextObj(false);
    while (this.savelevel > 0)
      grestore(); 
    if (this.cloned != null) {
      debug(this.pg, "%dispose-sub");
      this.inited = false;
      return;
    } 
    debug(this.pg, "%dispose");
    this.pg.flush();
    byte[] arrayOfByte = this.pgBuf.toByteArray();
    int i = this.os.getOffset();
    if (this.compressText) {
      if (!this.ascii) {
        arrayOfByte = Encoder.deflate(arrayOfByte);
        try {
          this.os.write(arrayOfByte);
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
      } else {
        arrayOfByte = Encoder.encodeAscii85(Encoder.deflate(arrayOfByte));
        for (int m = 0; m < arrayOfByte.length; m += 72) {
          if (m)
            this.os.println(""); 
          try {
            this.os.write(arrayOfByte, m, Math.min(arrayOfByte.length - m, 72));
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
        } 
        this.os.println("~>");
      } 
    } else {
      try {
        this.os.write(arrayOfByte);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
    this.pgBuf.reset();
    this.pg.reset();
    int j = this.os.getOffset() - i;
    this.resourceId = getNextObjectID();
    this.os.println("endstream");
    this.os.println("endobj");
    this.xrefs.put(new Integer(this.lengthId), new Integer(this.os.getOffset()));
    this.os.println(this.lengthId + " 0 obj");
    this.os.println(j + "");
    this.os.println("endobj");
    int k = getNextObjectID();
    this.xrefs.put(new Integer(k), new Integer(this.os.getOffset()));
    this.os.println(k + " 0 obj");
    this.os.println("<<");
    this.os.println("/Type /Page");
    this.os.println("/Parent " + this.pagesId + " 0 R");
    this.os.println("/Resources " + this.resourceId + " 0 R");
    this.os.println("/Contents " + this.contentId + " 0 R");
    this.os.println("/MediaBox [0 0 " + this.pagewidth + " " + this.pageheight + "]");
    this.os.println(">>");
    this.os.println("endobj");
    this.pageIds.addElement(k + " 0 R");
    this.xrefs.put(new Integer(this.resourceId), new Integer(this.os.getOffset()));
    this.os.println(this.resourceId + " 0 obj");
    this.os.println("<<");
    this.os.print("/ProcSet [/PDF");
    if (this.fnList.size() > 0)
      this.os.print(" /Text"); 
    if (this.imgList.size() > 0)
      this.os.print(" /ImageC"); 
    this.os.println("]");
    this.os.println("/ExtGState <<");
    this.os.println("/GS1 " + this.egsId + " 0 R");
    this.os.println(">>");
    if (this.fnList.size() > 0) {
      this.os.println("/Font <<");
      for (byte b = 0; b < this.fnList.size(); b++)
        this.os.println((String)this.fnList.elementAt(b)); 
      this.os.println(">>");
    } 
    if (this.imgList.size() > 0) {
      this.os.println("/XObject <<");
      for (byte b = 0; b < this.imgList.size(); b++)
        this.os.println((String)this.imgList.elementAt(b)); 
      this.os.println(">>");
    } 
    this.os.println(">>");
    this.os.println("endobj");
    this.os.flush();
    writeOthers();
    this.inited = false;
  }
  
  public void close() {
    if (!this.closed) {
      writeOthers();
      emitTrailer();
      this.os.write(26);
      this.os.write(4);
      this.os.close();
      this.closed = true;
      this.imgmap.clear();
    } 
  }
  
  public void finalize() {}
  
  public void emit(String paramString) { this.pg.println(paramString); }
  
  public void gsave() {
    checkTextObj(false);
    this.pg.println("q");
    this.savelevel++;
  }
  
  public void gsave(int paramInt) {
    if (this.savelevel > paramInt)
      System.err.println("Warning: PDF save level overflowed."); 
    while (this.savelevel < paramInt)
      gsave(); 
  }
  
  public void grestore() {
    if (this.savelevel > 0) {
      checkTextObj(false);
      this.pg.println("Q");
      this.savelevel--;
    } 
  }
  
  public int grestore(int paramInt) {
    byte b = 0;
    while (this.savelevel >= paramInt) {
      grestore();
      b++;
    } 
    if (b > 0) {
      setColor(this.clr);
      setFont(this.font);
    } 
    return b;
  }
  
  protected void writeOthers() {
    try {
      this.others.flush();
      Hashtable hashtable = this.others.getObjectMarks();
      int i = this.os.getOffset();
      Enumeration enumeration = hashtable.keys();
      while (enumeration.hasMoreElements()) {
        Object object = enumeration.nextElement();
        int j = ((Integer)hashtable.get(object)).intValue();
        this.xrefs.put(object, new Integer(j + i));
      } 
      this.os.write(this.othersBuf.toByteArray());
      this.others.reset();
      this.othersBuf.reset();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void startDoc() {
    if (!this.started) {
      this.started = true;
      this.pmargin = StyleSheet.getPrinterMargin();
      this.os.println("%PDF-" + getPDFVersion());
      this.os.println("%âãÏÓ");
      this.egsId = getNextObjectID();
      this.xrefs.put(new Integer(this.egsId), new Integer(this.os.getOffset()));
      this.os.println(this.egsId + " 0 obj");
      this.os.println("<<");
      this.os.println("/Type /ExtGState");
      this.os.println("/SA false");
      this.os.println("/OP false");
      this.os.println("/HT /Default");
      this.os.println(">>");
      this.os.println("endobj");
    } 
  }
  
  private boolean isTextObj() {
    if (this.cloned != null)
      return (getRoot()).textObj; 
    return this.textObj;
  }
  
  public void checkTextObj(boolean paramBoolean) {
    if (this.cloned != null) {
      PDFPrinter pDFPrinter = getRoot();
      if (pDFPrinter.textObj != paramBoolean) {
        pDFPrinter.textObj = paramBoolean;
        if (pDFPrinter.textObj) {
          this.pg.println("BT");
          if (this.psFontName == null)
            emitFont(this.font); 
        } else {
          this.pg.println("ET");
          this.psFontName = null;
        } 
      } 
      return;
    } 
    startPage();
    if (this.textObj != paramBoolean) {
      this.textObj = paramBoolean;
      if (this.textObj) {
        this.pg.println("BT");
        if (this.psFontName == null)
          emitFont(this.font); 
      } else {
        this.pg.println("ET");
        this.psFontName = null;
      } 
    } 
  }
  
  public String getPDFVersion() { return "1.2"; }
  
  public String toString() { return getClass().getName() + "[font=" + getFont() + ",color=" + getColor() + "]"; }
  
  protected double transformY(double paramDouble) { return -(paramDouble + this.center.y); }
  
  protected double transformX(double paramDouble) { return paramDouble + this.center.x; }
  
  void emitTrailer() {
    this.xrefs.put(new Integer(this.pagesId), new Integer(this.os.getOffset()));
    this.os.println(this.pagesId + " 0 obj");
    this.os.println("<<");
    this.os.println("/Type /Pages");
    this.os.print("/Kids [");
    for (byte b1 = 0; b1 < this.pageIds.size(); b1++) {
      if (b1)
        this.os.print(" "); 
      this.os.print((String)this.pageIds.elementAt(b1));
    } 
    this.os.println("]");
    this.os.println("/Count " + this.pageIds.size());
    this.os.println(">>");
    this.os.println("endobj");
    int i = getNextObjectID();
    this.xrefs.put(new Integer(i), new Integer(this.os.getOffset()));
    this.os.println(i + " 0 obj");
    this.os.println("<<");
    this.os.println("/Type /Catalog");
    this.os.println("/Pages " + this.pagesId + " 0 R");
    if (this.outlines != null)
      this.os.println("/Outlines " + this.outlines); 
    this.os.println(">>");
    this.os.println("endobj");
    int j = this.os.getOffset();
    this.os.println("xref");
    this.os.println("0 " + (this.xrefs.size() + 1));
    this.os.println("0000000000 65535 f" + XREF_SPACE);
    for (byte b2 = 0; b2 < this.xrefs.size(); b2++) {
      String str = "0000000000" + this.xrefs.get(new Integer(b2 + true));
      this.os.println(str.substring(str.length() - 10) + " 00000 n" + XREF_SPACE);
    } 
    this.os.println("trailer");
    this.os.println("<<");
    this.os.println("/Size " + (this.xrefs.size() + 1));
    this.os.println("/Root " + i + " 0 R");
    this.os.println(">>");
    this.os.println("startxref");
    this.os.println(j + "");
    this.os.println("%%EOF");
  }
  
  protected int getNextFontIndex() { return (getRoot()).fontIdx++; }
  
  public int getNextObjectID() { return (getRoot()).objId++; }
  
  private PDFPrinter getRoot() {
    PDFPrinter pDFPrinter = this;
    while (pDFPrinter.cloned != null)
      pDFPrinter = pDFPrinter.cloned; 
    return pDFPrinter;
  }
  
  protected void startPage() {
    if (!this.inited) {
      this.inited = true;
      this.clippingRect = this.default_cliprect;
      this.savelevel = 0;
      this.center.x = this.center.y = 0;
      this.textObj = false;
      this.contentId = getNextObjectID();
      this.lengthId = getNextObjectID();
      this.xrefs.put(new Integer(this.contentId), new Integer(this.os.getOffset()));
      this.os.println(this.contentId + " 0 obj");
      this.os.println("<<");
      this.os.println("/Length " + this.lengthId + " 0 R");
      if (this.compressText)
        if (this.ascii) {
          this.os.println("/Filter [ /ASCII85Decode /FlateDecode ]");
        } else {
          this.os.println("/Filter [ /FlateDecode ]");
        }  
      this.os.println(">>");
      this.os.println("stream");
      this.clr = Color.black;
      this.pg.println("0 g");
      this.pg.println("BX /GS1 gs EX");
      this.pg.println("1 0 0 1 " + (this.pmargin.left * 72.0D) + " " + (this.pageheight - this.pmargin.top * 72.0D) + " cm");
      gsave();
    } 
  }
  
  protected boolean isBase14Font(String paramString) {
    paramString = paramString.toLowerCase();
    for (byte b = 0; b < base14fonts.length; b++) {
      if (paramString.equals(base14fonts[b]) || paramString.startsWith(base14fonts[b] + "-"))
        return true; 
    } 
    return false;
  }
  
  private FitCurves.Point2 getArcPoint(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5) {
    double d1 = paramDouble3 / 2.0D, d2 = paramDouble4 / 2.0D;
    while (paramDouble5 < 0.0D)
      paramDouble5 += 360.0D; 
    while (paramDouble5 > 360.0D)
      paramDouble5 %= 360.0D; 
    double d3 = paramDouble5;
    paramDouble5 = paramDouble5 * Math.PI / 180.0D;
    double d4 = Math.atan(Math.tan(paramDouble5) * d2 / d1);
    paramDouble5 = (d3 > 90.0D && d3 <= 270.0D) ? (d4 + Math.PI) : d4;
    double d5 = Math.tan(paramDouble5);
    boolean bool = (Math.cos(paramDouble5) >= 0.0D) ? 1 : -1;
    double d6 = Math.sqrt(d1 * d1 * d2 * d2 / (d1 * d1 * d5 * d5 + d2 * d2)) * bool;
    double d7 = d5 * d6;
    return new FitCurves.Point2(d6 + paramDouble1 + d1, d7 + paramDouble2 - d2);
  }
  
  private static String toString(double paramDouble) { return Util.toString(paramDouble, 3); }
  
  protected class CountWriter extends PrintWriter implements Serializable {
    OutputStream stream;
    
    int offset;
    
    Hashtable objmarks;
    
    private final PDFPrinter this$0;
    
    public CountWriter(PDFPrinter this$0, OutputStream param1OutputStream) {
      super(param1OutputStream);
      this.this$0 = this$0;
      this.offset = 0;
      this.objmarks = new Hashtable();
      this.stream = param1OutputStream;
    }
    
    public void print(String param1String) {
      super.print(param1String);
      this.offset += param1String.length();
    }
    
    public void println(String param1String) { print(param1String);
      print("\n"); }
    
    public void write(int param1Int) {
      flush();
      try {
        this.stream.write(param1Int);
        this.offset++;
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    }
    
    public void write(byte[] param1ArrayOfByte) throws IOException { write(param1ArrayOfByte, 0, param1ArrayOfByte.length); }
    
    public void write(byte[] param1ArrayOfByte, int param1Int1, int param1Int2) throws IOException {
      flush();
      this.stream.write(param1ArrayOfByte, param1Int1, param1Int2);
      this.offset += param1Int2;
    }
    
    public void reset() {
      this.offset = 0;
      this.objmarks.clear();
    }
    
    public int getOffset() { return this.offset; }
    
    public void markObject(int param1Int) { this.objmarks.put(new Integer(param1Int), new Integer(this.offset)); }
    
    public Hashtable getObjectMarks() { return this.objmarks; }
  }
  
  public static String escapeString(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramString.length(); b++) {
      switch (paramString.charAt(b)) {
        case '\n':
          stringBuffer.append("\\n");
          break;
        case '\r':
          stringBuffer.append("\\r");
          break;
        case '\t':
          stringBuffer.append("\\t");
          break;
        case '\b':
          stringBuffer.append("\\b");
          break;
        case '\f':
          stringBuffer.append("\\f");
          break;
        case '\\':
          stringBuffer.append("\\\\");
          break;
        case '(':
          stringBuffer.append("\\(");
          break;
        case ')':
          stringBuffer.append("\\)");
          break;
        default:
          stringBuffer.append(paramString.charAt(b));
          break;
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static String[] splitWords(String paramString) {
    if (paramString == null || paramString.length() == 0)
      return new String[0]; 
    Vector vector = new Vector();
    int i;
    while ((i = paramString.indexOf(' ')) >= 0) {
      if (i == 0) {
        for (; ++i < paramString.length() && paramString.charAt(i) == ' '; i++);
        i--;
      } 
      vector.addElement(paramString.substring(0, i));
      paramString = paramString.substring(i + 1);
    } 
    vector.addElement(paramString);
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public boolean isSupported(int paramInt) { return false; }
  
  static int NL = 1;
  
  static String XREF_SPACE = " ";
  
  static final String[] base14fonts = { "times", "helvetica", "courier", "symbol", "zapfdingbats" };
  
  protected void debug(PrintWriter paramPrintWriter, String paramString) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\PDFPrinter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */