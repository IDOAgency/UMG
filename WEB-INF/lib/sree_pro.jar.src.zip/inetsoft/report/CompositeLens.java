/*     */ package inetsoft.report;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface CompositeLens
/*     */   extends Cloneable
/*     */ {
/*  31 */   public static final Object PAGE_BREAK = new String("PageBreak");
/*     */ 
/*     */ 
/*     */   
/*  35 */   public static final Object AREA_BREAK = new String("AreaBreak");
/*     */ 
/*     */ 
/*     */   
/*  39 */   public static final Object NEWLINE = new String("Newline");
/*     */ 
/*     */ 
/*     */   
/*  43 */   public static final Object BREAK = new String("Break");
/*     */ 
/*     */   
/*     */   Object nextElement(Context paramContext);
/*     */   
/*     */   void reset();
/*     */   
/*     */   public static class Tab
/*     */   {
/*     */     int fill;
/*     */     
/*  54 */     public Tab(int param1Int) { this.fill = param1Int; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     public int getFillStyle() { return this.fill; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Separator
/*     */   {
/*     */     int style;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     public Separator(int param1Int) { this.style = param1Int; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     public int getStyle() { return this.style; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Space
/*     */   {
/*     */     int pixels;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     public Space(int param1Int) { this.pixels = param1Int; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     public int getSpace() { return this.pixels; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\CompositeLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */