/*     */ package inetsoft.report.web;
/*     */ 
/*     */ import inetsoft.report.ReportEnv;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.XSessionManager;
/*     */ import inetsoft.report.io.Builder;
/*     */ import inetsoft.report.pdf.PDF3Generator;
/*     */ import inetsoft.uql.VariableTable;
/*     */ import inetsoft.uql.XEnv;
/*     */ import inetsoft.uql.XLog;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDFService
/*     */   extends HttpServlet
/*     */ {
/*     */   XSessionManager session;
/*     */   
/*     */   public void init(ServletConfig paramServletConfig) throws ServletException {
/*  39 */     String str = paramServletConfig.getInitParameter("license.key");
/*  40 */     if (str != null) {
/*  41 */       ReportEnv.setProperty("license.key", str);
/*     */     }
/*     */     
/*  44 */     XEnv.init(new Properties());
/*  45 */     Enumeration enumeration = paramServletConfig.getInitParameterNames();
/*  46 */     while (enumeration.hasMoreElements()) {
/*  47 */       String str1 = (String)enumeration.nextElement();
/*  48 */       XEnv.setProperty(str1, paramServletConfig.getInitParameter(str1));
/*     */     } 
/*     */     
/*  51 */     this.tmpdir = paramServletConfig.getInitParameter("tmpDir");
/*  52 */     this.templatedir = paramServletConfig.getInitParameter("templateDir");
/*  53 */     this.refresh = paramServletConfig.getInitParameter("refreshInterval");
/*     */     
/*  55 */     if (this.refresh == null) {
/*  56 */       this.refresh = "2000";
/*     */     }
/*     */     
/*     */     try {
/*  60 */       this.session = XSessionManager.getSessionManager();
/*     */     } catch (Exception exception) {
/*  62 */       XLog.print(exception);
/*  63 */       throw new ServletException(exception.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/*     */     try {
/*  72 */       String str1 = paramHttpServletRequest.getRequestURI();
/*  73 */       PrintWriter printWriter = new PrintWriter(paramHttpServletResponse.getOutputStream());
/*     */       
/*  75 */       String str2 = paramHttpServletRequest.getParameter("reportuid");
/*     */ 
/*     */       
/*  78 */       if (str2 != null) {
/*  79 */         String str = (String)this.statusmap.get(str2);
/*     */         
/*  81 */         if (str == null) {
/*  82 */           paramHttpServletResponse.sendError(400, "Unknown ID: " + str2);
/*     */           
/*     */           return;
/*     */         } 
/*  86 */         if (str.equals("processing")) {
/*  87 */           paramHttpServletResponse.setContentType("text/html");
/*  88 */           paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
/*  89 */           printWriter.println("<HTML><HEAD><script>");
/*  90 */           printWriter.println("function retry() {");
/*  91 */           printWriter.println("window.location = '" + str1 + "?reportuid=" + encode(str2) + "';");
/*     */           
/*  93 */           printWriter.println("}");
/*  94 */           printWriter.println("window.setTimeout('retry()', " + this.refresh + ");");
/*  95 */           printWriter.println("</script></HEAD><BODY bgcolor=white><I>");
/*  96 */           printWriter.println("Generating report ...");
/*  97 */           printWriter.println("</I></BODY></HTML>");
/*  98 */           printWriter.flush();
/*  99 */           printWriter.close();
/*     */         }
/* 101 */         else if (str.equals("finished")) {
/* 102 */           paramHttpServletResponse.setContentType("application/pdf");
/* 103 */           paramHttpServletResponse.setHeader("extension", "pdf");
/* 104 */           paramHttpServletResponse.setHeader("Content-disposition", "attachment; filename=report.pdf");
/*     */           
/* 106 */           String str3 = (String)this.filemap.get(str2);
/*     */           
/* 108 */           if (str3 == null) {
/* 109 */             paramHttpServletResponse.sendError(400, "Internal Error: PDF file missing: " + str3);
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 114 */           File file = new File(str3);
/* 115 */           ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
/*     */           
/* 117 */           if (file.exists()) {
/* 118 */             FileInputStream fileInputStream = new FileInputStream(file);
/* 119 */             byte[] arrayOfByte = new byte[4096];
/*     */             
/*     */             int i;
/* 122 */             while ((i = fileInputStream.read(arrayOfByte)) > 0) {
/* 123 */               servletOutputStream.write(arrayOfByte, 0, i);
/*     */             }
/*     */             
/* 126 */             fileInputStream.close();
/*     */             try {
/* 128 */               file.delete();
/*     */             } catch (Exception exception) {
/* 130 */               XLog.print(exception);
/*     */             } 
/*     */           } else {
/*     */             
/* 134 */             paramHttpServletResponse.sendError(400, "Internal Error: PDF file not found: " + str3);
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 139 */           servletOutputStream.close();
/*     */         }
/* 141 */         else if (str.startsWith("error:")) {
/* 142 */           paramHttpServletResponse.setContentType("text/html");
/* 143 */           paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
/* 144 */           printWriter.println("<HTML>");
/* 145 */           printWriter.println("<BODY><I>Report generation failed: " + str);
/* 146 */           printWriter.println("</BODY></HTML>");
/* 147 */           printWriter.flush();
/* 148 */           printWriter.close();
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 154 */       long l = System.currentTimeMillis();
/* 155 */       str2 = "pdf" + l++;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 176 */       XLog.print(exception);
/* 177 */       paramHttpServletResponse.sendError(400, "Internal Error: " + exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 185 */   public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException { doGet(paramHttpServletRequest, paramHttpServletResponse); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startProcessing(String paramString, HttpServletRequest paramHttpServletRequest) {
/* 190 */     this.statusmap.put(paramString, "processing");
/*     */     
/* 192 */     (new Thread(this, paramString, paramHttpServletRequest) { private final String val$id;
/*     */         
/*     */         public void run() {
/*     */           try {
/* 196 */             String str1 = this.this$0.tmpdir + File.separator + this.val$id + ".pdf";
/*     */             
/* 198 */             InputStream inputStream = null;
/* 199 */             String str2 = this.val$req.getParameter("templateFile");
/* 200 */             if (str2 != null) {
/* 201 */               File file = new File(str2);
/*     */               
/* 203 */               if (!file.isAbsolute() && this.this$0.templatedir != null) {
/* 204 */                 file = new File(this.this$0.templatedir + File.separator + str2);
/*     */               }
/*     */               
/* 207 */               if (file.exists()) {
/* 208 */                 inputStream = new FileInputStream(file);
/*     */               }
/*     */             } else {
/*     */               
/* 212 */               str2 = this.val$req.getParameter("templateResource");
/* 213 */               if (str2 != null) {
/* 214 */                 inputStream = getClass().getResourceAsStream(str2);
/*     */               }
/*     */             } 
/*     */             
/* 218 */             if (inputStream == null) {
/* 219 */               throw new RuntimeException("Template not found: " + str2);
/*     */             }
/*     */             
/* 222 */             Builder builder = Builder.getBuilder(1, inputStream);
/* 223 */             StyleSheet styleSheet = builder.read(".");
/* 224 */             inputStream.close();
/*     */             
/* 226 */             VariableTable variableTable = new VariableTable();
/* 227 */             Enumeration enumeration = this.val$req.getParameterNames();
/* 228 */             while (enumeration.hasMoreElements()) {
/* 229 */               String str = (String)enumeration.nextElement();
/*     */               
/* 231 */               variableTable.put(str, this.val$req.getParameter(str));
/*     */             } 
/*     */             
/* 234 */             this.this$0.session.execute(styleSheet, variableTable);
/*     */             
/* 236 */             FileOutputStream fileOutputStream = new FileOutputStream(str1);
/* 237 */             PDF3Generator pDF3Generator = new PDF3Generator(fileOutputStream);
/* 238 */             pDF3Generator.generate(styleSheet);
/*     */             
/* 240 */             this.this$0.filemap.put(this.val$id, str1);
/* 241 */             this.this$0.statusmap.put(this.val$id, "finished");
/*     */           } catch (Throwable throwable) {
/* 243 */             this.this$0.statusmap.put(this.val$id, "error: " + throwable.toString());
/*     */           } 
/*     */         }
/*     */         private final HttpServletRequest val$req; private final PDFService this$0; }
/*     */       ).start();
/*     */   }
/*     */   static String encode(String paramString) {
/* 250 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 252 */     for (byte b = 0; b < paramString.length(); b++) {
/* 253 */       char c = paramString.charAt(b);
/*     */       
/* 255 */       if (c == ' ') {
/* 256 */         stringBuffer.append("+");
/*     */       }
/* 258 */       else if (!Character.isLetterOrDigit(c)) {
/* 259 */         String str = "00" + Integer.toString(c, 16);
/* 260 */         stringBuffer.append("%" + str.substring(str.length() - 2));
/*     */       } else {
/*     */         
/* 263 */         stringBuffer.append(c);
/*     */       } 
/*     */     } 
/*     */     
/* 267 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 271 */   Hashtable statusmap = new Hashtable();
/* 272 */   Hashtable filemap = new Hashtable();
/* 273 */   String tmpdir = ".";
/* 274 */   String templatedir = ".";
/* 275 */   String refresh = "2000";
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\web\PDFService.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */