package inetsoft.report.web;

import inetsoft.report.ReportEnv;
import inetsoft.report.StyleSheet;
import inetsoft.report.XSessionManager;
import inetsoft.report.io.Builder;
import inetsoft.report.pdf.PDF3Generator;
import inetsoft.uql.VariableTable;
import inetsoft.uql.XEnv;
import inetsoft.uql.XLog;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PDFService extends HttpServlet {
  XSessionManager session;
  
  public void init(ServletConfig paramServletConfig) throws ServletException {
    String str = paramServletConfig.getInitParameter("license.key");
    if (str != null)
      ReportEnv.setProperty("license.key", str); 
    XEnv.init(new Properties());
    Enumeration enumeration = paramServletConfig.getInitParameterNames();
    while (enumeration.hasMoreElements()) {
      String str1 = (String)enumeration.nextElement();
      XEnv.setProperty(str1, paramServletConfig.getInitParameter(str1));
    } 
    this.tmpdir = paramServletConfig.getInitParameter("tmpDir");
    this.templatedir = paramServletConfig.getInitParameter("templateDir");
    this.refresh = paramServletConfig.getInitParameter("refreshInterval");
    if (this.refresh == null)
      this.refresh = "2000"; 
    try {
      this.session = XSessionManager.getSessionManager();
    } catch (Exception exception) {
      XLog.print(exception);
      throw new ServletException(exception.toString());
    } 
  }
  
  public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    try {
      String str1 = paramHttpServletRequest.getRequestURI();
      PrintWriter printWriter = new PrintWriter(paramHttpServletResponse.getOutputStream());
      String str2 = paramHttpServletRequest.getParameter("reportuid");
      if (str2 != null) {
        String str = (String)this.statusmap.get(str2);
        if (str == null) {
          paramHttpServletResponse.sendError(400, "Unknown ID: " + str2);
          return;
        } 
        if (str.equals("processing")) {
          paramHttpServletResponse.setContentType("text/html");
          paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
          printWriter.println("<HTML><HEAD><script>");
          printWriter.println("function retry() {");
          printWriter.println("window.location = '" + str1 + "?reportuid=" + encode(str2) + "';");
          printWriter.println("}");
          printWriter.println("window.setTimeout('retry()', " + this.refresh + ");");
          printWriter.println("</script></HEAD><BODY bgcolor=white><I>");
          printWriter.println("Generating report ...");
          printWriter.println("</I></BODY></HTML>");
          printWriter.flush();
          printWriter.close();
        } else if (str.equals("finished")) {
          paramHttpServletResponse.setContentType("application/pdf");
          paramHttpServletResponse.setHeader("extension", "pdf");
          paramHttpServletResponse.setHeader("Content-disposition", "attachment; filename=report.pdf");
          String str3 = (String)this.filemap.get(str2);
          if (str3 == null) {
            paramHttpServletResponse.sendError(400, "Internal Error: PDF file missing: " + str3);
            return;
          } 
          File file = new File(str3);
          ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
          if (file.exists()) {
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] arrayOfByte = new byte[4096];
            int i;
            while ((i = fileInputStream.read(arrayOfByte)) > 0)
              servletOutputStream.write(arrayOfByte, 0, i); 
            fileInputStream.close();
            try {
              file.delete();
            } catch (Exception exception) {
              XLog.print(exception);
            } 
          } else {
            paramHttpServletResponse.sendError(400, "Internal Error: PDF file not found: " + str3);
            return;
          } 
          servletOutputStream.close();
        } else if (str.startsWith("error:")) {
          paramHttpServletResponse.setContentType("text/html");
          paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
          printWriter.println("<HTML>");
          printWriter.println("<BODY><I>Report generation failed: " + str);
          printWriter.println("</BODY></HTML>");
          printWriter.flush();
          printWriter.close();
        } 
        return;
      } 
      long l = System.currentTimeMillis();
      str2 = "pdf" + l++;
    } catch (Exception exception) {
      XLog.print(exception);
      paramHttpServletResponse.sendError(400, "Internal Error: " + exception);
    } 
  }
  
  public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException { doGet(paramHttpServletRequest, paramHttpServletResponse); }
  
  protected void startProcessing(String paramString, HttpServletRequest paramHttpServletRequest) {
    this.statusmap.put(paramString, "processing");
    (new Thread(this, paramString, paramHttpServletRequest) {
        private final String val$id;
        
        private final HttpServletRequest val$req;
        
        private final PDFService this$0;
        
        public void run() {
          try {
            String str1 = this.this$0.tmpdir + File.separator + this.val$id + ".pdf";
            InputStream inputStream = null;
            String str2 = this.val$req.getParameter("templateFile");
            if (str2 != null) {
              File file = new File(str2);
              if (!file.isAbsolute() && this.this$0.templatedir != null)
                file = new File(this.this$0.templatedir + File.separator + str2); 
              if (file.exists())
                inputStream = new FileInputStream(file); 
            } else {
              str2 = this.val$req.getParameter("templateResource");
              if (str2 != null)
                inputStream = getClass().getResourceAsStream(str2); 
            } 
            if (inputStream == null)
              throw new RuntimeException("Template not found: " + str2); 
            Builder builder = Builder.getBuilder(1, inputStream);
            StyleSheet styleSheet = builder.read(".");
            inputStream.close();
            VariableTable variableTable = new VariableTable();
            Enumeration enumeration = this.val$req.getParameterNames();
            while (enumeration.hasMoreElements()) {
              String str = (String)enumeration.nextElement();
              variableTable.put(str, this.val$req.getParameter(str));
            } 
            this.this$0.session.execute(styleSheet, variableTable);
            FileOutputStream fileOutputStream = new FileOutputStream(str1);
            PDF3Generator pDF3Generator = new PDF3Generator(fileOutputStream);
            pDF3Generator.generate(styleSheet);
            this.this$0.filemap.put(this.val$id, str1);
            this.this$0.statusmap.put(this.val$id, "finished");
          } catch (Throwable throwable) {
            this.this$0.statusmap.put(this.val$id, "error: " + throwable.toString());
          } 
        }
      }).start();
  }
  
  static String encode(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c == ' ') {
        stringBuffer.append("+");
      } else if (!Character.isLetterOrDigit(c)) {
        String str = "00" + Integer.toString(c, 16);
        stringBuffer.append("%" + str.substring(str.length() - 2));
      } else {
        stringBuffer.append(c);
      } 
    } 
    return stringBuffer.toString();
  }
  
  Hashtable statusmap = new Hashtable();
  
  Hashtable filemap = new Hashtable();
  
  String tmpdir = ".";
  
  String templatedir = ".";
  
  String refresh = "2000";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\web\PDFService.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */