package inetsoft.report.web;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PDFServlet extends HttpServlet {
  public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    System.err.println("PDFServlet: GET Received.");
    String str = paramHttpServletRequest.getParameter("report");
    System.err.println("report parameter = " + str);
    if (str == null) {
      Cookie[] arrayOfCookie = paramHttpServletRequest.getCookies();
      if (arrayOfCookie != null)
        for (byte b = 0; b < arrayOfCookie.length; b++) {
          if (arrayOfCookie[b].getName().equals("PDFReport")) {
            str = arrayOfCookie[b].getValue();
            break;
          } 
        }  
    } 
    if (str != null) {
      System.err.println("Retrieving Report: " + str);
      Long long = Long.valueOf(str);
      byte[] arrayOfByte = (byte[])this.cache.get(long);
      paramHttpServletResponse.setContentType("application/pdf");
      paramHttpServletResponse.setHeader("extension", "pdf");
      paramHttpServletResponse.setHeader("Content-disposition", "attachment; filename=report.pdf");
      paramHttpServletResponse.setContentLength(arrayOfByte.length);
      paramHttpServletResponse.getOutputStream().write(arrayOfByte);
      System.err.println("Sent " + arrayOfByte.length + " bytes");
      return;
    } 
    try {
      System.err.println("Report information missing.");
      paramHttpServletResponse.setContentType("text/html");
      PrintWriter printWriter = new PrintWriter(paramHttpServletResponse.getOutputStream());
      printWriter.println("<h2>Error: Cookie missing. Cookie must be enabled in the browser!</h2>");
      printWriter.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    System.err.println("PDFServlet: POST Received.");
    if (this.cache.size() > 0) {
      Enumeration enumeration = this.cache.keys();
      long l = System.currentTimeMillis();
      while (enumeration.hasMoreElements()) {
        Long long = (Long)enumeration.nextElement();
        if (l - long.longValue() > 300000L)
          this.cache.remove(long); 
      } 
    } 
    try {
      ServletInputStream servletInputStream = paramHttpServletRequest.getInputStream();
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      byte[] arrayOfByte = new byte[2048];
      int i;
      while ((i = servletInputStream.read(arrayOfByte, 0, arrayOfByte.length)) >= 0)
        byteArrayOutputStream.write(arrayOfByte, 0, i); 
      long l = System.currentTimeMillis();
      synchronized (this.cache) {
        while (this.cache.get(new Long(l)) != null)
          l++; 
        arrayOfByte = byteArrayOutputStream.toByteArray();
        this.cache.put(new Long(l), arrayOfByte);
      } 
      paramHttpServletResponse.addCookie(new Cookie("PDFReport", Long.toString(l)));
      ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
      OutputStreamWriter outputStreamWriter = new OutputStreamWriter(servletOutputStream);
      outputStreamWriter.write(Long.toString(l) + "\n");
      outputStreamWriter.close();
      System.err.println("Report saved: " + l + " " + arrayOfByte.length);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  Hashtable cache = new Hashtable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\web\PDFServlet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */