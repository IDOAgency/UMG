/*     */ package inetsoft.report.web;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletInputStream;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDFServlet
/*     */   extends HttpServlet
/*     */ {
/*     */   public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/*  37 */     System.err.println("PDFServlet: GET Received.");
/*  38 */     String str = paramHttpServletRequest.getParameter("report");
/*     */     
/*  40 */     System.err.println("report parameter = " + str);
/*     */ 
/*     */     
/*  43 */     if (str == null) {
/*  44 */       Cookie[] arrayOfCookie = paramHttpServletRequest.getCookies();
/*     */       
/*  46 */       if (arrayOfCookie != null) {
/*  47 */         for (byte b = 0; b < arrayOfCookie.length; b++) {
/*     */           
/*  49 */           if (arrayOfCookie[b].getName().equals("PDFReport")) {
/*  50 */             str = arrayOfCookie[b].getValue();
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*  57 */     if (str != null) {
/*  58 */       System.err.println("Retrieving Report: " + str);
/*  59 */       Long long = Long.valueOf(str);
/*  60 */       byte[] arrayOfByte = (byte[])this.cache.get(long);
/*     */ 
/*     */       
/*  63 */       paramHttpServletResponse.setContentType("application/pdf");
/*  64 */       paramHttpServletResponse.setHeader("extension", "pdf");
/*  65 */       paramHttpServletResponse.setHeader("Content-disposition", "attachment; filename=report.pdf");
/*     */       
/*  67 */       paramHttpServletResponse.setContentLength(arrayOfByte.length);
/*  68 */       paramHttpServletResponse.getOutputStream().write(arrayOfByte);
/*     */ 
/*     */       
/*  71 */       System.err.println("Sent " + arrayOfByte.length + " bytes");
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/*  76 */       System.err.println("Report information missing.");
/*  77 */       paramHttpServletResponse.setContentType("text/html");
/*  78 */       PrintWriter printWriter = new PrintWriter(paramHttpServletResponse.getOutputStream());
/*  79 */       printWriter.println("<h2>Error: Cookie missing. Cookie must be enabled in the browser!</h2>");
/*     */       
/*  81 */       printWriter.close();
/*     */     } catch (Exception exception) {
/*  83 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/*  90 */     System.err.println("PDFServlet: POST Received.");
/*     */ 
/*     */     
/*  93 */     if (this.cache.size() > 0) {
/*  94 */       Enumeration enumeration = this.cache.keys();
/*  95 */       long l = System.currentTimeMillis();
/*     */       
/*  97 */       while (enumeration.hasMoreElements()) {
/*  98 */         Long long = (Long)enumeration.nextElement();
/*  99 */         if (l - long.longValue() > 300000L) {
/* 100 */           this.cache.remove(long);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 106 */       ServletInputStream servletInputStream = paramHttpServletRequest.getInputStream();
/* 107 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */       
/* 109 */       byte[] arrayOfByte = new byte[2048];
/*     */       int i;
/* 111 */       while ((i = servletInputStream.read(arrayOfByte, 0, arrayOfByte.length)) >= 0) {
/* 112 */         byteArrayOutputStream.write(arrayOfByte, 0, i);
/*     */       }
/*     */       
/* 115 */       long l = System.currentTimeMillis();
/*     */       
/* 117 */       synchronized (this.cache) {
/*     */         
/* 119 */         while (this.cache.get(new Long(l)) != null) {
/* 120 */           l++;
/*     */         }
/*     */         
/* 123 */         arrayOfByte = byteArrayOutputStream.toByteArray();
/* 124 */         this.cache.put(new Long(l), arrayOfByte);
/*     */       } 
/*     */       
/* 127 */       paramHttpServletResponse.addCookie(new Cookie("PDFReport", Long.toString(l)));
/*     */       
/* 129 */       ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
/* 130 */       OutputStreamWriter outputStreamWriter = new OutputStreamWriter(servletOutputStream);
/* 131 */       outputStreamWriter.write(Long.toString(l) + "\n");
/* 132 */       outputStreamWriter.close();
/*     */       
/* 134 */       System.err.println("Report saved: " + l + " " + arrayOfByte.length);
/*     */ 
/*     */     
/*     */     }
/*     */     catch (Exception exception) {
/*     */ 
/*     */       
/* 141 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/* 145 */   Hashtable cache = new Hashtable();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\web\PDFServlet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */