package inetsoft.report.filter;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public class TableSummaryFilter implements TableFilter, Cloneable {
  TableLens table;
  
  Formula[] calc;
  
  Object[] sum;
  
  String label;
  
  Font sumFont;
  
  public TableSummaryFilter(TableLens paramTableLens, String paramString, Formula[] paramArrayOfFormula) {
    this.table = paramTableLens;
    this.calc = paramArrayOfFormula;
    this.label = paramString;
  }
  
  public TableSummaryFilter(TableLens paramTableLens, String paramString, int paramInt, Formula paramFormula) {
    this.table = paramTableLens;
    this.label = paramString;
    this.calc = new Formula[paramTableLens.getColCount()];
    for (byte b = 0; b < this.calc.length; b++)
      this.calc[b] = (b == paramInt) ? paramFormula : null; 
  }
  
  public TableLens getTable() { return this.table; }
  
  public void setSummaryFont(Font paramFont) { this.sumFont = paramFont; }
  
  public Font getSummaryFont() { return this.sumFont; }
  
  public void refresh() {
    if (this.table instanceof TableFilter)
      ((TableFilter)this.table).refresh(); 
    for (byte b1 = 0; b1 < this.calc.length; b1++) {
      if (this.calc[b1] != null)
        this.calc[b1].reset(); 
    } 
    for (int i = this.table.getHeaderRowCount(); i < this.table.getRowCount(); i++) {
      for (byte b = 0; b < this.calc.length; b++) {
        if (this.calc[b] != null)
          this.calc[b].addValue(this.table.getObject(i, b)); 
      } 
    } 
    this.sum = new Object[this.calc.length];
    this.sum[0] = this.label;
    for (byte b2 = 0; b2 < this.calc.length; b2++) {
      if (this.calc[b2] != null)
        this.sum[b2] = this.calc[b2].getResult(); 
    } 
  }
  
  public int getRowCount() { return this.table.getRowCount() + 1; }
  
  public int getColCount() { return this.table.getColCount(); }
  
  public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
  
  public int getHeaderColCount() { return this.table.getHeaderColCount(); }
  
  public int getRowHeight(int paramInt) { return (paramInt < this.table.getRowCount()) ? this.table.getRowHeight(paramInt) : -1; }
  
  public int getColWidth(int paramInt) { return this.table.getColWidth(paramInt); }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getRowBorderColor(paramInt1, paramInt2) : Color.black; }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getColBorderColor(paramInt1, paramInt2) : Color.black; }
  
  public int getRowBorder(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getRowBorder(paramInt1, paramInt2) : 4097; }
  
  public int getColBorder(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getColBorder(paramInt1, paramInt2) : this.table.getColBorder(paramInt1 - 1, paramInt2); }
  
  public Insets getInsets(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getInsets(paramInt1, paramInt2) : null; }
  
  public Dimension getSpan(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getSpan(paramInt1, paramInt2) : null; }
  
  public int getAlignment(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getAlignment(paramInt1, paramInt2) : this.table.getAlignment(paramInt1 - 1, paramInt2); }
  
  public Font getFont(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getFont(paramInt1, paramInt2) : ((this.sumFont != null) ? this.sumFont : this.table.getFont(paramInt1 - 1, paramInt2)); }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.isLineWrap(paramInt1, paramInt2) : this.table.isLineWrap(paramInt1 - 1, paramInt2); }
  
  public Color getForeground(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getForeground(paramInt1, paramInt2) : this.table.getForeground(paramInt1 - 1, paramInt2); }
  
  public Color getBackground(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getBackground(paramInt1, paramInt2) : this.table.getBackground(paramInt1 - 1, paramInt2); }
  
  public Object getObject(int paramInt1, int paramInt2) {
    if (paramInt1 < this.table.getRowCount())
      return this.table.getObject(paramInt1, paramInt2); 
    if (this.sum == null)
      refresh(); 
    return this.sum[paramInt2];
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\TableSummaryFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */