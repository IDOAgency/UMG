/*     */ package inetsoft.report.filter;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableSummaryFilter
/*     */   implements TableFilter, Cloneable
/*     */ {
/*     */   TableLens table;
/*     */   Formula[] calc;
/*     */   Object[] sum;
/*     */   String label;
/*     */   Font sumFont;
/*     */   
/*     */   public TableSummaryFilter(TableLens paramTableLens, String paramString, Formula[] paramArrayOfFormula) {
/*  38 */     this.table = paramTableLens;
/*  39 */     this.calc = paramArrayOfFormula;
/*  40 */     this.label = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableSummaryFilter(TableLens paramTableLens, String paramString, int paramInt, Formula paramFormula) {
/*  53 */     this.table = paramTableLens;
/*  54 */     this.label = paramString;
/*  55 */     this.calc = new Formula[paramTableLens.getColCount()];
/*     */     
/*  57 */     for (byte b = 0; b < this.calc.length; b++) {
/*  58 */       this.calc[b] = (b == paramInt) ? paramFormula : null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public TableLens getTable() { return this.table; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public void setSummaryFont(Font paramFont) { this.sumFont = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public Font getSummaryFont() { return this.sumFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/*  91 */     if (this.table instanceof TableFilter) {
/*  92 */       ((TableFilter)this.table).refresh();
/*     */     }
/*     */     
/*  95 */     for (byte b1 = 0; b1 < this.calc.length; b1++) {
/*  96 */       if (this.calc[b1] != null) {
/*  97 */         this.calc[b1].reset();
/*     */       }
/*     */     } 
/*     */     
/* 101 */     for (int i = this.table.getHeaderRowCount(); i < this.table.getRowCount(); i++) {
/* 102 */       for (byte b = 0; b < this.calc.length; b++) {
/* 103 */         if (this.calc[b] != null) {
/* 104 */           this.calc[b].addValue(this.table.getObject(i, b));
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     this.sum = new Object[this.calc.length];
/* 110 */     this.sum[0] = this.label;
/* 111 */     for (byte b2 = 0; b2 < this.calc.length; b2++) {
/* 112 */       if (this.calc[b2] != null) {
/* 113 */         this.sum[b2] = this.calc[b2].getResult();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public int getRowCount() { return this.table.getRowCount() + 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public int getColCount() { return this.table.getColCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public int getHeaderColCount() { return this.table.getHeaderColCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public int getRowHeight(int paramInt) { return (paramInt < this.table.getRowCount()) ? this.table.getRowHeight(paramInt) : -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   public int getColWidth(int paramInt) { return this.table.getColWidth(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public Color getRowBorderColor(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getRowBorderColor(paramInt1, paramInt2) : Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public Color getColBorderColor(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getColBorderColor(paramInt1, paramInt2) : Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   public int getRowBorder(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getRowBorder(paramInt1, paramInt2) : 4097; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public int getColBorder(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getColBorder(paramInt1, paramInt2) : this.table.getColBorder(paramInt1 - 1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public Insets getInsets(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getInsets(paramInt1, paramInt2) : null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   public Dimension getSpan(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getSpan(paramInt1, paramInt2) : null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public int getAlignment(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getAlignment(paramInt1, paramInt2) : this.table.getAlignment(paramInt1 - 1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 272 */   public Font getFont(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getFont(paramInt1, paramInt2) : ((this.sumFont != null) ? this.sumFont : this.table.getFont(paramInt1 - 1, paramInt2)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   public boolean isLineWrap(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.isLineWrap(paramInt1, paramInt2) : this.table.isLineWrap(paramInt1 - 1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 298 */   public Color getForeground(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getForeground(paramInt1, paramInt2) : this.table.getForeground(paramInt1 - 1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 310 */   public Color getBackground(int paramInt1, int paramInt2) { return (paramInt1 < this.table.getRowCount()) ? this.table.getBackground(paramInt1, paramInt2) : this.table.getBackground(paramInt1 - 1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/* 321 */     if (paramInt1 < this.table.getRowCount()) {
/* 322 */       return this.table.getObject(paramInt1, paramInt2);
/*     */     }
/*     */     
/* 325 */     if (this.sum == null) {
/* 326 */       refresh();
/*     */     }
/*     */     
/* 329 */     return this.sum[paramInt2];
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\TableSummaryFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */