/*    */ package inetsoft.report.filter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MinFormula
/*    */   implements Formula, Serializable
/*    */ {
/* 27 */   public void reset() { this.min = Double.MAX_VALUE; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addValue(Object paramObject) {
/* 34 */     if (paramObject == null) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 39 */       this.min = Math.min(this.min, (paramObject instanceof Number) ? ((Number)paramObject).doubleValue() : Double.valueOf(paramObject.toString()).doubleValue());
/*    */     }
/*    */     catch (NumberFormatException numberFormatException) {
/*    */       
/* 43 */       System.err.println("Not a number, ignored: " + paramObject);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   public Object getResult() { return new Double((this.min == Double.MAX_VALUE) ? 0.0D : this.min); }
/*    */ 
/*    */ 
/*    */   
/* 55 */   public Object clone() { return super.clone(); }
/*    */ 
/*    */   
/* 58 */   private double min = Double.MAX_VALUE;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\MinFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */