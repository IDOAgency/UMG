/*    */ package inetsoft.report.filter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AverageFormula
/*    */   implements Formula, Serializable
/*    */ {
/*    */   public void reset() {
/* 27 */     this.sum = 0.0D;
/* 28 */     this.cnt = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addValue(Object paramObject) {
/* 35 */     if (paramObject == null) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 40 */       this.sum += ((paramObject instanceof Number) ? ((Number)paramObject).doubleValue() : Double.valueOf(paramObject.toString()).doubleValue());
/*    */     } catch (NumberFormatException numberFormatException) {
/*    */       
/* 43 */       System.err.println("Not a number, ignored: " + paramObject);
/*    */     } 
/*    */     
/* 46 */     this.cnt++;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public Object getResult() { return new Double((this.cnt == 0) ? 0.0D : (this.sum / this.cnt)); }
/*    */ 
/*    */ 
/*    */   
/* 57 */   public Object clone() { return super.clone(); }
/*    */ 
/*    */   
/* 60 */   private double sum = 0.0D;
/* 61 */   private int cnt = 0;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\AverageFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */