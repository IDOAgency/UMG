/*    */ package inetsoft.report.filter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountFormula
/*    */   implements Formula, Serializable
/*    */ {
/* 27 */   public void reset() { this.count = 0; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public void addValue(Object paramObject) { this.count++; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public Object getResult() { return new Integer(this.count); }
/*    */ 
/*    */ 
/*    */   
/* 45 */   public Object clone() { return super.clone(); }
/*    */ 
/*    */   
/* 48 */   private int count = 0;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\CountFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */