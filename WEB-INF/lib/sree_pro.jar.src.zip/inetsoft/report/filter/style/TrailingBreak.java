/*     */ package inetsoft.report.filter.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.filter.GroupedTable;
/*     */ import inetsoft.report.style.TableStyle;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrailingBreak
/*     */   extends GroupStyle
/*     */ {
/*     */   public TrailingBreak() {}
/*     */   
/*  41 */   public TrailingBreak(GroupedTable paramGroupedTable) { super(paramGroupedTable); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final TrailingBreak this$0;
/*     */     
/*  55 */     Style(TrailingBreak this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  63 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 == -1 || param1Int1 == lastRow()) ? 4098 : ((this.this$0.gtable.isSummaryRow(param1Int1) && this.this$0.gtable.getObject(param1Int1, true) == null && this.this$0.gtable.isSummaryCol(param1Int2)) ? 4097 : (((param1Int1 == 0 && this.this$0.isFormatFirstRow()) || (this.this$0.gtable.isGroupHeaderRow(param1Int1) && this.this$0.gtable.getObject(param1Int1, false) != null) || (this.this$0.gtable.isGroupHeaderRow(param1Int1 + 1) && this.this$0.gtable.getObject(param1Int1 + true, param1Int2) != null) || this.this$0.gtable.isSummaryRow(param1Int1 + 1)) ? 4145 : 0)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     public int getColBorder(int param1Int1, int param1Int2) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 127 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/*     */       
/* 129 */       if ((param1Int1 == 0 && this.this$0.isFormatFirstRow()) || this.this$0.gtable.isSummaryRow(param1Int1)) {
/* 130 */         return this.this$0.createFont(font, 1);
/*     */       }
/*     */       
/* 133 */       return font;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\style\TrailingBreak.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */