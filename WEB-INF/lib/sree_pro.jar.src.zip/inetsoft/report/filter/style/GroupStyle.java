/*     */ package inetsoft.report.filter.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.filter.GroupedTable;
/*     */ import inetsoft.report.style.TableStyle;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.text.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupStyle
/*     */   extends TableStyle
/*     */ {
/*     */   Color headerFG;
/*     */   Color headerBG;
/*     */   Font headerFont;
/*     */   Insets headerInsets;
/*     */   Integer headerAlign;
/*     */   Color sumFG;
/*     */   Color sumBG;
/*     */   Font sumFont;
/*     */   Insets sumInsets;
/*     */   Integer sumAlign;
/*     */   Format sumFormat;
/*     */   Color grandFG;
/*     */   Color grandBG;
/*     */   Font grandFont;
/*     */   Insets grandInsets;
/*     */   Integer grandAlign;
/*     */   protected GroupedTable gtable;
/*     */   
/*     */   public GroupStyle() {}
/*     */   
/*     */   public GroupStyle(GroupedTable paramGroupedTable) {
/*  46 */     super(paramGroupedTable);
/*  47 */     this.gtable = paramGroupedTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTable(TableLens paramTableLens) {
/*  55 */     if (!(paramTableLens instanceof GroupedTable) || !(paramTableLens instanceof inetsoft.report.TableFilter))
/*     */     {
/*  57 */       throw new IllegalArgumentException("Only GroupedTable filter can be  added to a group style");
/*     */     }
/*     */ 
/*     */     
/*  61 */     super.setTable(paramTableLens);
/*  62 */     this.gtable = (GroupedTable)paramTableLens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public Color getHeaderForeground() { return this.headerFG; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public void setHeaderForeground(Color paramColor) { this.headerFG = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public Color getHeaderBackground() { return this.headerBG; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public void setHeaderBackground(Color paramColor) { this.headerBG = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public Font getHeaderFont() { return this.headerFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void setHeaderFont(Font paramFont) { this.headerFont = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public Insets getHeaderInsets() { return this.headerInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void setHeaderInsets(Insets paramInsets) { this.headerInsets = paramInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public Integer getHeaderAlignment() { return this.headerAlign; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public void setHeaderAlignment(Integer paramInteger) { this.headerAlign = paramInteger; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public Color getSummaryForeground() { return this.sumFG; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public void setSummaryForeground(Color paramColor) { this.sumFG = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public Color getSummaryBackground() { return this.sumBG; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public void setSummaryBackground(Color paramColor) { this.sumBG = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public Font getSummaryFont() { return this.sumFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   public void setSummaryFont(Font paramFont) { this.sumFont = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public Insets getSummaryInsets() { return this.sumInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public void setSummaryInsets(Insets paramInsets) { this.sumInsets = paramInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public Integer getSummaryAlignment() { return this.sumAlign; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   public void setSummaryAlignment(Integer paramInteger) { this.sumAlign = paramInteger; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   public Format getSummaryFormat() { return this.sumFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   public void setSummaryFormat(Format paramFormat) { this.sumFormat = paramFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public Color getGrandForeground() { return this.grandFG; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public void setGrandForeground(Color paramColor) { this.grandFG = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public Color getGrandBackground() { return this.grandBG; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 268 */   public void setGrandBackground(Color paramColor) { this.grandBG = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   public Font getGrandFont() { return this.grandFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 284 */   public void setGrandFont(Font paramFont) { this.grandFont = paramFont; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   public Insets getGrandInsets() { return this.grandInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public void setGrandInsets(Insets paramInsets) { this.grandInsets = paramInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 308 */   public Integer getGrandAlignment() { return this.grandAlign; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 316 */   public void setGrandAlignment(Integer paramInteger) { this.grandAlign = paramInteger; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Insets getInsets(int paramInt1, int paramInt2) {
/* 326 */     if (this.grandInsets != null && paramInt1 == this.gtable.getRowCount() - 1) {
/* 327 */       return this.grandInsets;
/*     */     }
/* 329 */     if (this.sumInsets != null && this.gtable.isSummaryRow(paramInt1)) {
/* 330 */       return this.sumInsets;
/*     */     }
/* 332 */     if (this.headerInsets != null && this.gtable.isGroupHeaderRow(paramInt1)) {
/* 333 */       return this.headerInsets;
/*     */     }
/*     */     
/* 336 */     return super.getInsets(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAlignment(int paramInt1, int paramInt2) {
/* 346 */     if (this.grandAlign != null && paramInt1 == this.gtable.getRowCount() - 1) {
/* 347 */       return this.grandAlign.intValue();
/*     */     }
/* 349 */     if (this.sumAlign != null && this.gtable.isSummaryRow(paramInt1)) {
/* 350 */       return this.sumAlign.intValue();
/*     */     }
/* 352 */     if (this.headerAlign != null && this.gtable.isGroupHeaderRow(paramInt1)) {
/* 353 */       return this.headerAlign.intValue();
/*     */     }
/*     */     
/* 356 */     return super.getAlignment(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getFont(int paramInt1, int paramInt2) {
/* 366 */     if (this.grandFont != null && paramInt1 == this.gtable.getRowCount() - 1) {
/* 367 */       return this.grandFont;
/*     */     }
/* 369 */     if (this.sumFont != null && this.gtable.isSummaryRow(paramInt1)) {
/* 370 */       return this.sumFont;
/*     */     }
/* 372 */     if (this.headerFont != null && this.gtable.isGroupHeaderCell(paramInt1, paramInt2)) {
/* 373 */       return this.headerFont;
/*     */     }
/*     */     
/* 376 */     return super.getFont(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getForeground(int paramInt1, int paramInt2) {
/* 387 */     if (this.grandFG != null && paramInt1 == this.gtable.getRowCount() - 1) {
/* 388 */       return this.grandFG;
/*     */     }
/* 390 */     if (this.sumFG != null && this.gtable.isSummaryRow(paramInt1)) {
/* 391 */       return this.sumFG;
/*     */     }
/* 393 */     if (this.headerFG != null && this.gtable.isGroupHeaderRow(paramInt1)) {
/* 394 */       return this.headerFG;
/*     */     }
/*     */     
/* 397 */     return super.getForeground(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getBackground(int paramInt1, int paramInt2) {
/* 408 */     if (this.grandBG != null && paramInt1 == this.gtable.getRowCount() - 1) {
/* 409 */       return this.grandBG;
/*     */     }
/* 411 */     if (this.sumBG != null && this.gtable.isSummaryRow(paramInt1)) {
/* 412 */       return this.sumBG;
/*     */     }
/* 414 */     if (this.headerBG != null && this.gtable.isGroupHeaderRow(paramInt1)) {
/* 415 */       return this.headerBG;
/*     */     }
/*     */     
/* 418 */     return super.getBackground(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/* 422 */     Object object = super.getObject(paramInt1, paramInt2);
/*     */     
/*     */     try {
/* 425 */       if (this.sumFormat != null && object != null && this.gtable.isSummaryRow(paramInt1)) {
/* 426 */         return this.sumFormat.format(object);
/*     */       }
/* 428 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */     
/* 431 */     return object;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\style\GroupStyle.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */