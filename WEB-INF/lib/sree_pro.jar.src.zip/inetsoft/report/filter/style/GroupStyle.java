package inetsoft.report.filter.style;

import inetsoft.report.TableLens;
import inetsoft.report.filter.GroupedTable;
import inetsoft.report.style.TableStyle;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.text.Format;

public class GroupStyle extends TableStyle {
  Color headerFG;
  
  Color headerBG;
  
  Font headerFont;
  
  Insets headerInsets;
  
  Integer headerAlign;
  
  Color sumFG;
  
  Color sumBG;
  
  Font sumFont;
  
  Insets sumInsets;
  
  Integer sumAlign;
  
  Format sumFormat;
  
  Color grandFG;
  
  Color grandBG;
  
  Font grandFont;
  
  Insets grandInsets;
  
  Integer grandAlign;
  
  protected GroupedTable gtable;
  
  public GroupStyle() {}
  
  public GroupStyle(GroupedTable paramGroupedTable) {
    super(paramGroupedTable);
    this.gtable = paramGroupedTable;
  }
  
  public void setTable(TableLens paramTableLens) {
    if (!(paramTableLens instanceof GroupedTable) || !(paramTableLens instanceof inetsoft.report.TableFilter))
      throw new IllegalArgumentException("Only GroupedTable filter can be  added to a group style"); 
    super.setTable(paramTableLens);
    this.gtable = (GroupedTable)paramTableLens;
  }
  
  public Color getHeaderForeground() { return this.headerFG; }
  
  public void setHeaderForeground(Color paramColor) { this.headerFG = paramColor; }
  
  public Color getHeaderBackground() { return this.headerBG; }
  
  public void setHeaderBackground(Color paramColor) { this.headerBG = paramColor; }
  
  public Font getHeaderFont() { return this.headerFont; }
  
  public void setHeaderFont(Font paramFont) { this.headerFont = paramFont; }
  
  public Insets getHeaderInsets() { return this.headerInsets; }
  
  public void setHeaderInsets(Insets paramInsets) { this.headerInsets = paramInsets; }
  
  public Integer getHeaderAlignment() { return this.headerAlign; }
  
  public void setHeaderAlignment(Integer paramInteger) { this.headerAlign = paramInteger; }
  
  public Color getSummaryForeground() { return this.sumFG; }
  
  public void setSummaryForeground(Color paramColor) { this.sumFG = paramColor; }
  
  public Color getSummaryBackground() { return this.sumBG; }
  
  public void setSummaryBackground(Color paramColor) { this.sumBG = paramColor; }
  
  public Font getSummaryFont() { return this.sumFont; }
  
  public void setSummaryFont(Font paramFont) { this.sumFont = paramFont; }
  
  public Insets getSummaryInsets() { return this.sumInsets; }
  
  public void setSummaryInsets(Insets paramInsets) { this.sumInsets = paramInsets; }
  
  public Integer getSummaryAlignment() { return this.sumAlign; }
  
  public void setSummaryAlignment(Integer paramInteger) { this.sumAlign = paramInteger; }
  
  public Format getSummaryFormat() { return this.sumFormat; }
  
  public void setSummaryFormat(Format paramFormat) { this.sumFormat = paramFormat; }
  
  public Color getGrandForeground() { return this.grandFG; }
  
  public void setGrandForeground(Color paramColor) { this.grandFG = paramColor; }
  
  public Color getGrandBackground() { return this.grandBG; }
  
  public void setGrandBackground(Color paramColor) { this.grandBG = paramColor; }
  
  public Font getGrandFont() { return this.grandFont; }
  
  public void setGrandFont(Font paramFont) { this.grandFont = paramFont; }
  
  public Insets getGrandInsets() { return this.grandInsets; }
  
  public void setGrandInsets(Insets paramInsets) { this.grandInsets = paramInsets; }
  
  public Integer getGrandAlignment() { return this.grandAlign; }
  
  public void setGrandAlignment(Integer paramInteger) { this.grandAlign = paramInteger; }
  
  public Insets getInsets(int paramInt1, int paramInt2) {
    if (this.grandInsets != null && paramInt1 == this.gtable.getRowCount() - 1)
      return this.grandInsets; 
    if (this.sumInsets != null && this.gtable.isSummaryRow(paramInt1))
      return this.sumInsets; 
    if (this.headerInsets != null && this.gtable.isGroupHeaderRow(paramInt1))
      return this.headerInsets; 
    return super.getInsets(paramInt1, paramInt2);
  }
  
  public int getAlignment(int paramInt1, int paramInt2) {
    if (this.grandAlign != null && paramInt1 == this.gtable.getRowCount() - 1)
      return this.grandAlign.intValue(); 
    if (this.sumAlign != null && this.gtable.isSummaryRow(paramInt1))
      return this.sumAlign.intValue(); 
    if (this.headerAlign != null && this.gtable.isGroupHeaderRow(paramInt1))
      return this.headerAlign.intValue(); 
    return super.getAlignment(paramInt1, paramInt2);
  }
  
  public Font getFont(int paramInt1, int paramInt2) {
    if (this.grandFont != null && paramInt1 == this.gtable.getRowCount() - 1)
      return this.grandFont; 
    if (this.sumFont != null && this.gtable.isSummaryRow(paramInt1))
      return this.sumFont; 
    if (this.headerFont != null && this.gtable.isGroupHeaderCell(paramInt1, paramInt2))
      return this.headerFont; 
    return super.getFont(paramInt1, paramInt2);
  }
  
  public Color getForeground(int paramInt1, int paramInt2) {
    if (this.grandFG != null && paramInt1 == this.gtable.getRowCount() - 1)
      return this.grandFG; 
    if (this.sumFG != null && this.gtable.isSummaryRow(paramInt1))
      return this.sumFG; 
    if (this.headerFG != null && this.gtable.isGroupHeaderRow(paramInt1))
      return this.headerFG; 
    return super.getForeground(paramInt1, paramInt2);
  }
  
  public Color getBackground(int paramInt1, int paramInt2) {
    if (this.grandBG != null && paramInt1 == this.gtable.getRowCount() - 1)
      return this.grandBG; 
    if (this.sumBG != null && this.gtable.isSummaryRow(paramInt1))
      return this.sumBG; 
    if (this.headerBG != null && this.gtable.isGroupHeaderRow(paramInt1))
      return this.headerBG; 
    return super.getBackground(paramInt1, paramInt2);
  }
  
  public Object getObject(int paramInt1, int paramInt2) {
    Object object = super.getObject(paramInt1, paramInt2);
    try {
      if (this.sumFormat != null && object != null && this.gtable.isSummaryRow(paramInt1))
        return this.sumFormat.format(object); 
    } catch (IllegalArgumentException illegalArgumentException) {}
    return object;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\style\GroupStyle.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */