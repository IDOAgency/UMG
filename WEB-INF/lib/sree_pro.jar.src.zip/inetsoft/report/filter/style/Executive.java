/*     */ package inetsoft.report.filter.style;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.filter.GroupedTable;
/*     */ import inetsoft.report.painter.PresenterPainter;
/*     */ import inetsoft.report.painter.ShadowPresenter;
/*     */ import inetsoft.report.style.TableStyle;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Executive
/*     */   extends GroupStyle
/*     */ {
/*     */   public Executive() {}
/*     */   
/*  43 */   public Executive(GroupedTable paramGroupedTable) { super(paramGroupedTable); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public void setShading(Color paramColor) { this.shading = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public Color getShading() { return this.shading; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public void setTextColor(Color paramColor) { this.textC = paramColor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public Color getTextColor() { return this.textC; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   protected TableLens createStyle(TableLens paramTableLens) { return new Style(this); }
/*     */   
/*     */   class Style
/*     */     extends TableStyle.Transparent {
/*     */     private final Executive this$0;
/*     */     
/*  90 */     Style(Executive this$0) { super(this$0); this.this$0 = this$0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     public Color getRowBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     public Color getColBorderColor(int param1Int1, int param1Int2) { return Color.black; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     public int getRowBorder(int param1Int1, int param1Int2) { return (param1Int1 == -1 || param1Int1 == lastRow()) ? 4098 : ((param1Int1 == 0 && this.this$0.isFormatFirstRow()) ? 4145 : 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     public int getColBorder(int param1Int1, int param1Int2) { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     public int getAlignment(int param1Int1, int param1Int2) { return 17; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Font getFont(int param1Int1, int param1Int2) {
/* 156 */       Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/*     */       
/* 158 */       if (param1Int1 == 0 && this.this$0.isFormatFirstRow()) {
/* 159 */         return this.this$0.createFont(font, 1);
/*     */       }
/*     */       
/* 162 */       return font;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getObject(int param1Int1, int param1Int2) {
/* 172 */       Object object = this.this$0.table.getObject(param1Int1, param1Int2);
/* 173 */       if (object != null && (this.this$0.gtable.isSummaryRow(param1Int1) || this.this$0.gtable.isGroupHeaderRow(param1Int1))) {
/*     */         
/* 175 */         ShadowPresenter shadowPresenter = new ShadowPresenter();
/* 176 */         Font font = this.this$0.table.getFont(param1Int1, param1Int2);
/* 177 */         shadowPresenter.setFont(this.this$0.createFont(font, 1));
/* 178 */         shadowPresenter.setShading(this.this$0.shading);
/* 179 */         shadowPresenter.setTextColor(this.this$0.textC);
/* 180 */         return new PresenterPainter(object, shadowPresenter);
/*     */       } 
/*     */       
/* 183 */       return object;
/*     */     }
/*     */   }
/*     */   
/* 187 */   Color shading = Color.white;
/* 188 */   Color textC = Color.black;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\style\Executive.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */