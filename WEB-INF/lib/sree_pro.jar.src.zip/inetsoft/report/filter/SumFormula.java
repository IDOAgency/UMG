package inetsoft.report.filter;

import java.io.Serializable;

public class SumFormula implements Formula, Serializable {
  public void reset() { this.sum = 0.0D; }
  
  public void addValue(Object paramObject) {
    if (paramObject == null)
      return; 
    try {
      this.sum += ((paramObject instanceof Number) ? ((Number)paramObject).doubleValue() : Double.valueOf(paramObject.toString()).doubleValue());
    } catch (NumberFormatException numberFormatException) {
      System.err.println("Not a number, ignored: " + paramObject);
    } 
  }
  
  public Object getResult() { return new Double(this.sum); }
  
  public Object clone() { return super.clone(); }
  
  private double sum = 0.0D;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\SumFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */