/*    */ package inetsoft.report.filter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SumFormula
/*    */   implements Formula, Serializable
/*    */ {
/* 27 */   public void reset() { this.sum = 0.0D; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addValue(Object paramObject) {
/* 34 */     if (paramObject == null) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 39 */       this.sum += ((paramObject instanceof Number) ? ((Number)paramObject).doubleValue() : Double.valueOf(paramObject.toString()).doubleValue());
/*    */     } catch (NumberFormatException numberFormatException) {
/*    */       
/* 42 */       System.err.println("Not a number, ignored: " + paramObject);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public Object getResult() { return new Double(this.sum); }
/*    */ 
/*    */ 
/*    */   
/* 54 */   public Object clone() { return super.clone(); }
/*    */ 
/*    */   
/* 57 */   private double sum = 0.0D;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\SumFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */