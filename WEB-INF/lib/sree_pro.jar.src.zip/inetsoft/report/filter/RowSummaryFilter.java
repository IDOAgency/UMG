package inetsoft.report.filter;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.util.Vector;

public class RowSummaryFilter implements TableFilter, Cloneable {
  TableLens table;
  
  Vector sumcol;
  
  String header;
  
  Formula sum;
  
  int[] cols;
  
  public RowSummaryFilter(TableLens paramTableLens, String paramString, Formula paramFormula, int[] paramArrayOfInt) {
    this.table = paramTableLens;
    this.header = paramString;
    this.sum = paramFormula;
    this.cols = paramArrayOfInt;
  }
  
  public TableLens getTable() { return this.table; }
  
  public void refresh() {
    if (this.table instanceof TableFilter)
      ((TableFilter)this.table).refresh(); 
    this.sumcol = new Vector();
    if (this.table.getHeaderRowCount() > 0) {
      this.sumcol.addElement(this.header);
      this.sumcol.setSize(this.table.getHeaderRowCount());
    } 
    for (int i = this.table.getHeaderRowCount(); i < this.table.getRowCount(); i++) {
      this.sum.reset();
      for (byte b = 0; b < this.cols.length; b++)
        this.sum.addValue(this.table.getObject(i, this.cols[b])); 
      this.sumcol.addElement(this.sum.getResult());
    } 
  }
  
  public int getRowCount() { return this.table.getRowCount(); }
  
  public int getColCount() { return this.table.getColCount() + 1; }
  
  public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
  
  public int getHeaderColCount() { return this.table.getHeaderColCount(); }
  
  public int getRowHeight(int paramInt) { return this.table.getRowHeight(paramInt); }
  
  public int getColWidth(int paramInt) { return this.table.getColWidth(Math.min(paramInt, this.table.getColCount() - 1)); }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) { return this.table.getRowBorderColor(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) { return this.table.getColBorderColor(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public int getRowBorder(int paramInt1, int paramInt2) { return this.table.getRowBorder(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public int getColBorder(int paramInt1, int paramInt2) { return this.table.getColBorder(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public Insets getInsets(int paramInt1, int paramInt2) { return this.table.getInsets(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public Dimension getSpan(int paramInt1, int paramInt2) { return this.table.getSpan(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public int getAlignment(int paramInt1, int paramInt2) { return this.table.getAlignment(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public Font getFont(int paramInt1, int paramInt2) { return this.table.getFont(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) { return this.table.isLineWrap(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public Color getForeground(int paramInt1, int paramInt2) { return this.table.getForeground(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public Color getBackground(int paramInt1, int paramInt2) { return this.table.getBackground(paramInt1, Math.min(this.table.getColCount() - 1, paramInt2)); }
  
  public Object getObject(int paramInt1, int paramInt2) {
    if (paramInt2 < this.table.getColCount())
      return this.table.getObject(paramInt1, paramInt2); 
    if (this.sumcol == null)
      refresh(); 
    return this.sumcol.elementAt(paramInt1);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\RowSummaryFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */