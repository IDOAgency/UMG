package inetsoft.report.filter;

import inetsoft.report.Comparer;
import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.internal.Util;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.io.Serializable;
import java.util.Vector;

public class TopNFilter implements TableFilter, GroupedTable, Cloneable {
  public static final int ALL = -1;
  
  GroupedTable table;
  
  int[] rowmap;
  
  int[] sums;
  
  int N;
  
  boolean asc;
  
  Comparer[] comparers;
  
  boolean sum1;
  
  boolean lasteq;
  
  public TopNFilter(GroupedTable paramGroupedTable, int paramInt1, int paramInt2) { this(paramGroupedTable, paramInt1, new int[] { paramInt2 }, true); }
  
  public TopNFilter(GroupedTable paramGroupedTable, int paramInt, int[] paramArrayOfInt, boolean paramBoolean) {
    this.asc = false;
    this.sum1 = false;
    this.lasteq = false;
    this.table = paramGroupedTable;
    this.N = paramInt;
    this.asc = !paramBoolean;
    this.sums = paramArrayOfInt;
    this.comparers = new Comparer[paramGroupedTable.getColCount()];
    DefaultComparer defaultComparer = new DefaultComparer();
    for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++)
      this.comparers[paramArrayOfInt[b1]] = defaultComparer; 
    for (byte b2 = 0; b2 < this.sums.length; b2++) {
      if (this.sums[b2] == 1) {
        this.sum1 = true;
        break;
      } 
    } 
  }
  
  public int getGroupColCount() { return this.table.getGroupColCount(); }
  
  public int getGroupLevel(int paramInt) { return this.table.getGroupLevel(this.rowmap[paramInt]); }
  
  public TableLens getTable() { return this.table; }
  
  public void setComparer(int paramInt, Comparer paramComparer) {
    if (paramComparer == null)
      paramComparer = new DefaultComparer(); 
    this.comparers[paramInt] = paramComparer;
  }
  
  public Comparer getComparer(int paramInt) { return this.comparers[paramInt]; }
  
  public void setAscending(boolean paramBoolean) { this.asc = paramBoolean; }
  
  public boolean isAscending() { return this.asc; }
  
  public void refresh() {
    if (this.table instanceof TableFilter)
      ((TableFilter)this.table).refresh(); 
    Vector vector = new Vector();
    int i = this.table.hasGrandSummary() ? (this.table.getRowCount() - 1) : this.table.getRowCount();
    for (int j = this.table.getHeaderRowCount(); j < i; j++) {
      Section section = new Section();
      section.srow = j;
      while (j < this.table.getRowCount() && (!this.table.isSummaryRow(j) || this.table.getObject(j, false) == null || (!this.sum1 && this.table.getObject(j, true) != null)))
        j++; 
      section.erow = j;
      if (section.erow < this.table.getRowCount()) {
        section.values = new Object[this.sums.length];
        for (byte b = 0; b < this.sums.length; b++)
          section.values[b] = this.table.getObject(j, this.sums[b]); 
        vector.addElement(section);
      } 
    } 
    Section[] arrayOfSection = new Section[vector.size()];
    vector.copyInto(arrayOfSection);
    Util.qsort(arrayOfSection, 0, arrayOfSection.length - 1, this.asc, new SComparer(this));
    int k = this.table.getHeaderRowCount();
    int m = (this.N > 0) ? Math.min(this.N, arrayOfSection.length) : arrayOfSection.length;
    if (isKeepLastEq()) {
      SComparer sComparer = new SComparer(this);
      while (m < arrayOfSection.length && sComparer.compare(arrayOfSection[m - 1], arrayOfSection[m]) == 0)
        m++; 
    } 
    for (byte b1 = 0; b1 < m; b1++)
      k += (arrayOfSection[b1]).erow - (arrayOfSection[b1]).srow + 1; 
    this.rowmap = new int[k];
    byte b2 = 0;
    for (byte b3 = 0; b3 < this.table.getHeaderRowCount(); b3++)
      this.rowmap[b2++] = b3; 
    for (byte b4 = 0; b4 < m; b4++) {
      for (int n = (arrayOfSection[b4]).srow; n <= (arrayOfSection[b4]).erow; n++)
        this.rowmap[b2++] = n; 
    } 
  }
  
  public void setKeepLastEq(boolean paramBoolean) { this.lasteq = paramBoolean; }
  
  public boolean isKeepLastEq() { return this.lasteq; }
  
  public boolean isGroupHeaderRow(int paramInt) {
    checkInit();
    return this.table.isGroupHeaderRow(this.rowmap[paramInt]);
  }
  
  public boolean isGroupHeaderCell(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.isGroupHeaderCell(this.rowmap[paramInt1], paramInt2);
  }
  
  public boolean isSummaryRow(int paramInt) {
    checkInit();
    return this.table.isSummaryRow(this.rowmap[paramInt]);
  }
  
  public boolean isSummaryCol(int paramInt) { return this.table.isSummaryCol(paramInt); }
  
  public boolean hasGrandSummary() { return false; }
  
  public int getRowCount() {
    checkInit();
    return this.rowmap.length;
  }
  
  public int getColCount() { return this.table.getColCount(); }
  
  public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
  
  public int getHeaderColCount() { return this.table.getHeaderColCount(); }
  
  public int getRowHeight(int paramInt) {
    checkInit();
    return this.table.getRowHeight(this.rowmap[paramInt]);
  }
  
  public int getColWidth(int paramInt) { return this.table.getColWidth(paramInt); }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getRowBorderColor((paramInt1 >= 0) ? this.rowmap[paramInt1] : paramInt1, paramInt2);
  }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getColBorderColor((paramInt1 >= 0) ? this.rowmap[paramInt1] : paramInt1, paramInt2);
  }
  
  public int getRowBorder(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getRowBorder((paramInt1 >= 0) ? this.rowmap[paramInt1] : paramInt1, paramInt2);
  }
  
  public int getColBorder(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getColBorder((paramInt1 >= 0) ? this.rowmap[paramInt1] : paramInt1, paramInt2);
  }
  
  public Insets getInsets(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getInsets(this.rowmap[paramInt1], paramInt2);
  }
  
  public Dimension getSpan(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getSpan(this.rowmap[paramInt1], paramInt2);
  }
  
  public int getAlignment(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getAlignment(this.rowmap[paramInt1], paramInt2);
  }
  
  public Font getFont(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getFont(this.rowmap[paramInt1], paramInt2);
  }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.isLineWrap(this.rowmap[paramInt1], paramInt2);
  }
  
  public Color getForeground(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getForeground(this.rowmap[paramInt1], paramInt2);
  }
  
  public Color getBackground(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getBackground(this.rowmap[paramInt1], paramInt2);
  }
  
  public Object getObject(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getObject(this.rowmap[paramInt1], paramInt2);
  }
  
  private void checkInit() {
    if (this.rowmap == null)
      refresh(); 
  }
  
  static class Section implements Serializable {
    int srow;
    
    int erow;
    
    Object[] values;
    
    public String toString() { return "section: " + this.srow + " to " + this.erow; }
  }
  
  class SComparer implements Comparer {
    private final TopNFilter this$0;
    
    SComparer(TopNFilter this$0) { this.this$0 = this$0; }
    
    public int compare(Object param1Object1, Object param1Object2) {
      TopNFilter.Section section1 = (TopNFilter.Section)param1Object1, section2 = (TopNFilter.Section)param1Object2;
      for (byte b = 0; b < section1.values.length; b++) {
        int i = this.this$0.comparers[this.this$0.sums[b]].compare(section1.values[b], section2.values[b]);
        if (i != 0)
          return i; 
      } 
      return 0;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\TopNFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */