package inetsoft.report.filter;

import inetsoft.report.Comparer;
import java.text.Collator;

public class TextComparer implements Comparer {
  private Collator collator;
  
  public TextComparer(Collator paramCollator) { this.collator = paramCollator; }
  
  public int compare(Object paramObject1, Object paramObject2) { return this.collator.compare(paramObject1.toString(), paramObject2.toString()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\TextComparer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */