/*     */ package inetsoft.report.filter;
/*     */ 
/*     */ import inetsoft.report.Comparer;
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.internal.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.io.Serializable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrossTabFilter
/*     */   implements TableFilter, Cloneable
/*     */ {
/*     */   TableLens table;
/*     */   Object[][] data;
/*     */   Formula sum;
/*     */   int[] rowh;
/*     */   int colh;
/*     */   int dcol;
/*     */   boolean keepheader;
/*     */   Font bold;
/*     */   Comparer chsort;
/*     */   
/*  64 */   public CrossTabFilter(TableLens paramTableLens, int paramInt1, int paramInt2, int paramInt3, Formula paramFormula) { this(paramTableLens, new int[] { paramInt1 }, paramInt2, paramInt3, paramFormula); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CrossTabFilter(TableLens paramTableLens, int[] paramArrayOfInt, int paramInt1, int paramInt2, Formula paramFormula) {
/* 532 */     this.keepheader = false;
/* 533 */     this.bold = new Font("Serif", 1, 10);
/* 534 */     this.chsort = null;
/*     */     this.sum = paramFormula;
/*     */     this.table = paramTableLens;
/*     */     this.rowh = paramArrayOfInt;
/*     */     this.colh = paramInt1;
/*     */     this.dcol = paramInt2;
/*     */   }
/*     */   
/*     */   public TableLens getTable() { return this.table; }
/*     */   
/*     */   public void setColHeaderSorting(Comparer paramComparer) { this.chsort = paramComparer; }
/*     */   
/*     */   public Comparer getColHeaderSorting() { return this.chsort; }
/*     */   
/*     */   public void setKeepColumnHeaders(boolean paramBoolean) { this.keepheader = paramBoolean; }
/*     */   
/*     */   public boolean isKeepColumnHeaders() { return this.keepheader; }
/*     */   
/*     */   public void refresh() {
/*     */     if (this.table instanceof TableFilter)
/*     */       ((TableFilter)this.table).refresh(); 
/*     */     Hashtable hashtable1 = new Hashtable();
/*     */     Hashtable hashtable2 = new Hashtable();
/*     */     Hashtable hashtable3 = new Hashtable();
/*     */     for (int i = this.table.getHeaderRowCount(); i < this.table.getRowCount(); i++) {
/*     */       Pair pair = new Pair(new Tuple(this, this.table, i), this.table.getObject(i, this.colh));
/*     */       if (pair.val1 != null && pair.val2 != null) {
/*     */         hashtable2.put(pair.val1, pair.val1);
/*     */         hashtable3.put(pair.val2, pair.val2);
/*     */         Object object = this.table.getObject(i, this.dcol);
/*     */         if (this.sum == null) {
/*     */           hashtable1.put(pair, object);
/*     */         } else {
/*     */           Object object1 = hashtable1.get(pair);
/*     */           if (object1 == null) {
/*     */             try {
/*     */               Formula formula = (Formula)this.sum.clone();
/*     */               formula.reset();
/*     */               formula.addValue(object);
/*     */               hashtable1.put(pair, formula);
/*     */             } catch (Exception exception) {
/*     */               exception.printStackTrace();
/*     */             } 
/*     */           } else {
/*     */             ((Formula)object1).addValue(object);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     this.data = new Object[hashtable2.size() + 1][hashtable3.size() + this.rowh.length];
/*     */     Enumeration enumeration1 = hashtable2.keys();
/*     */     Enumeration enumeration2 = hashtable3.keys();
/*     */     for (byte b1 = 1; b1 < this.data.length; b1++)
/*     */       ((Tuple)enumeration1.nextElement()).copyInto(this.data[b1]); 
/*     */     for (int j = this.rowh.length; j < this.data[0].length; j++)
/*     */       this.data[0][j] = enumeration2.nextElement(); 
/*     */     if (this.keepheader)
/*     */       for (byte b = 0; b < this.rowh.length; b++)
/*     */         this.data[0][b] = this.table.getObject(0, b);  
/*     */     if (this.chsort != null)
/*     */       Util.qsort(this.data[0], getHeaderColCount(), this.data[0].length - 1, true, this.chsort); 
/*     */     for (byte b2 = 1; b2 < this.data.length; b2++) {
/*     */       for (int k = this.rowh.length; k < this.data[b2].length; k++) {
/*     */         this.data[b2][k] = hashtable1.get(new Pair(new Tuple(this, b2), this.data[0][k]));
/*     */         if (this.sum != null && this.data[b2][k] != null)
/*     */           this.data[b2][k] = ((Formula)this.data[b2][k]).getResult(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getRowCount() {
/*     */     checkInit();
/*     */     return this.data.length;
/*     */   }
/*     */   
/*     */   public int getColCount() {
/*     */     checkInit();
/*     */     return this.data[0].length;
/*     */   }
/*     */   
/*     */   public int getHeaderRowCount() { return 1; }
/*     */   
/*     */   public int getHeaderColCount() {
/*     */     checkInit();
/*     */     return this.rowh.length;
/*     */   }
/*     */   
/*     */   public int getRowHeight(int paramInt) { return -1; }
/*     */   
/*     */   public int getColWidth(int paramInt) { return -1; }
/*     */   
/*     */   public Color getRowBorderColor(int paramInt1, int paramInt2) { return Color.black; }
/*     */   
/*     */   public Color getColBorderColor(int paramInt1, int paramInt2) { return Color.black; }
/*     */   
/*     */   public int getRowBorder(int paramInt1, int paramInt2) { return 4097; }
/*     */   
/*     */   public int getColBorder(int paramInt1, int paramInt2) { return 4097; }
/*     */   
/*     */   public Insets getInsets(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public Dimension getSpan(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public int getAlignment(int paramInt1, int paramInt2) { return 1; }
/*     */   
/*     */   public Font getFont(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return (paramInt1 == 0 || paramInt2 < this.rowh.length) ? this.bold : null;
/*     */   }
/*     */   
/*     */   public boolean isLineWrap(int paramInt1, int paramInt2) { return true; }
/*     */   
/*     */   public Color getForeground(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public Color getBackground(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return this.data[paramInt1][paramInt2];
/*     */   }
/*     */   
/*     */   private void checkInit() {
/*     */     if (this.data == null)
/*     */       refresh(); 
/*     */   }
/*     */   
/*     */   static class Pair implements Serializable {
/*     */     public Object val1;
/*     */     public Object val2;
/*     */     
/*     */     public Pair(Object param1Object1, Object param1Object2) {
/*     */       this.val1 = param1Object1;
/*     */       this.val2 = param1Object2;
/*     */     }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*     */       if (param1Object instanceof Pair)
/*     */         return (this.val1.equals(((Pair)param1Object).val1) && this.val2.equals(((Pair)param1Object).val2)); 
/*     */       return false;
/*     */     }
/*     */     
/*     */     public int hashCode() { return this.val1.hashCode() + this.val2.hashCode(); }
/*     */     
/*     */     public String toString() { return "[Pair: " + this.val1 + ", " + this.val2 + "]"; }
/*     */   }
/*     */   
/*     */   class Tuple implements Serializable {
/*     */     TableLens table;
/*     */     Object[] row;
/*     */     private final CrossTabFilter this$0;
/*     */     
/*     */     public Tuple(CrossTabFilter this$0, TableLens param1TableLens, int param1Int) {
/*     */       this.this$0 = this$0;
/*     */       this.table = param1TableLens;
/*     */       this.row = new Object[this$0.rowh.length];
/*     */       for (byte b = 0; b < this.row.length; b++)
/*     */         this.row[b] = param1TableLens.getObject(param1Int, this$0.rowh[b]); 
/*     */     }
/*     */     
/*     */     public Tuple(CrossTabFilter this$0, int param1Int) {
/*     */       this.this$0 = this$0;
/*     */       this.table = this.table;
/*     */       this.row = new Object[this$0.rowh.length];
/*     */       for (byte b = 0; b < this.row.length; b++)
/*     */         this.row[b] = this$0.getObject(param1Int, b); 
/*     */     }
/*     */     
/*     */     public void copyInto(Object[] param1ArrayOfObject) {
/*     */       for (byte b = 0; b < this.row.length; b++)
/*     */         param1ArrayOfObject[b] = this.row[b]; 
/*     */     }
/*     */     
/*     */     public boolean equals(Object param1Object) {
/*     */       if (!(param1Object instanceof Tuple))
/*     */         return false; 
/*     */       Tuple tuple = (Tuple)param1Object;
/*     */       for (byte b = 0; b < this.row.length; b++) {
/*     */         if (this.row[b] != null) {
/*     */           if (!this.row[b].equals(tuple.row[b]))
/*     */             return false; 
/*     */         } else if (tuple.row[b] != null) {
/*     */           return false;
/*     */         } 
/*     */       } 
/*     */       return true;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       int i = 0;
/*     */       for (byte b = 0; b < this.row.length; b++) {
/*     */         if (this.row[b] != null)
/*     */           i += this.row[b].hashCode(); 
/*     */       } 
/*     */       return i;
/*     */     }
/*     */     
/*     */     public String toString() {
/*     */       String str = "[Tuple: ";
/*     */       for (byte b = 0; b < this.row.length; b++)
/*     */         str = str + " ;" + this.row[b]; 
/*     */       return str + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\CrossTabFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */