package inetsoft.report.filter;

import inetsoft.report.Common;
import inetsoft.report.Comparer;

public class DefaultComparer implements Comparer {
  public int compare(Object paramObject1, Object paramObject2) { return this.sign * Common.compare(paramObject1, paramObject2); }
  
  public void setNegate(boolean paramBoolean) { this.sign = paramBoolean ? -1 : 1; }
  
  public boolean isNegate() { return (this.sign < 0); }
  
  private int sign = 1;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\DefaultComparer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */