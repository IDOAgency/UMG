package inetsoft.report.filter;

import inetsoft.report.Comparer;
import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public class SortFilter implements TableFilter, SortedTable, Cloneable {
  Object[][] cache;
  
  TableLens table;
  
  int[] rowmap;
  
  int[] cols;
  
  boolean[] asc;
  
  Comparer[] comparers;
  
  public SortFilter(TableLens paramTableLens, int[] paramArrayOfInt) { this(paramTableLens, paramArrayOfInt, true); }
  
  public SortFilter(TableLens paramTableLens, int[] paramArrayOfInt, boolean paramBoolean) { this(paramTableLens, paramArrayOfInt, new boolean[] { paramBoolean }); }
  
  public SortFilter(TableLens paramTableLens, int[] paramArrayOfInt, boolean[] paramArrayOfBoolean) {
    this.asc = new boolean[] { true };
    this.table = paramTableLens;
    this.cols = paramArrayOfInt;
    this.asc = paramArrayOfBoolean;
    this.comparers = new Comparer[paramTableLens.getColCount()];
    DefaultComparer defaultComparer = new DefaultComparer();
    for (byte b = 0; b < paramArrayOfInt.length; b++)
      this.comparers[paramArrayOfInt[b]] = defaultComparer; 
  }
  
  public TableLens getTable() { return this.table; }
  
  public void setComparer(int paramInt, Comparer paramComparer) {
    if (paramComparer == null)
      paramComparer = new DefaultComparer(); 
    this.comparers[paramInt] = paramComparer;
  }
  
  public Comparer getComparer(int paramInt) { return this.comparers[paramInt]; }
  
  public void refresh() {
    if (this.table instanceof TableFilter)
      ((TableFilter)this.table).refresh(); 
    sort(this.asc);
  }
  
  public int[] getSortCols() { return this.cols; }
  
  private void sort(boolean[] paramArrayOfBoolean) {
    this.rowmap = new int[this.table.getRowCount()];
    for (byte b1 = 0; b1 < this.rowmap.length; b1++)
      this.rowmap[b1] = b1; 
    this.cache = new Object[this.table.getRowCount()][this.cols.length];
    for (byte b2 = 0; b2 < this.cache.length; b2++) {
      for (byte b = 0; b < this.cache[b2].length; b++)
        this.cache[b2][b] = this.table.getObject(b2, this.cols[b]); 
    } 
    qsort(paramArrayOfBoolean, this.table.getHeaderRowCount(), this.rowmap.length - 1);
    this.cache = null;
  }
  
  private int compare(int paramInt1, int paramInt2, boolean[] paramArrayOfBoolean) {
    for (int i = 0; i < this.cols.length; i++) {
      int j = this.comparers[this.cols[i]].compare(this.cache[this.rowmap[paramInt1]][i], this.cache[this.rowmap[paramInt2]][i]);
      if (j != 0) {
        int k = paramArrayOfBoolean[i % paramArrayOfBoolean.length] ? 1 : -1;
        return j * k;
      } 
    } 
    return 0;
  }
  
  private void qsort(boolean[] paramArrayOfBoolean, int paramInt1, int paramInt2) {
    if (paramInt1 >= paramInt2)
      return; 
    int i = paramInt1;
    int j = paramInt2;
    int k = (i + j) / 2;
    int m = this.rowmap[k];
    this.rowmap[k] = this.rowmap[paramInt1];
    this.rowmap[paramInt1] = m;
    while (i < j) {
      int n;
      while (i < paramInt2 && ((n = compare(i, paramInt1, paramArrayOfBoolean)) < 0 || n == 0))
        i++; 
      while (compare(j, paramInt1, paramArrayOfBoolean) > 0)
        j--; 
      if (i < j) {
        m = this.rowmap[i];
        this.rowmap[i] = this.rowmap[j];
        this.rowmap[j] = m;
      } 
    } 
    m = this.rowmap[paramInt1];
    this.rowmap[paramInt1] = this.rowmap[j];
    this.rowmap[j] = m;
    qsort(paramArrayOfBoolean, paramInt1, j - 1);
    qsort(paramArrayOfBoolean, j + 1, paramInt2);
  }
  
  public int getRowCount() { return this.table.getRowCount(); }
  
  public int getColCount() { return this.table.getColCount(); }
  
  public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
  
  public int getHeaderColCount() { return this.table.getHeaderColCount(); }
  
  public int getRowHeight(int paramInt) {
    checkInit();
    return this.table.getRowHeight(this.rowmap[paramInt]);
  }
  
  public int getColWidth(int paramInt) { return this.table.getColWidth(paramInt); }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getRowBorderColor((paramInt1 < 0) ? paramInt1 : this.rowmap[paramInt1], paramInt2);
  }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getColBorderColor((paramInt1 < 0) ? paramInt1 : this.rowmap[paramInt1], paramInt2);
  }
  
  public int getRowBorder(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getRowBorder((paramInt1 < 0) ? paramInt1 : this.rowmap[paramInt1], paramInt2);
  }
  
  public int getColBorder(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getColBorder((paramInt1 < 0) ? paramInt1 : this.rowmap[paramInt1], paramInt2);
  }
  
  public Insets getInsets(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getInsets(this.rowmap[paramInt1], paramInt2);
  }
  
  public Dimension getSpan(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getSpan(this.rowmap[paramInt1], paramInt2);
  }
  
  public int getAlignment(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getAlignment(this.rowmap[paramInt1], paramInt2);
  }
  
  public Font getFont(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getFont(this.rowmap[paramInt1], paramInt2);
  }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.isLineWrap(this.rowmap[paramInt1], paramInt2);
  }
  
  public Color getForeground(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getForeground(this.rowmap[paramInt1], paramInt2);
  }
  
  public Color getBackground(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getBackground(this.rowmap[paramInt1], paramInt2);
  }
  
  public Object getObject(int paramInt1, int paramInt2) {
    checkInit();
    return this.table.getObject(this.rowmap[paramInt1], paramInt2);
  }
  
  private void checkInit() {
    if (this.rowmap == null)
      refresh(); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\SortFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */