package inetsoft.report.filter;

import inetsoft.report.Comparer;

public class NumericComparer implements Comparer {
  public int compare(Object paramObject1, Object paramObject2) { return (int)Math.ceil(Double.valueOf(paramObject1.toString()).doubleValue() - Double.valueOf(paramObject2.toString()).doubleValue()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\NumericComparer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */