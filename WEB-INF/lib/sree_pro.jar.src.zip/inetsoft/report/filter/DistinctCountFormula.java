/*    */ package inetsoft.report.filter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DistinctCountFormula
/*    */   implements Formula, Serializable
/*    */ {
/* 29 */   public void reset() { this.set.clear(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addValue(Object paramObject) {
/* 36 */     if (paramObject != null) {
/* 37 */       this.set.put(paramObject, paramObject);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public Object getResult() { return new Integer(this.set.size()); }
/*    */ 
/*    */ 
/*    */   
/* 49 */   public Object clone() { return new DistinctCountFormula(); }
/*    */ 
/*    */   
/* 52 */   private Hashtable set = new Hashtable();
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\DistinctCountFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */