package inetsoft.report.filter;

import java.io.Serializable;
import java.util.Hashtable;

public class DistinctCountFormula implements Formula, Serializable {
  public void reset() { this.set.clear(); }
  
  public void addValue(Object paramObject) {
    if (paramObject != null)
      this.set.put(paramObject, paramObject); 
  }
  
  public Object getResult() { return new Integer(this.set.size()); }
  
  public Object clone() { return new DistinctCountFormula(); }
  
  private Hashtable set = new Hashtable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\DistinctCountFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */