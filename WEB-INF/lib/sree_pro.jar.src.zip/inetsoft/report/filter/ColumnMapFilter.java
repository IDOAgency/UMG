/*     */ package inetsoft.report.filter;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColumnMapFilter
/*     */   implements TableFilter, SortedTable, Cloneable
/*     */ {
/*     */   TableLens table;
/*     */   int[] map;
/*     */   
/*     */   public ColumnMapFilter(TableLens paramTableLens, int[] paramArrayOfInt) {
/*  33 */     this.table = paramTableLens;
/*  34 */     this.map = paramArrayOfInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   public TableLens getTable() { return this.table; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh() {
/*  49 */     if (this.table instanceof TableFilter) {
/*  50 */       ((TableFilter)this.table).refresh();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getSortCols() {
/*  59 */     if (this.table instanceof SortedTable) {
/*  60 */       int[] arrayOfInt = ((SortedTable)this.table).getSortCols();
/*  61 */       for (byte b = 0; b < arrayOfInt.length; b++) {
/*  62 */         for (byte b1 = 0; b1 < this.map.length; b1++) {
/*  63 */           if (this.map[b1] == arrayOfInt[b]) {
/*  64 */             arrayOfInt[b] = b1;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*  70 */       return arrayOfInt;
/*     */     } 
/*     */     
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public int getRowCount() { return this.table.getRowCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public int getColCount() { return this.map.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public int getHeaderColCount() { return this.table.getHeaderColCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public int getRowHeight(int paramInt) { return this.table.getRowHeight(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public int getColWidth(int paramInt) { return this.table.getColWidth(this.map[paramInt]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public Color getRowBorderColor(int paramInt1, int paramInt2) { return this.table.getRowBorderColor(paramInt1, (paramInt2 < 0) ? paramInt2 : this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public Color getColBorderColor(int paramInt1, int paramInt2) { return this.table.getColBorderColor(paramInt1, (paramInt2 < 0) ? paramInt2 : this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public int getRowBorder(int paramInt1, int paramInt2) { return this.table.getRowBorder(paramInt1, (paramInt2 < 0) ? paramInt2 : this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   public int getColBorder(int paramInt1, int paramInt2) { return this.table.getColBorder(paramInt1, (paramInt2 < 0) ? paramInt2 : this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public Insets getInsets(int paramInt1, int paramInt2) { return this.table.getInsets(paramInt1, this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public Dimension getSpan(int paramInt1, int paramInt2) { return this.table.getSpan(paramInt1, this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   public int getAlignment(int paramInt1, int paramInt2) { return this.table.getAlignment(paramInt1, this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public Font getFont(int paramInt1, int paramInt2) { return this.table.getFont(paramInt1, this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public boolean isLineWrap(int paramInt1, int paramInt2) { return this.table.isLineWrap(paramInt1, this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public Color getForeground(int paramInt1, int paramInt2) { return this.table.getForeground(paramInt1, this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 259 */   public Color getBackground(int paramInt1, int paramInt2) { return this.table.getBackground(paramInt1, this.map[paramInt2]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public Object getObject(int paramInt1, int paramInt2) { return this.table.getObject(paramInt1, this.map[paramInt2]); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\ColumnMapFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */