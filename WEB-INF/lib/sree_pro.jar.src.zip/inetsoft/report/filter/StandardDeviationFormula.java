package inetsoft.report.filter;

import java.io.Serializable;
import java.util.Vector;

public class StandardDeviationFormula implements Formula, Serializable {
  public void reset() { this.vector.removeAllElements(); }
  
  public void addValue(Object paramObject) {
    if (paramObject == null)
      return; 
    try {
      this.vector.addElement((paramObject instanceof Number) ? (Number)paramObject : Double.valueOf(paramObject.toString()));
    } catch (NumberFormatException numberFormatException) {
      System.err.println("Not a number, ignored: " + paramObject);
    } 
  }
  
  public Object getResult() {
    double d1 = 0.0D;
    double[] arrayOfDouble = new double[this.vector.size()];
    for (byte b1 = 0; b1 < this.vector.size(); b1++) {
      arrayOfDouble[b1] = ((Number)this.vector.elementAt(b1)).doubleValue();
      d1 += arrayOfDouble[b1];
    } 
    double d2 = d1 / arrayOfDouble.length;
    d1 = 0.0D;
    for (byte b2 = 0; b2 < arrayOfDouble.length; b2++) {
      double d = arrayOfDouble[b2] - d2;
      d1 += d * d;
    } 
    return new Double(Math.sqrt(d1 / (arrayOfDouble.length - 1)));
  }
  
  public Object clone() { return new StandardDeviationFormula(); }
  
  private Vector vector = new Vector();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\StandardDeviationFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */