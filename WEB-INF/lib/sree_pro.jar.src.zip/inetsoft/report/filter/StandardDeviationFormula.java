/*    */ package inetsoft.report.filter;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StandardDeviationFormula
/*    */   implements Formula, Serializable
/*    */ {
/* 29 */   public void reset() { this.vector.removeAllElements(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addValue(Object paramObject) {
/* 36 */     if (paramObject == null) {
/*    */       return;
/*    */     }
/*    */     
/*    */     try {
/* 41 */       this.vector.addElement((paramObject instanceof Number) ? (Number)paramObject : Double.valueOf(paramObject.toString()));
/*    */     } catch (NumberFormatException numberFormatException) {
/*    */       
/* 44 */       System.err.println("Not a number, ignored: " + paramObject);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getResult() {
/* 52 */     double d1 = 0.0D;
/* 53 */     double[] arrayOfDouble = new double[this.vector.size()];
/*    */     
/* 55 */     for (byte b1 = 0; b1 < this.vector.size(); b1++) {
/* 56 */       arrayOfDouble[b1] = ((Number)this.vector.elementAt(b1)).doubleValue();
/* 57 */       d1 += arrayOfDouble[b1];
/*    */     } 
/*    */     
/* 60 */     double d2 = d1 / arrayOfDouble.length;
/* 61 */     d1 = 0.0D;
/* 62 */     for (byte b2 = 0; b2 < arrayOfDouble.length; b2++) {
/* 63 */       double d = arrayOfDouble[b2] - d2;
/* 64 */       d1 += d * d;
/*    */     } 
/*    */     
/* 67 */     return new Double(Math.sqrt(d1 / (arrayOfDouble.length - 1)));
/*    */   }
/*    */ 
/*    */   
/* 71 */   public Object clone() { return new StandardDeviationFormula(); }
/*    */ 
/*    */   
/* 74 */   private Vector vector = new Vector();
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\StandardDeviationFormula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */