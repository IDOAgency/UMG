/*     */ package inetsoft.report.filter;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SummaryFilter
/*     */   implements TableFilter, Cloneable
/*     */ {
/*     */   SortedTable table;
/*     */   Vector sumrows;
/*     */   int[] cols;
/*     */   int[] sums;
/*     */   String[] headers;
/*     */   Formula[] calcs;
/*     */   Formula[] grand;
/*     */   Font bold;
/*     */   
/*  38 */   public SummaryFilter(SortedTable paramSortedTable, int paramInt, Formula paramFormula1, Formula paramFormula2) { this(paramSortedTable, new int[1], new Formula[1], (paramFormula2 != null) ? new Formula[1] : null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SummaryFilter(SortedTable paramSortedTable, int[] paramArrayOfInt, Formula paramFormula1, Formula paramFormula2) {
/* 440 */     this.sumrows = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 445 */     this.bold = new Font("Serif", 1, 10); this.table = paramSortedTable; this.sums = paramArrayOfInt; this.cols = paramSortedTable.getSortCols(); this.calcs = new Formula[paramArrayOfInt.length]; for (byte b = 0; b < this.calcs.length; b++) { try { this.calcs[b] = (Formula)paramFormula1.clone(); } catch (Exception exception) { exception.printStackTrace(); }  }  if (paramFormula2 != null) { this.grand = new Formula[paramArrayOfInt.length]; for (byte b1 = 0; b1 < paramArrayOfInt.length; b1++) { try { this.grand[b1] = (Formula)paramFormula2.clone(); } catch (Exception exception) { exception.printStackTrace(); }  }  }  } public SummaryFilter(SortedTable paramSortedTable, int[] paramArrayOfInt, Formula[] paramArrayOfFormula1, Formula[] paramArrayOfFormula2) { this.sumrows = null; this.bold = new Font("Serif", 1, 10);
/*     */     this.sums = paramArrayOfInt;
/*     */     this.calcs = paramArrayOfFormula1;
/*     */     this.grand = paramArrayOfFormula2;
/*     */     this.table = paramSortedTable;
/*     */     this.cols = paramSortedTable.getSortCols(); }
/*     */ 
/*     */   
/*     */   public SummaryFilter(SortedTable paramSortedTable, int[] paramArrayOfInt, Formula[] paramArrayOfFormula1, Formula[] paramArrayOfFormula2, String[] paramArrayOfString) {
/*     */     this(paramSortedTable, paramArrayOfInt, paramArrayOfFormula1, paramArrayOfFormula2);
/*     */     this.headers = paramArrayOfString;
/*     */   }
/*     */   
/*     */   public TableLens getTable() { return this.table; }
/*     */   
/*     */   public void refresh() {
/*     */     if (this.table instanceof TableFilter)
/*     */       ((TableFilter)this.table).refresh(); 
/*     */     this.sumrows = new Vector();
/*     */     Object[] arrayOfObject = new Object[this.table.getColCount()];
/*     */     boolean bool = true;
/*     */     for (byte b1 = 0; b1 < this.calcs.length; b1++) {
/*     */       this.calcs[b1].reset();
/*     */       if (this.grand != null)
/*     */         this.grand[b1].reset(); 
/*     */     } 
/*     */     for (byte b2 = 0; b2 < this.table.getRowCount(); b2++) {
/*     */       if (b2 < this.table.getHeaderRowCount()) {
/*     */         Vector vector1 = new Vector(this.sums.length + this.cols.length);
/*     */         for (byte b5 = 0; b5 < this.cols.length; b5++)
/*     */           vector1.addElement(this.table.getObject(b2, this.cols[b5])); 
/*     */         for (byte b6 = 0; b6 < this.sums.length; b6++)
/*     */           vector1.addElement((this.headers != null && b6 < this.headers.length) ? this.headers[b6] : this.table.getObject(b2, this.sums[b6])); 
/*     */         this.sumrows.addElement(vector1);
/*     */       } else {
/*     */         boolean bool1 = true;
/*     */         for (byte b5 = 0; b5 < this.cols.length; b5++) {
/*     */           Object object1 = arrayOfObject[this.cols[b5]];
/*     */           Object object2 = this.table.getObject(b2, this.cols[b5]);
/*     */           if (object1 == null || object2 == null || !object1.equals(object2)) {
/*     */             bool1 = false;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         if (!bool1) {
/*     */           if (bool) {
/*     */             bool = false;
/*     */           } else {
/*     */             Vector vector1 = new Vector(this.cols.length + this.sums.length);
/*     */             for (byte b9 = 0; b9 < this.cols.length; b9++)
/*     */               vector1.addElement(this.table.getObject(b2 - 1, this.cols[b9])); 
/*     */             for (byte b10 = 0; b10 < this.sums.length; b10++) {
/*     */               Object object = this.calcs[b10].getResult();
/*     */               vector1.addElement(object);
/*     */               if (this.grand != null)
/*     */                 this.grand[b10].addValue(object); 
/*     */             } 
/*     */             this.sumrows.addElement(vector1);
/*     */           } 
/*     */           for (byte b7 = 0; b7 < this.cols.length; b7++)
/*     */             arrayOfObject[this.cols[b7]] = this.table.getObject(b2, this.cols[b7]); 
/*     */           for (byte b8 = 0; b8 < this.calcs.length; b8++)
/*     */             this.calcs[b8].reset(); 
/*     */         } 
/*     */         for (byte b6 = 0; b6 < this.calcs.length; b6++)
/*     */           this.calcs[b6].addValue(this.table.getObject(b2, this.sums[b6])); 
/*     */       } 
/*     */     } 
/*     */     Vector vector = new Vector(this.cols.length + this.sums.length);
/*     */     for (byte b3 = 0; b3 < this.cols.length; b3++)
/*     */       vector.addElement(this.table.getObject(this.table.getRowCount() - 1, this.cols[b3])); 
/*     */     for (byte b4 = 0; b4 < this.sums.length; b4++) {
/*     */       Object object = this.calcs[b4].getResult();
/*     */       vector.addElement(object);
/*     */       if (this.grand != null)
/*     */         this.grand[b4].addValue(object); 
/*     */     } 
/*     */     this.sumrows.addElement(vector);
/*     */     if (this.grand != null) {
/*     */       vector = new Vector();
/*     */       vector.setSize(this.cols.length);
/*     */       for (byte b = 0; b < this.sums.length; b++)
/*     */         vector.addElement(this.grand[b].getResult()); 
/*     */       this.sumrows.addElement(vector);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getRowCount() {
/*     */     checkInit();
/*     */     return this.sumrows.size();
/*     */   }
/*     */   
/*     */   public int getColCount() {
/*     */     checkInit();
/*     */     return this.cols.length + this.sums.length;
/*     */   }
/*     */   
/*     */   public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
/*     */   
/*     */   public int getHeaderColCount() { return this.cols.length; }
/*     */   
/*     */   public int getRowHeight(int paramInt) { return -1; }
/*     */   
/*     */   public int getColWidth(int paramInt) { return -1; }
/*     */   
/*     */   public Color getRowBorderColor(int paramInt1, int paramInt2) { return Color.black; }
/*     */   
/*     */   public Color getColBorderColor(int paramInt1, int paramInt2) { return Color.black; }
/*     */   
/*     */   public int getRowBorder(int paramInt1, int paramInt2) { return 0; }
/*     */   
/*     */   public int getColBorder(int paramInt1, int paramInt2) { return 0; }
/*     */   
/*     */   public Insets getInsets(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public Dimension getSpan(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public int getAlignment(int paramInt1, int paramInt2) { return 1; }
/*     */   
/*     */   public Font getFont(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return (paramInt1 < getHeaderRowCount() || (paramInt1 == this.sumrows.size() - 1 && this.grand != null)) ? this.bold : null;
/*     */   }
/*     */   
/*     */   public boolean isLineWrap(int paramInt1, int paramInt2) { return true; }
/*     */   
/*     */   public Color getForeground(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public Color getBackground(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return ((Vector)this.sumrows.elementAt(paramInt1)).elementAt(paramInt2);
/*     */   }
/*     */   
/*     */   private void checkInit() {
/*     */     if (this.sumrows == null)
/*     */       refresh(); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\SummaryFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */