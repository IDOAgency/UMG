package inetsoft.report.filter;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public class DefaultSortedTable implements SortedTable, TableFilter {
  private TableLens table;
  
  private int[] cols;
  
  public DefaultSortedTable(TableLens paramTableLens, int[] paramArrayOfInt) {
    this.table = paramTableLens;
    this.cols = paramArrayOfInt;
  }
  
  public TableLens getTable() { return this.table; }
  
  public void refresh() {
    if (this.table instanceof TableFilter)
      ((TableFilter)this.table).refresh(); 
  }
  
  public int[] getSortCols() { return this.cols; }
  
  public int getRowCount() { return this.table.getRowCount(); }
  
  public int getColCount() { return this.table.getColCount(); }
  
  public int getRowHeight(int paramInt) { return this.table.getRowHeight(paramInt); }
  
  public int getColWidth(int paramInt) { return this.table.getColWidth(paramInt); }
  
  public Object getObject(int paramInt1, int paramInt2) { return this.table.getObject(paramInt1, paramInt2); }
  
  public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
  
  public int getHeaderColCount() { return this.table.getHeaderColCount(); }
  
  public Color getRowBorderColor(int paramInt1, int paramInt2) { return this.table.getRowBorderColor(paramInt1, paramInt2); }
  
  public Color getColBorderColor(int paramInt1, int paramInt2) { return this.table.getColBorderColor(paramInt1, paramInt2); }
  
  public int getRowBorder(int paramInt1, int paramInt2) { return this.table.getRowBorder(paramInt1, paramInt2); }
  
  public int getColBorder(int paramInt1, int paramInt2) { return this.table.getColBorder(paramInt1, paramInt2); }
  
  public Insets getInsets(int paramInt1, int paramInt2) { return this.table.getInsets(paramInt1, paramInt2); }
  
  public Dimension getSpan(int paramInt1, int paramInt2) { return this.table.getSpan(paramInt1, paramInt2); }
  
  public int getAlignment(int paramInt1, int paramInt2) { return this.table.getAlignment(paramInt1, paramInt2); }
  
  public Font getFont(int paramInt1, int paramInt2) { return this.table.getFont(paramInt1, paramInt2); }
  
  public boolean isLineWrap(int paramInt1, int paramInt2) { return this.table.isLineWrap(paramInt1, paramInt2); }
  
  public Color getForeground(int paramInt1, int paramInt2) { return this.table.getForeground(paramInt1, paramInt2); }
  
  public Color getBackground(int paramInt1, int paramInt2) { return this.table.getBackground(paramInt1, paramInt2); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\DefaultSortedTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */