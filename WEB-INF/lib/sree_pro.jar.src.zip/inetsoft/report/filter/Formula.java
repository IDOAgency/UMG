package inetsoft.report.filter;

import java.io.Serializable;

public interface Formula extends Cloneable, Serializable {
  void reset();
  
  void addValue(Object paramObject);
  
  Object getResult();
  
  Object clone();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\Formula.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */