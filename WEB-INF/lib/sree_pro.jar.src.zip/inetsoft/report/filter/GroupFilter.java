/*     */ package inetsoft.report.filter;
/*     */ 
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GroupFilter
/*     */   implements TableFilter, GroupedTable, Cloneable
/*     */ {
/*     */   public static final int GROUP_HEADER_ROWS = 1;
/*     */   public static final int GROUP_HEADER_IN_PLACE = 2;
/*     */   public static final int GROUP_HEADER_FULL = 4098;
/*     */   SortedTable table;
/*     */   int[] rowmap;
/*     */   Hashtable headermap;
/*     */   Vector sumrows;
/*     */   Vector groupboundries;
/*     */   int[] cols;
/*     */   int[] sums;
/*     */   Formula[][] calcs;
/*     */   Formula[] grand;
/*     */   boolean headerrow;
/*     */   boolean grpcols;
/*     */   boolean groupPerPage;
/*     */   String grandLabel;
/*     */   Font bold;
/*     */   int headerS;
/*     */   
/*  59 */   public GroupFilter(SortedTable paramSortedTable) { this(paramSortedTable, new int[0], (Formula[])null, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public GroupFilter(SortedTable paramSortedTable, int paramInt, Formula paramFormula1, Formula paramFormula2) { this(paramSortedTable, new int[1], (paramFormula1 != null) ? new Formula[1] : null, (paramFormula2 != null) ? new Formula[1] : null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GroupFilter(SortedTable paramSortedTable, int[] paramArrayOfInt, Formula paramFormula1, Formula paramFormula2) {
/* 810 */     this.headermap = new Hashtable();
/* 811 */     this.sumrows = new Vector();
/*     */     
/* 813 */     this.groupboundries = new Vector();
/*     */ 
/*     */ 
/*     */     
/* 817 */     this.headerrow = false;
/* 818 */     this.grpcols = true;
/* 819 */     this.groupPerPage = false;
/* 820 */     this.grandLabel = null;
/* 821 */     this.bold = new Font("Serif", 1, 10);
/* 822 */     this.headerS = 1; this.sums = paramArrayOfInt; this.cols = paramSortedTable.getSortCols(); Formula[] arrayOfFormula = null; if (paramFormula1 != null) { arrayOfFormula = new Formula[paramArrayOfInt.length]; for (byte b = 0; b < arrayOfFormula.length; b++) { try { arrayOfFormula[b] = (Formula)paramFormula1.clone(); } catch (Exception exception) { exception.printStackTrace(); }  }  }  if (paramFormula2 != null) { this.grand = new Formula[paramArrayOfInt.length]; for (byte b = 0; b < paramArrayOfInt.length; b++) { try { this.grand[b] = (Formula)paramFormula2.clone(); } catch (Exception exception) { exception.printStackTrace(); }  }  }  init(paramSortedTable, arrayOfFormula); } public GroupFilter(SortedTable paramSortedTable, int[] paramArrayOfInt, Formula[] paramArrayOfFormula1, Formula[] paramArrayOfFormula2) { this.headermap = new Hashtable(); this.sumrows = new Vector(); this.groupboundries = new Vector(); this.headerrow = false; this.grpcols = true; this.groupPerPage = false; this.grandLabel = null; this.bold = new Font("Serif", 1, 10); this.headerS = 1;
/*     */     this.sums = paramArrayOfInt;
/*     */     this.grand = paramArrayOfFormula2;
/*     */     this.cols = paramSortedTable.getSortCols();
/*     */     init(paramSortedTable, paramArrayOfFormula1); }
/*     */ 
/*     */   
/*     */   public int getGroupColCount() { return this.cols.length; }
/*     */   
/*     */   public TableLens getTable() { return this.table; }
/*     */   
/*     */   private void init(SortedTable paramSortedTable, Formula[] paramArrayOfFormula) {
/*     */     int[] arrayOfInt = new int[paramSortedTable.getColCount()];
/*     */     Vector vector = new Vector();
/*     */     for (byte b1 = 0; b1 < arrayOfInt.length; b1++)
/*     */       vector.addElement(new Integer(b1)); 
/*     */     for (byte b2 = 0; b2 < this.cols.length; b2++)
/*     */       vector.removeElement(new Integer(this.cols[b2])); 
/*     */     for (byte b3 = 0; b3 < arrayOfInt.length; b3++) {
/*     */       if (b3 < this.cols.length) {
/*     */         arrayOfInt[b3] = this.cols[b3];
/*     */       } else {
/*     */         arrayOfInt[b3] = ((Integer)vector.elementAt(0)).intValue();
/*     */         vector.removeElementAt(0);
/*     */       } 
/*     */     } 
/*     */     this.table = new ColumnMapFilter(paramSortedTable, arrayOfInt);
/*     */     if (this.sums != null)
/*     */       for (byte b = 0; b < this.sums.length; b++) {
/*     */         for (byte b4 = 0; b4 < arrayOfInt.length; b4++) {
/*     */           if (arrayOfInt[b4] == this.sums[b]) {
/*     */             this.sums[b] = b4;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }  
/*     */     if (paramArrayOfFormula != null && this.sums != null) {
/*     */       this.calcs = new Formula[this.cols.length][this.sums.length];
/*     */       for (byte b = 0; b < this.calcs.length; b++) {
/*     */         for (byte b4 = 0; b4 < this.calcs[b].length; b4++) {
/*     */           try {
/*     */             this.calcs[b][b4] = (Formula)paramArrayOfFormula[b4].clone();
/*     */           } catch (Exception exception) {
/*     */             exception.printStackTrace();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void refresh() {
/*     */     if (this.table instanceof TableFilter)
/*     */       ((TableFilter)this.table).refresh(); 
/*     */     Object[] arrayOfObject = new Object[this.cols.length];
/*     */     Vector vector = new Vector();
/*     */     boolean bool = true;
/*     */     byte b1 = 0;
/*     */     this.sumrows.setSize(1);
/*     */     this.groupboundries.removeAllElements();
/*     */     if (this.calcs != null)
/*     */       for (byte b = 0; b < this.calcs.length; b++) {
/*     */         for (byte b4 = 0; b4 < this.calcs[b].length; b4++)
/*     */           this.calcs[b][b4].reset(); 
/*     */       }  
/*     */     this.headermap.clear();
/*     */     if (this.grand != null)
/*     */       for (byte b = 0; b < this.grand.length; b++)
/*     */         this.grand[b].reset();  
/*     */     for (byte b2 = 0; b2 < this.table.getRowCount(); b2++) {
/*     */       if (b2 < this.table.getHeaderRowCount()) {
/*     */         vector.addElement(new Integer(b2));
/*     */       } else {
/*     */         boolean bool1 = true;
/*     */         for (byte b = 0; b < this.cols.length; b++) {
/*     */           Object object1 = arrayOfObject[b];
/*     */           Object object2 = this.table.getObject(b2, b);
/*     */           if (object1 == null || object2 == null || !object1.equals(object2)) {
/*     */             bool1 = false;
/*     */             b1 = b;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */         if (!bool1) {
/*     */           if (bool) {
/*     */             bool = false;
/*     */           } else {
/*     */             addSummaryRow(b2, b1, vector);
/*     */           } 
/*     */           for (byte b4 = 0; b4 < this.cols.length; b4++)
/*     */             arrayOfObject[b4] = this.table.getObject(b2, b4); 
/*     */           if (this.calcs != null)
/*     */             for (byte b5 = b1; b5 < this.calcs.length; b5++) {
/*     */               for (byte b6 = 0; b6 < this.calcs[b5].length; b6++)
/*     */                 this.calcs[b5][b6].reset(); 
/*     */             }  
/*     */           if (this.headerrow)
/*     */             if (this.headerS == 1) {
/*     */               for (byte b5 = b1; b5 < this.cols.length; b5++) {
/*     */                 this.headermap.put(new Integer(vector.size()), new Integer(b5));
/*     */                 vector.addElement(new Integer(-this.sumrows.size()));
/*     */                 Vector vector1 = new Vector();
/*     */                 vector1.setSize(this.table.getColCount());
/*     */                 vector1.setElementAt(this.table.getObject(b2, b5), b5);
/*     */                 this.sumrows.addElement(vector1);
/*     */               } 
/*     */             } else if ((this.headerS & 0x2) != 0) {
/*     */               this.headermap.put(new Integer(vector.size()), new Integer(b1));
/*     */             }  
/*     */         } 
/*     */         if (this.sums != null)
/*     */           for (byte b4 = 0; b4 < this.sums.length; b4++) {
/*     */             Object object = this.table.getObject(b2, this.sums[b4]);
/*     */             if (this.grand != null)
/*     */               this.grand[b4].addValue(object); 
/*     */             if (this.calcs != null)
/*     */               for (byte b5 = 0; b5 < this.calcs.length; b5++)
/*     */                 this.calcs[b5][b4].addValue(object);  
/*     */           }  
/*     */         vector.addElement(new Integer(b2));
/*     */       } 
/*     */     } 
/*     */     addSummaryRow(this.table.getRowCount(), 0, vector);
/*     */     if (this.grand != null) {
/*     */       vector.addElement(new Integer(-this.sumrows.size()));
/*     */       Vector vector1 = new Vector();
/*     */       vector1.setSize(this.table.getColCount());
/*     */       vector1.setElementAt(this.grandLabel, 0);
/*     */       if (this.sums != null)
/*     */         for (byte b = 0; b < this.sums.length; b++)
/*     */           vector1.setElementAt(this.grand[b].getResult(), this.sums[b]);  
/*     */       this.sumrows.addElement(vector1);
/*     */     } 
/*     */     this.rowmap = new int[vector.size()];
/*     */     for (byte b3 = 0; b3 < this.rowmap.length; b3++)
/*     */       this.rowmap[b3] = ((Integer)vector.elementAt(b3)).intValue(); 
/*     */   }
/*     */   
/*     */   private int addSummaryRow(int paramInt1, int paramInt2, Vector paramVector) {
/*     */     byte b = 0;
/*     */     if (this.calcs != null && this.sums != null && this.sums.length > 0)
/*     */       for (int i = this.cols.length - 1; i >= paramInt2; i--) {
/*     */         paramVector.addElement(new Integer(-this.sumrows.size()));
/*     */         b++;
/*     */         Vector vector = new Vector();
/*     */         vector.setSize(this.table.getColCount());
/*     */         for (byte b1 = 0; b1 <= i; b1++)
/*     */           vector.setElementAt(this.table.getObject(paramInt1 - 1, b1), b1); 
/*     */         for (byte b2 = 0; b2 < this.sums.length; b2++)
/*     */           vector.setElementAt(this.calcs[i][b2].getResult(), this.sums[b2]); 
/*     */         this.sumrows.addElement(vector);
/*     */       }  
/*     */     if (paramInt2 == 0)
/*     */       this.groupboundries.addElement(new Integer(paramVector.size() - 1)); 
/*     */     return b;
/*     */   }
/*     */   
/*     */   public boolean isAddGroupHeader() { return this.headerrow; }
/*     */   
/*     */   public void setAddGroupHeader(boolean paramBoolean) { this.headerrow = paramBoolean; }
/*     */   
/*     */   public boolean isShowGroupColumns() { return this.grpcols; }
/*     */   
/*     */   public void setShowGroupColumns(boolean paramBoolean) { this.grpcols = paramBoolean; }
/*     */   
/*     */   public int getGroupHeaderStyle() { return this.headerS; }
/*     */   
/*     */   public void setGroupHeaderStyle(int paramInt) { this.headerS = paramInt; }
/*     */   
/*     */   public boolean isBreakAfterSection() { return this.groupPerPage; }
/*     */   
/*     */   public void setBreakAfterSection(boolean paramBoolean) { this.groupPerPage = paramBoolean; }
/*     */   
/*     */   public void setGrandLabel(String paramString) { this.grandLabel = paramString; }
/*     */   
/*     */   public String getGrandLabel() { return this.grandLabel; }
/*     */   
/*     */   public boolean isGroupHeaderRow(int paramInt) {
/*     */     checkInit();
/*     */     return (this.headerS == 1 && this.headermap.get(new Integer(paramInt)) != null);
/*     */   }
/*     */   
/*     */   public boolean isGroupHeaderCell(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     if (this.headerrow && (this.headerS & 0x2) != 0) {
/*     */       Integer integer = (Integer)this.headermap.get(new Integer(paramInt1));
/*     */       return (integer != null && paramInt2 >= integer.intValue() && paramInt2 < this.cols.length);
/*     */     } 
/*     */     return isGroupHeaderRow(paramInt1);
/*     */   }
/*     */   
/*     */   public int getGroupLevel(int paramInt) {
/*     */     Integer integer = (Integer)this.headermap.get(new Integer(paramInt));
/*     */     return (integer == null) ? -1 : integer.intValue();
/*     */   }
/*     */   
/*     */   public boolean isSummaryRow(int paramInt) {
/*     */     checkInit();
/*     */     return (this.rowmap[paramInt] < 0 && this.sums != null && this.sums.length > 0 && getObject(paramInt, this.sums[false]) != null);
/*     */   }
/*     */   
/*     */   public boolean isSummaryCol(int paramInt) {
/*     */     checkInit();
/*     */     if (this.sums != null)
/*     */       for (byte b = 0; b < this.sums.length; b++) {
/*     */         if (this.sums[b] == paramInt)
/*     */           return true; 
/*     */       }  
/*     */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasGrandSummary() {
/*     */     checkInit();
/*     */     return (this.grand != null);
/*     */   }
/*     */   
/*     */   public int getRowCount() {
/*     */     checkInit();
/*     */     return this.rowmap.length;
/*     */   }
/*     */   
/*     */   public int getColCount() { return this.table.getColCount(); }
/*     */   
/*     */   public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
/*     */   
/*     */   public int getHeaderColCount() { return this.table.getHeaderColCount(); }
/*     */   
/*     */   public int getRowHeight(int paramInt) {
/*     */     checkInit();
/*     */     return this.table.getRowHeight((this.rowmap[paramInt] >= 0) ? this.rowmap[paramInt] : 0);
/*     */   }
/*     */   
/*     */   public int getColWidth(int paramInt) { return this.table.getColWidth(paramInt); }
/*     */   
/*     */   public Color getRowBorderColor(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return (paramInt1 < 0 || this.rowmap[paramInt1] >= 0) ? this.table.getRowBorderColor((paramInt1 < 0) ? paramInt1 : this.rowmap[paramInt1], paramInt2) : Color.black;
/*     */   }
/*     */   
/*     */   public Color getColBorderColor(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return (paramInt1 < 0 || this.rowmap[paramInt1] >= 0) ? this.table.getColBorderColor((paramInt1 < 0) ? paramInt1 : this.rowmap[paramInt1], paramInt2) : Color.black;
/*     */   }
/*     */   
/*     */   public int getRowBorder(int paramInt1, int paramInt2) {
/*     */     char c = (paramInt1 == this.table.getHeaderRowCount() - 1 || paramInt2 < 0 || (paramInt1 >= 0 && (!isSummaryRow(paramInt1) || isSummaryCol(paramInt2)))) ? 4097 : 0;
/*     */     int i = this.groupboundries.indexOf(new Integer(paramInt1));
/*     */     if (this.groupPerPage && paramInt2 == 0 && i >= 0 && (this.grand != null || i < this.groupboundries.size() - 1))
/*     */       return 0x1000000 | c; 
/*     */     return c;
/*     */   }
/*     */   
/*     */   public int getColBorder(int paramInt1, int paramInt2) { return 0; }
/*     */   
/*     */   public Insets getInsets(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public Dimension getSpan(int paramInt1, int paramInt2) { return null; }
/*     */   
/*     */   public int getAlignment(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return (this.rowmap[paramInt1] >= 0) ? this.table.getAlignment(this.rowmap[paramInt1], paramInt2) : 1;
/*     */   }
/*     */   
/*     */   public Font getFont(int paramInt1, int paramInt2) {
/*     */     if (this.headerrow && (this.headerS & 0x2) != 0 && paramInt2 < this.cols.length)
/*     */       return this.bold; 
/*     */     checkInit();
/*     */     return (paramInt1 >= this.table.getHeaderRowCount() && this.rowmap[paramInt1] >= 0) ? this.table.getFont(this.rowmap[paramInt1], paramInt2) : this.bold;
/*     */   }
/*     */   
/*     */   public boolean isLineWrap(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return (this.rowmap[paramInt1] >= 0) ? this.table.isLineWrap(this.rowmap[paramInt1], paramInt2) : 1;
/*     */   }
/*     */   
/*     */   public Color getForeground(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return (this.rowmap[paramInt1] >= 0) ? this.table.getForeground(this.rowmap[paramInt1], paramInt2) : null;
/*     */   }
/*     */   
/*     */   public Color getBackground(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     return (this.rowmap[paramInt1] >= 0) ? this.table.getBackground(this.rowmap[paramInt1], paramInt2) : null;
/*     */   }
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/*     */     checkInit();
/*     */     Object object = null;
/*     */     if (this.rowmap[paramInt1] < 0) {
/*     */       object = ((Vector)this.sumrows.elementAt(-this.rowmap[paramInt1])).elementAt(paramInt2);
/*     */     } else if (this.grpcols || paramInt2 >= this.cols.length || paramInt1 < this.table.getHeaderRowCount()) {
/*     */       object = this.table.getObject(this.rowmap[paramInt1], paramInt2);
/*     */     } else if (this.headerrow && (this.headerS & 0x2) != 0) {
/*     */       Integer integer = (Integer)this.headermap.get(new Integer(paramInt1));
/*     */       if (this.headerS == 4098 || (integer != null && paramInt2 >= integer.intValue()))
/*     */         object = this.table.getObject(this.rowmap[paramInt1], paramInt2); 
/*     */     } 
/*     */     return object;
/*     */   }
/*     */   
/*     */   private void checkInit() {
/*     */     if (this.rowmap == null)
/*     */       refresh(); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\GroupFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */