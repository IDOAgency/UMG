package inetsoft.report.filter;

import inetsoft.report.Comparer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateComparer implements Comparer {
  DateFormat fmt;
  
  public DateComparer() {}
  
  public DateComparer(String paramString) { this.fmt = new SimpleDateFormat(paramString); }
  
  public DateComparer(DateFormat paramDateFormat) { this.fmt = paramDateFormat; }
  
  public int compare(Object paramObject1, Object paramObject2) {
    if (paramObject1 instanceof Date && paramObject2 instanceof Date) {
      long l = ((Date)paramObject1).getTime() - ((Date)paramObject2).getTime();
      return (l == 0L) ? 0 : (int)(l / Math.abs(l));
    } 
    try {
      long l = this.fmt.parse(paramObject1.toString()).getTime() - this.fmt.parse(paramObject2.toString()).getTime();
      return (l == 0L) ? 0 : (int)(l / Math.abs(l));
    } catch (Exception exception) {
      exception.printStackTrace();
      return 0;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\DateComparer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */