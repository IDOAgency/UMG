/*    */ package inetsoft.report.filter;
/*    */ 
/*    */ import inetsoft.report.Comparer;
/*    */ import java.text.DateFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateComparer
/*    */   implements Comparer
/*    */ {
/*    */   DateFormat fmt;
/*    */   
/*    */   public DateComparer() {}
/*    */   
/* 40 */   public DateComparer(String paramString) { this.fmt = new SimpleDateFormat(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   public DateComparer(DateFormat paramDateFormat) { this.fmt = paramDateFormat; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int compare(Object paramObject1, Object paramObject2) {
/* 61 */     if (paramObject1 instanceof Date && paramObject2 instanceof Date) {
/* 62 */       long l = ((Date)paramObject1).getTime() - ((Date)paramObject2).getTime();
/* 63 */       return (l == 0L) ? 0 : (int)(l / Math.abs(l));
/*    */     } 
/*    */     
/*    */     try {
/* 67 */       long l = this.fmt.parse(paramObject1.toString()).getTime() - this.fmt.parse(paramObject2.toString()).getTime();
/*    */       
/* 69 */       return (l == 0L) ? 0 : (int)(l / Math.abs(l));
/*    */     } catch (Exception exception) {
/* 71 */       exception.printStackTrace();
/*    */ 
/*    */       
/* 74 */       return 0;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\DateComparer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */