package inetsoft.report.filter;

import inetsoft.report.TableLens;

public interface GroupedTable extends TableLens {
  int getGroupColCount();
  
  boolean isGroupHeaderRow(int paramInt);
  
  boolean isGroupHeaderCell(int paramInt1, int paramInt2);
  
  int getGroupLevel(int paramInt);
  
  boolean isSummaryRow(int paramInt);
  
  boolean isSummaryCol(int paramInt);
  
  boolean hasGrandSummary();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\GroupedTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */