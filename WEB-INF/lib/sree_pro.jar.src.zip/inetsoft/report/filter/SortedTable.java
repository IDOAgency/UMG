package inetsoft.report.filter;

import inetsoft.report.TableLens;

public interface SortedTable extends TableLens {
  int[] getSortCols();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\filter\SortedTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */