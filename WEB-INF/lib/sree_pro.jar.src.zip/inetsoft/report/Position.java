/*    */ package inetsoft.report;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Position
/*    */   implements Serializable
/*    */ {
/*    */   public float x;
/*    */   public float y;
/*    */   
/* 27 */   public Position() { this(0.0F, 0.0F); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public Position(Position paramPosition) { this(paramPosition.x, paramPosition.y); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Position(float paramFloat1, float paramFloat2) {
/* 43 */     this.x = paramFloat1;
/* 44 */     this.y = paramFloat2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public Position(double paramDouble1, double paramDouble2) { this((float)paramDouble1, (float)paramDouble2); }
/*    */ 
/*    */ 
/*    */   
/* 57 */   public String toString() { return "Position[" + this.x + "," + this.y + "]"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Position.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */