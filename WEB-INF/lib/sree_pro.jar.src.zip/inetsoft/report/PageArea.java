/*     */ package inetsoft.report;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PageArea
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   public double x;
/*     */   public double y;
/*     */   public double width;
/*     */   public double height;
/*     */   boolean relative;
/*     */   int border;
/*     */   Insets insets;
/*     */   Rectangle rect;
/*     */   boolean flow;
/*     */   boolean repeat;
/*     */   Color bcolor;
/*     */   FixedContainer container;
/*     */   
/*     */   public PageArea(Rectangle paramRectangle) {
/* 280 */     this.relative = false;
/* 281 */     this.border = 0;
/* 282 */     this.insets = new Insets(0, 0, 0, 0);
/*     */     
/* 284 */     this.flow = true;
/* 285 */     this.repeat = true;
/* 286 */     this.bcolor = Color.black; this.rect = paramRectangle; } public PageArea(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, boolean paramBoolean) { this.relative = false; this.border = 0; this.insets = new Insets(0, 0, 0, 0); this.flow = true; this.repeat = true; this.bcolor = Color.black;
/*     */     this.x = paramDouble1;
/*     */     this.y = paramDouble2;
/*     */     this.width = paramDouble3;
/*     */     this.height = paramDouble4;
/*     */     this.relative = paramBoolean; }
/*     */ 
/*     */   
/*     */   public PageArea(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) { this(paramDouble1, paramDouble2, paramDouble3, paramDouble4, false); }
/*     */   
/*     */   public void setBorder(int paramInt) {
/*     */     this.border = paramInt;
/*     */     if (this.insets == null)
/*     */       this.insets = new Insets(0, 0, 0, 0); 
/*     */     int i = (int)Math.ceil(Common.getLineWidth(paramInt));
/*     */     this.insets.top = Math.max(this.insets.top, i + 2);
/*     */     this.insets.left = Math.max(this.insets.left, i + 2);
/*     */     this.insets.bottom = Math.max(this.insets.bottom, i + 2);
/*     */     this.insets.right = Math.max(this.insets.right, i + 2);
/*     */   }
/*     */   
/*     */   public int getBorder() { return this.border; }
/*     */   
/*     */   public void setBorderColor(Color paramColor) { this.bcolor = paramColor; }
/*     */   
/*     */   public Color getBorderColor() { return this.bcolor; }
/*     */   
/*     */   public void setInsets(Insets paramInsets) { this.insets = paramInsets; }
/*     */   
/*     */   public Insets getInsets() { return this.insets; }
/*     */   
/*     */   public void setRelative(boolean paramBoolean) { this.relative = paramBoolean; }
/*     */   
/*     */   public boolean isRelative() { return this.relative; }
/*     */   
/*     */   public void setElements(FixedContainer paramFixedContainer) {
/*     */     this.container = paramFixedContainer;
/*     */     this.flow = false;
/*     */   }
/*     */   
/*     */   public FixedContainer getElements() { return this.container; }
/*     */   
/*     */   public void setFlow(boolean paramBoolean) { this.flow = paramBoolean; }
/*     */   
/*     */   public boolean isFlow() { return this.flow; }
/*     */   
/*     */   public void setRepeat(boolean paramBoolean) { this.repeat = paramBoolean; }
/*     */   
/*     */   public boolean isRepeat() { return this.repeat; }
/*     */   
/*     */   public void setBounds(Rectangle paramRectangle1, Rectangle paramRectangle2, int paramInt) {
/*     */     this.relative = false;
/*     */     this.x = (paramRectangle1.x - paramRectangle2.x) / paramInt;
/*     */     this.y = (paramRectangle1.y - paramRectangle2.y) / paramInt;
/*     */     this.width = paramRectangle1.width / paramInt;
/*     */     this.height = paramRectangle1.height / paramInt;
/*     */   }
/*     */   
/*     */   public Rectangle getBounds(Rectangle paramRectangle, int paramInt) {
/*     */     if (this.rect != null)
/*     */       return new Rectangle(this.rect); 
/*     */     Rectangle rectangle = new Rectangle(paramRectangle);
/*     */     if (this.relative) {
/*     */       rectangle.x += (int)(this.x * paramRectangle.width);
/*     */       rectangle.y += (int)(this.y * paramRectangle.height);
/*     */       rectangle.width = (int)(this.width * paramRectangle.width);
/*     */       rectangle.height = (int)(this.height * paramRectangle.height);
/*     */     } else {
/*     */       rectangle.x += (int)(this.x * paramInt);
/*     */       rectangle.y += (int)(this.y * paramInt);
/*     */       rectangle.width = (int)(this.width * paramInt);
/*     */       rectangle.height = (int)(this.height * paramInt);
/*     */     } 
/*     */     return rectangle;
/*     */   }
/*     */   
/*     */   public Rectangle getPrintArea(Rectangle paramRectangle, int paramInt) {
/*     */     Rectangle rectangle = getBounds(paramRectangle, paramInt);
/*     */     if (this.insets != null) {
/*     */       rectangle.x += this.insets.left;
/*     */       rectangle.y += this.insets.top;
/*     */       rectangle.width -= this.insets.left + this.insets.right;
/*     */       rectangle.height -= this.insets.top + this.insets.bottom;
/*     */     } 
/*     */     return rectangle;
/*     */   }
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*     */       return super.clone();
/*     */     } catch (Exception exception) {
/*     */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\PageArea.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */