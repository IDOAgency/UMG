package inetsoft.report;

import java.awt.Dimension;
import java.awt.Graphics;
import java.io.Serializable;

public interface Painter extends Serializable {
  void paint(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  Dimension getPreferredSize();
  
  boolean isScalable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Painter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */