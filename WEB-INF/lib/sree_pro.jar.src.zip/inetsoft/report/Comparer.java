package inetsoft.report;

import java.io.Serializable;

public interface Comparer extends Serializable {
  int compare(Object paramObject1, Object paramObject2);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\Comparer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */