package inetsoft.report;

import java.awt.Color;
import java.awt.Font;
import java.io.Serializable;

public interface ReportElement extends Serializable, Cloneable {
  public static final String QUERY = "query";
  
  public static final String XNODEPATH = "xnodepath";
  
  public static final String AGGREGATE = "aggregate";
  
  String getID();
  
  void setID(String paramString);
  
  int getAlignment();
  
  void setAlignment(int paramInt);
  
  double getIndent();
  
  void setIndent(double paramDouble);
  
  Font getFont();
  
  void setFont(Font paramFont);
  
  Color getForeground();
  
  void setForeground(Color paramColor);
  
  Color getBackground();
  
  void setBackground(Color paramColor);
  
  int getSpacing();
  
  void setSpacing(int paramInt);
  
  boolean isVisible();
  
  void setVisible(boolean paramBoolean);
  
  boolean isKeepWithNext();
  
  void setKeepWithNext(boolean paramBoolean);
  
  String getScript();
  
  void setScript(String paramString);
  
  String getOnClick();
  
  void setOnClick(String paramString);
  
  String getProperty(String paramString);
  
  void setProperty(String paramString1, String paramString2);
  
  void setContext(ReportElement paramReportElement);
  
  String getType();
  
  Size getPreferredSize();
  
  Object clone() throws CloneNotSupportedException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\ReportElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */