package inetsoft.report;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

public interface TableLens extends StyleConstants, Cloneable {
  public static final int BREAK_BORDER = 16777216;
  
  int getRowCount();
  
  int getColCount();
  
  int getHeaderRowCount();
  
  int getHeaderColCount();
  
  int getRowHeight(int paramInt);
  
  int getColWidth(int paramInt);
  
  Color getRowBorderColor(int paramInt1, int paramInt2);
  
  Color getColBorderColor(int paramInt1, int paramInt2);
  
  int getRowBorder(int paramInt1, int paramInt2);
  
  int getColBorder(int paramInt1, int paramInt2);
  
  Insets getInsets(int paramInt1, int paramInt2);
  
  Dimension getSpan(int paramInt1, int paramInt2);
  
  int getAlignment(int paramInt1, int paramInt2);
  
  Font getFont(int paramInt1, int paramInt2);
  
  boolean isLineWrap(int paramInt1, int paramInt2);
  
  Color getForeground(int paramInt1, int paramInt2);
  
  Color getBackground(int paramInt1, int paramInt2);
  
  Object getObject(int paramInt1, int paramInt2);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\TableLens.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */