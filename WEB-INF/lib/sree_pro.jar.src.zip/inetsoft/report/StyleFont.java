package inetsoft.report;

import inetsoft.report.internal.Util;
import java.awt.Font;

public class StyleFont extends Font implements StyleConstants {
  public static final int AWT_FONT_MASK = 3;
  
  public static final int STYLE_FONT_MASK = 65520;
  
  public static final int UNDERLINE = 16;
  
  public static final int STRIKETHROUGH = 32;
  
  public static final int SUPERSCRIPT = 64;
  
  public static final int SUBSCRIPT = 128;
  
  public static final int SHADOW = 256;
  
  public static final int SMALLCAPS = 512;
  
  public static final int ALLCAPS = 1024;
  
  private int extstyle;
  
  private int linetype;
  
  public StyleFont(String paramString, int paramInt1, int paramInt2) {
    super(paramString, paramInt1 & 0x3, paramInt2);
    this.linetype = 4097;
    this.extstyle = paramInt1;
  }
  
  public StyleFont(String paramString, int paramInt1, int paramInt2, int paramInt3) {
    this(paramString, paramInt1, paramInt2);
    this.linetype = paramInt3;
  }
  
  public StyleFont(Font paramFont) { this(paramFont.getName(), paramFont.getStyle(), paramFont.getSize(), (paramFont instanceof StyleFont) ? ((StyleFont)paramFont).getLineStyle() : 0); }
  
  public int getStyle() { return this.extstyle; }
  
  public int getLineStyle() { return this.linetype; }
  
  public static Font decode(String paramString) {
    try {
      String[] arrayOfString = Util.split(paramString, '-');
      String str = null;
      int i = 12;
      char c = Character.MIN_VALUE;
      int j = 0;
      if (paramString.indexOf("PLAIN") >= 0)
        c |= false; 
      if (paramString.indexOf("BOLD") >= 0)
        c |= true; 
      if (paramString.indexOf("ITALIC") >= 0)
        c |= 0x2; 
      if (paramString.indexOf("UNDERLINE") >= 0)
        c |= 0x10; 
      if (paramString.indexOf("STRIKETHROUGH") >= 0)
        c |= 0x20; 
      if (paramString.indexOf("SUPERSCRIPT") >= 0)
        c |= 0x40; 
      if (paramString.indexOf("SUBSCRIPT") >= 0)
        c |= 0x80; 
      if (paramString.indexOf("SHADOW") >= 0)
        c |= 0x100; 
      if (paramString.indexOf("SMALLCAPS") >= 0)
        c |= 0x200; 
      if (paramString.indexOf("ALLCAPS") >= 0)
        c |= 0x400; 
      if ((c & 0x10) != '\000' || (c & 0x20) != '\000')
        j = decodeLineStyle(arrayOfString[arrayOfString.length - 1]); 
      if ((c & 0xFFF0) != '\000') {
        i = Integer.parseInt(arrayOfString[arrayOfString.length - 2]);
        str = arrayOfString[0];
        for (byte b1 = 1; b1 < arrayOfString.length - 3; b1++)
          str = str + "-" + arrayOfString[b1]; 
        return new StyleFont(str, c, i, j);
      } 
      i = Integer.parseInt(arrayOfString[arrayOfString.length - 1]);
      str = arrayOfString[0];
      for (byte b = 1; b < arrayOfString.length - 2; b++)
        str = str + "-" + arrayOfString[b]; 
      return new Font(str, c, i);
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public static String toString(Font paramFont) {
    String str = paramFont.getName() + "-";
    int i = paramFont.getStyle();
    if (i == 0)
      str = str + "PLAIN"; 
    if ((i & true) != 0)
      str = str + "BOLD"; 
    if ((i & 0x2) != 0)
      str = str + "ITALIC"; 
    if ((i & 0x10) != 0)
      str = str + "UNDERLINE"; 
    if ((i & 0x20) != 0)
      str = str + "STRIKETHROUGH"; 
    if ((i & 0x40) != 0)
      str = str + "SUPERSCRIPT"; 
    if ((i & 0x80) != 0)
      str = str + "SUBSCRIPT"; 
    if ((i & 0x100) != 0)
      str = str + "SHADOW"; 
    if ((i & 0x200) != 0)
      str = str + "SMALLCAPS"; 
    if ((i & 0x400) != 0)
      str = str + "ALLCAPS"; 
    str = str + "-" + paramFont.getSize();
    if ((i & 0xFFF0) != 0)
      str = str + "-" + ((StyleFont)paramFont).getLineStyle(); 
    return str;
  }
  
  public static int decodeLineStyle(String paramString) {
    if (paramString.equals("NO_BORDER"))
      return 0; 
    if (paramString.equals("ULTRA_THIN_LINE"))
      return 266240; 
    if (paramString.equals("THIN_THIN_LINE"))
      return 528384; 
    if (paramString.equals("THIN_LINE"))
      return 4097; 
    if (paramString.equals("MEDIUM_LINE"))
      return 4098; 
    if (paramString.equals("THICK_LINE"))
      return 4099; 
    if (paramString.equals("DOUBLE_LINE"))
      return 8195; 
    if (paramString.equals("RAISED_3D"))
      return 24578; 
    if (paramString.equals("LOWERED_3D"))
      return 40962; 
    if (paramString.equals("DOUBLE_3D_RAISED"))
      return 24579; 
    if (paramString.equals("DOUBLE_3D_LOWERE"))
      return 40963; 
    if (paramString.equals("DOT_LINE"))
      return 4113; 
    if (paramString.equals("DASH_LINE"))
      return 4145; 
    if (paramString.equals("MEDIUM_DASH"))
      return 4193; 
    if (paramString.equals("LARGE_DASH"))
      return 4241; 
    return Integer.decode(paramString).intValue();
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof StyleFont) {
      StyleFont styleFont = (StyleFont)paramObject;
      return (this.extstyle == styleFont.extstyle && this.linetype == styleFont.linetype && super.equals(paramObject));
    } 
    if (paramObject instanceof Font)
      return ((this.extstyle & 0xFFF0) == 0 && super.equals(paramObject)); 
    return false;
  }
  
  static  {
    Common.getAllFonts();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\report\StyleFont.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */