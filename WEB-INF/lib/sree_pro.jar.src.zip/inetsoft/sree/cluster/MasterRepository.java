/*     */ package inetsoft.sree.cluster;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.event.SelectionEvent;
/*     */ import inetsoft.sree.EventHandler;
/*     */ import inetsoft.sree.PageLocation;
/*     */ import inetsoft.sree.RepletCommand;
/*     */ import inetsoft.sree.RepletEngine;
/*     */ import inetsoft.sree.RepletException;
/*     */ import inetsoft.sree.RepletParameters;
/*     */ import inetsoft.sree.RepletRepository;
/*     */ import inetsoft.sree.RepletRequest;
/*     */ import inetsoft.sree.SearchCondition;
/*     */ import inetsoft.sree.SreeEnv;
/*     */ import inetsoft.sree.SreeLog;
/*     */ import inetsoft.sree.internal.RepletPages;
/*     */ import inetsoft.uql.corba.CorbaHandler;
/*     */ import java.awt.Point;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.RMISecurityManager;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ import java.util.EventObject;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MasterRepository
/*     */   extends UnicastRemoteObject
/*     */   implements RepletRepository, RepositoryRegistry
/*     */ {
/*     */   RepletEngine engine;
/*     */   Hashtable repmap;
/*     */   Vector reps;
/*     */   
/*     */   public MasterRepository() throws RemoteException {
/* 567 */     this.repmap = new Hashtable();
/* 568 */     this.reps = new Vector();
/*     */     this.engine = new RepletEngine("master");
/*     */     this.engine.init();
/*     */     int i = Integer.parseInt(SreeEnv.getProperty("cluster.master.threshold", "500"));
/*     */     this.repmap.put("master", this.engine);
/*     */     this.reps.insertElementAt(new RepCount(this, "master", i), 0);
/*     */   }
/*     */   
/*     */   public String register(String paramString) throws RemoteException {
/*     */     try {
/*     */       PingableRepository pingableRepository = (PingableRepository)Naming.lookup(paramString);
/*     */       this.repmap.put(paramString, pingableRepository);
/*     */       this.reps.insertElementAt(new RepCount(this, paramString, 0), 0);
/*     */       SreeLog.print("Slave repository registered: " + paramString);
/*     */     } catch (Throwable throwable) {
/*     */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */     return paramString;
/*     */   }
/*     */   
/*     */   public void remove(String paramString) throws RemoteException {
/*     */     this.repmap.remove(paramString);
/*     */     SreeLog.print("Remove slave: " + paramString);
/*     */     for (byte b = 0; b < this.reps.size(); b++) {
/*     */       if (((RepCount)this.reps.elementAt(b)).url.equals(paramString)) {
/*     */         this.reps.removeElementAt(b);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public String[] getRepletNames(Object paramObject) throws RemoteException { return this.engine.getRepletNames(paramObject); }
/*     */   
/*     */   public Object create(String paramString, Object paramObject) throws RepletException, RemoteException {
/*     */     RepCount repCount = (RepCount)this.reps.elementAt(0);
/*     */     RepletRepository repletRepository = (RepletRepository)this.repmap.get(repCount.url);
/*     */     if (repletRepository == null) {
/*     */       SreeLog.print("Internal Error: RepletRepository missing: " + repCount.url);
/*     */       throw new RepletException("No Replet Repository available");
/*     */     } 
/*     */     repCount.count++;
/*     */     byte b1 = 0;
/*     */     for (byte b2 = 1; b2 < this.reps.size(); ) {
/*     */       RepCount repCount1 = (RepCount)this.reps.elementAt(b2);
/*     */       if (repCount.count >= repCount1.count) {
/*     */         b1 = b2 + 1;
/*     */         b2++;
/*     */       } 
/*     */       break;
/*     */     } 
/*     */     if (b1 > 0) {
/*     */       this.reps.insertElementAt(repCount, b1);
/*     */       this.reps.removeElementAt(0);
/*     */     } 
/*     */     try {
/*     */       return repletRepository.create(paramString, paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       if (repletRepository instanceof PingableRepository && !((PingableRepository)repletRepository).ping()) {
/*     */         SreeLog.print("Slave not responding: " + repCount.url);
/*     */         remove(repCount.url);
/*     */       } 
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public RepletParameters getRepletParameters(Object paramObject, String paramString) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getRepletParameters(paramObject, paramString);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void generate(Object paramObject, RepletRequest paramRepletRequest) throws RepletException, RemoteException {
/*     */     try {
/*     */       getRepletRepository(paramObject).generate(paramObject, paramRepletRequest);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getEventMask(Object paramObject) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getEventMask(paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public EventHandler getEventHandler(Object paramObject) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getEventHandler(paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public RepletCommand handleEvent(Object paramObject, EventObject paramEventObject) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).handleEvent(paramObject, paramEventObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public SelectionEvent[] getRegisteredSelections(Object paramObject) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getRegisteredSelections(paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public StylePage getPage(Object paramObject, int paramInt) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getPage(paramObject, paramInt);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getPageCount(Object paramObject) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getPageCount(paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public PageLocation find(Object paramObject, SearchCondition paramSearchCondition, PageLocation paramPageLocation) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).find(paramObject, paramSearchCondition, paramPageLocation);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String[] getTOCPaths(Object paramObject) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getTOCPaths(paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public PageLocation[] getTOCLocations(Object paramObject) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getTOCLocations(paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public PageLocation getPageLocation(Object paramObject, String paramString, Point paramPoint) throws RemoteException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).getPageLocation(paramObject, paramString, paramPoint);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mailTo(Object paramObject, String paramString1, String paramString2, String paramString3) throws RemoteException, RepletException {
/*     */     try {
/*     */       getRepletRepository(paramObject).mailTo(paramObject, paramString1, paramString2, paramString3);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object export(Object paramObject, int paramInt) throws RemoteException, RepletException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).export(paramObject, paramInt);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] nextBlock(Object paramObject) throws RemoteException, RepletException {
/*     */     try {
/*     */       return getRepletRepository(paramObject).nextBlock(paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String[] getPrinters() throws RemoteException { return this.engine.getPrinters(); }
/*     */   
/*     */   public void print(Object paramObject, String paramString) throws RemoteException, RepletException {
/*     */     try {
/*     */       RepletRepository repletRepository = getRepletRepository(paramObject);
/*     */       RepletPages repletPages = new RepletPages(paramObject, repletRepository);
/*     */       Common.print(paramString, repletPages, false);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } catch (Exception exception) {
/*     */       throw new RepletException(exception.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void destroy(Object paramObject) throws RemoteException {
/*     */     try {
/*     */       getRepletRepository(paramObject).destroy(paramObject);
/*     */     } catch (RemoteException remoteException) {
/*     */       pingSlave(paramObject);
/*     */       throw remoteException;
/*     */     } 
/*     */     String str1 = (String)paramObject;
/*     */     int i = str1.lastIndexOf('@');
/*     */     if (i < 0) {
/*     */       SreeLog.print("Malformatted report ID: " + paramObject);
/*     */       return;
/*     */     } 
/*     */     String str2 = str1.substring(i + 1);
/*     */     for (byte b = 0; b < this.reps.size(); b++) {
/*     */       RepCount repCount = (RepCount)this.reps.elementAt(b);
/*     */       if (repCount.url.equals(str2)) {
/*     */         repCount.count--;
/*     */         byte b1 = 0;
/*     */         for (b1 = b - 1; b1 >= 0; b1--) {
/*     */           RepCount repCount1 = (RepCount)this.reps.elementAt(b);
/*     */           if (repCount.count >= repCount1.count)
/*     */             break; 
/*     */         } 
/*     */         if (b1 + 1 != b) {
/*     */           this.reps.insertElementAt(repCount, b1 + 1);
/*     */           this.reps.removeElementAt(b + 1);
/*     */         } 
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private RepletRepository getRepletRepository(Object paramObject) throws RemoteException {
/*     */     String str = (String)paramObject;
/*     */     int i = str.lastIndexOf('@');
/*     */     if (i < 0)
/*     */       throw new RemoteException("Malformatted report ID: " + paramObject); 
/*     */     RepletRepository repletRepository = (RepletRepository)this.repmap.get(str.substring(i + 1));
/*     */     if (repletRepository == null)
/*     */       throw new RemoteException("Replet Repository is not available"); 
/*     */     return repletRepository;
/*     */   }
/*     */   
/*     */   private void pingSlave(Object paramObject) throws RemoteException {
/*     */     String str1 = (String)paramObject;
/*     */     int i = str1.lastIndexOf('@');
/*     */     if (i < 0)
/*     */       throw new RemoteException("Malformatted report ID: " + paramObject); 
/*     */     String str2 = str1.substring(i + 1);
/*     */     RepletRepository repletRepository = (RepletRepository)this.repmap.get(str2);
/*     */     if (repletRepository instanceof PingableRepository)
/*     */       try {
/*     */         if (((PingableRepository)repletRepository).ping())
/*     */           return; 
/*     */       } catch (Throwable throwable) {
/*     */         SreeLog.print("Repository is not responding: " + str2);
/*     */         remove(str2);
/*     */       }  
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*     */     String str = "MasterRepository";
/*     */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*     */       if (paramArrayOfString[b].startsWith("-url")) {
/*     */         str = paramArrayOfString[++b];
/*     */       } else if (paramArrayOfString[b].startsWith("-ORB")) {
/*     */         CorbaHandler.init(paramArrayOfString, null);
/*     */       } 
/*     */     } 
/*     */     SreeLog.print("Starting Replet repository: " + str);
/*     */     if (System.getSecurityManager() == null)
/*     */       System.setSecurityManager(new RMISecurityManager()); 
/*     */     try {
/*     */       MasterRepository masterRepository = new MasterRepository();
/*     */       Naming.rebind(str, masterRepository);
/*     */       SreeLog.print("RepletRepository bound in registry: " + str);
/*     */     } catch (Exception exception) {
/*     */       SreeLog.print(exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   class RepCount {
/*     */     public String url;
/*     */     public int count;
/*     */     private final MasterRepository this$0;
/*     */     
/*     */     public RepCount(MasterRepository this$0, String param1String, int param1Int) {
/*     */       this.this$0 = this$0;
/*     */       this.count = 0;
/*     */       this.url = param1String;
/*     */       this.count = param1Int;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\cluster\MasterRepository.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */