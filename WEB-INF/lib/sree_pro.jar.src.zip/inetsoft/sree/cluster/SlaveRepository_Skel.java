package inetsoft.sree.cluster;

import inetsoft.report.event.SelectionEvent;
import inetsoft.sree.EventHandler;
import inetsoft.sree.PageLocation;
import inetsoft.sree.RepletParameters;
import inetsoft.sree.RepletRequest;
import inetsoft.sree.SearchCondition;
import java.awt.Point;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.rmi.MarshalException;
import java.rmi.Remote;
import java.rmi.UnmarshalException;
import java.rmi.server.Operation;
import java.rmi.server.RemoteCall;
import java.rmi.server.Skeleton;
import java.rmi.server.SkeletonMismatchException;
import java.util.EventObject;

public final class SlaveRepository_Skel implements Skeleton {
  private static final Operation[] operations = { 
      new Operation("java.lang.Object create(java.lang.String, java.lang.Object)"), new Operation("void destroy(java.lang.Object)"), new Operation("java.lang.Object export(java.lang.Object, int)"), new Operation("inetsoft.sree.PageLocation find(java.lang.Object, inetsoft.sree.SearchCondition, inetsoft.sree.PageLocation)"), new Operation("void generate(java.lang.Object, inetsoft.sree.RepletRequest)"), new Operation("inetsoft.sree.EventHandler getEventHandler(java.lang.Object)"), new Operation("int getEventMask(java.lang.Object)"), new Operation("inetsoft.report.StylePage getPage(java.lang.Object, int)"), new Operation("int getPageCount(java.lang.Object)"), new Operation("inetsoft.sree.PageLocation getPageLocation(java.lang.Object, java.lang.String, java.awt.Point)"), 
      new Operation("java.lang.String getPrinters()[]"), new Operation("inetsoft.report.event.SelectionEvent getRegisteredSelections(java.lang.Object)[]"), new Operation("java.lang.String getRepletNames(java.lang.Object)[]"), new Operation("inetsoft.sree.RepletParameters getRepletParameters(java.lang.Object, java.lang.String)"), new Operation("inetsoft.sree.PageLocation getTOCLocations(java.lang.Object)[]"), new Operation("java.lang.String getTOCPaths(java.lang.Object)[]"), new Operation("inetsoft.sree.RepletCommand handleEvent(java.lang.Object, java.util.EventObject)"), new Operation("void mailTo(java.lang.Object, java.lang.String, java.lang.String, java.lang.String)"), new Operation("byte nextBlock(java.lang.Object)[]"), new Operation("boolean ping()"), 
      new Operation("void print(java.lang.Object, java.lang.String)") };
  
  private static final long interfaceHash = 1611125192970903503L;
  
  public void dispatch(Remote paramRemote, RemoteCall paramRemoteCall, int paramInt, long paramLong) throws Exception {
    int i;
    String str1;
    Object object1;
    Object object3;
    boolean bool;
    Object object2;
    if (paramInt < 0) {
      if (paramLong == -1790019831898905230L) {
        paramInt = 0;
      } else if (paramLong == 727944400545220549L) {
        paramInt = 1;
      } else if (paramLong == -6456634367568685559L) {
        paramInt = 2;
      } else if (paramLong == -8735840020142472033L) {
        paramInt = 3;
      } else if (paramLong == -6635596011196890673L) {
        paramInt = 4;
      } else if (paramLong == -6574545409934069781L) {
        paramInt = 5;
      } else if (paramLong == -5693350595088988331L) {
        paramInt = 6;
      } else if (paramLong == -7455158305430669685L) {
        paramInt = 7;
      } else if (paramLong == 7101141975835072383L) {
        paramInt = 8;
      } else if (paramLong == -294847319861730919L) {
        paramInt = 9;
      } else if (paramLong == 1954972749739203841L) {
        paramInt = 10;
      } else if (paramLong == 4794497489811828693L) {
        paramInt = 11;
      } else if (paramLong == 4005983239363120113L) {
        paramInt = 12;
      } else if (paramLong == 7945634108811962781L) {
        paramInt = 13;
      } else if (paramLong == 1098689123812989454L) {
        paramInt = 14;
      } else if (paramLong == -588741335134556819L) {
        paramInt = 15;
      } else if (paramLong == -9071656322587346031L) {
        paramInt = 16;
      } else if (paramLong == 783181715290693041L) {
        paramInt = 17;
      } else if (paramLong == 8763735659872399781L) {
        paramInt = 18;
      } else if (paramLong == 587447140426392889L) {
        paramInt = 19;
      } else if (paramLong == 8335386151287522138L) {
        paramInt = 20;
      } else {
        throw new UnmarshalException("invalid method hash");
      } 
    } else if (paramLong != 1611125192970903503L) {
      throw new SkeletonMismatchException("interface hash mismatch");
    } 
    SlaveRepository slaveRepository = (SlaveRepository)paramRemote;
    switch (paramInt) {
      case 0:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = (String)objectInput.readObject();
          null = objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.create(object3, null);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
      case 1:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        slaveRepository.destroy(object3);
        try {
          paramRemoteCall.getResultStream(true);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 2:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
          i = objectInput.readInt();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.export(object3, i);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
      case 3:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
          null = (SearchCondition)objectInput.readObject();
          null = (PageLocation)objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.find(object3, null, null);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
      case 4:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
          null = (RepletRequest)objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        slaveRepository.generate(object3, null);
        try {
          paramRemoteCall.getResultStream(true);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
      case 5:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
        } catch (IOException null) {
          throw new UnmarshalException("error unmarshalling arguments", null);
        } catch (ClassNotFoundException null) {
          throw new UnmarshalException("error unmarshalling arguments", null);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.getEventHandler(object3);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
      case 6:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
        } catch (IOException null) {
          throw new UnmarshalException("error unmarshalling arguments", null);
        } catch (ClassNotFoundException null) {
          throw new UnmarshalException("error unmarshalling arguments", null);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        i = slaveRepository.getEventMask(object3);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeInt(i);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
      case 7:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
          i = objectInput.readInt();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.getPage(object3, i);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 8:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
        } catch (IOException null) {
          throw new UnmarshalException("error unmarshalling arguments", null);
        } catch (ClassNotFoundException null) {
          throw new UnmarshalException("error unmarshalling arguments", null);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        i = slaveRepository.getPageCount(object3);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeInt(i);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 9:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object3 = objectInput.readObject();
          null = (String)objectInput.readObject();
          null = (Point)objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        str2 = slaveRepository.getPageLocation(object3, null, null);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(str2);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
      case 10:
        paramRemoteCall.releaseInputStream();
        object2 = slaveRepository.getPrinters();
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(object2);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 11:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object2 = objectInput.readObject();
        } catch (IOException null) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } catch (ClassNotFoundException null) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.getRegisteredSelections(object2);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 12:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object2 = objectInput.readObject();
        } catch (IOException null) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } catch (ClassNotFoundException null) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.getRepletNames(object2);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 13:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object2 = objectInput.readObject();
          null = (String)objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.getRepletParameters(object2, null);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", str2);
        } 
        return;
      case 14:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object2 = objectInput.readObject();
        } catch (IOException null) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } catch (ClassNotFoundException null) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.getTOCLocations(object2);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 15:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object2 = objectInput.readObject();
        } catch (IOException null) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } catch (ClassNotFoundException null) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.getTOCPaths(object2);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 16:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object2 = objectInput.readObject();
          null = (EventObject)objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        null = slaveRepository.handleEvent(object2, null);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(null);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", str2);
        } 
        return;
      case 17:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object2 = objectInput.readObject();
          null = (String)objectInput.readObject();
          null = (String)objectInput.readObject();
          str2 = (String)objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        slaveRepository.mailTo(object2, null, null, str2);
        try {
          paramRemoteCall.getResultStream(true);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
      case 18:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object2 = objectInput.readObject();
        } catch (IOException str2) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } catch (ClassNotFoundException str2) {
          throw new UnmarshalException("error unmarshalling arguments", str2);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        str1 = slaveRepository.nextBlock(object2);
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeObject(str1);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", null);
        } 
        return;
      case 19:
        paramRemoteCall.releaseInputStream();
        bool = slaveRepository.ping();
        try {
          ObjectOutput objectOutput = paramRemoteCall.getResultStream(true);
          objectOutput.writeBoolean(bool);
        } catch (IOException null) {
          throw new MarshalException("error marshalling return", str1);
        } 
        return;
      case 20:
        try {
          ObjectInput objectInput = paramRemoteCall.getInputStream();
          object1 = objectInput.readObject();
          str1 = (String)objectInput.readObject();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } finally {
          paramRemoteCall.releaseInputStream();
        } 
        slaveRepository.print(object1, str1);
        try {
          paramRemoteCall.getResultStream(true);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return;
    } 
    throw new UnmarshalException("invalid method number");
  }
  
  public Operation[] getOperations() { return (Operation[])operations.clone(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\cluster\SlaveRepository_Skel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */