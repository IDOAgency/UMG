package inetsoft.sree.cluster;

import inetsoft.sree.RepletRepository;
import java.rmi.RemoteException;

public interface PingableRepository extends RepletRepository {
  boolean ping() throws RemoteException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\cluster\PingableRepository.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */