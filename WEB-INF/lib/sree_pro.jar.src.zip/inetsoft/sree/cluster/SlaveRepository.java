package inetsoft.sree.cluster;

import inetsoft.report.StylePage;
import inetsoft.report.event.SelectionEvent;
import inetsoft.sree.EventHandler;
import inetsoft.sree.PageLocation;
import inetsoft.sree.RepletCommand;
import inetsoft.sree.RepletEngine;
import inetsoft.sree.RepletException;
import inetsoft.sree.RepletParameters;
import inetsoft.sree.RepletRequest;
import inetsoft.sree.SearchCondition;
import inetsoft.sree.SreeLog;
import inetsoft.uql.corba.CorbaHandler;
import java.awt.Point;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.EventObject;

public class SlaveRepository extends UnicastRemoteObject implements PingableRepository {
  RepletEngine engine;
  
  public SlaveRepository(String paramString) throws RemoteException {
    this.engine = new RepletEngine(paramString);
    this.engine.init();
  }
  
  public boolean ping() throws RemoteException { return true; }
  
  public String[] getRepletNames(Object paramObject) throws RemoteException { return this.engine.getRepletNames(paramObject); }
  
  public Object create(String paramString, Object paramObject) throws RepletException { return this.engine.create(paramString, paramObject); }
  
  public RepletParameters getRepletParameters(Object paramObject, String paramString) throws RemoteException { return this.engine.getRepletParameters(paramObject, paramString); }
  
  public void generate(Object paramObject, RepletRequest paramRepletRequest) throws RepletException, RemoteException { this.engine.generate(paramObject, paramRepletRequest); }
  
  public int getEventMask(Object paramObject) throws RemoteException { return this.engine.getEventMask(paramObject); }
  
  public EventHandler getEventHandler(Object paramObject) throws RemoteException { return this.engine.getEventHandler(paramObject); }
  
  public RepletCommand handleEvent(Object paramObject, EventObject paramEventObject) throws RemoteException { return this.engine.handleEvent(paramObject, paramEventObject); }
  
  public SelectionEvent[] getRegisteredSelections(Object paramObject) { return this.engine.getRegisteredSelections(paramObject); }
  
  public StylePage getPage(Object paramObject, int paramInt) throws RemoteException { return this.engine.getPage(paramObject, paramInt); }
  
  public int getPageCount(Object paramObject) throws RemoteException { return this.engine.getPageCount(paramObject); }
  
  public PageLocation find(Object paramObject, SearchCondition paramSearchCondition, PageLocation paramPageLocation) throws RemoteException { return this.engine.find(paramObject, paramSearchCondition, paramPageLocation); }
  
  public String[] getTOCPaths(Object paramObject) throws RemoteException { return this.engine.getTOCPaths(paramObject); }
  
  public PageLocation[] getTOCLocations(Object paramObject) throws RemoteException { return this.engine.getTOCLocations(paramObject); }
  
  public PageLocation getPageLocation(Object paramObject, String paramString, Point paramPoint) throws RemoteException { return this.engine.getPageLocation(paramObject, paramString, paramPoint); }
  
  public void mailTo(Object paramObject, String paramString1, String paramString2, String paramString3) throws RemoteException, RepletException { this.engine.mailTo(paramObject, paramString1, paramString2, paramString3); }
  
  public Object export(Object paramObject, int paramInt) throws RemoteException, RepletException { return this.engine.export(paramObject, paramInt); }
  
  public byte[] nextBlock(Object paramObject) throws RemoteException, RepletException { return this.engine.nextBlock(paramObject); }
  
  public String[] getPrinters() throws RemoteException { return this.engine.getPrinters(); }
  
  public void print(Object paramObject, String paramString) throws RemoteException, RepletException { this.engine.print(paramObject, paramString); }
  
  public void destroy(Object paramObject) throws RemoteException { this.engine.destroy(paramObject); }
  
  public static void main(String[] paramArrayOfString) {
    String str1 = "SlaveRepository";
    String str2 = "//localhost/MasterRepository";
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramArrayOfString[b].startsWith("-url")) {
        str1 = paramArrayOfString[++b];
      } else if (paramArrayOfString[b].startsWith("-master")) {
        str2 = paramArrayOfString[++b];
      } else if (paramArrayOfString[b].startsWith("-ORB")) {
        CorbaHandler.init(paramArrayOfString, null);
      } 
    } 
    SreeLog.print("Starting Replet repository: " + str1);
    if (System.getSecurityManager() == null)
      System.setSecurityManager(new RMISecurityManager()); 
    RepositoryRegistry repositoryRegistry = null;
    try {
      repositoryRegistry = (RepositoryRegistry)Naming.lookup(str2);
      if (repositoryRegistry == null)
        SreeLog.print("Repository registry not available"); 
      SlaveRepository slaveRepository = new SlaveRepository(str1);
      Naming.rebind(str1, slaveRepository);
      repositoryRegistry.register(str1);
      SreeLog.print("RepletRepository bound in registry: " + str1);
    } catch (Exception exception) {
      SreeLog.print(exception);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\cluster\SlaveRepository.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */