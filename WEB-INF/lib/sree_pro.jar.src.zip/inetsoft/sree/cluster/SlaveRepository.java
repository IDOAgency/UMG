/*     */ package inetsoft.sree.cluster;
/*     */ 
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.event.SelectionEvent;
/*     */ import inetsoft.sree.EventHandler;
/*     */ import inetsoft.sree.PageLocation;
/*     */ import inetsoft.sree.RepletCommand;
/*     */ import inetsoft.sree.RepletEngine;
/*     */ import inetsoft.sree.RepletException;
/*     */ import inetsoft.sree.RepletParameters;
/*     */ import inetsoft.sree.RepletRequest;
/*     */ import inetsoft.sree.SearchCondition;
/*     */ import inetsoft.sree.SreeLog;
/*     */ import inetsoft.uql.corba.CorbaHandler;
/*     */ import java.awt.Point;
/*     */ import java.rmi.Naming;
/*     */ import java.rmi.RMISecurityManager;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ import java.util.EventObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SlaveRepository
/*     */   extends UnicastRemoteObject
/*     */   implements PingableRepository
/*     */ {
/*     */   RepletEngine engine;
/*     */   
/*     */   public SlaveRepository(String paramString) throws RemoteException {
/*  41 */     this.engine = new RepletEngine(paramString);
/*  42 */     this.engine.init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public boolean ping() throws RemoteException { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public String[] getRepletNames(Object paramObject) throws RemoteException { return this.engine.getRepletNames(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public Object create(String paramString, Object paramObject) throws RepletException { return this.engine.create(paramString, paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public RepletParameters getRepletParameters(Object paramObject, String paramString) throws RemoteException { return this.engine.getRepletParameters(paramObject, paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public void generate(Object paramObject, RepletRequest paramRepletRequest) throws RepletException, RemoteException { this.engine.generate(paramObject, paramRepletRequest); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public int getEventMask(Object paramObject) throws RemoteException { return this.engine.getEventMask(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public EventHandler getEventHandler(Object paramObject) throws RemoteException { return this.engine.getEventHandler(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public RepletCommand handleEvent(Object paramObject, EventObject paramEventObject) throws RemoteException { return this.engine.handleEvent(paramObject, paramEventObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public SelectionEvent[] getRegisteredSelections(Object paramObject) { return this.engine.getRegisteredSelections(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public StylePage getPage(Object paramObject, int paramInt) throws RemoteException { return this.engine.getPage(paramObject, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public int getPageCount(Object paramObject) throws RemoteException { return this.engine.getPageCount(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public PageLocation find(Object paramObject, SearchCondition paramSearchCondition, PageLocation paramPageLocation) throws RemoteException { return this.engine.find(paramObject, paramSearchCondition, paramPageLocation); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public String[] getTOCPaths(Object paramObject) throws RemoteException { return this.engine.getTOCPaths(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public PageLocation[] getTOCLocations(Object paramObject) throws RemoteException { return this.engine.getTOCLocations(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public PageLocation getPageLocation(Object paramObject, String paramString, Point paramPoint) throws RemoteException { return this.engine.getPageLocation(paramObject, paramString, paramPoint); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   public void mailTo(Object paramObject, String paramString1, String paramString2, String paramString3) throws RemoteException, RepletException { this.engine.mailTo(paramObject, paramString1, paramString2, paramString3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public Object export(Object paramObject, int paramInt) throws RemoteException, RepletException { return this.engine.export(paramObject, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 243 */   public byte[] nextBlock(Object paramObject) throws RemoteException, RepletException { return this.engine.nextBlock(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   public String[] getPrinters() throws RemoteException { return this.engine.getPrinters(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   public void print(Object paramObject, String paramString) throws RemoteException, RepletException { this.engine.print(paramObject, paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 271 */   public void destroy(Object paramObject) throws RemoteException { this.engine.destroy(paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 283 */     String str1 = "SlaveRepository";
/* 284 */     String str2 = "//localhost/MasterRepository";
/*     */     
/* 286 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 287 */       if (paramArrayOfString[b].startsWith("-url")) {
/* 288 */         str1 = paramArrayOfString[++b];
/*     */       }
/* 290 */       else if (paramArrayOfString[b].startsWith("-master")) {
/* 291 */         str2 = paramArrayOfString[++b];
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 296 */       else if (paramArrayOfString[b].startsWith("-ORB")) {
/* 297 */         CorbaHandler.init(paramArrayOfString, null);
/*     */       } 
/*     */     } 
/*     */     
/* 301 */     SreeLog.print("Starting Replet repository: " + str1);
/*     */ 
/*     */     
/* 304 */     if (System.getSecurityManager() == null) {
/* 305 */       System.setSecurityManager(new RMISecurityManager());
/*     */     }
/*     */     
/* 308 */     RepositoryRegistry repositoryRegistry = null;
/*     */     try {
/* 310 */       repositoryRegistry = (RepositoryRegistry)Naming.lookup(str2);
/* 311 */       if (repositoryRegistry == null) {
/* 312 */         SreeLog.print("Repository registry not available");
/*     */       }
/*     */ 
/*     */       
/* 316 */       SlaveRepository slaveRepository = new SlaveRepository(str1);
/* 317 */       Naming.rebind(str1, slaveRepository);
/*     */       
/* 319 */       repositoryRegistry.register(str1);
/*     */       
/* 321 */       SreeLog.print("RepletRepository bound in registry: " + str1);
/*     */     } catch (Exception exception) {
/* 323 */       SreeLog.print(exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\cluster\SlaveRepository.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */