package inetsoft.sree.cluster;

import inetsoft.report.StylePage;
import inetsoft.report.event.SelectionEvent;
import inetsoft.sree.EventHandler;
import inetsoft.sree.PageLocation;
import inetsoft.sree.RepletCommand;
import inetsoft.sree.RepletException;
import inetsoft.sree.RepletParameters;
import inetsoft.sree.RepletRequest;
import inetsoft.sree.SearchCondition;
import java.awt.Point;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.lang.reflect.Method;
import java.rmi.MarshalException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.UnexpectedException;
import java.rmi.UnmarshalException;
import java.rmi.server.Operation;
import java.rmi.server.RemoteCall;
import java.rmi.server.RemoteRef;
import java.rmi.server.RemoteStub;
import java.util.EventObject;

public final class SlaveRepository_Stub extends RemoteStub implements PingableRepository, Remote {
  private static final Operation[] operations = { 
      new Operation("java.lang.Object create(java.lang.String, java.lang.Object)"), new Operation("void destroy(java.lang.Object)"), new Operation("java.lang.Object export(java.lang.Object, int)"), new Operation("inetsoft.sree.PageLocation find(java.lang.Object, inetsoft.sree.SearchCondition, inetsoft.sree.PageLocation)"), new Operation("void generate(java.lang.Object, inetsoft.sree.RepletRequest)"), new Operation("inetsoft.sree.EventHandler getEventHandler(java.lang.Object)"), new Operation("int getEventMask(java.lang.Object)"), new Operation("inetsoft.report.StylePage getPage(java.lang.Object, int)"), new Operation("int getPageCount(java.lang.Object)"), new Operation("inetsoft.sree.PageLocation getPageLocation(java.lang.Object, java.lang.String, java.awt.Point)"), 
      new Operation("java.lang.String getPrinters()[]"), new Operation("inetsoft.report.event.SelectionEvent getRegisteredSelections(java.lang.Object)[]"), new Operation("java.lang.String getRepletNames(java.lang.Object)[]"), new Operation("inetsoft.sree.RepletParameters getRepletParameters(java.lang.Object, java.lang.String)"), new Operation("inetsoft.sree.PageLocation getTOCLocations(java.lang.Object)[]"), new Operation("java.lang.String getTOCPaths(java.lang.Object)[]"), new Operation("inetsoft.sree.RepletCommand handleEvent(java.lang.Object, java.util.EventObject)"), new Operation("void mailTo(java.lang.Object, java.lang.String, java.lang.String, java.lang.String)"), new Operation("byte nextBlock(java.lang.Object)[]"), new Operation("boolean ping()"), 
      new Operation("void print(java.lang.Object, java.lang.String)") };
  
  private static final long interfaceHash = 1611125192970903503L;
  
  private static final long serialVersionUID = 2L;
  
  private static boolean useNewInvoke;
  
  private static Method $method_create_0;
  
  private static Method $method_destroy_1;
  
  private static Method $method_export_2;
  
  private static Method $method_find_3;
  
  private static Method $method_generate_4;
  
  private static Method $method_getEventHandler_5;
  
  private static Method $method_getEventMask_6;
  
  private static Method $method_getPage_7;
  
  private static Method $method_getPageCount_8;
  
  private static Method $method_getPageLocation_9;
  
  private static Method $method_getPrinters_10;
  
  private static Method $method_getRegisteredSelections_11;
  
  private static Method $method_getRepletNames_12;
  
  private static Method $method_getRepletParameters_13;
  
  private static Method $method_getTOCLocations_14;
  
  private static Method $method_getTOCPaths_15;
  
  private static Method $method_handleEvent_16;
  
  private static Method $method_mailTo_17;
  
  private static Method $method_nextBlock_18;
  
  private static Method $method_ping_19;
  
  private static Method $method_print_20;
  
  static Class array$Ljava$lang$Object;
  
  static  {
    try {
      RemoteRef.class.getMethod("invoke", new Class[] { Remote.class, Method.class, (array$Ljava$lang$Object != null) ? array$Ljava$lang$Object : (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")), long.class });
      useNewInvoke = true;
      $method_create_0 = inetsoft.sree.RepletRepository.class.getMethod("create", new Class[] { String.class, Object.class });
      $method_destroy_1 = inetsoft.sree.RepletRepository.class.getMethod("destroy", new Class[] { Object.class });
      $method_export_2 = inetsoft.sree.RepletRepository.class.getMethod("export", new Class[] { Object.class, int.class });
      $method_find_3 = inetsoft.sree.RepletRepository.class.getMethod("find", new Class[] { Object.class, SearchCondition.class, PageLocation.class });
      $method_generate_4 = inetsoft.sree.RepletRepository.class.getMethod("generate", new Class[] { Object.class, RepletRequest.class });
      $method_getEventHandler_5 = inetsoft.sree.RepletRepository.class.getMethod("getEventHandler", new Class[] { Object.class });
      $method_getEventMask_6 = inetsoft.sree.RepletRepository.class.getMethod("getEventMask", new Class[] { Object.class });
      $method_getPage_7 = inetsoft.sree.RepletRepository.class.getMethod("getPage", new Class[] { Object.class, int.class });
      $method_getPageCount_8 = inetsoft.sree.RepletRepository.class.getMethod("getPageCount", new Class[] { Object.class });
      $method_getPageLocation_9 = inetsoft.sree.RepletRepository.class.getMethod("getPageLocation", new Class[] { Object.class, String.class, Point.class });
      $method_getPrinters_10 = inetsoft.sree.RepletRepository.class.getMethod("getPrinters", new Class[0]);
      $method_getRegisteredSelections_11 = inetsoft.sree.RepletRepository.class.getMethod("getRegisteredSelections", new Class[] { Object.class });
      $method_getRepletNames_12 = inetsoft.sree.RepletRepository.class.getMethod("getRepletNames", new Class[] { Object.class });
      $method_getRepletParameters_13 = inetsoft.sree.RepletRepository.class.getMethod("getRepletParameters", new Class[] { Object.class, String.class });
      $method_getTOCLocations_14 = inetsoft.sree.RepletRepository.class.getMethod("getTOCLocations", new Class[] { Object.class });
      $method_getTOCPaths_15 = inetsoft.sree.RepletRepository.class.getMethod("getTOCPaths", new Class[] { Object.class });
      $method_handleEvent_16 = inetsoft.sree.RepletRepository.class.getMethod("handleEvent", new Class[] { Object.class, EventObject.class });
      $method_mailTo_17 = inetsoft.sree.RepletRepository.class.getMethod("mailTo", new Class[] { Object.class, String.class, String.class, String.class });
      $method_nextBlock_18 = inetsoft.sree.RepletRepository.class.getMethod("nextBlock", new Class[] { Object.class });
      $method_ping_19 = PingableRepository.class.getMethod("ping", new Class[0]);
      $method_print_20 = inetsoft.sree.RepletRepository.class.getMethod("print", new Class[] { Object.class, String.class });
    } catch (NoSuchMethodException noSuchMethodException) {
      useNewInvoke = false;
    } 
  }
  
  public SlaveRepository_Stub() {}
  
  public SlaveRepository_Stub(RemoteRef paramRemoteRef) { super(paramRemoteRef); }
  
  public Object create(String paramString, Object paramObject) throws RepletException, RemoteException {
    try {
      Object object;
      if (useNewInvoke)
        return this.ref.invoke(this, $method_create_0, new Object[] { paramString, paramObject }, -1790019831898905230L); 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 0, 1611125192970903503L);
      try {
        object = remoteCall.getOutputStream();
        object.writeObject(paramString);
        object.writeObject(paramObject);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", object);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        object = objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return object;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (RepletException repletException) {
      throw repletException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public void destroy(Object paramObject) throws RemoteException {
    try {
      if (useNewInvoke) {
        this.ref.invoke(this, $method_destroy_1, new Object[] { paramObject }, 727944400545220549L);
      } else {
        RemoteCall remoteCall = this.ref.newCall(this, operations, 1, 1611125192970903503L);
        try {
          ObjectOutput objectOutput = remoteCall.getOutputStream();
          objectOutput.writeObject(paramObject);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling arguments", iOException);
        } 
        this.ref.invoke(remoteCall);
        this.ref.done(remoteCall);
      } 
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public Object export(Object paramObject, int paramInt) throws RepletException, RemoteException {
    try {
      Object object;
      if (useNewInvoke)
        return this.ref.invoke(this, $method_export_2, new Object[] { paramObject, new Integer(paramInt) }, -6456634367568685559L); 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 2, 1611125192970903503L);
      try {
        object = remoteCall.getOutputStream();
        object.writeObject(paramObject);
        object.writeInt(paramInt);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", object);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        object = objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return object;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (RepletException repletException) {
      throw repletException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public PageLocation find(Object paramObject, SearchCondition paramSearchCondition, PageLocation paramPageLocation) throws RemoteException {
    try {
      PageLocation pageLocation;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_find_3, new Object[] { paramObject, paramSearchCondition, paramPageLocation }, -8735840020142472033L);
        return (PageLocation)object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 3, 1611125192970903503L);
      try {
        pageLocation = remoteCall.getOutputStream();
        pageLocation.writeObject(paramObject);
        pageLocation.writeObject(paramSearchCondition);
        pageLocation.writeObject(paramPageLocation);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", pageLocation);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        pageLocation = (PageLocation)objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return pageLocation;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public void generate(Object paramObject, RepletRequest paramRepletRequest) throws RepletException, RemoteException {
    try {
      if (useNewInvoke) {
        this.ref.invoke(this, $method_generate_4, new Object[] { paramObject, paramRepletRequest }, -6635596011196890673L);
      } else {
        RemoteCall remoteCall = this.ref.newCall(this, operations, 4, 1611125192970903503L);
        try {
          ObjectOutput objectOutput = remoteCall.getOutputStream();
          objectOutput.writeObject(paramObject);
          objectOutput.writeObject(paramRepletRequest);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling arguments", iOException);
        } 
        this.ref.invoke(remoteCall);
        this.ref.done(remoteCall);
      } 
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (RepletException repletException) {
      throw repletException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public EventHandler getEventHandler(Object paramObject) throws RemoteException {
    try {
      EventHandler eventHandler;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getEventHandler_5, new Object[] { paramObject }, -6574545409934069781L);
        return (EventHandler)object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 5, 1611125192970903503L);
      try {
        eventHandler = remoteCall.getOutputStream();
        eventHandler.writeObject(paramObject);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", eventHandler);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        eventHandler = (EventHandler)objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return eventHandler;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public int getEventMask(Object paramObject) throws RemoteException {
    try {
      int i;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getEventMask_6, new Object[] { paramObject }, -5693350595088988331L);
        return ((Integer)object).intValue();
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 6, 1611125192970903503L);
      try {
        ObjectOutput objectOutput = remoteCall.getOutputStream();
        objectOutput.writeObject(paramObject);
      } catch (IOException iOException) {
        throw new MarshalException("error marshalling arguments", iOException);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        i = objectInput.readInt();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return i;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public StylePage getPage(Object paramObject, int paramInt) throws RemoteException {
    try {
      StylePage stylePage;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getPage_7, new Object[] { paramObject, new Integer(paramInt) }, -7455158305430669685L);
        return (StylePage)object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 7, 1611125192970903503L);
      try {
        stylePage = remoteCall.getOutputStream();
        stylePage.writeObject(paramObject);
        stylePage.writeInt(paramInt);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", stylePage);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        stylePage = (StylePage)objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return stylePage;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public int getPageCount(Object paramObject) throws RemoteException {
    try {
      int i;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getPageCount_8, new Object[] { paramObject }, 7101141975835072383L);
        return ((Integer)object).intValue();
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 8, 1611125192970903503L);
      try {
        ObjectOutput objectOutput = remoteCall.getOutputStream();
        objectOutput.writeObject(paramObject);
      } catch (IOException iOException) {
        throw new MarshalException("error marshalling arguments", iOException);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        i = objectInput.readInt();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return i;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public PageLocation getPageLocation(Object paramObject, String paramString, Point paramPoint) throws RemoteException {
    try {
      PageLocation pageLocation;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getPageLocation_9, new Object[] { paramObject, paramString, paramPoint }, -294847319861730919L);
        return (PageLocation)object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 9, 1611125192970903503L);
      try {
        pageLocation = remoteCall.getOutputStream();
        pageLocation.writeObject(paramObject);
        pageLocation.writeObject(paramString);
        pageLocation.writeObject(paramPoint);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", pageLocation);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        pageLocation = (PageLocation)objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return pageLocation;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public String[] getPrinters() throws RemoteException {
    try {
      String[] arrayOfString;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getPrinters_10, null, 1954972749739203841L);
        return (String[])object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 10, 1611125192970903503L);
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        arrayOfString = (String[])objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return arrayOfString;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public SelectionEvent[] getRegisteredSelections(Object paramObject) throws RemoteException {
    try {
      SelectionEvent[] arrayOfSelectionEvent;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getRegisteredSelections_11, new Object[] { paramObject }, 4794497489811828693L);
        return (SelectionEvent[])object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 11, 1611125192970903503L);
      try {
        arrayOfSelectionEvent = remoteCall.getOutputStream();
        arrayOfSelectionEvent.writeObject(paramObject);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", arrayOfSelectionEvent);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        arrayOfSelectionEvent = (SelectionEvent[])objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return arrayOfSelectionEvent;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public String[] getRepletNames(Object paramObject) throws RemoteException {
    try {
      String[] arrayOfString;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getRepletNames_12, new Object[] { paramObject }, 4005983239363120113L);
        return (String[])object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 12, 1611125192970903503L);
      try {
        arrayOfString = remoteCall.getOutputStream();
        arrayOfString.writeObject(paramObject);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", arrayOfString);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        arrayOfString = (String[])objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return arrayOfString;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public RepletParameters getRepletParameters(Object paramObject, String paramString) throws RemoteException {
    try {
      RepletParameters repletParameters;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getRepletParameters_13, new Object[] { paramObject, paramString }, 7945634108811962781L);
        return (RepletParameters)object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 13, 1611125192970903503L);
      try {
        repletParameters = remoteCall.getOutputStream();
        repletParameters.writeObject(paramObject);
        repletParameters.writeObject(paramString);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", repletParameters);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        repletParameters = (RepletParameters)objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return repletParameters;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public PageLocation[] getTOCLocations(Object paramObject) throws RemoteException {
    try {
      PageLocation[] arrayOfPageLocation;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getTOCLocations_14, new Object[] { paramObject }, 1098689123812989454L);
        return (PageLocation[])object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 14, 1611125192970903503L);
      try {
        arrayOfPageLocation = remoteCall.getOutputStream();
        arrayOfPageLocation.writeObject(paramObject);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", arrayOfPageLocation);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        arrayOfPageLocation = (PageLocation[])objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return arrayOfPageLocation;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public String[] getTOCPaths(Object paramObject) throws RemoteException {
    try {
      String[] arrayOfString;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_getTOCPaths_15, new Object[] { paramObject }, -588741335134556819L);
        return (String[])object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 15, 1611125192970903503L);
      try {
        arrayOfString = remoteCall.getOutputStream();
        arrayOfString.writeObject(paramObject);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", arrayOfString);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        arrayOfString = (String[])objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return arrayOfString;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public RepletCommand handleEvent(Object paramObject, EventObject paramEventObject) throws RemoteException {
    try {
      RepletCommand repletCommand;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_handleEvent_16, new Object[] { paramObject, paramEventObject }, -9071656322587346031L);
        return (RepletCommand)object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 16, 1611125192970903503L);
      try {
        repletCommand = remoteCall.getOutputStream();
        repletCommand.writeObject(paramObject);
        repletCommand.writeObject(paramEventObject);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", repletCommand);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        repletCommand = (RepletCommand)objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return repletCommand;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public void mailTo(Object paramObject, String paramString1, String paramString2, String paramString3) throws RepletException, RemoteException {
    try {
      if (useNewInvoke) {
        this.ref.invoke(this, $method_mailTo_17, new Object[] { paramObject, paramString1, paramString2, paramString3 }, 783181715290693041L);
      } else {
        RemoteCall remoteCall = this.ref.newCall(this, operations, 17, 1611125192970903503L);
        try {
          ObjectOutput objectOutput = remoteCall.getOutputStream();
          objectOutput.writeObject(paramObject);
          objectOutput.writeObject(paramString1);
          objectOutput.writeObject(paramString2);
          objectOutput.writeObject(paramString3);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling arguments", iOException);
        } 
        this.ref.invoke(remoteCall);
        this.ref.done(remoteCall);
      } 
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (RepletException repletException) {
      throw repletException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public byte[] nextBlock(Object paramObject) throws RepletException, RemoteException {
    try {
      byte[] arrayOfByte;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_nextBlock_18, new Object[] { paramObject }, 8763735659872399781L);
        return (byte[])object;
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 18, 1611125192970903503L);
      try {
        arrayOfByte = remoteCall.getOutputStream();
        arrayOfByte.writeObject(paramObject);
      } catch (IOException null) {
        throw new MarshalException("error marshalling arguments", arrayOfByte);
      } 
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        arrayOfByte = (byte[])objectInput.readObject();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } catch (ClassNotFoundException classNotFoundException) {
        throw new UnmarshalException("error unmarshalling return", classNotFoundException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return arrayOfByte;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (RepletException repletException) {
      throw repletException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public boolean ping() throws RemoteException {
    try {
      boolean bool;
      if (useNewInvoke) {
        Object object = this.ref.invoke(this, $method_ping_19, null, 587447140426392889L);
        return ((Boolean)object).booleanValue();
      } 
      RemoteCall remoteCall = this.ref.newCall(this, operations, 19, 1611125192970903503L);
      this.ref.invoke(remoteCall);
      try {
        ObjectInput objectInput = remoteCall.getInputStream();
        bool = objectInput.readBoolean();
      } catch (IOException iOException) {
        throw new UnmarshalException("error unmarshalling return", iOException);
      } finally {
        this.ref.done(remoteCall);
      } 
      return bool;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
  
  public void print(Object paramObject, String paramString) throws RepletException, RemoteException {
    try {
      if (useNewInvoke) {
        this.ref.invoke(this, $method_print_20, new Object[] { paramObject, paramString }, 8335386151287522138L);
      } else {
        RemoteCall remoteCall = this.ref.newCall(this, operations, 20, 1611125192970903503L);
        try {
          ObjectOutput objectOutput = remoteCall.getOutputStream();
          objectOutput.writeObject(paramObject);
          objectOutput.writeObject(paramString);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling arguments", iOException);
        } 
        this.ref.invoke(remoteCall);
        this.ref.done(remoteCall);
      } 
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (RepletException repletException) {
      throw repletException;
    } catch (Exception exception) {
      throw new UnexpectedException("undeclared checked exception", exception);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\cluster\SlaveRepository_Stub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */