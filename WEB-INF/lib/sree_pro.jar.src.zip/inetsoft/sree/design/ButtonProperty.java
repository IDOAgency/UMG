/*    */ package inetsoft.sree.design;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.design.DesignView;
/*    */ import inetsoft.report.internal.ButtonElementDef;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ButtonProperty
/*    */   extends FieldProperty
/*    */ {
/*    */   ButtonElementDef elem;
/*    */   JTextField labelTF;
/*    */   
/*    */   public ButtonProperty(DesignView paramDesignView) {
/* 36 */     super(paramDesignView, Catalog.getString("Button"));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     this.labelTF = new JTextField(15);
/*    */     this.pane.add(Catalog.getString("Button"), new Object[][] { { Catalog.getString("Label") + ":", this.labelTF } });
/*    */   }
/*    */   
/*    */   public void setElement(ReportElement paramReportElement) {
/*    */     super.setElement(paramReportElement);
/*    */     this.elem = (ButtonElementDef)paramReportElement;
/*    */     this.labelTF.setText(this.elem.getText());
/*    */   }
/*    */   
/*    */   public boolean populateElement() {
/*    */     if (!super.populateElement())
/*    */       return false; 
/*    */     this.elem.setText(this.labelTF.getText());
/*    */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\design\ButtonProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */