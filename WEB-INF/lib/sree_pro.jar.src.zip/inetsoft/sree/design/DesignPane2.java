/*     */ package inetsoft.sree.design;
/*     */ 
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.design.DesignPane;
/*     */ import inetsoft.report.design.PropertyDialog;
/*     */ import inetsoft.report.design.SectionInsertMenu;
/*     */ import inetsoft.report.internal.ButtonElementDef;
/*     */ import inetsoft.report.internal.CheckBoxElementDef;
/*     */ import inetsoft.report.internal.ChoiceElementDef;
/*     */ import inetsoft.report.internal.ImageButtonElementDef;
/*     */ import inetsoft.report.internal.RadioButtonElementDef;
/*     */ import inetsoft.report.internal.ScriptEnv;
/*     */ import inetsoft.report.internal.TextAreaElementDef;
/*     */ import inetsoft.report.internal.TextFieldElementDef;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.sree.BasicReplet;
/*     */ import inetsoft.sree.RepletRequest;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JMenuItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DesignPane2
/*     */   extends DesignPane
/*     */ {
/*     */   ActionListener buttonListener;
/*     */   ActionListener ibuttonListener;
/*     */   ActionListener checkBoxListener;
/*     */   ActionListener choiceListener;
/*     */   ActionListener radioListener;
/*     */   ActionListener textFieldListener;
/*     */   ActionListener textAreaListener;
/*     */   JMenuItem buttonSecM;
/*     */   JMenuItem ibuttonSecM;
/*     */   JMenuItem checkBoxSecM;
/*     */   JMenuItem choiceSecM;
/*     */   JMenuItem radioSecM;
/*     */   JMenuItem textFieldSecM;
/*     */   JMenuItem textAreaSecM;
/*     */   
/*     */   public DesignPane2() {
/* 269 */     this.buttonListener = new ActionListener(this)
/*     */       {
/* 271 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insertButton(true); }
/*     */         
/*     */         private final DesignPane2 this$0;
/*     */       };
/* 275 */     this.ibuttonListener = new ActionListener(this)
/*     */       {
/* 277 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insertImageButton(true); }
/*     */         
/*     */         private final DesignPane2 this$0;
/*     */       };
/* 281 */     this.checkBoxListener = new ActionListener(this)
/*     */       {
/* 283 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insertCheckBox(true); }
/*     */         
/*     */         private final DesignPane2 this$0;
/*     */       };
/* 287 */     this.choiceListener = new ActionListener(this)
/*     */       {
/* 289 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insertChoice(true); }
/*     */         
/*     */         private final DesignPane2 this$0;
/*     */       };
/* 293 */     this.radioListener = new ActionListener(this)
/*     */       {
/* 295 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insertRadioButton(true); }
/*     */         
/*     */         private final DesignPane2 this$0;
/*     */       };
/* 299 */     this.textFieldListener = new ActionListener(this)
/*     */       {
/* 301 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insertTextField(true); }
/*     */         
/*     */         private final DesignPane2 this$0;
/*     */       };
/* 305 */     this.textAreaListener = new ActionListener(this)
/*     */       {
/* 307 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insertTextArea(true); }
/*     */         
/*     */         private final DesignPane2 this$0;
/*     */       };
/*     */     this.sectionInsertM.addSeparator();
/*     */     SectionInsertMenu sectionInsertMenu = this.sectionInsertM;
/*     */     sectionInsertMenu.add(this.buttonSecM = new JMenuItem(Catalog.getString("Button")));
/*     */     this.buttonSecM.setMnemonic('B');
/*     */     this.buttonSecM.addActionListener(this.buttonListener);
/*     */     sectionInsertMenu.add(this.ibuttonSecM = new JMenuItem(Catalog.getString("ImageButton")));
/*     */     this.ibuttonSecM.setMnemonic('I');
/*     */     this.ibuttonSecM.addActionListener(this.ibuttonListener);
/*     */     sectionInsertMenu.add(this.checkBoxSecM = new JMenuItem(Catalog.getString("CheckBox")));
/*     */     this.checkBoxSecM.setMnemonic('C');
/*     */     this.checkBoxSecM.addActionListener(this.checkBoxListener);
/*     */     sectionInsertMenu.add(this.radioSecM = new JMenuItem(Catalog.getString("RadioButton")));
/*     */     this.radioSecM.setMnemonic('R');
/*     */     this.radioSecM.addActionListener(this.radioListener);
/*     */     sectionInsertMenu.add(this.choiceSecM = new JMenuItem(Catalog.getString("Choice")));
/*     */     this.choiceSecM.setMnemonic('o');
/*     */     this.choiceSecM.addActionListener(this.choiceListener);
/*     */     sectionInsertMenu.add(this.textFieldSecM = new JMenuItem(Catalog.getString("TextField")));
/*     */     this.textFieldSecM.setMnemonic('T');
/*     */     this.textFieldSecM.addActionListener(this.textFieldListener);
/*     */     sectionInsertMenu.add(this.textAreaSecM = new JMenuItem(Catalog.getString("TextArea")));
/*     */     this.textAreaSecM.setMnemonic('A');
/*     */     this.textAreaSecM.addActionListener(this.textAreaListener);
/*     */   }
/*     */   
/*     */   public void print(StyleSheet paramStyleSheet) {
/*     */     ScriptEnv scriptEnv = paramStyleSheet.getScriptEnv();
/*     */     if (scriptEnv != null)
/*     */       scriptEnv.put("replet", new BasicReplet(this, paramStyleSheet) {
/*     */             private final StyleSheet val$sheet;
/*     */             private final DesignPane2 this$0;
/*     */             
/*     */             public StyleSheet createReport(RepletRequest param1RepletRequest) { return this.val$sheet; }
/*     */           }); 
/*     */     super.print(paramStyleSheet);
/*     */   }
/*     */   
/*     */   public void insertButton(boolean paramBoolean) {
/*     */     ButtonElementDef buttonElementDef = new ButtonElementDef(this.sheet, "Form", "Submit", "Submit");
/*     */     buttonElementDef.setName(buttonElementDef.getID());
/*     */     if (paramBoolean) {
/*     */       insert(buttonElementDef, paramBoolean);
/*     */     } else {
/*     */       ButtonProperty buttonProperty = new ButtonProperty(this);
/*     */       buttonProperty.show(buttonElementDef, Catalog.getString("Button"), new ActionListener(this, buttonElementDef, paramBoolean) {
/*     */             private final ButtonElementDef val$comp;
/*     */             private final boolean val$section;
/*     */             private final DesignPane2 this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$comp, this.val$section); }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void insertImageButton(boolean paramBoolean) {
/*     */     ImageButtonElementDef imageButtonElementDef = new ImageButtonElementDef(this.sheet, "Form", "Submit");
/*     */     imageButtonElementDef.setName(imageButtonElementDef.getID());
/*     */     if (paramBoolean) {
/*     */       insert(imageButtonElementDef, paramBoolean);
/*     */     } else {
/*     */       ImageButtonProperty imageButtonProperty = new ImageButtonProperty(this);
/*     */       imageButtonProperty.show(imageButtonElementDef, Catalog.getString("ImageButton"), new ActionListener(this, imageButtonElementDef, paramBoolean) {
/*     */             private final ImageButtonElementDef val$comp;
/*     */             private final boolean val$section;
/*     */             private final DesignPane2 this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$comp, this.val$section); }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void insertCheckBox(boolean paramBoolean) {
/*     */     CheckBoxElementDef checkBoxElementDef = new CheckBoxElementDef(this.sheet, "Form", "CheckBox", "CheckBox", false);
/*     */     checkBoxElementDef.setName(checkBoxElementDef.getID());
/*     */     if (paramBoolean) {
/*     */       insert(checkBoxElementDef, paramBoolean);
/*     */     } else {
/*     */       CheckBoxProperty checkBoxProperty = new CheckBoxProperty(this);
/*     */       checkBoxProperty.show(checkBoxElementDef, Catalog.getString("CheckBox"), new ActionListener(this, checkBoxElementDef, paramBoolean) {
/*     */             private final CheckBoxElementDef val$comp;
/*     */             private final boolean val$section;
/*     */             private final DesignPane2 this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$comp, this.val$section); }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void insertRadioButton(boolean paramBoolean) {
/*     */     RadioButtonElementDef radioButtonElementDef = new RadioButtonElementDef(this.sheet, "Form", "RadioButton", "RadioButton", false, "Group");
/*     */     radioButtonElementDef.setName(radioButtonElementDef.getID());
/*     */     if (paramBoolean) {
/*     */       insert(radioButtonElementDef, paramBoolean);
/*     */     } else {
/*     */       RadioButtonProperty radioButtonProperty = new RadioButtonProperty(this);
/*     */       radioButtonProperty.show(radioButtonElementDef, Catalog.getString("RadioButton"), new ActionListener(this, radioButtonElementDef, paramBoolean) {
/*     */             private final RadioButtonElementDef val$comp;
/*     */             private final boolean val$section;
/*     */             private final DesignPane2 this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$comp, this.val$section); }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void insertChoice(boolean paramBoolean) {
/*     */     ChoiceElementDef choiceElementDef = new ChoiceElementDef(this.sheet, "Form", "Choice", null, new String[0]);
/*     */     choiceElementDef.setName(choiceElementDef.getID());
/*     */     if (paramBoolean) {
/*     */       insert(choiceElementDef, paramBoolean);
/*     */     } else {
/*     */       ChoiceProperty choiceProperty = new ChoiceProperty(this);
/*     */       choiceProperty.show(choiceElementDef, Catalog.getString("Choice"), new ActionListener(this, choiceElementDef, paramBoolean) {
/*     */             private final ChoiceElementDef val$comp;
/*     */             private final boolean val$section;
/*     */             private final DesignPane2 this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$comp, this.val$section); }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void insertTextField(boolean paramBoolean) {
/*     */     TextFieldElementDef textFieldElementDef = new TextFieldElementDef(this.sheet, "Form", "Text", "");
/*     */     textFieldElementDef.setName(textFieldElementDef.getID());
/*     */     if (paramBoolean) {
/*     */       insert(textFieldElementDef, paramBoolean);
/*     */     } else {
/*     */       TextFieldProperty textFieldProperty = new TextFieldProperty(this);
/*     */       textFieldProperty.show(textFieldElementDef, Catalog.getString("TextField"), new ActionListener(this, textFieldElementDef, paramBoolean) {
/*     */             private final TextFieldElementDef val$comp;
/*     */             private final boolean val$section;
/*     */             private final DesignPane2 this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$comp, this.val$section); }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   public void insertTextArea(boolean paramBoolean) {
/*     */     TextAreaElementDef textAreaElementDef = new TextAreaElementDef(this.sheet, "Form", "TextArea", "");
/*     */     textAreaElementDef.setName(textAreaElementDef.getID());
/*     */     if (paramBoolean) {
/*     */       insert(textAreaElementDef, paramBoolean);
/*     */     } else {
/*     */       TextAreaProperty textAreaProperty = new TextAreaProperty(this);
/*     */       textAreaProperty.show(textAreaElementDef, Catalog.getString("TextArea"), new ActionListener(this, textAreaElementDef, paramBoolean) {
/*     */             private final TextAreaElementDef val$comp;
/*     */             private final boolean val$section;
/*     */             private final DesignPane2 this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$comp, this.val$section); }
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   protected PropertyDialog getPropertyDialog(ReportElement paramReportElement) {
/*     */     if (paramReportElement instanceof ButtonElementDef)
/*     */       return new ButtonProperty(this); 
/*     */     if (paramReportElement instanceof ImageButtonElementDef)
/*     */       return new ImageButtonProperty(this); 
/*     */     if (paramReportElement instanceof RadioButtonElementDef)
/*     */       return new RadioButtonProperty(this); 
/*     */     if (paramReportElement instanceof CheckBoxElementDef)
/*     */       return new CheckBoxProperty(this); 
/*     */     if (paramReportElement instanceof ChoiceElementDef)
/*     */       return new ChoiceProperty(this); 
/*     */     if (paramReportElement instanceof TextFieldElementDef)
/*     */       return new TextFieldProperty(this); 
/*     */     if (paramReportElement instanceof TextAreaElementDef)
/*     */       return new TextAreaProperty(this); 
/*     */     return super.getPropertyDialog(paramReportElement);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\design\DesignPane2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */