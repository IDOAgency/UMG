package inetsoft.sree.design;

import inetsoft.report.ReportElement;
import inetsoft.report.design.DesignView;
import inetsoft.report.internal.ChoiceElementDef;
import inetsoft.report.locale.Catalog;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

class ChoiceProperty extends FieldProperty {
  ActionListener addListener;
  
  ActionListener removeListener;
  
  ChoiceElementDef elem;
  
  JTextField fieldTF;
  
  DefaultListModel listM;
  
  JList list;
  
  JButton addB;
  
  JButton removeB;
  
  public ChoiceProperty(DesignView paramDesignView) {
    super(paramDesignView, Catalog.getString("Choice"));
    this.addListener = new ActionListener(this) {
        private final ChoiceProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.listM.addElement(this.this$0.fieldTF.getText());
          this.this$0.fieldTF.setText("");
        }
      };
    this.removeListener = new ActionListener(this) {
        private final ChoiceProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int i = this.this$0.list.getSelectedIndex();
          if (i >= 0)
            this.this$0.listM.removeElementAt(i); 
        }
      };
    this.fieldTF = new JTextField(15);
    this.listM = new DefaultListModel();
    this.list = new JList(this.listM);
    this.addB = new JButton(Catalog.getString("Add"));
    this.removeB = new JButton(Catalog.getString("Remove"));
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new GridBagLayout());
    jPanel.setBorder(new TitledBorder(new EtchedBorder(0), Catalog.getString("Choice")));
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.anchor = 17;
    jPanel.add(this.fieldTF, gridBagConstraints);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.insets = new Insets(4, 8, 2, 4);
    gridBagConstraints.anchor = 13;
    jPanel.add(this.addB, gridBagConstraints);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.fill = 1;
    gridBagConstraints.weightx = gridBagConstraints.weighty = 1.0D;
    JScrollPane jScrollPane = new JScrollPane(this.list);
    jScrollPane.setPreferredSize(new Dimension(100, 100));
    jPanel.add(jScrollPane, gridBagConstraints);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.insets = new Insets(4, 8, 2, 4);
    gridBagConstraints.anchor = 12;
    jPanel.add(this.removeB, gridBagConstraints);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.fill = 2;
    this.pane.add(jPanel, gridBagConstraints);
    this.fieldTF.getDocument().addDocumentListener(new DocumentListener(this) {
          private final ChoiceProperty this$0;
          
          public void insertUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setEnabled(); }
          
          public void removeUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
          
          public void changedUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
        });
    this.list.addListSelectionListener(new ListSelectionListener(this) {
          private final ChoiceProperty this$0;
          
          public void valueChanged(ListSelectionEvent param1ListSelectionEvent) { this.this$0.setEnabled(); }
        });
    this.list.setSelectionMode(0);
    this.fieldTF.addActionListener(this.addListener);
    this.addB.addActionListener(this.addListener);
    this.removeB.addActionListener(this.removeListener);
  }
  
  public void setElement(ReportElement paramReportElement) {
    super.setElement(paramReportElement);
    this.elem = (ChoiceElementDef)paramReportElement;
    this.listM.removeAllElements();
    Object[] arrayOfObject = this.elem.getChoices();
    for (byte b = 0; b < arrayOfObject.length; b++)
      this.listM.addElement(arrayOfObject[b]); 
    Object object = this.elem.getSelectedItem();
    if (object != null) {
      int i = this.listM.indexOf(object);
      if (i >= 0)
        this.list.setSelectedIndex(i); 
    } 
  }
  
  public boolean populateElement() {
    if (!super.populateElement())
      return false; 
    this.elem.setChoices(this.listM.toArray());
    this.elem.setSelectedItem((String)this.list.getSelectedValue());
    return true;
  }
  
  public void setEnabled() {
    this.addB.setEnabled((this.fieldTF.getText().length() > 0));
    this.removeB.setEnabled((this.list.getSelectedIndex() >= 0));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\design\ChoiceProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */