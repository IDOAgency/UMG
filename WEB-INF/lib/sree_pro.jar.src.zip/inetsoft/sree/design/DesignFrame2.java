package inetsoft.sree.design;

import inetsoft.report.design.DesignFrame;
import inetsoft.report.design.DesignPane;

public class DesignFrame2 extends DesignFrame {
  DesignPane2 pane;
  
  protected DesignPane createDesignPane() { return this.pane = new DesignPane2(); }
  
  public void insertButton(boolean paramBoolean) { this.pane.insertButton(paramBoolean); }
  
  public void insertImageButton(boolean paramBoolean) { this.pane.insertImageButton(paramBoolean); }
  
  public void insertCheckBox(boolean paramBoolean) { this.pane.insertCheckBox(paramBoolean); }
  
  public void insertRadioButton(boolean paramBoolean) { this.pane.insertRadioButton(paramBoolean); }
  
  public void insertChoice(boolean paramBoolean) { this.pane.insertChoice(paramBoolean); }
  
  public void insertTextField(boolean paramBoolean) { this.pane.insertTextField(paramBoolean); }
  
  public void insertTextArea(boolean paramBoolean) { this.pane.insertTextArea(paramBoolean); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\design\DesignFrame2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */