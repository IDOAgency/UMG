/*    */ package inetsoft.sree.corba;
/*    */ 
/*    */ import org.omg.CORBA.Any;
/*    */ import org.omg.CORBA.ORB;
/*    */ import org.omg.CORBA.TCKind;
/*    */ import org.omg.CORBA.TypeCode;
/*    */ import org.omg.CORBA.portable.InputStream;
/*    */ import org.omg.CORBA.portable.OutputStream;
/*    */ 
/*    */ public class stringListHelper
/*    */ {
/*    */   private static TypeCode _tc;
/*    */   
/*    */   public static void write(OutputStream paramOutputStream, String[] paramArrayOfString) {
/* 15 */     paramOutputStream.write_long(paramArrayOfString.length);
/* 16 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 17 */       paramOutputStream.write_string(paramArrayOfString[b]);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static String[] read(InputStream paramInputStream) {
/* 24 */     int i = paramInputStream.read_long();
/* 25 */     String[] arrayOfString = new String[i];
/* 26 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 27 */       arrayOfString[b] = paramInputStream.read_string();
/*    */     }
/*    */     
/* 30 */     return arrayOfString;
/*    */   }
/*    */   public static String[] extract(Any paramAny) {
/* 33 */     InputStream inputStream = paramAny.create_input_stream();
/* 34 */     return read(inputStream);
/*    */   }
/*    */   public static void insert(Any paramAny, String[] paramArrayOfString) {
/* 37 */     OutputStream outputStream = paramAny.create_output_stream();
/* 38 */     paramAny.type(type());
/* 39 */     write(outputStream, paramArrayOfString);
/* 40 */     paramAny.read_value(outputStream.create_input_stream(), type());
/*    */   }
/*    */   
/*    */   public static TypeCode type() {
/* 44 */     if (_tc == null)
/* 45 */       _tc = ORB.init().create_alias_tc(id(), "stringList", ORB.init().create_sequence_tc(0, ORB.init().get_primitive_tc(TCKind.tk_string))); 
/* 46 */     return _tc;
/*    */   }
/*    */   
/* 49 */   public static String id() { return "IDL:inetsoft/sree/corba/stringList:1.0"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\stringListHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */