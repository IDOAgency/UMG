package inetsoft.sree.corba;

import inetsoft.report.StylePage;
import inetsoft.report.event.SelectionEvent;
import inetsoft.sree.EventHandler;
import inetsoft.sree.PageLocation;
import inetsoft.sree.RepletCommand;
import inetsoft.sree.RepletException;
import inetsoft.sree.RepletParameters;
import inetsoft.sree.RepletRepository;
import inetsoft.sree.RepletRequest;
import inetsoft.sree.SearchCondition;
import inetsoft.sree.SreeLog;
import java.awt.Point;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.EventObject;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;

public class CorbaRepository implements RepletRepository {
  IDLRepletRepository engine;
  
  DataEncoder coder;
  
  public static CorbaRepository bind(ORB paramORB) {
    try {
      SreeLog.print("Binding to name service...");
      Object object = paramORB.resolve_initial_references("NameService");
      NamingContext namingContext = NamingContextHelper.narrow(object);
      NameComponent nameComponent = new NameComponent("RepletRepository", "");
      NameComponent[] arrayOfNameComponent = { nameComponent };
      SreeLog.print("Resolving name path...");
      IDLRepletRepository iDLRepletRepository = IDLRepletRepositoryHelper.narrow(namingContext.resolve(arrayOfNameComponent));
      SreeLog.print("Creating client interface...");
      return new CorbaRepository(iDLRepletRepository, paramORB);
    } catch (Exception exception) {
      System.out.println("ERROR : " + exception);
      SreeLog.print(exception);
      return null;
    } 
  }
  
  public CorbaRepository(IDLRepletRepository paramIDLRepletRepository, ORB paramORB) {
    this.engine = paramIDLRepletRepository;
    this.coder = new DataEncoder();
  }
  
  public String[] getRepletNames(Object paramObject) throws RemoteException {
    try {
      return this.engine.getRepletNames(this.coder.encode(paramObject));
    } catch (IOException iOException) {
      throw new RemoteException(iOException.toString());
    } 
  }
  
  public Object create(String paramString, Object paramObject) throws RepletException {
    try {
      return this.engine.create(paramString, this.coder.encode(paramObject));
    } catch (Throwable throwable) {
      throw new RepletException(throwable.toString());
    } 
  }
  
  public int getEventMask(Object paramObject) { return this.engine.getEventMask((String)paramObject); }
  
  public RepletParameters getRepletParameters(Object paramObject, String paramString) throws RemoteException {
    try {
      return (RepletParameters)this.coder.decode(this.engine.getRepletParameters((String)paramObject, paramString));
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public void generate(Object paramObject, RepletRequest paramRepletRequest) throws RepletException {
    try {
      this.engine.generate((String)paramObject, this.coder.encode(paramRepletRequest));
    } catch (Throwable throwable) {
      throw new RepletException(throwable.toString());
    } 
  }
  
  public EventHandler getEventHandler(Object paramObject) throws RemoteException {
    try {
      return (EventHandler)this.coder.decode(this.engine.getEventHandler((String)paramObject));
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public RepletCommand handleEvent(Object paramObject, EventObject paramEventObject) throws RemoteException {
    try {
      return (RepletCommand)this.coder.decode(this.engine.handleEvent((String)paramObject, this.coder.encode(paramEventObject)));
    } catch (Throwable throwable) {
      throw new RemoteException(paramEventObject.toString());
    } 
  }
  
  public SelectionEvent[] getRegisteredSelections(Object paramObject) throws RemoteException {
    try {
      return (SelectionEvent[])this.coder.decode(this.engine.getRegisteredSelections((String)paramObject));
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public StylePage getPage(Object paramObject, int paramInt) throws RemoteException {
    try {
      return (StylePage)this.coder.decode(this.engine.getPage((String)paramObject, paramInt));
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public int getPageCount(Object paramObject) { return this.engine.getPageCount((String)paramObject); }
  
  public PageLocation find(Object paramObject, SearchCondition paramSearchCondition, PageLocation paramPageLocation) throws RemoteException {
    try {
      return (PageLocation)this.coder.decode(this.engine.find((String)paramObject, this.coder.encode(paramSearchCondition), this.coder.encode(paramPageLocation)));
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public String[] getTOCPaths(Object paramObject) throws RemoteException { return this.engine.getTOCPaths((String)paramObject); }
  
  public PageLocation[] getTOCLocations(Object paramObject) throws RemoteException {
    try {
      return (PageLocation[])this.coder.decode(this.engine.getTOCLocations((String)paramObject));
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public PageLocation getPageLocation(Object paramObject, String paramString, Point paramPoint) throws RemoteException {
    try {
      int i = -1, j = -1;
      if (paramPoint != null) {
        i = paramPoint.x;
        j = paramPoint.y;
      } 
      return (PageLocation)this.coder.decode(this.engine.getPageLocation((String)paramObject, paramString, i, j));
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public void mailTo(Object paramObject, String paramString1, String paramString2, String paramString3) throws RemoteException, RepletException {
    try {
      this.engine.mailTo((String)paramObject, paramString1, paramString2, paramString3);
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public Object export(Object paramObject, int paramInt) throws RemoteException, RepletException {
    try {
      return this.engine.export((String)paramObject, paramInt);
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public byte[] nextBlock(Object paramObject) throws RemoteException, RepletException {
    try {
      return this.engine.nextBlock((String)paramObject);
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public String[] getPrinters() throws RemoteException {
    try {
      return this.engine.getPrinters();
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public void print(Object paramObject, String paramString) throws RemoteException, RepletException {
    try {
      this.engine.print((String)paramObject, paramString);
    } catch (Throwable throwable) {
      throw new RemoteException(throwable.toString());
    } 
  }
  
  public void destroy(Object paramObject) { this.engine.destroy((String)paramObject); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\CorbaRepository.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */