/*     */ package inetsoft.sree.corba;
/*     */ 
/*     */ import inetsoft.report.StylePage;
/*     */ import inetsoft.report.event.SelectionEvent;
/*     */ import inetsoft.sree.EventHandler;
/*     */ import inetsoft.sree.PageLocation;
/*     */ import inetsoft.sree.RepletCommand;
/*     */ import inetsoft.sree.RepletException;
/*     */ import inetsoft.sree.RepletParameters;
/*     */ import inetsoft.sree.RepletRepository;
/*     */ import inetsoft.sree.RepletRequest;
/*     */ import inetsoft.sree.SearchCondition;
/*     */ import inetsoft.sree.SreeLog;
/*     */ import java.awt.Point;
/*     */ import java.io.IOException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.EventObject;
/*     */ import org.omg.CORBA.ORB;
/*     */ import org.omg.CORBA.Object;
/*     */ import org.omg.CosNaming.NameComponent;
/*     */ import org.omg.CosNaming.NamingContext;
/*     */ import org.omg.CosNaming.NamingContextHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CorbaRepository
/*     */   implements RepletRepository
/*     */ {
/*     */   IDLRepletRepository engine;
/*     */   DataEncoder coder;
/*     */   
/*     */   public static CorbaRepository bind(ORB paramORB) {
/*     */     try {
/*  41 */       SreeLog.print("Binding to name service...");
/*     */       
/*  43 */       Object object = paramORB.resolve_initial_references("NameService");
/*     */       
/*  45 */       NamingContext namingContext = NamingContextHelper.narrow(object);
/*     */ 
/*     */       
/*  48 */       NameComponent nameComponent = new NameComponent("RepletRepository", "");
/*  49 */       NameComponent[] arrayOfNameComponent = { nameComponent };
/*  50 */       SreeLog.print("Resolving name path...");
/*  51 */       IDLRepletRepository iDLRepletRepository = IDLRepletRepositoryHelper.narrow(namingContext.resolve(arrayOfNameComponent));
/*     */ 
/*     */       
/*  54 */       SreeLog.print("Creating client interface...");
/*  55 */       return new CorbaRepository(iDLRepletRepository, paramORB);
/*     */     } catch (Exception exception) {
/*  57 */       System.out.println("ERROR : " + exception);
/*  58 */       SreeLog.print(exception);
/*     */ 
/*     */       
/*  61 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CorbaRepository(IDLRepletRepository paramIDLRepletRepository, ORB paramORB) {
/*  68 */     this.engine = paramIDLRepletRepository;
/*  69 */     this.coder = new DataEncoder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRepletNames(Object paramObject) throws RemoteException {
/*     */     try {
/*  80 */       return this.engine.getRepletNames(this.coder.encode(paramObject));
/*     */     } catch (IOException iOException) {
/*  82 */       throw new RemoteException(iOException.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object create(String paramString, Object paramObject) throws RepletException {
/*     */     try {
/*  94 */       return this.engine.create(paramString, this.coder.encode(paramObject));
/*     */     } catch (Throwable throwable) {
/*  96 */       throw new RepletException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public int getEventMask(Object paramObject) { return this.engine.getEventMask((String)paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RepletParameters getRepletParameters(Object paramObject, String paramString) throws RemoteException {
/*     */     try {
/* 121 */       return (RepletParameters)this.coder.decode(this.engine.getRepletParameters((String)paramObject, paramString));
/*     */     } catch (Throwable throwable) {
/*     */       
/* 124 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(Object paramObject, RepletRequest paramRepletRequest) throws RepletException {
/*     */     try {
/* 138 */       this.engine.generate((String)paramObject, this.coder.encode(paramRepletRequest));
/*     */     } catch (Throwable throwable) {
/* 140 */       throw new RepletException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EventHandler getEventHandler(Object paramObject) throws RemoteException {
/*     */     try {
/* 151 */       return (EventHandler)this.coder.decode(this.engine.getEventHandler((String)paramObject));
/*     */     } catch (Throwable throwable) {
/*     */       
/* 154 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RepletCommand handleEvent(Object paramObject, EventObject paramEventObject) throws RemoteException {
/*     */     try {
/* 169 */       return (RepletCommand)this.coder.decode(this.engine.handleEvent((String)paramObject, this.coder.encode(paramEventObject)));
/*     */     } catch (Throwable throwable) {
/*     */       
/* 172 */       throw new RemoteException(paramEventObject.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SelectionEvent[] getRegisteredSelections(Object paramObject) throws RemoteException {
/*     */     try {
/* 183 */       return (SelectionEvent[])this.coder.decode(this.engine.getRegisteredSelections((String)paramObject));
/*     */     } catch (Throwable throwable) {
/*     */       
/* 186 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StylePage getPage(Object paramObject, int paramInt) throws RemoteException {
/*     */     try {
/* 199 */       return (StylePage)this.coder.decode(this.engine.getPage((String)paramObject, paramInt));
/*     */     } catch (Throwable throwable) {
/*     */       
/* 202 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   public int getPageCount(Object paramObject) { return this.engine.getPageCount((String)paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageLocation find(Object paramObject, SearchCondition paramSearchCondition, PageLocation paramPageLocation) throws RemoteException {
/*     */     try {
/* 227 */       return (PageLocation)this.coder.decode(this.engine.find((String)paramObject, this.coder.encode(paramSearchCondition), this.coder.encode(paramPageLocation)));
/*     */     }
/*     */     catch (Throwable throwable) {
/*     */       
/* 231 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 243 */   public String[] getTOCPaths(Object paramObject) throws RemoteException { return this.engine.getTOCPaths((String)paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageLocation[] getTOCLocations(Object paramObject) throws RemoteException {
/*     */     try {
/* 253 */       return (PageLocation[])this.coder.decode(this.engine.getTOCLocations((String)paramObject));
/*     */     } catch (Throwable throwable) {
/*     */       
/* 256 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageLocation getPageLocation(Object paramObject, String paramString, Point paramPoint) throws RemoteException {
/*     */     try {
/* 270 */       int i = -1, j = -1;
/* 271 */       if (paramPoint != null) {
/* 272 */         i = paramPoint.x;
/* 273 */         j = paramPoint.y;
/*     */       } 
/*     */       
/* 276 */       return (PageLocation)this.coder.decode(this.engine.getPageLocation((String)paramObject, paramString, i, j));
/*     */     } catch (Throwable throwable) {
/*     */       
/* 279 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mailTo(Object paramObject, String paramString1, String paramString2, String paramString3) throws RemoteException, RepletException {
/*     */     try {
/* 294 */       this.engine.mailTo((String)paramObject, paramString1, paramString2, paramString3);
/*     */     } catch (Throwable throwable) {
/* 296 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object export(Object paramObject, int paramInt) throws RemoteException, RepletException {
/*     */     try {
/* 313 */       return this.engine.export((String)paramObject, paramInt);
/*     */     } catch (Throwable throwable) {
/* 315 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] nextBlock(Object paramObject) throws RemoteException, RepletException {
/*     */     try {
/* 329 */       return this.engine.nextBlock((String)paramObject);
/*     */     } catch (Throwable throwable) {
/* 331 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPrinters() throws RemoteException {
/*     */     try {
/* 341 */       return this.engine.getPrinters();
/*     */     } catch (Throwable throwable) {
/* 343 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(Object paramObject, String paramString) throws RemoteException, RepletException {
/*     */     try {
/* 356 */       this.engine.print((String)paramObject, paramString);
/*     */     } catch (Throwable throwable) {
/* 358 */       throw new RemoteException(throwable.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 368 */   public void destroy(Object paramObject) { this.engine.destroy((String)paramObject); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\CorbaRepository.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */