package inetsoft.sree.corba;

import org.omg.CORBA.Object;
import org.omg.CORBA.portable.IDLEntity;

public interface IDLRepletRepository extends Object, IDLEntity {
  String[] getRepletNames(byte[] paramArrayOfByte);
  
  String create(String paramString, byte[] paramArrayOfByte) throws IDLRepletException;
  
  byte[] getRepletParameters(String paramString1, String paramString2);
  
  void generate(String paramString, byte[] paramArrayOfByte) throws IDLRepletException;
  
  int getEventMask(String paramString);
  
  byte[] getEventHandler(String paramString);
  
  byte[] handleEvent(String paramString, byte[] paramArrayOfByte);
  
  byte[] getRegisteredSelections(String paramString);
  
  byte[] getPage(String paramString, int paramInt);
  
  int getPageCount(String paramString);
  
  byte[] find(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  String[] getTOCPaths(String paramString);
  
  byte[] getTOCLocations(String paramString);
  
  byte[] getPageLocation(String paramString1, String paramString2, int paramInt1, int paramInt2);
  
  void mailTo(String paramString1, String paramString2, String paramString3, String paramString4) throws IDLRepletException;
  
  String export(String paramString, int paramInt) throws IDLRepletException;
  
  byte[] nextBlock(String paramString);
  
  String[] getPrinters();
  
  void print(String paramString1, String paramString2) throws IDLRepletException;
  
  void destroy(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\IDLRepletRepository.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */