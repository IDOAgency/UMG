/*     */ package inetsoft.sree.corba;
/*     */ 
/*     */ import java.util.Dictionary;
/*     */ import java.util.Hashtable;
/*     */ import org.omg.CORBA.Any;
/*     */ import org.omg.CORBA.BAD_OPERATION;
/*     */ import org.omg.CORBA.CompletionStatus;
/*     */ import org.omg.CORBA.DynamicImplementation;
/*     */ import org.omg.CORBA.NVList;
/*     */ import org.omg.CORBA.ORB;
/*     */ import org.omg.CORBA.ServerRequest;
/*     */ import org.omg.CORBA.TCKind;
/*     */ 
/*     */ public abstract class _IDLRepletRepositoryImplBase
/*     */   extends DynamicImplementation implements IDLRepletRepository {
/*  16 */   private static final String[] _type_ids = { "IDL:inetsoft/sree/corba/IDLRepletRepository:1.0" };
/*     */ 
/*     */   
/*  19 */   public String[] _ids() { return (String[])_type_ids.clone(); }
/*     */   
/*  21 */   private static Dictionary _methods = new Hashtable();
/*     */   
/*  23 */   static  { _methods.put("getRepletNames", new Integer(0));
/*  24 */     _methods.put("create", new Integer(1));
/*  25 */     _methods.put("getRepletParameters", new Integer(2));
/*  26 */     _methods.put("generate", new Integer(3));
/*  27 */     _methods.put("getEventMask", new Integer(4));
/*  28 */     _methods.put("getEventHandler", new Integer(5));
/*  29 */     _methods.put("handleEvent", new Integer(6));
/*  30 */     _methods.put("getRegisteredSelections", new Integer(7));
/*  31 */     _methods.put("getPage", new Integer(8));
/*  32 */     _methods.put("getPageCount", new Integer(9));
/*  33 */     _methods.put("find", new Integer(10));
/*  34 */     _methods.put("getTOCPaths", new Integer(11));
/*  35 */     _methods.put("getTOCLocations", new Integer(12));
/*  36 */     _methods.put("getPageLocation", new Integer(13));
/*  37 */     _methods.put("mailTo", new Integer(14));
/*  38 */     _methods.put("export", new Integer(15));
/*  39 */     _methods.put("nextBlock", new Integer(16));
/*  40 */     _methods.put("getPrinters", new Integer(17));
/*  41 */     _methods.put("print", new Integer(18));
/*  42 */     _methods.put("destroy", new Integer(19)); } public void invoke(ServerRequest paramServerRequest) { Any any24; Any any23; int i1; String str18; Any any22; int n; byte[] arrayOfByte12; String str17; Any any21; Any any20; byte[] arrayOfByte11; String str15; byte[] arrayOfByte9; Any any18; Any any19; Any any16; Any any14; Any any12; byte[] arrayOfByte8; String str11; String str13; Any any15; Any any13; byte[] arrayOfByte6; Any any17; byte[] arrayOfByte7; int m; String str12; String str9; byte[] arrayOfByte2; Any any10; String str10; String str8; Any any9; String[] arrayOfString2; byte[] arrayOfByte4; byte[] arrayOfByte5; int j; int i; String str7; byte[] arrayOfByte3; Any any11; String[] arrayOfString3; String str3; Any any8; Any any5; String str4; String str5; Any any4; Any any6; byte[] arrayOfByte1; String str6; String str1; Any any7; Any any3; String str2; Any any2;
/*     */     Any any1;
/*     */     String[] arrayOfString1;
/*     */     NVList nVList;
/*  46 */     switch (((Integer)_methods.get(paramServerRequest.op_name())).intValue()) {
/*     */       
/*     */       case 0:
/*  49 */         nVList = _orb().create_list(0);
/*  50 */         any2 = _orb().create_any();
/*  51 */         any2.type(serializableHelper.type());
/*  52 */         nVList.add_value("ticket", any2, 1);
/*  53 */         paramServerRequest.params(nVList);
/*     */         
/*  55 */         arrayOfByte1 = serializableHelper.extract(any2);
/*     */         
/*  57 */         arrayOfString3 = getRepletNames(arrayOfByte1);
/*  58 */         any17 = _orb().create_any();
/*  59 */         stringListHelper.insert(any17, arrayOfString3);
/*  60 */         paramServerRequest.result(any17);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 1:
/*  65 */         nVList = _orb().create_list(0);
/*  66 */         any2 = _orb().create_any();
/*  67 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/*  68 */         nVList.add_value("name", any2, 1);
/*  69 */         any8 = _orb().create_any();
/*  70 */         any8.type(serializableHelper.type());
/*  71 */         nVList.add_value("ticket", any8, 1);
/*  72 */         paramServerRequest.params(nVList);
/*     */         
/*  74 */         str10 = any2.extract_string();
/*     */         
/*  76 */         arrayOfByte8 = serializableHelper.extract(any8);
/*     */         
/*     */         try {
/*  79 */           str15 = create(str10, arrayOfByte8);
/*     */         }
/*  81 */         catch (IDLRepletException iDLRepletException) {
/*  82 */           Any any = _orb().create_any();
/*  83 */           IDLRepletExceptionHelper.insert(any, iDLRepletException);
/*  84 */           paramServerRequest.except(any);
/*     */           return;
/*     */         } 
/*  87 */         any21 = _orb().create_any();
/*  88 */         any21.insert_string(str15);
/*  89 */         paramServerRequest.result(any21);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 2:
/*  94 */         nVList = _orb().create_list(0);
/*  95 */         any2 = _orb().create_any();
/*  96 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/*  97 */         nVList.add_value("id", any2, 1);
/*  98 */         any8 = _orb().create_any();
/*  99 */         any8.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 100 */         nVList.add_value("reqname", any8, 1);
/* 101 */         paramServerRequest.params(nVList);
/*     */         
/* 103 */         str10 = any2.extract_string();
/*     */         
/* 105 */         str13 = any8.extract_string();
/*     */         
/* 107 */         arrayOfByte10 = getRepletParameters(str10, str13);
/* 108 */         any21 = _orb().create_any();
/* 109 */         serializableHelper.insert(any21, arrayOfByte10);
/* 110 */         paramServerRequest.result(any21);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 3:
/* 115 */         nVList = _orb().create_list(0);
/* 116 */         any2 = _orb().create_any();
/* 117 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 118 */         nVList.add_value("id", any2, 1);
/* 119 */         any8 = _orb().create_any();
/* 120 */         any8.type(serializableHelper.type());
/* 121 */         nVList.add_value("param", any8, 1);
/* 122 */         paramServerRequest.params(nVList);
/*     */         
/* 124 */         str10 = any2.extract_string();
/*     */         
/* 126 */         arrayOfByte7 = serializableHelper.extract(any8);
/*     */         try {
/* 128 */           generate(str10, arrayOfByte7);
/*     */         }
/* 130 */         catch (IDLRepletException arrayOfByte10) {
/* 131 */           any21 = _orb().create_any();
/* 132 */           IDLRepletExceptionHelper.insert(any21, arrayOfByte10);
/* 133 */           paramServerRequest.except(any21);
/*     */           return;
/*     */         } 
/* 136 */         any19 = _orb().create_any();
/* 137 */         any19.type(_orb().get_primitive_tc(TCKind.tk_void));
/* 138 */         paramServerRequest.result(any19);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 4:
/* 143 */         nVList = _orb().create_list(0);
/* 144 */         any2 = _orb().create_any();
/* 145 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 146 */         nVList.add_value("id", any2, 1);
/* 147 */         paramServerRequest.params(nVList);
/*     */         
/* 149 */         str6 = any2.extract_string();
/*     */         
/* 151 */         j = getEventMask(str6);
/* 152 */         any16 = _orb().create_any();
/* 153 */         any16.insert_long(j);
/* 154 */         paramServerRequest.result(any16);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 5:
/* 159 */         nVList = _orb().create_list(0);
/* 160 */         any2 = _orb().create_any();
/* 161 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 162 */         nVList.add_value("id", any2, 1);
/* 163 */         paramServerRequest.params(nVList);
/*     */         
/* 165 */         str6 = any2.extract_string();
/*     */         
/* 167 */         arrayOfByte5 = getEventHandler(str6);
/* 168 */         any16 = _orb().create_any();
/* 169 */         serializableHelper.insert(any16, arrayOfByte5);
/* 170 */         paramServerRequest.result(any16);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 6:
/* 175 */         nVList = _orb().create_list(0);
/* 176 */         any2 = _orb().create_any();
/* 177 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 178 */         nVList.add_value("id", any2, 1);
/* 179 */         any7 = _orb().create_any();
/* 180 */         any7.type(serializableHelper.type());
/* 181 */         nVList.add_value("event", any7, 1);
/* 182 */         paramServerRequest.params(nVList);
/*     */         
/* 184 */         str9 = any2.extract_string();
/*     */         
/* 186 */         arrayOfByte6 = serializableHelper.extract(any7);
/*     */         
/* 188 */         arrayOfByte9 = handleEvent(str9, arrayOfByte6);
/* 189 */         any21 = _orb().create_any();
/* 190 */         serializableHelper.insert(any21, arrayOfByte9);
/* 191 */         paramServerRequest.result(any21);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 7:
/* 196 */         nVList = _orb().create_list(0);
/* 197 */         any2 = _orb().create_any();
/* 198 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 199 */         nVList.add_value("id", any2, 1);
/* 200 */         paramServerRequest.params(nVList);
/*     */         
/* 202 */         str5 = any2.extract_string();
/*     */         
/* 204 */         arrayOfByte4 = getRegisteredSelections(str5);
/* 205 */         any15 = _orb().create_any();
/* 206 */         serializableHelper.insert(any15, arrayOfByte4);
/* 207 */         paramServerRequest.result(any15);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 8:
/* 212 */         nVList = _orb().create_list(0);
/* 213 */         any2 = _orb().create_any();
/* 214 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 215 */         nVList.add_value("id", any2, 1);
/* 216 */         any6 = _orb().create_any();
/* 217 */         any6.type(ORB.init().get_primitive_tc(TCKind.tk_long));
/* 218 */         nVList.add_value("n", any6, 1);
/* 219 */         paramServerRequest.params(nVList);
/*     */         
/* 221 */         str8 = any2.extract_string();
/*     */         
/* 223 */         m = any6.extract_long();
/*     */         
/* 225 */         arrayOfByte9 = getPage(str8, m);
/* 226 */         any21 = _orb().create_any();
/* 227 */         serializableHelper.insert(any21, arrayOfByte9);
/* 228 */         paramServerRequest.result(any21);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 9:
/* 233 */         nVList = _orb().create_list(0);
/* 234 */         any2 = _orb().create_any();
/* 235 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 236 */         nVList.add_value("id", any2, 1);
/* 237 */         paramServerRequest.params(nVList);
/*     */         
/* 239 */         str4 = any2.extract_string();
/*     */         
/* 241 */         i = getPageCount(str4);
/* 242 */         any14 = _orb().create_any();
/* 243 */         any14.insert_long(i);
/* 244 */         paramServerRequest.result(any14);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 10:
/* 249 */         nVList = _orb().create_list(0);
/* 250 */         any2 = _orb().create_any();
/* 251 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 252 */         nVList.add_value("id", any2, 1);
/* 253 */         any5 = _orb().create_any();
/* 254 */         any5.type(serializableHelper.type());
/* 255 */         nVList.add_value("cond", any5, 1);
/* 256 */         any11 = _orb().create_any();
/* 257 */         any11.type(serializableHelper.type());
/* 258 */         nVList.add_value("next", any11, 1);
/* 259 */         paramServerRequest.params(nVList);
/*     */         
/* 261 */         str12 = any2.extract_string();
/*     */         
/* 263 */         arrayOfByte9 = serializableHelper.extract(any5);
/*     */         
/* 265 */         arrayOfByte11 = serializableHelper.extract(any11);
/*     */         
/* 267 */         arrayOfByte12 = find(str12, arrayOfByte9, arrayOfByte11);
/* 268 */         any22 = _orb().create_any();
/* 269 */         serializableHelper.insert(any22, arrayOfByte12);
/* 270 */         paramServerRequest.result(any22);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 11:
/* 275 */         nVList = _orb().create_list(0);
/* 276 */         any2 = _orb().create_any();
/* 277 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 278 */         nVList.add_value("id", any2, 1);
/* 279 */         paramServerRequest.params(nVList);
/*     */         
/* 281 */         str3 = any2.extract_string();
/*     */         
/* 283 */         arrayOfString2 = getTOCPaths(str3);
/* 284 */         any13 = _orb().create_any();
/* 285 */         stringListHelper.insert(any13, arrayOfString2);
/* 286 */         paramServerRequest.result(any13);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 12:
/* 291 */         nVList = _orb().create_list(0);
/* 292 */         any2 = _orb().create_any();
/* 293 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 294 */         nVList.add_value("id", any2, 1);
/* 295 */         paramServerRequest.params(nVList);
/*     */         
/* 297 */         str3 = any2.extract_string();
/*     */         
/* 299 */         arrayOfByte3 = getTOCLocations(str3);
/* 300 */         any13 = _orb().create_any();
/* 301 */         serializableHelper.insert(any13, arrayOfByte3);
/* 302 */         paramServerRequest.result(any13);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 13:
/* 307 */         nVList = _orb().create_list(0);
/* 308 */         any2 = _orb().create_any();
/* 309 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 310 */         nVList.add_value("id", any2, 1);
/* 311 */         any4 = _orb().create_any();
/* 312 */         any4.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 313 */         nVList.add_value("eid", any4, 1);
/* 314 */         any10 = _orb().create_any();
/* 315 */         any10.type(ORB.init().get_primitive_tc(TCKind.tk_long));
/* 316 */         nVList.add_value("x", any10, 1);
/* 317 */         any13 = _orb().create_any();
/* 318 */         any13.type(ORB.init().get_primitive_tc(TCKind.tk_long));
/* 319 */         nVList.add_value("y", any13, 1);
/* 320 */         paramServerRequest.params(nVList);
/*     */         
/* 322 */         str14 = any2.extract_string();
/*     */         
/* 324 */         str16 = any4.extract_string();
/*     */         
/* 326 */         n = any10.extract_long();
/*     */         
/* 328 */         i1 = any13.extract_long();
/*     */         
/* 330 */         arrayOfByte13 = getPageLocation(str14, str16, n, i1);
/* 331 */         any24 = _orb().create_any();
/* 332 */         serializableHelper.insert(any24, arrayOfByte13);
/* 333 */         paramServerRequest.result(any24);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 14:
/* 338 */         nVList = _orb().create_list(0);
/* 339 */         any2 = _orb().create_any();
/* 340 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 341 */         nVList.add_value("id", any2, 1);
/* 342 */         any4 = _orb().create_any();
/* 343 */         any4.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 344 */         nVList.add_value("recipients", any4, 1);
/* 345 */         any10 = _orb().create_any();
/* 346 */         any10.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 347 */         nVList.add_value("msg", any10, 1);
/* 348 */         any13 = _orb().create_any();
/* 349 */         any13.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 350 */         nVList.add_value("fmt", any13, 1);
/* 351 */         paramServerRequest.params(nVList);
/*     */         
/* 353 */         str14 = any2.extract_string();
/*     */         
/* 355 */         str16 = any4.extract_string();
/*     */         
/* 357 */         str17 = any10.extract_string();
/*     */         
/* 359 */         str18 = any13.extract_string();
/*     */         try {
/* 361 */           mailTo(str14, str16, str17, str18);
/*     */         }
/* 363 */         catch (IDLRepletException arrayOfByte13) {
/* 364 */           any24 = _orb().create_any();
/* 365 */           IDLRepletExceptionHelper.insert(any24, arrayOfByte13);
/* 366 */           paramServerRequest.except(any24);
/*     */           return;
/*     */         } 
/* 369 */         any23 = _orb().create_any();
/* 370 */         any23.type(_orb().get_primitive_tc(TCKind.tk_void));
/* 371 */         paramServerRequest.result(any23);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 15:
/* 376 */         nVList = _orb().create_list(0);
/* 377 */         any2 = _orb().create_any();
/* 378 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 379 */         nVList.add_value("id", any2, 1);
/* 380 */         any4 = _orb().create_any();
/* 381 */         any4.type(ORB.init().get_primitive_tc(TCKind.tk_long));
/* 382 */         nVList.add_value("fmt", any4, 1);
/* 383 */         paramServerRequest.params(nVList);
/*     */         
/* 385 */         arrayOfByte2 = any2.extract_string();
/*     */         
/* 387 */         k = any4.extract_long();
/*     */         
/*     */         try {
/* 390 */           str14 = export(arrayOfByte2, k);
/*     */         }
/* 392 */         catch (IDLRepletException str16) {
/* 393 */           Any any = _orb().create_any();
/* 394 */           IDLRepletExceptionHelper.insert(any, str16);
/* 395 */           paramServerRequest.except(any);
/*     */           return;
/*     */         } 
/* 398 */         any20 = _orb().create_any();
/* 399 */         any20.insert_string(str14);
/* 400 */         paramServerRequest.result(any20);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 16:
/* 405 */         nVList = _orb().create_list(0);
/* 406 */         any2 = _orb().create_any();
/* 407 */         any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 408 */         nVList.add_value("rid", any2, 1);
/* 409 */         paramServerRequest.params(nVList);
/*     */         
/* 411 */         str2 = any2.extract_string();
/*     */         
/*     */         try {
/* 414 */           arrayOfByte2 = nextBlock(str2);
/*     */         }
/* 416 */         catch (IDLRepletException k) {
/* 417 */           IDLRepletException iDLRepletException; Any any = _orb().create_any();
/* 418 */           IDLRepletExceptionHelper.insert(any, iDLRepletException);
/* 419 */           paramServerRequest.except(any);
/*     */           return;
/*     */         } 
/* 422 */         any12 = _orb().create_any();
/* 423 */         serializableHelper.insert(any12, arrayOfByte2);
/* 424 */         paramServerRequest.result(any12);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 17:
/* 429 */         nVList = _orb().create_list(0);
/* 430 */         paramServerRequest.params(nVList);
/*     */         
/* 432 */         arrayOfString1 = getPrinters();
/* 433 */         any3 = _orb().create_any();
/* 434 */         stringListHelper.insert(any3, arrayOfString1);
/* 435 */         paramServerRequest.result(any3);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 18:
/* 440 */         nVList = _orb().create_list(0);
/* 441 */         any1 = _orb().create_any();
/* 442 */         any1.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 443 */         nVList.add_value("id", any1, 1);
/* 444 */         any3 = _orb().create_any();
/* 445 */         any3.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 446 */         nVList.add_value("printer", any3, 1);
/* 447 */         paramServerRequest.params(nVList);
/*     */         
/* 449 */         str7 = any1.extract_string();
/*     */         
/* 451 */         str11 = any3.extract_string();
/*     */         try {
/* 453 */           print(str7, str11);
/*     */         }
/* 455 */         catch (IDLRepletException str14) {
/* 456 */           any20 = _orb().create_any();
/* 457 */           IDLRepletExceptionHelper.insert(any20, str14);
/* 458 */           paramServerRequest.except(any20);
/*     */           return;
/*     */         } 
/* 461 */         any18 = _orb().create_any();
/* 462 */         any18.type(_orb().get_primitive_tc(TCKind.tk_void));
/* 463 */         paramServerRequest.result(any18);
/*     */         return;
/*     */ 
/*     */       
/*     */       case 19:
/* 468 */         nVList = _orb().create_list(0);
/* 469 */         any1 = _orb().create_any();
/* 470 */         any1.type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 471 */         nVList.add_value("id", any1, 1);
/* 472 */         paramServerRequest.params(nVList);
/*     */         
/* 474 */         str1 = any1.extract_string();
/* 475 */         destroy(str1);
/* 476 */         any9 = _orb().create_any();
/* 477 */         any9.type(_orb().get_primitive_tc(TCKind.tk_void));
/* 478 */         paramServerRequest.result(any9);
/*     */         return;
/*     */     } 
/*     */     
/* 482 */     throw new BAD_OPERATION(0, CompletionStatus.COMPLETED_MAYBE); }
/*     */ 
/*     */   
/*     */   public abstract String create(String paramString, byte[] paramArrayOfByte) throws IDLRepletException;
/*     */   
/*     */   public abstract void destroy(String paramString);
/*     */   
/*     */   public abstract String export(String paramString, int paramInt) throws IDLRepletException;
/*     */   
/*     */   public abstract byte[] find(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*     */   
/*     */   public abstract void generate(String paramString, byte[] paramArrayOfByte) throws IDLRepletException;
/*     */   
/*     */   public abstract byte[] getEventHandler(String paramString);
/*     */   
/*     */   public abstract int getEventMask(String paramString);
/*     */   
/*     */   public abstract byte[] getPage(String paramString, int paramInt);
/*     */   
/*     */   public abstract int getPageCount(String paramString);
/*     */   
/*     */   public abstract byte[] getPageLocation(String paramString1, String paramString2, int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract String[] getPrinters();
/*     */   
/*     */   public abstract byte[] getRegisteredSelections(String paramString);
/*     */   
/*     */   public abstract String[] getRepletNames(byte[] paramArrayOfByte);
/*     */   
/*     */   public abstract byte[] getRepletParameters(String paramString1, String paramString2);
/*     */   
/*     */   public abstract byte[] getTOCLocations(String paramString);
/*     */   
/*     */   public abstract String[] getTOCPaths(String paramString);
/*     */   
/*     */   public abstract byte[] handleEvent(String paramString, byte[] paramArrayOfByte);
/*     */   
/*     */   public abstract void mailTo(String paramString1, String paramString2, String paramString3, String paramString4) throws IDLRepletException;
/*     */   
/*     */   public abstract byte[] nextBlock(String paramString);
/*     */   
/*     */   public abstract void print(String paramString1, String paramString2) throws IDLRepletException;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\_IDLRepletRepositoryImplBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */