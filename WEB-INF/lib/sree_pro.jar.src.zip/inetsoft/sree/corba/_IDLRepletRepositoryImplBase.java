package inetsoft.sree.corba;

import java.util.Dictionary;
import java.util.Hashtable;
import org.omg.CORBA.Any;
import org.omg.CORBA.BAD_OPERATION;
import org.omg.CORBA.CompletionStatus;
import org.omg.CORBA.DynamicImplementation;
import org.omg.CORBA.NVList;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ServerRequest;
import org.omg.CORBA.TCKind;

public abstract class _IDLRepletRepositoryImplBase extends DynamicImplementation implements IDLRepletRepository {
  private static final String[] _type_ids = { "IDL:inetsoft/sree/corba/IDLRepletRepository:1.0" };
  
  public String[] _ids() { return (String[])_type_ids.clone(); }
  
  private static Dictionary _methods = new Hashtable();
  
  static  {
    _methods.put("getRepletNames", new Integer(0));
    _methods.put("create", new Integer(1));
    _methods.put("getRepletParameters", new Integer(2));
    _methods.put("generate", new Integer(3));
    _methods.put("getEventMask", new Integer(4));
    _methods.put("getEventHandler", new Integer(5));
    _methods.put("handleEvent", new Integer(6));
    _methods.put("getRegisteredSelections", new Integer(7));
    _methods.put("getPage", new Integer(8));
    _methods.put("getPageCount", new Integer(9));
    _methods.put("find", new Integer(10));
    _methods.put("getTOCPaths", new Integer(11));
    _methods.put("getTOCLocations", new Integer(12));
    _methods.put("getPageLocation", new Integer(13));
    _methods.put("mailTo", new Integer(14));
    _methods.put("export", new Integer(15));
    _methods.put("nextBlock", new Integer(16));
    _methods.put("getPrinters", new Integer(17));
    _methods.put("print", new Integer(18));
    _methods.put("destroy", new Integer(19));
  }
  
  public void invoke(ServerRequest paramServerRequest) {
    Any any24;
    Any any23;
    Any any22;
    int i1;
    String str18;
    byte[] arrayOfByte12;
    int n;
    String str17;
    Any any20;
    byte[] arrayOfByte11;
    Any any21;
    Any any19;
    String str15;
    byte[] arrayOfByte9;
    Any any18;
    String str12;
    Any any17;
    byte[] arrayOfByte7;
    Any any12;
    String str11;
    int m;
    byte[] arrayOfByte8;
    Any any16;
    String str13;
    byte[] arrayOfByte6;
    Any any14;
    Any any13;
    Any any15;
    Any any10;
    String str10;
    Any any11;
    byte[] arrayOfByte3;
    byte[] arrayOfByte2;
    byte[] arrayOfByte4;
    String str9;
    String str8;
    String[] arrayOfString2;
    int j;
    String str7;
    String[] arrayOfString3;
    Any any9;
    int i;
    byte[] arrayOfByte5;
    Any any8;
    String str6;
    Any any5;
    String str2;
    String str4;
    Any any4;
    String str1;
    Any any6;
    Any any7;
    String str5;
    byte[] arrayOfByte1;
    String str3;
    Any any3;
    Any any1;
    Any any2;
    String[] arrayOfString1;
    NVList nVList;
    switch (((Integer)_methods.get(paramServerRequest.op_name())).intValue()) {
      case 0:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(serializableHelper.type());
        nVList.add_value("ticket", any2, 1);
        paramServerRequest.params(nVList);
        arrayOfByte1 = serializableHelper.extract(any2);
        arrayOfString3 = getRepletNames(arrayOfByte1);
        any17 = _orb().create_any();
        stringListHelper.insert(any17, arrayOfString3);
        paramServerRequest.result(any17);
        return;
      case 1:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("name", any2, 1);
        any8 = _orb().create_any();
        any8.type(serializableHelper.type());
        nVList.add_value("ticket", any8, 1);
        paramServerRequest.params(nVList);
        str10 = any2.extract_string();
        arrayOfByte8 = serializableHelper.extract(any8);
        try {
          str15 = create(str10, arrayOfByte8);
        } catch (IDLRepletException iDLRepletException) {
          Any any = _orb().create_any();
          IDLRepletExceptionHelper.insert(any, iDLRepletException);
          paramServerRequest.except(any);
          return;
        } 
        any21 = _orb().create_any();
        any21.insert_string(str15);
        paramServerRequest.result(any21);
        return;
      case 2:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        any8 = _orb().create_any();
        any8.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("reqname", any8, 1);
        paramServerRequest.params(nVList);
        str10 = any2.extract_string();
        str13 = any8.extract_string();
        arrayOfByte10 = getRepletParameters(str10, str13);
        any21 = _orb().create_any();
        serializableHelper.insert(any21, arrayOfByte10);
        paramServerRequest.result(any21);
        return;
      case 3:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        any8 = _orb().create_any();
        any8.type(serializableHelper.type());
        nVList.add_value("param", any8, 1);
        paramServerRequest.params(nVList);
        str10 = any2.extract_string();
        arrayOfByte7 = serializableHelper.extract(any8);
        try {
          generate(str10, arrayOfByte7);
        } catch (IDLRepletException arrayOfByte10) {
          any21 = _orb().create_any();
          IDLRepletExceptionHelper.insert(any21, arrayOfByte10);
          paramServerRequest.except(any21);
          return;
        } 
        any19 = _orb().create_any();
        any19.type(_orb().get_primitive_tc(TCKind.tk_void));
        paramServerRequest.result(any19);
        return;
      case 4:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        paramServerRequest.params(nVList);
        str6 = any2.extract_string();
        j = getEventMask(str6);
        any16 = _orb().create_any();
        any16.insert_long(j);
        paramServerRequest.result(any16);
        return;
      case 5:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        paramServerRequest.params(nVList);
        str6 = any2.extract_string();
        arrayOfByte5 = getEventHandler(str6);
        any16 = _orb().create_any();
        serializableHelper.insert(any16, arrayOfByte5);
        paramServerRequest.result(any16);
        return;
      case 6:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        any7 = _orb().create_any();
        any7.type(serializableHelper.type());
        nVList.add_value("event", any7, 1);
        paramServerRequest.params(nVList);
        str9 = any2.extract_string();
        arrayOfByte6 = serializableHelper.extract(any7);
        arrayOfByte9 = handleEvent(str9, arrayOfByte6);
        any21 = _orb().create_any();
        serializableHelper.insert(any21, arrayOfByte9);
        paramServerRequest.result(any21);
        return;
      case 7:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        paramServerRequest.params(nVList);
        str5 = any2.extract_string();
        arrayOfByte4 = getRegisteredSelections(str5);
        any15 = _orb().create_any();
        serializableHelper.insert(any15, arrayOfByte4);
        paramServerRequest.result(any15);
        return;
      case 8:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        any6 = _orb().create_any();
        any6.type(ORB.init().get_primitive_tc(TCKind.tk_long));
        nVList.add_value("n", any6, 1);
        paramServerRequest.params(nVList);
        str8 = any2.extract_string();
        m = any6.extract_long();
        arrayOfByte9 = getPage(str8, m);
        any21 = _orb().create_any();
        serializableHelper.insert(any21, arrayOfByte9);
        paramServerRequest.result(any21);
        return;
      case 9:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        paramServerRequest.params(nVList);
        str4 = any2.extract_string();
        i = getPageCount(str4);
        any14 = _orb().create_any();
        any14.insert_long(i);
        paramServerRequest.result(any14);
        return;
      case 10:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        any5 = _orb().create_any();
        any5.type(serializableHelper.type());
        nVList.add_value("cond", any5, 1);
        any11 = _orb().create_any();
        any11.type(serializableHelper.type());
        nVList.add_value("next", any11, 1);
        paramServerRequest.params(nVList);
        str12 = any2.extract_string();
        arrayOfByte9 = serializableHelper.extract(any5);
        arrayOfByte11 = serializableHelper.extract(any11);
        arrayOfByte12 = find(str12, arrayOfByte9, arrayOfByte11);
        any22 = _orb().create_any();
        serializableHelper.insert(any22, arrayOfByte12);
        paramServerRequest.result(any22);
        return;
      case 11:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        paramServerRequest.params(nVList);
        str3 = any2.extract_string();
        arrayOfString2 = getTOCPaths(str3);
        any13 = _orb().create_any();
        stringListHelper.insert(any13, arrayOfString2);
        paramServerRequest.result(any13);
        return;
      case 12:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        paramServerRequest.params(nVList);
        str3 = any2.extract_string();
        arrayOfByte3 = getTOCLocations(str3);
        any13 = _orb().create_any();
        serializableHelper.insert(any13, arrayOfByte3);
        paramServerRequest.result(any13);
        return;
      case 13:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        any4 = _orb().create_any();
        any4.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("eid", any4, 1);
        any10 = _orb().create_any();
        any10.type(ORB.init().get_primitive_tc(TCKind.tk_long));
        nVList.add_value("x", any10, 1);
        any13 = _orb().create_any();
        any13.type(ORB.init().get_primitive_tc(TCKind.tk_long));
        nVList.add_value("y", any13, 1);
        paramServerRequest.params(nVList);
        str14 = any2.extract_string();
        str16 = any4.extract_string();
        n = any10.extract_long();
        i1 = any13.extract_long();
        arrayOfByte13 = getPageLocation(str14, str16, n, i1);
        any24 = _orb().create_any();
        serializableHelper.insert(any24, arrayOfByte13);
        paramServerRequest.result(any24);
        return;
      case 14:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        any4 = _orb().create_any();
        any4.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("recipients", any4, 1);
        any10 = _orb().create_any();
        any10.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("msg", any10, 1);
        any13 = _orb().create_any();
        any13.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("fmt", any13, 1);
        paramServerRequest.params(nVList);
        str14 = any2.extract_string();
        str16 = any4.extract_string();
        str17 = any10.extract_string();
        str18 = any13.extract_string();
        try {
          mailTo(str14, str16, str17, str18);
        } catch (IDLRepletException arrayOfByte13) {
          any24 = _orb().create_any();
          IDLRepletExceptionHelper.insert(any24, arrayOfByte13);
          paramServerRequest.except(any24);
          return;
        } 
        any23 = _orb().create_any();
        any23.type(_orb().get_primitive_tc(TCKind.tk_void));
        paramServerRequest.result(any23);
        return;
      case 15:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any2, 1);
        any4 = _orb().create_any();
        any4.type(ORB.init().get_primitive_tc(TCKind.tk_long));
        nVList.add_value("fmt", any4, 1);
        paramServerRequest.params(nVList);
        arrayOfByte2 = any2.extract_string();
        k = any4.extract_long();
        try {
          str14 = export(arrayOfByte2, k);
        } catch (IDLRepletException str16) {
          Any any = _orb().create_any();
          IDLRepletExceptionHelper.insert(any, str16);
          paramServerRequest.except(any);
          return;
        } 
        any20 = _orb().create_any();
        any20.insert_string(str14);
        paramServerRequest.result(any20);
        return;
      case 16:
        nVList = _orb().create_list(0);
        any2 = _orb().create_any();
        any2.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("rid", any2, 1);
        paramServerRequest.params(nVList);
        str2 = any2.extract_string();
        try {
          arrayOfByte2 = nextBlock(str2);
        } catch (IDLRepletException k) {
          IDLRepletException iDLRepletException;
          Any any = _orb().create_any();
          IDLRepletExceptionHelper.insert(any, iDLRepletException);
          paramServerRequest.except(any);
          return;
        } 
        any12 = _orb().create_any();
        serializableHelper.insert(any12, arrayOfByte2);
        paramServerRequest.result(any12);
        return;
      case 17:
        nVList = _orb().create_list(0);
        paramServerRequest.params(nVList);
        arrayOfString1 = getPrinters();
        any3 = _orb().create_any();
        stringListHelper.insert(any3, arrayOfString1);
        paramServerRequest.result(any3);
        return;
      case 18:
        nVList = _orb().create_list(0);
        any1 = _orb().create_any();
        any1.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any1, 1);
        any3 = _orb().create_any();
        any3.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("printer", any3, 1);
        paramServerRequest.params(nVList);
        str7 = any1.extract_string();
        str11 = any3.extract_string();
        try {
          print(str7, str11);
        } catch (IDLRepletException str14) {
          any20 = _orb().create_any();
          IDLRepletExceptionHelper.insert(any20, str14);
          paramServerRequest.except(any20);
          return;
        } 
        any18 = _orb().create_any();
        any18.type(_orb().get_primitive_tc(TCKind.tk_void));
        paramServerRequest.result(any18);
        return;
      case 19:
        nVList = _orb().create_list(0);
        any1 = _orb().create_any();
        any1.type(ORB.init().get_primitive_tc(TCKind.tk_string));
        nVList.add_value("id", any1, 1);
        paramServerRequest.params(nVList);
        str1 = any1.extract_string();
        destroy(str1);
        any9 = _orb().create_any();
        any9.type(_orb().get_primitive_tc(TCKind.tk_void));
        paramServerRequest.result(any9);
        return;
    } 
    throw new BAD_OPERATION(0, CompletionStatus.COMPLETED_MAYBE);
  }
  
  public abstract String create(String paramString, byte[] paramArrayOfByte) throws IDLRepletException;
  
  public abstract void destroy(String paramString);
  
  public abstract String export(String paramString, int paramInt) throws IDLRepletException;
  
  public abstract byte[] find(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public abstract void generate(String paramString, byte[] paramArrayOfByte) throws IDLRepletException;
  
  public abstract byte[] getEventHandler(String paramString);
  
  public abstract int getEventMask(String paramString);
  
  public abstract byte[] getPage(String paramString, int paramInt);
  
  public abstract int getPageCount(String paramString);
  
  public abstract byte[] getPageLocation(String paramString1, String paramString2, int paramInt1, int paramInt2);
  
  public abstract String[] getPrinters();
  
  public abstract byte[] getRegisteredSelections(String paramString);
  
  public abstract String[] getRepletNames(byte[] paramArrayOfByte);
  
  public abstract byte[] getRepletParameters(String paramString1, String paramString2);
  
  public abstract byte[] getTOCLocations(String paramString);
  
  public abstract String[] getTOCPaths(String paramString);
  
  public abstract byte[] handleEvent(String paramString, byte[] paramArrayOfByte);
  
  public abstract void mailTo(String paramString1, String paramString2, String paramString3, String paramString4) throws IDLRepletException;
  
  public abstract byte[] nextBlock(String paramString);
  
  public abstract void print(String paramString1, String paramString2) throws IDLRepletException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\_IDLRepletRepositoryImplBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */