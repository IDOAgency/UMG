package inetsoft.sree.corba;

import org.omg.CORBA.Any;
import org.omg.CORBA.BAD_PARAM;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.Delegate;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.ObjectImpl;
import org.omg.CORBA.portable.OutputStream;

public class IDLRepletRepositoryHelper {
  private static TypeCode _tc;
  
  public static void write(OutputStream paramOutputStream, IDLRepletRepository paramIDLRepletRepository) { paramOutputStream.write_Object(paramIDLRepletRepository); }
  
  public static IDLRepletRepository read(InputStream paramInputStream) { return narrow(paramInputStream.read_Object()); }
  
  public static IDLRepletRepository extract(Any paramAny) {
    InputStream inputStream = paramAny.create_input_stream();
    return read(inputStream);
  }
  
  public static void insert(Any paramAny, IDLRepletRepository paramIDLRepletRepository) {
    OutputStream outputStream = paramAny.create_output_stream();
    write(outputStream, paramIDLRepletRepository);
    paramAny.read_value(outputStream.create_input_stream(), type());
  }
  
  public static TypeCode type() {
    if (_tc == null)
      _tc = ORB.init().create_interface_tc(id(), "IDLRepletRepository"); 
    return _tc;
  }
  
  public static String id() { return "IDL:inetsoft/sree/corba/IDLRepletRepository:1.0"; }
  
  public static IDLRepletRepository narrow(Object paramObject) throws BAD_PARAM {
    if (paramObject == null)
      return null; 
    if (paramObject instanceof IDLRepletRepository)
      return (IDLRepletRepository)paramObject; 
    if (!paramObject._is_a(id()))
      throw new BAD_PARAM(); 
    Delegate delegate = ((ObjectImpl)paramObject)._get_delegate();
    return new _IDLRepletRepositoryStub(delegate);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\IDLRepletRepositoryHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */