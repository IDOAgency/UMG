/*    */ package inetsoft.sree.corba;
/*    */ 
/*    */ import org.omg.CORBA.Any;
/*    */ import org.omg.CORBA.BAD_PARAM;
/*    */ import org.omg.CORBA.ORB;
/*    */ import org.omg.CORBA.Object;
/*    */ import org.omg.CORBA.TypeCode;
/*    */ import org.omg.CORBA.portable.Delegate;
/*    */ import org.omg.CORBA.portable.InputStream;
/*    */ import org.omg.CORBA.portable.ObjectImpl;
/*    */ import org.omg.CORBA.portable.OutputStream;
/*    */ 
/*    */ public class IDLRepletRepositoryHelper {
/* 14 */   public static void write(OutputStream paramOutputStream, IDLRepletRepository paramIDLRepletRepository) { paramOutputStream.write_Object(paramIDLRepletRepository); }
/*    */ 
/*    */   
/* 17 */   public static IDLRepletRepository read(InputStream paramInputStream) { return narrow(paramInputStream.read_Object()); }
/*    */   private static TypeCode _tc;
/*    */   public static IDLRepletRepository extract(Any paramAny) {
/* 20 */     InputStream inputStream = paramAny.create_input_stream();
/* 21 */     return read(inputStream);
/*    */   }
/*    */   public static void insert(Any paramAny, IDLRepletRepository paramIDLRepletRepository) {
/* 24 */     OutputStream outputStream = paramAny.create_output_stream();
/* 25 */     write(outputStream, paramIDLRepletRepository);
/* 26 */     paramAny.read_value(outputStream.create_input_stream(), type());
/*    */   }
/*    */   
/*    */   public static TypeCode type() {
/* 30 */     if (_tc == null)
/* 31 */       _tc = ORB.init().create_interface_tc(id(), "IDLRepletRepository"); 
/* 32 */     return _tc;
/*    */   }
/*    */   
/* 35 */   public static String id() { return "IDL:inetsoft/sree/corba/IDLRepletRepository:1.0"; }
/*    */ 
/*    */   
/*    */   public static IDLRepletRepository narrow(Object paramObject) throws BAD_PARAM {
/* 39 */     if (paramObject == null)
/* 40 */       return null; 
/* 41 */     if (paramObject instanceof IDLRepletRepository)
/* 42 */       return (IDLRepletRepository)paramObject; 
/* 43 */     if (!paramObject._is_a(id())) {
/* 44 */       throw new BAD_PARAM();
/*    */     }
/* 46 */     Delegate delegate = ((ObjectImpl)paramObject)._get_delegate();
/* 47 */     return new _IDLRepletRepositoryStub(delegate);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\IDLRepletRepositoryHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */