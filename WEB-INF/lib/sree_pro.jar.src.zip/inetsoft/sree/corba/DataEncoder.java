/*    */ package inetsoft.sree.corba;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DataEncoder
/*    */ {
/*    */   public byte[] encode(Object paramObject) throws IOException {
/* 27 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 28 */     ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
/* 29 */     objectOutputStream.writeObject(paramObject);
/* 30 */     objectOutputStream.close();
/*    */     
/* 32 */     return byteArrayOutputStream.toByteArray();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object decode(byte[] paramArrayOfByte) throws IOException, ClassNotFoundException {
/* 38 */     ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(paramArrayOfByte));
/*    */     
/* 40 */     Object object = objectInputStream.readObject();
/* 41 */     objectInputStream.close();
/*    */     
/* 43 */     return object;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\DataEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */