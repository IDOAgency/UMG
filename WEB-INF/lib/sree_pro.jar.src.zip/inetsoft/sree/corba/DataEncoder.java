package inetsoft.sree.corba;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class DataEncoder {
  public byte[] encode(Object paramObject) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
    objectOutputStream.writeObject(paramObject);
    objectOutputStream.close();
    return byteArrayOutputStream.toByteArray();
  }
  
  public Object decode(byte[] paramArrayOfByte) throws IOException, ClassNotFoundException {
    ObjectInputStream objectInputStream = new ObjectInputStream(new ByteArrayInputStream(paramArrayOfByte));
    Object object = objectInputStream.readObject();
    objectInputStream.close();
    return object;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\DataEncoder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */