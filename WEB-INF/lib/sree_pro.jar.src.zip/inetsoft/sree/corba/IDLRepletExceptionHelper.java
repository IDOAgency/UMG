/*    */ package inetsoft.sree.corba;
/*    */ 
/*    */ import org.omg.CORBA.Any;
/*    */ import org.omg.CORBA.ORB;
/*    */ import org.omg.CORBA.StructMember;
/*    */ import org.omg.CORBA.TCKind;
/*    */ import org.omg.CORBA.TypeCode;
/*    */ import org.omg.CORBA.portable.InputStream;
/*    */ import org.omg.CORBA.portable.OutputStream;
/*    */ 
/*    */ public class IDLRepletExceptionHelper
/*    */ {
/*    */   public static void write(OutputStream paramOutputStream, IDLRepletException paramIDLRepletException) {
/* 14 */     paramOutputStream.write_string(id());
/*    */     
/* 16 */     paramOutputStream.write_string(paramIDLRepletException.msg);
/*    */   } private static TypeCode _tc;
/*    */   public static IDLRepletException read(InputStream paramInputStream) {
/* 19 */     IDLRepletException iDLRepletException = new IDLRepletException();
/*    */     
/* 21 */     paramInputStream.read_string();
/*    */     
/* 23 */     iDLRepletException.msg = paramInputStream.read_string();
/* 24 */     return iDLRepletException;
/*    */   }
/*    */   public static IDLRepletException extract(Any paramAny) {
/* 27 */     InputStream inputStream = paramAny.create_input_stream();
/* 28 */     return read(inputStream);
/*    */   }
/*    */   public static void insert(Any paramAny, IDLRepletException paramIDLRepletException) {
/* 31 */     OutputStream outputStream = paramAny.create_output_stream();
/* 32 */     write(outputStream, paramIDLRepletException);
/* 33 */     paramAny.read_value(outputStream.create_input_stream(), type());
/*    */   }
/*    */   
/*    */   public static TypeCode type() {
/* 37 */     boolean bool = true;
/* 38 */     StructMember[] arrayOfStructMember = null;
/* 39 */     if (_tc == null) {
/* 40 */       arrayOfStructMember = new StructMember[1];
/* 41 */       arrayOfStructMember[0] = new StructMember("msg", ORB.init().get_primitive_tc(TCKind.tk_string), null);
/*    */ 
/*    */ 
/*    */       
/* 45 */       _tc = ORB.init().create_exception_tc(id(), "IDLRepletException", arrayOfStructMember);
/*    */     } 
/* 47 */     return _tc;
/*    */   }
/*    */   
/* 50 */   public static String id() { return "IDL:inetsoft/sree/corba/IDLRepletException:1.0"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\IDLRepletExceptionHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */