package inetsoft.sree.corba;

import org.omg.CORBA.Any;
import org.omg.CORBA.ORB;
import org.omg.CORBA.StructMember;
import org.omg.CORBA.TCKind;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;

public class IDLRepletExceptionHelper {
  private static TypeCode _tc;
  
  public static void write(OutputStream paramOutputStream, IDLRepletException paramIDLRepletException) {
    paramOutputStream.write_string(id());
    paramOutputStream.write_string(paramIDLRepletException.msg);
  }
  
  public static IDLRepletException read(InputStream paramInputStream) {
    IDLRepletException iDLRepletException = new IDLRepletException();
    paramInputStream.read_string();
    iDLRepletException.msg = paramInputStream.read_string();
    return iDLRepletException;
  }
  
  public static IDLRepletException extract(Any paramAny) {
    InputStream inputStream = paramAny.create_input_stream();
    return read(inputStream);
  }
  
  public static void insert(Any paramAny, IDLRepletException paramIDLRepletException) {
    OutputStream outputStream = paramAny.create_output_stream();
    write(outputStream, paramIDLRepletException);
    paramAny.read_value(outputStream.create_input_stream(), type());
  }
  
  public static TypeCode type() {
    boolean bool = true;
    StructMember[] arrayOfStructMember = null;
    if (_tc == null) {
      arrayOfStructMember = new StructMember[1];
      arrayOfStructMember[0] = new StructMember("msg", ORB.init().get_primitive_tc(TCKind.tk_string), null);
      _tc = ORB.init().create_exception_tc(id(), "IDLRepletException", arrayOfStructMember);
    } 
    return _tc;
  }
  
  public static String id() { return "IDL:inetsoft/sree/corba/IDLRepletException:1.0"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\IDLRepletExceptionHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */