/*     */ package inetsoft.sree.corba;
/*     */ 
/*     */ import inetsoft.sree.PageLocation;
/*     */ import inetsoft.sree.RepletEngine;
/*     */ import inetsoft.sree.RepletException;
/*     */ import inetsoft.sree.RepletRepository;
/*     */ import inetsoft.sree.RepletRequest;
/*     */ import inetsoft.sree.SearchCondition;
/*     */ import inetsoft.sree.SreeEnv;
/*     */ import inetsoft.sree.SreeLog;
/*     */ import java.awt.Point;
/*     */ import java.rmi.Naming;
/*     */ import java.util.EventObject;
/*     */ import org.omg.CORBA.ORB;
/*     */ import org.omg.CORBA.Object;
/*     */ import org.omg.CosNaming.NameComponent;
/*     */ import org.omg.CosNaming.NamingContext;
/*     */ import org.omg.CosNaming.NamingContextHelper;
/*     */ 
/*     */ public class RepositoryServer
/*     */   extends _IDLRepletRepositoryImplBase {
/*     */   RepletRepository engine;
/*     */   DataEncoder coder;
/*     */   
/*     */   public RepositoryServer(RepletRepository paramRepletRepository, ORB paramORB) {
/*  26 */     if (paramRepletRepository == null) {
/*  27 */       this.engine = new RepletEngine();
/*  28 */       ((RepletEngine)this.engine).init();
/*     */     } else {
/*     */       
/*  31 */       this.engine = paramRepletRepository;
/*     */     } 
/*     */     
/*  34 */     this.coder = new DataEncoder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRepletNames(byte[] paramArrayOfByte) {
/*     */     try {
/*  45 */       return this.engine.getRepletNames(this.coder.decode(paramArrayOfByte));
/*  46 */     } catch (Throwable throwable) {
/*  47 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/*  50 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String create(String paramString, byte[] paramArrayOfByte) throws IDLRepletException {
/*     */     try {
/*  61 */       return (String)this.engine.create(paramString, this.coder.decode(paramArrayOfByte));
/*  62 */     } catch (RepletException repletException) {
/*  63 */       throw new IDLRepletException(repletException.getMessage());
/*  64 */     } catch (Throwable throwable) {
/*  65 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/*  68 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getRepletParameters(String paramString1, String paramString2) {
/*     */     try {
/*  80 */       return this.coder.encode(this.engine.getRepletParameters(paramString1, paramString2));
/*  81 */     } catch (Throwable throwable) {
/*  82 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/*  85 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(String paramString, byte[] paramArrayOfByte) throws IDLRepletException {
/*     */     try {
/*  96 */       this.engine.generate(paramString, (RepletRequest)this.coder.decode(paramArrayOfByte));
/*  97 */     } catch (RepletException repletException) {
/*  98 */       throw new IDLRepletException(repletException.getMessage());
/*  99 */     } catch (Throwable throwable) {
/* 100 */       SreeLog.print(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEventMask(String paramString) {
/*     */     try {
/* 112 */       return this.engine.getEventMask(paramString);
/* 113 */     } catch (Throwable throwable) {
/* 114 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 117 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getEventHandler(String paramString) {
/*     */     try {
/* 127 */       return this.coder.encode(this.engine.getEventHandler(paramString));
/* 128 */     } catch (Throwable throwable) {
/* 129 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 132 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] handleEvent(String paramString, byte[] paramArrayOfByte) {
/*     */     try {
/* 145 */       EventObject eventObject = (EventObject)this.coder.decode(paramArrayOfByte);
/* 146 */       return this.coder.encode(this.engine.handleEvent(paramString, eventObject));
/* 147 */     } catch (Throwable throwable) {
/* 148 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 151 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getRegisteredSelections(String paramString) {
/*     */     try {
/* 160 */       return this.coder.encode(this.engine.getRegisteredSelections(paramString));
/* 161 */     } catch (Throwable throwable) {
/* 162 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 165 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPage(String paramString, int paramInt) {
/*     */     try {
/* 177 */       return this.coder.encode(this.engine.getPage(paramString, paramInt));
/* 178 */     } catch (Throwable throwable) {
/* 179 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 182 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPageCount(String paramString) {
/*     */     try {
/* 192 */       return this.engine.getPageCount(paramString);
/* 193 */     } catch (Throwable throwable) {
/* 194 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 197 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] find(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
/*     */     try {
/* 211 */       return this.coder.encode(this.engine.find(paramString, 
/* 212 */             (SearchCondition)this.coder.decode(paramArrayOfByte1), 
/*     */             
/* 214 */             (PageLocation)this.coder.decode(paramArrayOfByte2)));
/* 215 */     } catch (Throwable throwable) {
/* 216 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 219 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getTOCPaths(String paramString) {
/*     */     try {
/* 231 */       return this.engine.getTOCPaths(paramString);
/* 232 */     } catch (Throwable throwable) {
/* 233 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 236 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getTOCLocations(String paramString) {
/*     */     try {
/* 246 */       return this.coder.encode(this.engine.getTOCLocations(paramString));
/* 247 */     } catch (Throwable throwable) {
/* 248 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 251 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPageLocation(String paramString1, String paramString2, int paramInt1, int paramInt2) {
/*     */     try {
/* 263 */       Point point = (paramInt1 < 0 && paramInt2 < 0) ? null : new Point(paramInt1, paramInt2);
/* 264 */       return this.coder.encode(this.engine.getPageLocation(paramString1, paramString2, point));
/* 265 */     } catch (Throwable throwable) {
/* 266 */       SreeLog.print(throwable);
/*     */ 
/*     */       
/* 269 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mailTo(String paramString1, String paramString2, String paramString3, String paramString4) throws IDLRepletException {
/*     */     try {
/* 283 */       this.engine.mailTo(paramString1, paramString2, paramString3, paramString4);
/* 284 */     } catch (Throwable throwable) {
/* 285 */       SreeLog.print(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String export(String paramString, int paramInt) throws IDLRepletException {
/*     */     try {
/* 301 */       return (String)this.engine.export(paramString, paramInt);
/* 302 */     } catch (RepletException repletException) {
/* 303 */       throw new IDLRepletException(repletException.getMessage());
/* 304 */     } catch (Throwable throwable) {
/* 305 */       SreeLog.print(throwable);
/* 306 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] nextBlock(String paramString) {
/*     */     try {
/* 319 */       return this.engine.nextBlock(paramString);
/* 320 */     } catch (RepletException repletException) {
/* 321 */       throw new IDLRepletException(repletException.getMessage());
/* 322 */     } catch (Throwable throwable) {
/* 323 */       SreeLog.print(throwable);
/* 324 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPrinters() {
/*     */     try {
/* 334 */       return this.engine.getPrinters();
/* 335 */     } catch (Throwable throwable) {
/* 336 */       SreeLog.print(throwable);
/* 337 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(String paramString1, String paramString2) throws IDLRepletException {
/*     */     try {
/* 350 */       this.engine.print(paramString1, paramString2);
/* 351 */     } catch (RepletException repletException) {
/* 352 */       throw new IDLRepletException(repletException.getMessage());
/* 353 */     } catch (Throwable throwable) {
/* 354 */       SreeLog.print(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy(String paramString) {
/*     */     try {
/* 365 */       this.engine.destroy(paramString);
/* 366 */     } catch (Throwable throwable) {
/* 367 */       SreeLog.print(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 380 */     RepletRepository repletRepository = null;
/*     */     
/* 382 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 383 */       if (paramArrayOfString[b].startsWith("-master")) {
/*     */         try {
/* 385 */           repletRepository = (RepletRepository)Naming.lookup(paramArrayOfString[++b]);
/* 386 */         } catch (Throwable throwable) {
/* 387 */           SreeLog.print(throwable);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 394 */       SreeLog.print("Initializing ORB...");
/* 395 */       ORB oRB = ORB.init(paramArrayOfString, SreeEnv.getProperties());
/*     */ 
/*     */       
/* 398 */       RepositoryServer repositoryServer = new RepositoryServer(repletRepository, oRB);
/* 399 */       SreeLog.print("Connecting to ORB...");
/* 400 */       oRB.connect(repositoryServer);
/*     */ 
/*     */       
/* 403 */       Object object = 
/* 404 */         oRB.resolve_initial_references("NameService");
/* 405 */       NamingContext namingContext = NamingContextHelper.narrow(object);
/*     */ 
/*     */       
/* 408 */       NameComponent nameComponent = new NameComponent("RepletRepository", "");
/* 409 */       NameComponent[] arrayOfNameComponent = { nameComponent };
/* 410 */       SreeLog.print("Binding to name services...");
/* 411 */       namingContext.rebind(arrayOfNameComponent, repositoryServer);
/*     */ 
/*     */       
/* 414 */       Object object1 = new Object();
/* 415 */       synchronized (object1) {
/* 416 */         SreeLog.print("Waiting for request...");
/* 417 */         object1.wait();
/*     */       } 
/* 419 */     } catch (Exception exception) {
/* 420 */       SreeLog.print("ERROR: " + exception);
/* 421 */       SreeLog.print(exception);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\RepositoryServer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */