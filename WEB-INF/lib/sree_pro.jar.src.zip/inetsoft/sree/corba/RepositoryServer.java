package inetsoft.sree.corba;

import inetsoft.sree.PageLocation;
import inetsoft.sree.RepletEngine;
import inetsoft.sree.RepletException;
import inetsoft.sree.RepletRepository;
import inetsoft.sree.RepletRequest;
import inetsoft.sree.SearchCondition;
import inetsoft.sree.SreeEnv;
import inetsoft.sree.SreeLog;
import java.awt.Point;
import java.rmi.Naming;
import java.util.EventObject;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;

public class RepositoryServer extends _IDLRepletRepositoryImplBase {
  RepletRepository engine;
  
  DataEncoder coder;
  
  public RepositoryServer(RepletRepository paramRepletRepository, ORB paramORB) {
    if (paramRepletRepository == null) {
      this.engine = new RepletEngine();
      ((RepletEngine)this.engine).init();
    } else {
      this.engine = paramRepletRepository;
    } 
    this.coder = new DataEncoder();
  }
  
  public String[] getRepletNames(byte[] paramArrayOfByte) {
    try {
      return this.engine.getRepletNames(this.coder.decode(paramArrayOfByte));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public String create(String paramString, byte[] paramArrayOfByte) throws IDLRepletException {
    try {
      return (String)this.engine.create(paramString, this.coder.decode(paramArrayOfByte));
    } catch (RepletException repletException) {
      throw new IDLRepletException(repletException.getMessage());
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public byte[] getRepletParameters(String paramString1, String paramString2) {
    try {
      return this.coder.encode(this.engine.getRepletParameters(paramString1, paramString2));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public void generate(String paramString, byte[] paramArrayOfByte) throws IDLRepletException {
    try {
      this.engine.generate(paramString, (RepletRequest)this.coder.decode(paramArrayOfByte));
    } catch (RepletException repletException) {
      throw new IDLRepletException(repletException.getMessage());
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
    } 
  }
  
  public int getEventMask(String paramString) {
    try {
      return this.engine.getEventMask(paramString);
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return 0;
    } 
  }
  
  public byte[] getEventHandler(String paramString) {
    try {
      return this.coder.encode(this.engine.getEventHandler(paramString));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public byte[] handleEvent(String paramString, byte[] paramArrayOfByte) {
    try {
      EventObject eventObject = (EventObject)this.coder.decode(paramArrayOfByte);
      return this.coder.encode(this.engine.handleEvent(paramString, eventObject));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public byte[] getRegisteredSelections(String paramString) {
    try {
      return this.coder.encode(this.engine.getRegisteredSelections(paramString));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public byte[] getPage(String paramString, int paramInt) {
    try {
      return this.coder.encode(this.engine.getPage(paramString, paramInt));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public int getPageCount(String paramString) {
    try {
      return this.engine.getPageCount(paramString);
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return 0;
    } 
  }
  
  public byte[] find(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
    try {
      return this.coder.encode(this.engine.find(paramString, 
            (SearchCondition)this.coder.decode(paramArrayOfByte1), 
            
            (PageLocation)this.coder.decode(paramArrayOfByte2)));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public String[] getTOCPaths(String paramString) {
    try {
      return this.engine.getTOCPaths(paramString);
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public byte[] getTOCLocations(String paramString) {
    try {
      return this.coder.encode(this.engine.getTOCLocations(paramString));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public byte[] getPageLocation(String paramString1, String paramString2, int paramInt1, int paramInt2) {
    try {
      Point point = (paramInt1 < 0 && paramInt2 < 0) ? null : new Point(paramInt1, paramInt2);
      return this.coder.encode(this.engine.getPageLocation(paramString1, paramString2, point));
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public void mailTo(String paramString1, String paramString2, String paramString3, String paramString4) throws IDLRepletException {
    try {
      this.engine.mailTo(paramString1, paramString2, paramString3, paramString4);
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
    } 
  }
  
  public String export(String paramString, int paramInt) throws IDLRepletException {
    try {
      return (String)this.engine.export(paramString, paramInt);
    } catch (RepletException repletException) {
      throw new IDLRepletException(repletException.getMessage());
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public byte[] nextBlock(String paramString) {
    try {
      return this.engine.nextBlock(paramString);
    } catch (RepletException repletException) {
      throw new IDLRepletException(repletException.getMessage());
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public String[] getPrinters() {
    try {
      return this.engine.getPrinters();
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
      return null;
    } 
  }
  
  public void print(String paramString1, String paramString2) throws IDLRepletException {
    try {
      this.engine.print(paramString1, paramString2);
    } catch (RepletException repletException) {
      throw new IDLRepletException(repletException.getMessage());
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
    } 
  }
  
  public void destroy(String paramString) {
    try {
      this.engine.destroy(paramString);
    } catch (Throwable throwable) {
      SreeLog.print(throwable);
    } 
  }
  
  public static void main(String[] paramArrayOfString) {
    RepletRepository repletRepository = null;
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramArrayOfString[b].startsWith("-master"))
        try {
          repletRepository = (RepletRepository)Naming.lookup(paramArrayOfString[++b]);
        } catch (Throwable throwable) {
          SreeLog.print(throwable);
        }  
    } 
    try {
      SreeLog.print("Initializing ORB...");
      ORB oRB = ORB.init(paramArrayOfString, SreeEnv.getProperties());
      RepositoryServer repositoryServer = new RepositoryServer(repletRepository, oRB);
      SreeLog.print("Connecting to ORB...");
      oRB.connect(repositoryServer);
      Object object = 
        oRB.resolve_initial_references("NameService");
      NamingContext namingContext = NamingContextHelper.narrow(object);
      NameComponent nameComponent = new NameComponent("RepletRepository", "");
      NameComponent[] arrayOfNameComponent = { nameComponent };
      SreeLog.print("Binding to name services...");
      namingContext.rebind(arrayOfNameComponent, repositoryServer);
      Object object1 = new Object();
      synchronized (object1) {
        SreeLog.print("Waiting for request...");
        object1.wait();
      } 
    } catch (Exception exception) {
      SreeLog.print("ERROR: " + exception);
      SreeLog.print(exception);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\RepositoryServer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */