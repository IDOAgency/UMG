/*     */ package inetsoft.sree.corba;
/*     */ 
/*     */ import org.omg.CORBA.Any;
/*     */ import org.omg.CORBA.ORB;
/*     */ import org.omg.CORBA.Request;
/*     */ import org.omg.CORBA.TCKind;
/*     */ import org.omg.CORBA.UnknownUserException;
/*     */ import org.omg.CORBA.portable.Delegate;
/*     */ import org.omg.CORBA.portable.ObjectImpl;
/*     */ 
/*     */ public class _IDLRepletRepositoryStub
/*     */   extends ObjectImpl
/*     */   implements IDLRepletRepository
/*     */ {
/*  15 */   public _IDLRepletRepositoryStub(Delegate paramDelegate) { _set_delegate(paramDelegate); }
/*     */ 
/*     */   
/*  18 */   private static final String[] _type_ids = { "IDL:inetsoft/sree/corba/IDLRepletRepository:1.0" };
/*     */ 
/*     */ 
/*     */   
/*  22 */   public String[] _ids() { return (String[])_type_ids.clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRepletNames(byte[] paramArrayOfByte) {
/*  28 */     Request request = _request("getRepletNames");
/*  29 */     request.set_return_type(stringListHelper.type());
/*  30 */     Any any = request.add_in_arg();
/*  31 */     serializableHelper.insert(any, paramArrayOfByte);
/*  32 */     request.invoke();
/*     */     
/*  34 */     return stringListHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String create(String paramString, byte[] paramArrayOfByte) throws IDLRepletException {
/*  40 */     Request request = _request("create");
/*  41 */     request.set_return_type(ORB.init().get_primitive_tc(TCKind.tk_string));
/*  42 */     Any any1 = request.add_in_arg();
/*  43 */     any1.insert_string(paramString);
/*  44 */     Any any2 = request.add_in_arg();
/*  45 */     serializableHelper.insert(any2, paramArrayOfByte);
/*  46 */     request.exceptions().add(IDLRepletExceptionHelper.type());
/*  47 */     request.invoke();
/*  48 */     Exception exception = request.env().exception();
/*  49 */     if (exception instanceof UnknownUserException) {
/*  50 */       UnknownUserException unknownUserException = (UnknownUserException)exception;
/*  51 */       if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type())) {
/*  52 */         throw IDLRepletExceptionHelper.extract(unknownUserException.except);
/*     */       }
/*     */     } 
/*     */     
/*  56 */     return request.return_value().extract_string();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getRepletParameters(String paramString1, String paramString2) {
/*  62 */     Request request = _request("getRepletParameters");
/*  63 */     request.set_return_type(serializableHelper.type());
/*  64 */     Any any1 = request.add_in_arg();
/*  65 */     any1.insert_string(paramString1);
/*  66 */     Any any2 = request.add_in_arg();
/*  67 */     any2.insert_string(paramString2);
/*  68 */     request.invoke();
/*     */     
/*  70 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(String paramString, byte[] paramArrayOfByte) throws IDLRepletException {
/*  76 */     Request request = _request("generate");
/*  77 */     Any any1 = request.add_in_arg();
/*  78 */     any1.insert_string(paramString);
/*  79 */     Any any2 = request.add_in_arg();
/*  80 */     serializableHelper.insert(any2, paramArrayOfByte);
/*  81 */     request.exceptions().add(IDLRepletExceptionHelper.type());
/*  82 */     request.invoke();
/*  83 */     Exception exception = request.env().exception();
/*  84 */     if (exception instanceof UnknownUserException) {
/*  85 */       UnknownUserException unknownUserException = (UnknownUserException)exception;
/*  86 */       if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type())) {
/*  87 */         throw IDLRepletExceptionHelper.extract(unknownUserException.except);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getEventMask(String paramString) {
/*  94 */     Request request = _request("getEventMask");
/*  95 */     request.set_return_type(ORB.init().get_primitive_tc(TCKind.tk_long));
/*  96 */     Any any = request.add_in_arg();
/*  97 */     any.insert_string(paramString);
/*  98 */     request.invoke();
/*     */     
/* 100 */     return request.return_value().extract_long();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getEventHandler(String paramString) {
/* 106 */     Request request = _request("getEventHandler");
/* 107 */     request.set_return_type(serializableHelper.type());
/* 108 */     Any any = request.add_in_arg();
/* 109 */     any.insert_string(paramString);
/* 110 */     request.invoke();
/*     */     
/* 112 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] handleEvent(String paramString, byte[] paramArrayOfByte) {
/* 118 */     Request request = _request("handleEvent");
/* 119 */     request.set_return_type(serializableHelper.type());
/* 120 */     Any any1 = request.add_in_arg();
/* 121 */     any1.insert_string(paramString);
/* 122 */     Any any2 = request.add_in_arg();
/* 123 */     serializableHelper.insert(any2, paramArrayOfByte);
/* 124 */     request.invoke();
/*     */     
/* 126 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getRegisteredSelections(String paramString) {
/* 132 */     Request request = _request("getRegisteredSelections");
/* 133 */     request.set_return_type(serializableHelper.type());
/* 134 */     Any any = request.add_in_arg();
/* 135 */     any.insert_string(paramString);
/* 136 */     request.invoke();
/*     */     
/* 138 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPage(String paramString, int paramInt) {
/* 144 */     Request request = _request("getPage");
/* 145 */     request.set_return_type(serializableHelper.type());
/* 146 */     Any any1 = request.add_in_arg();
/* 147 */     any1.insert_string(paramString);
/* 148 */     Any any2 = request.add_in_arg();
/* 149 */     any2.insert_long(paramInt);
/* 150 */     request.invoke();
/*     */     
/* 152 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPageCount(String paramString) {
/* 158 */     Request request = _request("getPageCount");
/* 159 */     request.set_return_type(ORB.init().get_primitive_tc(TCKind.tk_long));
/* 160 */     Any any = request.add_in_arg();
/* 161 */     any.insert_string(paramString);
/* 162 */     request.invoke();
/*     */     
/* 164 */     return request.return_value().extract_long();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] find(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
/* 170 */     Request request = _request("find");
/* 171 */     request.set_return_type(serializableHelper.type());
/* 172 */     Any any1 = request.add_in_arg();
/* 173 */     any1.insert_string(paramString);
/* 174 */     Any any2 = request.add_in_arg();
/* 175 */     serializableHelper.insert(any2, paramArrayOfByte1);
/* 176 */     Any any3 = request.add_in_arg();
/* 177 */     serializableHelper.insert(any3, paramArrayOfByte2);
/* 178 */     request.invoke();
/*     */     
/* 180 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getTOCPaths(String paramString) {
/* 186 */     Request request = _request("getTOCPaths");
/* 187 */     request.set_return_type(stringListHelper.type());
/* 188 */     Any any = request.add_in_arg();
/* 189 */     any.insert_string(paramString);
/* 190 */     request.invoke();
/*     */     
/* 192 */     return stringListHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getTOCLocations(String paramString) {
/* 198 */     Request request = _request("getTOCLocations");
/* 199 */     request.set_return_type(serializableHelper.type());
/* 200 */     Any any = request.add_in_arg();
/* 201 */     any.insert_string(paramString);
/* 202 */     request.invoke();
/*     */     
/* 204 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getPageLocation(String paramString1, String paramString2, int paramInt1, int paramInt2) {
/* 210 */     Request request = _request("getPageLocation");
/* 211 */     request.set_return_type(serializableHelper.type());
/* 212 */     Any any1 = request.add_in_arg();
/* 213 */     any1.insert_string(paramString1);
/* 214 */     Any any2 = request.add_in_arg();
/* 215 */     any2.insert_string(paramString2);
/* 216 */     Any any3 = request.add_in_arg();
/* 217 */     any3.insert_long(paramInt1);
/* 218 */     Any any4 = request.add_in_arg();
/* 219 */     any4.insert_long(paramInt2);
/* 220 */     request.invoke();
/*     */     
/* 222 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mailTo(String paramString1, String paramString2, String paramString3, String paramString4) throws IDLRepletException {
/* 228 */     Request request = _request("mailTo");
/* 229 */     Any any1 = request.add_in_arg();
/* 230 */     any1.insert_string(paramString1);
/* 231 */     Any any2 = request.add_in_arg();
/* 232 */     any2.insert_string(paramString2);
/* 233 */     Any any3 = request.add_in_arg();
/* 234 */     any3.insert_string(paramString3);
/* 235 */     Any any4 = request.add_in_arg();
/* 236 */     any4.insert_string(paramString4);
/* 237 */     request.exceptions().add(IDLRepletExceptionHelper.type());
/* 238 */     request.invoke();
/* 239 */     Exception exception = request.env().exception();
/* 240 */     if (exception instanceof UnknownUserException) {
/* 241 */       UnknownUserException unknownUserException = (UnknownUserException)exception;
/* 242 */       if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type())) {
/* 243 */         throw IDLRepletExceptionHelper.extract(unknownUserException.except);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String export(String paramString, int paramInt) throws IDLRepletException {
/* 250 */     Request request = _request("export");
/* 251 */     request.set_return_type(ORB.init().get_primitive_tc(TCKind.tk_string));
/* 252 */     Any any1 = request.add_in_arg();
/* 253 */     any1.insert_string(paramString);
/* 254 */     Any any2 = request.add_in_arg();
/* 255 */     any2.insert_long(paramInt);
/* 256 */     request.exceptions().add(IDLRepletExceptionHelper.type());
/* 257 */     request.invoke();
/* 258 */     Exception exception = request.env().exception();
/* 259 */     if (exception instanceof UnknownUserException) {
/* 260 */       UnknownUserException unknownUserException = (UnknownUserException)exception;
/* 261 */       if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type())) {
/* 262 */         throw IDLRepletExceptionHelper.extract(unknownUserException.except);
/*     */       }
/*     */     } 
/*     */     
/* 266 */     return request.return_value().extract_string();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] nextBlock(String paramString) {
/* 272 */     Request request = _request("nextBlock");
/* 273 */     request.set_return_type(serializableHelper.type());
/* 274 */     Any any = request.add_in_arg();
/* 275 */     any.insert_string(paramString);
/* 276 */     request.exceptions().add(IDLRepletExceptionHelper.type());
/* 277 */     request.invoke();
/* 278 */     Exception exception = request.env().exception();
/* 279 */     if (exception instanceof UnknownUserException) {
/* 280 */       UnknownUserException unknownUserException = (UnknownUserException)exception;
/* 281 */       if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type())) {
/* 282 */         throw IDLRepletExceptionHelper.extract(unknownUserException.except);
/*     */       }
/*     */     } 
/*     */     
/* 286 */     return serializableHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPrinters() {
/* 292 */     Request request = _request("getPrinters");
/* 293 */     request.set_return_type(stringListHelper.type());
/* 294 */     request.invoke();
/*     */     
/* 296 */     return stringListHelper.extract(request.return_value());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void print(String paramString1, String paramString2) throws IDLRepletException {
/* 302 */     Request request = _request("print");
/* 303 */     Any any1 = request.add_in_arg();
/* 304 */     any1.insert_string(paramString1);
/* 305 */     Any any2 = request.add_in_arg();
/* 306 */     any2.insert_string(paramString2);
/* 307 */     request.exceptions().add(IDLRepletExceptionHelper.type());
/* 308 */     request.invoke();
/* 309 */     Exception exception = request.env().exception();
/* 310 */     if (exception instanceof UnknownUserException) {
/* 311 */       UnknownUserException unknownUserException = (UnknownUserException)exception;
/* 312 */       if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type())) {
/* 313 */         throw IDLRepletExceptionHelper.extract(unknownUserException.except);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy(String paramString) {
/* 320 */     Request request = _request("destroy");
/* 321 */     Any any = request.add_in_arg();
/* 322 */     any.insert_string(paramString);
/* 323 */     request.invoke();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\_IDLRepletRepositoryStub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */