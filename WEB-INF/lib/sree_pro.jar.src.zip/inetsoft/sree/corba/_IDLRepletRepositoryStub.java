package inetsoft.sree.corba;

import org.omg.CORBA.Any;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Request;
import org.omg.CORBA.TCKind;
import org.omg.CORBA.UnknownUserException;
import org.omg.CORBA.portable.Delegate;
import org.omg.CORBA.portable.ObjectImpl;

public class _IDLRepletRepositoryStub extends ObjectImpl implements IDLRepletRepository {
  public _IDLRepletRepositoryStub(Delegate paramDelegate) { _set_delegate(paramDelegate); }
  
  private static final String[] _type_ids = { "IDL:inetsoft/sree/corba/IDLRepletRepository:1.0" };
  
  public String[] _ids() { return (String[])_type_ids.clone(); }
  
  public String[] getRepletNames(byte[] paramArrayOfByte) {
    Request request = _request("getRepletNames");
    request.set_return_type(stringListHelper.type());
    Any any = request.add_in_arg();
    serializableHelper.insert(any, paramArrayOfByte);
    request.invoke();
    return stringListHelper.extract(request.return_value());
  }
  
  public String create(String paramString, byte[] paramArrayOfByte) throws IDLRepletException {
    Request request = _request("create");
    request.set_return_type(ORB.init().get_primitive_tc(TCKind.tk_string));
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString);
    Any any2 = request.add_in_arg();
    serializableHelper.insert(any2, paramArrayOfByte);
    request.exceptions().add(IDLRepletExceptionHelper.type());
    request.invoke();
    Exception exception = request.env().exception();
    if (exception instanceof UnknownUserException) {
      UnknownUserException unknownUserException = (UnknownUserException)exception;
      if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type()))
        throw IDLRepletExceptionHelper.extract(unknownUserException.except); 
    } 
    return request.return_value().extract_string();
  }
  
  public byte[] getRepletParameters(String paramString1, String paramString2) {
    Request request = _request("getRepletParameters");
    request.set_return_type(serializableHelper.type());
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString1);
    Any any2 = request.add_in_arg();
    any2.insert_string(paramString2);
    request.invoke();
    return serializableHelper.extract(request.return_value());
  }
  
  public void generate(String paramString, byte[] paramArrayOfByte) throws IDLRepletException {
    Request request = _request("generate");
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString);
    Any any2 = request.add_in_arg();
    serializableHelper.insert(any2, paramArrayOfByte);
    request.exceptions().add(IDLRepletExceptionHelper.type());
    request.invoke();
    Exception exception = request.env().exception();
    if (exception instanceof UnknownUserException) {
      UnknownUserException unknownUserException = (UnknownUserException)exception;
      if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type()))
        throw IDLRepletExceptionHelper.extract(unknownUserException.except); 
    } 
  }
  
  public int getEventMask(String paramString) {
    Request request = _request("getEventMask");
    request.set_return_type(ORB.init().get_primitive_tc(TCKind.tk_long));
    Any any = request.add_in_arg();
    any.insert_string(paramString);
    request.invoke();
    return request.return_value().extract_long();
  }
  
  public byte[] getEventHandler(String paramString) {
    Request request = _request("getEventHandler");
    request.set_return_type(serializableHelper.type());
    Any any = request.add_in_arg();
    any.insert_string(paramString);
    request.invoke();
    return serializableHelper.extract(request.return_value());
  }
  
  public byte[] handleEvent(String paramString, byte[] paramArrayOfByte) {
    Request request = _request("handleEvent");
    request.set_return_type(serializableHelper.type());
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString);
    Any any2 = request.add_in_arg();
    serializableHelper.insert(any2, paramArrayOfByte);
    request.invoke();
    return serializableHelper.extract(request.return_value());
  }
  
  public byte[] getRegisteredSelections(String paramString) {
    Request request = _request("getRegisteredSelections");
    request.set_return_type(serializableHelper.type());
    Any any = request.add_in_arg();
    any.insert_string(paramString);
    request.invoke();
    return serializableHelper.extract(request.return_value());
  }
  
  public byte[] getPage(String paramString, int paramInt) {
    Request request = _request("getPage");
    request.set_return_type(serializableHelper.type());
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString);
    Any any2 = request.add_in_arg();
    any2.insert_long(paramInt);
    request.invoke();
    return serializableHelper.extract(request.return_value());
  }
  
  public int getPageCount(String paramString) {
    Request request = _request("getPageCount");
    request.set_return_type(ORB.init().get_primitive_tc(TCKind.tk_long));
    Any any = request.add_in_arg();
    any.insert_string(paramString);
    request.invoke();
    return request.return_value().extract_long();
  }
  
  public byte[] find(String paramString, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
    Request request = _request("find");
    request.set_return_type(serializableHelper.type());
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString);
    Any any2 = request.add_in_arg();
    serializableHelper.insert(any2, paramArrayOfByte1);
    Any any3 = request.add_in_arg();
    serializableHelper.insert(any3, paramArrayOfByte2);
    request.invoke();
    return serializableHelper.extract(request.return_value());
  }
  
  public String[] getTOCPaths(String paramString) {
    Request request = _request("getTOCPaths");
    request.set_return_type(stringListHelper.type());
    Any any = request.add_in_arg();
    any.insert_string(paramString);
    request.invoke();
    return stringListHelper.extract(request.return_value());
  }
  
  public byte[] getTOCLocations(String paramString) {
    Request request = _request("getTOCLocations");
    request.set_return_type(serializableHelper.type());
    Any any = request.add_in_arg();
    any.insert_string(paramString);
    request.invoke();
    return serializableHelper.extract(request.return_value());
  }
  
  public byte[] getPageLocation(String paramString1, String paramString2, int paramInt1, int paramInt2) {
    Request request = _request("getPageLocation");
    request.set_return_type(serializableHelper.type());
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString1);
    Any any2 = request.add_in_arg();
    any2.insert_string(paramString2);
    Any any3 = request.add_in_arg();
    any3.insert_long(paramInt1);
    Any any4 = request.add_in_arg();
    any4.insert_long(paramInt2);
    request.invoke();
    return serializableHelper.extract(request.return_value());
  }
  
  public void mailTo(String paramString1, String paramString2, String paramString3, String paramString4) throws IDLRepletException {
    Request request = _request("mailTo");
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString1);
    Any any2 = request.add_in_arg();
    any2.insert_string(paramString2);
    Any any3 = request.add_in_arg();
    any3.insert_string(paramString3);
    Any any4 = request.add_in_arg();
    any4.insert_string(paramString4);
    request.exceptions().add(IDLRepletExceptionHelper.type());
    request.invoke();
    Exception exception = request.env().exception();
    if (exception instanceof UnknownUserException) {
      UnknownUserException unknownUserException = (UnknownUserException)exception;
      if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type()))
        throw IDLRepletExceptionHelper.extract(unknownUserException.except); 
    } 
  }
  
  public String export(String paramString, int paramInt) throws IDLRepletException {
    Request request = _request("export");
    request.set_return_type(ORB.init().get_primitive_tc(TCKind.tk_string));
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString);
    Any any2 = request.add_in_arg();
    any2.insert_long(paramInt);
    request.exceptions().add(IDLRepletExceptionHelper.type());
    request.invoke();
    Exception exception = request.env().exception();
    if (exception instanceof UnknownUserException) {
      UnknownUserException unknownUserException = (UnknownUserException)exception;
      if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type()))
        throw IDLRepletExceptionHelper.extract(unknownUserException.except); 
    } 
    return request.return_value().extract_string();
  }
  
  public byte[] nextBlock(String paramString) {
    Request request = _request("nextBlock");
    request.set_return_type(serializableHelper.type());
    Any any = request.add_in_arg();
    any.insert_string(paramString);
    request.exceptions().add(IDLRepletExceptionHelper.type());
    request.invoke();
    Exception exception = request.env().exception();
    if (exception instanceof UnknownUserException) {
      UnknownUserException unknownUserException = (UnknownUserException)exception;
      if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type()))
        throw IDLRepletExceptionHelper.extract(unknownUserException.except); 
    } 
    return serializableHelper.extract(request.return_value());
  }
  
  public String[] getPrinters() {
    Request request = _request("getPrinters");
    request.set_return_type(stringListHelper.type());
    request.invoke();
    return stringListHelper.extract(request.return_value());
  }
  
  public void print(String paramString1, String paramString2) throws IDLRepletException {
    Request request = _request("print");
    Any any1 = request.add_in_arg();
    any1.insert_string(paramString1);
    Any any2 = request.add_in_arg();
    any2.insert_string(paramString2);
    request.exceptions().add(IDLRepletExceptionHelper.type());
    request.invoke();
    Exception exception = request.env().exception();
    if (exception instanceof UnknownUserException) {
      UnknownUserException unknownUserException = (UnknownUserException)exception;
      if (unknownUserException.except.type().equals(IDLRepletExceptionHelper.type()))
        throw IDLRepletExceptionHelper.extract(unknownUserException.except); 
    } 
  }
  
  public void destroy(String paramString) {
    Request request = _request("destroy");
    Any any = request.add_in_arg();
    any.insert_string(paramString);
    request.invoke();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\_IDLRepletRepositoryStub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */