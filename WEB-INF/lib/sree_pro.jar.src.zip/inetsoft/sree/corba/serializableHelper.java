package inetsoft.sree.corba;

import org.omg.CORBA.Any;
import org.omg.CORBA.ORB;
import org.omg.CORBA.TCKind;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;

public class serializableHelper {
  private static TypeCode _tc;
  
  public static void write(OutputStream paramOutputStream, byte[] paramArrayOfByte) {
    paramOutputStream.write_long(paramArrayOfByte.length);
    paramOutputStream.write_octet_array(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public static byte[] read(InputStream paramInputStream) {
    int i = paramInputStream.read_long();
    byte[] arrayOfByte = new byte[i];
    paramInputStream.read_octet_array(arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
  
  public static byte[] extract(Any paramAny) {
    InputStream inputStream = paramAny.create_input_stream();
    return read(inputStream);
  }
  
  public static void insert(Any paramAny, byte[] paramArrayOfByte) {
    OutputStream outputStream = paramAny.create_output_stream();
    paramAny.type(type());
    write(outputStream, paramArrayOfByte);
    paramAny.read_value(outputStream.create_input_stream(), type());
  }
  
  public static TypeCode type() {
    if (_tc == null)
      _tc = ORB.init().create_alias_tc(id(), "serializable", ORB.init().create_sequence_tc(0, ORB.init().get_primitive_tc(TCKind.tk_octet))); 
    return _tc;
  }
  
  public static String id() { return "IDL:inetsoft/sree/corba/serializable:1.0"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\serializableHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */