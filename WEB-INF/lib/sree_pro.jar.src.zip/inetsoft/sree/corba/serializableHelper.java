/*    */ package inetsoft.sree.corba;
/*    */ 
/*    */ import org.omg.CORBA.Any;
/*    */ import org.omg.CORBA.ORB;
/*    */ import org.omg.CORBA.TCKind;
/*    */ import org.omg.CORBA.TypeCode;
/*    */ import org.omg.CORBA.portable.InputStream;
/*    */ import org.omg.CORBA.portable.OutputStream;
/*    */ 
/*    */ public class serializableHelper
/*    */ {
/*    */   private static TypeCode _tc;
/*    */   
/*    */   public static void write(OutputStream paramOutputStream, byte[] paramArrayOfByte) {
/* 15 */     paramOutputStream.write_long(paramArrayOfByte.length);
/* 16 */     paramOutputStream.write_octet_array(paramArrayOfByte, 0, paramArrayOfByte.length);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] read(InputStream paramInputStream) {
/* 22 */     int i = paramInputStream.read_long();
/* 23 */     byte[] arrayOfByte = new byte[i];
/* 24 */     paramInputStream.read_octet_array(arrayOfByte, 0, arrayOfByte.length);
/*    */     
/* 26 */     return arrayOfByte;
/*    */   }
/*    */   public static byte[] extract(Any paramAny) {
/* 29 */     InputStream inputStream = paramAny.create_input_stream();
/* 30 */     return read(inputStream);
/*    */   }
/*    */   public static void insert(Any paramAny, byte[] paramArrayOfByte) {
/* 33 */     OutputStream outputStream = paramAny.create_output_stream();
/* 34 */     paramAny.type(type());
/* 35 */     write(outputStream, paramArrayOfByte);
/* 36 */     paramAny.read_value(outputStream.create_input_stream(), type());
/*    */   }
/*    */   
/*    */   public static TypeCode type() {
/* 40 */     if (_tc == null)
/* 41 */       _tc = ORB.init().create_alias_tc(id(), "serializable", ORB.init().create_sequence_tc(0, ORB.init().get_primitive_tc(TCKind.tk_octet))); 
/* 42 */     return _tc;
/*    */   }
/*    */   
/* 45 */   public static String id() { return "IDL:inetsoft/sree/corba/serializable:1.0"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\serializableHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */