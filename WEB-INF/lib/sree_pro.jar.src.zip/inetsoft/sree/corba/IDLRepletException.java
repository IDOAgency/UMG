/*    */ package inetsoft.sree.corba;
/*    */ 
/*    */ import org.omg.CORBA.UserException;
/*    */ import org.omg.CORBA.portable.IDLEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IDLRepletException
/*    */   extends UserException
/*    */   implements IDLEntity
/*    */ {
/*    */   public String msg;
/*    */   
/*    */   public IDLRepletException() {}
/*    */   
/* 19 */   public IDLRepletException(String paramString) { this.msg = paramString; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\corba\IDLRepletException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */