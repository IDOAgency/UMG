/*    */ package inetsoft.sree.adm;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import javax.swing.ListModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ListModelEnumeration
/*    */   implements Enumeration
/*    */ {
/*    */   int idx;
/*    */   ListModel model;
/*    */   
/*    */   public ListModelEnumeration(ListModel paramListModel) {
/* 37 */     this.idx = 0;
/*    */     this.model = paramListModel;
/*    */   }
/*    */   
/*    */   public boolean hasMoreElements() { return (this.idx < this.model.getSize()); }
/*    */   
/*    */   public Object nextElement() { return this.model.getElementAt(this.idx++); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\ListModelEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */