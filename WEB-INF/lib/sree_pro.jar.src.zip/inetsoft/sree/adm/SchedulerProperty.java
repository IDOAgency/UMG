package inetsoft.sree.adm;

import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.sree.SreeEnv;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

class SchedulerProperty extends ContentPane {
  JTextField taskTF;
  
  JButton taskBrowseB;
  
  JTextField logTF;
  
  JButton logBrowseB;
  
  NumField deltaTF;
  
  NumField intervalTF;
  
  JButton setB;
  
  JButton restoreB;
  
  public SchedulerProperty() {
    this.taskTF = new JTextField(30);
    this.taskBrowseB = new JButton(Catalog.getString("Browse"));
    this.logTF = new JTextField(30);
    this.logBrowseB = new JButton(Catalog.getString("Browse"));
    this.deltaTF = new NumField(8, true);
    this.intervalTF = new NumField(12, true);
    this.setB = new JButton(Catalog.getString("Set"));
    this.restoreB = new JButton(Catalog.getString("Restore"));
    setLayout(new BorderLayout(5, 5));
    Property2Panel property2Panel = new Property2Panel();
    add(property2Panel, "Center");
    property2Panel.add(Catalog.getString("Files"), new Object[][] { { Catalog.getString("Tasks File") + ":", { this.taskTF, this.taskBrowseB } }, { Catalog.getString("Log File") + ":", { this.logTF, this.logBrowseB } } });
    property2Panel.add(Catalog.getString("Timing"), new Object[][] { { Catalog.getString("Cycle Interval") + ":", this.intervalTF } });
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(2, 10, 5));
    jPanel.add(this.setB);
    this.setB.addActionListener(new ActionListener(this) {
          private final SchedulerProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.set(); }
        });
    jPanel.add(this.restoreB);
    this.restoreB.addActionListener(new ActionListener(this) {
          private final SchedulerProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.restore(); }
        });
    add(jPanel, "South");
    this.taskBrowseB.addActionListener(new BrowseListener(this.taskTF));
    this.logBrowseB.addActionListener(new BrowseListener(this.logTF));
  }
  
  public void init() {
    restore();
    this.taskTF.getDocument().addDocumentListener(this);
    this.logTF.getDocument().addDocumentListener(this);
    this.deltaTF.getDocument().addDocumentListener(this);
    this.intervalTF.getDocument().addDocumentListener(this);
    setEnabled();
  }
  
  void setEnabled() {
    this.setB.setEnabled(this.changed);
    this.restoreB.setEnabled(this.changed);
  }
  
  public void restore() {
    this.taskTF.setText(SreeEnv.getProperty("schedule.task.file", ""));
    this.logTF.setText(SreeEnv.getProperty("schedule.log.file", ""));
    this.deltaTF.setText(SreeEnv.getProperty("schedule.time.delta", "60000"));
    this.intervalTF.setText(SreeEnv.getProperty("schedule.cycle.interval", "43200000"));
    this.changed = false;
    setEnabled();
  }
  
  public void set() {
    SreeEnv.setProperty("schedule.task.file", this.taskTF.getText());
    SreeEnv.setProperty("schedule.log.file", this.logTF.getText());
    SreeEnv.setProperty("schedule.time.delta", this.deltaTF.getText());
    SreeEnv.setProperty("schedule.cycle.interval", this.intervalTF.getText());
    try {
      AdmGui.saveSreeEnv();
      this.changed = false;
      setEnabled();
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      AdmGui.showMessage(throwable.toString());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\SchedulerProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */