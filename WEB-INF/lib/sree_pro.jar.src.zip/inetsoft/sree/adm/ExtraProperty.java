/*     */ package inetsoft.sree.adm;
/*     */ 
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.sree.SreeEnv;
/*     */ import inetsoft.widget.VFlowLayout;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.TitledBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExtraProperty
/*     */   extends ContentPane
/*     */ {
/*     */   JButton setB;
/*     */   JButton restoreB;
/*     */   Pane pane;
/*     */   
/*     */   public ExtraProperty() {
/* 252 */     this.setB = new JButton(Catalog.getString("Set"));
/* 253 */     this.restoreB = new JButton(Catalog.getString("Restore"));
/* 254 */     this.pane = new Pane(this);
/*     */     setLayout(new BorderLayout(5, 5));
/*     */     add(this.pane, "Center");
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setLayout(new FlowLayout(2, 10, 5));
/*     */     jPanel.add(this.setB);
/*     */     this.setB.addActionListener(new ActionListener(this) {
/*     */           private final ExtraProperty this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.set(); }
/*     */         });
/*     */     jPanel.add(this.restoreB);
/*     */     this.restoreB.addActionListener(new ActionListener(this) {
/*     */           private final ExtraProperty this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.restore(); }
/*     */         });
/*     */     add(jPanel, "South");
/*     */   }
/*     */   
/*     */   public void init() {
/*     */     restore();
/*     */     this.changed = false;
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   void setEnabled() {
/*     */     this.setB.setEnabled(this.changed);
/*     */     this.restoreB.setEnabled(this.changed);
/*     */   }
/*     */   
/*     */   public void restore() {
/*     */     this.pane.restore();
/*     */     this.changed = false;
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public void set() {
/*     */     this.pane.set();
/*     */     try {
/*     */       AdmGui.saveSreeEnv();
/*     */       this.changed = false;
/*     */       setEnabled();
/*     */     } catch (Throwable throwable) {
/*     */       throwable.printStackTrace();
/*     */       AdmGui.showMessage(throwable.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   class Pane extends JPanel {
/*     */     FocusListener focusListener;
/*     */     ActionListener removeListener;
/*     */     ActionListener moreListener;
/*     */     Vector params;
/*     */     JPanel paramPnl;
/*     */     Component currfield;
/*     */     JButton addB;
/*     */     JButton removeB;
/*     */     private final ExtraProperty this$0;
/*     */     
/*     */     public Pane(ExtraProperty this$0) {
/*     */       this.this$0 = this$0;
/*     */       this.focusListener = new ExtraProperty$3(this);
/*     */       this.removeListener = new ExtraProperty$4(this);
/*     */       this.moreListener = new ExtraProperty$5(this);
/*     */       this.params = new Vector();
/*     */       this.paramPnl = new JPanel();
/*     */       this.currfield = null;
/*     */       this.addB = new JButton(Catalog.getString("Add"));
/*     */       this.removeB = new JButton(Catalog.getString("Remove"));
/*     */       setLayout(new BorderLayout(5, 2));
/*     */       JPanel jPanel = new JPanel();
/*     */       jPanel.setLayout(new VFlowLayout());
/*     */       jPanel.add(Box.createVerticalStrut(10));
/*     */       jPanel.add(this.addB);
/*     */       this.addB.addActionListener(this.moreListener);
/*     */       jPanel.add(this.removeB);
/*     */       this.removeB.addActionListener(this.removeListener);
/*     */       add(jPanel, "East");
/*     */       JScrollPane jScrollPane = new JScrollPane(this.paramPnl);
/*     */       this.paramPnl.setLayout(new GridBagLayout());
/*     */       setBorder(new TitledBorder(Catalog.getString("Extra Properties")));
/*     */       add(jScrollPane, "Center");
/*     */       setEnabled();
/*     */     }
/*     */     
/*     */     public void set() {
/*     */       Enumeration enumeration = SreeEnv.getProperties().keys();
/*     */       while (enumeration.hasMoreElements()) {
/*     */         String str = (String)enumeration.nextElement();
/*     */         if (str.startsWith("extra."))
/*     */           SreeEnv.getProperties().remove(str); 
/*     */       } 
/*     */       for (byte b = 0; b < this.params.size(); b++) {
/*     */         JTextField[] arrayOfJTextField = (JTextField[])this.params.elementAt(b);
/*     */         String str1 = arrayOfJTextField[0].getText();
/*     */         String str2 = arrayOfJTextField[1].getText();
/*     */         if (str1.length() > 0)
/*     */           SreeEnv.setProperty("extra." + str1, str2); 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void restore() {
/*     */       this.params.removeAllElements();
/*     */       Enumeration enumeration = SreeEnv.getProperties().keys();
/*     */       while (enumeration.hasMoreElements()) {
/*     */         String str = (String)enumeration.nextElement();
/*     */         if (str.startsWith("extra."))
/*     */           addParameter(str.substring(6), SreeEnv.getProperty(str)); 
/*     */       } 
/*     */       setup();
/*     */     }
/*     */     
/*     */     private void addParameter(String param1String, Object param1Object) {
/*     */       JTextField jTextField1 = new JTextField(15);
/*     */       jTextField1.addFocusListener(this.focusListener);
/*     */       jTextField1.getDocument().addDocumentListener(this.this$0);
/*     */       jTextField1.setText(param1String);
/*     */       JTextField jTextField2 = new JTextField(15);
/*     */       jTextField2.setText((param1Object == null) ? "" : param1Object.toString());
/*     */       jTextField2.getDocument().addDocumentListener(this.this$0);
/*     */       this.params.addElement(new JTextField[] { jTextField1, jTextField2 });
/*     */     }
/*     */     
/*     */     private void setup() {
/*     */       while (this.paramPnl.getComponentCount() > 0)
/*     */         this.paramPnl.remove(0); 
/*     */       GridBagConstraints gridBagConstraints = null;
/*     */       for (byte b = 0; b < this.params.size(); b++) {
/*     */         Component[] arrayOfComponent = (Component[])this.params.elementAt(b);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.anchor = 13;
/*     */         this.paramPnl.add(new JLabel("extra."));
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.fill = 2;
/*     */         gridBagConstraints.weightx = 1.0D;
/*     */         gridBagConstraints.insets = new Insets(2, 2, 1, 5);
/*     */         this.paramPnl.add(arrayOfComponent[0], gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.insets = new Insets(2, 2, 1, 5);
/*     */         this.paramPnl.add(new JLabel(" = "), gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.fill = 2;
/*     */         gridBagConstraints.weightx = 1.0D;
/*     */         gridBagConstraints.gridwidth = 0;
/*     */         gridBagConstraints.anchor = 17;
/*     */         this.paramPnl.add(arrayOfComponent[1], gridBagConstraints);
/*     */       } 
/*     */       gridBagConstraints = new GridBagConstraints();
/*     */       gridBagConstraints.weighty = 100.0D;
/*     */       gridBagConstraints.gridwidth = 0;
/*     */       this.paramPnl.add(new JLabel(""), gridBagConstraints);
/*     */       validate();
/*     */       repaint();
/*     */     }
/*     */     
/*     */     public void setEnabled(boolean param1Boolean) {
/*     */       this.addB.setEnabled(param1Boolean);
/*     */       this.removeB.setEnabled(param1Boolean);
/*     */     }
/*     */     
/*     */     private void setEnabled() { this.removeB.setEnabled((this.currfield != null)); }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\ExtraProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */