package inetsoft.sree.adm;

import inetsoft.report.internal.Util;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.sree.SreeEnv;
import inetsoft.widget.VFlowLayout;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusListener;
import java.util.Vector;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

class PDFProperty extends ContentPane {
  JTextField truetypeTF;
  
  JTextField afmTF;
  
  JCheckBox preloadRB;
  
  JCheckBox compTextRB;
  
  JCheckBox compImgRB;
  
  JCheckBox asciiRB;
  
  JCheckBox symbolRB;
  
  MapPane mappane;
  
  JButton setB;
  
  JButton restoreB;
  
  public PDFProperty() {
    this.truetypeTF = new JTextField(30);
    this.afmTF = new JTextField(30);
    this.preloadRB = new JCheckBox(Catalog.getString("Preload Font Information"));
    this.compTextRB = new JCheckBox(Catalog.getString("Compress Text"));
    this.compImgRB = new JCheckBox(Catalog.getString("Compress Image"));
    this.asciiRB = new JCheckBox(Catalog.getString("Ascii Only"));
    this.symbolRB = new JCheckBox(Catalog.getString("Map Symbols"));
    this.mappane = new MapPane(this);
    this.setB = new JButton(Catalog.getString("Set"));
    this.restoreB = new JButton(Catalog.getString("Restore"));
    setLayout(new BorderLayout(5, 5));
    Property2Panel property2Panel = new Property2Panel();
    add(property2Panel, "Center");
    property2Panel.add(Catalog.getString("Font"), new Object[][] { { Catalog.getString("TrueType/CID Font Path") + ":", this.truetypeTF }, { Catalog.getString("AFM Font Path") + ":", this.afmTF } });
    property2Panel.add(Catalog.getString("Compression"), new Object[][] { { this.compTextRB, this.compImgRB, this.asciiRB, this.symbolRB } });
    property2Panel.add(Catalog.getString("PDF Font Mapping"), new Object[][] { { this.mappane } });
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(2, 10, 5));
    jPanel.add(this.setB);
    this.setB.addActionListener(new ActionListener(this) {
          private final PDFProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.set(); }
        });
    jPanel.add(this.restoreB);
    this.restoreB.addActionListener(new ActionListener(this) {
          private final PDFProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.restore(); }
        });
    add(jPanel, "South");
  }
  
  public void init() {
    restore();
    this.truetypeTF.getDocument().addDocumentListener(this);
    this.afmTF.getDocument().addDocumentListener(this);
    this.preloadRB.addItemListener(this);
    this.compTextRB.addItemListener(this);
    this.compImgRB.addItemListener(this);
    this.asciiRB.addItemListener(this);
    this.symbolRB.addItemListener(this);
    setEnabled();
  }
  
  void setEnabled() {
    this.setB.setEnabled(this.changed);
    this.restoreB.setEnabled(this.changed);
  }
  
  public void restore() {
    this.truetypeTF.setText(SreeEnv.getProperty("font.truetype.path", ""));
    this.afmTF.setText(SreeEnv.getProperty("font.afm.path", ""));
    this.preloadRB.setSelected(SreeEnv.getProperty("font.preload", "true").equalsIgnoreCase("true"));
    this.compTextRB.setSelected(SreeEnv.getProperty("pdf.compress.text", "true").equalsIgnoreCase("true"));
    this.compImgRB.setSelected(SreeEnv.getProperty("pdf.compress.image", "true").equalsIgnoreCase("true"));
    this.asciiRB.setSelected(SreeEnv.getProperty("pdf.output.ascii", "false").equalsIgnoreCase("true"));
    this.symbolRB.setSelected(SreeEnv.getProperty("pdf.map.symbols", "false").equalsIgnoreCase("false"));
    this.mappane.restore();
    this.changed = false;
    setEnabled();
  }
  
  public void set() {
    SreeEnv.setProperty("font.truetype.path", this.truetypeTF.getText());
    SreeEnv.setProperty("font.afm.path", this.afmTF.getText());
    SreeEnv.setProperty("font.preload", this.preloadRB.isSelected() + "");
    SreeEnv.setProperty("pdf.compress.text", this.compTextRB.isSelected() + "");
    SreeEnv.setProperty("pdf.compress.text", this.compImgRB.isSelected() + "");
    SreeEnv.setProperty("pdf.output.ascii", this.asciiRB.isSelected() + "");
    SreeEnv.setProperty("pdf.map.symbols", this.symbolRB.isSelected() + "");
    this.mappane.set();
    try {
      AdmGui.saveSreeEnv();
      this.changed = false;
      setEnabled();
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      AdmGui.showMessage(throwable.toString());
    } 
  }
  
  class MapPane extends JPanel {
    FocusListener focusListener;
    
    ActionListener removeListener;
    
    ActionListener moreListener;
    
    Vector params;
    
    JPanel paramPnl;
    
    Component currfield;
    
    JButton addB;
    
    JButton removeB;
    
    private final PDFProperty this$0;
    
    public MapPane(PDFProperty this$0) {
      this.this$0 = this$0;
      this.focusListener = new PDFProperty$3(this);
      this.removeListener = new PDFProperty$4(this);
      this.moreListener = new PDFProperty$5(this);
      this.params = new Vector();
      this.paramPnl = new JPanel();
      this.currfield = null;
      this.addB = new JButton(Catalog.getString("Add"));
      this.removeB = new JButton(Catalog.getString("Remove"));
      setLayout(new BorderLayout(5, 2));
      JPanel jPanel = new JPanel();
      jPanel.setLayout(new VFlowLayout());
      jPanel.add(Box.createVerticalStrut(10));
      jPanel.add(this.addB);
      this.addB.addActionListener(this.moreListener);
      jPanel.add(this.removeB);
      this.removeB.addActionListener(this.removeListener);
      add(jPanel, "East");
      JScrollPane jScrollPane = new JScrollPane(this.paramPnl);
      jScrollPane.setPreferredSize(new Dimension(400, 100));
      this.paramPnl.setLayout(new GridBagLayout());
      add(jScrollPane, "Center");
      setEnabled();
    }
    
    public void set() {
      StringBuffer stringBuffer = new StringBuffer();
      for (byte b = 0; b < this.params.size(); b++) {
        JTextField[] arrayOfJTextField = (JTextField[])this.params.elementAt(b);
        String str1 = arrayOfJTextField[0].getText();
        String str2 = arrayOfJTextField[1].getText();
        if (str1.length() > 0)
          stringBuffer.append(str1 + ":" + str2 + ";"); 
      } 
      SreeEnv.setProperty("pdf.font.mapping", (stringBuffer.length() > 0) ? stringBuffer.toString() : null);
    }
    
    public void restore() {
      this.params.removeAllElements();
      String str = SreeEnv.getProperty("pdf.font.mapping");
      String[] arrayOfString = Util.split(str, ';');
      for (byte b = 0; b < arrayOfString.length; b++) {
        String[] arrayOfString1 = Util.split(arrayOfString[b], ':');
        if (arrayOfString1.length == 2 && arrayOfString1[0].length() > 0 && arrayOfString1[1].length() > 0)
          addParameter(arrayOfString1[0], arrayOfString1[1]); 
      } 
      setup();
    }
    
    private void addParameter(String param1String, Object param1Object) {
      JTextField jTextField1 = new JTextField(15);
      jTextField1.addFocusListener(this.focusListener);
      jTextField1.getDocument().addDocumentListener(this.this$0);
      jTextField1.setText(param1String);
      JTextField jTextField2 = new JTextField(15);
      jTextField2.setText((param1Object == null) ? "" : param1Object.toString());
      jTextField2.getDocument().addDocumentListener(this.this$0);
      this.params.addElement(new JTextField[] { jTextField1, jTextField2 });
    }
    
    private void setup() {
      while (this.paramPnl.getComponentCount() > 0)
        this.paramPnl.remove(0); 
      GridBagConstraints gridBagConstraints = null;
      for (byte b = 0; b < this.params.size(); b++) {
        Component[] arrayOfComponent = (Component[])this.params.elementAt(b);
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = 2;
        gridBagConstraints.weightx = 1.0D;
        gridBagConstraints.insets = new Insets(2, 2, 1, 5);
        this.paramPnl.add(arrayOfComponent[0], gridBagConstraints);
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.insets = new Insets(2, 2, 1, 5);
        this.paramPnl.add(new JLabel(" = "), gridBagConstraints);
        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.fill = 2;
        gridBagConstraints.weightx = 1.0D;
        gridBagConstraints.gridwidth = 0;
        gridBagConstraints.anchor = 17;
        this.paramPnl.add(arrayOfComponent[1], gridBagConstraints);
      } 
      gridBagConstraints = new GridBagConstraints();
      gridBagConstraints.weighty = 100.0D;
      gridBagConstraints.gridwidth = 0;
      this.paramPnl.add(new JLabel(""), gridBagConstraints);
      validate();
      repaint();
    }
    
    public void setEnabled(boolean param1Boolean) {
      this.addB.setEnabled(param1Boolean);
      this.removeB.setEnabled(param1Boolean);
    }
    
    private void setEnabled() { this.removeB.setEnabled((this.currfield != null)); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\PDFProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */