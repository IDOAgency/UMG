/*     */ package inetsoft.sree.adm;
/*     */ 
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.sree.RepletRegistry;
/*     */ import inetsoft.sree.RepletRequest;
/*     */ import inetsoft.sree.SreeEnv;
/*     */ import inetsoft.sree.internal.SecurityData;
/*     */ import inetsoft.widget.STree;
/*     */ import inetsoft.widget.VFlowLayout;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.border.BevelBorder;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.border.TitledBorder;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.TreeModelListener;
/*     */ import javax.swing.event.TreeSelectionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdmGui
/*     */   extends JFrame
/*     */ {
/*     */   ActionListener addListener;
/*     */   ActionListener removeListener;
/*     */   ActionListener exitListener;
/*     */   STree tree;
/*     */   RepletPane repletPane;
/*     */   SchedulePane schedulePane;
/*     */   UserPane userPane;
/*     */   RepositoryProperty repositoryPane;
/*     */   PDFProperty pdfPane;
/*     */   HTMLProperty htmlPane;
/*     */   SecurityProperty securityPane;
/*     */   MailProperty mailPane;
/*     */   SchedulerProperty schedulerPane;
/*     */   MiscProperty miscPane;
/*     */   ExtraProperty extraPane;
/*     */   DefaultListModel usersM;
/*     */   DefaultListModel groupsM;
/*     */   JToggleButton.ToggleButtonModel secM;
/*     */   JTabbedPane folder;
/*     */   JLabel status;
/*     */   RepletRegistry registry;
/*     */   SecurityData security;
/*     */   
/*     */   void removeReplet(STree.Node paramNode) {
/*     */     if (paramNode == null)
/*     */       return; 
/*     */     if (paramNode.isLeaf())
/*     */       this.registry.remove(paramNode.getPath()); 
/*     */     for (byte b = 0; b < paramNode.getChildCount(); b++)
/*     */       removeReplet(paramNode.getChild(b)); 
/*     */   }
/*     */   
/*     */   void selectObjects(JList paramJList, DefaultListModel paramDefaultListModel, Object[] paramArrayOfObject) {
/*     */     if (paramArrayOfObject == null)
/*     */       return; 
/*     */     int[] arrayOfInt = new int[paramArrayOfObject.length];
/*     */     for (byte b = 0; b < arrayOfInt.length; b++)
/*     */       arrayOfInt[b] = paramDefaultListModel.indexOf(paramArrayOfObject[b]); 
/*     */     paramJList.setSelectedIndices(arrayOfInt);
/*     */   }
/*     */   
/*     */   static void saveSreeEnv() {
/*     */     File file = null;
/*     */     String str = SreeEnv.getProperty("sree.properties");
/*     */     if (str != null)
/*     */       file = new File(str); 
/*     */     if (file == null) {
/*     */       str = SreeEnv.getProperty("sree.home");
/*     */       if (str != null)
/*     */         file = new File(str + File.separator + "sree.properties"); 
/*     */     } 
/*     */     if (file == null) {
/*     */       String str1 = System.getProperty("java.class.path");
/*     */       String str2 = System.getProperty("path.separator");
/*     */       StringTokenizer stringTokenizer = new StringTokenizer(str1, str2);
/*     */       while (stringTokenizer.hasMoreTokens()) {
/*     */         String str3 = stringTokenizer.nextToken();
/*     */         File file1 = new File(str3, "sree.properties");
/*     */         if (file1.exists()) {
/*     */           file = file1;
/*     */           break;
/*     */         } 
/*     */         file1 = new File(str3, "inetsoft/sree/sree.properties");
/*     */         if (file1.exists()) {
/*     */           file = file1;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     if (file == null) {
/*     */       JFileChooser jFileChooser = new JFileChooser();
/*     */       int i = jFileChooser.showSaveDialog(null);
/*     */       if (i == 0)
/*     */         file = jFileChooser.getSelectedFile(); 
/*     */     } 
/*     */     if (file == null)
/*     */       throw new IOException("sree.properties file not found"); 
/*     */     SreeEnv.getProperties().save(new FileOutputStream(file), null);
/*     */   }
/*     */   
/*     */   class RepletPane
/*     */     extends ContentPane
/*     */   {
/*     */     TreeSelectionListener treeListener;
/*     */     TreeModelListener treeModelListener;
/*     */     ItemListener templateListener;
/*     */     JTextField nameTF;
/*     */     JTextField clsTF;
/*     */     JTextField aliasTF;
/*     */     JLabel clsLB;
/*     */     JCheckBox templateCB;
/*     */     JCheckBox visRB;
/*     */     JCheckBox defRB;
/*     */     JList usersLT;
/*     */     JList groupsLT;
/*     */     JTabbedPane reqfolder;
/*     */     RequestPane initReq;
/*     */     RequestPane defReq;
/*     */     Property pane;
/*     */     JButton setB;
/*     */     JButton restoreB;
/*     */     JButton addB;
/*     */     JButton removeB;
/*     */     JSplitPane spliter;
/*     */     String replet;
/*     */     private final AdmGui this$0;
/*     */     
/*     */     public RepletPane(AdmGui this$0) {
/*     */       this.this$0 = this$0;
/*     */       this.treeListener = new AdmGui$5(this);
/*     */       this.treeModelListener = new AdmGui$6(this);
/*     */       this.templateListener = new AdmGui$7(this);
/*     */       this.nameTF = new JTextField(20);
/*     */       this.clsTF = new JTextField(20);
/*     */       this.aliasTF = new JTextField(15);
/*     */       this.clsLB = new JLabel(Catalog.getString("Class") + ":", 4);
/*     */       this.templateCB = new JCheckBox(Catalog.getString("Template"));
/*     */       this.visRB = new JCheckBox(Catalog.getString("Visible"));
/*     */       this.defRB = new JCheckBox(Catalog.getString("Use Default Permissions"));
/*     */       this.usersLT = new JList(this.this$0.usersM);
/*     */       this.groupsLT = new JList(this.this$0.groupsM);
/*     */       this.reqfolder = new JTabbedPane();
/*     */       this.initReq = new RequestPane(null, this);
/*     */       this.defReq = new RequestPane(null, this);
/*     */       setLayout(new BorderLayout());
/*     */       this$0.tree.addTreeSelectionListener(this.treeListener);
/*     */       this$0.tree.getModel().addTreeModelListener(this.treeModelListener);
/*     */       JScrollPane jScrollPane1 = new JScrollPane(this$0.tree);
/*     */       jScrollPane1.setMinimumSize(new Dimension(0, 0));
/*     */       jScrollPane1.setPreferredSize(new Dimension(150, 0));
/*     */       JScrollPane jScrollPane2 = new JScrollPane(this.pane = new Property(this));
/*     */       jScrollPane2.setMinimumSize(new Dimension(0, 0));
/*     */       jScrollPane2.setPreferredSize(new Dimension(400, 0));
/*     */       this$0.tree.setEditable(true);
/*     */       this$0.tree.setMultiSelect(false);
/*     */       this.spliter = new JSplitPane(1, jScrollPane1, jScrollPane2);
/*     */       JPanel jPanel1 = new JPanel();
/*     */       jPanel1.setLayout(new BorderLayout());
/*     */       JPanel jPanel2 = new JPanel();
/*     */       jPanel1.add(jPanel2, "West");
/*     */       jPanel2.setLayout(new FlowLayout(0, 10, 5));
/*     */       jPanel2.add(this.addB = new JButton(Catalog.getString("Add")));
/*     */       this.addB.addActionListener(this$0.addListener);
/*     */       jPanel2.add(this.removeB = new JButton(Catalog.getString("Remove")));
/*     */       this.removeB.addActionListener(this$0.removeListener);
/*     */       jPanel2 = new JPanel();
/*     */       jPanel1.add(jPanel2, "East");
/*     */       jPanel2.setLayout(new FlowLayout(2, 10, 5));
/*     */       jPanel2.add(this.setB = new JButton(Catalog.getString("Set")));
/*     */       this.setB.addActionListener(new AdmGui$3(this));
/*     */       jPanel2.add(this.restoreB = new JButton(Catalog.getString("Restore")));
/*     */       this.restoreB.addActionListener(new AdmGui$4(this));
/*     */       add(this.spliter, "Center");
/*     */       add(jPanel1, "South");
/*     */       this.setB.setEnabled(false);
/*     */       this.restoreB.setEnabled(false);
/*     */       this.changed = false;
/*     */       setEnabled();
/*     */     }
/*     */     
/*     */     public void setReplet(String param1String) {
/*     */       if (param1String == null)
/*     */         return; 
/*     */       if (this.changed && this.replet != null && this.replet.equals(param1String))
/*     */         return; 
/*     */       if (this.changed && this.replet != null && !this.replet.equals(param1String) && JOptionPane.showConfirmDialog(this.this$0, AdmGui.changedMsg, Catalog.getString("Confirmation"), 0) != 0) {
/*     */         this.this$0.tree.setSelected(this.replet, true);
/*     */         return;
/*     */       } 
/*     */       this.replet = param1String;
/*     */       this.nameTF.setText(param1String);
/*     */       this.this$0.selectObjects(this.usersLT, this.this$0.usersM, this.this$0.security.getRepletUsers(param1String));
/*     */       this.this$0.selectObjects(this.groupsLT, this.this$0.groupsM, this.this$0.security.getRepletGroups(param1String));
/*     */       String str2 = this.this$0.registry.getTemplate(param1String);
/*     */       this.templateCB.setSelected((str2 != null));
/*     */       this.clsTF.setText((str2 == null) ? this.this$0.registry.getRepletClass(param1String) : str2);
/*     */       String str1 = this.this$0.registry.getRepletAlias(param1String);
/*     */       this.aliasTF.setText((str1 == null) ? "" : str1);
/*     */       this.defReq.setRepletRequest(this.this$0.registry.getDefaultRequest(param1String));
/*     */       this.initReq.setRepletRequest(this.this$0.registry.getInitRequest(param1String));
/*     */       this.visRB.setSelected(this.this$0.registry.isVisible(param1String));
/*     */       this.defRB.setSelected(this.this$0.security.isUseDefault(param1String));
/*     */       this.changed = false;
/*     */       setEnabled();
/*     */     }
/*     */     
/*     */     public void restore() {
/*     */       this.changed = false;
/*     */       setReplet(this.replet);
/*     */     }
/*     */     
/*     */     public void set() {
/*     */       if (this.replet == null) {
/*     */         this.changed = false;
/*     */         setEnabled();
/*     */         return;
/*     */       } 
/*     */       if (!this.replet.equals(this.nameTF.getText())) {
/*     */         String str = this.nameTF.getText();
/*     */         this.this$0.tree.removeTreeSelectionListener(this.treeListener);
/*     */         this.this$0.tree.remove(this.replet);
/*     */         this.this$0.registry.remove(this.replet);
/*     */         this.this$0.tree.add(str);
/*     */         this.this$0.tree.addTreeSelectionListener(this.treeListener);
/*     */         this.replet = str;
/*     */       } 
/*     */       String str1 = this.aliasTF.getText();
/*     */       String str2 = this.templateCB.isSelected() ? "inetsoft.sree.TemplateReplet" : this.clsTF.getText();
/*     */       RepletRequest repletRequest1 = this.defReq.getRepletRequest("create");
/*     */       RepletRequest repletRequest2 = this.initReq.getRepletRequest("init");
/*     */       this.this$0.registry.register(this.replet, str2, (str1.length() == 0) ? null : str1, (repletRequest2.getParameterCount() == 0) ? null : repletRequest2, (repletRequest1.getParameterCount() == 0) ? null : repletRequest1);
/*     */       this.this$0.registry.setVisible(this.replet, this.visRB.isSelected());
/*     */       this.this$0.registry.setTemplate(this.replet, this.templateCB.isSelected() ? this.clsTF.getText() : null);
/*     */       this.this$0.security.setUseDefault(this.replet, this.defRB.isSelected());
/*     */       this.this$0.security.setRepletUsers(this.replet, this.usersLT.getSelectedValues());
/*     */       this.this$0.security.setRepletGroups(this.replet, this.groupsLT.getSelectedValues());
/*     */       try {
/*     */         this.this$0.registry.save();
/*     */         this.this$0.security.save();
/*     */         this.changed = false;
/*     */         setEnabled();
/*     */       } catch (Throwable throwable) {
/*     */         throwable.printStackTrace();
/*     */         AdmGui.showMessage(throwable.toString());
/*     */       } 
/*     */     }
/*     */     
/*     */     void setEnabled() {
/*     */       STree.Node node = this.this$0.tree.getSelectedNode();
/*     */       this.removeB.setEnabled((node != null));
/*     */       this.addB.setEnabled((node == null || !node.isLeaf()));
/*     */       this.setB.setEnabled((node != null && this.changed));
/*     */       this.restoreB.setEnabled((node != null && this.changed));
/*     */       this.defRB.setEnabled((node != null && this.this$0.secM.isSelected()));
/*     */       this.usersLT.setEnabled((node != null && this.this$0.secM.isSelected() && !this.defRB.isSelected()));
/*     */       this.groupsLT.setEnabled((node != null && this.this$0.secM.isSelected() && !this.defRB.isSelected()));
/*     */       this.initReq.setEnabled((node != null));
/*     */       this.defReq.setEnabled((node != null));
/*     */     }
/*     */     
/*     */     class Property
/*     */       extends Property2Panel
/*     */     {
/*     */       private final AdmGui.RepletPane this$1;
/*     */       
/*     */       public Property(AdmGui.RepletPane this$0) {
/*     */         this.this$1 = this$0;
/*     */         this$0.reqfolder.add(Catalog.getString("Initialization Parameters"), this$0.initReq);
/*     */         this$0.reqfolder.add(Catalog.getString("Default Parameters"), this$0.defReq);
/*     */         add(Catalog.getString("Replet"), new Object[][] { { Catalog.getString("Name") + ":", this$0.nameTF, Catalog.getString("Alias") + ":", this$0.aliasTF }, { this$0.clsLB, this$0.clsTF, { this$0.templateCB, this$0.visRB } } });
/*     */         JScrollPane jScrollPane1 = new JScrollPane(this$0.usersLT);
/*     */         jScrollPane1.setPreferredSize(new Dimension(140, 60));
/*     */         JScrollPane jScrollPane2 = new JScrollPane(this$0.groupsLT);
/*     */         jScrollPane2.setPreferredSize(new Dimension(140, 60));
/*     */         add(Catalog.getString("Replet Permissions"), new Object[][] { { this$0.defRB }, { Catalog.getString("Users") + ":", jScrollPane1, Catalog.getString("Groups") + ":", jScrollPane2 } });
/*     */         GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.fill = 1;
/*     */         gridBagConstraints.gridwidth = 0;
/*     */         gridBagConstraints.weightx = gridBagConstraints.weighty = 3.0D;
/*     */         add(this$0.reqfolder, gridBagConstraints);
/*     */         this$0.nameTF.getDocument().addDocumentListener(this$0);
/*     */         this$0.clsTF.getDocument().addDocumentListener(this$0);
/*     */         this$0.aliasTF.getDocument().addDocumentListener(this$0);
/*     */         this$0.defRB.addItemListener(this$0);
/*     */         this$0.visRB.addItemListener(this$0);
/*     */         this$0.templateCB.addItemListener(this$0);
/*     */         this$0.templateCB.addItemListener(this$0.templateListener);
/*     */         this$0.usersLT.addListSelectionListener(this$0);
/*     */         this$0.groupsLT.addListSelectionListener(this$0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public AdmGui() {
/* 882 */     this.addListener = new ActionListener(this) { private final AdmGui this$0;
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 884 */           String str = this.this$0.tree.getSelectedPath();
/*     */           
/* 886 */           if (str == null) {
/* 887 */             str = "";
/*     */           } else {
/*     */             
/* 890 */             str = str + "/";
/*     */           } 
/*     */           
/* 893 */           STree.Node node = this.this$0.tree.add(str);
/* 894 */           this.this$0.tree.startEditingAtPath(node.getTreePath());
/*     */         } }
/*     */       ;
/*     */     
/* 898 */     this.removeListener = new ActionListener(this) { private final AdmGui this$0;
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 900 */           if (JOptionPane.showConfirmDialog(this.this$0, AdmGui.removeMsg, Catalog.getString("Remove Replet"), 0) == 0) {
/*     */ 
/*     */ 
/*     */             
/* 904 */             String str = this.this$0.tree.getSelectedPath();
/* 905 */             this.this$0.removeReplet(this.this$0.tree.findNode(str, false));
/* 906 */             this.this$0.tree.remove(str);
/*     */             
/*     */             try {
/* 909 */               this.this$0.registry.save();
/* 910 */               this.this$0.security.save();
/*     */             } catch (Throwable throwable) {
/* 912 */               throwable.printStackTrace();
/* 913 */               AdmGui.showMessage(throwable.toString());
/*     */             } 
/*     */           } 
/*     */         } }
/*     */       ;
/*     */     
/* 919 */     this.exitListener = new ActionListener(this) { private final AdmGui this$0;
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 921 */           if (this.this$0.repletPane.isChanged() || this.this$0.schedulePane.isChanged() || this.this$0.repositoryPane.isChanged() || this.this$0.pdfPane.isChanged() || this.this$0.htmlPane.isChanged() || this.this$0.securityPane.isChanged() || this.this$0.mailPane.isChanged() || this.this$0.schedulerPane.isChanged() || this.this$0.miscPane.isChanged() || this.this$0.extraPane.isChanged())
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 926 */             if (JOptionPane.showConfirmDialog(this.this$0, AdmGui.changedMsg, Catalog.getString("Confirmation"), 0) != 0) {
/*     */               return;
/*     */             }
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 935 */           System.exit(0);
/*     */         } }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 968 */     this.tree = new STree();
/* 969 */     this.repletPane = null;
/* 970 */     this.schedulePane = null;
/* 971 */     this.userPane = null;
/*     */     
/* 973 */     this.repositoryPane = null;
/* 974 */     this.pdfPane = null;
/* 975 */     this.htmlPane = null;
/* 976 */     this.securityPane = null;
/* 977 */     this.mailPane = null;
/* 978 */     this.schedulerPane = null;
/* 979 */     this.miscPane = null;
/* 980 */     this.extraPane = null;
/*     */     
/* 982 */     this.usersM = new DefaultListModel();
/* 983 */     this.groupsM = new DefaultListModel();
/* 984 */     this.secM = new JToggleButton.ToggleButtonModel();
/*     */     
/* 986 */     this.folder = new JTabbedPane();
/* 987 */     this.status = new JLabel(" ");
/*     */     
/* 989 */     this.registry = null;
/* 990 */     this.security = null; setTitle(Catalog.getString("Style Report/EE Admin")); setDefaultCloseOperation(0); try { this.registry = RepletRegistry.getRegistry(); Enumeration enumeration1 = this.registry.getRepletNames(false); this.tree.setSorting(1); this.tree.setSeparator('/'); while (enumeration1.hasMoreElements()) this.tree.add((String)enumeration1.nextElement());  this.tree.setSorting(0); this.security = new SecurityData(); Enumeration enumeration2 = this.security.getAllUsers(); while (enumeration2.hasMoreElements()) this.usersM.addElement(enumeration2.nextElement());  enumeration2 = this.security.getAllGroups(); while (enumeration2.hasMoreElements())
/*     */         this.groupsM.addElement(enumeration2.nextElement());  String str = SreeEnv.getProperty("security.access.controller"); this.secM.setSelected((str != null && str.equals("inetsoft.sree.security.DefaultController"))); } catch (Throwable throwable) { throwable.printStackTrace(); showMessage(throwable.toString()); }  JMenuBar jMenuBar = new JMenuBar(); setJMenuBar(jMenuBar); JMenu jMenu = new JMenu(Catalog.getString("File")); jMenuBar.add(jMenu); jMenu.setMnemonic('F'); JMenuItem jMenuItem; jMenu.add(jMenuItem = new JMenuItem(Catalog.getString("Exit"))); jMenuItem.setMnemonic('x'); jMenuItem.setAccelerator(KeyStroke.getKeyStroke(88, 2)); jMenuItem.addActionListener(this.exitListener); this.folder.setPreferredSize(new Dimension(700, 500)); getContentPane().add(this.folder, "Center"); this.folder.add(Catalog.getString("Replets"), this.repletPane = new RepletPane(this)); this.folder.add(Catalog.getString("Scheduled Tasks"), this.schedulePane = new SchedulePane(this.tree.getModel())); this.folder.add(Catalog.getString("Users"), this.userPane = new UserPane(this)); this.folder.add(Catalog.getString("Repository"), this.repositoryPane = new RepositoryProperty()); this.folder.add(Catalog.getString("PDF"), this.pdfPane = new PDFProperty()); this.folder.add(Catalog.getString("HTML"), this.htmlPane = new HTMLProperty()); this.folder.add(Catalog.getString("Security"), this.securityPane = new SecurityProperty(this.secM)); this.folder.add(Catalog.getString("Mail"), this.mailPane = new MailProperty()); this.folder.add(Catalog.getString("Scheduler"), this.schedulerPane = new SchedulerProperty()); this.folder.add(Catalog.getString("Misc"), this.miscPane = new MiscProperty()); this.folder.add(Catalog.getString("Extra"), this.extraPane = new ExtraProperty()); this.repositoryPane.init(); this.pdfPane.init(); this.htmlPane.init(); this.securityPane.init(); this.mailPane.init(); this.schedulerPane.init(); this.miscPane.init(); this.extraPane.init(); this.status.setBorder(new CompoundBorder(new EmptyBorder(2, 0, 0, 0), new BevelBorder(1))); getContentPane().add(this.status, "South"); addWindowListener(new WindowAdapter(this) { private final AdmGui this$0; public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.exitListener.actionPerformed(null); } }); this.secM.addChangeListener(new ChangeListener(this) { private final AdmGui this$0; public void stateChanged(ChangeEvent param1ChangeEvent) { this.this$0.repletPane.setEnabled(); this.this$0.userPane.setEnabled(); } });
/* 992 */   } static final String removeMsg = Catalog.getString("Remove ALL replets in the selected branch?");
/*     */   class UserPane extends ContentPane {
/* 994 */     JList usersLT; JList groupsLT; JButton addUserB; JButton removeUserB; JButton passwdB; JButton addGroupB; JButton removeGroupB; JButton editGroupB; JList defUsersLT; JList defGroupsLT; JButton setB; JButton restoreB; private final AdmGui this$0; public UserPane(AdmGui this$0) { this.this$0 = this$0; this.usersLT = new JList(this.this$0.usersM); this.groupsLT = new JList(this.this$0.groupsM); this.addUserB = new JButton(Catalog.getString("Add")); this.removeUserB = new JButton(Catalog.getString("Remove")); this.passwdB = new JButton(Catalog.getString("Change Password")); this.addGroupB = new JButton(Catalog.getString("Add")); this.removeGroupB = new JButton(Catalog.getString("Remove")); this.editGroupB = new JButton(Catalog.getString("Edit")); this.defUsersLT = new JList(this.this$0.usersM); this.defGroupsLT = new JList(this.this$0.groupsM); this.setB = new JButton(Catalog.getString("Set")); this.restoreB = new JButton(Catalog.getString("Restore")); setLayout(new BorderLayout(5, 5)); JPanel jPanel1 = new JPanel(); jPanel1.setLayout(new BorderLayout(5, 5)); add(jPanel1, "North"); AdmGui$8 admGui$8 = new AdmGui$8(this); this.usersLT.addListSelectionListener(admGui$8); this.groupsLT.addListSelectionListener(admGui$8); JPanel jPanel2 = new JPanel(); jPanel1.add(jPanel2, "North"); jPanel2.setBorder(new TitledBorder(Catalog.getString("Users"))); jPanel2.setLayout(new BorderLayout(20, 10)); JScrollPane jScrollPane1 = new JScrollPane(this.usersLT); jScrollPane1.setPreferredSize(new Dimension(150, 100)); jPanel2.add(jScrollPane1, "West"); Box box = Box.createVerticalBox(); box.add(Box.createVerticalStrut(10)); box.add(this.addUserB); box.add(Box.createVerticalStrut(10)); box.add(this.removeUserB); box.add(Box.createVerticalStrut(10)); box.add(this.passwdB); jPanel2.add(box, "Center"); JPanel jPanel3 = new JPanel(); jPanel1.add(jPanel3, "South"); jPanel3.setBorder(new TitledBorder(Catalog.getString("Groups"))); jPanel3.setLayout(new BorderLayout(20, 10)); JScrollPane jScrollPane2 = new JScrollPane(this.groupsLT); jScrollPane2.setPreferredSize(new Dimension(150, 100)); jPanel3.add(jScrollPane2, "West"); box = Box.createVerticalBox(); box.add(Box.createVerticalStrut(10)); box.add(this.addGroupB); box.add(Box.createVerticalStrut(10)); box.add(this.removeGroupB); box.add(Box.createVerticalStrut(10)); box.add(this.editGroupB); jPanel3.add(box, "Center"); Property2Panel property2Panel = new Property2Panel(); JScrollPane jScrollPane3 = new JScrollPane(this.defUsersLT); jScrollPane3.setPreferredSize(new Dimension(140, 60)); JScrollPane jScrollPane4 = new JScrollPane(this.defGroupsLT); jScrollPane4.setPreferredSize(new Dimension(140, 60)); property2Panel.add(Catalog.getString("Default Permissions"), new Object[][] { { Catalog.getString("Users") + ":", jScrollPane3, Catalog.getString("Groups") + ":", jScrollPane4 } }); add(property2Panel, "Center"); JPanel jPanel4 = new JPanel(); jPanel4.setLayout(new FlowLayout(2, 10, 5)); jPanel4.add(this.setB); this.setB.addActionListener(new AdmGui$9(this)); jPanel4.add(this.restoreB); this.restoreB.addActionListener(new AdmGui$10(this)); add(jPanel4, "South"); this.addUserB.addActionListener(new AdmGui$11(this)); this.removeUserB.addActionListener(new AdmGui$12(this)); this.passwdB.addActionListener(new AdmGui$13(this)); this.addGroupB.addActionListener(new AdmGui$14(this)); this.removeGroupB.addActionListener(new AdmGui$15(this)); this.editGroupB.addActionListener(new AdmGui$16(this)); restore(); } void setEnabled() { boolean bool = this.this$0.secM.isSelected(); this.removeUserB.setEnabled((bool && this.usersLT.getSelectedIndex() >= 0)); this.passwdB.setEnabled((bool && this.usersLT.getSelectedIndex() >= 0)); this.removeGroupB.setEnabled((bool && this.groupsLT.getSelectedIndex() >= 0)); this.editGroupB.setEnabled((bool && this.groupsLT.getSelectedIndex() >= 0)); this.usersLT.setEnabled(bool); this.groupsLT.setEnabled(bool); this.addUserB.setEnabled(bool); this.addGroupB.setEnabled(bool); this.defUsersLT.setEnabled(bool); this.defGroupsLT.setEnabled(bool); this.setB.setEnabled(this.changed); this.restoreB.setEnabled(this.changed); } public void set() { this.this$0.security.setDefaultUsers(this.defUsersLT.getSelectedValues()); this.this$0.security.setDefaultGroups(this.defGroupsLT.getSelectedValues()); try { this.this$0.security.save(); this.changed = false; setEnabled(); } catch (Throwable throwable) { throwable.printStackTrace(); AdmGui.showMessage(throwable.toString()); }  } public void restore() { this.this$0.selectObjects(this.defUsersLT, this.this$0.usersM, this.this$0.security.getDefaultUsers()); this.this$0.selectObjects(this.defGroupsLT, this.this$0.groupsM, this.this$0.security.getDefaultGroups()); this.defUsersLT.addListSelectionListener(this); this.defGroupsLT.addListSelectionListener(this); this.changed = false; setEnabled(); } } static final String removeUserMsg = Catalog.getString("Remove the user and all references to the user?");
/*     */   class GroupEditor extends JDialog {
/* 996 */     String group; DefaultListModel inM; DefaultListModel outM; JList inLT; JList outLT; JButton addB; JButton removeB; JButton okB; JButton cancelB; private final AdmGui this$0; public GroupEditor(AdmGui this$0, String param1String) { super(this$0); this.this$0 = this$0; this.inM = new DefaultListModel(); this.outM = new DefaultListModel(); this.inLT = new JList(this.inM); this.outLT = new JList(this.outM); this.addB = new JButton(Catalog.getString("<< Add")); this.removeB = new JButton(Catalog.getString("Remove >>")); this.okB = new JButton(Catalog.getString("OK")); this.cancelB = new JButton(Catalog.getString("Cancel")); setModal(true); this.group = param1String; getContentPane().setLayout(new BorderLayout(5, 5)); Object[] arrayOfObject = this$0.security.getGroupUsers(this.group); Enumeration enumeration = this$0.security.getAllUsers(); for (byte b = 0; b < arrayOfObject.length; b++) this.inM.addElement(arrayOfObject[b]);  while (enumeration.hasMoreElements()) { String str = (String)enumeration.nextElement(); if (!this.inM.contains(str)) this.outM.addElement(str);  }  JPanel jPanel1 = new JPanel(); jPanel1.setLayout(new VFlowLayout(16)); jPanel1.add(this.addB); jPanel1.add(this.removeB); JPanel jPanel2 = new JPanel(); jPanel2.setLayout(new BorderLayout(5, 5)); JScrollPane jScrollPane1 = new JScrollPane(this.inLT); jScrollPane1.setPreferredSize(new Dimension(80, 90)); JScrollPane jScrollPane2 = new JScrollPane(this.outLT); jScrollPane2.setPreferredSize(new Dimension(80, 90)); jPanel2.add(jScrollPane1, "West"); jPanel2.add(jPanel1, "Center"); jPanel2.add(jScrollPane2, "East"); getContentPane().add(jPanel2, "Center"); jPanel2 = new JPanel(); jPanel2.add(this.okB); jPanel2.add(this.cancelB); getContentPane().add(jPanel2, "South"); this.addB.addActionListener(new AdmGui$17(this)); this.removeB.addActionListener(new AdmGui$18(this)); this.okB.addActionListener(new AdmGui$19(this)); this.cancelB.addActionListener(new AdmGui$20(this)); } void setEnabled() { this.addB.setEnabled((this.outLT.getSelectedIndex() >= 0)); this.removeB.setEnabled((this.inLT.getSelectedIndex() >= 0)); } } public static void main(String[] paramArrayOfString) { if (paramArrayOfString.length > 0) { System.getProperties().put("sree.properties", paramArrayOfString[0]); if (SreeEnv.getProperty("sree.home") == null) { File file = new File(paramArrayOfString[0]); String str = file.getParent(); if (str != null) SreeEnv.setProperty("sree.home", str);  }  }  if (SreeEnv.getProperty("sree.home") == null) SreeEnv.setProperty("sree.home", ".");  AdmGui admGui = new AdmGui(); admGui.pack(); admGui.setVisible(true); } static void showMessage(String paramString) { JOptionPane.showMessageDialog(null, paramString, Catalog.getString("Error"), 0); } static final String removeGroupMsg = Catalog.getString("Remove the group and all references to the group?");
/*     */   
/* 998 */   static final String changedMsg = Catalog.getString("Values changed on this panel. Discard changes?");
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\AdmGui.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */