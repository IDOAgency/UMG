/*     */ package inetsoft.sree.adm;
/*     */ 
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.sree.SreeEnv;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MiscProperty
/*     */   extends ContentPane
/*     */ {
/*     */   JTextField keyTF;
/*     */   JTextField dateTF;
/*     */   JTextField timeTF;
/*     */   JTextField datetimeTF;
/*     */   JTextField logTF;
/*     */   JTextField delegateTF;
/*     */   JButton logBrowseB;
/*     */   JCheckBox stderrRB;
/*     */   JButton setB;
/*     */   JButton restoreB;
/*     */   JComboBox sortCB;
/*     */   JTextField sprinterTF;
/*     */   
/*     */   public MiscProperty() {
/* 140 */     this.keyTF = new JTextField(20);
/* 141 */     this.dateTF = new JTextField(10);
/* 142 */     this.timeTF = new JTextField(10);
/* 143 */     this.datetimeTF = new JTextField(10);
/* 144 */     this.logTF = new JTextField(30);
/* 145 */     this.delegateTF = new JTextField(30);
/* 146 */     this.logBrowseB = new JButton(Catalog.getString("Browse"));
/* 147 */     this.stderrRB = new JCheckBox(Catalog.getString("Output to stderr"));
/*     */     
/* 149 */     this.setB = new JButton(Catalog.getString("Set"));
/* 150 */     this.restoreB = new JButton(Catalog.getString("Restore"));
/* 151 */     this.sortCB = new JComboBox(sorting);
/* 152 */     this.sprinterTF = new JTextField(30); setLayout(new BorderLayout(5, 5)); Property2Panel property2Panel = new Property2Panel(); add(property2Panel, "Center"); property2Panel.add(Catalog.getString("License Key"), new Object[][] { { Catalog.getString("Server License Key") + ":", this.keyTF } }); property2Panel.add(Catalog.getString("Formats"), new Object[][] { { Catalog.getString("Date") + ":", this.dateTF, Catalog.getString("Time") + ":", this.timeTF, Catalog.getString("Date/Time") + ":", this.datetimeTF } }); property2Panel.add(Catalog.getString("Log"), new Object[][] { { Catalog.getString("Log File") + ":", { this.logTF, this.logBrowseB } }, { Catalog.getString("Log Delegate") + ":", this.delegateTF }, { this.stderrRB } }); property2Panel.add(Catalog.getString("Repository Tree"), new Object[][] { { Catalog.getString("Sorting") + ":", this.sortCB } }); property2Panel.add(Catalog.getString("Server Printers"), new Object[][] { { Catalog.getString("Printers (Comma separated)") + ":", this.sprinterTF } }); JPanel jPanel = new JPanel(); jPanel.setLayout(new FlowLayout(2, 10, 5)); jPanel.add(this.setB); this.setB.addActionListener(new ActionListener(this) { private final MiscProperty this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.set(); } }); jPanel.add(this.restoreB); this.restoreB.addActionListener(new ActionListener(this) { private final MiscProperty this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.restore(); } });
/*     */     add(jPanel, "South");
/* 154 */     this.logBrowseB.addActionListener(new BrowseListener(this.logTF)); } static final String[] sorting = { "none", "Ascent", "Descent" };
/*     */   
/*     */   public void init() {
/*     */     restore();
/*     */     this.keyTF.getDocument().addDocumentListener(this);
/*     */     this.dateTF.getDocument().addDocumentListener(this);
/*     */     this.timeTF.getDocument().addDocumentListener(this);
/*     */     this.datetimeTF.getDocument().addDocumentListener(this);
/*     */     this.logTF.getDocument().addDocumentListener(this);
/*     */     this.delegateTF.getDocument().addDocumentListener(this);
/*     */     this.stderrRB.addItemListener(this);
/*     */     this.sortCB.addItemListener(this);
/*     */     this.sprinterTF.getDocument().addDocumentListener(this);
/*     */     this.changed = false;
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   void setEnabled() {
/*     */     this.setB.setEnabled(this.changed);
/*     */     this.restoreB.setEnabled(this.changed);
/*     */   }
/*     */   
/*     */   public void restore() {
/*     */     this.keyTF.setText(SreeEnv.getProperty("license.key", ""));
/*     */     this.dateTF.setText(SreeEnv.getProperty("format.date", ""));
/*     */     this.timeTF.setText(SreeEnv.getProperty("format.time", ""));
/*     */     this.datetimeTF.setText(SreeEnv.getProperty("format.datetime", ""));
/*     */     this.logTF.setText(SreeEnv.getProperty("log.output.file", ""));
/*     */     this.delegateTF.setText(SreeEnv.getProperty("log.delegate.class", ""));
/*     */     this.stderrRB.setSelected(SreeEnv.getProperty("log.output.stderr", "false").equalsIgnoreCase("true"));
/*     */     String str = SreeEnv.getProperty("repository.tree.sort", "");
/*     */     this.sortCB.setSelectedItem(str.toUpperCase());
/*     */     this.sprinterTF.setText(SreeEnv.getProperty("replet.repository.printers", ""));
/*     */     this.changed = false;
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public void set() {
/*     */     SreeEnv.setProperty("license.key", this.keyTF.getText());
/*     */     SreeEnv.setProperty("format.date", this.dateTF.getText());
/*     */     SreeEnv.setProperty("format.time", this.timeTF.getText());
/*     */     SreeEnv.setProperty("format.datetime", this.datetimeTF.getText());
/*     */     SreeEnv.setProperty("log.output.file", this.logTF.getText());
/*     */     String str = this.delegateTF.getText();
/*     */     SreeEnv.setProperty("log.delegate.class", (str.length() > 0) ? str : null);
/*     */     SreeEnv.setProperty("log.output.stderr", this.stderrRB.isSelected() + "");
/*     */     SreeEnv.setProperty("repository.tree.sort", (String)this.sortCB.getSelectedItem());
/*     */     SreeEnv.setProperty("replet.repository.printers", this.sprinterTF.getText());
/*     */     try {
/*     */       AdmGui.saveSreeEnv();
/*     */       this.changed = false;
/*     */       setEnabled();
/*     */     } catch (Throwable throwable) {
/*     */       throwable.printStackTrace();
/*     */       AdmGui.showMessage(throwable.toString());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\MiscProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */