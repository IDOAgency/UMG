package inetsoft.sree.adm;

import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.sree.SreeEnv;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

class RepositoryProperty extends ContentPane {
  JTextField xmlTF;
  
  JButton xmlBrowseB;
  
  JTextField cacheTF;
  
  JButton cacheBrowseB;
  
  JTextField datasourceTF;
  
  JButton datasourceBrowseB;
  
  JTextField queryTF;
  
  JButton queryBrowseB;
  
  JTextField servletTF;
  
  JComboBox protocolCB;
  
  JTextField urlTF;
  
  NumField entriesTF;
  
  NumField worksetTF;
  
  NumField concurrentTF;
  
  NumField intervalTF;
  
  JCheckBox varUniqCB;
  
  JButton setB;
  
  JButton restoreB;
  
  public RepositoryProperty() {
    this.xmlTF = new JTextField(25);
    this.xmlBrowseB = new JButton(Catalog.getString("Browse"));
    this.cacheTF = new JTextField(25);
    this.cacheBrowseB = new JButton(Catalog.getString("Browse"));
    this.datasourceTF = new JTextField(25);
    this.datasourceBrowseB = new JButton(Catalog.getString("Browse"));
    this.queryTF = new JTextField(25);
    this.queryBrowseB = new JButton(Catalog.getString("Browse"));
    this.servletTF = new JTextField(20);
    this.protocolCB = new JComboBox(protocols);
    this.urlTF = new JTextField(20);
    this.entriesTF = new NumField(5, true);
    this.worksetTF = new NumField(3, true);
    this.concurrentTF = new NumField(3, true);
    this.intervalTF = new NumField(5, true);
    this.varUniqCB = new JCheckBox(Catalog.getString("Query variable names are unique"));
    this.setB = new JButton(Catalog.getString("Set"));
    this.restoreB = new JButton(Catalog.getString("Restore"));
    setLayout(new BorderLayout(5, 5));
    Property2Panel property2Panel = new Property2Panel();
    add(property2Panel, "Center");
    property2Panel.add(Catalog.getString("Files"), new Object[][] { { Catalog.getString("Repository XML File") + ":", { this.xmlTF, this.xmlBrowseB } }, { Catalog.getString("Cache Directory") + ":", { this.cacheTF, this.cacheBrowseB } } });
    property2Panel.add(Catalog.getString("Servers"), new Object[][] { { Catalog.getString("Repository Servlet") + ":", this.servletTF }, { Catalog.getString("Server URL") + ":", this.urlTF, Catalog.getString("Protocol") + ":", this.protocolCB } });
    property2Panel.add(Catalog.getString("Data Source"), new Object[][] { { Catalog.getString("DataSource Registry") + ":", { this.datasourceTF, this.datasourceBrowseB } }, { Catalog.getString("Query Registry") + ":", { this.queryTF, this.queryBrowseB } }, { this.varUniqCB } });
    property2Panel.add(Catalog.getString("Cache"), new Object[][] { { Catalog.getString("Cache Entries") + ":", this.entriesTF, Catalog.getString("Cache Interval") + ":", this.intervalTF }, { Catalog.getString("Workset Size") + ":", this.worksetTF, Catalog.getString("Maximum Concurrency") + ":", this.concurrentTF } });
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(2, 10, 5));
    jPanel.add(this.setB);
    this.setB.addActionListener(new ActionListener(this) {
          private final RepositoryProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.set(); }
        });
    jPanel.add(this.restoreB);
    this.restoreB.addActionListener(new ActionListener(this) {
          private final RepositoryProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.restore(); }
        });
    add(jPanel, "South");
    this.xmlBrowseB.addActionListener(new BrowseListener(this.xmlTF));
    this.cacheBrowseB.addActionListener(new BrowseListener(this.cacheTF));
    this.datasourceBrowseB.addActionListener(new BrowseListener(this.datasourceTF));
    this.queryBrowseB.addActionListener(new BrowseListener(this.queryTF));
  }
  
  public void init() {
    restore();
    this.xmlTF.getDocument().addDocumentListener(this);
    this.cacheTF.getDocument().addDocumentListener(this);
    this.datasourceTF.getDocument().addDocumentListener(this);
    this.queryTF.getDocument().addDocumentListener(this);
    this.servletTF.getDocument().addDocumentListener(this);
    this.protocolCB.addItemListener(this);
    this.urlTF.getDocument().addDocumentListener(this);
    this.entriesTF.getDocument().addDocumentListener(this);
    this.worksetTF.getDocument().addDocumentListener(this);
    this.concurrentTF.getDocument().addDocumentListener(this);
    this.intervalTF.getDocument().addDocumentListener(this);
    this.varUniqCB.addItemListener(this);
    setEnabled();
  }
  
  void setEnabled() {
    this.setB.setEnabled(this.changed);
    this.restoreB.setEnabled(this.changed);
  }
  
  public void restore() {
    this.xmlTF.setText(SreeEnv.getProperty("replet.repository.file", ""));
    this.cacheTF.setText(SreeEnv.getProperty("replet.cache.directory", ""));
    this.datasourceTF.setText(SreeEnv.getProperty("datasource.registry.file", ""));
    this.queryTF.setText(SreeEnv.getProperty("query.registry.file", ""));
    this.servletTF.setText(SreeEnv.getProperty("replet.repository.servlet", ""));
    String str = SreeEnv.getProperty("replet.repository.protocol", "");
    this.protocolCB.setSelectedItem(str.toUpperCase());
    this.urlTF.setText(SreeEnv.getProperty("replet.repository.url", ""));
    this.entriesTF.setText(SreeEnv.getProperty("replet.cache.entries", "1000"));
    this.worksetTF.setText(SreeEnv.getProperty("replet.cache.workset", "3"));
    this.concurrentTF.setText(SreeEnv.getProperty("replet.cache.concurrency", "2"));
    this.intervalTF.setText(SreeEnv.getProperty("replet.cache.interval", "1000"));
    this.varUniqCB.setSelected(SreeEnv.getProperty("query.variable.unique", "true").equalsIgnoreCase("true"));
    this.changed = false;
    setEnabled();
  }
  
  public void set() {
    SreeEnv.setProperty("replet.repository.file", this.xmlTF.getText());
    SreeEnv.setProperty("replet.cache.directory", this.cacheTF.getText());
    SreeEnv.setProperty("datasource.registry.file", this.datasourceTF.getText());
    SreeEnv.setProperty("query.registry.file", this.queryTF.getText());
    SreeEnv.setProperty("replet.repository.servlet", this.servletTF.getText());
    SreeEnv.setProperty("replet.repository.protocol", (String)this.protocolCB.getSelectedItem());
    SreeEnv.setProperty("replet.repository.url", this.urlTF.getText());
    SreeEnv.setProperty("replet.cache.entries", this.entriesTF.getText());
    SreeEnv.setProperty("replet.cache.workset", this.worksetTF.getText());
    SreeEnv.setProperty("replet.cache.concurrency", this.concurrentTF.getText());
    SreeEnv.setProperty("replet.cache.interval", this.intervalTF.getText());
    SreeEnv.setProperty("query.variable.unique", this.varUniqCB.isSelected() + "");
    try {
      AdmGui.saveSreeEnv();
      this.changed = false;
      setEnabled();
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      AdmGui.showMessage(throwable.toString());
    } 
  }
  
  static final String[] protocols = { "LOCAL", "RMI", "CORBA" };
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\RepositoryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */