/*    */ package inetsoft.sree.adm;
/*    */ 
/*    */ import inetsoft.report.internal.j2d.Property2Panel;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Frame;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JPasswordField;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class AddUserD
/*    */   extends JDialog
/*    */ {
/*    */   boolean ok;
/*    */   JTextField userTF;
/*    */   JPasswordField passwdTF;
/*    */   JButton okB;
/*    */   JButton cancelB;
/*    */   
/*    */   public AddUserD(Frame paramFrame) {
/* 31 */     super(paramFrame);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 77 */     this.ok = true;
/* 78 */     this.userTF = new JTextField(20);
/* 79 */     this.passwdTF = new JPasswordField(20);
/* 80 */     this.okB = new JButton(Catalog.getString("OK"));
/* 81 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*    */     getContentPane().setLayout(new BorderLayout(5, 5));
/*    */     Property2Panel property2Panel = new Property2Panel();
/*    */     property2Panel.add(Catalog.getString("User Information"), new Object[][] { { Catalog.getString("User ID") + ":", this.userTF }, { Catalog.getString("Password") + ":", this.passwdTF } });
/*    */     getContentPane().add(property2Panel, "Center");
/*    */     JPanel jPanel = new JPanel();
/*    */     jPanel.add(this.okB);
/*    */     jPanel.add(this.cancelB);
/*    */     getContentPane().add(jPanel, "South");
/*    */     this.okB.addActionListener(new ActionListener(this) {
/*    */           private final AddUserD this$0;
/*    */           
/*    */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*    */             this.this$0.ok = true;
/*    */             this.this$0.dispose();
/*    */           }
/*    */         });
/*    */     this.cancelB.addActionListener(new ActionListener(this) {
/*    */           private final AddUserD this$0;
/*    */           
/*    */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*    */             this.this$0.ok = false;
/*    */             this.this$0.dispose();
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public static String[] showDialog(Frame paramFrame) {
/*    */     AddUserD addUserD = new AddUserD(paramFrame);
/*    */     addUserD.setModal(true);
/*    */     addUserD.pack();
/*    */     addUserD.setVisible(true);
/*    */     new String[2][0] = addUserD.getUser();
/*    */     new String[2][1] = addUserD.getPassword();
/*    */     return addUserD.ok ? new String[2] : null;
/*    */   }
/*    */   
/*    */   public String getUser() { return this.userTF.getText(); }
/*    */   
/*    */   public String getPassword() { return this.passwdTF.getText(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\AddUserD.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */