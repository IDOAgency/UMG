/*    */ package inetsoft.sree.adm;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.awt.event.ItemEvent;
/*    */ import java.awt.event.ItemListener;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.event.DocumentEvent;
/*    */ import javax.swing.event.DocumentListener;
/*    */ import javax.swing.event.ListSelectionEvent;
/*    */ import javax.swing.event.ListSelectionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ContentPane
/*    */   extends JPanel
/*    */   implements ActionListener, ItemListener, DocumentListener, ListSelectionListener
/*    */ {
/*    */   public void init() {}
/*    */   
/*    */   public void actionPerformed(ActionEvent paramActionEvent) {
/* 32 */     this.changed = true;
/* 33 */     setEnabled();
/*    */   }
/*    */   
/*    */   public void itemStateChanged(ItemEvent paramItemEvent) {
/* 37 */     this.changed = true;
/* 38 */     setEnabled();
/*    */   }
/*    */   
/*    */   public void insertUpdate(DocumentEvent paramDocumentEvent) {
/* 42 */     this.changed = true;
/* 43 */     setEnabled();
/*    */   }
/*    */ 
/*    */   
/* 47 */   public void removeUpdate(DocumentEvent paramDocumentEvent) { insertUpdate(paramDocumentEvent); }
/*    */ 
/*    */ 
/*    */   
/* 51 */   public void changedUpdate(DocumentEvent paramDocumentEvent) { insertUpdate(paramDocumentEvent); }
/*    */ 
/*    */   
/*    */   public void valueChanged(ListSelectionEvent paramListSelectionEvent) {
/* 55 */     this.changed = true;
/* 56 */     setEnabled();
/*    */   }
/*    */ 
/*    */   
/* 60 */   public boolean isChanged() { return this.changed; }
/*    */ 
/*    */ 
/*    */   
/* 64 */   public void setChanged(boolean paramBoolean) { this.changed = paramBoolean; }
/*    */   
/*    */   void setEnabled() {}
/*    */   
/*    */   protected boolean changed = false;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\ContentPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */