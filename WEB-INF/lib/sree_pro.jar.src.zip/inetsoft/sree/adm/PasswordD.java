package inetsoft.sree.adm;

import inetsoft.report.internal.j2d.PropertyPanel;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

class PasswordD extends JDialog {
  boolean ok;
  
  JPasswordField passwdTF;
  
  JButton okB;
  
  JButton cancelB;
  
  public PasswordD(Frame paramFrame) {
    super(paramFrame);
    this.ok = true;
    this.passwdTF = new JPasswordField(20);
    this.okB = new JButton(Catalog.getString("OK"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    getContentPane().setLayout(new BorderLayout(5, 5));
    PropertyPanel propertyPanel = new PropertyPanel();
    propertyPanel.setFields(new Object[][] { { Catalog.getString("Password") + ":", this.passwdTF } });
    getContentPane().add(propertyPanel, "Center");
    JPanel jPanel = new JPanel();
    jPanel.add(this.okB);
    jPanel.add(this.cancelB);
    getContentPane().add(jPanel, "South");
    this.okB.addActionListener(new ActionListener(this) {
          private final PasswordD this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.ok = true;
            this.this$0.dispose();
          }
        });
    this.cancelB.addActionListener(new ActionListener(this) {
          private final PasswordD this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.ok = false;
            this.this$0.dispose();
          }
        });
  }
  
  public static String showDialog(Frame paramFrame) {
    PasswordD passwordD = new PasswordD(paramFrame);
    passwordD.setModal(true);
    passwordD.pack();
    passwordD.setVisible(true);
    return passwordD.ok ? passwordD.getPassword() : null;
  }
  
  public String getPassword() { return this.passwdTF.getText(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\PasswordD.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */