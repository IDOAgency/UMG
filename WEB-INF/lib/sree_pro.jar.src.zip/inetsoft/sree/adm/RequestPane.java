package inetsoft.sree.adm;

import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.locale.Catalog;
import inetsoft.sree.RepletRequest;
import inetsoft.widget.DateCombo;
import inetsoft.widget.DateTimeCombo;
import inetsoft.widget.MenuButton;
import inetsoft.widget.TimeSpinner;
import inetsoft.widget.VFlowLayout;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

class RequestPane extends JPanel {
  FocusListener focusListener;
  
  ActionListener removeReqListener;
  
  ActionListener moreListener;
  
  Vector params;
  
  JPanel paramPnl;
  
  Component currfield;
  
  ContentPane content;
  
  MenuButton addB;
  
  JButton removeB;
  
  JCheckBoxMenuItem stringCM;
  
  JCheckBoxMenuItem booleanCM;
  
  JCheckBoxMenuItem integerCM;
  
  JCheckBoxMenuItem doubleCM;
  
  JCheckBoxMenuItem dateCM;
  
  JCheckBoxMenuItem timeCM;
  
  public RequestPane(String paramString, ContentPane paramContentPane) {
    this.focusListener = new FocusListener(this) {
        private final RequestPane this$0;
        
        public void focusGained(FocusEvent param1FocusEvent) {
          this.this$0.currfield = (Component)param1FocusEvent.getSource();
          this.this$0.setEnabled();
        }
        
        public void focusLost(FocusEvent param1FocusEvent) { this.this$0.setEnabled(); }
      };
    this.removeReqListener = new ActionListener(this) {
        private final RequestPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          for (byte b = 0; b < this.this$0.params.size(); b++) {
            Component component = (Component[])this.this$0.params.elementAt(b)[0];
            if (component == this.this$0.currfield) {
              this.this$0.params.removeElementAt(b);
              this.this$0.currfield = null;
              this.this$0.setup();
              this.this$0.setEnabled();
              break;
            } 
          } 
        }
      };
    this.moreListener = new ActionListener(this) {
        private final RequestPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.stringCM.isSelected()) {
            this.this$0.addParameter("Parameter", "");
          } else if (this.this$0.booleanCM.isSelected()) {
            this.this$0.addParameter("Parameter", new Boolean(false));
          } else if (this.this$0.integerCM.isSelected()) {
            this.this$0.addParameter("Parameter", new Integer(0));
          } else if (this.this$0.doubleCM.isSelected()) {
            this.this$0.addParameter("Parameter", new Double(0.0D));
          } else if (this.this$0.dateCM.isSelected()) {
            this.this$0.addParameter("Parameter", new Date());
          } else if (this.this$0.timeCM.isSelected()) {
            this.this$0.addParameter("Parameter", new Date(0L));
          } 
          this.this$0.setup();
        }
      };
    this.params = new Vector();
    this.paramPnl = new JPanel();
    this.currfield = null;
    this.addB = new MenuButton(Catalog.getString("Add"));
    this.removeB = new JButton(Catalog.getString("Remove"));
    this.stringCM = new JCheckBoxMenuItem(Catalog.getString("String"), true);
    this.booleanCM = new JCheckBoxMenuItem(Catalog.getString("Boolean"));
    this.integerCM = new JCheckBoxMenuItem(Catalog.getString("Integer"));
    this.doubleCM = new JCheckBoxMenuItem(Catalog.getString("Double"));
    this.dateCM = new JCheckBoxMenuItem(Catalog.getString("Date"));
    this.timeCM = new JCheckBoxMenuItem(Catalog.getString("Time"));
    this.content = paramContentPane;
    setLayout(new BorderLayout(5, 2));
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new VFlowLayout());
    jPanel.add(Box.createVerticalStrut(10));
    jPanel.add(this.addB);
    this.addB.addActionListener(this.moreListener);
    jPanel.add(this.removeB);
    this.removeB.addActionListener(this.removeReqListener);
    add(jPanel, "East");
    JPopupMenu jPopupMenu = new JPopupMenu();
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(this.stringCM);
    buttonGroup.add(this.booleanCM);
    buttonGroup.add(this.integerCM);
    buttonGroup.add(this.doubleCM);
    buttonGroup.add(this.dateCM);
    buttonGroup.add(this.timeCM);
    jPopupMenu.add(this.stringCM);
    jPopupMenu.add(this.booleanCM);
    jPopupMenu.add(this.integerCM);
    jPopupMenu.add(this.doubleCM);
    jPopupMenu.add(this.dateCM);
    jPopupMenu.add(this.timeCM);
    this.addB.setMenu(jPopupMenu);
    JScrollPane jScrollPane = new JScrollPane(this.paramPnl);
    this.paramPnl.setLayout(new GridBagLayout());
    if (paramString != null)
      setBorder(new TitledBorder(paramString)); 
    add(jScrollPane, "Center");
    setEnabled();
  }
  
  public RepletRequest getRepletRequest(String paramString) {
    RepletRequest repletRequest = new RepletRequest(paramString);
    for (byte b = 0; b < this.params.size(); b++) {
      Component[] arrayOfComponent = (Component[])this.params.elementAt(b);
      String str = ((JTextField)arrayOfComponent[0]).getText();
      if (arrayOfComponent[1] instanceof NumField) {
        NumField numField = (NumField)arrayOfComponent[1];
        if (numField.isInteger()) {
          repletRequest.setParameter(str, new Integer(numField.intValue()));
        } else {
          repletRequest.setParameter(str, new Double(numField.doubleValue()));
        } 
      } else if (arrayOfComponent[1] instanceof JTextField) {
        repletRequest.setParameter(str, ((JTextField)arrayOfComponent[1]).getText());
      } else if (arrayOfComponent[1] instanceof TimeSpinner) {
        repletRequest.setParameter(str, ((TimeSpinner)arrayOfComponent[1]).getDate());
      } else if (arrayOfComponent[1] instanceof DateCombo) {
        repletRequest.setParameter(str, ((DateCombo)arrayOfComponent[1]).getDate());
      } else if (arrayOfComponent[1] instanceof JCheckBox) {
        repletRequest.setParameter(str, new Boolean(((JCheckBox)arrayOfComponent[1]).isSelected()));
      } 
    } 
    return repletRequest;
  }
  
  public void setRepletRequest(RepletRequest paramRepletRequest) {
    this.params.removeAllElements();
    if (paramRepletRequest != null) {
      Enumeration enumeration = paramRepletRequest.getParameterNames();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        Object object = paramRepletRequest.getParameter(str);
        addParameter(str, object);
      } 
    } 
    setup();
  }
  
  private void addParameter(String paramString, Object paramObject) {
    JTextField jTextField1 = new JTextField(15);
    jTextField1.addFocusListener(this.focusListener);
    jTextField1.getDocument().addDocumentListener(this.content);
    jTextField1.setText(paramString);
    JTextField jTextField2 = null;
    if (paramObject instanceof Boolean) {
      JCheckBox jCheckBox = new JCheckBox("", ((Boolean)paramObject).booleanValue());
      jCheckBox.addItemListener(this.content);
      jTextField2 = jCheckBox;
    } else if (paramObject instanceof Integer) {
      NumField numField2 = new NumField(9, true);
      numField2.setValue(((Integer)paramObject).intValue());
      numField2.getDocument().addDocumentListener(this.content);
      NumField numField1 = numField2;
    } else if (paramObject instanceof Double) {
      NumField numField2 = new NumField(9, false);
      numField2.setValue(((Double)paramObject).doubleValue());
      numField2.getDocument().addDocumentListener(this.content);
      NumField numField1 = numField2;
    } else if (paramObject instanceof Date) {
      long l = ((Date)paramObject).getTime();
      if (l <= 172800000L) {
        TimeSpinner timeSpinner2 = new TimeSpinner();
        timeSpinner2.setDate((Date)paramObject);
        timeSpinner2.addActionListener(this.content);
        TimeSpinner timeSpinner1 = timeSpinner2;
      } else {
        DateTimeCombo dateTimeCombo2 = new DateTimeCombo();
        dateTimeCombo2.setDate((Date)paramObject);
        dateTimeCombo2.addActionListener(this.content);
        DateTimeCombo dateTimeCombo1 = dateTimeCombo2;
      } 
    } else {
      JTextField jTextField = new JTextField(15);
      jTextField.setText((paramObject == null) ? "" : paramObject.toString());
      jTextField.getDocument().addDocumentListener(this.content);
      jTextField2 = jTextField;
    } 
    this.params.addElement(new Component[] { jTextField1, jTextField2 });
  }
  
  private void setup() {
    while (this.paramPnl.getComponentCount() > 0)
      this.paramPnl.remove(0); 
    GridBagConstraints gridBagConstraints = null;
    for (byte b = 0; b < this.params.size(); b++) {
      Component[] arrayOfComponent = (Component[])this.params.elementAt(b);
      gridBagConstraints = new GridBagConstraints();
      gridBagConstraints.fill = 2;
      gridBagConstraints.weightx = 1.0D;
      gridBagConstraints.insets = new Insets(2, 2, 1, 5);
      this.paramPnl.add(arrayOfComponent[0], gridBagConstraints);
      gridBagConstraints = new GridBagConstraints();
      gridBagConstraints.insets = new Insets(2, 2, 1, 5);
      this.paramPnl.add(new JLabel(" = "), gridBagConstraints);
      gridBagConstraints = new GridBagConstraints();
      gridBagConstraints.fill = 2;
      gridBagConstraints.weightx = 1.0D;
      gridBagConstraints.gridwidth = 0;
      gridBagConstraints.anchor = 17;
      this.paramPnl.add(arrayOfComponent[1], gridBagConstraints);
    } 
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.weighty = 100.0D;
    gridBagConstraints.gridwidth = 0;
    this.paramPnl.add(new JLabel(""), gridBagConstraints);
    validate();
    repaint();
  }
  
  public void setEnabled(boolean paramBoolean) {
    this.addB.setEnabled(paramBoolean);
    this.removeB.setEnabled(paramBoolean);
  }
  
  private void setEnabled() { this.removeB.setEnabled((this.currfield != null)); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\RequestPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */