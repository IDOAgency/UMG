package inetsoft.sree.adm;

import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.sree.SreeEnv;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

class MailProperty extends ContentPane {
  JTextField fromTF;
  
  JTextField subjectTF;
  
  JTextField smtpTF;
  
  JTextField splitTF;
  
  NumField maxTF;
  
  JButton setB;
  
  JButton restoreB;
  
  public MailProperty() {
    this.fromTF = new JTextField(30);
    this.subjectTF = new JTextField(30);
    this.smtpTF = new JTextField(20);
    this.splitTF = new JTextField(30);
    this.maxTF = new NumField(9, true);
    this.setB = new JButton(Catalog.getString("Set"));
    this.restoreB = new JButton(Catalog.getString("Restore"));
    setLayout(new BorderLayout(5, 5));
    Property2Panel property2Panel = new Property2Panel();
    add(property2Panel, "Center");
    property2Panel.add(Catalog.getString("Message"), new Object[][] { { Catalog.getString("From Address") + ":", this.fromTF }, { Catalog.getString("Subject Format") + ":", this.subjectTF }, { Catalog.getString("Split Message") + ":", this.splitTF } });
    property2Panel.add(Catalog.getString("Server"), new Object[][] { { Catalog.getString("SMTP Host") + ":", this.smtpTF }, { Catalog.getString("Attachment Max Size") + ":", this.maxTF } });
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(2, 10, 5));
    jPanel.add(this.setB);
    this.setB.addActionListener(new ActionListener(this) {
          private final MailProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.set(); }
        });
    jPanel.add(this.restoreB);
    this.restoreB.addActionListener(new ActionListener(this) {
          private final MailProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.restore(); }
        });
    add(jPanel, "South");
  }
  
  public void init() {
    restore();
    this.fromTF.getDocument().addDocumentListener(this);
    this.subjectTF.getDocument().addDocumentListener(this);
    this.smtpTF.getDocument().addDocumentListener(this);
    this.splitTF.getDocument().addDocumentListener(this);
    this.maxTF.getDocument().addDocumentListener(this);
    setEnabled();
  }
  
  void setEnabled() {
    this.setB.setEnabled(this.changed);
    this.restoreB.setEnabled(this.changed);
  }
  
  public void restore() {
    this.fromTF.setText(SreeEnv.getProperty("mail.from.address", ""));
    this.subjectTF.setText(SreeEnv.getProperty("mail.subject.format", ""));
    this.smtpTF.setText(SreeEnv.getProperty("mail.smtp.host", ""));
    this.splitTF.setText(SreeEnv.getProperty("mail.split.message", ""));
    this.maxTF.setText(SreeEnv.getProperty("mail.attachment.max", ""));
    this.changed = false;
    setEnabled();
  }
  
  public void set() {
    SreeEnv.setProperty("mail.from.address", this.fromTF.getText());
    SreeEnv.setProperty("mail.subject.format", this.subjectTF.getText());
    SreeEnv.setProperty("mail.smtp.host", this.smtpTF.getText());
    SreeEnv.setProperty("mail.split.message", this.splitTF.getText());
    SreeEnv.setProperty("mail.attachment.max", this.maxTF.getText());
    try {
      AdmGui.saveSreeEnv();
      this.changed = false;
      setEnabled();
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      AdmGui.showMessage(throwable.toString());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\MailProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */