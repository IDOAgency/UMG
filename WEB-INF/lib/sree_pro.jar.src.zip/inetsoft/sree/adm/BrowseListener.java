package inetsoft.sree.adm;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFileChooser;
import javax.swing.JTextField;

class BrowseListener implements ActionListener {
  JTextField field;
  
  public BrowseListener(JTextField paramJTextField) { this.field = paramJTextField; }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    JFileChooser jFileChooser = new JFileChooser(this.field.getText());
    if (jFileChooser.showOpenDialog(null) == 0)
      this.field.setText(jFileChooser.getSelectedFile().toString()); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\BrowseListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */