package inetsoft.sree.adm;

import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.sree.SreeEnv;
import inetsoft.widget.ColorComboBox;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTextField;

class HTMLProperty extends ContentPane {
  JTextField repoHdrTF;
  
  JTextField repoFtrTF;
  
  JTextField pageFtrTF;
  
  JTextField pageFrameTF;
  
  JTextField tempTF;
  
  JCheckBox newFrameRB;
  
  JCheckBox framesRB;
  
  JCheckBox showWinRB;
  
  NumField timeoutTF;
  
  JButton tempBrowseB;
  
  ColorComboBox bgCB;
  
  JCheckBox texttoolCB;
  
  JCheckBox findCB;
  
  JCheckBox findNextCB;
  
  JCheckBox pdfCB;
  
  JCheckBox mailCB;
  
  JCheckBox sprintCB;
  
  JCheckBox tocCB;
  
  JCheckBox exportCB;
  
  JCheckBox refreshCB;
  
  JButton setB;
  
  JButton restoreB;
  
  public HTMLProperty() {
    this.repoHdrTF = new JTextField(30);
    this.repoFtrTF = new JTextField(30);
    this.pageFtrTF = new JTextField(30);
    this.pageFrameTF = new JTextField(15);
    this.tempTF = new JTextField(30);
    this.newFrameRB = new JCheckBox(Catalog.getString("Create New Window from Repository"));
    this.framesRB = new JCheckBox(Catalog.getString("Use Frame-based Viewer"));
    this.showWinRB = new JCheckBox(Catalog.getString("Create New Window when Drilldown"));
    this.timeoutTF = new NumField(10, true);
    this.tempBrowseB = new JButton(Catalog.getString("Browse"));
    this.bgCB = new ColorComboBox();
    this.texttoolCB = new JCheckBox(Catalog.getString("Text Style Toolbar"));
    this.findCB = new JCheckBox(Catalog.getString("Find"));
    this.findNextCB = new JCheckBox(Catalog.getString("Find Next"));
    this.pdfCB = new JCheckBox(Catalog.getString("PDF"));
    this.mailCB = new JCheckBox(Catalog.getString("Mail"));
    this.sprintCB = new JCheckBox(Catalog.getString("Server Print"));
    this.tocCB = new JCheckBox(Catalog.getString("TOC"));
    this.exportCB = new JCheckBox(Catalog.getString("Export"));
    this.refreshCB = new JCheckBox(Catalog.getString("Refresh"));
    this.setB = new JButton(Catalog.getString("Set"));
    this.restoreB = new JButton(Catalog.getString("Restore"));
    setLayout(new BorderLayout(5, 5));
    Property2Panel property2Panel = new Property2Panel();
    add(property2Panel, "Center");
    property2Panel.add(Catalog.getString("Presentation"), new Object[][] { { Catalog.getString("Repository Header") + ":", this.repoHdrTF }, { Catalog.getString("Repository Footer") + ":", this.repoFtrTF }, { Catalog.getString("Page Footer") + ":", this.pageFtrTF }, { Catalog.getString("Background") + ":", this.bgCB, this.texttoolCB } });
    property2Panel.add(Catalog.getString("Toolbar"), new Object[][] { { this.findCB, this.findNextCB, this.pdfCB, this.mailCB, this.sprintCB, this.tocCB, this.exportCB, this.refreshCB } });
    property2Panel.add(Catalog.getString("Frames"), new Object[][] { { this.framesRB, { Catalog.getString("Page Frame") + ":", this.pageFrameTF } }, { this.newFrameRB, this.showWinRB } });
    property2Panel.add(Catalog.getString("Page Management"), new Object[][] { { Catalog.getString("Cache Directory") + ":", { this.tempTF, this.tempBrowseB } }, { Catalog.getString("Session Timeout") + ":", this.timeoutTF } });
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(2, 10, 5));
    jPanel.add(this.setB);
    this.setB.addActionListener(new ActionListener(this) {
          private final HTMLProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.set(); }
        });
    jPanel.add(this.restoreB);
    this.restoreB.addActionListener(new ActionListener(this) {
          private final HTMLProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.restore(); }
        });
    add(jPanel, "South");
    this.tempBrowseB.addActionListener(new BrowseListener(this.tempTF));
  }
  
  public void init() {
    restore();
    this.repoHdrTF.getDocument().addDocumentListener(this);
    this.repoFtrTF.getDocument().addDocumentListener(this);
    this.pageFtrTF.getDocument().addDocumentListener(this);
    this.pageFrameTF.getDocument().addDocumentListener(this);
    this.tempTF.getDocument().addDocumentListener(this);
    this.timeoutTF.getDocument().addDocumentListener(this);
    this.bgCB.addActionListener(this);
    this.newFrameRB.addItemListener(this);
    this.showWinRB.addItemListener(this);
    this.framesRB.addItemListener(this);
    this.texttoolCB.addItemListener(this);
    this.findCB.addItemListener(this);
    this.findNextCB.addItemListener(this);
    this.pdfCB.addItemListener(this);
    this.mailCB.addItemListener(this);
    this.sprintCB.addItemListener(this);
    this.tocCB.addItemListener(this);
    this.exportCB.addItemListener(this);
    this.refreshCB.addItemListener(this);
    setEnabled();
  }
  
  void setEnabled() {
    this.newFrameRB.setEnabled(!this.framesRB.isSelected());
    this.pageFrameTF.setEnabled((this.newFrameRB.isEnabled() && !this.newFrameRB.isSelected()));
    this.setB.setEnabled(this.changed);
    this.restoreB.setEnabled(this.changed);
  }
  
  public void restore() {
    this.repoHdrTF.setText(SreeEnv.getProperty("html.repository.header", ""));
    this.repoFtrTF.setText(SreeEnv.getProperty("html.repository.footer", ""));
    this.pageFtrTF.setText(SreeEnv.getProperty("html.page.footer", ""));
    this.pageFrameTF.setText(SreeEnv.getProperty("html.page.frame", ""));
    this.newFrameRB.setSelected(SreeEnv.getProperty("html.page.window", "false").equalsIgnoreCase("true"));
    this.showWinRB.setSelected(SreeEnv.getProperty("html.showreplet.window", "true").equalsIgnoreCase("true"));
    this.framesRB.setSelected(SreeEnv.getProperty("html.viewer.frameset", "false").equalsIgnoreCase("true"));
    this.texttoolCB.setSelected(SreeEnv.getProperty("html.toolbar.text", "false").equalsIgnoreCase("true"));
    this.findCB.setSelected(SreeEnv.getProperty("html.find.button", "true").equalsIgnoreCase("true"));
    this.findNextCB.setSelected(SreeEnv.getProperty("html.findNext.button", "true").equalsIgnoreCase("true"));
    this.pdfCB.setSelected(SreeEnv.getProperty("html.pdf.button", "true").equalsIgnoreCase("true"));
    this.mailCB.setSelected(SreeEnv.getProperty("html.mail.button", "true").equalsIgnoreCase("true"));
    this.sprintCB.setSelected(SreeEnv.getProperty("html.serverPrint.button", "false").equalsIgnoreCase("true"));
    this.tocCB.setSelected(SreeEnv.getProperty("html.toc.button", "true").equalsIgnoreCase("true"));
    this.exportCB.setSelected(SreeEnv.getProperty("html.export.button", "true").equalsIgnoreCase("true"));
    this.refreshCB.setSelected(SreeEnv.getProperty("html.refresh.button", "true").equalsIgnoreCase("true"));
    this.tempTF.setText(SreeEnv.getProperty("html.directory", ""));
    this.timeoutTF.setText(SreeEnv.getProperty("html.session.timeout", "12000000"));
    try {
      String str = SreeEnv.getProperty("html.background", "#FFFFFF");
      this.bgCB.setSelectedColor(Color.decode(str));
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      AdmGui.showMessage(throwable.toString());
    } 
    this.changed = false;
    setEnabled();
  }
  
  public void set() {
    SreeEnv.setProperty("html.repository.header", this.repoHdrTF.getText());
    SreeEnv.setProperty("html.repository.footer", this.repoFtrTF.getText());
    SreeEnv.setProperty("html.page.footer", this.pageFtrTF.getText());
    SreeEnv.setProperty("html.directory", this.tempTF.getText());
    SreeEnv.setProperty("html.session.timeout", this.timeoutTF.getText());
    SreeEnv.setProperty("html.viewer.frameset", this.framesRB.isSelected() + "");
    SreeEnv.setProperty("html.page.window", this.newFrameRB.isSelected() + "");
    SreeEnv.setProperty("html.showreplet.window", this.showWinRB.isSelected() + "");
    SreeEnv.setProperty("html.page.frame", this.pageFrameTF.getText());
    SreeEnv.setProperty("html.toolbar.text", this.texttoolCB.isSelected() + "");
    SreeEnv.setProperty("html.find.button", this.findCB.isSelected() + "");
    SreeEnv.setProperty("html.findNext.button", this.findNextCB.isSelected() + "");
    SreeEnv.setProperty("html.pdf.button", this.pdfCB.isSelected() + "");
    SreeEnv.setProperty("html.mail.button", this.mailCB.isSelected() + "");
    SreeEnv.setProperty("html.serverPrint.button", this.sprintCB.isSelected() + "");
    SreeEnv.setProperty("html.toc.button", this.tocCB.isSelected() + "");
    SreeEnv.setProperty("html.export.button", this.exportCB.isSelected() + "");
    SreeEnv.setProperty("html.refresh.button", this.refreshCB.isSelected() + "");
    Color color = this.bgCB.getSelectedColor();
    SreeEnv.setProperty("html.background", "#" + Integer.toString(0xFFFFFF & color.getRGB(), 16));
    try {
      AdmGui.saveSreeEnv();
      this.changed = false;
      setEnabled();
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      AdmGui.showMessage(throwable.toString());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\HTMLProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */