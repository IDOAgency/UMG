package inetsoft.sree.adm;

import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.sree.SreeEnv;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToggleButton;

class SecurityProperty extends ContentPane {
  JCheckBox secRB;
  
  JTextField controllerTF;
  
  JTextField passwdTF;
  
  JButton passwdBrowseB;
  
  JTextField aclTF;
  
  JButton aclBrowseB;
  
  JButton setB;
  
  JButton restoreB;
  
  public SecurityProperty(JToggleButton.ToggleButtonModel paramToggleButtonModel) {
    this.secRB = new JCheckBox(Catalog.getString("Use Default Security Manager"));
    this.controllerTF = new JTextField(30);
    this.passwdTF = new JTextField(30);
    this.passwdBrowseB = new JButton(Catalog.getString("Browse"));
    this.aclTF = new JTextField(30);
    this.aclBrowseB = new JButton(Catalog.getString("Browse"));
    this.setB = new JButton(Catalog.getString("Set"));
    this.restoreB = new JButton(Catalog.getString("Restore"));
    setLayout(new BorderLayout(5, 5));
    this.secRB.setSelected(paramToggleButtonModel.isSelected());
    this.secRB.addItemListener(new ItemListener(this, paramToggleButtonModel) {
          private final JToggleButton.ToggleButtonModel val$def;
          
          private final SecurityProperty this$0;
          
          public void itemStateChanged(ItemEvent param1ItemEvent) { this.val$def.setSelected(this.this$0.secRB.isSelected()); }
        });
    Property2Panel property2Panel = new Property2Panel();
    add(property2Panel, "Center");
    property2Panel.add(Catalog.getString("Controller"), new Object[][] { { this.secRB }, { Catalog.getString("Controller Class") + ":", this.controllerTF } });
    property2Panel.add(Catalog.getString("Files"), new Object[][] { { Catalog.getString("Password File") + ":", { this.passwdTF, this.passwdBrowseB } }, { Catalog.getString("ACL File") + ":", { this.aclTF, this.aclBrowseB } } });
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(2, 10, 5));
    jPanel.add(this.setB);
    this.setB.addActionListener(new ActionListener(this) {
          private final SecurityProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.set(); }
        });
    jPanel.add(this.restoreB);
    this.restoreB.addActionListener(new ActionListener(this) {
          private final SecurityProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.restore(); }
        });
    add(jPanel, "South");
    this.passwdBrowseB.addActionListener(new BrowseListener(this.passwdTF));
    this.aclBrowseB.addActionListener(new BrowseListener(this.aclTF));
  }
  
  public void init() {
    restore();
    this.secRB.addItemListener(this);
    this.controllerTF.getDocument().addDocumentListener(this);
    this.passwdTF.getDocument().addDocumentListener(this);
    this.aclTF.getDocument().addDocumentListener(this);
    setEnabled();
  }
  
  void setEnabled() {
    this.setB.setEnabled(this.changed);
    this.restoreB.setEnabled(this.changed);
    this.passwdTF.setEnabled(this.secRB.isSelected());
    this.passwdBrowseB.setEnabled(this.secRB.isSelected());
    this.aclTF.setEnabled(this.secRB.isSelected());
    this.aclBrowseB.setEnabled(this.secRB.isSelected());
    this.controllerTF.setEnabled(!this.secRB.isSelected());
  }
  
  public void restore() {
    this.controllerTF.setText(SreeEnv.getProperty("security.access.controller", ""));
    this.passwdTF.setText(SreeEnv.getProperty("security.password.file", ""));
    this.aclTF.setText(SreeEnv.getProperty("security.acl.file", ""));
    this.changed = false;
    setEnabled();
  }
  
  public void set() {
    if (this.secRB.isSelected()) {
      SreeEnv.setProperty("security.access.controller", "inetsoft.sree.security.DefaultController");
      SreeEnv.setProperty("security.password.file", this.passwdTF.getText());
      SreeEnv.setProperty("security.acl.file", this.aclTF.getText());
    } else {
      String str = this.controllerTF.getText();
      if (str.equals("inetsoft.sree.security.DefaultController") || str.length() == 0) {
        SreeEnv.getProperties().remove("security.access.controller");
      } else {
        SreeEnv.setProperty("security.access.controller", str);
      } 
    } 
    try {
      AdmGui.saveSreeEnv();
      this.changed = false;
      setEnabled();
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      AdmGui.showMessage(throwable.toString());
    } 
  }
  
  JToggleButton.ToggleButtonModel getModel() { return (JToggleButton.ToggleButtonModel)this.secRB.getModel(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\sree_pro.jar!\inetsoft\sree\adm\SecurityProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */