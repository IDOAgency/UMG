package weblogic.ant.taskdefs.webservices.clientgen;

import java.io.File;
import java.io.IOException;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;
import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.utils.StringUtils;
import weblogic.webservice.tools.build.BuildToolsFactory;
import weblogic.webservice.tools.build.ClientGen;
import weblogic.webservice.tools.build.WSBuildException;

public class ClientGenTask extends Task {
  protected static boolean DEBUG = false;
  
  private static final String LIST_DELIM = ",";
  
  private String wsdlURI;
  
  private File ear;
  
  private File clientJar;
  
  private String packageName;
  
  private String typePackageBase;
  
  private String typePackageName;
  
  private String serviceName;
  
  private boolean autotype = true;
  
  private boolean overwrite = true;
  
  private String defaultEndpoint;
  
  private String warName;
  
  private File typeMappingFile;
  
  private boolean useServerTypes = false;
  
  private Path compilerClasspath;
  
  private boolean isJ2ME = false;
  
  private boolean saveWSDL = true;
  
  private boolean keepGenerated = false;
  
  private String portInterfaces;
  
  private boolean useLowerCaseMethodNames = true;
  
  private boolean usePortNameAsMethodName = false;
  
  private boolean generateAsyncMethods = false;
  
  private boolean onlyConvenienceMethod = false;
  
  private boolean generatePublicFields = false;
  
  private String proxyHost;
  
  private String proxyPort = "80";
  
  private String compiler;
  
  public void setWsdl(String paramString) { this.wsdlURI = paramString; }
  
  public void setEar(File paramFile) { this.ear = paramFile; }
  
  public void setWarName(String paramString) { this.warName = paramString; }
  
  public void setClientjar(File paramFile) { this.clientJar = paramFile; }
  
  public void setPackageName(String paramString) { this.packageName = paramString; }
  
  public void setOnlyConvenienceMethod(boolean paramBoolean) { this.onlyConvenienceMethod = paramBoolean; }
  
  public void setTypePackageBase(String paramString) { this.typePackageBase = paramString; }
  
  public void setTypePackageName(String paramString) { this.typePackageName = paramString; }
  
  public void setServiceName(String paramString) { this.serviceName = paramString; }
  
  public void setTypeMappingFile(File paramFile) { this.typeMappingFile = paramFile; }
  
  public void setAutotype(boolean paramBoolean) { this.autotype = paramBoolean; }
  
  public void setUseServerTypes(boolean paramBoolean) { this.useServerTypes = paramBoolean; }
  
  public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
  
  public void setJ2ME(boolean paramBoolean) { this.isJ2ME = paramBoolean; }
  
  public void setSavewsdl(boolean paramBoolean) { this.saveWSDL = paramBoolean; }
  
  public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
  
  public void setDefaultendpoint(String paramString) { this.defaultEndpoint = paramString; }
  
  public void setClasspath(Path paramPath) {
    if (this.compilerClasspath == null) {
      this.compilerClasspath = paramPath;
    } else {
      this.compilerClasspath.append(paramPath);
    } 
  }
  
  public Path getClasspath() { return this.compilerClasspath; }
  
  public void setGenerateAsyncMethods(boolean paramBoolean) { this.generateAsyncMethods = paramBoolean; }
  
  public void setGeneratePublicFields(boolean paramBoolean) { this.generatePublicFields = paramBoolean; }
  
  public void setProxyHost(String paramString) { this.proxyHost = paramString; }
  
  public void setProxyPort(String paramString) { this.proxyPort = paramString; }
  
  public Path createClasspath() {
    if (this.compilerClasspath == null)
      this.compilerClasspath = new Path(this.project); 
    return this.compilerClasspath.createPath();
  }
  
  public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
  
  public void setPortInterfaces(String paramString) { this.portInterfaces = paramString; }
  
  public void setUseLowerCaseMethodNames(boolean paramBoolean) { this.useLowerCaseMethodNames = paramBoolean; }
  
  public void setUsePortNameAsMethodName(boolean paramBoolean) { this.usePortNameAsMethodName = paramBoolean; }
  
  public void execute() {
    validateAttributeSettings();
    TaskUtils.setAntProject(getProject());
    if (!this.overwrite && !needToRun())
      return; 
    String str = null;
    if (this.ear != null) {
      str = this.ear.getName() + ((this.serviceName == null) ? "" : ("(" + this.serviceName + ")"));
    } else {
      str = this.wsdlURI;
    } 
    log("Generating client jar for " + str + " ...");
    try {
      setupCompiler();
      doClientGen();
    } catch (IOException iOException) {
      iOException.printStackTrace();
      throw new BuildException(iOException);
    } catch (WSBuildException wSBuildException) {
      if (wSBuildException.getNested() != null)
        wSBuildException.getNested().printStackTrace(); 
      throw new BuildException(wSBuildException);
    } catch (RuntimeException runtimeException) {
      throw new BuildException(runtimeException);
    } 
  }
  
  private void validateAttributeSettings() {
    if (this.clientJar == null)
      throw new BuildException("The clientJar attribute must be set"); 
    if (this.packageName == null)
      throw new BuildException("The packageName attribute must be set"); 
    this.packageName = this.packageName.trim();
    if (this.packageName.length() == 0)
      throw new BuildException("Invalid packageName attribute"); 
    if (this.useServerTypes && this.wsdlURI != null)
      throw new BuildException("Cannot specify useServerTypes = \"true\" if the wsdl attribute is set"); 
    if (this.ear == null && this.wsdlURI == null)
      throw new BuildException("Either the ear or wsdl attribute must be set"); 
    if (this.ear != null && this.wsdlURI != null)
      throw new BuildException("Either the ear or wsdl attribute must be set, but not both"); 
    if (this.ear != null && !this.ear.exists())
      throw new BuildException("The ear file specified does not exist (" + this.ear.getAbsolutePath() + ")"); 
    if (this.ear == null) {
      if (this.warName != null)
        throw new BuildException("WarName attribute can only be specified with ear attribute"); 
    } else if (this.warName == null) {
      this.warName = "web-services.war";
    } 
    if (this.typePackageName != null && this.typePackageBase != null)
      throw new BuildException("Can't specify both typePackageName and typePackageBase."); 
    if (this.proxyHost != null) {
      System.setProperty("http.proxyHost", this.proxyHost);
      System.setProperty("http.proxyPort", this.proxyPort);
    } 
  }
  
  private boolean needToRun() {
    if (!this.clientJar.exists())
      return true; 
    if (this.clientJar.isDirectory())
      return true; 
    long l1 = this.clientJar.lastModified();
    long l2 = 0L;
    if (this.ear != null) {
      if (this.ear.isDirectory())
        return true; 
      l2 = this.ear.lastModified();
    } else {
      File file = TaskUtils.getFileFromWSDLURI(this.wsdlURI);
      if (file == null)
        return true; 
      l2 = file.lastModified();
    } 
    if (l2 == 0L)
      return true; 
    return (l2 > l1);
  }
  
  private void doClientGen() {
    BuildToolsFactory buildToolsFactory = null;
    if (this.isJ2ME) {
      buildToolsFactory;
      buildToolsFactory = BuildToolsFactory.getInstance("j2me");
    } else {
      buildToolsFactory = buildToolsFactory.getInstance();
    } 
    ClientGen clientGen = buildToolsFactory.getClientGen();
    String[] arrayOfString = null;
    if (this.portInterfaces != null) {
      String[] arrayOfString1 = StringUtils.splitCompletely(this.portInterfaces, ",");
      arrayOfString = new String[arrayOfString1.length];
      for (byte b = 0; b < arrayOfString1.length; b++)
        arrayOfString[b] = arrayOfString1[b].trim(); 
    } 
    if (this.wsdlURI != null)
      clientGen.setWsdlUrl(TaskUtils.getResourceURL(this.wsdlURI)); 
    clientGen.setEarFile(this.ear);
    clientGen.setWarName(this.warName);
    clientGen.setServiceName(this.serviceName);
    clientGen.setClientJar(this.clientJar);
    clientGen.setClientPackageName(this.packageName);
    clientGen.setTypePackageName(this.typePackageName);
    clientGen.setTypePackageBase(this.typePackageBase);
    clientGen.setTypeMappingFile(this.typeMappingFile);
    clientGen.setAutotype(this.autotype);
    clientGen.setUseServerTypes(this.useServerTypes);
    clientGen.setSaveWSDL(this.saveWSDL);
    clientGen.setCompiler(this.compiler);
    clientGen.setCompilerClasspath(this.compilerClasspath.toString());
    clientGen.setPortInterfaces(arrayOfString);
    clientGen.setUseLowerCaseMethodNames(this.useLowerCaseMethodNames);
    clientGen.setUsePortNameAsMethodName(this.usePortNameAsMethodName);
    clientGen.setKeepGenerated(this.keepGenerated);
    clientGen.setLogger(new BuildTaskLogger(this));
    clientGen.setGenerateAsyncMethods(this.generateAsyncMethods);
    clientGen.setGeneratePublicFields(this.generatePublicFields);
    clientGen.setOnlyConvenienceMethod(this.onlyConvenienceMethod);
    classLoader = TaskUtils.setClasspath(this.compilerClasspath.toString());
    try {
      clientGen.run();
    } finally {
      TaskUtils.setClassLoader(classLoader);
    } 
  }
  
  private void setupCompiler() {
    this.compiler = TaskUtils.getCompiler();
    log("Will use compiler " + this.compiler, 3);
    if (this.compilerClasspath == null) {
      this.compilerClasspath = (Path)Path.systemClasspath.clone();
    } else {
      this.compilerClasspath.concatSystemClasspath("ignore");
    } 
    log("Will use compilerClasspath " + this.compilerClasspath, 3);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\clientgen\ClientGenTask.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */