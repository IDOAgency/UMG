/*     */ package weblogic.ant.taskdefs.webservices.clientgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.utils.StringUtils;
/*     */ import weblogic.webservice.tools.build.BuildToolsFactory;
/*     */ import weblogic.webservice.tools.build.ClientGen;
/*     */ import weblogic.webservice.tools.build.WSBuildException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientGenTask
/*     */   extends Task
/*     */ {
/*     */   protected static boolean DEBUG = false;
/*     */   private static final String LIST_DELIM = ",";
/*     */   private String wsdlURI;
/*     */   private File ear;
/*     */   private File clientJar;
/*     */   private String packageName;
/*     */   private String typePackageBase;
/*     */   private String typePackageName;
/*     */   private String serviceName;
/*     */   private boolean autotype = true;
/*     */   private boolean overwrite = true;
/*     */   private String defaultEndpoint;
/*     */   private String warName;
/*     */   private File typeMappingFile;
/*     */   private boolean useServerTypes = false;
/*     */   private Path compilerClasspath;
/*     */   private boolean isJ2ME = false;
/*     */   private boolean saveWSDL = true;
/*     */   private boolean keepGenerated = false;
/*     */   private String portInterfaces;
/*     */   private boolean useLowerCaseMethodNames = true;
/*     */   private boolean usePortNameAsMethodName = false;
/*     */   private boolean generateAsyncMethods = false;
/*     */   private boolean onlyConvenienceMethod = false;
/*     */   private boolean generatePublicFields = false;
/*     */   private String proxyHost;
/*  58 */   private String proxyPort = "80";
/*     */ 
/*     */ 
/*     */   
/*     */   private String compiler;
/*     */ 
/*     */ 
/*     */   
/*  66 */   public void setWsdl(String paramString) { this.wsdlURI = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  70 */   public void setEar(File paramFile) { this.ear = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  74 */   public void setWarName(String paramString) { this.warName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  78 */   public void setClientjar(File paramFile) { this.clientJar = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  82 */   public void setPackageName(String paramString) { this.packageName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  86 */   public void setOnlyConvenienceMethod(boolean paramBoolean) { this.onlyConvenienceMethod = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  90 */   public void setTypePackageBase(String paramString) { this.typePackageBase = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  94 */   public void setTypePackageName(String paramString) { this.typePackageName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  98 */   public void setServiceName(String paramString) { this.serviceName = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 102 */   public void setTypeMappingFile(File paramFile) { this.typeMappingFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/* 106 */   public void setAutotype(boolean paramBoolean) { this.autotype = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void setUseServerTypes(boolean paramBoolean) { this.useServerTypes = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 114 */   public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 118 */   public void setJ2ME(boolean paramBoolean) { this.isJ2ME = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 122 */   public void setSavewsdl(boolean paramBoolean) { this.saveWSDL = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 130 */   public void setDefaultendpoint(String paramString) { this.defaultEndpoint = paramString; }
/*     */ 
/*     */   
/*     */   public void setClasspath(Path paramPath) {
/* 134 */     if (this.compilerClasspath == null) {
/* 135 */       this.compilerClasspath = paramPath;
/*     */     } else {
/* 137 */       this.compilerClasspath.append(paramPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 142 */   public Path getClasspath() { return this.compilerClasspath; }
/*     */ 
/*     */ 
/*     */   
/* 146 */   public void setGenerateAsyncMethods(boolean paramBoolean) { this.generateAsyncMethods = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 150 */   public void setGeneratePublicFields(boolean paramBoolean) { this.generatePublicFields = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 154 */   public void setProxyHost(String paramString) { this.proxyHost = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 158 */   public void setProxyPort(String paramString) { this.proxyPort = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/* 165 */     if (this.compilerClasspath == null) {
/* 166 */       this.compilerClasspath = new Path(this.project);
/*     */     }
/* 168 */     return this.compilerClasspath.createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
/*     */ 
/*     */ 
/*     */   
/* 179 */   public void setPortInterfaces(String paramString) { this.portInterfaces = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 183 */   public void setUseLowerCaseMethodNames(boolean paramBoolean) { this.useLowerCaseMethodNames = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 187 */   public void setUsePortNameAsMethodName(boolean paramBoolean) { this.usePortNameAsMethodName = paramBoolean; }
/*     */ 
/*     */   
/*     */   public void execute() {
/* 191 */     validateAttributeSettings();
/*     */     
/* 193 */     TaskUtils.setAntProject(getProject());
/*     */     
/* 195 */     if (!this.overwrite && !needToRun())
/*     */       return; 
/* 197 */     String str = null;
/* 198 */     if (this.ear != null) {
/* 199 */       str = this.ear.getName() + ((this.serviceName == null) ? "" : ("(" + this.serviceName + ")"));
/*     */     } else {
/* 201 */       str = this.wsdlURI;
/*     */     } 
/* 203 */     log("Generating client jar for " + str + " ...");
/*     */     
/*     */     try {
/* 206 */       setupCompiler();
/*     */       
/* 208 */       doClientGen();
/*     */     }
/* 210 */     catch (IOException iOException) {
/* 211 */       iOException.printStackTrace();
/* 212 */       throw new BuildException(iOException);
/* 213 */     } catch (WSBuildException wSBuildException) {
/* 214 */       if (wSBuildException.getNested() != null) {
/* 215 */         wSBuildException.getNested().printStackTrace();
/*     */       }
/* 217 */       throw new BuildException(wSBuildException);
/* 218 */     } catch (RuntimeException runtimeException) {
/* 219 */       throw new BuildException(runtimeException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateAttributeSettings() {
/* 224 */     if (this.clientJar == null) {
/* 225 */       throw new BuildException("The clientJar attribute must be set");
/*     */     }
/*     */     
/* 228 */     if (this.packageName == null) {
/* 229 */       throw new BuildException("The packageName attribute must be set");
/*     */     }
/*     */     
/* 232 */     this.packageName = this.packageName.trim();
/*     */     
/* 234 */     if (this.packageName.length() == 0) {
/* 235 */       throw new BuildException("Invalid packageName attribute");
/*     */     }
/*     */     
/* 238 */     if (this.useServerTypes && this.wsdlURI != null) {
/* 239 */       throw new BuildException("Cannot specify useServerTypes = \"true\" if the wsdl attribute is set");
/*     */     }
/* 241 */     if (this.ear == null && this.wsdlURI == null) {
/* 242 */       throw new BuildException("Either the ear or wsdl attribute must be set");
/*     */     }
/*     */ 
/*     */     
/* 246 */     if (this.ear != null && this.wsdlURI != null) {
/* 247 */       throw new BuildException("Either the ear or wsdl attribute must be set, but not both");
/*     */     }
/*     */ 
/*     */     
/* 251 */     if (this.ear != null && !this.ear.exists()) {
/* 252 */       throw new BuildException("The ear file specified does not exist (" + this.ear.getAbsolutePath() + ")");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 257 */     if (this.ear == null) {
/* 258 */       if (this.warName != null) {
/* 259 */         throw new BuildException("WarName attribute can only be specified with ear attribute");
/*     */       
/*     */       }
/*     */     }
/* 263 */     else if (this.warName == null) {
/* 264 */       this.warName = "web-services.war";
/*     */     } 
/*     */ 
/*     */     
/* 268 */     if (this.typePackageName != null && this.typePackageBase != null) {
/* 269 */       throw new BuildException("Can't specify both typePackageName and typePackageBase.");
/*     */     }
/*     */ 
/*     */     
/* 273 */     if (this.proxyHost != null) {
/* 274 */       System.setProperty("http.proxyHost", this.proxyHost);
/* 275 */       System.setProperty("http.proxyPort", this.proxyPort);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean needToRun() {
/* 280 */     if (!this.clientJar.exists()) return true;
/*     */     
/* 282 */     if (this.clientJar.isDirectory()) return true;
/*     */     
/* 284 */     long l1 = this.clientJar.lastModified();
/* 285 */     long l2 = 0L;
/*     */     
/* 287 */     if (this.ear != null) {
/* 288 */       if (this.ear.isDirectory()) return true;
/*     */       
/* 290 */       l2 = this.ear.lastModified();
/*     */     } else {
/*     */       
/* 293 */       File file = TaskUtils.getFileFromWSDLURI(this.wsdlURI);
/*     */       
/* 295 */       if (file == null) return true;
/*     */       
/* 297 */       l2 = file.lastModified();
/*     */     } 
/*     */     
/* 300 */     if (l2 == 0L) return true;
/*     */     
/* 302 */     return (l2 > l1);
/*     */   }
/*     */   
/*     */   private void doClientGen() {
/* 306 */     BuildToolsFactory buildToolsFactory = null;
/* 307 */     if (this.isJ2ME) {
/* 308 */       buildToolsFactory; buildToolsFactory = BuildToolsFactory.getInstance("j2me");
/*     */     } else {
/* 310 */       buildToolsFactory = buildToolsFactory.getInstance();
/*     */     } 
/* 312 */     ClientGen clientGen = buildToolsFactory.getClientGen();
/*     */     
/* 314 */     String[] arrayOfString = null;
/* 315 */     if (this.portInterfaces != null) {
/* 316 */       String[] arrayOfString1 = StringUtils.splitCompletely(this.portInterfaces, ",");
/* 317 */       arrayOfString = new String[arrayOfString1.length];
/* 318 */       for (byte b = 0; b < arrayOfString1.length; b++) {
/* 319 */         arrayOfString[b] = arrayOfString1[b].trim();
/*     */       }
/*     */     } 
/*     */     
/* 323 */     if (this.wsdlURI != null) {
/* 324 */       clientGen.setWsdlUrl(TaskUtils.getResourceURL(this.wsdlURI));
/*     */     }
/*     */     
/* 327 */     clientGen.setEarFile(this.ear);
/* 328 */     clientGen.setWarName(this.warName);
/* 329 */     clientGen.setServiceName(this.serviceName);
/* 330 */     clientGen.setClientJar(this.clientJar);
/* 331 */     clientGen.setClientPackageName(this.packageName);
/* 332 */     clientGen.setTypePackageName(this.typePackageName);
/* 333 */     clientGen.setTypePackageBase(this.typePackageBase);
/* 334 */     clientGen.setTypeMappingFile(this.typeMappingFile);
/* 335 */     clientGen.setAutotype(this.autotype);
/* 336 */     clientGen.setUseServerTypes(this.useServerTypes);
/* 337 */     clientGen.setSaveWSDL(this.saveWSDL);
/* 338 */     clientGen.setCompiler(this.compiler);
/* 339 */     clientGen.setCompilerClasspath(this.compilerClasspath.toString());
/* 340 */     clientGen.setPortInterfaces(arrayOfString);
/* 341 */     clientGen.setUseLowerCaseMethodNames(this.useLowerCaseMethodNames);
/* 342 */     clientGen.setUsePortNameAsMethodName(this.usePortNameAsMethodName);
/* 343 */     clientGen.setKeepGenerated(this.keepGenerated);
/* 344 */     clientGen.setLogger(new BuildTaskLogger(this));
/* 345 */     clientGen.setGenerateAsyncMethods(this.generateAsyncMethods);
/* 346 */     clientGen.setGeneratePublicFields(this.generatePublicFields);
/* 347 */     clientGen.setOnlyConvenienceMethod(this.onlyConvenienceMethod);
/*     */     
/* 349 */     classLoader = TaskUtils.setClasspath(this.compilerClasspath.toString());
/*     */     try {
/* 351 */       clientGen.run();
/*     */     } finally {
/* 353 */       TaskUtils.setClassLoader(classLoader);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setupCompiler() {
/* 358 */     this.compiler = TaskUtils.getCompiler();
/* 359 */     log("Will use compiler " + this.compiler, 3);
/*     */     
/* 361 */     if (this.compilerClasspath == null) {
/* 362 */       this.compilerClasspath = (Path)Path.systemClasspath.clone();
/*     */     } else {
/* 364 */       this.compilerClasspath.concatSystemClasspath("ignore");
/*     */     } 
/*     */     
/* 367 */     log("Will use compilerClasspath " + this.compilerClasspath, 3);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\clientgen\ClientGenTask.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */