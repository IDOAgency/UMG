/*    */ package weblogic.ant.taskdefs.webservices;
/*    */ 
/*    */ import org.apache.tools.ant.Task;
/*    */ import weblogic.webservice.tools.build.BuildLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuildTaskLogger
/*    */   implements BuildLogger
/*    */ {
/*    */   private Task task;
/*    */   
/* 18 */   public BuildTaskLogger(Task paramTask) { this.task = paramTask; }
/*    */ 
/*    */ 
/*    */   
/* 22 */   public void logError(String paramString) { this.task.log(paramString, 0); }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public void logWarning(String paramString) { this.task.log(paramString, 1); }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public void logInfo(String paramString) { this.task.log(paramString, 2); }
/*    */ 
/*    */ 
/*    */   
/* 34 */   public void logVerbose(String paramString) { this.task.log(paramString, 3); }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public void logDebug(String paramString) { this.task.log(paramString, 4); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\BuildTaskLogger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */