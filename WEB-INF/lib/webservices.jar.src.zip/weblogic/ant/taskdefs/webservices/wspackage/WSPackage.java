/*     */ package weblogic.ant.taskdefs.webservices.wspackage;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.utils.StringUtils;
/*     */ import weblogic.webservice.tools.build.BuildToolsFactory;
/*     */ import weblogic.webservice.tools.build.WSBuildException;
/*     */ import weblogic.webservice.tools.build.WSPackager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSPackage
/*     */   extends Task
/*     */ {
/*     */   protected static boolean DEBUG = false;
/*     */   private static final String LIST_DELIM = ",";
/*     */   private File output;
/*     */   private File ddFile;
/*     */   private File wsdlFile;
/*     */   private File codecDir;
/*     */   private String warName;
/*     */   private String contextURI;
/*     */   private boolean overwrite = true;
/*     */   private Path compileClasspath;
/*     */   private File[] filesToWar;
/*     */   private File[] filesToEar;
/*     */   private File[] utilJars;
/*     */   private String[] webAppClasses;
/*     */   private String[] javaClassNames;
/*     */   
/*  59 */   public void setWarName(String paramString) { this.warName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public void setContextURI(String paramString) { this.contextURI = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilesToEar(String paramString) {
/*  75 */     if (paramString != null) {
/*  76 */       String[] arrayOfString = StringUtils.splitCompletely(paramString, ",");
/*     */       
/*  78 */       this.filesToEar = new File[arrayOfString.length];
/*  79 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*  80 */         arrayOfString[b] = arrayOfString[b].trim();
/*  81 */         this.filesToEar[b] = getProject().resolveFile(arrayOfString[b]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilesToWar(String paramString) {
/*  91 */     if (paramString != null) {
/*  92 */       String[] arrayOfString = StringUtils.splitCompletely(paramString, ",");
/*     */       
/*  94 */       this.filesToWar = new File[arrayOfString.length];
/*  95 */       for (byte b = 0; b < arrayOfString.length; b++) {
/*  96 */         arrayOfString[b] = arrayOfString[b].trim();
/*  97 */         this.filesToWar[b] = getProject().resolveFile(arrayOfString[b]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUtilJars(String paramString) {
/* 106 */     if (paramString != null) {
/* 107 */       String[] arrayOfString = StringUtils.splitCompletely(paramString, ",");
/*     */       
/* 109 */       this.utilJars = new File[arrayOfString.length];
/* 110 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 111 */         arrayOfString[b] = arrayOfString[b].trim();
/* 112 */         this.utilJars[b] = getProject().resolveFile(arrayOfString[b]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public void setDDFile(File paramFile) { this.ddFile = paramFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public void setWsdlFile(File paramFile) { this.wsdlFile = paramFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public void setCodecDir(File paramFile) { this.codecDir = paramFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWebAppClasses(String paramString) {
/* 143 */     if (paramString != null) {
/* 144 */       this.webAppClasses = StringUtils.splitCompletely(paramString, ",");
/* 145 */       for (byte b = 0; b < this.webAppClasses.length; b++) {
/* 146 */         this.webAppClasses[b] = this.webAppClasses[b].trim();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 153 */   public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 157 */   public void setOutput(File paramFile) { this.output = paramFile; }
/*     */ 
/*     */   
/*     */   public void setClasspath(Path paramPath) {
/* 161 */     if (this.compileClasspath == null) {
/* 162 */       this.compileClasspath = paramPath;
/*     */     } else {
/* 164 */       this.compileClasspath.append(paramPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 169 */   public Path getClasspath() { return this.compileClasspath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/* 176 */     if (this.compileClasspath == null) {
/* 177 */       this.compileClasspath = new Path(this.project);
/*     */     }
/* 179 */     return this.compileClasspath.createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
/*     */ 
/*     */   
/*     */   public void execute() throws BuildException {
/* 190 */     validateAttribute();
/*     */     
/* 192 */     TaskUtils.setAntProject(getProject());
/*     */     
/*     */     try {
/* 195 */       doWSPackage();
/* 196 */     } catch (IOException iOException) {
/* 197 */       if (DEBUG) iOException.printStackTrace(System.out); 
/* 198 */       throw new BuildException(iOException);
/* 199 */     } catch (WSBuildException wSBuildException) {
/* 200 */       if (wSBuildException.getNested() != null && 
/* 201 */         DEBUG) wSBuildException.getNested().printStackTrace(System.out);
/*     */       
/* 203 */       throw new BuildException(wSBuildException);
/*     */     } finally {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void validateAttribute() throws BuildException {
/* 209 */     if (this.output == null) {
/* 210 */       throw new BuildException("The output attribute must be set");
/*     */     }
/*     */     
/* 213 */     if (this.ddFile != null) {
/* 214 */       if (!this.ddFile.exists()) {
/* 215 */         throw new BuildException("Web service DDFile doesn't exist.");
/*     */       }
/* 217 */       if (!this.ddFile.isFile()) {
/* 218 */         throw new BuildException("Web service DDFile can't be a directory.");
/*     */       }
/* 220 */     } else if (!this.output.exists()) {
/* 221 */       throw new BuildException("output must exist if DDFile is not specified");
/*     */     } 
/*     */     
/* 224 */     if (this.codecDir != null) {
/* 225 */       if (this.codecDir.exists()) {
/* 226 */         if (this.codecDir.isFile()) {
/* 227 */           throw new BuildException("codecDir can't be a file.");
/*     */         }
/*     */       } else {
/* 230 */         log("codecDir doesn't exist! Ignored", 1);
/* 231 */         this.codecDir = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void doWSPackage() throws BuildException {
/* 238 */     setupClasspath();
/*     */     
/* 240 */     WSPackager wSPackager = BuildToolsFactory.getInstance().getWSPackager();
/* 241 */     wSPackager.setDestDir(this.output);
/* 242 */     wSPackager.setContextURI(this.contextURI);
/* 243 */     wSPackager.setWarName(this.warName);
/* 244 */     wSPackager.setCodecDir(this.codecDir);
/* 245 */     wSPackager.setDDFile(this.ddFile);
/* 246 */     wSPackager.setWsdlFile(this.wsdlFile);
/* 247 */     wSPackager.setWebAppClasses(this.webAppClasses);
/* 248 */     wSPackager.setFilesToWar(this.filesToWar);
/* 249 */     wSPackager.setFilesToEar(this.filesToEar);
/* 250 */     wSPackager.setUtilJars(this.utilJars);
/* 251 */     wSPackager.setLogger(new BuildTaskLogger(this));
/*     */     
/* 253 */     classLoader = TaskUtils.setClasspath(this.compileClasspath.toString());
/*     */     try {
/* 255 */       wSPackager.run();
/*     */     } finally {
/* 257 */       TaskUtils.setClassLoader(classLoader);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setupClasspath() throws BuildException {
/* 262 */     if (this.compileClasspath == null) {
/* 263 */       this.compileClasspath = (Path)Path.systemClasspath.clone();
/*     */     } else {
/* 265 */       this.compileClasspath.concatSystemClasspath("ignore");
/*     */     } 
/*     */     
/* 268 */     log("Will use compilerClasspath " + this.compileClasspath, 3);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wspackage\WSPackage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */