package weblogic.ant.taskdefs.webservices.wspackage;

import java.io.File;
import java.io.IOException;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;
import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.utils.StringUtils;
import weblogic.webservice.tools.build.BuildToolsFactory;
import weblogic.webservice.tools.build.WSBuildException;
import weblogic.webservice.tools.build.WSPackager;

public class WSPackage extends Task {
  protected static boolean DEBUG = false;
  
  private static final String LIST_DELIM = ",";
  
  private File output;
  
  private File ddFile;
  
  private File wsdlFile;
  
  private File codecDir;
  
  private String warName;
  
  private String contextURI;
  
  private boolean overwrite = true;
  
  private Path compileClasspath;
  
  private File[] filesToWar;
  
  private File[] filesToEar;
  
  private File[] utilJars;
  
  private String[] webAppClasses;
  
  private String[] javaClassNames;
  
  public void setWarName(String paramString) { this.warName = paramString; }
  
  public void setContextURI(String paramString) { this.contextURI = paramString; }
  
  public void setFilesToEar(String paramString) {
    if (paramString != null) {
      String[] arrayOfString = StringUtils.splitCompletely(paramString, ",");
      this.filesToEar = new File[arrayOfString.length];
      for (byte b = 0; b < arrayOfString.length; b++) {
        arrayOfString[b] = arrayOfString[b].trim();
        this.filesToEar[b] = getProject().resolveFile(arrayOfString[b]);
      } 
    } 
  }
  
  public void setFilesToWar(String paramString) {
    if (paramString != null) {
      String[] arrayOfString = StringUtils.splitCompletely(paramString, ",");
      this.filesToWar = new File[arrayOfString.length];
      for (byte b = 0; b < arrayOfString.length; b++) {
        arrayOfString[b] = arrayOfString[b].trim();
        this.filesToWar[b] = getProject().resolveFile(arrayOfString[b]);
      } 
    } 
  }
  
  public void setUtilJars(String paramString) {
    if (paramString != null) {
      String[] arrayOfString = StringUtils.splitCompletely(paramString, ",");
      this.utilJars = new File[arrayOfString.length];
      for (byte b = 0; b < arrayOfString.length; b++) {
        arrayOfString[b] = arrayOfString[b].trim();
        this.utilJars[b] = getProject().resolveFile(arrayOfString[b]);
      } 
    } 
  }
  
  public void setDDFile(File paramFile) { this.ddFile = paramFile; }
  
  public void setWsdlFile(File paramFile) { this.wsdlFile = paramFile; }
  
  public void setCodecDir(File paramFile) { this.codecDir = paramFile; }
  
  public void setWebAppClasses(String paramString) {
    if (paramString != null) {
      this.webAppClasses = StringUtils.splitCompletely(paramString, ",");
      for (byte b = 0; b < this.webAppClasses.length; b++)
        this.webAppClasses[b] = this.webAppClasses[b].trim(); 
    } 
  }
  
  public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
  
  public void setOutput(File paramFile) { this.output = paramFile; }
  
  public void setClasspath(Path paramPath) {
    if (this.compileClasspath == null) {
      this.compileClasspath = paramPath;
    } else {
      this.compileClasspath.append(paramPath);
    } 
  }
  
  public Path getClasspath() { return this.compileClasspath; }
  
  public Path createClasspath() {
    if (this.compileClasspath == null)
      this.compileClasspath = new Path(this.project); 
    return this.compileClasspath.createPath();
  }
  
  public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
  
  public void execute() throws BuildException {
    validateAttribute();
    TaskUtils.setAntProject(getProject());
    try {
      doWSPackage();
    } catch (IOException iOException) {
      if (DEBUG)
        iOException.printStackTrace(System.out); 
      throw new BuildException(iOException);
    } catch (WSBuildException wSBuildException) {
      if (wSBuildException.getNested() != null && 
        DEBUG)
        wSBuildException.getNested().printStackTrace(System.out); 
      throw new BuildException(wSBuildException);
    } finally {}
  }
  
  private void validateAttribute() throws BuildException {
    if (this.output == null)
      throw new BuildException("The output attribute must be set"); 
    if (this.ddFile != null) {
      if (!this.ddFile.exists())
        throw new BuildException("Web service DDFile doesn't exist."); 
      if (!this.ddFile.isFile())
        throw new BuildException("Web service DDFile can't be a directory."); 
    } else if (!this.output.exists()) {
      throw new BuildException("output must exist if DDFile is not specified");
    } 
    if (this.codecDir != null)
      if (this.codecDir.exists()) {
        if (this.codecDir.isFile())
          throw new BuildException("codecDir can't be a file."); 
      } else {
        log("codecDir doesn't exist! Ignored", 1);
        this.codecDir = null;
      }  
  }
  
  private void doWSPackage() throws BuildException {
    setupClasspath();
    WSPackager wSPackager = BuildToolsFactory.getInstance().getWSPackager();
    wSPackager.setDestDir(this.output);
    wSPackager.setContextURI(this.contextURI);
    wSPackager.setWarName(this.warName);
    wSPackager.setCodecDir(this.codecDir);
    wSPackager.setDDFile(this.ddFile);
    wSPackager.setWsdlFile(this.wsdlFile);
    wSPackager.setWebAppClasses(this.webAppClasses);
    wSPackager.setFilesToWar(this.filesToWar);
    wSPackager.setFilesToEar(this.filesToEar);
    wSPackager.setUtilJars(this.utilJars);
    wSPackager.setLogger(new BuildTaskLogger(this));
    classLoader = TaskUtils.setClasspath(this.compileClasspath.toString());
    try {
      wSPackager.run();
    } finally {
      TaskUtils.setClassLoader(classLoader);
    } 
  }
  
  private void setupClasspath() throws BuildException {
    if (this.compileClasspath == null) {
      this.compileClasspath = (Path)Path.systemClasspath.clone();
    } else {
      this.compileClasspath.concatSystemClasspath("ignore");
    } 
    log("Will use compilerClasspath " + this.compileClasspath, 3);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wspackage\WSPackage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */