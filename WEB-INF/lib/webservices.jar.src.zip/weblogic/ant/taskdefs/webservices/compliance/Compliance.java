/*     */ package weblogic.ant.taskdefs.webservices.compliance;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.utils.compiler.ToolFailureException;
/*     */ import weblogic.webservice.dd.DDProcessingException;
/*     */ import weblogic.webservice.dd.verify.VerifyException;
/*     */ import weblogic.webservice.tools.cchecker.ComplianceChecker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Compliance
/*     */   extends Task
/*     */ {
/*     */   protected static boolean DEBUG = false;
/*     */   private File ear;
/*     */   private File tmpDir;
/*     */   private boolean stopOnError = false;
/*     */   private boolean verbose = false;
/*     */   private String traceLevel;
/*     */   
/*  43 */   public void setEar(File paramFile) { this.ear = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  47 */   public void setTraceLevel(String paramString) { this.traceLevel = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  51 */   public void setTempDir(File paramFile) { this.tmpDir = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  55 */   public void setVerbose(boolean paramBoolean) { this.verbose = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  59 */   public void setStopOnError(boolean paramBoolean) { this.stopOnError = paramBoolean; }
/*     */ 
/*     */   
/*     */   public void execute() throws BuildException {
/*  63 */     validateAttribute();
/*     */     
/*  65 */     TaskUtils.setAntProject(getProject());
/*     */     
/*     */     try {
/*  68 */       doCompliance();
/*  69 */     } catch (IOException iOException) {
/*  70 */       if (DEBUG) iOException.printStackTrace(System.out); 
/*  71 */       throw new BuildException(iOException);
/*  72 */     } catch (VerifyException verifyException) {
/*  73 */       if (verifyException.getNested() != null && 
/*  74 */         DEBUG) verifyException.getNested().printStackTrace(System.out);
/*     */       
/*  76 */       throw new BuildException(verifyException);
/*  77 */     } catch (ToolFailureException toolFailureException) {
/*  78 */       if (DEBUG) toolFailureException.printStackTrace(System.out); 
/*  79 */       throw new BuildException(toolFailureException);
/*  80 */     } catch (DDProcessingException dDProcessingException) {
/*  81 */       if (DEBUG) dDProcessingException.printStackTrace(System.out); 
/*  82 */       throw new BuildException(dDProcessingException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateAttribute() throws BuildException {
/*  87 */     if (this.ear == null) {
/*  88 */       throw new BuildException("EAR attribute must be set");
/*     */     }
/*     */     
/*  91 */     if (this.tmpDir != null) {
/*  92 */       if (this.tmpDir.exists() && 
/*  93 */         this.tmpDir.isFile()) {
/*  94 */         throw new BuildException("tmpDir can't be a file.");
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/*  99 */       String str = System.getProperty("java.io.tempdir");
/* 100 */       if (str == null) {
/* 101 */         String str1 = System.getProperty("os.name");
/* 102 */         if (str1 != null && str1.toLowerCase().indexOf("windows") > 0) {
/* 103 */           str = "C:\\TMP";
/*     */         } else {
/* 105 */           str = "/tmp";
/*     */         } 
/*     */       } 
/* 108 */       this.tmpDir = new File(str);
/* 109 */       this.tmpDir = new File(this.tmpDir, "_wl_ccheck_tmp");
/* 110 */       this.tmpDir.mkdirs();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void doCompliance() throws BuildException {
/* 117 */     setEar(this.ear);
/* 118 */     if (this.verbose) log("checking:" + this.ear); 
/* 119 */     String[] arrayOfString = new String[1];
/* 120 */     arrayOfString[0] = this.ear.getName();
/* 121 */     ComplianceChecker complianceChecker = new ComplianceChecker(arrayOfString);
/* 122 */     complianceChecker.ccTmpDir = this.tmpDir;
/* 123 */     complianceChecker; ComplianceChecker.verbose = this.verbose;
/* 124 */     complianceChecker; ComplianceChecker.stopOnError = this.stopOnError;
/* 125 */     complianceChecker.checkTraceLevel(this.traceLevel);
/* 126 */     complianceChecker.runAnt(this.ear.getPath());
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\compliance\Compliance.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */