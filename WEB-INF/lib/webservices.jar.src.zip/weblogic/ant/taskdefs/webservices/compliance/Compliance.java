package weblogic.ant.taskdefs.webservices.compliance;

import java.io.File;
import java.io.IOException;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.utils.compiler.ToolFailureException;
import weblogic.webservice.dd.DDProcessingException;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.tools.cchecker.ComplianceChecker;

public class Compliance extends Task {
  protected static boolean DEBUG = false;
  
  private File ear;
  
  private File tmpDir;
  
  private boolean stopOnError = false;
  
  private boolean verbose = false;
  
  private String traceLevel;
  
  public void setEar(File paramFile) { this.ear = paramFile; }
  
  public void setTraceLevel(String paramString) { this.traceLevel = paramString; }
  
  public void setTempDir(File paramFile) { this.tmpDir = paramFile; }
  
  public void setVerbose(boolean paramBoolean) { this.verbose = paramBoolean; }
  
  public void setStopOnError(boolean paramBoolean) { this.stopOnError = paramBoolean; }
  
  public void execute() throws BuildException {
    validateAttribute();
    TaskUtils.setAntProject(getProject());
    try {
      doCompliance();
    } catch (IOException iOException) {
      if (DEBUG)
        iOException.printStackTrace(System.out); 
      throw new BuildException(iOException);
    } catch (VerifyException verifyException) {
      if (verifyException.getNested() != null && 
        DEBUG)
        verifyException.getNested().printStackTrace(System.out); 
      throw new BuildException(verifyException);
    } catch (ToolFailureException toolFailureException) {
      if (DEBUG)
        toolFailureException.printStackTrace(System.out); 
      throw new BuildException(toolFailureException);
    } catch (DDProcessingException dDProcessingException) {
      if (DEBUG)
        dDProcessingException.printStackTrace(System.out); 
      throw new BuildException(dDProcessingException);
    } 
  }
  
  private void validateAttribute() throws BuildException {
    if (this.ear == null)
      throw new BuildException("EAR attribute must be set"); 
    if (this.tmpDir != null) {
      if (this.tmpDir.exists() && 
        this.tmpDir.isFile())
        throw new BuildException("tmpDir can't be a file."); 
    } else {
      String str = System.getProperty("java.io.tempdir");
      if (str == null) {
        String str1 = System.getProperty("os.name");
        if (str1 != null && str1.toLowerCase().indexOf("windows") > 0) {
          str = "C:\\TMP";
        } else {
          str = "/tmp";
        } 
      } 
      this.tmpDir = new File(str);
      this.tmpDir = new File(this.tmpDir, "_wl_ccheck_tmp");
      this.tmpDir.mkdirs();
    } 
  }
  
  private void doCompliance() throws BuildException {
    setEar(this.ear);
    if (this.verbose)
      log("checking:" + this.ear); 
    String[] arrayOfString = new String[1];
    arrayOfString[0] = this.ear.getName();
    ComplianceChecker complianceChecker = new ComplianceChecker(arrayOfString);
    complianceChecker.ccTmpDir = this.tmpDir;
    complianceChecker;
    ComplianceChecker.verbose = this.verbose;
    complianceChecker;
    ComplianceChecker.stopOnError = this.stopOnError;
    complianceChecker.checkTraceLevel(this.traceLevel);
    complianceChecker.runAnt(this.ear.getPath());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\compliance\Compliance.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */