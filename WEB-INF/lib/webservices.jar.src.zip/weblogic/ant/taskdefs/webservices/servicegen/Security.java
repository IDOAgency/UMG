package weblogic.ant.taskdefs.webservices.servicegen;

import org.apache.tools.ant.BuildException;

public class Security {
  private String userName;
  
  private String password;
  
  private String signKeyName;
  
  private String signKeyPass;
  
  private String encryptKeyName;
  
  private String encryptKeyPass;
  
  private boolean enablePasswordAuth = false;
  
  public void setUserName(String paramString) { this.userName = paramString; }
  
  public String getUserName() { return this.userName; }
  
  public void setPassword(String paramString) { this.password = paramString; }
  
  public String getPassword() { return this.password; }
  
  public void setSignKeyName(String paramString) { this.signKeyName = paramString; }
  
  public String getSignKeyName() { return this.signKeyName; }
  
  public void setSignKeyPass(String paramString) { this.signKeyPass = paramString; }
  
  public String getSignKeyPass() { return this.signKeyPass; }
  
  public void setEncryptKeyName(String paramString) { this.encryptKeyName = paramString; }
  
  public String getEncryptKeyName() { return this.encryptKeyName; }
  
  public void setEncryptKeyPass(String paramString) { this.encryptKeyPass = paramString; }
  
  public String getEncryptKeyPass() { return this.encryptKeyPass; }
  
  public void setEnablePasswordAuth(boolean paramBoolean) { this.enablePasswordAuth = paramBoolean; }
  
  public boolean getEnablePasswordAuth() { return this.enablePasswordAuth; }
  
  void validateAttributes() {
    if (this.userName != null && this.password == null) {
      this.password = "";
    } else if (this.userName == null && this.password != null) {
      throw new BuildException("security element: password is specified, but username is not specified.");
    } 
    if (this.signKeyName != null && this.signKeyPass == null) {
      this.signKeyPass = "";
    } else if (this.signKeyName == null && this.signKeyPass != null) {
      throw new BuildException("security element: signKeyPass is specified, but signKeyName is not specified.");
    } 
    if (this.encryptKeyName != null && this.encryptKeyPass == null) {
      this.encryptKeyPass = "";
    } else if (this.encryptKeyName == null && this.encryptKeyPass != null) {
      throw new BuildException("security element: encryptKeyPass is specified, but encryptKeyName is not specified.");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\Security.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */