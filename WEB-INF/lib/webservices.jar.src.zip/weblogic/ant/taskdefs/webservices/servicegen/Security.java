/*    */ package weblogic.ant.taskdefs.webservices.servicegen;
/*    */ 
/*    */ import org.apache.tools.ant.BuildException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Security
/*    */ {
/*    */   private String userName;
/*    */   private String password;
/*    */   private String signKeyName;
/*    */   private String signKeyPass;
/*    */   private String encryptKeyName;
/*    */   private String encryptKeyPass;
/*    */   private boolean enablePasswordAuth = false;
/*    */   
/* 19 */   public void setUserName(String paramString) { this.userName = paramString; }
/*    */ 
/*    */   
/* 22 */   public String getUserName() { return this.userName; }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public void setPassword(String paramString) { this.password = paramString; }
/*    */ 
/*    */   
/* 29 */   public String getPassword() { return this.password; }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public void setSignKeyName(String paramString) { this.signKeyName = paramString; }
/*    */ 
/*    */   
/* 36 */   public String getSignKeyName() { return this.signKeyName; }
/*    */ 
/*    */ 
/*    */   
/* 40 */   public void setSignKeyPass(String paramString) { this.signKeyPass = paramString; }
/*    */ 
/*    */   
/* 43 */   public String getSignKeyPass() { return this.signKeyPass; }
/*    */ 
/*    */ 
/*    */   
/* 47 */   public void setEncryptKeyName(String paramString) { this.encryptKeyName = paramString; }
/*    */ 
/*    */   
/* 50 */   public String getEncryptKeyName() { return this.encryptKeyName; }
/*    */ 
/*    */ 
/*    */   
/* 54 */   public void setEncryptKeyPass(String paramString) { this.encryptKeyPass = paramString; }
/*    */ 
/*    */   
/* 57 */   public String getEncryptKeyPass() { return this.encryptKeyPass; }
/*    */ 
/*    */ 
/*    */   
/* 61 */   public void setEnablePasswordAuth(boolean paramBoolean) { this.enablePasswordAuth = paramBoolean; }
/*    */ 
/*    */   
/* 64 */   public boolean getEnablePasswordAuth() { return this.enablePasswordAuth; }
/*    */ 
/*    */   
/*    */   void validateAttributes() {
/* 68 */     if (this.userName != null && this.password == null) {
/* 69 */       this.password = "";
/* 70 */     } else if (this.userName == null && this.password != null) {
/* 71 */       throw new BuildException("security element: password is specified, but username is not specified.");
/*    */     } 
/*    */ 
/*    */     
/* 75 */     if (this.signKeyName != null && this.signKeyPass == null) {
/* 76 */       this.signKeyPass = "";
/* 77 */     } else if (this.signKeyName == null && this.signKeyPass != null) {
/* 78 */       throw new BuildException("security element: signKeyPass is specified, but signKeyName is not specified.");
/*    */     } 
/*    */ 
/*    */     
/* 82 */     if (this.encryptKeyName != null && this.encryptKeyPass == null) {
/* 83 */       this.encryptKeyPass = "";
/* 84 */     } else if (this.encryptKeyName == null && this.encryptKeyPass != null) {
/* 85 */       throw new BuildException("security element: encryptKeyPass is specified, but encryptKeyName is not specified.");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\Security.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */