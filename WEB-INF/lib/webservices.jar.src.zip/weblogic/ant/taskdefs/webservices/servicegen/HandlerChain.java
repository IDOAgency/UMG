package weblogic.ant.taskdefs.webservices.servicegen;

import org.apache.tools.ant.BuildException;
import weblogic.utils.StringUtils;

public class HandlerChain {
  private static final String LIST_DELIM = ",";
  
  private String[] handlers;
  
  private String name;
  
  private Service service;
  
  public HandlerChain(Service paramService) { this.service = paramService; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setHandlers(String paramString) {
    this.handlers = StringUtils.splitCompletely(paramString, ",");
    for (byte b = 0; b < this.handlers.length; b++)
      this.handlers[b] = this.handlers[b].trim(); 
  }
  
  public String[] getHandlers() { return this.handlers; }
  
  void validateAttributes() {
    if (this.handlers == null)
      throw new BuildException("handlers attribute of the handlerChain elemenent is required"); 
    if (this.name == null)
      this.name = this.service.getServiceName() + "HandlerChain"; 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\HandlerChain.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */