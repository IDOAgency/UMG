/*    */ package weblogic.ant.taskdefs.webservices.servicegen;
/*    */ 
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import weblogic.utils.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HandlerChain
/*    */ {
/*    */   private static final String LIST_DELIM = ",";
/*    */   private String[] handlers;
/*    */   private String name;
/*    */   private Service service;
/*    */   
/* 19 */   public HandlerChain(Service paramService) { this.service = paramService; }
/*    */ 
/*    */ 
/*    */   
/* 23 */   public void setName(String paramString) { this.name = paramString; }
/*    */ 
/*    */   
/* 26 */   public String getName() { return this.name; }
/*    */ 
/*    */   
/*    */   public void setHandlers(String paramString) {
/* 30 */     this.handlers = StringUtils.splitCompletely(paramString, ",");
/* 31 */     for (byte b = 0; b < this.handlers.length; b++) {
/* 32 */       this.handlers[b] = this.handlers[b].trim();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 37 */   public String[] getHandlers() { return this.handlers; }
/*    */ 
/*    */   
/*    */   void validateAttributes() {
/* 41 */     if (this.handlers == null) {
/* 42 */       throw new BuildException("handlers attribute of the handlerChain elemenent is required");
/*    */     }
/*    */ 
/*    */     
/* 46 */     if (this.name == null)
/* 47 */       this.name = this.service.getServiceName() + "HandlerChain"; 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\HandlerChain.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */