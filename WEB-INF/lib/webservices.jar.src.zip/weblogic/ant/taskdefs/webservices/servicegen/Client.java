package weblogic.ant.taskdefs.webservices.servicegen;

import java.io.File;
import org.apache.tools.ant.BuildException;
import weblogic.ant.taskdefs.webservices.TaskUtils;

public class Client {
  private String packageName;
  
  private String clientJar;
  
  private String defaultEndpoint;
  
  private boolean useservertypes;
  
  private boolean saveWSDL;
  
  private File typeMappingFile;
  
  private Service service;
  
  public Client(Service paramService) {
    this.saveWSDL = true;
    this.service = paramService;
  }
  
  public void setPackageName(String paramString) { this.packageName = paramString; }
  
  public String getPackageName() { return this.packageName; }
  
  public void setClientjarname(String paramString) { this.clientJar = paramString; }
  
  public String getClientjarname() { return this.clientJar; }
  
  public void setDefaultendpoint(String paramString) { this.defaultEndpoint = paramString; }
  
  public String getDefaultendpoint() { return this.defaultEndpoint; }
  
  public void setUseServerTypes(boolean paramBoolean) { this.useservertypes = paramBoolean; }
  
  public boolean getUseServerTypes() { return this.useservertypes; }
  
  public void setSavewsdl(boolean paramBoolean) { this.saveWSDL = paramBoolean; }
  
  public boolean getSavewsdl() { return this.saveWSDL; }
  
  public void setTypeMappingFile(File paramFile) { this.typeMappingFile = paramFile; }
  
  public File getTypeMappingFile() { return this.typeMappingFile; }
  
  public void validateAttributes() {
    if (this.packageName == null)
      throw new BuildException("The PackageName attribute must be specified in the <client> element."); 
    this.packageName = this.packageName.trim();
    if (this.packageName.length() == 0)
      throw new BuildException("Invalid PackageName attribute specified in the <client> element."); 
    if (this.clientJar == null)
      this.clientJar = this.service.getServiceName() + "_client.jar"; 
    if (!TaskUtils.isFileName(this.clientJar))
      throw new BuildException("The clientJarName attribute must be the name of a jar, not a pathname. To generate a client jar outside the web service EAR, use the <clientgen> task."); 
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<client>:\n");
    stringBuffer.append("packageName = " + this.packageName + "\n");
    stringBuffer.append("clientJarName = " + this.clientJar + "\n");
    stringBuffer.append("defaultEndpoint = " + this.defaultEndpoint + "\n");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\Client.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */