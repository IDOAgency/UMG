/*    */ package weblogic.ant.taskdefs.webservices.servicegen;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*    */ 
/*    */ public class Client
/*    */ {
/*    */   private String packageName;
/*    */   private String clientJar;
/*    */   private String defaultEndpoint;
/*    */   private boolean useservertypes;
/*    */   private boolean saveWSDL;
/*    */   private File typeMappingFile;
/*    */   private Service service;
/*    */   
/*    */   public Client(Service paramService) {
/* 18 */     this.saveWSDL = true;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 23 */     this.service = paramService;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 28 */   public void setPackageName(String paramString) { this.packageName = paramString; }
/* 29 */   public String getPackageName() { return this.packageName; }
/*    */   
/* 31 */   public void setClientjarname(String paramString) { this.clientJar = paramString; }
/* 32 */   public String getClientjarname() { return this.clientJar; }
/*    */   
/* 34 */   public void setDefaultendpoint(String paramString) { this.defaultEndpoint = paramString; }
/* 35 */   public String getDefaultendpoint() { return this.defaultEndpoint; }
/*    */   
/* 37 */   public void setUseServerTypes(boolean paramBoolean) { this.useservertypes = paramBoolean; }
/* 38 */   public boolean getUseServerTypes() { return this.useservertypes; }
/*    */   
/* 40 */   public void setSavewsdl(boolean paramBoolean) { this.saveWSDL = paramBoolean; }
/* 41 */   public boolean getSavewsdl() { return this.saveWSDL; }
/*    */   
/* 43 */   public void setTypeMappingFile(File paramFile) { this.typeMappingFile = paramFile; }
/* 44 */   public File getTypeMappingFile() { return this.typeMappingFile; }
/*    */   
/*    */   public void validateAttributes() {
/* 47 */     if (this.packageName == null) {
/* 48 */       throw new BuildException("The PackageName attribute must be specified in the <client> element.");
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 53 */     this.packageName = this.packageName.trim();
/*    */     
/* 55 */     if (this.packageName.length() == 0) {
/* 56 */       throw new BuildException("Invalid PackageName attribute specified in the <client> element.");
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 61 */     if (this.clientJar == null) {
/* 62 */       this.clientJar = this.service.getServiceName() + "_client.jar";
/*    */     }
/*    */     
/* 65 */     if (!TaskUtils.isFileName(this.clientJar)) {
/* 66 */       throw new BuildException("The clientJarName attribute must be the name of a jar, not a pathname. To generate a client jar outside the web service EAR, use the <clientgen> task.");
/*    */     }
/*    */   }
/*    */   
/*    */   public String toString() {
/* 71 */     StringBuffer stringBuffer = new StringBuffer();
/* 72 */     stringBuffer.append("<client>:\n");
/* 73 */     stringBuffer.append("packageName = " + this.packageName + "\n");
/* 74 */     stringBuffer.append("clientJarName = " + this.clientJar + "\n");
/* 75 */     stringBuffer.append("defaultEndpoint = " + this.defaultEndpoint + "\n");
/* 76 */     return stringBuffer.toString();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\Client.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */