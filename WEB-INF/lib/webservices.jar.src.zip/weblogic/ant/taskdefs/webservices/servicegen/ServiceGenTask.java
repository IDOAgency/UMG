/*     */ package weblogic.ant.taskdefs.webservices.servicegen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.ant.taskdefs.webservices.autotype.AutoTyper;
/*     */ import weblogic.ant.taskdefs.webservices.autotype.ComponentAutoTyper;
/*     */ import weblogic.ant.taskdefs.webservices.autotype.EJBAutoTyper;
/*     */ import weblogic.ant.taskdefs.webservices.autotype.JMSAutoTyper;
/*     */ import weblogic.ant.taskdefs.webservices.autotype.JavaAutoTyper;
/*     */ import weblogic.management.descriptors.webservice.HandlerChainMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.HandlerChainsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.HandlerMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.OperationMBean;
/*     */ import weblogic.management.descriptors.webservice.ParamMBean;
/*     */ import weblogic.management.descriptors.webservice.ReliableDeliveryMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
/*     */ import weblogic.utils.FileUtils;
/*     */ import weblogic.webservice.dd.DDMerger;
/*     */ import weblogic.webservice.dd.DDProcessingException;
/*     */ import weblogic.webservice.tools.build.BuildToolsFactory;
/*     */ import weblogic.webservice.tools.build.ClientGen;
/*     */ import weblogic.webservice.tools.build.WSBuildException;
/*     */ import weblogic.webservice.util.WebServiceEarFile;
/*     */ import weblogic.webservice.util.WebServiceJarException;
/*     */ import weblogic.webservice.util.WebServiceWarFile;
/*     */ import weblogic.xml.schema.model.XSDException;
/*     */ import weblogic.xml.schema.model.util.MergeSchemas;
/*     */ import weblogic.xml.security.specs.EncryptionKey;
/*     */ import weblogic.xml.security.specs.SecurityDD;
/*     */ import weblogic.xml.security.specs.SignatureKey;
/*     */ import weblogic.xml.security.specs.User;
/*     */ import weblogic.xml.stream.XMLInputOutputStream;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ import weblogic.xml.xmlnode.XMLNodeOutputStream;
/*     */ import weblogic.xml.xmlnode.XMLNodeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceGenTask
/*     */   extends Task
/*     */ {
/*  78 */   private List services = new ArrayList();
/*     */   private File destEar;
/*  80 */   private String warName = "web-services.war";
/*  81 */   private String contextURI = null;
/*     */   
/*     */   private boolean overwrite = true;
/*     */   private boolean mergeWithExistingWS = false;
/*     */   private boolean keepGenerated = false;
/*  86 */   private String tmpDir = ".";
/*  87 */   private Set clientJarNames = new HashSet();
/*  88 */   private Set ejbJarNames = new HashSet();
/*     */   private Path compilerClasspath;
/*     */   
/*     */   public ServiceGenTask() {
/*  92 */     String str = System.getProperty("java.io.tmpdir");
/*  93 */     if (str != null) this.tmpDir = str;
/*     */   
/*     */   }
/*     */   
/*  97 */   public void setDestear(File paramFile) { this.destEar = paramFile; }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void setMergeWithExistingWS(boolean paramBoolean) { this.mergeWithExistingWS = paramBoolean; }
/*     */ 
/*     */   
/* 112 */   public String getWarName() { return this.warName; }
/* 113 */   public void setWarName(String paramString) { this.warName = paramString; }
/*     */   
/* 115 */   public String getContextURI() { return this.contextURI; }
/* 116 */   public void setContextURI(String paramString) { this.contextURI = paramString; }
/*     */   
/*     */   public Service createService() {
/* 119 */     Service service = new Service();
/* 120 */     this.services.add(service);
/* 121 */     return service;
/*     */   }
/*     */   
/*     */   public void setClasspath(Path paramPath) {
/* 125 */     if (this.compilerClasspath == null) {
/* 126 */       this.compilerClasspath = paramPath;
/*     */     } else {
/* 128 */       this.compilerClasspath.append(paramPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 133 */   public Path getClasspath() { return this.compilerClasspath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/* 140 */     if (this.compilerClasspath == null) {
/* 141 */       this.compilerClasspath = new Path(this.project);
/*     */     }
/* 143 */     return this.compilerClasspath.createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
/*     */ 
/*     */   
/*     */   public void execute() {
/* 154 */     validateAttributes();
/*     */     
/* 156 */     TaskUtils.setAntProject(getProject());
/*     */     
/* 158 */     if (!this.overwrite && !needToRun())
/*     */       return; 
/* 160 */     webServiceEarFile = null;
/*     */ 
/*     */     
/*     */     try {
/* 164 */       if (!this.destEar.getPath().endsWith(".ear") && !this.destEar.exists()) {
/* 165 */         this.destEar.mkdirs();
/*     */       }
/*     */       
/* 168 */       webServiceEarFile = new WebServiceEarFile(new File(this.tmpDir), this.destEar, this.warName);
/* 169 */       webServiceEarFile.setContextURI(this.contextURI);
/*     */       
/* 171 */       setupClasspath();
/*     */       
/* 173 */       hashSet = new HashSet();
/* 174 */       for (Service service : this.services) {
/*     */ 
/*     */ 
/*     */         
/* 178 */         File file = service.getEjbJar();
/* 179 */         if (file != null) hashSet.add(file);
/*     */         
/* 181 */         generateService(webServiceEarFile, service);
/*     */         
/* 183 */         this.mergeWithExistingWS = true;
/*     */       } 
/*     */ 
/*     */       
/* 187 */       copyEjbJars(webServiceEarFile, hashSet);
/*     */ 
/*     */       
/* 190 */       webServiceEarFile.createAppDescriptor(hashSet);
/*     */ 
/*     */       
/* 193 */       for (Service service : this.services)
/*     */       {
/* 195 */         generateClient(webServiceEarFile, service);
/*     */       }
/*     */ 
/*     */       
/* 199 */       mergeClients(webServiceEarFile);
/*     */ 
/*     */ 
/*     */       
/* 203 */       this.mergeWithExistingWS = false;
/*     */ 
/*     */       
/* 206 */       webServiceEarFile.save();
/*     */     }
/* 208 */     catch (WSBuildException wSBuildException) {
/* 209 */       if (wSBuildException.getNested() != null) {
/* 210 */         wSBuildException.getNested().printStackTrace();
/*     */       }
/* 212 */       throw new BuildException(wSBuildException);
/* 213 */     } catch (BuildException buildException) {
/* 214 */       buildException.printStackTrace();
/* 215 */       throw buildException;
/* 216 */     } catch (Exception exception) {
/* 217 */       exception.printStackTrace();
/* 218 */       throw new BuildException(exception);
/*     */     } finally {
/*     */       try {
/* 221 */         if (webServiceEarFile != null) webServiceEarFile.remove(); 
/* 222 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   public void validateAttributes() {
/* 227 */     if (this.services.size() == 0) {
/* 228 */       throw new BuildException("At least one <service> subelement must be specified in <servicegen>");
/*     */     }
/*     */ 
/*     */     
/* 232 */     if (this.destEar == null) {
/* 233 */       throw new BuildException("The destEar attribute must be specified in <servicegen>");
/*     */     }
/* 235 */     if (this.contextURI == null) {
/* 236 */       if (this.warName.endsWith(".war")) {
/* 237 */         this.contextURI = this.warName.substring(0, this.warName.length() - 4);
/*     */       } else {
/* 239 */         this.contextURI = this.warName;
/*     */       } 
/*     */     }
/*     */     
/* 243 */     HashMap hashMap = new HashMap();
/* 244 */     for (Service service : this.services) {
/*     */       
/* 246 */       String str1 = service.getServiceName();
/* 247 */       String str2 = service.getServiceURI();
/* 248 */       if (hashMap.get(str2) != null && !str1.equals(hashMap.get(str2)))
/*     */       {
/*     */         
/* 251 */         throw new BuildException("The same service URI \"" + str2 + "\" cannot be used for more than one service in an application");
/*     */       }
/* 253 */       hashMap.put(str2, str1);
/* 254 */       service.validateAttributes();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean needToRun() {
/* 259 */     if (this.destEar.isDirectory()) return true;
/*     */     
/* 261 */     long l = this.destEar.lastModified();
/*     */     
/* 263 */     if (l == 0L) return true;
/*     */     
/* 265 */     for (Service service : this.services) {
/*     */ 
/*     */       
/* 268 */       if (service.needToRun(l)) return true;
/*     */     
/*     */     } 
/* 271 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 275 */     StringBuffer stringBuffer = new StringBuffer();
/* 276 */     stringBuffer.append("<servicegen>:\n");
/* 277 */     stringBuffer.append("destEar = " + this.destEar + "\n");
/* 278 */     stringBuffer.append("warName = " + this.warName + "\n");
/* 279 */     for (Iterator iterator = this.services.iterator(); iterator.hasNext();) {
/* 280 */       stringBuffer.append(((Service)iterator.next()).toString());
/*     */     }
/* 282 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateService(WebServiceEarFile paramWebServiceEarFile, Service paramService) throws IOException {
/* 289 */     log("Generating service \"" + paramService.getServiceName() + "\" ...");
/* 290 */     webServiceWarFile = null;
/* 291 */     File file1 = paramWebServiceEarFile.getWSWarFile();
/* 292 */     File file2 = paramService.getEjbJar();
/*     */     
/* 294 */     if (!file1.exists() && !file1.getPath().endsWith(".war")) {
/* 295 */       file1.mkdirs();
/*     */     }
/*     */     
/* 298 */     webServiceWarFile = new WebServiceWarFile(new File(this.tmpDir), file1, paramWebServiceEarFile);
/*     */     
/* 300 */     File file3 = webServiceWarFile.getClassesDir();
/*     */     
/* 302 */     String str = this.compilerClasspath.toString() + File.pathSeparator + file3.getCanonicalPath();
/*     */ 
/*     */     
/* 305 */     if (file2 != null) {
/* 306 */       str = str + File.pathSeparator + file2.getCanonicalPath();
/*     */     }
/* 308 */     log("using classpath " + str, 3);
/*     */     
/* 310 */     classLoader = TaskUtils.setClasspath(str);
/*     */     
/*     */     try {
/* 313 */       autoTyper = runAutoTyper(file3, str, paramService);
/* 314 */       WebServiceMBean webServiceMBean = createDD(autoTyper, webServiceWarFile, paramService);
/* 315 */       HashSet hashSet = autoTyper.getExtraClasses();
/* 316 */       if (paramService.getHandlerChain() != null) {
/* 317 */         hashSet.addAll(Arrays.asList((Object[])paramService.getHandlerChain().getHandlers()));
/*     */       }
/*     */       
/* 320 */       saveExtraClasses(hashSet, file3);
/*     */       
/* 322 */       TaskUtils.copyClasses(paramService.getJavaclassComponents(), webServiceMBean.getTypeMapping(), file3);
/*     */ 
/*     */       
/* 325 */       webServiceWarFile.save();
/*     */     } finally {
/* 327 */       TaskUtils.setClassLoader(classLoader);
/*     */       
/* 329 */       if (webServiceWarFile != null) {
/* 330 */         try { webServiceWarFile.remove(); } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private AutoTyper runAutoTyper(File paramFile, String paramString, Service paramService) {
/* 336 */     JMSAutoTyper jMSAutoTyper = null;
/*     */     try {
/* 338 */       if (paramService.getEjbJar() != null) {
/* 339 */         jMSAutoTyper = new EJBAutoTyper(paramService.getEjbJar(), paramService.getServiceName(), paramFile, paramService.getIncludeEjbs(), paramService.getExcludeEjbs(), this);
/*     */         
/* 341 */         ((ComponentAutoTyper)jMSAutoTyper).setProtocol(paramService.getProtocol());
/* 342 */       } else if (paramService.getJavaclassComponents() != null) {
/* 343 */         jMSAutoTyper = new JavaAutoTyper(paramService.getJavaclassComponents(), paramService.getServiceName(), paramFile, this);
/*     */         
/* 345 */         ((ComponentAutoTyper)jMSAutoTyper).setProtocol(paramService.getProtocol());
/*     */       } else {
/* 347 */         JMSAutoTyper jMSAutoTyper1 = new JMSAutoTyper(paramFile, paramService.getServiceName(), this);
/* 348 */         jMSAutoTyper1.setJMSDestination(paramService.getJMSDestination());
/* 349 */         jMSAutoTyper1.setJMSDestinationType(paramService.getJMSDestinationType());
/* 350 */         jMSAutoTyper1.setJMSAction(paramService.getJMSAction());
/* 351 */         jMSAutoTyper1.setJMSConnectionFactory(paramService.getJMSConnectionFactory());
/* 352 */         jMSAutoTyper1.setJMSMessageType(paramService.getJMSMessageType());
/* 353 */         jMSAutoTyper1.setJMSOperationName(paramService.getJMSOperationName());
/* 354 */         jMSAutoTyper1.setProtocol(paramService.getProtocol());
/* 355 */         jMSAutoTyper = jMSAutoTyper1;
/*     */       } 
/*     */       
/* 358 */       jMSAutoTyper.setKeepGenerated(this.keepGenerated);
/* 359 */       jMSAutoTyper.setExpandMethods(paramService.getExpandMethods());
/* 360 */       jMSAutoTyper.setGenerateTypes(paramService.getGenerateTypes());
/* 361 */       jMSAutoTyper.setCompilerClasspath(paramString);
/* 362 */       jMSAutoTyper.setStyle(paramService.getStyle());
/* 363 */       jMSAutoTyper.setServiceURI(paramService.getServiceURI());
/* 364 */       jMSAutoTyper.setTargetNSURI(paramService.getTargetNamespace());
/* 365 */       jMSAutoTyper.setUseSoap12(paramService.getUseSoap12());
/* 366 */       jMSAutoTyper.setTypeMappingFile(paramService.getTypeMappingFile());
/* 367 */       jMSAutoTyper.run();
/* 368 */     } catch (IOException iOException) {
/* 369 */       throw new BuildException("Failed to do typemapping.", iOException);
/*     */     } 
/* 371 */     return jMSAutoTyper;
/*     */   }
/*     */ 
/*     */   
/*     */   private WebServiceMBean createDD(AutoTyper paramAutoTyper, WebServiceWarFile paramWebServiceWarFile, Service paramService) {
/*     */     try {
/* 377 */       log("Creating web service DD mbeans ...", 3);
/* 378 */       WebServiceMBean webServiceMBean = paramAutoTyper.getWebServiceDescriptor();
/* 379 */       if (paramService.getIgnoreAuthHeader())
/* 380 */         webServiceMBean.setIgnoreAuthHeader(true); 
/* 381 */       addSecurity(webServiceMBean, paramService);
/* 382 */       addReliabilityAndHandlerChainName(webServiceMBean, paramService);
/* 383 */       addExistingSchemas(webServiceMBean, paramService);
/*     */       
/* 385 */       WebServicesMBeanImpl webServicesMBeanImpl = paramWebServiceWarFile.getWSDD();
/*     */       
/* 387 */       log(((WebServiceMBeanImpl)webServiceMBean).toXML(0), 4);
/*     */       
/* 389 */       if (this.mergeWithExistingWS && webServicesMBeanImpl != null) {
/* 390 */         log("Merging service description into existing web service deployment descriptor ...", 3);
/*     */         
/* 392 */         webServicesMBeanImpl = DDMerger.mergeWebServices(webServicesMBeanImpl, new WebServiceMBean[] { webServiceMBean });
/*     */       } else {
/* 394 */         webServicesMBeanImpl = new WebServicesMBeanImpl();
/* 395 */         webServicesMBeanImpl.setWebServices(new WebServiceMBean[] { webServiceMBean });
/*     */       } 
/*     */       
/* 398 */       addHandlerChain(webServicesMBeanImpl, paramService);
/* 399 */       paramWebServiceWarFile.writeDD(webServicesMBeanImpl);
/*     */       
/* 401 */       return webServiceMBean;
/* 402 */     } catch (DDProcessingException dDProcessingException) {
/* 403 */       throw new BuildException(dDProcessingException);
/* 404 */     } catch (WebServiceJarException webServiceJarException) {
/* 405 */       throw new BuildException(webServiceJarException);
/* 406 */     } catch (IOException iOException) {
/* 407 */       throw new BuildException(iOException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addSecurity(WebServiceMBean paramWebServiceMBean, Service paramService) {
/* 412 */     Security security = paramService.getSecurity();
/* 413 */     if (security == null)
/*     */       return; 
/* 415 */     SecurityDD securityDD = SecurityDD.getDefaultSecurityDD();
/* 416 */     securityDD.getSpec().setEnablePasswordAuth(security.getEnablePasswordAuth());
/*     */     
/* 418 */     if (security.getUserName() != null && security.getPassword() != null) {
/* 419 */       securityDD.setUser(new User(security.getUserName(), security.getPassword()));
/* 420 */       securityDD.getSpec().setEnablePasswordAuth(true);
/*     */     } 
/*     */     
/* 423 */     if (security.getEncryptKeyName() != null && security.getEncryptKeyPass() != null) {
/* 424 */       securityDD.setEncryptionKey(new EncryptionKey(security.getEncryptKeyName(), security.getEncryptKeyPass()));
/*     */     }
/*     */     else {
/*     */       
/* 428 */       securityDD.getSpec().setEncryptionSpec(null);
/*     */     } 
/*     */     
/* 431 */     if (security.getSignKeyName() != null && security.getSignKeyPass() != null) {
/* 432 */       securityDD.setSigningKey(new SignatureKey(security.getSignKeyName(), security.getSignKeyPass()));
/*     */     }
/*     */ 
/*     */     
/* 436 */     XMLOutputStreamFactory xMLOutputStreamFactory = XMLOutputStreamFactory.newInstance();
/*     */     
/*     */     try {
/* 439 */       XMLInputOutputStream xMLInputOutputStream = xMLOutputStreamFactory.newInputOutputStream();
/*     */       
/* 441 */       securityDD.toXML(xMLInputOutputStream);
/*     */       
/* 443 */       xMLInputOutputStream.flush();
/*     */       
/* 445 */       XMLNode xMLNode = new XMLNode();
/* 446 */       xMLNode.read(xMLInputOutputStream);
/* 447 */       paramWebServiceMBean.setSecurity(xMLNode);
/* 448 */     } catch (XMLStreamException xMLStreamException) {
/* 449 */       throw new BuildException("Failed to create security element.", xMLStreamException);
/* 450 */     } catch (IOException iOException) {
/* 451 */       throw new BuildException("Failed to create security element.", iOException);
/*     */     } 
/*     */     
/* 454 */     OperationMBean[] arrayOfOperationMBean = paramWebServiceMBean.getOperations().getOperations();
/* 455 */     for (byte b = 0; b < arrayOfOperationMBean.length; b++) {
/* 456 */       arrayOfOperationMBean[b].setInSecuritySpec(securityDD.getSpec().getId());
/* 457 */       arrayOfOperationMBean[b].setOutSecuritySpec(securityDD.getSpec().getId());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addReliabilityAndHandlerChainName(WebServiceMBean paramWebServiceMBean, Service paramService) {
/* 462 */     Reliability reliability = paramService.getReliability();
/* 463 */     HandlerChain handlerChain = paramService.getHandlerChain();
/* 464 */     if (reliability == null && handlerChain == null)
/*     */       return; 
/* 466 */     OperationMBean[] arrayOfOperationMBean = paramWebServiceMBean.getOperations().getOperations();
/* 467 */     for (byte b = 0; b < arrayOfOperationMBean.length; b++) {
/* 468 */       if (handlerChain != null) {
/* 469 */         arrayOfOperationMBean[b].setHandlerChainName(handlerChain.getName());
/*     */       }
/*     */       
/* 472 */       if (reliability != null)
/*     */       {
/* 474 */         if (hasOutParam(arrayOfOperationMBean[b])) {
/* 475 */           log("Operation \"" + arrayOfOperationMBean[b].getOperationName() + "\"" + " has return/inout/out type parameters. It is ignored for" + " reliable delivery.", 1);
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 481 */           ReliableDeliveryMBeanImpl reliableDeliveryMBeanImpl = new ReliableDeliveryMBeanImpl();
/* 482 */           if (reliability.getDuplicateElimination() != null) {
/* 483 */             reliableDeliveryMBeanImpl.setDuplicateElimination(reliability.getDuplicateElimination().booleanValue());
/*     */           }
/* 485 */           if (reliability.getPersistDuration() != null) {
/* 486 */             reliableDeliveryMBeanImpl.setPersistDuration(reliability.getPersistDuration().intValue());
/*     */           }
/*     */           
/* 489 */           arrayOfOperationMBean[b].setReliableDelivery(reliableDeliveryMBeanImpl);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addExistingSchemas(WebServiceMBean paramWebServiceMBean, Service paramService) {
/* 496 */     File file = paramService.getTypeMappingFile();
/*     */     
/* 498 */     if (file == null)
/*     */       return; 
/* 500 */     log("Reading init type mapping schemas...", 3);
/*     */     
/* 502 */     xMLInputStream = null;
/*     */     try {
/* 504 */       xMLInputStreamFactory = XMLInputStreamFactory.newInstance();
/* 505 */       xMLInputStream = xMLInputStreamFactory.newInputStream(file);
/*     */       
/* 507 */       XMLInputStream xMLInputStream1 = null;
/* 508 */       if (paramWebServiceMBean.getTypes() != null) {
/* 509 */         xMLInputStream1 = paramWebServiceMBean.getTypes().stream();
/*     */       } else {
/* 511 */         xMLInputStream1 = (new XMLNode()).stream();
/*     */       } 
/*     */       
/* 514 */       XMLNode xMLNode = new XMLNode();
/* 515 */       XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream(xMLNode);
/* 516 */       MergeSchemas.merge(xMLNodeOutputStream, new XMLInputStream[] { xMLInputStream1, xMLInputStream });
/* 517 */       xMLNodeOutputStream.flush();
/*     */       
/* 519 */       XMLNodeSet xMLNodeSet = new XMLNodeSet();
/*     */       
/* 521 */       for (Iterator iterator = xMLNode.getChildren(); iterator.hasNext();) {
/* 522 */         xMLNodeSet.addXMLNode((XMLNode)iterator.next());
/*     */       }
/*     */       
/* 525 */       paramWebServiceMBean.setTypes(xMLNodeSet);
/* 526 */     } catch (XMLStreamException xMLStreamException) {
/* 527 */       throw new BuildException("Failed to read schemas in typemapping file", xMLStreamException);
/* 528 */     } catch (XSDException xSDException) {
/* 529 */       throw new BuildException("Failed to read schemas in typemapping file", xSDException);
/*     */     } finally {
/* 531 */       if (xMLInputStream != null) {
/* 532 */         try { xMLInputStream.close(); } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addHandlerChain(WebServicesMBean paramWebServicesMBean, Service paramService) {
/* 538 */     HandlerChain handlerChain = paramService.getHandlerChain();
/* 539 */     if (handlerChain == null)
/*     */       return; 
/* 541 */     HandlerChainMBeanImpl handlerChainMBeanImpl = new HandlerChainMBeanImpl();
/* 542 */     handlerChainMBeanImpl.setHandlerChainName(handlerChain.getName());
/*     */     
/* 544 */     String[] arrayOfString = handlerChain.getHandlers();
/* 545 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 546 */       HandlerMBeanImpl handlerMBeanImpl = new HandlerMBeanImpl();
/* 547 */       handlerMBeanImpl.setClassName(arrayOfString[b]);
/* 548 */       handlerChainMBeanImpl.addHandler(handlerMBeanImpl);
/*     */     } 
/*     */     
/* 551 */     HandlerChainsMBeanImpl handlerChainsMBeanImpl = paramWebServicesMBean.getHandlerChains();
/* 552 */     if (handlerChainsMBeanImpl == null) {
/* 553 */       handlerChainsMBeanImpl = new HandlerChainsMBeanImpl();
/*     */     }
/*     */     
/* 556 */     handlerChainsMBeanImpl.addHandlerChain(handlerChainMBeanImpl);
/* 557 */     paramWebServicesMBean.setHandlerChains(handlerChainsMBeanImpl);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateClient(WebServiceEarFile paramWebServiceEarFile, Service paramService) throws IOException {
/* 563 */     Client client = paramService.getClient();
/* 564 */     if (client != null) {
/* 565 */       log("Generating client for " + paramService.getServiceName(), 3);
/* 566 */       BuildToolsFactory buildToolsFactory = BuildToolsFactory.getInstance();
/* 567 */       ClientGen clientGen = buildToolsFactory.getClientGen();
/* 568 */       clientGen.setEarFile(paramWebServiceEarFile.getExploded());
/* 569 */       clientGen.setWarName(paramWebServiceEarFile.getWSWarFile().getName());
/* 570 */       File file = new File(paramWebServiceEarFile.getExploded(), client.getClientjarname());
/* 571 */       clientGen.setClientJar(file);
/* 572 */       clientGen.setServiceName(paramService.getServiceName());
/* 573 */       clientGen.setClientPackageName(client.getPackageName());
/* 574 */       if (client.getTypeMappingFile() != null) {
/* 575 */         clientGen.setTypeMappingFile(client.getTypeMappingFile());
/* 576 */       } else if (paramService.getTypeMappingFile() != null) {
/* 577 */         clientGen.setTypeMappingFile(paramService.getTypeMappingFile());
/*     */       } 
/* 579 */       clientGen.setUseServerTypes(client.getUseServerTypes());
/* 580 */       clientGen.setAutotype(paramService.getGenerateTypes());
/* 581 */       clientGen.setSaveWSDL(client.getSavewsdl());
/* 582 */       if (paramService.getUseSoap12()) {
/*     */ 
/*     */         
/* 585 */         clientGen.setUsePortNameAsMethodName(true);
/*     */       } else {
/* 587 */         clientGen.setUsePortNameAsMethodName(false);
/*     */       } 
/* 589 */       clientGen.setCompiler(TaskUtils.getCompiler());
/* 590 */       clientGen.setCompilerClasspath(this.compilerClasspath.toString());
/*     */       
/* 592 */       clientGen.setKeepGenerated(this.keepGenerated);
/* 593 */       clientGen.setLogger(new BuildTaskLogger(this));
/*     */       
/* 595 */       classLoader = TaskUtils.setClasspath(this.compilerClasspath.toString());
/*     */       try {
/* 597 */         clientGen.run();
/*     */       } finally {
/* 599 */         TaskUtils.setClassLoader(classLoader);
/*     */       } 
/*     */       
/* 602 */       this.clientJarNames.add(file.getName());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void mergeClients(WebServiceEarFile paramWebServiceEarFile) throws IOException {
/* 607 */     if (this.clientJarNames.size() == 0)
/*     */       return; 
/* 609 */     webServiceWarFile = new WebServiceWarFile(new File(this.tmpDir), paramWebServiceEarFile.getWSWarFile(), null);
/*     */ 
/*     */     
/*     */     try {
/* 613 */       file = webServiceWarFile.getExploded();
/*     */       
/* 615 */       for (String str : this.clientJarNames) {
/*     */ 
/*     */         
/* 618 */         File file1 = new File(paramWebServiceEarFile.getExploded(), str);
/*     */         
/* 620 */         FileUtils.copy(file1, new File(file, str));
/*     */         
/* 622 */         file1.delete();
/*     */       } 
/*     */       
/* 625 */       webServiceWarFile.save();
/*     */     } finally {
/* 627 */       if (webServiceWarFile != null) {
/* 628 */         try { webServiceWarFile.remove(); } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setupClasspath() {
/* 634 */     if (this.compilerClasspath == null) {
/* 635 */       this.compilerClasspath = (Path)Path.systemClasspath.clone();
/*     */     } else {
/* 637 */       this.compilerClasspath.concatSystemClasspath("ignore");
/*     */     } 
/*     */     
/* 640 */     log("Will use compilerClasspath " + this.compilerClasspath, 3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyEjbJars(WebServiceEarFile paramWebServiceEarFile, Collection paramCollection) throws BuildException, IOException {
/* 646 */     if (paramCollection != null && paramCollection.size() > 0) {
/* 647 */       log("Copying ejb-jars to EAR ...", 3);
/*     */       
/* 649 */       for (File file1 : paramCollection) {
/*     */         
/* 651 */         File file2 = new File(paramWebServiceEarFile.getExploded(), file1.getName());
/*     */         
/* 653 */         if (!file1.equals(file2)) {
/* 654 */           FileUtils.copy(file1, file2);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void saveExtraClasses(Set paramSet, File paramFile) {
/* 661 */     for (String str : paramSet)
/*     */     {
/* 663 */       TaskUtils.writeClass(str, paramFile);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean hasOutParam(OperationMBean paramOperationMBean) {
/* 668 */     if (paramOperationMBean.getParams() == null) return false;
/*     */     
/* 670 */     if (paramOperationMBean.getParams().getReturnParam() != null) return true;
/*     */     
/* 672 */     ParamMBean[] arrayOfParamMBean = paramOperationMBean.getParams().getParams();
/*     */     
/* 674 */     if (arrayOfParamMBean == null) return false;
/*     */     
/* 676 */     for (byte b = 0; b < arrayOfParamMBean.length; b++) {
/* 677 */       if ("out".equals(arrayOfParamMBean[b].getParamStyle()) || "inout".equals(arrayOfParamMBean[b].getParamStyle()))
/*     */       {
/*     */         
/* 680 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 684 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\ServiceGenTask.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */