package weblogic.ant.taskdefs.webservices.servicegen;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;
import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.ant.taskdefs.webservices.autotype.AutoTyper;
import weblogic.ant.taskdefs.webservices.autotype.ComponentAutoTyper;
import weblogic.ant.taskdefs.webservices.autotype.EJBAutoTyper;
import weblogic.ant.taskdefs.webservices.autotype.JMSAutoTyper;
import weblogic.ant.taskdefs.webservices.autotype.JavaAutoTyper;
import weblogic.management.descriptors.webservice.HandlerChainMBeanImpl;
import weblogic.management.descriptors.webservice.HandlerChainsMBeanImpl;
import weblogic.management.descriptors.webservice.HandlerMBeanImpl;
import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.ParamMBean;
import weblogic.management.descriptors.webservice.ReliableDeliveryMBeanImpl;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
import weblogic.utils.FileUtils;
import weblogic.webservice.dd.DDMerger;
import weblogic.webservice.dd.DDProcessingException;
import weblogic.webservice.tools.build.BuildToolsFactory;
import weblogic.webservice.tools.build.ClientGen;
import weblogic.webservice.tools.build.WSBuildException;
import weblogic.webservice.util.WebServiceEarFile;
import weblogic.webservice.util.WebServiceJarException;
import weblogic.webservice.util.WebServiceWarFile;
import weblogic.xml.schema.model.XSDException;
import weblogic.xml.schema.model.util.MergeSchemas;
import weblogic.xml.security.specs.EncryptionKey;
import weblogic.xml.security.specs.SecurityDD;
import weblogic.xml.security.specs.SignatureKey;
import weblogic.xml.security.specs.User;
import weblogic.xml.stream.XMLInputOutputStream;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeOutputStream;
import weblogic.xml.xmlnode.XMLNodeSet;

public class ServiceGenTask extends Task {
  private List services = new ArrayList();
  
  private File destEar;
  
  private String warName = "web-services.war";
  
  private String contextURI = null;
  
  private boolean overwrite = true;
  
  private boolean mergeWithExistingWS = false;
  
  private boolean keepGenerated = false;
  
  private String tmpDir = ".";
  
  private Set clientJarNames = new HashSet();
  
  private Set ejbJarNames = new HashSet();
  
  private Path compilerClasspath;
  
  public ServiceGenTask() {
    String str = System.getProperty("java.io.tmpdir");
    if (str != null)
      this.tmpDir = str; 
  }
  
  public void setDestear(File paramFile) { this.destEar = paramFile; }
  
  public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
  
  public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
  
  public void setMergeWithExistingWS(boolean paramBoolean) { this.mergeWithExistingWS = paramBoolean; }
  
  public String getWarName() { return this.warName; }
  
  public void setWarName(String paramString) { this.warName = paramString; }
  
  public String getContextURI() { return this.contextURI; }
  
  public void setContextURI(String paramString) { this.contextURI = paramString; }
  
  public Service createService() {
    Service service = new Service();
    this.services.add(service);
    return service;
  }
  
  public void setClasspath(Path paramPath) {
    if (this.compilerClasspath == null) {
      this.compilerClasspath = paramPath;
    } else {
      this.compilerClasspath.append(paramPath);
    } 
  }
  
  public Path getClasspath() { return this.compilerClasspath; }
  
  public Path createClasspath() {
    if (this.compilerClasspath == null)
      this.compilerClasspath = new Path(this.project); 
    return this.compilerClasspath.createPath();
  }
  
  public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
  
  public void execute() {
    validateAttributes();
    TaskUtils.setAntProject(getProject());
    if (!this.overwrite && !needToRun())
      return; 
    webServiceEarFile = null;
    try {
      if (!this.destEar.getPath().endsWith(".ear") && !this.destEar.exists())
        this.destEar.mkdirs(); 
      webServiceEarFile = new WebServiceEarFile(new File(this.tmpDir), this.destEar, this.warName);
      webServiceEarFile.setContextURI(this.contextURI);
      setupClasspath();
      hashSet = new HashSet();
      for (Service service : this.services) {
        File file = service.getEjbJar();
        if (file != null)
          hashSet.add(file); 
        generateService(webServiceEarFile, service);
        this.mergeWithExistingWS = true;
      } 
      copyEjbJars(webServiceEarFile, hashSet);
      webServiceEarFile.createAppDescriptor(hashSet);
      for (Service service : this.services)
        generateClient(webServiceEarFile, service); 
      mergeClients(webServiceEarFile);
      this.mergeWithExistingWS = false;
      webServiceEarFile.save();
    } catch (WSBuildException wSBuildException) {
      if (wSBuildException.getNested() != null)
        wSBuildException.getNested().printStackTrace(); 
      throw new BuildException(wSBuildException);
    } catch (BuildException buildException) {
      buildException.printStackTrace();
      throw buildException;
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new BuildException(exception);
    } finally {
      try {
        if (webServiceEarFile != null)
          webServiceEarFile.remove(); 
      } catch (IOException iOException) {}
    } 
  }
  
  public void validateAttributes() {
    if (this.services.size() == 0)
      throw new BuildException("At least one <service> subelement must be specified in <servicegen>"); 
    if (this.destEar == null)
      throw new BuildException("The destEar attribute must be specified in <servicegen>"); 
    if (this.contextURI == null)
      if (this.warName.endsWith(".war")) {
        this.contextURI = this.warName.substring(0, this.warName.length() - 4);
      } else {
        this.contextURI = this.warName;
      }  
    HashMap hashMap = new HashMap();
    for (Service service : this.services) {
      String str1 = service.getServiceName();
      String str2 = service.getServiceURI();
      if (hashMap.get(str2) != null && !str1.equals(hashMap.get(str2)))
        throw new BuildException("The same service URI \"" + str2 + "\" cannot be used for more than one service in an application"); 
      hashMap.put(str2, str1);
      service.validateAttributes();
    } 
  }
  
  private boolean needToRun() {
    if (this.destEar.isDirectory())
      return true; 
    long l = this.destEar.lastModified();
    if (l == 0L)
      return true; 
    for (Service service : this.services) {
      if (service.needToRun(l))
        return true; 
    } 
    return false;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<servicegen>:\n");
    stringBuffer.append("destEar = " + this.destEar + "\n");
    stringBuffer.append("warName = " + this.warName + "\n");
    for (Iterator iterator = this.services.iterator(); iterator.hasNext();)
      stringBuffer.append(((Service)iterator.next()).toString()); 
    return stringBuffer.toString();
  }
  
  private void generateService(WebServiceEarFile paramWebServiceEarFile, Service paramService) throws IOException {
    log("Generating service \"" + paramService.getServiceName() + "\" ...");
    webServiceWarFile = null;
    File file1 = paramWebServiceEarFile.getWSWarFile();
    File file2 = paramService.getEjbJar();
    if (!file1.exists() && !file1.getPath().endsWith(".war"))
      file1.mkdirs(); 
    webServiceWarFile = new WebServiceWarFile(new File(this.tmpDir), file1, paramWebServiceEarFile);
    File file3 = webServiceWarFile.getClassesDir();
    String str = this.compilerClasspath.toString() + File.pathSeparator + file3.getCanonicalPath();
    if (file2 != null)
      str = str + File.pathSeparator + file2.getCanonicalPath(); 
    log("using classpath " + str, 3);
    classLoader = TaskUtils.setClasspath(str);
    try {
      autoTyper = runAutoTyper(file3, str, paramService);
      WebServiceMBean webServiceMBean = createDD(autoTyper, webServiceWarFile, paramService);
      HashSet hashSet = autoTyper.getExtraClasses();
      if (paramService.getHandlerChain() != null)
        hashSet.addAll(Arrays.asList((Object[])paramService.getHandlerChain().getHandlers())); 
      saveExtraClasses(hashSet, file3);
      TaskUtils.copyClasses(paramService.getJavaclassComponents(), webServiceMBean.getTypeMapping(), file3);
      webServiceWarFile.save();
    } finally {
      TaskUtils.setClassLoader(classLoader);
      if (webServiceWarFile != null)
        try {
          webServiceWarFile.remove();
        } catch (IOException iOException) {} 
    } 
  }
  
  private AutoTyper runAutoTyper(File paramFile, String paramString, Service paramService) {
    JMSAutoTyper jMSAutoTyper = null;
    try {
      if (paramService.getEjbJar() != null) {
        jMSAutoTyper = new EJBAutoTyper(paramService.getEjbJar(), paramService.getServiceName(), paramFile, paramService.getIncludeEjbs(), paramService.getExcludeEjbs(), this);
        ((ComponentAutoTyper)jMSAutoTyper).setProtocol(paramService.getProtocol());
      } else if (paramService.getJavaclassComponents() != null) {
        jMSAutoTyper = new JavaAutoTyper(paramService.getJavaclassComponents(), paramService.getServiceName(), paramFile, this);
        ((ComponentAutoTyper)jMSAutoTyper).setProtocol(paramService.getProtocol());
      } else {
        JMSAutoTyper jMSAutoTyper1 = new JMSAutoTyper(paramFile, paramService.getServiceName(), this);
        jMSAutoTyper1.setJMSDestination(paramService.getJMSDestination());
        jMSAutoTyper1.setJMSDestinationType(paramService.getJMSDestinationType());
        jMSAutoTyper1.setJMSAction(paramService.getJMSAction());
        jMSAutoTyper1.setJMSConnectionFactory(paramService.getJMSConnectionFactory());
        jMSAutoTyper1.setJMSMessageType(paramService.getJMSMessageType());
        jMSAutoTyper1.setJMSOperationName(paramService.getJMSOperationName());
        jMSAutoTyper1.setProtocol(paramService.getProtocol());
        jMSAutoTyper = jMSAutoTyper1;
      } 
      jMSAutoTyper.setKeepGenerated(this.keepGenerated);
      jMSAutoTyper.setExpandMethods(paramService.getExpandMethods());
      jMSAutoTyper.setGenerateTypes(paramService.getGenerateTypes());
      jMSAutoTyper.setCompilerClasspath(paramString);
      jMSAutoTyper.setStyle(paramService.getStyle());
      jMSAutoTyper.setServiceURI(paramService.getServiceURI());
      jMSAutoTyper.setTargetNSURI(paramService.getTargetNamespace());
      jMSAutoTyper.setUseSoap12(paramService.getUseSoap12());
      jMSAutoTyper.setTypeMappingFile(paramService.getTypeMappingFile());
      jMSAutoTyper.run();
    } catch (IOException iOException) {
      throw new BuildException("Failed to do typemapping.", iOException);
    } 
    return jMSAutoTyper;
  }
  
  private WebServiceMBean createDD(AutoTyper paramAutoTyper, WebServiceWarFile paramWebServiceWarFile, Service paramService) {
    try {
      log("Creating web service DD mbeans ...", 3);
      WebServiceMBean webServiceMBean = paramAutoTyper.getWebServiceDescriptor();
      if (paramService.getIgnoreAuthHeader())
        webServiceMBean.setIgnoreAuthHeader(true); 
      addSecurity(webServiceMBean, paramService);
      addReliabilityAndHandlerChainName(webServiceMBean, paramService);
      addExistingSchemas(webServiceMBean, paramService);
      WebServicesMBeanImpl webServicesMBeanImpl = paramWebServiceWarFile.getWSDD();
      log(((WebServiceMBeanImpl)webServiceMBean).toXML(0), 4);
      if (this.mergeWithExistingWS && webServicesMBeanImpl != null) {
        log("Merging service description into existing web service deployment descriptor ...", 3);
        webServicesMBeanImpl = DDMerger.mergeWebServices(webServicesMBeanImpl, new WebServiceMBean[] { webServiceMBean });
      } else {
        webServicesMBeanImpl = new WebServicesMBeanImpl();
        webServicesMBeanImpl.setWebServices(new WebServiceMBean[] { webServiceMBean });
      } 
      addHandlerChain(webServicesMBeanImpl, paramService);
      paramWebServiceWarFile.writeDD(webServicesMBeanImpl);
      return webServiceMBean;
    } catch (DDProcessingException dDProcessingException) {
      throw new BuildException(dDProcessingException);
    } catch (WebServiceJarException webServiceJarException) {
      throw new BuildException(webServiceJarException);
    } catch (IOException iOException) {
      throw new BuildException(iOException);
    } 
  }
  
  private void addSecurity(WebServiceMBean paramWebServiceMBean, Service paramService) {
    Security security = paramService.getSecurity();
    if (security == null)
      return; 
    SecurityDD securityDD = SecurityDD.getDefaultSecurityDD();
    securityDD.getSpec().setEnablePasswordAuth(security.getEnablePasswordAuth());
    if (security.getUserName() != null && security.getPassword() != null) {
      securityDD.setUser(new User(security.getUserName(), security.getPassword()));
      securityDD.getSpec().setEnablePasswordAuth(true);
    } 
    if (security.getEncryptKeyName() != null && security.getEncryptKeyPass() != null) {
      securityDD.setEncryptionKey(new EncryptionKey(security.getEncryptKeyName(), security.getEncryptKeyPass()));
    } else {
      securityDD.getSpec().setEncryptionSpec(null);
    } 
    if (security.getSignKeyName() != null && security.getSignKeyPass() != null)
      securityDD.setSigningKey(new SignatureKey(security.getSignKeyName(), security.getSignKeyPass())); 
    XMLOutputStreamFactory xMLOutputStreamFactory = XMLOutputStreamFactory.newInstance();
    try {
      XMLInputOutputStream xMLInputOutputStream = xMLOutputStreamFactory.newInputOutputStream();
      securityDD.toXML(xMLInputOutputStream);
      xMLInputOutputStream.flush();
      XMLNode xMLNode = new XMLNode();
      xMLNode.read(xMLInputOutputStream);
      paramWebServiceMBean.setSecurity(xMLNode);
    } catch (XMLStreamException xMLStreamException) {
      throw new BuildException("Failed to create security element.", xMLStreamException);
    } catch (IOException iOException) {
      throw new BuildException("Failed to create security element.", iOException);
    } 
    OperationMBean[] arrayOfOperationMBean = paramWebServiceMBean.getOperations().getOperations();
    for (byte b = 0; b < arrayOfOperationMBean.length; b++) {
      arrayOfOperationMBean[b].setInSecuritySpec(securityDD.getSpec().getId());
      arrayOfOperationMBean[b].setOutSecuritySpec(securityDD.getSpec().getId());
    } 
  }
  
  private void addReliabilityAndHandlerChainName(WebServiceMBean paramWebServiceMBean, Service paramService) {
    Reliability reliability = paramService.getReliability();
    HandlerChain handlerChain = paramService.getHandlerChain();
    if (reliability == null && handlerChain == null)
      return; 
    OperationMBean[] arrayOfOperationMBean = paramWebServiceMBean.getOperations().getOperations();
    for (byte b = 0; b < arrayOfOperationMBean.length; b++) {
      if (handlerChain != null)
        arrayOfOperationMBean[b].setHandlerChainName(handlerChain.getName()); 
      if (reliability != null)
        if (hasOutParam(arrayOfOperationMBean[b])) {
          log("Operation \"" + arrayOfOperationMBean[b].getOperationName() + "\"" + " has return/inout/out type parameters. It is ignored for" + " reliable delivery.", 1);
        } else {
          ReliableDeliveryMBeanImpl reliableDeliveryMBeanImpl = new ReliableDeliveryMBeanImpl();
          if (reliability.getDuplicateElimination() != null)
            reliableDeliveryMBeanImpl.setDuplicateElimination(reliability.getDuplicateElimination().booleanValue()); 
          if (reliability.getPersistDuration() != null)
            reliableDeliveryMBeanImpl.setPersistDuration(reliability.getPersistDuration().intValue()); 
          arrayOfOperationMBean[b].setReliableDelivery(reliableDeliveryMBeanImpl);
        }  
    } 
  }
  
  private void addExistingSchemas(WebServiceMBean paramWebServiceMBean, Service paramService) {
    File file = paramService.getTypeMappingFile();
    if (file == null)
      return; 
    log("Reading init type mapping schemas...", 3);
    xMLInputStream = null;
    try {
      xMLInputStreamFactory = XMLInputStreamFactory.newInstance();
      xMLInputStream = xMLInputStreamFactory.newInputStream(file);
      XMLInputStream xMLInputStream1 = null;
      if (paramWebServiceMBean.getTypes() != null) {
        xMLInputStream1 = paramWebServiceMBean.getTypes().stream();
      } else {
        xMLInputStream1 = (new XMLNode()).stream();
      } 
      XMLNode xMLNode = new XMLNode();
      XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream(xMLNode);
      MergeSchemas.merge(xMLNodeOutputStream, new XMLInputStream[] { xMLInputStream1, xMLInputStream });
      xMLNodeOutputStream.flush();
      XMLNodeSet xMLNodeSet = new XMLNodeSet();
      for (Iterator iterator = xMLNode.getChildren(); iterator.hasNext();)
        xMLNodeSet.addXMLNode((XMLNode)iterator.next()); 
      paramWebServiceMBean.setTypes(xMLNodeSet);
    } catch (XMLStreamException xMLStreamException) {
      throw new BuildException("Failed to read schemas in typemapping file", xMLStreamException);
    } catch (XSDException xSDException) {
      throw new BuildException("Failed to read schemas in typemapping file", xSDException);
    } finally {
      if (xMLInputStream != null)
        try {
          xMLInputStream.close();
        } catch (IOException iOException) {} 
    } 
  }
  
  private void addHandlerChain(WebServicesMBean paramWebServicesMBean, Service paramService) {
    HandlerChain handlerChain = paramService.getHandlerChain();
    if (handlerChain == null)
      return; 
    HandlerChainMBeanImpl handlerChainMBeanImpl = new HandlerChainMBeanImpl();
    handlerChainMBeanImpl.setHandlerChainName(handlerChain.getName());
    String[] arrayOfString = handlerChain.getHandlers();
    for (byte b = 0; b < arrayOfString.length; b++) {
      HandlerMBeanImpl handlerMBeanImpl = new HandlerMBeanImpl();
      handlerMBeanImpl.setClassName(arrayOfString[b]);
      handlerChainMBeanImpl.addHandler(handlerMBeanImpl);
    } 
    HandlerChainsMBeanImpl handlerChainsMBeanImpl = paramWebServicesMBean.getHandlerChains();
    if (handlerChainsMBeanImpl == null)
      handlerChainsMBeanImpl = new HandlerChainsMBeanImpl(); 
    handlerChainsMBeanImpl.addHandlerChain(handlerChainMBeanImpl);
    paramWebServicesMBean.setHandlerChains(handlerChainsMBeanImpl);
  }
  
  private void generateClient(WebServiceEarFile paramWebServiceEarFile, Service paramService) throws IOException {
    Client client = paramService.getClient();
    if (client != null) {
      log("Generating client for " + paramService.getServiceName(), 3);
      BuildToolsFactory buildToolsFactory = BuildToolsFactory.getInstance();
      ClientGen clientGen = buildToolsFactory.getClientGen();
      clientGen.setEarFile(paramWebServiceEarFile.getExploded());
      clientGen.setWarName(paramWebServiceEarFile.getWSWarFile().getName());
      File file = new File(paramWebServiceEarFile.getExploded(), client.getClientjarname());
      clientGen.setClientJar(file);
      clientGen.setServiceName(paramService.getServiceName());
      clientGen.setClientPackageName(client.getPackageName());
      if (client.getTypeMappingFile() != null) {
        clientGen.setTypeMappingFile(client.getTypeMappingFile());
      } else if (paramService.getTypeMappingFile() != null) {
        clientGen.setTypeMappingFile(paramService.getTypeMappingFile());
      } 
      clientGen.setUseServerTypes(client.getUseServerTypes());
      clientGen.setAutotype(paramService.getGenerateTypes());
      clientGen.setSaveWSDL(client.getSavewsdl());
      if (paramService.getUseSoap12()) {
        clientGen.setUsePortNameAsMethodName(true);
      } else {
        clientGen.setUsePortNameAsMethodName(false);
      } 
      clientGen.setCompiler(TaskUtils.getCompiler());
      clientGen.setCompilerClasspath(this.compilerClasspath.toString());
      clientGen.setKeepGenerated(this.keepGenerated);
      clientGen.setLogger(new BuildTaskLogger(this));
      classLoader = TaskUtils.setClasspath(this.compilerClasspath.toString());
      try {
        clientGen.run();
      } finally {
        TaskUtils.setClassLoader(classLoader);
      } 
      this.clientJarNames.add(file.getName());
    } 
  }
  
  private void mergeClients(WebServiceEarFile paramWebServiceEarFile) throws IOException {
    if (this.clientJarNames.size() == 0)
      return; 
    webServiceWarFile = new WebServiceWarFile(new File(this.tmpDir), paramWebServiceEarFile.getWSWarFile(), null);
    try {
      file = webServiceWarFile.getExploded();
      for (String str : this.clientJarNames) {
        File file1 = new File(paramWebServiceEarFile.getExploded(), str);
        FileUtils.copy(file1, new File(file, str));
        file1.delete();
      } 
      webServiceWarFile.save();
    } finally {
      if (webServiceWarFile != null)
        try {
          webServiceWarFile.remove();
        } catch (IOException iOException) {} 
    } 
  }
  
  private void setupClasspath() {
    if (this.compilerClasspath == null) {
      this.compilerClasspath = (Path)Path.systemClasspath.clone();
    } else {
      this.compilerClasspath.concatSystemClasspath("ignore");
    } 
    log("Will use compilerClasspath " + this.compilerClasspath, 3);
  }
  
  private void copyEjbJars(WebServiceEarFile paramWebServiceEarFile, Collection paramCollection) throws BuildException, IOException {
    if (paramCollection != null && paramCollection.size() > 0) {
      log("Copying ejb-jars to EAR ...", 3);
      for (File file1 : paramCollection) {
        File file2 = new File(paramWebServiceEarFile.getExploded(), file1.getName());
        if (!file1.equals(file2))
          FileUtils.copy(file1, file2); 
      } 
    } 
  }
  
  private void saveExtraClasses(Set paramSet, File paramFile) {
    for (String str : paramSet)
      TaskUtils.writeClass(str, paramFile); 
  }
  
  private boolean hasOutParam(OperationMBean paramOperationMBean) {
    if (paramOperationMBean.getParams() == null)
      return false; 
    if (paramOperationMBean.getParams().getReturnParam() != null)
      return true; 
    ParamMBean[] arrayOfParamMBean = paramOperationMBean.getParams().getParams();
    if (arrayOfParamMBean == null)
      return false; 
    for (byte b = 0; b < arrayOfParamMBean.length; b++) {
      if ("out".equals(arrayOfParamMBean[b].getParamStyle()) || "inout".equals(arrayOfParamMBean[b].getParamStyle()))
        return true; 
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\ServiceGenTask.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */