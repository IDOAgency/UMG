package weblogic.ant.taskdefs.webservices.servicegen;

import java.io.File;
import org.apache.tools.ant.BuildException;
import weblogic.utils.StringUtils;

public class Service {
  private static final String LIST_DELIM = ",";
  
  private File ejbJar;
  
  private String[] javaClasses;
  
  private String[] ejbIncludes;
  
  private String[] ejbExcludes;
  
  private String serviceURI;
  
  private String serviceName;
  
  private String targetNS;
  
  private String protocol;
  
  private String style;
  
  private File typeMappingFile;
  
  private boolean expandMethods = true;
  
  private boolean generateTypes = true;
  
  private boolean ignoreAuthHeader = false;
  
  private boolean useSoap12 = false;
  
  private String jmsDestination;
  
  private String jmsDestinationType;
  
  private String jmsAction;
  
  private String jmsConnectionFactory;
  
  private String jmsOperationName;
  
  private String jmsMessageType;
  
  private Client client;
  
  private Security security;
  
  private Reliability reliability;
  
  private HandlerChain handlerChain;
  
  private boolean isJMS = false;
  
  public File getEjbJar() { return this.ejbJar; }
  
  public void setEjbJar(File paramFile) { this.ejbJar = paramFile; }
  
  public String[] getJavaclassComponents() { return this.javaClasses; }
  
  public void setJavaclassComponents(String paramString) {
    if (paramString != null) {
      this.javaClasses = StringUtils.splitCompletely(paramString, ",");
      for (byte b = 0; b < this.javaClasses.length; b++)
        this.javaClasses[b] = this.javaClasses[b].trim(); 
    } 
  }
  
  public String[] getIncludeEjbs() { return this.ejbIncludes; }
  
  public void setIncludeEjbs(String paramString) {
    if (paramString != null) {
      this.ejbIncludes = StringUtils.splitCompletely(paramString, ",");
      for (byte b = 0; b < this.ejbIncludes.length; b++)
        this.ejbIncludes[b] = this.ejbIncludes[b].trim(); 
    } 
  }
  
  public String[] getExcludeEjbs() { return this.ejbExcludes; }
  
  public void setExcludeEjbs(String paramString) {
    if (paramString != null) {
      this.ejbExcludes = StringUtils.splitCompletely(paramString, ",");
      for (byte b = 0; b < this.ejbExcludes.length; b++)
        this.ejbExcludes[b] = this.ejbExcludes[b].trim(); 
    } 
  }
  
  public String getServiceName() { return this.serviceName; }
  
  public void setServiceName(String paramString) { this.serviceName = paramString; }
  
  public String getServiceURI() { return this.serviceURI; }
  
  public void setServiceURI(String paramString) { this.serviceURI = paramString; }
  
  public String getTargetNamespace() { return this.targetNS; }
  
  public void setTargetNamespace(String paramString) { this.targetNS = paramString; }
  
  public String getProtocol() { return this.protocol; }
  
  public void setProtocol(String paramString) { this.protocol = paramString; }
  
  public String getStyle() { return this.style; }
  
  public void setStyle(String paramString) { this.style = paramString; }
  
  public boolean getExpandMethods() { return this.expandMethods; }
  
  public void setExpandMethods(boolean paramBoolean) { this.expandMethods = paramBoolean; }
  
  public boolean getGenerateTypes() { return this.generateTypes; }
  
  public void setGenerateTypes(boolean paramBoolean) { this.generateTypes = paramBoolean; }
  
  public boolean getUseSoap12() { return this.useSoap12; }
  
  public void setUseSoap12(boolean paramBoolean) { this.useSoap12 = paramBoolean; }
  
  public void setTypeMappingFile(File paramFile) { this.typeMappingFile = paramFile; }
  
  public File getTypeMappingFile() { return this.typeMappingFile; }
  
  public void setIgnoreAuthHeader(boolean paramBoolean) { this.ignoreAuthHeader = paramBoolean; }
  
  public boolean getIgnoreAuthHeader() { return this.ignoreAuthHeader; }
  
  public String getJMSDestination() { return this.jmsDestination; }
  
  public void setJMSDestination(String paramString) {
    this.jmsDestination = paramString;
    this.isJMS = true;
  }
  
  public String getJMSDestinationType() { return this.jmsDestinationType; }
  
  public void setJMSDestinationType(String paramString) {
    this.jmsDestinationType = paramString;
    this.isJMS = true;
  }
  
  public String getJMSAction() { return this.jmsAction; }
  
  public void setJMSAction(String paramString) {
    this.jmsAction = paramString;
    this.isJMS = true;
  }
  
  public String getJMSConnectionFactory() { return this.jmsConnectionFactory; }
  
  public void setJMSConnectionFactory(String paramString) {
    this.jmsConnectionFactory = paramString;
    this.isJMS = true;
  }
  
  public String getJMSOperationName() { return this.jmsOperationName; }
  
  public void setJMSOperationName(String paramString) {
    this.jmsOperationName = paramString;
    this.isJMS = true;
  }
  
  public String getJMSMessageType() { return this.jmsMessageType; }
  
  public void setJMSMessageType(String paramString) {
    this.jmsMessageType = paramString;
    this.isJMS = true;
  }
  
  public Client createClient() {
    if (this.client != null)
      throw new BuildException("Only one client element may be specified in the service element"); 
    this.client = new Client(this);
    return this.client;
  }
  
  public Client getClient() { return this.client; }
  
  public Security createSecurity() {
    if (this.security != null)
      throw new BuildException("Only one security element may be specified in the service element"); 
    this.security = new Security();
    return this.security;
  }
  
  public Security getSecurity() { return this.security; }
  
  public Reliability createReliability() {
    if (this.reliability != null)
      throw new BuildException("Only one reliability element may be specified in the service element"); 
    this.reliability = new Reliability();
    return this.reliability;
  }
  
  public Reliability getReliability() { return this.reliability; }
  
  public HandlerChain createHandlerChain() {
    if (this.handlerChain != null)
      throw new BuildException("Only one handlerChain element may be specified in the service element"); 
    this.handlerChain = new HandlerChain(this);
    return this.handlerChain;
  }
  
  public HandlerChain getHandlerChain() { return this.handlerChain; }
  
  public void validateAttributes() {
    if (this.serviceURI == null)
      throw new BuildException("the serviceURI attribute must be set in the <service> element"); 
    if (!this.serviceURI.startsWith("/"))
      this.serviceURI = "/" + this.serviceURI; 
    if (this.serviceName == null)
      throw new BuildException("the serviceName attribute must be set in the <service> element"); 
    if (this.targetNS == null)
      throw new BuildException("the targetNamespace attribute must be set in the <service> element"); 
    if (this.isJMS) {
      if (this.jmsDestination == null)
        throw new BuildException("the JMSDestination attribute must be set for message style webservice."); 
      if (this.jmsDestinationType == null)
        throw new BuildException("the JMSDestinationType attribute must be set for message style webservice."); 
      if (this.jmsAction == null)
        throw new BuildException("the JMSAction attribute must be set for message style webservice."); 
      if (this.jmsConnectionFactory == null)
        throw new BuildException("the JMSConnectionFactory attribute must be set for message style webservice."); 
      if (this.jmsOperationName == null)
        this.jmsOperationName = this.jmsAction; 
      if (this.jmsMessageType == null)
        this.jmsMessageType = "java.lang.String"; 
      if (!this.jmsDestinationType.equals("topic") && !this.jmsDestinationType.equals("queue"))
        throw new BuildException("JMSDestinationType attribute of Service must be \"topic\" or \"queue\""); 
      if (!this.jmsAction.equals("send") && !this.jmsAction.equals("receive"))
        throw new BuildException("JMSAction attribute of Service must be \"send\" or \"receive\""); 
      if (this.style == null) {
        this.style = "document";
      } else {
        this.style = this.style.toLowerCase();
      } 
    } else {
      if (this.ejbJar == null && this.javaClasses == null)
        throw new BuildException("Either the ejbJar or javaClassComponents attribute must be set in the <service> element"); 
      if (this.ejbJar != null && this.javaClasses != null)
        throw new BuildException("Either the ejbJar or javaClassComponents attribute must be set, but not both, in the <service> element"); 
      if (this.ejbIncludes != null && this.ejbJar == null)
        throw new BuildException("the includeEJBs attribute must not be set if the ejbJar attribute is not set in the <service> element"); 
      if (this.ejbExcludes != null && this.ejbJar == null)
        throw new BuildException("the excludeEJBs attribute must not be set if the ejbJar attribute is not set in the <service> element"); 
      if (this.style == null) {
        this.style = "rpc";
      } else {
        this.style = this.style.toLowerCase();
      } 
    } 
    if (this.client != null)
      this.client.validateAttributes(); 
    if (this.reliability != null)
      this.reliability.validateAttributes(); 
    if (this.security != null)
      this.security.validateAttributes(); 
    if (this.handlerChain != null)
      this.handlerChain.validateAttributes(); 
  }
  
  public boolean needToRun(long paramLong) {
    if (this.ejbJar == null)
      return true; 
    return (this.ejbJar.lastModified() > paramLong);
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<service>:\n");
    stringBuffer.append("ejbJar = " + this.ejbJar + "\n");
    stringBuffer.append("javaClasses = " + this.javaClasses + "\n");
    stringBuffer.append("ejbIncludes = " + this.ejbIncludes + "\n");
    stringBuffer.append("ejbExcludes = " + this.ejbExcludes + "\n");
    stringBuffer.append("serviceURI = " + this.serviceURI + "\n");
    stringBuffer.append("serviceName = " + this.serviceName + "\n");
    stringBuffer.append("targetNS = " + this.targetNS + "\n");
    stringBuffer.append("protocol = " + this.protocol + "\n");
    stringBuffer.append("expandMethods = " + this.expandMethods + "\n");
    stringBuffer.append("generateTypes = " + this.generateTypes + "\n");
    stringBuffer.append("ignoreAuthHeader = " + this.ignoreAuthHeader + "\n");
    if (this.client != null)
      stringBuffer.append(this.client.toString()); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\Service.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */