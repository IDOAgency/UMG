/*     */ package weblogic.ant.taskdefs.webservices.servicegen;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import weblogic.utils.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Service
/*     */ {
/*     */   private static final String LIST_DELIM = ",";
/*     */   private File ejbJar;
/*     */   private String[] javaClasses;
/*     */   private String[] ejbIncludes;
/*     */   private String[] ejbExcludes;
/*     */   private String serviceURI;
/*     */   private String serviceName;
/*     */   private String targetNS;
/*     */   private String protocol;
/*     */   private String style;
/*     */   private File typeMappingFile;
/*     */   private boolean expandMethods = true;
/*     */   private boolean generateTypes = true;
/*     */   private boolean ignoreAuthHeader = false;
/*     */   private boolean useSoap12 = false;
/*     */   private String jmsDestination;
/*     */   private String jmsDestinationType;
/*     */   private String jmsAction;
/*     */   private String jmsConnectionFactory;
/*     */   private String jmsOperationName;
/*     */   private String jmsMessageType;
/*     */   private Client client;
/*     */   private Security security;
/*     */   private Reliability reliability;
/*     */   private HandlerChain handlerChain;
/*     */   private boolean isJMS = false;
/*     */   
/*  49 */   public File getEjbJar() { return this.ejbJar; }
/*     */   
/*  51 */   public void setEjbJar(File paramFile) { this.ejbJar = paramFile; }
/*     */ 
/*     */   
/*  54 */   public String[] getJavaclassComponents() { return this.javaClasses; }
/*     */   public void setJavaclassComponents(String paramString) {
/*  56 */     if (paramString != null) {
/*  57 */       this.javaClasses = StringUtils.splitCompletely(paramString, ",");
/*  58 */       for (byte b = 0; b < this.javaClasses.length; b++) {
/*  59 */         this.javaClasses[b] = this.javaClasses[b].trim();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*  64 */   public String[] getIncludeEjbs() { return this.ejbIncludes; }
/*     */   public void setIncludeEjbs(String paramString) {
/*  66 */     if (paramString != null) {
/*  67 */       this.ejbIncludes = StringUtils.splitCompletely(paramString, ",");
/*  68 */       for (byte b = 0; b < this.ejbIncludes.length; b++) {
/*  69 */         this.ejbIncludes[b] = this.ejbIncludes[b].trim();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*  74 */   public String[] getExcludeEjbs() { return this.ejbExcludes; }
/*     */   public void setExcludeEjbs(String paramString) {
/*  76 */     if (paramString != null) {
/*  77 */       this.ejbExcludes = StringUtils.splitCompletely(paramString, ",");
/*  78 */       for (byte b = 0; b < this.ejbExcludes.length; b++) {
/*  79 */         this.ejbExcludes[b] = this.ejbExcludes[b].trim();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*  84 */   public String getServiceName() { return this.serviceName; }
/*  85 */   public void setServiceName(String paramString) { this.serviceName = paramString; }
/*     */   
/*  87 */   public String getServiceURI() { return this.serviceURI; }
/*  88 */   public void setServiceURI(String paramString) { this.serviceURI = paramString; }
/*     */   
/*  90 */   public String getTargetNamespace() { return this.targetNS; }
/*  91 */   public void setTargetNamespace(String paramString) { this.targetNS = paramString; }
/*     */   
/*  93 */   public String getProtocol() { return this.protocol; }
/*  94 */   public void setProtocol(String paramString) { this.protocol = paramString; }
/*     */   
/*  96 */   public String getStyle() { return this.style; }
/*  97 */   public void setStyle(String paramString) { this.style = paramString; }
/*     */   
/*  99 */   public boolean getExpandMethods() { return this.expandMethods; }
/* 100 */   public void setExpandMethods(boolean paramBoolean) { this.expandMethods = paramBoolean; }
/*     */   
/* 102 */   public boolean getGenerateTypes() { return this.generateTypes; }
/* 103 */   public void setGenerateTypes(boolean paramBoolean) { this.generateTypes = paramBoolean; }
/*     */   
/* 105 */   public boolean getUseSoap12() { return this.useSoap12; }
/* 106 */   public void setUseSoap12(boolean paramBoolean) { this.useSoap12 = paramBoolean; }
/*     */   
/* 108 */   public void setTypeMappingFile(File paramFile) { this.typeMappingFile = paramFile; }
/* 109 */   public File getTypeMappingFile() { return this.typeMappingFile; }
/*     */   
/* 111 */   public void setIgnoreAuthHeader(boolean paramBoolean) { this.ignoreAuthHeader = paramBoolean; }
/* 112 */   public boolean getIgnoreAuthHeader() { return this.ignoreAuthHeader; }
/*     */   
/* 114 */   public String getJMSDestination() { return this.jmsDestination; }
/*     */   public void setJMSDestination(String paramString) {
/* 116 */     this.jmsDestination = paramString;
/* 117 */     this.isJMS = true;
/*     */   }
/*     */   
/* 120 */   public String getJMSDestinationType() { return this.jmsDestinationType; }
/*     */   public void setJMSDestinationType(String paramString) {
/* 122 */     this.jmsDestinationType = paramString;
/* 123 */     this.isJMS = true;
/*     */   }
/*     */   
/* 126 */   public String getJMSAction() { return this.jmsAction; }
/*     */   public void setJMSAction(String paramString) {
/* 128 */     this.jmsAction = paramString;
/* 129 */     this.isJMS = true;
/*     */   }
/*     */   
/* 132 */   public String getJMSConnectionFactory() { return this.jmsConnectionFactory; }
/*     */   public void setJMSConnectionFactory(String paramString) {
/* 134 */     this.jmsConnectionFactory = paramString;
/* 135 */     this.isJMS = true;
/*     */   }
/*     */   
/* 138 */   public String getJMSOperationName() { return this.jmsOperationName; }
/*     */   public void setJMSOperationName(String paramString) {
/* 140 */     this.jmsOperationName = paramString;
/* 141 */     this.isJMS = true;
/*     */   }
/*     */   
/* 144 */   public String getJMSMessageType() { return this.jmsMessageType; }
/*     */   public void setJMSMessageType(String paramString) {
/* 146 */     this.jmsMessageType = paramString;
/* 147 */     this.isJMS = true;
/*     */   }
/*     */   
/*     */   public Client createClient() {
/* 151 */     if (this.client != null) {
/* 152 */       throw new BuildException("Only one client element may be specified in the service element");
/*     */     }
/*     */ 
/*     */     
/* 156 */     this.client = new Client(this);
/* 157 */     return this.client;
/*     */   }
/* 159 */   public Client getClient() { return this.client; }
/*     */   
/*     */   public Security createSecurity() {
/* 162 */     if (this.security != null) {
/* 163 */       throw new BuildException("Only one security element may be specified in the service element");
/*     */     }
/*     */ 
/*     */     
/* 167 */     this.security = new Security();
/* 168 */     return this.security;
/*     */   }
/* 170 */   public Security getSecurity() { return this.security; }
/*     */   
/*     */   public Reliability createReliability() {
/* 173 */     if (this.reliability != null) {
/* 174 */       throw new BuildException("Only one reliability element may be specified in the service element");
/*     */     }
/*     */ 
/*     */     
/* 178 */     this.reliability = new Reliability();
/* 179 */     return this.reliability;
/*     */   }
/* 181 */   public Reliability getReliability() { return this.reliability; }
/*     */   
/*     */   public HandlerChain createHandlerChain() {
/* 184 */     if (this.handlerChain != null) {
/* 185 */       throw new BuildException("Only one handlerChain element may be specified in the service element");
/*     */     }
/*     */ 
/*     */     
/* 189 */     this.handlerChain = new HandlerChain(this);
/* 190 */     return this.handlerChain;
/*     */   }
/* 192 */   public HandlerChain getHandlerChain() { return this.handlerChain; }
/*     */   
/*     */   public void validateAttributes() {
/* 195 */     if (this.serviceURI == null) {
/* 196 */       throw new BuildException("the serviceURI attribute must be set in the <service> element");
/*     */     }
/* 198 */     if (!this.serviceURI.startsWith("/")) {
/* 199 */       this.serviceURI = "/" + this.serviceURI;
/*     */     }
/* 201 */     if (this.serviceName == null) {
/* 202 */       throw new BuildException("the serviceName attribute must be set in the <service> element");
/*     */     }
/* 204 */     if (this.targetNS == null) {
/* 205 */       throw new BuildException("the targetNamespace attribute must be set in the <service> element");
/*     */     }
/*     */     
/* 208 */     if (this.isJMS) {
/*     */       
/* 210 */       if (this.jmsDestination == null) {
/* 211 */         throw new BuildException("the JMSDestination attribute must be set for message style webservice.");
/*     */       }
/* 213 */       if (this.jmsDestinationType == null) {
/* 214 */         throw new BuildException("the JMSDestinationType attribute must be set for message style webservice.");
/*     */       }
/* 216 */       if (this.jmsAction == null) {
/* 217 */         throw new BuildException("the JMSAction attribute must be set for message style webservice.");
/*     */       }
/* 219 */       if (this.jmsConnectionFactory == null) {
/* 220 */         throw new BuildException("the JMSConnectionFactory attribute must be set for message style webservice.");
/*     */       }
/*     */       
/* 223 */       if (this.jmsOperationName == null) {
/* 224 */         this.jmsOperationName = this.jmsAction;
/*     */       }
/*     */       
/* 227 */       if (this.jmsMessageType == null) {
/* 228 */         this.jmsMessageType = "java.lang.String";
/*     */       }
/*     */       
/* 231 */       if (!this.jmsDestinationType.equals("topic") && !this.jmsDestinationType.equals("queue")) {
/* 232 */         throw new BuildException("JMSDestinationType attribute of Service must be \"topic\" or \"queue\"");
/*     */       }
/* 234 */       if (!this.jmsAction.equals("send") && !this.jmsAction.equals("receive")) {
/* 235 */         throw new BuildException("JMSAction attribute of Service must be \"send\" or \"receive\"");
/*     */       }
/*     */       
/* 238 */       if (this.style == null) {
/* 239 */         this.style = "document";
/*     */       } else {
/* 241 */         this.style = this.style.toLowerCase();
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 247 */       if (this.ejbJar == null && this.javaClasses == null) {
/* 248 */         throw new BuildException("Either the ejbJar or javaClassComponents attribute must be set in the <service> element");
/*     */       }
/*     */ 
/*     */       
/* 252 */       if (this.ejbJar != null && this.javaClasses != null) {
/* 253 */         throw new BuildException("Either the ejbJar or javaClassComponents attribute must be set, but not both, in the <service> element");
/*     */       }
/*     */ 
/*     */       
/* 257 */       if (this.ejbIncludes != null && this.ejbJar == null) {
/* 258 */         throw new BuildException("the includeEJBs attribute must not be set if the ejbJar attribute is not set in the <service> element");
/*     */       }
/*     */ 
/*     */       
/* 262 */       if (this.ejbExcludes != null && this.ejbJar == null) {
/* 263 */         throw new BuildException("the excludeEJBs attribute must not be set if the ejbJar attribute is not set in the <service> element");
/*     */       }
/*     */ 
/*     */       
/* 267 */       if (this.style == null) {
/* 268 */         this.style = "rpc";
/*     */       } else {
/* 270 */         this.style = this.style.toLowerCase();
/*     */       } 
/*     */     } 
/*     */     
/* 274 */     if (this.client != null) this.client.validateAttributes();
/*     */     
/* 276 */     if (this.reliability != null) this.reliability.validateAttributes();
/*     */     
/* 278 */     if (this.security != null) this.security.validateAttributes();
/*     */     
/* 280 */     if (this.handlerChain != null) this.handlerChain.validateAttributes(); 
/*     */   }
/*     */   
/*     */   public boolean needToRun(long paramLong) {
/* 284 */     if (this.ejbJar == null) return true;
/*     */     
/* 286 */     return (this.ejbJar.lastModified() > paramLong);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 290 */     StringBuffer stringBuffer = new StringBuffer();
/* 291 */     stringBuffer.append("<service>:\n");
/* 292 */     stringBuffer.append("ejbJar = " + this.ejbJar + "\n");
/* 293 */     stringBuffer.append("javaClasses = " + this.javaClasses + "\n");
/* 294 */     stringBuffer.append("ejbIncludes = " + this.ejbIncludes + "\n");
/* 295 */     stringBuffer.append("ejbExcludes = " + this.ejbExcludes + "\n");
/* 296 */     stringBuffer.append("serviceURI = " + this.serviceURI + "\n");
/* 297 */     stringBuffer.append("serviceName = " + this.serviceName + "\n");
/* 298 */     stringBuffer.append("targetNS = " + this.targetNS + "\n");
/* 299 */     stringBuffer.append("protocol = " + this.protocol + "\n");
/* 300 */     stringBuffer.append("expandMethods = " + this.expandMethods + "\n");
/* 301 */     stringBuffer.append("generateTypes = " + this.generateTypes + "\n");
/* 302 */     stringBuffer.append("ignoreAuthHeader = " + this.ignoreAuthHeader + "\n");
/* 303 */     if (this.client != null) stringBuffer.append(this.client.toString()); 
/* 304 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\Service.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */