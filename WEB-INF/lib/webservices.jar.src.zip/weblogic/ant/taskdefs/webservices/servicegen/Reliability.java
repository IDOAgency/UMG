package weblogic.ant.taskdefs.webservices.servicegen;

public class Reliability {
  private Integer persistDuration;
  
  private Boolean duplicateElimination;
  
  public void setPersistDuration(Integer paramInteger) { this.persistDuration = paramInteger; }
  
  public Integer getPersistDuration() { return this.persistDuration; }
  
  public void setDuplicateElimination(Boolean paramBoolean) { this.duplicateElimination = paramBoolean; }
  
  public Boolean getDuplicateElimination() { return this.duplicateElimination; }
  
  void validateAttributes() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\Reliability.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */