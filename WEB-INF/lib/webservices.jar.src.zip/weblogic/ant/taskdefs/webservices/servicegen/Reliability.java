/*    */ package weblogic.ant.taskdefs.webservices.servicegen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Reliability
/*    */ {
/*    */   private Integer persistDuration;
/*    */   private Boolean duplicateElimination;
/*    */   
/* 11 */   public void setPersistDuration(Integer paramInteger) { this.persistDuration = paramInteger; }
/*    */ 
/*    */   
/* 14 */   public Integer getPersistDuration() { return this.persistDuration; }
/*    */ 
/*    */ 
/*    */   
/* 18 */   public void setDuplicateElimination(Boolean paramBoolean) { this.duplicateElimination = paramBoolean; }
/*    */ 
/*    */   
/* 21 */   public Boolean getDuplicateElimination() { return this.duplicateElimination; }
/*    */   
/*    */   void validateAttributes() {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\servicegen\Reliability.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */