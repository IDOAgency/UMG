/*     */ package weblogic.ant.taskdefs.webservices.wsdl2service;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.webservice.tools.build.BuildToolsFactory;
/*     */ import weblogic.webservice.tools.build.WSBuildException;
/*     */ import weblogic.webservice.tools.build.WSDL2JavaService;
/*     */ import weblogic.xml.schema.binding.internal.NameUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSDL2Service
/*     */   extends Task
/*     */ {
/*     */   protected static boolean DEBUG = false;
/*     */   private File typeMappingFile;
/*     */   private String wsdlURI;
/*     */   private File destDir;
/*     */   private String packageName;
/*     */   private String serviceName;
/*     */   private String componentName;
/*     */   private File ddFile;
/*     */   private boolean generateInterface = true;
/*     */   private boolean overwrite = true;
/*     */   private boolean keepGenerated;
/*     */   private boolean generateImpl;
/*     */   private FileInputStream typeMappingStream;
/*     */   private Path compileClasspath;
/*     */   
/*  53 */   public void setTypemappingfile(File paramFile) { this.typeMappingFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public void setWsdl(String paramString) { this.wsdlURI = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void setDDFile(File paramFile) { this.ddFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void setGenerateInterface(boolean paramBoolean) { this.generateInterface = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void setDestDir(File paramFile) { this.destDir = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void setPackageName(String paramString) { this.packageName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  77 */   public void setServiceName(String paramString) { this.serviceName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void setComponentName(String paramString) { this.componentName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void setGenerateImpl(boolean paramBoolean) { this.generateImpl = paramBoolean; }
/*     */ 
/*     */   
/*     */   public void setClasspath(Path paramPath) {
/*  93 */     if (this.compileClasspath == null) {
/*  94 */       this.compileClasspath = paramPath;
/*     */     } else {
/*  96 */       this.compileClasspath.append(paramPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 101 */   public Path getClasspath() { return this.compileClasspath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/* 108 */     if (this.compileClasspath == null) {
/* 109 */       this.compileClasspath = new Path(this.project);
/*     */     }
/* 111 */     return this.compileClasspath.createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
/*     */ 
/*     */   
/*     */   public void execute() throws BuildException {
/* 122 */     validateAttribute();
/*     */     
/* 124 */     TaskUtils.setAntProject(getProject());
/*     */     
/* 126 */     if (!this.overwrite && !needToRun())
/*     */       return; 
/* 128 */     log("Generating web service from wsdl " + this.wsdlURI);
/*     */     
/*     */     try {
/* 131 */       doWSDL2JavaService();
/* 132 */     } catch (IOException iOException) {
/* 133 */       iOException.printStackTrace();
/* 134 */       throw new BuildException(iOException);
/* 135 */     } catch (WSBuildException wSBuildException) {
/* 136 */       if (wSBuildException.getNested() != null) {
/* 137 */         wSBuildException.getNested().printStackTrace();
/*     */       }
/* 139 */       throw new BuildException(wSBuildException);
/* 140 */     } catch (Exception exception) {
/* 141 */       throw new BuildException(exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateAttribute() throws BuildException {
/* 146 */     if (this.destDir == null) {
/* 147 */       throw new BuildException("destDir attribute must be set");
/*     */     }
/*     */     
/* 150 */     if (this.destDir.exists()) {
/* 151 */       if (this.destDir.isFile()) {
/* 152 */         throw new BuildException("destDir can't be a file.");
/*     */       }
/*     */     } else {
/* 155 */       this.destDir.mkdirs();
/*     */     } 
/*     */     
/* 158 */     if (this.wsdlURI == null) {
/* 159 */       throw new BuildException("Wsdl attribute must be set");
/*     */     }
/*     */     
/* 162 */     if (this.packageName == null) {
/* 163 */       throw new BuildException("PackageName attribute must be set");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean needToRun() {
/* 168 */     File file = TaskUtils.getFileFromWSDLURI(this.wsdlURI);
/*     */     
/* 170 */     if (file == null) return true;
/*     */     
/* 172 */     long l1 = file.lastModified();
/*     */     
/* 174 */     long l2 = 0L;
/*     */     
/* 176 */     if (this.serviceName != null) {
/* 177 */       File file1 = new File(this.destDir, this.packageName.replace('.', '/') + NameUtil.getJAXRPCClassName(this.serviceName) + ".java");
/*     */ 
/*     */       
/* 180 */       l2 = file1.lastModified();
/* 181 */     } else if (this.ddFile != null) {
/* 182 */       l2 = this.ddFile.lastModified();
/*     */     } 
/*     */     
/* 185 */     return (l1 > l2);
/*     */   }
/*     */   
/*     */   private void doWSDL2JavaService() throws BuildException {
/* 189 */     setupClasspath();
/*     */     
/* 191 */     WSDL2JavaService wSDL2JavaService = BuildToolsFactory.getInstance().getWSDL2JavaService();
/* 192 */     wSDL2JavaService.setWsdlUrl(TaskUtils.getResourceURL(this.wsdlURI));
/* 193 */     wSDL2JavaService.setDestDir(this.destDir);
/* 194 */     wSDL2JavaService.setPackageName(this.packageName);
/* 195 */     wSDL2JavaService.setServiceName(this.serviceName);
/* 196 */     wSDL2JavaService.setLogger(new BuildTaskLogger(this));
/* 197 */     wSDL2JavaService.setDDFile(this.ddFile);
/* 198 */     wSDL2JavaService.setGenerateInterface(this.generateInterface);
/* 199 */     wSDL2JavaService.setComponentName(this.componentName);
/* 200 */     wSDL2JavaService.setKeepGenerated(this.keepGenerated);
/* 201 */     wSDL2JavaService.setGenerateImpl(this.generateImpl);
/*     */ 
/*     */     
/* 204 */     if (this.typeMappingFile != null) {
/* 205 */       this.typeMappingStream = new FileInputStream(this.typeMappingFile);
/* 206 */       wSDL2JavaService.setInitTypeMapping(this.typeMappingStream);
/*     */     } 
/*     */     
/* 209 */     classLoader = TaskUtils.setClasspath(this.compileClasspath.toString());
/*     */     try {
/* 211 */       wSDL2JavaService.run();
/*     */     } finally {
/* 213 */       TaskUtils.setClassLoader(classLoader);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setupClasspath() throws BuildException {
/* 218 */     if (this.compileClasspath == null) {
/* 219 */       this.compileClasspath = (Path)Path.systemClasspath.clone();
/*     */     } else {
/* 221 */       this.compileClasspath.concatSystemClasspath("ignore");
/*     */     } 
/*     */     
/* 224 */     Path path = new Path(this.project, this.destDir.getCanonicalPath());
/* 225 */     this.compileClasspath.append(path);
/* 226 */     log("Will use compilerClasspath " + this.compileClasspath, 3);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsdl2service\WSDL2Service.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */