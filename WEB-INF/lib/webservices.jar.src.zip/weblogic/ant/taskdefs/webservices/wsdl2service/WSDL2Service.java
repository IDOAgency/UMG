package weblogic.ant.taskdefs.webservices.wsdl2service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;
import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.webservice.tools.build.BuildToolsFactory;
import weblogic.webservice.tools.build.WSBuildException;
import weblogic.webservice.tools.build.WSDL2JavaService;
import weblogic.xml.schema.binding.internal.NameUtil;

public class WSDL2Service extends Task {
  protected static boolean DEBUG = false;
  
  private File typeMappingFile;
  
  private String wsdlURI;
  
  private File destDir;
  
  private String packageName;
  
  private String serviceName;
  
  private String componentName;
  
  private File ddFile;
  
  private boolean generateInterface = true;
  
  private boolean overwrite = true;
  
  private boolean keepGenerated;
  
  private boolean generateImpl;
  
  private FileInputStream typeMappingStream;
  
  private Path compileClasspath;
  
  public void setTypemappingfile(File paramFile) { this.typeMappingFile = paramFile; }
  
  public void setWsdl(String paramString) { this.wsdlURI = paramString; }
  
  public void setDDFile(File paramFile) { this.ddFile = paramFile; }
  
  public void setGenerateInterface(boolean paramBoolean) { this.generateInterface = paramBoolean; }
  
  public void setDestDir(File paramFile) { this.destDir = paramFile; }
  
  public void setPackageName(String paramString) { this.packageName = paramString; }
  
  public void setServiceName(String paramString) { this.serviceName = paramString; }
  
  public void setComponentName(String paramString) { this.componentName = paramString; }
  
  public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
  
  public void setGenerateImpl(boolean paramBoolean) { this.generateImpl = paramBoolean; }
  
  public void setClasspath(Path paramPath) {
    if (this.compileClasspath == null) {
      this.compileClasspath = paramPath;
    } else {
      this.compileClasspath.append(paramPath);
    } 
  }
  
  public Path getClasspath() { return this.compileClasspath; }
  
  public Path createClasspath() {
    if (this.compileClasspath == null)
      this.compileClasspath = new Path(this.project); 
    return this.compileClasspath.createPath();
  }
  
  public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
  
  public void execute() throws BuildException {
    validateAttribute();
    TaskUtils.setAntProject(getProject());
    if (!this.overwrite && !needToRun())
      return; 
    log("Generating web service from wsdl " + this.wsdlURI);
    try {
      doWSDL2JavaService();
    } catch (IOException iOException) {
      iOException.printStackTrace();
      throw new BuildException(iOException);
    } catch (WSBuildException wSBuildException) {
      if (wSBuildException.getNested() != null)
        wSBuildException.getNested().printStackTrace(); 
      throw new BuildException(wSBuildException);
    } catch (Exception exception) {
      throw new BuildException(exception);
    } 
  }
  
  private void validateAttribute() throws BuildException {
    if (this.destDir == null)
      throw new BuildException("destDir attribute must be set"); 
    if (this.destDir.exists()) {
      if (this.destDir.isFile())
        throw new BuildException("destDir can't be a file."); 
    } else {
      this.destDir.mkdirs();
    } 
    if (this.wsdlURI == null)
      throw new BuildException("Wsdl attribute must be set"); 
    if (this.packageName == null)
      throw new BuildException("PackageName attribute must be set"); 
  }
  
  private boolean needToRun() {
    File file = TaskUtils.getFileFromWSDLURI(this.wsdlURI);
    if (file == null)
      return true; 
    long l1 = file.lastModified();
    long l2 = 0L;
    if (this.serviceName != null) {
      File file1 = new File(this.destDir, this.packageName.replace('.', '/') + NameUtil.getJAXRPCClassName(this.serviceName) + ".java");
      l2 = file1.lastModified();
    } else if (this.ddFile != null) {
      l2 = this.ddFile.lastModified();
    } 
    return (l1 > l2);
  }
  
  private void doWSDL2JavaService() throws BuildException {
    setupClasspath();
    WSDL2JavaService wSDL2JavaService = BuildToolsFactory.getInstance().getWSDL2JavaService();
    wSDL2JavaService.setWsdlUrl(TaskUtils.getResourceURL(this.wsdlURI));
    wSDL2JavaService.setDestDir(this.destDir);
    wSDL2JavaService.setPackageName(this.packageName);
    wSDL2JavaService.setServiceName(this.serviceName);
    wSDL2JavaService.setLogger(new BuildTaskLogger(this));
    wSDL2JavaService.setDDFile(this.ddFile);
    wSDL2JavaService.setGenerateInterface(this.generateInterface);
    wSDL2JavaService.setComponentName(this.componentName);
    wSDL2JavaService.setKeepGenerated(this.keepGenerated);
    wSDL2JavaService.setGenerateImpl(this.generateImpl);
    if (this.typeMappingFile != null) {
      this.typeMappingStream = new FileInputStream(this.typeMappingFile);
      wSDL2JavaService.setInitTypeMapping(this.typeMappingStream);
    } 
    classLoader = TaskUtils.setClasspath(this.compileClasspath.toString());
    try {
      wSDL2JavaService.run();
    } finally {
      TaskUtils.setClassLoader(classLoader);
    } 
  }
  
  private void setupClasspath() throws BuildException {
    if (this.compileClasspath == null) {
      this.compileClasspath = (Path)Path.systemClasspath.clone();
    } else {
      this.compileClasspath.concatSystemClasspath("ignore");
    } 
    Path path = new Path(this.project, this.destDir.getCanonicalPath());
    this.compileClasspath.append(path);
    log("Will use compilerClasspath " + this.compileClasspath, 3);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsdl2service\WSDL2Service.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */