package weblogic.ant.taskdefs.webservices.javaschema;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashSet;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;
import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.utils.StringUtils;
import weblogic.webservice.tools.build.BuildToolsFactory;
import weblogic.webservice.tools.build.Component2Schema;
import weblogic.webservice.tools.build.Java2Schema;
import weblogic.webservice.tools.build.Schema2Java;
import weblogic.webservice.tools.build.WSBuildException;
import weblogic.webservice.tools.build.WSDL2Java;
import weblogic.webservice.util.WebServiceEarFile;
import weblogic.webservice.util.WebServiceJarException;

public class JavaSchema extends Task {
  protected static boolean DEBUG = false;
  
  private static final String LIST_DELIM = ",";
  
  private File destDir;
  
  private String schemaFile;
  
  private File earClasspath;
  
  private String wsdlURI;
  
  private String javaTypes;
  
  private String javaComponents;
  
  private File typeMappingFile;
  
  private String targetNSURI;
  
  private String packageBase;
  
  private String packageName;
  
  private String encoding;
  
  private boolean keepGenerated = false;
  
  private boolean generatePublicFields = false;
  
  private boolean overwrite = true;
  
  private Class[] javaClasses;
  
  private FileInputStream typeMappingStream;
  
  private InputStream schemaFileStream;
  
  private String compiler;
  
  private Path compileClasspath;
  
  private WebServiceEarFile loadEar = null;
  
  public void setTypemappingfile(File paramFile) { this.typeMappingFile = paramFile; }
  
  public void setSchemaFile(String paramString) { this.schemaFile = paramString; }
  
  public void setWsdl(String paramString) { this.wsdlURI = paramString; }
  
  public void setJavaTypes(String paramString) { this.javaTypes = paramString; }
  
  public void setJavaComponents(String paramString) { this.javaComponents = paramString; }
  
  public void setDestDir(File paramFile) { this.destDir = paramFile; }
  
  public void setTargetnamespace(String paramString) { this.targetNSURI = paramString; }
  
  public void setPackageName(String paramString) { this.packageName = paramString; }
  
  public void setPackageBase(String paramString) { this.packageBase = paramString; }
  
  public void setEncoding(String paramString) { this.encoding = paramString; }
  
  public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
  
  public void setGeneratePublicFields(boolean paramBoolean) { this.generatePublicFields = paramBoolean; }
  
  public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
  
  public void setEarClasspath(File paramFile) { this.earClasspath = paramFile; }
  
  public void setClasspath(Path paramPath) {
    if (this.compileClasspath == null) {
      this.compileClasspath = paramPath;
    } else {
      this.compileClasspath.append(paramPath);
    } 
  }
  
  public Path getClasspath() { return this.compileClasspath; }
  
  public Path createClasspath() {
    if (this.compileClasspath == null)
      this.compileClasspath = new Path(this.project); 
    return this.compileClasspath.createPath();
  }
  
  public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
  
  public void execute() throws BuildException {
    validateAttribute();
    TaskUtils.setAntProject(getProject());
    setupCompiler();
    classLoader = TaskUtils.setClasspath(this.compileClasspath.toString());
    try {
      if (this.javaComponents != null) {
        if (this.wsdlURI != null || this.javaTypes != null || this.schemaFile != null)
          throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set"); 
        doComponent2Schema();
      } else if (this.wsdlURI != null) {
        if (this.javaComponents != null || this.javaTypes != null || this.schemaFile != null)
          throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set"); 
        doWSDL2Java();
      } else if (this.javaTypes != null) {
        if (this.wsdlURI != null || this.javaComponents != null || this.schemaFile != null)
          throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set"); 
        doJava2Schema();
      } else {
        if (this.wsdlURI != null || this.javaTypes != null || this.javaComponents != null)
          throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set"); 
        doSchema2Java();
      } 
    } catch (IOException iOException) {
      iOException.printStackTrace();
      throw new BuildException(iOException);
    } catch (WSBuildException wSBuildException) {
      if (wSBuildException.getNested() != null)
        wSBuildException.getNested().printStackTrace(System.out); 
      throw new BuildException(wSBuildException);
    } catch (BuildException buildException) {
      throw buildException;
    } catch (RuntimeException runtimeException) {
      runtimeException.printStackTrace();
      throw new BuildException(runtimeException);
    } finally {
      TaskUtils.setClassLoader(classLoader);
      try {
        if (this.schemaFileStream != null)
          this.schemaFileStream.close(); 
        if (this.typeMappingStream != null)
          this.typeMappingStream.close(); 
      } catch (IOException iOException) {}
      try {
        if (this.loadEar != null)
          this.loadEar.remove(); 
      } catch (IOException iOException) {}
    } 
  }
  
  private void validateAttribute() throws BuildException {
    if (this.destDir == null)
      throw new BuildException("The destDir attribute must be set"); 
    if (this.destDir.exists()) {
      if (this.destDir.isFile())
        throw new BuildException("destDir can't be a file."); 
    } else {
      this.destDir.mkdirs();
    } 
    if (this.schemaFile == null && this.javaTypes == null && this.javaComponents == null && this.wsdlURI == null)
      throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set"); 
    if (this.packageName != null && this.packageBase != null)
      throw new BuildException("Can't specify both packageName and packageBase."); 
    if (this.encoding != null) {
      if (this.javaTypes == null && this.javaComponents == null)
        throw new BuildException("Encoding can only be specifed with javaTypes or javaComponents."); 
      if ("soap".equals(this.encoding) && !"literal".equals(this.encoding))
        throw new BuildException("Encoding can only be \"soap\" or \"literal\"."); 
    } 
    if (this.typeMappingFile != null && 
      !this.typeMappingFile.exists()) {
      log("typeMappingFile " + this.typeMappingFile.getAbsolutePath() + " doesn't exits!. Ignored", 0);
      this.typeMappingFile = null;
    } 
    if (this.earClasspath != null && this.earClasspath.exists()) {
      String str = System.getProperty("java.io.tmpdir");
      if (str == null)
        str = "."; 
      try {
        this.loadEar = new WebServiceEarFile(new File(str), this.earClasspath, "junk");
      } catch (IOException iOException) {
        throw new BuildException("Failed to access " + this.earClasspath, iOException);
      } catch (WebServiceJarException webServiceJarException) {
        throw new BuildException("Failed to access " + this.earClasspath, webServiceJarException);
      } 
    } 
  }
  
  private void doJava2Schema() throws BuildException {
    loadClasses(this.javaTypes);
    if (!this.overwrite && !needToRun(this.javaClasses)) {
      log("Types.xml file is up to date.", 3);
      return;
    } 
    log("Autotyping for javaTypes " + this.javaTypes);
    Java2Schema java2Schema = BuildToolsFactory.getInstance().getJava2Schema();
    java2Schema.setJavaClassTypes(this.javaClasses);
    java2Schema.setDestDir(this.destDir);
    java2Schema.setPackageName(this.packageName);
    java2Schema.setPackageBase(this.packageBase);
    java2Schema.setEncoding(this.encoding);
    java2Schema.setKeepGenerated(this.keepGenerated);
    java2Schema.setCompiler(this.compiler);
    java2Schema.setCompilerClasspath(this.compileClasspath.toString());
    java2Schema.setLogger(new BuildTaskLogger(this));
    if (this.typeMappingFile != null) {
      this.typeMappingStream = new FileInputStream(this.typeMappingFile);
      java2Schema.setInitTypeMapping(this.typeMappingStream);
    } 
    java2Schema.run();
  }
  
  private void doSchema2Java() throws BuildException {
    String str = TaskUtils.getResourceURL(this.schemaFile);
    if (!this.overwrite) {
      File file = TaskUtils.getFileFromWSDLURI(str);
      if (file != null && !needToRun(file))
        return; 
    } 
    log("Autotyping for schemaFile " + this.schemaFile);
    Schema2Java schema2Java = BuildToolsFactory.getInstance().getSchema2Java();
    this.schemaFileStream = (new URL(str)).openStream();
    schema2Java.setSchemaStream(this.schemaFileStream);
    schema2Java.setSchemaURL(str);
    schema2Java.setDestDir(this.destDir);
    schema2Java.setPackageName(this.packageName);
    schema2Java.setPackageBase(this.packageBase);
    schema2Java.setKeepGenerated(this.keepGenerated);
    schema2Java.setGeneratePublicFields(this.generatePublicFields);
    schema2Java.setCompiler(this.compiler);
    schema2Java.setCompilerClasspath(this.compileClasspath.toString());
    schema2Java.setLogger(new BuildTaskLogger(this));
    if (this.typeMappingFile != null) {
      this.typeMappingStream = new FileInputStream(this.typeMappingFile);
      schema2Java.setInitTypeMapping(this.typeMappingStream);
    } 
    schema2Java.run();
  }
  
  private void doComponent2Schema() throws BuildException {
    loadClasses(this.javaComponents);
    if (!this.overwrite && !needToRun(this.javaClasses)) {
      log("Types.xml file is up to date.", 3);
      return;
    } 
    log("Autotyping for javaComponents " + this.javaComponents);
    Component2Schema component2Schema = BuildToolsFactory.getInstance().getComponent2Schema();
    component2Schema.setComponents(this.javaClasses);
    component2Schema.setDestDir(this.destDir);
    component2Schema.setPackageName(this.packageName);
    component2Schema.setPackageBase(this.packageBase);
    component2Schema.setEncoding(this.encoding);
    component2Schema.setKeepGenerated(this.keepGenerated);
    component2Schema.setCompiler(this.compiler);
    component2Schema.setCompilerClasspath(this.compileClasspath.toString());
    component2Schema.setLogger(new BuildTaskLogger(this));
    if (this.typeMappingFile != null) {
      this.typeMappingStream = new FileInputStream(this.typeMappingFile);
      component2Schema.setInitTypeMapping(this.typeMappingStream);
    } 
    component2Schema.run();
  }
  
  private void doWSDL2Java() throws BuildException {
    String str = TaskUtils.getResourceURL(this.wsdlURI);
    if (!this.overwrite) {
      File file = TaskUtils.getFileFromWSDLURI(str);
      if (file != null && !needToRun(file)) {
        log("Types.xml file is up to date.", 3);
        return;
      } 
    } 
    log("Autotyping for wsdl " + this.wsdlURI);
    WSDL2Java wSDL2Java = BuildToolsFactory.getInstance().getWSDL2Java();
    wSDL2Java.setWsdlUrl(str);
    wSDL2Java.setDestDir(this.destDir);
    wSDL2Java.setPackageName(this.packageName);
    wSDL2Java.setPackageBase(this.packageBase);
    wSDL2Java.setKeepGenerated(this.keepGenerated);
    wSDL2Java.setGeneratePublicFields(this.generatePublicFields);
    wSDL2Java.setCompiler(this.compiler);
    wSDL2Java.setCompilerClasspath(this.compileClasspath.toString());
    wSDL2Java.setLogger(new BuildTaskLogger(this));
    if (this.typeMappingFile != null) {
      this.typeMappingStream = new FileInputStream(this.typeMappingFile);
      wSDL2Java.setInitTypeMapping(this.typeMappingStream);
    } 
    wSDL2Java.run();
  }
  
  private void setupCompiler() throws BuildException {
    this.compiler = TaskUtils.getCompiler();
    log("Will use compiler " + this.compiler, 3);
    if (this.compileClasspath == null) {
      this.compileClasspath = (Path)Path.systemClasspath.clone();
    } else {
      this.compileClasspath.concatSystemClasspath("ignore");
    } 
    if (this.loadEar != null)
      this.compileClasspath.createPathElement().setPath(this.loadEar.getApplicationClasspath()); 
    log("Will use compilerClasspath " + this.compileClasspath, 3);
  }
  
  private void loadClasses(String paramString) {
    String[] arrayOfString = StringUtils.splitCompletely(paramString, ",");
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = arrayOfString[b].trim(); 
    HashSet hashSet = new HashSet();
    String str = null;
    try {
      for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
        str = arrayOfString[b1];
        Class clazz = TaskUtils.loadClass(arrayOfString[b1]);
        hashSet.add(clazz);
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      log("Can't load class " + str + "! Is it in your classpath?", 0);
    } 
    if (hashSet.isEmpty())
      throw new BuildException("No input class can be loaded!"); 
    this.javaClasses = new Class[hashSet.size()];
    this.javaClasses = (Class[])hashSet.toArray(this.javaClasses);
  }
  
  private boolean needToRun(File paramFile) {
    long l1 = paramFile.lastModified();
    if (l1 == 0L)
      return true; 
    long l2 = (new File(this.destDir, "types.xml")).lastModified();
    return (l1 > l2);
  }
  
  private boolean needToRun(Class[] paramArrayOfClass) {
    long l1 = 0L;
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    for (byte b = 0; b < paramArrayOfClass.length; b++) {
      Class clazz = getComponentType(paramArrayOfClass[b]);
      if (!clazz.getName().startsWith("java")) {
        String str = clazz.getName().replace('.', '/') + ".class";
        File file = new File(classLoader.getResource(str).getPath());
        if (file.lastModified() > l1)
          l1 = file.lastModified(); 
      } 
    } 
    if (l1 == 0L)
      return true; 
    long l2 = (new File(this.destDir, "types.xml")).lastModified();
    return (l1 > l2);
  }
  
  private Class getComponentType(Class paramClass) {
    if (paramClass.isArray())
      return paramClass.getComponentType(); 
    return paramClass;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\javaschema\JavaSchema.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */