/*     */ package weblogic.ant.taskdefs.webservices.javaschema;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.HashSet;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.utils.StringUtils;
/*     */ import weblogic.webservice.tools.build.BuildToolsFactory;
/*     */ import weblogic.webservice.tools.build.Component2Schema;
/*     */ import weblogic.webservice.tools.build.Java2Schema;
/*     */ import weblogic.webservice.tools.build.Schema2Java;
/*     */ import weblogic.webservice.tools.build.WSBuildException;
/*     */ import weblogic.webservice.tools.build.WSDL2Java;
/*     */ import weblogic.webservice.util.WebServiceEarFile;
/*     */ import weblogic.webservice.util.WebServiceJarException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaSchema
/*     */   extends Task
/*     */ {
/*     */   protected static boolean DEBUG = false;
/*     */   private static final String LIST_DELIM = ",";
/*     */   private File destDir;
/*     */   private String schemaFile;
/*     */   private File earClasspath;
/*     */   private String wsdlURI;
/*     */   private String javaTypes;
/*     */   private String javaComponents;
/*     */   private File typeMappingFile;
/*     */   private String targetNSURI;
/*     */   private String packageBase;
/*     */   private String packageName;
/*     */   private String encoding;
/*     */   private boolean keepGenerated = false;
/*     */   private boolean generatePublicFields = false;
/*     */   private boolean overwrite = true;
/*     */   private Class[] javaClasses;
/*     */   private FileInputStream typeMappingStream;
/*     */   private InputStream schemaFileStream;
/*     */   private String compiler;
/*     */   private Path compileClasspath;
/*  67 */   private WebServiceEarFile loadEar = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void setTypemappingfile(File paramFile) { this.typeMappingFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  77 */   public void setSchemaFile(String paramString) { this.schemaFile = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void setWsdl(String paramString) { this.wsdlURI = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void setJavaTypes(String paramString) { this.javaTypes = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void setJavaComponents(String paramString) { this.javaComponents = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public void setDestDir(File paramFile) { this.destDir = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void setTargetnamespace(String paramString) { this.targetNSURI = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void setPackageName(String paramString) { this.packageName = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void setPackageBase(String paramString) { this.packageBase = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void setEncoding(String paramString) { this.encoding = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void setGeneratePublicFields(boolean paramBoolean) { this.generatePublicFields = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void setEarClasspath(File paramFile) { this.earClasspath = paramFile; }
/*     */ 
/*     */   
/*     */   public void setClasspath(Path paramPath) {
/* 129 */     if (this.compileClasspath == null) {
/* 130 */       this.compileClasspath = paramPath;
/*     */     } else {
/* 132 */       this.compileClasspath.append(paramPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 137 */   public Path getClasspath() { return this.compileClasspath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/* 144 */     if (this.compileClasspath == null) {
/* 145 */       this.compileClasspath = new Path(this.project);
/*     */     }
/* 147 */     return this.compileClasspath.createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
/*     */ 
/*     */   
/*     */   public void execute() throws BuildException {
/* 158 */     validateAttribute();
/*     */     
/* 160 */     TaskUtils.setAntProject(getProject());
/*     */     
/* 162 */     setupCompiler();
/*     */     
/* 164 */     classLoader = TaskUtils.setClasspath(this.compileClasspath.toString());
/*     */     
/*     */     try {
/* 167 */       if (this.javaComponents != null) {
/* 168 */         if (this.wsdlURI != null || this.javaTypes != null || this.schemaFile != null) {
/* 169 */           throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set");
/*     */         }
/*     */         
/* 172 */         doComponent2Schema();
/* 173 */       } else if (this.wsdlURI != null) {
/* 174 */         if (this.javaComponents != null || this.javaTypes != null || this.schemaFile != null) {
/* 175 */           throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set");
/*     */         }
/*     */         
/* 178 */         doWSDL2Java();
/* 179 */       } else if (this.javaTypes != null) {
/* 180 */         if (this.wsdlURI != null || this.javaComponents != null || this.schemaFile != null) {
/* 181 */           throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set");
/*     */         }
/*     */         
/* 184 */         doJava2Schema();
/*     */       } else {
/* 186 */         if (this.wsdlURI != null || this.javaTypes != null || this.javaComponents != null) {
/* 187 */           throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set");
/*     */         }
/*     */         
/* 190 */         doSchema2Java();
/*     */       } 
/* 192 */     } catch (IOException iOException) {
/* 193 */       iOException.printStackTrace();
/* 194 */       throw new BuildException(iOException);
/* 195 */     } catch (WSBuildException wSBuildException) {
/* 196 */       if (wSBuildException.getNested() != null) {
/* 197 */         wSBuildException.getNested().printStackTrace(System.out);
/*     */       }
/* 199 */       throw new BuildException(wSBuildException);
/* 200 */     } catch (BuildException buildException) {
/* 201 */       throw buildException;
/* 202 */     } catch (RuntimeException runtimeException) {
/* 203 */       runtimeException.printStackTrace();
/* 204 */       throw new BuildException(runtimeException);
/*     */     } finally {
/* 206 */       TaskUtils.setClassLoader(classLoader);
/*     */       
/*     */       try {
/* 209 */         if (this.schemaFileStream != null) this.schemaFileStream.close(); 
/* 210 */         if (this.typeMappingStream != null) this.typeMappingStream.close(); 
/* 211 */       } catch (IOException iOException) {}
/*     */       
/*     */       try {
/* 214 */         if (this.loadEar != null) this.loadEar.remove(); 
/* 215 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateAttribute() throws BuildException {
/* 220 */     if (this.destDir == null) {
/* 221 */       throw new BuildException("The destDir attribute must be set");
/*     */     }
/*     */     
/* 224 */     if (this.destDir.exists()) {
/* 225 */       if (this.destDir.isFile()) {
/* 226 */         throw new BuildException("destDir can't be a file.");
/*     */       }
/*     */     } else {
/* 229 */       this.destDir.mkdirs();
/*     */     } 
/*     */     
/* 232 */     if (this.schemaFile == null && this.javaTypes == null && this.javaComponents == null && this.wsdlURI == null)
/*     */     {
/* 234 */       throw new BuildException("One and only one of javaTypes, javaComponents, schemaFile and wsdlURI attributes must be set");
/*     */     }
/*     */ 
/*     */     
/* 238 */     if (this.packageName != null && this.packageBase != null) {
/* 239 */       throw new BuildException("Can't specify both packageName and packageBase.");
/*     */     }
/*     */ 
/*     */     
/* 243 */     if (this.encoding != null) {
/* 244 */       if (this.javaTypes == null && this.javaComponents == null) {
/* 245 */         throw new BuildException("Encoding can only be specifed with javaTypes or javaComponents.");
/*     */       }
/*     */ 
/*     */       
/* 249 */       if ("soap".equals(this.encoding) && !"literal".equals(this.encoding)) {
/* 250 */         throw new BuildException("Encoding can only be \"soap\" or \"literal\".");
/*     */       }
/*     */     } 
/*     */     
/* 254 */     if (this.typeMappingFile != null && 
/* 255 */       !this.typeMappingFile.exists()) {
/* 256 */       log("typeMappingFile " + this.typeMappingFile.getAbsolutePath() + " doesn't exits!. Ignored", 0);
/*     */       
/* 258 */       this.typeMappingFile = null;
/*     */     } 
/*     */ 
/*     */     
/* 262 */     if (this.earClasspath != null && this.earClasspath.exists()) {
/* 263 */       String str = System.getProperty("java.io.tmpdir");
/* 264 */       if (str == null) str = ".";
/*     */       
/*     */       try {
/* 267 */         this.loadEar = new WebServiceEarFile(new File(str), this.earClasspath, "junk");
/* 268 */       } catch (IOException iOException) {
/* 269 */         throw new BuildException("Failed to access " + this.earClasspath, iOException);
/* 270 */       } catch (WebServiceJarException webServiceJarException) {
/* 271 */         throw new BuildException("Failed to access " + this.earClasspath, webServiceJarException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doJava2Schema() throws BuildException {
/* 277 */     loadClasses(this.javaTypes);
/*     */     
/* 279 */     if (!this.overwrite && !needToRun(this.javaClasses)) {
/* 280 */       log("Types.xml file is up to date.", 3);
/*     */       
/*     */       return;
/*     */     } 
/* 284 */     log("Autotyping for javaTypes " + this.javaTypes);
/*     */     
/* 286 */     Java2Schema java2Schema = BuildToolsFactory.getInstance().getJava2Schema();
/* 287 */     java2Schema.setJavaClassTypes(this.javaClasses);
/* 288 */     java2Schema.setDestDir(this.destDir);
/* 289 */     java2Schema.setPackageName(this.packageName);
/* 290 */     java2Schema.setPackageBase(this.packageBase);
/* 291 */     java2Schema.setEncoding(this.encoding);
/* 292 */     java2Schema.setKeepGenerated(this.keepGenerated);
/* 293 */     java2Schema.setCompiler(this.compiler);
/* 294 */     java2Schema.setCompilerClasspath(this.compileClasspath.toString());
/* 295 */     java2Schema.setLogger(new BuildTaskLogger(this));
/*     */     
/* 297 */     if (this.typeMappingFile != null) {
/* 298 */       this.typeMappingStream = new FileInputStream(this.typeMappingFile);
/* 299 */       java2Schema.setInitTypeMapping(this.typeMappingStream);
/*     */     } 
/*     */     
/* 302 */     java2Schema.run();
/*     */   }
/*     */   
/*     */   private void doSchema2Java() throws BuildException {
/* 306 */     String str = TaskUtils.getResourceURL(this.schemaFile);
/*     */     
/* 308 */     if (!this.overwrite) {
/* 309 */       File file = TaskUtils.getFileFromWSDLURI(str);
/*     */       
/* 311 */       if (file != null && !needToRun(file)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 316 */     log("Autotyping for schemaFile " + this.schemaFile);
/*     */     
/* 318 */     Schema2Java schema2Java = BuildToolsFactory.getInstance().getSchema2Java();
/* 319 */     this.schemaFileStream = (new URL(str)).openStream();
/* 320 */     schema2Java.setSchemaStream(this.schemaFileStream);
/* 321 */     schema2Java.setSchemaURL(str);
/* 322 */     schema2Java.setDestDir(this.destDir);
/* 323 */     schema2Java.setPackageName(this.packageName);
/* 324 */     schema2Java.setPackageBase(this.packageBase);
/* 325 */     schema2Java.setKeepGenerated(this.keepGenerated);
/* 326 */     schema2Java.setGeneratePublicFields(this.generatePublicFields);
/* 327 */     schema2Java.setCompiler(this.compiler);
/* 328 */     schema2Java.setCompilerClasspath(this.compileClasspath.toString());
/* 329 */     schema2Java.setLogger(new BuildTaskLogger(this));
/*     */     
/* 331 */     if (this.typeMappingFile != null) {
/* 332 */       this.typeMappingStream = new FileInputStream(this.typeMappingFile);
/* 333 */       schema2Java.setInitTypeMapping(this.typeMappingStream);
/*     */     } 
/*     */     
/* 336 */     schema2Java.run();
/*     */   }
/*     */   
/*     */   private void doComponent2Schema() throws BuildException {
/* 340 */     loadClasses(this.javaComponents);
/*     */     
/* 342 */     if (!this.overwrite && !needToRun(this.javaClasses)) {
/* 343 */       log("Types.xml file is up to date.", 3);
/*     */       
/*     */       return;
/*     */     } 
/* 347 */     log("Autotyping for javaComponents " + this.javaComponents);
/*     */     
/* 349 */     Component2Schema component2Schema = BuildToolsFactory.getInstance().getComponent2Schema();
/* 350 */     component2Schema.setComponents(this.javaClasses);
/* 351 */     component2Schema.setDestDir(this.destDir);
/* 352 */     component2Schema.setPackageName(this.packageName);
/* 353 */     component2Schema.setPackageBase(this.packageBase);
/* 354 */     component2Schema.setEncoding(this.encoding);
/* 355 */     component2Schema.setKeepGenerated(this.keepGenerated);
/* 356 */     component2Schema.setCompiler(this.compiler);
/* 357 */     component2Schema.setCompilerClasspath(this.compileClasspath.toString());
/* 358 */     component2Schema.setLogger(new BuildTaskLogger(this));
/*     */     
/* 360 */     if (this.typeMappingFile != null) {
/* 361 */       this.typeMappingStream = new FileInputStream(this.typeMappingFile);
/* 362 */       component2Schema.setInitTypeMapping(this.typeMappingStream);
/*     */     } 
/*     */     
/* 365 */     component2Schema.run();
/*     */   }
/*     */   
/*     */   private void doWSDL2Java() throws BuildException {
/* 369 */     String str = TaskUtils.getResourceURL(this.wsdlURI);
/*     */     
/* 371 */     if (!this.overwrite) {
/* 372 */       File file = TaskUtils.getFileFromWSDLURI(str);
/*     */       
/* 374 */       if (file != null && !needToRun(file)) {
/* 375 */         log("Types.xml file is up to date.", 3);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 380 */     log("Autotyping for wsdl " + this.wsdlURI);
/*     */     
/* 382 */     WSDL2Java wSDL2Java = BuildToolsFactory.getInstance().getWSDL2Java();
/* 383 */     wSDL2Java.setWsdlUrl(str);
/* 384 */     wSDL2Java.setDestDir(this.destDir);
/* 385 */     wSDL2Java.setPackageName(this.packageName);
/* 386 */     wSDL2Java.setPackageBase(this.packageBase);
/* 387 */     wSDL2Java.setKeepGenerated(this.keepGenerated);
/* 388 */     wSDL2Java.setGeneratePublicFields(this.generatePublicFields);
/* 389 */     wSDL2Java.setCompiler(this.compiler);
/* 390 */     wSDL2Java.setCompilerClasspath(this.compileClasspath.toString());
/* 391 */     wSDL2Java.setLogger(new BuildTaskLogger(this));
/*     */     
/* 393 */     if (this.typeMappingFile != null) {
/* 394 */       this.typeMappingStream = new FileInputStream(this.typeMappingFile);
/* 395 */       wSDL2Java.setInitTypeMapping(this.typeMappingStream);
/*     */     } 
/*     */     
/* 398 */     wSDL2Java.run();
/*     */   }
/*     */   
/*     */   private void setupCompiler() throws BuildException {
/* 402 */     this.compiler = TaskUtils.getCompiler();
/* 403 */     log("Will use compiler " + this.compiler, 3);
/*     */     
/* 405 */     if (this.compileClasspath == null) {
/* 406 */       this.compileClasspath = (Path)Path.systemClasspath.clone();
/*     */     } else {
/* 408 */       this.compileClasspath.concatSystemClasspath("ignore");
/*     */     } 
/*     */     
/* 411 */     if (this.loadEar != null) {
/* 412 */       this.compileClasspath.createPathElement().setPath(this.loadEar.getApplicationClasspath());
/*     */     }
/*     */ 
/*     */     
/* 416 */     log("Will use compilerClasspath " + this.compileClasspath, 3);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadClasses(String paramString) {
/* 422 */     String[] arrayOfString = StringUtils.splitCompletely(paramString, ",");
/* 423 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 424 */       arrayOfString[b] = arrayOfString[b].trim();
/*     */     }
/*     */     
/* 427 */     HashSet hashSet = new HashSet();
/*     */     
/* 429 */     String str = null;
/*     */     try {
/* 431 */       for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 432 */         str = arrayOfString[b1];
/* 433 */         Class clazz = TaskUtils.loadClass(arrayOfString[b1]);
/* 434 */         hashSet.add(clazz);
/*     */       } 
/* 436 */     } catch (ClassNotFoundException classNotFoundException) {
/* 437 */       log("Can't load class " + str + "! Is it in your classpath?", 0);
/*     */     } 
/*     */ 
/*     */     
/* 441 */     if (hashSet.isEmpty()) {
/* 442 */       throw new BuildException("No input class can be loaded!");
/*     */     }
/*     */     
/* 445 */     this.javaClasses = new Class[hashSet.size()];
/* 446 */     this.javaClasses = (Class[])hashSet.toArray(this.javaClasses);
/*     */   }
/*     */   
/*     */   private boolean needToRun(File paramFile) {
/* 450 */     long l1 = paramFile.lastModified();
/* 451 */     if (l1 == 0L) return true;
/*     */     
/* 453 */     long l2 = (new File(this.destDir, "types.xml")).lastModified();
/*     */     
/* 455 */     return (l1 > l2);
/*     */   }
/*     */   
/*     */   private boolean needToRun(Class[] paramArrayOfClass) {
/* 459 */     long l1 = 0L;
/* 460 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     
/* 462 */     for (byte b = 0; b < paramArrayOfClass.length; b++) {
/* 463 */       Class clazz = getComponentType(paramArrayOfClass[b]);
/* 464 */       if (!clazz.getName().startsWith("java")) {
/* 465 */         String str = clazz.getName().replace('.', '/') + ".class";
/* 466 */         File file = new File(classLoader.getResource(str).getPath());
/* 467 */         if (file.lastModified() > l1) {
/* 468 */           l1 = file.lastModified();
/*     */         }
/*     */       } 
/*     */     } 
/* 472 */     if (l1 == 0L) return true;
/*     */     
/* 474 */     long l2 = (new File(this.destDir, "types.xml")).lastModified();
/*     */     
/* 476 */     return (l1 > l2);
/*     */   }
/*     */   
/*     */   private Class getComponentType(Class paramClass) {
/* 480 */     if (paramClass.isArray()) {
/* 481 */       return paramClass.getComponentType();
/*     */     }
/* 483 */     return paramClass;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\javaschema\JavaSchema.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */