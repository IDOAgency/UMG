/*     */ package weblogic.ant.taskdefs.webservices;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Project;
/*     */ import org.apache.tools.ant.Task;
/*     */ import weblogic.management.descriptors.webservice.TypeMappingEntryMBean;
/*     */ import weblogic.management.descriptors.webservice.TypeMappingMBean;
/*     */ import weblogic.utils.classloaders.ClasspathClassLoader;
/*     */ import weblogic.utils.classloaders.GenericClassLoader;
/*     */ import weblogic.webservice.wsdl.DefinitionFactory;
/*     */ import weblogic.xml.schema.binding.ClassLoadingUtils;
/*     */ import weblogic.xml.stream.BufferedXMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskUtils
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*  43 */   private static Project currentAntProject = null;
/*     */   static  {
/*  45 */     new String[8][0] = "byte"; new String[8][1] = "int"; new String[8][2] = "short"; new String[8][3] = "long"; new String[8][4] = "boolean"; new String[8][5] = "double"; new String[8][6] = "char"; new String[8][7] = "float"; PRIMITIVES = new HashSet(Arrays.asList((Object[])new String[8]));
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Set PRIMITIVES;
/*     */   private static final int BUFFER_SIZE = 1024;
/*     */   
/*  52 */   public static Project getAntProject() { return currentAntProject; }
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static void setAntProject(Project paramProject) { currentAntProject = paramProject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BufferedXMLInputStream getXMLInputStream(String paramString) throws XMLStreamException, IOException {
/*  63 */     String str = getResourceURL(paramString);
/*     */     
/*  65 */     DefinitionFactory definitionFactory = new DefinitionFactory();
/*  66 */     XMLNode xMLNode = definitionFactory.createDefinition(str);
/*     */     
/*  68 */     XMLInputStreamFactory xMLInputStreamFactory = XMLInputStreamFactory.newInstance();
/*  69 */     return xMLInputStreamFactory.newBufferedInputStream(xMLNode.stream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getResourceURL(String paramString) throws MalformedURLException {
/*  76 */     boolean bool = false;
/*     */ 
/*     */     
/*     */     try {
/*  80 */       URL uRL1 = new URL(paramString);
/*  81 */       if (uRL1 != null) return uRL1.toString(); 
/*  82 */     } catch (MalformedURLException malformedURLException) {}
/*     */ 
/*     */     
/*  85 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*  86 */     if (classLoader == null) {
/*  87 */       classLoader = TaskUtils.class.getClassLoader();
/*     */     }
/*     */     
/*  90 */     URL uRL = classLoader.getResource(paramString);
/*  91 */     if (uRL != null) return uRL.toString();
/*     */ 
/*     */     
/*  94 */     File file = currentAntProject.resolveFile(paramString);
/*  95 */     if (file != null && file.exists()) {
/*  96 */       return file.toURL().toString();
/*     */     }
/*     */     
/*  99 */     String str = "Can't locate resource '" + paramString + "'.";
/*     */     
/* 101 */     throw new MalformedURLException(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getFileFromWSDLURI(String paramString) {
/* 108 */     String str = null;
/*     */     
/*     */     try {
/* 111 */       str = getResourceURL(paramString);
/* 112 */     } catch (MalformedURLException malformedURLException) {
/* 113 */       return null;
/*     */     } 
/*     */     
/* 116 */     if (str.startsWith("file:")) {
/* 117 */       File file = null;
/*     */       
/*     */       try {
/* 120 */         file = new File((new URL(str)).getFile());
/* 121 */       } catch (MalformedURLException malformedURLException) {
/* 122 */         throw new BuildException("Failed to construct URL from " + str + "." + " This should never happen.");
/*     */       } 
/*     */ 
/*     */       
/* 126 */       return file;
/*     */     } 
/*     */     
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader setClasspath(String paramString) {
/* 138 */     ClassLoader classLoader = TaskUtils.class.getClassLoader();
/* 139 */     ClasspathClassLoader classpathClassLoader = new ClasspathClassLoader(paramString, classLoader);
/* 140 */     return setClassLoader(classpathClassLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassLoader setClassLoader(ClassLoader paramClassLoader) {
/* 148 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     
/* 150 */     if (classLoader instanceof GenericClassLoader) {
/* 151 */       GenericClassLoader genericClassLoader = (GenericClassLoader)classLoader;
/* 152 */       genericClassLoader.close();
/*     */     } 
/*     */     
/* 155 */     Thread.currentThread().setContextClassLoader(paramClassLoader);
/* 156 */     return classLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public static ClassLoader getClassLoader() { return Thread.currentThread().getContextClassLoader(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class loadClass(String paramString) throws ClassNotFoundException {
/* 169 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 170 */     if (classLoader == null) {
/* 171 */       classLoader = TaskUtils.class.getClassLoader();
/*     */     }
/*     */     
/* 174 */     if (classLoader == null) {
/* 175 */       return Class.forName(paramString);
/*     */     }
/* 177 */     return ClassLoadingUtils.loadClass(paramString, classLoader);
/*     */   }
/*     */ 
/*     */   
/*     */   public static InputStream loadResource(String paramString) {
/* 182 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 183 */     if (classLoader == null) {
/* 184 */       classLoader = TaskUtils.class.getClassLoader();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     return classLoader.getResourceAsStream(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Task linkToTask(Task paramTask1, Task paramTask2) {
/* 200 */     paramTask1.setProject(paramTask2.getProject());
/* 201 */     paramTask1.setTaskName(paramTask2.getTaskName());
/* 202 */     return paramTask1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFileName(String paramString) {
/* 210 */     if (paramString == null || paramString.length() == 0) return false; 
/* 211 */     File file = new File(paramString);
/* 212 */     return file.getName().equals(file.getPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeClass(String paramString, File paramFile) {
/* 229 */     int i = paramString.indexOf("[");
/* 230 */     if (i > 0) {
/* 231 */       if (i == 0) {
/* 232 */         paramString = paramString.substring(0, paramString.indexOf(";"));
/*     */       } else {
/* 234 */         paramString = paramString.substring(0, i);
/*     */       } 
/*     */     }
/* 237 */     if (PRIMITIVES.contains(paramString) || paramString.startsWith("java.") || paramString.startsWith("javax.")) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 247 */     String str = "/" + paramString.replace('.', '/') + ".class";
/*     */     
/* 249 */     File file = new File(paramFile, str);
/* 250 */     if (!file.exists()) {
/* 251 */       file.getParentFile().mkdirs();
/*     */       
/* 253 */       inputStream = null;
/* 254 */       bufferedOutputStream = null;
/* 255 */       fileOutputStream = null;
/*     */       
/* 257 */       try { inputStream = loadResource(str);
/* 258 */         if (inputStream == null) {
/* 259 */           throw new BuildException("Could not load resource " + str + ". Is it in the classpath?");
/*     */         }
/*     */ 
/*     */         
/* 263 */         fileOutputStream = new FileOutputStream(file);
/* 264 */         bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
/* 265 */         arrayOfByte = new byte[1024];
/* 266 */         int j = 0;
/* 267 */         int k = 0;
/* 268 */         while ((k = inputStream.read(arrayOfByte, 0, 1024)) != -1) {
/* 269 */           bufferedOutputStream.write(arrayOfByte, 0, k);
/* 270 */           j += k;
/*     */         }
/*     */          }
/* 273 */       catch (IOException iOException)
/* 274 */       { throw new BuildException("Could not copy class file to working war", iOException); }
/*     */       finally { 
/* 276 */         try { inputStream.close(); } catch (Throwable throwable) {} 
/* 277 */         try { bufferedOutputStream.close(); } catch (Throwable throwable) {} 
/* 278 */         try { fileOutputStream.close(); } catch (Throwable throwable) {} }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyClasses(String[] paramArrayOfString, TypeMappingMBean paramTypeMappingMBean, File paramFile) {
/* 291 */     if (paramArrayOfString != null) {
/* 292 */       for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 293 */         writeClass(paramArrayOfString[b], paramFile);
/*     */       }
/*     */     }
/* 296 */     if (paramTypeMappingMBean != null) {
/* 297 */       TypeMappingEntryMBean[] arrayOfTypeMappingEntryMBean = paramTypeMappingMBean.getTypeMappingEntries();
/* 298 */       if (arrayOfTypeMappingEntryMBean != null) {
/* 299 */         for (byte b = 0; b < arrayOfTypeMappingEntryMBean.length; b++) {
/* 300 */           String str = arrayOfTypeMappingEntryMBean[b].getClassName();
/* 301 */           if (!str.startsWith("weblogic.xml.schema.binding.internal.builtin")) {
/* 302 */             writeClass(str, paramFile);
/*     */           }
/*     */           
/* 305 */           str = arrayOfTypeMappingEntryMBean[b].getSerializerName();
/* 306 */           if (!str.startsWith("weblogic.xml.schema.binding.internal.builtin")) {
/* 307 */             writeClass(str, paramFile);
/*     */           }
/*     */           
/* 310 */           str = arrayOfTypeMappingEntryMBean[b].getDeserializerName();
/* 311 */           if (!str.startsWith("weblogic.xml.schema.binding.internal.builtin")) {
/* 312 */             writeClass(str, paramFile);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getCompiler() {
/* 321 */     String str1, str2 = currentAntProject.getProperty("build.compiler");
/* 322 */     if (str2 != null) {
/* 323 */       if (str2.equals("modern") || str2.equals("classic") || str2.startsWith("javac")) {
/*     */ 
/*     */         
/* 326 */         str1 = "javac";
/* 327 */       } else if (str2.equals("sj") || str2.equals("gcj") || str2.equals("jvc")) {
/*     */ 
/*     */         
/* 330 */         str1 = str2;
/*     */       } else {
/* 332 */         currentAntProject.log("Unknown compiler " + str2 + ", will use javac", 1);
/* 333 */         str1 = "javac";
/*     */       } 
/*     */     } else {
/* 336 */       str1 = "javac";
/*     */     } 
/* 338 */     return str1;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\TaskUtils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */