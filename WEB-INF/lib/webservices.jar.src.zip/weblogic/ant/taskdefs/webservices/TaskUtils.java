package weblogic.ant.taskdefs.webservices;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import weblogic.management.descriptors.webservice.TypeMappingEntryMBean;
import weblogic.management.descriptors.webservice.TypeMappingMBean;
import weblogic.utils.classloaders.ClasspathClassLoader;
import weblogic.utils.classloaders.GenericClassLoader;
import weblogic.webservice.wsdl.DefinitionFactory;
import weblogic.xml.schema.binding.ClassLoadingUtils;
import weblogic.xml.stream.BufferedXMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;

public class TaskUtils {
  private static final boolean DEBUG = false;
  
  private static Project currentAntProject = null;
  
  private static final Set PRIMITIVES;
  
  private static final int BUFFER_SIZE = 1024;
  
  static  {
    new String[8][0] = "byte";
    new String[8][1] = "int";
    new String[8][2] = "short";
    new String[8][3] = "long";
    new String[8][4] = "boolean";
    new String[8][5] = "double";
    new String[8][6] = "char";
    new String[8][7] = "float";
    PRIMITIVES = new HashSet(Arrays.asList((Object[])new String[8]));
  }
  
  public static Project getAntProject() { return currentAntProject; }
  
  public static void setAntProject(Project paramProject) { currentAntProject = paramProject; }
  
  public static BufferedXMLInputStream getXMLInputStream(String paramString) throws XMLStreamException, IOException {
    String str = getResourceURL(paramString);
    DefinitionFactory definitionFactory = new DefinitionFactory();
    XMLNode xMLNode = definitionFactory.createDefinition(str);
    XMLInputStreamFactory xMLInputStreamFactory = XMLInputStreamFactory.newInstance();
    return xMLInputStreamFactory.newBufferedInputStream(xMLNode.stream());
  }
  
  public static String getResourceURL(String paramString) throws MalformedURLException {
    boolean bool = false;
    try {
      URL uRL1 = new URL(paramString);
      if (uRL1 != null)
        return uRL1.toString(); 
    } catch (MalformedURLException malformedURLException) {}
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = TaskUtils.class.getClassLoader(); 
    URL uRL = classLoader.getResource(paramString);
    if (uRL != null)
      return uRL.toString(); 
    File file = currentAntProject.resolveFile(paramString);
    if (file != null && file.exists())
      return file.toURL().toString(); 
    String str = "Can't locate resource '" + paramString + "'.";
    throw new MalformedURLException(str);
  }
  
  public static File getFileFromWSDLURI(String paramString) {
    String str = null;
    try {
      str = getResourceURL(paramString);
    } catch (MalformedURLException malformedURLException) {
      return null;
    } 
    if (str.startsWith("file:")) {
      File file = null;
      try {
        file = new File((new URL(str)).getFile());
      } catch (MalformedURLException malformedURLException) {
        throw new BuildException("Failed to construct URL from " + str + "." + " This should never happen.");
      } 
      return file;
    } 
    return null;
  }
  
  public static ClassLoader setClasspath(String paramString) {
    ClassLoader classLoader = TaskUtils.class.getClassLoader();
    ClasspathClassLoader classpathClassLoader = new ClasspathClassLoader(paramString, classLoader);
    return setClassLoader(classpathClassLoader);
  }
  
  public static ClassLoader setClassLoader(ClassLoader paramClassLoader) {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader instanceof GenericClassLoader) {
      GenericClassLoader genericClassLoader = (GenericClassLoader)classLoader;
      genericClassLoader.close();
    } 
    Thread.currentThread().setContextClassLoader(paramClassLoader);
    return classLoader;
  }
  
  public static ClassLoader getClassLoader() { return Thread.currentThread().getContextClassLoader(); }
  
  public static Class loadClass(String paramString) throws ClassNotFoundException {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = TaskUtils.class.getClassLoader(); 
    if (classLoader == null)
      return Class.forName(paramString); 
    return ClassLoadingUtils.loadClass(paramString, classLoader);
  }
  
  public static InputStream loadResource(String paramString) {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = TaskUtils.class.getClassLoader(); 
    return classLoader.getResourceAsStream(paramString);
  }
  
  public static Task linkToTask(Task paramTask1, Task paramTask2) {
    paramTask1.setProject(paramTask2.getProject());
    paramTask1.setTaskName(paramTask2.getTaskName());
    return paramTask1;
  }
  
  public static boolean isFileName(String paramString) {
    if (paramString == null || paramString.length() == 0)
      return false; 
    File file = new File(paramString);
    return file.getName().equals(file.getPath());
  }
  
  public static void writeClass(String paramString, File paramFile) {
    int i = paramString.indexOf("[");
    if (i > 0)
      if (i == 0) {
        paramString = paramString.substring(0, paramString.indexOf(";"));
      } else {
        paramString = paramString.substring(0, i);
      }  
    if (PRIMITIVES.contains(paramString) || paramString.startsWith("java.") || paramString.startsWith("javax."))
      return; 
    String str = "/" + paramString.replace('.', '/') + ".class";
    File file = new File(paramFile, str);
    if (!file.exists()) {
      file.getParentFile().mkdirs();
      inputStream = null;
      bufferedOutputStream = null;
      fileOutputStream = null;
      try {
        inputStream = loadResource(str);
        if (inputStream == null)
          throw new BuildException("Could not load resource " + str + ". Is it in the classpath?"); 
        fileOutputStream = new FileOutputStream(file);
        bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
        arrayOfByte = new byte[1024];
        int j = 0;
        int k = 0;
        while ((k = inputStream.read(arrayOfByte, 0, 1024)) != -1) {
          bufferedOutputStream.write(arrayOfByte, 0, k);
          j += k;
        } 
      } catch (IOException iOException) {
        throw new BuildException("Could not copy class file to working war", iOException);
      } finally {
        try {
          inputStream.close();
        } catch (Throwable throwable) {}
        try {
          bufferedOutputStream.close();
        } catch (Throwable throwable) {}
        try {
          fileOutputStream.close();
        } catch (Throwable throwable) {}
      } 
    } 
  }
  
  public static void copyClasses(String[] paramArrayOfString, TypeMappingMBean paramTypeMappingMBean, File paramFile) {
    if (paramArrayOfString != null)
      for (byte b = 0; b < paramArrayOfString.length; b++)
        writeClass(paramArrayOfString[b], paramFile);  
    if (paramTypeMappingMBean != null) {
      TypeMappingEntryMBean[] arrayOfTypeMappingEntryMBean = paramTypeMappingMBean.getTypeMappingEntries();
      if (arrayOfTypeMappingEntryMBean != null)
        for (byte b = 0; b < arrayOfTypeMappingEntryMBean.length; b++) {
          String str = arrayOfTypeMappingEntryMBean[b].getClassName();
          if (!str.startsWith("weblogic.xml.schema.binding.internal.builtin"))
            writeClass(str, paramFile); 
          str = arrayOfTypeMappingEntryMBean[b].getSerializerName();
          if (!str.startsWith("weblogic.xml.schema.binding.internal.builtin"))
            writeClass(str, paramFile); 
          str = arrayOfTypeMappingEntryMBean[b].getDeserializerName();
          if (!str.startsWith("weblogic.xml.schema.binding.internal.builtin"))
            writeClass(str, paramFile); 
        }  
    } 
  }
  
  public static String getCompiler() {
    String str1, str2 = currentAntProject.getProperty("build.compiler");
    if (str2 != null) {
      if (str2.equals("modern") || str2.equals("classic") || str2.startsWith("javac")) {
        str1 = "javac";
      } else if (str2.equals("sj") || str2.equals("gcj") || str2.equals("jvc")) {
        str1 = str2;
      } else {
        currentAntProject.log("Unknown compiler " + str2 + ", will use javac", 1);
        str1 = "javac";
      } 
    } else {
      str1 = "javac";
    } 
    return str1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\TaskUtils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */