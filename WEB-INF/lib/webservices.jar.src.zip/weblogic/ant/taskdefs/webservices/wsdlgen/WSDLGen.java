/*     */ package weblogic.ant.taskdefs.webservices.wsdlgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.webservice.tools.build.BuildToolsFactory;
/*     */ import weblogic.webservice.tools.build.WSBuildException;
/*     */ import weblogic.webservice.tools.build.WSDLGen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSDLGen
/*     */   extends Task
/*     */ {
/*     */   private File ear;
/*     */   private String warName;
/*     */   private String serviceName;
/*     */   private File wsdlFile;
/*     */   private boolean overwrite;
/*     */   private String defaultEndpoint;
/*     */   private Path compileClasspath;
/*     */   
/*  40 */   public void setEar(File paramFile) { this.ear = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  44 */   public void setWarName(String paramString) { this.warName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  48 */   public void setServiceName(String paramString) { this.serviceName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  52 */   public void setWsdlFile(File paramFile) { this.wsdlFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  56 */   public void setDefaultEndpoint(String paramString) { this.defaultEndpoint = paramString; }
/*     */ 
/*     */   
/*     */   public void setClasspath(Path paramPath) {
/*  60 */     if (this.compileClasspath == null) {
/*  61 */       this.compileClasspath = paramPath;
/*     */     } else {
/*  63 */       this.compileClasspath.append(paramPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  68 */   public Path getClasspath() { return this.compileClasspath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/*  75 */     if (this.compileClasspath == null) {
/*  76 */       this.compileClasspath = new Path(this.project);
/*     */     }
/*  78 */     return this.compileClasspath.createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
/*     */ 
/*     */   
/*     */   public void execute() {
/*  89 */     validateAttribute();
/*     */     
/*  91 */     if (!this.overwrite && !needToRun())
/*     */       return; 
/*  93 */     log("Generating wsdl from ear " + this.ear);
/*     */     
/*     */     try {
/*  96 */       setupClasspath();
/*     */       
/*  98 */       doWSDLGen();
/*  99 */     } catch (IOException iOException) {
/* 100 */       iOException.printStackTrace();
/* 101 */       throw new BuildException(iOException);
/* 102 */     } catch (WSBuildException wSBuildException) {
/* 103 */       if (wSBuildException.getNested() != null) {
/* 104 */         wSBuildException.getNested().printStackTrace();
/*     */       }
/* 106 */       throw new BuildException(wSBuildException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateAttribute() {
/* 111 */     if (this.ear == null)
/* 112 */       throw new BuildException("ear attribute must be set."); 
/* 113 */     if (!this.ear.exists()) {
/* 114 */       throw new BuildException("ear " + this.ear + " doesn't exist.");
/*     */     }
/*     */     
/* 117 */     if (this.wsdlFile == null) {
/* 118 */       throw new BuildException("wsdlFile attribute must be set.");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean needToRun() {
/* 123 */     if (!this.ear.isFile()) return true;
/*     */     
/* 125 */     long l1 = this.ear.lastModified();
/* 126 */     long l2 = this.wsdlFile.lastModified();
/*     */     
/* 128 */     return (l1 > l2);
/*     */   }
/*     */   
/*     */   private void doWSDLGen() {
/* 132 */     FileOutputStream fileOutputStream = new FileOutputStream(this.wsdlFile);
/* 133 */     printStream = new PrintStream(fileOutputStream);
/*     */     
/* 135 */     WSDLGen wSDLGen = BuildToolsFactory.getInstance().getWSDLGen();
/*     */ 
/*     */     
/* 138 */     wSDLGen.setEarFile(this.ear);
/* 139 */     wSDLGen.setWarName(this.warName);
/* 140 */     wSDLGen.setServiceName(this.serviceName);
/* 141 */     wSDLGen.setWsdlStream(printStream);
/* 142 */     wSDLGen.setServerURL(this.defaultEndpoint);
/* 143 */     wSDLGen.setLogger(new BuildTaskLogger(this));
/*     */     
/* 145 */     classLoader = TaskUtils.setClasspath(this.compileClasspath.toString());
/*     */     try {
/* 147 */       wSDLGen.run();
/*     */     } finally {
/* 149 */       printStream.close();
/* 150 */       TaskUtils.setClassLoader(classLoader);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setupClasspath() {
/* 155 */     if (this.compileClasspath == null) {
/* 156 */       this.compileClasspath = (Path)Path.systemClasspath.clone();
/*     */     } else {
/* 158 */       this.compileClasspath.concatSystemClasspath("ignore");
/*     */     } 
/*     */     
/* 161 */     log("Will use compileClasspath " + this.compileClasspath, 3);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsdlgen\WSDLGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */