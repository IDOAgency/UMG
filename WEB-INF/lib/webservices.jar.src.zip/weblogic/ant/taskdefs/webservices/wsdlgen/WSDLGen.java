package weblogic.ant.taskdefs.webservices.wsdlgen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;
import weblogic.ant.taskdefs.webservices.BuildTaskLogger;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.webservice.tools.build.BuildToolsFactory;
import weblogic.webservice.tools.build.WSBuildException;
import weblogic.webservice.tools.build.WSDLGen;

public class WSDLGen extends Task {
  private File ear;
  
  private String warName;
  
  private String serviceName;
  
  private File wsdlFile;
  
  private boolean overwrite;
  
  private String defaultEndpoint;
  
  private Path compileClasspath;
  
  public void setEar(File paramFile) { this.ear = paramFile; }
  
  public void setWarName(String paramString) { this.warName = paramString; }
  
  public void setServiceName(String paramString) { this.serviceName = paramString; }
  
  public void setWsdlFile(File paramFile) { this.wsdlFile = paramFile; }
  
  public void setDefaultEndpoint(String paramString) { this.defaultEndpoint = paramString; }
  
  public void setClasspath(Path paramPath) {
    if (this.compileClasspath == null) {
      this.compileClasspath = paramPath;
    } else {
      this.compileClasspath.append(paramPath);
    } 
  }
  
  public Path getClasspath() { return this.compileClasspath; }
  
  public Path createClasspath() {
    if (this.compileClasspath == null)
      this.compileClasspath = new Path(this.project); 
    return this.compileClasspath.createPath();
  }
  
  public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
  
  public void execute() {
    validateAttribute();
    if (!this.overwrite && !needToRun())
      return; 
    log("Generating wsdl from ear " + this.ear);
    try {
      setupClasspath();
      doWSDLGen();
    } catch (IOException iOException) {
      iOException.printStackTrace();
      throw new BuildException(iOException);
    } catch (WSBuildException wSBuildException) {
      if (wSBuildException.getNested() != null)
        wSBuildException.getNested().printStackTrace(); 
      throw new BuildException(wSBuildException);
    } 
  }
  
  private void validateAttribute() {
    if (this.ear == null)
      throw new BuildException("ear attribute must be set."); 
    if (!this.ear.exists())
      throw new BuildException("ear " + this.ear + " doesn't exist."); 
    if (this.wsdlFile == null)
      throw new BuildException("wsdlFile attribute must be set."); 
  }
  
  private boolean needToRun() {
    if (!this.ear.isFile())
      return true; 
    long l1 = this.ear.lastModified();
    long l2 = this.wsdlFile.lastModified();
    return (l1 > l2);
  }
  
  private void doWSDLGen() {
    FileOutputStream fileOutputStream = new FileOutputStream(this.wsdlFile);
    printStream = new PrintStream(fileOutputStream);
    WSDLGen wSDLGen = BuildToolsFactory.getInstance().getWSDLGen();
    wSDLGen.setEarFile(this.ear);
    wSDLGen.setWarName(this.warName);
    wSDLGen.setServiceName(this.serviceName);
    wSDLGen.setWsdlStream(printStream);
    wSDLGen.setServerURL(this.defaultEndpoint);
    wSDLGen.setLogger(new BuildTaskLogger(this));
    classLoader = TaskUtils.setClasspath(this.compileClasspath.toString());
    try {
      wSDLGen.run();
    } finally {
      printStream.close();
      TaskUtils.setClassLoader(classLoader);
    } 
  }
  
  private void setupClasspath() {
    if (this.compileClasspath == null) {
      this.compileClasspath = (Path)Path.systemClasspath.clone();
    } else {
      this.compileClasspath.concatSystemClasspath("ignore");
    } 
    log("Will use compileClasspath " + this.compileClasspath, 3);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsdlgen\WSDLGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */