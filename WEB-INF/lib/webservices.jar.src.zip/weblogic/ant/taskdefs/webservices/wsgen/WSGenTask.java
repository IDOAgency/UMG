package weblogic.ant.taskdefs.webservices.wsgen;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.taskdefs.Jar;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.ant.taskdefs.webservices.clientgen.ClientGenTask;
import weblogic.ant.taskdefs.webservices.servicegen.ServiceGenTask;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.utils.FileUtils;
import weblogic.webservice.util.WebServiceEarFile;
import weblogic.webservice.util.WebServiceJarException;
import weblogic.webservice.util.WebServiceWarFile;

public class WSGenTask extends Task {
  private static final boolean DEBUG = false;
  
  private String basepath;
  
  private String destpath;
  
  private String classpath;
  
  private String context;
  
  private String protocol = "http";
  
  private String host = "localhost";
  
  private String port = "80";
  
  private String webApp = "web-services.war";
  
  private MessageServices msgServices;
  
  private ArrayList rpcServices = new ArrayList();
  
  private ClientJar clientJar;
  
  private HashSet allServiceNames = new HashSet();
  
  public void setBasepath(String paramString) { this.basepath = paramString; }
  
  public String getBasepath() { return this.basepath; }
  
  public void setDestpath(String paramString) { this.destpath = paramString; }
  
  public String getDestpath() { return this.destpath; }
  
  public void setProtocol(String paramString) { this.protocol = paramString; }
  
  public String getProtocol() { return this.protocol; }
  
  public void setContext(String paramString) { this.context = paramString; }
  
  public String getContext() { return this.context; }
  
  public void setHost(String paramString) { this.host = paramString; }
  
  public String getHost() { return this.host; }
  
  public void setPort(String paramString) { this.port = paramString; }
  
  public String getPort() { return this.port; }
  
  public void setWebapp(String paramString) { this.webApp = paramString; }
  
  public String getWebapp() { return this.webApp; }
  
  public void setClasspath(String paramString) { this.classpath = this.project.translatePath(paramString); }
  
  public String getClassPath() { return this.classpath; }
  
  public List getRPCServices() { return this.rpcServices; }
  
  public MessageServices getMessageServices() { return this.msgServices; }
  
  public ClientJar getClientjar() { return this.clientJar; }
  
  public Object createRpcservices() {
    RPCServices rPCServices = new RPCServices(this);
    this.rpcServices.add(rPCServices);
    return rPCServices;
  }
  
  public Object createMessageservices() {
    if (this.msgServices != null)
      return this.msgServices; 
    return this.msgServices = new MessageServices(this);
  }
  
  public Object createClientjar() {
    if (this.clientJar == null)
      return this.clientJar = new ClientJar(this); 
    throw new BuildException("Only one <clientJar> element can be specified in <wsgen>.");
  }
  
  public void execute() {
    validateAttributes();
    buildMessageServices();
    buildRPCServices();
    buildClientJar();
    cleanup();
  }
  
  public void validateAttributes() {
    if (this.rpcServices.size() == 0 && this.msgServices == null)
      throw new BuildException("At lease one <rpcServices> or <messageservices> must be specified in <wsgen>"); 
    if (this.context == null)
      throw new BuildException("context attribute must be specified in <wsgen>"); 
    if (this.destpath == null)
      throw new BuildException("destpath attribute must be specified in <wsgen>"); 
    if (this.basepath != null && 
      !(new File(this.basepath)).exists())
      throw new BuildException("basepath doesn't exist."); 
    if (this.protocol != null && 
      !this.protocol.equals("http") && !this.protocol.equals("https"))
      throw new BuildException("protocol can only be \"http\" or \"https\"."); 
    if (!this.webApp.endsWith(".war"))
      throw new BuildException("webapp attribute value must end with \".war\"."); 
    for (byte b = 0; b < this.rpcServices.size(); b++)
      ((RPCServices)this.rpcServices.get(b)).validateAttributes(); 
    if (this.msgServices != null)
      this.msgServices.validateAttributes(); 
    if (this.clientJar != null)
      this.clientJar.validateAttributes(); 
  }
  
  private void buildMessageServices() {
    if (this.msgServices == null)
      return; 
    this.msgServices.buildMessageServices();
    WebServicesMBean webServicesMBean = this.msgServices.getWebServicesMBean();
    webServiceEarFile = null;
    webServiceWarFile = null;
    try {
      webServiceEarFile = new WebServiceEarFile(new File(getTempDir()), new File(this.destpath), this.webApp);
      file = webServiceEarFile.getWSWarFile();
      webServiceWarFile = new WebServiceWarFile(new File(getTempDir()), file, null);
      webServiceWarFile.writeDD(webServicesMBean);
      webServiceEarFile.createAppDescriptor(new HashSet());
      if (this.destpath.endsWith(".ear")) {
        webServiceWarFile.save();
        webServiceEarFile.save();
      } else {
        webServiceWarFile.save();
        FileUtils.copy(webServiceEarFile.getExploded(), new File(this.destpath));
      } 
    } catch (WebServiceJarException webServiceJarException) {
      throw new BuildException(webServiceJarException);
    } catch (IOException iOException) {
      throw new BuildException(iOException);
    } finally {
      try {
        webServiceWarFile.remove();
      } catch (Throwable throwable) {}
      try {
        webServiceEarFile.remove();
      } catch (Throwable throwable) {}
    } 
  }
  
  private void buildRPCServices() {
    if (this.rpcServices.size() == 0)
      return; 
    boolean bool = (this.msgServices == null);
    ServiceGenTask serviceGenTask = (ServiceGenTask)TaskUtils.linkToTask(new ServiceGenTask(), this);
    serviceGenTask.setDestear(new File(this.destpath));
    serviceGenTask.setOverwrite(bool);
    serviceGenTask.setWarName(this.webApp);
    serviceGenTask.setContextURI(this.context);
    for (byte b = 0; b < this.rpcServices.size(); b++)
      ((RPCServices)this.rpcServices.get(b)).addServices(serviceGenTask); 
    serviceGenTask.execute();
  }
  
  private void buildClientJar() {
    if (this.clientJar == null)
      return; 
    File file = null;
    try {
      file = new File(getTempDir(), this.clientJar.getPath());
      if (file.exists())
        file.delete(); 
      file.createNewFile();
      file.deleteOnExit();
    } catch (IOException iOException) {
      throw new BuildException("Could not create temporary client jar file", iOException);
    } 
    try {
      this.clientJar.addto(file);
    } catch (IOException iOException) {
      throw new BuildException("Failed to add files to clientJar.", iOException);
    } 
    Iterator iterator = this.allServiceNames.iterator();
    while (iterator.hasNext()) {
      String str = (String)iterator.next();
      ClientGenTask clientGenTask = (ClientGenTask)TaskUtils.linkToTask(new ClientGenTask(), this);
      clientGenTask.setEar(new File(this.destpath));
      clientGenTask.setWarName(this.webApp);
      clientGenTask.setPackageName(this.clientJar.getPackageName());
      clientGenTask.setServiceName(str);
      clientGenTask.setOverwrite(false);
      clientGenTask.setAutotype(true);
      clientGenTask.setClientjar(file);
      clientGenTask.execute();
    } 
    try {
      putClientJarFile(file);
    } catch (IOException iOException) {
      throw new BuildException("Failed to put clientJar to ear.", iOException);
    } 
  }
  
  private void putClientJarFile(File paramFile) throws IOException {
    File file = new File(this.destpath);
    if (file.isDirectory()) {
      File file1 = new File(file.getCanonicalPath() + File.separator + this.webApp);
      Jar jar = (Jar)TaskUtils.linkToTask(new Jar(), this);
      jar.setJarfile(file1.getCanonicalFile());
      jar.setBasedir(paramFile.getParentFile());
      jar.setIncludes(paramFile.getName());
      jar.setUpdate(true);
      jar.execute();
    } else {
      webServiceEarFile = null;
      try {
        webServiceEarFile = new WebServiceEarFile(new File(getTempDir()), new File(this.destpath), this.webApp);
        file1 = webServiceEarFile.getWSWarFile();
        Jar jar = (Jar)TaskUtils.linkToTask(new Jar(), this);
        jar.setJarfile(file1.getCanonicalFile());
        jar.setBasedir(paramFile.getParentFile());
        jar.setIncludes(paramFile.getName());
        jar.setUpdate(true);
        jar.execute();
        webServiceEarFile.save();
      } catch (WebServiceJarException webServiceJarException) {
        throw new BuildException(webServiceJarException);
      } finally {
        try {
          webServiceEarFile.remove();
        } catch (Throwable throwable) {}
      } 
    } 
  }
  
  public void addServiceName(String paramString) { this.allServiceNames.add(paramString); }
  
  public static String getTempDir() {
    String str = System.getProperty("java.io.tmpdir");
    if (str == null)
      str = "."; 
    return str;
  }
  
  private void cleanup() {
    try {
      for (byte b = 0; b < this.rpcServices.size(); b++)
        ((RPCServices)this.rpcServices.get(b)).cleanup(); 
    } catch (IOException iOException) {}
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\WSGenTask.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */