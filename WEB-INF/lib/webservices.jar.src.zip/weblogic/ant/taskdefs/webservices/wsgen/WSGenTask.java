/*     */ package weblogic.ant.taskdefs.webservices.wsgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.taskdefs.Jar;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.ant.taskdefs.webservices.clientgen.ClientGenTask;
/*     */ import weblogic.ant.taskdefs.webservices.servicegen.ServiceGenTask;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.utils.FileUtils;
/*     */ import weblogic.webservice.util.WebServiceEarFile;
/*     */ import weblogic.webservice.util.WebServiceJarException;
/*     */ import weblogic.webservice.util.WebServiceWarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSGenTask
/*     */   extends Task
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   private String basepath;
/*     */   private String destpath;
/*     */   private String classpath;
/*     */   private String context;
/*  40 */   private String protocol = "http";
/*  41 */   private String host = "localhost";
/*  42 */   private String port = "80";
/*  43 */   private String webApp = "web-services.war";
/*     */   
/*     */   private MessageServices msgServices;
/*  46 */   private ArrayList rpcServices = new ArrayList();
/*     */   private ClientJar clientJar;
/*  48 */   private HashSet allServiceNames = new HashSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public void setBasepath(String paramString) { this.basepath = paramString; }
/*  55 */   public String getBasepath() { return this.basepath; }
/*     */   
/*  57 */   public void setDestpath(String paramString) { this.destpath = paramString; }
/*  58 */   public String getDestpath() { return this.destpath; }
/*     */   
/*  60 */   public void setProtocol(String paramString) { this.protocol = paramString; }
/*  61 */   public String getProtocol() { return this.protocol; }
/*     */   
/*  63 */   public void setContext(String paramString) { this.context = paramString; }
/*  64 */   public String getContext() { return this.context; }
/*     */   
/*  66 */   public void setHost(String paramString) { this.host = paramString; }
/*  67 */   public String getHost() { return this.host; }
/*     */   
/*  69 */   public void setPort(String paramString) { this.port = paramString; }
/*  70 */   public String getPort() { return this.port; }
/*     */   
/*  72 */   public void setWebapp(String paramString) { this.webApp = paramString; }
/*  73 */   public String getWebapp() { return this.webApp; }
/*     */ 
/*     */   
/*  76 */   public void setClasspath(String paramString) { this.classpath = this.project.translatePath(paramString); }
/*     */ 
/*     */   
/*  79 */   public String getClassPath() { return this.classpath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public List getRPCServices() { return this.rpcServices; }
/*     */ 
/*     */ 
/*     */   
/*  91 */   public MessageServices getMessageServices() { return this.msgServices; }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public ClientJar getClientjar() { return this.clientJar; }
/*     */ 
/*     */   
/*     */   public Object createRpcservices() {
/*  99 */     RPCServices rPCServices = new RPCServices(this);
/* 100 */     this.rpcServices.add(rPCServices);
/* 101 */     return rPCServices;
/*     */   }
/*     */   
/*     */   public Object createMessageservices() {
/* 105 */     if (this.msgServices != null) return this.msgServices;
/*     */     
/* 107 */     return this.msgServices = new MessageServices(this);
/*     */   }
/*     */   
/*     */   public Object createClientjar() {
/* 111 */     if (this.clientJar == null) {
/* 112 */       return this.clientJar = new ClientJar(this);
/*     */     }
/* 114 */     throw new BuildException("Only one <clientJar> element can be specified in <wsgen>.");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute() {
/* 120 */     validateAttributes();
/*     */     
/* 122 */     buildMessageServices();
/* 123 */     buildRPCServices();
/* 124 */     buildClientJar();
/*     */     
/* 126 */     cleanup();
/*     */   }
/*     */ 
/*     */   
/*     */   public void validateAttributes() {
/* 131 */     if (this.rpcServices.size() == 0 && this.msgServices == null) {
/* 132 */       throw new BuildException("At lease one <rpcServices> or <messageservices> must be specified in <wsgen>");
/*     */     }
/* 134 */     if (this.context == null) {
/* 135 */       throw new BuildException("context attribute must be specified in <wsgen>");
/*     */     }
/* 137 */     if (this.destpath == null) {
/* 138 */       throw new BuildException("destpath attribute must be specified in <wsgen>");
/*     */     }
/*     */     
/* 141 */     if (this.basepath != null && 
/* 142 */       !(new File(this.basepath)).exists()) {
/* 143 */       throw new BuildException("basepath doesn't exist.");
/*     */     }
/*     */     
/* 146 */     if (this.protocol != null && 
/* 147 */       !this.protocol.equals("http") && !this.protocol.equals("https")) {
/* 148 */       throw new BuildException("protocol can only be \"http\" or \"https\".");
/*     */     }
/*     */     
/* 151 */     if (!this.webApp.endsWith(".war")) {
/* 152 */       throw new BuildException("webapp attribute value must end with \".war\".");
/*     */     }
/*     */     
/* 155 */     for (byte b = 0; b < this.rpcServices.size(); b++) {
/* 156 */       ((RPCServices)this.rpcServices.get(b)).validateAttributes();
/*     */     }
/*     */     
/* 159 */     if (this.msgServices != null) this.msgServices.validateAttributes();
/*     */     
/* 161 */     if (this.clientJar != null) this.clientJar.validateAttributes(); 
/*     */   }
/*     */   
/*     */   private void buildMessageServices() {
/* 165 */     if (this.msgServices == null)
/*     */       return; 
/* 167 */     this.msgServices.buildMessageServices();
/* 168 */     WebServicesMBean webServicesMBean = this.msgServices.getWebServicesMBean();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     webServiceEarFile = null;
/* 178 */     webServiceWarFile = null;
/*     */     
/* 180 */     try { webServiceEarFile = new WebServiceEarFile(new File(getTempDir()), new File(this.destpath), this.webApp);
/* 181 */       file = webServiceEarFile.getWSWarFile();
/* 182 */       webServiceWarFile = new WebServiceWarFile(new File(getTempDir()), file, null);
/* 183 */       webServiceWarFile.writeDD(webServicesMBean);
/* 184 */       webServiceEarFile.createAppDescriptor(new HashSet());
/* 185 */       if (this.destpath.endsWith(".ear")) {
/* 186 */         webServiceWarFile.save();
/* 187 */         webServiceEarFile.save();
/*     */       } else {
/* 189 */         webServiceWarFile.save();
/* 190 */         FileUtils.copy(webServiceEarFile.getExploded(), new File(this.destpath));
/*     */       }  }
/* 192 */     catch (WebServiceJarException webServiceJarException)
/* 193 */     { throw new BuildException(webServiceJarException); }
/* 194 */     catch (IOException iOException)
/* 195 */     { throw new BuildException(iOException); }
/*     */     finally { 
/* 197 */       try { webServiceWarFile.remove(); } catch (Throwable throwable) {} 
/* 198 */       try { webServiceEarFile.remove(); } catch (Throwable throwable) {} }
/*     */   
/*     */   }
/*     */   
/*     */   private void buildRPCServices() {
/* 203 */     if (this.rpcServices.size() == 0)
/*     */       return; 
/* 205 */     boolean bool = (this.msgServices == null);
/* 206 */     ServiceGenTask serviceGenTask = (ServiceGenTask)TaskUtils.linkToTask(new ServiceGenTask(), this);
/*     */     
/* 208 */     serviceGenTask.setDestear(new File(this.destpath));
/* 209 */     serviceGenTask.setOverwrite(bool);
/* 210 */     serviceGenTask.setWarName(this.webApp);
/* 211 */     serviceGenTask.setContextURI(this.context);
/*     */     
/* 213 */     for (byte b = 0; b < this.rpcServices.size(); b++) {
/* 214 */       ((RPCServices)this.rpcServices.get(b)).addServices(serviceGenTask);
/*     */     }
/*     */     
/* 217 */     serviceGenTask.execute();
/*     */   }
/*     */   
/*     */   private void buildClientJar() {
/* 221 */     if (this.clientJar == null)
/*     */       return; 
/* 223 */     File file = null;
/*     */     try {
/* 225 */       file = new File(getTempDir(), this.clientJar.getPath());
/* 226 */       if (file.exists()) file.delete(); 
/* 227 */       file.createNewFile();
/* 228 */       file.deleteOnExit();
/* 229 */     } catch (IOException iOException) {
/* 230 */       throw new BuildException("Could not create temporary client jar file", iOException);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 235 */       this.clientJar.addto(file);
/* 236 */     } catch (IOException iOException) {
/* 237 */       throw new BuildException("Failed to add files to clientJar.", iOException);
/*     */     } 
/*     */     
/* 240 */     Iterator iterator = this.allServiceNames.iterator();
/* 241 */     while (iterator.hasNext()) {
/* 242 */       String str = (String)iterator.next();
/*     */ 
/*     */       
/* 245 */       ClientGenTask clientGenTask = (ClientGenTask)TaskUtils.linkToTask(new ClientGenTask(), this);
/*     */       
/* 247 */       clientGenTask.setEar(new File(this.destpath));
/* 248 */       clientGenTask.setWarName(this.webApp);
/* 249 */       clientGenTask.setPackageName(this.clientJar.getPackageName());
/* 250 */       clientGenTask.setServiceName(str);
/* 251 */       clientGenTask.setOverwrite(false);
/* 252 */       clientGenTask.setAutotype(true);
/* 253 */       clientGenTask.setClientjar(file);
/* 254 */       clientGenTask.execute();
/*     */     } 
/*     */     
/*     */     try {
/* 258 */       putClientJarFile(file);
/* 259 */     } catch (IOException iOException) {
/* 260 */       throw new BuildException("Failed to put clientJar to ear.", iOException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void putClientJarFile(File paramFile) throws IOException {
/* 265 */     File file = new File(this.destpath);
/* 266 */     if (file.isDirectory()) {
/* 267 */       File file1 = new File(file.getCanonicalPath() + File.separator + this.webApp);
/* 268 */       Jar jar = (Jar)TaskUtils.linkToTask(new Jar(), this);
/* 269 */       jar.setJarfile(file1.getCanonicalFile());
/* 270 */       jar.setBasedir(paramFile.getParentFile());
/* 271 */       jar.setIncludes(paramFile.getName());
/* 272 */       jar.setUpdate(true);
/* 273 */       jar.execute();
/*     */     } else {
/* 275 */       webServiceEarFile = null;
/*     */       
/* 277 */       try { webServiceEarFile = new WebServiceEarFile(new File(getTempDir()), new File(this.destpath), this.webApp);
/*     */         
/* 279 */         file1 = webServiceEarFile.getWSWarFile();
/* 280 */         Jar jar = (Jar)TaskUtils.linkToTask(new Jar(), this);
/* 281 */         jar.setJarfile(file1.getCanonicalFile());
/* 282 */         jar.setBasedir(paramFile.getParentFile());
/* 283 */         jar.setIncludes(paramFile.getName());
/* 284 */         jar.setUpdate(true);
/* 285 */         jar.execute();
/*     */         
/* 287 */         webServiceEarFile.save(); }
/* 288 */       catch (WebServiceJarException webServiceJarException)
/* 289 */       { throw new BuildException(webServiceJarException); }
/*     */       finally { 
/* 291 */         try { webServiceEarFile.remove(); } catch (Throwable throwable) {} }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 297 */   public void addServiceName(String paramString) { this.allServiceNames.add(paramString); }
/*     */ 
/*     */   
/*     */   public static String getTempDir() {
/* 301 */     String str = System.getProperty("java.io.tmpdir");
/* 302 */     if (str == null) str = "."; 
/* 303 */     return str;
/*     */   }
/*     */   
/*     */   private void cleanup() {
/*     */     try {
/* 308 */       for (byte b = 0; b < this.rpcServices.size(); b++) {
/* 309 */         ((RPCServices)this.rpcServices.get(b)).cleanup();
/*     */       }
/* 311 */     } catch (IOException iOException) {}
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\WSGenTask.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */