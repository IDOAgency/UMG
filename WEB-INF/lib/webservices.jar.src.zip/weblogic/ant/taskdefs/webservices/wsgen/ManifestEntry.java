package weblogic.ant.taskdefs.webservices.wsgen;

import org.apache.tools.ant.BuildException;

public class ManifestEntry {
  private String name;
  
  private String value;
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setValue(String paramString) { this.value = paramString; }
  
  public String getValue() { return this.value; }
  
  public void validateAttributes() {
    if (this.name == null)
      throw new BuildException("name attribute must be specified in <Entry>"); 
    if (this.value == null)
      throw new BuildException("value attribute must be specified in <Entry>"); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\ManifestEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */