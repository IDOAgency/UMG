/*    */ package weblogic.ant.taskdefs.webservices.wsgen;
/*    */ 
/*    */ import org.apache.tools.ant.BuildException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManifestEntry
/*    */ {
/*    */   private String name;
/*    */   private String value;
/*    */   
/* 16 */   public void setName(String paramString) { this.name = paramString; }
/* 17 */   public String getName() { return this.name; }
/*    */   
/* 19 */   public void setValue(String paramString) { this.value = paramString; }
/* 20 */   public String getValue() { return this.value; }
/*    */   
/*    */   public void validateAttributes() {
/* 23 */     if (this.name == null) {
/* 24 */       throw new BuildException("name attribute must be specified in <Entry>");
/*    */     }
/* 26 */     if (this.value == null)
/* 27 */       throw new BuildException("value attribute must be specified in <Entry>"); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\ManifestEntry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */