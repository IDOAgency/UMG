package weblogic.ant.taskdefs.webservices.wsgen;

import java.util.ArrayList;
import org.apache.tools.ant.BuildException;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
import weblogic.webservice.dd.DDMerger;
import weblogic.webservice.dd.DDProcessingException;

public class MessageServices {
  private ArrayList services;
  
  private WSGenTask wsgen;
  
  private WebServicesMBean wssb;
  
  public MessageServices(WSGenTask paramWSGenTask) {
    this.services = new ArrayList();
    this.wsgen = paramWSGenTask;
  }
  
  public Object createMessageservice() {
    MessageService messageService = new MessageService(this.wsgen);
    this.services.add(messageService);
    return messageService;
  }
  
  public void validateAttributes() {
    for (byte b = 0; b < this.services.size(); b++) {
      MessageService messageService = (MessageService)this.services.get(b);
      messageService.validateAttributes();
      this.wsgen.addServiceName(messageService.getName());
    } 
  }
  
  public void buildMessageServices() {
    this.wssb = new WebServicesMBeanImpl();
    for (byte b = 0; b < this.services.size(); b++) {
      MessageService messageService = (MessageService)this.services.get(b);
      try {
        this.wssb = DDMerger.mergeWebServices(this.wssb, new WebServiceMBean[] { messageService.createWebServiceMBean() });
      } catch (DDProcessingException dDProcessingException) {
        throw new BuildException("Failed to merge two MessageServices.", dDProcessingException);
      } 
    } 
  }
  
  public WebServicesMBean getWebServicesMBean() { return this.wssb; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\MessageServices.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */