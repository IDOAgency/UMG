/*    */ package weblogic.ant.taskdefs.webservices.wsgen;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*    */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*    */ import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
/*    */ import weblogic.webservice.dd.DDMerger;
/*    */ import weblogic.webservice.dd.DDProcessingException;
/*    */ 
/*    */ public class MessageServices {
/*    */   private ArrayList services;
/*    */   private WSGenTask wsgen;
/*    */   private WebServicesMBean wssb;
/*    */   
/*    */   public MessageServices(WSGenTask paramWSGenTask) {
/* 17 */     this.services = new ArrayList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 23 */     this.wsgen = paramWSGenTask;
/*    */   }
/*    */   
/*    */   public Object createMessageservice() {
/* 27 */     MessageService messageService = new MessageService(this.wsgen);
/* 28 */     this.services.add(messageService);
/* 29 */     return messageService;
/*    */   }
/*    */   
/*    */   public void validateAttributes() {
/* 33 */     for (byte b = 0; b < this.services.size(); b++) {
/* 34 */       MessageService messageService = (MessageService)this.services.get(b);
/* 35 */       messageService.validateAttributes();
/* 36 */       this.wsgen.addServiceName(messageService.getName());
/*    */     } 
/*    */   }
/*    */   
/*    */   public void buildMessageServices() {
/* 41 */     this.wssb = new WebServicesMBeanImpl();
/* 42 */     for (byte b = 0; b < this.services.size(); b++) {
/* 43 */       MessageService messageService = (MessageService)this.services.get(b);
/*    */       
/*    */       try {
/* 46 */         this.wssb = DDMerger.mergeWebServices(this.wssb, new WebServiceMBean[] { messageService.createWebServiceMBean() });
/*    */       }
/* 48 */       catch (DDProcessingException dDProcessingException) {
/* 49 */         throw new BuildException("Failed to merge two MessageServices.", dDProcessingException);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 55 */   public WebServicesMBean getWebServicesMBean() { return this.wssb; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\MessageServices.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */