/*    */ package weblogic.ant.taskdefs.webservices.wsgen;
/*    */ 
/*    */ import org.apache.tools.ant.BuildException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RPCService
/*    */ {
/*    */   private String bean;
/*    */   private String uri;
/* 13 */   private String targetNamespace = "http://example.org";
/*    */ 
/*    */ 
/*    */   
/* 17 */   public void setBean(String paramString) { this.bean = paramString; }
/* 18 */   public String getBean() { return this.bean; }
/*    */   
/* 20 */   public void setUri(String paramString) { this.uri = paramString; }
/* 21 */   public String getUri() { return this.uri; }
/*    */   
/* 23 */   public void setTargetNamespace(String paramString) { this.targetNamespace = paramString; }
/* 24 */   public String getTargetNamespace() { return this.targetNamespace; }
/*    */   
/*    */   public void validateAttributes() {
/* 27 */     if (this.bean == null) {
/* 28 */       throw new BuildException("bean attribute of rpcService must be set.");
/*    */     }
/* 30 */     if (this.uri == null) {
/* 31 */       throw new BuildException("uri attribute of rpcService must be set.");
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 36 */   public String toString() { return "bean: " + this.bean + " uri: " + this.uri; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\RPCService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */