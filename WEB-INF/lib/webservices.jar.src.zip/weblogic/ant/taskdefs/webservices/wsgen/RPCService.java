package weblogic.ant.taskdefs.webservices.wsgen;

import org.apache.tools.ant.BuildException;

public class RPCService {
  private String bean;
  
  private String uri;
  
  private String targetNamespace = "http://example.org";
  
  public void setBean(String paramString) { this.bean = paramString; }
  
  public String getBean() { return this.bean; }
  
  public void setUri(String paramString) { this.uri = paramString; }
  
  public String getUri() { return this.uri; }
  
  public void setTargetNamespace(String paramString) { this.targetNamespace = paramString; }
  
  public String getTargetNamespace() { return this.targetNamespace; }
  
  public void validateAttributes() {
    if (this.bean == null)
      throw new BuildException("bean attribute of rpcService must be set."); 
    if (this.uri == null)
      throw new BuildException("uri attribute of rpcService must be set."); 
  }
  
  public String toString() { return "bean: " + this.bean + " uri: " + this.uri; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\RPCService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */