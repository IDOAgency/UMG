package weblogic.ant.taskdefs.webservices.wsgen;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.tools.ant.BuildException;
import weblogic.utils.jars.JarFileObject;
import weblogic.utils.jars.Manifest;

public class Manifest {
  ArrayList entries = new ArrayList();
  
  public Object createEntry() {
    ManifestEntry manifestEntry = new ManifestEntry();
    this.entries.add(manifestEntry);
    return manifestEntry;
  }
  
  public int size() { return this.entries.size(); }
  
  public ManifestEntry entry(int paramInt) { return (ManifestEntry)this.entries.get(paramInt); }
  
  public void addto(File paramFile) throws IOException {
    JarFileObject jarFileObject = new JarFileObject(paramFile);
    if (jarFileObject.getManifest() == null)
      jarFileObject.setManifest(new Manifest()); 
    for (byte b = 0; b < size(); b++)
      jarFileObject.getManifest().getHeaders().addHeader(entry(b).getName(), entry(b).getValue()); 
    jarFileObject.save();
  }
  
  public void validateAttributes() {
    if (this.entries.size() == 0)
      throw new BuildException("At least one entry must be defined in Manifest."); 
    for (byte b = 0; b < size(); b++)
      ((ManifestEntry)this.entries.get(b)).validateAttributes(); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\Manifest.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */