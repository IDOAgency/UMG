/*    */ package weblogic.ant.taskdefs.webservices.wsgen;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import weblogic.utils.jars.JarFileObject;
/*    */ import weblogic.utils.jars.Manifest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Manifest
/*    */ {
/* 15 */   ArrayList entries = new ArrayList();
/*    */ 
/*    */ 
/*    */   
/*    */   public Object createEntry() {
/* 20 */     ManifestEntry manifestEntry = new ManifestEntry();
/* 21 */     this.entries.add(manifestEntry);
/* 22 */     return manifestEntry;
/*    */   }
/*    */ 
/*    */   
/* 26 */   public int size() { return this.entries.size(); }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public ManifestEntry entry(int paramInt) { return (ManifestEntry)this.entries.get(paramInt); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addto(File paramFile) throws IOException {
/* 37 */     JarFileObject jarFileObject = new JarFileObject(paramFile);
/* 38 */     if (jarFileObject.getManifest() == null) {
/* 39 */       jarFileObject.setManifest(new Manifest());
/*    */     }
/*    */     
/* 42 */     for (byte b = 0; b < size(); b++) {
/* 43 */       jarFileObject.getManifest().getHeaders().addHeader(entry(b).getName(), entry(b).getValue());
/*    */     }
/*    */     
/* 46 */     jarFileObject.save();
/*    */   }
/*    */   
/*    */   public void validateAttributes() {
/* 50 */     if (this.entries.size() == 0) {
/* 51 */       throw new BuildException("At least one entry must be defined in Manifest.");
/*    */     }
/* 53 */     for (byte b = 0; b < size(); b++)
/* 54 */       ((ManifestEntry)this.entries.get(b)).validateAttributes(); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\Manifest.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */