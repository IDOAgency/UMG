package weblogic.ant.taskdefs.webservices.wsgen;

import java.io.File;
import java.util.ArrayList;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.taskdefs.Expand;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.ant.taskdefs.webservices.servicegen.Service;
import weblogic.ant.taskdefs.webservices.servicegen.ServiceGenTask;
import weblogic.utils.FileUtils;

public class RPCServices {
  private String path;
  
  private String module;
  
  private ArrayList services;
  
  private WSGenTask wsgen;
  
  private File ejbFile;
  
  private File tempBaseEar;
  
  public RPCServices(WSGenTask paramWSGenTask) {
    this.services = new ArrayList();
    this.wsgen = paramWSGenTask;
  }
  
  public void setPath(String paramString) { this.path = paramString; }
  
  public String getPath() { return this.path; }
  
  public void setModule(String paramString) { this.module = paramString; }
  
  public String getModule() { return this.module; }
  
  public Object createRpcservice() {
    RPCService rPCService = new RPCService();
    this.services.add(rPCService);
    return rPCService;
  }
  
  public void validateAttributes() {
    if (this.wsgen.getBasepath() == null && this.path == null)
      throw new BuildException("If the basepath attribute of the wsgen element is not set, the path attribute of rpcServices must be set"); 
    if (this.wsgen.getBasepath() != null && this.module == null)
      throw new BuildException("If the basepath attribute of the wsgen element is set, the module attribute of rpcServices must be set"); 
    for (byte b = 0; b < this.services.size(); b++) {
      RPCService rPCService = (RPCService)this.services.get(b);
      rPCService.validateAttributes();
      this.wsgen.addServiceName(rPCService.getBean());
    } 
  }
  
  public void addServices(ServiceGenTask paramServiceGenTask) {
    for (byte b = 0; b < this.services.size(); b++) {
      RPCService rPCService = (RPCService)this.services.get(b);
      Service service = paramServiceGenTask.createService();
      service.setEjbJar(getEJBFile());
      service.setIncludeEjbs(rPCService.getBean());
      service.setServiceName(rPCService.getBean());
      service.setServiceURI(rPCService.getUri());
      service.setTargetNamespace(rPCService.getTargetNamespace());
      service.setProtocol(this.wsgen.getProtocol());
      service.setExpandMethods(true);
      service.setGenerateTypes(true);
    } 
  }
  
  private File getEJBFile() {
    if (this.ejbFile != null)
      return this.ejbFile; 
    if (this.wsgen.getBasepath() == null)
      return new File(this.path); 
    File file = new File(this.wsgen.getBasepath());
    if (file.isDirectory())
      return new File(this.wsgen.getBasepath(), this.module); 
    this.tempBaseEar = new File(this.wsgen.getTempDir(), "temp-basepathear");
    Expand expand = (Expand)TaskUtils.linkToTask(new Expand(), this.wsgen);
    expand.setSrc(file);
    expand.setDest(this.tempBaseEar);
    expand.execute();
    return new File(this.tempBaseEar, this.module);
  }
  
  public void cleanup() {
    if (this.tempBaseEar != null)
      FileUtils.remove(this.tempBaseEar); 
  }
  
  public String toString() { return "module: " + this.module + "\n" + "path: " + this.path + "\n" + super.toString(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\RPCServices.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */