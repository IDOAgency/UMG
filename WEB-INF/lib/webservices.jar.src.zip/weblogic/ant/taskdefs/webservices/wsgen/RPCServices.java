/*     */ package weblogic.ant.taskdefs.webservices.wsgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.taskdefs.Expand;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.ant.taskdefs.webservices.servicegen.Service;
/*     */ import weblogic.ant.taskdefs.webservices.servicegen.ServiceGenTask;
/*     */ import weblogic.utils.FileUtils;
/*     */ 
/*     */ 
/*     */ public class RPCServices
/*     */ {
/*     */   private String path;
/*     */   private String module;
/*     */   private ArrayList services;
/*     */   private WSGenTask wsgen;
/*     */   private File ejbFile;
/*     */   private File tempBaseEar;
/*     */   
/*     */   public RPCServices(WSGenTask paramWSGenTask) {
/*  23 */     this.services = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  30 */     this.wsgen = paramWSGenTask;
/*     */   }
/*     */   
/*  33 */   public void setPath(String paramString) { this.path = paramString; }
/*  34 */   public String getPath() { return this.path; }
/*     */   
/*  36 */   public void setModule(String paramString) { this.module = paramString; }
/*  37 */   public String getModule() { return this.module; }
/*     */   
/*     */   public Object createRpcservice() {
/*  40 */     RPCService rPCService = new RPCService();
/*  41 */     this.services.add(rPCService);
/*  42 */     return rPCService;
/*     */   }
/*     */   
/*     */   public void validateAttributes() {
/*  46 */     if (this.wsgen.getBasepath() == null && this.path == null) {
/*  47 */       throw new BuildException("If the basepath attribute of the wsgen element is not set, the path attribute of rpcServices must be set");
/*     */     }
/*  49 */     if (this.wsgen.getBasepath() != null && this.module == null) {
/*  50 */       throw new BuildException("If the basepath attribute of the wsgen element is set, the module attribute of rpcServices must be set");
/*     */     }
/*  52 */     for (byte b = 0; b < this.services.size(); b++) {
/*  53 */       RPCService rPCService = (RPCService)this.services.get(b);
/*  54 */       rPCService.validateAttributes();
/*  55 */       this.wsgen.addServiceName(rPCService.getBean());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addServices(ServiceGenTask paramServiceGenTask) {
/*  60 */     for (byte b = 0; b < this.services.size(); b++) {
/*  61 */       RPCService rPCService = (RPCService)this.services.get(b);
/*     */       
/*  63 */       Service service = paramServiceGenTask.createService();
/*  64 */       service.setEjbJar(getEJBFile());
/*  65 */       service.setIncludeEjbs(rPCService.getBean());
/*  66 */       service.setServiceName(rPCService.getBean());
/*  67 */       service.setServiceURI(rPCService.getUri());
/*  68 */       service.setTargetNamespace(rPCService.getTargetNamespace());
/*  69 */       service.setProtocol(this.wsgen.getProtocol());
/*  70 */       service.setExpandMethods(true);
/*  71 */       service.setGenerateTypes(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private File getEJBFile() {
/*  76 */     if (this.ejbFile != null) return this.ejbFile;
/*     */     
/*  78 */     if (this.wsgen.getBasepath() == null) {
/*  79 */       return new File(this.path);
/*     */     }
/*  81 */     File file = new File(this.wsgen.getBasepath());
/*  82 */     if (file.isDirectory()) {
/*  83 */       return new File(this.wsgen.getBasepath(), this.module);
/*     */     }
/*  85 */     this.tempBaseEar = new File(this.wsgen.getTempDir(), "temp-basepathear");
/*  86 */     Expand expand = (Expand)TaskUtils.linkToTask(new Expand(), this.wsgen);
/*  87 */     expand.setSrc(file);
/*  88 */     expand.setDest(this.tempBaseEar);
/*  89 */     expand.execute();
/*  90 */     return new File(this.tempBaseEar, this.module);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/*  96 */     if (this.tempBaseEar != null) {
/*  97 */       FileUtils.remove(this.tempBaseEar);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 102 */   public String toString() { return "module: " + this.module + "\n" + "path: " + this.path + "\n" + super.toString(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\RPCServices.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */