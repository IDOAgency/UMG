/*     */ package weblogic.ant.taskdefs.webservices.wsgen;
/*     */ 
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JMSReceiveQueueMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JMSReceiveTopicMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JMSSendDestinationMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JNDINameMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.OperationMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageService
/*     */ {
/*     */   private String name;
/*     */   private String destination;
/*     */   private String destinationType;
/*     */   private String action;
/*     */   private String connectionFactory;
/*     */   private String uri;
/*     */   private String targetNamespace;
/*     */   private WSGenTask wsgen;
/*  35 */   private static int jmsCompCounter = 0;
/*     */   
/*     */   public MessageService(WSGenTask paramWSGenTask) {
/*     */     this.targetNamespace = "http://example.org";
/*  39 */     this.wsgen = paramWSGenTask;
/*     */   }
/*     */   
/*  42 */   public void setName(String paramString) { this.name = paramString; }
/*  43 */   public String getName() { return this.name; }
/*     */   
/*  45 */   public void setUri(String paramString) { this.uri = paramString; }
/*  46 */   public String getUri() { return this.uri; }
/*     */   
/*  48 */   public void setAction(String paramString) { this.action = paramString.toLowerCase(); }
/*  49 */   public String getAction() { return this.action; }
/*     */   
/*  51 */   public void setDestination(String paramString) { this.destination = paramString; }
/*  52 */   public String getDestination() { return this.destination; }
/*     */   
/*  54 */   public void setDestinationtype(String paramString) { this.destinationType = paramString.toLowerCase(); }
/*  55 */   public String getDestinationtype() { return this.destinationType; }
/*     */   
/*  57 */   public void setConnectionfactory(String paramString) { this.connectionFactory = paramString; }
/*  58 */   public String getConnectionfactory() { return this.connectionFactory; }
/*     */   
/*  60 */   public void setTargetNamespace(String paramString) { this.targetNamespace = paramString; }
/*  61 */   public String getTargetNamespace() { return this.targetNamespace; }
/*     */ 
/*     */   
/*     */   public void validateAttributes() {
/*  65 */     if (this.name == null) {
/*  66 */       throw new BuildException("name attribute of messageService must be set");
/*     */     }
/*  68 */     if (this.destination == null) {
/*  69 */       throw new BuildException("destination attribute of messageService must be set");
/*     */     }
/*  71 */     if (this.destinationType == null) {
/*  72 */       throw new BuildException("destinationType attribute of messageService must be set");
/*     */     }
/*  74 */     if (this.action == null) {
/*  75 */       throw new BuildException("action attribute of messageService must be set");
/*     */     }
/*  77 */     if (this.connectionFactory == null) {
/*  78 */       throw new BuildException("connectionFactory attribute of messageService must be set");
/*     */     }
/*  80 */     if (this.uri == null) {
/*  81 */       throw new BuildException("uri attribute of messageService must be set");
/*     */     }
/*     */     
/*  84 */     if (!this.destinationType.equals("topic") && !this.destinationType.equals("queue")) {
/*  85 */       throw new BuildException("destinationType attribute of MessageService must be \"topic\" or \"queue\"");
/*     */     }
/*  87 */     if (!this.action.equals("send") && !this.action.equals("receive")) {
/*  88 */       throw new BuildException("action attribute of MessageService must be \"send\" or \"receive\"");
/*     */     }
/*     */   }
/*     */   
/*     */   public WebServiceMBean createWebServiceMBean() {
/*  93 */     WebServiceMBeanImpl webServiceMBeanImpl = new WebServiceMBeanImpl();
/*  94 */     webServiceMBeanImpl.setWebServiceName(this.name);
/*  95 */     webServiceMBeanImpl.setURI(this.uri);
/*  96 */     webServiceMBeanImpl.setProtocol(this.wsgen.getProtocol());
/*  97 */     webServiceMBeanImpl.setTargetNamespace(this.targetNamespace);
/*     */ 
/*     */     
/* 100 */     ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
/* 101 */     OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
/* 102 */     webServiceMBeanImpl.setComponents(componentsMBeanImpl);
/* 103 */     webServiceMBeanImpl.setOperations(operationsMBeanImpl);
/*     */     
/* 105 */     if (this.action.equals("send")) {
/*     */       
/* 107 */       JMSSendDestinationMBeanImpl jMSSendDestinationMBeanImpl = new JMSSendDestinationMBeanImpl();
/*     */ 
/*     */       
/* 110 */       componentsMBeanImpl.addJMSSendDestination(jMSSendDestinationMBeanImpl);
/* 111 */       jMSSendDestinationMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
/* 112 */       jMSSendDestinationMBeanImpl.setConnectionFactory(this.connectionFactory);
/* 113 */       JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
/* 114 */       jNDINameMBeanImpl.setPath(this.destination);
/* 115 */       jMSSendDestinationMBeanImpl.setJNDIName(jNDINameMBeanImpl);
/*     */ 
/*     */       
/* 118 */       OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 119 */       operationMBeanImpl.setMethod("send");
/* 120 */       operationMBeanImpl.setComponent(jMSSendDestinationMBeanImpl);
/* 121 */       operationMBeanImpl.setComponentName(jMSSendDestinationMBeanImpl.getComponentName());
/* 122 */       operationsMBeanImpl.addOperation(operationMBeanImpl);
/*     */     }
/* 124 */     else if (this.destinationType.equals("queue")) {
/*     */       
/* 126 */       JMSReceiveQueueMBeanImpl jMSReceiveQueueMBeanImpl = new JMSReceiveQueueMBeanImpl();
/*     */ 
/*     */       
/* 129 */       componentsMBeanImpl.addJMSReceiveQueue(jMSReceiveQueueMBeanImpl);
/* 130 */       jMSReceiveQueueMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
/* 131 */       jMSReceiveQueueMBeanImpl.setConnectionFactory(this.connectionFactory);
/* 132 */       JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
/* 133 */       jNDINameMBeanImpl.setPath(this.destination);
/* 134 */       jMSReceiveQueueMBeanImpl.setJNDIName(jNDINameMBeanImpl);
/*     */ 
/*     */       
/* 137 */       OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 138 */       operationMBeanImpl.setMethod("receive");
/* 139 */       operationMBeanImpl.setComponent(jMSReceiveQueueMBeanImpl);
/* 140 */       operationMBeanImpl.setComponentName(jMSReceiveQueueMBeanImpl.getComponentName());
/* 141 */       operationsMBeanImpl.addOperation(operationMBeanImpl);
/*     */     }
/* 143 */     else if (this.destinationType.equals("topic")) {
/*     */       
/* 145 */       JMSReceiveTopicMBeanImpl jMSReceiveTopicMBeanImpl = new JMSReceiveTopicMBeanImpl();
/*     */ 
/*     */       
/* 148 */       componentsMBeanImpl.addJMSReceiveTopic(jMSReceiveTopicMBeanImpl);
/* 149 */       jMSReceiveTopicMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
/* 150 */       jMSReceiveTopicMBeanImpl.setConnectionFactory(this.connectionFactory);
/* 151 */       JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
/* 152 */       jNDINameMBeanImpl.setPath(this.destination);
/* 153 */       jMSReceiveTopicMBeanImpl.setJNDIName(jNDINameMBeanImpl);
/*     */ 
/*     */       
/* 156 */       OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 157 */       operationMBeanImpl.setMethod("receive");
/* 158 */       operationMBeanImpl.setComponent(jMSReceiveTopicMBeanImpl);
/* 159 */       operationMBeanImpl.setComponentName(jMSReceiveTopicMBeanImpl.getComponentName());
/* 160 */       operationsMBeanImpl.addOperation(operationMBeanImpl);
/*     */     } 
/*     */     
/* 163 */     return webServiceMBeanImpl;
/*     */   }
/*     */ 
/*     */   
/* 167 */   public String toString() { return super.toString() + "\n" + "destination: " + this.destination + "\n" + "destinationType: " + this.destinationType + "\n" + "connectionFactory: " + this.connectionFactory + "\n"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\MessageService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */