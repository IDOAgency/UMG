package weblogic.ant.taskdefs.webservices.wsgen;

import org.apache.tools.ant.BuildException;
import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
import weblogic.management.descriptors.webservice.JMSReceiveQueueMBeanImpl;
import weblogic.management.descriptors.webservice.JMSReceiveTopicMBeanImpl;
import weblogic.management.descriptors.webservice.JMSSendDestinationMBeanImpl;
import weblogic.management.descriptors.webservice.JNDINameMBeanImpl;
import weblogic.management.descriptors.webservice.OperationMBeanImpl;
import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;

public class MessageService {
  private String name;
  
  private String destination;
  
  private String destinationType;
  
  private String action;
  
  private String connectionFactory;
  
  private String uri;
  
  private String targetNamespace;
  
  private WSGenTask wsgen;
  
  private static int jmsCompCounter = 0;
  
  public MessageService(WSGenTask paramWSGenTask) {
    this.targetNamespace = "http://example.org";
    this.wsgen = paramWSGenTask;
  }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setUri(String paramString) { this.uri = paramString; }
  
  public String getUri() { return this.uri; }
  
  public void setAction(String paramString) { this.action = paramString.toLowerCase(); }
  
  public String getAction() { return this.action; }
  
  public void setDestination(String paramString) { this.destination = paramString; }
  
  public String getDestination() { return this.destination; }
  
  public void setDestinationtype(String paramString) { this.destinationType = paramString.toLowerCase(); }
  
  public String getDestinationtype() { return this.destinationType; }
  
  public void setConnectionfactory(String paramString) { this.connectionFactory = paramString; }
  
  public String getConnectionfactory() { return this.connectionFactory; }
  
  public void setTargetNamespace(String paramString) { this.targetNamespace = paramString; }
  
  public String getTargetNamespace() { return this.targetNamespace; }
  
  public void validateAttributes() {
    if (this.name == null)
      throw new BuildException("name attribute of messageService must be set"); 
    if (this.destination == null)
      throw new BuildException("destination attribute of messageService must be set"); 
    if (this.destinationType == null)
      throw new BuildException("destinationType attribute of messageService must be set"); 
    if (this.action == null)
      throw new BuildException("action attribute of messageService must be set"); 
    if (this.connectionFactory == null)
      throw new BuildException("connectionFactory attribute of messageService must be set"); 
    if (this.uri == null)
      throw new BuildException("uri attribute of messageService must be set"); 
    if (!this.destinationType.equals("topic") && !this.destinationType.equals("queue"))
      throw new BuildException("destinationType attribute of MessageService must be \"topic\" or \"queue\""); 
    if (!this.action.equals("send") && !this.action.equals("receive"))
      throw new BuildException("action attribute of MessageService must be \"send\" or \"receive\""); 
  }
  
  public WebServiceMBean createWebServiceMBean() {
    WebServiceMBeanImpl webServiceMBeanImpl = new WebServiceMBeanImpl();
    webServiceMBeanImpl.setWebServiceName(this.name);
    webServiceMBeanImpl.setURI(this.uri);
    webServiceMBeanImpl.setProtocol(this.wsgen.getProtocol());
    webServiceMBeanImpl.setTargetNamespace(this.targetNamespace);
    ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
    OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
    webServiceMBeanImpl.setComponents(componentsMBeanImpl);
    webServiceMBeanImpl.setOperations(operationsMBeanImpl);
    if (this.action.equals("send")) {
      JMSSendDestinationMBeanImpl jMSSendDestinationMBeanImpl = new JMSSendDestinationMBeanImpl();
      componentsMBeanImpl.addJMSSendDestination(jMSSendDestinationMBeanImpl);
      jMSSendDestinationMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
      jMSSendDestinationMBeanImpl.setConnectionFactory(this.connectionFactory);
      JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
      jNDINameMBeanImpl.setPath(this.destination);
      jMSSendDestinationMBeanImpl.setJNDIName(jNDINameMBeanImpl);
      OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
      operationMBeanImpl.setMethod("send");
      operationMBeanImpl.setComponent(jMSSendDestinationMBeanImpl);
      operationMBeanImpl.setComponentName(jMSSendDestinationMBeanImpl.getComponentName());
      operationsMBeanImpl.addOperation(operationMBeanImpl);
    } else if (this.destinationType.equals("queue")) {
      JMSReceiveQueueMBeanImpl jMSReceiveQueueMBeanImpl = new JMSReceiveQueueMBeanImpl();
      componentsMBeanImpl.addJMSReceiveQueue(jMSReceiveQueueMBeanImpl);
      jMSReceiveQueueMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
      jMSReceiveQueueMBeanImpl.setConnectionFactory(this.connectionFactory);
      JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
      jNDINameMBeanImpl.setPath(this.destination);
      jMSReceiveQueueMBeanImpl.setJNDIName(jNDINameMBeanImpl);
      OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
      operationMBeanImpl.setMethod("receive");
      operationMBeanImpl.setComponent(jMSReceiveQueueMBeanImpl);
      operationMBeanImpl.setComponentName(jMSReceiveQueueMBeanImpl.getComponentName());
      operationsMBeanImpl.addOperation(operationMBeanImpl);
    } else if (this.destinationType.equals("topic")) {
      JMSReceiveTopicMBeanImpl jMSReceiveTopicMBeanImpl = new JMSReceiveTopicMBeanImpl();
      componentsMBeanImpl.addJMSReceiveTopic(jMSReceiveTopicMBeanImpl);
      jMSReceiveTopicMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
      jMSReceiveTopicMBeanImpl.setConnectionFactory(this.connectionFactory);
      JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
      jNDINameMBeanImpl.setPath(this.destination);
      jMSReceiveTopicMBeanImpl.setJNDIName(jNDINameMBeanImpl);
      OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
      operationMBeanImpl.setMethod("receive");
      operationMBeanImpl.setComponent(jMSReceiveTopicMBeanImpl);
      operationMBeanImpl.setComponentName(jMSReceiveTopicMBeanImpl.getComponentName());
      operationsMBeanImpl.addOperation(operationMBeanImpl);
    } 
    return webServiceMBeanImpl;
  }
  
  public String toString() { return super.toString() + "\n" + "destination: " + this.destination + "\n" + "destinationType: " + this.destinationType + "\n" + "connectionFactory: " + this.connectionFactory + "\n"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\MessageService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */