package weblogic.ant.taskdefs.webservices.wsgen;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.taskdefs.MatchingTask;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.types.ZipFileSet;
import org.apache.tools.ant.types.ZipScanner;
import weblogic.utils.FileUtils;
import weblogic.webservice.util.WebServiceWarFile;

public class ClientJar extends MatchingTask {
  private static final boolean DEBUG = false;
  
  private ArrayList filesets;
  
  private String path;
  
  private String packageName;
  
  private Manifest manifest;
  
  private WSGenTask wsgen;
  
  public ClientJar(WSGenTask paramWSGenTask) {
    this.filesets = new ArrayList();
    this.path = "client.jar";
    this.packageName = "org.example";
    this.wsgen = paramWSGenTask;
  }
  
  public void setPath(String paramString) { this.path = paramString; }
  
  public String getPath() { return this.path; }
  
  public void setPackageName(String paramString) { this.packageName = paramString; }
  
  public String getPackageName() { return this.packageName; }
  
  public Manifest getManifest() { return this.manifest; }
  
  public List getFilesets() { return this.filesets; }
  
  public Object createManifest() {
    if (this.manifest != null)
      return new BuildException("Only one <Manifest> is allowed."); 
    return this.manifest = new Manifest();
  }
  
  public void addFileset(FileSet paramFileSet) { this.filesets.add(paramFileSet); }
  
  public void addZipfileset(ZipFileSet paramZipFileSet) { this.filesets.add(paramZipFileSet); }
  
  public void validateAttributes() {
    if (!this.path.endsWith(".jar"))
      throw new BuildException("clientJar \"path\" attribute value must end with \".jar\"."); 
    if (this.manifest != null)
      this.manifest.validateAttributes(); 
  }
  
  public void addto(File paramFile) throws IOException {
    webServiceWarFile = null;
    try {
      webServiceWarFile = new WebServiceWarFile(new File(this.wsgen.getTempDir()), paramFile, null);
      writeFilesets(this.filesets, webServiceWarFile.getExploded());
      webServiceWarFile.save();
      if (this.manifest != null)
        this.manifest.addto(paramFile); 
    } catch (FileNotFoundException fileNotFoundException) {
      throw new BuildException(fileNotFoundException.getMessage(), fileNotFoundException);
    } finally {
      try {
        webServiceWarFile.remove();
      } catch (Throwable throwable) {}
    } 
  }
  
  private void writeFilesets(List paramList, File paramFile) throws FileNotFoundException, IOException {
    if (paramList != null)
      for (byte b = 0; b < paramList.size(); b++) {
        FileSet fileSet = (FileSet)paramList.get(b);
        DirectoryScanner directoryScanner = fileSet.getDirectoryScanner(this.wsgen.getProject());
        if (fileSet instanceof ZipFileSet) {
          ZipFileSet zipFileSet = (ZipFileSet)fileSet;
          File file = zipFileSet.getSrc(this.wsgen.getProject());
          if (file != null) {
            ZipScanner zipScanner = (ZipScanner)directoryScanner;
            FileInputStream fileInputStream = new FileInputStream(file);
            ZipInputStream zipInputStream = new ZipInputStream(fileInputStream);
            ZipEntry zipEntry;
            while ((zipEntry = zipInputStream.getNextEntry()) != null) {
              String str = zipEntry.getName();
              if (zipScanner.match(str)) {
                str = str.replace('/', File.separatorChar);
                File file1 = new File(paramFile, str);
                if (zipEntry.isDirectory()) {
                  file1.mkdirs();
                  continue;
                } 
                file1.getParentFile().mkdirs();
                FileOutputStream fileOutputStream = new FileOutputStream(file1);
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                int i;
                while ((i = zipInputStream.read()) != -1)
                  byteArrayOutputStream.write(i); 
                byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
                byteArrayOutputStream.close();
                fileOutputStream.write(arrayOfByte);
                fileOutputStream.close();
              } 
            } 
          } else {
            String str1 = zipFileSet.getPrefix(this.wsgen.getProject());
            String str2 = zipFileSet.getFullpath(this.wsgen.getProject());
            File file1 = directoryScanner.getBasedir();
            String[] arrayOfString = directoryScanner.getIncludedFiles();
            for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
              File file2 = new File(file1, arrayOfString[b1]);
              copyFile(file2, file1, str1, str2, paramFile);
            } 
          } 
        } else {
          String[] arrayOfString = directoryScanner.getIncludedFiles();
          File file = directoryScanner.getBasedir();
          for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
            File file1 = new File(file, arrayOfString[b1]);
            copyFile(file1, file, paramFile);
          } 
        } 
      }  
  }
  
  private void copyFile(File paramFile1, File paramFile2, File paramFile3) throws FileNotFoundException, IOException {
    String str1 = paramFile1.getAbsolutePath();
    String str2 = paramFile2.getAbsolutePath();
    String str3 = str1.substring(str2.length());
    File file1 = new File(paramFile3, str3);
    String str4 = file1.getAbsolutePath();
    File file2 = file1.getParentFile();
    file2.mkdirs();
    copyFile(str1, str4);
  }
  
  private void copyFile(File paramFile1, File paramFile2, String paramString1, String paramString2, File paramFile3) throws FileNotFoundException, IOException {
    String str1 = paramFile1.getAbsolutePath();
    String str2 = paramFile2.getAbsolutePath();
    String str3 = str1.substring(str2.length());
    if (paramString1 != null && paramString1.length() > 0) {
      str3 = paramString1 + File.separatorChar + str3;
    } else if (paramString2 != null && paramString2.length() > 0) {
      str3 = paramString2 + File.separatorChar + paramFile1.getName();
    } 
    str3 = str3.replace('/', File.separatorChar);
    File file1 = new File(paramFile3, str3);
    String str4 = file1.getAbsolutePath();
    File file2 = file1.getParentFile();
    file2.mkdirs();
    copyFile(str1, str4);
  }
  
  public void copyFile(String paramString1, String paramString2) throws IOException, FileNotFoundException { FileUtils.copy(new File(paramString1), new File(paramString2)); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\ClientJar.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */