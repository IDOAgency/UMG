/*     */ package weblogic.ant.taskdefs.webservices.wsgen;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.taskdefs.MatchingTask;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ import org.apache.tools.ant.types.ZipFileSet;
/*     */ import org.apache.tools.ant.types.ZipScanner;
/*     */ import weblogic.utils.FileUtils;
/*     */ import weblogic.webservice.util.WebServiceWarFile;
/*     */ 
/*     */ public class ClientJar
/*     */   extends MatchingTask
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*     */   private ArrayList filesets;
/*     */   private String path;
/*     */   private String packageName;
/*     */   private Manifest manifest;
/*     */   private WSGenTask wsgen;
/*     */   
/*     */   public ClientJar(WSGenTask paramWSGenTask) {
/*  33 */     this.filesets = new ArrayList();
/*  34 */     this.path = "client.jar";
/*  35 */     this.packageName = "org.example";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  41 */     this.wsgen = paramWSGenTask;
/*     */   }
/*     */   
/*  44 */   public void setPath(String paramString) { this.path = paramString; }
/*  45 */   public String getPath() { return this.path; }
/*     */   
/*  47 */   public void setPackageName(String paramString) { this.packageName = paramString; }
/*  48 */   public String getPackageName() { return this.packageName; }
/*     */ 
/*     */   
/*  51 */   public Manifest getManifest() { return this.manifest; }
/*     */ 
/*     */ 
/*     */   
/*  55 */   public List getFilesets() { return this.filesets; }
/*     */ 
/*     */   
/*     */   public Object createManifest() {
/*  59 */     if (this.manifest != null) {
/*  60 */       return new BuildException("Only one <Manifest> is allowed.");
/*     */     }
/*  62 */     return this.manifest = new Manifest();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  67 */   public void addFileset(FileSet paramFileSet) { this.filesets.add(paramFileSet); }
/*     */ 
/*     */ 
/*     */   
/*  71 */   public void addZipfileset(ZipFileSet paramZipFileSet) { this.filesets.add(paramZipFileSet); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateAttributes() {
/*  76 */     if (!this.path.endsWith(".jar")) {
/*  77 */       throw new BuildException("clientJar \"path\" attribute value must end with \".jar\".");
/*     */     }
/*  79 */     if (this.manifest != null) this.manifest.validateAttributes();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addto(File paramFile) throws IOException {
/*  87 */     webServiceWarFile = null;
/*     */     
/*  89 */     try { webServiceWarFile = new WebServiceWarFile(new File(this.wsgen.getTempDir()), paramFile, null);
/*  90 */       writeFilesets(this.filesets, webServiceWarFile.getExploded());
/*  91 */       webServiceWarFile.save();
/*     */       
/*  93 */       if (this.manifest != null)
/*  94 */         this.manifest.addto(paramFile);  }
/*  95 */     catch (FileNotFoundException fileNotFoundException)
/*  96 */     { throw new BuildException(fileNotFoundException.getMessage(), fileNotFoundException); }
/*     */     finally { 
/*  98 */       try { webServiceWarFile.remove(); } catch (Throwable throwable) {} }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeFilesets(List paramList, File paramFile) throws FileNotFoundException, IOException {
/* 107 */     if (paramList != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 115 */       for (byte b = 0; b < paramList.size(); b++) {
/* 116 */         FileSet fileSet = (FileSet)paramList.get(b);
/* 117 */         DirectoryScanner directoryScanner = fileSet.getDirectoryScanner(this.wsgen.getProject());
/*     */         
/* 119 */         if (fileSet instanceof ZipFileSet) {
/* 120 */           ZipFileSet zipFileSet = (ZipFileSet)fileSet;
/* 121 */           File file = zipFileSet.getSrc(this.wsgen.getProject());
/*     */           
/* 123 */           if (file != null) {
/* 124 */             ZipScanner zipScanner = (ZipScanner)directoryScanner;
/* 125 */             FileInputStream fileInputStream = new FileInputStream(file);
/* 126 */             ZipInputStream zipInputStream = new ZipInputStream(fileInputStream);
/*     */ 
/*     */             
/*     */             ZipEntry zipEntry;
/*     */             
/* 131 */             while ((zipEntry = zipInputStream.getNextEntry()) != null) {
/* 132 */               String str = zipEntry.getName();
/*     */               
/* 134 */               if (zipScanner.match(str)) {
/* 135 */                 str = str.replace('/', File.separatorChar);
/* 136 */                 File file1 = new File(paramFile, str);
/*     */                 
/* 138 */                 if (zipEntry.isDirectory()) {
/* 139 */                   file1.mkdirs();
/*     */                   continue;
/*     */                 } 
/* 142 */                 file1.getParentFile().mkdirs();
/*     */                 
/* 144 */                 FileOutputStream fileOutputStream = new FileOutputStream(file1);
/* 145 */                 ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */                 
/*     */                 int i;
/* 148 */                 while ((i = zipInputStream.read()) != -1) {
/* 149 */                   byteArrayOutputStream.write(i);
/*     */                 }
/* 151 */                 byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/* 152 */                 byteArrayOutputStream.close();
/*     */                 
/* 154 */                 fileOutputStream.write(arrayOfByte);
/* 155 */                 fileOutputStream.close();
/*     */               }
/*     */             
/*     */             } 
/*     */           } else {
/*     */             
/* 161 */             String str1 = zipFileSet.getPrefix(this.wsgen.getProject());
/* 162 */             String str2 = zipFileSet.getFullpath(this.wsgen.getProject());
/*     */             
/* 164 */             File file1 = directoryScanner.getBasedir();
/* 165 */             String[] arrayOfString = directoryScanner.getIncludedFiles();
/*     */             
/* 167 */             for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 168 */               File file2 = new File(file1, arrayOfString[b1]);
/* 169 */               copyFile(file2, file1, str1, str2, paramFile);
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 174 */           String[] arrayOfString = directoryScanner.getIncludedFiles();
/* 175 */           File file = directoryScanner.getBasedir();
/*     */           
/* 177 */           for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
/* 178 */             File file1 = new File(file, arrayOfString[b1]);
/* 179 */             copyFile(file1, file, paramFile);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyFile(File paramFile1, File paramFile2, File paramFile3) throws FileNotFoundException, IOException {
/* 190 */     String str1 = paramFile1.getAbsolutePath();
/* 191 */     String str2 = paramFile2.getAbsolutePath();
/* 192 */     String str3 = str1.substring(str2.length());
/* 193 */     File file1 = new File(paramFile3, str3);
/* 194 */     String str4 = file1.getAbsolutePath();
/* 195 */     File file2 = file1.getParentFile();
/*     */     
/* 197 */     file2.mkdirs();
/* 198 */     copyFile(str1, str4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyFile(File paramFile1, File paramFile2, String paramString1, String paramString2, File paramFile3) throws FileNotFoundException, IOException {
/* 210 */     String str1 = paramFile1.getAbsolutePath();
/* 211 */     String str2 = paramFile2.getAbsolutePath();
/* 212 */     String str3 = str1.substring(str2.length());
/*     */     
/* 214 */     if (paramString1 != null && paramString1.length() > 0) {
/* 215 */       str3 = paramString1 + File.separatorChar + str3;
/* 216 */     } else if (paramString2 != null && paramString2.length() > 0) {
/* 217 */       str3 = paramString2 + File.separatorChar + paramFile1.getName();
/*     */     } 
/* 219 */     str3 = str3.replace('/', File.separatorChar);
/*     */     
/* 221 */     File file1 = new File(paramFile3, str3);
/* 222 */     String str4 = file1.getAbsolutePath();
/* 223 */     File file2 = file1.getParentFile();
/*     */     
/* 225 */     file2.mkdirs();
/* 226 */     copyFile(str1, str4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public void copyFile(String paramString1, String paramString2) throws IOException, FileNotFoundException { FileUtils.copy(new File(paramString1), new File(paramString2)); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\wsgen\ClientJar.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */