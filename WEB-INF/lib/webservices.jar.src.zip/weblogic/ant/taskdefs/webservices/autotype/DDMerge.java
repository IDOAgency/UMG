package weblogic.ant.taskdefs.webservices.autotype;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Iterator;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.FileList;
import weblogic.xml.xmlnode.XMLNode;

public class DDMerge extends Task {
  private FileList filelist;
  
  private File targetDD;
  
  private boolean useSOAP12 = false;
  
  public FileList createFileList() {
    if (this.filelist == null)
      this.filelist = new FileList(); 
    return this.filelist;
  }
  
  public void setFileList(FileList paramFileList) { this.filelist = paramFileList; }
  
  public void setTargetDD(File paramFile) { this.targetDD = paramFile; }
  
  public void setInternal_useSOAP12(boolean paramBoolean) { this.useSOAP12 = paramBoolean; }
  
  public void execute() {
    if (this.filelist == null)
      throw new BuildException("filelist not specified"); 
    if (this.targetDD == null)
      throw new BuildException("targetDD not specified"); 
    if (this.targetDD.exists())
      throw new BuildException("Target DD all ready exists" + this.targetDD); 
    try {
      mergeDDs();
    } catch (IOException iOException) {
      throw new BuildException("Failed to merge dd files " + iOException, iOException);
    } 
  }
  
  private void mergeDDs() {
    String[] arrayOfString = this.filelist.getFiles(getProject());
    File file = this.filelist.getDir(getProject());
    if (arrayOfString == null || arrayOfString.length == 0)
      throw new BuildException("Source DD Files not specified"); 
    XMLNode[] arrayOfXMLNode = loadDDFiles(file, arrayOfString);
    XMLNode xMLNode = new XMLNode();
    xMLNode.setName("web-services", null, null);
    populateTargetDD(xMLNode, arrayOfXMLNode);
    PrintStream printStream = new PrintStream(new FileOutputStream(this.targetDD));
    printStream.print(xMLNode);
    printStream.close();
  }
  
  private void populateTargetDD(XMLNode paramXMLNode, XMLNode[] paramArrayOfXMLNode) {
    byte b;
    for (b = 0; b < paramArrayOfXMLNode.length; b++)
      populateHandlerChain(paramXMLNode, paramArrayOfXMLNode[b]); 
    for (b = 0; b < paramArrayOfXMLNode.length; b++)
      populateWebServices(paramXMLNode, paramArrayOfXMLNode[b]); 
  }
  
  private void populateWebServices(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
    for (Iterator iterator = paramXMLNode2.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("web-service".equals(xMLNode.getName().getLocalName())) {
        if (this.useSOAP12)
          xMLNode.addAttribute("useSOAP12", null, null, "true"); 
        paramXMLNode1.addChild(xMLNode);
      } 
    } 
  }
  
  private void populateHandlerChain(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
    for (Iterator iterator = paramXMLNode2.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("handler-chains".equals(xMLNode.getName().getLocalName())) {
        XMLNode xMLNode1 = getHandlerChains(paramXMLNode1);
        addToTargetChains(xMLNode1, xMLNode);
      } 
    } 
  }
  
  private XMLNode getHandlerChains(XMLNode paramXMLNode) {
    for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("handler-chains".equals(xMLNode.getName().getLocalName()))
        return xMLNode; 
    } 
    return paramXMLNode.addChild("handler-chains", null, null);
  }
  
  private void addToTargetChains(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
    for (Iterator iterator = paramXMLNode2.getChildren(); iterator.hasNext();)
      paramXMLNode1.addChild((XMLNode)iterator.next()); 
  }
  
  private XMLNode[] loadDDFiles(File paramFile, String[] paramArrayOfString) throws IOException {
    XMLNode[] arrayOfXMLNode = new XMLNode[paramArrayOfString.length];
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      arrayOfXMLNode[b] = new XMLNode();
      arrayOfXMLNode[b].read(new FileInputStream(new File(paramFile, paramArrayOfString[b])), true);
    } 
    return arrayOfXMLNode;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\DDMerge.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */