/*     */ package weblogic.ant.taskdefs.webservices.autotype;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.FileList;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DDMerge
/*     */   extends Task
/*     */ {
/*     */   private FileList filelist;
/*     */   private File targetDD;
/*     */   private boolean useSOAP12 = false;
/*     */   
/*     */   public FileList createFileList() {
/*  27 */     if (this.filelist == null) {
/*  28 */       this.filelist = new FileList();
/*     */     }
/*     */     
/*  31 */     return this.filelist;
/*     */   }
/*     */ 
/*     */   
/*  35 */   public void setFileList(FileList paramFileList) { this.filelist = paramFileList; }
/*     */ 
/*     */ 
/*     */   
/*  39 */   public void setTargetDD(File paramFile) { this.targetDD = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  43 */   public void setInternal_useSOAP12(boolean paramBoolean) { this.useSOAP12 = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute() {
/*  48 */     if (this.filelist == null) {
/*  49 */       throw new BuildException("filelist not specified");
/*     */     }
/*     */     
/*  52 */     if (this.targetDD == null) {
/*  53 */       throw new BuildException("targetDD not specified");
/*     */     }
/*     */     
/*  56 */     if (this.targetDD.exists()) {
/*  57 */       throw new BuildException("Target DD all ready exists" + this.targetDD);
/*     */     }
/*     */     
/*     */     try {
/*  61 */       mergeDDs();
/*  62 */     } catch (IOException iOException) {
/*  63 */       throw new BuildException("Failed to merge dd files " + iOException, iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void mergeDDs() {
/*  69 */     String[] arrayOfString = this.filelist.getFiles(getProject());
/*  70 */     File file = this.filelist.getDir(getProject());
/*     */     
/*  72 */     if (arrayOfString == null || arrayOfString.length == 0) {
/*  73 */       throw new BuildException("Source DD Files not specified");
/*     */     }
/*     */     
/*  76 */     XMLNode[] arrayOfXMLNode = loadDDFiles(file, arrayOfString);
/*     */     
/*  78 */     XMLNode xMLNode = new XMLNode();
/*  79 */     xMLNode.setName("web-services", null, null);
/*     */     
/*  81 */     populateTargetDD(xMLNode, arrayOfXMLNode);
/*     */     
/*  83 */     PrintStream printStream = new PrintStream(new FileOutputStream(this.targetDD));
/*  84 */     printStream.print(xMLNode);
/*  85 */     printStream.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private void populateTargetDD(XMLNode paramXMLNode, XMLNode[] paramArrayOfXMLNode) {
/*     */     byte b;
/*  91 */     for (b = 0; b < paramArrayOfXMLNode.length; b++) {
/*  92 */       populateHandlerChain(paramXMLNode, paramArrayOfXMLNode[b]);
/*     */     }
/*     */     
/*  95 */     for (b = 0; b < paramArrayOfXMLNode.length; b++) {
/*  96 */       populateWebServices(paramXMLNode, paramArrayOfXMLNode[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateWebServices(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
/* 103 */     for (Iterator iterator = paramXMLNode2.getChildren(); iterator.hasNext(); ) {
/* 104 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 106 */       if ("web-service".equals(xMLNode.getName().getLocalName())) {
/*     */         
/* 108 */         if (this.useSOAP12) {
/* 109 */           xMLNode.addAttribute("useSOAP12", null, null, "true");
/*     */         }
/*     */         
/* 112 */         paramXMLNode1.addChild(xMLNode);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateHandlerChain(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
/* 120 */     for (Iterator iterator = paramXMLNode2.getChildren(); iterator.hasNext(); ) {
/* 121 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 123 */       if ("handler-chains".equals(xMLNode.getName().getLocalName())) {
/* 124 */         XMLNode xMLNode1 = getHandlerChains(paramXMLNode1);
/* 125 */         addToTargetChains(xMLNode1, xMLNode);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private XMLNode getHandlerChains(XMLNode paramXMLNode) {
/* 131 */     for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 132 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 134 */       if ("handler-chains".equals(xMLNode.getName().getLocalName())) {
/* 135 */         return xMLNode;
/*     */       }
/*     */     } 
/*     */     
/* 139 */     return paramXMLNode.addChild("handler-chains", null, null);
/*     */   }
/*     */   
/*     */   private void addToTargetChains(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
/* 143 */     for (Iterator iterator = paramXMLNode2.getChildren(); iterator.hasNext();) {
/* 144 */       paramXMLNode1.addChild((XMLNode)iterator.next());
/*     */     }
/*     */   }
/*     */   
/*     */   private XMLNode[] loadDDFiles(File paramFile, String[] paramArrayOfString) throws IOException {
/* 149 */     XMLNode[] arrayOfXMLNode = new XMLNode[paramArrayOfString.length];
/*     */     
/* 151 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 152 */       arrayOfXMLNode[b] = new XMLNode();
/* 153 */       arrayOfXMLNode[b].read(new FileInputStream(new File(paramFile, paramArrayOfString[b])), true);
/*     */     } 
/*     */ 
/*     */     
/* 157 */     return arrayOfXMLNode;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\DDMerge.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */