package weblogic.ant.taskdefs.webservices.autotype;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import weblogic.management.descriptors.webservice.ComponentMBean;
import weblogic.management.descriptors.webservice.FaultMBeanImpl;
import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.OperationMBeanImpl;
import weblogic.management.descriptors.webservice.ParamMBeanImpl;
import weblogic.management.descriptors.webservice.ParamsMBean;
import weblogic.management.descriptors.webservice.ParamsMBeanImpl;
import weblogic.management.descriptors.webservice.ReturnParamMBeanImpl;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.webservice.dd.ComponentIntrospector;
import weblogic.webservice.dd.MethodDescriptor;
import weblogic.webservice.tools.MethodIterator;
import weblogic.webservice.tools.ParamIterator;
import weblogic.webservice.util.ExceptionUtil;
import weblogic.webservice.util.HolderUtil;
import weblogic.webservice.util.SmartNameStore;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.TypeMappingBuilder;
import weblogic.xml.stream.ElementFactory;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.xmlnode.XMLNodeSet;

public abstract class ComponentAutoTyper extends AutoTyper {
  protected static final Class HOLDER_CLASS = javax.xml.rpc.holders.Holder.class;
  
  protected String protocol;
  
  protected HashSet opNames = new HashSet();
  
  public ComponentAutoTyper(File paramFile, String paramString, Task paramTask) { super(paramFile, paramString, paramTask); }
  
  public void setProtocol(String paramString) { this.protocol = paramString; }
  
  private static void addMapping(Class[] paramArrayOfClass, TypeMappingBuilder paramTypeMappingBuilder) throws BindingException { paramTypeMappingBuilder.addMapping(paramArrayOfClass); }
  
  protected void mapComponent(ComponentIntrospector paramComponentIntrospector, TypeMappingBuilder paramTypeMappingBuilder) {
    if (DEBUG)
      System.out.println("Processing component " + paramComponentIntrospector); 
    try {
      HashSet hashSet = new HashSet();
      MethodIterator methodIterator = paramComponentIntrospector.getMethods();
      while (methodIterator.hasNext()) {
        Method method = methodIterator.next();
        Class[] arrayOfClass1 = method.getExceptionTypes();
        for (byte b = 0; b < arrayOfClass1.length; b++) {
          this.extraClasses.add(arrayOfClass1[b].getName());
          if (!java.rmi.RemoteException.class.isAssignableFrom(arrayOfClass1[b]))
            if (!RuntimeException.class.isAssignableFrom(arrayOfClass1[b]))
              if (!Exception.class.equals(arrayOfClass1[b]))
                if (!arrayOfClass1[b].getName().startsWith("java.sql"))
                  if (ExceptionUtil.getSingleSimpleProperty(arrayOfClass1[b]) == null)
                    hashSet.add(arrayOfClass1[b]);     
        } 
      } 
      if (!"document".equals(this.style)) {
        methodIterator = paramComponentIntrospector.getMethods();
        while (methodIterator.hasNext()) {
          ParamIterator paramIterator = new ParamIterator(methodIterator.next());
          Class clazz = paramIterator.getReturnType();
          if (clazz != null && clazz != void.class)
            hashSet.add(clazz); 
          while (paramIterator.hasNext()) {
            Class clazz1 = paramIterator.next();
            hashSet.add(HolderUtil.getRealType(clazz1));
          } 
        } 
      } 
      Class[] arrayOfClass = new Class[hashSet.size()];
      hashSet.toArray(arrayOfClass);
      if (DEBUG)
        System.out.println("Adding: " + hashSet); 
      addMapping(arrayOfClass, paramTypeMappingBuilder);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new BuildException(classNotFoundException);
    } catch (BindingException bindingException) {
      throw new BuildException(bindingException);
    } 
  }
  
  protected OperationMBean createMetaOperation(ComponentMBean paramComponentMBean) {
    OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
    operationMBeanImpl.setMethod("*");
    operationMBeanImpl.setComponent(paramComponentMBean);
    operationMBeanImpl.setComponentName(paramComponentMBean.getComponentName());
    return operationMBeanImpl;
  }
  
  protected OperationMBean[] createExpandedOperations(ComponentMBean paramComponentMBean, TypeMapping paramTypeMapping, ComponentIntrospector paramComponentIntrospector) {
    if (DEBUG)
      try {
        System.out.println("Typemapping ...");
        XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(System.out);
        paramTypeMapping.writeXML(xMLOutputStream);
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
    if ("documentwrapped".equals(this.style))
      return createDocWrpStyleOperations(paramComponentMBean, paramTypeMapping, paramComponentIntrospector); 
    if ("rpc".equals(this.style))
      return createRpcStyleOperations(paramComponentMBean, paramTypeMapping, paramComponentIntrospector, false); 
    return createDocStyleOperations(paramComponentMBean, paramTypeMapping, paramComponentIntrospector);
  }
  
  protected OperationMBean[] createDocWrpStyleOperations(ComponentMBean paramComponentMBean, TypeMapping paramTypeMapping, ComponentIntrospector paramComponentIntrospector) { return createRpcStyleOperations(paramComponentMBean, paramTypeMapping, paramComponentIntrospector, true); }
  
  protected OperationMBean[] createDocStyleOperations(ComponentMBean paramComponentMBean, TypeMapping paramTypeMapping, ComponentIntrospector paramComponentIntrospector) {
    ArrayList arrayList1 = new ArrayList();
    MethodIterator methodIterator = null;
    try {
      methodIterator = paramComponentIntrospector.getMethods();
    } catch (ClassNotFoundException classNotFoundException) {
      throw new BuildException("Could not load component class", classNotFoundException);
    } 
    ArrayList arrayList2 = new ArrayList();
    ArrayList arrayList3 = new ArrayList();
    while (methodIterator.hasNext()) {
      Method method = methodIterator.next();
      OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
      String str = getUniqueName(method.getName());
      operationMBeanImpl.setComponent(paramComponentMBean);
      operationMBeanImpl.setComponentName(paramComponentMBean.getComponentName());
      operationMBeanImpl.setOperationName(str);
      operationMBeanImpl.setMethod((new MethodDescriptor(method)).getMethodString());
      ParamsMBeanImpl paramsMBeanImpl = new ParamsMBeanImpl();
      ParamIterator paramIterator = new ParamIterator(method);
      Iterator iterator = (new SmartNameStore()).getNames(method);
      Class clazz = paramIterator.getReturnType();
      if (paramIterator.hasNext()) {
        Class clazz1 = paramIterator.next();
        if (paramIterator.hasNext()) {
          System.err.println("WARNING: Backend components for Document style webservice can only accept methods with one input parameter. Method \"" + method.getName() + "\" of the " + "component \"" + paramComponentIntrospector + "\" is ignored.");
          continue;
        } 
        arrayList2.add(clazz1);
        ParamMBeanImpl paramMBeanImpl = new ParamMBeanImpl();
        paramMBeanImpl.setParamName((String)iterator.next());
        paramMBeanImpl.setClassName(clazz1.getName());
        if (HOLDER_CLASS.isAssignableFrom(clazz1)) {
          clazz1 = HolderUtil.getRealType(clazz1);
          paramMBeanImpl.setParamStyle("inout");
        } else {
          paramMBeanImpl.setParamStyle("in");
        } 
        if (isAttachment(clazz1)) {
          paramMBeanImpl.setLocation("attachment");
        } else {
          paramMBeanImpl.setLocation("body");
        } 
        XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, str);
        arrayList3.add(xMLName);
        paramMBeanImpl.setParamType(prefixIfNeeded(xMLName));
        paramsMBeanImpl.addParam(paramMBeanImpl);
      } 
      if (clazz != null && !void.class.equals(clazz)) {
        ReturnParamMBeanImpl returnParamMBeanImpl = new ReturnParamMBeanImpl();
        returnParamMBeanImpl.setParamName("result");
        if (isAttachment(clazz)) {
          returnParamMBeanImpl.setLocation("attachment");
        } else {
          returnParamMBeanImpl.setLocation("body");
        } 
        returnParamMBeanImpl.setClassName(clazz.getName());
        XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, str + "Response");
        returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
        paramsMBeanImpl.setReturnParam(returnParamMBeanImpl);
        arrayList2.add(clazz);
        arrayList3.add(xMLName);
      } 
      addFaultInfo(paramsMBeanImpl, method, paramTypeMapping);
      if ((paramsMBeanImpl.getParams() != null && paramsMBeanImpl.getParams().length > 0) || (paramsMBeanImpl.getFaults() != null && paramsMBeanImpl.getFaults().length > 0))
        operationMBeanImpl.setParams(paramsMBeanImpl); 
      arrayList1.add(operationMBeanImpl);
    } 
    Class[] arrayOfClass = new Class[arrayList2.size()];
    arrayList2.toArray(arrayOfClass);
    XMLName[] arrayOfXMLName = new XMLName[arrayList3.size()];
    arrayList3.toArray(arrayOfXMLName);
    try {
      this.tbuilder.addMapping(arrayOfClass, arrayOfXMLName);
    } catch (BindingException bindingException) {
      throw new BuildException(bindingException);
    } 
    return (OperationMBean[])arrayList1.toArray(new OperationMBean[0]);
  }
  
  protected OperationMBean[] createRpcStyleOperations(ComponentMBean paramComponentMBean, TypeMapping paramTypeMapping, ComponentIntrospector paramComponentIntrospector, boolean paramBoolean) {
    ArrayList arrayList = new ArrayList();
    MethodIterator methodIterator = null;
    try {
      methodIterator = paramComponentIntrospector.getMethods();
    } catch (ClassNotFoundException classNotFoundException) {
      throw new BuildException("Could not load component class", classNotFoundException);
    } 
    while (methodIterator.hasNext()) {
      Method method = methodIterator.next();
      OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
      String str = getUniqueName(method.getName());
      operationMBeanImpl.setComponent(paramComponentMBean);
      operationMBeanImpl.setComponentName(paramComponentMBean.getComponentName());
      operationMBeanImpl.setOperationName(str);
      operationMBeanImpl.setMethod((new MethodDescriptor(method)).getMethodString());
      ParamsMBeanImpl paramsMBeanImpl = new ParamsMBeanImpl();
      ParamIterator paramIterator = new ParamIterator(method);
      Iterator iterator = (new SmartNameStore()).getNames(method);
      Class clazz = paramIterator.getReturnType();
      if (clazz != null && !void.class.equals(clazz)) {
        ReturnParamMBeanImpl returnParamMBeanImpl = new ReturnParamMBeanImpl();
        returnParamMBeanImpl.setParamName("result");
        if (isAttachment(clazz) && !paramBoolean) {
          returnParamMBeanImpl.setLocation("attachment");
        } else {
          returnParamMBeanImpl.setLocation("body");
        } 
        returnParamMBeanImpl.setClassName(clazz.getName());
        XMLName xMLName = prefixIfNeeded(paramTypeMapping.getXMLNameFromClass(clazz));
        xMLName = prefixIfNeeded(xMLName);
        if (xMLName == null)
          throw new BuildException("Could not find a type mapping that maps Java type " + clazz.getName() + " to an XML type"); 
        returnParamMBeanImpl.setParamType(xMLName);
        paramsMBeanImpl.setReturnParam(returnParamMBeanImpl);
        if (paramBoolean)
          try {
            this.tbuilder.addWrappedSchemaType(new Class[] { clazz }, new String[] { returnParamMBeanImpl.getParamName() }, ElementFactory.createXMLName(this.targetNSURI, str + "Response"));
          } catch (BindingException bindingException) {
            throw new BuildException("Failed to wrap schemas.", bindingException);
          }  
      } 
      ArrayList arrayList1 = new ArrayList();
      ArrayList arrayList2 = new ArrayList();
      for (b = 0; paramIterator.hasNext(); b++) {
        Class clazz1 = paramIterator.next();
        if (!void.class.equals(clazz1)) {
          arrayList1.add(clazz1);
          ParamMBeanImpl paramMBeanImpl = new ParamMBeanImpl();
          paramMBeanImpl.setParamName((String)iterator.next());
          paramMBeanImpl.setClassName(clazz1.getName());
          arrayList2.add(paramMBeanImpl.getParamName());
          if (HOLDER_CLASS.isAssignableFrom(clazz1)) {
            clazz1 = HolderUtil.getRealType(clazz1);
            paramMBeanImpl.setParamStyle("inout");
          } else {
            paramMBeanImpl.setParamStyle("in");
          } 
          if (isAttachment(clazz1) && !paramBoolean) {
            paramMBeanImpl.setLocation("attachment");
          } else {
            paramMBeanImpl.setLocation("body");
          } 
          XMLName xMLName = prefixIfNeeded(paramTypeMapping.getXMLNameFromClass(clazz1));
          if (xMLName == null)
            throw new BuildException("Could not find a type mapping that maps Java type " + clazz1.getName() + " to an XML type"); 
          paramMBeanImpl.setParamType(xMLName);
          paramsMBeanImpl.addParam(paramMBeanImpl);
        } 
      } 
      if (paramBoolean)
        try {
          this.tbuilder.addWrappedSchemaType((Class[])arrayList1.toArray(new Class[0]), (String[])arrayList2.toArray(new String[0]), ElementFactory.createXMLName(this.targetNSURI, str));
        } catch (BindingException b) {
          BindingException bindingException;
          throw new BuildException("Failed to wrap schemas.", bindingException);
        }  
      addFaultInfo(paramsMBeanImpl, method, paramTypeMapping);
      if ((paramsMBeanImpl.getParams() != null && paramsMBeanImpl.getParams().length > 0) || (paramsMBeanImpl.getFaults() != null && paramsMBeanImpl.getFaults().length > 0))
        operationMBeanImpl.setParams(paramsMBeanImpl); 
      arrayList.add(operationMBeanImpl);
    } 
    return (OperationMBean[])arrayList.toArray(new OperationMBean[0]);
  }
  
  private String getUniqueName(String paramString) {
    String str = paramString;
    byte b = 0;
    while (this.opNames.contains(str)) {
      str = paramString + b;
      b++;
    } 
    this.opNames.add(str);
    return str;
  }
  
  private void addFaultInfo(ParamsMBean paramParamsMBean, Method paramMethod, TypeMapping paramTypeMapping) {
    Class[] arrayOfClass = paramMethod.getExceptionTypes();
    for (byte b = 0; b < arrayOfClass.length; b++) {
      if (!java.rmi.RemoteException.class.isAssignableFrom(arrayOfClass[b]))
        if (!RuntimeException.class.isAssignableFrom(arrayOfClass[b]))
          if (!Exception.class.equals(arrayOfClass[b]))
            if (!arrayOfClass[b].getName().startsWith("java.sql")) {
              FaultMBeanImpl faultMBeanImpl = new FaultMBeanImpl();
              String str = arrayOfClass[b].getName();
              faultMBeanImpl.setClassName(str);
              faultMBeanImpl.setFaultName(str.substring(str.lastIndexOf(".") + 1));
              Class clazz = ExceptionUtil.getSingleSimpleProperty(arrayOfClass[b]);
              XMLName xMLName = null;
              if (clazz != null) {
                xMLName = paramTypeMapping.getXMLNameFromClass(clazz);
              } else {
                xMLName = paramTypeMapping.getXMLNameFromClass(arrayOfClass[b]);
              } 
              if (xMLName == null)
                throw new AssertionError("Failed to process exception " + arrayOfClass[b]); 
              xMLName = prefixIfNeeded(xMLName);
              faultMBeanImpl.setFaultType(xMLName);
              paramParamsMBean.addFault(faultMBeanImpl);
            }    
    } 
  }
  
  public abstract void run();
  
  public abstract WebServiceMBean getWebServiceDescriptor();
  
  public abstract XMLNodeSet getTypes();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\ComponentAutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */