/*     */ package weblogic.ant.taskdefs.webservices.autotype;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import weblogic.management.descriptors.webservice.ComponentMBean;
/*     */ import weblogic.management.descriptors.webservice.FaultMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.OperationMBean;
/*     */ import weblogic.management.descriptors.webservice.OperationMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.ParamMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.ParamsMBean;
/*     */ import weblogic.management.descriptors.webservice.ParamsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.ReturnParamMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.webservice.dd.ComponentIntrospector;
/*     */ import weblogic.webservice.dd.MethodDescriptor;
/*     */ import weblogic.webservice.tools.MethodIterator;
/*     */ import weblogic.webservice.tools.ParamIterator;
/*     */ import weblogic.webservice.util.ExceptionUtil;
/*     */ import weblogic.webservice.util.HolderUtil;
/*     */ import weblogic.webservice.util.SmartNameStore;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilder;
/*     */ import weblogic.xml.stream.ElementFactory;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.xmlnode.XMLNodeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ComponentAutoTyper
/*     */   extends AutoTyper
/*     */ {
/*  54 */   protected static final Class HOLDER_CLASS = javax.xml.rpc.holders.Holder.class;
/*     */   
/*     */   protected String protocol;
/*  57 */   protected HashSet opNames = new HashSet();
/*     */ 
/*     */   
/*  60 */   public ComponentAutoTyper(File paramFile, String paramString, Task paramTask) { super(paramFile, paramString, paramTask); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public void setProtocol(String paramString) { this.protocol = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private static void addMapping(Class[] paramArrayOfClass, TypeMappingBuilder paramTypeMappingBuilder) throws BindingException { paramTypeMappingBuilder.addMapping(paramArrayOfClass); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mapComponent(ComponentIntrospector paramComponentIntrospector, TypeMappingBuilder paramTypeMappingBuilder) {
/*  96 */     if (DEBUG) System.out.println("Processing component " + paramComponentIntrospector);
/*     */     
/*     */     try {
/*  99 */       HashSet hashSet = new HashSet();
/* 100 */       MethodIterator methodIterator = paramComponentIntrospector.getMethods();
/* 101 */       while (methodIterator.hasNext()) {
/* 102 */         Method method = methodIterator.next();
/* 103 */         Class[] arrayOfClass1 = method.getExceptionTypes();
/*     */         
/* 105 */         for (byte b = 0; b < arrayOfClass1.length; b++) {
/* 106 */           this.extraClasses.add(arrayOfClass1[b].getName());
/* 107 */           if (!java.rmi.RemoteException.class.isAssignableFrom(arrayOfClass1[b]))
/*     */           {
/* 109 */             if (!RuntimeException.class.isAssignableFrom(arrayOfClass1[b]))
/*     */             {
/* 111 */               if (!Exception.class.equals(arrayOfClass1[b]))
/*     */               {
/*     */                 
/* 114 */                 if (!arrayOfClass1[b].getName().startsWith("java.sql"))
/*     */                 {
/* 116 */                   if (ExceptionUtil.getSingleSimpleProperty(arrayOfClass1[b]) == null)
/* 117 */                     hashSet.add(arrayOfClass1[b]);  }  } 
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/* 122 */       if (!"document".equals(this.style)) {
/*     */ 
/*     */         
/* 125 */         methodIterator = paramComponentIntrospector.getMethods();
/* 126 */         while (methodIterator.hasNext()) {
/* 127 */           ParamIterator paramIterator = new ParamIterator(methodIterator.next());
/* 128 */           Class clazz = paramIterator.getReturnType();
/* 129 */           if (clazz != null && clazz != void.class) {
/* 130 */             hashSet.add(clazz);
/*     */           }
/* 132 */           while (paramIterator.hasNext()) {
/* 133 */             Class clazz1 = paramIterator.next();
/* 134 */             hashSet.add(HolderUtil.getRealType(clazz1));
/*     */           } 
/*     */         } 
/*     */       } 
/* 138 */       Class[] arrayOfClass = new Class[hashSet.size()];
/* 139 */       hashSet.toArray(arrayOfClass);
/* 140 */       if (DEBUG) System.out.println("Adding: " + hashSet); 
/* 141 */       addMapping(arrayOfClass, paramTypeMappingBuilder);
/* 142 */     } catch (ClassNotFoundException classNotFoundException) {
/* 143 */       throw new BuildException(classNotFoundException);
/* 144 */     } catch (BindingException bindingException) {
/* 145 */       throw new BuildException(bindingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OperationMBean createMetaOperation(ComponentMBean paramComponentMBean) {
/* 154 */     OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 155 */     operationMBeanImpl.setMethod("*");
/* 156 */     operationMBeanImpl.setComponent(paramComponentMBean);
/* 157 */     operationMBeanImpl.setComponentName(paramComponentMBean.getComponentName());
/* 158 */     return operationMBeanImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OperationMBean[] createExpandedOperations(ComponentMBean paramComponentMBean, TypeMapping paramTypeMapping, ComponentIntrospector paramComponentIntrospector) {
/* 168 */     if (DEBUG) {
/*     */       
/* 170 */       try { System.out.println("Typemapping ...");
/* 171 */         XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(System.out);
/* 172 */         paramTypeMapping.writeXML(xMLOutputStream); }
/* 173 */       catch (Exception exception) { exception.printStackTrace(); }
/*     */     
/*     */     }
/* 176 */     if ("documentwrapped".equals(this.style))
/* 177 */       return createDocWrpStyleOperations(paramComponentMBean, paramTypeMapping, paramComponentIntrospector); 
/* 178 */     if ("rpc".equals(this.style)) {
/* 179 */       return createRpcStyleOperations(paramComponentMBean, paramTypeMapping, paramComponentIntrospector, false);
/*     */     }
/* 181 */     return createDocStyleOperations(paramComponentMBean, paramTypeMapping, paramComponentIntrospector);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   protected OperationMBean[] createDocWrpStyleOperations(ComponentMBean paramComponentMBean, TypeMapping paramTypeMapping, ComponentIntrospector paramComponentIntrospector) { return createRpcStyleOperations(paramComponentMBean, paramTypeMapping, paramComponentIntrospector, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OperationMBean[] createDocStyleOperations(ComponentMBean paramComponentMBean, TypeMapping paramTypeMapping, ComponentIntrospector paramComponentIntrospector) {
/* 200 */     ArrayList arrayList1 = new ArrayList();
/* 201 */     MethodIterator methodIterator = null;
/*     */     
/*     */     try {
/* 204 */       methodIterator = paramComponentIntrospector.getMethods();
/* 205 */     } catch (ClassNotFoundException classNotFoundException) {
/* 206 */       throw new BuildException("Could not load component class", classNotFoundException);
/*     */     } 
/*     */     
/* 209 */     ArrayList arrayList2 = new ArrayList();
/* 210 */     ArrayList arrayList3 = new ArrayList();
/*     */     
/* 212 */     while (methodIterator.hasNext()) {
/* 213 */       Method method = methodIterator.next();
/* 214 */       OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 215 */       String str = getUniqueName(method.getName());
/* 216 */       operationMBeanImpl.setComponent(paramComponentMBean);
/* 217 */       operationMBeanImpl.setComponentName(paramComponentMBean.getComponentName());
/* 218 */       operationMBeanImpl.setOperationName(str);
/* 219 */       operationMBeanImpl.setMethod((new MethodDescriptor(method)).getMethodString());
/* 220 */       ParamsMBeanImpl paramsMBeanImpl = new ParamsMBeanImpl();
/* 221 */       ParamIterator paramIterator = new ParamIterator(method);
/* 222 */       Iterator iterator = (new SmartNameStore()).getNames(method);
/* 223 */       Class clazz = paramIterator.getReturnType();
/*     */       
/* 225 */       if (paramIterator.hasNext()) {
/* 226 */         Class clazz1 = paramIterator.next();
/* 227 */         if (paramIterator.hasNext()) {
/* 228 */           System.err.println("WARNING: Backend components for Document style webservice can only accept methods with one input parameter. Method \"" + method.getName() + "\" of the " + "component \"" + paramComponentIntrospector + "\" is ignored.");
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/* 235 */         arrayList2.add(clazz1);
/*     */         
/* 237 */         ParamMBeanImpl paramMBeanImpl = new ParamMBeanImpl();
/* 238 */         paramMBeanImpl.setParamName((String)iterator.next());
/* 239 */         paramMBeanImpl.setClassName(clazz1.getName());
/* 240 */         if (HOLDER_CLASS.isAssignableFrom(clazz1)) {
/* 241 */           clazz1 = HolderUtil.getRealType(clazz1);
/* 242 */           paramMBeanImpl.setParamStyle("inout");
/*     */         } else {
/* 244 */           paramMBeanImpl.setParamStyle("in");
/*     */         } 
/*     */         
/* 247 */         if (isAttachment(clazz1)) {
/* 248 */           paramMBeanImpl.setLocation("attachment");
/*     */         } else {
/* 250 */           paramMBeanImpl.setLocation("body");
/*     */         } 
/*     */         
/* 253 */         XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, str);
/* 254 */         arrayList3.add(xMLName);
/*     */         
/* 256 */         paramMBeanImpl.setParamType(prefixIfNeeded(xMLName));
/* 257 */         paramsMBeanImpl.addParam(paramMBeanImpl);
/*     */       } 
/*     */       
/* 260 */       if (clazz != null && !void.class.equals(clazz)) {
/* 261 */         ReturnParamMBeanImpl returnParamMBeanImpl = new ReturnParamMBeanImpl();
/* 262 */         returnParamMBeanImpl.setParamName("result");
/*     */         
/* 264 */         if (isAttachment(clazz)) {
/* 265 */           returnParamMBeanImpl.setLocation("attachment");
/*     */         } else {
/* 267 */           returnParamMBeanImpl.setLocation("body");
/*     */         } 
/*     */         
/* 270 */         returnParamMBeanImpl.setClassName(clazz.getName());
/* 271 */         XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, str + "Response");
/*     */         
/* 273 */         returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
/* 274 */         paramsMBeanImpl.setReturnParam(returnParamMBeanImpl);
/* 275 */         arrayList2.add(clazz);
/* 276 */         arrayList3.add(xMLName);
/*     */       } 
/*     */       
/* 279 */       addFaultInfo(paramsMBeanImpl, method, paramTypeMapping);
/*     */       
/* 281 */       if ((paramsMBeanImpl.getParams() != null && paramsMBeanImpl.getParams().length > 0) || (paramsMBeanImpl.getFaults() != null && paramsMBeanImpl.getFaults().length > 0))
/*     */       {
/* 283 */         operationMBeanImpl.setParams(paramsMBeanImpl);
/*     */       }
/*     */       
/* 286 */       arrayList1.add(operationMBeanImpl);
/*     */     } 
/*     */     
/* 289 */     Class[] arrayOfClass = new Class[arrayList2.size()];
/* 290 */     arrayList2.toArray(arrayOfClass);
/* 291 */     XMLName[] arrayOfXMLName = new XMLName[arrayList3.size()];
/* 292 */     arrayList3.toArray(arrayOfXMLName);
/*     */     try {
/* 294 */       this.tbuilder.addMapping(arrayOfClass, arrayOfXMLName);
/* 295 */     } catch (BindingException bindingException) {
/* 296 */       throw new BuildException(bindingException);
/*     */     } 
/*     */     
/* 299 */     return (OperationMBean[])arrayList1.toArray(new OperationMBean[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected OperationMBean[] createRpcStyleOperations(ComponentMBean paramComponentMBean, TypeMapping paramTypeMapping, ComponentIntrospector paramComponentIntrospector, boolean paramBoolean) {
/* 305 */     ArrayList arrayList = new ArrayList();
/* 306 */     MethodIterator methodIterator = null;
/*     */     
/*     */     try {
/* 309 */       methodIterator = paramComponentIntrospector.getMethods();
/* 310 */     } catch (ClassNotFoundException classNotFoundException) {
/* 311 */       throw new BuildException("Could not load component class", classNotFoundException);
/*     */     } 
/*     */     
/* 314 */     while (methodIterator.hasNext()) {
/* 315 */       Method method = methodIterator.next();
/* 316 */       OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 317 */       String str = getUniqueName(method.getName());
/* 318 */       operationMBeanImpl.setComponent(paramComponentMBean);
/* 319 */       operationMBeanImpl.setComponentName(paramComponentMBean.getComponentName());
/* 320 */       operationMBeanImpl.setOperationName(str);
/* 321 */       operationMBeanImpl.setMethod((new MethodDescriptor(method)).getMethodString());
/* 322 */       ParamsMBeanImpl paramsMBeanImpl = new ParamsMBeanImpl();
/* 323 */       ParamIterator paramIterator = new ParamIterator(method);
/* 324 */       Iterator iterator = (new SmartNameStore()).getNames(method);
/* 325 */       Class clazz = paramIterator.getReturnType();
/*     */       
/* 327 */       if (clazz != null && !void.class.equals(clazz)) {
/* 328 */         ReturnParamMBeanImpl returnParamMBeanImpl = new ReturnParamMBeanImpl();
/* 329 */         returnParamMBeanImpl.setParamName("result");
/*     */         
/* 331 */         if (isAttachment(clazz) && !paramBoolean) {
/* 332 */           returnParamMBeanImpl.setLocation("attachment");
/*     */         } else {
/* 334 */           returnParamMBeanImpl.setLocation("body");
/*     */         } 
/*     */         
/* 337 */         returnParamMBeanImpl.setClassName(clazz.getName());
/* 338 */         XMLName xMLName = prefixIfNeeded(paramTypeMapping.getXMLNameFromClass(clazz));
/*     */         
/* 340 */         xMLName = prefixIfNeeded(xMLName);
/* 341 */         if (xMLName == null) {
/* 342 */           throw new BuildException("Could not find a type mapping that maps Java type " + clazz.getName() + " to an XML type");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 347 */         returnParamMBeanImpl.setParamType(xMLName);
/*     */         
/* 349 */         paramsMBeanImpl.setReturnParam(returnParamMBeanImpl);
/*     */         
/* 351 */         if (paramBoolean) {
/*     */           try {
/* 353 */             this.tbuilder.addWrappedSchemaType(new Class[] { clazz }, new String[] { returnParamMBeanImpl.getParamName() }, ElementFactory.createXMLName(this.targetNSURI, str + "Response"));
/*     */ 
/*     */           
/*     */           }
/* 357 */           catch (BindingException bindingException) {
/* 358 */             throw new BuildException("Failed to wrap schemas.", bindingException);
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 364 */       ArrayList arrayList1 = new ArrayList();
/* 365 */       ArrayList arrayList2 = new ArrayList();
/* 366 */       for (b = 0; paramIterator.hasNext(); b++) {
/* 367 */         Class clazz1 = paramIterator.next();
/* 368 */         if (!void.class.equals(clazz1)) {
/*     */ 
/*     */           
/* 371 */           arrayList1.add(clazz1);
/*     */           
/* 373 */           ParamMBeanImpl paramMBeanImpl = new ParamMBeanImpl();
/* 374 */           paramMBeanImpl.setParamName((String)iterator.next());
/* 375 */           paramMBeanImpl.setClassName(clazz1.getName());
/* 376 */           arrayList2.add(paramMBeanImpl.getParamName());
/*     */           
/* 378 */           if (HOLDER_CLASS.isAssignableFrom(clazz1)) {
/* 379 */             clazz1 = HolderUtil.getRealType(clazz1);
/* 380 */             paramMBeanImpl.setParamStyle("inout");
/*     */           } else {
/* 382 */             paramMBeanImpl.setParamStyle("in");
/*     */           } 
/*     */           
/* 385 */           if (isAttachment(clazz1) && !paramBoolean) {
/* 386 */             paramMBeanImpl.setLocation("attachment");
/*     */           } else {
/* 388 */             paramMBeanImpl.setLocation("body");
/*     */           } 
/*     */           
/* 391 */           XMLName xMLName = prefixIfNeeded(paramTypeMapping.getXMLNameFromClass(clazz1));
/*     */           
/* 393 */           if (xMLName == null) {
/* 394 */             throw new BuildException("Could not find a type mapping that maps Java type " + clazz1.getName() + " to an XML type");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 399 */           paramMBeanImpl.setParamType(xMLName);
/*     */           
/* 401 */           paramsMBeanImpl.addParam(paramMBeanImpl);
/*     */         } 
/*     */       } 
/* 404 */       if (paramBoolean) {
/*     */         try {
/* 406 */           this.tbuilder.addWrappedSchemaType((Class[])arrayList1.toArray(new Class[0]), (String[])arrayList2.toArray(new String[0]), ElementFactory.createXMLName(this.targetNSURI, str));
/*     */ 
/*     */         
/*     */         }
/* 410 */         catch (BindingException b) {
/* 411 */           BindingException bindingException; throw new BuildException("Failed to wrap schemas.", bindingException);
/*     */         } 
/*     */       }
/*     */       
/* 415 */       addFaultInfo(paramsMBeanImpl, method, paramTypeMapping);
/*     */       
/* 417 */       if ((paramsMBeanImpl.getParams() != null && paramsMBeanImpl.getParams().length > 0) || (paramsMBeanImpl.getFaults() != null && paramsMBeanImpl.getFaults().length > 0))
/*     */       {
/* 419 */         operationMBeanImpl.setParams(paramsMBeanImpl);
/*     */       }
/*     */       
/* 422 */       arrayList.add(operationMBeanImpl);
/*     */     } 
/* 424 */     return (OperationMBean[])arrayList.toArray(new OperationMBean[0]);
/*     */   }
/*     */   
/*     */   private String getUniqueName(String paramString) {
/* 428 */     String str = paramString;
/*     */     
/* 430 */     byte b = 0;
/*     */     
/* 432 */     while (this.opNames.contains(str)) {
/* 433 */       str = paramString + b;
/* 434 */       b++;
/*     */     } 
/*     */     
/* 437 */     this.opNames.add(str);
/* 438 */     return str;
/*     */   }
/*     */   
/*     */   private void addFaultInfo(ParamsMBean paramParamsMBean, Method paramMethod, TypeMapping paramTypeMapping) {
/* 442 */     Class[] arrayOfClass = paramMethod.getExceptionTypes();
/*     */     
/* 444 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/* 445 */       if (!java.rmi.RemoteException.class.isAssignableFrom(arrayOfClass[b]))
/*     */       {
/* 447 */         if (!RuntimeException.class.isAssignableFrom(arrayOfClass[b]))
/*     */         {
/* 449 */           if (!Exception.class.equals(arrayOfClass[b]))
/*     */           {
/*     */             
/* 452 */             if (!arrayOfClass[b].getName().startsWith("java.sql")) {
/*     */               
/* 454 */               FaultMBeanImpl faultMBeanImpl = new FaultMBeanImpl();
/*     */               
/* 456 */               String str = arrayOfClass[b].getName();
/* 457 */               faultMBeanImpl.setClassName(str);
/* 458 */               faultMBeanImpl.setFaultName(str.substring(str.lastIndexOf(".") + 1));
/*     */               
/* 460 */               Class clazz = ExceptionUtil.getSingleSimpleProperty(arrayOfClass[b]);
/*     */               
/* 462 */               XMLName xMLName = null;
/* 463 */               if (clazz != null) {
/* 464 */                 xMLName = paramTypeMapping.getXMLNameFromClass(clazz);
/*     */               } else {
/* 466 */                 xMLName = paramTypeMapping.getXMLNameFromClass(arrayOfClass[b]);
/*     */               } 
/*     */               
/* 469 */               if (xMLName == null) {
/* 470 */                 throw new AssertionError("Failed to process exception " + arrayOfClass[b]);
/*     */               }
/*     */               
/* 473 */               xMLName = prefixIfNeeded(xMLName);
/* 474 */               faultMBeanImpl.setFaultType(xMLName);
/*     */               
/* 476 */               paramParamsMBean.addFault(faultMBeanImpl);
/*     */             } 
/*     */           }
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract void run();
/*     */   
/*     */   public abstract WebServiceMBean getWebServiceDescriptor();
/*     */   
/*     */   public abstract XMLNodeSet getTypes();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\ComponentAutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */