package weblogic.ant.taskdefs.webservices.autotype;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import weblogic.application.ApplicationFileManager;
import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
import weblogic.management.descriptors.webservice.EJBLinkMBeanImpl;
import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
import weblogic.management.descriptors.webservice.StatelessEJBMBeanImpl;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
import weblogic.utils.jars.VirtualJarFile;
import weblogic.webservice.dd.EJBIntrospector;
import weblogic.webservice.dd.EJBJarIntrospector;
import weblogic.webservice.dd.EJBProcessingException;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.stream.XMLInputOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.xmlnode.XMLNodeSet;

public class EJBAutoTyper extends ComponentAutoTyper {
  private File outputDir;
  
  private File ejbJar;
  
  private EJBJarIntrospector introspector;
  
  private String[] ejbIncludes;
  
  private String[] ejbExcludes;
  
  private Collection ejbs;
  
  private static int ejbCompCounter = 0;
  
  public EJBAutoTyper(File paramFile1, String paramString, File paramFile2, String[] paramArrayOfString1, String[] paramArrayOfString2, Task paramTask) {
    super(paramFile2, paramString, paramTask);
    this.ejbJar = paramFile1;
    this.ejbIncludes = paramArrayOfString1;
    this.ejbExcludes = paramArrayOfString2;
    virtualJarFile = null;
    try {
      applicationFileManager = ApplicationFileManager.newInstance(paramFile1);
      virtualJarFile = applicationFileManager.getVirtualJarFile();
      this.introspector = new EJBJarIntrospector(virtualJarFile);
    } catch (EJBProcessingException eJBProcessingException) {
      throw new BuildException("Could not process ejb-jar", eJBProcessingException);
    } catch (IOException iOException) {
      throw new BuildException("Could not process ejb-jar", iOException);
    } finally {
      try {
        if (virtualJarFile != null)
          virtualJarFile.close(); 
      } catch (IOException iOException) {}
    } 
  }
  
  public void run() {
    try {
      createTypeMappingBuilder();
    } catch (IOException iOException) {
      throw new BuildException("Failed to create type mapping builder. ", iOException);
    } 
    if (this.generateTypes) {
      log("Running autotyper for EJB jar " + this.ejbJar, 3);
      try {
        this.ejbs = this.introspector.getEJBs();
        if (this.ejbIncludes != null)
          for (byte b = 0; b < this.ejbIncludes.length; ) {
            Iterator iterator1 = this.ejbs.iterator();
            boolean bool = false;
            while (iterator1.hasNext()) {
              String str = ((EJBIntrospector)iterator1.next()).getEJBName();
              if (str.equals(this.ejbIncludes[b])) {
                bool = true;
                break;
              } 
            } 
            if (bool) {
              b++;
              continue;
            } 
            throw new BuildException("EJBBean " + this.ejbIncludes[b] + " doesn't exist in EJBJar " + this.ejbJar.getCanonicalPath());
          }  
        Iterator iterator = this.ejbs.iterator();
        while (iterator.hasNext()) {
          EJBIntrospector eJBIntrospector = (EJBIntrospector)iterator.next();
          if (isEJBIncluded(eJBIntrospector))
            mapComponent(eJBIntrospector, this.tbuilder); 
        } 
      } catch (IOException iOException) {
        throw new BuildException(iOException);
      } 
    } 
  }
  
  private boolean isEJBIncluded(EJBIntrospector paramEJBIntrospector) {
    String str = paramEJBIntrospector.getEJBName();
    if (this.ejbIncludes == null && this.ejbExcludes == null)
      return true; 
    if (this.ejbIncludes != null && this.ejbExcludes == null) {
      for (byte b1 = 0; b1 < this.ejbIncludes.length; b1++) {
        if (str.equals(this.ejbIncludes[b1]))
          return true; 
      } 
      return false;
    } 
    if (this.ejbIncludes == null && this.ejbExcludes != null) {
      for (byte b1 = 0; b1 < this.ejbExcludes.length; b1++) {
        if (str.equals(this.ejbExcludes[b1]))
          return false; 
      } 
      return true;
    } 
    boolean bool1 = false;
    boolean bool2 = false;
    byte b;
    for (b = 0; b < this.ejbIncludes.length; b++) {
      if (str.equals(this.ejbIncludes[b])) {
        bool1 = true;
        break;
      } 
    } 
    for (b = 0; b < this.ejbExcludes.length; b++) {
      if (str.equals(this.ejbExcludes[b])) {
        bool2 = true;
        break;
      } 
    } 
    return (bool1 && !bool2);
  }
  
  public WebServiceMBean getWebServiceDescriptor() {
    WebServiceMBeanImpl webServiceMBeanImpl = new WebServiceMBeanImpl();
    webServiceMBeanImpl.setWebServiceName(this.serviceName);
    webServiceMBeanImpl.setURI(this.serviceURI);
    webServiceMBeanImpl.setTargetNamespace(this.targetNSURI);
    webServiceMBeanImpl.setProtocol(this.protocol);
    webServiceMBeanImpl.setStyle(this.style);
    webServiceMBeanImpl.setUseSOAP12(this.useSoap12);
    ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
    OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
    Iterator iterator = this.introspector.getEJBs().iterator();
    TypeMapping typeMapping = null;
    try {
      typeMapping = this.tbuilder.getTypeMapping();
    } catch (BindingException bindingException) {
      throw new BuildException("Could not get type mapping", bindingException);
    } 
    for (b = 0; iterator.hasNext(); b++) {
      EJBIntrospector eJBIntrospector = (EJBIntrospector)iterator.next();
      if (isEJBIncluded(eJBIntrospector)) {
        StatelessEJBMBeanImpl statelessEJBMBeanImpl = new StatelessEJBMBeanImpl();
        statelessEJBMBeanImpl.setComponentName("ejbcomp" + ejbCompCounter++);
        EJBLinkMBeanImpl eJBLinkMBeanImpl = new EJBLinkMBeanImpl();
        eJBLinkMBeanImpl.setPath(this.ejbJar.getName() + "#" + eJBIntrospector.getEJBName());
        statelessEJBMBeanImpl.setEJBLink(eJBLinkMBeanImpl);
        componentsMBeanImpl.addStatelessEJB(statelessEJBMBeanImpl);
        OperationMBean[] arrayOfOperationMBean = null;
        if (this.expandMethods) {
          arrayOfOperationMBean = createExpandedOperations(statelessEJBMBeanImpl, typeMapping, eJBIntrospector);
          for (byte b1 = 0; b1 < arrayOfOperationMBean.length; b1++)
            operationsMBeanImpl.addOperation(arrayOfOperationMBean[b1]); 
        } else {
          operationsMBeanImpl.addOperation(createMetaOperation(statelessEJBMBeanImpl));
        } 
      } 
    } 
    webServiceMBeanImpl.setComponents(componentsMBeanImpl);
    webServiceMBeanImpl.setOperations(operationsMBeanImpl);
    try {
      webServiceMBeanImpl.setTypeMapping(getTypeMappingDescriptor());
      webServiceMBeanImpl.setTypes(getTypes());
    } catch (BindingException b) {
      BindingException bindingException;
      throw new BuildException(bindingException);
    } 
    return webServiceMBeanImpl;
  }
  
  public XMLNodeSet getTypes() {
    xMLInputOutputStream = null;
    try {
      xMLInputOutputStream = XMLOutputStreamFactory.newInstance().newInputOutputStream();
      this.tbuilder.writeGeneratedSchemas(xMLInputOutputStream);
      return readSchemasFromStream(xMLInputOutputStream);
    } catch (IOException iOException) {
      throw new BuildException("Problem writing XML types", iOException);
    } catch (BindingException bindingException) {
      throw new BuildException("Problem generating XML types", bindingException);
    } finally {
      try {
        xMLInputOutputStream.close();
      } catch (Throwable throwable) {}
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\EJBAutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */