/*     */ package weblogic.ant.taskdefs.webservices.autotype;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import weblogic.application.ApplicationFileManager;
/*     */ import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.EJBLinkMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.OperationMBean;
/*     */ import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.StatelessEJBMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
/*     */ import weblogic.utils.jars.VirtualJarFile;
/*     */ import weblogic.webservice.dd.EJBIntrospector;
/*     */ import weblogic.webservice.dd.EJBJarIntrospector;
/*     */ import weblogic.webservice.dd.EJBProcessingException;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.stream.XMLInputOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.xmlnode.XMLNodeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EJBAutoTyper
/*     */   extends ComponentAutoTyper
/*     */ {
/*     */   private File outputDir;
/*     */   private File ejbJar;
/*     */   private EJBJarIntrospector introspector;
/*     */   private String[] ejbIncludes;
/*     */   private String[] ejbExcludes;
/*     */   private Collection ejbs;
/*  54 */   private static int ejbCompCounter = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EJBAutoTyper(File paramFile1, String paramString, File paramFile2, String[] paramArrayOfString1, String[] paramArrayOfString2, Task paramTask) {
/*  60 */     super(paramFile2, paramString, paramTask);
/*  61 */     this.ejbJar = paramFile1;
/*  62 */     this.ejbIncludes = paramArrayOfString1;
/*  63 */     this.ejbExcludes = paramArrayOfString2;
/*  64 */     virtualJarFile = null;
/*     */     
/*  66 */     try { applicationFileManager = ApplicationFileManager.newInstance(paramFile1);
/*  67 */       virtualJarFile = applicationFileManager.getVirtualJarFile();
/*  68 */       this.introspector = new EJBJarIntrospector(virtualJarFile); }
/*  69 */     catch (EJBProcessingException eJBProcessingException)
/*  70 */     { throw new BuildException("Could not process ejb-jar", eJBProcessingException); }
/*  71 */     catch (IOException iOException)
/*  72 */     { throw new BuildException("Could not process ejb-jar", iOException); }
/*     */     finally { 
/*  74 */       try { if (virtualJarFile != null) virtualJarFile.close();  } catch (IOException iOException) {} }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*  83 */       createTypeMappingBuilder();
/*  84 */     } catch (IOException iOException) {
/*  85 */       throw new BuildException("Failed to create type mapping builder. ", iOException);
/*     */     } 
/*     */     
/*  88 */     if (this.generateTypes) {
/*  89 */       log("Running autotyper for EJB jar " + this.ejbJar, 3);
/*     */       try {
/*  91 */         this.ejbs = this.introspector.getEJBs();
/*  92 */         if (this.ejbIncludes != null) {
/*  93 */           for (byte b = 0; b < this.ejbIncludes.length; ) {
/*  94 */             Iterator iterator1 = this.ejbs.iterator();
/*  95 */             boolean bool = false;
/*  96 */             while (iterator1.hasNext()) {
/*  97 */               String str = ((EJBIntrospector)iterator1.next()).getEJBName();
/*  98 */               if (str.equals(this.ejbIncludes[b])) {
/*  99 */                 bool = true;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/* 104 */             if (bool) { b++; continue; }
/* 105 */              throw new BuildException("EJBBean " + this.ejbIncludes[b] + " doesn't exist in EJBJar " + this.ejbJar.getCanonicalPath());
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/* 110 */         Iterator iterator = this.ejbs.iterator();
/* 111 */         while (iterator.hasNext()) {
/* 112 */           EJBIntrospector eJBIntrospector = (EJBIntrospector)iterator.next();
/* 113 */           if (isEJBIncluded(eJBIntrospector)) {
/* 114 */             mapComponent(eJBIntrospector, this.tbuilder);
/*     */           }
/*     */         } 
/* 117 */       } catch (IOException iOException) {
/* 118 */         throw new BuildException(iOException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isEJBIncluded(EJBIntrospector paramEJBIntrospector) {
/* 127 */     String str = paramEJBIntrospector.getEJBName();
/*     */     
/* 129 */     if (this.ejbIncludes == null && this.ejbExcludes == null) {
/* 130 */       return true;
/*     */     }
/* 132 */     if (this.ejbIncludes != null && this.ejbExcludes == null) {
/* 133 */       for (byte b1 = 0; b1 < this.ejbIncludes.length; b1++) {
/* 134 */         if (str.equals(this.ejbIncludes[b1])) {
/* 135 */           return true;
/*     */         }
/*     */       } 
/* 138 */       return false;
/*     */     } 
/*     */     
/* 141 */     if (this.ejbIncludes == null && this.ejbExcludes != null) {
/* 142 */       for (byte b1 = 0; b1 < this.ejbExcludes.length; b1++) {
/* 143 */         if (str.equals(this.ejbExcludes[b1])) {
/* 144 */           return false;
/*     */         }
/*     */       } 
/* 147 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 151 */     boolean bool1 = false;
/* 152 */     boolean bool2 = false; byte b;
/* 153 */     for (b = 0; b < this.ejbIncludes.length; b++) {
/* 154 */       if (str.equals(this.ejbIncludes[b])) {
/* 155 */         bool1 = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 159 */     for (b = 0; b < this.ejbExcludes.length; b++) {
/* 160 */       if (str.equals(this.ejbExcludes[b])) {
/* 161 */         bool2 = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 166 */     return (bool1 && !bool2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceMBean getWebServiceDescriptor() {
/* 174 */     WebServiceMBeanImpl webServiceMBeanImpl = new WebServiceMBeanImpl();
/* 175 */     webServiceMBeanImpl.setWebServiceName(this.serviceName);
/* 176 */     webServiceMBeanImpl.setURI(this.serviceURI);
/* 177 */     webServiceMBeanImpl.setTargetNamespace(this.targetNSURI);
/* 178 */     webServiceMBeanImpl.setProtocol(this.protocol);
/* 179 */     webServiceMBeanImpl.setStyle(this.style);
/* 180 */     webServiceMBeanImpl.setUseSOAP12(this.useSoap12);
/*     */ 
/*     */     
/* 183 */     ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
/* 184 */     OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
/* 185 */     Iterator iterator = this.introspector.getEJBs().iterator();
/* 186 */     TypeMapping typeMapping = null;
/*     */     try {
/* 188 */       typeMapping = this.tbuilder.getTypeMapping();
/* 189 */     } catch (BindingException bindingException) {
/* 190 */       throw new BuildException("Could not get type mapping", bindingException);
/*     */     } 
/*     */     
/* 193 */     for (b = 0; iterator.hasNext(); b++) {
/* 194 */       EJBIntrospector eJBIntrospector = (EJBIntrospector)iterator.next();
/* 195 */       if (isEJBIncluded(eJBIntrospector)) {
/*     */ 
/*     */         
/* 198 */         StatelessEJBMBeanImpl statelessEJBMBeanImpl = new StatelessEJBMBeanImpl();
/* 199 */         statelessEJBMBeanImpl.setComponentName("ejbcomp" + ejbCompCounter++);
/* 200 */         EJBLinkMBeanImpl eJBLinkMBeanImpl = new EJBLinkMBeanImpl();
/* 201 */         eJBLinkMBeanImpl.setPath(this.ejbJar.getName() + "#" + eJBIntrospector.getEJBName());
/* 202 */         statelessEJBMBeanImpl.setEJBLink(eJBLinkMBeanImpl);
/* 203 */         componentsMBeanImpl.addStatelessEJB(statelessEJBMBeanImpl);
/* 204 */         OperationMBean[] arrayOfOperationMBean = null;
/* 205 */         if (this.expandMethods) {
/* 206 */           arrayOfOperationMBean = createExpandedOperations(statelessEJBMBeanImpl, typeMapping, eJBIntrospector);
/* 207 */           for (byte b1 = 0; b1 < arrayOfOperationMBean.length; b1++) {
/* 208 */             operationsMBeanImpl.addOperation(arrayOfOperationMBean[b1]);
/*     */           }
/*     */         } else {
/* 211 */           operationsMBeanImpl.addOperation(createMetaOperation(statelessEJBMBeanImpl));
/*     */         } 
/*     */       } 
/* 214 */     }  webServiceMBeanImpl.setComponents(componentsMBeanImpl);
/* 215 */     webServiceMBeanImpl.setOperations(operationsMBeanImpl);
/*     */     
/*     */     try {
/* 218 */       webServiceMBeanImpl.setTypeMapping(getTypeMappingDescriptor());
/* 219 */       webServiceMBeanImpl.setTypes(getTypes());
/* 220 */     } catch (BindingException b) {
/* 221 */       BindingException bindingException; throw new BuildException(bindingException);
/*     */     } 
/*     */     
/* 224 */     return webServiceMBeanImpl;
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLNodeSet getTypes() {
/* 229 */     xMLInputOutputStream = null;
/*     */     
/* 231 */     try { xMLInputOutputStream = XMLOutputStreamFactory.newInstance().newInputOutputStream();
/* 232 */       this.tbuilder.writeGeneratedSchemas(xMLInputOutputStream);
/* 233 */       return readSchemasFromStream(xMLInputOutputStream); }
/* 234 */     catch (IOException iOException)
/* 235 */     { throw new BuildException("Problem writing XML types", iOException); }
/* 236 */     catch (BindingException bindingException)
/* 237 */     { throw new BuildException("Problem generating XML types", bindingException); }
/*     */     finally { 
/* 239 */       try { xMLInputOutputStream.close(); } catch (Throwable throwable) {} }
/*     */   
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\EJBAutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */