/*     */ package weblogic.ant.taskdefs.webservices.autotype;
/*     */ 
/*     */ import com.sun.tools.javadoc.Main;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.Path;
/*     */ import org.apache.tools.ant.types.Reference;
/*     */ import weblogic.webservice.util.WebServiceEarFile;
/*     */ import weblogic.webservice.util.WebServiceJarException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaSource2DD
/*     */   extends Task
/*     */ {
/*     */   private File javaSource;
/*     */   private File ddFile;
/*     */   private String serviceURI;
/*     */   private File typesInfo;
/*     */   private File securityInfo;
/*     */   private Path classpath;
/*     */   private File handlerInfo;
/*     */   private String ejbLink;
/*     */   private String ignoreAuthHeader;
/*     */   private Path sourcePath;
/*     */   private File wsdlFile;
/*     */   private File earClasspath;
/*     */   private boolean mergeWithExistingWS = false;
/*     */   private boolean overwrite = true;
/*     */   private boolean isDotEjbFile = false;
/*     */   private String targetNameSpace;
/*  53 */   private WebServiceEarFile loadEar = null;
/*     */ 
/*     */   
/*  56 */   public void setHandlerInfo(File paramFile) { this.handlerInfo = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  60 */   public void setEjbLink(String paramString) { this.ejbLink = paramString; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaSource(File paramFile) {
/*  65 */     if (paramFile.getName().endsWith(".java")) {
/*  66 */       this.javaSource = paramFile;
/*  67 */     } else if (paramFile.getName().endsWith(".ejb")) {
/*  68 */       this.javaSource = renameJavaSource(paramFile);
/*     */     } else {
/*  70 */       throw new BuildException("Not a .java or .ejb file");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  75 */   public void setDdFile(File paramFile) { this.ddFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  79 */   public void setWsdlFile(File paramFile) { this.wsdlFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  83 */   public void setTypesInfo(File paramFile) { this.typesInfo = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  87 */   public void setSecurityInfo(File paramFile) { this.securityInfo = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public void setMergeWithExistingWS(boolean paramBoolean) { this.mergeWithExistingWS = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void setServiceUri(String paramString) { this.serviceURI = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 103 */   public void setSourcePath(Path paramPath) { this.sourcePath = paramPath; }
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void setEarClasspath(File paramFile) { this.earClasspath = paramFile; }
/*     */ 
/*     */   
/*     */   public void setClasspath(Path paramPath) {
/* 111 */     if (this.classpath == null) {
/* 112 */       this.classpath = paramPath;
/*     */     } else {
/* 114 */       this.classpath.append(paramPath);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 119 */   public void setIgnoreAuthHeader(String paramString) { this.ignoreAuthHeader = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 123 */   public void setTargetNameSpace(String paramString) { this.targetNameSpace = paramString; }
/*     */ 
/*     */   
/*     */   public Path createClasspath() {
/* 127 */     if (this.classpath == null) {
/* 128 */       this.classpath = new Path(getProject());
/*     */     }
/*     */     
/* 131 */     return this.classpath.createPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
/*     */ 
/*     */   
/*     */   public void execute() {
/* 142 */     validateAttribute();
/*     */     
/* 144 */     if (!this.overwrite && !needToRun())
/*     */       return; 
/* 146 */     setupSourcePath();
/* 147 */     setupClassPath();
/*     */     
/*     */     try {
/* 150 */       runJavadoc();
/*     */       
/* 152 */       if (this.isDotEjbFile) {
/* 153 */         this.javaSource.delete();
/*     */       }
/*     */     } finally {
/*     */       try {
/* 157 */         if (this.loadEar != null) this.loadEar.remove(); 
/* 158 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   private File renameJavaSource(File paramFile) {
/* 163 */     String str = paramFile.getAbsolutePath();
/* 164 */     int i = str.lastIndexOf(".");
/* 165 */     str = str.substring(0, i);
/* 166 */     str = str + ".java";
/*     */     
/* 168 */     File file = new File(str);
/*     */     
/* 170 */     if (file.exists()) {
/* 171 */       throw new BuildException("Unable to copy .ejb file to .java file. " + str + " already exists");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 176 */       FileInputStream fileInputStream = new FileInputStream(paramFile);
/* 177 */       FileOutputStream fileOutputStream = new FileOutputStream(file);
/*     */       
/*     */       int j;
/*     */       
/* 181 */       while ((j = fileInputStream.read()) != -1) {
/* 182 */         fileOutputStream.write((char)j);
/*     */       }
/*     */       
/* 185 */       fileInputStream.close();
/* 186 */       fileOutputStream.close();
/*     */       
/* 188 */       this.isDotEjbFile = true;
/* 189 */     } catch (IOException iOException) {
/* 190 */       throw new BuildException("Failed to copy .ejb file to .java file: " + iOException);
/*     */     } 
/*     */ 
/*     */     
/* 194 */     return file;
/*     */   }
/*     */   
/*     */   public void validateAttribute() {
/* 198 */     if (this.javaSource == null) {
/* 199 */       throw new BuildException("javaSource not specified");
/*     */     }
/* 201 */     if (!this.javaSource.exists()) {
/* 202 */       throw new BuildException(this.javaSource.getAbsolutePath() + " doesn't exists.");
/*     */     }
/* 204 */     if (!this.javaSource.isFile()) {
/* 205 */       throw new BuildException(this.javaSource.getAbsolutePath() + " is not a file.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (this.ddFile == null) {
/* 212 */       throw new BuildException("ddFile not specified");
/*     */     }
/*     */     
/* 215 */     if (this.serviceURI == null) {
/* 216 */       throw new BuildException("serviceURI not specified");
/*     */     }
/*     */     
/* 219 */     if (this.earClasspath != null && this.earClasspath.exists()) {
/* 220 */       String str = System.getProperty("java.io.tmpdir");
/* 221 */       if (str == null) str = ".";
/*     */       
/*     */       try {
/* 224 */         this.loadEar = new WebServiceEarFile(new File(str), this.earClasspath, "junk");
/* 225 */       } catch (IOException iOException) {
/* 226 */         throw new BuildException("Failed to access " + this.earClasspath, iOException);
/* 227 */       } catch (WebServiceJarException webServiceJarException) {
/* 228 */         throw new BuildException("Failed to access " + this.earClasspath, webServiceJarException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void runJavadoc() {
/* 234 */     ArrayList arrayList = new ArrayList();
/*     */ 
/*     */     
/* 237 */     arrayList.add("-classpath");
/* 238 */     arrayList.add(this.classpath.toString());
/*     */     
/* 240 */     arrayList.add("-sourcepath");
/* 241 */     arrayList.add(this.sourcePath.toString());
/*     */ 
/*     */     
/* 244 */     this.ddFile.getParentFile().mkdirs();
/* 245 */     arrayList.add("-fileName");
/* 246 */     arrayList.add(this.ddFile.getAbsolutePath());
/*     */     
/* 248 */     arrayList.add("-uri");
/* 249 */     arrayList.add(this.serviceURI);
/*     */     
/* 251 */     if (this.typesInfo != null) {
/* 252 */       arrayList.add("-typesInfo");
/* 253 */       arrayList.add(this.typesInfo.getAbsolutePath());
/*     */     } 
/*     */     
/* 256 */     if (this.securityInfo != null) {
/* 257 */       arrayList.add("-securityInfo");
/* 258 */       arrayList.add(this.securityInfo.getAbsolutePath());
/*     */     } 
/*     */     
/* 261 */     if (this.handlerInfo != null) {
/* 262 */       arrayList.add("-handlerInfo");
/* 263 */       arrayList.add(this.handlerInfo.getAbsolutePath());
/*     */     } 
/*     */     
/* 266 */     if (this.ejbLink != null) {
/* 267 */       arrayList.add("-ejbLink");
/* 268 */       arrayList.add(this.ejbLink);
/*     */     } 
/*     */     
/* 271 */     if (this.wsdlFile != null) {
/* 272 */       arrayList.add("-wsdlFile");
/* 273 */       arrayList.add(this.wsdlFile.getAbsolutePath());
/*     */     } 
/*     */ 
/*     */     
/* 277 */     if (this.ignoreAuthHeader != null) {
/* 278 */       arrayList.add("-ignoreAuthHeader");
/* 279 */       arrayList.add(this.ignoreAuthHeader);
/*     */     } 
/*     */     
/* 282 */     if (this.targetNameSpace != null) {
/* 283 */       arrayList.add("-targetNamespace");
/* 284 */       arrayList.add(this.targetNameSpace);
/*     */     } 
/*     */     
/* 287 */     arrayList.add("-mergeWithExistingWS");
/* 288 */     arrayList.add(Boolean.valueOf(this.mergeWithExistingWS).toString());
/*     */ 
/*     */     
/* 291 */     arrayList.add(this.javaSource.getAbsolutePath());
/*     */     
/* 293 */     int i = Main.execute("source2wsdd", weblogic.webservice.tools.ddgen.ServiceGen.class.getName(), (String[])arrayList.toArray(new String[0]));
/*     */ 
/*     */     
/* 296 */     if (i != 0) {
/* 297 */       throw new BuildException("javadoc execution failed");
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean needToRun() {
/* 302 */     long l1 = this.javaSource.lastModified();
/* 303 */     long l2 = this.ddFile.lastModified();
/*     */     
/* 305 */     if (this.typesInfo != null && this.typesInfo.lastModified() > l1) {
/* 306 */       l1 = this.typesInfo.lastModified();
/*     */     }
/*     */     
/* 309 */     if (this.wsdlFile != null && this.wsdlFile.lastModified() < l2) {
/* 310 */       l2 = this.wsdlFile.lastModified();
/*     */     }
/*     */     
/* 313 */     return (l1 > l2);
/*     */   }
/*     */   
/*     */   private void setupSourcePath() {
/* 317 */     Path path = new Path(getProject());
/* 318 */     path.setLocation(this.javaSource.getParentFile());
/*     */     
/* 320 */     if (this.sourcePath != null) {
/* 321 */       this.sourcePath.append(path);
/*     */     } else {
/* 323 */       this.sourcePath = path;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setupClassPath() {
/* 328 */     if (this.classpath == null) {
/* 329 */       this.classpath = (Path)Path.systemClasspath.clone();
/*     */     } else {
/* 331 */       this.classpath.concatSystemClasspath("ignore");
/*     */     } 
/*     */     
/* 334 */     if (this.loadEar != null) {
/* 335 */       this.classpath.createPathElement().setPath(this.loadEar.getApplicationClasspath());
/*     */     }
/*     */     
/* 338 */     log("classpath " + this.classpath.toString(), 3);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\JavaSource2DD.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */