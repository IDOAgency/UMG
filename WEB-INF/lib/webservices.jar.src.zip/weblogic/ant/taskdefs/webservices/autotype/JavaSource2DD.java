package weblogic.ant.taskdefs.webservices.autotype;

import com.sun.tools.javadoc.Main;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;
import weblogic.webservice.util.WebServiceEarFile;
import weblogic.webservice.util.WebServiceJarException;

public class JavaSource2DD extends Task {
  private File javaSource;
  
  private File ddFile;
  
  private String serviceURI;
  
  private File typesInfo;
  
  private File securityInfo;
  
  private Path classpath;
  
  private File handlerInfo;
  
  private String ejbLink;
  
  private String ignoreAuthHeader;
  
  private Path sourcePath;
  
  private File wsdlFile;
  
  private File earClasspath;
  
  private boolean mergeWithExistingWS = false;
  
  private boolean overwrite = true;
  
  private boolean isDotEjbFile = false;
  
  private String targetNameSpace;
  
  private WebServiceEarFile loadEar = null;
  
  public void setHandlerInfo(File paramFile) { this.handlerInfo = paramFile; }
  
  public void setEjbLink(String paramString) { this.ejbLink = paramString; }
  
  public void setJavaSource(File paramFile) {
    if (paramFile.getName().endsWith(".java")) {
      this.javaSource = paramFile;
    } else if (paramFile.getName().endsWith(".ejb")) {
      this.javaSource = renameJavaSource(paramFile);
    } else {
      throw new BuildException("Not a .java or .ejb file");
    } 
  }
  
  public void setDdFile(File paramFile) { this.ddFile = paramFile; }
  
  public void setWsdlFile(File paramFile) { this.wsdlFile = paramFile; }
  
  public void setTypesInfo(File paramFile) { this.typesInfo = paramFile; }
  
  public void setSecurityInfo(File paramFile) { this.securityInfo = paramFile; }
  
  public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
  
  public void setMergeWithExistingWS(boolean paramBoolean) { this.mergeWithExistingWS = paramBoolean; }
  
  public void setServiceUri(String paramString) { this.serviceURI = paramString; }
  
  public void setSourcePath(Path paramPath) { this.sourcePath = paramPath; }
  
  public void setEarClasspath(File paramFile) { this.earClasspath = paramFile; }
  
  public void setClasspath(Path paramPath) {
    if (this.classpath == null) {
      this.classpath = paramPath;
    } else {
      this.classpath.append(paramPath);
    } 
  }
  
  public void setIgnoreAuthHeader(String paramString) { this.ignoreAuthHeader = paramString; }
  
  public void setTargetNameSpace(String paramString) { this.targetNameSpace = paramString; }
  
  public Path createClasspath() {
    if (this.classpath == null)
      this.classpath = new Path(getProject()); 
    return this.classpath.createPath();
  }
  
  public void setClasspathRef(Reference paramReference) { createClasspath().setRefid(paramReference); }
  
  public void execute() {
    validateAttribute();
    if (!this.overwrite && !needToRun())
      return; 
    setupSourcePath();
    setupClassPath();
    try {
      runJavadoc();
      if (this.isDotEjbFile)
        this.javaSource.delete(); 
    } finally {
      try {
        if (this.loadEar != null)
          this.loadEar.remove(); 
      } catch (IOException iOException) {}
    } 
  }
  
  private File renameJavaSource(File paramFile) {
    String str = paramFile.getAbsolutePath();
    int i = str.lastIndexOf(".");
    str = str.substring(0, i);
    str = str + ".java";
    File file = new File(str);
    if (file.exists())
      throw new BuildException("Unable to copy .ejb file to .java file. " + str + " already exists"); 
    try {
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      FileOutputStream fileOutputStream = new FileOutputStream(file);
      int j;
      while ((j = fileInputStream.read()) != -1)
        fileOutputStream.write((char)j); 
      fileInputStream.close();
      fileOutputStream.close();
      this.isDotEjbFile = true;
    } catch (IOException iOException) {
      throw new BuildException("Failed to copy .ejb file to .java file: " + iOException);
    } 
    return file;
  }
  
  public void validateAttribute() {
    if (this.javaSource == null)
      throw new BuildException("javaSource not specified"); 
    if (!this.javaSource.exists())
      throw new BuildException(this.javaSource.getAbsolutePath() + " doesn't exists."); 
    if (!this.javaSource.isFile())
      throw new BuildException(this.javaSource.getAbsolutePath() + " is not a file."); 
    if (this.ddFile == null)
      throw new BuildException("ddFile not specified"); 
    if (this.serviceURI == null)
      throw new BuildException("serviceURI not specified"); 
    if (this.earClasspath != null && this.earClasspath.exists()) {
      String str = System.getProperty("java.io.tmpdir");
      if (str == null)
        str = "."; 
      try {
        this.loadEar = new WebServiceEarFile(new File(str), this.earClasspath, "junk");
      } catch (IOException iOException) {
        throw new BuildException("Failed to access " + this.earClasspath, iOException);
      } catch (WebServiceJarException webServiceJarException) {
        throw new BuildException("Failed to access " + this.earClasspath, webServiceJarException);
      } 
    } 
  }
  
  private void runJavadoc() {
    ArrayList arrayList = new ArrayList();
    arrayList.add("-classpath");
    arrayList.add(this.classpath.toString());
    arrayList.add("-sourcepath");
    arrayList.add(this.sourcePath.toString());
    this.ddFile.getParentFile().mkdirs();
    arrayList.add("-fileName");
    arrayList.add(this.ddFile.getAbsolutePath());
    arrayList.add("-uri");
    arrayList.add(this.serviceURI);
    if (this.typesInfo != null) {
      arrayList.add("-typesInfo");
      arrayList.add(this.typesInfo.getAbsolutePath());
    } 
    if (this.securityInfo != null) {
      arrayList.add("-securityInfo");
      arrayList.add(this.securityInfo.getAbsolutePath());
    } 
    if (this.handlerInfo != null) {
      arrayList.add("-handlerInfo");
      arrayList.add(this.handlerInfo.getAbsolutePath());
    } 
    if (this.ejbLink != null) {
      arrayList.add("-ejbLink");
      arrayList.add(this.ejbLink);
    } 
    if (this.wsdlFile != null) {
      arrayList.add("-wsdlFile");
      arrayList.add(this.wsdlFile.getAbsolutePath());
    } 
    if (this.ignoreAuthHeader != null) {
      arrayList.add("-ignoreAuthHeader");
      arrayList.add(this.ignoreAuthHeader);
    } 
    if (this.targetNameSpace != null) {
      arrayList.add("-targetNamespace");
      arrayList.add(this.targetNameSpace);
    } 
    arrayList.add("-mergeWithExistingWS");
    arrayList.add(Boolean.valueOf(this.mergeWithExistingWS).toString());
    arrayList.add(this.javaSource.getAbsolutePath());
    int i = Main.execute("source2wsdd", weblogic.webservice.tools.ddgen.ServiceGen.class.getName(), (String[])arrayList.toArray(new String[0]));
    if (i != 0)
      throw new BuildException("javadoc execution failed"); 
  }
  
  private boolean needToRun() {
    long l1 = this.javaSource.lastModified();
    long l2 = this.ddFile.lastModified();
    if (this.typesInfo != null && this.typesInfo.lastModified() > l1)
      l1 = this.typesInfo.lastModified(); 
    if (this.wsdlFile != null && this.wsdlFile.lastModified() < l2)
      l2 = this.wsdlFile.lastModified(); 
    return (l1 > l2);
  }
  
  private void setupSourcePath() {
    Path path = new Path(getProject());
    path.setLocation(this.javaSource.getParentFile());
    if (this.sourcePath != null) {
      this.sourcePath.append(path);
    } else {
      this.sourcePath = path;
    } 
  }
  
  private void setupClassPath() {
    if (this.classpath == null) {
      this.classpath = (Path)Path.systemClasspath.clone();
    } else {
      this.classpath.concatSystemClasspath("ignore");
    } 
    if (this.loadEar != null)
      this.classpath.createPathElement().setPath(this.loadEar.getApplicationClasspath()); 
    log("classpath " + this.classpath.toString(), 3);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\JavaSource2DD.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */