package weblogic.ant.taskdefs.webservices.autotype;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.tools.ant.Task;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.management.descriptors.webservice.TypeMappingEntryMBeanImpl;
import weblogic.management.descriptors.webservice.TypeMappingMBean;
import weblogic.management.descriptors.webservice.TypeMappingMBeanImpl;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.xml.schema.binding.BindingConfiguration;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.TypeMappingBuilder;
import weblogic.xml.schema.binding.TypeMappingBuilderFactory;
import weblogic.xml.schema.binding.TypeMappingEntry;
import weblogic.xml.schema.binding.util.StdNamespace;
import weblogic.xml.schema.model.SchemaTypes;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeSet;

public abstract class AutoTyper {
  protected static boolean DEBUG = false;
  
  protected File outputDir;
  
  protected BindingConfiguration config;
  
  protected TypeMappingBuilder tbuilder;
  
  protected String serviceName;
  
  protected String serviceURI;
  
  protected String packageBase;
  
  protected String packageName;
  
  protected String targetNSURI;
  
  protected boolean expandMethods;
  
  protected boolean generateTypes;
  
  protected boolean useSoap12;
  
  protected String style;
  
  protected boolean keepGenerated;
  
  protected File typeMappingFile;
  
  protected XMLNodeSet types;
  
  protected String compilerClasspath;
  
  private int nprefixes;
  
  private Task antTask;
  
  protected HashSet extraClasses;
  
  private static final HashSet attachmentTypes = new HashSet();
  
  static  {
    attachmentTypes.add("javax.xml.transform.Source");
    attachmentTypes.add("javax.mail.internet.MimeMultipart");
    attachmentTypes.add("javax.activation.DataHandler");
    attachmentTypes.add("java.awt.Image");
  }
  
  public AutoTyper(File paramFile, String paramString, Task paramTask) {
    this.expandMethods = false;
    this.generateTypes = true;
    this.useSoap12 = false;
    this.nprefixes = 0;
    this.extraClasses = new HashSet();
    this.outputDir = paramFile;
    this.serviceName = paramString;
    this.antTask = paramTask;
  }
  
  public HashSet getExtraClasses() { return this.extraClasses; }
  
  public void setExpandMethods(boolean paramBoolean) { this.expandMethods = paramBoolean; }
  
  public void setGenerateTypes(boolean paramBoolean) { this.generateTypes = paramBoolean; }
  
  public void setTargetNSURI(String paramString) { this.targetNSURI = paramString; }
  
  public void setServiceURI(String paramString) { this.serviceURI = paramString; }
  
  public void setStyle(String paramString) { this.style = paramString; }
  
  public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
  
  public void setUseSoap12(boolean paramBoolean) { this.useSoap12 = paramBoolean; }
  
  public void setPackageBase(String paramString) { this.packageBase = paramString; }
  
  public void setPackageName(String paramString) { this.packageName = paramString; }
  
  public void setCompilerClasspath(String paramString) { this.compilerClasspath = paramString; }
  
  public TypeMapping getTypeMapping() throws BindingException { return this.tbuilder.getTypeMapping(); }
  
  public void setTypeMappingFile(File paramFile) throws IOException { this.typeMappingFile = paramFile; }
  
  public File getTypeMappingFile() { return this.typeMappingFile; }
  
  public TypeMappingMBean getTypeMappingDescriptor() throws BindingException {
    TypeMapping typeMapping = getTypeMapping();
    if (typeMapping == null)
      return null; 
    TypeMappingMBeanImpl typeMappingMBeanImpl = new TypeMappingMBeanImpl();
    TypeMappingEntry[] arrayOfTypeMappingEntry = typeMapping.getEntries();
    if (arrayOfTypeMappingEntry == null || arrayOfTypeMappingEntry.length == 0)
      return null; 
    for (byte b = 0; b < arrayOfTypeMappingEntry.length; b++) {
      if (DEBUG)
        log(arrayOfTypeMappingEntry[b].toString()); 
      TypeMappingEntryMBeanImpl typeMappingEntryMBeanImpl = new TypeMappingEntryMBeanImpl();
      typeMappingEntryMBeanImpl.setClassName(unmangleName(arrayOfTypeMappingEntry[b].getJavaType().getName()));
      typeMappingEntryMBeanImpl.setXSDTypeName(prefixIfNeeded(arrayOfTypeMappingEntry[b].getSchemaType()));
      typeMappingEntryMBeanImpl.setSerializerName(arrayOfTypeMappingEntry[b].getSerializer().getClass().getName());
      typeMappingEntryMBeanImpl.setDeserializerName(arrayOfTypeMappingEntry[b].getDeserializer().getClass().getName());
      typeMappingMBeanImpl.addTypeMappingEntry(typeMappingEntryMBeanImpl);
    } 
    return typeMappingMBeanImpl;
  }
  
  protected TypeMappingBuilder createTypeMappingBuilder() throws IOException {
    TypeMappingBuilderFactory typeMappingBuilderFactory = TypeMappingBuilderFactory.newInstance();
    if (this.typeMappingFile == null) {
      this.tbuilder = typeMappingBuilderFactory.createTypeMappingBuilder();
    } else {
      xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(this.typeMappingFile);
      try {
        this.tbuilder = typeMappingBuilderFactory.createTypeMappingBuilder(xMLInputStream);
      } finally {
        try {
          if (xMLInputStream != null)
            xMLInputStream.close(); 
        } catch (IOException iOException) {}
      } 
    } 
    BindingConfiguration bindingConfiguration = this.tbuilder.getBindingConfiguration();
    bindingConfiguration.setBeanOutputDirectory(this.outputDir.getCanonicalPath());
    bindingConfiguration.setAutoCreateSerials(true);
    bindingConfiguration.setIncludeHolders(true);
    bindingConfiguration.setKeepGenerated(this.keepGenerated);
    if (this.compilerClasspath != null)
      bindingConfiguration.setCompilerClasspath(this.compilerClasspath); 
    bindingConfiguration.setCompiler(TaskUtils.getCompiler());
    log("TypeMapping will use compiler " + bindingConfiguration.getCompiler(), 3);
    if (this.packageBase != null)
      bindingConfiguration.setPackageBase(this.packageBase); 
    if (this.packageName != null)
      bindingConfiguration.setFixedPackage(this.packageName); 
    if (!"rpc".equalsIgnoreCase(this.style))
      bindingConfiguration.setUseSoapStyleArrays(false); 
    return this.tbuilder;
  }
  
  protected static XMLNodeSet readSchemasFromStream(XMLInputStream paramXMLInputStream) throws XMLStreamException, IOException {
    XMLNodeSet xMLNodeSet = new XMLNodeSet();
    boolean bool = false;
    while (paramXMLInputStream.skip(SchemaTypes.SCHEMA_ENAME, 2)) {
      XMLNode xMLNode = new XMLNode();
      xMLNode.read(paramXMLInputStream);
      if (DEBUG)
        System.out.println("Adding: schema: " + xMLNode); 
      xMLNodeSet.addXMLNode(xMLNode);
      bool = true;
    } 
    if (bool)
      return xMLNodeSet; 
    return null;
  }
  
  protected static XMLNodeSet readSchemasFromWsdl(XMLInputStream paramXMLInputStream) throws XMLStreamException, IOException {
    XMLNodeSet xMLNodeSet = new XMLNodeSet();
    boolean bool = false;
    XMLNode xMLNode1 = new XMLNode();
    paramXMLInputStream.skip(2);
    xMLNode1.read(paramXMLInputStream);
    String str = StdNamespace.instance().wsdl();
    XMLNode xMLNode2 = xMLNode1.getChild("types", str);
    if (xMLNode2 == null)
      return null; 
    Iterator iterator = xMLNode2.getChildren();
    while (iterator.hasNext()) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      xMLNode.inheritNamespace();
      if (DEBUG)
        System.out.println("Adding: schema: " + xMLNode); 
      xMLNodeSet.addXMLNode(xMLNode);
      bool = true;
    } 
    if (bool)
      return xMLNodeSet; 
    return null;
  }
  
  protected XMLName prefixIfNeeded(XMLName paramXMLName) {
    if (paramXMLName == null)
      return null; 
    Name name = (Name)paramXMLName;
    if (name.getPrefix() == null)
      if ("http://www.w3.org/2001/XMLSchema".equals(paramXMLName.getNamespaceUri())) {
        name.setPrefix("xsd");
      } else {
        name.setPrefix("p" + Integer.toString(++this.nprefixes));
      }  
    return name;
  }
  
  protected static String unmangleName(String paramString) {
    if (paramString == null || !paramString.startsWith("["))
      return paramString; 
    StringBuffer stringBuffer = new StringBuffer();
    if (paramString.endsWith(";")) {
      stringBuffer.append(paramString.substring(paramString.lastIndexOf("[") + 2, paramString.length() - 1));
    } else if (paramString.endsWith("B")) {
      stringBuffer.append("byte");
    } else if (paramString.endsWith("I")) {
      stringBuffer.append("int");
    } else if (paramString.endsWith("S")) {
      stringBuffer.append("short");
    } else if (paramString.endsWith("J")) {
      stringBuffer.append("long");
    } else if (paramString.endsWith("Z")) {
      stringBuffer.append("boolean");
    } else if (paramString.endsWith("D")) {
      stringBuffer.append("double");
    } else if (paramString.endsWith("C")) {
      stringBuffer.append("char");
    } else if (paramString.endsWith("F")) {
      stringBuffer.append("float");
    } 
    for (byte b = 0; b < paramString.lastIndexOf("[") + 1; b++)
      stringBuffer.append("[]"); 
    return stringBuffer.toString();
  }
  
  protected static boolean isAttachment(Class paramClass) { return attachmentTypes.contains(paramClass.getName()); }
  
  public void log(String paramString) { this.antTask.log(paramString); }
  
  protected void log(String paramString, int paramInt) { this.antTask.log(paramString, paramInt); }
  
  public abstract void run();
  
  public abstract WebServiceMBean getWebServiceDescriptor();
  
  public abstract XMLNodeSet getTypes();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\AutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */