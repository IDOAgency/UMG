/*     */ package weblogic.ant.taskdefs.webservices.autotype;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.apache.tools.ant.Task;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.management.descriptors.webservice.TypeMappingEntryMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.TypeMappingMBean;
/*     */ import weblogic.management.descriptors.webservice.TypeMappingMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.xml.schema.binding.BindingConfiguration;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilder;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilderFactory;
/*     */ import weblogic.xml.schema.binding.TypeMappingEntry;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ import weblogic.xml.schema.model.SchemaTypes;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ import weblogic.xml.xmlnode.XMLNodeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AutoTyper
/*     */ {
/*     */   protected static boolean DEBUG = false;
/*     */   protected File outputDir;
/*     */   protected BindingConfiguration config;
/*     */   protected TypeMappingBuilder tbuilder;
/*     */   protected String serviceName;
/*     */   protected String serviceURI;
/*     */   protected String packageBase;
/*     */   protected String packageName;
/*     */   protected String targetNSURI;
/*     */   protected boolean expandMethods;
/*     */   protected boolean generateTypes;
/*     */   protected boolean useSoap12;
/*     */   protected String style;
/*     */   protected boolean keepGenerated;
/*     */   protected File typeMappingFile;
/*     */   protected XMLNodeSet types;
/*     */   protected String compilerClasspath;
/*     */   private int nprefixes;
/*     */   private Task antTask;
/*     */   protected HashSet extraClasses;
/*  71 */   private static final HashSet attachmentTypes = new HashSet();
/*     */   
/*     */   static  {
/*  74 */     attachmentTypes.add("javax.xml.transform.Source");
/*  75 */     attachmentTypes.add("javax.mail.internet.MimeMultipart");
/*  76 */     attachmentTypes.add("javax.activation.DataHandler");
/*  77 */     attachmentTypes.add("java.awt.Image"); } public AutoTyper(File paramFile, String paramString, Task paramTask) { this.expandMethods = false; this.generateTypes = true;
/*     */     this.useSoap12 = false;
/*     */     this.nprefixes = 0;
/*     */     this.extraClasses = new HashSet();
/*  81 */     this.outputDir = paramFile;
/*  82 */     this.serviceName = paramString;
/*  83 */     this.antTask = paramTask; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public HashSet getExtraClasses() { return this.extraClasses; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void setExpandMethods(boolean paramBoolean) { this.expandMethods = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void setGenerateTypes(boolean paramBoolean) { this.generateTypes = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public void setTargetNSURI(String paramString) { this.targetNSURI = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public void setServiceURI(String paramString) { this.serviceURI = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public void setStyle(String paramString) { this.style = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 139 */   public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 143 */   public void setUseSoap12(boolean paramBoolean) { this.useSoap12 = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public void setPackageBase(String paramString) { this.packageBase = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public void setPackageName(String paramString) { this.packageName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public void setCompilerClasspath(String paramString) { this.compilerClasspath = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public TypeMapping getTypeMapping() throws BindingException { return this.tbuilder.getTypeMapping(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public void setTypeMappingFile(File paramFile) throws IOException { this.typeMappingFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/* 180 */   public File getTypeMappingFile() { return this.typeMappingFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMappingMBean getTypeMappingDescriptor() throws BindingException {
/* 187 */     TypeMapping typeMapping = getTypeMapping();
/* 188 */     if (typeMapping == null) return null;
/*     */     
/* 190 */     TypeMappingMBeanImpl typeMappingMBeanImpl = new TypeMappingMBeanImpl();
/* 191 */     TypeMappingEntry[] arrayOfTypeMappingEntry = typeMapping.getEntries();
/* 192 */     if (arrayOfTypeMappingEntry == null || arrayOfTypeMappingEntry.length == 0) return null; 
/* 193 */     for (byte b = 0; b < arrayOfTypeMappingEntry.length; b++) {
/* 194 */       if (DEBUG) log(arrayOfTypeMappingEntry[b].toString()); 
/* 195 */       TypeMappingEntryMBeanImpl typeMappingEntryMBeanImpl = new TypeMappingEntryMBeanImpl();
/* 196 */       typeMappingEntryMBeanImpl.setClassName(unmangleName(arrayOfTypeMappingEntry[b].getJavaType().getName()));
/*     */       
/* 198 */       typeMappingEntryMBeanImpl.setXSDTypeName(prefixIfNeeded(arrayOfTypeMappingEntry[b].getSchemaType()));
/* 199 */       typeMappingEntryMBeanImpl.setSerializerName(arrayOfTypeMappingEntry[b].getSerializer().getClass().getName());
/* 200 */       typeMappingEntryMBeanImpl.setDeserializerName(arrayOfTypeMappingEntry[b].getDeserializer().getClass().getName());
/*     */ 
/*     */       
/* 203 */       typeMappingMBeanImpl.addTypeMappingEntry(typeMappingEntryMBeanImpl);
/*     */     } 
/* 205 */     return typeMappingMBeanImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeMappingBuilder createTypeMappingBuilder() throws IOException {
/* 213 */     TypeMappingBuilderFactory typeMappingBuilderFactory = TypeMappingBuilderFactory.newInstance();
/*     */     
/* 215 */     if (this.typeMappingFile == null) {
/* 216 */       this.tbuilder = typeMappingBuilderFactory.createTypeMappingBuilder();
/*     */     } else {
/* 218 */       xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(this.typeMappingFile);
/*     */ 
/*     */       
/* 221 */       try { this.tbuilder = typeMappingBuilderFactory.createTypeMappingBuilder(xMLInputStream); }
/*     */       finally { 
/* 223 */         try { if (xMLInputStream != null) xMLInputStream.close();  } catch (IOException iOException) {} }
/*     */     
/*     */     } 
/* 226 */     BindingConfiguration bindingConfiguration = this.tbuilder.getBindingConfiguration();
/* 227 */     bindingConfiguration.setBeanOutputDirectory(this.outputDir.getCanonicalPath());
/* 228 */     bindingConfiguration.setAutoCreateSerials(true);
/* 229 */     bindingConfiguration.setIncludeHolders(true);
/* 230 */     bindingConfiguration.setKeepGenerated(this.keepGenerated);
/* 231 */     if (this.compilerClasspath != null) {
/* 232 */       bindingConfiguration.setCompilerClasspath(this.compilerClasspath);
/*     */     }
/*     */     
/* 235 */     bindingConfiguration.setCompiler(TaskUtils.getCompiler());
/* 236 */     log("TypeMapping will use compiler " + bindingConfiguration.getCompiler(), 3);
/*     */     
/* 238 */     if (this.packageBase != null) {
/* 239 */       bindingConfiguration.setPackageBase(this.packageBase);
/*     */     }
/*     */     
/* 242 */     if (this.packageName != null) {
/* 243 */       bindingConfiguration.setFixedPackage(this.packageName);
/*     */     }
/*     */     
/* 246 */     if (!"rpc".equalsIgnoreCase(this.style)) {
/* 247 */       bindingConfiguration.setUseSoapStyleArrays(false);
/*     */     }
/*     */     
/* 250 */     return this.tbuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static XMLNodeSet readSchemasFromStream(XMLInputStream paramXMLInputStream) throws XMLStreamException, IOException {
/* 259 */     XMLNodeSet xMLNodeSet = new XMLNodeSet();
/* 260 */     boolean bool = false;
/* 261 */     while (paramXMLInputStream.skip(SchemaTypes.SCHEMA_ENAME, 2)) {
/* 262 */       XMLNode xMLNode = new XMLNode();
/* 263 */       xMLNode.read(paramXMLInputStream);
/* 264 */       if (DEBUG) System.out.println("Adding: schema: " + xMLNode); 
/* 265 */       xMLNodeSet.addXMLNode(xMLNode);
/* 266 */       bool = true;
/*     */     } 
/*     */     
/* 269 */     if (bool) return xMLNodeSet;
/*     */     
/* 271 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static XMLNodeSet readSchemasFromWsdl(XMLInputStream paramXMLInputStream) throws XMLStreamException, IOException {
/* 277 */     XMLNodeSet xMLNodeSet = new XMLNodeSet();
/* 278 */     boolean bool = false;
/*     */     
/* 280 */     XMLNode xMLNode1 = new XMLNode();
/* 281 */     paramXMLInputStream.skip(2);
/* 282 */     xMLNode1.read(paramXMLInputStream);
/*     */     
/* 284 */     String str = StdNamespace.instance().wsdl();
/* 285 */     XMLNode xMLNode2 = xMLNode1.getChild("types", str);
/*     */     
/* 287 */     if (xMLNode2 == null) return null;
/*     */     
/* 289 */     Iterator iterator = xMLNode2.getChildren();
/* 290 */     while (iterator.hasNext()) {
/* 291 */       XMLNode xMLNode = (XMLNode)iterator.next();
/* 292 */       xMLNode.inheritNamespace();
/* 293 */       if (DEBUG) System.out.println("Adding: schema: " + xMLNode); 
/* 294 */       xMLNodeSet.addXMLNode(xMLNode);
/* 295 */       bool = true;
/*     */     } 
/*     */     
/* 298 */     if (bool) return xMLNodeSet;
/*     */     
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLName prefixIfNeeded(XMLName paramXMLName) {
/* 306 */     if (paramXMLName == null) return null; 
/* 307 */     Name name = (Name)paramXMLName;
/* 308 */     if (name.getPrefix() == null) {
/* 309 */       if ("http://www.w3.org/2001/XMLSchema".equals(paramXMLName.getNamespaceUri())) {
/* 310 */         name.setPrefix("xsd");
/*     */       } else {
/* 312 */         name.setPrefix("p" + Integer.toString(++this.nprefixes));
/*     */       } 
/*     */     }
/* 315 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String unmangleName(String paramString) {
/* 325 */     if (paramString == null || !paramString.startsWith("[")) {
/* 326 */       return paramString;
/*     */     }
/* 328 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 330 */     if (paramString.endsWith(";"))
/* 331 */     { stringBuffer.append(paramString.substring(paramString.lastIndexOf("[") + 2, paramString.length() - 1));
/*     */        }
/*     */     
/* 334 */     else if (paramString.endsWith("B")) { stringBuffer.append("byte"); }
/* 335 */     else if (paramString.endsWith("I")) { stringBuffer.append("int"); }
/* 336 */     else if (paramString.endsWith("S")) { stringBuffer.append("short"); }
/* 337 */     else if (paramString.endsWith("J")) { stringBuffer.append("long"); }
/* 338 */     else if (paramString.endsWith("Z")) { stringBuffer.append("boolean"); }
/* 339 */     else if (paramString.endsWith("D")) { stringBuffer.append("double"); }
/* 340 */     else if (paramString.endsWith("C")) { stringBuffer.append("char"); }
/* 341 */     else if (paramString.endsWith("F")) { stringBuffer.append("float"); }
/*     */ 
/*     */     
/* 344 */     for (byte b = 0; b < paramString.lastIndexOf("[") + 1; b++) {
/* 345 */       stringBuffer.append("[]");
/*     */     }
/* 347 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 352 */   protected static boolean isAttachment(Class paramClass) { return attachmentTypes.contains(paramClass.getName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 359 */   public void log(String paramString) { this.antTask.log(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 363 */   protected void log(String paramString, int paramInt) { this.antTask.log(paramString, paramInt); }
/*     */   
/*     */   public abstract void run();
/*     */   
/*     */   public abstract WebServiceMBean getWebServiceDescriptor();
/*     */   
/*     */   public abstract XMLNodeSet getTypes();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\AutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */