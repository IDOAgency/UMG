/*     */ package weblogic.ant.taskdefs.webservices.autotype;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JavaClassMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.OperationMBean;
/*     */ import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
/*     */ import weblogic.webservice.dd.JavaClassIntrospector;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.stream.XMLInputOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.xmlnode.XMLNodeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaAutoTyper
/*     */   extends ComponentAutoTyper
/*     */ {
/*     */   private String[] classNames;
/*     */   private JavaClassIntrospector[] introspectors;
/*  48 */   private static int jcCompCounter = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaAutoTyper(String[] paramArrayOfString, String paramString, File paramFile, Task paramTask) {
/*  55 */     super(paramFile, paramString, paramTask);
/*  56 */     this.classNames = paramArrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*  64 */       createTypeMappingBuilder();
/*  65 */     } catch (IOException iOException) {
/*  66 */       throw new BuildException("Failed to create type mapping builder. ", iOException);
/*     */     } 
/*     */     
/*  69 */     ArrayList arrayList = new ArrayList();
/*     */     
/*  71 */     Class clazz = null;
/*     */     
/*     */     try {
/*  74 */       for (byte b = 0; b < this.classNames.length; b++) {
/*  75 */         clazz = TaskUtils.loadClass(this.classNames[b]);
/*     */         
/*  77 */         JavaClassIntrospector javaClassIntrospector = new JavaClassIntrospector(clazz);
/*  78 */         arrayList.add(javaClassIntrospector);
/*  79 */         if (this.generateTypes) {
/*  80 */           log("Running autotyper for javaclass " + clazz, 3);
/*  81 */           mapComponent(javaClassIntrospector, this.tbuilder);
/*     */         } 
/*     */       } 
/*  84 */     } catch (ClassNotFoundException classNotFoundException) {
/*  85 */       throw new BuildException(classNotFoundException);
/*     */     } 
/*     */     
/*  88 */     this.introspectors = (JavaClassIntrospector[])arrayList.toArray(new JavaClassIntrospector[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceMBean getWebServiceDescriptor() {
/*  97 */     WebServiceMBeanImpl webServiceMBeanImpl = new WebServiceMBeanImpl();
/*  98 */     webServiceMBeanImpl.setWebServiceName(this.serviceName);
/*  99 */     webServiceMBeanImpl.setURI(this.serviceURI);
/* 100 */     webServiceMBeanImpl.setTargetNamespace(this.targetNSURI);
/* 101 */     webServiceMBeanImpl.setProtocol(this.protocol);
/* 102 */     webServiceMBeanImpl.setStyle(this.style);
/* 103 */     webServiceMBeanImpl.setUseSOAP12(this.useSoap12);
/*     */ 
/*     */     
/* 106 */     ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
/* 107 */     OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
/*     */     
/* 109 */     TypeMapping typeMapping = null;
/*     */     try {
/* 111 */       typeMapping = this.tbuilder.getTypeMapping();
/* 112 */     } catch (BindingException bindingException) {
/* 113 */       throw new BuildException("Could not get type mapping", bindingException);
/*     */     } 
/*     */     
/* 116 */     for (b = 0; b < this.introspectors.length; b++) {
/* 117 */       JavaClassIntrospector javaClassIntrospector = this.introspectors[b];
/* 118 */       JavaClassMBeanImpl javaClassMBeanImpl = new JavaClassMBeanImpl();
/* 119 */       javaClassMBeanImpl.setComponentName("jcComp" + jcCompCounter++);
/* 120 */       javaClassMBeanImpl.setClassName(this.classNames[b]);
/* 121 */       componentsMBeanImpl.addJavaClassComponent(javaClassMBeanImpl);
/* 122 */       OperationMBean[] arrayOfOperationMBean = null;
/* 123 */       if (this.expandMethods) {
/* 124 */         arrayOfOperationMBean = createExpandedOperations(javaClassMBeanImpl, typeMapping, javaClassIntrospector);
/* 125 */         for (byte b1 = 0; b1 < arrayOfOperationMBean.length; b1++) {
/* 126 */           operationsMBeanImpl.addOperation(arrayOfOperationMBean[b1]);
/*     */         }
/*     */       } else {
/* 129 */         operationsMBeanImpl.addOperation(createMetaOperation(javaClassMBeanImpl));
/*     */       } 
/*     */     } 
/* 132 */     webServiceMBeanImpl.setOperations(operationsMBeanImpl);
/* 133 */     webServiceMBeanImpl.setComponents(componentsMBeanImpl);
/*     */     
/*     */     try {
/* 136 */       webServiceMBeanImpl.setTypeMapping(getTypeMappingDescriptor());
/* 137 */       webServiceMBeanImpl.setTypes(getTypes());
/* 138 */     } catch (BindingException b) {
/* 139 */       BindingException bindingException; throw new BuildException(bindingException);
/*     */     } 
/*     */     
/* 142 */     return webServiceMBeanImpl;
/*     */   }
/*     */ 
/*     */   
/*     */   public XMLNodeSet getTypes() {
/* 147 */     xMLInputOutputStream = null;
/*     */     
/* 149 */     try { xMLInputOutputStream = XMLOutputStreamFactory.newInstance().newInputOutputStream();
/* 150 */       this.tbuilder.writeGeneratedSchemas(xMLInputOutputStream);
/* 151 */       xMLInputOutputStream.flush();
/* 152 */       return readSchemasFromStream(xMLInputOutputStream); }
/* 153 */     catch (IOException iOException)
/* 154 */     { throw new BuildException("Problem writing XML types", iOException); }
/* 155 */     catch (BindingException bindingException)
/* 156 */     { throw new BuildException("Problem generating XML types", bindingException); }
/*     */     finally { 
/* 158 */       try { xMLInputOutputStream.close(); } catch (Throwable throwable) {} }
/*     */   
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\JavaAutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */