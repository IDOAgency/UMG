package weblogic.ant.taskdefs.webservices.autotype;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
import weblogic.management.descriptors.webservice.JavaClassMBeanImpl;
import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
import weblogic.webservice.dd.JavaClassIntrospector;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.stream.XMLInputOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.xmlnode.XMLNodeSet;

public class JavaAutoTyper extends ComponentAutoTyper {
  private String[] classNames;
  
  private JavaClassIntrospector[] introspectors;
  
  private static int jcCompCounter = 0;
  
  public JavaAutoTyper(String[] paramArrayOfString, String paramString, File paramFile, Task paramTask) {
    super(paramFile, paramString, paramTask);
    this.classNames = paramArrayOfString;
  }
  
  public void run() {
    try {
      createTypeMappingBuilder();
    } catch (IOException iOException) {
      throw new BuildException("Failed to create type mapping builder. ", iOException);
    } 
    ArrayList arrayList = new ArrayList();
    Class clazz = null;
    try {
      for (byte b = 0; b < this.classNames.length; b++) {
        clazz = TaskUtils.loadClass(this.classNames[b]);
        JavaClassIntrospector javaClassIntrospector = new JavaClassIntrospector(clazz);
        arrayList.add(javaClassIntrospector);
        if (this.generateTypes) {
          log("Running autotyper for javaclass " + clazz, 3);
          mapComponent(javaClassIntrospector, this.tbuilder);
        } 
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      throw new BuildException(classNotFoundException);
    } 
    this.introspectors = (JavaClassIntrospector[])arrayList.toArray(new JavaClassIntrospector[0]);
  }
  
  public WebServiceMBean getWebServiceDescriptor() {
    WebServiceMBeanImpl webServiceMBeanImpl = new WebServiceMBeanImpl();
    webServiceMBeanImpl.setWebServiceName(this.serviceName);
    webServiceMBeanImpl.setURI(this.serviceURI);
    webServiceMBeanImpl.setTargetNamespace(this.targetNSURI);
    webServiceMBeanImpl.setProtocol(this.protocol);
    webServiceMBeanImpl.setStyle(this.style);
    webServiceMBeanImpl.setUseSOAP12(this.useSoap12);
    ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
    OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
    TypeMapping typeMapping = null;
    try {
      typeMapping = this.tbuilder.getTypeMapping();
    } catch (BindingException bindingException) {
      throw new BuildException("Could not get type mapping", bindingException);
    } 
    for (b = 0; b < this.introspectors.length; b++) {
      JavaClassIntrospector javaClassIntrospector = this.introspectors[b];
      JavaClassMBeanImpl javaClassMBeanImpl = new JavaClassMBeanImpl();
      javaClassMBeanImpl.setComponentName("jcComp" + jcCompCounter++);
      javaClassMBeanImpl.setClassName(this.classNames[b]);
      componentsMBeanImpl.addJavaClassComponent(javaClassMBeanImpl);
      OperationMBean[] arrayOfOperationMBean = null;
      if (this.expandMethods) {
        arrayOfOperationMBean = createExpandedOperations(javaClassMBeanImpl, typeMapping, javaClassIntrospector);
        for (byte b1 = 0; b1 < arrayOfOperationMBean.length; b1++)
          operationsMBeanImpl.addOperation(arrayOfOperationMBean[b1]); 
      } else {
        operationsMBeanImpl.addOperation(createMetaOperation(javaClassMBeanImpl));
      } 
    } 
    webServiceMBeanImpl.setOperations(operationsMBeanImpl);
    webServiceMBeanImpl.setComponents(componentsMBeanImpl);
    try {
      webServiceMBeanImpl.setTypeMapping(getTypeMappingDescriptor());
      webServiceMBeanImpl.setTypes(getTypes());
    } catch (BindingException b) {
      BindingException bindingException;
      throw new BuildException(bindingException);
    } 
    return webServiceMBeanImpl;
  }
  
  public XMLNodeSet getTypes() {
    xMLInputOutputStream = null;
    try {
      xMLInputOutputStream = XMLOutputStreamFactory.newInstance().newInputOutputStream();
      this.tbuilder.writeGeneratedSchemas(xMLInputOutputStream);
      xMLInputOutputStream.flush();
      return readSchemasFromStream(xMLInputOutputStream);
    } catch (IOException iOException) {
      throw new BuildException("Problem writing XML types", iOException);
    } catch (BindingException bindingException) {
      throw new BuildException("Problem generating XML types", bindingException);
    } finally {
      try {
        xMLInputOutputStream.close();
      } catch (Throwable throwable) {}
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\JavaAutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */