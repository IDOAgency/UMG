/*     */ package weblogic.ant.taskdefs.webservices.autotype;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import weblogic.ant.taskdefs.webservices.TaskUtils;
/*     */ import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JMSReceiveQueueMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JMSReceiveTopicMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JMSSendDestinationMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.JNDINameMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.OperationMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.ParamMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.ParamsMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.ReturnParamMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
/*     */ import weblogic.webservice.util.SmartNameStore;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.stream.ElementFactory;
/*     */ import weblogic.xml.stream.XMLInputOutputStream;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.xmlnode.XMLNodeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSAutoTyper
/*     */   extends AutoTyper
/*     */ {
/*     */   private String destination;
/*     */   private String destinationType;
/*     */   private String action;
/*     */   private String connectionFactory;
/*     */   private String operationName;
/*     */   private String messageType;
/*     */   private String protocol;
/*  67 */   private Class messageType_clazz = null;
/*  68 */   private static int jmsCompCounter = 0;
/*     */ 
/*     */   
/*  71 */   public JMSAutoTyper(File paramFile, String paramString, Task paramTask) { super(paramFile, paramString, paramTask); }
/*     */ 
/*     */ 
/*     */   
/*  75 */   public void setJMSDestination(String paramString) { this.destination = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  79 */   public void setJMSDestinationType(String paramString) { this.destinationType = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  83 */   public void setJMSAction(String paramString) { this.action = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  87 */   public void setJMSConnectionFactory(String paramString) { this.connectionFactory = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void setJMSMessageType(String paramString) { this.messageType = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public void setJMSOperationName(String paramString) { this.operationName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void setProtocol(String paramString) { this.protocol = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 107 */       createTypeMappingBuilder();
/* 108 */     } catch (IOException iOException) {
/* 109 */       throw new BuildException("Failed to create type mapping builder. ", iOException);
/*     */     } 
/*     */     
/*     */     try {
/* 113 */       this.messageType_clazz = TaskUtils.loadClass(this.messageType);
/*     */       
/* 115 */       if (this.style.startsWith("document")) {
/* 116 */         Class[] arrayOfClass = new Class[1];
/* 117 */         XMLName[] arrayOfXMLName = new XMLName[1];
/*     */         
/* 119 */         if (this.action.equals("send")) {
/* 120 */           arrayOfClass[0] = this.messageType_clazz;
/* 121 */           arrayOfXMLName[0] = ElementFactory.createXMLName(this.targetNSURI, this.operationName);
/*     */         } else {
/* 123 */           arrayOfClass[0] = this.messageType_clazz;
/* 124 */           arrayOfXMLName[0] = ElementFactory.createXMLName(this.targetNSURI, this.operationName + "Response");
/*     */         } 
/* 126 */         this.tbuilder.addMapping(arrayOfClass, arrayOfXMLName);
/*     */       } else {
/* 128 */         this.tbuilder.addMapping(new Class[] { this.messageType_clazz });
/*     */       } 
/* 130 */     } catch (BindingException bindingException) {
/* 131 */       throw new BuildException(bindingException);
/* 132 */     } catch (ClassNotFoundException classNotFoundException) {
/* 133 */       throw new BuildException(classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceMBean getWebServiceDescriptor() {
/* 143 */     WebServiceMBeanImpl webServiceMBeanImpl = new WebServiceMBeanImpl();
/* 144 */     webServiceMBeanImpl.setWebServiceName(this.serviceName);
/* 145 */     webServiceMBeanImpl.setURI(this.serviceURI);
/* 146 */     webServiceMBeanImpl.setTargetNamespace(this.targetNSURI);
/* 147 */     webServiceMBeanImpl.setStyle(this.style);
/* 148 */     webServiceMBeanImpl.setUseSOAP12(this.useSoap12);
/* 149 */     if (this.protocol != null) {
/* 150 */       webServiceMBeanImpl.setProtocol(this.protocol);
/*     */     }
/*     */     
/* 153 */     TypeMapping typeMapping = null;
/*     */     try {
/* 155 */       typeMapping = this.tbuilder.getTypeMapping();
/* 156 */     } catch (BindingException bindingException) {
/* 157 */       throw new BuildException("Could not get type mapping", bindingException);
/*     */     } 
/*     */ 
/*     */     
/* 161 */     ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
/* 162 */     OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
/* 163 */     webServiceMBeanImpl.setComponents(componentsMBeanImpl);
/* 164 */     webServiceMBeanImpl.setOperations(operationsMBeanImpl);
/*     */     
/* 166 */     ParamsMBeanImpl paramsMBeanImpl = new ParamsMBeanImpl();
/*     */     
/* 168 */     if (this.action.equals("send")) {
/*     */       
/* 170 */       JMSSendDestinationMBeanImpl jMSSendDestinationMBeanImpl = new JMSSendDestinationMBeanImpl();
/*     */ 
/*     */       
/* 173 */       componentsMBeanImpl.addJMSSendDestination(jMSSendDestinationMBeanImpl);
/* 174 */       jMSSendDestinationMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
/* 175 */       jMSSendDestinationMBeanImpl.setConnectionFactory(this.connectionFactory);
/* 176 */       JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
/* 177 */       jNDINameMBeanImpl.setPath(this.destination);
/* 178 */       jMSSendDestinationMBeanImpl.setJNDIName(jNDINameMBeanImpl);
/*     */ 
/*     */       
/* 181 */       OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 182 */       operationMBeanImpl.setOperationName(this.operationName);
/* 183 */       operationMBeanImpl.setComponent(jMSSendDestinationMBeanImpl);
/* 184 */       operationMBeanImpl.setComponentName(jMSSendDestinationMBeanImpl.getComponentName());
/* 185 */       operationsMBeanImpl.addOperation(operationMBeanImpl);
/*     */ 
/*     */       
/* 188 */       ParamMBeanImpl paramMBeanImpl = new ParamMBeanImpl();
/* 189 */       paramMBeanImpl.setParamName(SmartNameStore.getMangleName(this.messageType_clazz));
/* 190 */       paramMBeanImpl.setClassName(this.messageType);
/* 191 */       paramMBeanImpl.setParamStyle("in");
/* 192 */       paramMBeanImpl.setLocation("body");
/* 193 */       if ("document".equals(this.style)) {
/* 194 */         XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, this.operationName);
/* 195 */         paramMBeanImpl.setParamType(prefixIfNeeded(xMLName));
/*     */       } else {
/* 197 */         XMLName xMLName = typeMapping.getXMLNameFromClass(this.messageType_clazz);
/* 198 */         paramMBeanImpl.setParamType(prefixIfNeeded(xMLName));
/*     */       } 
/*     */       
/* 201 */       paramsMBeanImpl.addParam(paramMBeanImpl);
/* 202 */       operationMBeanImpl.setParams(paramsMBeanImpl);
/*     */     }
/* 204 */     else if (this.destinationType.equals("queue")) {
/*     */       
/* 206 */       JMSReceiveQueueMBeanImpl jMSReceiveQueueMBeanImpl = new JMSReceiveQueueMBeanImpl();
/*     */ 
/*     */       
/* 209 */       componentsMBeanImpl.addJMSReceiveQueue(jMSReceiveQueueMBeanImpl);
/* 210 */       jMSReceiveQueueMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
/* 211 */       jMSReceiveQueueMBeanImpl.setConnectionFactory(this.connectionFactory);
/* 212 */       JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
/* 213 */       jNDINameMBeanImpl.setPath(this.destination);
/* 214 */       jMSReceiveQueueMBeanImpl.setJNDIName(jNDINameMBeanImpl);
/*     */ 
/*     */       
/* 217 */       OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 218 */       operationMBeanImpl.setOperationName(this.operationName);
/* 219 */       operationMBeanImpl.setComponent(jMSReceiveQueueMBeanImpl);
/* 220 */       operationMBeanImpl.setComponentName(jMSReceiveQueueMBeanImpl.getComponentName());
/* 221 */       operationsMBeanImpl.addOperation(operationMBeanImpl);
/*     */ 
/*     */       
/* 224 */       ReturnParamMBeanImpl returnParamMBeanImpl = new ReturnParamMBeanImpl();
/* 225 */       returnParamMBeanImpl.setParamName("result");
/* 226 */       returnParamMBeanImpl.setClassName(this.messageType);
/* 227 */       returnParamMBeanImpl.setLocation("body");
/* 228 */       if (this.style.equals("document")) {
/* 229 */         XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, this.operationName + "Response");
/* 230 */         returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
/*     */       } else {
/* 232 */         XMLName xMLName = typeMapping.getXMLNameFromClass(this.messageType_clazz);
/* 233 */         returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
/*     */       } 
/*     */       
/* 236 */       paramsMBeanImpl.setReturnParam(returnParamMBeanImpl);
/* 237 */       operationMBeanImpl.setParams(paramsMBeanImpl);
/*     */     }
/* 239 */     else if (this.destinationType.equals("topic")) {
/*     */       
/* 241 */       JMSReceiveTopicMBeanImpl jMSReceiveTopicMBeanImpl = new JMSReceiveTopicMBeanImpl();
/*     */ 
/*     */       
/* 244 */       componentsMBeanImpl.addJMSReceiveTopic(jMSReceiveTopicMBeanImpl);
/* 245 */       jMSReceiveTopicMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
/* 246 */       jMSReceiveTopicMBeanImpl.setConnectionFactory(this.connectionFactory);
/* 247 */       JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
/* 248 */       jNDINameMBeanImpl.setPath(this.destination);
/* 249 */       jMSReceiveTopicMBeanImpl.setJNDIName(jNDINameMBeanImpl);
/*     */ 
/*     */       
/* 252 */       OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
/* 253 */       operationMBeanImpl.setOperationName(this.operationName);
/* 254 */       operationMBeanImpl.setComponent(jMSReceiveTopicMBeanImpl);
/* 255 */       operationMBeanImpl.setComponentName(jMSReceiveTopicMBeanImpl.getComponentName());
/* 256 */       operationsMBeanImpl.addOperation(operationMBeanImpl);
/*     */ 
/*     */       
/* 259 */       ReturnParamMBeanImpl returnParamMBeanImpl = new ReturnParamMBeanImpl();
/* 260 */       returnParamMBeanImpl.setParamName("result");
/* 261 */       returnParamMBeanImpl.setClassName(this.messageType);
/* 262 */       returnParamMBeanImpl.setLocation("body");
/* 263 */       if ("document".equals(this.style)) {
/* 264 */         XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, this.operationName + "Response");
/* 265 */         returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
/*     */       } else {
/* 267 */         XMLName xMLName = typeMapping.getXMLNameFromClass(this.messageType_clazz);
/* 268 */         returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
/*     */       } 
/*     */       
/* 271 */       paramsMBeanImpl.setReturnParam(returnParamMBeanImpl);
/* 272 */       operationMBeanImpl.setParams(paramsMBeanImpl);
/*     */     } 
/*     */     
/*     */     try {
/* 276 */       webServiceMBeanImpl.setTypeMapping(getTypeMappingDescriptor());
/* 277 */       webServiceMBeanImpl.setTypes(getTypes());
/* 278 */     } catch (BindingException bindingException) {
/* 279 */       throw new BuildException(bindingException);
/*     */     } 
/*     */     
/* 282 */     return webServiceMBeanImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLNodeSet getTypes() {
/* 289 */     xMLInputOutputStream = null;
/*     */     
/* 291 */     try { xMLInputOutputStream = XMLOutputStreamFactory.newInstance().newInputOutputStream();
/* 292 */       this.tbuilder.writeGeneratedSchemas(xMLInputOutputStream);
/* 293 */       return readSchemasFromStream(xMLInputOutputStream); }
/* 294 */     catch (IOException iOException)
/* 295 */     { throw new BuildException("Problem writing XML types", iOException); }
/* 296 */     catch (BindingException bindingException)
/* 297 */     { throw new BuildException("Problem generating XML types", bindingException); }
/*     */     finally { 
/* 299 */       try { xMLInputOutputStream.close(); } catch (Throwable throwable) {} }
/*     */   
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\JMSAutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */