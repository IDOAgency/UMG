package weblogic.ant.taskdefs.webservices.autotype;

import java.io.File;
import java.io.IOException;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import weblogic.ant.taskdefs.webservices.TaskUtils;
import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
import weblogic.management.descriptors.webservice.JMSReceiveQueueMBeanImpl;
import weblogic.management.descriptors.webservice.JMSReceiveTopicMBeanImpl;
import weblogic.management.descriptors.webservice.JMSSendDestinationMBeanImpl;
import weblogic.management.descriptors.webservice.JNDINameMBeanImpl;
import weblogic.management.descriptors.webservice.OperationMBeanImpl;
import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
import weblogic.management.descriptors.webservice.ParamMBeanImpl;
import weblogic.management.descriptors.webservice.ParamsMBeanImpl;
import weblogic.management.descriptors.webservice.ReturnParamMBeanImpl;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
import weblogic.webservice.util.SmartNameStore;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.stream.ElementFactory;
import weblogic.xml.stream.XMLInputOutputStream;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.xmlnode.XMLNodeSet;

public class JMSAutoTyper extends AutoTyper {
  private String destination;
  
  private String destinationType;
  
  private String action;
  
  private String connectionFactory;
  
  private String operationName;
  
  private String messageType;
  
  private String protocol;
  
  private Class messageType_clazz = null;
  
  private static int jmsCompCounter = 0;
  
  public JMSAutoTyper(File paramFile, String paramString, Task paramTask) { super(paramFile, paramString, paramTask); }
  
  public void setJMSDestination(String paramString) { this.destination = paramString; }
  
  public void setJMSDestinationType(String paramString) { this.destinationType = paramString; }
  
  public void setJMSAction(String paramString) { this.action = paramString; }
  
  public void setJMSConnectionFactory(String paramString) { this.connectionFactory = paramString; }
  
  public void setJMSMessageType(String paramString) { this.messageType = paramString; }
  
  public void setJMSOperationName(String paramString) { this.operationName = paramString; }
  
  public void setProtocol(String paramString) { this.protocol = paramString; }
  
  public void run() {
    try {
      createTypeMappingBuilder();
    } catch (IOException iOException) {
      throw new BuildException("Failed to create type mapping builder. ", iOException);
    } 
    try {
      this.messageType_clazz = TaskUtils.loadClass(this.messageType);
      if (this.style.startsWith("document")) {
        Class[] arrayOfClass = new Class[1];
        XMLName[] arrayOfXMLName = new XMLName[1];
        if (this.action.equals("send")) {
          arrayOfClass[0] = this.messageType_clazz;
          arrayOfXMLName[0] = ElementFactory.createXMLName(this.targetNSURI, this.operationName);
        } else {
          arrayOfClass[0] = this.messageType_clazz;
          arrayOfXMLName[0] = ElementFactory.createXMLName(this.targetNSURI, this.operationName + "Response");
        } 
        this.tbuilder.addMapping(arrayOfClass, arrayOfXMLName);
      } else {
        this.tbuilder.addMapping(new Class[] { this.messageType_clazz });
      } 
    } catch (BindingException bindingException) {
      throw new BuildException(bindingException);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new BuildException(classNotFoundException);
    } 
  }
  
  public WebServiceMBean getWebServiceDescriptor() {
    WebServiceMBeanImpl webServiceMBeanImpl = new WebServiceMBeanImpl();
    webServiceMBeanImpl.setWebServiceName(this.serviceName);
    webServiceMBeanImpl.setURI(this.serviceURI);
    webServiceMBeanImpl.setTargetNamespace(this.targetNSURI);
    webServiceMBeanImpl.setStyle(this.style);
    webServiceMBeanImpl.setUseSOAP12(this.useSoap12);
    if (this.protocol != null)
      webServiceMBeanImpl.setProtocol(this.protocol); 
    TypeMapping typeMapping = null;
    try {
      typeMapping = this.tbuilder.getTypeMapping();
    } catch (BindingException bindingException) {
      throw new BuildException("Could not get type mapping", bindingException);
    } 
    ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
    OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
    webServiceMBeanImpl.setComponents(componentsMBeanImpl);
    webServiceMBeanImpl.setOperations(operationsMBeanImpl);
    ParamsMBeanImpl paramsMBeanImpl = new ParamsMBeanImpl();
    if (this.action.equals("send")) {
      JMSSendDestinationMBeanImpl jMSSendDestinationMBeanImpl = new JMSSendDestinationMBeanImpl();
      componentsMBeanImpl.addJMSSendDestination(jMSSendDestinationMBeanImpl);
      jMSSendDestinationMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
      jMSSendDestinationMBeanImpl.setConnectionFactory(this.connectionFactory);
      JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
      jNDINameMBeanImpl.setPath(this.destination);
      jMSSendDestinationMBeanImpl.setJNDIName(jNDINameMBeanImpl);
      OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
      operationMBeanImpl.setOperationName(this.operationName);
      operationMBeanImpl.setComponent(jMSSendDestinationMBeanImpl);
      operationMBeanImpl.setComponentName(jMSSendDestinationMBeanImpl.getComponentName());
      operationsMBeanImpl.addOperation(operationMBeanImpl);
      ParamMBeanImpl paramMBeanImpl = new ParamMBeanImpl();
      paramMBeanImpl.setParamName(SmartNameStore.getMangleName(this.messageType_clazz));
      paramMBeanImpl.setClassName(this.messageType);
      paramMBeanImpl.setParamStyle("in");
      paramMBeanImpl.setLocation("body");
      if ("document".equals(this.style)) {
        XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, this.operationName);
        paramMBeanImpl.setParamType(prefixIfNeeded(xMLName));
      } else {
        XMLName xMLName = typeMapping.getXMLNameFromClass(this.messageType_clazz);
        paramMBeanImpl.setParamType(prefixIfNeeded(xMLName));
      } 
      paramsMBeanImpl.addParam(paramMBeanImpl);
      operationMBeanImpl.setParams(paramsMBeanImpl);
    } else if (this.destinationType.equals("queue")) {
      JMSReceiveQueueMBeanImpl jMSReceiveQueueMBeanImpl = new JMSReceiveQueueMBeanImpl();
      componentsMBeanImpl.addJMSReceiveQueue(jMSReceiveQueueMBeanImpl);
      jMSReceiveQueueMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
      jMSReceiveQueueMBeanImpl.setConnectionFactory(this.connectionFactory);
      JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
      jNDINameMBeanImpl.setPath(this.destination);
      jMSReceiveQueueMBeanImpl.setJNDIName(jNDINameMBeanImpl);
      OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
      operationMBeanImpl.setOperationName(this.operationName);
      operationMBeanImpl.setComponent(jMSReceiveQueueMBeanImpl);
      operationMBeanImpl.setComponentName(jMSReceiveQueueMBeanImpl.getComponentName());
      operationsMBeanImpl.addOperation(operationMBeanImpl);
      ReturnParamMBeanImpl returnParamMBeanImpl = new ReturnParamMBeanImpl();
      returnParamMBeanImpl.setParamName("result");
      returnParamMBeanImpl.setClassName(this.messageType);
      returnParamMBeanImpl.setLocation("body");
      if (this.style.equals("document")) {
        XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, this.operationName + "Response");
        returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
      } else {
        XMLName xMLName = typeMapping.getXMLNameFromClass(this.messageType_clazz);
        returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
      } 
      paramsMBeanImpl.setReturnParam(returnParamMBeanImpl);
      operationMBeanImpl.setParams(paramsMBeanImpl);
    } else if (this.destinationType.equals("topic")) {
      JMSReceiveTopicMBeanImpl jMSReceiveTopicMBeanImpl = new JMSReceiveTopicMBeanImpl();
      componentsMBeanImpl.addJMSReceiveTopic(jMSReceiveTopicMBeanImpl);
      jMSReceiveTopicMBeanImpl.setComponentName("jmsComp" + jmsCompCounter++);
      jMSReceiveTopicMBeanImpl.setConnectionFactory(this.connectionFactory);
      JNDINameMBeanImpl jNDINameMBeanImpl = new JNDINameMBeanImpl();
      jNDINameMBeanImpl.setPath(this.destination);
      jMSReceiveTopicMBeanImpl.setJNDIName(jNDINameMBeanImpl);
      OperationMBeanImpl operationMBeanImpl = new OperationMBeanImpl();
      operationMBeanImpl.setOperationName(this.operationName);
      operationMBeanImpl.setComponent(jMSReceiveTopicMBeanImpl);
      operationMBeanImpl.setComponentName(jMSReceiveTopicMBeanImpl.getComponentName());
      operationsMBeanImpl.addOperation(operationMBeanImpl);
      ReturnParamMBeanImpl returnParamMBeanImpl = new ReturnParamMBeanImpl();
      returnParamMBeanImpl.setParamName("result");
      returnParamMBeanImpl.setClassName(this.messageType);
      returnParamMBeanImpl.setLocation("body");
      if ("document".equals(this.style)) {
        XMLName xMLName = ElementFactory.createXMLName(this.targetNSURI, this.operationName + "Response");
        returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
      } else {
        XMLName xMLName = typeMapping.getXMLNameFromClass(this.messageType_clazz);
        returnParamMBeanImpl.setParamType(prefixIfNeeded(xMLName));
      } 
      paramsMBeanImpl.setReturnParam(returnParamMBeanImpl);
      operationMBeanImpl.setParams(paramsMBeanImpl);
    } 
    try {
      webServiceMBeanImpl.setTypeMapping(getTypeMappingDescriptor());
      webServiceMBeanImpl.setTypes(getTypes());
    } catch (BindingException bindingException) {
      throw new BuildException(bindingException);
    } 
    return webServiceMBeanImpl;
  }
  
  public XMLNodeSet getTypes() {
    xMLInputOutputStream = null;
    try {
      xMLInputOutputStream = XMLOutputStreamFactory.newInstance().newInputOutputStream();
      this.tbuilder.writeGeneratedSchemas(xMLInputOutputStream);
      return readSchemasFromStream(xMLInputOutputStream);
    } catch (IOException iOException) {
      throw new BuildException("Problem writing XML types", iOException);
    } catch (BindingException bindingException) {
      throw new BuildException("Problem generating XML types", bindingException);
    } finally {
      try {
        xMLInputOutputStream.close();
      } catch (Throwable throwable) {}
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\ant\taskdefs\webservices\autotype\JMSAutoTyper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */