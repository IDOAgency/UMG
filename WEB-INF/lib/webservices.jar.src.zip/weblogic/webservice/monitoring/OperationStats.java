package weblogic.webservice.monitoring;

import javax.xml.soap.SOAPException;

public interface OperationStats {
  HandlerStats[] getHandlerStats();
  
  void reportInvocation(long paramLong1, long paramLong2, long paramLong3);
  
  void reportResponseError(SOAPException paramSOAPException);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\OperationStats.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */