package weblogic.webservice.monitoring;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.soap.SOAPException;
import weblogic.management.ManagementException;
import weblogic.management.runtime.RuntimeMBean;
import weblogic.management.runtime.RuntimeMBeanDelegate;
import weblogic.management.runtime.ServerRuntimeMBean;
import weblogic.management.runtime.WebServiceHandlerRuntimeMBean;
import weblogic.management.runtime.WebServiceOperationRuntimeMBean;
import weblogic.management.runtime.WebServiceRuntimeMBean;
import weblogic.utils.AssertionError;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;

public final class WSRuntimeMBeanImpl extends RuntimeMBeanDelegate implements WebServiceRuntimeMBean, WebServiceStats {
  private static final String WSDL_QUERYPARAM = "WSDL";
  
  private Date mLastResetTime = null;
  
  private String mURI;
  
  private String mContextPath;
  
  private WebService mService;
  
  private WSOperationRuntimeMBeanImpl[] mOperations;
  
  private WSHandlerRuntimeMBeanImpl[] mAllHandlers = null;
  
  private WSHandlerRuntimeMBeanImpl[] mUserHandlers = null;
  
  private int mWSDLHits = 0, mHomePageHits = 0;
  
  private int mMalformedRequestCount = 0;
  
  private SOAPException mLastMalformedRequestError = null;
  
  WSRuntimeMBeanImpl(WebService paramWebService, String paramString1, String paramString2, RuntimeMBean paramRuntimeMBean) throws ManagementException {
    super(paramWebService.getName(), paramRuntimeMBean);
    this.mURI = paramString1;
    this.mContextPath = paramString2;
    this.mService = paramWebService;
    initOps(paramWebService);
    initHandlers(paramWebService);
  }
  
  public String getURI() { return this.mURI; }
  
  public String getHomePageURL() {
    ServerRuntimeMBean serverRuntimeMBean = (ServerRuntimeMBean)getParent().getParent().getParent();
    String str = serverRuntimeMBean.getURL("http");
    return str + this.mContextPath + this.mURI;
  }
  
  public String getWSDLUrl() { return getHomePageURL() + "?" + "WSDL"; }
  
  public String getServiceName() { return this.mService.getName(); }
  
  public int getWSDLHitCount() { return this.mWSDLHits; }
  
  public int getHomePageHitCount() { return this.mHomePageHits; }
  
  public WebServiceOperationRuntimeMBean[] getOperations() { return this.mOperations; }
  
  public WebServiceHandlerRuntimeMBean[] getHandlers() { return this.mUserHandlers; }
  
  public WebServiceHandlerRuntimeMBean[] getAllHandlers() { return this.mAllHandlers; }
  
  public int getMalformedRequestCount() { return this.mMalformedRequestCount; }
  
  public SOAPException getLastMalformedRequestError() { return this.mLastMalformedRequestError; }
  
  public void reset() {
    synchronized (this) {
      this.mLastResetTime = new Date();
      this.mMalformedRequestCount = 0;
      this.mLastMalformedRequestError = null;
      this.mHomePageHits = 0;
      this.mWSDLHits = 0;
    } 
  }
  
  public Date getLastResetTime() { return this.mLastResetTime; }
  
  public void reportWSDLHit() {
    synchronized (this) {
      this.mWSDLHits++;
    } 
  }
  
  public void reportHomePageHit() {
    synchronized (this) {
      this.mHomePageHits++;
    } 
  }
  
  public void reportMalformedRequest(SOAPException paramSOAPException) {
    synchronized (this) {
      this.mMalformedRequestCount++;
    } 
    this.mLastMalformedRequestError = paramSOAPException;
  }
  
  public HandlerStats[] getHandlerStats() { return this.mAllHandlers; }
  
  private void initOps(WebService paramWebService) throws ManagementException {
    ArrayList arrayList = new ArrayList();
    byte b = 0;
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      for (Iterator iterator1 = port.getOperations(); iterator1.hasNext(); ) {
        Operation operation = (Operation)iterator1.next();
        if (operation.getStats() == null) {
          WSOperationRuntimeMBeanImpl wSOperationRuntimeMBeanImpl = new WSOperationRuntimeMBeanImpl(operation, operation.getName() + "-" + b, this);
          operation.setStats(wSOperationRuntimeMBeanImpl);
          arrayList.add(wSOperationRuntimeMBeanImpl);
        } 
      } 
    } 
    this.mOperations = new WSOperationRuntimeMBeanImpl[arrayList.size()];
    arrayList.toArray(this.mOperations);
  }
  
  private void initHandlers(WebService paramWebService) throws ManagementException {
    HandlerInfo[] arrayOfHandlerInfo = paramWebService.getHandlerInfos();
    if (arrayOfHandlerInfo == null || arrayOfHandlerInfo.length == 0) {
      this.mAllHandlers = null;
      this.mUserHandlers = null;
      return;
    } 
    ArrayList arrayList = new ArrayList();
    this.mAllHandlers = new WSHandlerRuntimeMBeanImpl[arrayOfHandlerInfo.length];
    for (byte b = 0; b < arrayOfHandlerInfo.length; b++) {
      this.mAllHandlers[b] = new WSHandlerRuntimeMBeanImpl(arrayOfHandlerInfo[b], "handler-" + b, this);
      if (!this.mAllHandlers[b].isInternal())
        arrayList.add(this.mAllHandlers[b]); 
    } 
    if (arrayList.size() == 0) {
      this.mUserHandlers = null;
    } else {
      this.mUserHandlers = new WSHandlerRuntimeMBeanImpl[arrayList.size()];
      arrayList.toArray(this.mUserHandlers);
    } 
  }
  
  public WSRuntimeMBeanImpl() { throw new AssertionError("Public constructor provided only for JMX compliance."); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WSRuntimeMBeanImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */