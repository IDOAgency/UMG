/*     */ package weblogic.webservice.monitoring;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.management.ManagementException;
/*     */ import weblogic.management.runtime.RuntimeMBean;
/*     */ import weblogic.management.runtime.RuntimeMBeanDelegate;
/*     */ import weblogic.management.runtime.ServerRuntimeMBean;
/*     */ import weblogic.management.runtime.WebServiceHandlerRuntimeMBean;
/*     */ import weblogic.management.runtime.WebServiceOperationRuntimeMBean;
/*     */ import weblogic.management.runtime.WebServiceRuntimeMBean;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WSRuntimeMBeanImpl
/*     */   extends RuntimeMBeanDelegate
/*     */   implements WebServiceRuntimeMBean, WebServiceStats
/*     */ {
/*     */   private static final String WSDL_QUERYPARAM = "WSDL";
/*  46 */   private Date mLastResetTime = null;
/*     */   
/*     */   private String mURI;
/*     */   private String mContextPath;
/*  50 */   private WSHandlerRuntimeMBeanImpl[] mAllHandlers = null; private WebService mService; private WSOperationRuntimeMBeanImpl[] mOperations;
/*  51 */   private WSHandlerRuntimeMBeanImpl[] mUserHandlers = null;
/*  52 */   private int mWSDLHits = 0, mHomePageHits = 0;
/*  53 */   private int mMalformedRequestCount = 0;
/*  54 */   private SOAPException mLastMalformedRequestError = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WSRuntimeMBeanImpl(WebService paramWebService, String paramString1, String paramString2, RuntimeMBean paramRuntimeMBean) throws ManagementException {
/*  65 */     super(paramWebService.getName(), paramRuntimeMBean);
/*  66 */     this.mURI = paramString1;
/*  67 */     this.mContextPath = paramString2;
/*  68 */     this.mService = paramWebService;
/*  69 */     initOps(paramWebService);
/*  70 */     initHandlers(paramWebService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public String getURI() { return this.mURI; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHomePageURL() {
/*  83 */     ServerRuntimeMBean serverRuntimeMBean = (ServerRuntimeMBean)getParent().getParent().getParent();
/*     */     
/*  85 */     String str = serverRuntimeMBean.getURL("http");
/*  86 */     return str + this.mContextPath + this.mURI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public String getWSDLUrl() { return getHomePageURL() + "?" + "WSDL"; }
/*     */ 
/*     */   
/*  95 */   public String getServiceName() { return this.mService.getName(); }
/*     */   
/*  97 */   public int getWSDLHitCount() { return this.mWSDLHits; }
/*     */   
/*  99 */   public int getHomePageHitCount() { return this.mHomePageHits; }
/*     */ 
/*     */   
/* 102 */   public WebServiceOperationRuntimeMBean[] getOperations() { return this.mOperations; }
/*     */ 
/*     */ 
/*     */   
/* 106 */   public WebServiceHandlerRuntimeMBean[] getHandlers() { return this.mUserHandlers; }
/*     */ 
/*     */ 
/*     */   
/* 110 */   public WebServiceHandlerRuntimeMBean[] getAllHandlers() { return this.mAllHandlers; }
/*     */ 
/*     */   
/* 113 */   public int getMalformedRequestCount() { return this.mMalformedRequestCount; }
/*     */ 
/*     */   
/* 116 */   public SOAPException getLastMalformedRequestError() { return this.mLastMalformedRequestError; }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 120 */     synchronized (this) {
/* 121 */       this.mLastResetTime = new Date();
/* 122 */       this.mMalformedRequestCount = 0;
/* 123 */       this.mLastMalformedRequestError = null;
/* 124 */       this.mHomePageHits = 0;
/* 125 */       this.mWSDLHits = 0;
/*     */     } 
/*     */   }
/*     */   
/* 129 */   public Date getLastResetTime() { return this.mLastResetTime; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportWSDLHit() {
/* 135 */     synchronized (this) {
/* 136 */       this.mWSDLHits++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportHomePageHit() {
/* 141 */     synchronized (this) {
/* 142 */       this.mHomePageHits++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportMalformedRequest(SOAPException paramSOAPException) {
/* 147 */     synchronized (this) {
/* 148 */       this.mMalformedRequestCount++;
/*     */     } 
/* 150 */     this.mLastMalformedRequestError = paramSOAPException;
/*     */   }
/*     */   
/* 153 */   public HandlerStats[] getHandlerStats() { return this.mAllHandlers; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initOps(WebService paramWebService) throws ManagementException {
/* 177 */     ArrayList arrayList = new ArrayList();
/* 178 */     byte b = 0;
/* 179 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 180 */       Port port = (Port)iterator.next();
/* 181 */       for (Iterator iterator1 = port.getOperations(); iterator1.hasNext(); ) {
/* 182 */         Operation operation = (Operation)iterator1.next();
/*     */         
/* 184 */         if (operation.getStats() == null) {
/* 185 */           WSOperationRuntimeMBeanImpl wSOperationRuntimeMBeanImpl = new WSOperationRuntimeMBeanImpl(operation, operation.getName() + "-" + b, this);
/*     */ 
/*     */           
/* 188 */           operation.setStats(wSOperationRuntimeMBeanImpl);
/* 189 */           arrayList.add(wSOperationRuntimeMBeanImpl);
/*     */         } 
/*     */       } 
/*     */     } 
/* 193 */     this.mOperations = new WSOperationRuntimeMBeanImpl[arrayList.size()];
/* 194 */     arrayList.toArray(this.mOperations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initHandlers(WebService paramWebService) throws ManagementException {
/* 202 */     HandlerInfo[] arrayOfHandlerInfo = paramWebService.getHandlerInfos();
/* 203 */     if (arrayOfHandlerInfo == null || arrayOfHandlerInfo.length == 0) {
/* 204 */       this.mAllHandlers = null;
/* 205 */       this.mUserHandlers = null;
/*     */       return;
/*     */     } 
/* 208 */     ArrayList arrayList = new ArrayList();
/* 209 */     this.mAllHandlers = new WSHandlerRuntimeMBeanImpl[arrayOfHandlerInfo.length];
/* 210 */     for (byte b = 0; b < arrayOfHandlerInfo.length; b++) {
/* 211 */       this.mAllHandlers[b] = new WSHandlerRuntimeMBeanImpl(arrayOfHandlerInfo[b], "handler-" + b, this);
/*     */       
/* 213 */       if (!this.mAllHandlers[b].isInternal()) arrayList.add(this.mAllHandlers[b]); 
/*     */     } 
/* 215 */     if (arrayList.size() == 0) {
/* 216 */       this.mUserHandlers = null;
/*     */     } else {
/* 218 */       this.mUserHandlers = new WSHandlerRuntimeMBeanImpl[arrayList.size()];
/* 219 */       arrayList.toArray(this.mUserHandlers);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 232 */   public WSRuntimeMBeanImpl() { throw new AssertionError("Public constructor provided only for JMX compliance."); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WSRuntimeMBeanImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */