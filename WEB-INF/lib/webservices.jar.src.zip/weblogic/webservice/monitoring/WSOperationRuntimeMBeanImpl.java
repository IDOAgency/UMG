/*     */ package weblogic.webservice.monitoring;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.management.ManagementException;
/*     */ import weblogic.management.runtime.RuntimeMBean;
/*     */ import weblogic.management.runtime.RuntimeMBeanDelegate;
/*     */ import weblogic.management.runtime.WebServiceHandlerRuntimeMBean;
/*     */ import weblogic.management.runtime.WebServiceOperationRuntimeMBean;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.InvocationHandler;
/*     */ import weblogic.webservice.Operation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WSOperationRuntimeMBeanImpl
/*     */   extends RuntimeMBeanDelegate
/*     */   implements WebServiceOperationRuntimeMBean, OperationStats
/*     */ {
/*     */   private InvocationHandler mInvocationHandler;
/*     */   private Operation mOp;
/*  45 */   private WSHandlerRuntimeMBeanImpl[] mUserHandlers = null;
/*  46 */   private WSHandlerRuntimeMBeanImpl[] mAllHandlers = null;
/*  47 */   private WSHandlerRuntimeMBeanImpl mInvocationHandlerMBean = null;
/*  48 */   private Date mLastResetTime = null;
/*     */ 
/*     */   
/*  51 */   private int mDispatchCount = 0;
/*  52 */   private long mDispatchTimeTotal = 0L;
/*  53 */   private long mDispatchTimeHigh = 0L;
/*  54 */   private long mDispatchTimeLow = 0L;
/*     */   
/*  56 */   private int mExecutionCount = 0;
/*  57 */   private long mExecutionTimeTotal = 0L;
/*  58 */   private long mExecutionTimeHigh = 0L;
/*  59 */   private long mExecutionTimeLow = 0L;
/*     */   
/*  61 */   private int mResponseCount = 0;
/*  62 */   private long mResponseTimeTotal = 0L;
/*  63 */   private long mResponseTimeHigh = 0L;
/*  64 */   private long mResponseTimeLow = 0L;
/*     */   
/*  66 */   private int mResponseErrorCount = 0;
/*  67 */   private SOAPException mLastResponseError = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WSOperationRuntimeMBeanImpl(Operation paramOperation, String paramString, RuntimeMBean paramRuntimeMBean) throws ManagementException {
/*  79 */     super(paramString, paramRuntimeMBean);
/*  80 */     this.mOp = paramOperation;
/*  81 */     this.mInvocationHandler = paramOperation.getInvocationHandler();
/*  82 */     initHandlers(paramOperation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public String getOperationName() { return this.mOp.getName(); }
/*     */   
/*  91 */   public int getComponentType() { return this.mInvocationHandler.getType(); }
/*     */   
/*  93 */   public String getComponentInfo() { return this.mInvocationHandler.getInfo(); }
/*     */ 
/*     */   
/*  96 */   public WebServiceHandlerRuntimeMBean[] getHandlers() { return this.mUserHandlers; }
/*     */ 
/*     */ 
/*     */   
/* 100 */   public WebServiceHandlerRuntimeMBean[] getAllHandlers() { return this.mAllHandlers; }
/*     */ 
/*     */ 
/*     */   
/* 104 */   public WebServiceHandlerRuntimeMBean getInvocationHandler() { return this.mInvocationHandlerMBean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public int getInvocationCount() { return this.mDispatchCount; }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public long getDispatchTimeTotal() { return this.mDispatchTimeTotal; }
/*     */   
/* 117 */   public long getDispatchTimeHigh() { return this.mDispatchTimeHigh; }
/*     */   
/* 119 */   public long getDispatchTimeLow() { return this.mDispatchTimeLow; }
/*     */ 
/*     */   
/* 122 */   public long getDispatchTimeAverage() { return (this.mDispatchCount == 0) ? 0L : (this.mDispatchTimeTotal / this.mDispatchCount); }
/*     */ 
/*     */ 
/*     */   
/* 126 */   public long getExecutionTimeTotal() { return this.mExecutionTimeTotal; }
/*     */   
/* 128 */   public long getExecutionTimeHigh() { return this.mExecutionTimeHigh; }
/*     */   
/* 130 */   public long getExecutionTimeLow() { return this.mExecutionTimeLow; }
/*     */ 
/*     */   
/* 133 */   public long getExecutionTimeAverage() { return (this.mExecutionCount == 0) ? 0L : (this.mExecutionTimeTotal / this.mExecutionCount); }
/*     */ 
/*     */   
/* 136 */   public int getResponseCount() { return this.mResponseCount; }
/*     */   
/* 138 */   public long getResponseTimeTotal() { return this.mResponseTimeTotal; }
/*     */   
/* 140 */   public long getResponseTimeHigh() { return this.mResponseTimeHigh; }
/*     */   
/* 142 */   public long getResponseTimeLow() { return this.mResponseTimeLow; }
/*     */ 
/*     */   
/* 145 */   public long getResponseTimeAverage() { return (this.mResponseCount == 0) ? 0L : (this.mResponseTimeTotal / this.mResponseCount); }
/*     */ 
/*     */   
/* 148 */   public int getResponseErrorCount() { return this.mResponseErrorCount; }
/*     */   
/* 150 */   public SOAPException getLastResponseError() { return this.mLastResponseError; }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 154 */     synchronized (this) {
/* 155 */       this.mLastResetTime = new Date();
/* 156 */       this.mExecutionCount = 0;
/* 157 */       this.mDispatchTimeTotal = 0L;
/* 158 */       this.mDispatchTimeHigh = 0L;
/* 159 */       this.mDispatchTimeLow = 0L;
/* 160 */       this.mExecutionTimeTotal = 0L;
/* 161 */       this.mExecutionTimeHigh = 0L;
/* 162 */       this.mExecutionTimeLow = 0L;
/*     */     } 
/*     */   }
/*     */   
/* 166 */   public Date getLastResetTime() { return this.mLastResetTime; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportInvocation(long paramLong1, long paramLong2, long paramLong3) {
/* 175 */     synchronized (this) {
/* 176 */       unsync_reportDispatch(paramLong1);
/* 177 */       unsync_reportExecution(paramLong2);
/* 178 */       unsync_reportResponse(paramLong3);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportDispatch(long paramLong) {
/* 183 */     synchronized (this) {
/* 184 */       unsync_reportDispatch(paramLong);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reportExecution(long paramLong) {
/* 190 */     synchronized (this) {
/* 191 */       unsync_reportExecution(paramLong);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportResponse(long paramLong) {
/* 196 */     synchronized (this) {
/* 197 */       unsync_reportResponse(paramLong);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportResponseError(SOAPException paramSOAPException) {
/* 202 */     synchronized (this) {
/* 203 */       this.mResponseErrorCount++;
/* 204 */       this.mLastResponseError = paramSOAPException;
/*     */     } 
/*     */   }
/*     */   
/* 208 */   public HandlerStats[] getHandlerStats() { return this.mAllHandlers; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unsync_reportResponse(long paramLong) {
/* 220 */     if (paramLong >= 0L)
/*     */     {
/*     */       
/* 223 */       if (this.mResponseCount == 0) {
/* 224 */         this.mResponseTimeTotal = paramLong;
/* 225 */         this.mResponseTimeHigh = paramLong;
/* 226 */         this.mResponseTimeLow = paramLong;
/* 227 */         this.mResponseCount = 1;
/*     */       } else {
/* 229 */         this.mResponseCount++;
/* 230 */         this.mResponseTimeTotal += paramLong;
/* 231 */         if (paramLong > this.mResponseTimeHigh) this.mResponseTimeHigh = paramLong; 
/* 232 */         if (paramLong < this.mResponseTimeLow) this.mResponseTimeLow = paramLong;
/*     */       
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void unsync_reportExecution(long paramLong) {
/* 239 */     if (paramLong >= 0L)
/*     */     {
/*     */       
/* 242 */       if (this.mExecutionCount == 0) {
/* 243 */         this.mExecutionTimeTotal = paramLong;
/* 244 */         this.mExecutionTimeHigh = paramLong;
/* 245 */         this.mExecutionTimeLow = paramLong;
/* 246 */         this.mExecutionCount = 1;
/*     */       } else {
/* 248 */         this.mExecutionCount++;
/* 249 */         this.mExecutionTimeTotal += paramLong;
/* 250 */         if (paramLong > this.mExecutionTimeHigh) this.mExecutionTimeHigh = paramLong; 
/* 251 */         if (paramLong < this.mExecutionTimeLow) this.mExecutionTimeLow = paramLong; 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void unsync_reportDispatch(long paramLong) {
/* 257 */     if (paramLong >= 0L)
/*     */     {
/*     */       
/* 260 */       if (this.mDispatchCount == 0) {
/* 261 */         this.mDispatchTimeTotal = paramLong;
/* 262 */         this.mDispatchTimeHigh = paramLong;
/* 263 */         this.mDispatchTimeLow = paramLong;
/* 264 */         this.mDispatchCount = 1;
/*     */       } else {
/* 266 */         this.mDispatchCount++;
/* 267 */         this.mDispatchTimeTotal += paramLong;
/* 268 */         if (paramLong > this.mDispatchTimeHigh) this.mDispatchTimeHigh = paramLong; 
/* 269 */         if (paramLong < this.mDispatchTimeLow) this.mDispatchTimeLow = paramLong;
/*     */       
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initHandlers(Operation paramOperation) throws ManagementException {
/* 279 */     HandlerInfo[] arrayOfHandlerInfo = paramOperation.getHandlerInfos();
/* 280 */     if (arrayOfHandlerInfo == null || arrayOfHandlerInfo.length == 0) {
/*     */       
/* 282 */       this.mAllHandlers = null;
/* 283 */       this.mUserHandlers = null;
/* 284 */       this.mInvocationHandlerMBean = null;
/*     */       return;
/*     */     } 
/* 287 */     ArrayList arrayList = new ArrayList();
/* 288 */     this.mAllHandlers = new WSHandlerRuntimeMBeanImpl[arrayOfHandlerInfo.length];
/* 289 */     for (byte b = 0; b < arrayOfHandlerInfo.length; b++) {
/* 290 */       this.mAllHandlers[b] = new WSHandlerRuntimeMBeanImpl(arrayOfHandlerInfo[b], "handler-" + b, this);
/*     */       
/* 292 */       if (!this.mAllHandlers[b].isInternal()) arrayList.add(this.mAllHandlers[b]); 
/*     */     } 
/* 294 */     if (arrayList.size() == 0) {
/* 295 */       this.mUserHandlers = null;
/*     */     } else {
/* 297 */       this.mUserHandlers = new WSHandlerRuntimeMBeanImpl[arrayList.size()];
/* 298 */       arrayList.toArray(this.mUserHandlers);
/*     */     } 
/* 300 */     this.mInvocationHandlerMBean = this.mAllHandlers[this.mAllHandlers.length - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 313 */   public WSOperationRuntimeMBeanImpl() { throw new AssertionError("Public constructor provided only for JMX compliance."); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WSOperationRuntimeMBeanImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */