package weblogic.webservice.monitoring;

import java.util.ArrayList;
import java.util.Date;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.soap.SOAPException;
import weblogic.management.ManagementException;
import weblogic.management.runtime.RuntimeMBean;
import weblogic.management.runtime.RuntimeMBeanDelegate;
import weblogic.management.runtime.WebServiceHandlerRuntimeMBean;
import weblogic.management.runtime.WebServiceOperationRuntimeMBean;
import weblogic.utils.AssertionError;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.Operation;

public final class WSOperationRuntimeMBeanImpl extends RuntimeMBeanDelegate implements WebServiceOperationRuntimeMBean, OperationStats {
  private InvocationHandler mInvocationHandler;
  
  private Operation mOp;
  
  private WSHandlerRuntimeMBeanImpl[] mUserHandlers = null;
  
  private WSHandlerRuntimeMBeanImpl[] mAllHandlers = null;
  
  private WSHandlerRuntimeMBeanImpl mInvocationHandlerMBean = null;
  
  private Date mLastResetTime = null;
  
  private int mDispatchCount = 0;
  
  private long mDispatchTimeTotal = 0L;
  
  private long mDispatchTimeHigh = 0L;
  
  private long mDispatchTimeLow = 0L;
  
  private int mExecutionCount = 0;
  
  private long mExecutionTimeTotal = 0L;
  
  private long mExecutionTimeHigh = 0L;
  
  private long mExecutionTimeLow = 0L;
  
  private int mResponseCount = 0;
  
  private long mResponseTimeTotal = 0L;
  
  private long mResponseTimeHigh = 0L;
  
  private long mResponseTimeLow = 0L;
  
  private int mResponseErrorCount = 0;
  
  private SOAPException mLastResponseError = null;
  
  WSOperationRuntimeMBeanImpl(Operation paramOperation, String paramString, RuntimeMBean paramRuntimeMBean) throws ManagementException {
    super(paramString, paramRuntimeMBean);
    this.mOp = paramOperation;
    this.mInvocationHandler = paramOperation.getInvocationHandler();
    initHandlers(paramOperation);
  }
  
  public String getOperationName() { return this.mOp.getName(); }
  
  public int getComponentType() { return this.mInvocationHandler.getType(); }
  
  public String getComponentInfo() { return this.mInvocationHandler.getInfo(); }
  
  public WebServiceHandlerRuntimeMBean[] getHandlers() { return this.mUserHandlers; }
  
  public WebServiceHandlerRuntimeMBean[] getAllHandlers() { return this.mAllHandlers; }
  
  public WebServiceHandlerRuntimeMBean getInvocationHandler() { return this.mInvocationHandlerMBean; }
  
  public int getInvocationCount() { return this.mDispatchCount; }
  
  public long getDispatchTimeTotal() { return this.mDispatchTimeTotal; }
  
  public long getDispatchTimeHigh() { return this.mDispatchTimeHigh; }
  
  public long getDispatchTimeLow() { return this.mDispatchTimeLow; }
  
  public long getDispatchTimeAverage() { return (this.mDispatchCount == 0) ? 0L : (this.mDispatchTimeTotal / this.mDispatchCount); }
  
  public long getExecutionTimeTotal() { return this.mExecutionTimeTotal; }
  
  public long getExecutionTimeHigh() { return this.mExecutionTimeHigh; }
  
  public long getExecutionTimeLow() { return this.mExecutionTimeLow; }
  
  public long getExecutionTimeAverage() { return (this.mExecutionCount == 0) ? 0L : (this.mExecutionTimeTotal / this.mExecutionCount); }
  
  public int getResponseCount() { return this.mResponseCount; }
  
  public long getResponseTimeTotal() { return this.mResponseTimeTotal; }
  
  public long getResponseTimeHigh() { return this.mResponseTimeHigh; }
  
  public long getResponseTimeLow() { return this.mResponseTimeLow; }
  
  public long getResponseTimeAverage() { return (this.mResponseCount == 0) ? 0L : (this.mResponseTimeTotal / this.mResponseCount); }
  
  public int getResponseErrorCount() { return this.mResponseErrorCount; }
  
  public SOAPException getLastResponseError() { return this.mLastResponseError; }
  
  public void reset() {
    synchronized (this) {
      this.mLastResetTime = new Date();
      this.mExecutionCount = 0;
      this.mDispatchTimeTotal = 0L;
      this.mDispatchTimeHigh = 0L;
      this.mDispatchTimeLow = 0L;
      this.mExecutionTimeTotal = 0L;
      this.mExecutionTimeHigh = 0L;
      this.mExecutionTimeLow = 0L;
    } 
  }
  
  public Date getLastResetTime() { return this.mLastResetTime; }
  
  public void reportInvocation(long paramLong1, long paramLong2, long paramLong3) {
    synchronized (this) {
      unsync_reportDispatch(paramLong1);
      unsync_reportExecution(paramLong2);
      unsync_reportResponse(paramLong3);
    } 
  }
  
  public void reportDispatch(long paramLong) {
    synchronized (this) {
      unsync_reportDispatch(paramLong);
    } 
  }
  
  public void reportExecution(long paramLong) {
    synchronized (this) {
      unsync_reportExecution(paramLong);
    } 
  }
  
  public void reportResponse(long paramLong) {
    synchronized (this) {
      unsync_reportResponse(paramLong);
    } 
  }
  
  public void reportResponseError(SOAPException paramSOAPException) {
    synchronized (this) {
      this.mResponseErrorCount++;
      this.mLastResponseError = paramSOAPException;
    } 
  }
  
  public HandlerStats[] getHandlerStats() { return this.mAllHandlers; }
  
  private void unsync_reportResponse(long paramLong) {
    if (paramLong >= 0L)
      if (this.mResponseCount == 0) {
        this.mResponseTimeTotal = paramLong;
        this.mResponseTimeHigh = paramLong;
        this.mResponseTimeLow = paramLong;
        this.mResponseCount = 1;
      } else {
        this.mResponseCount++;
        this.mResponseTimeTotal += paramLong;
        if (paramLong > this.mResponseTimeHigh)
          this.mResponseTimeHigh = paramLong; 
        if (paramLong < this.mResponseTimeLow)
          this.mResponseTimeLow = paramLong; 
      }  
  }
  
  private void unsync_reportExecution(long paramLong) {
    if (paramLong >= 0L)
      if (this.mExecutionCount == 0) {
        this.mExecutionTimeTotal = paramLong;
        this.mExecutionTimeHigh = paramLong;
        this.mExecutionTimeLow = paramLong;
        this.mExecutionCount = 1;
      } else {
        this.mExecutionCount++;
        this.mExecutionTimeTotal += paramLong;
        if (paramLong > this.mExecutionTimeHigh)
          this.mExecutionTimeHigh = paramLong; 
        if (paramLong < this.mExecutionTimeLow)
          this.mExecutionTimeLow = paramLong; 
      }  
  }
  
  private void unsync_reportDispatch(long paramLong) {
    if (paramLong >= 0L)
      if (this.mDispatchCount == 0) {
        this.mDispatchTimeTotal = paramLong;
        this.mDispatchTimeHigh = paramLong;
        this.mDispatchTimeLow = paramLong;
        this.mDispatchCount = 1;
      } else {
        this.mDispatchCount++;
        this.mDispatchTimeTotal += paramLong;
        if (paramLong > this.mDispatchTimeHigh)
          this.mDispatchTimeHigh = paramLong; 
        if (paramLong < this.mDispatchTimeLow)
          this.mDispatchTimeLow = paramLong; 
      }  
  }
  
  private void initHandlers(Operation paramOperation) throws ManagementException {
    HandlerInfo[] arrayOfHandlerInfo = paramOperation.getHandlerInfos();
    if (arrayOfHandlerInfo == null || arrayOfHandlerInfo.length == 0) {
      this.mAllHandlers = null;
      this.mUserHandlers = null;
      this.mInvocationHandlerMBean = null;
      return;
    } 
    ArrayList arrayList = new ArrayList();
    this.mAllHandlers = new WSHandlerRuntimeMBeanImpl[arrayOfHandlerInfo.length];
    for (byte b = 0; b < arrayOfHandlerInfo.length; b++) {
      this.mAllHandlers[b] = new WSHandlerRuntimeMBeanImpl(arrayOfHandlerInfo[b], "handler-" + b, this);
      if (!this.mAllHandlers[b].isInternal())
        arrayList.add(this.mAllHandlers[b]); 
    } 
    if (arrayList.size() == 0) {
      this.mUserHandlers = null;
    } else {
      this.mUserHandlers = new WSHandlerRuntimeMBeanImpl[arrayList.size()];
      arrayList.toArray(this.mUserHandlers);
    } 
    this.mInvocationHandlerMBean = this.mAllHandlers[this.mAllHandlers.length - 1];
  }
  
  public WSOperationRuntimeMBeanImpl() { throw new AssertionError("Public constructor provided only for JMX compliance."); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WSOperationRuntimeMBeanImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */