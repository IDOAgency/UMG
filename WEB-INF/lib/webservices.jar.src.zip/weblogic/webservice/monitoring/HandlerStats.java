package weblogic.webservice.monitoring;

import javax.xml.rpc.soap.SOAPFaultException;

public interface HandlerStats {
  void reportInitError(Throwable paramThrowable);
  
  void reportRequestSOAPFault(SOAPFaultException paramSOAPFaultException);
  
  void reportRequestTermination();
  
  void reportRequestError(Throwable paramThrowable);
  
  void reportResponseSOAPFault(SOAPFaultException paramSOAPFaultException);
  
  void reportResponseTermination();
  
  void reportResponseError(Throwable paramThrowable);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\HandlerStats.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */