package weblogic.webservice.monitoring;

import java.security.AccessController;
import weblogic.management.ManagementException;
import weblogic.management.configuration.WebServiceComponentMBean;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.runtime.RuntimeMBean;
import weblogic.management.runtime.RuntimeMBeanDelegate;
import weblogic.management.runtime.WebServiceComponentRuntimeMBean;
import weblogic.management.runtime.WebServiceRuntimeMBean;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.PrivilegedActions;
import weblogic.utils.AssertionError;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceLogger;

public final class WSComponentRuntimeMBeanImpl extends RuntimeMBeanDelegate implements WebServiceComponentRuntimeMBean {
  private static final boolean VERBOSE = false;
  
  private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
  
  private WebServiceRuntimeMBean[] mServiceRuntimes;
  
  public static WSComponentRuntimeMBeanImpl create(WebServiceComponentMBean paramWebServiceComponentMBean, String paramString, RuntimeMBean paramRuntimeMBean, WebServiceMBean[] paramArrayOfWebServiceMBean, WebService[] paramArrayOfWebService) {
    if (paramWebServiceComponentMBean == null)
      throw new IllegalArgumentException("null mbean"); 
    if (paramString == null)
      throw new IllegalArgumentException("null webappContextpath"); 
    if (paramRuntimeMBean == null)
      throw new IllegalArgumentException("null parent"); 
    if (paramArrayOfWebServiceMBean == null)
      throw new IllegalArgumentException("null descriptors"); 
    if (paramArrayOfWebService == null)
      throw new IllegalArgumentException("null services"); 
    try {
      WSComponentRuntimeMBeanImpl wSComponentRuntimeMBeanImpl = new WSComponentRuntimeMBeanImpl(paramWebServiceComponentMBean.getName(), paramRuntimeMBean);
      WebServiceRuntimeMBean[] arrayOfWebServiceRuntimeMBean = new WebServiceRuntimeMBean[paramArrayOfWebService.length];
      for (byte b = 0; b < paramArrayOfWebService.length; b++) {
        WSRuntimeMBeanImpl wSRuntimeMBeanImpl = new WSRuntimeMBeanImpl(paramArrayOfWebService[b], paramArrayOfWebServiceMBean[b].getURI(), paramString, wSComponentRuntimeMBeanImpl);
        arrayOfWebServiceRuntimeMBean[b] = wSRuntimeMBeanImpl;
        paramArrayOfWebService[b].setStats(wSRuntimeMBeanImpl);
      } 
      wSComponentRuntimeMBeanImpl.setWebServiceRuntimes(arrayOfWebServiceRuntimeMBean);
      return wSComponentRuntimeMBeanImpl;
    } catch (Exception exception) {
      WebServiceLogger.logStackTrace(WebServiceLogger.logManagementException(exception.toString()), exception);
      return null;
    } 
  }
  
  public WebServiceRuntimeMBean[] getWebServiceRuntimes() { return this.mServiceRuntimes; }
  
  private void setWebServiceRuntimes(WebServiceRuntimeMBean[] paramArrayOfWebServiceRuntimeMBean) { this.mServiceRuntimes = paramArrayOfWebServiceRuntimeMBean; }
  
  private WSComponentRuntimeMBeanImpl(String paramString, RuntimeMBean paramRuntimeMBean) throws ManagementException { super(paramString, paramRuntimeMBean); }
  
  public WSComponentRuntimeMBeanImpl() throws ManagementException { throw new AssertionError("Public constructor provided only for JMX compliance."); }
  
  public String getModuleId() { return getName(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WSComponentRuntimeMBeanImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */