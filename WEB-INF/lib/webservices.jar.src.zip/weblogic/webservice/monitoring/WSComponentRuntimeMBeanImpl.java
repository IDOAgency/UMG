/*     */ package weblogic.webservice.monitoring;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import weblogic.management.ManagementException;
/*     */ import weblogic.management.configuration.WebServiceComponentMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.runtime.RuntimeMBean;
/*     */ import weblogic.management.runtime.RuntimeMBeanDelegate;
/*     */ import weblogic.management.runtime.WebServiceComponentRuntimeMBean;
/*     */ import weblogic.management.runtime.WebServiceRuntimeMBean;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WSComponentRuntimeMBeanImpl
/*     */   extends RuntimeMBeanDelegate
/*     */   implements WebServiceComponentRuntimeMBean
/*     */ {
/*     */   private static final boolean VERBOSE = false;
/*  50 */   private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WebServiceRuntimeMBean[] mServiceRuntimes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WSComponentRuntimeMBeanImpl create(WebServiceComponentMBean paramWebServiceComponentMBean, String paramString, RuntimeMBean paramRuntimeMBean, WebServiceMBean[] paramArrayOfWebServiceMBean, WebService[] paramArrayOfWebService) {
/*  96 */     if (paramWebServiceComponentMBean == null)
/*  97 */       throw new IllegalArgumentException("null mbean"); 
/*  98 */     if (paramString == null)
/*  99 */       throw new IllegalArgumentException("null webappContextpath"); 
/* 100 */     if (paramRuntimeMBean == null)
/* 101 */       throw new IllegalArgumentException("null parent"); 
/* 102 */     if (paramArrayOfWebServiceMBean == null)
/* 103 */       throw new IllegalArgumentException("null descriptors"); 
/* 104 */     if (paramArrayOfWebService == null)
/* 105 */       throw new IllegalArgumentException("null services"); 
/*     */     try {
/* 107 */       WSComponentRuntimeMBeanImpl wSComponentRuntimeMBeanImpl = new WSComponentRuntimeMBeanImpl(paramWebServiceComponentMBean.getName(), paramRuntimeMBean);
/*     */ 
/*     */       
/* 110 */       WebServiceRuntimeMBean[] arrayOfWebServiceRuntimeMBean = new WebServiceRuntimeMBean[paramArrayOfWebService.length];
/*     */       
/* 112 */       for (byte b = 0; b < paramArrayOfWebService.length; b++) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 117 */         WSRuntimeMBeanImpl wSRuntimeMBeanImpl = new WSRuntimeMBeanImpl(paramArrayOfWebService[b], paramArrayOfWebServiceMBean[b].getURI(), paramString, wSComponentRuntimeMBeanImpl);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 122 */         arrayOfWebServiceRuntimeMBean[b] = wSRuntimeMBeanImpl;
/* 123 */         paramArrayOfWebService[b].setStats(wSRuntimeMBeanImpl);
/*     */       } 
/*     */       
/* 126 */       wSComponentRuntimeMBeanImpl.setWebServiceRuntimes(arrayOfWebServiceRuntimeMBean);
/* 127 */       return wSComponentRuntimeMBeanImpl;
/* 128 */     } catch (Exception exception) {
/*     */       
/* 130 */       WebServiceLogger.logStackTrace(WebServiceLogger.logManagementException(exception.toString()), exception);
/*     */       
/* 132 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public WebServiceRuntimeMBean[] getWebServiceRuntimes() { return this.mServiceRuntimes; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   private void setWebServiceRuntimes(WebServiceRuntimeMBean[] paramArrayOfWebServiceRuntimeMBean) { this.mServiceRuntimes = paramArrayOfWebServiceRuntimeMBean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   private WSComponentRuntimeMBeanImpl(String paramString, RuntimeMBean paramRuntimeMBean) throws ManagementException { super(paramString, paramRuntimeMBean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public WSComponentRuntimeMBeanImpl() throws ManagementException { throw new AssertionError("Public constructor provided only for JMX compliance."); }
/*     */ 
/*     */ 
/*     */   
/* 175 */   public String getModuleId() { return getName(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WSComponentRuntimeMBeanImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */