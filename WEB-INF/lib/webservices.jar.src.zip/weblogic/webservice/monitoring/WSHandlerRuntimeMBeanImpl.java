package weblogic.webservice.monitoring;

import java.util.Collections;
import java.util.Date;
import java.util.Map;
import javax.xml.namespace.QName;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.soap.SOAPFaultException;
import weblogic.management.ManagementException;
import weblogic.management.runtime.RuntimeMBean;
import weblogic.management.runtime.RuntimeMBeanDelegate;
import weblogic.management.runtime.WebServiceHandlerRuntimeMBean;
import weblogic.utils.AssertionError;

public final class WSHandlerRuntimeMBeanImpl extends RuntimeMBeanDelegate implements WebServiceHandlerRuntimeMBean, HandlerStats {
  private Throwable mInitError = null;
  
  private Throwable mLastRequestError = null;
  
  private Throwable mLastResponseError = null;
  
  private SOAPFaultException mLastRequestSoapFault = null;
  
  private SOAPFaultException mLastResponseSoapFault = null;
  
  private HandlerInfo mHandlerInfo;
  
  private int mRequestSoapFaultsCount = 0;
  
  private int mRequestTerminationsCount = 0;
  
  private int mRequestErrorsCount = 0;
  
  private int mResponseSoapFaultsCount = 0;
  
  private int mResponseTerminationsCount = 0;
  
  private int mResponseErrorsCount = 0;
  
  private Date mLastResetTime = null;
  
  private boolean mIsInternal;
  
  WSHandlerRuntimeMBeanImpl(HandlerInfo paramHandlerInfo, String paramString, RuntimeMBean paramRuntimeMBean) throws ManagementException {
    super(paramString, paramRuntimeMBean);
    this.mHandlerInfo = paramHandlerInfo;
    this.mIsInternal = paramHandlerInfo.getHandlerClass().getName().startsWith("weblogic.webservice");
  }
  
  public boolean isInternal() { return this.mIsInternal; }
  
  public Class getHandlerClass() { return this.mHandlerInfo.getHandlerClass(); }
  
  public Map getHandlerConfig() { return (this.mHandlerInfo.getHandlerConfig() == null) ? null : Collections.unmodifiableMap(this.mHandlerInfo.getHandlerConfig()); }
  
  public QName[] getHeaders() { return this.mHandlerInfo.getHeaders(); }
  
  public int getRequestSOAPFaultsCount() { return this.mRequestSoapFaultsCount; }
  
  public int getRequestTerminationsCount() { return this.mRequestTerminationsCount; }
  
  public int getRequestErrorsCount() { return this.mRequestErrorsCount; }
  
  public int getResponseSOAPFaultsCount() { return this.mResponseSoapFaultsCount; }
  
  public int getResponseTerminationsCount() { return this.mResponseTerminationsCount; }
  
  public int getResponseErrorsCount() { return this.mResponseErrorsCount; }
  
  public void reset() {
    synchronized (this) {
      this.mLastResetTime = new Date();
      this.mRequestSoapFaultsCount = 0;
      this.mRequestTerminationsCount = 0;
      this.mRequestErrorsCount = 0;
      this.mResponseTerminationsCount = 0;
      this.mResponseErrorsCount = 0;
      this.mLastRequestSoapFault = null;
      this.mLastResponseSoapFault = null;
      this.mLastRequestError = null;
      this.mLastResponseError = null;
    } 
  }
  
  public Date getLastResetTime() { return this.mLastResetTime; }
  
  public Throwable getInitError() { return this.mInitError; }
  
  public SOAPFaultException getLastRequestSOAPFault() { return this.mLastRequestSoapFault; }
  
  public SOAPFaultException getLastResponseSOAPFault() { return this.mLastResponseSoapFault; }
  
  public Throwable getLastRequestError() { return this.mLastRequestError; }
  
  public Throwable getLastResponseError() { return this.mLastResponseError; }
  
  public void reportRequestSOAPFault(SOAPFaultException paramSOAPFaultException) {
    synchronized (this) {
      this.mRequestSoapFaultsCount++;
      this.mLastRequestSoapFault = paramSOAPFaultException;
    } 
  }
  
  public void reportRequestTermination() {
    synchronized (this) {
      this.mRequestTerminationsCount++;
    } 
  }
  
  public void reportRequestError(Throwable paramThrowable) {
    synchronized (this) {
      this.mRequestErrorsCount++;
      this.mLastRequestError = paramThrowable;
    } 
  }
  
  public void reportResponseSOAPFault(SOAPFaultException paramSOAPFaultException) {
    synchronized (this) {
      this.mResponseSoapFaultsCount++;
      this.mLastResponseSoapFault = paramSOAPFaultException;
    } 
  }
  
  public void reportResponseTermination() {
    synchronized (this) {
      this.mResponseTerminationsCount++;
    } 
  }
  
  public void reportResponseError(Throwable paramThrowable) {
    synchronized (this) {
      this.mResponseErrorsCount++;
      this.mLastResponseError = paramThrowable;
    } 
  }
  
  public void reportInitError(Throwable paramThrowable) { this.mInitError = paramThrowable; }
  
  public WSHandlerRuntimeMBeanImpl() { throw new AssertionError("Public constructor provided only for JMX compliance."); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WSHandlerRuntimeMBeanImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */