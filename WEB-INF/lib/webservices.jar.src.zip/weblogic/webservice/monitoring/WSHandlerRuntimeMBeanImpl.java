/*     */ package weblogic.webservice.monitoring;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import weblogic.management.ManagementException;
/*     */ import weblogic.management.runtime.RuntimeMBean;
/*     */ import weblogic.management.runtime.RuntimeMBeanDelegate;
/*     */ import weblogic.management.runtime.WebServiceHandlerRuntimeMBean;
/*     */ import weblogic.utils.AssertionError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WSHandlerRuntimeMBeanImpl
/*     */   extends RuntimeMBeanDelegate
/*     */   implements WebServiceHandlerRuntimeMBean, HandlerStats
/*     */ {
/*  36 */   private Throwable mInitError = null;
/*  37 */   private Throwable mLastRequestError = null;
/*  38 */   private Throwable mLastResponseError = null;
/*  39 */   private SOAPFaultException mLastRequestSoapFault = null;
/*  40 */   private SOAPFaultException mLastResponseSoapFault = null;
/*     */   private HandlerInfo mHandlerInfo;
/*  42 */   private int mRequestSoapFaultsCount = 0;
/*  43 */   private int mRequestTerminationsCount = 0;
/*  44 */   private int mRequestErrorsCount = 0;
/*  45 */   private int mResponseSoapFaultsCount = 0;
/*  46 */   private int mResponseTerminationsCount = 0;
/*  47 */   private int mResponseErrorsCount = 0;
/*  48 */   private Date mLastResetTime = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mIsInternal;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WSHandlerRuntimeMBeanImpl(HandlerInfo paramHandlerInfo, String paramString, RuntimeMBean paramRuntimeMBean) throws ManagementException {
/*  59 */     super(paramString, paramRuntimeMBean);
/*  60 */     this.mHandlerInfo = paramHandlerInfo;
/*     */     
/*  62 */     this.mIsInternal = paramHandlerInfo.getHandlerClass().getName().startsWith("weblogic.webservice");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public boolean isInternal() { return this.mIsInternal; }
/*     */   
/*  71 */   public Class getHandlerClass() { return this.mHandlerInfo.getHandlerClass(); }
/*     */ 
/*     */   
/*  74 */   public Map getHandlerConfig() { return (this.mHandlerInfo.getHandlerConfig() == null) ? null : Collections.unmodifiableMap(this.mHandlerInfo.getHandlerConfig()); }
/*     */ 
/*     */ 
/*     */   
/*  78 */   public QName[] getHeaders() { return this.mHandlerInfo.getHeaders(); }
/*     */   
/*  80 */   public int getRequestSOAPFaultsCount() { return this.mRequestSoapFaultsCount; }
/*     */ 
/*     */   
/*  83 */   public int getRequestTerminationsCount() { return this.mRequestTerminationsCount; }
/*     */ 
/*     */   
/*  86 */   public int getRequestErrorsCount() { return this.mRequestErrorsCount; }
/*     */ 
/*     */   
/*  89 */   public int getResponseSOAPFaultsCount() { return this.mResponseSoapFaultsCount; }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public int getResponseTerminationsCount() { return this.mResponseTerminationsCount; }
/*     */ 
/*     */   
/*  96 */   public int getResponseErrorsCount() { return this.mResponseErrorsCount; }
/*     */   
/*     */   public void reset() {
/*  99 */     synchronized (this) {
/* 100 */       this.mLastResetTime = new Date();
/* 101 */       this.mRequestSoapFaultsCount = 0;
/* 102 */       this.mRequestTerminationsCount = 0;
/* 103 */       this.mRequestErrorsCount = 0;
/* 104 */       this.mResponseTerminationsCount = 0;
/* 105 */       this.mResponseErrorsCount = 0;
/* 106 */       this.mLastRequestSoapFault = null;
/* 107 */       this.mLastResponseSoapFault = null;
/* 108 */       this.mLastRequestError = null;
/* 109 */       this.mLastResponseError = null;
/*     */     } 
/*     */   }
/*     */   
/* 113 */   public Date getLastResetTime() { return this.mLastResetTime; }
/*     */   
/* 115 */   public Throwable getInitError() { return this.mInitError; }
/*     */ 
/*     */   
/* 118 */   public SOAPFaultException getLastRequestSOAPFault() { return this.mLastRequestSoapFault; }
/*     */ 
/*     */ 
/*     */   
/* 122 */   public SOAPFaultException getLastResponseSOAPFault() { return this.mLastResponseSoapFault; }
/*     */ 
/*     */ 
/*     */   
/* 126 */   public Throwable getLastRequestError() { return this.mLastRequestError; }
/*     */ 
/*     */ 
/*     */   
/* 130 */   public Throwable getLastResponseError() { return this.mLastResponseError; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportRequestSOAPFault(SOAPFaultException paramSOAPFaultException) {
/* 137 */     synchronized (this) {
/* 138 */       this.mRequestSoapFaultsCount++;
/* 139 */       this.mLastRequestSoapFault = paramSOAPFaultException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportRequestTermination() {
/* 144 */     synchronized (this) {
/* 145 */       this.mRequestTerminationsCount++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportRequestError(Throwable paramThrowable) {
/* 150 */     synchronized (this) {
/* 151 */       this.mRequestErrorsCount++;
/* 152 */       this.mLastRequestError = paramThrowable;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportResponseSOAPFault(SOAPFaultException paramSOAPFaultException) {
/* 157 */     synchronized (this) {
/* 158 */       this.mResponseSoapFaultsCount++;
/* 159 */       this.mLastResponseSoapFault = paramSOAPFaultException;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportResponseTermination() {
/* 164 */     synchronized (this) {
/* 165 */       this.mResponseTerminationsCount++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reportResponseError(Throwable paramThrowable) {
/* 170 */     synchronized (this) {
/* 171 */       this.mResponseErrorsCount++;
/* 172 */       this.mLastResponseError = paramThrowable;
/*     */     } 
/*     */   }
/*     */   
/* 176 */   public void reportInitError(Throwable paramThrowable) { this.mInitError = paramThrowable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public WSHandlerRuntimeMBeanImpl() { throw new AssertionError("Public constructor provided only for JMX compliance."); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WSHandlerRuntimeMBeanImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */