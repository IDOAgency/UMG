package weblogic.webservice.monitoring;

import javax.xml.soap.SOAPException;

public interface WebServiceStats {
  void reportWSDLHit();
  
  void reportHomePageHit();
  
  void reportMalformedRequest(SOAPException paramSOAPException);
  
  HandlerStats[] getHandlerStats();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\monitoring\WebServiceStats.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */