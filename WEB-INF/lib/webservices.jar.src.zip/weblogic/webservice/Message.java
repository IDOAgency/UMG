package weblogic.webservice;

import java.util.Iterator;
import java.util.Map;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.webservice.context.WebServiceContext;

public interface Message {
  public static final int LITERAL = 0;
  
  public static final int ENCODED = 1;
  
  String getName();
  
  void setName(String paramString);
  
  String getNamespace();
  
  void setNamespace(String paramString);
  
  boolean isVoid();
  
  boolean isMultiPart();
  
  boolean isSinglePart();
  
  String getEncodingStyle();
  
  void setEncodingStyle(String paramString);
  
  String getSecuritySpecRef();
  
  void setSecuritySpecRef(String paramString);
  
  boolean isLiteral();
  
  void useLiteral();
  
  boolean isEncoded();
  
  void useEncoded();
  
  boolean getContainsAttachment();
  
  void setContainsAttachment(boolean paramBoolean);
  
  Object[] getSortedParameters(Map paramMap);
  
  Part getPart(String paramString);
  
  Part addPart(String paramString1, String paramString2, String paramString3, Class paramClass);
  
  Iterator getParts();
  
  Part[] getParts(PartFilter paramPartFilter);
  
  void toXML(SOAPMessage paramSOAPMessage, Object[] paramArrayOfObject, WebServiceContext paramWebServiceContext) throws SOAPException;
  
  Object toJava(Map paramMap, SOAPMessage paramSOAPMessage, WebServiceContext paramWebServiceContext) throws SOAPException;
  
  TypeMappingRegistry getTypeMappingRegistry();
  
  void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry);
  
  Part addPart(String paramString1, String paramString2, String paramString3);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\Message.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */