/*     */ package weblogic.webservice.server.smtp;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import weblogic.utils.compiler.Tool;
/*     */ import weblogic.utils.compiler.ToolFailureException;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SMTPGateway
/*     */   extends Tool
/*     */ {
/*     */   private ServerSocket serverSocket;
/*  30 */   private MailQ mailQ = new MailQ();
/*  31 */   private SOAPDispatcher dispatcher = new SOAPDispatcher();
/*  32 */   private int workerThreads = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SMTPGateway(String[] paramArrayOfString) throws IOException {
/*  39 */     super(paramArrayOfString);
/*  40 */     fillInOptions();
/*     */   }
/*     */ 
/*     */   
/*     */   public void prepare() {}
/*     */ 
/*     */   
/*     */   public void runBody() {
/*  48 */     int i = this.opts.getIntegerOption("port", 25);
/*     */     
/*     */     try {
/*  51 */       this.serverSocket = new ServerSocket(i);
/*  52 */       System.out.println("SMTPGateway started at port:" + i);
/*  53 */       startDispatchThreads();
/*  54 */       acceptConnection();
/*  55 */     } catch (IOException iOException) {
/*  56 */       logErrorMessage("Failed to create Server Socket", iOException);
/*  57 */       throw new ToolFailureException("got an IOException");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void startDispatchThreads() {
/*  63 */     for (byte b = 0; b < this.workerThreads; b++) {
/*     */       
/*  65 */       (new Thread() { private final SMTPGateway this$0;
/*     */           public void run() {
/*     */             while (true) {
/*  68 */               MailMessage mailMessage = SMTPGateway.this.mailQ.next();
/*  69 */               SMTPGateway.this.dispatcher.dispatch(mailMessage);
/*     */             } 
/*     */           } }
/*     */         ).start();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void acceptConnection() {
/*     */     while (true) {
/*  79 */       final Socket socket = this.serverSocket.accept();
/*     */ 
/*     */       
/*     */       try {
/*  83 */         (new Thread() { private final Socket val$socket;
/*     */             
/*  85 */             public void run() { SMTPGateway.this.processConnection(socket); }
/*     */             
/*     */             private final SMTPGateway this$0; }
/*     */           ).run();
/*  89 */       } catch (Exception exception) {
/*  90 */         logErrorMessage("Error processing SMTP connection", exception);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void logErrorMessage(String paramString, Throwable paramThrowable) {
/*  96 */     System.err.println("SMTP Gateway Error:");
/*  97 */     System.err.println(paramString);
/*  98 */     String str = WebServiceLogger.logSMTPGatewayError();
/*  99 */     WebServiceLogger.logStackTrace(str, paramThrowable);
/* 100 */     System.err.println();
/*     */   }
/*     */ 
/*     */   
/*     */   private void processConnection(Socket paramSocket) {
/*     */     try {
/* 106 */       handleConnection(paramSocket);
/* 107 */     } catch (Throwable throwable) {
/* 108 */       logErrorMessage("Failed to handle SMTP connection", throwable);
/*     */     } finally {
/*     */       
/*     */       try {
/* 112 */         paramSocket.close();
/* 113 */       } catch (IOException iOException) {
/* 114 */         logErrorMessage("Failed to close SMTP connection", iOException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleConnection(Socket paramSocket) {
/* 120 */     InputStream inputStream = paramSocket.getInputStream();
/* 121 */     OutputStream outputStream = paramSocket.getOutputStream();
/*     */     
/* 123 */     PrintWriter printWriter = new PrintWriter(outputStream);
/* 124 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
/*     */     
/* 126 */     new SMTPConnection(bufferedReader, printWriter, this.mailQ);
/*     */   }
/*     */ 
/*     */   
/*     */   private void write(PrintWriter paramPrintWriter, String paramString) {
/* 131 */     paramPrintWriter.println(paramString);
/* 132 */     paramPrintWriter.flush();
/*     */   }
/*     */   
/*     */   private void fillInOptions() {
/* 136 */     this.opts.setUsageArgs("<options>");
/* 137 */     this.opts.addOption("port", "port", "SMTP Gateway port");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 142 */   public static void main(String[] paramArrayOfString) throws IOException { (new SMTPGateway(paramArrayOfString)).run(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\SMTPGateway.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */