package weblogic.webservice.server.smtp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import weblogic.utils.compiler.Tool;
import weblogic.utils.compiler.ToolFailureException;
import weblogic.webservice.WebServiceLogger;

public class SMTPGateway extends Tool {
  private ServerSocket serverSocket;
  
  private MailQ mailQ = new MailQ();
  
  private SOAPDispatcher dispatcher = new SOAPDispatcher();
  
  private int workerThreads = 2;
  
  public SMTPGateway(String[] paramArrayOfString) throws IOException {
    super(paramArrayOfString);
    fillInOptions();
  }
  
  public void prepare() {}
  
  public void runBody() {
    int i = this.opts.getIntegerOption("port", 25);
    try {
      this.serverSocket = new ServerSocket(i);
      System.out.println("SMTPGateway started at port:" + i);
      startDispatchThreads();
      acceptConnection();
    } catch (IOException iOException) {
      logErrorMessage("Failed to create Server Socket", iOException);
      throw new ToolFailureException("got an IOException");
    } 
  }
  
  private void startDispatchThreads() {
    for (byte b = 0; b < this.workerThreads; b++) {
      (new Thread() {
          private final SMTPGateway this$0;
          
          public void run() {
            while (true) {
              MailMessage mailMessage = SMTPGateway.this.mailQ.next();
              SMTPGateway.this.dispatcher.dispatch(mailMessage);
            } 
          }
        }).start();
    } 
  }
  
  private void acceptConnection() {
    while (true) {
      final Socket socket = this.serverSocket.accept();
      try {
        (new Thread() {
            private final Socket val$socket;
            
            private final SMTPGateway this$0;
            
            public void run() { SMTPGateway.this.processConnection(socket); }
          }).run();
      } catch (Exception exception) {
        logErrorMessage("Error processing SMTP connection", exception);
      } 
    } 
  }
  
  private void logErrorMessage(String paramString, Throwable paramThrowable) {
    System.err.println("SMTP Gateway Error:");
    System.err.println(paramString);
    String str = WebServiceLogger.logSMTPGatewayError();
    WebServiceLogger.logStackTrace(str, paramThrowable);
    System.err.println();
  }
  
  private void processConnection(Socket paramSocket) {
    try {
      handleConnection(paramSocket);
    } catch (Throwable throwable) {
      logErrorMessage("Failed to handle SMTP connection", throwable);
    } finally {
      try {
        paramSocket.close();
      } catch (IOException iOException) {
        logErrorMessage("Failed to close SMTP connection", iOException);
      } 
    } 
  }
  
  private void handleConnection(Socket paramSocket) {
    InputStream inputStream = paramSocket.getInputStream();
    OutputStream outputStream = paramSocket.getOutputStream();
    PrintWriter printWriter = new PrintWriter(outputStream);
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
    new SMTPConnection(bufferedReader, printWriter, this.mailQ);
  }
  
  private void write(PrintWriter paramPrintWriter, String paramString) {
    paramPrintWriter.println(paramString);
    paramPrintWriter.flush();
  }
  
  private void fillInOptions() {
    this.opts.setUsageArgs("<options>");
    this.opts.addOption("port", "port", "SMTP Gateway port");
  }
  
  public static void main(String[] paramArrayOfString) throws IOException { (new SMTPGateway(paramArrayOfString)).run(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\SMTPGateway.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */