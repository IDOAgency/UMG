package weblogic.webservice.server.smtp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

abstract class SMTPCommand {
  public abstract void process(StringTokenizer paramStringTokenizer, BufferedReader paramBufferedReader, PrintWriter paramPrintWriter) throws IOException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\SMTPCommand.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */