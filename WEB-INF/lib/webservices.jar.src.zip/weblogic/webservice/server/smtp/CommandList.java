/*    */ package weblogic.webservice.server.smtp;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandList
/*    */ {
/* 13 */   private HashMap commands = new HashMap();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 25 */   public void add(String paramString, SMTPCommand paramSMTPCommand) { this.commands.put(new Key(paramString), paramSMTPCommand); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   public SMTPCommand get(String paramString) { return (SMTPCommand)this.commands.get(new Key(paramString)); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static final class Key
/*    */   {
/*    */     private String key;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     Key(String param1String) {
/* 50 */       if (param1String == null) {
/* 51 */         throw new IllegalArgumentException("key can not be null");
/*    */       }
/*    */       
/* 54 */       this.key = param1String;
/*    */     }
/*    */ 
/*    */     
/* 58 */     public String toString() { return this.key; }
/*    */ 
/*    */ 
/*    */     
/*    */     public boolean equals(Object param1Object) {
/* 63 */       if (param1Object == null) {
/* 64 */         return false;
/*    */       }
/*    */       
/* 67 */       if (param1Object instanceof String) {
/* 68 */         return this.key.equalsIgnoreCase((String)param1Object);
/*    */       }
/*    */       
/* 71 */       if (param1Object instanceof Key) {
/* 72 */         return this.key.equalsIgnoreCase(((Key)param1Object).key);
/*    */       }
/*    */       
/* 75 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 79 */     public int hashCode() { return this.key.hashCode(); }
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\CommandList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */