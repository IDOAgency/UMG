package weblogic.webservice.server.smtp;

import java.util.HashMap;

public class CommandList {
  private HashMap commands = new HashMap();
  
  public void add(String paramString, SMTPCommand paramSMTPCommand) { this.commands.put(new Key(paramString), paramSMTPCommand); }
  
  public SMTPCommand get(String paramString) { return (SMTPCommand)this.commands.get(new Key(paramString)); }
  
  static final class Key {
    private String key;
    
    Key(String param1String) {
      if (param1String == null)
        throw new IllegalArgumentException("key can not be null"); 
      this.key = param1String;
    }
    
    public String toString() { return this.key; }
    
    public boolean equals(Object param1Object) {
      if (param1Object == null)
        return false; 
      if (param1Object instanceof String)
        return this.key.equalsIgnoreCase((String)param1Object); 
      if (param1Object instanceof Key)
        return this.key.equalsIgnoreCase(((Key)param1Object).key); 
      return false;
    }
    
    public int hashCode() { return this.key.hashCode(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\CommandList.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */