package weblogic.webservice.server.smtp;

import java.io.Serializable;

public class MailMessage implements Serializable {
  private String from;
  
  private String to;
  
  private String data;
  
  public String getFrom() { return this.from; }
  
  public void setFrom(String paramString) { this.from = paramString; }
  
  public String getTo() { return this.to; }
  
  public void setTo(String paramString) { this.to = paramString; }
  
  public String getData() { return this.data; }
  
  public void setData(String paramString) { this.data = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\MailMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */