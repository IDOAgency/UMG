/*    */ package weblogic.webservice.server.smtp;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MailMessage
/*    */   implements Serializable
/*    */ {
/*    */   private String from;
/*    */   private String to;
/*    */   private String data;
/*    */   
/* 18 */   public String getFrom() { return this.from; }
/*    */ 
/*    */ 
/*    */   
/* 22 */   public void setFrom(String paramString) { this.from = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public String getTo() { return this.to; }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public void setTo(String paramString) { this.to = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 34 */   public String getData() { return this.data; }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public void setData(String paramString) { this.data = paramString; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\MailMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */