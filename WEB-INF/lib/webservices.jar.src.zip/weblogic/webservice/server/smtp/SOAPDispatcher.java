package weblogic.webservice.server.smtp;

public class SOAPDispatcher {
  public void dispatch(MailMessage paramMailMessage) { System.out.println("(**):dispatch called with " + paramMailMessage); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\SOAPDispatcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */