package weblogic.webservice.server.smtp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.StringTokenizer;
import weblogic.webservice.WebServiceLogger;

public class SMTPConnection {
  private static String TITLE = "Weblogic SMTP SOAP Gateway";
  
  private static String SERVICE_READY = "220";
  
  private static String OK = "250";
  
  private static String SYNTAX_ERROR = "500";
  
  private boolean done;
  
  private CommandList commands;
  
  private String host;
  
  private MailMessage mail;
  
  private MailQ mailQ;
  
  SMTPConnection(BufferedReader paramBufferedReader, PrintWriter paramPrintWriter, MailQ paramMailQ) throws IOException {
    this.done = false;
    this.mailQ = paramMailQ;
    this.commands = getCommandList();
    sayGreeting(paramPrintWriter);
    processCommands(paramBufferedReader, paramPrintWriter);
  }
  
  private CommandList getCommandList() {
    CommandList commandList = new CommandList();
    commandList.add("MAIL", new MailCommand(null));
    commandList.add("HELO", new HelloCommand(null));
    commandList.add("QUIT", new QuitCommand(null));
    commandList.add("DATA", new DataCommand(null));
    commandList.add("RCPT", new RecipientCommand(null));
    return commandList;
  }
  
  private void processCommands(BufferedReader paramBufferedReader, PrintWriter paramPrintWriter) throws IOException { do {
      String str = paramBufferedReader.readLine();
      System.out.println("(**):line" + str);
      StringTokenizer stringTokenizer = new StringTokenizer(str);
      if (stringTokenizer.hasMoreTokens()) {
        SMTPCommand sMTPCommand = this.commands.get(stringTokenizer.nextToken());
        if (sMTPCommand == null) {
          sendError(paramPrintWriter);
        } else {
          sMTPCommand.process(stringTokenizer, paramBufferedReader, paramPrintWriter);
        } 
      } else {
        sendError(paramPrintWriter);
      } 
    } while (!this.done); }
  
  private class HelloCommand extends SMTPCommand {
    private final SMTPConnection this$0;
    
    private HelloCommand() {}
    
    public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) { SMTPConnection.this.println(param1PrintWriter, OK + " " + SMTPConnection.this.getHost()); }
  }
  
  private class QuitCommand extends SMTPCommand {
    private final SMTPConnection this$0;
    
    private QuitCommand() {}
    
    public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) {
      SMTPConnection.this.println(param1PrintWriter, "221 " + SMTPConnection.this.getHost() + " Service closing transmission channel");
      SMTPConnection.this.done = true;
      try {
        param1BufferedReader.close();
        param1PrintWriter.close();
      } catch (IOException iOException) {
        String str = WebServiceLogger.logSMTPquitCommandIOException();
        WebServiceLogger.logStackTrace(str, iOException);
      } 
    }
  }
  
  private class DataCommand extends SMTPCommand {
    private final SMTPConnection this$0;
    
    private DataCommand() {}
    
    public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) {
      String str;
      if (SMTPConnection.this.mail == null) {
        SMTPConnection.this.println(param1PrintWriter, "503 Bad sequence of commands");
        return;
      } 
      SMTPConnection.this.println(param1PrintWriter, "354 send the mail data, end with .");
      StringBuffer stringBuffer = new StringBuffer();
      do {
        try {
          str = param1BufferedReader.readLine();
        } catch (IOException iOException) {
          String str1 = WebServiceLogger.logSMTPprocessReadIOException();
          WebServiceLogger.logStackTrace(str1, iOException);
          try {
            param1BufferedReader.close();
            param1PrintWriter.close();
          } catch (IOException iOException1) {
            String str2 = WebServiceLogger.logSMTPprocessCloseIOException();
            WebServiceLogger.logStackTrace(str2, iOException1);
          } 
          SMTPConnection.this.done = true;
          return;
        } 
        stringBuffer.append(str);
        stringBuffer.append("\n");
      } while (!".".equals(str));
      SMTPConnection.this.mail.setData(stringBuffer.toString());
      SMTPConnection.this.mailQ.add(SMTPConnection.this.mail);
      SMTPConnection.this.println(param1PrintWriter, OK + "  ok");
    }
  }
  
  private class RecipientCommand extends SMTPCommand {
    private final SMTPConnection this$0;
    
    private RecipientCommand() {}
    
    public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) {
      String str;
      if (SMTPConnection.this.mail == null) {
        SMTPConnection.this.println(param1PrintWriter, "503 Bad sequence of commands");
        return;
      } 
      if (param1StringTokenizer.hasMoreTokens()) {
        str = SMTPConnection.this.makeString(param1StringTokenizer);
      } else {
        SMTPConnection.this.println(param1PrintWriter, "501 Syntax error in parameters or arguments");
        return;
      } 
      if (!SMTPConnection.this.startsWithIgnoreCase(str, "TO:")) {
        SMTPConnection.this.println(param1PrintWriter, "501 Syntax error in parameters or arguments");
        return;
      } 
      SMTPConnection.this.mail.setTo(str.substring(3, str.length()));
      SMTPConnection.this.println(param1PrintWriter, OK + "  ok");
    }
  }
  
  private String makeString(StringTokenizer paramStringTokenizer) {
    StringBuffer stringBuffer = new StringBuffer();
    while (paramStringTokenizer.hasMoreTokens())
      stringBuffer.append(paramStringTokenizer.nextToken()); 
    return stringBuffer.toString();
  }
  
  private class MailCommand extends SMTPCommand {
    private final SMTPConnection this$0;
    
    private MailCommand() {}
    
    public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) {
      String str;
      if (SMTPConnection.this.mail != null) {
        SMTPConnection.this.println(param1PrintWriter, "503 Bad sequence of commands");
        return;
      } 
      SMTPConnection.this.mail = new MailMessage();
      if (param1StringTokenizer.hasMoreTokens()) {
        str = SMTPConnection.this.makeString(param1StringTokenizer);
      } else {
        SMTPConnection.this.println(param1PrintWriter, "501 Syntax error in parameters or arguments");
        return;
      } 
      if (!SMTPConnection.this.startsWithIgnoreCase(str, "FROM:")) {
        SMTPConnection.this.println(param1PrintWriter, "501 Syntax error in parameters or arguments");
        return;
      } 
      SMTPConnection.this.mail.setFrom(str.substring(5, str.length()));
      SMTPConnection.this.println(param1PrintWriter, OK + "  ok");
    }
  }
  
  private boolean startsWithIgnoreCase(String paramString1, String paramString2) {
    int i = paramString2.length();
    if (paramString1.length() < i)
      return false; 
    paramString1 = paramString1.substring(0, i);
    return paramString1.equalsIgnoreCase(paramString2);
  }
  
  private void println(PrintWriter paramPrintWriter, String paramString) {
    paramPrintWriter.println(paramString);
    paramPrintWriter.flush();
  }
  
  private void sayGreeting(PrintWriter paramPrintWriter) { println(paramPrintWriter, SERVICE_READY + " " + getHost() + " " + TITLE); }
  
  private void sendError(PrintWriter paramPrintWriter) { println(paramPrintWriter, SYNTAX_ERROR + " Syntax error, command unrecognized"); }
  
  private String getHost() {
    try {
      if (this.host == null)
        this.host = InetAddress.getLocalHost().getHostName(); 
    } catch (UnknownHostException unknownHostException) {
      System.out.println("Failed to get local host name:" + unknownHostException);
      this.host = "localhost";
    } 
    return this.host;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\SMTPConnection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */