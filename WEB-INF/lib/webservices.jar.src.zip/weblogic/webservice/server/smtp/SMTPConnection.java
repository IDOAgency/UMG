/*     */ package weblogic.webservice.server.smtp;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.StringTokenizer;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SMTPConnection
/*     */ {
/*  18 */   private static String TITLE = "Weblogic SMTP SOAP Gateway";
/*  19 */   private static String SERVICE_READY = "220";
/*  20 */   private static String OK = "250";
/*  21 */   private static String SYNTAX_ERROR = "500"; private boolean done; private CommandList commands;
/*     */   SMTPConnection(BufferedReader paramBufferedReader, PrintWriter paramPrintWriter, MailQ paramMailQ) throws IOException {
/*  23 */     this.done = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  33 */     this.mailQ = paramMailQ;
/*  34 */     this.commands = getCommandList();
/*  35 */     sayGreeting(paramPrintWriter);
/*  36 */     processCommands(paramBufferedReader, paramPrintWriter);
/*     */   }
/*     */   private String host; private MailMessage mail; private MailQ mailQ;
/*     */   private CommandList getCommandList() {
/*  40 */     CommandList commandList = new CommandList();
/*     */     
/*  42 */     commandList.add("MAIL", new MailCommand(null));
/*  43 */     commandList.add("HELO", new HelloCommand(null));
/*  44 */     commandList.add("QUIT", new QuitCommand(null));
/*  45 */     commandList.add("DATA", new DataCommand(null));
/*  46 */     commandList.add("RCPT", new RecipientCommand(null));
/*     */     
/*  48 */     return commandList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processCommands(BufferedReader paramBufferedReader, PrintWriter paramPrintWriter) throws IOException { do {
/*  55 */       String str = paramBufferedReader.readLine();
/*  56 */       System.out.println("(**):line" + str);
/*     */       
/*  58 */       StringTokenizer stringTokenizer = new StringTokenizer(str);
/*     */       
/*  60 */       if (stringTokenizer.hasMoreTokens()) {
/*  61 */         SMTPCommand sMTPCommand = this.commands.get(stringTokenizer.nextToken());
/*     */         
/*  63 */         if (sMTPCommand == null) {
/*  64 */           sendError(paramPrintWriter);
/*     */         }
/*     */         else {
/*     */           
/*  68 */           sMTPCommand.process(stringTokenizer, paramBufferedReader, paramPrintWriter);
/*     */         } 
/*     */       } else {
/*  71 */         sendError(paramPrintWriter);
/*     */       }
/*     */     
/*  74 */     } while (!this.done); }
/*     */   
/*     */   private class HelloCommand
/*     */     extends SMTPCommand {
/*     */     private final SMTPConnection this$0;
/*     */     
/*     */     private HelloCommand() {}
/*     */     
/*  82 */     public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) { SMTPConnection.this.println(param1PrintWriter, OK + " " + SMTPConnection.this.getHost()); }
/*     */   }
/*     */   
/*     */   private class QuitCommand extends SMTPCommand {
/*     */     private final SMTPConnection this$0;
/*     */     
/*     */     private QuitCommand() {}
/*     */     
/*     */     public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) {
/*  91 */       SMTPConnection.this.println(param1PrintWriter, "221 " + SMTPConnection.this.getHost() + " Service closing transmission channel");
/*     */ 
/*     */       
/*  94 */       SMTPConnection.this.done = true;
/*     */       try {
/*  96 */         param1BufferedReader.close();
/*  97 */         param1PrintWriter.close();
/*  98 */       } catch (IOException iOException) {
/*  99 */         String str = WebServiceLogger.logSMTPquitCommandIOException();
/* 100 */         WebServiceLogger.logStackTrace(str, iOException);
/*     */       } 
/*     */     } }
/*     */   
/*     */   private class DataCommand extends SMTPCommand { private final SMTPConnection this$0;
/*     */     
/*     */     private DataCommand() {}
/*     */     
/*     */     public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) {
/*     */       String str;
/* 110 */       if (SMTPConnection.this.mail == null) {
/* 111 */         SMTPConnection.this.println(param1PrintWriter, "503 Bad sequence of commands");
/*     */         
/*     */         return;
/*     */       } 
/* 115 */       SMTPConnection.this.println(param1PrintWriter, "354 send the mail data, end with .");
/*     */       
/* 117 */       StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */       
/*     */       do {
/*     */         try {
/* 122 */           str = param1BufferedReader.readLine();
/* 123 */         } catch (IOException iOException) {
/* 124 */           String str1 = WebServiceLogger.logSMTPprocessReadIOException();
/* 125 */           WebServiceLogger.logStackTrace(str1, iOException);
/*     */           try {
/* 127 */             param1BufferedReader.close();
/* 128 */             param1PrintWriter.close();
/* 129 */           } catch (IOException iOException1) {
/* 130 */             String str2 = WebServiceLogger.logSMTPprocessCloseIOException();
/* 131 */             WebServiceLogger.logStackTrace(str2, iOException1);
/*     */           } 
/* 133 */           SMTPConnection.this.done = true;
/*     */           
/*     */           return;
/*     */         } 
/* 137 */         stringBuffer.append(str);
/* 138 */         stringBuffer.append("\n");
/* 139 */       } while (!".".equals(str));
/*     */       
/* 141 */       SMTPConnection.this.mail.setData(stringBuffer.toString());
/* 142 */       SMTPConnection.this.mailQ.add(SMTPConnection.this.mail);
/*     */       
/* 144 */       SMTPConnection.this.println(param1PrintWriter, OK + "  ok");
/*     */     } }
/*     */   
/*     */   private class RecipientCommand extends SMTPCommand { private final SMTPConnection this$0;
/*     */     
/*     */     private RecipientCommand() {}
/*     */     
/*     */     public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) {
/*     */       String str;
/* 153 */       if (SMTPConnection.this.mail == null) {
/* 154 */         SMTPConnection.this.println(param1PrintWriter, "503 Bad sequence of commands");
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 160 */       if (param1StringTokenizer.hasMoreTokens()) {
/* 161 */         str = SMTPConnection.this.makeString(param1StringTokenizer);
/*     */       } else {
/* 163 */         SMTPConnection.this.println(param1PrintWriter, "501 Syntax error in parameters or arguments");
/*     */         
/*     */         return;
/*     */       } 
/* 167 */       if (!SMTPConnection.this.startsWithIgnoreCase(str, "TO:")) {
/* 168 */         SMTPConnection.this.println(param1PrintWriter, "501 Syntax error in parameters or arguments");
/*     */         
/*     */         return;
/*     */       } 
/* 172 */       SMTPConnection.this.mail.setTo(str.substring(3, str.length()));
/* 173 */       SMTPConnection.this.println(param1PrintWriter, OK + "  ok");
/*     */     } }
/*     */ 
/*     */   
/*     */   private String makeString(StringTokenizer paramStringTokenizer) {
/* 178 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 180 */     while (paramStringTokenizer.hasMoreTokens()) {
/* 181 */       stringBuffer.append(paramStringTokenizer.nextToken());
/*     */     }
/*     */     
/* 184 */     return stringBuffer.toString();
/*     */   }
/*     */   private class MailCommand extends SMTPCommand { private final SMTPConnection this$0;
/*     */     
/*     */     private MailCommand() {}
/*     */     
/*     */     public void process(StringTokenizer param1StringTokenizer, BufferedReader param1BufferedReader, PrintWriter param1PrintWriter) {
/*     */       String str;
/* 192 */       if (SMTPConnection.this.mail != null) {
/* 193 */         SMTPConnection.this.println(param1PrintWriter, "503 Bad sequence of commands");
/*     */         
/*     */         return;
/*     */       } 
/* 197 */       SMTPConnection.this.mail = new MailMessage();
/*     */ 
/*     */ 
/*     */       
/* 201 */       if (param1StringTokenizer.hasMoreTokens()) {
/* 202 */         str = SMTPConnection.this.makeString(param1StringTokenizer);
/*     */       } else {
/* 204 */         SMTPConnection.this.println(param1PrintWriter, "501 Syntax error in parameters or arguments");
/*     */         
/*     */         return;
/*     */       } 
/* 208 */       if (!SMTPConnection.this.startsWithIgnoreCase(str, "FROM:")) {
/* 209 */         SMTPConnection.this.println(param1PrintWriter, "501 Syntax error in parameters or arguments");
/*     */         
/*     */         return;
/*     */       } 
/* 213 */       SMTPConnection.this.mail.setFrom(str.substring(5, str.length()));
/* 214 */       SMTPConnection.this.println(param1PrintWriter, OK + "  ok");
/*     */     } }
/*     */ 
/*     */   
/*     */   private boolean startsWithIgnoreCase(String paramString1, String paramString2) {
/* 219 */     int i = paramString2.length();
/*     */     
/* 221 */     if (paramString1.length() < i) {
/* 222 */       return false;
/*     */     }
/*     */     
/* 225 */     paramString1 = paramString1.substring(0, i);
/*     */     
/* 227 */     return paramString1.equalsIgnoreCase(paramString2);
/*     */   }
/*     */   
/*     */   private void println(PrintWriter paramPrintWriter, String paramString) {
/* 231 */     paramPrintWriter.println(paramString);
/* 232 */     paramPrintWriter.flush();
/*     */   }
/*     */ 
/*     */   
/* 236 */   private void sayGreeting(PrintWriter paramPrintWriter) { println(paramPrintWriter, SERVICE_READY + " " + getHost() + " " + TITLE); }
/*     */ 
/*     */ 
/*     */   
/* 240 */   private void sendError(PrintWriter paramPrintWriter) { println(paramPrintWriter, SYNTAX_ERROR + " Syntax error, command unrecognized"); }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getHost() {
/*     */     try {
/* 246 */       if (this.host == null) {
/* 247 */         this.host = InetAddress.getLocalHost().getHostName();
/*     */       }
/*     */     }
/* 250 */     catch (UnknownHostException unknownHostException) {
/* 251 */       System.out.println("Failed to get local host name:" + unknownHostException);
/* 252 */       this.host = "localhost";
/*     */     } 
/*     */     
/* 255 */     return this.host;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\SMTPConnection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */