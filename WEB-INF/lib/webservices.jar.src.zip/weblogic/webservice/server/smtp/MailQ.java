package weblogic.webservice.server.smtp;

import java.util.ArrayList;
import java.util.List;
import weblogic.webservice.WebServiceLogger;

public class MailQ {
  private List queue = new ArrayList();
  
  public MailMessage next() {
    while (this.queue.size() == 0) {
      try {
        wait();
      } catch (InterruptedException interruptedException) {
        String str = WebServiceLogger.logMailInterruptedException();
        WebServiceLogger.logStackTrace(str, interruptedException);
      } 
    } 
    return (MailMessage)this.queue.remove(0);
  }
  
  public void add(MailMessage paramMailMessage) {
    this.queue.add(paramMailMessage);
    notifyAll();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\MailQ.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */