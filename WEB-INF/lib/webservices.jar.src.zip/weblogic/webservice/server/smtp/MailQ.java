/*    */ package weblogic.webservice.server.smtp;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import weblogic.webservice.WebServiceLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MailQ
/*    */ {
/* 11 */   private List queue = new ArrayList();
/*    */ 
/*    */   
/*    */   public MailMessage next() {
/* 15 */     while (this.queue.size() == 0) {
/*    */       try {
/* 17 */         wait();
/* 18 */       } catch (InterruptedException interruptedException) {
/* 19 */         String str = WebServiceLogger.logMailInterruptedException();
/* 20 */         WebServiceLogger.logStackTrace(str, interruptedException);
/*    */       } 
/*    */     } 
/*    */     
/* 24 */     return (MailMessage)this.queue.remove(0);
/*    */   }
/*    */   
/*    */   public void add(MailMessage paramMailMessage) {
/* 28 */     this.queue.add(paramMailMessage);
/* 29 */     notifyAll();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\smtp\MailQ.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */