package weblogic.webservice.server.jms;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.rpc.JAXRPCException;
import javax.xml.soap.SOAPException;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.binding.jms.JMSBindingInfo;
import weblogic.webservice.binding.jms.JMSServerBinding;
import weblogic.webservice.server.WebServiceManager;
import weblogic.webservice.util.ServerSecurityHelper;

public class JMSListener extends TimerTask implements MessageListener {
  private QueueConnectionFactory factory;
  
  private QueueConnection connection;
  
  private QueueSession session;
  
  private QueueReceiver receiver;
  
  private String wsUrl;
  
  private WebServiceManager manager;
  
  private JMSBindingInfo bindingInfo;
  
  private Timer timer;
  
  private static int TIME_TO_SLEEP = 60000;
  
  public JMSListener(BindingInfo paramBindingInfo, String paramString, WebServiceManager paramWebServiceManager) throws JAXRPCException {
    this.wsUrl = paramString;
    this.manager = paramWebServiceManager;
    this.bindingInfo = (JMSBindingInfo)paramBindingInfo;
    connect();
  }
  
  private void connect() {
    try {
      InitialContext initialContext = new InitialContext();
      String str1 = this.bindingInfo.getFactoryName();
      String str2 = this.bindingInfo.getQueueName();
      this.factory = (QueueConnectionFactory)initialContext.lookup(str1);
      this.connection = this.factory.createQueueConnection();
      this.session = this.connection.createQueueSession(false, 1);
      Queue queue = (Queue)initialContext.lookup(str2);
      String str3 = "URI like '" + this.manager.getContextPath() + this.wsUrl + "'";
      this.receiver = this.session.createReceiver(queue, str3);
      this.receiver.setMessageListener(this);
      this.connection.start();
      if (this.timer != null) {
        this.timer.cancel();
        this.timer = null;
      } 
    } catch (NamingException namingException) {
      handleConnectionException(namingException);
    } catch (JMSException jMSException) {
      handleConnectionException(jMSException);
    } 
  }
  
  private void handleConnectionException(Exception paramException) {
    String str = WebServiceLogger.logJMSListenerJMSException();
    WebServiceLogger.logStackTrace(str, paramException);
    if (this.timer == null) {
      this.timer = new Timer(true);
      this.timer.scheduleAtFixedRate(this, TIME_TO_SLEEP, TIME_TO_SLEEP);
    } 
  }
  
  public void close() {
    this.receiver.close();
    this.session.close();
    this.connection.close();
  }
  
  public void run() { connect(); }
  
  public void onMessage(Message paramMessage) {
    ServerSecurityHelper.assertAnonymousIdentity();
    if (!(paramMessage instanceof TextMessage))
      throw new JAXRPCException("not text message" + paramMessage); 
    String str = null;
    try {
      str = paramMessage.getStringProperty("URI");
    } catch (JMSException jMSException) {
      throw new JAXRPCException("Failed to get URI property from JMS text message:" + jMSException, jMSException);
    } 
    try {
      String str1 = null;
      String str2 = this.manager.getContextPath();
      if (str.startsWith(this.manager.getContextPath())) {
        str1 = str.substring(this.manager.getContextPath().length());
      } else {
        str1 = str;
      } 
      this.manager.dispatch(str1, new JMSServerBinding((TextMessage)paramMessage, this.factory));
    } catch (SOAPException sOAPException) {
      String str1 = WebServiceLogger.logJMSonMessageSOAPException();
      WebServiceLogger.logStackTrace(str1, sOAPException);
    } catch (IOException iOException) {
      String str1 = WebServiceLogger.logJMSonMessageIOException();
      WebServiceLogger.logStackTrace(str1, iOException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\jms\JMSListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */