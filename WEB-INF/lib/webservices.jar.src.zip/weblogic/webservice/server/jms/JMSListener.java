/*     */ package weblogic.webservice.server.jms;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.jms.TextMessage;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.binding.jms.JMSBindingInfo;
/*     */ import weblogic.webservice.binding.jms.JMSServerBinding;
/*     */ import weblogic.webservice.server.WebServiceManager;
/*     */ import weblogic.webservice.util.ServerSecurityHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSListener
/*     */   extends TimerTask
/*     */   implements MessageListener
/*     */ {
/*     */   private QueueConnectionFactory factory;
/*     */   private QueueConnection connection;
/*     */   private QueueSession session;
/*     */   private QueueReceiver receiver;
/*     */   private String wsUrl;
/*     */   private WebServiceManager manager;
/*     */   private JMSBindingInfo bindingInfo;
/*     */   private Timer timer;
/*  49 */   private static int TIME_TO_SLEEP = 60000;
/*     */ 
/*     */ 
/*     */   
/*     */   public JMSListener(BindingInfo paramBindingInfo, String paramString, WebServiceManager paramWebServiceManager) throws JAXRPCException {
/*  54 */     this.wsUrl = paramString;
/*  55 */     this.manager = paramWebServiceManager;
/*  56 */     this.bindingInfo = (JMSBindingInfo)paramBindingInfo;
/*  57 */     connect();
/*     */   }
/*     */ 
/*     */   
/*     */   private void connect() {
/*     */     try {
/*  63 */       InitialContext initialContext = new InitialContext();
/*     */       
/*  65 */       String str1 = this.bindingInfo.getFactoryName();
/*  66 */       String str2 = this.bindingInfo.getQueueName();
/*     */       
/*  68 */       this.factory = (QueueConnectionFactory)initialContext.lookup(str1);
/*  69 */       this.connection = this.factory.createQueueConnection();
/*     */       
/*  71 */       this.session = this.connection.createQueueSession(false, 1);
/*     */ 
/*     */       
/*  74 */       Queue queue = (Queue)initialContext.lookup(str2);
/*     */       
/*  76 */       String str3 = "URI like '" + this.manager.getContextPath() + this.wsUrl + "'";
/*     */ 
/*     */       
/*  79 */       this.receiver = this.session.createReceiver(queue, str3);
/*     */       
/*  81 */       this.receiver.setMessageListener(this);
/*  82 */       this.connection.start();
/*     */       
/*  84 */       if (this.timer != null) {
/*  85 */         this.timer.cancel();
/*  86 */         this.timer = null;
/*     */       }
/*     */     
/*  89 */     } catch (NamingException namingException) {
/*  90 */       handleConnectionException(namingException);
/*  91 */     } catch (JMSException jMSException) {
/*  92 */       handleConnectionException(jMSException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleConnectionException(Exception paramException) {
/*  97 */     String str = WebServiceLogger.logJMSListenerJMSException();
/*  98 */     WebServiceLogger.logStackTrace(str, paramException);
/*     */     
/* 100 */     if (this.timer == null) {
/* 101 */       this.timer = new Timer(true);
/* 102 */       this.timer.scheduleAtFixedRate(this, TIME_TO_SLEEP, TIME_TO_SLEEP);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() {
/* 107 */     this.receiver.close();
/* 108 */     this.session.close();
/* 109 */     this.connection.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void run() { connect(); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onMessage(Message paramMessage) {
/* 122 */     ServerSecurityHelper.assertAnonymousIdentity();
/*     */     
/* 124 */     if (!(paramMessage instanceof TextMessage)) {
/* 125 */       throw new JAXRPCException("not text message" + paramMessage);
/*     */     }
/*     */     
/* 128 */     String str = null;
/*     */     
/*     */     try {
/* 131 */       str = paramMessage.getStringProperty("URI");
/* 132 */     } catch (JMSException jMSException) {
/* 133 */       throw new JAXRPCException("Failed to get URI property from JMS text message:" + jMSException, jMSException);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 139 */       String str1 = null;
/* 140 */       String str2 = this.manager.getContextPath();
/*     */       
/* 142 */       if (str.startsWith(this.manager.getContextPath())) {
/* 143 */         str1 = str.substring(this.manager.getContextPath().length());
/*     */       } else {
/* 145 */         str1 = str;
/*     */       } 
/*     */       
/* 148 */       this.manager.dispatch(str1, new JMSServerBinding((TextMessage)paramMessage, this.factory));
/*     */     
/*     */     }
/* 151 */     catch (SOAPException sOAPException) {
/* 152 */       String str1 = WebServiceLogger.logJMSonMessageSOAPException();
/* 153 */       WebServiceLogger.logStackTrace(str1, sOAPException);
/* 154 */     } catch (IOException iOException) {
/* 155 */       String str1 = WebServiceLogger.logJMSonMessageIOException();
/* 156 */       WebServiceLogger.logStackTrace(str1, iOException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\jms\JMSListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */