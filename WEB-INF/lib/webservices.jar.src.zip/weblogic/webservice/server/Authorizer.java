package weblogic.webservice.server;

import weblogic.webservice.Operation;
import weblogic.webservice.WLMessageContext;

public interface Authorizer {
  boolean isAccessAllowed(Operation paramOperation, WLMessageContext paramWLMessageContext);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\Authorizer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */