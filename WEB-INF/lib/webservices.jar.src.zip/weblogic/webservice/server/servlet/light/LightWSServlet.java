package weblogic.webservice.server.servlet.light;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.xml.rpc.handler.HandlerInfo;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceFactory;
import weblogic.webservice.component.javaclass.JavaClassInvocationHandler;
import weblogic.webservice.server.servlet.ServletBase;
import weblogic.xml.xmlnode.XMLNode;

public abstract class LightWSServlet extends ServletBase {
  private static final String WEBSERVICES_XML_FILE_NAME = "light-web-services.xml";
  
  private static final String WEBSERVICES_XML_PATH = "/WEB-INF/light-web-services.xml";
  
  private HashMap webServices = new HashMap();
  
  private HandlerInfo[] invokeHandlerInfo = { new HandlerInfo(weblogic.webservice.core.handler.InvokeHandler.class, null, null) };
  
  public void init() {
    ServletContext servletContext = getServletConfig().getServletContext();
    InputStream inputStream = servletContext.getResourceAsStream("/WEB-INF/light-web-services.xml");
    if (inputStream == null)
      throw new ServletException("unable to find the /WEB-INF/light-web-services.xmlconfiguration file. This file should be in the WEB-INF directory"); 
    loadWebServices(inputStream);
  }
  
  private void loadWebServices(InputStream paramInputStream) throws ServletException {
    try {
      XMLNode xMLNode = new XMLNode();
      xMLNode.read(paramInputStream);
      for (Iterator iterator = xMLNode.getChildren(); iterator.hasNext(); ) {
        XMLNode xMLNode1 = (XMLNode)iterator.next();
        if ("web-service".equals(xMLNode1.getName().getLocalName()))
          addWebService(xMLNode1); 
      } 
    } catch (IOException iOException) {
      throw new ServletException("failed to parse xml file", iOException);
    } 
  }
  
  private void addWebService(XMLNode paramXMLNode) throws IOException {
    String str1 = paramXMLNode.getAttribute("uri", null);
    if (str1 == null)
      throw new IOException("uri not defined in the webservice" + paramXMLNode); 
    String str2 = paramXMLNode.getAttribute("wsdl-url", null);
    if (str2 == null)
      throw new IOException("wsdl-url not specified:" + paramXMLNode); 
    URL uRL = getServletConfig().getServletContext().getResource(str2);
    if (uRL == null)
      throw new IOException("unable to find wsdl file:" + str2); 
    WebService webService = WebServiceFactory.newInstance().createFromWSDL(uRL.toString());
    XMLNode xMLNode1 = paramXMLNode.getChild("components", null);
    if (xMLNode1 == null)
      throw new IOException("unable to find components:" + paramXMLNode); 
    XMLNode xMLNode2 = xMLNode1.getChild("java-class", null);
    if (xMLNode2 == null)
      throw new IOException("unable to find java-class component:" + paramXMLNode); 
    setComponent(webService, xMLNode2);
    this.webServices.put(str1, webService);
  }
  
  private void setComponent(WebService paramWebService, XMLNode paramXMLNode) throws IOException {
    String str = paramXMLNode.getAttribute("class-name", null);
    if (str == null)
      throw new IOException("class name not defined in component:" + paramXMLNode); 
    Class clazz = loadClass(str);
    JavaClassInvocationHandler javaClassInvocationHandler = null;
    try {
      javaClassInvocationHandler = new JavaClassInvocationHandler(clazz);
    } catch (InstantiationException instantiationException) {
      throw new IOException("failed to create invocation handler:" + instantiationException);
    } 
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      for (Iterator iterator1 = port.getOperations(); iterator1.hasNext(); ) {
        Operation operation = (Operation)iterator1.next();
        operation.setInvocationHandler(javaClassInvocationHandler);
        operation.setHandlerInfos(this.invokeHandlerInfo);
        try {
          javaClassInvocationHandler.registerOperation(operation.getName(), operation.getName(), null);
        } catch (NoSuchMethodException noSuchMethodException) {
          throw new IOException(noSuchMethodException.getMessage());
        } 
      } 
    } 
  }
  
  private Class loadClass(String paramString) throws IOException {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = getClass().getClassLoader(); 
    try {
      return classLoader.loadClass(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new IOException("unable to load component class:" + classNotFoundException);
    } 
  }
  
  protected WebService getWebService(HttpServletRequest paramHttpServletRequest) { return (WebService)this.webServices.get(paramHttpServletRequest.getPathInfo()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\servlet\light\LightWSServlet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */