/*     */ package weblogic.webservice.server.servlet.light;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceFactory;
/*     */ import weblogic.webservice.component.javaclass.JavaClassInvocationHandler;
/*     */ import weblogic.webservice.server.servlet.ServletBase;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LightWSServlet
/*     */   extends ServletBase
/*     */ {
/*     */   private static final String WEBSERVICES_XML_FILE_NAME = "light-web-services.xml";
/*     */   private static final String WEBSERVICES_XML_PATH = "/WEB-INF/light-web-services.xml";
/*  44 */   private HashMap webServices = new HashMap();
/*     */   
/*  46 */   private HandlerInfo[] invokeHandlerInfo = { new HandlerInfo(weblogic.webservice.core.handler.InvokeHandler.class, null, null) };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  52 */     ServletContext servletContext = getServletConfig().getServletContext();
/*     */     
/*  54 */     InputStream inputStream = servletContext.getResourceAsStream("/WEB-INF/light-web-services.xml");
/*     */ 
/*     */     
/*  57 */     if (inputStream == null) {
/*  58 */       throw new ServletException("unable to find the /WEB-INF/light-web-services.xmlconfiguration file. This file should be in the WEB-INF directory");
/*     */     }
/*     */ 
/*     */     
/*  62 */     loadWebServices(inputStream);
/*     */   }
/*     */   
/*     */   private void loadWebServices(InputStream paramInputStream) throws ServletException {
/*     */     try {
/*  67 */       XMLNode xMLNode = new XMLNode();
/*  68 */       xMLNode.read(paramInputStream);
/*     */       
/*  70 */       for (Iterator iterator = xMLNode.getChildren(); iterator.hasNext(); ) {
/*  71 */         XMLNode xMLNode1 = (XMLNode)iterator.next();
/*     */         
/*  73 */         if ("web-service".equals(xMLNode1.getName().getLocalName())) {
/*  74 */           addWebService(xMLNode1);
/*     */         }
/*     */       } 
/*  77 */     } catch (IOException iOException) {
/*  78 */       throw new ServletException("failed to parse xml file", iOException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addWebService(XMLNode paramXMLNode) throws IOException {
/*  83 */     String str1 = paramXMLNode.getAttribute("uri", null);
/*     */     
/*  85 */     if (str1 == null) {
/*  86 */       throw new IOException("uri not defined in the webservice" + paramXMLNode);
/*     */     }
/*     */     
/*  89 */     String str2 = paramXMLNode.getAttribute("wsdl-url", null);
/*     */     
/*  91 */     if (str2 == null) {
/*  92 */       throw new IOException("wsdl-url not specified:" + paramXMLNode);
/*     */     }
/*     */     
/*  95 */     URL uRL = getServletConfig().getServletContext().getResource(str2);
/*     */     
/*  97 */     if (uRL == null) {
/*  98 */       throw new IOException("unable to find wsdl file:" + str2);
/*     */     }
/*     */     
/* 101 */     WebService webService = WebServiceFactory.newInstance().createFromWSDL(uRL.toString());
/*     */ 
/*     */     
/* 104 */     XMLNode xMLNode1 = paramXMLNode.getChild("components", null);
/*     */     
/* 106 */     if (xMLNode1 == null) {
/* 107 */       throw new IOException("unable to find components:" + paramXMLNode);
/*     */     }
/*     */     
/* 110 */     XMLNode xMLNode2 = xMLNode1.getChild("java-class", null);
/*     */     
/* 112 */     if (xMLNode2 == null) {
/* 113 */       throw new IOException("unable to find java-class component:" + paramXMLNode);
/*     */     }
/*     */ 
/*     */     
/* 117 */     setComponent(webService, xMLNode2);
/*     */     
/* 119 */     this.webServices.put(str1, webService);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setComponent(WebService paramWebService, XMLNode paramXMLNode) throws IOException {
/* 125 */     String str = paramXMLNode.getAttribute("class-name", null);
/*     */     
/* 127 */     if (str == null) {
/* 128 */       throw new IOException("class name not defined in component:" + paramXMLNode);
/*     */     }
/*     */ 
/*     */     
/* 132 */     Class clazz = loadClass(str);
/* 133 */     JavaClassInvocationHandler javaClassInvocationHandler = null;
/*     */     
/*     */     try {
/* 136 */       javaClassInvocationHandler = new JavaClassInvocationHandler(clazz);
/* 137 */     } catch (InstantiationException instantiationException) {
/* 138 */       throw new IOException("failed to create invocation handler:" + instantiationException);
/*     */     } 
/*     */     
/* 141 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 142 */       Port port = (Port)iterator.next();
/*     */       
/* 144 */       for (Iterator iterator1 = port.getOperations(); iterator1.hasNext(); ) {
/* 145 */         Operation operation = (Operation)iterator1.next();
/* 146 */         operation.setInvocationHandler(javaClassInvocationHandler);
/* 147 */         operation.setHandlerInfos(this.invokeHandlerInfo);
/*     */         try {
/* 149 */           javaClassInvocationHandler.registerOperation(operation.getName(), operation.getName(), null);
/* 150 */         } catch (NoSuchMethodException noSuchMethodException) {
/* 151 */           throw new IOException(noSuchMethodException.getMessage());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Class loadClass(String paramString) throws IOException {
/* 159 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     
/* 161 */     if (classLoader == null) {
/* 162 */       classLoader = getClass().getClassLoader();
/*     */     }
/*     */     
/*     */     try {
/* 166 */       return classLoader.loadClass(paramString);
/* 167 */     } catch (ClassNotFoundException classNotFoundException) {
/* 168 */       throw new IOException("unable to load component class:" + classNotFoundException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 173 */   protected WebService getWebService(HttpServletRequest paramHttpServletRequest) { return (WebService)this.webServices.get(paramHttpServletRequest.getPathInfo()); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\servlet\light\LightWSServlet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */