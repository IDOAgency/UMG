package weblogic.webservice.server.servlet;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.CharsetMap;
import weblogic.utils.StackTraceUtils;
import weblogic.utils.http.HttpParsing;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLSOAPMessage;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceFactory;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.binding.soap.HttpServerBinding;
import weblogic.webservice.cg.WebServiceCGRootPathTextFormatter;
import weblogic.webservice.monitoring.WebServiceStats;
import weblogic.webservice.tools.pagegen.OperationGen;
import weblogic.webservice.tools.pagegen.PageGen;
import weblogic.webservice.tools.pagegen.ResultGen;
import weblogic.webservice.tools.pagegen.SampleInstance;
import weblogic.webservice.tools.wsdlgen.WSDLGen;
import weblogic.webservice.util.WLMessageFactory;
import weblogic.webservice.util.jspgen.GenFactory;

public abstract class ServletBase extends HttpServlet {
  private static final String VIEW = "operation.view";
  
  private static final String INVOKE = "operation.invoke";
  
  private static final String WL_PATH_TRIM = "WL-PATH-TRIM";
  
  private WebServiceFactory wsFactory = WebServiceFactory.newInstance();
  
  protected abstract WebService getWebService(HttpServletRequest paramHttpServletRequest) throws ServletException;
  
  protected String getWebServiceUri(HttpServletRequest paramHttpServletRequest) throws ServletException { return paramHttpServletRequest.getRequestURI(); }
  
  public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    WebService webService = getWebService(paramHttpServletRequest);
    if (!webService.getExposeWSDL()) {
      paramHttpServletResponse;
      paramHttpServletResponse.setStatus(403);
      return;
    } 
    if (webService == null) {
      PrintWriter printWriter = paramHttpServletResponse.getWriter();
      printWriter.println("<html><body><h1>Error:</h1><p>");
      printWriter.println("unable to find web service for url:" + paramHttpServletRequest.getPathInfo());
      printWriter.println("</body></html>");
      return;
    } 
    if (!validProtocol(webService, paramHttpServletRequest, paramHttpServletResponse)) {
      sendForbiddenError(paramHttpServletRequest, paramHttpServletResponse, "Service requires protocol: " + webService.getProtocol());
      return;
    } 
    String str = paramHttpServletRequest.getQueryString();
    if ("wsdl".equals(str) || "WSDL".equals(str)) {
      if (!webService.getExposeWSDL()) {
        paramHttpServletResponse;
        paramHttpServletResponse.sendError(404, "WSDL Not exposed");
        return;
      } 
      paramHttpServletResponse.setContentType("text/xml");
      WSDLGen wSDLGen = new WSDLGen(new PrintStream(paramHttpServletResponse.getOutputStream()));
      String str1 = getLocation(paramHttpServletRequest, false);
      wSDLGen.setDefaultEndpoint(str1);
      wSDLGen.visit(webService);
      WebServiceStats webServiceStats = webService.getStats();
      if (webServiceStats != null)
        webServiceStats.reportWSDLHit(); 
    } else {
      if (!webService.getExposeHomePage()) {
        paramHttpServletResponse;
        paramHttpServletResponse.sendError(404, "Home page not exposed");
        return;
      } 
      paramHttpServletResponse.setContentType("text/html");
      handleGet(paramHttpServletRequest, paramHttpServletResponse, webService);
    } 
  }
  
  private String getLocation(HttpServletRequest paramHttpServletRequest, boolean paramBoolean) {
    StringBuffer stringBuffer = new StringBuffer(256);
    stringBuffer.append(paramHttpServletRequest.getScheme());
    stringBuffer.append("://");
    String str1 = paramHttpServletRequest.getHeader("Authorization");
    if (paramBoolean && str1 != null) {
      String[] arrayOfString = HttpParsing.getAuthInfo(str1);
      if (arrayOfString != null && 
        arrayOfString[false] != null) {
        stringBuffer.append(arrayOfString[0]);
        if (arrayOfString[true] != null) {
          stringBuffer.append(":");
          stringBuffer.append(arrayOfString[1]);
        } 
        stringBuffer.append("@");
      } 
    } 
    stringBuffer.append(paramHttpServletRequest.getServerName());
    stringBuffer.append(":");
    stringBuffer.append(paramHttpServletRequest.getServerPort());
    String str2 = paramHttpServletRequest.getHeader("WL-PATH-TRIM");
    if (str2 != null)
      stringBuffer.append(str2); 
    stringBuffer.append(paramHttpServletRequest.getRequestURI());
    return stringBuffer.toString();
  }
  
  public void handleGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, WebService paramWebService) throws ServletException, IOException {
    boolean bool1 = false;
    boolean bool2 = false;
    String str1 = System.getProperty("file.encoding");
    String str2 = CharsetMap.getIANAFromJava(str1);
    if (str2 == null) {
      paramHttpServletResponse.setContentType("text/html");
    } else {
      paramHttpServletResponse.setContentType("text/html; charset=" + str2);
    } 
    if (paramHttpServletRequest.getParameter("operation.view") != null) {
      bool1 = true;
    } else if (paramHttpServletRequest.getParameter("operation.invoke") != null) {
      bool2 = true;
    } else {
      PageGen pageGen = (PageGen)GenFactory.create((new WebServiceCGRootPathTextFormatter()).cgToolsPagegen() + ".index");
      PrintStream printStream = new PrintStream(paramHttpServletResponse.getOutputStream());
      pageGen.setOutput(printStream);
      pageGen.setRequest(paramHttpServletRequest);
      pageGen.visit(paramWebService);
      printStream.flush();
      WebServiceStats webServiceStats = paramWebService.getStats();
      if (webServiceStats != null)
        webServiceStats.reportHomePageHit(); 
      return;
    } 
    if (str1 != null && str1.length() != 0)
      paramHttpServletRequest.setCharacterEncoding(str1); 
    String str3 = paramHttpServletRequest.getParameter(bool1 ? "operation.view" : "operation.invoke");
    Operation operation = paramWebService.findOperation(str3);
    if (operation == null) {
      ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
      PrintWriter printWriter = new PrintWriter(servletOutputStream);
      printWriter.println("<html><body><h1>Failed to invoke service:</h1><p>");
      printWriter.println("Couldn't find operation \"" + str3 + "\".");
      printWriter.println("</body></html>");
      printWriter.flush();
      return;
    } 
    if (bool1) {
      OperationGen operationGen = (OperationGen)GenFactory.create((new WebServiceCGRootPathTextFormatter()).cgToolsPagegen() + ".operation");
      PrintStream printStream = new PrintStream(paramHttpServletResponse.getOutputStream());
      operationGen.setOutput(printStream);
      operationGen.setRequest(paramHttpServletRequest);
      operationGen.visit(paramWebService, operation);
      printStream.flush();
    } else {
      operation;
      if ("documentwrapped".equals(operation.getStyle())) {
        ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
        PrintWriter printWriter = new PrintWriter(servletOutputStream);
        printWriter.println("<html><body><h1>Failed to invoke service:</h1><p>");
        printWriter.println("WebLogic webservice 8.1 doesn't support calling documentWrapped style webservice from test page.");
        printWriter.println("</body></html>");
        printWriter.flush();
        return;
      } 
      invokeOperation(str3, paramHttpServletRequest, paramHttpServletResponse, paramWebService.getTypeMappingRegistry());
    } 
  }
  
  private void propagateAuthInfo(Port paramPort, HttpServletRequest paramHttpServletRequest) {
    String str = paramHttpServletRequest.getHeader("Authorization");
    if (str != null) {
      String[] arrayOfString = HttpParsing.getAuthInfo(str);
      if (arrayOfString != null) {
        if (arrayOfString[false] == null)
          arrayOfString[0] = ""; 
        if (arrayOfString[true] == null)
          arrayOfString[1] = ""; 
        paramPort.setUserName(arrayOfString[0]);
        paramPort.setPassword(arrayOfString[1]);
      } 
    } 
  }
  
  protected void invokeOperation(String paramString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, TypeMappingRegistry paramTypeMappingRegistry) throws ServletException, IOException {
    try {
      String str = getLocation(paramHttpServletRequest, true) + "?WSDL";
      WebService webService = this.wsFactory.createFromWSDL(str, paramTypeMappingRegistry);
      Operation operation = webService.findOperation(paramString);
      propagateAuthInfo(operation.getPort(), paramHttpServletRequest);
      invokeMultiOutput(webService, operation, paramHttpServletRequest, paramHttpServletResponse);
    } catch (Throwable throwable) {
      ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
      PrintWriter printWriter = new PrintWriter(servletOutputStream);
      printWriter.println("<html><body><h1>Failed to invoke service:</h1><p>");
      printWriter.println(StackTraceUtils.throwable2StackTrace(throwable));
      printWriter.println("</body></html>");
      printWriter.flush();
    } 
  }
  
  private void outputResult(OutputStream paramOutputStream, WebService paramWebService, Operation paramOperation, Map paramMap, ByteArrayOutputStream paramByteArrayOutputStream, boolean paramBoolean) throws IOException {
    ResultGen resultGen = (ResultGen)GenFactory.create((new WebServiceCGRootPathTextFormatter()).cgToolsPagegen() + ".result");
    PrintStream printStream = new PrintStream(paramOutputStream);
    resultGen.setOutput(printStream);
    String str = new String(paramByteArrayOutputStream.toByteArray());
    resultGen.visit(paramWebService, paramOperation, paramMap, str, paramBoolean);
    printStream.flush();
  }
  
  protected void invokeMultiOutput(WebService paramWebService, Operation paramOperation, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws SOAPException, IOException, ServletException {
    ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    HashMap hashMap = new HashMap();
    try {
      PrintStream printStream = new PrintStream(byteArrayOutputStream);
      Map map = getJavaParams(paramOperation, paramHttpServletRequest.getParameterMap());
      Object object = paramOperation.invoke(hashMap, map, printStream);
      hashMap.put("Return Value", object);
      outputResult(servletOutputStream, paramWebService, paramOperation, hashMap, byteArrayOutputStream, false);
    } catch (SOAPFaultException sOAPFaultException) {
      if ("Client.Authentication".equals(sOAPFaultException.getFaultCode().getLocalPart())) {
        sendAuthError(paramHttpServletRequest, paramHttpServletResponse, "Authentication failed: " + sOAPFaultException);
      } else {
        outputResult(servletOutputStream, paramWebService, paramOperation, hashMap, byteArrayOutputStream, true);
      } 
    } catch (TargetInvocationException targetInvocationException) {
      outputResult(servletOutputStream, paramWebService, paramOperation, hashMap, byteArrayOutputStream, true);
    } 
  }
  
  private Map getJavaParams(Operation paramOperation, Map paramMap) throws SOAPException {
    HashMap hashMap = new HashMap();
    for (Iterator iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      String[] arrayOfString = (String[])paramMap.get(part.getName());
      String str = null;
      if (arrayOfString != null && arrayOfString.length > 0)
        str = arrayOfString[0]; 
      SampleInstance sampleInstance = new SampleInstance();
      if (str != null)
        hashMap.put(part.getName(), sampleInstance.getJavaObject(str, part)); 
    } 
    return hashMap;
  }
  
  public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    WebService webService = getWebService(paramHttpServletRequest);
    if (webService == null) {
      paramHttpServletResponse;
      paramHttpServletResponse.sendError(404);
      return;
    } 
    if (!validProtocol(webService, paramHttpServletRequest, paramHttpServletResponse)) {
      sendForbiddenError(paramHttpServletRequest, paramHttpServletResponse, "Service requires protocol: " + webService.getProtocol());
      return;
    } 
    try {
      int i = webService.getResponseBufferSize();
      if (i > 0)
        paramHttpServletResponse.setBufferSize(i); 
      HttpServerBinding httpServerBinding = new HttpServerBinding(paramHttpServletRequest, paramHttpServletResponse);
      serverSideInvoke(webService, httpServerBinding, paramHttpServletRequest, paramHttpServletResponse);
    } catch (SOAPException sOAPException) {
      String str = WebServiceLogger.logServletBaseSoapException();
      WebServiceLogger.logStackTrace(str, sOAPException);
      throw new ServletException("unable to invoke service:", sOAPException);
    } 
  }
  
  protected abstract void serverSideInvoke(WebService paramWebService, Binding paramBinding, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws SOAPException, ServletException, IOException;
  
  protected boolean validProtocol(WebService paramWebService, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException { return ("http".equalsIgnoreCase(paramWebService.getProtocol()) || paramHttpServletRequest.getScheme().equalsIgnoreCase(paramWebService.getProtocol())); }
  
  protected void sendForbiddenError(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString) throws IOException, ServletException {
    try {
      paramHttpServletResponse;
      paramHttpServletResponse.setStatus(403);
      SOAPMessage sOAPMessage = getFaultMessage("Client", paramString);
      paramHttpServletResponse.setContentType(((WLSOAPMessage)sOAPMessage).getContentType());
      sOAPMessage.writeTo(paramHttpServletResponse.getOutputStream());
    } catch (SOAPException sOAPException) {
      String str = WebServiceLogger.logServletBaseSoapSendException();
      WebServiceLogger.logStackTrace(str, sOAPException);
      throw new ServletException("unable to send error:", sOAPException);
    } 
  }
  
  protected void sendAuthError(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString) throws IOException, ServletException {
    try {
      paramHttpServletResponse.setHeader("WWW-Authenticate", "Basic realm=\"" + getAuthRealm() + "\"");
      paramHttpServletResponse;
      paramHttpServletResponse.setStatus(401);
      SOAPMessage sOAPMessage = getFaultMessage("Client.Authentication", paramString);
      paramHttpServletResponse.setContentType(((WLSOAPMessage)sOAPMessage).getContentType());
      sOAPMessage.writeTo(paramHttpServletResponse.getOutputStream());
    } catch (SOAPException sOAPException) {
      String str = WebServiceLogger.logServletBaseSoapAuthException();
      WebServiceLogger.logStackTrace(str, sOAPException);
      throw new ServletException("unable to send error:", sOAPException);
    } 
  }
  
  public String getAuthRealm() { return "Default"; }
  
  private SOAPMessage getFaultMessage(String paramString1, String paramString2) throws SOAPException {
    SOAPMessage sOAPMessage = WLMessageFactory.getInstance().getMessageFactory().createMessage();
    SOAPFault sOAPFault = sOAPMessage.getSOAPPart().getEnvelope().getBody().addFault();
    sOAPFault.setFaultCode(paramString1);
    sOAPFault.setFaultString(paramString2);
    return sOAPMessage;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\servlet\ServletBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */