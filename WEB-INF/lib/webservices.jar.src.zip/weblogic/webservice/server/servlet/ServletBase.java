/*     */ package weblogic.webservice.server.servlet;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.utils.CharsetMap;
/*     */ import weblogic.utils.StackTraceUtils;
/*     */ import weblogic.utils.http.HttpParsing;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLSOAPMessage;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceFactory;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.binding.soap.HttpServerBinding;
/*     */ import weblogic.webservice.cg.WebServiceCGRootPathTextFormatter;
/*     */ import weblogic.webservice.monitoring.WebServiceStats;
/*     */ import weblogic.webservice.tools.pagegen.OperationGen;
/*     */ import weblogic.webservice.tools.pagegen.PageGen;
/*     */ import weblogic.webservice.tools.pagegen.ResultGen;
/*     */ import weblogic.webservice.tools.pagegen.SampleInstance;
/*     */ import weblogic.webservice.tools.wsdlgen.WSDLGen;
/*     */ import weblogic.webservice.util.WLMessageFactory;
/*     */ import weblogic.webservice.util.jspgen.GenFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ServletBase
/*     */   extends HttpServlet
/*     */ {
/*     */   private static final String VIEW = "operation.view";
/*     */   private static final String INVOKE = "operation.invoke";
/*     */   private static final String WL_PATH_TRIM = "WL-PATH-TRIM";
/*  79 */   private WebServiceFactory wsFactory = WebServiceFactory.newInstance();
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract WebService getWebService(HttpServletRequest paramHttpServletRequest) throws ServletException;
/*     */ 
/*     */ 
/*     */   
/*  87 */   protected String getWebServiceUri(HttpServletRequest paramHttpServletRequest) throws ServletException { return paramHttpServletRequest.getRequestURI(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/*  98 */     WebService webService = getWebService(paramHttpServletRequest);
/*     */     
/* 100 */     if (!webService.getExposeWSDL()) {
/* 101 */       paramHttpServletResponse; paramHttpServletResponse.setStatus(403);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 107 */     if (webService == null) {
/* 108 */       PrintWriter printWriter = paramHttpServletResponse.getWriter();
/* 109 */       printWriter.println("<html><body><h1>Error:</h1><p>");
/* 110 */       printWriter.println("unable to find web service for url:" + paramHttpServletRequest.getPathInfo());
/*     */       
/* 112 */       printWriter.println("</body></html>");
/*     */       
/*     */       return;
/*     */     } 
/* 116 */     if (!validProtocol(webService, paramHttpServletRequest, paramHttpServletResponse)) {
/* 117 */       sendForbiddenError(paramHttpServletRequest, paramHttpServletResponse, "Service requires protocol: " + webService.getProtocol());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 122 */     String str = paramHttpServletRequest.getQueryString();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     if ("wsdl".equals(str) || "WSDL".equals(str)) {
/*     */       
/* 129 */       if (!webService.getExposeWSDL()) {
/* 130 */         paramHttpServletResponse; paramHttpServletResponse.sendError(404, "WSDL Not exposed");
/*     */         
/*     */         return;
/*     */       } 
/* 134 */       paramHttpServletResponse.setContentType("text/xml");
/*     */ 
/*     */       
/* 137 */       WSDLGen wSDLGen = new WSDLGen(new PrintStream(paramHttpServletResponse.getOutputStream()));
/*     */ 
/*     */       
/* 140 */       String str1 = getLocation(paramHttpServletRequest, false);
/*     */ 
/*     */ 
/*     */       
/* 144 */       wSDLGen.setDefaultEndpoint(str1);
/* 145 */       wSDLGen.visit(webService);
/*     */       
/* 147 */       WebServiceStats webServiceStats = webService.getStats();
/* 148 */       if (webServiceStats != null) webServiceStats.reportWSDLHit();
/*     */     
/*     */     } else {
/* 151 */       if (!webService.getExposeHomePage()) {
/* 152 */         paramHttpServletResponse; paramHttpServletResponse.sendError(404, "Home page not exposed");
/*     */         
/*     */         return;
/*     */       } 
/* 156 */       paramHttpServletResponse.setContentType("text/html");
/* 157 */       handleGet(paramHttpServletRequest, paramHttpServletResponse, webService);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getLocation(HttpServletRequest paramHttpServletRequest, boolean paramBoolean) {
/* 162 */     StringBuffer stringBuffer = new StringBuffer(256);
/*     */ 
/*     */     
/* 165 */     stringBuffer.append(paramHttpServletRequest.getScheme());
/* 166 */     stringBuffer.append("://");
/*     */     
/* 168 */     String str1 = paramHttpServletRequest.getHeader("Authorization");
/* 169 */     if (paramBoolean && str1 != null) {
/*     */       
/* 171 */       String[] arrayOfString = HttpParsing.getAuthInfo(str1);
/* 172 */       if (arrayOfString != null && 
/* 173 */         arrayOfString[false] != null) {
/* 174 */         stringBuffer.append(arrayOfString[0]);
/* 175 */         if (arrayOfString[true] != null) {
/* 176 */           stringBuffer.append(":");
/* 177 */           stringBuffer.append(arrayOfString[1]);
/*     */         } 
/* 179 */         stringBuffer.append("@");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 184 */     stringBuffer.append(paramHttpServletRequest.getServerName());
/* 185 */     stringBuffer.append(":");
/* 186 */     stringBuffer.append(paramHttpServletRequest.getServerPort());
/*     */     
/* 188 */     String str2 = paramHttpServletRequest.getHeader("WL-PATH-TRIM");
/*     */     
/* 190 */     if (str2 != null) {
/* 191 */       stringBuffer.append(str2);
/*     */     }
/*     */     
/* 194 */     stringBuffer.append(paramHttpServletRequest.getRequestURI());
/*     */     
/* 196 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, WebService paramWebService) throws ServletException, IOException {
/* 203 */     boolean bool1 = false;
/* 204 */     boolean bool2 = false;
/*     */     
/* 206 */     String str1 = System.getProperty("file.encoding");
/* 207 */     String str2 = CharsetMap.getIANAFromJava(str1);
/*     */     
/* 209 */     if (str2 == null) {
/* 210 */       paramHttpServletResponse.setContentType("text/html");
/*     */     } else {
/* 212 */       paramHttpServletResponse.setContentType("text/html; charset=" + str2);
/*     */     } 
/*     */     
/* 215 */     if (paramHttpServletRequest.getParameter("operation.view") != null) {
/* 216 */       bool1 = true;
/* 217 */     } else if (paramHttpServletRequest.getParameter("operation.invoke") != null) {
/* 218 */       bool2 = true;
/*     */     } else {
/* 220 */       PageGen pageGen = (PageGen)GenFactory.create((new WebServiceCGRootPathTextFormatter()).cgToolsPagegen() + ".index");
/*     */ 
/*     */ 
/*     */       
/* 224 */       PrintStream printStream = new PrintStream(paramHttpServletResponse.getOutputStream());
/* 225 */       pageGen.setOutput(printStream);
/* 226 */       pageGen.setRequest(paramHttpServletRequest);
/* 227 */       pageGen.visit(paramWebService);
/* 228 */       printStream.flush();
/*     */ 
/*     */       
/* 231 */       WebServiceStats webServiceStats = paramWebService.getStats();
/* 232 */       if (webServiceStats != null) webServiceStats.reportHomePageHit();
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/* 237 */     if (str1 != null && str1.length() != 0) {
/* 238 */       paramHttpServletRequest.setCharacterEncoding(str1);
/*     */     }
/* 240 */     String str3 = paramHttpServletRequest.getParameter(bool1 ? "operation.view" : "operation.invoke");
/* 241 */     Operation operation = paramWebService.findOperation(str3);
/*     */     
/* 243 */     if (operation == null) {
/* 244 */       ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
/* 245 */       PrintWriter printWriter = new PrintWriter(servletOutputStream);
/*     */       
/* 247 */       printWriter.println("<html><body><h1>Failed to invoke service:</h1><p>");
/*     */       
/* 249 */       printWriter.println("Couldn't find operation \"" + str3 + "\".");
/*     */       
/* 251 */       printWriter.println("</body></html>");
/* 252 */       printWriter.flush();
/*     */       
/*     */       return;
/*     */     } 
/* 256 */     if (bool1) {
/* 257 */       OperationGen operationGen = (OperationGen)GenFactory.create((new WebServiceCGRootPathTextFormatter()).cgToolsPagegen() + ".operation");
/*     */ 
/*     */ 
/*     */       
/* 261 */       PrintStream printStream = new PrintStream(paramHttpServletResponse.getOutputStream());
/* 262 */       operationGen.setOutput(printStream);
/* 263 */       operationGen.setRequest(paramHttpServletRequest);
/* 264 */       operationGen.visit(paramWebService, operation);
/* 265 */       printStream.flush();
/*     */     } else {
/* 267 */       operation; if ("documentwrapped".equals(operation.getStyle())) {
/* 268 */         ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
/* 269 */         PrintWriter printWriter = new PrintWriter(servletOutputStream);
/*     */         
/* 271 */         printWriter.println("<html><body><h1>Failed to invoke service:</h1><p>");
/*     */         
/* 273 */         printWriter.println("WebLogic webservice 8.1 doesn't support calling documentWrapped style webservice from test page.");
/*     */ 
/*     */         
/* 276 */         printWriter.println("</body></html>");
/* 277 */         printWriter.flush();
/*     */         return;
/*     */       } 
/* 280 */       invokeOperation(str3, paramHttpServletRequest, paramHttpServletResponse, paramWebService.getTypeMappingRegistry());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void propagateAuthInfo(Port paramPort, HttpServletRequest paramHttpServletRequest) {
/* 286 */     String str = paramHttpServletRequest.getHeader("Authorization");
/*     */     
/* 288 */     if (str != null) {
/* 289 */       String[] arrayOfString = HttpParsing.getAuthInfo(str);
/*     */       
/* 291 */       if (arrayOfString != null) {
/* 292 */         if (arrayOfString[false] == null) arrayOfString[0] = ""; 
/* 293 */         if (arrayOfString[true] == null) arrayOfString[1] = ""; 
/* 294 */         paramPort.setUserName(arrayOfString[0]);
/* 295 */         paramPort.setPassword(arrayOfString[1]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeOperation(String paramString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, TypeMappingRegistry paramTypeMappingRegistry) throws ServletException, IOException {
/*     */     try {
/* 308 */       String str = getLocation(paramHttpServletRequest, true) + "?WSDL";
/* 309 */       WebService webService = this.wsFactory.createFromWSDL(str, paramTypeMappingRegistry);
/*     */       
/* 311 */       Operation operation = webService.findOperation(paramString);
/* 312 */       propagateAuthInfo(operation.getPort(), paramHttpServletRequest);
/*     */       
/* 314 */       invokeMultiOutput(webService, operation, paramHttpServletRequest, paramHttpServletResponse);
/*     */     }
/* 316 */     catch (Throwable throwable) {
/* 317 */       ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
/* 318 */       PrintWriter printWriter = new PrintWriter(servletOutputStream);
/* 319 */       printWriter.println("<html><body><h1>Failed to invoke service:</h1><p>");
/* 320 */       printWriter.println(StackTraceUtils.throwable2StackTrace(throwable));
/* 321 */       printWriter.println("</body></html>");
/* 322 */       printWriter.flush();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void outputResult(OutputStream paramOutputStream, WebService paramWebService, Operation paramOperation, Map paramMap, ByteArrayOutputStream paramByteArrayOutputStream, boolean paramBoolean) throws IOException {
/* 334 */     ResultGen resultGen = (ResultGen)GenFactory.create((new WebServiceCGRootPathTextFormatter()).cgToolsPagegen() + ".result");
/*     */ 
/*     */ 
/*     */     
/* 338 */     PrintStream printStream = new PrintStream(paramOutputStream);
/* 339 */     resultGen.setOutput(printStream);
/* 340 */     String str = new String(paramByteArrayOutputStream.toByteArray());
/* 341 */     resultGen.visit(paramWebService, paramOperation, paramMap, str, paramBoolean);
/* 342 */     printStream.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeMultiOutput(WebService paramWebService, Operation paramOperation, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws SOAPException, IOException, ServletException {
/* 350 */     ServletOutputStream servletOutputStream = paramHttpServletResponse.getOutputStream();
/* 351 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 352 */     HashMap hashMap = new HashMap();
/*     */     
/*     */     try {
/* 355 */       PrintStream printStream = new PrintStream(byteArrayOutputStream);
/*     */       
/* 357 */       Map map = getJavaParams(paramOperation, paramHttpServletRequest.getParameterMap());
/*     */       
/* 359 */       Object object = paramOperation.invoke(hashMap, map, printStream);
/* 360 */       hashMap.put("Return Value", object);
/*     */       
/* 362 */       outputResult(servletOutputStream, paramWebService, paramOperation, hashMap, byteArrayOutputStream, false);
/* 363 */     } catch (SOAPFaultException sOAPFaultException) {
/* 364 */       if ("Client.Authentication".equals(sOAPFaultException.getFaultCode().getLocalPart())) {
/* 365 */         sendAuthError(paramHttpServletRequest, paramHttpServletResponse, "Authentication failed: " + sOAPFaultException);
/*     */       } else {
/* 367 */         outputResult(servletOutputStream, paramWebService, paramOperation, hashMap, byteArrayOutputStream, true);
/*     */       } 
/* 369 */     } catch (TargetInvocationException targetInvocationException) {
/* 370 */       outputResult(servletOutputStream, paramWebService, paramOperation, hashMap, byteArrayOutputStream, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map getJavaParams(Operation paramOperation, Map paramMap) throws SOAPException {
/* 377 */     HashMap hashMap = new HashMap();
/*     */     
/* 379 */     for (Iterator iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 380 */       Part part = (Part)iterator.next();
/* 381 */       String[] arrayOfString = (String[])paramMap.get(part.getName());
/*     */       
/* 383 */       String str = null;
/*     */       
/* 385 */       if (arrayOfString != null && arrayOfString.length > 0) {
/* 386 */         str = arrayOfString[0];
/*     */       }
/*     */       
/* 389 */       SampleInstance sampleInstance = new SampleInstance();
/*     */       
/* 391 */       if (str != null) {
/* 392 */         hashMap.put(part.getName(), sampleInstance.getJavaObject(str, part));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 397 */     return hashMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/* 403 */     WebService webService = getWebService(paramHttpServletRequest);
/*     */     
/* 405 */     if (webService == null) {
/*     */       
/* 407 */       paramHttpServletResponse; paramHttpServletResponse.sendError(404);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 412 */     if (!validProtocol(webService, paramHttpServletRequest, paramHttpServletResponse)) {
/* 413 */       sendForbiddenError(paramHttpServletRequest, paramHttpServletResponse, "Service requires protocol: " + webService.getProtocol());
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 420 */       int i = webService.getResponseBufferSize();
/*     */       
/* 422 */       if (i > 0) {
/* 423 */         paramHttpServletResponse.setBufferSize(i);
/*     */       }
/*     */ 
/*     */       
/* 427 */       HttpServerBinding httpServerBinding = new HttpServerBinding(paramHttpServletRequest, paramHttpServletResponse);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 439 */       serverSideInvoke(webService, httpServerBinding, paramHttpServletRequest, paramHttpServletResponse);
/*     */     }
/* 441 */     catch (SOAPException sOAPException) {
/*     */       
/* 443 */       String str = WebServiceLogger.logServletBaseSoapException();
/* 444 */       WebServiceLogger.logStackTrace(str, sOAPException);
/* 445 */       throw new ServletException("unable to invoke service:", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void serverSideInvoke(WebService paramWebService, Binding paramBinding, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws SOAPException, ServletException, IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 470 */   protected boolean validProtocol(WebService paramWebService, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException { return ("http".equalsIgnoreCase(paramWebService.getProtocol()) || paramHttpServletRequest.getScheme().equalsIgnoreCase(paramWebService.getProtocol())); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendForbiddenError(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString) throws IOException, ServletException {
/*     */     try {
/* 480 */       paramHttpServletResponse; paramHttpServletResponse.setStatus(403);
/*     */       
/* 482 */       SOAPMessage sOAPMessage = getFaultMessage("Client", paramString);
/* 483 */       paramHttpServletResponse.setContentType(((WLSOAPMessage)sOAPMessage).getContentType());
/*     */       
/* 485 */       sOAPMessage.writeTo(paramHttpServletResponse.getOutputStream());
/* 486 */     } catch (SOAPException sOAPException) {
/* 487 */       String str = WebServiceLogger.logServletBaseSoapSendException();
/* 488 */       WebServiceLogger.logStackTrace(str, sOAPException);
/* 489 */       throw new ServletException("unable to send error:", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendAuthError(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString) throws IOException, ServletException {
/*     */     try {
/* 499 */       paramHttpServletResponse.setHeader("WWW-Authenticate", "Basic realm=\"" + getAuthRealm() + "\"");
/*     */ 
/*     */       
/* 502 */       paramHttpServletResponse; paramHttpServletResponse.setStatus(401);
/*     */       
/* 504 */       SOAPMessage sOAPMessage = getFaultMessage("Client.Authentication", paramString);
/* 505 */       paramHttpServletResponse.setContentType(((WLSOAPMessage)sOAPMessage).getContentType());
/*     */       
/* 507 */       sOAPMessage.writeTo(paramHttpServletResponse.getOutputStream());
/* 508 */     } catch (SOAPException sOAPException) {
/* 509 */       String str = WebServiceLogger.logServletBaseSoapAuthException();
/* 510 */       WebServiceLogger.logStackTrace(str, sOAPException);
/* 511 */       throw new ServletException("unable to send error:", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 519 */   public String getAuthRealm() { return "Default"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SOAPMessage getFaultMessage(String paramString1, String paramString2) throws SOAPException {
/* 527 */     SOAPMessage sOAPMessage = WLMessageFactory.getInstance().getMessageFactory().createMessage();
/* 528 */     SOAPFault sOAPFault = sOAPMessage.getSOAPPart().getEnvelope().getBody().addFault();
/*     */ 
/*     */ 
/*     */     
/* 532 */     sOAPFault.setFaultCode(paramString1);
/* 533 */     sOAPFault.setFaultString(paramString2);
/*     */ 
/*     */     
/* 536 */     return sOAPMessage;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\servlet\ServletBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */