/*     */ package weblogic.webservice.server.servlet;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.security.AccessController;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.application.ApplicationContextInternal;
/*     */ import weblogic.logging.Loggable;
/*     */ import weblogic.management.configuration.AppDeploymentMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.management.provider.ManagementService;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.servlet.HTTPLogger;
/*     */ import weblogic.servlet.internal.ServletRequestImpl;
/*     */ import weblogic.servlet.internal.WebAppServletContext;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.dd.DDLoader;
/*     */ import weblogic.webservice.dd.DDProcessingException;
/*     */ import weblogic.webservice.dd.verify.VerifyException;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ import weblogic.webservice.server.WebServiceContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServiceServlet
/*     */   extends ServletBase
/*     */ {
/*     */   private WebServiceContext wsCtx;
/*     */   private WebServicesMBean webServicesMB;
/*  63 */   private ServletSecurityHelper securityHelper = null;
/*     */ 
/*     */   
/*     */   private static final String WEBSERVICES_XML_FILE_NAME = "web-services.xml";
/*     */ 
/*     */   
/*     */   private static final String WEBSERVICES_XML_PATH = "/WEB-INF/web-services.xml";
/*     */ 
/*     */   
/*     */   private static final boolean debug = false;
/*     */   
/*  74 */   private String authRealm = null;
/*     */ 
/*     */   
/*     */   private boolean isInitialized = false;
/*     */   
/*     */   private static final String ENABLE_AUTH = "weblogic.webservice.security.enableAuth";
/*     */   
/*     */   private static boolean authorizationEnabled = false;
/*     */   
/*  83 */   private static final AuthenticatedSubject kernelId = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/*  88 */     if ("true".equals(System.getProperty("weblogic.webservice.security.enableAuth"))) {
/*  89 */       authorizationEnabled = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*     */     try {
/*  97 */       initLocal();
/*  98 */     } catch (ServletException servletException) {
/*  99 */       throw servletException;
/* 100 */     } catch (Throwable throwable) {
/* 101 */       String str = WebServiceLogger.logWebServiceServletException();
/* 102 */       WebServiceLogger.logStackTrace(str, throwable);
/*     */       
/* 104 */       throw new ServletException("Web Service init() failed: " + throwable, throwable);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initLocal() {
/* 109 */     WebAppServletContext webAppServletContext = (WebAppServletContext)getServletConfig().getServletContext();
/*     */     
/* 111 */     this.webServicesMB = initWebServices(webAppServletContext);
/* 112 */     if (this.webServicesMB == null)
/* 113 */       return;  checkAppVersion(webAppServletContext);
/*     */     try {
/* 115 */       this.securityHelper = new ServletSecurityHelper(webAppServletContext);
/*     */ 
/*     */ 
/*     */       
/* 119 */       this.wsCtx = this.securityHelper.createWebServiceContext(this.webServicesMB);
/* 120 */     } catch (ConfigException configException) {
/* 121 */       String str = WebServiceLogger.logWebServiceServletDDConfigException();
/* 122 */       WebServiceLogger.logStackTrace(str, configException);
/*     */       
/* 124 */       throw new ServletException("WebServiceServlet did not initialized properly." + configException, configException);
/*     */     
/*     */     }
/* 127 */     catch (VerifyException verifyException) {
/* 128 */       throw new ServletException(verifyException);
/*     */     } 
/*     */ 
/*     */     
/* 132 */     if (this.wsCtx == null) {
/* 133 */       throw new ServletException("Cannot create WebServiceContext. WebServiceServlet did not initialized properly.");
/*     */     }
/*     */ 
/*     */     
/* 137 */     this.isInitialized = true;
/*     */     
/* 139 */     StringBuffer stringBuffer = new StringBuffer();
/* 140 */     WebServiceMBean[] arrayOfWebServiceMBean = this.webServicesMB.getWebServices();
/* 141 */     stringBuffer.append("(");
/* 142 */     for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
/* 143 */       if (!b) {
/* 144 */         stringBuffer.append(arrayOfWebServiceMBean[b].getURI());
/*     */       } else {
/* 146 */         stringBuffer.append(", ");
/* 147 */         stringBuffer.append(arrayOfWebServiceMBean[b].getURI());
/*     */       } 
/*     */     } 
/* 150 */     stringBuffer.append(")");
/*     */     
/* 152 */     WebServiceLogger.logSuccessfulDeployment(webAppServletContext.getName(), webAppServletContext.getContextPath(), stringBuffer.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkAppVersion(WebAppServletContext paramWebAppServletContext) throws ServletException {
/* 157 */     ApplicationContextInternal applicationContextInternal = paramWebAppServletContext.getApplicationContext();
/* 158 */     if (applicationContextInternal != null) {
/* 159 */       AppDeploymentMBean appDeploymentMBean = applicationContextInternal.getAppDeploymentMBean();
/* 160 */       if (appDeploymentMBean != null) {
/* 161 */         String str = appDeploymentMBean.getVersionIdentifier();
/* 162 */         if (str != null) {
/* 163 */           WebServiceMBean[] arrayOfWebServiceMBean = this.webServicesMB.getWebServices();
/* 164 */           if (arrayOfWebServiceMBean != null && arrayOfWebServiceMBean.length > 0) {
/* 165 */             StringBuffer stringBuffer = new StringBuffer();
/* 166 */             for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
/* 167 */               stringBuffer.append(arrayOfWebServiceMBean[b].getWebServiceName());
/* 168 */               if (b != arrayOfWebServiceMBean.length - 1) stringBuffer.append(","); 
/*     */             } 
/* 170 */             Loggable loggable = HTTPLogger.logWebServicesVersioningNotSupportedLoggable(toString(), stringBuffer.toString(), str);
/*     */             
/* 172 */             loggable.log();
/* 173 */             throw new ServletException(loggable.getMessage());
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private WebServicesMBean initWebServices(WebAppServletContext paramWebAppServletContext) throws ServletException {
/* 181 */     InputStream inputStream = paramWebAppServletContext.getResourceAsStream("/WEB-INF/web-services.xml");
/* 182 */     if (inputStream == null) return null; 
/*     */     try {
/* 184 */       return (new DDLoader()).load(inputStream);
/* 185 */     } catch (DDProcessingException dDProcessingException) {
/* 186 */       throw new ServletException("Failed to process webservices DD file", dDProcessingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getWebServiceUri(HttpServletRequest paramHttpServletRequest) throws ServletException {
/*     */     ServletRequestImpl servletRequestImpl;
/* 197 */     if (paramHttpServletRequest instanceof javax.servlet.http.HttpServletRequestWrapper) {
/* 198 */       servletRequestImpl = ServletRequestImpl.getOriginalRequest(paramHttpServletRequest);
/*     */     } else {
/* 200 */       servletRequestImpl = (ServletRequestImpl)paramHttpServletRequest;
/*     */     } 
/*     */     
/* 203 */     String str = null;
/* 204 */     int i = servletRequestImpl.getContext().getContextPath().length();
/*     */     
/* 206 */     if (i > 1) {
/* 207 */       str = servletRequestImpl.getInputHelper().getNormalizedURI().substring(i);
/*     */     } else {
/* 209 */       str = servletRequestImpl.getInputHelper().getNormalizedURI();
/*     */     } 
/*     */     
/* 212 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WebService getWebService(HttpServletRequest paramHttpServletRequest) throws ServletException {
/* 225 */     if (this.wsCtx == null) {
/* 226 */       throw new ServletException("No web services registered for this web app. WebServiceServlet did not initialized properly.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 232 */     String str = paramHttpServletRequest.getRequestURI();
/* 233 */     WebService webService = this.wsCtx.getWebService(str);
/* 234 */     if (webService == null) {
/*     */       ServletRequestImpl servletRequestImpl;
/*     */ 
/*     */ 
/*     */       
/* 239 */       if (paramHttpServletRequest instanceof javax.servlet.http.HttpServletRequestWrapper) {
/* 240 */         servletRequestImpl = ServletRequestImpl.getOriginalRequest(paramHttpServletRequest);
/*     */       } else {
/* 242 */         servletRequestImpl = (ServletRequestImpl)paramHttpServletRequest;
/*     */       } 
/* 244 */       if (servletRequestImpl.getContext().getContextPath().length() > 1) {
/* 245 */         str = servletRequestImpl.getInputHelper().getNormalizedURI().substring(servletRequestImpl.getContext().getContextPath().length());
/*     */       } else {
/* 247 */         str = servletRequestImpl.getInputHelper().getNormalizedURI();
/*     */       } 
/* 249 */       webService = this.wsCtx.getWebService(str);
/*     */     } 
/* 251 */     return webService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 258 */   public WebServicesMBean getWebServicesMBean() { return this.webServicesMB; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 263 */     if (this.wsCtx != null) {
/* 264 */       this.wsCtx.destroy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/* 274 */     if (!this.isInitialized) {
/* 275 */       throw new ServletException("Web Service servlet was not initialized correctly. Make sure web-services.xml file exists is WEB-INF directory.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 280 */     super.doGet(paramHttpServletRequest, paramHttpServletResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
/* 286 */     if (!this.isInitialized) {
/* 287 */       throw new ServletException("Web Service servlet was not initialized correctly. Make sure web-services.xml file exists in the WEB-INF directory.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 292 */     super.doPost(paramHttpServletRequest, paramHttpServletResponse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void serverSideInvoke(WebService paramWebService, Binding paramBinding, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException, SOAPException {
/* 299 */     AuthenticatedSubject authenticatedSubject = null;
/*     */     
/*     */     try {
/* 302 */       String str = getWebServiceUri(paramHttpServletRequest);
/*     */       
/* 304 */       boolean bool = false;
/* 305 */       WebServiceMBean[] arrayOfWebServiceMBean = getWebServicesMBean().getWebServices();
/* 306 */       for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
/* 307 */         WebServiceMBean webServiceMBean = arrayOfWebServiceMBean[b];
/* 308 */         if (str.endsWith(webServiceMBean.getURI())) {
/* 309 */           bool = webServiceMBean.getIgnoreAuthHeader();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 314 */       authenticatedSubject = this.securityHelper.getRequestSubject(paramHttpServletRequest, bool);
/*     */       
/* 316 */       if (authenticatedSubject == null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 321 */         this.wsCtx.getManager().dispatch(getWebServiceUri(paramHttpServletRequest), paramBinding);
/*     */       }
/*     */       else
/*     */       {
/* 325 */         this.securityHelper.authenticatedPortInvoke(authenticatedSubject, str, this.wsCtx.getManager(), paramBinding);
/*     */       }
/*     */     
/* 328 */     } catch (LoginException loginException) {
/* 329 */       sendAuthError(paramHttpServletRequest, paramHttpServletResponse, loginException.getMessage());
/* 330 */     } catch (SOAPException sOAPException) {
/* 331 */       if (sOAPException.getCause() instanceof weblogic.webservice.util.AccessException) {
/* 332 */         sendAuthError(paramHttpServletRequest, paramHttpServletResponse, sOAPException.getCause().getMessage());
/*     */       } else {
/* 334 */         throw sOAPException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAuthRealm() {
/* 341 */     if (this.authRealm == null) {
/* 342 */       WebAppServletContext webAppServletContext = (WebAppServletContext)getServletConfig().getServletContext();
/*     */       
/* 344 */       this.authRealm = webAppServletContext.getConfigManager().getAuthRealmName();
/*     */       
/* 346 */       if (this.authRealm == null) {
/* 347 */         this.authRealm = "Default";
/*     */       }
/*     */     } 
/*     */     
/* 351 */     return this.authRealm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeOperation(String paramString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, TypeMappingRegistry paramTypeMappingRegistry) throws ServletException, IOException {
/* 359 */     if ("https".equalsIgnoreCase(paramHttpServletRequest.getScheme()))
/* 360 */       System.setProperty("trustedfile", ManagementService.getRuntimeAccess(kernelId).getServer().getSSL().getTrustedCAFileName()); 
/* 361 */     super.invokeOperation(paramString, paramHttpServletRequest, paramHttpServletResponse, paramTypeMappingRegistry);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\servlet\WebServiceServlet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */