package weblogic.webservice.server.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.security.AccessController;
import javax.security.auth.login.LoginException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.soap.SOAPException;
import weblogic.application.ApplicationContextInternal;
import weblogic.logging.Loggable;
import weblogic.management.configuration.AppDeploymentMBean;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.management.provider.ManagementService;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.PrivilegedActions;
import weblogic.servlet.HTTPLogger;
import weblogic.servlet.internal.ServletRequestImpl;
import weblogic.servlet.internal.WebAppServletContext;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.dd.DDLoader;
import weblogic.webservice.dd.DDProcessingException;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.server.ConfigException;
import weblogic.webservice.server.WebServiceContext;

public class WebServiceServlet extends ServletBase {
  private WebServiceContext wsCtx;
  
  private WebServicesMBean webServicesMB;
  
  private ServletSecurityHelper securityHelper = null;
  
  private static final String WEBSERVICES_XML_FILE_NAME = "web-services.xml";
  
  private static final String WEBSERVICES_XML_PATH = "/WEB-INF/web-services.xml";
  
  private static final boolean debug = false;
  
  private String authRealm = null;
  
  private boolean isInitialized = false;
  
  private static final String ENABLE_AUTH = "weblogic.webservice.security.enableAuth";
  
  private static boolean authorizationEnabled = false;
  
  private static final AuthenticatedSubject kernelId = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
  
  static  {
    if ("true".equals(System.getProperty("weblogic.webservice.security.enableAuth")))
      authorizationEnabled = true; 
  }
  
  public void init() {
    try {
      initLocal();
    } catch (ServletException servletException) {
      throw servletException;
    } catch (Throwable throwable) {
      String str = WebServiceLogger.logWebServiceServletException();
      WebServiceLogger.logStackTrace(str, throwable);
      throw new ServletException("Web Service init() failed: " + throwable, throwable);
    } 
  }
  
  private void initLocal() {
    WebAppServletContext webAppServletContext = (WebAppServletContext)getServletConfig().getServletContext();
    this.webServicesMB = initWebServices(webAppServletContext);
    if (this.webServicesMB == null)
      return; 
    checkAppVersion(webAppServletContext);
    try {
      this.securityHelper = new ServletSecurityHelper(webAppServletContext);
      this.wsCtx = this.securityHelper.createWebServiceContext(this.webServicesMB);
    } catch (ConfigException configException) {
      String str = WebServiceLogger.logWebServiceServletDDConfigException();
      WebServiceLogger.logStackTrace(str, configException);
      throw new ServletException("WebServiceServlet did not initialized properly." + configException, configException);
    } catch (VerifyException verifyException) {
      throw new ServletException(verifyException);
    } 
    if (this.wsCtx == null)
      throw new ServletException("Cannot create WebServiceContext. WebServiceServlet did not initialized properly."); 
    this.isInitialized = true;
    StringBuffer stringBuffer = new StringBuffer();
    WebServiceMBean[] arrayOfWebServiceMBean = this.webServicesMB.getWebServices();
    stringBuffer.append("(");
    for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
      if (!b) {
        stringBuffer.append(arrayOfWebServiceMBean[b].getURI());
      } else {
        stringBuffer.append(", ");
        stringBuffer.append(arrayOfWebServiceMBean[b].getURI());
      } 
    } 
    stringBuffer.append(")");
    WebServiceLogger.logSuccessfulDeployment(webAppServletContext.getName(), webAppServletContext.getContextPath(), stringBuffer.toString());
  }
  
  private void checkAppVersion(WebAppServletContext paramWebAppServletContext) throws ServletException {
    ApplicationContextInternal applicationContextInternal = paramWebAppServletContext.getApplicationContext();
    if (applicationContextInternal != null) {
      AppDeploymentMBean appDeploymentMBean = applicationContextInternal.getAppDeploymentMBean();
      if (appDeploymentMBean != null) {
        String str = appDeploymentMBean.getVersionIdentifier();
        if (str != null) {
          WebServiceMBean[] arrayOfWebServiceMBean = this.webServicesMB.getWebServices();
          if (arrayOfWebServiceMBean != null && arrayOfWebServiceMBean.length > 0) {
            StringBuffer stringBuffer = new StringBuffer();
            for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
              stringBuffer.append(arrayOfWebServiceMBean[b].getWebServiceName());
              if (b != arrayOfWebServiceMBean.length - 1)
                stringBuffer.append(","); 
            } 
            Loggable loggable = HTTPLogger.logWebServicesVersioningNotSupportedLoggable(toString(), stringBuffer.toString(), str);
            loggable.log();
            throw new ServletException(loggable.getMessage());
          } 
        } 
      } 
    } 
  }
  
  private WebServicesMBean initWebServices(WebAppServletContext paramWebAppServletContext) throws ServletException {
    InputStream inputStream = paramWebAppServletContext.getResourceAsStream("/WEB-INF/web-services.xml");
    if (inputStream == null)
      return null; 
    try {
      return (new DDLoader()).load(inputStream);
    } catch (DDProcessingException dDProcessingException) {
      throw new ServletException("Failed to process webservices DD file", dDProcessingException);
    } 
  }
  
  protected String getWebServiceUri(HttpServletRequest paramHttpServletRequest) throws ServletException {
    ServletRequestImpl servletRequestImpl;
    if (paramHttpServletRequest instanceof javax.servlet.http.HttpServletRequestWrapper) {
      servletRequestImpl = ServletRequestImpl.getOriginalRequest(paramHttpServletRequest);
    } else {
      servletRequestImpl = (ServletRequestImpl)paramHttpServletRequest;
    } 
    String str = null;
    int i = servletRequestImpl.getContext().getContextPath().length();
    if (i > 1) {
      str = servletRequestImpl.getInputHelper().getNormalizedURI().substring(i);
    } else {
      str = servletRequestImpl.getInputHelper().getNormalizedURI();
    } 
    return str;
  }
  
  protected WebService getWebService(HttpServletRequest paramHttpServletRequest) throws ServletException {
    if (this.wsCtx == null)
      throw new ServletException("No web services registered for this web app. WebServiceServlet did not initialized properly."); 
    String str = paramHttpServletRequest.getRequestURI();
    WebService webService = this.wsCtx.getWebService(str);
    if (webService == null) {
      ServletRequestImpl servletRequestImpl;
      if (paramHttpServletRequest instanceof javax.servlet.http.HttpServletRequestWrapper) {
        servletRequestImpl = ServletRequestImpl.getOriginalRequest(paramHttpServletRequest);
      } else {
        servletRequestImpl = (ServletRequestImpl)paramHttpServletRequest;
      } 
      if (servletRequestImpl.getContext().getContextPath().length() > 1) {
        str = servletRequestImpl.getInputHelper().getNormalizedURI().substring(servletRequestImpl.getContext().getContextPath().length());
      } else {
        str = servletRequestImpl.getInputHelper().getNormalizedURI();
      } 
      webService = this.wsCtx.getWebService(str);
    } 
    return webService;
  }
  
  public WebServicesMBean getWebServicesMBean() { return this.webServicesMB; }
  
  public void destroy() {
    if (this.wsCtx != null)
      this.wsCtx.destroy(); 
  }
  
  public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    if (!this.isInitialized)
      throw new ServletException("Web Service servlet was not initialized correctly. Make sure web-services.xml file exists is WEB-INF directory."); 
    super.doGet(paramHttpServletRequest, paramHttpServletResponse);
  }
  
  public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    if (!this.isInitialized)
      throw new ServletException("Web Service servlet was not initialized correctly. Make sure web-services.xml file exists in the WEB-INF directory."); 
    super.doPost(paramHttpServletRequest, paramHttpServletResponse);
  }
  
  protected void serverSideInvoke(WebService paramWebService, Binding paramBinding, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException, SOAPException {
    AuthenticatedSubject authenticatedSubject = null;
    try {
      String str = getWebServiceUri(paramHttpServletRequest);
      boolean bool = false;
      WebServiceMBean[] arrayOfWebServiceMBean = getWebServicesMBean().getWebServices();
      for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
        WebServiceMBean webServiceMBean = arrayOfWebServiceMBean[b];
        if (str.endsWith(webServiceMBean.getURI())) {
          bool = webServiceMBean.getIgnoreAuthHeader();
          break;
        } 
      } 
      authenticatedSubject = this.securityHelper.getRequestSubject(paramHttpServletRequest, bool);
      if (authenticatedSubject == null) {
        this.wsCtx.getManager().dispatch(getWebServiceUri(paramHttpServletRequest), paramBinding);
      } else {
        this.securityHelper.authenticatedPortInvoke(authenticatedSubject, str, this.wsCtx.getManager(), paramBinding);
      } 
    } catch (LoginException loginException) {
      sendAuthError(paramHttpServletRequest, paramHttpServletResponse, loginException.getMessage());
    } catch (SOAPException sOAPException) {
      if (sOAPException.getCause() instanceof weblogic.webservice.util.AccessException) {
        sendAuthError(paramHttpServletRequest, paramHttpServletResponse, sOAPException.getCause().getMessage());
      } else {
        throw sOAPException;
      } 
    } 
  }
  
  public String getAuthRealm() {
    if (this.authRealm == null) {
      WebAppServletContext webAppServletContext = (WebAppServletContext)getServletConfig().getServletContext();
      this.authRealm = webAppServletContext.getConfigManager().getAuthRealmName();
      if (this.authRealm == null)
        this.authRealm = "Default"; 
    } 
    return this.authRealm;
  }
  
  protected void invokeOperation(String paramString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, TypeMappingRegistry paramTypeMappingRegistry) throws ServletException, IOException {
    if ("https".equalsIgnoreCase(paramHttpServletRequest.getScheme()))
      System.setProperty("trustedfile", ManagementService.getRuntimeAccess(kernelId).getServer().getSSL().getTrustedCAFileName()); 
    super.invokeOperation(paramString, paramHttpServletRequest, paramHttpServletResponse, paramTypeMappingRegistry);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\servlet\WebServiceServlet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */