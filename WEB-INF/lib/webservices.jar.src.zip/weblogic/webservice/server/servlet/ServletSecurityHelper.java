package weblogic.webservice.server.servlet;

import java.lang.reflect.UndeclaredThrowableException;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.security.cert.X509Certificate;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.xml.soap.SOAPException;
import weblogic.management.ManagementException;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.security.SubjectUtils;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.PrivilegedActions;
import weblogic.security.service.SecurityServiceManager;
import weblogic.servlet.internal.WebAppServletContext;
import weblogic.utils.http.HttpParsing;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.monitoring.WSComponentRuntimeMBeanImpl;
import weblogic.webservice.server.ConfigException;
import weblogic.webservice.server.WebServiceContext;
import weblogic.webservice.server.WebServiceManager;
import weblogic.webservice.util.ServerSecurityHelper;

public class ServletSecurityHelper {
  private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
  
  private static String AUTHENTICATION_HEADER = "Authorization";
  
  private final WebAppServletContext servletCtx;
  
  private final String securityRealm;
  
  public ServletSecurityHelper(WebAppServletContext paramWebAppServletContext) {
    this.servletCtx = paramWebAppServletContext;
    this.securityRealm = this.servletCtx.getSecurityRealmName();
  }
  
  public final AuthenticatedSubject getRequestSubject(HttpServletRequest paramHttpServletRequest, boolean paramBoolean) throws LoginException {
    AuthenticatedSubject authenticatedSubject = ServerSecurityHelper.getCurrentSubject();
    if (!SubjectUtils.isUserAnonymous(authenticatedSubject))
      return null; 
    if (!paramBoolean) {
      String str = paramHttpServletRequest.getHeader(AUTHENTICATION_HEADER);
      if (str != null) {
        String[] arrayOfString = HttpParsing.getAuthInfo(str);
        if (arrayOfString == null)
          return null; 
        if (arrayOfString != null && arrayOfString[false] != null && arrayOfString[true] != null)
          return ServerSecurityHelper.assertIdentity(arrayOfString[0], arrayOfString[1], this.securityRealm); 
      } 
    } 
    if (paramHttpServletRequest.isSecure()) {
      X509Certificate[] arrayOfX509Certificate = null;
      try {
        arrayOfX509Certificate = (X509Certificate[])paramHttpServletRequest.getAttribute("javax.servlet.request.X509Certificate");
      } catch (ClassCastException classCastException) {}
      if (arrayOfX509Certificate != null && arrayOfX509Certificate.length > 0)
        return ServerSecurityHelper.assertIdentity(arrayOfX509Certificate, this.securityRealm); 
    } 
    return null;
  }
  
  protected WebServiceContext createWebServiceContext(final WebServicesMBean wsMBean) throws ConfigException, VerifyException {
    try {
      return (WebServiceContext)SecurityServiceManager.runAs(kernelID, kernelID, new PrivilegedExceptionAction() {
            private final WebServicesMBean val$wsMBean;
            
            private final ServletSecurityHelper this$0;
            
            public Object run() throws ConfigException, VerifyException { return new WebServiceContext(wsMBean, ServletSecurityHelper.this.servletCtx); }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof VerifyException)
        throw (VerifyException)exception; 
      if (exception instanceof ConfigException)
        throw (ConfigException)exception; 
      throw new UndeclaredThrowableException(exception);
    } 
  }
  
  public static void unregisterRuntime(final WSComponentRuntimeMBeanImpl wm) throws PrivilegedActionException {
    SecurityServiceManager.runAs(kernelID, kernelID, new PrivilegedExceptionAction() {
          private final WSComponentRuntimeMBeanImpl val$wm;
          
          public Object run() throws ConfigException, VerifyException {
            try {
              wm.unregister();
            } catch (ManagementException managementException) {
              WebServiceLogger.logStackTrace(WebServiceLogger.logManagementException(managementException.toString()), managementException);
            } 
            return null;
          }
        });
  }
  
  public static final void authenticatedPortInvoke(AuthenticatedSubject paramAuthenticatedSubject, final String uri, final WebServiceManager manager, final Binding binding) throws SOAPException {
    try {
      SecurityServiceManager.runAs(getKernelID(), paramAuthenticatedSubject, new PrivilegedExceptionAction() {
            private final WebServiceManager val$manager;
            
            private final String val$uri;
            
            private final Binding val$binding;
            
            public Object run() throws ConfigException, VerifyException {
              manager.dispatch(uri, binding);
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      if (privilegedActionException.getException() instanceof SOAPException)
        throw (SOAPException)privilegedActionException.getException(); 
      throw new UndeclaredThrowableException(privilegedActionException.getException());
    } 
  }
  
  private static AuthenticatedSubject getKernelID() { return kernelID; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\servlet\ServletSecurityHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */