/*     */ package weblogic.webservice.server.servlet;
/*     */ 
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.management.ManagementException;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.security.SubjectUtils;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.security.service.SecurityServiceManager;
/*     */ import weblogic.servlet.internal.WebAppServletContext;
/*     */ import weblogic.utils.http.HttpParsing;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.dd.verify.VerifyException;
/*     */ import weblogic.webservice.monitoring.WSComponentRuntimeMBeanImpl;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ import weblogic.webservice.server.WebServiceContext;
/*     */ import weblogic.webservice.server.WebServiceManager;
/*     */ import weblogic.webservice.util.ServerSecurityHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServletSecurityHelper
/*     */ {
/*  43 */   private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private static String AUTHENTICATION_HEADER = "Authorization";
/*     */   
/*     */   private final WebAppServletContext servletCtx;
/*     */   private final String securityRealm;
/*     */   
/*     */   public ServletSecurityHelper(WebAppServletContext paramWebAppServletContext) {
/*  54 */     this.servletCtx = paramWebAppServletContext;
/*  55 */     this.securityRealm = this.servletCtx.getSecurityRealmName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AuthenticatedSubject getRequestSubject(HttpServletRequest paramHttpServletRequest, boolean paramBoolean) throws LoginException {
/*  65 */     AuthenticatedSubject authenticatedSubject = ServerSecurityHelper.getCurrentSubject();
/*     */     
/*  67 */     if (!SubjectUtils.isUserAnonymous(authenticatedSubject))
/*     */     {
/*  69 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  73 */     if (!paramBoolean) {
/*     */       
/*  75 */       String str = paramHttpServletRequest.getHeader(AUTHENTICATION_HEADER);
/*  76 */       if (str != null) {
/*  77 */         String[] arrayOfString = HttpParsing.getAuthInfo(str);
/*  78 */         if (arrayOfString == null) return null; 
/*  79 */         if (arrayOfString != null && arrayOfString[false] != null && arrayOfString[true] != null)
/*     */         {
/*     */ 
/*     */           
/*  83 */           return ServerSecurityHelper.assertIdentity(arrayOfString[0], arrayOfString[1], this.securityRealm);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  89 */     if (paramHttpServletRequest.isSecure()) {
/*     */ 
/*     */ 
/*     */       
/*  93 */       X509Certificate[] arrayOfX509Certificate = null;
/*     */       try {
/*  95 */         arrayOfX509Certificate = (X509Certificate[])paramHttpServletRequest.getAttribute("javax.servlet.request.X509Certificate");
/*  96 */       } catch (ClassCastException classCastException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       if (arrayOfX509Certificate != null && arrayOfX509Certificate.length > 0)
/*     */       {
/*     */         
/* 104 */         return ServerSecurityHelper.assertIdentity(arrayOfX509Certificate, this.securityRealm);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WebServiceContext createWebServiceContext(final WebServicesMBean wsMBean) throws ConfigException, VerifyException {
/*     */     try {
/* 123 */       return (WebServiceContext)SecurityServiceManager.runAs(kernelID, kernelID, new PrivilegedExceptionAction()
/*     */           {
/*     */             private final WebServicesMBean val$wsMBean;
/*     */             private final ServletSecurityHelper this$0;
/*     */             
/*     */             public Object run() throws ConfigException, VerifyException {
/* 129 */               return new WebServiceContext(wsMBean, ServletSecurityHelper.this.servletCtx);
/*     */             }
/*     */           });
/*     */     }
/* 133 */     catch (PrivilegedActionException privilegedActionException) {
/* 134 */       Exception exception = privilegedActionException.getException();
/* 135 */       if (exception instanceof VerifyException)
/* 136 */         throw (VerifyException)exception; 
/* 137 */       if (exception instanceof ConfigException) {
/* 138 */         throw (ConfigException)exception;
/*     */       }
/* 140 */       throw new UndeclaredThrowableException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unregisterRuntime(final WSComponentRuntimeMBeanImpl wm) throws PrivilegedActionException {
/* 158 */     SecurityServiceManager.runAs(kernelID, kernelID, new PrivilegedExceptionAction() {
/*     */           private final WSComponentRuntimeMBeanImpl val$wm;
/*     */           
/*     */           public Object run() throws ConfigException, VerifyException {
/*     */             try {
/* 163 */               wm.unregister();
/* 164 */             } catch (ManagementException managementException) {
/* 165 */               WebServiceLogger.logStackTrace(WebServiceLogger.logManagementException(managementException.toString()), managementException);
/*     */             } 
/*     */             
/* 168 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void authenticatedPortInvoke(AuthenticatedSubject paramAuthenticatedSubject, final String uri, final WebServiceManager manager, final Binding binding) throws SOAPException {
/*     */     try {
/* 180 */       SecurityServiceManager.runAs(getKernelID(), paramAuthenticatedSubject, new PrivilegedExceptionAction() { private final WebServiceManager val$manager;
/*     */             
/*     */             public Object run() throws ConfigException, VerifyException {
/* 183 */               manager.dispatch(uri, binding);
/* 184 */               return null;
/*     */             } private final String val$uri; private final Binding val$binding; }
/*     */         );
/* 187 */     } catch (PrivilegedActionException privilegedActionException) {
/* 188 */       if (privilegedActionException.getException() instanceof SOAPException) {
/* 189 */         throw (SOAPException)privilegedActionException.getException();
/*     */       }
/* 191 */       throw new UndeclaredThrowableException(privilegedActionException.getException());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   private static AuthenticatedSubject getKernelID() { return kernelID; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\servlet\ServletSecurityHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */