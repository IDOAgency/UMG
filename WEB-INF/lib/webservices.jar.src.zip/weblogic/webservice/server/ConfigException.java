package weblogic.webservice.server;

import weblogic.utils.NestedException;

public class ConfigException extends NestedException {
  public ConfigException(String paramString) { super(paramString); }
  
  public ConfigException(Throwable paramThrowable) { super(paramThrowable); }
  
  public ConfigException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\ConfigException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */