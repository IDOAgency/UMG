/*    */ package weblogic.webservice.server;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthorizationContext
/*    */ {
/*    */   private final String applicationName;
/*    */   private final String contextPath;
/*    */   private final String securityRealm;
/*    */   
/*    */   public AuthorizationContext(String paramString1, String paramString2, String paramString3) {
/* 14 */     this.applicationName = paramString1;
/* 15 */     this.contextPath = paramString2;
/* 16 */     this.securityRealm = paramString3;
/*    */   }
/*    */ 
/*    */   
/* 20 */   public final String getApplicationName() { return this.applicationName; }
/*    */ 
/*    */ 
/*    */   
/* 24 */   public final String getContextPath() { return this.contextPath; }
/*    */ 
/*    */ 
/*    */   
/* 28 */   public final String getSecurityRealm() { return this.securityRealm; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\AuthorizationContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */