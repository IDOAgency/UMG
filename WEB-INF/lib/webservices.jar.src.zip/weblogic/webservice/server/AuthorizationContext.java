package weblogic.webservice.server;

public final class AuthorizationContext {
  private final String applicationName;
  
  private final String contextPath;
  
  private final String securityRealm;
  
  public AuthorizationContext(String paramString1, String paramString2, String paramString3) {
    this.applicationName = paramString1;
    this.contextPath = paramString2;
    this.securityRealm = paramString3;
  }
  
  public final String getApplicationName() { return this.applicationName; }
  
  public final String getContextPath() { return this.contextPath; }
  
  public final String getSecurityRealm() { return this.securityRealm; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\AuthorizationContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */