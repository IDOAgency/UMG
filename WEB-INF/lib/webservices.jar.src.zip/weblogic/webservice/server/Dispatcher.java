/*     */ package weblogic.webservice.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.security.service.SecurityServiceManager;
/*     */ import weblogic.webservice.HandlerChain;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.binding.soap.HttpServerBinding;
/*     */ import weblogic.webservice.core.DefaultMessageContext;
/*     */ import weblogic.webservice.monitoring.OperationStats;
/*     */ import weblogic.webservice.monitoring.WebServiceStats;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dispatcher
/*     */ {
/*  42 */   private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_OPERATION = "_default";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatch(WebService paramWebService, Binding paramBinding) throws IOException {
/*  53 */     WebServiceStats webServiceStats = (paramWebService == null) ? null : paramWebService.getStats();
/*     */     
/*  55 */     long l1 = (webServiceStats == null) ? 0L : System.currentTimeMillis();
/*     */     
/*  57 */     DefaultMessageContext defaultMessageContext = null;
/*     */     
/*     */     try {
/*  60 */       defaultMessageContext = new DefaultMessageContext();
/*  61 */     } catch (SOAPException sOAPException) {
/*  62 */       throw new IOException("Internal Error: unable to create MessageContext" + sOAPException);
/*     */     } 
/*     */ 
/*     */     
/*  66 */     if (paramWebService != null) {
/*  67 */       initBindingInfo(paramWebService, paramBinding);
/*     */     }
/*     */     
/*  70 */     boolean bool = true;
/*     */     
/*     */     try {
/*  73 */       paramBinding.receive(defaultMessageContext);
/*  74 */     } catch (SOAPException sOAPException) {
/*  75 */       if (webServiceStats != null) webServiceStats.reportMalformedRequest(sOAPException); 
/*  76 */       setFault(defaultMessageContext, "Unable to parse the incoming request. Please make sure that the request is valid: " + sOAPException);
/*     */ 
/*     */       
/*  79 */       bool = false;
/*     */     } 
/*     */     
/*  82 */     if (bool && paramWebService == null) {
/*     */       
/*  84 */       setFault(defaultMessageContext, "No web service was found at this URL. Please check your URL and try again");
/*     */ 
/*     */       
/*  87 */       bool = false;
/*     */     } 
/*     */ 
/*     */     
/*  91 */     boolean bool1 = true;
/*     */     
/*  93 */     long l2 = System.currentTimeMillis();
/*     */     
/*  95 */     if (bool) {
/*     */       try {
/*  97 */         bool1 = doDispatch(paramWebService, paramBinding, defaultMessageContext);
/*  98 */       } catch (SOAPException sOAPException) {
/*  99 */         setFault(defaultMessageContext, "Internal Error: unable to process your request: " + sOAPException);
/*     */       } 
/*     */     }
/*     */     
/* 103 */     long l3 = System.currentTimeMillis();
/*     */     try {
/* 105 */       if (bool1) {
/* 106 */         paramBinding.send(defaultMessageContext);
/*     */       }
/* 108 */     } catch (SOAPException sOAPException) {
/* 109 */       Operation operation1 = defaultMessageContext.getOperation();
/* 110 */       if (operation1 != null) {
/* 111 */         OperationStats operationStats = operation1.getStats();
/* 112 */         if (operationStats != null) operationStats.reportResponseError(sOAPException); 
/*     */       } 
/* 114 */       throw new IOException("Failed to send response:" + sOAPException);
/*     */     } 
/*     */ 
/*     */     
/* 118 */     Operation operation = defaultMessageContext.getOperation();
/* 119 */     if (operation != null) {
/* 120 */       OperationStats operationStats = operation.getStats();
/* 121 */       if (operationStats != null) {
/* 122 */         operationStats.reportInvocation(l2 - l1, l3 - l2, System.currentTimeMillis() - l3);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean doDispatch(WebService paramWebService, Binding paramBinding, DefaultMessageContext paramDefaultMessageContext) throws SOAPException, IOException {
/* 140 */     boolean bool = true;
/*     */     
/* 142 */     HandlerChain handlerChain = paramWebService.getServerHandlerChain();
/*     */ 
/*     */     
/* 145 */     if (handlerChain != null) {
/* 146 */       paramDefaultMessageContext.setProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP", paramWebService);
/* 147 */       if (!handlerChain.handleRequest(paramDefaultMessageContext)) {
/*     */         
/* 149 */         handlerChain.handleResponse(paramDefaultMessageContext);
/* 150 */         return bool;
/*     */       } 
/* 152 */       paramDefaultMessageContext.removeProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP");
/*     */     } 
/*     */     
/* 155 */     SOAPBody sOAPBody = getBody(paramDefaultMessageContext);
/* 156 */     Operation operation = getOperation(paramWebService, sOAPBody);
/*     */     
/* 158 */     if (operation != null) {
/* 159 */       paramDefaultMessageContext.setOperation(operation);
/* 160 */       paramDefaultMessageContext.setProperty("__BEA_PRIVATE_BINDING_PROP", paramBinding);
/*     */ 
/*     */ 
/*     */       
/* 164 */       if (paramBinding instanceof HttpServerBinding) {
/* 165 */         HttpServerBinding httpServerBinding = (HttpServerBinding)paramBinding;
/* 166 */         paramDefaultMessageContext.setProperty("weblogic.webservice.transport.http.request", httpServerBinding.getRequest());
/* 167 */         paramDefaultMessageContext.setProperty("weblogic.webservice.transport.http.response", httpServerBinding.getResponse());
/*     */       } 
/*     */       
/* 170 */       if (operation.isOneway()) {
/* 171 */         paramBinding.send(paramDefaultMessageContext);
/* 172 */         bool = false;
/*     */       } 
/*     */       
/* 175 */       process(operation, paramDefaultMessageContext);
/*     */     } else {
/*     */       
/* 178 */       String str = "Unable to find a matching Operation for this remote invocation " + sOAPBody.getChildElements().next() + ".  Please check your operation name. ";
/*     */ 
/*     */       
/* 181 */       if (paramWebService.getStats() != null) {
/* 182 */         paramWebService.getStats().reportMalformedRequest(new SOAPException(str));
/*     */       }
/*     */       
/* 185 */       setFault(paramDefaultMessageContext, str);
/*     */     } 
/*     */     
/* 188 */     if (handlerChain != null) {
/* 189 */       handlerChain.handleResponse(paramDefaultMessageContext);
/*     */     }
/*     */     
/* 192 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void process(final Operation operation, final DefaultMessageContext context) throws SOAPException {
/* 200 */     AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)paramDefaultMessageContext.getProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP");
/*     */ 
/*     */     
/* 203 */     if (authenticatedSubject == null) {
/* 204 */       paramOperation.process(paramDefaultMessageContext);
/*     */     } else {
/* 206 */       paramDefaultMessageContext.removeProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP");
/*     */       
/* 208 */       PrivilegedExceptionAction privilegedExceptionAction = new PrivilegedExceptionAction() { private final Operation val$operation;
/*     */           
/*     */           public Object run() throws SOAPException, IOException {
/* 211 */             operation.process(context);
/* 212 */             return null;
/*     */           }
/*     */           private final DefaultMessageContext val$context; private final Dispatcher this$0; }
/*     */         ;
/*     */       try {
/* 217 */         SecurityServiceManager.runAs(getKernelID(), authenticatedSubject, privilegedExceptionAction);
/*     */       
/*     */       }
/* 220 */       catch (PrivilegedActionException privilegedActionException) {
/* 221 */         Exception exception = privilegedActionException.getException();
/* 222 */         if (exception instanceof SOAPException)
/* 223 */           throw (SOAPException)exception; 
/* 224 */         if (exception instanceof RuntimeException) {
/* 225 */           throw (RuntimeException)exception;
/*     */         }
/* 227 */         throw new UndeclaredThrowableException(exception);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static SOAPElement getFirstElement(Iterator paramIterator) {
/* 234 */     while (paramIterator.hasNext()) {
/* 235 */       Object object = paramIterator.next();
/*     */       
/* 237 */       if (object instanceof SOAPElement) {
/* 238 */         return (SOAPElement)object;
/*     */       }
/*     */     } 
/*     */     
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initBindingInfo(WebService paramWebService, Binding paramBinding) throws IOException {
/* 249 */     Iterator iterator = paramWebService.getPorts(); if (iterator.hasNext()) {
/* 250 */       Port port = (Port)iterator.next();
/* 251 */       paramBinding.init(port.getBindingInfo());
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setFault(DefaultMessageContext paramDefaultMessageContext, String paramString) throws IOException {
/*     */     try {
/* 260 */       SOAPMessage sOAPMessage = paramDefaultMessageContext.clearMessage();
/*     */       
/* 262 */       SOAPFault sOAPFault = sOAPMessage.getSOAPPart().getEnvelope().getBody().addFault();
/*     */ 
/*     */       
/* 265 */       sOAPFault.setFaultCode("Client");
/* 266 */       sOAPFault.setFaultString(paramString);
/* 267 */       paramDefaultMessageContext.setMessage(sOAPMessage);
/* 268 */     } catch (SOAPException sOAPException) {
/* 269 */       throw new IOException("Internal Error: failed to construct soap fault:" + sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   private static AuthenticatedSubject getKernelID() { return kernelID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Operation getOperation(WLMessageContext paramWLMessageContext) throws SOAPException {
/* 286 */     WebService webService = (WebService)paramWLMessageContext.getProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP");
/*     */ 
/*     */     
/* 289 */     return getOperation(webService, getBody(paramWLMessageContext));
/*     */   }
/*     */   private static Operation getOperation(WebService paramWebService, SOAPBody paramSOAPBody) {
/*     */     Operation operation;
/* 293 */     Iterator iterator = paramSOAPBody.getChildElements();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 300 */     SOAPElement sOAPElement = getFirstElement(iterator);
/*     */     
/* 302 */     if (sOAPElement != null) {
/* 303 */       operation = paramWebService.findOperation(sOAPElement);
/*     */     } else {
/* 305 */       operation = paramWebService.findOperation((SOAPElement)null);
/*     */     } 
/*     */     
/* 308 */     if (operation == null) {
/* 309 */       operation = paramWebService.findOperation("_default");
/*     */     }
/* 311 */     return operation;
/*     */   }
/*     */   
/*     */   private static SOAPBody getBody(SOAPMessageContext paramSOAPMessageContext) throws SOAPException {
/* 315 */     SOAPMessage sOAPMessage = paramSOAPMessageContext.getMessage();
/*     */     
/* 317 */     return sOAPMessage.getSOAPPart().getEnvelope().getBody();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\Dispatcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */