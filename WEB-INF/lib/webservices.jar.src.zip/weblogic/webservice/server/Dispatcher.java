package weblogic.webservice.server;

import java.io.IOException;
import java.lang.reflect.UndeclaredThrowableException;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Iterator;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.PrivilegedActions;
import weblogic.security.service.SecurityServiceManager;
import weblogic.webservice.HandlerChain;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebService;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.binding.soap.HttpServerBinding;
import weblogic.webservice.core.DefaultMessageContext;
import weblogic.webservice.monitoring.OperationStats;
import weblogic.webservice.monitoring.WebServiceStats;

public class Dispatcher {
  private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
  
  private static final String DEFAULT_OPERATION = "_default";
  
  public void dispatch(WebService paramWebService, Binding paramBinding) throws IOException {
    WebServiceStats webServiceStats = (paramWebService == null) ? null : paramWebService.getStats();
    long l1 = (webServiceStats == null) ? 0L : System.currentTimeMillis();
    DefaultMessageContext defaultMessageContext = null;
    try {
      defaultMessageContext = new DefaultMessageContext();
    } catch (SOAPException sOAPException) {
      throw new IOException("Internal Error: unable to create MessageContext" + sOAPException);
    } 
    if (paramWebService != null)
      initBindingInfo(paramWebService, paramBinding); 
    boolean bool = true;
    try {
      paramBinding.receive(defaultMessageContext);
    } catch (SOAPException sOAPException) {
      if (webServiceStats != null)
        webServiceStats.reportMalformedRequest(sOAPException); 
      setFault(defaultMessageContext, "Unable to parse the incoming request. Please make sure that the request is valid: " + sOAPException);
      bool = false;
    } 
    if (bool && paramWebService == null) {
      setFault(defaultMessageContext, "No web service was found at this URL. Please check your URL and try again");
      bool = false;
    } 
    boolean bool1 = true;
    long l2 = System.currentTimeMillis();
    if (bool)
      try {
        bool1 = doDispatch(paramWebService, paramBinding, defaultMessageContext);
      } catch (SOAPException sOAPException) {
        setFault(defaultMessageContext, "Internal Error: unable to process your request: " + sOAPException);
      }  
    long l3 = System.currentTimeMillis();
    try {
      if (bool1)
        paramBinding.send(defaultMessageContext); 
    } catch (SOAPException sOAPException) {
      Operation operation1 = defaultMessageContext.getOperation();
      if (operation1 != null) {
        OperationStats operationStats = operation1.getStats();
        if (operationStats != null)
          operationStats.reportResponseError(sOAPException); 
      } 
      throw new IOException("Failed to send response:" + sOAPException);
    } 
    Operation operation = defaultMessageContext.getOperation();
    if (operation != null) {
      OperationStats operationStats = operation.getStats();
      if (operationStats != null)
        operationStats.reportInvocation(l2 - l1, l3 - l2, System.currentTimeMillis() - l3); 
    } 
  }
  
  private boolean doDispatch(WebService paramWebService, Binding paramBinding, DefaultMessageContext paramDefaultMessageContext) throws SOAPException, IOException {
    boolean bool = true;
    HandlerChain handlerChain = paramWebService.getServerHandlerChain();
    if (handlerChain != null) {
      paramDefaultMessageContext.setProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP", paramWebService);
      if (!handlerChain.handleRequest(paramDefaultMessageContext)) {
        handlerChain.handleResponse(paramDefaultMessageContext);
        return bool;
      } 
      paramDefaultMessageContext.removeProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP");
    } 
    SOAPBody sOAPBody = getBody(paramDefaultMessageContext);
    Operation operation = getOperation(paramWebService, sOAPBody);
    if (operation != null) {
      paramDefaultMessageContext.setOperation(operation);
      paramDefaultMessageContext.setProperty("__BEA_PRIVATE_BINDING_PROP", paramBinding);
      if (paramBinding instanceof HttpServerBinding) {
        HttpServerBinding httpServerBinding = (HttpServerBinding)paramBinding;
        paramDefaultMessageContext.setProperty("weblogic.webservice.transport.http.request", httpServerBinding.getRequest());
        paramDefaultMessageContext.setProperty("weblogic.webservice.transport.http.response", httpServerBinding.getResponse());
      } 
      if (operation.isOneway()) {
        paramBinding.send(paramDefaultMessageContext);
        bool = false;
      } 
      process(operation, paramDefaultMessageContext);
    } else {
      String str = "Unable to find a matching Operation for this remote invocation " + sOAPBody.getChildElements().next() + ".  Please check your operation name. ";
      if (paramWebService.getStats() != null)
        paramWebService.getStats().reportMalformedRequest(new SOAPException(str)); 
      setFault(paramDefaultMessageContext, str);
    } 
    if (handlerChain != null)
      handlerChain.handleResponse(paramDefaultMessageContext); 
    return bool;
  }
  
  private void process(final Operation operation, final DefaultMessageContext context) throws SOAPException {
    AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)paramDefaultMessageContext.getProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP");
    if (authenticatedSubject == null) {
      paramOperation.process(paramDefaultMessageContext);
    } else {
      paramDefaultMessageContext.removeProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP");
      PrivilegedExceptionAction privilegedExceptionAction = new PrivilegedExceptionAction() {
          private final Operation val$operation;
          
          private final DefaultMessageContext val$context;
          
          private final Dispatcher this$0;
          
          public Object run() throws SOAPException, IOException {
            operation.process(context);
            return null;
          }
        };
      try {
        SecurityServiceManager.runAs(getKernelID(), authenticatedSubject, privilegedExceptionAction);
      } catch (PrivilegedActionException privilegedActionException) {
        Exception exception = privilegedActionException.getException();
        if (exception instanceof SOAPException)
          throw (SOAPException)exception; 
        if (exception instanceof RuntimeException)
          throw (RuntimeException)exception; 
        throw new UndeclaredThrowableException(exception);
      } 
    } 
  }
  
  private static SOAPElement getFirstElement(Iterator paramIterator) {
    while (paramIterator.hasNext()) {
      Object object = paramIterator.next();
      if (object instanceof SOAPElement)
        return (SOAPElement)object; 
    } 
    return null;
  }
  
  private void initBindingInfo(WebService paramWebService, Binding paramBinding) throws IOException {
    Iterator iterator = paramWebService.getPorts();
    if (iterator.hasNext()) {
      Port port = (Port)iterator.next();
      paramBinding.init(port.getBindingInfo());
      return;
    } 
  }
  
  private void setFault(DefaultMessageContext paramDefaultMessageContext, String paramString) throws IOException {
    try {
      SOAPMessage sOAPMessage = paramDefaultMessageContext.clearMessage();
      SOAPFault sOAPFault = sOAPMessage.getSOAPPart().getEnvelope().getBody().addFault();
      sOAPFault.setFaultCode("Client");
      sOAPFault.setFaultString(paramString);
      paramDefaultMessageContext.setMessage(sOAPMessage);
    } catch (SOAPException sOAPException) {
      throw new IOException("Internal Error: failed to construct soap fault:" + sOAPException);
    } 
  }
  
  private static AuthenticatedSubject getKernelID() { return kernelID; }
  
  public static Operation getOperation(WLMessageContext paramWLMessageContext) throws SOAPException {
    WebService webService = (WebService)paramWLMessageContext.getProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP");
    return getOperation(webService, getBody(paramWLMessageContext));
  }
  
  private static Operation getOperation(WebService paramWebService, SOAPBody paramSOAPBody) {
    Operation operation;
    Iterator iterator = paramSOAPBody.getChildElements();
    SOAPElement sOAPElement = getFirstElement(iterator);
    if (sOAPElement != null) {
      operation = paramWebService.findOperation(sOAPElement);
    } else {
      operation = paramWebService.findOperation((SOAPElement)null);
    } 
    if (operation == null)
      operation = paramWebService.findOperation("_default"); 
    return operation;
  }
  
  private static SOAPBody getBody(SOAPMessageContext paramSOAPMessageContext) throws SOAPException {
    SOAPMessage sOAPMessage = paramSOAPMessageContext.getMessage();
    return sOAPMessage.getSOAPPart().getEnvelope().getBody();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\Dispatcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */