/*     */ package weblogic.webservice.server;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.security.auth.Subject;
/*     */ import weblogic.security.service.ContextElement;
/*     */ import weblogic.security.service.ContextHandler;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.xml.security.SecurityAssertion;
/*     */ import weblogic.xml.security.assertion.IntegrityAssertion;
/*     */ import weblogic.xml.security.assertion.ServerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServiceContextHandler
/*     */   implements ContextHandler
/*     */ {
/*  28 */   public static final ContextHandler EMPTY_HANDLER = new WebServiceContextHandler(new String[0], new Object[0]);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DICTIONARY_PREFIX = "com.bea.contextelement.webservice.";
/*     */ 
/*     */   
/*     */   private final String[] names;
/*     */ 
/*     */   
/*     */   private final Object[] values;
/*     */ 
/*     */ 
/*     */   
/*     */   private WebServiceContextHandler(String[] paramArrayOfString, Object[] paramArrayOfObject) {
/*  43 */     this.names = paramArrayOfString;
/*  44 */     this.values = paramArrayOfObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public int size() { return this.values.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public String[] getNames() { return this.names; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getValue(String paramString) {
/*  81 */     for (byte b = 0; b < this.names.length; b++) {
/*  82 */       String str = this.names[b];
/*  83 */       if (str.equals(paramString)) {
/*  84 */         return this.values[b];
/*     */       }
/*     */     } 
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContextElement[] getValues(String[] paramArrayOfString) {
/* 108 */     ContextElement[] arrayOfContextElement = new ContextElement[paramArrayOfString.length];
/* 109 */     byte b1 = 0;
/* 110 */     for (byte b2 = 0; b2 < paramArrayOfString.length; b2++) {
/* 111 */       String str = paramArrayOfString[b2];
/* 112 */       for (byte b = 0; b < this.names.length; b++) {
/* 113 */         if (str.equals(this.names[b])) {
/* 114 */           arrayOfContextElement[b1++] = new ContextElement(str, this.values[b]);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     if (b1 < paramArrayOfString.length) {
/* 122 */       ContextElement[] arrayOfContextElement1 = arrayOfContextElement;
/* 123 */       arrayOfContextElement = new ContextElement[b1];
/* 124 */       System.arraycopy(arrayOfContextElement1, 0, arrayOfContextElement, 0, b1);
/*     */     } 
/* 126 */     return arrayOfContextElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final ContextHandler getContextHandler(WLMessageContext paramWLMessageContext) {
/* 138 */     ArrayList arrayList1 = new ArrayList();
/* 139 */     ArrayList arrayList2 = new ArrayList();
/*     */     
/* 141 */     getSecurityAssertions(paramWLMessageContext, arrayList1, arrayList2);
/*     */     
/* 143 */     getParameters(paramWLMessageContext, arrayList1, arrayList2);
/*     */     
/* 145 */     int i = arrayList1.size();
/* 146 */     if (i == 0) return EMPTY_HANDLER;
/*     */     
/* 148 */     String[] arrayOfString = new String[i];
/* 149 */     arrayOfString = (String[])arrayList1.toArray(arrayOfString);
/*     */     
/* 151 */     Object[] arrayOfObject = arrayList2.toArray();
/*     */     
/* 153 */     return new WebServiceContextHandler(arrayOfString, arrayOfObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void getParameters(WLMessageContext paramWLMessageContext, List paramList1, List paramList2) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void getSecurityAssertions(WLMessageContext paramWLMessageContext, List paramList1, List paramList2) {
/* 165 */     SecurityAssertion[] arrayOfSecurityAssertion = (SecurityAssertion[])paramWLMessageContext.getProperty("weblogic.webservice.security.assertions.request");
/*     */     
/* 167 */     if (arrayOfSecurityAssertion == null)
/*     */       return; 
/* 169 */     for (byte b = 0; b < arrayOfSecurityAssertion.length; b++) {
/* 170 */       Subject subject; String str; IntegrityAssertion integrityAssertion; SecurityAssertion securityAssertion = arrayOfSecurityAssertion[b];
/* 171 */       switch (securityAssertion.getAssertionTypeCode()) {
/*     */         case 1:
/*     */         case 2:
/* 174 */           integrityAssertion = (IntegrityAssertion)securityAssertion;
/* 175 */           str = integrityAssertion.getPolicyString();
/* 176 */           subject = ServerHelper.getSubject(integrityAssertion);
/* 177 */           paramList1.add("com.bea.contextelement.webservice." + str);
/* 178 */           paramList2.add(subject);
/* 179 */           paramList1.add(str);
/* 180 */           paramList2.add(subject);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WebServiceContextHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */