package weblogic.webservice.server;

import java.util.ArrayList;
import java.util.List;
import javax.security.auth.Subject;
import weblogic.security.service.ContextElement;
import weblogic.security.service.ContextHandler;
import weblogic.webservice.WLMessageContext;
import weblogic.xml.security.SecurityAssertion;
import weblogic.xml.security.assertion.IntegrityAssertion;
import weblogic.xml.security.assertion.ServerHelper;

public class WebServiceContextHandler implements ContextHandler {
  public static final ContextHandler EMPTY_HANDLER = new WebServiceContextHandler(new String[0], new Object[0]);
  
  private static final String DICTIONARY_PREFIX = "com.bea.contextelement.webservice.";
  
  private final String[] names;
  
  private final Object[] values;
  
  private WebServiceContextHandler(String[] paramArrayOfString, Object[] paramArrayOfObject) {
    this.names = paramArrayOfString;
    this.values = paramArrayOfObject;
  }
  
  public int size() { return this.values.length; }
  
  public String[] getNames() { return this.names; }
  
  public final Object getValue(String paramString) {
    for (byte b = 0; b < this.names.length; b++) {
      String str = this.names[b];
      if (str.equals(paramString))
        return this.values[b]; 
    } 
    return null;
  }
  
  public ContextElement[] getValues(String[] paramArrayOfString) {
    ContextElement[] arrayOfContextElement = new ContextElement[paramArrayOfString.length];
    byte b1 = 0;
    for (byte b2 = 0; b2 < paramArrayOfString.length; b2++) {
      String str = paramArrayOfString[b2];
      for (byte b = 0; b < this.names.length; b++) {
        if (str.equals(this.names[b])) {
          arrayOfContextElement[b1++] = new ContextElement(str, this.values[b]);
          break;
        } 
      } 
    } 
    if (b1 < paramArrayOfString.length) {
      ContextElement[] arrayOfContextElement1 = arrayOfContextElement;
      arrayOfContextElement = new ContextElement[b1];
      System.arraycopy(arrayOfContextElement1, 0, arrayOfContextElement, 0, b1);
    } 
    return arrayOfContextElement;
  }
  
  public static final ContextHandler getContextHandler(WLMessageContext paramWLMessageContext) {
    ArrayList arrayList1 = new ArrayList();
    ArrayList arrayList2 = new ArrayList();
    getSecurityAssertions(paramWLMessageContext, arrayList1, arrayList2);
    getParameters(paramWLMessageContext, arrayList1, arrayList2);
    int i = arrayList1.size();
    if (i == 0)
      return EMPTY_HANDLER; 
    String[] arrayOfString = new String[i];
    arrayOfString = (String[])arrayList1.toArray(arrayOfString);
    Object[] arrayOfObject = arrayList2.toArray();
    return new WebServiceContextHandler(arrayOfString, arrayOfObject);
  }
  
  private static void getParameters(WLMessageContext paramWLMessageContext, List paramList1, List paramList2) {}
  
  private static void getSecurityAssertions(WLMessageContext paramWLMessageContext, List paramList1, List paramList2) {
    SecurityAssertion[] arrayOfSecurityAssertion = (SecurityAssertion[])paramWLMessageContext.getProperty("weblogic.webservice.security.assertions.request");
    if (arrayOfSecurityAssertion == null)
      return; 
    for (byte b = 0; b < arrayOfSecurityAssertion.length; b++) {
      Subject subject;
      String str;
      IntegrityAssertion integrityAssertion;
      SecurityAssertion securityAssertion = arrayOfSecurityAssertion[b];
      switch (securityAssertion.getAssertionTypeCode()) {
        case 1:
        case 2:
          integrityAssertion = (IntegrityAssertion)securityAssertion;
          str = integrityAssertion.getPolicyString();
          subject = ServerHelper.getSubject(integrityAssertion);
          paramList1.add("com.bea.contextelement.webservice." + str);
          paramList2.add(subject);
          paramList1.add(str);
          paramList2.add(subject);
          break;
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WebServiceContextHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */