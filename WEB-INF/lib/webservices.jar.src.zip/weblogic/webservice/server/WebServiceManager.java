/*     */ package weblogic.webservice.server;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import javax.jms.JMSException;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.server.jms.JMSListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServiceManager
/*     */ {
/*  27 */   private HashMap webServices = new HashMap();
/*  28 */   private Dispatcher dispatcher = new Dispatcher();
/*     */   
/*  30 */   private HashMap jmsListeners = new HashMap();
/*     */ 
/*     */ 
/*     */   
/*     */   private String contextPath;
/*     */ 
/*     */ 
/*     */   
/*  38 */   public static WebServiceManager newInstance() { return new WebServiceManager(); }
/*     */ 
/*     */   
/*     */   public void register(String paramString, WebService paramWebService) {
/*  42 */     BindingInfo bindingInfo = getJmsUri(paramWebService);
/*     */ 
/*     */ 
/*     */     
/*  46 */     this.webServices.put(paramString, paramWebService);
/*     */     
/*  48 */     if (bindingInfo != null) {
/*  49 */       this.jmsListeners.put(bindingInfo.getAddress(), new JMSListener(bindingInfo, paramString, this));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  55 */   public WebService getWebService(String paramString) { return (WebService)this.webServices.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  59 */   public void setContextPath(String paramString) { this.contextPath = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  63 */   public String getContextPath() { return this.contextPath; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  68 */     for (WebService webService : this.webServices.values())
/*     */     {
/*  70 */       webService.destroy();
/*     */     }
/*     */     
/*  73 */     this.webServices.clear();
/*     */     
/*  75 */     for (JMSListener jMSListener : this.jmsListeners.values()) {
/*     */       
/*     */       try {
/*  78 */         jMSListener.close();
/*  79 */       } catch (JMSException jMSException) {
/*  80 */         String str = WebServiceLogger.logJMSCloseListenerException();
/*  81 */         WebServiceLogger.logStackTrace(str, jMSException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private BindingInfo getJmsUri(WebService paramWebService) {
/*  88 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/*  89 */       Port port = (Port)iterator.next();
/*     */       
/*  91 */       if (port.getBindingInfo() instanceof weblogic.webservice.binding.jms.JMSBindingInfo) {
/*  92 */         return port.getBindingInfo();
/*     */       }
/*     */     } 
/*     */     
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   public void dispatch(String paramString, Binding paramBinding) throws IOException {
/* 100 */     WebService webService = getWebService(paramString);
/* 101 */     this.dispatcher.dispatch(webService, paramBinding);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WebServiceManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */