package weblogic.webservice.server;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import javax.jms.JMSException;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.server.jms.JMSListener;

public class WebServiceManager {
  private HashMap webServices = new HashMap();
  
  private Dispatcher dispatcher = new Dispatcher();
  
  private HashMap jmsListeners = new HashMap();
  
  private String contextPath;
  
  public static WebServiceManager newInstance() { return new WebServiceManager(); }
  
  public void register(String paramString, WebService paramWebService) {
    BindingInfo bindingInfo = getJmsUri(paramWebService);
    this.webServices.put(paramString, paramWebService);
    if (bindingInfo != null)
      this.jmsListeners.put(bindingInfo.getAddress(), new JMSListener(bindingInfo, paramString, this)); 
  }
  
  public WebService getWebService(String paramString) { return (WebService)this.webServices.get(paramString); }
  
  public void setContextPath(String paramString) { this.contextPath = paramString; }
  
  public String getContextPath() { return this.contextPath; }
  
  public void destroy() {
    for (WebService webService : this.webServices.values())
      webService.destroy(); 
    this.webServices.clear();
    for (JMSListener jMSListener : this.jmsListeners.values()) {
      try {
        jMSListener.close();
      } catch (JMSException jMSException) {
        String str = WebServiceLogger.logJMSCloseListenerException();
        WebServiceLogger.logStackTrace(str, jMSException);
      } 
    } 
  }
  
  private BindingInfo getJmsUri(WebService paramWebService) {
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      if (port.getBindingInfo() instanceof weblogic.webservice.binding.jms.JMSBindingInfo)
        return port.getBindingInfo(); 
    } 
    return null;
  }
  
  public void dispatch(String paramString, Binding paramBinding) throws IOException {
    WebService webService = getWebService(paramString);
    this.dispatcher.dispatch(webService, paramBinding);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WebServiceManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */