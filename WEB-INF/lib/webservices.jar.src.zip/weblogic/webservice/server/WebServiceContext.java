/*     */ package weblogic.webservice.server;
/*     */ 
/*     */ import java.security.PrivilegedActionException;
/*     */ import weblogic.management.configuration.WebServiceComponentMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.management.runtime.RuntimeMBean;
/*     */ import weblogic.servlet.internal.WebAppServletContext;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.dd.verify.DDVerifierFactory;
/*     */ import weblogic.webservice.dd.verify.VerifyException;
/*     */ import weblogic.webservice.monitoring.WSComponentRuntimeMBeanImpl;
/*     */ import weblogic.webservice.server.servlet.ServletSecurityHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServiceContext
/*     */ {
/*  44 */   private static boolean debug = Boolean.getBoolean("weblogic.webservice.verbose");
/*     */   
/*     */   private WebServicesMBean mbean;
/*     */   
/*     */   private WebAppServletContext webappctx;
/*     */   
/*     */   private WebServiceManager manager;
/*     */   private WSComponentRuntimeMBeanImpl runtime;
/*     */   
/*  53 */   public WebServiceManager getManager() { return this.manager; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceContext(WebServicesMBean paramWebServicesMBean, WebAppServletContext paramWebAppServletContext) throws ConfigException, VerifyException {
/*     */     this.manager = WebServiceManager.newInstance();
/*  64 */     this.mbean = paramWebServicesMBean;
/*  65 */     this.webappctx = paramWebAppServletContext;
/*     */     
/*  67 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     DDVerifierFactory.newVerifier(classLoader).verify(paramWebServicesMBean);
/*     */     
/*  74 */     WebServiceMBean[] arrayOfWebServiceMBean = paramWebServicesMBean.getWebServices();
/*  75 */     if (arrayOfWebServiceMBean == null || arrayOfWebServiceMBean.length == 0) {
/*     */ 
/*     */       
/*  78 */       System.err.println("No WebServices in WebServicesMBean!");
/*     */       return;
/*     */     } 
/*  81 */     String str = paramWebAppServletContext.getContextPath();
/*  82 */     this.manager.setContextPath(str);
/*  83 */     AuthorizationContext authorizationContext = new AuthorizationContext(paramWebAppServletContext.getApplicationId(), str, paramWebAppServletContext.getSecurityRealmName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     WebService[] arrayOfWebService = new WebService[arrayOfWebServiceMBean.length]; byte b;
/*  90 */     for (b = 0; b < arrayOfWebServiceMBean.length; b++) {
/*     */ 
/*     */       
/*  93 */       WebServiceFactory webServiceFactory = WebServiceFactory.newFactoryInstance();
/*  94 */       arrayOfWebService[b] = webServiceFactory.createFromMBean(arrayOfWebServiceMBean[b], authorizationContext);
/*     */     } 
/*     */     
/*  97 */     for (b = 0; b < arrayOfWebService.length; b++) {
/*  98 */       String str1 = arrayOfWebServiceMBean[b].getURI();
/*  99 */       paramWebAppServletContext.registerServletMap("WebServiceServlet", str1);
/* 100 */       registerWebService(str1, arrayOfWebService[b]);
/* 101 */       if (debug) {
/* 102 */         System.out.println("Registering WS [" + arrayOfWebService[b].getName() + "] at context: '" + paramWebAppServletContext.getContextPath() + "' URI: '" + str1 + "'");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     if (paramWebAppServletContext.getMBean() instanceof WebServiceComponentMBean) {
/* 111 */       WebServiceComponentMBean webServiceComponentMBean = (WebServiceComponentMBean)paramWebAppServletContext.getMBean();
/*     */       
/* 113 */       this.runtime = WSComponentRuntimeMBeanImpl.create(webServiceComponentMBean, str, (RuntimeMBean)paramWebAppServletContext.getRuntimeMBean().getParent(), arrayOfWebServiceMBean, arrayOfWebService);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerWebService(String paramString, WebService paramWebService) {
/* 132 */     if (!paramString.startsWith("/")) {
/* 133 */       paramString = "/" + paramString;
/*     */     }
/*     */     
/* 136 */     this.manager.register(paramString, paramWebService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebService getWebService(String paramString) {
/* 150 */     WebService webService = null;
/*     */     
/* 152 */     if (paramString != null) {
/* 153 */       webService = this.manager.getWebService(paramString);
/*     */     }
/*     */     
/* 156 */     if (debug) {
/* 157 */       System.out.println("Got a Web Service Request at URL: '" + paramString + "' for web service '" + ((webService == null) ? null : webService.getName()) + "'");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 162 */     return webService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public WebServicesMBean getWebServicesMBean() { return this.mbean; }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 188 */     this.manager.destroy();
/* 189 */     if (this.runtime != null)
/*     */       
/*     */       try {
/* 192 */         ServletSecurityHelper.unregisterRuntime(this.runtime);
/*     */       }
/* 194 */       catch (PrivilegedActionException privilegedActionException) {} 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WebServiceContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */