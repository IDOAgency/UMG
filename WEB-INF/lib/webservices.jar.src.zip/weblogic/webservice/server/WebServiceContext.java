package weblogic.webservice.server;

import java.security.PrivilegedActionException;
import weblogic.management.configuration.WebServiceComponentMBean;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.management.runtime.RuntimeMBean;
import weblogic.servlet.internal.WebAppServletContext;
import weblogic.webservice.WebService;
import weblogic.webservice.dd.verify.DDVerifierFactory;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.monitoring.WSComponentRuntimeMBeanImpl;
import weblogic.webservice.server.servlet.ServletSecurityHelper;

public class WebServiceContext {
  private static boolean debug = Boolean.getBoolean("weblogic.webservice.verbose");
  
  private WebServicesMBean mbean;
  
  private WebAppServletContext webappctx;
  
  private WebServiceManager manager;
  
  private WSComponentRuntimeMBeanImpl runtime;
  
  public WebServiceManager getManager() { return this.manager; }
  
  public WebServiceContext(WebServicesMBean paramWebServicesMBean, WebAppServletContext paramWebAppServletContext) throws ConfigException, VerifyException {
    this.manager = WebServiceManager.newInstance();
    this.mbean = paramWebServicesMBean;
    this.webappctx = paramWebAppServletContext;
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    DDVerifierFactory.newVerifier(classLoader).verify(paramWebServicesMBean);
    WebServiceMBean[] arrayOfWebServiceMBean = paramWebServicesMBean.getWebServices();
    if (arrayOfWebServiceMBean == null || arrayOfWebServiceMBean.length == 0) {
      System.err.println("No WebServices in WebServicesMBean!");
      return;
    } 
    String str = paramWebAppServletContext.getContextPath();
    this.manager.setContextPath(str);
    AuthorizationContext authorizationContext = new AuthorizationContext(paramWebAppServletContext.getApplicationId(), str, paramWebAppServletContext.getSecurityRealmName());
    WebService[] arrayOfWebService = new WebService[arrayOfWebServiceMBean.length];
    byte b;
    for (b = 0; b < arrayOfWebServiceMBean.length; b++) {
      WebServiceFactory webServiceFactory = WebServiceFactory.newFactoryInstance();
      arrayOfWebService[b] = webServiceFactory.createFromMBean(arrayOfWebServiceMBean[b], authorizationContext);
    } 
    for (b = 0; b < arrayOfWebService.length; b++) {
      String str1 = arrayOfWebServiceMBean[b].getURI();
      paramWebAppServletContext.registerServletMap("WebServiceServlet", str1);
      registerWebService(str1, arrayOfWebService[b]);
      if (debug)
        System.out.println("Registering WS [" + arrayOfWebService[b].getName() + "] at context: '" + paramWebAppServletContext.getContextPath() + "' URI: '" + str1 + "'"); 
    } 
    if (paramWebAppServletContext.getMBean() instanceof WebServiceComponentMBean) {
      WebServiceComponentMBean webServiceComponentMBean = (WebServiceComponentMBean)paramWebAppServletContext.getMBean();
      this.runtime = WSComponentRuntimeMBeanImpl.create(webServiceComponentMBean, str, (RuntimeMBean)paramWebAppServletContext.getRuntimeMBean().getParent(), arrayOfWebServiceMBean, arrayOfWebService);
    } 
  }
  
  public void registerWebService(String paramString, WebService paramWebService) {
    if (!paramString.startsWith("/"))
      paramString = "/" + paramString; 
    this.manager.register(paramString, paramWebService);
  }
  
  public WebService getWebService(String paramString) {
    WebService webService = null;
    if (paramString != null)
      webService = this.manager.getWebService(paramString); 
    if (debug)
      System.out.println("Got a Web Service Request at URL: '" + paramString + "' for web service '" + ((webService == null) ? null : webService.getName()) + "'"); 
    return webService;
  }
  
  public WebServicesMBean getWebServicesMBean() { return this.mbean; }
  
  public void destroy() {
    this.manager.destroy();
    if (this.runtime != null)
      try {
        ServletSecurityHelper.unregisterRuntime(this.runtime);
      } catch (PrivilegedActionException privilegedActionException) {} 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WebServiceContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */