/*     */ package weblogic.webservice.server;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.AuthorizationManager;
/*     */ import weblogic.security.service.ContextHandler;
/*     */ import weblogic.security.service.WebServiceResource;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.util.ServerSecurityHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WLAuthorizer
/*     */   implements Authorizer
/*     */ {
/*     */   private final ResourceMap resourceMap;
/*     */   private AuthorizationManager am;
/*     */   private AuthorizationContext authContext;
/*     */   private static final String VERBOSE_PROPERTY = "weblogic.webservice.security.verbose";
/*     */   private static final String DEBUG_PROPERTY = "weblogic.webservice.security.debug";
/*  42 */   private static final boolean DEBUG = Boolean.getBoolean("weblogic.webservice.security.debug");
/*  43 */   private static final boolean VERBOSE = Boolean.getBoolean("weblogic.webservice.security.verbose");
/*     */   public WLAuthorizer(AuthorizationContext paramAuthorizationContext) {
/*     */     this.resourceMap = new ResourceMap();
/*  46 */     this.authContext = paramAuthorizationContext;
/*  47 */     this.am = ServerSecurityHelper.getAuthManager(paramAuthorizationContext.getSecurityRealm());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccessAllowed(Operation paramOperation, WLMessageContext paramWLMessageContext) {
/*  59 */     AuthenticatedSubject authenticatedSubject = ServerSecurityHelper.getCurrentSubject();
/*  60 */     WebServiceResource webServiceResource = getResource(paramOperation);
/*  61 */     ContextHandler contextHandler = getContextHandler(paramWLMessageContext);
/*     */     
/*  63 */     if (VERBOSE) {
/*  64 */       Debug.say("** Authorizer got Operation " + paramOperation.getName() + " and user " + authenticatedSubject);
/*     */       
/*  66 */       Debug.say("** Authorizer using Resource " + webServiceResource);
/*     */     } 
/*     */     
/*  69 */     if (DEBUG) {
/*  70 */       Debug.assertion((webServiceResource != null), "Failed to retrieve Resource for Operation " + paramOperation);
/*     */       
/*  72 */       Debug.assertion((authenticatedSubject != null), "Failed to retrieve subject for invoke");
/*     */     } 
/*     */     
/*  75 */     boolean bool = this.am.isAccessAllowed(authenticatedSubject, webServiceResource, contextHandler);
/*     */     
/*  77 */     if (VERBOSE) {
/*  78 */       if (bool) { Debug.say("** Access granted for subject " + authenticatedSubject + " to Resource " + webServiceResource); }
/*     */       else
/*  80 */       { Debug.say("** Access denied for subject " + authenticatedSubject + " to Resource " + webServiceResource); }
/*     */     
/*     */     }
/*     */     
/*  84 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static ContextHandler getContextHandler(WLMessageContext paramWLMessageContext) {
/*  90 */     if (paramWLMessageContext == null) return WebServiceContextHandler.EMPTY_HANDLER; 
/*  91 */     return WebServiceContextHandler.getContextHandler(paramWLMessageContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceResource getResource(Operation paramOperation) {
/*  97 */     WebServiceResource webServiceResource = lookupResource(paramOperation);
/*     */     
/*  99 */     if (webServiceResource == null)
/* 100 */     { if (VERBOSE) Debug.say("** Missed on cache for Operation " + paramOperation.getName()); 
/* 101 */       webServiceResource = createResource(paramOperation);
/* 102 */       cacheResource(paramOperation, webServiceResource);
/*     */        }
/*     */     
/* 105 */     else if (VERBOSE) { Debug.say("** Cache hit for Operation " + paramOperation.getName()); }
/*     */     
/* 107 */     return webServiceResource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 112 */   private WebServiceResource lookupResource(Operation paramOperation) { return this.resourceMap.get(paramOperation); }
/*     */ 
/*     */ 
/*     */   
/*     */   private WebServiceResource cacheResource(Operation paramOperation, WebServiceResource paramWebServiceResource) {
/* 117 */     this.resourceMap.put(paramOperation, paramWebServiceResource);
/* 118 */     return paramWebServiceResource;
/*     */   }
/*     */ 
/*     */   
/*     */   private WebServiceResource createResource(Operation paramOperation) {
/* 123 */     if (VERBOSE) Debug.say("** Creating resource for " + paramOperation.getName());
/*     */ 
/*     */     
/* 126 */     String str1 = null;
/*     */ 
/*     */     
/* 129 */     String[] arrayOfString1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     String[] arrayOfString2 = null;
/*     */     
/* 137 */     if (DEBUG) Debug.assertion((paramOperation != null), "Operation provided WLAuthorizer was null");
/*     */ 
/*     */     
/* 140 */     str1 = paramOperation.getName();
/*     */     
/* 142 */     ArrayList arrayList1 = new ArrayList();
/* 143 */     ArrayList arrayList2 = new ArrayList();
/*     */ 
/*     */     
/* 146 */     Message message = paramOperation.getInput();
/*     */     
/* 148 */     if (message != null) {
/*     */       
/* 150 */       Iterator iterator = message.getParts();
/* 151 */       byte b = 0;
/*     */       
/* 153 */       while (iterator.hasNext()) {
/* 154 */         Part part = (Part)iterator.next();
/*     */         
/* 156 */         String str3 = part.getJavaType().getName();
/* 157 */         if (str3 == null) str3 = "undefined"; 
/* 158 */         arrayList2.add(str3);
/*     */         
/* 160 */         String str4 = part.getName();
/* 161 */         if (str4 == null) str4 = "param" + b; 
/* 162 */         arrayList1.add(str4);
/*     */         
/* 164 */         b++;
/*     */         
/* 166 */         if (VERBOSE) {
/* 167 */           Debug.say("**  added param type " + str3);
/* 168 */           Debug.say("**  added param name " + str4);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 174 */     int i = arrayList2.size();
/*     */     
/* 176 */     arrayOfString1 = new String[i];
/* 177 */     arrayList2.toArray(arrayOfString1);
/*     */     
/* 179 */     arrayOfString2 = new String[i];
/* 180 */     arrayList1.toArray(arrayOfString2);
/*     */     
/* 182 */     WebServiceResource webServiceResource = null;
/*     */     
/* 184 */     if (VERBOSE) {
/* 185 */       Debug.say("** Args to WebServiceResource");
/* 186 */       Debug.say("**   methodName = " + str1);
/* 187 */       Debug.say("**   methodParams = " + arrayOfString1);
/* 188 */       Debug.say("**   paramNames = " + arrayOfString2);
/*     */     } 
/*     */     
/* 191 */     String str2 = paramOperation.getPort().getService().getName();
/*     */     
/* 193 */     webServiceResource = new WebServiceResource(this.authContext.getApplicationName(), this.authContext.getContextPath(), str2, str1, arrayOfString1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     if (DEBUG) Debug.assertion((webServiceResource != null), "Failed to create WebServiceResource for " + str1);
/*     */ 
/*     */ 
/*     */     
/* 203 */     if (VERBOSE) Debug.say("** Created resource " + webServiceResource);
/*     */     
/* 205 */     return webServiceResource;
/*     */   }
/*     */   
/*     */   protected static class ResourceMap { private Map resourceMap;
/*     */     
/*     */     protected ResourceMap() {
/* 211 */       this.resourceMap = null;
/*     */ 
/*     */       
/* 214 */       this.resourceMap = Collections.synchronizedMap(new HashMap());
/*     */     }
/*     */     
/*     */     protected WebServiceResource get(Operation param1Operation) {
/* 218 */       if (DEBUG) Debug.assertion((param1Operation != null), "WebServiceResource lookup got a null operation");
/*     */       
/* 220 */       return (WebServiceResource)this.resourceMap.get(param1Operation);
/*     */     }
/*     */ 
/*     */     
/*     */     protected WebServiceResource put(Operation param1Operation, WebServiceResource param1WebServiceResource) {
/* 225 */       if (DEBUG) {
/* 226 */         Debug.assertion((param1WebServiceResource != null), "WebServiceResource cache got a null resource");
/*     */         
/* 228 */         Debug.assertion((param1Operation != null), "WebServiceResource cache got a null operation");
/*     */       } 
/*     */ 
/*     */       
/* 232 */       this.resourceMap.put(param1Operation, param1WebServiceResource);
/* 233 */       return param1WebServiceResource;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WLAuthorizer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */