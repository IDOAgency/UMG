package weblogic.webservice.server;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.AuthorizationManager;
import weblogic.security.service.ContextHandler;
import weblogic.security.service.WebServiceResource;
import weblogic.utils.Debug;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.util.ServerSecurityHelper;

public class WLAuthorizer implements Authorizer {
  private final ResourceMap resourceMap;
  
  private AuthorizationManager am;
  
  private AuthorizationContext authContext;
  
  private static final String VERBOSE_PROPERTY = "weblogic.webservice.security.verbose";
  
  private static final String DEBUG_PROPERTY = "weblogic.webservice.security.debug";
  
  private static final boolean DEBUG = Boolean.getBoolean("weblogic.webservice.security.debug");
  
  private static final boolean VERBOSE = Boolean.getBoolean("weblogic.webservice.security.verbose");
  
  public WLAuthorizer(AuthorizationContext paramAuthorizationContext) {
    this.resourceMap = new ResourceMap();
    this.authContext = paramAuthorizationContext;
    this.am = ServerSecurityHelper.getAuthManager(paramAuthorizationContext.getSecurityRealm());
  }
  
  public boolean isAccessAllowed(Operation paramOperation, WLMessageContext paramWLMessageContext) {
    AuthenticatedSubject authenticatedSubject = ServerSecurityHelper.getCurrentSubject();
    WebServiceResource webServiceResource = getResource(paramOperation);
    ContextHandler contextHandler = getContextHandler(paramWLMessageContext);
    if (VERBOSE) {
      Debug.say("** Authorizer got Operation " + paramOperation.getName() + " and user " + authenticatedSubject);
      Debug.say("** Authorizer using Resource " + webServiceResource);
    } 
    if (DEBUG) {
      Debug.assertion((webServiceResource != null), "Failed to retrieve Resource for Operation " + paramOperation);
      Debug.assertion((authenticatedSubject != null), "Failed to retrieve subject for invoke");
    } 
    boolean bool = this.am.isAccessAllowed(authenticatedSubject, webServiceResource, contextHandler);
    if (VERBOSE)
      if (bool) {
        Debug.say("** Access granted for subject " + authenticatedSubject + " to Resource " + webServiceResource);
      } else {
        Debug.say("** Access denied for subject " + authenticatedSubject + " to Resource " + webServiceResource);
      }  
    return bool;
  }
  
  private static ContextHandler getContextHandler(WLMessageContext paramWLMessageContext) {
    if (paramWLMessageContext == null)
      return WebServiceContextHandler.EMPTY_HANDLER; 
    return WebServiceContextHandler.getContextHandler(paramWLMessageContext);
  }
  
  public WebServiceResource getResource(Operation paramOperation) {
    WebServiceResource webServiceResource = lookupResource(paramOperation);
    if (webServiceResource == null) {
      if (VERBOSE)
        Debug.say("** Missed on cache for Operation " + paramOperation.getName()); 
      webServiceResource = createResource(paramOperation);
      cacheResource(paramOperation, webServiceResource);
    } else if (VERBOSE) {
      Debug.say("** Cache hit for Operation " + paramOperation.getName());
    } 
    return webServiceResource;
  }
  
  private WebServiceResource lookupResource(Operation paramOperation) { return this.resourceMap.get(paramOperation); }
  
  private WebServiceResource cacheResource(Operation paramOperation, WebServiceResource paramWebServiceResource) {
    this.resourceMap.put(paramOperation, paramWebServiceResource);
    return paramWebServiceResource;
  }
  
  private WebServiceResource createResource(Operation paramOperation) {
    if (VERBOSE)
      Debug.say("** Creating resource for " + paramOperation.getName()); 
    String str1 = null;
    String[] arrayOfString1 = null;
    String[] arrayOfString2 = null;
    if (DEBUG)
      Debug.assertion((paramOperation != null), "Operation provided WLAuthorizer was null"); 
    str1 = paramOperation.getName();
    ArrayList arrayList1 = new ArrayList();
    ArrayList arrayList2 = new ArrayList();
    Message message = paramOperation.getInput();
    if (message != null) {
      Iterator iterator = message.getParts();
      byte b = 0;
      while (iterator.hasNext()) {
        Part part = (Part)iterator.next();
        String str3 = part.getJavaType().getName();
        if (str3 == null)
          str3 = "undefined"; 
        arrayList2.add(str3);
        String str4 = part.getName();
        if (str4 == null)
          str4 = "param" + b; 
        arrayList1.add(str4);
        b++;
        if (VERBOSE) {
          Debug.say("**  added param type " + str3);
          Debug.say("**  added param name " + str4);
        } 
      } 
    } 
    int i = arrayList2.size();
    arrayOfString1 = new String[i];
    arrayList2.toArray(arrayOfString1);
    arrayOfString2 = new String[i];
    arrayList1.toArray(arrayOfString2);
    WebServiceResource webServiceResource = null;
    if (VERBOSE) {
      Debug.say("** Args to WebServiceResource");
      Debug.say("**   methodName = " + str1);
      Debug.say("**   methodParams = " + arrayOfString1);
      Debug.say("**   paramNames = " + arrayOfString2);
    } 
    String str2 = paramOperation.getPort().getService().getName();
    webServiceResource = new WebServiceResource(this.authContext.getApplicationName(), this.authContext.getContextPath(), str2, str1, arrayOfString1);
    if (DEBUG)
      Debug.assertion((webServiceResource != null), "Failed to create WebServiceResource for " + str1); 
    if (VERBOSE)
      Debug.say("** Created resource " + webServiceResource); 
    return webServiceResource;
  }
  
  protected static class ResourceMap {
    private Map resourceMap;
    
    protected ResourceMap() {
      this.resourceMap = null;
      this.resourceMap = Collections.synchronizedMap(new HashMap());
    }
    
    protected WebServiceResource get(Operation param1Operation) {
      if (DEBUG)
        Debug.assertion((param1Operation != null), "WebServiceResource lookup got a null operation"); 
      return (WebServiceResource)this.resourceMap.get(param1Operation);
    }
    
    protected WebServiceResource put(Operation param1Operation, WebServiceResource param1WebServiceResource) {
      if (DEBUG) {
        Debug.assertion((param1WebServiceResource != null), "WebServiceResource cache got a null resource");
        Debug.assertion((param1Operation != null), "WebServiceResource cache got a null operation");
      } 
      this.resourceMap.put(param1Operation, param1WebServiceResource);
      return param1WebServiceResource;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WLAuthorizer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */