/*      */ package weblogic.webservice.server;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.naming.NamingException;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.rpc.JAXRPCException;
/*      */ import javax.xml.rpc.encoding.TypeMapping;
/*      */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*      */ import javax.xml.rpc.handler.HandlerInfo;
/*      */ import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;
/*      */ import weblogic.management.descriptors.webservice.ComponentsMBean;
/*      */ import weblogic.management.descriptors.webservice.FaultMBean;
/*      */ import weblogic.management.descriptors.webservice.HandlerChainMBean;
/*      */ import weblogic.management.descriptors.webservice.HandlerMBean;
/*      */ import weblogic.management.descriptors.webservice.InitParamMBean;
/*      */ import weblogic.management.descriptors.webservice.InitParamsMBean;
/*      */ import weblogic.management.descriptors.webservice.JMSReceiveQueueMBean;
/*      */ import weblogic.management.descriptors.webservice.JMSReceiveTopicMBean;
/*      */ import weblogic.management.descriptors.webservice.JMSSendDestinationMBean;
/*      */ import weblogic.management.descriptors.webservice.JavaClassMBean;
/*      */ import weblogic.management.descriptors.webservice.OperationMBean;
/*      */ import weblogic.management.descriptors.webservice.OperationsMBean;
/*      */ import weblogic.management.descriptors.webservice.ParamMBean;
/*      */ import weblogic.management.descriptors.webservice.ParamsMBean;
/*      */ import weblogic.management.descriptors.webservice.ReliableDeliveryMBean;
/*      */ import weblogic.management.descriptors.webservice.ReturnParamMBean;
/*      */ import weblogic.management.descriptors.webservice.StatefulJavaClassMBean;
/*      */ import weblogic.management.descriptors.webservice.StatelessEJBMBean;
/*      */ import weblogic.management.descriptors.webservice.TypeMappingEntryMBean;
/*      */ import weblogic.management.descriptors.webservice.TypeMappingMBean;
/*      */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*      */ import weblogic.utils.AssertionError;
/*      */ import weblogic.utils.reflect.ReflectUtils;
/*      */ import weblogic.webservice.InvocationHandler;
/*      */ import weblogic.webservice.Message;
/*      */ import weblogic.webservice.Operation;
/*      */ import weblogic.webservice.Part;
/*      */ import weblogic.webservice.Port;
/*      */ import weblogic.webservice.WSServerService;
/*      */ import weblogic.webservice.WebService;
/*      */ import weblogic.webservice.WebServiceFactory;
/*      */ import weblogic.webservice.WebServiceLogger;
/*      */ import weblogic.webservice.binding.jms.JMSBindingInfo;
/*      */ import weblogic.webservice.component.javaclass.JavaClassInvocationHandler;
/*      */ import weblogic.webservice.component.javaclass.StatefulInvocationHandler;
/*      */ import weblogic.webservice.component.jms.JMSQueueReceiveInvocationHandler;
/*      */ import weblogic.webservice.component.jms.JMSSendInvocationHandler;
/*      */ import weblogic.webservice.component.jms.JMSTopicReceiveInvocationHandler;
/*      */ import weblogic.webservice.component.slsb.SLSBInvocationHandler;
/*      */ import weblogic.webservice.core.encoding.DefaultRegistry;
/*      */ import weblogic.webservice.core.handler.WSSEHandler;
/*      */ import weblogic.webservice.dd.ComponentIntrospector;
/*      */ import weblogic.webservice.dd.MethodDescriptor;
/*      */ import weblogic.webservice.tools.MethodIterator;
/*      */ import weblogic.webservice.util.AttachmentUtil;
/*      */ import weblogic.webservice.util.EJBHelper;
/*      */ import weblogic.webservice.util.ExceptionUtil;
/*      */ import weblogic.webservice.util.HolderUtil;
/*      */ import weblogic.webservice.util.SmartNameStore;
/*      */ import weblogic.xml.schema.binding.BindingException;
/*      */ import weblogic.xml.schema.binding.Deserializer;
/*      */ import weblogic.xml.schema.binding.Serializer;
/*      */ import weblogic.xml.schema.binding.TypeMapping;
/*      */ import weblogic.xml.schema.binding.TypeMappingBuilder;
/*      */ import weblogic.xml.schema.binding.TypeMappingBuilderFactory;
/*      */ import weblogic.xml.schema.binding.internal.codegen.ArrayUtils;
/*      */ import weblogic.xml.schema.binding.util.StdNamespace;
/*      */ import weblogic.xml.schema.model.XSDException;
/*      */ import weblogic.xml.schema.model.util.MergeSchemas;
/*      */ import weblogic.xml.security.specs.SecurityDD;
/*      */ import weblogic.xml.stream.ElementFactory;
/*      */ import weblogic.xml.stream.XMLInputStream;
/*      */ import weblogic.xml.stream.XMLName;
/*      */ import weblogic.xml.stream.XMLStreamException;
/*      */ import weblogic.xml.stream.events.Name;
/*      */ import weblogic.xml.xmlnode.XMLNode;
/*      */ import weblogic.xml.xmlnode.XMLNodeOutputStream;
/*      */ import weblogic.xml.xmlnode.XMLNodeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WebServiceFactory
/*      */   extends WebServiceFactory
/*      */ {
/*  114 */   private static final boolean noDynamicTypeGeneration = "true".equalsIgnoreCase(System.getProperty("weblogic.webservice.noDynamicTypeGeneration"));
/*      */ 
/*      */ 
/*      */   
/*  118 */   public static WebServiceFactory newFactoryInstance() { return new WebServiceFactory(); }
/*      */ 
/*      */   
/*  121 */   private static final HandlerInfo invokeHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.InvokeHandler.class, null, null);
/*      */ 
/*      */ 
/*      */   
/*      */   private HandlerInfo authHandlerInfo;
/*      */ 
/*      */   
/*  128 */   private static final HandlerInfo conversationHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.ServerConversationHandler.class, null, null);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  133 */   private static int defaultPersistDuration = initDefaultPersistDuration();
/*      */   private static int initDefaultPersistDuration() {
/*  135 */     int i = -1;
/*  136 */     WSServerService wSServerService = WSServerService.getWSServerService();
/*  137 */     if (wSServerService != null) {
/*  138 */       WSReliableDeliveryPolicyMBean wSReliableDeliveryPolicyMBean = wSServerService.getReliableDeliveryPolicyMBean();
/*      */       
/*  140 */       if (wSReliableDeliveryPolicyMBean != null) {
/*  141 */         i = wSReliableDeliveryPolicyMBean.getDefaultTimeToLive();
/*      */       }
/*      */     } 
/*  144 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebService createFromMBean(WebServiceMBean paramWebServiceMBean, AuthorizationContext paramAuthorizationContext) throws ConfigException {
/*  151 */     HashMap hashMap = new HashMap();
/*      */ 
/*      */     
/*  154 */     hashMap.put("WSAuthorizationContext", paramAuthorizationContext);
/*      */     
/*  156 */     this.authHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.AuthorizationHandler.class, hashMap, null);
/*      */     
/*  158 */     WebService webService = createFromMBean(paramWebServiceMBean, (Map)null);
/*      */     
/*  160 */     initServerHandlerInfos(webService, hashMap);
/*      */     
/*  162 */     return webService;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public WebService createFromMBean(WebServiceMBean paramWebServiceMBean, Map paramMap) throws ConfigException {
/*  168 */     String str1 = paramWebServiceMBean.getWebServiceName();
/*  169 */     String str2 = paramWebServiceMBean.getProtocol();
/*  170 */     String str3 = paramWebServiceMBean.getTargetNamespace();
/*      */     
/*  172 */     int i = paramWebServiceMBean.getResponseBufferSize();
/*      */     
/*  174 */     WebService webService = create(str3, str1);
/*      */     
/*  176 */     if (paramWebServiceMBean.getSecurity() != null) {
/*  177 */       initSecurityDD(paramWebServiceMBean, webService);
/*      */     }
/*      */     
/*  180 */     XMLNodeSet xMLNodeSet = paramWebServiceMBean.getTypes();
/*      */     
/*  182 */     if (xMLNodeSet != null) {
/*  183 */       webService.setTypes(xMLNodeSet.getAsXMLNode(new Name("types")));
/*      */     }
/*      */     
/*  186 */     TypeMappingBuilder typeMappingBuilder = initTypeMaps(webService, paramWebServiceMBean);
/*      */     
/*  188 */     ComponentsMBean componentsMBean = paramWebServiceMBean.getComponents();
/*      */     
/*  190 */     HashMap hashMap = new HashMap();
/*      */ 
/*      */ 
/*      */     
/*  194 */     if (componentsMBean != null) {
/*      */       
/*  196 */       boolean bool = (paramMap == null);
/*  197 */       hashMap = initComponents(componentsMBean, bool);
/*      */     } 
/*      */ 
/*      */     
/*  201 */     if (str2 != null) {
/*  202 */       webService.setProtocol(str2);
/*      */     }
/*      */     
/*  205 */     if (i > -1) {
/*  206 */       webService.setResponseBufferSize(i);
/*      */     }
/*      */     
/*  209 */     webService.setExposeWSDL(paramWebServiceMBean.getExposeWSDL());
/*  210 */     webService.setExposeHomePage(paramWebServiceMBean.getExposeHomePage());
/*  211 */     webService.setHandleAllActors(paramWebServiceMBean.getHandleAllActors());
/*      */ 
/*      */ 
/*      */     
/*  215 */     OperationsMBean operationsMBean = paramWebServiceMBean.getOperations();
/*      */     
/*  217 */     if (operationsMBean == null) {
/*  218 */       throw new ConfigException("Cannot create a WebService with no operations");
/*      */     }
/*      */ 
/*      */     
/*  222 */     initOperations(operationsMBean, webService, hashMap, paramMap, str3, paramWebServiceMBean);
/*      */     
/*  224 */     updateParameterOrder(webService);
/*      */     
/*  226 */     if (paramWebServiceMBean.getUseSOAP12()) {
/*  227 */       addSoap12Ports(webService);
/*      */     }
/*      */     
/*  230 */     if (paramWebServiceMBean.getJmsURI() != null) {
/*  231 */       addJmsPorts(paramWebServiceMBean.getJmsURI(), webService);
/*      */     }
/*      */     
/*  234 */     if (paramWebServiceMBean.getCharset() != null) {
/*  235 */       setCharset(paramWebServiceMBean.getCharset(), webService);
/*      */     }
/*      */     
/*  238 */     addConversationSchema(webService);
/*      */     
/*  240 */     addDocumentStyleSupport(webService, typeMappingBuilder);
/*      */     
/*  242 */     checkForUniqueFaultNames(webService);
/*  243 */     return webService;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkForUniqueFaultNames(WebService paramWebService) {
/*  249 */     HashSet hashSet = new HashSet();
/*  250 */     HashMap hashMap = new HashMap();
/*      */ 
/*      */     
/*  253 */     Iterator iterator = paramWebService.getPorts();
/*  254 */     while (iterator.hasNext()) {
/*  255 */       Port port = (Port)iterator.next();
/*      */       
/*  257 */       Iterator iterator1 = port.getOperations();
/*  258 */       while (iterator1.hasNext()) {
/*  259 */         Operation operation = (Operation)iterator1.next();
/*      */         
/*  261 */         Iterator iterator2 = operation.getFaults();
/*  262 */         while (iterator2.hasNext()) {
/*  263 */           Message message = (Message)iterator2.next();
/*  264 */           String str = message.getName();
/*      */           
/*  266 */           if (hashMap.containsKey(str))
/*      */             continue; 
/*  268 */           Iterator iterator3 = message.getParts();
/*  269 */           while (iterator3.hasNext()) {
/*  270 */             Part part = (Part)iterator3.next();
/*  271 */             part.setName(getUniqueName(part.getName(), hashSet));
/*  272 */             hashMap.put(str, str);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void initSecurityDD(WebServiceMBean paramWebServiceMBean, WebService paramWebService) throws ConfigException {
/*  281 */     SecurityDD securityDD = null;
/*      */     
/*      */     try {
/*  284 */       securityDD = new SecurityDD(paramWebServiceMBean.getSecurity().stream());
/*  285 */     } catch (XMLStreamException xMLStreamException) {
/*      */       
/*  287 */       throw new ConfigException("Failed to create securityDD object. ");
/*      */     } 
/*  289 */     paramWebService.setSecurity(securityDD);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void initServerHandlerInfos(WebService paramWebService, Map paramMap) throws ConfigException {
/*  295 */     SecurityDD securityDD = paramWebService.getSecurity();
/*      */     
/*  297 */     if (securityDD != null) {
/*  298 */       HandlerInfo handlerInfo = new HandlerInfo(WSSEHandler.class, paramMap, null);
/*      */ 
/*      */ 
/*      */       
/*  302 */       WSSEHandler.initHandlerInfo(securityDD, handlerInfo);
/*      */       
/*  304 */       paramWebService.setHandlerInfos(new HandlerInfo[] { handlerInfo });
/*      */     } 
/*      */   }
/*      */   
/*      */   private String[] getPortNames(String paramString) {
/*  309 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
/*  310 */     ArrayList arrayList = new ArrayList();
/*      */     
/*  312 */     while (stringTokenizer.hasMoreTokens()) {
/*  313 */       arrayList.add(stringTokenizer.nextToken());
/*      */     }
/*      */     
/*  316 */     return (String[])arrayList.toArray(new String[arrayList.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Iterator getPorts(WebService paramWebService, String paramString1, String paramString2, String paramString3) {
/*  322 */     if (paramString1 == null) {
/*  323 */       paramString1 = paramWebService.getName() + "Port";
/*      */     }
/*      */     
/*  326 */     String[] arrayOfString = getPortNames(paramString1);
/*      */     
/*  328 */     if (arrayOfString.length > 1 && paramString2 != null) {
/*  329 */       throw new JAXRPCException("can not set portName for multiple ports. In the case of multiple ports, portName and portTypeName are the same");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  334 */     ArrayList arrayList = new ArrayList();
/*      */     
/*  336 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*      */       
/*  338 */       Port port = paramWebService.getPort(arrayOfString[b]);
/*      */       
/*  340 */       if (port == null) {
/*      */         
/*  342 */         if (paramString2 == null) {
/*  343 */           port = paramWebService.addPort(arrayOfString[b]);
/*      */         } else {
/*  345 */           port = paramWebService.addPort(paramString2);
/*      */         } 
/*      */         
/*  348 */         port.setTypeName(arrayOfString[b]);
/*      */         
/*  350 */         port.setStyle(paramString3);
/*      */       } 
/*      */       
/*  353 */       arrayList.add(port);
/*      */     } 
/*      */     
/*  356 */     return arrayList.iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeMappingBuilder initTypeMaps(WebService paramWebService, WebServiceMBean paramWebServiceMBean) throws ConfigException {
/*      */     DefaultRegistry defaultRegistry;
/*      */     try {
/*  366 */       defaultRegistry = new DefaultRegistry();
/*  367 */     } catch (JAXRPCException jAXRPCException) {
/*  368 */       throw new ConfigException("failed to create type mapping registry: ", jAXRPCException);
/*      */     } 
/*      */ 
/*      */     
/*  372 */     TypeMappingBuilder typeMappingBuilder = TypeMappingBuilderFactory.newInstance().createTypeMappingBuilder();
/*      */     
/*      */     try {
/*  375 */       TypeMapping typeMapping = typeMappingBuilder.getTypeMapping();
/*      */       
/*  377 */       defaultRegistry.register(StdNamespace.instance().soapEncoding(), (TypeMapping)typeMapping);
/*      */ 
/*      */ 
/*      */       
/*  381 */       TypeMappingMBean typeMappingMBean = paramWebServiceMBean.getTypeMapping();
/*  382 */       if (typeMappingMBean != null) {
/*  383 */         TypeMappingEntryMBean[] arrayOfTypeMappingEntryMBean = typeMappingMBean.getTypeMappingEntries();
/*  384 */         int i = arrayOfTypeMappingEntryMBean.length;
/*  385 */         for (byte b = 0; b < i; b++) {
/*  386 */           typeMapping.add(loadClass(arrayOfTypeMappingEntryMBean[b].getClassName()), arrayOfTypeMappingEntryMBean[b].getXSDTypeName(), (Serializer)loadClass(arrayOfTypeMappingEntryMBean[b].getSerializerName()).newInstance(), (Deserializer)loadClass(arrayOfTypeMappingEntryMBean[b].getDeserializerName()).newInstance());
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  394 */     catch (Exception exception) {
/*  395 */       throw new ConfigException("failed to add type mapping to registry: ", exception);
/*      */     } 
/*  397 */     paramWebService.setTypeMappingRegistry(defaultRegistry);
/*  398 */     return typeMappingBuilder;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private HashMap initComponents(ComponentsMBean paramComponentsMBean, boolean paramBoolean) throws ConfigException {
/*  404 */     HashMap hashMap = new HashMap();
/*  405 */     StatelessEJBMBean[] arrayOfStatelessEJBMBean = paramComponentsMBean.getStatelessEJBs();
/*  406 */     if (arrayOfStatelessEJBMBean != null) {
/*  407 */       for (byte b = 0; b < arrayOfStatelessEJBMBean.length; b++) {
/*      */         
/*      */         try {
/*  410 */           if (paramBoolean) {
/*  411 */             hashMap.put(arrayOfStatelessEJBMBean[b].getComponentName(), new SLSBInvocationHandler(EJBHelper.getEJBHome(arrayOfStatelessEJBMBean[b])));
/*      */           } else {
/*      */             
/*  414 */             hashMap.put(arrayOfStatelessEJBMBean[b].getComponentName(), null);
/*      */           } 
/*  416 */         } catch (NamingException namingException) {
/*      */           
/*  418 */           throw new AssertionError(namingException);
/*      */         } 
/*      */       } 
/*      */     }
/*  422 */     JavaClassMBean[] arrayOfJavaClassMBean = paramComponentsMBean.getJavaClassComponents();
/*  423 */     if (arrayOfJavaClassMBean != null) {
/*  424 */       for (byte b = 0; b < arrayOfJavaClassMBean.length; b++) {
/*      */         try {
/*  426 */           if (paramBoolean) {
/*  427 */             Class clazz = loadClass(arrayOfJavaClassMBean[b].getClassName());
/*  428 */             JavaClassInvocationHandler javaClassInvocationHandler = new JavaClassInvocationHandler(clazz);
/*      */             
/*  430 */             hashMap.put(arrayOfJavaClassMBean[b].getComponentName(), javaClassInvocationHandler);
/*      */           } else {
/*  432 */             hashMap.put(arrayOfJavaClassMBean[b].getComponentName(), null);
/*      */           } 
/*  434 */         } catch (InstantiationException instantiationException) {
/*  435 */           throw new ConfigException("failed to create invocation handler");
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  440 */     StatefulJavaClassMBean[] arrayOfStatefulJavaClassMBean = paramComponentsMBean.getStatefulJavaClassComponents();
/*  441 */     if (arrayOfStatefulJavaClassMBean != null) {
/*  442 */       for (byte b = 0; b < arrayOfStatefulJavaClassMBean.length; b++) {
/*      */         try {
/*  444 */           if (paramBoolean) {
/*  445 */             Class clazz = loadClass(arrayOfStatefulJavaClassMBean[b].getClassName());
/*  446 */             StatefulInvocationHandler statefulInvocationHandler = new StatefulInvocationHandler(clazz);
/*      */             
/*  448 */             hashMap.put(arrayOfStatefulJavaClassMBean[b].getComponentName(), statefulInvocationHandler);
/*      */           } else {
/*  450 */             hashMap.put(arrayOfStatefulJavaClassMBean[b].getComponentName(), null);
/*      */           } 
/*  452 */         } catch (InstantiationException instantiationException) {
/*  453 */           throw new ConfigException("failed to create invocation handler" + instantiationException);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  458 */     JMSSendDestinationMBean[] arrayOfJMSSendDestinationMBean = paramComponentsMBean.getJMSSendDestinations();
/*  459 */     if (arrayOfJMSSendDestinationMBean != null) {
/*  460 */       for (byte b = 0; b < arrayOfJMSSendDestinationMBean.length; b++) {
/*  461 */         if (paramBoolean) {
/*  462 */           String str1 = arrayOfJMSSendDestinationMBean[b].getJNDIName().getPath();
/*  463 */           String str2 = arrayOfJMSSendDestinationMBean[b].getConnectionFactory();
/*  464 */           JMSSendInvocationHandler jMSSendInvocationHandler = new JMSSendInvocationHandler(str2, str1);
/*      */           
/*  466 */           hashMap.put(arrayOfJMSSendDestinationMBean[b].getComponentName(), jMSSendInvocationHandler);
/*      */         } else {
/*  468 */           hashMap.put(arrayOfJMSSendDestinationMBean[b].getComponentName(), null);
/*      */         } 
/*      */       } 
/*      */     }
/*  472 */     JMSReceiveQueueMBean[] arrayOfJMSReceiveQueueMBean = paramComponentsMBean.getJMSReceiveQueues();
/*  473 */     if (arrayOfJMSReceiveQueueMBean != null) {
/*  474 */       for (byte b = 0; b < arrayOfJMSReceiveQueueMBean.length; b++) {
/*  475 */         if (paramBoolean) {
/*  476 */           String str1 = arrayOfJMSReceiveQueueMBean[b].getJNDIName().getPath();
/*  477 */           String str2 = arrayOfJMSReceiveQueueMBean[b].getConnectionFactory();
/*  478 */           JMSQueueReceiveInvocationHandler jMSQueueReceiveInvocationHandler = new JMSQueueReceiveInvocationHandler(str2, str1);
/*      */           
/*  480 */           hashMap.put(arrayOfJMSReceiveQueueMBean[b].getComponentName(), jMSQueueReceiveInvocationHandler);
/*      */         } else {
/*  482 */           hashMap.put(arrayOfJMSReceiveQueueMBean[b].getComponentName(), null);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  487 */     JMSReceiveTopicMBean[] arrayOfJMSReceiveTopicMBean = paramComponentsMBean.getJMSReceiveTopics();
/*  488 */     if (arrayOfJMSReceiveTopicMBean != null) {
/*  489 */       for (byte b = 0; b < arrayOfJMSReceiveTopicMBean.length; b++) {
/*  490 */         if (paramBoolean) {
/*  491 */           String str1 = arrayOfJMSReceiveTopicMBean[b].getJNDIName().getPath();
/*  492 */           String str2 = arrayOfJMSReceiveTopicMBean[b].getConnectionFactory();
/*  493 */           JMSTopicReceiveInvocationHandler jMSTopicReceiveInvocationHandler = new JMSTopicReceiveInvocationHandler(str2, str1);
/*      */           
/*  495 */           hashMap.put(arrayOfJMSReceiveTopicMBean[b].getComponentName(), jMSTopicReceiveInvocationHandler);
/*      */         } else {
/*  497 */           hashMap.put(arrayOfJMSReceiveTopicMBean[b].getComponentName(), null);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  502 */     return hashMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HandlerInfo[] getHandlerInfos(OperationMBean paramOperationMBean) throws ConfigException {
/*  509 */     HandlerChainMBean handlerChainMBean = paramOperationMBean.getHandlerChain();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  517 */     HandlerInfo handlerInfo = null;
/*  518 */     ReliableDeliveryMBean reliableDeliveryMBean = paramOperationMBean.getReliableDelivery();
/*  519 */     if (reliableDeliveryMBean != null) {
/*  520 */       handlerInfo = initReliableDelivery(reliableDeliveryMBean);
/*      */     }
/*      */     
/*  523 */     ArrayList arrayList = new ArrayList();
/*      */     
/*  525 */     if (this.authHandlerInfo != null) arrayList.add(this.authHandlerInfo);
/*      */ 
/*      */ 
/*      */     
/*  529 */     arrayList.add(conversationHandlerInfo);
/*      */     
/*  531 */     if (handlerInfo != null) arrayList.add(handlerInfo);
/*      */     
/*  533 */     if (handlerChainMBean != null) {
/*  534 */       HandlerMBean[] arrayOfHandlerMBean = handlerChainMBean.getHandlers();
/*  535 */       for (byte b = 0; b < arrayOfHandlerMBean.length; b++) {
/*  536 */         Class clazz = loadClass(arrayOfHandlerMBean[b].getClassName());
/*      */         
/*  538 */         HashMap hashMap = new HashMap();
/*      */         
/*  540 */         InitParamsMBean initParamsMBean = arrayOfHandlerMBean[b].getInitParams();
/*      */         
/*  542 */         if (initParamsMBean != null) {
/*  543 */           InitParamMBean[] arrayOfInitParamMBean = initParamsMBean.getInitParams();
/*      */           
/*  545 */           for (byte b1 = 0; b1 < arrayOfInitParamMBean.length; b1++) {
/*  546 */             hashMap.put(arrayOfInitParamMBean[b1].getParamName(), arrayOfInitParamMBean[b1].getParamValue());
/*      */           }
/*      */         } 
/*      */         
/*  550 */         arrayList.add(new HandlerInfo(clazz, hashMap, null));
/*      */       } 
/*      */     } 
/*      */     
/*  554 */     if (paramOperationMBean.getComponentName() != null) arrayList.add(invokeHandlerInfo);
/*      */     
/*  556 */     return (HandlerInfo[])arrayList.toArray(new HandlerInfo[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initOperations(OperationsMBean paramOperationsMBean, WebService paramWebService, Map paramMap1, Map paramMap2, String paramString, WebServiceMBean paramWebServiceMBean) throws ConfigException {
/*  568 */     OperationMBean[] arrayOfOperationMBean = paramOperationsMBean.getOperations();
/*      */     
/*  570 */     if (arrayOfOperationMBean == null) {
/*  571 */       throw new ConfigException("Cannot create a WebService with no operations");
/*      */     }
/*      */ 
/*      */     
/*  575 */     TypeMappingRegistry typeMappingRegistry = paramWebService.getTypeMappingRegistry();
/*  576 */     TypeMapping typeMapping = (TypeMapping)typeMappingRegistry.getTypeMapping(StdNamespace.instance().soapEncoding());
/*      */ 
/*      */     
/*  579 */     if (typeMapping == null) {
/*  580 */       throw new ConfigException("Cannot find TypeMapping");
/*      */     }
/*      */ 
/*      */     
/*  584 */     HashMap hashMap = new HashMap();
/*      */     
/*  586 */     for (byte b = 0; b < arrayOfOperationMBean.length; b++) {
/*      */       
/*  588 */       InvocationHandler invocationHandler = null;
/*  589 */       String str1 = arrayOfOperationMBean[b].getOperationName();
/*  590 */       if (str1 == null) str1 = arrayOfOperationMBean[b].getMethod();
/*      */       
/*  592 */       arrayOfOperationMBean[b].setStyle(paramWebServiceMBean.getStyle());
/*      */       
/*  594 */       String str2 = arrayOfOperationMBean[b].getComponentName();
/*      */       
/*  596 */       if (str2 != null) {
/*  597 */         invocationHandler = (InvocationHandler)paramMap1.get(str2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  603 */         if (invocationHandler == null && paramMap2 == null) {
/*  604 */           throw new ConfigException("No component '" + str2 + "' was found for operation '" + str1 + "'");
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  609 */       String str3 = arrayOfOperationMBean[b].getPortTypeName();
/*  610 */       String str4 = paramWebServiceMBean.getPortName();
/*      */       
/*  612 */       if (str3 == null) {
/*  613 */         str3 = paramWebServiceMBean.getPortTypeName();
/*      */       }
/*      */       
/*  616 */       Iterator iterator = getPorts(paramWebService, str3, str4, paramWebServiceMBean.getStyle());
/*      */ 
/*      */       
/*  619 */       boolean bool = false;
/*  620 */       if (invocationHandler != null && invocationHandler instanceof StatefulInvocationHandler) {
/*  621 */         bool = true;
/*      */       }
/*      */       
/*  624 */       while (iterator.hasNext()) {
/*  625 */         Port port = (Port)iterator.next();
/*      */         
/*  627 */         HashSet hashSet = getUniqueNameStore(port.getTypeName(), hashMap);
/*      */ 
/*      */         
/*  630 */         registerOperation(arrayOfOperationMBean[b], port, invocationHandler, paramMap2, typeMapping, paramString, hashSet, bool);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HashSet getUniqueNameStore(String paramString, HashMap paramHashMap) {
/*  639 */     HashSet hashSet = (HashSet)paramHashMap.get(paramString);
/*      */     
/*  641 */     if (hashSet == null) {
/*  642 */       hashSet = new HashSet();
/*  643 */       paramHashMap.put(paramString, hashSet);
/*      */     } 
/*      */     
/*  646 */     return hashSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void registerOperation(OperationMBean paramOperationMBean, Port paramPort, InvocationHandler paramInvocationHandler, Map paramMap, TypeMapping paramTypeMapping, String paramString, HashSet paramHashSet, boolean paramBoolean) throws ConfigException {
/*      */     MethodIterator methodIterator;
/*  662 */     String str1 = paramOperationMBean.getComponentName();
/*  663 */     String str2 = paramOperationMBean.getOperationName();
/*  664 */     String str3 = paramOperationMBean.getMethod();
/*  665 */     String str4 = paramString;
/*  666 */     String str5 = paramOperationMBean.getConversationPhase();
/*      */     
/*  668 */     int i = defaultPersistDuration;
/*  669 */     ReliableDeliveryMBean reliableDeliveryMBean = paramOperationMBean.getReliableDelivery();
/*  670 */     if (reliableDeliveryMBean != null) { i = reliableDeliveryMBean.getPersistDuration(); }
/*      */     
/*      */     else
/*      */     
/*  674 */     { i = -1; }
/*      */ 
/*      */     
/*  677 */     if (str5 == null && paramBoolean) {
/*  678 */       str5 = "CONTINUE";
/*      */     }
/*      */     
/*  681 */     if (str2 == null) str2 = str3; 
/*  682 */     if (str3 == null) str3 = str2;
/*      */     
/*  684 */     if (paramOperationMBean.getNamespace() != null) {
/*  685 */       str4 = paramOperationMBean.getNamespace();
/*      */     }
/*      */     
/*  688 */     if (str1 == null) {
/*      */       
/*  690 */       Operation operation = paramPort.addOperation(str2, getHandlerInfos(paramOperationMBean));
/*      */       
/*  692 */       if (paramOperationMBean.getParams() != null) {
/*  693 */         addParamsToMethod((Method)null, operation, paramOperationMBean.getParams(), paramTypeMapping, str4);
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  700 */     boolean bool = isJMSHandler(paramInvocationHandler);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  708 */     if (paramMap == null) {
/*  709 */       if (bool || paramInvocationHandler == null) {
/*      */         
/*  711 */         methodIterator = new MethodIterator((Class)null);
/*      */       } else {
/*      */         
/*  714 */         methodIterator = introspectComponent(str1, paramInvocationHandler);
/*      */       } 
/*      */     } else {
/*  717 */       ComponentIntrospector componentIntrospector = (ComponentIntrospector)paramMap.get(str1);
/*      */       try {
/*  719 */         if (componentIntrospector != null) {
/*  720 */           methodIterator = componentIntrospector.getMethods();
/*      */         } else {
/*      */           
/*  723 */           methodIterator = new MethodIterator((Class)null);
/*      */         }
/*      */       
/*  726 */       } catch (Exception exception) {
/*  727 */         String str = WebServiceLogger.logComponentIntrospectorException();
/*  728 */         WebServiceLogger.logStackTrace(str, exception);
/*  729 */         throw new ConfigException("Exception introspecting component '" + str1 + "'", exception);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  737 */     if (bool || (paramInvocationHandler == null && methodIterator == null)) {
/*      */ 
/*      */       
/*  740 */       Operation operation = paramPort.addOperation(str2, getHandlerInfos(paramOperationMBean));
/*  741 */       addParamsToJMSComponent(operation, paramOperationMBean.getParams(), paramTypeMapping, str4);
/*      */       
/*  743 */       operation.setInvocationHandler(paramInvocationHandler);
/*  744 */       operation.setConversationPhase(str5);
/*  745 */       operation.setPersistDurationTime(i);
/*  746 */       operation.setStyle(paramOperationMBean.getStyle());
/*      */       
/*  748 */       if (paramOperationMBean.getInSecuritySpec() != null) {
/*  749 */         String str = paramOperationMBean.getInSecuritySpec();
/*  750 */         SecurityDD securityDD = paramPort.getService().getSecurity();
/*  751 */         if (securityDD == null || securityDD.getSecuritySpec(str) == null) {
/*  752 */           throw new ConfigException("Operation " + paramOperationMBean.getName() + " is trying to refer to " + "a undefined security spec named " + str);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  757 */         operation.getInput().setSecuritySpecRef(str);
/*      */       } 
/*      */       
/*  760 */       if (paramOperationMBean.getOutSecuritySpec() != null) {
/*  761 */         String str = paramOperationMBean.getOutSecuritySpec();
/*  762 */         SecurityDD securityDD = paramPort.getService().getSecurity();
/*  763 */         if (securityDD == null || securityDD.getSecuritySpec(str) == null) {
/*  764 */           throw new ConfigException("Operation " + paramOperationMBean.getName() + " is trying to refer to " + "a undefined security spec named " + str);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  769 */         operation.getOutput().setSecuritySpecRef(str);
/*      */       } 
/*      */       
/*  772 */       if (paramInvocationHandler != null) {
/*      */         try {
/*  774 */           paramInvocationHandler.registerOperation(str2, str2, null);
/*  775 */         } catch (NoSuchMethodException noSuchMethodException) {
/*  776 */           throw new ConfigException(noSuchMethodException);
/*      */         }
/*      */       
/*      */       }
/*  780 */     } else if ("*".equals(str3)) {
/*  781 */       while (methodIterator.hasNext()) {
/*  782 */         Method method = methodIterator.next();
/*  783 */         str2 = method.getName();
/*      */ 
/*      */         
/*  786 */         str2 = getUniqueName(str2, paramHashSet);
/*  787 */         Operation operation = paramPort.addOperation(str2, getHandlerInfos(paramOperationMBean));
/*  788 */         if ("one-way".equals(paramOperationMBean.getInvocationStyle())) {
/*  789 */           operation.setOneway(true);
/*      */         }
/*  791 */         operation.setConversationPhase(str5);
/*  792 */         operation.setPersistDurationTime(i);
/*  793 */         operation.setStyle(paramOperationMBean.getStyle());
/*      */         
/*  795 */         addParamsToMethod(method, operation, paramTypeMapping, str4);
/*      */         
/*  797 */         operation.setInvocationHandler(paramInvocationHandler);
/*  798 */         if (paramInvocationHandler != null) {
/*      */           try {
/*  800 */             paramInvocationHandler.registerOperation(str2, method.getName(), method.getParameterTypes());
/*  801 */           } catch (NoSuchMethodException noSuchMethodException) {
/*  802 */             throw new ConfigException(noSuchMethodException);
/*      */           }
/*      */         
/*      */         }
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  810 */       MethodDescriptor methodDescriptor = new MethodDescriptor(str3);
/*  811 */       str2 = paramOperationMBean.getOperationName();
/*      */       
/*  813 */       if (str2 == null) {
/*  814 */         str2 = methodDescriptor.getName();
/*      */       }
/*      */ 
/*      */       
/*  818 */       str2 = getUniqueName(str2, paramHashSet);
/*  819 */       Operation operation = paramPort.addOperation(str2, getHandlerInfos(paramOperationMBean));
/*  820 */       operation.setConversationPhase(str5);
/*  821 */       operation.setPersistDurationTime(i);
/*  822 */       operation.setStyle(paramOperationMBean.getStyle());
/*      */       
/*  824 */       if ("one-way".equals(paramOperationMBean.getInvocationStyle())) {
/*  825 */         operation.setOneway(true);
/*      */       }
/*      */       
/*  828 */       if (paramOperationMBean.getInSecuritySpec() != null) {
/*  829 */         String str = paramOperationMBean.getInSecuritySpec();
/*  830 */         SecurityDD securityDD = paramPort.getService().getSecurity();
/*  831 */         if (securityDD == null || securityDD.getSecuritySpec(str) == null) {
/*  832 */           throw new ConfigException("Operation " + paramOperationMBean.getName() + " is trying to refer to " + "a undefined security spec named " + str);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  837 */         operation.getInput().setSecuritySpecRef(str);
/*      */       } 
/*      */       
/*  840 */       if (paramOperationMBean.getOutSecuritySpec() != null) {
/*  841 */         String str = paramOperationMBean.getOutSecuritySpec();
/*  842 */         SecurityDD securityDD = paramPort.getService().getSecurity();
/*  843 */         if (securityDD == null || securityDD.getSecuritySpec(str) == null) {
/*  844 */           throw new ConfigException("Operation " + paramOperationMBean.getName() + " is trying to refer to " + "a undefined security spec named " + str);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  849 */         operation.getOutput().setSecuritySpecRef(str);
/*      */       } 
/*      */       
/*  852 */       ParamsMBean paramsMBean = paramOperationMBean.getParams();
/*      */       
/*  854 */       if (paramsMBean == null) {
/*  855 */         Method method = null;
/*      */         
/*  857 */         while (methodIterator.hasNext()) {
/*  858 */           method = methodIterator.next();
/*  859 */           if (methodDescriptor.equals(method)) {
/*      */             break;
/*      */           }
/*  862 */           method = null;
/*      */         } 
/*      */         
/*  865 */         if (method == null && !bool) {
/*  866 */           throw new ConfigException("No method '" + methodDescriptor.getName() + "' was found in component '" + str1 + "' for operation '" + str2 + "'");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  872 */         addParamsToMethod(method, operation, paramTypeMapping, str4);
/*      */       } else {
/*      */         
/*  875 */         addParamsToMethod((Method)null, operation, paramsMBean, paramTypeMapping, str4);
/*      */       } 
/*      */ 
/*      */       
/*  879 */       operation.setInvocationHandler(paramInvocationHandler);
/*      */       
/*  881 */       if (paramInvocationHandler != null) {
/*      */         try {
/*  883 */           paramInvocationHandler.registerOperation(str2, methodDescriptor.getName(), methodDescriptor.getParams());
/*  884 */         } catch (NoSuchMethodException noSuchMethodException) {
/*  885 */           throw new ConfigException(noSuchMethodException);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private MethodIterator introspectComponent(String paramString, InvocationHandler paramInvocationHandler) throws ConfigException {
/*  894 */     Method[] arrayOfMethod = paramInvocationHandler.getAllMethods();
/*      */     
/*  896 */     if (arrayOfMethod == null) {
/*  897 */       throw new ConfigException("Cannot introspect component '" + paramString + "' to resolve '*' in operation.");
/*      */     }
/*      */     
/*  900 */     MethodIterator methodIterator = new MethodIterator(arrayOfMethod);
/*  901 */     if (paramInvocationHandler instanceof SLSBInvocationHandler) {
/*  902 */       methodIterator.setEJBExcludes();
/*      */     }
/*  904 */     return methodIterator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addParamsToJMSComponent(Operation paramOperation, ParamsMBean paramParamsMBean, TypeMapping paramTypeMapping, String paramString) throws ConfigException {
/*      */     Message message;
/*  916 */     String str1 = null;
/*  917 */     XMLName xMLName = null;
/*  918 */     String str2 = null;
/*      */     
/*  920 */     boolean bool = false;
/*      */ 
/*      */     
/*  923 */     if (paramParamsMBean != null) {
/*      */       
/*  925 */       ParamMBean[] arrayOfParamMBean = paramParamsMBean.getParams();
/*  926 */       ReturnParamMBean returnParamMBean = paramParamsMBean.getReturnParam();
/*      */       
/*  928 */       if (arrayOfParamMBean != null && arrayOfParamMBean.length > 0) {
/*      */ 
/*      */ 
/*      */         
/*  932 */         ParamMBean paramMBean = arrayOfParamMBean[0];
/*  933 */         str1 = paramMBean.getParamName();
/*  934 */         xMLName = paramMBean.getParamType();
/*  935 */         str2 = paramMBean.getClassName();
/*      */         
/*  937 */         if ("in".equalsIgnoreCase(paramMBean.getParamStyle())) {
/*  938 */           bool = true;
/*      */         }
/*  940 */       } else if (returnParamMBean != null) {
/*      */         
/*  942 */         str1 = returnParamMBean.getParamName();
/*  943 */         xMLName = returnParamMBean.getParamType();
/*  944 */         str2 = returnParamMBean.getClassName();
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  953 */       str2 = "java.lang.String";
/*  954 */       if (bool) {
/*  955 */         str1 = "param";
/*      */       } else {
/*  957 */         str1 = "result";
/*      */       } 
/*      */     } 
/*      */     
/*  961 */     paramOperation.getInput().setNamespace(paramString);
/*  962 */     paramOperation.getOutput().setNamespace(paramString);
/*      */     
/*  964 */     Iterator iterator = paramOperation.getFaults();
/*  965 */     while (iterator.hasNext()) {
/*  966 */       ((Message)iterator.next()).setNamespace(paramString);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  971 */     if (bool) {
/*  972 */       message = paramOperation.getInput();
/*      */     } else {
/*  974 */       message = paramOperation.getOutput();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  981 */     Part.Mode mode = bool ? Part.Mode.IN : Part.Mode.RETURN;
/*  982 */     addPart(paramOperation, message, str1, xMLName, str2, paramTypeMapping, mode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addParamsToMethod(Method paramMethod, Operation paramOperation, ParamsMBean paramParamsMBean, TypeMapping paramTypeMapping, String paramString) throws ConfigException {
/*  996 */     if (paramParamsMBean == null) throw new AssertionError();
/*      */     
/*  998 */     ParamMBean[] arrayOfParamMBean = paramParamsMBean.getParams();
/*  999 */     if (arrayOfParamMBean == null)
/* 1000 */       return;  XMLName xMLName = null;
/* 1001 */     ReturnParamMBean returnParamMBean = paramParamsMBean.getReturnParam();
/* 1002 */     FaultMBean[] arrayOfFaultMBean = paramParamsMBean.getFaults();
/*      */     
/* 1004 */     Message message1 = paramOperation.getInput();
/* 1005 */     message1.setNamespace(paramString);
/* 1006 */     Message message2 = paramOperation.getOutput();
/* 1007 */     message2.setNamespace(paramString);
/*      */     
/* 1009 */     Class[] arrayOfClass = null;
/* 1010 */     Class clazz = null;
/* 1011 */     Iterator iterator = null;
/*      */     
/* 1013 */     if (paramMethod != null) {
/* 1014 */       arrayOfClass = paramMethod.getParameterTypes();
/* 1015 */       clazz = paramMethod.getReturnType();
/* 1016 */       iterator = (new SmartNameStore()).getNames(paramMethod);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1022 */     if (returnParamMBean != null) {
/* 1023 */       if ("header".equalsIgnoreCase(returnParamMBean.getLocation()))
/*      */       {
/*      */ 
/*      */         
/* 1027 */         throw new ConfigException("Return value can not be a header. use out or in-out parameters instead");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1032 */       String str = (returnParamMBean.getParamName() == null) ? "result" : returnParamMBean.getParamName();
/*      */ 
/*      */       
/* 1035 */       xMLName = returnParamMBean.getParamType();
/*      */       
/* 1037 */       Class clazz1 = null;
/*      */       
/* 1039 */       if (returnParamMBean.getClassName() != null) {
/* 1040 */         clazz1 = loadClass(returnParamMBean.getClassName());
/*      */       } else {
/* 1042 */         clazz1 = clazz;
/*      */       } 
/*      */       
/* 1045 */       Part part = addPart(paramOperation, message2, str, xMLName, clazz1, paramTypeMapping, Part.Mode.RETURN);
/*      */ 
/*      */       
/* 1048 */       setLocation(returnParamMBean.getLocation(), part);
/*      */     } 
/*      */ 
/*      */     
/* 1052 */     String[] arrayOfString = new String[arrayOfParamMBean.length];
/*      */     byte b;
/* 1054 */     for (b = 0; b < arrayOfParamMBean.length; b++) {
/*      */ 
/*      */       
/* 1057 */       if (!arrayOfParamMBean[b].isImplicit()) {
/*      */         Part part;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1063 */         String str = null;
/* 1064 */         xMLName = arrayOfParamMBean[b].getParamType();
/*      */         
/* 1066 */         if (arrayOfParamMBean[b].getParamName() != null) {
/* 1067 */           str = arrayOfParamMBean[b].getParamName();
/* 1068 */         } else if (iterator != null) {
/* 1069 */           if (!iterator.hasNext()) {
/* 1070 */             throw new ConfigException("No of params in the DD file do notmatch the no of param in the end component for method:" + paramMethod);
/*      */           }
/*      */           
/* 1073 */           str = (String)iterator.next();
/*      */         } else {
/* 1075 */           throw new ConfigException("Parameter name is expected.");
/*      */         } 
/*      */         
/* 1078 */         arrayOfString[b] = str;
/*      */         
/* 1080 */         Class clazz1 = null;
/* 1081 */         if (arrayOfClass != null) {
/* 1082 */           clazz1 = arrayOfClass[b];
/*      */         }
/*      */         
/* 1085 */         Class clazz2 = null;
/* 1086 */         if (arrayOfParamMBean[b].getClassName() != null) {
/* 1087 */           clazz2 = loadClass(arrayOfParamMBean[b].getClassName());
/*      */         }
/*      */         
/* 1090 */         clazz1 = validateParameterType(paramTypeMapping, xMLName, clazz2, clazz1);
/*      */ 
/*      */ 
/*      */         
/* 1094 */         if ("in".equalsIgnoreCase(arrayOfParamMBean[b].getParamStyle())) {
/*      */           
/* 1096 */           part = addPart(paramOperation, message1, str, xMLName, clazz1, paramTypeMapping, Part.Mode.IN);
/*      */         
/*      */         }
/* 1099 */         else if ("inout".equalsIgnoreCase(arrayOfParamMBean[b].getParamStyle())) {
/*      */           
/* 1101 */           part = addPart(paramOperation, message1, str, xMLName, getRealType(clazz1), paramTypeMapping, Part.Mode.INOUT);
/*      */ 
/*      */           
/* 1104 */           setLocation(arrayOfParamMBean[b].getLocation(), part);
/*      */           
/* 1106 */           part = addPart(paramOperation, message2, str, xMLName, getRealType(clazz1), paramTypeMapping, Part.Mode.INOUT);
/*      */         
/*      */         }
/* 1109 */         else if ("out".equalsIgnoreCase(arrayOfParamMBean[b].getParamStyle())) {
/*      */           
/* 1111 */           part = addPart(paramOperation, message2, str, xMLName, getRealType(clazz1), paramTypeMapping, Part.Mode.OUT);
/*      */         }
/*      */         else {
/*      */           
/* 1115 */           throw new AssertionError(arrayOfParamMBean[b].getParamStyle());
/*      */         } 
/*      */         
/* 1118 */         setLocation(arrayOfParamMBean[b].getLocation(), part);
/*      */       } 
/*      */     } 
/*      */     
/* 1122 */     paramOperation.setParameterOrder(arrayOfString);
/*      */     
/* 1124 */     if (arrayOfFaultMBean != null && arrayOfFaultMBean.length > 0) {
/* 1125 */       for (b = 0; b < arrayOfFaultMBean.length; b++) {
/* 1126 */         String str1 = arrayOfFaultMBean[b].getFaultName();
/* 1127 */         if (str1 == null) {
/* 1128 */           str1 = arrayOfFaultMBean[b].getClassName();
/*      */         }
/*      */         
/* 1131 */         xMLName = arrayOfFaultMBean[b].getFaultType();
/*      */         
/* 1133 */         Class clazz1 = loadClass(arrayOfFaultMBean[b].getClassName());
/*      */         
/* 1135 */         Message message = paramOperation.addFault();
/* 1136 */         message.setName(str1);
/* 1137 */         message.setNamespace(paramString);
/*      */         
/* 1139 */         String str2 = ExceptionUtil.getSingleSimplePropertyName(clazz1);
/* 1140 */         if (str2 == null) str2 = str1;
/*      */         
/* 1142 */         Part part = addPart(paramOperation, message, str2, xMLName, clazz1, paramTypeMapping, Part.Mode.OUT);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setLocation(String paramString, Part paramPart) {
/* 1150 */     if (paramString == null) {
/* 1151 */       paramString = "body";
/*      */     }
/*      */     
/* 1154 */     if ("body".equalsIgnoreCase(paramString)) {
/* 1155 */       paramPart.setBody();
/* 1156 */     } else if ("header".equalsIgnoreCase(paramString)) {
/* 1157 */       paramPart.setHeader();
/* 1158 */     } else if ("attachment".equalsIgnoreCase(paramString)) {
/* 1159 */       paramPart.setAttachment();
/*      */       
/* 1161 */       String str = AttachmentUtil.getContentType(paramPart.getJavaType().getName());
/*      */ 
/*      */       
/* 1164 */       paramPart.setContentType(new String[] { str });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addParamsToMethod(Method paramMethod, Operation paramOperation, TypeMapping paramTypeMapping, String paramString) throws ConfigException {
/* 1178 */     Message message1 = paramOperation.getInput();
/* 1179 */     message1.setNamespace(paramString);
/* 1180 */     Message message2 = paramOperation.getOutput();
/* 1181 */     message2.setNamespace(paramString);
/*      */ 
/*      */     
/* 1184 */     if (paramMethod == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1189 */     Class[] arrayOfClass = paramMethod.getParameterTypes();
/*      */     
/* 1191 */     Iterator iterator = (new SmartNameStore()).getNames(paramMethod);
/* 1192 */     String[] arrayOfString = new String[arrayOfClass.length];
/*      */     
/* 1194 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/* 1195 */       String str = (String)iterator.next();
/* 1196 */       arrayOfString[b] = str;
/*      */ 
/*      */       
/* 1199 */       if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(arrayOfClass[b])) {
/*      */         
/* 1201 */         addPart(paramOperation, message1, str, null, getRealType(arrayOfClass[b]), paramTypeMapping, Part.Mode.INOUT);
/*      */ 
/*      */         
/* 1204 */         addPart(paramOperation, message2, str, null, getRealType(arrayOfClass[b]), paramTypeMapping, Part.Mode.INOUT);
/*      */       }
/*      */       else {
/*      */         
/* 1208 */         addPart(paramOperation, message1, str, null, arrayOfClass[b], paramTypeMapping, Part.Mode.IN);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1213 */     paramOperation.setParameterOrder(arrayOfString);
/*      */ 
/*      */     
/* 1216 */     Class clazz = paramMethod.getReturnType();
/*      */     
/* 1218 */     if (clazz != null && !clazz.equals(void.class)) {
/* 1219 */       addPart(paramOperation, message2, "result", null, clazz, paramTypeMapping, Part.Mode.RETURN);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Part addPart(Operation paramOperation, Message paramMessage, String paramString1, XMLName paramXMLName, String paramString2, TypeMapping paramTypeMapping, Part.Mode paramMode) throws ConfigException {
/* 1228 */     Class clazz = null;
/*      */     
/* 1230 */     if (paramString2 != null) {
/* 1231 */       clazz = loadClass(paramString2);
/*      */     }
/*      */     
/* 1234 */     return addPart(paramOperation, paramMessage, paramString1, paramXMLName, clazz, paramTypeMapping, paramMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Part addPart(Operation paramOperation, Message paramMessage, String paramString, XMLName paramXMLName, Class paramClass, TypeMapping paramTypeMapping, Part.Mode paramMode) throws ConfigException {
/*      */     Part part;
/* 1243 */     if (paramString == null) {
/* 1244 */       throw new ConfigException("Could not add parameter to operation. You must specify its name.");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1251 */     if (paramXMLName == null && paramClass != null) {
/* 1252 */       paramXMLName = paramTypeMapping.getXMLNameFromClass(paramClass);
/*      */     }
/* 1254 */     if (paramXMLName == null) {
/* 1255 */       throw new ConfigException("Could not add parameter to operation. You must specify either its Java or XML type.");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1260 */     String str1 = paramXMLName.getLocalName();
/* 1261 */     String str2 = paramXMLName.getNamespaceUri();
/*      */     
/* 1263 */     if (paramClass == null) {
/* 1264 */       part = paramMessage.addPart(paramString, str1, str2);
/*      */     } else {
/* 1266 */       part = paramMessage.addPart(paramString, str1, str2, paramClass);
/*      */     } 
/*      */     
/* 1269 */     if (paramOperation.isDocumentStyle()) {
/* 1270 */       part.setElement();
/*      */     }
/*      */     
/* 1273 */     part.setMode(paramMode);
/*      */     
/* 1275 */     return part;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class loadClass(String paramString) throws ConfigException {
/*      */     try {
/* 1285 */       if (ReflectUtils.isPrimitiveClass(paramString)) {
/* 1286 */         return loadPrimitiveClass(paramString);
/*      */       }
/*      */       
/* 1289 */       Class clazz = loadArrayClass(paramString);
/* 1290 */       if (clazz != null) {
/* 1291 */         return clazz;
/*      */       }
/* 1293 */       return loadNonArrayClass(paramString);
/* 1294 */     } catch (ClassNotFoundException classNotFoundException) {
/* 1295 */       throw new ConfigException("unable to load class:[" + paramString + "] " + classNotFoundException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1302 */   private static Class loadPrimitiveClass(String paramString) throws ConfigException { return ReflectUtils.loadPrimitiveClass(paramString); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Class loadNonArrayClass(String paramString) throws ConfigException {
/* 1308 */     Class clazz2, clazz1 = loadPrimitiveClass(paramString);
/* 1309 */     if (clazz1 != null) {
/* 1310 */       return clazz1;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1315 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*      */ 
/*      */       
/* 1318 */       clazz2 = classLoader.loadClass(paramString);
/* 1319 */     } catch (ClassNotFoundException classNotFoundException) {
/* 1320 */       ClassLoader classLoader = WebServiceFactory.class.getClassLoader();
/* 1321 */       clazz2 = classLoader.loadClass(paramString);
/*      */     } 
/* 1323 */     return clazz2;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Class loadArrayClass(String paramString) throws ConfigException {
/* 1329 */     StringBuffer stringBuffer = new StringBuffer(paramString.length());
/* 1330 */     int i = ArrayUtils.getArrayComponentNameFromDecl(stringBuffer, paramString);
/*      */     
/* 1332 */     if (i < 1) return null;
/*      */     
/* 1334 */     int[] arrayOfInt = new int[i];
/* 1335 */     Class clazz = loadNonArrayClass(stringBuffer.toString());
/* 1336 */     Object object = Array.newInstance(clazz, arrayOfInt);
/* 1337 */     return object.getClass();
/*      */   }
/*      */ 
/*      */   
/* 1341 */   private boolean isJMSHandler(InvocationHandler paramInvocationHandler) { return (paramInvocationHandler instanceof JMSSendInvocationHandler || paramInvocationHandler instanceof JMSQueueReceiveInvocationHandler || paramInvocationHandler instanceof JMSTopicReceiveInvocationHandler); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getUniqueName(String paramString, HashSet paramHashSet) {
/* 1347 */     String str = paramString;
/*      */     
/* 1349 */     byte b = 0;
/*      */     
/* 1351 */     while (paramHashSet.contains(str)) {
/* 1352 */       str = paramString + b;
/* 1353 */       b++;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1364 */     paramHashSet.add(str);
/* 1365 */     return str;
/*      */   }
/*      */   
/*      */   private void updateParameterOrder(WebService paramWebService) {
/* 1369 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext();) {
/* 1370 */       updateParameterOrder((Port)iterator.next());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateParameterOrder(Port paramPort) {
/* 1376 */     for (Iterator iterator = paramPort.getOperations(); iterator.hasNext(); ) {
/* 1377 */       Operation operation = (Operation)iterator.next();
/* 1378 */       updateParameterOrder(operation);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void updateParameterOrder(Operation paramOperation) {
/* 1383 */     if (!needsParameterOrder(paramOperation))
/* 1384 */       paramOperation.setParameterOrder(new String[0]); 
/*      */   }
/*      */   
/*      */   private boolean needsParameterOrder(Operation paramOperation) {
/*      */     Iterator iterator;
/* 1389 */     for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 1390 */       Part part = (Part)iterator.next();
/*      */       
/* 1392 */       if (part.getMode() == Part.Mode.INOUT) {
/* 1393 */         return true;
/*      */       }
/*      */     } 
/*      */     
/* 1397 */     for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/* 1398 */       Part part = (Part)iterator.next();
/*      */       
/* 1400 */       if (part.getMode() == Part.Mode.INOUT || part.getMode() == Part.Mode.OUT)
/*      */       {
/* 1402 */         return true;
/*      */       }
/*      */     } 
/*      */     
/* 1406 */     return false;
/*      */   }
/*      */ 
/*      */   
/* 1410 */   private Class getRealType(Class paramClass) { return HolderUtil.getRealType(paramClass); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Class validateParameterType(TypeMapping paramTypeMapping, XMLName paramXMLName, Class paramClass1, Class paramClass2) throws ConfigException {
/* 1420 */     if (paramClass1 == null) {
/* 1421 */       paramClass1 = paramTypeMapping.getClassFromXMLName(paramXMLName);
/*      */       
/* 1423 */       if (paramClass1 == null) {
/*      */         
/* 1425 */         if (paramClass2 == null)
/*      */         {
/* 1427 */           return Object.class;
/*      */         }
/* 1429 */         throw new ConfigException("Can't find type mapping entry for XML type " + paramXMLName);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1434 */       if (paramClass2 != null && !isAssignableFrom(paramClass2, paramClass1)) {
/* 1435 */         throw new ConfigException("XML type '" + paramXMLName + "' specified in web-services.xml file does not match with " + paramClass2 + "' found in method signature of the component.");
/*      */       }
/*      */ 
/*      */       
/* 1439 */       return paramClass1;
/*      */     } 
/*      */     
/* 1442 */     if (paramClass2 != null && !isAssignableFrom(paramClass2, paramClass1)) {
/* 1443 */       throw new ConfigException("Parameter class type '" + paramClass1 + "' specified in web-services.xml file does not match with " + paramClass2 + "' found in method signature of the component.");
/*      */     }
/*      */ 
/*      */     
/* 1447 */     return paramClass1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isAssignableFrom(Class paramClass1, Class paramClass2) {
/* 1453 */     if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass1)) paramClass1 = getRealType(paramClass1);
/*      */     
/* 1455 */     if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass2)) paramClass2 = getRealType(paramClass2);
/*      */     
/* 1457 */     if (paramClass1.isAssignableFrom(paramClass2)) return true;
/*      */     
/* 1459 */     if ((paramClass1 == int.class && paramClass2 == Integer.class) || (paramClass1 == Integer.class && paramClass2 == int.class))
/*      */     {
/* 1461 */       return true;
/*      */     }
/*      */     
/* 1464 */     if ((paramClass1 == byte.class && paramClass2 == Byte.class) || (paramClass1 == Byte.class && paramClass2 == byte.class))
/*      */     {
/* 1466 */       return true;
/*      */     }
/*      */     
/* 1469 */     if ((paramClass1 == float.class && paramClass2 == Float.class) || (paramClass1 == Float.class && paramClass2 == float.class))
/*      */     {
/* 1471 */       return true;
/*      */     }
/*      */     
/* 1474 */     if ((paramClass1 == boolean.class && paramClass2 == Boolean.class) || (paramClass1 == Boolean.class && paramClass2 == boolean.class))
/*      */     {
/* 1476 */       return true;
/*      */     }
/*      */     
/* 1479 */     if ((paramClass1 == char.class && paramClass2 == Character.class) || (paramClass1 == Character.class && paramClass2 == char.class))
/*      */     {
/* 1481 */       return true;
/*      */     }
/*      */     
/* 1484 */     if ((paramClass1 == short.class && paramClass2 == Short.class) || (paramClass1 == Short.class && paramClass2 == short.class))
/*      */     {
/* 1486 */       return true;
/*      */     }
/*      */     
/* 1489 */     if ((paramClass1 == long.class && paramClass2 == Long.class) || (paramClass1 == Long.class && paramClass2 == long.class))
/*      */     {
/* 1491 */       return true;
/*      */     }
/*      */     
/* 1494 */     if ((paramClass1 == double.class && paramClass2 == Double.class) || (paramClass1 == Double.class && paramClass2 == double.class))
/*      */     {
/* 1496 */       return true;
/*      */     }
/*      */     
/* 1499 */     return false;
/*      */   }
/*      */   
/*      */   private HandlerInfo initReliableDelivery(ReliableDeliveryMBean paramReliableDeliveryMBean) {
/* 1503 */     HashMap hashMap = new HashMap(5);
/* 1504 */     hashMap.put("dup_elim_param", new Boolean(paramReliableDeliveryMBean.isDuplicateElimination()));
/*      */     
/* 1506 */     hashMap.put("in_order_delivery_param", new Boolean(paramReliableDeliveryMBean.isInOrderDelivery()));
/*      */     
/* 1508 */     hashMap.put("retries_param", new Integer(paramReliableDeliveryMBean.getRetries()));
/*      */     
/* 1510 */     hashMap.put("retry_interval_param", new Integer(paramReliableDeliveryMBean.getRetryInterval()));
/*      */     
/* 1512 */     hashMap.put("persist_interval_param", new Integer(paramReliableDeliveryMBean.getPersistDuration()));
/*      */     
/* 1514 */     return new HandlerInfo(weblogic.webservice.saf.DupsEliminationHandler.class, hashMap, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setCharset(String paramString, WebService paramWebService) {
/* 1522 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 1523 */       Port port = (Port)iterator.next();
/* 1524 */       port.getBindingInfo().setCharset(paramString);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addJmsPorts(String paramString, WebService paramWebService) {
/* 1529 */     ArrayList arrayList = new ArrayList();
/*      */     
/* 1531 */     for (null = paramWebService.getPorts(); null.hasNext();) {
/* 1532 */       arrayList.add(null.next());
/*      */     }
/*      */     
/* 1535 */     for (Port port1 : arrayList) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1540 */       String str = port1.getName();
/*      */       
/* 1542 */       str = str + "JMS";
/* 1543 */       Port port2 = paramWebService.addPort(str);
/* 1544 */       JMSBindingInfo jMSBindingInfo = new JMSBindingInfo();
/* 1545 */       jMSBindingInfo.setAddress("jms://localhost:7001/" + paramString + "?URI=junk");
/* 1546 */       port2.setBindingInfo(jMSBindingInfo);
/* 1547 */       port2.setTypeName(port1.getTypeName());
/* 1548 */       addOperationsToNewPort(port2, port1);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void isJMSOperations(Port paramPort) {
/* 1553 */     for (Iterator iterator = paramPort.getOperations(); iterator.hasNext(); ) {
/* 1554 */       Operation operation = (Operation)iterator.next();
/*      */       
/* 1556 */       if (!operation.isOneway()) {
/* 1557 */         throw new JAXRPCException("Operation '" + operation.getName() + "' " + "in port '" + paramPort.getName() + "' is not oneway. Only one way " + "operations are supported by JMS transport. Please edit the " + "web-services.xml DD file to make this operation oneway");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addSoap12Ports(WebService paramWebService) {
/* 1566 */     ArrayList arrayList = new ArrayList();
/*      */     
/* 1568 */     for (null = paramWebService.getPorts(); null.hasNext();) {
/* 1569 */       arrayList.add(null.next());
/*      */     }
/*      */     
/* 1572 */     for (Port port1 : arrayList) {
/*      */ 
/*      */       
/* 1575 */       String str = port1.getName();
/*      */       
/* 1577 */       str = str + (str.endsWith("Soap") ? "12" : "Soap12");
/* 1578 */       Port port2 = paramWebService.addPort(str);
/* 1579 */       port2.getBindingInfo().setType("SOAP1.2");
/* 1580 */       port2.setTypeName(port1.getTypeName());
/* 1581 */       addOperationsToNewPort(port2, port1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addOperationsToNewPort(Port paramPort1, Port paramPort2) {
/* 1589 */     for (Iterator iterator = paramPort2.getOperations(); iterator.hasNext(); ) {
/* 1590 */       Operation operation = (Operation)iterator.next();
/* 1591 */       paramPort1.addOperation(operation);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addConversationSchema(WebService paramWebService) {
/* 1596 */     boolean bool = false;
/* 1597 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 1598 */       Iterator iterator1 = ((Port)iterator.next()).getOperations();
/* 1599 */       while (iterator1.hasNext()) {
/* 1600 */         String str = ((Operation)iterator1.next()).getConversationPhase();
/* 1601 */         if (str != null && !str.equals("NONE")) {
/* 1602 */           bool = true;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1606 */       if (bool)
/*      */         break; 
/*      */     } 
/* 1609 */     if (!bool)
/*      */       return; 
/* 1611 */     XMLNode xMLNode1 = paramWebService.getTypes();
/* 1612 */     if (xMLNode1 == null) {
/* 1613 */       XMLName xMLName = ElementFactory.createXMLName("http://www.openuri.org/2002/04/soap/conversation/", "types");
/*      */ 
/*      */       
/* 1616 */       xMLNode1 = new XMLNode(xMLName);
/* 1617 */       paramWebService.setTypes(xMLNode1);
/*      */     } 
/*      */     
/* 1620 */     XMLNode xMLNode2 = xMLNode1.addChild("schema", "xsd");
/* 1621 */     xMLNode2.addNamespace("xsd", "http://www.w3.org/2001/XMLSchema");
/* 1622 */     xMLNode2.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
/* 1623 */     xMLNode2.addAttribute("targetNamespace", null, null, "http://www.openuri.org/2002/04/soap/conversation/");
/*      */ 
/*      */     
/* 1626 */     xMLNode2.addAttribute("elementFormDefault", null, null, "qualified");
/*      */     
/* 1628 */     XMLNode xMLNode3 = xMLNode2.addChild("element", "xsd");
/* 1629 */     xMLNode3.addAttribute("name", null, null, "StartHeader");
/* 1630 */     xMLNode3.addAttribute("type", null, null, "conv:StartHeader");
/*      */     
/* 1632 */     xMLNode3 = xMLNode2.addChild("element", "xsd");
/* 1633 */     xMLNode3.addAttribute("name", null, null, "ContinueHeader");
/* 1634 */     xMLNode3.addAttribute("type", null, null, "conv:ContinueHeader");
/*      */     
/* 1636 */     XMLNode xMLNode4 = xMLNode2.addChild("complexType", "xsd");
/* 1637 */     xMLNode4.addAttribute("name", null, null, "StartHeader");
/* 1638 */     XMLNode xMLNode5 = xMLNode4.addChild("sequence", "xsd");
/* 1639 */     XMLNode xMLNode6 = xMLNode5.addChild("element", "xsd");
/* 1640 */     xMLNode6.addAttribute("name", null, null, "conversationID");
/* 1641 */     xMLNode6.addAttribute("minOccurs", null, null, "0");
/* 1642 */     xMLNode6.addAttribute("maxOccurs", null, null, "1");
/* 1643 */     xMLNode6.addAttribute("type", null, null, "xsd:string");
/*      */     
/* 1645 */     xMLNode4 = xMLNode2.addChild("complexType", "xsd");
/* 1646 */     xMLNode4.addAttribute("name", null, null, "ContinueHeader");
/* 1647 */     xMLNode5 = xMLNode4.addChild("sequence", "xsd");
/* 1648 */     xMLNode6 = xMLNode5.addChild("element", "xsd");
/* 1649 */     xMLNode6.addAttribute("name", null, null, "conversationID");
/* 1650 */     xMLNode6.addAttribute("type", null, null, "xsd:string");
/* 1651 */     xMLNode6.addAttribute("minOccurs", null, null, "1");
/* 1652 */     xMLNode6.addAttribute("maxOccurs", null, null, "1");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void addDocumentStyleSupport(WebService paramWebService, TypeMappingBuilder paramTypeMappingBuilder) throws ConfigException {
/* 1658 */     Port port = (Port)paramWebService.getPorts().next();
/* 1659 */     if ("document".equals(port.getStyle())) {
/* 1660 */       ArrayList arrayList1 = new ArrayList();
/* 1661 */       ArrayList arrayList2 = new ArrayList();
/*      */       
/* 1663 */       for (iterator = port.getOperations(); iterator.hasNext(); ) {
/* 1664 */         Operation operation = (Operation)iterator.next();
/* 1665 */         String str = paramWebService.getTargetNamespace();
/* 1666 */         XMLName xMLName1 = ElementFactory.createXMLName(str, operation.getName());
/* 1667 */         XMLName xMLName2 = ElementFactory.createXMLName(str, operation.getName() + "Response");
/*      */         
/* 1669 */         Part part = null;
/*      */         Iterator iterator1;
/* 1671 */         for (iterator1 = operation.getInput().getParts(); iterator1.hasNext(); ) {
/* 1672 */           Part part1 = (Part)iterator1.next();
/*      */           
/* 1674 */           if (part1.isHeader()) {
/*      */             continue;
/*      */           }
/*      */           
/* 1678 */           if (part == null) {
/* 1679 */             part = part1; continue;
/*      */           } 
/* 1681 */           throw new ConfigException("ERROR: Backend components for Document style webservice can only accept methods with one input parameter. Operation \"" + operation.getName() + "\" of the " + "webservice \"" + paramWebService.getName() + "\" is ignored.");
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1689 */         if (part != null) {
/* 1690 */           part.setElement();
/*      */           
/* 1692 */           if (!noDynamicTypeGeneration && !isElement(paramWebService.getTypes(), part.getXMLType())) {
/*      */             
/* 1694 */             arrayList1.add(part.getJavaType());
/* 1695 */             arrayList2.add(xMLName1);
/* 1696 */             part.setXMLType(operation.getName(), str);
/*      */           } 
/*      */         } 
/*      */         
/* 1700 */         if (operation.getReturnPart() != null) {
/* 1701 */           Part part1 = operation.getReturnPart();
/* 1702 */           part1.setElement();
/* 1703 */           if (!noDynamicTypeGeneration && !isElement(paramWebService.getTypes(), part1.getXMLType())) {
/*      */             
/* 1705 */             arrayList1.add(part1.getJavaType());
/* 1706 */             arrayList2.add(xMLName2);
/* 1707 */             part1.setXMLType(operation.getName() + "Response", str);
/*      */           } 
/*      */         } 
/*      */         
/* 1711 */         for (iterator1 = operation.getFaults(); iterator1.hasNext(); ) {
/* 1712 */           Message message = (Message)iterator1.next();
/* 1713 */           Part part1 = (Part)message.getParts().next();
/* 1714 */           part1.setElement();
/* 1715 */           if (!isElement(paramWebService.getTypes(), part1.getXMLType())) {
/*      */ 
/*      */             
/* 1718 */             XMLName xMLName = ElementFactory.createXMLName(part1.getXMLType().getNamespaceURI(), message.getName());
/* 1719 */             if (arrayList2.contains(xMLName))
/* 1720 */               continue;  Class clazz = ExceptionUtil.getSingleSimpleProperty(part1.getJavaType());
/* 1721 */             if (clazz != null) {
/* 1722 */               arrayList1.add(clazz);
/*      */             } else {
/* 1724 */               arrayList1.add(part1.getJavaType());
/*      */             } 
/* 1726 */             arrayList2.add(xMLName);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*      */       try {
/* 1732 */         paramTypeMappingBuilder.addMapping((Class[])arrayList1.toArray(new Class[0]), (XMLName[])arrayList2.toArray(new XMLName[0]));
/*      */       
/*      */       }
/* 1735 */       catch (BindingException iterator) {
/* 1736 */         throw new ConfigException("Failed to generate element document operations", iterator);
/*      */       } 
/* 1738 */       mergeSchema(paramWebService, paramTypeMappingBuilder);
/*      */     }
/* 1740 */     else if ("documentwrapped".equals(port.getStyle())) {
/* 1741 */       ArrayList arrayList1 = new ArrayList();
/* 1742 */       ArrayList arrayList2 = new ArrayList();
/*      */       
/* 1744 */       for (iterator = port.getOperations(); iterator.hasNext(); ) {
/* 1745 */         Operation operation = (Operation)iterator.next();
/* 1746 */         String str = paramWebService.getTargetNamespace();
/* 1747 */         XMLName xMLName1 = ElementFactory.createXMLName(str, operation.getName());
/* 1748 */         XMLName xMLName2 = ElementFactory.createXMLName(str, operation.getName() + "Response");
/*      */         
/* 1750 */         if (!operation.getInput().getParts().hasNext()) {
/* 1751 */           addEmptyElement(paramTypeMappingBuilder, xMLName1);
/*      */         } else {
/* 1753 */           ArrayList arrayList3 = new ArrayList();
/* 1754 */           ArrayList arrayList4 = new ArrayList();
/* 1755 */           for (iterator2 = operation.getInput().getParts(); iterator2.hasNext(); ) {
/* 1756 */             Part part = (Part)iterator2.next();
/* 1757 */             arrayList3.add(part.getJavaType());
/* 1758 */             arrayList4.add(part.getName());
/*      */           } 
/*      */           try {
/* 1761 */             paramTypeMappingBuilder.addWrappedSchemaType((Class[])arrayList3.toArray(new Class[0]), (String[])arrayList4.toArray(new String[0]), xMLName1);
/*      */ 
/*      */           
/*      */           }
/* 1765 */           catch (BindingException iterator2) {
/* 1766 */             throw new ConfigException("Failed to generate element document operations", iterator2);
/*      */           } 
/*      */         } 
/*      */         
/* 1770 */         if (operation.getReturnPart() != null) {
/*      */           try {
/* 1772 */             paramTypeMappingBuilder.addWrappedSchemaType(new Class[] { operation.getReturnPart().getJavaType() }, new String[] { operation.getReturnPart().getName() }, xMLName2);
/*      */ 
/*      */           
/*      */           }
/* 1776 */           catch (BindingException bindingException) {
/* 1777 */             throw new ConfigException("Failed to generate element document operations", bindingException);
/*      */           } 
/*      */         } else {
/* 1780 */           addEmptyElement(paramTypeMappingBuilder, xMLName2);
/*      */         } 
/*      */         
/* 1783 */         for (Iterator iterator1 = operation.getFaults(); iterator1.hasNext(); ) {
/* 1784 */           Message message = (Message)iterator1.next();
/* 1785 */           Part part = (Part)message.getParts().next();
/* 1786 */           part.setElement();
/* 1787 */           if (!isElement(paramWebService.getTypes(), part.getXMLType())) {
/* 1788 */             XMLName xMLName = ElementFactory.createXMLName(str, message.getName());
/* 1789 */             part.setXMLType(xMLName.getLocalName(), str);
/* 1790 */             if (arrayList2.contains(xMLName))
/* 1791 */               continue;  Class clazz = ExceptionUtil.getSingleSimpleProperty(part.getJavaType());
/* 1792 */             if (clazz != null) {
/* 1793 */               arrayList1.add(clazz);
/*      */             } else {
/* 1795 */               arrayList1.add(part.getJavaType());
/*      */             } 
/* 1797 */             arrayList2.add(xMLName);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1802 */       if (arrayList1.size() > 0) {
/*      */         try {
/* 1804 */           paramTypeMappingBuilder.addMapping((Class[])arrayList1.toArray(new Class[0]), (XMLName[])arrayList2.toArray(new XMLName[0]));
/*      */         
/*      */         }
/* 1807 */         catch (BindingException iterator) {
/* 1808 */           throw new ConfigException("Failed to generate element for exceptions", iterator);
/*      */         } 
/*      */       }
/* 1811 */       mergeSchema(paramWebService, paramTypeMappingBuilder);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void mergeSchema(WebService paramWebService, TypeMappingBuilder paramTypeMappingBuilder) throws ConfigException {
/*      */     try {
/* 1819 */       XMLNode xMLNode = new XMLNode();
/* 1820 */       xMLNode.setName("types", null, null);
/* 1821 */       XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream(xMLNode);
/*      */       
/* 1823 */       paramTypeMappingBuilder.writeGeneratedSchemas(xMLNodeOutputStream);
/* 1824 */       xMLNodeOutputStream.flush();
/*      */       
/* 1826 */       if (paramWebService.getTypes() == null) {
/* 1827 */         paramWebService.setTypes(xMLNode);
/*      */       } else {
/* 1829 */         XMLNode xMLNode1 = new XMLNode();
/* 1830 */         xMLNode1.setName("types", null, null);
/* 1831 */         XMLNodeOutputStream xMLNodeOutputStream1 = new XMLNodeOutputStream(xMLNode1);
/*      */         
/* 1833 */         MergeSchemas.merge(xMLNodeOutputStream1, new XMLInputStream[] { paramWebService.getTypes().stream(), xMLNode.stream() });
/*      */ 
/*      */         
/* 1836 */         xMLNodeOutputStream1.flush();
/* 1837 */         paramWebService.setTypes(xMLNode1);
/*      */       } 
/* 1839 */     } catch (XMLStreamException xMLStreamException) {
/* 1840 */       throw new ConfigException("Failed to add generated schema", xMLStreamException);
/* 1841 */     } catch (BindingException bindingException) {
/* 1842 */       throw new ConfigException("Failed to add generated schema", bindingException);
/* 1843 */     } catch (XSDException xSDException) {
/* 1844 */       throw new ConfigException("Failed to add generated schema", xSDException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void addEmptyElement(TypeMappingBuilder paramTypeMappingBuilder, XMLName paramXMLName) throws ConfigException {
/*      */     try {
/* 1852 */       paramTypeMappingBuilder.addWrappedSchemaType(new Class[0], new String[0], paramXMLName);
/* 1853 */     } catch (BindingException bindingException) {
/* 1854 */       throw new ConfigException("Failed to add empty element", bindingException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isElement(XMLNode paramXMLNode, QName paramQName) {
/* 1863 */     if (paramXMLNode == null) {
/* 1864 */       return false;
/*      */     }
/*      */     
/* 1867 */     Iterator iterator = paramXMLNode.getChildren("schema", "http://www.w3.org/2001/XMLSchema");
/*      */     
/* 1869 */     while (iterator.hasNext()) {
/* 1870 */       XMLNode xMLNode = (XMLNode)iterator.next();
/* 1871 */       String str1 = paramQName.getNamespaceURI();
/* 1872 */       String str2 = xMLNode.getAttribute("targetNamespace", null);
/*      */       
/* 1874 */       if ((str1 == null && str2 == null) || (str1.equals("") && str2 == null) || (str1 == null && str2.equals("")) || str1.equals(str2))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1879 */         for (Iterator iterator1 = xMLNode.getChildren("element", null); iterator1.hasNext(); ) {
/* 1880 */           XMLNode xMLNode1 = (XMLNode)iterator1.next();
/* 1881 */           if (paramQName.getLocalPart().equals(xMLNode1.getAttribute("name", null))) {
/* 1882 */             return true;
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1889 */     return false;
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WebServiceFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */