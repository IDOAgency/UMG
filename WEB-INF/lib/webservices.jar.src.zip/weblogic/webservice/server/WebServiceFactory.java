package weblogic.webservice.server;

import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import javax.naming.NamingException;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.handler.HandlerInfo;
import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;
import weblogic.management.descriptors.webservice.ComponentsMBean;
import weblogic.management.descriptors.webservice.FaultMBean;
import weblogic.management.descriptors.webservice.HandlerChainMBean;
import weblogic.management.descriptors.webservice.HandlerMBean;
import weblogic.management.descriptors.webservice.InitParamMBean;
import weblogic.management.descriptors.webservice.InitParamsMBean;
import weblogic.management.descriptors.webservice.JMSReceiveQueueMBean;
import weblogic.management.descriptors.webservice.JMSReceiveTopicMBean;
import weblogic.management.descriptors.webservice.JMSSendDestinationMBean;
import weblogic.management.descriptors.webservice.JavaClassMBean;
import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.OperationsMBean;
import weblogic.management.descriptors.webservice.ParamMBean;
import weblogic.management.descriptors.webservice.ParamsMBean;
import weblogic.management.descriptors.webservice.ReliableDeliveryMBean;
import weblogic.management.descriptors.webservice.ReturnParamMBean;
import weblogic.management.descriptors.webservice.StatefulJavaClassMBean;
import weblogic.management.descriptors.webservice.StatelessEJBMBean;
import weblogic.management.descriptors.webservice.TypeMappingEntryMBean;
import weblogic.management.descriptors.webservice.TypeMappingMBean;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.utils.AssertionError;
import weblogic.utils.reflect.ReflectUtils;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.WSServerService;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceFactory;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.jms.JMSBindingInfo;
import weblogic.webservice.component.javaclass.JavaClassInvocationHandler;
import weblogic.webservice.component.javaclass.StatefulInvocationHandler;
import weblogic.webservice.component.jms.JMSQueueReceiveInvocationHandler;
import weblogic.webservice.component.jms.JMSSendInvocationHandler;
import weblogic.webservice.component.jms.JMSTopicReceiveInvocationHandler;
import weblogic.webservice.component.slsb.SLSBInvocationHandler;
import weblogic.webservice.core.encoding.DefaultRegistry;
import weblogic.webservice.core.handler.WSSEHandler;
import weblogic.webservice.dd.ComponentIntrospector;
import weblogic.webservice.dd.MethodDescriptor;
import weblogic.webservice.tools.MethodIterator;
import weblogic.webservice.util.AttachmentUtil;
import weblogic.webservice.util.EJBHelper;
import weblogic.webservice.util.ExceptionUtil;
import weblogic.webservice.util.HolderUtil;
import weblogic.webservice.util.SmartNameStore;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.Deserializer;
import weblogic.xml.schema.binding.Serializer;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.TypeMappingBuilder;
import weblogic.xml.schema.binding.TypeMappingBuilderFactory;
import weblogic.xml.schema.binding.internal.codegen.ArrayUtils;
import weblogic.xml.schema.binding.util.StdNamespace;
import weblogic.xml.schema.model.XSDException;
import weblogic.xml.schema.model.util.MergeSchemas;
import weblogic.xml.security.specs.SecurityDD;
import weblogic.xml.stream.ElementFactory;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeOutputStream;
import weblogic.xml.xmlnode.XMLNodeSet;

public class WebServiceFactory extends WebServiceFactory {
  private static final boolean noDynamicTypeGeneration = "true".equalsIgnoreCase(System.getProperty("weblogic.webservice.noDynamicTypeGeneration"));
  
  public static WebServiceFactory newFactoryInstance() { return new WebServiceFactory(); }
  
  private static final HandlerInfo invokeHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.InvokeHandler.class, null, null);
  
  private HandlerInfo authHandlerInfo;
  
  private static final HandlerInfo conversationHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.ServerConversationHandler.class, null, null);
  
  private static int defaultPersistDuration = initDefaultPersistDuration();
  
  private static int initDefaultPersistDuration() {
    int i = -1;
    WSServerService wSServerService = WSServerService.getWSServerService();
    if (wSServerService != null) {
      WSReliableDeliveryPolicyMBean wSReliableDeliveryPolicyMBean = wSServerService.getReliableDeliveryPolicyMBean();
      if (wSReliableDeliveryPolicyMBean != null)
        i = wSReliableDeliveryPolicyMBean.getDefaultTimeToLive(); 
    } 
    return i;
  }
  
  public WebService createFromMBean(WebServiceMBean paramWebServiceMBean, AuthorizationContext paramAuthorizationContext) throws ConfigException {
    HashMap hashMap = new HashMap();
    hashMap.put("WSAuthorizationContext", paramAuthorizationContext);
    this.authHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.AuthorizationHandler.class, hashMap, null);
    WebService webService = createFromMBean(paramWebServiceMBean, (Map)null);
    initServerHandlerInfos(webService, hashMap);
    return webService;
  }
  
  public WebService createFromMBean(WebServiceMBean paramWebServiceMBean, Map paramMap) throws ConfigException {
    String str1 = paramWebServiceMBean.getWebServiceName();
    String str2 = paramWebServiceMBean.getProtocol();
    String str3 = paramWebServiceMBean.getTargetNamespace();
    int i = paramWebServiceMBean.getResponseBufferSize();
    WebService webService = create(str3, str1);
    if (paramWebServiceMBean.getSecurity() != null)
      initSecurityDD(paramWebServiceMBean, webService); 
    XMLNodeSet xMLNodeSet = paramWebServiceMBean.getTypes();
    if (xMLNodeSet != null)
      webService.setTypes(xMLNodeSet.getAsXMLNode(new Name("types"))); 
    TypeMappingBuilder typeMappingBuilder = initTypeMaps(webService, paramWebServiceMBean);
    ComponentsMBean componentsMBean = paramWebServiceMBean.getComponents();
    HashMap hashMap = new HashMap();
    if (componentsMBean != null) {
      boolean bool = (paramMap == null);
      hashMap = initComponents(componentsMBean, bool);
    } 
    if (str2 != null)
      webService.setProtocol(str2); 
    if (i > -1)
      webService.setResponseBufferSize(i); 
    webService.setExposeWSDL(paramWebServiceMBean.getExposeWSDL());
    webService.setExposeHomePage(paramWebServiceMBean.getExposeHomePage());
    webService.setHandleAllActors(paramWebServiceMBean.getHandleAllActors());
    OperationsMBean operationsMBean = paramWebServiceMBean.getOperations();
    if (operationsMBean == null)
      throw new ConfigException("Cannot create a WebService with no operations"); 
    initOperations(operationsMBean, webService, hashMap, paramMap, str3, paramWebServiceMBean);
    updateParameterOrder(webService);
    if (paramWebServiceMBean.getUseSOAP12())
      addSoap12Ports(webService); 
    if (paramWebServiceMBean.getJmsURI() != null)
      addJmsPorts(paramWebServiceMBean.getJmsURI(), webService); 
    if (paramWebServiceMBean.getCharset() != null)
      setCharset(paramWebServiceMBean.getCharset(), webService); 
    addConversationSchema(webService);
    addDocumentStyleSupport(webService, typeMappingBuilder);
    checkForUniqueFaultNames(webService);
    return webService;
  }
  
  private void checkForUniqueFaultNames(WebService paramWebService) {
    HashSet hashSet = new HashSet();
    HashMap hashMap = new HashMap();
    Iterator iterator = paramWebService.getPorts();
    while (iterator.hasNext()) {
      Port port = (Port)iterator.next();
      Iterator iterator1 = port.getOperations();
      while (iterator1.hasNext()) {
        Operation operation = (Operation)iterator1.next();
        Iterator iterator2 = operation.getFaults();
        while (iterator2.hasNext()) {
          Message message = (Message)iterator2.next();
          String str = message.getName();
          if (hashMap.containsKey(str))
            continue; 
          Iterator iterator3 = message.getParts();
          while (iterator3.hasNext()) {
            Part part = (Part)iterator3.next();
            part.setName(getUniqueName(part.getName(), hashSet));
            hashMap.put(str, str);
          } 
        } 
      } 
    } 
  }
  
  private void initSecurityDD(WebServiceMBean paramWebServiceMBean, WebService paramWebService) throws ConfigException {
    SecurityDD securityDD = null;
    try {
      securityDD = new SecurityDD(paramWebServiceMBean.getSecurity().stream());
    } catch (XMLStreamException xMLStreamException) {
      throw new ConfigException("Failed to create securityDD object. ");
    } 
    paramWebService.setSecurity(securityDD);
  }
  
  private void initServerHandlerInfos(WebService paramWebService, Map paramMap) throws ConfigException {
    SecurityDD securityDD = paramWebService.getSecurity();
    if (securityDD != null) {
      HandlerInfo handlerInfo = new HandlerInfo(WSSEHandler.class, paramMap, null);
      WSSEHandler.initHandlerInfo(securityDD, handlerInfo);
      paramWebService.setHandlerInfos(new HandlerInfo[] { handlerInfo });
    } 
  }
  
  private String[] getPortNames(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
    ArrayList arrayList = new ArrayList();
    while (stringTokenizer.hasMoreTokens())
      arrayList.add(stringTokenizer.nextToken()); 
    return (String[])arrayList.toArray(new String[arrayList.size()]);
  }
  
  private Iterator getPorts(WebService paramWebService, String paramString1, String paramString2, String paramString3) {
    if (paramString1 == null)
      paramString1 = paramWebService.getName() + "Port"; 
    String[] arrayOfString = getPortNames(paramString1);
    if (arrayOfString.length > 1 && paramString2 != null)
      throw new JAXRPCException("can not set portName for multiple ports. In the case of multiple ports, portName and portTypeName are the same"); 
    ArrayList arrayList = new ArrayList();
    for (byte b = 0; b < arrayOfString.length; b++) {
      Port port = paramWebService.getPort(arrayOfString[b]);
      if (port == null) {
        if (paramString2 == null) {
          port = paramWebService.addPort(arrayOfString[b]);
        } else {
          port = paramWebService.addPort(paramString2);
        } 
        port.setTypeName(arrayOfString[b]);
        port.setStyle(paramString3);
      } 
      arrayList.add(port);
    } 
    return arrayList.iterator();
  }
  
  private TypeMappingBuilder initTypeMaps(WebService paramWebService, WebServiceMBean paramWebServiceMBean) throws ConfigException {
    DefaultRegistry defaultRegistry;
    try {
      defaultRegistry = new DefaultRegistry();
    } catch (JAXRPCException jAXRPCException) {
      throw new ConfigException("failed to create type mapping registry: ", jAXRPCException);
    } 
    TypeMappingBuilder typeMappingBuilder = TypeMappingBuilderFactory.newInstance().createTypeMappingBuilder();
    try {
      TypeMapping typeMapping = typeMappingBuilder.getTypeMapping();
      defaultRegistry.register(StdNamespace.instance().soapEncoding(), (TypeMapping)typeMapping);
      TypeMappingMBean typeMappingMBean = paramWebServiceMBean.getTypeMapping();
      if (typeMappingMBean != null) {
        TypeMappingEntryMBean[] arrayOfTypeMappingEntryMBean = typeMappingMBean.getTypeMappingEntries();
        int i = arrayOfTypeMappingEntryMBean.length;
        for (byte b = 0; b < i; b++)
          typeMapping.add(loadClass(arrayOfTypeMappingEntryMBean[b].getClassName()), arrayOfTypeMappingEntryMBean[b].getXSDTypeName(), (Serializer)loadClass(arrayOfTypeMappingEntryMBean[b].getSerializerName()).newInstance(), (Deserializer)loadClass(arrayOfTypeMappingEntryMBean[b].getDeserializerName()).newInstance()); 
      } 
    } catch (Exception exception) {
      throw new ConfigException("failed to add type mapping to registry: ", exception);
    } 
    paramWebService.setTypeMappingRegistry(defaultRegistry);
    return typeMappingBuilder;
  }
  
  private HashMap initComponents(ComponentsMBean paramComponentsMBean, boolean paramBoolean) throws ConfigException {
    HashMap hashMap = new HashMap();
    StatelessEJBMBean[] arrayOfStatelessEJBMBean = paramComponentsMBean.getStatelessEJBs();
    if (arrayOfStatelessEJBMBean != null)
      for (byte b = 0; b < arrayOfStatelessEJBMBean.length; b++) {
        try {
          if (paramBoolean) {
            hashMap.put(arrayOfStatelessEJBMBean[b].getComponentName(), new SLSBInvocationHandler(EJBHelper.getEJBHome(arrayOfStatelessEJBMBean[b])));
          } else {
            hashMap.put(arrayOfStatelessEJBMBean[b].getComponentName(), null);
          } 
        } catch (NamingException namingException) {
          throw new AssertionError(namingException);
        } 
      }  
    JavaClassMBean[] arrayOfJavaClassMBean = paramComponentsMBean.getJavaClassComponents();
    if (arrayOfJavaClassMBean != null)
      for (byte b = 0; b < arrayOfJavaClassMBean.length; b++) {
        try {
          if (paramBoolean) {
            Class clazz = loadClass(arrayOfJavaClassMBean[b].getClassName());
            JavaClassInvocationHandler javaClassInvocationHandler = new JavaClassInvocationHandler(clazz);
            hashMap.put(arrayOfJavaClassMBean[b].getComponentName(), javaClassInvocationHandler);
          } else {
            hashMap.put(arrayOfJavaClassMBean[b].getComponentName(), null);
          } 
        } catch (InstantiationException instantiationException) {
          throw new ConfigException("failed to create invocation handler");
        } 
      }  
    StatefulJavaClassMBean[] arrayOfStatefulJavaClassMBean = paramComponentsMBean.getStatefulJavaClassComponents();
    if (arrayOfStatefulJavaClassMBean != null)
      for (byte b = 0; b < arrayOfStatefulJavaClassMBean.length; b++) {
        try {
          if (paramBoolean) {
            Class clazz = loadClass(arrayOfStatefulJavaClassMBean[b].getClassName());
            StatefulInvocationHandler statefulInvocationHandler = new StatefulInvocationHandler(clazz);
            hashMap.put(arrayOfStatefulJavaClassMBean[b].getComponentName(), statefulInvocationHandler);
          } else {
            hashMap.put(arrayOfStatefulJavaClassMBean[b].getComponentName(), null);
          } 
        } catch (InstantiationException instantiationException) {
          throw new ConfigException("failed to create invocation handler" + instantiationException);
        } 
      }  
    JMSSendDestinationMBean[] arrayOfJMSSendDestinationMBean = paramComponentsMBean.getJMSSendDestinations();
    if (arrayOfJMSSendDestinationMBean != null)
      for (byte b = 0; b < arrayOfJMSSendDestinationMBean.length; b++) {
        if (paramBoolean) {
          String str1 = arrayOfJMSSendDestinationMBean[b].getJNDIName().getPath();
          String str2 = arrayOfJMSSendDestinationMBean[b].getConnectionFactory();
          JMSSendInvocationHandler jMSSendInvocationHandler = new JMSSendInvocationHandler(str2, str1);
          hashMap.put(arrayOfJMSSendDestinationMBean[b].getComponentName(), jMSSendInvocationHandler);
        } else {
          hashMap.put(arrayOfJMSSendDestinationMBean[b].getComponentName(), null);
        } 
      }  
    JMSReceiveQueueMBean[] arrayOfJMSReceiveQueueMBean = paramComponentsMBean.getJMSReceiveQueues();
    if (arrayOfJMSReceiveQueueMBean != null)
      for (byte b = 0; b < arrayOfJMSReceiveQueueMBean.length; b++) {
        if (paramBoolean) {
          String str1 = arrayOfJMSReceiveQueueMBean[b].getJNDIName().getPath();
          String str2 = arrayOfJMSReceiveQueueMBean[b].getConnectionFactory();
          JMSQueueReceiveInvocationHandler jMSQueueReceiveInvocationHandler = new JMSQueueReceiveInvocationHandler(str2, str1);
          hashMap.put(arrayOfJMSReceiveQueueMBean[b].getComponentName(), jMSQueueReceiveInvocationHandler);
        } else {
          hashMap.put(arrayOfJMSReceiveQueueMBean[b].getComponentName(), null);
        } 
      }  
    JMSReceiveTopicMBean[] arrayOfJMSReceiveTopicMBean = paramComponentsMBean.getJMSReceiveTopics();
    if (arrayOfJMSReceiveTopicMBean != null)
      for (byte b = 0; b < arrayOfJMSReceiveTopicMBean.length; b++) {
        if (paramBoolean) {
          String str1 = arrayOfJMSReceiveTopicMBean[b].getJNDIName().getPath();
          String str2 = arrayOfJMSReceiveTopicMBean[b].getConnectionFactory();
          JMSTopicReceiveInvocationHandler jMSTopicReceiveInvocationHandler = new JMSTopicReceiveInvocationHandler(str2, str1);
          hashMap.put(arrayOfJMSReceiveTopicMBean[b].getComponentName(), jMSTopicReceiveInvocationHandler);
        } else {
          hashMap.put(arrayOfJMSReceiveTopicMBean[b].getComponentName(), null);
        } 
      }  
    return hashMap;
  }
  
  private HandlerInfo[] getHandlerInfos(OperationMBean paramOperationMBean) throws ConfigException {
    HandlerChainMBean handlerChainMBean = paramOperationMBean.getHandlerChain();
    HandlerInfo handlerInfo = null;
    ReliableDeliveryMBean reliableDeliveryMBean = paramOperationMBean.getReliableDelivery();
    if (reliableDeliveryMBean != null)
      handlerInfo = initReliableDelivery(reliableDeliveryMBean); 
    ArrayList arrayList = new ArrayList();
    if (this.authHandlerInfo != null)
      arrayList.add(this.authHandlerInfo); 
    arrayList.add(conversationHandlerInfo);
    if (handlerInfo != null)
      arrayList.add(handlerInfo); 
    if (handlerChainMBean != null) {
      HandlerMBean[] arrayOfHandlerMBean = handlerChainMBean.getHandlers();
      for (byte b = 0; b < arrayOfHandlerMBean.length; b++) {
        Class clazz = loadClass(arrayOfHandlerMBean[b].getClassName());
        HashMap hashMap = new HashMap();
        InitParamsMBean initParamsMBean = arrayOfHandlerMBean[b].getInitParams();
        if (initParamsMBean != null) {
          InitParamMBean[] arrayOfInitParamMBean = initParamsMBean.getInitParams();
          for (byte b1 = 0; b1 < arrayOfInitParamMBean.length; b1++)
            hashMap.put(arrayOfInitParamMBean[b1].getParamName(), arrayOfInitParamMBean[b1].getParamValue()); 
        } 
        arrayList.add(new HandlerInfo(clazz, hashMap, null));
      } 
    } 
    if (paramOperationMBean.getComponentName() != null)
      arrayList.add(invokeHandlerInfo); 
    return (HandlerInfo[])arrayList.toArray(new HandlerInfo[0]);
  }
  
  private void initOperations(OperationsMBean paramOperationsMBean, WebService paramWebService, Map paramMap1, Map paramMap2, String paramString, WebServiceMBean paramWebServiceMBean) throws ConfigException {
    OperationMBean[] arrayOfOperationMBean = paramOperationsMBean.getOperations();
    if (arrayOfOperationMBean == null)
      throw new ConfigException("Cannot create a WebService with no operations"); 
    TypeMappingRegistry typeMappingRegistry = paramWebService.getTypeMappingRegistry();
    TypeMapping typeMapping = (TypeMapping)typeMappingRegistry.getTypeMapping(StdNamespace.instance().soapEncoding());
    if (typeMapping == null)
      throw new ConfigException("Cannot find TypeMapping"); 
    HashMap hashMap = new HashMap();
    for (byte b = 0; b < arrayOfOperationMBean.length; b++) {
      InvocationHandler invocationHandler = null;
      String str1 = arrayOfOperationMBean[b].getOperationName();
      if (str1 == null)
        str1 = arrayOfOperationMBean[b].getMethod(); 
      arrayOfOperationMBean[b].setStyle(paramWebServiceMBean.getStyle());
      String str2 = arrayOfOperationMBean[b].getComponentName();
      if (str2 != null) {
        invocationHandler = (InvocationHandler)paramMap1.get(str2);
        if (invocationHandler == null && paramMap2 == null)
          throw new ConfigException("No component '" + str2 + "' was found for operation '" + str1 + "'"); 
      } 
      String str3 = arrayOfOperationMBean[b].getPortTypeName();
      String str4 = paramWebServiceMBean.getPortName();
      if (str3 == null)
        str3 = paramWebServiceMBean.getPortTypeName(); 
      Iterator iterator = getPorts(paramWebService, str3, str4, paramWebServiceMBean.getStyle());
      boolean bool = false;
      if (invocationHandler != null && invocationHandler instanceof StatefulInvocationHandler)
        bool = true; 
      while (iterator.hasNext()) {
        Port port = (Port)iterator.next();
        HashSet hashSet = getUniqueNameStore(port.getTypeName(), hashMap);
        registerOperation(arrayOfOperationMBean[b], port, invocationHandler, paramMap2, typeMapping, paramString, hashSet, bool);
      } 
    } 
  }
  
  private HashSet getUniqueNameStore(String paramString, HashMap paramHashMap) {
    HashSet hashSet = (HashSet)paramHashMap.get(paramString);
    if (hashSet == null) {
      hashSet = new HashSet();
      paramHashMap.put(paramString, hashSet);
    } 
    return hashSet;
  }
  
  private void registerOperation(OperationMBean paramOperationMBean, Port paramPort, InvocationHandler paramInvocationHandler, Map paramMap, TypeMapping paramTypeMapping, String paramString, HashSet paramHashSet, boolean paramBoolean) throws ConfigException {
    MethodIterator methodIterator;
    String str1 = paramOperationMBean.getComponentName();
    String str2 = paramOperationMBean.getOperationName();
    String str3 = paramOperationMBean.getMethod();
    String str4 = paramString;
    String str5 = paramOperationMBean.getConversationPhase();
    int i = defaultPersistDuration;
    ReliableDeliveryMBean reliableDeliveryMBean = paramOperationMBean.getReliableDelivery();
    if (reliableDeliveryMBean != null) {
      i = reliableDeliveryMBean.getPersistDuration();
    } else {
      i = -1;
    } 
    if (str5 == null && paramBoolean)
      str5 = "CONTINUE"; 
    if (str2 == null)
      str2 = str3; 
    if (str3 == null)
      str3 = str2; 
    if (paramOperationMBean.getNamespace() != null)
      str4 = paramOperationMBean.getNamespace(); 
    if (str1 == null) {
      Operation operation = paramPort.addOperation(str2, getHandlerInfos(paramOperationMBean));
      if (paramOperationMBean.getParams() != null)
        addParamsToMethod((Method)null, operation, paramOperationMBean.getParams(), paramTypeMapping, str4); 
      return;
    } 
    boolean bool = isJMSHandler(paramInvocationHandler);
    if (paramMap == null) {
      if (bool || paramInvocationHandler == null) {
        methodIterator = new MethodIterator((Class)null);
      } else {
        methodIterator = introspectComponent(str1, paramInvocationHandler);
      } 
    } else {
      ComponentIntrospector componentIntrospector = (ComponentIntrospector)paramMap.get(str1);
      try {
        if (componentIntrospector != null) {
          methodIterator = componentIntrospector.getMethods();
        } else {
          methodIterator = new MethodIterator((Class)null);
        } 
      } catch (Exception exception) {
        String str = WebServiceLogger.logComponentIntrospectorException();
        WebServiceLogger.logStackTrace(str, exception);
        throw new ConfigException("Exception introspecting component '" + str1 + "'", exception);
      } 
    } 
    if (bool || (paramInvocationHandler == null && methodIterator == null)) {
      Operation operation = paramPort.addOperation(str2, getHandlerInfos(paramOperationMBean));
      addParamsToJMSComponent(operation, paramOperationMBean.getParams(), paramTypeMapping, str4);
      operation.setInvocationHandler(paramInvocationHandler);
      operation.setConversationPhase(str5);
      operation.setPersistDurationTime(i);
      operation.setStyle(paramOperationMBean.getStyle());
      if (paramOperationMBean.getInSecuritySpec() != null) {
        String str = paramOperationMBean.getInSecuritySpec();
        SecurityDD securityDD = paramPort.getService().getSecurity();
        if (securityDD == null || securityDD.getSecuritySpec(str) == null)
          throw new ConfigException("Operation " + paramOperationMBean.getName() + " is trying to refer to " + "a undefined security spec named " + str); 
        operation.getInput().setSecuritySpecRef(str);
      } 
      if (paramOperationMBean.getOutSecuritySpec() != null) {
        String str = paramOperationMBean.getOutSecuritySpec();
        SecurityDD securityDD = paramPort.getService().getSecurity();
        if (securityDD == null || securityDD.getSecuritySpec(str) == null)
          throw new ConfigException("Operation " + paramOperationMBean.getName() + " is trying to refer to " + "a undefined security spec named " + str); 
        operation.getOutput().setSecuritySpecRef(str);
      } 
      if (paramInvocationHandler != null)
        try {
          paramInvocationHandler.registerOperation(str2, str2, null);
        } catch (NoSuchMethodException noSuchMethodException) {
          throw new ConfigException(noSuchMethodException);
        }  
    } else if ("*".equals(str3)) {
      while (methodIterator.hasNext()) {
        Method method = methodIterator.next();
        str2 = method.getName();
        str2 = getUniqueName(str2, paramHashSet);
        Operation operation = paramPort.addOperation(str2, getHandlerInfos(paramOperationMBean));
        if ("one-way".equals(paramOperationMBean.getInvocationStyle()))
          operation.setOneway(true); 
        operation.setConversationPhase(str5);
        operation.setPersistDurationTime(i);
        operation.setStyle(paramOperationMBean.getStyle());
        addParamsToMethod(method, operation, paramTypeMapping, str4);
        operation.setInvocationHandler(paramInvocationHandler);
        if (paramInvocationHandler != null)
          try {
            paramInvocationHandler.registerOperation(str2, method.getName(), method.getParameterTypes());
          } catch (NoSuchMethodException noSuchMethodException) {
            throw new ConfigException(noSuchMethodException);
          }  
      } 
    } else {
      MethodDescriptor methodDescriptor = new MethodDescriptor(str3);
      str2 = paramOperationMBean.getOperationName();
      if (str2 == null)
        str2 = methodDescriptor.getName(); 
      str2 = getUniqueName(str2, paramHashSet);
      Operation operation = paramPort.addOperation(str2, getHandlerInfos(paramOperationMBean));
      operation.setConversationPhase(str5);
      operation.setPersistDurationTime(i);
      operation.setStyle(paramOperationMBean.getStyle());
      if ("one-way".equals(paramOperationMBean.getInvocationStyle()))
        operation.setOneway(true); 
      if (paramOperationMBean.getInSecuritySpec() != null) {
        String str = paramOperationMBean.getInSecuritySpec();
        SecurityDD securityDD = paramPort.getService().getSecurity();
        if (securityDD == null || securityDD.getSecuritySpec(str) == null)
          throw new ConfigException("Operation " + paramOperationMBean.getName() + " is trying to refer to " + "a undefined security spec named " + str); 
        operation.getInput().setSecuritySpecRef(str);
      } 
      if (paramOperationMBean.getOutSecuritySpec() != null) {
        String str = paramOperationMBean.getOutSecuritySpec();
        SecurityDD securityDD = paramPort.getService().getSecurity();
        if (securityDD == null || securityDD.getSecuritySpec(str) == null)
          throw new ConfigException("Operation " + paramOperationMBean.getName() + " is trying to refer to " + "a undefined security spec named " + str); 
        operation.getOutput().setSecuritySpecRef(str);
      } 
      ParamsMBean paramsMBean = paramOperationMBean.getParams();
      if (paramsMBean == null) {
        Method method = null;
        while (methodIterator.hasNext()) {
          method = methodIterator.next();
          if (methodDescriptor.equals(method))
            break; 
          method = null;
        } 
        if (method == null && !bool)
          throw new ConfigException("No method '" + methodDescriptor.getName() + "' was found in component '" + str1 + "' for operation '" + str2 + "'"); 
        addParamsToMethod(method, operation, paramTypeMapping, str4);
      } else {
        addParamsToMethod((Method)null, operation, paramsMBean, paramTypeMapping, str4);
      } 
      operation.setInvocationHandler(paramInvocationHandler);
      if (paramInvocationHandler != null)
        try {
          paramInvocationHandler.registerOperation(str2, methodDescriptor.getName(), methodDescriptor.getParams());
        } catch (NoSuchMethodException noSuchMethodException) {
          throw new ConfigException(noSuchMethodException);
        }  
    } 
  }
  
  private MethodIterator introspectComponent(String paramString, InvocationHandler paramInvocationHandler) throws ConfigException {
    Method[] arrayOfMethod = paramInvocationHandler.getAllMethods();
    if (arrayOfMethod == null)
      throw new ConfigException("Cannot introspect component '" + paramString + "' to resolve '*' in operation."); 
    MethodIterator methodIterator = new MethodIterator(arrayOfMethod);
    if (paramInvocationHandler instanceof SLSBInvocationHandler)
      methodIterator.setEJBExcludes(); 
    return methodIterator;
  }
  
  private void addParamsToJMSComponent(Operation paramOperation, ParamsMBean paramParamsMBean, TypeMapping paramTypeMapping, String paramString) throws ConfigException {
    Message message;
    String str1 = null;
    XMLName xMLName = null;
    String str2 = null;
    boolean bool = false;
    if (paramParamsMBean != null) {
      ParamMBean[] arrayOfParamMBean = paramParamsMBean.getParams();
      ReturnParamMBean returnParamMBean = paramParamsMBean.getReturnParam();
      if (arrayOfParamMBean != null && arrayOfParamMBean.length > 0) {
        ParamMBean paramMBean = arrayOfParamMBean[0];
        str1 = paramMBean.getParamName();
        xMLName = paramMBean.getParamType();
        str2 = paramMBean.getClassName();
        if ("in".equalsIgnoreCase(paramMBean.getParamStyle()))
          bool = true; 
      } else if (returnParamMBean != null) {
        str1 = returnParamMBean.getParamName();
        xMLName = returnParamMBean.getParamType();
        str2 = returnParamMBean.getClassName();
      } 
    } else {
      str2 = "java.lang.String";
      if (bool) {
        str1 = "param";
      } else {
        str1 = "result";
      } 
    } 
    paramOperation.getInput().setNamespace(paramString);
    paramOperation.getOutput().setNamespace(paramString);
    Iterator iterator = paramOperation.getFaults();
    while (iterator.hasNext())
      ((Message)iterator.next()).setNamespace(paramString); 
    if (bool) {
      message = paramOperation.getInput();
    } else {
      message = paramOperation.getOutput();
    } 
    Part.Mode mode = bool ? Part.Mode.IN : Part.Mode.RETURN;
    addPart(paramOperation, message, str1, xMLName, str2, paramTypeMapping, mode);
  }
  
  private void addParamsToMethod(Method paramMethod, Operation paramOperation, ParamsMBean paramParamsMBean, TypeMapping paramTypeMapping, String paramString) throws ConfigException {
    if (paramParamsMBean == null)
      throw new AssertionError(); 
    ParamMBean[] arrayOfParamMBean = paramParamsMBean.getParams();
    if (arrayOfParamMBean == null)
      return; 
    XMLName xMLName = null;
    ReturnParamMBean returnParamMBean = paramParamsMBean.getReturnParam();
    FaultMBean[] arrayOfFaultMBean = paramParamsMBean.getFaults();
    Message message1 = paramOperation.getInput();
    message1.setNamespace(paramString);
    Message message2 = paramOperation.getOutput();
    message2.setNamespace(paramString);
    Class[] arrayOfClass = null;
    Class clazz = null;
    Iterator iterator = null;
    if (paramMethod != null) {
      arrayOfClass = paramMethod.getParameterTypes();
      clazz = paramMethod.getReturnType();
      iterator = (new SmartNameStore()).getNames(paramMethod);
    } 
    if (returnParamMBean != null) {
      if ("header".equalsIgnoreCase(returnParamMBean.getLocation()))
        throw new ConfigException("Return value can not be a header. use out or in-out parameters instead"); 
      String str = (returnParamMBean.getParamName() == null) ? "result" : returnParamMBean.getParamName();
      xMLName = returnParamMBean.getParamType();
      Class clazz1 = null;
      if (returnParamMBean.getClassName() != null) {
        clazz1 = loadClass(returnParamMBean.getClassName());
      } else {
        clazz1 = clazz;
      } 
      Part part = addPart(paramOperation, message2, str, xMLName, clazz1, paramTypeMapping, Part.Mode.RETURN);
      setLocation(returnParamMBean.getLocation(), part);
    } 
    String[] arrayOfString = new String[arrayOfParamMBean.length];
    byte b;
    for (b = 0; b < arrayOfParamMBean.length; b++) {
      if (!arrayOfParamMBean[b].isImplicit()) {
        Part part;
        String str = null;
        xMLName = arrayOfParamMBean[b].getParamType();
        if (arrayOfParamMBean[b].getParamName() != null) {
          str = arrayOfParamMBean[b].getParamName();
        } else if (iterator != null) {
          if (!iterator.hasNext())
            throw new ConfigException("No of params in the DD file do notmatch the no of param in the end component for method:" + paramMethod); 
          str = (String)iterator.next();
        } else {
          throw new ConfigException("Parameter name is expected.");
        } 
        arrayOfString[b] = str;
        Class clazz1 = null;
        if (arrayOfClass != null)
          clazz1 = arrayOfClass[b]; 
        Class clazz2 = null;
        if (arrayOfParamMBean[b].getClassName() != null)
          clazz2 = loadClass(arrayOfParamMBean[b].getClassName()); 
        clazz1 = validateParameterType(paramTypeMapping, xMLName, clazz2, clazz1);
        if ("in".equalsIgnoreCase(arrayOfParamMBean[b].getParamStyle())) {
          part = addPart(paramOperation, message1, str, xMLName, clazz1, paramTypeMapping, Part.Mode.IN);
        } else if ("inout".equalsIgnoreCase(arrayOfParamMBean[b].getParamStyle())) {
          part = addPart(paramOperation, message1, str, xMLName, getRealType(clazz1), paramTypeMapping, Part.Mode.INOUT);
          setLocation(arrayOfParamMBean[b].getLocation(), part);
          part = addPart(paramOperation, message2, str, xMLName, getRealType(clazz1), paramTypeMapping, Part.Mode.INOUT);
        } else if ("out".equalsIgnoreCase(arrayOfParamMBean[b].getParamStyle())) {
          part = addPart(paramOperation, message2, str, xMLName, getRealType(clazz1), paramTypeMapping, Part.Mode.OUT);
        } else {
          throw new AssertionError(arrayOfParamMBean[b].getParamStyle());
        } 
        setLocation(arrayOfParamMBean[b].getLocation(), part);
      } 
    } 
    paramOperation.setParameterOrder(arrayOfString);
    if (arrayOfFaultMBean != null && arrayOfFaultMBean.length > 0)
      for (b = 0; b < arrayOfFaultMBean.length; b++) {
        String str1 = arrayOfFaultMBean[b].getFaultName();
        if (str1 == null)
          str1 = arrayOfFaultMBean[b].getClassName(); 
        xMLName = arrayOfFaultMBean[b].getFaultType();
        Class clazz1 = loadClass(arrayOfFaultMBean[b].getClassName());
        Message message = paramOperation.addFault();
        message.setName(str1);
        message.setNamespace(paramString);
        String str2 = ExceptionUtil.getSingleSimplePropertyName(clazz1);
        if (str2 == null)
          str2 = str1; 
        Part part = addPart(paramOperation, message, str2, xMLName, clazz1, paramTypeMapping, Part.Mode.OUT);
      }  
  }
  
  private void setLocation(String paramString, Part paramPart) {
    if (paramString == null)
      paramString = "body"; 
    if ("body".equalsIgnoreCase(paramString)) {
      paramPart.setBody();
    } else if ("header".equalsIgnoreCase(paramString)) {
      paramPart.setHeader();
    } else if ("attachment".equalsIgnoreCase(paramString)) {
      paramPart.setAttachment();
      String str = AttachmentUtil.getContentType(paramPart.getJavaType().getName());
      paramPart.setContentType(new String[] { str });
    } 
  }
  
  private void addParamsToMethod(Method paramMethod, Operation paramOperation, TypeMapping paramTypeMapping, String paramString) throws ConfigException {
    Message message1 = paramOperation.getInput();
    message1.setNamespace(paramString);
    Message message2 = paramOperation.getOutput();
    message2.setNamespace(paramString);
    if (paramMethod == null)
      return; 
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    Iterator iterator = (new SmartNameStore()).getNames(paramMethod);
    String[] arrayOfString = new String[arrayOfClass.length];
    for (byte b = 0; b < arrayOfClass.length; b++) {
      String str = (String)iterator.next();
      arrayOfString[b] = str;
      if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(arrayOfClass[b])) {
        addPart(paramOperation, message1, str, null, getRealType(arrayOfClass[b]), paramTypeMapping, Part.Mode.INOUT);
        addPart(paramOperation, message2, str, null, getRealType(arrayOfClass[b]), paramTypeMapping, Part.Mode.INOUT);
      } else {
        addPart(paramOperation, message1, str, null, arrayOfClass[b], paramTypeMapping, Part.Mode.IN);
      } 
    } 
    paramOperation.setParameterOrder(arrayOfString);
    Class clazz = paramMethod.getReturnType();
    if (clazz != null && !clazz.equals(void.class))
      addPart(paramOperation, message2, "result", null, clazz, paramTypeMapping, Part.Mode.RETURN); 
  }
  
  private Part addPart(Operation paramOperation, Message paramMessage, String paramString1, XMLName paramXMLName, String paramString2, TypeMapping paramTypeMapping, Part.Mode paramMode) throws ConfigException {
    Class clazz = null;
    if (paramString2 != null)
      clazz = loadClass(paramString2); 
    return addPart(paramOperation, paramMessage, paramString1, paramXMLName, clazz, paramTypeMapping, paramMode);
  }
  
  private Part addPart(Operation paramOperation, Message paramMessage, String paramString, XMLName paramXMLName, Class paramClass, TypeMapping paramTypeMapping, Part.Mode paramMode) throws ConfigException {
    Part part;
    if (paramString == null)
      throw new ConfigException("Could not add parameter to operation. You must specify its name."); 
    if (paramXMLName == null && paramClass != null)
      paramXMLName = paramTypeMapping.getXMLNameFromClass(paramClass); 
    if (paramXMLName == null)
      throw new ConfigException("Could not add parameter to operation. You must specify either its Java or XML type."); 
    String str1 = paramXMLName.getLocalName();
    String str2 = paramXMLName.getNamespaceUri();
    if (paramClass == null) {
      part = paramMessage.addPart(paramString, str1, str2);
    } else {
      part = paramMessage.addPart(paramString, str1, str2, paramClass);
    } 
    if (paramOperation.isDocumentStyle())
      part.setElement(); 
    part.setMode(paramMode);
    return part;
  }
  
  public static Class loadClass(String paramString) throws ConfigException {
    try {
      if (ReflectUtils.isPrimitiveClass(paramString))
        return loadPrimitiveClass(paramString); 
      Class clazz = loadArrayClass(paramString);
      if (clazz != null)
        return clazz; 
      return loadNonArrayClass(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new ConfigException("unable to load class:[" + paramString + "] " + classNotFoundException);
    } 
  }
  
  private static Class loadPrimitiveClass(String paramString) throws ConfigException { return ReflectUtils.loadPrimitiveClass(paramString); }
  
  private static Class loadNonArrayClass(String paramString) throws ConfigException {
    Class clazz2, clazz1 = loadPrimitiveClass(paramString);
    if (clazz1 != null)
      return clazz1; 
    try {
      ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
      clazz2 = classLoader.loadClass(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      ClassLoader classLoader = WebServiceFactory.class.getClassLoader();
      clazz2 = classLoader.loadClass(paramString);
    } 
    return clazz2;
  }
  
  private static Class loadArrayClass(String paramString) throws ConfigException {
    StringBuffer stringBuffer = new StringBuffer(paramString.length());
    int i = ArrayUtils.getArrayComponentNameFromDecl(stringBuffer, paramString);
    if (i < 1)
      return null; 
    int[] arrayOfInt = new int[i];
    Class clazz = loadNonArrayClass(stringBuffer.toString());
    Object object = Array.newInstance(clazz, arrayOfInt);
    return object.getClass();
  }
  
  private boolean isJMSHandler(InvocationHandler paramInvocationHandler) { return (paramInvocationHandler instanceof JMSSendInvocationHandler || paramInvocationHandler instanceof JMSQueueReceiveInvocationHandler || paramInvocationHandler instanceof JMSTopicReceiveInvocationHandler); }
  
  private String getUniqueName(String paramString, HashSet paramHashSet) {
    String str = paramString;
    byte b = 0;
    while (paramHashSet.contains(str)) {
      str = paramString + b;
      b++;
    } 
    paramHashSet.add(str);
    return str;
  }
  
  private void updateParameterOrder(WebService paramWebService) {
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext();)
      updateParameterOrder((Port)iterator.next()); 
  }
  
  private void updateParameterOrder(Port paramPort) {
    for (Iterator iterator = paramPort.getOperations(); iterator.hasNext(); ) {
      Operation operation = (Operation)iterator.next();
      updateParameterOrder(operation);
    } 
  }
  
  private void updateParameterOrder(Operation paramOperation) {
    if (!needsParameterOrder(paramOperation))
      paramOperation.setParameterOrder(new String[0]); 
  }
  
  private boolean needsParameterOrder(Operation paramOperation) {
    Iterator iterator;
    for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.INOUT)
        return true; 
    } 
    for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.INOUT || part.getMode() == Part.Mode.OUT)
        return true; 
    } 
    return false;
  }
  
  private Class getRealType(Class paramClass) { return HolderUtil.getRealType(paramClass); }
  
  private Class validateParameterType(TypeMapping paramTypeMapping, XMLName paramXMLName, Class paramClass1, Class paramClass2) throws ConfigException {
    if (paramClass1 == null) {
      paramClass1 = paramTypeMapping.getClassFromXMLName(paramXMLName);
      if (paramClass1 == null) {
        if (paramClass2 == null)
          return Object.class; 
        throw new ConfigException("Can't find type mapping entry for XML type " + paramXMLName);
      } 
      if (paramClass2 != null && !isAssignableFrom(paramClass2, paramClass1))
        throw new ConfigException("XML type '" + paramXMLName + "' specified in web-services.xml file does not match with " + paramClass2 + "' found in method signature of the component."); 
      return paramClass1;
    } 
    if (paramClass2 != null && !isAssignableFrom(paramClass2, paramClass1))
      throw new ConfigException("Parameter class type '" + paramClass1 + "' specified in web-services.xml file does not match with " + paramClass2 + "' found in method signature of the component."); 
    return paramClass1;
  }
  
  private boolean isAssignableFrom(Class paramClass1, Class paramClass2) {
    if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass1))
      paramClass1 = getRealType(paramClass1); 
    if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass2))
      paramClass2 = getRealType(paramClass2); 
    if (paramClass1.isAssignableFrom(paramClass2))
      return true; 
    if ((paramClass1 == int.class && paramClass2 == Integer.class) || (paramClass1 == Integer.class && paramClass2 == int.class))
      return true; 
    if ((paramClass1 == byte.class && paramClass2 == Byte.class) || (paramClass1 == Byte.class && paramClass2 == byte.class))
      return true; 
    if ((paramClass1 == float.class && paramClass2 == Float.class) || (paramClass1 == Float.class && paramClass2 == float.class))
      return true; 
    if ((paramClass1 == boolean.class && paramClass2 == Boolean.class) || (paramClass1 == Boolean.class && paramClass2 == boolean.class))
      return true; 
    if ((paramClass1 == char.class && paramClass2 == Character.class) || (paramClass1 == Character.class && paramClass2 == char.class))
      return true; 
    if ((paramClass1 == short.class && paramClass2 == Short.class) || (paramClass1 == Short.class && paramClass2 == short.class))
      return true; 
    if ((paramClass1 == long.class && paramClass2 == Long.class) || (paramClass1 == Long.class && paramClass2 == long.class))
      return true; 
    if ((paramClass1 == double.class && paramClass2 == Double.class) || (paramClass1 == Double.class && paramClass2 == double.class))
      return true; 
    return false;
  }
  
  private HandlerInfo initReliableDelivery(ReliableDeliveryMBean paramReliableDeliveryMBean) {
    HashMap hashMap = new HashMap(5);
    hashMap.put("dup_elim_param", new Boolean(paramReliableDeliveryMBean.isDuplicateElimination()));
    hashMap.put("in_order_delivery_param", new Boolean(paramReliableDeliveryMBean.isInOrderDelivery()));
    hashMap.put("retries_param", new Integer(paramReliableDeliveryMBean.getRetries()));
    hashMap.put("retry_interval_param", new Integer(paramReliableDeliveryMBean.getRetryInterval()));
    hashMap.put("persist_interval_param", new Integer(paramReliableDeliveryMBean.getPersistDuration()));
    return new HandlerInfo(weblogic.webservice.saf.DupsEliminationHandler.class, hashMap, null);
  }
  
  private void setCharset(String paramString, WebService paramWebService) {
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      port.getBindingInfo().setCharset(paramString);
    } 
  }
  
  private void addJmsPorts(String paramString, WebService paramWebService) {
    ArrayList arrayList = new ArrayList();
    for (null = paramWebService.getPorts(); null.hasNext();)
      arrayList.add(null.next()); 
    for (Port port1 : arrayList) {
      String str = port1.getName();
      str = str + "JMS";
      Port port2 = paramWebService.addPort(str);
      JMSBindingInfo jMSBindingInfo = new JMSBindingInfo();
      jMSBindingInfo.setAddress("jms://localhost:7001/" + paramString + "?URI=junk");
      port2.setBindingInfo(jMSBindingInfo);
      port2.setTypeName(port1.getTypeName());
      addOperationsToNewPort(port2, port1);
    } 
  }
  
  private void isJMSOperations(Port paramPort) {
    for (Iterator iterator = paramPort.getOperations(); iterator.hasNext(); ) {
      Operation operation = (Operation)iterator.next();
      if (!operation.isOneway())
        throw new JAXRPCException("Operation '" + operation.getName() + "' " + "in port '" + paramPort.getName() + "' is not oneway. Only one way " + "operations are supported by JMS transport. Please edit the " + "web-services.xml DD file to make this operation oneway"); 
    } 
  }
  
  private void addSoap12Ports(WebService paramWebService) {
    ArrayList arrayList = new ArrayList();
    for (null = paramWebService.getPorts(); null.hasNext();)
      arrayList.add(null.next()); 
    for (Port port1 : arrayList) {
      String str = port1.getName();
      str = str + (str.endsWith("Soap") ? "12" : "Soap12");
      Port port2 = paramWebService.addPort(str);
      port2.getBindingInfo().setType("SOAP1.2");
      port2.setTypeName(port1.getTypeName());
      addOperationsToNewPort(port2, port1);
    } 
  }
  
  private void addOperationsToNewPort(Port paramPort1, Port paramPort2) {
    for (Iterator iterator = paramPort2.getOperations(); iterator.hasNext(); ) {
      Operation operation = (Operation)iterator.next();
      paramPort1.addOperation(operation);
    } 
  }
  
  private void addConversationSchema(WebService paramWebService) {
    boolean bool = false;
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Iterator iterator1 = ((Port)iterator.next()).getOperations();
      while (iterator1.hasNext()) {
        String str = ((Operation)iterator1.next()).getConversationPhase();
        if (str != null && !str.equals("NONE")) {
          bool = true;
          break;
        } 
      } 
      if (bool)
        break; 
    } 
    if (!bool)
      return; 
    XMLNode xMLNode1 = paramWebService.getTypes();
    if (xMLNode1 == null) {
      XMLName xMLName = ElementFactory.createXMLName("http://www.openuri.org/2002/04/soap/conversation/", "types");
      xMLNode1 = new XMLNode(xMLName);
      paramWebService.setTypes(xMLNode1);
    } 
    XMLNode xMLNode2 = xMLNode1.addChild("schema", "xsd");
    xMLNode2.addNamespace("xsd", "http://www.w3.org/2001/XMLSchema");
    xMLNode2.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
    xMLNode2.addAttribute("targetNamespace", null, null, "http://www.openuri.org/2002/04/soap/conversation/");
    xMLNode2.addAttribute("elementFormDefault", null, null, "qualified");
    XMLNode xMLNode3 = xMLNode2.addChild("element", "xsd");
    xMLNode3.addAttribute("name", null, null, "StartHeader");
    xMLNode3.addAttribute("type", null, null, "conv:StartHeader");
    xMLNode3 = xMLNode2.addChild("element", "xsd");
    xMLNode3.addAttribute("name", null, null, "ContinueHeader");
    xMLNode3.addAttribute("type", null, null, "conv:ContinueHeader");
    XMLNode xMLNode4 = xMLNode2.addChild("complexType", "xsd");
    xMLNode4.addAttribute("name", null, null, "StartHeader");
    XMLNode xMLNode5 = xMLNode4.addChild("sequence", "xsd");
    XMLNode xMLNode6 = xMLNode5.addChild("element", "xsd");
    xMLNode6.addAttribute("name", null, null, "conversationID");
    xMLNode6.addAttribute("minOccurs", null, null, "0");
    xMLNode6.addAttribute("maxOccurs", null, null, "1");
    xMLNode6.addAttribute("type", null, null, "xsd:string");
    xMLNode4 = xMLNode2.addChild("complexType", "xsd");
    xMLNode4.addAttribute("name", null, null, "ContinueHeader");
    xMLNode5 = xMLNode4.addChild("sequence", "xsd");
    xMLNode6 = xMLNode5.addChild("element", "xsd");
    xMLNode6.addAttribute("name", null, null, "conversationID");
    xMLNode6.addAttribute("type", null, null, "xsd:string");
    xMLNode6.addAttribute("minOccurs", null, null, "1");
    xMLNode6.addAttribute("maxOccurs", null, null, "1");
  }
  
  private void addDocumentStyleSupport(WebService paramWebService, TypeMappingBuilder paramTypeMappingBuilder) throws ConfigException {
    Port port = (Port)paramWebService.getPorts().next();
    if ("document".equals(port.getStyle())) {
      ArrayList arrayList1 = new ArrayList();
      ArrayList arrayList2 = new ArrayList();
      for (iterator = port.getOperations(); iterator.hasNext(); ) {
        Operation operation = (Operation)iterator.next();
        String str = paramWebService.getTargetNamespace();
        XMLName xMLName1 = ElementFactory.createXMLName(str, operation.getName());
        XMLName xMLName2 = ElementFactory.createXMLName(str, operation.getName() + "Response");
        Part part = null;
        Iterator iterator1;
        for (iterator1 = operation.getInput().getParts(); iterator1.hasNext(); ) {
          Part part1 = (Part)iterator1.next();
          if (part1.isHeader())
            continue; 
          if (part == null) {
            part = part1;
            continue;
          } 
          throw new ConfigException("ERROR: Backend components for Document style webservice can only accept methods with one input parameter. Operation \"" + operation.getName() + "\" of the " + "webservice \"" + paramWebService.getName() + "\" is ignored.");
        } 
        if (part != null) {
          part.setElement();
          if (!noDynamicTypeGeneration && !isElement(paramWebService.getTypes(), part.getXMLType())) {
            arrayList1.add(part.getJavaType());
            arrayList2.add(xMLName1);
            part.setXMLType(operation.getName(), str);
          } 
        } 
        if (operation.getReturnPart() != null) {
          Part part1 = operation.getReturnPart();
          part1.setElement();
          if (!noDynamicTypeGeneration && !isElement(paramWebService.getTypes(), part1.getXMLType())) {
            arrayList1.add(part1.getJavaType());
            arrayList2.add(xMLName2);
            part1.setXMLType(operation.getName() + "Response", str);
          } 
        } 
        for (iterator1 = operation.getFaults(); iterator1.hasNext(); ) {
          Message message = (Message)iterator1.next();
          Part part1 = (Part)message.getParts().next();
          part1.setElement();
          if (!isElement(paramWebService.getTypes(), part1.getXMLType())) {
            XMLName xMLName = ElementFactory.createXMLName(part1.getXMLType().getNamespaceURI(), message.getName());
            if (arrayList2.contains(xMLName))
              continue; 
            Class clazz = ExceptionUtil.getSingleSimpleProperty(part1.getJavaType());
            if (clazz != null) {
              arrayList1.add(clazz);
            } else {
              arrayList1.add(part1.getJavaType());
            } 
            arrayList2.add(xMLName);
          } 
        } 
      } 
      try {
        paramTypeMappingBuilder.addMapping((Class[])arrayList1.toArray(new Class[0]), (XMLName[])arrayList2.toArray(new XMLName[0]));
      } catch (BindingException iterator) {
        throw new ConfigException("Failed to generate element document operations", iterator);
      } 
      mergeSchema(paramWebService, paramTypeMappingBuilder);
    } else if ("documentwrapped".equals(port.getStyle())) {
      ArrayList arrayList1 = new ArrayList();
      ArrayList arrayList2 = new ArrayList();
      for (iterator = port.getOperations(); iterator.hasNext(); ) {
        Operation operation = (Operation)iterator.next();
        String str = paramWebService.getTargetNamespace();
        XMLName xMLName1 = ElementFactory.createXMLName(str, operation.getName());
        XMLName xMLName2 = ElementFactory.createXMLName(str, operation.getName() + "Response");
        if (!operation.getInput().getParts().hasNext()) {
          addEmptyElement(paramTypeMappingBuilder, xMLName1);
        } else {
          ArrayList arrayList3 = new ArrayList();
          ArrayList arrayList4 = new ArrayList();
          for (iterator2 = operation.getInput().getParts(); iterator2.hasNext(); ) {
            Part part = (Part)iterator2.next();
            arrayList3.add(part.getJavaType());
            arrayList4.add(part.getName());
          } 
          try {
            paramTypeMappingBuilder.addWrappedSchemaType((Class[])arrayList3.toArray(new Class[0]), (String[])arrayList4.toArray(new String[0]), xMLName1);
          } catch (BindingException iterator2) {
            throw new ConfigException("Failed to generate element document operations", iterator2);
          } 
        } 
        if (operation.getReturnPart() != null) {
          try {
            paramTypeMappingBuilder.addWrappedSchemaType(new Class[] { operation.getReturnPart().getJavaType() }, new String[] { operation.getReturnPart().getName() }, xMLName2);
          } catch (BindingException bindingException) {
            throw new ConfigException("Failed to generate element document operations", bindingException);
          } 
        } else {
          addEmptyElement(paramTypeMappingBuilder, xMLName2);
        } 
        for (Iterator iterator1 = operation.getFaults(); iterator1.hasNext(); ) {
          Message message = (Message)iterator1.next();
          Part part = (Part)message.getParts().next();
          part.setElement();
          if (!isElement(paramWebService.getTypes(), part.getXMLType())) {
            XMLName xMLName = ElementFactory.createXMLName(str, message.getName());
            part.setXMLType(xMLName.getLocalName(), str);
            if (arrayList2.contains(xMLName))
              continue; 
            Class clazz = ExceptionUtil.getSingleSimpleProperty(part.getJavaType());
            if (clazz != null) {
              arrayList1.add(clazz);
            } else {
              arrayList1.add(part.getJavaType());
            } 
            arrayList2.add(xMLName);
          } 
        } 
      } 
      if (arrayList1.size() > 0)
        try {
          paramTypeMappingBuilder.addMapping((Class[])arrayList1.toArray(new Class[0]), (XMLName[])arrayList2.toArray(new XMLName[0]));
        } catch (BindingException iterator) {
          throw new ConfigException("Failed to generate element for exceptions", iterator);
        }  
      mergeSchema(paramWebService, paramTypeMappingBuilder);
    } 
  }
  
  private void mergeSchema(WebService paramWebService, TypeMappingBuilder paramTypeMappingBuilder) throws ConfigException {
    try {
      XMLNode xMLNode = new XMLNode();
      xMLNode.setName("types", null, null);
      XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream(xMLNode);
      paramTypeMappingBuilder.writeGeneratedSchemas(xMLNodeOutputStream);
      xMLNodeOutputStream.flush();
      if (paramWebService.getTypes() == null) {
        paramWebService.setTypes(xMLNode);
      } else {
        XMLNode xMLNode1 = new XMLNode();
        xMLNode1.setName("types", null, null);
        XMLNodeOutputStream xMLNodeOutputStream1 = new XMLNodeOutputStream(xMLNode1);
        MergeSchemas.merge(xMLNodeOutputStream1, new XMLInputStream[] { paramWebService.getTypes().stream(), xMLNode.stream() });
        xMLNodeOutputStream1.flush();
        paramWebService.setTypes(xMLNode1);
      } 
    } catch (XMLStreamException xMLStreamException) {
      throw new ConfigException("Failed to add generated schema", xMLStreamException);
    } catch (BindingException bindingException) {
      throw new ConfigException("Failed to add generated schema", bindingException);
    } catch (XSDException xSDException) {
      throw new ConfigException("Failed to add generated schema", xSDException);
    } 
  }
  
  private void addEmptyElement(TypeMappingBuilder paramTypeMappingBuilder, XMLName paramXMLName) throws ConfigException {
    try {
      paramTypeMappingBuilder.addWrappedSchemaType(new Class[0], new String[0], paramXMLName);
    } catch (BindingException bindingException) {
      throw new ConfigException("Failed to add empty element", bindingException);
    } 
  }
  
  private boolean isElement(XMLNode paramXMLNode, QName paramQName) {
    if (paramXMLNode == null)
      return false; 
    Iterator iterator = paramXMLNode.getChildren("schema", "http://www.w3.org/2001/XMLSchema");
    while (iterator.hasNext()) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      String str1 = paramQName.getNamespaceURI();
      String str2 = xMLNode.getAttribute("targetNamespace", null);
      if ((str1 == null && str2 == null) || (str1.equals("") && str2 == null) || (str1 == null && str2.equals("")) || str1.equals(str2))
        for (Iterator iterator1 = xMLNode.getChildren("element", null); iterator1.hasNext(); ) {
          XMLNode xMLNode1 = (XMLNode)iterator1.next();
          if (paramQName.getLocalPart().equals(xMLNode1.getAttribute("name", null)))
            return true; 
        }  
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\server\WebServiceFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */