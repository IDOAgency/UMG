/*    */ package weblogic.webservice.conversation;
/*    */ 
/*    */ import weblogic.utils.NestedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConversationException
/*    */   extends NestedException
/*    */ {
/*    */   public ConversationException() {}
/*    */   
/* 15 */   public ConversationException(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 20 */   public ConversationException(Throwable paramThrowable) { super(paramThrowable); }
/*    */ 
/*    */ 
/*    */   
/* 24 */   public ConversationException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\ConversationException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */