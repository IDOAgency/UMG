package weblogic.webservice.conversation;

import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ConversationState extends Remote {
  boolean isLocked();
  
  long getCreationTime() throws RemoteException;
  
  String getId() throws RemoteException;
  
  long getLastAccessedTime() throws RemoteException;
  
  void setMaxInactiveInterval(long paramLong) throws RemoteException;
  
  long getMaxInactiveInterval() throws RemoteException;
  
  Serializable getComponent() throws RemoteException;
  
  void setComponent(Serializable paramSerializable) throws RemoteException;
  
  void setCallbackURI(String paramString) throws RemoteException;
  
  String getCallbackURI() throws RemoteException;
  
  boolean hasTimedOut();
  
  void destroy() throws RemoteException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\ConversationState.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */