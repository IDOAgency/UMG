/*    */ package weblogic.webservice.conversation;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.rmi.server.UID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Guid
/*    */ {
/*    */   public static String generateGuid() {
/* 16 */     UID uID = new UID();
/* 17 */     String str = null;
/*    */     try {
/* 19 */       InetAddress inetAddress = InetAddress.getLocalHost();
/* 20 */       str = inetAddress.getHostAddress();
/* 21 */     } catch (UnknownHostException unknownHostException) {
/* 22 */       str = "uknownhost";
/*    */     } 
/*    */     
/* 25 */     null = str + "-" + uID.toString();
/*    */ 
/*    */ 
/*    */     
/* 29 */     null = null.replace(':', '.');
/* 30 */     null = null.replace('[', '(');
/* 31 */     return null.replace(']', ')');
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\Guid.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */