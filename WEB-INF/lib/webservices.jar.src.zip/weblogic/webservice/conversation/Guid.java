package weblogic.webservice.conversation;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.server.UID;

public class Guid {
  public static String generateGuid() {
    UID uID = new UID();
    String str = null;
    try {
      InetAddress inetAddress = InetAddress.getLocalHost();
      str = inetAddress.getHostAddress();
    } catch (UnknownHostException unknownHostException) {
      str = "uknownhost";
    } 
    null = str + "-" + uID.toString();
    null = null.replace(':', '.');
    null = null.replace('[', '(');
    return null.replace(']', ')');
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\Guid.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */