package weblogic.webservice.conversation;

public interface ConversationListener {
  void conversationStart(String paramString);
  
  void conversationEnd(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\ConversationListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */