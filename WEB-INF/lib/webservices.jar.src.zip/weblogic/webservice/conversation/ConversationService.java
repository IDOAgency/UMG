package weblogic.webservice.conversation;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ConversationService extends Remote {
  public static final String JNDI_NAME = "ConversationService";
  
  void registerConversation(String paramString1, String paramString2) throws RemoteException;
  
  void registerConversation(String paramString1, String paramString2, ConversationState paramConversationState) throws RemoteException;
  
  ConversationState getConversation(String paramString) throws RemoteException;
  
  String getConversationLocation(String paramString) throws RemoteException;
  
  void endConversation(String paramString) throws RemoteException;
  
  String whereAmI() throws RemoteException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\ConversationService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */