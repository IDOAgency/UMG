package weblogic.webservice.conversation.internal;

import java.io.IOException;
import java.io.Serializable;
import java.rmi.MarshalException;
import java.rmi.UnmarshalException;
import weblogic.rmi.internal.Skeleton;
import weblogic.rmi.spi.InboundRequest;
import weblogic.rmi.spi.MsgInput;
import weblogic.rmi.spi.OutboundResponse;
import weblogic.webservice.conversation.ConversationState;

public final class ConversationStateImpl_WLSkel extends Skeleton {
  public OutboundResponse invoke(int paramInt, InboundRequest paramInboundRequest, OutboundResponse paramOutboundResponse, Object paramObject) throws Exception {
    long l3;
    String str1;
    boolean bool;
    Serializable serializable2;
    Serializable serializable1;
    String str2;
    long l2;
    long l1;
    switch (paramInt) {
      case 0:
        ((ConversationState)paramObject).destroy();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        return paramOutboundResponse;
      case 1:
        str2 = ((ConversationState)paramObject).getCallbackURI();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeObject(str2, String.class);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 2:
        serializable2 = ((ConversationState)paramObject).getComponent();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeObject(serializable2, Serializable.class);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 3:
        l2 = ((ConversationState)paramObject).getCreationTime();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeLong(l2);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 4:
        str1 = ((ConversationState)paramObject).getId();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeObject(str1, String.class);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 5:
        l1 = ((ConversationState)paramObject).getLastAccessedTime();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeLong(l1);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 6:
        l1 = ((ConversationState)paramObject).getMaxInactiveInterval();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeLong(l1);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 7:
        bool = ((ConversationState)paramObject).hasTimedOut();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeBoolean(bool);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 8:
        bool = ((ConversationState)paramObject).isLocked();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeBoolean(bool);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 9:
        try {
          MsgInput msgInput = paramInboundRequest.getMsgInput();
          serializable1 = (String)msgInput.readObject(String.class);
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } 
        ((ConversationState)paramObject).setCallbackURI(serializable1);
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        return paramOutboundResponse;
      case 10:
        try {
          MsgInput msgInput = paramInboundRequest.getMsgInput();
          serializable1 = (Serializable)msgInput.readObject(Serializable.class);
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } 
        ((ConversationState)paramObject).setComponent(serializable1);
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        return paramOutboundResponse;
      case 11:
        try {
          MsgInput msgInput = paramInboundRequest.getMsgInput();
          l3 = msgInput.readLong();
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } 
        ((ConversationState)paramObject).setMaxInactiveInterval(l3);
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        return paramOutboundResponse;
    } 
    throw new UnmarshalException("Method identifier [" + paramInt + "] out of range");
  }
  
  public Object invoke(int paramInt, Object[] paramArrayOfObject, Object paramObject) throws Exception {
    switch (paramInt) {
      case 0:
        ((ConversationState)paramObject).destroy();
        return null;
      case 1:
        return ((ConversationState)paramObject).getCallbackURI();
      case 2:
        return ((ConversationState)paramObject).getComponent();
      case 3:
        return new Long(((ConversationState)paramObject).getCreationTime());
      case 4:
        return ((ConversationState)paramObject).getId();
      case 5:
        return new Long(((ConversationState)paramObject).getLastAccessedTime());
      case 6:
        return new Long(((ConversationState)paramObject).getMaxInactiveInterval());
      case 7:
        return new Boolean(((ConversationState)paramObject).hasTimedOut());
      case 8:
        return new Boolean(((ConversationState)paramObject).isLocked());
      case 9:
        ((ConversationState)paramObject).setCallbackURI((String)paramArrayOfObject[0]);
        return null;
      case 10:
        ((ConversationState)paramObject).setComponent((Serializable)paramArrayOfObject[0]);
        return null;
      case 11:
        ((ConversationState)paramObject).setMaxInactiveInterval(((Long)paramArrayOfObject[0]).longValue());
        return null;
    } 
    throw new UnmarshalException("Method identifier [" + paramInt + "] out of range");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationStateImpl_WLSkel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */