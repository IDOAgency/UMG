/*     */ package weblogic.webservice.conversation.internal;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.rmi.RemoteException;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import weblogic.management.provider.ManagementService;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.webservice.conversation.ConversationException;
/*     */ import weblogic.webservice.conversation.ConversationListener;
/*     */ import weblogic.webservice.conversation.ConversationManager;
/*     */ import weblogic.webservice.conversation.ConversationState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConversationManagerImpl
/*     */   implements ConversationManager
/*     */ {
/*     */   private static boolean debug = false;
/*  27 */   private HashMap conversations = new HashMap();
/*  28 */   private ArrayList listeners = new ArrayList();
/*     */ 
/*     */   
/*  31 */   private long timeOutInterval = 20000L;
/*     */   
/*     */   String internalId;
/*  34 */   private StateInvalidator invalidator = new StateInvalidator(this, this.timeOutInterval);
/*     */   
/*     */   public ConversationManagerImpl(String paramString) {
/*  37 */     this();
/*  38 */     this.internalId = paramString;
/*     */   }
/*  40 */   public void setId(String paramString) { this.internalId = paramString; }
/*  41 */   public String getId() { return this.internalId; }
/*     */ 
/*     */   
/*  44 */   public Iterator getIds() { return this.conversations.keySet().iterator(); }
/*     */ 
/*     */ 
/*     */   
/*  48 */   public boolean hasConversation(String paramString) { return (this.conversations.get(paramString) != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public ConversationState createConversation(String paramString) throws ConversationException { return createConversation(paramString, new ConversationStateImpl(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public ConversationState createConversation(String paramString, Serializable paramSerializable) throws ConversationException { return createConversation(paramString, new ConversationStateImpl(paramString, paramSerializable)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConversationState createConversation(String paramString, ConversationState paramConversationState) throws ConversationException {
/*  69 */     if (hasConversation(paramString))
/*  70 */       throw new ConversationException("Unable to create conversation with duplicate ID:" + paramString); 
/*  71 */     this.conversations.put(paramString, paramConversationState);
/*     */ 
/*     */     
/*  74 */     Iterator iterator = this.listeners.iterator();
/*  75 */     while (iterator.hasNext()) {
/*  76 */       ConversationListener conversationListener = (ConversationListener)iterator.next();
/*  77 */       conversationListener.conversationStart(paramString);
/*     */     } 
/*  79 */     return paramConversationState;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  84 */   public ConversationState getConversation(String paramString) throws ConversationException { return (ConversationState)this.conversations.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConversationLocation(String paramString) throws ConversationException {
/*  90 */     AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */ 
/*     */     
/*  93 */     if (hasConversation(paramString)) {
/*  94 */       return ManagementService.getRuntimeAccess(authenticatedSubject).getServer().getName();
/*     */     }
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregister(String paramString) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeConversation(String paramString) {
/* 108 */     this.conversations.remove(paramString);
/*     */ 
/*     */     
/* 111 */     Iterator iterator = this.listeners.iterator();
/* 112 */     while (iterator.hasNext()) {
/* 113 */       ConversationListener conversationListener = (ConversationListener)iterator.next();
/* 114 */       conversationListener.conversationEnd(paramString);
/*     */     } 
/* 116 */     unregister(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {}
/*     */ 
/*     */   
/*     */   public void removeTimedOutConversations() {
/* 124 */     Iterator iterator = this.conversations.values().iterator();
/* 125 */     while (iterator.hasNext()) {
/* 126 */       ConversationState conversationState = (ConversationState)iterator.next();
/*     */       try {
/* 128 */         if (conversationState.hasTimedOut()) {
/* 129 */           if (debug)
/* 130 */             System.out.println("ConversationManager::removeTimedOutConversations()::remove(" + conversationState.getId() + ")"); 
/* 131 */           iterator.remove();
/* 132 */           unregister(conversationState.getId());
/*     */         } 
/* 134 */       } catch (RemoteException remoteException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 140 */   public long getTimeOutInterval() { return this.timeOutInterval; }
/*     */ 
/*     */   
/*     */   public void setTimeOutInterval(long paramLong) {
/* 144 */     this.timeOutInterval = paramLong;
/* 145 */     this.invalidator.setTimeOutInterval(this.timeOutInterval);
/*     */   }
/*     */ 
/*     */   
/* 149 */   public void registerConversationListener(ConversationListener paramConversationListener) { this.listeners.add(paramConversationListener); }
/*     */   
/*     */   public ConversationManagerImpl() {}
/*     */   
/*     */   class StateInvalidator extends TimerTask { private Timer timer;
/*     */     private ConversationManager manager;
/*     */     private final ConversationManagerImpl this$0;
/*     */     
/*     */     public StateInvalidator(ConversationManager param1ConversationManager, long param1Long) {
/* 158 */       this.manager = param1ConversationManager;
/* 159 */       setTimeOutInterval(param1Long);
/*     */     }
/*     */     
/*     */     public void setTimeOutInterval(long param1Long) {
/* 163 */       if (this.timer != null)
/* 164 */         this.timer.cancel(); 
/* 165 */       this.timer = new Timer(true);
/* 166 */       this.timer.scheduleAtFixedRate(this, param1Long, param1Long);
/* 167 */       if (debug)
/* 168 */         System.out.println("StateInvalidator::setTimeOutInterval(" + param1Long + ")"); 
/*     */     }
/*     */     
/*     */     public void run() {
/* 172 */       if (debug)
/* 173 */         System.out.println("StateInvalidator::run():begin"); 
/*     */       try {
/* 175 */         this.manager.removeTimedOutConversations();
/* 176 */       } catch (ConversationException conversationException) {
/* 177 */         System.out.println(conversationException);
/*     */       } 
/* 179 */       if (debug)
/* 180 */         System.out.println("StateInvalidator::run():end"); 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationManagerImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */