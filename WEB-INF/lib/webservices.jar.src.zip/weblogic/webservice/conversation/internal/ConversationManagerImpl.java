package weblogic.webservice.conversation.internal;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.security.AccessController;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Timer;
import java.util.TimerTask;
import weblogic.management.provider.ManagementService;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.PrivilegedActions;
import weblogic.webservice.conversation.ConversationException;
import weblogic.webservice.conversation.ConversationListener;
import weblogic.webservice.conversation.ConversationManager;
import weblogic.webservice.conversation.ConversationState;

public class ConversationManagerImpl implements ConversationManager {
  private static boolean debug = false;
  
  private HashMap conversations = new HashMap();
  
  private ArrayList listeners = new ArrayList();
  
  private long timeOutInterval = 20000L;
  
  private StateInvalidator invalidator = new StateInvalidator(this, this.timeOutInterval);
  
  String internalId;
  
  public ConversationManagerImpl(String paramString) {
    this();
    this.internalId = paramString;
  }
  
  public void setId(String paramString) { this.internalId = paramString; }
  
  public String getId() { return this.internalId; }
  
  public Iterator getIds() { return this.conversations.keySet().iterator(); }
  
  public boolean hasConversation(String paramString) { return (this.conversations.get(paramString) != null); }
  
  public ConversationState createConversation(String paramString) throws ConversationException { return createConversation(paramString, new ConversationStateImpl(paramString)); }
  
  public ConversationState createConversation(String paramString, Serializable paramSerializable) throws ConversationException { return createConversation(paramString, new ConversationStateImpl(paramString, paramSerializable)); }
  
  protected ConversationState createConversation(String paramString, ConversationState paramConversationState) throws ConversationException {
    if (hasConversation(paramString))
      throw new ConversationException("Unable to create conversation with duplicate ID:" + paramString); 
    this.conversations.put(paramString, paramConversationState);
    Iterator iterator = this.listeners.iterator();
    while (iterator.hasNext()) {
      ConversationListener conversationListener = (ConversationListener)iterator.next();
      conversationListener.conversationStart(paramString);
    } 
    return paramConversationState;
  }
  
  public ConversationState getConversation(String paramString) throws ConversationException { return (ConversationState)this.conversations.get(paramString); }
  
  public String getConversationLocation(String paramString) throws ConversationException {
    AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
    if (hasConversation(paramString))
      return ManagementService.getRuntimeAccess(authenticatedSubject).getServer().getName(); 
    return null;
  }
  
  public void unregister(String paramString) {}
  
  public void removeConversation(String paramString) {
    this.conversations.remove(paramString);
    Iterator iterator = this.listeners.iterator();
    while (iterator.hasNext()) {
      ConversationListener conversationListener = (ConversationListener)iterator.next();
      conversationListener.conversationEnd(paramString);
    } 
    unregister(paramString);
  }
  
  public void shutdown() {}
  
  public void removeTimedOutConversations() {
    Iterator iterator = this.conversations.values().iterator();
    while (iterator.hasNext()) {
      ConversationState conversationState = (ConversationState)iterator.next();
      try {
        if (conversationState.hasTimedOut()) {
          if (debug)
            System.out.println("ConversationManager::removeTimedOutConversations()::remove(" + conversationState.getId() + ")"); 
          iterator.remove();
          unregister(conversationState.getId());
        } 
      } catch (RemoteException remoteException) {}
    } 
  }
  
  public long getTimeOutInterval() { return this.timeOutInterval; }
  
  public void setTimeOutInterval(long paramLong) {
    this.timeOutInterval = paramLong;
    this.invalidator.setTimeOutInterval(this.timeOutInterval);
  }
  
  public void registerConversationListener(ConversationListener paramConversationListener) { this.listeners.add(paramConversationListener); }
  
  public ConversationManagerImpl() {}
  
  class StateInvalidator extends TimerTask {
    private Timer timer;
    
    private ConversationManager manager;
    
    private final ConversationManagerImpl this$0;
    
    public StateInvalidator(ConversationManager param1ConversationManager, long param1Long) {
      this.manager = param1ConversationManager;
      setTimeOutInterval(param1Long);
    }
    
    public void setTimeOutInterval(long param1Long) {
      if (this.timer != null)
        this.timer.cancel(); 
      this.timer = new Timer(true);
      this.timer.scheduleAtFixedRate(this, param1Long, param1Long);
      if (debug)
        System.out.println("StateInvalidator::setTimeOutInterval(" + param1Long + ")"); 
    }
    
    public void run() {
      if (debug)
        System.out.println("StateInvalidator::run():begin"); 
      try {
        this.manager.removeTimedOutConversations();
      } catch (ConversationException conversationException) {
        System.out.println(conversationException);
      } 
      if (debug)
        System.out.println("StateInvalidator::run():end"); 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationManagerImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */