/*     */ package weblogic.webservice.conversation.internal;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.security.AccessController;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NameNotFoundException;
/*     */ import javax.naming.NamingException;
/*     */ import weblogic.jndi.Environment;
/*     */ import weblogic.management.provider.ManagementService;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.conversation.ConversationException;
/*     */ import weblogic.webservice.conversation.ConversationService;
/*     */ import weblogic.webservice.conversation.ConversationState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClusteredConversationManager
/*     */   extends ConversationManagerImpl
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   
/*     */   public ClusteredConversationManager() {}
/*     */   
/*  36 */   public ClusteredConversationManager(String paramString) { super(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConversationService getConversationService() {
/*     */     try {
/*  43 */       Context context = (new Environment()).getInitialContext();
/*  44 */       Object object = context.lookup("ConversationService");
/*  45 */       return (ConversationService)object;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  53 */     catch (NameNotFoundException nameNotFoundException) {
/*  54 */       System.out.println(nameNotFoundException);
/*  55 */       return null;
/*  56 */     } catch (NamingException namingException) {
/*  57 */       System.out.println(namingException);
/*  58 */       return null;
/*  59 */     } catch (RemoteException remoteException) {
/*  60 */       System.out.println(remoteException);
/*  61 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConversationService getNonNullConversationService() {
/*  68 */     ConversationService conversationService = getConversationService();
/*  69 */     if (conversationService == null)
/*  70 */       throw new ConversationException("Unable to contact conversation service you may need to add the following line to your config.xml file <ConversationService Name='{domain}' Targets='{your_target}'/>"); 
/*  71 */     return conversationService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConversationState createConversation(String paramString, ConversationState paramConversationState) throws ConversationException {
/*  80 */     ConversationState conversationState = super.createConversation(paramString, paramConversationState);
/*     */     
/*  82 */     ConversationService conversationService = getNonNullConversationService();
/*     */     
/*  84 */     AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */     
/*     */     try {
/*  87 */       conversationService.registerConversation(paramString, ManagementService.getRuntimeAccess(authenticatedSubject).getServer().getName(), conversationState);
/*  88 */     } catch (RemoteException remoteException) {
/*  89 */       throw new ConversationException("Unable to register conversation with ID:" + paramString, remoteException);
/*     */     } 
/*     */     
/*  92 */     return conversationState;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConversationState getConversation(String paramString) {
/*  97 */     ConversationState conversationState = super.getConversation(paramString);
/*     */     try {
/*  99 */       if (conversationState == null) {
/* 100 */         return getNonNullConversationService().getConversation(paramString);
/*     */       }
/* 102 */       return conversationState;
/* 103 */     } catch (ConversationException conversationException) {
/* 104 */       String str = WebServiceLogger.logConversationException();
/* 105 */       WebServiceLogger.logStackTrace(str, conversationException);
/* 106 */       return null;
/* 107 */     } catch (RemoteException remoteException) {
/* 108 */       String str = WebServiceLogger.logConversationRemoteException();
/* 109 */       WebServiceLogger.logStackTrace(str, remoteException);
/* 110 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConversationLocation(String paramString) throws ConversationException {
/* 117 */     String str = super.getConversationLocation(paramString);
/* 118 */     if (str != null) return str; 
/*     */     try {
/* 120 */       return getNonNullConversationService().getConversationLocation(paramString);
/* 121 */     } catch (RemoteException remoteException) {
/* 122 */       throw new ConversationException(remoteException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unregister(String paramString) {
/*     */     try {
/* 131 */       getNonNullConversationService().endConversation(paramString);
/* 132 */     } catch (RemoteException remoteException) {
/* 133 */       throw new ConversationException("Unable to end conversation with ID:" + paramString, remoteException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ClusteredConversationManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */