package weblogic.webservice.conversation.internal;

import java.rmi.RemoteException;
import java.security.AccessController;
import javax.naming.Context;
import javax.naming.NameNotFoundException;
import javax.naming.NamingException;
import weblogic.jndi.Environment;
import weblogic.management.provider.ManagementService;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.PrivilegedActions;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.conversation.ConversationException;
import weblogic.webservice.conversation.ConversationService;
import weblogic.webservice.conversation.ConversationState;

public class ClusteredConversationManager extends ConversationManagerImpl {
  private static final boolean debug = false;
  
  public ClusteredConversationManager() {}
  
  public ClusteredConversationManager(String paramString) { super(paramString); }
  
  public ConversationService getConversationService() {
    try {
      Context context = (new Environment()).getInitialContext();
      Object object = context.lookup("ConversationService");
      return (ConversationService)object;
    } catch (NameNotFoundException nameNotFoundException) {
      System.out.println(nameNotFoundException);
      return null;
    } catch (NamingException namingException) {
      System.out.println(namingException);
      return null;
    } catch (RemoteException remoteException) {
      System.out.println(remoteException);
      return null;
    } 
  }
  
  public ConversationService getNonNullConversationService() {
    ConversationService conversationService = getConversationService();
    if (conversationService == null)
      throw new ConversationException("Unable to contact conversation service you may need to add the following line to your config.xml file <ConversationService Name='{domain}' Targets='{your_target}'/>"); 
    return conversationService;
  }
  
  protected ConversationState createConversation(String paramString, ConversationState paramConversationState) throws ConversationException {
    ConversationState conversationState = super.createConversation(paramString, paramConversationState);
    ConversationService conversationService = getNonNullConversationService();
    AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
    try {
      conversationService.registerConversation(paramString, ManagementService.getRuntimeAccess(authenticatedSubject).getServer().getName(), conversationState);
    } catch (RemoteException remoteException) {
      throw new ConversationException("Unable to register conversation with ID:" + paramString, remoteException);
    } 
    return conversationState;
  }
  
  public ConversationState getConversation(String paramString) {
    ConversationState conversationState = super.getConversation(paramString);
    try {
      if (conversationState == null)
        return getNonNullConversationService().getConversation(paramString); 
      return conversationState;
    } catch (ConversationException conversationException) {
      String str = WebServiceLogger.logConversationException();
      WebServiceLogger.logStackTrace(str, conversationException);
      return null;
    } catch (RemoteException remoteException) {
      String str = WebServiceLogger.logConversationRemoteException();
      WebServiceLogger.logStackTrace(str, remoteException);
      return null;
    } 
  }
  
  public String getConversationLocation(String paramString) throws ConversationException {
    String str = super.getConversationLocation(paramString);
    if (str != null)
      return str; 
    try {
      return getNonNullConversationService().getConversationLocation(paramString);
    } catch (RemoteException remoteException) {
      throw new ConversationException(remoteException);
    } 
  }
  
  public void unregister(String paramString) {
    try {
      getNonNullConversationService().endConversation(paramString);
    } catch (RemoteException remoteException) {
      throw new ConversationException("Unable to end conversation with ID:" + paramString, remoteException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ClusteredConversationManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */