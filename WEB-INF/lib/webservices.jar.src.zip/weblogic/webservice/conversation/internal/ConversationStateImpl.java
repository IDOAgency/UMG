/*    */ package weblogic.webservice.conversation.internal;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.rmi.RemoteException;
/*    */ import weblogic.webservice.conversation.ConversationState;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConversationStateImpl
/*    */   implements ConversationState
/*    */ {
/*    */   private long creationTime;
/*    */   private String id;
/*    */   private String callbackURI;
/* 15 */   private long maxInactiveInterval = 30000L;
/*    */   private long lastAccessedTime;
/*    */   private Serializable component;
/*    */   private boolean LOCKED = false;
/*    */   
/*    */   public ConversationStateImpl() {
/* 21 */     this.creationTime = System.currentTimeMillis();
/* 22 */     this.lastAccessedTime = this.creationTime;
/*    */   }
/*    */   
/*    */   public ConversationStateImpl(String paramString) {
/* 26 */     this.id = paramString;
/* 27 */     this.creationTime = System.currentTimeMillis();
/* 28 */     this.lastAccessedTime = this.creationTime;
/*    */   }
/*    */   public ConversationStateImpl(String paramString, Serializable paramSerializable) {
/* 31 */     this.id = paramString;
/* 32 */     this.component = paramSerializable;
/* 33 */     this.creationTime = System.currentTimeMillis();
/* 34 */     this.lastAccessedTime = this.creationTime;
/*    */   }
/*    */ 
/*    */   
/* 38 */   public void setCallbackURI(String paramString) { this.callbackURI = paramString; }
/*    */ 
/*    */   
/* 41 */   public String getCallbackURI() throws RemoteException { return this.callbackURI; }
/*    */ 
/*    */   
/* 44 */   public long getCreationTime() throws RemoteException { return this.creationTime; }
/*    */   
/* 46 */   public String getId() throws RemoteException { return this.id; }
/*    */   
/* 48 */   public void setMaxInactiveInterval(long paramLong) throws RemoteException { this.maxInactiveInterval = paramLong; }
/*    */   
/* 50 */   public long getMaxInactiveInterval() throws RemoteException { return this.maxInactiveInterval; }
/*    */   
/* 52 */   public boolean isLocked() { return this.LOCKED; }
/*    */   
/*    */   public Serializable getComponent() throws RemoteException {
/* 55 */     if (this.LOCKED) throw new RemoteException("Unable to access locked state."); 
/* 56 */     this.LOCKED = true;
/* 57 */     access();
/* 58 */     return this.component;
/*    */   }
/*    */   
/*    */   public void setComponent(Serializable paramSerializable) throws RemoteException {
/* 62 */     if (!this.LOCKED) throw new RemoteException("Unable to set stale state."); 
/* 63 */     this.LOCKED = false;
/* 64 */     access();
/* 65 */     this.component = paramSerializable;
/*    */   }
/*    */   
/* 68 */   private void access() { this.lastAccessedTime = System.currentTimeMillis(); }
/*    */ 
/*    */   
/* 71 */   public long getLastAccessedTime() throws RemoteException { return this.lastAccessedTime; }
/*    */ 
/*    */   
/* 74 */   public boolean hasTimedOut() { return (getLastAccessedTime() + getMaxInactiveInterval() < System.currentTimeMillis()); }
/*    */   
/*    */   public void destroy() {
/* 77 */     this.component = null;
/* 78 */     this.id = null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationStateImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */