package weblogic.webservice.conversation.internal;

import java.io.Serializable;
import java.rmi.RemoteException;
import weblogic.webservice.conversation.ConversationState;

public class ConversationStateImpl implements ConversationState {
  private long creationTime;
  
  private String id;
  
  private String callbackURI;
  
  private long maxInactiveInterval = 30000L;
  
  private long lastAccessedTime;
  
  private Serializable component;
  
  private boolean LOCKED = false;
  
  public ConversationStateImpl() {
    this.creationTime = System.currentTimeMillis();
    this.lastAccessedTime = this.creationTime;
  }
  
  public ConversationStateImpl(String paramString) {
    this.id = paramString;
    this.creationTime = System.currentTimeMillis();
    this.lastAccessedTime = this.creationTime;
  }
  
  public ConversationStateImpl(String paramString, Serializable paramSerializable) {
    this.id = paramString;
    this.component = paramSerializable;
    this.creationTime = System.currentTimeMillis();
    this.lastAccessedTime = this.creationTime;
  }
  
  public void setCallbackURI(String paramString) { this.callbackURI = paramString; }
  
  public String getCallbackURI() throws RemoteException { return this.callbackURI; }
  
  public long getCreationTime() throws RemoteException { return this.creationTime; }
  
  public String getId() throws RemoteException { return this.id; }
  
  public void setMaxInactiveInterval(long paramLong) throws RemoteException { this.maxInactiveInterval = paramLong; }
  
  public long getMaxInactiveInterval() throws RemoteException { return this.maxInactiveInterval; }
  
  public boolean isLocked() { return this.LOCKED; }
  
  public Serializable getComponent() throws RemoteException {
    if (this.LOCKED)
      throw new RemoteException("Unable to access locked state."); 
    this.LOCKED = true;
    access();
    return this.component;
  }
  
  public void setComponent(Serializable paramSerializable) throws RemoteException {
    if (!this.LOCKED)
      throw new RemoteException("Unable to set stale state."); 
    this.LOCKED = false;
    access();
    this.component = paramSerializable;
  }
  
  private void access() { this.lastAccessedTime = System.currentTimeMillis(); }
  
  public long getLastAccessedTime() throws RemoteException { return this.lastAccessedTime; }
  
  public boolean hasTimedOut() { return (getLastAccessedTime() + getMaxInactiveInterval() < System.currentTimeMillis()); }
  
  public void destroy() {
    this.component = null;
    this.id = null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationStateImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */