package weblogic.webservice.conversation.internal;

import java.io.IOException;
import java.rmi.MarshalException;
import java.rmi.UnmarshalException;
import weblogic.rmi.internal.Skeleton;
import weblogic.rmi.spi.InboundRequest;
import weblogic.rmi.spi.MsgInput;
import weblogic.rmi.spi.OutboundResponse;
import weblogic.webservice.conversation.ConversationService;
import weblogic.webservice.conversation.ConversationState;

public final class ConversationServiceImpl_WLSkel extends Skeleton {
  public OutboundResponse invoke(int paramInt, InboundRequest paramInboundRequest, OutboundResponse paramOutboundResponse, Object paramObject) throws Exception {
    ConversationState conversationState2;
    ConversationState conversationState1;
    String str1;
    switch (paramInt) {
      case 0:
        try {
          MsgInput msgInput = paramInboundRequest.getMsgInput();
          str1 = (String)msgInput.readObject(String.class);
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } 
        ((ConversationService)paramObject).endConversation(str1);
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        return paramOutboundResponse;
      case 1:
        try {
          MsgInput msgInput = paramInboundRequest.getMsgInput();
          str1 = (String)msgInput.readObject(String.class);
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } 
        conversationState1 = ((ConversationService)paramObject).getConversation(str1);
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeObject(conversationState1, ConversationState.class);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 2:
        try {
          MsgInput msgInput = paramInboundRequest.getMsgInput();
          str1 = (String)msgInput.readObject(String.class);
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } 
        str2 = ((ConversationService)paramObject).getConversationLocation(str1);
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeObject(str2, String.class);
        } catch (IOException iOException) {
          throw new MarshalException("error marshalling return", iOException);
        } 
        return paramOutboundResponse;
      case 3:
        try {
          MsgInput msgInput = paramInboundRequest.getMsgInput();
          str1 = (String)msgInput.readObject(String.class);
          str2 = (String)msgInput.readObject(String.class);
        } catch (IOException null) {
          throw new UnmarshalException("error unmarshalling arguments", conversationState2);
        } catch (ClassNotFoundException null) {
          throw new UnmarshalException("error unmarshalling arguments", conversationState2);
        } 
        ((ConversationService)paramObject).registerConversation(str1, str2);
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        return paramOutboundResponse;
      case 4:
        try {
          MsgInput msgInput = paramInboundRequest.getMsgInput();
          str1 = (String)msgInput.readObject(String.class);
          str2 = (String)msgInput.readObject(String.class);
          conversationState2 = (ConversationState)msgInput.readObject(ConversationState.class);
        } catch (IOException iOException) {
          throw new UnmarshalException("error unmarshalling arguments", iOException);
        } catch (ClassNotFoundException classNotFoundException) {
          throw new UnmarshalException("error unmarshalling arguments", classNotFoundException);
        } 
        ((ConversationService)paramObject).registerConversation(str1, str2, conversationState2);
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        return paramOutboundResponse;
      case 5:
        str1 = ((ConversationService)paramObject).whereAmI();
        associateResponseData(paramInboundRequest, paramOutboundResponse);
        try {
          paramOutboundResponse.getMsgOutput().writeObject(str1, String.class);
        } catch (IOException str2) {
          throw new MarshalException("error marshalling return", str2);
        } 
        return paramOutboundResponse;
    } 
    throw new UnmarshalException("Method identifier [" + paramInt + "] out of range");
  }
  
  public Object invoke(int paramInt, Object[] paramArrayOfObject, Object paramObject) throws Exception {
    switch (paramInt) {
      case 0:
        ((ConversationService)paramObject).endConversation((String)paramArrayOfObject[0]);
        return null;
      case 1:
        return ((ConversationService)paramObject).getConversation((String)paramArrayOfObject[0]);
      case 2:
        return ((ConversationService)paramObject).getConversationLocation((String)paramArrayOfObject[0]);
      case 3:
        ((ConversationService)paramObject).registerConversation((String)paramArrayOfObject[0], (String)paramArrayOfObject[1]);
        return null;
      case 4:
        ((ConversationService)paramObject).registerConversation((String)paramArrayOfObject[0], (String)paramArrayOfObject[1], (ConversationState)paramArrayOfObject[2]);
        return null;
      case 5:
        return ((ConversationService)paramObject).whereAmI();
    } 
    throw new UnmarshalException("Method identifier [" + paramInt + "] out of range");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationServiceImpl_WLSkel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */