package weblogic.webservice.conversation.internal;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import weblogic.rmi.extensions.RemoteRuntimeException;
import weblogic.rmi.extensions.server.RemoteReference;
import weblogic.rmi.extensions.server.RuntimeMethodDescriptor;
import weblogic.rmi.internal.MethodDescriptor;
import weblogic.rmi.internal.Stub;
import weblogic.rmi.internal.StubInfo;
import weblogic.rmi.internal.StubInfoIntf;
import weblogic.rmi.utils.Utilities;
import weblogic.webservice.conversation.ConversationState;

public final class ConversationStateImpl_900_WLStub extends Stub implements StubInfoIntf, ConversationState {
  private static RuntimeMethodDescriptor md6;
  
  private static RuntimeMethodDescriptor md5;
  
  private static boolean initialized;
  
  private static RuntimeMethodDescriptor md3;
  
  private static RuntimeMethodDescriptor md2;
  
  private static RuntimeMethodDescriptor md1;
  
  private static RuntimeMethodDescriptor md0;
  
  private static RuntimeMethodDescriptor md11;
  
  private static RuntimeMethodDescriptor md10;
  
  private final RemoteReference ror;
  
  private final StubInfo stubinfo;
  
  private static RuntimeMethodDescriptor md4;
  
  private static Method[] m;
  
  private static RuntimeMethodDescriptor md9;
  
  private static RuntimeMethodDescriptor md8;
  
  private static RuntimeMethodDescriptor md7;
  
  public ConversationStateImpl_900_WLStub(StubInfo paramStubInfo) {
    super(paramStubInfo);
    this.stubinfo = paramStubInfo;
    this.ror = this.stubinfo.getRemoteRef();
    ensureInitialized(this.stubinfo);
  }
  
  public StubInfo getStubInfo() { return this.stubinfo; }
  
  private static void ensureInitialized(StubInfo paramStubInfo) {
    if (initialized)
      return; 
    m = Utilities.getRemoteRMIMethods(paramStubInfo.getInterfaces());
    md0 = new MethodDescriptor(m[0], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[0]), paramStubInfo.getRemoteRef().getObjectID());
    md1 = new MethodDescriptor(m[1], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[1]), paramStubInfo.getRemoteRef().getObjectID());
    md2 = new MethodDescriptor(m[2], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[2]), paramStubInfo.getRemoteRef().getObjectID());
    md3 = new MethodDescriptor(m[3], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[3]), paramStubInfo.getRemoteRef().getObjectID());
    md4 = new MethodDescriptor(m[4], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[4]), paramStubInfo.getRemoteRef().getObjectID());
    md5 = new MethodDescriptor(m[5], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[5]), paramStubInfo.getRemoteRef().getObjectID());
    md6 = new MethodDescriptor(m[6], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[6]), paramStubInfo.getRemoteRef().getObjectID());
    md7 = new MethodDescriptor(m[7], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[7]), paramStubInfo.getRemoteRef().getObjectID());
    md8 = new MethodDescriptor(m[8], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[8]), paramStubInfo.getRemoteRef().getObjectID());
    md9 = new MethodDescriptor(m[9], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[9]), paramStubInfo.getRemoteRef().getObjectID());
    md10 = new MethodDescriptor(m[10], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[10]), paramStubInfo.getRemoteRef().getObjectID());
    md11 = new MethodDescriptor(m[11], ConversationState.class, false, true, false, false, paramStubInfo.getTimeOut(m[11]), paramStubInfo.getRemoteRef().getObjectID());
    initialized = true;
  }
  
  public final void destroy() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      this.ror.invoke(null, md0, arrayOfObject, m[0]);
      return;
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final String getCallbackURI() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return (String)this.ror.invoke(null, md1, arrayOfObject, m[1]);
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final Serializable getComponent() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return (Serializable)this.ror.invoke(null, md2, arrayOfObject, m[2]);
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final long getCreationTime() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return ((Long)this.ror.invoke(null, md3, arrayOfObject, m[3])).longValue();
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final String getId() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return (String)this.ror.invoke(null, md4, arrayOfObject, m[4]);
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final long getLastAccessedTime() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return ((Long)this.ror.invoke(null, md5, arrayOfObject, m[5])).longValue();
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final long getMaxInactiveInterval() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return ((Long)this.ror.invoke(null, md6, arrayOfObject, m[6])).longValue();
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final boolean hasTimedOut() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return ((Boolean)this.ror.invoke(null, md7, arrayOfObject, m[7])).booleanValue();
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final boolean isLocked() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return ((Boolean)this.ror.invoke(null, md8, arrayOfObject, m[8])).booleanValue();
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final void setCallbackURI(String paramString) throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = paramString;
      this.ror.invoke(null, md9, arrayOfObject, m[9]);
      return;
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final void setComponent(Serializable paramSerializable) throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = paramSerializable;
      this.ror.invoke(null, md10, arrayOfObject, m[10]);
      return;
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final void setMaxInactiveInterval(long paramLong) throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = new Long(paramLong);
      this.ror.invoke(null, md11, arrayOfObject, m[11]);
      return;
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationStateImpl_900_WLStub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */