package weblogic.webservice.conversation.internal;

import java.lang.reflect.Method;
import java.rmi.RemoteException;
import weblogic.rmi.extensions.RemoteRuntimeException;
import weblogic.rmi.extensions.server.RemoteReference;
import weblogic.rmi.extensions.server.RuntimeMethodDescriptor;
import weblogic.rmi.internal.MethodDescriptor;
import weblogic.rmi.internal.Stub;
import weblogic.rmi.internal.StubInfo;
import weblogic.rmi.internal.StubInfoIntf;
import weblogic.rmi.utils.Utilities;
import weblogic.webservice.conversation.ConversationService;
import weblogic.webservice.conversation.ConversationState;

public final class ConversationServiceImpl_900_WLStub extends Stub implements StubInfoIntf, ConversationService {
  private static RuntimeMethodDescriptor md5;
  
  private static Method[] m;
  
  private static RuntimeMethodDescriptor md3;
  
  private static RuntimeMethodDescriptor md2;
  
  private final StubInfo stubinfo;
  
  private static RuntimeMethodDescriptor md0;
  
  private static RuntimeMethodDescriptor md4;
  
  private final RemoteReference ror;
  
  private static RuntimeMethodDescriptor md1;
  
  private static boolean initialized;
  
  public ConversationServiceImpl_900_WLStub(StubInfo paramStubInfo) {
    super(paramStubInfo);
    this.stubinfo = paramStubInfo;
    this.ror = this.stubinfo.getRemoteRef();
    ensureInitialized(this.stubinfo);
  }
  
  public StubInfo getStubInfo() { return this.stubinfo; }
  
  private static void ensureInitialized(StubInfo paramStubInfo) {
    if (initialized)
      return; 
    m = Utilities.getRemoteRMIMethods(paramStubInfo.getInterfaces());
    md0 = new MethodDescriptor(m[0], ConversationService.class, false, true, false, false, paramStubInfo.getTimeOut(m[0]), paramStubInfo.getRemoteRef().getObjectID());
    md1 = new MethodDescriptor(m[1], ConversationService.class, false, true, false, false, paramStubInfo.getTimeOut(m[1]), paramStubInfo.getRemoteRef().getObjectID());
    md2 = new MethodDescriptor(m[2], ConversationService.class, false, true, false, false, paramStubInfo.getTimeOut(m[2]), paramStubInfo.getRemoteRef().getObjectID());
    md3 = new MethodDescriptor(m[3], ConversationService.class, false, true, false, false, paramStubInfo.getTimeOut(m[3]), paramStubInfo.getRemoteRef().getObjectID());
    md4 = new MethodDescriptor(m[4], ConversationService.class, false, true, false, false, paramStubInfo.getTimeOut(m[4]), paramStubInfo.getRemoteRef().getObjectID());
    md5 = new MethodDescriptor(m[5], ConversationService.class, false, true, false, false, paramStubInfo.getTimeOut(m[5]), paramStubInfo.getRemoteRef().getObjectID());
    initialized = true;
  }
  
  public final void endConversation(String paramString) throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = paramString;
      this.ror.invoke(null, md0, arrayOfObject, m[0]);
      return;
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final ConversationState getConversation(String paramString) throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = paramString;
      return (ConversationState)this.ror.invoke(null, md1, arrayOfObject, m[1]);
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final String getConversationLocation(String paramString) throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = paramString;
      return (String)this.ror.invoke(null, md2, arrayOfObject, m[2]);
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final void registerConversation(String paramString1, String paramString2) throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = paramString1;
      arrayOfObject[1] = paramString2;
      this.ror.invoke(null, md3, arrayOfObject, m[3]);
      return;
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final void registerConversation(String paramString1, String paramString2, ConversationState paramConversationState) throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = paramString1;
      arrayOfObject[1] = paramString2;
      arrayOfObject[2] = paramConversationState;
      this.ror.invoke(null, md4, arrayOfObject, m[4]);
      return;
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
  
  public final String whereAmI() throws RemoteException {
    try {
      Object[] arrayOfObject = new Object[0];
      return (String)this.ror.invoke(null, md5, arrayOfObject, m[5]);
    } catch (Error error) {
      throw error;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (RemoteException remoteException) {
      throw remoteException;
    } catch (Throwable throwable) {
      throw new RemoteRuntimeException("Unexpected Exception", throwable);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationServiceImpl_900_WLStub.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */