/*     */ package weblogic.webservice.conversation.internal;
/*     */ 
/*     */ import java.rmi.RemoteException;
/*     */ import java.security.AccessController;
/*     */ import java.util.HashMap;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import weblogic.cluster.migration.Migratable;
/*     */ import weblogic.cluster.migration.MigratableRemote;
/*     */ import weblogic.cluster.migration.MigrationException;
/*     */ import weblogic.cluster.migration.MigrationManager;
/*     */ import weblogic.management.DeploymentException;
/*     */ import weblogic.management.UndeploymentException;
/*     */ import weblogic.management.configuration.ConversationServiceMBean;
/*     */ import weblogic.management.configuration.DeploymentMBean;
/*     */ import weblogic.management.configuration.MigratableTargetMBean;
/*     */ import weblogic.management.internal.DeploymentHandler;
/*     */ import weblogic.management.internal.DeploymentHandlerContext;
/*     */ import weblogic.management.internal.DeploymentHandlerHome;
/*     */ import weblogic.management.provider.ManagementService;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.server.AbstractServerService;
/*     */ import weblogic.webservice.conversation.ConversationService;
/*     */ import weblogic.webservice.conversation.ConversationState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConversationServiceImpl
/*     */   extends AbstractServerService
/*     */   implements ConversationService, MigratableRemote, DeploymentHandler
/*     */ {
/*     */   private static boolean debug = false;
/*  37 */   private MigratableTargetMBean mt = null;
/*     */   
/*     */   private boolean active = false;
/*     */   
/*     */   private boolean deployed = false;
/*     */   
/*  43 */   private HashMap conversations = new HashMap();
/*  44 */   private HashMap locations = new HashMap();
/*     */   
/*  46 */   private static final AuthenticatedSubject kernelId = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerConversation(String paramString1, String paramString2) throws RemoteException {
/*  53 */     if (this.conversations.get(paramString1) != null || this.locations.get(paramString1) != null)
/*     */     {
/*  55 */       throw new RemoteException("Duplicate conversation id:" + paramString1);
/*     */     }
/*  57 */     this.locations.put(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerConversation(String paramString1, String paramString2, ConversationState paramConversationState) throws RemoteException {
/*  65 */     if (debug) System.out.println("ConversationServiceImpl::register(" + paramString1 + "," + paramString2 + "," + paramConversationState.getId() + "):start()"); 
/*  66 */     if (this.conversations.get(paramString1) != null || this.locations.get(paramString1) != null)
/*     */     {
/*  68 */       throw new RemoteException("Duplicate conversation id:" + paramString1);
/*     */     }
/*     */     
/*  71 */     this.conversations.put(paramString1, paramConversationState);
/*  72 */     this.locations.put(paramString1, paramString2);
/*     */     
/*  74 */     if (debug) System.out.println("ConversationServiceImpl::register(" + paramString1 + "," + paramString2 + "," + paramConversationState.getId() + "):end()");
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  80 */   public ConversationState getConversation(String paramString) throws RemoteException { return (ConversationState)this.conversations.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public String getConversationLocation(String paramString) throws RemoteException { return (String)this.locations.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endConversation(String paramString) throws RemoteException {
/*  92 */     if (this.conversations.get(paramString) == null && this.locations.get(paramString) == null)
/*     */     {
/*  94 */       throw new RemoteException("Cannot end conversation" + paramString);
/*     */     }
/*  96 */     this.conversations.remove(paramString);
/*  97 */     this.locations.remove(paramString);
/*  98 */     if (debug) System.out.println("ConversationServiceImpl::endConversation(" + paramString + ")");
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 104 */   public String whereAmI() throws RemoteException { return ManagementService.getRuntimeAccess(kernelId).getServer().getName(); }
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void migratableInitialize(Migratable.LeaseMonitor paramLeaseMonitor) { if (debug) System.out.println("ConversationServiceImpl:migratableInitialize()");
/*     */      }
/*     */   
/*     */   public void migratableActivate() {
/* 112 */     if (debug) System.out.println("ConversationServiceImpl:migratableActivate()"); 
/* 113 */     synchronized (this) {
/* 114 */       if (this.active)
/* 115 */         return;  this.active = true;
/*     */     } 
/*     */     
/*     */     try {
/* 119 */       (new InitialContext()).rebind("ConversationService", this);
/* 120 */     } catch (NamingException namingException) {
/* 121 */       throw new MigrationException(namingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void migratableDeactivate() {
/* 127 */     if (debug) System.out.println("ConversationServiceImpl:migratableDeactivate()"); 
/* 128 */     synchronized (this) {
/* 129 */       if (!this.active)
/* 130 */         return;  this.active = false;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 135 */       InitialContext initialContext = new InitialContext();
/* 136 */       initialContext.unbind("ConversationService");
/* 137 */     } catch (NamingException namingException) {
/* 138 */       throw new MigrationException(namingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 145 */     if (debug) System.err.println("ConversationService::stop()"); 
/* 146 */     halt();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 152 */     if (debug) System.err.println("ConversationService::start()"); 
/* 153 */     if (ManagementService.getRuntimeAccess(kernelId).getServer().getCluster() == null)
/* 154 */       return;  DeploymentHandlerHome.addDeploymentHandler(this);
/*     */   }
/*     */   
/*     */   public void halt() {
/* 158 */     if (debug) System.err.println("ConversationService::halt()"); 
/* 159 */     if (ManagementService.getRuntimeAccess(kernelId).getServer().getCluster() == null)
/* 160 */       return;  DeploymentHandlerHome.removeDeploymentHandler(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deploy(ConversationServiceMBean paramConversationServiceMBean) throws DeploymentException {
/* 167 */     if (debug) System.err.println("--> deploy ..."); 
/* 168 */     if (ManagementService.getRuntimeAccess(kernelId).getServer().getCluster() == null || this.deployed) {
/* 169 */       System.err.println("--> not in cluster or already deployed not deploying...");
/*     */       return;
/*     */     } 
/*     */     try {
/* 173 */       MigratableTargetMBean migratableTargetMBean = (MigratableTargetMBean)paramConversationServiceMBean.getTargets()[0];
/* 174 */       MigrationManager.singleton().register(this, "ConversationService", migratableTargetMBean);
/* 175 */       this.deployed = true;
/* 176 */     } catch (Exception exception) {
/* 177 */       throw new DeploymentException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void undeploy(ConversationServiceMBean paramConversationServiceMBean) throws DeploymentException {
/* 184 */     if (debug) System.err.println("--> undeploy ..."); 
/* 185 */     if (!this.deployed) {
/* 186 */       System.err.println("--> attempt to undeploy, already undeployed,  not undeploying...");
/*     */       return;
/*     */     } 
/*     */     try {
/* 190 */       MigratableTargetMBean migratableTargetMBean = (MigratableTargetMBean)paramConversationServiceMBean.getTargets()[0];
/* 191 */       MigrationManager.singleton().unregister(this, migratableTargetMBean);
/* 192 */       this.deployed = false;
/* 193 */     } catch (Exception exception) {
/* 194 */       throw new UndeploymentException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void prepareDeployment(DeploymentMBean paramDeploymentMBean, DeploymentHandlerContext paramDeploymentHandlerContext) throws DeploymentException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void activateDeployment(DeploymentMBean paramDeploymentMBean, DeploymentHandlerContext paramDeploymentHandlerContext) throws DeploymentException {
/* 211 */     if (debug) System.out.println("ConversationService --> deploy ..."); 
/* 212 */     if (paramDeploymentMBean instanceof ConversationServiceMBean) {
/*     */       try {
/* 214 */         deploy((ConversationServiceMBean)paramDeploymentMBean);
/* 215 */       } catch (Exception exception) {
/* 216 */         throw new DeploymentException("failed to deploy ConversationServiceMBean " + paramDeploymentMBean.getName(), exception);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deactivateDeployment(DeploymentMBean paramDeploymentMBean, DeploymentHandlerContext paramDeploymentHandlerContext) throws DeploymentException {
/* 226 */     if (debug) System.out.println("ConversationService --> undeploy ..."); 
/* 227 */     if (paramDeploymentMBean instanceof ConversationServiceMBean)
/*     */       try {
/* 229 */         undeploy((ConversationServiceMBean)paramDeploymentMBean);
/* 230 */       } catch (Exception exception) {
/* 231 */         throw new UndeploymentException("failed to undeploy ConversationServiceMBean " + paramDeploymentMBean.getName(), exception);
/*     */       }  
/*     */   }
/*     */   
/*     */   public void unprepareDeployment(DeploymentMBean paramDeploymentMBean, DeploymentHandlerContext paramDeploymentHandlerContext) throws DeploymentException {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\ConversationServiceImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */