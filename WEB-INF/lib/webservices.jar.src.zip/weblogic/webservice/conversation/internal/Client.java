/*    */ package weblogic.webservice.conversation.internal;
/*    */ 
/*    */ import javax.naming.Context;
/*    */ import weblogic.jndi.Environment;
/*    */ import weblogic.rmi.internal.StubInfoIntf;
/*    */ import weblogic.webservice.conversation.ConversationService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Client
/*    */ {
/*    */   public static void main(String[] paramArrayOfString) throws Exception {
/* 17 */     if (paramArrayOfString.length < 2) {
/* 18 */       System.out.println("Usage: java ...Client t3://host:port jndi-name");
/*    */     } else {
/*    */       while (true) {
/* 21 */         System.out.println("Contacting: " + paramArrayOfString[0]);
/* 22 */         Context context = null;
/* 23 */         Environment environment = new Environment();
/* 24 */         environment.setProviderUrl(paramArrayOfString[0]);
/* 25 */         ConversationService conversationService = null;
/* 26 */         context = environment.getInitialContext();
/* 27 */         System.out.println("Lookup of: " + paramArrayOfString[1]);
/* 28 */         Object object = context.lookup(paramArrayOfString[1]);
/* 29 */         StubInfoIntf stubInfoIntf = (StubInfoIntf)object;
/* 30 */         System.out.println(stubInfoIntf.getStubInfo().getRemoteRef());
/* 31 */         conversationService = (ConversationService)object;
/* 32 */         System.out.println("looping forever, hit control-C to stop");
/* 33 */         boolean bool = false;
/* 34 */         while (!bool) {
/*    */           try {
/* 36 */             System.out.println(conversationService.whereAmI());
/* 37 */             Thread.currentThread().sleep(10000L);
/* 38 */           } catch (Exception exception) {
/* 39 */             exception.printStackTrace();
/* 40 */             bool = true;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\Client.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */