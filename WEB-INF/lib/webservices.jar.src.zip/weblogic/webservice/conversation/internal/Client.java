package weblogic.webservice.conversation.internal;

import javax.naming.Context;
import weblogic.jndi.Environment;
import weblogic.rmi.internal.StubInfoIntf;
import weblogic.webservice.conversation.ConversationService;

public final class Client {
  public static void main(String[] paramArrayOfString) throws Exception {
    if (paramArrayOfString.length < 2) {
      System.out.println("Usage: java ...Client t3://host:port jndi-name");
    } else {
      while (true) {
        System.out.println("Contacting: " + paramArrayOfString[0]);
        Context context = null;
        Environment environment = new Environment();
        environment.setProviderUrl(paramArrayOfString[0]);
        ConversationService conversationService = null;
        context = environment.getInitialContext();
        System.out.println("Lookup of: " + paramArrayOfString[1]);
        Object object = context.lookup(paramArrayOfString[1]);
        StubInfoIntf stubInfoIntf = (StubInfoIntf)object;
        System.out.println(stubInfoIntf.getStubInfo().getRemoteRef());
        conversationService = (ConversationService)object;
        System.out.println("looping forever, hit control-C to stop");
        boolean bool = false;
        while (!bool) {
          try {
            System.out.println(conversationService.whereAmI());
            Thread.currentThread().sleep(10000L);
          } catch (Exception exception) {
            exception.printStackTrace();
            bool = true;
          } 
        } 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\internal\Client.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */