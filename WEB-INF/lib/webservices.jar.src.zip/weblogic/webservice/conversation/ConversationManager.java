package weblogic.webservice.conversation;

import java.io.Serializable;
import java.util.Iterator;

public interface ConversationManager {
  Iterator getIds();
  
  boolean hasConversation(String paramString);
  
  ConversationState createConversation(String paramString) throws ConversationException;
  
  ConversationState createConversation(String paramString, Serializable paramSerializable) throws ConversationException;
  
  ConversationState getConversation(String paramString) throws ConversationException;
  
  String getConversationLocation(String paramString) throws ConversationException;
  
  String getId();
  
  void removeConversation(String paramString) throws ConversationException;
  
  void shutdown();
  
  void removeTimedOutConversations();
  
  void setTimeOutInterval(long paramLong);
  
  long getTimeOutInterval();
  
  void registerConversationListener(ConversationListener paramConversationListener);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\ConversationManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */