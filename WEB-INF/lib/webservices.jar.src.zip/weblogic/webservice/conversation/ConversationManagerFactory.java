/*    */ package weblogic.webservice.conversation;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import weblogic.management.provider.ManagementService;
/*    */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*    */ import weblogic.security.service.PrivilegedActions;
/*    */ import weblogic.webservice.conversation.internal.ClusteredConversationManager;
/*    */ import weblogic.webservice.conversation.internal.ConversationManagerImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConversationManagerFactory
/*    */ {
/*    */   private static ConversationManager instance;
/*    */   
/*    */   public static boolean inCluster() {
/* 20 */     AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*    */     
/* 22 */     return (ManagementService.getRuntimeAccess(authenticatedSubject).getServer().getCluster() != null);
/*    */   }
/*    */   
/*    */   public static ConversationManager getManager() {
/* 26 */     if (instance == null)
/* 27 */       if (inCluster()) {
/* 28 */         instance = new ClusteredConversationManager();
/*    */       } else {
/* 30 */         instance = new ConversationManagerImpl();
/*    */       }  
/* 32 */     return instance;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\conversation\ConversationManagerFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */