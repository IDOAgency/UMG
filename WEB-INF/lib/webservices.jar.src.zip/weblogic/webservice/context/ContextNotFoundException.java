package weblogic.webservice.context;

public class ContextNotFoundException extends Exception {
  public ContextNotFoundException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\ContextNotFoundException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */