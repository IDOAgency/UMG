/*    */ package weblogic.webservice.context;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Enumeration;
/*    */ import java.util.Iterator;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServiceHttpSessionImpl
/*    */   implements WebServiceSession
/*    */ {
/*    */   private HttpServletRequest request;
/*    */   
/* 25 */   public WebServiceHttpSessionImpl(HttpServletRequest paramHttpServletRequest) { this.request = paramHttpServletRequest; }
/*    */ 
/*    */ 
/*    */   
/* 29 */   public Object getUnderlyingSession() throws JAXRPCException { return this.request.getSession(); }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public Object getRequest() throws JAXRPCException { return this.request; }
/*    */ 
/*    */ 
/*    */   
/* 37 */   public Object getAttribute(String paramString) { return this.request.getSession().getAttribute(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 41 */   public void setAttribute(String paramString, Object paramObject) { this.request.getSession().setAttribute(paramString, paramObject); }
/*    */ 
/*    */   
/*    */   public Iterator getAttributeNames() {
/* 45 */     Enumeration enumeration = this.request.getSession().getAttributeNames();
/*    */     
/* 47 */     ArrayList arrayList = new ArrayList();
/*    */     
/* 49 */     while (enumeration.hasMoreElements()) {
/* 50 */       arrayList.add(enumeration.nextElement());
/*    */     }
/*    */     
/* 53 */     return arrayList.iterator();
/*    */   }
/*    */ 
/*    */   
/* 57 */   public void removeAttribute(String paramString) { this.request.getSession().removeAttribute(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 61 */   public void invalidate() { this.request.getSession().invalidate(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceHttpSessionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */