package weblogic.webservice.context;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import javax.servlet.http.HttpServletRequest;
import javax.xml.rpc.JAXRPCException;

public class WebServiceHttpSessionImpl implements WebServiceSession {
  private HttpServletRequest request;
  
  public WebServiceHttpSessionImpl(HttpServletRequest paramHttpServletRequest) { this.request = paramHttpServletRequest; }
  
  public Object getUnderlyingSession() throws JAXRPCException { return this.request.getSession(); }
  
  public Object getRequest() throws JAXRPCException { return this.request; }
  
  public Object getAttribute(String paramString) { return this.request.getSession().getAttribute(paramString); }
  
  public void setAttribute(String paramString, Object paramObject) { this.request.getSession().setAttribute(paramString, paramObject); }
  
  public Iterator getAttributeNames() {
    Enumeration enumeration = this.request.getSession().getAttributeNames();
    ArrayList arrayList = new ArrayList();
    while (enumeration.hasMoreElements())
      arrayList.add(enumeration.nextElement()); 
    return arrayList.iterator();
  }
  
  public void removeAttribute(String paramString) { this.request.getSession().removeAttribute(paramString); }
  
  public void invalidate() { this.request.getSession().invalidate(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceHttpSessionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */