/*    */ package weblogic.webservice.context;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServiceSessionImpl
/*    */   implements WebServiceSession
/*    */ {
/* 19 */   private HashMap attributes = new HashMap();
/*    */ 
/*    */   
/* 22 */   public Object getUnderlyingSession() throws JAXRPCException { return this; }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public Object getRequest() throws JAXRPCException { throw new JAXRPCException("This method is not implemented"); }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public Object getAttribute(String paramString) { return this.attributes.get(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 34 */   public void setAttribute(String paramString, Object paramObject) { this.attributes.put(paramString, paramObject); }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public Iterator getAttributeNames() { return this.attributes.keySet().iterator(); }
/*    */ 
/*    */ 
/*    */   
/* 42 */   public void removeAttribute(String paramString) { this.attributes.remove(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 46 */   public void invalidate() { this.attributes.clear(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceSessionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */