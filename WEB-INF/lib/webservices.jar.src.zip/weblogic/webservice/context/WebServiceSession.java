package weblogic.webservice.context;

import java.util.Iterator;
import javax.xml.rpc.JAXRPCException;

public interface WebServiceSession {
  Object getUnderlyingSession() throws JAXRPCException;
  
  Object getRequest() throws JAXRPCException;
  
  Object getAttribute(String paramString);
  
  void setAttribute(String paramString, Object paramObject);
  
  Iterator getAttributeNames();
  
  void removeAttribute(String paramString);
  
  void invalidate();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceSession.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */