package weblogic.webservice.context;

import java.util.HashMap;
import java.util.Iterator;
import javax.xml.namespace.QName;

public class WebServiceHeaderImpl implements WebServiceHeader {
  private HashMap headers = new HashMap();
  
  public void put(QName paramQName, Object paramObject) { this.headers.put(paramQName, paramObject); }
  
  public Object get(QName paramQName) { return this.headers.get(paramQName); }
  
  public Object remove(QName paramQName) { return this.headers.remove(paramQName); }
  
  public Iterator names() { return this.headers.keySet().iterator(); }
  
  public void clear() { this.headers.clear(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceHeaderImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */