/*    */ package weblogic.webservice.context;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServiceHeaderImpl
/*    */   implements WebServiceHeader
/*    */ {
/* 18 */   private HashMap headers = new HashMap();
/*    */ 
/*    */   
/* 21 */   public void put(QName paramQName, Object paramObject) { this.headers.put(paramQName, paramObject); }
/*    */ 
/*    */ 
/*    */   
/* 25 */   public Object get(QName paramQName) { return this.headers.get(paramQName); }
/*    */ 
/*    */ 
/*    */   
/* 29 */   public Object remove(QName paramQName) { return this.headers.remove(paramQName); }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public Iterator names() { return this.headers.keySet().iterator(); }
/*    */ 
/*    */ 
/*    */   
/* 37 */   public void clear() { this.headers.clear(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceHeaderImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */