package weblogic.webservice.context;

import java.util.Iterator;
import javax.xml.namespace.QName;

public interface WebServiceHeader {
  void put(QName paramQName, Object paramObject);
  
  Object get(QName paramQName);
  
  Object remove(QName paramQName);
  
  Iterator names();
  
  void clear();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceHeader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */