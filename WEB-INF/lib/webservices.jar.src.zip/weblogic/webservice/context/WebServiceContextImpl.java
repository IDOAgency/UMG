package weblogic.webservice.context;

import javax.xml.rpc.handler.soap.SOAPMessageContext;

public class WebServiceContextImpl extends WebServiceContext {
  private WebServiceHeader header;
  
  private WebServiceSession session;
  
  private SOAPMessageContext messageContext;
  
  public WebServiceHeader getHeader() {
    if (this.header == null)
      this.header = new WebServiceHeaderImpl(); 
    return this.header;
  }
  
  public WebServiceSession getSession() {
    if (this.session == null)
      this.session = new WebServiceSessionImpl(); 
    return this.session;
  }
  
  public void setSession(WebServiceSession paramWebServiceSession) {
    if (this.session != null)
      throw new IllegalStateException("session allready set"); 
    this.session = paramWebServiceSession;
  }
  
  public SOAPMessageContext getLastMessageContext() { return this.messageContext; }
  
  public void setLastMessageContext(SOAPMessageContext paramSOAPMessageContext) { this.messageContext = paramSOAPMessageContext; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceContextImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */