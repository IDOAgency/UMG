/*    */ package weblogic.webservice.context;
/*    */ 
/*    */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServiceContextImpl
/*    */   extends WebServiceContext
/*    */ {
/*    */   private WebServiceHeader header;
/*    */   private WebServiceSession session;
/*    */   private SOAPMessageContext messageContext;
/*    */   
/*    */   public WebServiceHeader getHeader() {
/* 23 */     if (this.header == null) {
/* 24 */       this.header = new WebServiceHeaderImpl();
/*    */     }
/*    */     
/* 27 */     return this.header;
/*    */   }
/*    */   
/*    */   public WebServiceSession getSession() {
/* 31 */     if (this.session == null) {
/* 32 */       this.session = new WebServiceSessionImpl();
/*    */     }
/*    */     
/* 35 */     return this.session;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setSession(WebServiceSession paramWebServiceSession) {
/* 40 */     if (this.session != null) {
/* 41 */       throw new IllegalStateException("session allready set");
/*    */     }
/*    */     
/* 44 */     this.session = paramWebServiceSession;
/*    */   }
/*    */ 
/*    */   
/* 48 */   public SOAPMessageContext getLastMessageContext() { return this.messageContext; }
/*    */ 
/*    */ 
/*    */   
/* 52 */   public void setLastMessageContext(SOAPMessageContext paramSOAPMessageContext) { this.messageContext = paramSOAPMessageContext; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceContextImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */