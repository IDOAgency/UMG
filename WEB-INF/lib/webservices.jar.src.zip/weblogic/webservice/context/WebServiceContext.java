package weblogic.webservice.context;

import java.util.HashMap;
import javax.xml.rpc.handler.soap.SOAPMessageContext;

public abstract class WebServiceContext {
  private static HashMap contexts = new HashMap();
  
  public static WebServiceContext currentContext() throws ContextNotFoundException {
    WebServiceContext webServiceContext = (WebServiceContext)contexts.get(Thread.currentThread());
    if (webServiceContext == null)
      throw new ContextNotFoundException("unable to find context for current thread"); 
    return webServiceContext;
  }
  
  public static void register(WebServiceContext paramWebServiceContext) {
    if (paramWebServiceContext == null) {
      contexts.remove(Thread.currentThread());
    } else {
      contexts.put(Thread.currentThread(), paramWebServiceContext);
    } 
  }
  
  public abstract WebServiceHeader getHeader();
  
  public abstract WebServiceSession getSession();
  
  public abstract SOAPMessageContext getLastMessageContext();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\context\WebServiceContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */