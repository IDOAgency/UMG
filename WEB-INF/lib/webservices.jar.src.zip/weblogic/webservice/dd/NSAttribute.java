package weblogic.webservice.dd;

import java.util.Map;
import weblogic.xml.stream.Attribute;
import weblogic.xml.stream.StartElement;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.stream.events.Name;

public class NSAttribute implements Attribute {
  private StartElement element;
  
  private Attribute attr;
  
  private Map namespaceMap;
  
  public NSAttribute(StartElement paramStartElement, Attribute paramAttribute) {
    this.attr = paramAttribute;
    this.namespaceMap = paramStartElement.getNamespaceMap();
    this.element = paramStartElement;
  }
  
  public XMLName getName() { return this.attr.getName(); }
  
  public String getType() { return this.attr.getType(); }
  
  public String getValue() { return this.attr.getValue(); }
  
  public XMLName getSchemaType() { return null; }
  
  public XMLName getValueAsXMLName() {
    String str1 = getValue();
    String str2 = null;
    String str3 = null;
    String str4 = null;
    int i = str1.indexOf(':');
    if (i < 0) {
      str3 = str1;
      str4 = this.element.getNamespaceUri("");
      if (str4 == null)
        return new Name(str3); 
      return new Name(str4, str3);
    } 
    str2 = str1.substring(0, i);
    str3 = str1.substring(i + 1);
    str4 = (String)this.namespaceMap.get(str2);
    if (str4 == null)
      throw new XMLStreamException("Attribute QName value \"" + str1 + "\" does not map to a prefix that is in scope"); 
    return new Name(str4, str3, str2);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\NSAttribute.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */