/*    */ package weblogic.webservice.dd;
/*    */ 
/*    */ import java.util.Map;
/*    */ import weblogic.xml.stream.Attribute;
/*    */ import weblogic.xml.stream.StartElement;
/*    */ import weblogic.xml.stream.XMLName;
/*    */ import weblogic.xml.stream.XMLStreamException;
/*    */ import weblogic.xml.stream.events.Name;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NSAttribute
/*    */   implements Attribute
/*    */ {
/*    */   private StartElement element;
/*    */   private Attribute attr;
/*    */   private Map namespaceMap;
/*    */   
/*    */   public NSAttribute(StartElement paramStartElement, Attribute paramAttribute) {
/* 29 */     this.attr = paramAttribute;
/* 30 */     this.namespaceMap = paramStartElement.getNamespaceMap();
/* 31 */     this.element = paramStartElement;
/*    */   }
/*    */   
/* 34 */   public XMLName getName() { return this.attr.getName(); }
/* 35 */   public String getType() { return this.attr.getType(); }
/* 36 */   public String getValue() { return this.attr.getValue(); }
/* 37 */   public XMLName getSchemaType() { return null; }
/*    */   public XMLName getValueAsXMLName() {
/* 39 */     String str1 = getValue();
/* 40 */     String str2 = null;
/* 41 */     String str3 = null;
/* 42 */     String str4 = null;
/* 43 */     int i = str1.indexOf(':');
/*    */     
/* 45 */     if (i < 0) {
/* 46 */       str3 = str1;
/* 47 */       str4 = this.element.getNamespaceUri("");
/* 48 */       if (str4 == null) {
/* 49 */         return new Name(str3);
/*    */       }
/* 51 */       return new Name(str4, str3);
/*    */     } 
/*    */ 
/*    */     
/* 55 */     str2 = str1.substring(0, i);
/* 56 */     str3 = str1.substring(i + 1);
/* 57 */     str4 = (String)this.namespaceMap.get(str2);
/* 58 */     if (str4 == null) {
/* 59 */       throw new XMLStreamException("Attribute QName value \"" + str1 + "\" does not map to a prefix that is in scope");
/*    */     }
/*    */ 
/*    */     
/* 63 */     return new Name(str4, str3, str2);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\NSAttribute.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */