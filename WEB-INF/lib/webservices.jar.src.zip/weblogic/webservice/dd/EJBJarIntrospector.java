/*     */ package weblogic.webservice.dd;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import weblogic.ejb.spi.EjbDescriptorBean;
/*     */ import weblogic.ejb20.dd.xml.DDUtils;
/*     */ import weblogic.j2ee.descriptor.EjbJarBean;
/*     */ import weblogic.j2ee.descriptor.EnterpriseBeansBean;
/*     */ import weblogic.j2ee.descriptor.SessionBeanBean;
/*     */ import weblogic.j2ee.descriptor.wl.WeblogicEjbJarBean;
/*     */ import weblogic.j2ee.descriptor.wl.WeblogicEnterpriseBeanBean;
/*     */ import weblogic.utils.jars.VirtualJarFile;
/*     */ import weblogic.xml.process.XMLParsingException;
/*     */ import weblogic.xml.process.XMLProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EJBJarIntrospector
/*     */ {
/*     */   private static boolean debug = false;
/*     */   private EjbDescriptorBean dd;
/*  39 */   private Set excludes = new HashSet();
/*  40 */   private Set includes = new HashSet();
/*     */ 
/*     */   
/*     */   private boolean mapped = false;
/*     */   
/*     */   private Map ejbNameMap;
/*     */   
/*     */   private Map jndiNameMap;
/*     */ 
/*     */   
/*     */   public EJBJarIntrospector(VirtualJarFile paramVirtualJarFile) throws IOException, EJBProcessingException {
/*     */     try {
/*  52 */       this.dd = DDUtils.createDescriptorFromJarFile(paramVirtualJarFile);
/*  53 */       map();
/*  54 */     } catch (XMLParsingException xMLParsingException) {
/*  55 */       throw new EJBProcessingException("Can not parse ejb DD files.", xMLParsingException);
/*  56 */     } catch (XMLProcessingException xMLProcessingException) {
/*  57 */       throw new EJBProcessingException("Can read in ejb DD files.", xMLProcessingException);
/*  58 */     } catch (XMLStreamException xMLStreamException) {
/*  59 */       throw new EJBProcessingException("Can not parse  ejb DD files.", xMLStreamException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EJBJarIntrospector(VirtualJarFile paramVirtualJarFile, String[] paramArrayOfString1, String[] paramArrayOfString2) throws IOException, EJBProcessingException {
/*  73 */     this(paramVirtualJarFile);
/*  74 */     this.excludes = new HashSet(Arrays.asList((Object[])paramArrayOfString1));
/*  75 */     this.includes = new HashSet(Arrays.asList((Object[])paramArrayOfString2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public EJBIntrospector getEJBByEJBName(String paramString) { return (EJBIntrospector)this.ejbNameMap.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  87 */   public EJBIntrospector getEJBByJNDIName(String paramString) { return (EJBIntrospector)this.jndiNameMap.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  91 */   public Collection getEJBs() { return this.ejbNameMap.values(); }
/*     */ 
/*     */   
/*     */   private void map() throws EJBProcessingException {
/*  95 */     this.ejbNameMap = new HashMap();
/*  96 */     this.jndiNameMap = new HashMap();
/*     */     
/*  98 */     EjbJarBean ejbJarBean = this.dd.getEjbJarBean();
/*  99 */     if (ejbJarBean == null) {
/* 100 */       throw new EJBProcessingException("No ejb-jar found in the ejb jar DD");
/*     */     }
/* 102 */     EnterpriseBeansBean enterpriseBeansBean = ejbJarBean.getEnterpriseBeans();
/* 103 */     if (enterpriseBeansBean == null) {
/* 104 */       throw new EJBProcessingException("No enterprise-beans found in the ejb jar DD");
/*     */     }
/* 106 */     SessionBeanBean[] arrayOfSessionBeanBean = enterpriseBeansBean.getSessions();
/* 107 */     if (arrayOfSessionBeanBean != null) {
/* 108 */       for (byte b = 0; b < arrayOfSessionBeanBean.length; b++) {
/* 109 */         if ("stateless".equalsIgnoreCase(arrayOfSessionBeanBean[b].getSessionType()) && isIncluded(arrayOfSessionBeanBean[b].getEjbName())) {
/*     */ 
/*     */ 
/*     */           
/* 113 */           if (debug) System.out.println("Matched " + arrayOfSessionBeanBean[b].getEjbName()); 
/* 114 */           WeblogicEnterpriseBeanBean weblogicEnterpriseBeanBean = getWLBean(arrayOfSessionBeanBean[b].getEjbName());
/* 115 */           EJBIntrospector eJBIntrospector = new EJBIntrospector(arrayOfSessionBeanBean[b], weblogicEnterpriseBeanBean);
/* 116 */           this.ejbNameMap.put(eJBIntrospector.getEJBName(), eJBIntrospector);
/* 117 */           this.jndiNameMap.put(eJBIntrospector.getJNDIName(), eJBIntrospector);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isIncluded(String paramString) {
/* 127 */     if (this.includes.size() > 0) {
/* 128 */       return (this.includes.contains(paramString) && !this.excludes.contains(paramString));
/*     */     }
/* 130 */     return !this.excludes.contains(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   private WeblogicEnterpriseBeanBean getWLBean(String paramString) {
/* 135 */     WeblogicEnterpriseBeanBean weblogicEnterpriseBeanBean = null;
/* 136 */     WeblogicEjbJarBean weblogicEjbJarBean = this.dd.getWeblogicEjbJarBean();
/* 137 */     if (weblogicEjbJarBean != null) {
/* 138 */       WeblogicEnterpriseBeanBean[] arrayOfWeblogicEnterpriseBeanBean = weblogicEjbJarBean.getWeblogicEnterpriseBeans();
/* 139 */       if (arrayOfWeblogicEnterpriseBeanBean != null) {
/* 140 */         for (byte b = 0; b < arrayOfWeblogicEnterpriseBeanBean.length; b++) {
/* 141 */           if (paramString.equals(arrayOfWeblogicEnterpriseBeanBean[b].getEjbName())) {
/* 142 */             weblogicEnterpriseBeanBean = arrayOfWeblogicEnterpriseBeanBean[b];
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 148 */     return weblogicEnterpriseBeanBean;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\EJBJarIntrospector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */