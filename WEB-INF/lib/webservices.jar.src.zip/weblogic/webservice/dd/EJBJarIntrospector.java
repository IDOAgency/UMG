package weblogic.webservice.dd;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.xml.stream.XMLStreamException;
import weblogic.ejb.spi.EjbDescriptorBean;
import weblogic.ejb20.dd.xml.DDUtils;
import weblogic.j2ee.descriptor.EjbJarBean;
import weblogic.j2ee.descriptor.EnterpriseBeansBean;
import weblogic.j2ee.descriptor.SessionBeanBean;
import weblogic.j2ee.descriptor.wl.WeblogicEjbJarBean;
import weblogic.j2ee.descriptor.wl.WeblogicEnterpriseBeanBean;
import weblogic.utils.jars.VirtualJarFile;
import weblogic.xml.process.XMLParsingException;
import weblogic.xml.process.XMLProcessingException;

public class EJBJarIntrospector {
  private static boolean debug = false;
  
  private EjbDescriptorBean dd;
  
  private Set excludes = new HashSet();
  
  private Set includes = new HashSet();
  
  private boolean mapped = false;
  
  private Map ejbNameMap;
  
  private Map jndiNameMap;
  
  public EJBJarIntrospector(VirtualJarFile paramVirtualJarFile) throws IOException, EJBProcessingException {
    try {
      this.dd = DDUtils.createDescriptorFromJarFile(paramVirtualJarFile);
      map();
    } catch (XMLParsingException xMLParsingException) {
      throw new EJBProcessingException("Can not parse ejb DD files.", xMLParsingException);
    } catch (XMLProcessingException xMLProcessingException) {
      throw new EJBProcessingException("Can read in ejb DD files.", xMLProcessingException);
    } catch (XMLStreamException xMLStreamException) {
      throw new EJBProcessingException("Can not parse  ejb DD files.", xMLStreamException);
    } 
  }
  
  public EJBJarIntrospector(VirtualJarFile paramVirtualJarFile, String[] paramArrayOfString1, String[] paramArrayOfString2) throws IOException, EJBProcessingException {
    this(paramVirtualJarFile);
    this.excludes = new HashSet(Arrays.asList((Object[])paramArrayOfString1));
    this.includes = new HashSet(Arrays.asList((Object[])paramArrayOfString2));
  }
  
  public EJBIntrospector getEJBByEJBName(String paramString) { return (EJBIntrospector)this.ejbNameMap.get(paramString); }
  
  public EJBIntrospector getEJBByJNDIName(String paramString) { return (EJBIntrospector)this.jndiNameMap.get(paramString); }
  
  public Collection getEJBs() { return this.ejbNameMap.values(); }
  
  private void map() throws EJBProcessingException {
    this.ejbNameMap = new HashMap();
    this.jndiNameMap = new HashMap();
    EjbJarBean ejbJarBean = this.dd.getEjbJarBean();
    if (ejbJarBean == null)
      throw new EJBProcessingException("No ejb-jar found in the ejb jar DD"); 
    EnterpriseBeansBean enterpriseBeansBean = ejbJarBean.getEnterpriseBeans();
    if (enterpriseBeansBean == null)
      throw new EJBProcessingException("No enterprise-beans found in the ejb jar DD"); 
    SessionBeanBean[] arrayOfSessionBeanBean = enterpriseBeansBean.getSessions();
    if (arrayOfSessionBeanBean != null)
      for (byte b = 0; b < arrayOfSessionBeanBean.length; b++) {
        if ("stateless".equalsIgnoreCase(arrayOfSessionBeanBean[b].getSessionType()) && isIncluded(arrayOfSessionBeanBean[b].getEjbName())) {
          if (debug)
            System.out.println("Matched " + arrayOfSessionBeanBean[b].getEjbName()); 
          WeblogicEnterpriseBeanBean weblogicEnterpriseBeanBean = getWLBean(arrayOfSessionBeanBean[b].getEjbName());
          EJBIntrospector eJBIntrospector = new EJBIntrospector(arrayOfSessionBeanBean[b], weblogicEnterpriseBeanBean);
          this.ejbNameMap.put(eJBIntrospector.getEJBName(), eJBIntrospector);
          this.jndiNameMap.put(eJBIntrospector.getJNDIName(), eJBIntrospector);
        } 
      }  
  }
  
  private boolean isIncluded(String paramString) {
    if (this.includes.size() > 0)
      return (this.includes.contains(paramString) && !this.excludes.contains(paramString)); 
    return !this.excludes.contains(paramString);
  }
  
  private WeblogicEnterpriseBeanBean getWLBean(String paramString) {
    WeblogicEnterpriseBeanBean weblogicEnterpriseBeanBean = null;
    WeblogicEjbJarBean weblogicEjbJarBean = this.dd.getWeblogicEjbJarBean();
    if (weblogicEjbJarBean != null) {
      WeblogicEnterpriseBeanBean[] arrayOfWeblogicEnterpriseBeanBean = weblogicEjbJarBean.getWeblogicEnterpriseBeans();
      if (arrayOfWeblogicEnterpriseBeanBean != null)
        for (byte b = 0; b < arrayOfWeblogicEnterpriseBeanBean.length; b++) {
          if (paramString.equals(arrayOfWeblogicEnterpriseBeanBean[b].getEjbName())) {
            weblogicEnterpriseBeanBean = arrayOfWeblogicEnterpriseBeanBean[b];
            break;
          } 
        }  
    } 
    return weblogicEnterpriseBeanBean;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\EJBJarIntrospector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */