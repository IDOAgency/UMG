/*     */ package weblogic.webservice.dd;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import weblogic.xml.stream.Attribute;
/*     */ import weblogic.xml.stream.AttributeIterator;
/*     */ import weblogic.xml.stream.Location;
/*     */ import weblogic.xml.stream.StartElement;
/*     */ import weblogic.xml.stream.XMLEvent;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.stream.util.TypeFilter;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ import weblogic.xml.xmlnode.XMLNodeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParsingHelper
/*     */ {
/*     */   private XMLInputStream stream;
/*     */   private static final boolean debug = false;
/*     */   private static final String DD_NS = "http://www.bea.com/servers/wls70";
/*     */   
/*     */   public ParsingHelper(InputStream paramInputStream) throws XMLStreamException {
/*  49 */     TypeFilter typeFilter = new TypeFilter(22);
/*     */ 
/*     */     
/*  52 */     this.stream = XMLInputStreamFactory.newInstance().newInputStream(paramInputStream, typeFilter);
/*  53 */     this.stream.skip(2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParsingHelper(XMLInputStream paramXMLInputStream) throws XMLStreamException {
/*  60 */     this.stream = paramXMLInputStream;
/*  61 */     this.stream.skip(2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent peekStartElement(String paramString) throws XMLStreamException, DDProcessingException {
/*  74 */     XMLEvent xMLEvent = this.stream.peek();
/*  75 */     if (xMLEvent.getType() == 2 && xMLEvent.getName().getLocalName().equals(paramString))
/*     */     {
/*  77 */       return xMLEvent;
/*     */     }
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent peekStartElement() throws XMLStreamException, DDProcessingException {
/*  91 */     XMLEvent xMLEvent = this.stream.peek();
/*  92 */     if (xMLEvent.getType() == 2) {
/*  93 */       return xMLEvent;
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent matchStartElement(String paramString) throws XMLStreamException, DDProcessingException {
/* 109 */     XMLEvent xMLEvent = this.stream.peek();
/* 110 */     if (xMLEvent.getType() != 2)
/*     */     {
/* 112 */       throw new DDProcessingException("Expected start element <" + paramString + ">, but got " + xMLEvent.getTypeAsString() + " instead", xMLEvent.getLocation());
/*     */     }
/* 114 */     String str = xMLEvent.getName().getLocalName();
/* 115 */     if (!paramString.equals(str)) {
/* 116 */       throw new DDProcessingException("Expected element <" + paramString + ">, but got <" + str + "> instead", xMLEvent.getLocation());
/*     */     }
/*     */     
/* 119 */     return this.stream.next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent matchStartElement(String[] paramArrayOfString) throws XMLStreamException, DDProcessingException {
/* 133 */     XMLEvent xMLEvent = matchOptionalStartElement(paramArrayOfString);
/* 134 */     if (xMLEvent == null) {
/* 135 */       StringBuffer stringBuffer = new StringBuffer("Expected a start element matching any of ");
/*     */       
/* 137 */       for (byte b = 0; b < paramArrayOfString.length - 1; b++) {
/* 138 */         stringBuffer.append("<").append(paramArrayOfString[b]).append(">,");
/*     */       }
/* 140 */       stringBuffer.append(" or <").append(paramArrayOfString[paramArrayOfString.length - 1]).append(">");
/* 141 */       stringBuffer.append(" but got ");
/* 142 */       stringBuffer.append(this.stream.peek().toString());
/* 143 */       stringBuffer.append(" instead");
/* 144 */       throw new DDProcessingException(stringBuffer.toString(), this.stream.peek().getLocation());
/*     */     } 
/*     */ 
/*     */     
/* 148 */     return xMLEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent matchOptionalStartElement(String[] paramArrayOfString) throws XMLStreamException, DDProcessingException {
/* 163 */     XMLEvent xMLEvent = null;
/* 164 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 165 */       xMLEvent = matchOptionalStartElement(paramArrayOfString[b]);
/* 166 */       if (xMLEvent != null) {
/*     */         break;
/*     */       }
/*     */     } 
/* 170 */     return xMLEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent matchOptionalStartElement(String paramString) throws XMLStreamException, DDProcessingException {
/* 182 */     XMLEvent xMLEvent = this.stream.peek();
/* 183 */     if (xMLEvent.getType() == 2 && xMLEvent.getName().getLocalName().equals(paramString))
/*     */     {
/*     */       
/* 186 */       return this.stream.next();
/*     */     }
/* 188 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent matchEndElement(String paramString) throws XMLStreamException, DDProcessingException {
/* 202 */     XMLEvent xMLEvent = this.stream.peek();
/* 203 */     if (xMLEvent.getType() != 4) {
/* 204 */       StringBuffer stringBuffer = new StringBuffer();
/* 205 */       stringBuffer.append("Expected end element </" + paramString + ">, but got ");
/* 206 */       stringBuffer.append(xMLEvent.getTypeAsString());
/* 207 */       if (xMLEvent.getName() != null) {
/* 208 */         stringBuffer.append("(" + xMLEvent.getName().getQualifiedName() + ")");
/*     */       }
/* 210 */       stringBuffer.append(" instead.");
/*     */       
/* 212 */       throw new DDProcessingException(stringBuffer.toString(), xMLEvent.getLocation());
/*     */     } 
/*     */     
/* 215 */     return this.stream.next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLEvent matchDocumentEnd() throws XMLStreamException, DDProcessingException {
/* 223 */     XMLEvent xMLEvent = this.stream.peek();
/* 224 */     if (xMLEvent.getType() != 512 && xMLEvent.getType() != 128) {
/* 225 */       throw new DDProcessingException("Expected end of document, but got " + xMLEvent.getTypeAsString() + " instead", xMLEvent.getLocation());
/*     */     }
/* 227 */     return this.stream.next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getLocation() throws XMLStreamException {
/* 235 */     XMLEvent xMLEvent = this.stream.peek();
/* 236 */     if (xMLEvent == null) return null; 
/* 237 */     return xMLEvent.getLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLNode forkSubtree() throws XMLStreamException {
/* 244 */     XMLNode xMLNode = new XMLNode();
/* 245 */     XMLInputStream xMLInputStream = this.stream.getSubStream();
/* 246 */     this.stream.skipElement();
/*     */     
/*     */     try {
/* 249 */       xMLNode.read(xMLInputStream);
/* 250 */       return xMLNode;
/* 251 */     } catch (IOException iOException) {
/* 252 */       throw new XMLStreamException(iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLNodeSet forkSubtrees() throws XMLStreamException {
/* 265 */     XMLNodeSet xMLNodeSet = new XMLNodeSet();
/* 266 */     XMLEvent xMLEvent1 = this.stream.peek();
/* 267 */     if (xMLEvent1.getType() != 2) {
/* 268 */       throw new XMLStreamException("Expected a start element");
/*     */     }
/*     */     
/* 271 */     XMLEvent xMLEvent2 = xMLEvent1;
/* 272 */     while (xMLEvent2.getName().equals(xMLEvent1.getName())) {
/*     */ 
/*     */       
/* 275 */       try { XMLNode xMLNode = new XMLNode();
/* 276 */         xMLNode.read(this.stream);
/* 277 */         xMLNodeSet.addXMLNode(xMLNode); }
/* 278 */       catch (IOException iOException) { throw new XMLStreamException(iOException); }
/* 279 */        xMLEvent2 = this.stream.peek();
/* 280 */       if (xMLEvent2.getName() == null)
/*     */         break; 
/* 282 */     }  return xMLNodeSet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NSAttribute getRequiredAttribute(StartElement paramStartElement, String paramString) throws XMLStreamException, DDProcessingException {
/* 288 */     Attribute attribute = paramStartElement.getAttributeByName(new Name(paramString));
/* 289 */     if (attribute == null) {
/* 290 */       throw new DDProcessingException("Could not find required attribute \"" + paramString + "\" for element <" + paramStartElement.getName().getLocalName() + ">", paramStartElement.getLocation());
/*     */     }
/*     */     
/* 293 */     return new NSAttribute(paramStartElement, attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static NSAttribute getOptionalAttribute(StartElement paramStartElement, String paramString) throws XMLStreamException, DDProcessingException {
/* 299 */     Attribute attribute = paramStartElement.getAttributeByName(new Name(paramString));
/* 300 */     if (attribute == null) return null; 
/* 301 */     return new NSAttribute(paramStartElement, attribute);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkAttributes(StartElement paramStartElement, String[] paramArrayOfString) throws DDProcessingException {
/* 312 */     HashSet hashSet = new HashSet(Arrays.asList((Object[])paramArrayOfString));
/* 313 */     AttributeIterator attributeIterator = paramStartElement.getAttributes();
/* 314 */     while (attributeIterator.hasNext()) {
/* 315 */       XMLName xMLName = attributeIterator.next().getName();
/* 316 */       if ((xMLName.getNamespaceUri() == null || xMLName.getNamespaceUri().equals("http://www.bea.com/servers/wls70")) && !hashSet.contains(xMLName.getLocalName()))
/*     */       {
/*     */ 
/*     */         
/* 320 */         throw new DDProcessingException("Unrecognized attribute " + xMLName.getLocalName(), paramStartElement.getLocation());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void dumpEvents(XMLInputStream paramXMLInputStream) throws XMLStreamException {
/* 326 */     while (paramXMLInputStream.hasNext()) {
/* 327 */       XMLEvent xMLEvent = paramXMLInputStream.next();
/* 328 */       System.out.print("EVENT: " + xMLEvent.getTypeAsString() + " [");
/* 329 */       System.out.print(xMLEvent);
/* 330 */       System.out.println("]");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\ParsingHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */