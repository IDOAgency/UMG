package weblogic.webservice.dd;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashSet;
import weblogic.xml.stream.Attribute;
import weblogic.xml.stream.AttributeIterator;
import weblogic.xml.stream.Location;
import weblogic.xml.stream.StartElement;
import weblogic.xml.stream.XMLEvent;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.stream.events.Name;
import weblogic.xml.stream.util.TypeFilter;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeSet;

public class ParsingHelper {
  private XMLInputStream stream;
  
  private static final boolean debug = false;
  
  private static final String DD_NS = "http://www.bea.com/servers/wls70";
  
  public ParsingHelper(InputStream paramInputStream) throws XMLStreamException {
    TypeFilter typeFilter = new TypeFilter(22);
    this.stream = XMLInputStreamFactory.newInstance().newInputStream(paramInputStream, typeFilter);
    this.stream.skip(2);
  }
  
  public ParsingHelper(XMLInputStream paramXMLInputStream) throws XMLStreamException {
    this.stream = paramXMLInputStream;
    this.stream.skip(2);
  }
  
  public XMLEvent peekStartElement(String paramString) throws XMLStreamException, DDProcessingException {
    XMLEvent xMLEvent = this.stream.peek();
    if (xMLEvent.getType() == 2 && xMLEvent.getName().getLocalName().equals(paramString))
      return xMLEvent; 
    return null;
  }
  
  public XMLEvent peekStartElement() throws XMLStreamException, DDProcessingException {
    XMLEvent xMLEvent = this.stream.peek();
    if (xMLEvent.getType() == 2)
      return xMLEvent; 
    return null;
  }
  
  public XMLEvent matchStartElement(String paramString) throws XMLStreamException, DDProcessingException {
    XMLEvent xMLEvent = this.stream.peek();
    if (xMLEvent.getType() != 2)
      throw new DDProcessingException("Expected start element <" + paramString + ">, but got " + xMLEvent.getTypeAsString() + " instead", xMLEvent.getLocation()); 
    String str = xMLEvent.getName().getLocalName();
    if (!paramString.equals(str))
      throw new DDProcessingException("Expected element <" + paramString + ">, but got <" + str + "> instead", xMLEvent.getLocation()); 
    return this.stream.next();
  }
  
  public XMLEvent matchStartElement(String[] paramArrayOfString) throws XMLStreamException, DDProcessingException {
    XMLEvent xMLEvent = matchOptionalStartElement(paramArrayOfString);
    if (xMLEvent == null) {
      StringBuffer stringBuffer = new StringBuffer("Expected a start element matching any of ");
      for (byte b = 0; b < paramArrayOfString.length - 1; b++)
        stringBuffer.append("<").append(paramArrayOfString[b]).append(">,"); 
      stringBuffer.append(" or <").append(paramArrayOfString[paramArrayOfString.length - 1]).append(">");
      stringBuffer.append(" but got ");
      stringBuffer.append(this.stream.peek().toString());
      stringBuffer.append(" instead");
      throw new DDProcessingException(stringBuffer.toString(), this.stream.peek().getLocation());
    } 
    return xMLEvent;
  }
  
  public XMLEvent matchOptionalStartElement(String[] paramArrayOfString) throws XMLStreamException, DDProcessingException {
    XMLEvent xMLEvent = null;
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      xMLEvent = matchOptionalStartElement(paramArrayOfString[b]);
      if (xMLEvent != null)
        break; 
    } 
    return xMLEvent;
  }
  
  public XMLEvent matchOptionalStartElement(String paramString) throws XMLStreamException, DDProcessingException {
    XMLEvent xMLEvent = this.stream.peek();
    if (xMLEvent.getType() == 2 && xMLEvent.getName().getLocalName().equals(paramString))
      return this.stream.next(); 
    return null;
  }
  
  public XMLEvent matchEndElement(String paramString) throws XMLStreamException, DDProcessingException {
    XMLEvent xMLEvent = this.stream.peek();
    if (xMLEvent.getType() != 4) {
      StringBuffer stringBuffer = new StringBuffer();
      stringBuffer.append("Expected end element </" + paramString + ">, but got ");
      stringBuffer.append(xMLEvent.getTypeAsString());
      if (xMLEvent.getName() != null)
        stringBuffer.append("(" + xMLEvent.getName().getQualifiedName() + ")"); 
      stringBuffer.append(" instead.");
      throw new DDProcessingException(stringBuffer.toString(), xMLEvent.getLocation());
    } 
    return this.stream.next();
  }
  
  public XMLEvent matchDocumentEnd() throws XMLStreamException, DDProcessingException {
    XMLEvent xMLEvent = this.stream.peek();
    if (xMLEvent.getType() != 512 && xMLEvent.getType() != 128)
      throw new DDProcessingException("Expected end of document, but got " + xMLEvent.getTypeAsString() + " instead", xMLEvent.getLocation()); 
    return this.stream.next();
  }
  
  public Location getLocation() throws XMLStreamException {
    XMLEvent xMLEvent = this.stream.peek();
    if (xMLEvent == null)
      return null; 
    return xMLEvent.getLocation();
  }
  
  public XMLNode forkSubtree() throws XMLStreamException {
    XMLNode xMLNode = new XMLNode();
    XMLInputStream xMLInputStream = this.stream.getSubStream();
    this.stream.skipElement();
    try {
      xMLNode.read(xMLInputStream);
      return xMLNode;
    } catch (IOException iOException) {
      throw new XMLStreamException(iOException);
    } 
  }
  
  public XMLNodeSet forkSubtrees() throws XMLStreamException {
    XMLNodeSet xMLNodeSet = new XMLNodeSet();
    XMLEvent xMLEvent1 = this.stream.peek();
    if (xMLEvent1.getType() != 2)
      throw new XMLStreamException("Expected a start element"); 
    XMLEvent xMLEvent2 = xMLEvent1;
    while (xMLEvent2.getName().equals(xMLEvent1.getName())) {
      try {
        XMLNode xMLNode = new XMLNode();
        xMLNode.read(this.stream);
        xMLNodeSet.addXMLNode(xMLNode);
      } catch (IOException iOException) {
        throw new XMLStreamException(iOException);
      } 
      xMLEvent2 = this.stream.peek();
      if (xMLEvent2.getName() == null)
        break; 
    } 
    return xMLNodeSet;
  }
  
  public static NSAttribute getRequiredAttribute(StartElement paramStartElement, String paramString) throws XMLStreamException, DDProcessingException {
    Attribute attribute = paramStartElement.getAttributeByName(new Name(paramString));
    if (attribute == null)
      throw new DDProcessingException("Could not find required attribute \"" + paramString + "\" for element <" + paramStartElement.getName().getLocalName() + ">", paramStartElement.getLocation()); 
    return new NSAttribute(paramStartElement, attribute);
  }
  
  public static NSAttribute getOptionalAttribute(StartElement paramStartElement, String paramString) throws XMLStreamException, DDProcessingException {
    Attribute attribute = paramStartElement.getAttributeByName(new Name(paramString));
    if (attribute == null)
      return null; 
    return new NSAttribute(paramStartElement, attribute);
  }
  
  public static void checkAttributes(StartElement paramStartElement, String[] paramArrayOfString) throws DDProcessingException {
    HashSet hashSet = new HashSet(Arrays.asList((Object[])paramArrayOfString));
    AttributeIterator attributeIterator = paramStartElement.getAttributes();
    while (attributeIterator.hasNext()) {
      XMLName xMLName = attributeIterator.next().getName();
      if ((xMLName.getNamespaceUri() == null || xMLName.getNamespaceUri().equals("http://www.bea.com/servers/wls70")) && !hashSet.contains(xMLName.getLocalName()))
        throw new DDProcessingException("Unrecognized attribute " + xMLName.getLocalName(), paramStartElement.getLocation()); 
    } 
  }
  
  private static void dumpEvents(XMLInputStream paramXMLInputStream) throws XMLStreamException {
    while (paramXMLInputStream.hasNext()) {
      XMLEvent xMLEvent = paramXMLInputStream.next();
      System.out.print("EVENT: " + xMLEvent.getTypeAsString() + " [");
      System.out.print(xMLEvent);
      System.out.println("]");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\ParsingHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */