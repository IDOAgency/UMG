package weblogic.webservice.dd;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import weblogic.management.descriptors.webservice.ComponentsMBean;
import weblogic.management.descriptors.webservice.JMSReceiveQueueMBean;
import weblogic.management.descriptors.webservice.JMSReceiveTopicMBean;
import weblogic.management.descriptors.webservice.JMSSendDestinationMBean;
import weblogic.management.descriptors.webservice.JavaClassMBean;
import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.OperationsMBean;
import weblogic.management.descriptors.webservice.StatelessEJBMBean;
import weblogic.management.descriptors.webservice.TypeMappingEntryMBean;
import weblogic.management.descriptors.webservice.TypeMappingMBean;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
import weblogic.xml.schema.model.XSDException;
import weblogic.xml.schema.model.util.MergeSchemas;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeOutputStream;
import weblogic.xml.xmlnode.XMLNodeSet;

public final class DDMerger {
  private static final boolean debug = (System.getProperty(DEBUG_PROPERTY()) != null);
  
  private static final boolean overwrite = false;
  
  private static final int DIFFERENT = 0;
  
  private static final int CONFLICTING = 1;
  
  private static final int EQUAL = 2;
  
  private static String DEBUG_PROPERTY() { return "ddmerger.debug"; }
  
  public static String DEFAULT_SERVICE_NAME() { return "myWebService"; }
  
  public static String DEFAULT_PROTOCOL() { return "http"; }
  
  public static String DEFAULT_TARGET_NAMESPACE() { return "http://example.com/services/MyWebService"; }
  
  public static String DEFAULT_SERVICE_URI() { return "mywebservice"; }
  
  public static String DEFAULT_EJB_COMPONENT_NAME() { return "myEJBComponent"; }
  
  public static String DEFAULT_JAVA_CLASS_COMPONENT_NAME() { return "myJavaClassComponent"; }
  
  public static String DEFAULT_EJB_JAR_NAME() { return "myejbs.jar"; }
  
  public static String DEFAULT_EJB_NAME() { return "myEJB"; }
  
  public static String DEFAULT_JAVA_CLASS_NAME() { return "com.example.services.MyWebService"; }
  
  public static WebServicesMBean mergeWebServices(WebServicesMBean paramWebServicesMBean, WebServiceMBean[] paramArrayOfWebServiceMBean) throws DDProcessingException {
    Map map = createWebServicesMap(paramArrayOfWebServiceMBean);
    WebServiceMBean[] arrayOfWebServiceMBean = paramWebServicesMBean.getWebServices();
    if (arrayOfWebServiceMBean != null)
      for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
        String str = arrayOfWebServiceMBean[b].getWebServiceName();
        WebServiceMBean webServiceMBean = (WebServiceMBean)map.get(str);
        if (webServiceMBean != null) {
          paramWebServicesMBean.removeWebService(arrayOfWebServiceMBean[b]);
          arrayOfWebServiceMBean[b] = mergeWebService(webServiceMBean, arrayOfWebServiceMBean[b]);
          paramWebServicesMBean.addWebService(arrayOfWebServiceMBean[b]);
          map.remove(str);
        } 
      }  
    Iterator iterator = map.values().iterator();
    while (iterator.hasNext())
      paramWebServicesMBean.addWebService((WebServiceMBean)iterator.next()); 
    return paramWebServicesMBean;
  }
  
  public static WebServiceMBean mergeWebService(WebServiceMBean paramWebServiceMBean1, WebServiceMBean paramWebServiceMBean2) throws DDProcessingException {
    if (debug) {
      System.out.println("MERGING:");
      System.out.println("src:\n" + ((WebServiceMBeanImpl)paramWebServiceMBean1).toXML(0));
      System.out.println("dest:\n" + ((WebServiceMBeanImpl)paramWebServiceMBean2).toXML(0));
    } 
    String str1 = paramWebServiceMBean1.getURI();
    String str2 = paramWebServiceMBean2.getURI();
    if (!str1.startsWith("/"))
      str1 = "/" + str1; 
    if (!str2.startsWith("/"))
      str2 = "/" + str2; 
    if (!str1.equals(str2))
      throw new DDProcessingException("Trying to merge two webservices with the same servicename \"" + paramWebServiceMBean1.getWebServiceName() + "\" but different uri."); 
    if (paramWebServiceMBean1.getProtocol() != null && paramWebServiceMBean2.getProtocol() != null && 
      !paramWebServiceMBean1.getProtocol().equals(paramWebServiceMBean2.getProtocol()))
      throw new DDProcessingException("Trying to merge two webservices with the same servicename \"" + paramWebServiceMBean1.getWebServiceName() + "\" but different protocols."); 
    paramWebServiceMBean2.setTypes(mergeSchemas(paramWebServiceMBean1.getTypes(), paramWebServiceMBean2.getTypes()));
    paramWebServiceMBean2.setTypeMapping(mergeTypeMapping(paramWebServiceMBean1.getTypeMapping(), paramWebServiceMBean2.getTypeMapping()));
    ComponentsMBean componentsMBean1 = paramWebServiceMBean1.getComponents();
    ComponentsMBean componentsMBean2 = paramWebServiceMBean2.getComponents();
    componentsMBean2.setStatelessEJBs(mergeStatelessEJBs(componentsMBean1.getStatelessEJBs(), componentsMBean2.getStatelessEJBs()));
    componentsMBean2.setJavaClassComponents(mergeJavaClassComponents(componentsMBean1.getJavaClassComponents(), componentsMBean2.getJavaClassComponents()));
    componentsMBean2.setJMSSendDestinations(mergeJMSSendDestination(componentsMBean1.getJMSSendDestinations(), componentsMBean2.getJMSSendDestinations()));
    componentsMBean2.setJMSReceiveTopics(mergeJMSReceiveTopics(componentsMBean1.getJMSReceiveTopics(), componentsMBean2.getJMSReceiveTopics()));
    componentsMBean2.setJMSReceiveQueues(mergeJMSReceiveQueues(componentsMBean1.getJMSReceiveQueues(), componentsMBean2.getJMSReceiveQueues()));
    paramWebServiceMBean2.setOperations(mergeOperations(paramWebServiceMBean1.getOperations(), paramWebServiceMBean2.getOperations()));
    if (debug)
      System.out.println("result:\n" + ((WebServiceMBeanImpl)paramWebServiceMBean2).toXML(0)); 
    return paramWebServiceMBean2;
  }
  
  public static XMLNodeSet mergeSchemas(XMLNodeSet paramXMLNodeSet1, XMLNodeSet paramXMLNodeSet2) throws DDProcessingException {
    if (paramXMLNodeSet1 == null)
      return paramXMLNodeSet2; 
    if (paramXMLNodeSet2 == null)
      return paramXMLNodeSet1; 
    try {
      XMLNode xMLNode = new XMLNode();
      XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream(xMLNode);
      MergeSchemas.merge(xMLNodeOutputStream, new XMLInputStream[] { paramXMLNodeSet1.stream(), paramXMLNodeSet2.stream() });
      xMLNodeOutputStream.flush();
      XMLNodeSet xMLNodeSet = new XMLNodeSet();
      for (Iterator iterator = xMLNode.getChildren(); iterator.hasNext();)
        xMLNodeSet.addXMLNode((XMLNode)iterator.next()); 
      return xMLNodeSet;
    } catch (XMLStreamException xMLStreamException) {
      throw new DDProcessingException("", xMLStreamException);
    } catch (XSDException xSDException) {
      throw new DDProcessingException("", xSDException);
    } 
  }
  
  public static JavaClassMBean[] mergeJavaClassComponents(JavaClassMBean[] paramArrayOfJavaClassMBean1, JavaClassMBean[] paramArrayOfJavaClassMBean2) throws DDProcessingException {
    if (paramArrayOfJavaClassMBean1 == null || paramArrayOfJavaClassMBean2 == null)
      return (JavaClassMBean[])checkForNull(paramArrayOfJavaClassMBean1, paramArrayOfJavaClassMBean2); 
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfJavaClassMBean1));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfJavaClassMBean2));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext()) {
      JavaClassMBean javaClassMBean = (JavaClassMBean)listIterator.next();
      ListIterator listIterator1 = arrayList2.listIterator();
      while (listIterator1.hasNext()) {
        JavaClassMBean javaClassMBean1 = (JavaClassMBean)listIterator1.next();
        if (nullableEquals(javaClassMBean.getComponentName(), javaClassMBean1.getComponentName()))
          throw new DDProcessingException("Failed to merge javaclass components. They have the same component name \"" + javaClassMBean.getComponentName() + "\"."); 
      } 
      arrayList2.add(javaClassMBean);
      listIterator.remove();
    } 
    return (JavaClassMBean[])arrayList2.toArray(new JavaClassMBean[0]);
  }
  
  public static StatelessEJBMBean[] mergeStatelessEJBs(StatelessEJBMBean[] paramArrayOfStatelessEJBMBean1, StatelessEJBMBean[] paramArrayOfStatelessEJBMBean2) throws DDProcessingException {
    if (paramArrayOfStatelessEJBMBean1 == null || paramArrayOfStatelessEJBMBean2 == null)
      return (StatelessEJBMBean[])checkForNull(paramArrayOfStatelessEJBMBean1, paramArrayOfStatelessEJBMBean2); 
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfStatelessEJBMBean1));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfStatelessEJBMBean2));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext()) {
      StatelessEJBMBean statelessEJBMBean = (StatelessEJBMBean)listIterator.next();
      ListIterator listIterator1 = arrayList2.listIterator();
      while (listIterator1.hasNext()) {
        StatelessEJBMBean statelessEJBMBean1 = (StatelessEJBMBean)listIterator1.next();
        if (nullableEquals(statelessEJBMBean.getComponentName(), statelessEJBMBean1.getComponentName()))
          throw new DDProcessingException("Failed to merge EJB components. They have the same component name \"" + statelessEJBMBean.getComponentName() + "\"."); 
      } 
      arrayList2.add(statelessEJBMBean);
      listIterator.remove();
    } 
    return (StatelessEJBMBean[])arrayList2.toArray(new StatelessEJBMBean[0]);
  }
  
  public static JMSSendDestinationMBean[] mergeJMSSendDestination(JMSSendDestinationMBean[] paramArrayOfJMSSendDestinationMBean1, JMSSendDestinationMBean[] paramArrayOfJMSSendDestinationMBean2) throws DDProcessingException {
    if (paramArrayOfJMSSendDestinationMBean1 == null || paramArrayOfJMSSendDestinationMBean2 == null)
      return (JMSSendDestinationMBean[])checkForNull(paramArrayOfJMSSendDestinationMBean1, paramArrayOfJMSSendDestinationMBean2); 
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSSendDestinationMBean1));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSSendDestinationMBean2));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext()) {
      JMSSendDestinationMBean jMSSendDestinationMBean = (JMSSendDestinationMBean)listIterator.next();
      ListIterator listIterator1 = arrayList2.listIterator();
      while (listIterator1.hasNext()) {
        JMSSendDestinationMBean jMSSendDestinationMBean1 = (JMSSendDestinationMBean)listIterator1.next();
        if (nullableEquals(jMSSendDestinationMBean.getComponentName(), jMSSendDestinationMBean1.getComponentName()))
          throw new DDProcessingException("Failed to merge JMSSendDestination components. They have the same component name \"" + jMSSendDestinationMBean.getComponentName() + "\"."); 
      } 
      arrayList2.add(jMSSendDestinationMBean);
      listIterator.remove();
    } 
    return (JMSSendDestinationMBean[])arrayList2.toArray(new JMSSendDestinationMBean[0]);
  }
  
  public static JMSReceiveTopicMBean[] mergeJMSReceiveTopics(JMSReceiveTopicMBean[] paramArrayOfJMSReceiveTopicMBean1, JMSReceiveTopicMBean[] paramArrayOfJMSReceiveTopicMBean2) throws DDProcessingException {
    if (paramArrayOfJMSReceiveTopicMBean1 == null || paramArrayOfJMSReceiveTopicMBean2 == null)
      return (JMSReceiveTopicMBean[])checkForNull(paramArrayOfJMSReceiveTopicMBean1, paramArrayOfJMSReceiveTopicMBean2); 
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSReceiveTopicMBean1));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSReceiveTopicMBean2));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext()) {
      JMSReceiveTopicMBean jMSReceiveTopicMBean = (JMSReceiveTopicMBean)listIterator.next();
      ListIterator listIterator1 = arrayList2.listIterator();
      while (listIterator1.hasNext()) {
        JMSReceiveTopicMBean jMSReceiveTopicMBean1 = (JMSReceiveTopicMBean)listIterator1.next();
        if (nullableEquals(jMSReceiveTopicMBean.getComponentName(), jMSReceiveTopicMBean1.getComponentName()))
          throw new DDProcessingException("Failed to merge JMSReceiveTopic components. They have the same component name \"" + jMSReceiveTopicMBean.getComponentName() + "\"."); 
      } 
      arrayList2.add(jMSReceiveTopicMBean);
      listIterator.remove();
    } 
    return (JMSReceiveTopicMBean[])arrayList2.toArray(new JMSReceiveTopicMBean[0]);
  }
  
  public static JMSReceiveQueueMBean[] mergeJMSReceiveQueues(JMSReceiveQueueMBean[] paramArrayOfJMSReceiveQueueMBean1, JMSReceiveQueueMBean[] paramArrayOfJMSReceiveQueueMBean2) throws DDProcessingException {
    if (paramArrayOfJMSReceiveQueueMBean1 == null || paramArrayOfJMSReceiveQueueMBean2 == null)
      return (JMSReceiveQueueMBean[])checkForNull(paramArrayOfJMSReceiveQueueMBean1, paramArrayOfJMSReceiveQueueMBean2); 
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSReceiveQueueMBean1));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSReceiveQueueMBean2));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext()) {
      JMSReceiveQueueMBean jMSReceiveQueueMBean = (JMSReceiveQueueMBean)listIterator.next();
      ListIterator listIterator1 = arrayList2.listIterator();
      while (listIterator1.hasNext()) {
        JMSReceiveQueueMBean jMSReceiveQueueMBean1 = (JMSReceiveQueueMBean)listIterator1.next();
        if (nullableEquals(jMSReceiveQueueMBean.getComponentName(), jMSReceiveQueueMBean1.getComponentName()))
          throw new DDProcessingException("Failed to merge JMSReceiveQueue components. They have the same component name \"" + jMSReceiveQueueMBean.getComponentName() + "\"."); 
      } 
      arrayList2.add(jMSReceiveQueueMBean);
      listIterator.remove();
    } 
    return (JMSReceiveQueueMBean[])arrayList2.toArray(new JMSReceiveQueueMBean[0]);
  }
  
  public static TypeMappingMBean mergeTypeMapping(TypeMappingMBean paramTypeMappingMBean1, TypeMappingMBean paramTypeMappingMBean2) {
    if (paramTypeMappingMBean1 == null || paramTypeMappingMBean2 == null)
      return (TypeMappingMBean)checkForNull(paramTypeMappingMBean1, paramTypeMappingMBean2); 
    if (paramTypeMappingMBean1.getTypeMappingEntries() == null)
      return paramTypeMappingMBean2; 
    if (paramTypeMappingMBean2.getTypeMappingEntries() == null)
      return paramTypeMappingMBean1; 
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramTypeMappingMBean1.getTypeMappingEntries()));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramTypeMappingMBean2.getTypeMappingEntries()));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext()) {
      TypeMappingEntryMBean typeMappingEntryMBean = (TypeMappingEntryMBean)listIterator.next();
      ListIterator listIterator1 = arrayList2.listIterator();
      while (listIterator1.hasNext()) {
        TypeMappingEntryMBean typeMappingEntryMBean1 = (TypeMappingEntryMBean)listIterator1.next();
        if (nullableEquals(typeMappingEntryMBean.getClassName(), typeMappingEntryMBean1.getClassName()) && nullableEquals(typeMappingEntryMBean.getElementName(), typeMappingEntryMBean1.getElementName()) && nullableEquals(typeMappingEntryMBean.getXSDTypeName(), typeMappingEntryMBean1.getXSDTypeName())) {
          listIterator1.remove();
          break;
        } 
      } 
      arrayList2.add(typeMappingEntryMBean);
      listIterator.remove();
    } 
    paramTypeMappingMBean2.setTypeMappingEntries((TypeMappingEntryMBean[])arrayList2.toArray(new TypeMappingEntryMBean[0]));
    return paramTypeMappingMBean2;
  }
  
  public static OperationsMBean mergeOperations(OperationsMBean paramOperationsMBean1, OperationsMBean paramOperationsMBean2) throws DDProcessingException {
    if (paramOperationsMBean1 == null || paramOperationsMBean2 == null)
      return (OperationsMBean)checkForNull(paramOperationsMBean1, paramOperationsMBean2); 
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramOperationsMBean1.getOperations()));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramOperationsMBean2.getOperations()));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext())
      arrayList2.add(listIterator.next()); 
    paramOperationsMBean2.setOperations((OperationMBean[])arrayList2.toArray(new OperationMBean[0]));
    return paramOperationsMBean2;
  }
  
  private static boolean nullableEquals(Object paramObject1, Object paramObject2) {
    if (paramObject1 != null)
      return paramObject1.equals(paramObject2); 
    return (paramObject2 == null);
  }
  
  private static Map createWebServicesMap(WebServiceMBean[] paramArrayOfWebServiceMBean) {
    HashMap hashMap = new HashMap();
    for (byte b = 0; b < paramArrayOfWebServiceMBean.length; b++)
      hashMap.put(paramArrayOfWebServiceMBean[b].getWebServiceName(), paramArrayOfWebServiceMBean[b]); 
    return hashMap;
  }
  
  private static Object checkForNull(Object paramObject1, Object paramObject2) {
    if (paramObject1 == null && paramObject2 != null)
      return paramObject2; 
    if (paramObject1 != null && paramObject2 == null)
      return paramObject1; 
    if (paramObject1 == null && paramObject2 == null)
      return null; 
    return null;
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    FileInputStream fileInputStream1 = new FileInputStream(paramArrayOfString[0]);
    FileInputStream fileInputStream2 = new FileInputStream(paramArrayOfString[1]);
    DDLoader dDLoader = new DDLoader();
    WebServicesMBeanImpl webServicesMBeanImpl1 = (WebServicesMBeanImpl)dDLoader.load(fileInputStream1);
    dDLoader = new DDLoader();
    WebServicesMBeanImpl webServicesMBeanImpl2 = (WebServicesMBeanImpl)dDLoader.load(fileInputStream2);
    mergeWebServices(webServicesMBeanImpl1, webServicesMBeanImpl2.getWebServices());
    XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(System.out);
    xMLOutputStream.add(webServicesMBeanImpl1.toXML(0));
    xMLOutputStream.flush();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\DDMerger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */