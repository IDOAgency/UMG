/*     */ package weblogic.webservice.dd;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import weblogic.management.descriptors.webservice.ComponentsMBean;
/*     */ import weblogic.management.descriptors.webservice.JMSReceiveQueueMBean;
/*     */ import weblogic.management.descriptors.webservice.JMSReceiveTopicMBean;
/*     */ import weblogic.management.descriptors.webservice.JMSSendDestinationMBean;
/*     */ import weblogic.management.descriptors.webservice.JavaClassMBean;
/*     */ import weblogic.management.descriptors.webservice.OperationMBean;
/*     */ import weblogic.management.descriptors.webservice.OperationsMBean;
/*     */ import weblogic.management.descriptors.webservice.StatelessEJBMBean;
/*     */ import weblogic.management.descriptors.webservice.TypeMappingEntryMBean;
/*     */ import weblogic.management.descriptors.webservice.TypeMappingMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
/*     */ import weblogic.xml.schema.model.XSDException;
/*     */ import weblogic.xml.schema.model.util.MergeSchemas;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ import weblogic.xml.xmlnode.XMLNodeOutputStream;
/*     */ import weblogic.xml.xmlnode.XMLNodeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DDMerger
/*     */ {
/*  60 */   private static final boolean debug = (System.getProperty(DEBUG_PROPERTY()) != null);
/*     */   private static final boolean overwrite = false;
/*     */   
/*  63 */   private static String DEBUG_PROPERTY() { return "ddmerger.debug"; }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DIFFERENT = 0;
/*     */ 
/*     */   
/*     */   private static final int CONFLICTING = 1;
/*     */   
/*     */   private static final int EQUAL = 2;
/*     */ 
/*     */   
/*  75 */   public static String DEFAULT_SERVICE_NAME() { return "myWebService"; }
/*  76 */   public static String DEFAULT_PROTOCOL() { return "http"; }
/*     */   
/*  78 */   public static String DEFAULT_TARGET_NAMESPACE() { return "http://example.com/services/MyWebService"; }
/*     */   
/*  80 */   public static String DEFAULT_SERVICE_URI() { return "mywebservice"; }
/*     */   
/*  82 */   public static String DEFAULT_EJB_COMPONENT_NAME() { return "myEJBComponent"; }
/*     */ 
/*     */   
/*  85 */   public static String DEFAULT_JAVA_CLASS_COMPONENT_NAME() { return "myJavaClassComponent"; }
/*     */   
/*  87 */   public static String DEFAULT_EJB_JAR_NAME() { return "myejbs.jar"; }
/*  88 */   public static String DEFAULT_EJB_NAME() { return "myEJB"; }
/*     */   
/*  90 */   public static String DEFAULT_JAVA_CLASS_NAME() { return "com.example.services.MyWebService"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebServicesMBean mergeWebServices(WebServicesMBean paramWebServicesMBean, WebServiceMBean[] paramArrayOfWebServiceMBean) throws DDProcessingException {
/* 119 */     Map map = createWebServicesMap(paramArrayOfWebServiceMBean);
/* 120 */     WebServiceMBean[] arrayOfWebServiceMBean = paramWebServicesMBean.getWebServices();
/* 121 */     if (arrayOfWebServiceMBean != null)
/*     */     {
/*     */       
/* 124 */       for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
/* 125 */         String str = arrayOfWebServiceMBean[b].getWebServiceName();
/* 126 */         WebServiceMBean webServiceMBean = (WebServiceMBean)map.get(str);
/* 127 */         if (webServiceMBean != null) {
/* 128 */           paramWebServicesMBean.removeWebService(arrayOfWebServiceMBean[b]);
/* 129 */           arrayOfWebServiceMBean[b] = mergeWebService(webServiceMBean, arrayOfWebServiceMBean[b]);
/* 130 */           paramWebServicesMBean.addWebService(arrayOfWebServiceMBean[b]);
/* 131 */           map.remove(str);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 137 */     Iterator iterator = map.values().iterator();
/* 138 */     while (iterator.hasNext()) {
/* 139 */       paramWebServicesMBean.addWebService((WebServiceMBean)iterator.next());
/*     */     }
/* 141 */     return paramWebServicesMBean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WebServiceMBean mergeWebService(WebServiceMBean paramWebServiceMBean1, WebServiceMBean paramWebServiceMBean2) throws DDProcessingException {
/* 148 */     if (debug) {
/* 149 */       System.out.println("MERGING:");
/* 150 */       System.out.println("src:\n" + ((WebServiceMBeanImpl)paramWebServiceMBean1).toXML(0));
/* 151 */       System.out.println("dest:\n" + ((WebServiceMBeanImpl)paramWebServiceMBean2).toXML(0));
/*     */     } 
/*     */     
/* 154 */     String str1 = paramWebServiceMBean1.getURI();
/* 155 */     String str2 = paramWebServiceMBean2.getURI();
/* 156 */     if (!str1.startsWith("/")) str1 = "/" + str1; 
/* 157 */     if (!str2.startsWith("/")) str2 = "/" + str2;
/*     */     
/* 159 */     if (!str1.equals(str2)) {
/* 160 */       throw new DDProcessingException("Trying to merge two webservices with the same servicename \"" + paramWebServiceMBean1.getWebServiceName() + "\" but different uri.");
/*     */     }
/*     */     
/* 163 */     if (paramWebServiceMBean1.getProtocol() != null && paramWebServiceMBean2.getProtocol() != null && 
/* 164 */       !paramWebServiceMBean1.getProtocol().equals(paramWebServiceMBean2.getProtocol())) {
/* 165 */       throw new DDProcessingException("Trying to merge two webservices with the same servicename \"" + paramWebServiceMBean1.getWebServiceName() + "\" but different protocols.");
/*     */     }
/*     */ 
/*     */     
/* 169 */     paramWebServiceMBean2.setTypes(mergeSchemas(paramWebServiceMBean1.getTypes(), paramWebServiceMBean2.getTypes()));
/* 170 */     paramWebServiceMBean2.setTypeMapping(mergeTypeMapping(paramWebServiceMBean1.getTypeMapping(), paramWebServiceMBean2.getTypeMapping()));
/*     */ 
/*     */     
/* 173 */     ComponentsMBean componentsMBean1 = paramWebServiceMBean1.getComponents();
/* 174 */     ComponentsMBean componentsMBean2 = paramWebServiceMBean2.getComponents();
/* 175 */     componentsMBean2.setStatelessEJBs(mergeStatelessEJBs(componentsMBean1.getStatelessEJBs(), componentsMBean2.getStatelessEJBs()));
/*     */ 
/*     */     
/* 178 */     componentsMBean2.setJavaClassComponents(mergeJavaClassComponents(componentsMBean1.getJavaClassComponents(), componentsMBean2.getJavaClassComponents()));
/*     */ 
/*     */     
/* 181 */     componentsMBean2.setJMSSendDestinations(mergeJMSSendDestination(componentsMBean1.getJMSSendDestinations(), componentsMBean2.getJMSSendDestinations()));
/*     */ 
/*     */     
/* 184 */     componentsMBean2.setJMSReceiveTopics(mergeJMSReceiveTopics(componentsMBean1.getJMSReceiveTopics(), componentsMBean2.getJMSReceiveTopics()));
/*     */ 
/*     */     
/* 187 */     componentsMBean2.setJMSReceiveQueues(mergeJMSReceiveQueues(componentsMBean1.getJMSReceiveQueues(), componentsMBean2.getJMSReceiveQueues()));
/*     */ 
/*     */     
/* 190 */     paramWebServiceMBean2.setOperations(mergeOperations(paramWebServiceMBean1.getOperations(), paramWebServiceMBean2.getOperations()));
/*     */ 
/*     */     
/* 193 */     if (debug) {
/* 194 */       System.out.println("result:\n" + ((WebServiceMBeanImpl)paramWebServiceMBean2).toXML(0));
/*     */     }
/* 196 */     return paramWebServiceMBean2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static XMLNodeSet mergeSchemas(XMLNodeSet paramXMLNodeSet1, XMLNodeSet paramXMLNodeSet2) throws DDProcessingException {
/* 202 */     if (paramXMLNodeSet1 == null) return paramXMLNodeSet2; 
/* 203 */     if (paramXMLNodeSet2 == null) return paramXMLNodeSet1;
/*     */     
/*     */     try {
/* 206 */       XMLNode xMLNode = new XMLNode();
/* 207 */       XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream(xMLNode);
/* 208 */       MergeSchemas.merge(xMLNodeOutputStream, new XMLInputStream[] { paramXMLNodeSet1.stream(), paramXMLNodeSet2.stream() });
/* 209 */       xMLNodeOutputStream.flush();
/*     */       
/* 211 */       XMLNodeSet xMLNodeSet = new XMLNodeSet();
/*     */       
/* 213 */       for (Iterator iterator = xMLNode.getChildren(); iterator.hasNext();) {
/* 214 */         xMLNodeSet.addXMLNode((XMLNode)iterator.next());
/*     */       }
/*     */       
/* 217 */       return xMLNodeSet;
/* 218 */     } catch (XMLStreamException xMLStreamException) {
/* 219 */       throw new DDProcessingException("", xMLStreamException);
/* 220 */     } catch (XSDException xSDException) {
/* 221 */       throw new DDProcessingException("", xSDException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaClassMBean[] mergeJavaClassComponents(JavaClassMBean[] paramArrayOfJavaClassMBean1, JavaClassMBean[] paramArrayOfJavaClassMBean2) throws DDProcessingException {
/* 228 */     if (paramArrayOfJavaClassMBean1 == null || paramArrayOfJavaClassMBean2 == null) {
/* 229 */       return (JavaClassMBean[])checkForNull(paramArrayOfJavaClassMBean1, paramArrayOfJavaClassMBean2);
/*     */     }
/* 231 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfJavaClassMBean1));
/* 232 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfJavaClassMBean2));
/* 233 */     ListIterator listIterator = arrayList1.listIterator();
/* 234 */     while (listIterator.hasNext()) {
/* 235 */       JavaClassMBean javaClassMBean = (JavaClassMBean)listIterator.next();
/* 236 */       ListIterator listIterator1 = arrayList2.listIterator();
/* 237 */       while (listIterator1.hasNext()) {
/* 238 */         JavaClassMBean javaClassMBean1 = (JavaClassMBean)listIterator1.next();
/* 239 */         if (nullableEquals(javaClassMBean.getComponentName(), javaClassMBean1.getComponentName()))
/*     */         {
/*     */ 
/*     */           
/* 243 */           throw new DDProcessingException("Failed to merge javaclass components. They have the same component name \"" + javaClassMBean.getComponentName() + "\".");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 249 */       arrayList2.add(javaClassMBean);
/* 250 */       listIterator.remove();
/*     */     } 
/* 252 */     return (JavaClassMBean[])arrayList2.toArray(new JavaClassMBean[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static StatelessEJBMBean[] mergeStatelessEJBs(StatelessEJBMBean[] paramArrayOfStatelessEJBMBean1, StatelessEJBMBean[] paramArrayOfStatelessEJBMBean2) throws DDProcessingException {
/* 258 */     if (paramArrayOfStatelessEJBMBean1 == null || paramArrayOfStatelessEJBMBean2 == null) {
/* 259 */       return (StatelessEJBMBean[])checkForNull(paramArrayOfStatelessEJBMBean1, paramArrayOfStatelessEJBMBean2);
/*     */     }
/* 261 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfStatelessEJBMBean1));
/* 262 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfStatelessEJBMBean2));
/* 263 */     ListIterator listIterator = arrayList1.listIterator();
/* 264 */     while (listIterator.hasNext()) {
/* 265 */       StatelessEJBMBean statelessEJBMBean = (StatelessEJBMBean)listIterator.next();
/* 266 */       ListIterator listIterator1 = arrayList2.listIterator();
/* 267 */       while (listIterator1.hasNext()) {
/* 268 */         StatelessEJBMBean statelessEJBMBean1 = (StatelessEJBMBean)listIterator1.next();
/* 269 */         if (nullableEquals(statelessEJBMBean.getComponentName(), statelessEJBMBean1.getComponentName()))
/*     */         {
/*     */ 
/*     */           
/* 273 */           throw new DDProcessingException("Failed to merge EJB components. They have the same component name \"" + statelessEJBMBean.getComponentName() + "\".");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 279 */       arrayList2.add(statelessEJBMBean);
/* 280 */       listIterator.remove();
/*     */     } 
/* 282 */     return (StatelessEJBMBean[])arrayList2.toArray(new StatelessEJBMBean[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JMSSendDestinationMBean[] mergeJMSSendDestination(JMSSendDestinationMBean[] paramArrayOfJMSSendDestinationMBean1, JMSSendDestinationMBean[] paramArrayOfJMSSendDestinationMBean2) throws DDProcessingException {
/* 289 */     if (paramArrayOfJMSSendDestinationMBean1 == null || paramArrayOfJMSSendDestinationMBean2 == null) {
/* 290 */       return (JMSSendDestinationMBean[])checkForNull(paramArrayOfJMSSendDestinationMBean1, paramArrayOfJMSSendDestinationMBean2);
/*     */     }
/* 292 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSSendDestinationMBean1));
/* 293 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSSendDestinationMBean2));
/* 294 */     ListIterator listIterator = arrayList1.listIterator();
/* 295 */     while (listIterator.hasNext()) {
/* 296 */       JMSSendDestinationMBean jMSSendDestinationMBean = (JMSSendDestinationMBean)listIterator.next();
/* 297 */       ListIterator listIterator1 = arrayList2.listIterator();
/* 298 */       while (listIterator1.hasNext()) {
/* 299 */         JMSSendDestinationMBean jMSSendDestinationMBean1 = (JMSSendDestinationMBean)listIterator1.next();
/* 300 */         if (nullableEquals(jMSSendDestinationMBean.getComponentName(), jMSSendDestinationMBean1.getComponentName()))
/*     */         {
/*     */ 
/*     */           
/* 304 */           throw new DDProcessingException("Failed to merge JMSSendDestination components. They have the same component name \"" + jMSSendDestinationMBean.getComponentName() + "\".");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 310 */       arrayList2.add(jMSSendDestinationMBean);
/* 311 */       listIterator.remove();
/*     */     } 
/* 313 */     return (JMSSendDestinationMBean[])arrayList2.toArray(new JMSSendDestinationMBean[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JMSReceiveTopicMBean[] mergeJMSReceiveTopics(JMSReceiveTopicMBean[] paramArrayOfJMSReceiveTopicMBean1, JMSReceiveTopicMBean[] paramArrayOfJMSReceiveTopicMBean2) throws DDProcessingException {
/* 320 */     if (paramArrayOfJMSReceiveTopicMBean1 == null || paramArrayOfJMSReceiveTopicMBean2 == null) {
/* 321 */       return (JMSReceiveTopicMBean[])checkForNull(paramArrayOfJMSReceiveTopicMBean1, paramArrayOfJMSReceiveTopicMBean2);
/*     */     }
/* 323 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSReceiveTopicMBean1));
/* 324 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSReceiveTopicMBean2));
/* 325 */     ListIterator listIterator = arrayList1.listIterator();
/* 326 */     while (listIterator.hasNext()) {
/* 327 */       JMSReceiveTopicMBean jMSReceiveTopicMBean = (JMSReceiveTopicMBean)listIterator.next();
/* 328 */       ListIterator listIterator1 = arrayList2.listIterator();
/* 329 */       while (listIterator1.hasNext()) {
/* 330 */         JMSReceiveTopicMBean jMSReceiveTopicMBean1 = (JMSReceiveTopicMBean)listIterator1.next();
/* 331 */         if (nullableEquals(jMSReceiveTopicMBean.getComponentName(), jMSReceiveTopicMBean1.getComponentName()))
/*     */         {
/*     */ 
/*     */           
/* 335 */           throw new DDProcessingException("Failed to merge JMSReceiveTopic components. They have the same component name \"" + jMSReceiveTopicMBean.getComponentName() + "\".");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 341 */       arrayList2.add(jMSReceiveTopicMBean);
/* 342 */       listIterator.remove();
/*     */     } 
/* 344 */     return (JMSReceiveTopicMBean[])arrayList2.toArray(new JMSReceiveTopicMBean[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JMSReceiveQueueMBean[] mergeJMSReceiveQueues(JMSReceiveQueueMBean[] paramArrayOfJMSReceiveQueueMBean1, JMSReceiveQueueMBean[] paramArrayOfJMSReceiveQueueMBean2) throws DDProcessingException {
/* 351 */     if (paramArrayOfJMSReceiveQueueMBean1 == null || paramArrayOfJMSReceiveQueueMBean2 == null) {
/* 352 */       return (JMSReceiveQueueMBean[])checkForNull(paramArrayOfJMSReceiveQueueMBean1, paramArrayOfJMSReceiveQueueMBean2);
/*     */     }
/* 354 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSReceiveQueueMBean1));
/* 355 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfJMSReceiveQueueMBean2));
/* 356 */     ListIterator listIterator = arrayList1.listIterator();
/* 357 */     while (listIterator.hasNext()) {
/* 358 */       JMSReceiveQueueMBean jMSReceiveQueueMBean = (JMSReceiveQueueMBean)listIterator.next();
/* 359 */       ListIterator listIterator1 = arrayList2.listIterator();
/* 360 */       while (listIterator1.hasNext()) {
/* 361 */         JMSReceiveQueueMBean jMSReceiveQueueMBean1 = (JMSReceiveQueueMBean)listIterator1.next();
/* 362 */         if (nullableEquals(jMSReceiveQueueMBean.getComponentName(), jMSReceiveQueueMBean1.getComponentName()))
/*     */         {
/*     */ 
/*     */           
/* 366 */           throw new DDProcessingException("Failed to merge JMSReceiveQueue components. They have the same component name \"" + jMSReceiveQueueMBean.getComponentName() + "\".");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 372 */       arrayList2.add(jMSReceiveQueueMBean);
/* 373 */       listIterator.remove();
/*     */     } 
/* 375 */     return (JMSReceiveQueueMBean[])arrayList2.toArray(new JMSReceiveQueueMBean[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeMappingMBean mergeTypeMapping(TypeMappingMBean paramTypeMappingMBean1, TypeMappingMBean paramTypeMappingMBean2) {
/* 381 */     if (paramTypeMappingMBean1 == null || paramTypeMappingMBean2 == null) {
/* 382 */       return (TypeMappingMBean)checkForNull(paramTypeMappingMBean1, paramTypeMappingMBean2);
/*     */     }
/* 384 */     if (paramTypeMappingMBean1.getTypeMappingEntries() == null) return paramTypeMappingMBean2; 
/* 385 */     if (paramTypeMappingMBean2.getTypeMappingEntries() == null) return paramTypeMappingMBean1;
/*     */     
/* 387 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramTypeMappingMBean1.getTypeMappingEntries()));
/* 388 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramTypeMappingMBean2.getTypeMappingEntries()));
/* 389 */     ListIterator listIterator = arrayList1.listIterator();
/* 390 */     while (listIterator.hasNext()) {
/* 391 */       TypeMappingEntryMBean typeMappingEntryMBean = (TypeMappingEntryMBean)listIterator.next();
/* 392 */       ListIterator listIterator1 = arrayList2.listIterator();
/* 393 */       while (listIterator1.hasNext()) {
/* 394 */         TypeMappingEntryMBean typeMappingEntryMBean1 = (TypeMappingEntryMBean)listIterator1.next();
/* 395 */         if (nullableEquals(typeMappingEntryMBean.getClassName(), typeMappingEntryMBean1.getClassName()) && nullableEquals(typeMappingEntryMBean.getElementName(), typeMappingEntryMBean1.getElementName()) && nullableEquals(typeMappingEntryMBean.getXSDTypeName(), typeMappingEntryMBean1.getXSDTypeName())) {
/*     */ 
/*     */           
/* 398 */           listIterator1.remove();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 403 */       arrayList2.add(typeMappingEntryMBean);
/* 404 */       listIterator.remove();
/*     */     } 
/* 406 */     paramTypeMappingMBean2.setTypeMappingEntries((TypeMappingEntryMBean[])arrayList2.toArray(new TypeMappingEntryMBean[0]));
/*     */ 
/*     */     
/* 409 */     return paramTypeMappingMBean2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static OperationsMBean mergeOperations(OperationsMBean paramOperationsMBean1, OperationsMBean paramOperationsMBean2) throws DDProcessingException {
/* 415 */     if (paramOperationsMBean1 == null || paramOperationsMBean2 == null) {
/* 416 */       return (OperationsMBean)checkForNull(paramOperationsMBean1, paramOperationsMBean2);
/*     */     }
/* 418 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramOperationsMBean1.getOperations()));
/* 419 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramOperationsMBean2.getOperations()));
/* 420 */     ListIterator listIterator = arrayList1.listIterator();
/*     */ 
/*     */     
/* 423 */     while (listIterator.hasNext()) {
/* 424 */       arrayList2.add(listIterator.next());
/*     */     }
/* 426 */     paramOperationsMBean2.setOperations((OperationMBean[])arrayList2.toArray(new OperationMBean[0]));
/*     */ 
/*     */     
/* 429 */     return paramOperationsMBean2;
/*     */   }
/*     */   
/*     */   private static boolean nullableEquals(Object paramObject1, Object paramObject2) {
/* 433 */     if (paramObject1 != null) {
/* 434 */       return paramObject1.equals(paramObject2);
/*     */     }
/* 436 */     return (paramObject2 == null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map createWebServicesMap(WebServiceMBean[] paramArrayOfWebServiceMBean) {
/* 442 */     HashMap hashMap = new HashMap();
/* 443 */     for (byte b = 0; b < paramArrayOfWebServiceMBean.length; b++) {
/* 444 */       hashMap.put(paramArrayOfWebServiceMBean[b].getWebServiceName(), paramArrayOfWebServiceMBean[b]);
/*     */     }
/* 446 */     return hashMap;
/*     */   }
/*     */   
/*     */   private static Object checkForNull(Object paramObject1, Object paramObject2) {
/* 450 */     if (paramObject1 == null && paramObject2 != null) return paramObject2; 
/* 451 */     if (paramObject1 != null && paramObject2 == null) return paramObject1; 
/* 452 */     if (paramObject1 == null && paramObject2 == null) return null; 
/* 453 */     return null;
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 457 */     FileInputStream fileInputStream1 = new FileInputStream(paramArrayOfString[0]);
/* 458 */     FileInputStream fileInputStream2 = new FileInputStream(paramArrayOfString[1]);
/* 459 */     DDLoader dDLoader = new DDLoader();
/* 460 */     WebServicesMBeanImpl webServicesMBeanImpl1 = (WebServicesMBeanImpl)dDLoader.load(fileInputStream1);
/* 461 */     dDLoader = new DDLoader();
/* 462 */     WebServicesMBeanImpl webServicesMBeanImpl2 = (WebServicesMBeanImpl)dDLoader.load(fileInputStream2);
/* 463 */     mergeWebServices(webServicesMBeanImpl1, webServicesMBeanImpl2.getWebServices());
/*     */     
/* 465 */     XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(System.out);
/*     */     
/* 467 */     xMLOutputStream.add(webServicesMBeanImpl1.toXML(0));
/* 468 */     xMLOutputStream.flush();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\DDMerger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */