/*      */ package weblogic.webservice.dd;
/*      */ 
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.zip.ZipEntry;
/*      */ import weblogic.management.descriptors.webservice.ComponentMBean;
/*      */ import weblogic.management.descriptors.webservice.ComponentsMBean;
/*      */ import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.EJBLinkMBean;
/*      */ import weblogic.management.descriptors.webservice.EJBLinkMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.FaultMBean;
/*      */ import weblogic.management.descriptors.webservice.FaultMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.HandlerChainMBean;
/*      */ import weblogic.management.descriptors.webservice.HandlerChainMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.HandlerChainsMBean;
/*      */ import weblogic.management.descriptors.webservice.HandlerChainsMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.HandlerMBean;
/*      */ import weblogic.management.descriptors.webservice.HandlerMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.InitParamMBean;
/*      */ import weblogic.management.descriptors.webservice.InitParamMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.InitParamsMBean;
/*      */ import weblogic.management.descriptors.webservice.InitParamsMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.JMSReceiveQueueMBean;
/*      */ import weblogic.management.descriptors.webservice.JMSReceiveQueueMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.JMSReceiveTopicMBean;
/*      */ import weblogic.management.descriptors.webservice.JMSReceiveTopicMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.JMSSendDestinationMBean;
/*      */ import weblogic.management.descriptors.webservice.JMSSendDestinationMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.JNDINameMBean;
/*      */ import weblogic.management.descriptors.webservice.JNDINameMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.JavaClassMBean;
/*      */ import weblogic.management.descriptors.webservice.JavaClassMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.OperationMBean;
/*      */ import weblogic.management.descriptors.webservice.OperationMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.OperationsMBean;
/*      */ import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.ParamMBean;
/*      */ import weblogic.management.descriptors.webservice.ParamMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.ParamsMBean;
/*      */ import weblogic.management.descriptors.webservice.ParamsMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.ReliableDeliveryMBean;
/*      */ import weblogic.management.descriptors.webservice.ReliableDeliveryMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.ReturnParamMBean;
/*      */ import weblogic.management.descriptors.webservice.ReturnParamMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.StatefulJavaClassMBean;
/*      */ import weblogic.management.descriptors.webservice.StatefulJavaClassMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.StatelessEJBMBean;
/*      */ import weblogic.management.descriptors.webservice.StatelessEJBMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.TypeMappingEntryMBean;
/*      */ import weblogic.management.descriptors.webservice.TypeMappingEntryMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.TypeMappingMBean;
/*      */ import weblogic.management.descriptors.webservice.TypeMappingMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*      */ import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
/*      */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*      */ import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
/*      */ import weblogic.utils.AssertionError;
/*      */ import weblogic.utils.jars.VirtualJarFile;
/*      */ import weblogic.xml.security.specs.SecurityDD;
/*      */ import weblogic.xml.stream.StartElement;
/*      */ import weblogic.xml.stream.XMLEvent;
/*      */ import weblogic.xml.stream.XMLOutputStream;
/*      */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*      */ import weblogic.xml.stream.XMLStreamException;
/*      */ import weblogic.xml.xmlnode.XMLNode;
/*      */ import weblogic.xml.xmlnode.XMLNodeSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class DDLoader
/*      */ {
/*      */   private static final String WS_DD_PATH = "WEB-INF/web-services.xml";
/*      */   private static final String WEB_SERVICES = "web-services";
/*      */   private static final String WEB_SERVICE = "web-service";
/*      */   private static final String COMPONENTS = "components";
/*      */   private static final String OPERATIONS = "operations";
/*      */   private static final String SECURITY = "security";
/*      */   private static final String TYPES = "types";
/*      */   private static final String TYPE_MAPPING = "type-mapping";
/*      */   private static final String TYPE_MAPPING_ENTRY = "type-mapping-entry";
/*      */   private static final String STATELESS_EJB = "stateless-ejb";
/*      */   private static final String JAVA_CLASS = "java-class";
/*      */   private static final String STATEFUL_JAVA_CLASS = "stateful-java-class";
/*      */   private static final String HANDLER = "handler";
/*      */   private static final String HANDLER_CHAIN = "handler-chain";
/*      */   private static final String HANDLER_CHAINS = "handler-chains";
/*      */   private static final String JMS_SEND_DESTINATION = "jms-send-destination";
/*      */   private static final String JMS_RECEIVE_TOPIC = "jms-receive-topic";
/*      */   private static final String JMS_RECEIVE_QUEUE = "jms-receive-queue";
/*      */   private static final String EJB_LINK = "ejb-link";
/*      */   private static final String JNDI_NAME = "jndi-name";
/*      */   private static final String INVOKE_HANDLER = "invoke-handler";
/*      */   private static final String INIT_PARAM = "init-param";
/*      */   private static final String INIT_PARAMS = "init-params";
/*      */   private static final String PARAM = "param";
/*      */   private static final String FAULT = "fault";
/*      */   private static final String PARAMS = "params";
/*      */   private static final String OPERATION = "operation";
/*      */   private static final String RELIABLE_DELIVERY = "reliable-delivery";
/*      */   private static final String DUPLICATE_ELIMINATION = "duplicate-elimination";
/*      */   private static final String RETRIES = "retries";
/*      */   private static final String RETRY_INTERVAL = "retry-interval";
/*      */   private static final String PERSIST_DURATION = "persist-duration";
/*      */   private static final String IN_ORDER_DELIVERY = "in-order-delivery";
/*      */   private static final String RETURN_PARAM = "return-param";
/*      */   private static final String ELEMENT = "element";
/*      */   private static final String TYPE = "type";
/*      */   private static final String SERIALIZER = "serializer";
/*      */   private static final String DESERIALIZER = "deserializer";
/*      */   private static final String NAME = "name";
/*      */   private static final String CLASS_NAME = "class-name";
/*      */   private static final String PATH = "path";
/*      */   private static final String VALUE = "value";
/*      */   private static final String METHOD = "method";
/*      */   private static final String COMPONENT = "component";
/*      */   private static final String URI = "uri";
/*      */   private static final String TARGET_NAMESPACE = "targetNamespace";
/*      */   private static final String USE_SOAP12 = "useSOAP12";
/*      */   private static final String JMS_URI = "jmsUri";
/*      */   private static final String CHARSET = "charset";
/*      */   private static final String PORT_TYPE_NAME = "portTypeName";
/*      */   private static final String CONVERSATION_PHASE = "conversationPhase";
/*      */   private static final String IN_SECURITY_SPEC = "in-security-spec";
/*      */   private static final String OUT_SECURITY_SPEC = "out-security-spec";
/*      */   private static final String PORT_NAME = "portName";
/*      */   private static final String PROTOCOL = "protocol";
/*      */   private static final String JAVA_TYPE = "java-type";
/*      */   private static final String CONNECTION_FACTORY = "connection-factory";
/*      */   private static final String PROVIDER_URL = "provider-url";
/*      */   private static final String INITIAL_CONTEXT_FACTORY = "initial-context-factory";
/*      */   private static final String INVOCATION_STYLE = "invocation-style";
/*      */   private static final String NAMESPACE = "namespace";
/*      */   private static final String IMPLICIT = "implicit";
/*      */   private static final String LOCATION = "location";
/*      */   private static final String STYLE = "style";
/*      */   private static final String ONE_WAY = "one-way";
/*      */   private static final String REQUEST_RESPONSE = "request-response";
/*      */   private static final String HEADER = "header";
/*      */   private static final String BODY = "body";
/*      */   private static final String ATTACHMENT = "attachment";
/*      */   private static final String IN = "in";
/*      */   private static final String INOUT = "inout";
/*      */   private static final String OUT = "out";
/*      */   private static final String USE_MULTIPLE_PORTS = "useMultiplePorts";
/*      */   private static final String RESPONSE_BUFFER_SIZE = "responseBufferSize";
/*      */   private static final String EXPOSE_WSDL = "exposeWSDL";
/*      */   private static final String EXPOSE_HOME_PAGE = "exposeHomePage";
/*      */   private static final String IGNORE_AUTH_HEADER = "ignoreAuthHeader";
/*      */   private static final String HANDLE_ALL_ACTORS = "handleAllActors";
/*  177 */   private static final String[] COMPONENT_CHOICES = { "stateless-ejb", "java-class", "stateful-java-class", "handler-chain", "jms-send-destination", "jms-receive-topic", "jms-receive-queue" };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  182 */   public static final String[] operationAttributes = { "name", "method", "handler-chain", "component", "invocation-style", "namespace", "portTypeName", "conversationPhase", "in-security-spec", "out-security-spec" };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  187 */   public static final String[] paramAttributes = { "name", "style", "location", "implicit", "class-name", "type" };
/*      */   
/*      */   public static final String[] webserviceAttributes = { 
/*  190 */       "name", "uri", "targetNamespace", "portTypeName", "portName", "protocol", "style", "useSOAP12", "exposeWSDL", "jmsUri", "charset", "responseBufferSize", "exposeHomePage", "ignoreAuthHeader", "handleAllActors" };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   public static final String[] returnAttributes = { "name", "location", "type", "class-name" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   private Map handlerChains = new HashMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  209 */   private Map components = new HashMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ParsingHelper ph;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebServicesMBean load(JarFile paramJarFile) throws DDProcessingException {
/*  227 */     inputStream = null;
/*      */     try {
/*  229 */       ZipEntry zipEntry = paramJarFile.getEntry("WEB-INF/web-services.xml");
/*  230 */       if (zipEntry == null) return null; 
/*  231 */       inputStream = paramJarFile.getInputStream(zipEntry);
/*  232 */       WebServicesMBean webServicesMBean = load(inputStream);
/*  233 */       return webServicesMBean;
/*  234 */     } catch (IOException iOException) {
/*  235 */       throw new DDProcessingException("Could not read deployment descriptor", iOException);
/*      */     } finally {
/*      */ 
/*      */       
/*  239 */       try { if (inputStream != null) inputStream.close();  } catch (Throwable throwable) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebServicesMBean load(VirtualJarFile paramVirtualJarFile) throws DDProcessingException {
/*  251 */     inputStream = null;
/*      */     try {
/*  253 */       ZipEntry zipEntry = paramVirtualJarFile.getEntry("WEB-INF/web-services.xml");
/*  254 */       if (zipEntry == null) return null; 
/*  255 */       inputStream = paramVirtualJarFile.getInputStream(zipEntry);
/*  256 */       WebServicesMBean webServicesMBean = load(inputStream);
/*  257 */       return webServicesMBean;
/*  258 */     } catch (IOException iOException) {
/*  259 */       throw new DDProcessingException("Could not read deployment descriptor", iOException);
/*      */     } finally {
/*      */ 
/*      */       
/*  263 */       try { if (inputStream != null) inputStream.close();  } catch (Throwable throwable) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WebServicesMBean load(InputStream paramInputStream) throws DDProcessingException {
/*      */     try {
/*  278 */       this.ph = new ParsingHelper(paramInputStream);
/*  279 */       WebServicesMBean webServicesMBean = processWebServicesElement();
/*  280 */       this.ph.matchDocumentEnd();
/*  281 */       return webServicesMBean;
/*  282 */     } catch (XMLStreamException xMLStreamException) {
/*  283 */       throw new DDProcessingException("Problem parsing deployment descriptor", xMLStreamException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WebServicesMBean processWebServicesElement() throws DDProcessingException, XMLStreamException {
/*  295 */     WebServicesMBeanImpl webServicesMBeanImpl = new WebServicesMBeanImpl();
/*  296 */     this.ph.matchStartElement("web-services");
/*      */     
/*  298 */     HandlerChainsMBean handlerChainsMBean = processHandlerChainsElement();
/*  299 */     if (handlerChainsMBean != null) webServicesMBeanImpl.setHandlerChains(handlerChainsMBean);
/*      */     
/*  301 */     WebServiceMBean[] arrayOfWebServiceMBean = processWebServiceElements();
/*  302 */     webServicesMBeanImpl.setWebServices(arrayOfWebServiceMBean);
/*  303 */     this.ph.matchEndElement("web-services");
/*  304 */     return webServicesMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WebServiceMBean[] processWebServiceElements() throws DDProcessingException, XMLStreamException {
/*  313 */     WebServiceMBean webServiceMBean = processWebServiceElement();
/*  314 */     if (webServiceMBean == null) {
/*  315 */       throw new DDProcessingException("There must be at least one <web-service> element in <web-services>", this.ph.getLocation());
/*      */     }
/*  317 */     ArrayList arrayList = new ArrayList();
/*  318 */     while (webServiceMBean != null) {
/*  319 */       arrayList.add(webServiceMBean);
/*  320 */       webServiceMBean = processWebServiceElement();
/*      */     } 
/*  322 */     if (arrayList.size() > 0) {
/*  323 */       return (WebServiceMBeanImpl[])arrayList.toArray(new WebServiceMBeanImpl[0]);
/*      */     }
/*  325 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WebServiceMBean processWebServiceElement() throws DDProcessingException, XMLStreamException {
/*  335 */     WebServiceMBeanImpl webServiceMBeanImpl = null;
/*  336 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("web-service");
/*      */     
/*  338 */     if (xMLEvent != null) {
/*  339 */       webServiceMBeanImpl = new WebServiceMBeanImpl();
/*      */       
/*  341 */       StartElement startElement = (StartElement)xMLEvent;
/*      */       
/*  343 */       ParsingHelper.checkAttributes(startElement, webserviceAttributes);
/*      */       
/*  345 */       String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "name").getValue();
/*      */ 
/*      */       
/*  348 */       webServiceMBeanImpl.setWebServiceName(str1);
/*      */       
/*  350 */       String str2 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "uri").getValue();
/*      */ 
/*      */       
/*  353 */       webServiceMBeanImpl.setURI(str2);
/*      */       
/*  355 */       String str3 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "targetNamespace").getValue();
/*      */ 
/*      */       
/*  358 */       webServiceMBeanImpl.setTargetNamespace(str3);
/*      */       
/*  360 */       NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "portTypeName");
/*      */ 
/*      */       
/*  363 */       if (nSAttribute1 != null) {
/*  364 */         webServiceMBeanImpl.setPortTypeName(nSAttribute1.getValue());
/*      */       }
/*      */       
/*  367 */       NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "portName");
/*      */ 
/*      */       
/*  370 */       if (nSAttribute2 != null) {
/*  371 */         webServiceMBeanImpl.setPortName(nSAttribute2.getValue());
/*      */       }
/*      */       
/*  374 */       NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "protocol");
/*      */       
/*  376 */       if (nSAttribute3 != null) webServiceMBeanImpl.setProtocol(nSAttribute3.getValue());
/*      */       
/*  378 */       NSAttribute nSAttribute4 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "style");
/*      */ 
/*      */       
/*  381 */       if (nSAttribute4 != null) {
/*  382 */         webServiceMBeanImpl.setStyle(nSAttribute4.getValue());
/*      */       }
/*      */       
/*  385 */       NSAttribute nSAttribute5 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "responseBufferSize");
/*      */ 
/*      */       
/*  388 */       if (nSAttribute5 != null) {
/*      */         try {
/*  390 */           int i = (new Integer(nSAttribute5.getValue())).intValue();
/*  391 */           webServiceMBeanImpl.setResponseBufferSize(i);
/*  392 */         } catch (NumberFormatException numberFormatException) {
/*  393 */           throw new DDProcessingException("Attribute responseBufferSize of element web-service is not an integer.");
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  398 */       NSAttribute nSAttribute6 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "exposeWSDL");
/*      */ 
/*      */       
/*  401 */       if (nSAttribute6 != null) {
/*      */         try {
/*  403 */           boolean bool = (new Boolean(nSAttribute6.getValue())).booleanValue();
/*  404 */           webServiceMBeanImpl.setExposeWSDL(bool);
/*  405 */         } catch (NumberFormatException numberFormatException) {
/*  406 */           throw new DDProcessingException("Attribute exposeWSDL of element web-service should be true | false.");
/*      */         } 
/*      */       } else {
/*      */         
/*  410 */         webServiceMBeanImpl.setExposeWSDL(true);
/*      */       } 
/*      */       
/*  413 */       NSAttribute nSAttribute7 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "exposeHomePage");
/*      */ 
/*      */       
/*  416 */       if (nSAttribute7 != null) {
/*      */         try {
/*  418 */           boolean bool = (new Boolean(nSAttribute7.getValue())).booleanValue();
/*      */ 
/*      */           
/*  421 */           webServiceMBeanImpl.setExposeHomePage(bool);
/*  422 */         } catch (NumberFormatException numberFormatException) {
/*  423 */           throw new DDProcessingException("Attribute exposeHomePage of element web-service should be true | false.");
/*      */         } 
/*      */       } else {
/*      */         
/*  427 */         webServiceMBeanImpl.setExposeHomePage(true);
/*      */       } 
/*      */       
/*  430 */       NSAttribute nSAttribute8 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "ignoreAuthHeader");
/*      */ 
/*      */       
/*  433 */       if (nSAttribute8 != null) {
/*      */         try {
/*  435 */           boolean bool = (new Boolean(nSAttribute8.getValue())).booleanValue();
/*      */ 
/*      */           
/*  438 */           webServiceMBeanImpl.setIgnoreAuthHeader(bool);
/*  439 */         } catch (NumberFormatException numberFormatException) {
/*  440 */           throw new DDProcessingException("Attribute ignoreAuthHeader of element web-service should be true | false.");
/*      */         } 
/*      */       } else {
/*      */         
/*  444 */         webServiceMBeanImpl.setIgnoreAuthHeader(false);
/*      */       } 
/*      */       
/*  447 */       NSAttribute nSAttribute9 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "useSOAP12");
/*      */ 
/*      */       
/*  450 */       if (nSAttribute9 != null) {
/*  451 */         webServiceMBeanImpl.setUseSOAP12(Boolean.valueOf(nSAttribute9.getValue()).booleanValue());
/*      */       }
/*      */ 
/*      */       
/*  455 */       NSAttribute nSAttribute10 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "jmsUri");
/*      */ 
/*      */       
/*  458 */       if (nSAttribute10 != null) {
/*  459 */         webServiceMBeanImpl.setJmsURI(nSAttribute10.getValue());
/*      */       }
/*      */       
/*  462 */       NSAttribute nSAttribute11 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "charset");
/*      */ 
/*      */       
/*  465 */       if (nSAttribute11 != null) {
/*  466 */         webServiceMBeanImpl.setCharset(nSAttribute11.getValue());
/*      */       }
/*      */       
/*  469 */       NSAttribute nSAttribute12 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "handleAllActors");
/*      */ 
/*      */       
/*  472 */       if (nSAttribute12 != null) {
/*  473 */         boolean bool = (new Boolean(nSAttribute12.getValue())).booleanValue();
/*      */         
/*  475 */         webServiceMBeanImpl.setHandleAllActors(bool);
/*      */       } else {
/*  477 */         webServiceMBeanImpl.setHandleAllActors(true);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  482 */       this.components = new HashMap();
/*      */       
/*  484 */       XMLNode xMLNode = processSecurityElement();
/*  485 */       if (xMLNode != null) {
/*      */         
/*  487 */         new SecurityDD(xMLNode.stream());
/*  488 */         webServiceMBeanImpl.setSecurity(xMLNode);
/*      */       } 
/*      */       
/*  491 */       XMLNodeSet xMLNodeSet = processTypesElement();
/*  492 */       if (xMLNodeSet != null) webServiceMBeanImpl.setTypes(xMLNodeSet);
/*      */       
/*  494 */       TypeMappingMBean typeMappingMBean = processTypeMappingElement();
/*  495 */       if (typeMappingMBean != null) webServiceMBeanImpl.setTypeMapping(typeMappingMBean);
/*      */       
/*  497 */       ComponentsMBean componentsMBean = processComponentsElement();
/*  498 */       if (componentsMBean != null) webServiceMBeanImpl.setComponents(componentsMBean);
/*      */       
/*  500 */       OperationsMBean operationsMBean = processOperationsElement();
/*  501 */       if (operationsMBean != null) { webServiceMBeanImpl.setOperations(operationsMBean); }
/*      */       else
/*  503 */       { throw new DDProcessingException("There must be exactly one <operations> element in <web-service>", this.ph.getLocation()); }
/*      */ 
/*      */       
/*  506 */       this.ph.matchEndElement("web-service");
/*      */     } 
/*      */     
/*  509 */     return webServiceMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XMLNode processSecurityElement() throws DDProcessingException, XMLStreamException {
/*  518 */     XMLNode xMLNode = null;
/*  519 */     XMLEvent xMLEvent = this.ph.peekStartElement("security");
/*      */     
/*  521 */     if (xMLEvent != null) {
/*  522 */       xMLNode = this.ph.forkSubtree();
/*      */     }
/*      */     
/*  525 */     return xMLNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XMLNodeSet processTypesElement() throws DDProcessingException, XMLStreamException {
/*  534 */     XMLNodeSet xMLNodeSet = null;
/*  535 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("types");
/*  536 */     if (xMLEvent != null) {
/*  537 */       if (this.ph.peekStartElement() != null) {
/*  538 */         xMLNodeSet = this.ph.forkSubtrees();
/*      */       }
/*  540 */       this.ph.matchEndElement("types");
/*      */     } 
/*  542 */     return xMLNodeSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeMappingMBean processTypeMappingElement() throws DDProcessingException, XMLStreamException {
/*  551 */     TypeMappingMBeanImpl typeMappingMBeanImpl = null;
/*  552 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("type-mapping");
/*  553 */     if (xMLEvent != null) {
/*  554 */       typeMappingMBeanImpl = new TypeMappingMBeanImpl();
/*  555 */       TypeMappingEntryMBean[] arrayOfTypeMappingEntryMBean = processTypeMappingEntryElements();
/*  556 */       typeMappingMBeanImpl.setTypeMappingEntries(arrayOfTypeMappingEntryMBean);
/*  557 */       this.ph.matchEndElement("type-mapping");
/*      */     } 
/*  559 */     return typeMappingMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ComponentsMBean processComponentsElement() throws DDProcessingException, XMLStreamException {
/*  568 */     ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
/*  569 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("components");
/*  570 */     if (xMLEvent == null) return null;
/*      */     
/*  572 */     NSAttribute nSAttribute = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "useMultiplePorts");
/*      */ 
/*      */     
/*  575 */     if (nSAttribute != null) {
/*  576 */       componentsMBeanImpl.setUseMultiplePorts((new Boolean(nSAttribute.getValue())).booleanValue());
/*      */     }
/*      */ 
/*      */     
/*  580 */     ComponentMBean componentMBean = processComponent();
/*  581 */     if (componentMBean == null) {
/*  582 */       throw new DDProcessingException("There must be at least one of <stateless-ejb>,<java-class>,<stateful-java-class>,<jms-send-destination>,<jms-receive-topic>,<jms-receive-queue> in <components>", this.ph.getLocation());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  589 */     while (componentMBean != null) {
/*  590 */       if (componentMBean instanceof StatelessEJBMBean) {
/*  591 */         componentsMBeanImpl.addStatelessEJB((StatelessEJBMBean)componentMBean);
/*  592 */       } else if (componentMBean instanceof JavaClassMBean) {
/*  593 */         componentsMBeanImpl.addJavaClassComponent((JavaClassMBean)componentMBean);
/*  594 */       } else if (componentMBean instanceof StatefulJavaClassMBean) {
/*  595 */         componentsMBeanImpl.addStatefulJavaClassComponent((StatefulJavaClassMBean)componentMBean);
/*  596 */       } else if (componentMBean instanceof JMSSendDestinationMBean) {
/*  597 */         componentsMBeanImpl.addJMSSendDestination((JMSSendDestinationMBean)componentMBean);
/*  598 */       } else if (componentMBean instanceof JMSReceiveTopicMBean) {
/*  599 */         componentsMBeanImpl.addJMSReceiveTopic((JMSReceiveTopicMBean)componentMBean);
/*  600 */       } else if (componentMBean instanceof JMSReceiveQueueMBean) {
/*  601 */         componentsMBeanImpl.addJMSReceiveQueue((JMSReceiveQueueMBean)componentMBean);
/*      */       } else {
/*  603 */         throw new AssertionError(componentMBean.getClass().getName());
/*      */       } 
/*  605 */       componentMBean = processComponent();
/*      */     } 
/*  607 */     this.ph.matchEndElement("components");
/*  608 */     return componentsMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ComponentMBean processComponent() throws DDProcessingException, XMLStreamException {
/*  618 */     JMSReceiveQueueMBeanImpl jMSReceiveQueueMBeanImpl = null;
/*  619 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement(COMPONENT_CHOICES);
/*  620 */     if (xMLEvent == null) return null; 
/*  621 */     String str = xMLEvent.getName().getLocalName();
/*      */     
/*  623 */     ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "class-name", "connection-factory", "provider-url", "initial-context-factory", "connection-factory", "name" });
/*  624 */     if ("stateless-ejb".equals(str)) {
/*      */       
/*  626 */       StatelessEJBMBeanImpl statelessEJBMBeanImpl = new StatelessEJBMBeanImpl();
/*  627 */       EJBLinkMBean eJBLinkMBean = processEJBLinkElement();
/*  628 */       if (eJBLinkMBean != null) { statelessEJBMBeanImpl.setEJBLink(eJBLinkMBean); }
/*      */       else
/*  630 */       { JNDINameMBean jNDINameMBean = processOptionalJNDINameElement();
/*  631 */         if (jNDINameMBean != null) { statelessEJBMBeanImpl.setJNDIName(jNDINameMBean); }
/*      */         else
/*  633 */         { throw new DDProcessingException("Expected an element matching either <ejb-link> or <jndi-name>", this.ph.getLocation()); }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  639 */       this.ph.matchEndElement("stateless-ejb");
/*  640 */       jMSReceiveQueueMBeanImpl = statelessEJBMBeanImpl;
/*      */     }
/*  642 */     else if ("java-class".equals(str)) {
/*      */       
/*  644 */       JavaClassMBeanImpl javaClassMBeanImpl2 = new JavaClassMBeanImpl();
/*  645 */       String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name").getValue();
/*  646 */       javaClassMBeanImpl2.setClassName(str1);
/*  647 */       this.ph.matchEndElement("java-class");
/*  648 */       JavaClassMBeanImpl javaClassMBeanImpl1 = javaClassMBeanImpl2;
/*      */     }
/*  650 */     else if ("stateful-java-class".equals(str)) {
/*      */       
/*  652 */       StatefulJavaClassMBeanImpl statefulJavaClassMBeanImpl2 = new StatefulJavaClassMBeanImpl();
/*  653 */       String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name").getValue();
/*  654 */       statefulJavaClassMBeanImpl2.setClassName(str1);
/*  655 */       this.ph.matchEndElement("stateful-java-class");
/*  656 */       StatefulJavaClassMBeanImpl statefulJavaClassMBeanImpl1 = statefulJavaClassMBeanImpl2;
/*      */     }
/*  658 */     else if ("jms-send-destination".equals(str)) {
/*      */       
/*  660 */       JMSSendDestinationMBeanImpl jMSSendDestinationMBeanImpl2 = new JMSSendDestinationMBeanImpl();
/*  661 */       JNDINameMBean jNDINameMBean = processJNDINameElement();
/*  662 */       jMSSendDestinationMBeanImpl2.setJNDIName(jNDINameMBean);
/*      */       
/*  664 */       String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "connection-factory").getValue();
/*  665 */       jMSSendDestinationMBeanImpl2.setConnectionFactory(str1);
/*      */       
/*  667 */       NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "provider-url");
/*      */       
/*  669 */       if (nSAttribute1 != null) jMSSendDestinationMBeanImpl2.setProviderUrl(nSAttribute1.getValue());
/*      */       
/*  671 */       NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "initial-context-factory");
/*      */       
/*  673 */       if (nSAttribute2 != null) jMSSendDestinationMBeanImpl2.setInitialContextFactory(nSAttribute2.getValue());
/*      */       
/*  675 */       this.ph.matchEndElement("jms-send-destination");
/*  676 */       JMSSendDestinationMBeanImpl jMSSendDestinationMBeanImpl1 = jMSSendDestinationMBeanImpl2;
/*      */     }
/*  678 */     else if ("jms-receive-topic".equals(str)) {
/*      */       
/*  680 */       JMSReceiveTopicMBeanImpl jMSReceiveTopicMBeanImpl2 = new JMSReceiveTopicMBeanImpl();
/*  681 */       JNDINameMBean jNDINameMBean = processJNDINameElement();
/*  682 */       jMSReceiveTopicMBeanImpl2.setJNDIName(jNDINameMBean);
/*      */       
/*  684 */       String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "connection-factory").getValue();
/*  685 */       jMSReceiveTopicMBeanImpl2.setConnectionFactory(str1);
/*      */       
/*  687 */       NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "provider-url");
/*      */       
/*  689 */       if (nSAttribute1 != null) jMSReceiveTopicMBeanImpl2.setProviderUrl(nSAttribute1.getValue());
/*      */       
/*  691 */       NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "initial-context-factory");
/*      */       
/*  693 */       if (nSAttribute2 != null) jMSReceiveTopicMBeanImpl2.setInitialContextFactory(nSAttribute2.getValue());
/*      */       
/*  695 */       this.ph.matchEndElement("jms-receive-topic");
/*  696 */       JMSReceiveTopicMBeanImpl jMSReceiveTopicMBeanImpl1 = jMSReceiveTopicMBeanImpl2;
/*      */     }
/*  698 */     else if ("jms-receive-queue".equals(str)) {
/*      */       
/*  700 */       JMSReceiveQueueMBeanImpl jMSReceiveQueueMBeanImpl1 = new JMSReceiveQueueMBeanImpl();
/*  701 */       JNDINameMBean jNDINameMBean = processJNDINameElement();
/*  702 */       jMSReceiveQueueMBeanImpl1.setJNDIName(jNDINameMBean);
/*      */       
/*  704 */       String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "connection-factory").getValue();
/*  705 */       jMSReceiveQueueMBeanImpl1.setConnectionFactory(str1);
/*      */       
/*  707 */       NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "provider-url");
/*      */       
/*  709 */       if (nSAttribute1 != null) jMSReceiveQueueMBeanImpl1.setProviderUrl(nSAttribute1.getValue());
/*      */       
/*  711 */       NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "initial-context-factory");
/*      */       
/*  713 */       if (nSAttribute2 != null) jMSReceiveQueueMBeanImpl1.setInitialContextFactory(nSAttribute2.getValue());
/*      */       
/*  715 */       this.ph.matchEndElement("jms-receive-queue");
/*  716 */       jMSReceiveQueueMBeanImpl = jMSReceiveQueueMBeanImpl1;
/*      */     } 
/*      */ 
/*      */     
/*  720 */     if (jMSReceiveQueueMBeanImpl != null) {
/*  721 */       String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "name").getValue();
/*      */       
/*  723 */       jMSReceiveQueueMBeanImpl.setComponentName(str1);
/*      */ 
/*      */ 
/*      */       
/*  727 */       this.components.put(str1, jMSReceiveQueueMBeanImpl);
/*      */     } 
/*      */     
/*  730 */     return jMSReceiveQueueMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private EJBLinkMBean processEJBLinkElement() throws DDProcessingException, XMLStreamException {
/*  739 */     EJBLinkMBeanImpl eJBLinkMBeanImpl = null;
/*  740 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("ejb-link");
/*  741 */     if (xMLEvent != null) {
/*  742 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "path" });
/*  743 */       eJBLinkMBeanImpl = new EJBLinkMBeanImpl();
/*  744 */       String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "path").getValue();
/*      */       
/*  746 */       if (str.indexOf('#') == -1) {
/*  747 */         throw new DDProcessingException("The \"path\" attribute of <ejb-link> must have the syntax \"<jar name>#<ejb name>\"", xMLEvent.getLocation());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  753 */       eJBLinkMBeanImpl.setPath(str);
/*  754 */       this.ph.matchEndElement("ejb-link");
/*      */     } 
/*  756 */     return eJBLinkMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JNDINameMBean processOptionalJNDINameElement() throws DDProcessingException, XMLStreamException {
/*  766 */     JNDINameMBeanImpl jNDINameMBeanImpl = null;
/*  767 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("jndi-name");
/*  768 */     if (xMLEvent != null) {
/*  769 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "path" });
/*  770 */       jNDINameMBeanImpl = new JNDINameMBeanImpl();
/*  771 */       String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "path").getValue();
/*      */       
/*  773 */       jNDINameMBeanImpl.setPath(str);
/*  774 */       this.ph.matchEndElement("jndi-name");
/*      */     } 
/*  776 */     return jNDINameMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JNDINameMBean processJNDINameElement() throws DDProcessingException, XMLStreamException {
/*  787 */     JNDINameMBeanImpl jNDINameMBeanImpl = null;
/*  788 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("jndi-name");
/*  789 */     if (xMLEvent != null) {
/*  790 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "path" });
/*  791 */       jNDINameMBeanImpl = new JNDINameMBeanImpl();
/*  792 */       String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "path").getValue();
/*      */       
/*  794 */       jNDINameMBeanImpl.setPath(str);
/*  795 */       this.ph.matchEndElement("jndi-name");
/*      */     } 
/*  797 */     return jNDINameMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HandlerChainsMBean processHandlerChainsElement() throws DDProcessingException, XMLStreamException {
/*  807 */     HandlerChainsMBeanImpl handlerChainsMBeanImpl = null;
/*  808 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("handler-chains");
/*  809 */     if (xMLEvent != null) {
/*  810 */       handlerChainsMBeanImpl = new HandlerChainsMBeanImpl();
/*  811 */       HandlerChainMBean[] arrayOfHandlerChainMBean = processHandlerChainElements();
/*  812 */       handlerChainsMBeanImpl.setHandlerChains(arrayOfHandlerChainMBean);
/*  813 */       this.ph.matchEndElement("web-services");
/*      */     } 
/*  815 */     return handlerChainsMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HandlerChainMBean[] processHandlerChainElements() throws DDProcessingException, XMLStreamException {
/*  824 */     HandlerChainMBean handlerChainMBean = processHandlerChainElement();
/*  825 */     if (handlerChainMBean == null) {
/*  826 */       throw new DDProcessingException("There must be at least one <handler-chain> element in <handler-chains>", this.ph.getLocation());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  831 */     ArrayList arrayList = new ArrayList();
/*  832 */     while (handlerChainMBean != null) {
/*  833 */       arrayList.add(handlerChainMBean);
/*  834 */       handlerChainMBean = processHandlerChainElement();
/*      */     } 
/*  836 */     return (HandlerChainMBean[])arrayList.toArray(new HandlerChainMBeanImpl[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HandlerChainMBean processHandlerChainElement() throws DDProcessingException, XMLStreamException {
/*  845 */     HandlerChainMBeanImpl handlerChainMBeanImpl = null;
/*  846 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("handler-chain");
/*      */     
/*  848 */     if (xMLEvent != null) {
/*  849 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "name" });
/*  850 */       handlerChainMBeanImpl = new HandlerChainMBeanImpl();
/*  851 */       String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "name").getValue();
/*      */       
/*  853 */       handlerChainMBeanImpl.setHandlerChainName(str);
/*      */       
/*  855 */       HandlerMBean[] arrayOfHandlerMBean = processHandlerElements();
/*  856 */       handlerChainMBeanImpl.setHandlers(arrayOfHandlerMBean);
/*      */ 
/*      */       
/*  859 */       if (this.handlerChains.put(str, handlerChainMBeanImpl) != null) {
/*  860 */         throw new DDProcessingException("<handler-chain> must have a unique \"name\" attribute within the scope of a <web-services>; the name \"" + str + "\" was used in a previous <" + "handler-chain" + "> element", xMLEvent.getLocation());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  867 */       this.ph.matchEndElement("handler-chain");
/*      */     } 
/*  869 */     return handlerChainMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HandlerMBean[] processHandlerElements() throws DDProcessingException, XMLStreamException {
/*  879 */     ArrayList arrayList = new ArrayList();
/*  880 */     HandlerMBean handlerMBean = processHandlerElement();
/*  881 */     if (handlerMBean == null) {
/*  882 */       throw new DDProcessingException("There must be at least one <handler> element in <handler-chain>", this.ph.getLocation());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  887 */     while (handlerMBean != null) {
/*  888 */       arrayList.add(handlerMBean);
/*  889 */       handlerMBean = processHandlerElement();
/*      */     } 
/*  891 */     return (HandlerMBean[])arrayList.toArray(new HandlerMBean[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HandlerMBean processHandlerElement() throws DDProcessingException, XMLStreamException {
/*  900 */     HandlerMBeanImpl handlerMBeanImpl = null;
/*  901 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("handler");
/*  902 */     if (xMLEvent != null) {
/*  903 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "class-name" });
/*  904 */       handlerMBeanImpl = new HandlerMBeanImpl();
/*      */       
/*  906 */       String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name").getValue();
/*      */       
/*  908 */       handlerMBeanImpl.setClassName(str);
/*      */       
/*  910 */       InitParamsMBean initParamsMBean = processInitParamsElement();
/*  911 */       if (initParamsMBean != null) handlerMBeanImpl.setInitParams(initParamsMBean);
/*      */       
/*  913 */       this.ph.matchEndElement("handler");
/*      */     } 
/*      */     
/*  916 */     return handlerMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InitParamsMBean processInitParamsElement() throws DDProcessingException, XMLStreamException {
/*  925 */     InitParamsMBeanImpl initParamsMBeanImpl = null;
/*  926 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("init-params");
/*  927 */     if (xMLEvent != null) {
/*  928 */       initParamsMBeanImpl = new InitParamsMBeanImpl();
/*  929 */       InitParamMBean[] arrayOfInitParamMBean = processInitParamElements();
/*  930 */       initParamsMBeanImpl.setInitParams(arrayOfInitParamMBean);
/*  931 */       this.ph.matchEndElement("init-params");
/*      */     } 
/*  933 */     return initParamsMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InitParamMBean[] processInitParamElements() throws DDProcessingException, XMLStreamException {
/*  942 */     InitParamMBean initParamMBean = processInitParamElement();
/*  943 */     if (initParamMBean == null) {
/*  944 */       throw new DDProcessingException("There must be at least one <param> element in <init-params>", this.ph.getLocation());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  949 */     ArrayList arrayList = new ArrayList();
/*  950 */     while (initParamMBean != null) {
/*  951 */       arrayList.add(initParamMBean);
/*  952 */       initParamMBean = processInitParamElement();
/*      */     } 
/*  954 */     return (InitParamMBeanImpl[])arrayList.toArray(new InitParamMBeanImpl[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InitParamMBean processInitParamElement() throws DDProcessingException, XMLStreamException {
/*  963 */     InitParamMBeanImpl initParamMBeanImpl = null;
/*  964 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("init-param");
/*  965 */     if (xMLEvent != null) {
/*  966 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "name", "value" });
/*  967 */       initParamMBeanImpl = new InitParamMBeanImpl();
/*  968 */       String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "name").getValue();
/*      */       
/*  970 */       initParamMBeanImpl.setParamName(str1);
/*  971 */       String str2 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "value").getValue();
/*      */ 
/*      */ 
/*      */       
/*  975 */       initParamMBeanImpl.setParamValue(str2);
/*  976 */       this.ph.matchEndElement("init-param");
/*      */     } 
/*  978 */     return initParamMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OperationsMBean processOperationsElement() throws DDProcessingException, XMLStreamException {
/*  987 */     OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
/*  988 */     this.ph.matchStartElement("operations");
/*  989 */     OperationMBean[] arrayOfOperationMBean = processOperationElements();
/*  990 */     operationsMBeanImpl.setOperations(arrayOfOperationMBean);
/*  991 */     this.ph.matchEndElement("operations");
/*  992 */     return operationsMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OperationMBean[] processOperationElements() throws DDProcessingException, XMLStreamException {
/* 1001 */     OperationMBean operationMBean = processOperationElement();
/* 1002 */     if (operationMBean == null) {
/* 1003 */       throw new DDProcessingException("There must be at least one <operation> element in <operations>", this.ph.getLocation());
/*      */     }
/* 1005 */     ArrayList arrayList = new ArrayList();
/* 1006 */     while (operationMBean != null) {
/* 1007 */       arrayList.add(operationMBean);
/* 1008 */       operationMBean = processOperationElement();
/*      */     } 
/* 1010 */     if (arrayList.size() > 0) {
/* 1011 */       return (OperationMBeanImpl[])arrayList.toArray(new OperationMBeanImpl[0]);
/*      */     }
/* 1013 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OperationMBean processOperationElement() throws DDProcessingException, XMLStreamException {
/* 1023 */     OperationMBeanImpl operationMBeanImpl = null;
/* 1024 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("operation");
/* 1025 */     if (xMLEvent == null) return null;
/*      */     
/* 1027 */     ParsingHelper.checkAttributes((StartElement)xMLEvent, operationAttributes);
/*      */     
/* 1029 */     operationMBeanImpl = new OperationMBeanImpl();
/*      */     
/* 1031 */     boolean bool = false;
/* 1032 */     NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "name");
/*      */     
/* 1034 */     if (nSAttribute1 != null) operationMBeanImpl.setOperationName(nSAttribute1.getValue()); 
/* 1035 */     if ("*".equals(nSAttribute1)) bool = true;
/*      */     
/* 1037 */     NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "method");
/*      */     
/* 1039 */     if (nSAttribute2 != null && !"*".equals(nSAttribute2)) {
/* 1040 */       if (bool) {
/* 1041 */         throw new DDProcessingException("Cannot set \"method\" attribute on <operation> if setting value of attribute \"name\" to \"*\"", xMLEvent.getLocation());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1047 */       operationMBeanImpl.setMethod(nSAttribute2.getValue());
/*      */     } 
/*      */     
/* 1050 */     NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "handler-chain");
/*      */     
/* 1052 */     if (nSAttribute3 != null) {
/* 1053 */       HandlerChainMBean handlerChainMBean = (HandlerChainMBean)this.handlerChains.get(nSAttribute3.getValue());
/*      */       
/* 1055 */       if (handlerChainMBean == null) {
/* 1056 */         throw new DDProcessingException("Could not locate the referenced <handler-chain> with name = \"" + nSAttribute3.getValue() + "\" when processing <" + "operation" + ">", xMLEvent.getLocation());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1062 */       operationMBeanImpl.setHandlerChainName(nSAttribute3.getValue());
/* 1063 */       operationMBeanImpl.setHandlerChain(handlerChainMBean);
/*      */     } 
/*      */ 
/*      */     
/* 1067 */     if (nSAttribute1 == null && nSAttribute2 == null && nSAttribute3 == null) {
/* 1068 */       throw new DDProcessingException("At least one of attributes name, method or handler-chain must be specified on <operation>", xMLEvent.getLocation());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1075 */     NSAttribute nSAttribute4 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "component");
/*      */     
/* 1077 */     if (nSAttribute4 != null) {
/* 1078 */       ComponentMBean componentMBean = (ComponentMBean)this.components.get(nSAttribute4.getValue());
/* 1079 */       if (componentMBean == null) {
/* 1080 */         throw new DDProcessingException("Could not locate the referenced component with name attribute = " + nSAttribute4.getValue() + " when processing <" + "operation" + ">", xMLEvent.getLocation());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1087 */       operationMBeanImpl.setComponentName(nSAttribute4.getValue());
/* 1088 */       operationMBeanImpl.setComponent(componentMBean);
/*      */     } 
/*      */ 
/*      */     
/* 1092 */     NSAttribute nSAttribute5 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "invocation-style");
/*      */     
/* 1094 */     if (nSAttribute5 != null) {
/* 1095 */       String str = nSAttribute5.getValue();
/* 1096 */       if (!"request-response".equalsIgnoreCase(str) && !"one-way".equalsIgnoreCase(str))
/*      */       {
/*      */         
/* 1099 */         throw new DDProcessingException("The value \"" + str + "\" of attribute \"" + "invocation-style" + "\" must be either \"" + "one-way" + "\" or \"" + "request-response" + "\"", xMLEvent.getLocation());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1105 */       operationMBeanImpl.setInvocationStyle(str);
/*      */     } 
/*      */ 
/*      */     
/* 1109 */     NSAttribute nSAttribute6 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "namespace");
/*      */     
/* 1111 */     if (nSAttribute6 != null) {
/* 1112 */       String str = nSAttribute6.getValue();
/* 1113 */       operationMBeanImpl.setNamespace(str);
/*      */     } 
/*      */     
/* 1116 */     NSAttribute nSAttribute7 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "portTypeName");
/*      */ 
/*      */     
/* 1119 */     if (nSAttribute7 != null) {
/* 1120 */       String str = nSAttribute7.getValue();
/* 1121 */       operationMBeanImpl.setPortTypeName(str);
/*      */     } 
/*      */     
/* 1124 */     NSAttribute nSAttribute8 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "style");
/*      */ 
/*      */     
/* 1127 */     if (nSAttribute8 != null) {
/* 1128 */       String str = nSAttribute8.getValue();
/* 1129 */       operationMBeanImpl.setStyle(str);
/*      */     } 
/*      */     
/* 1132 */     NSAttribute nSAttribute9 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "conversationPhase");
/*      */ 
/*      */     
/* 1135 */     if (nSAttribute9 != null) {
/* 1136 */       String str = nSAttribute9.getValue();
/* 1137 */       operationMBeanImpl.setConversationPhase(str);
/*      */     } 
/*      */     
/* 1140 */     NSAttribute nSAttribute10 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "in-security-spec");
/*      */ 
/*      */     
/* 1143 */     if (nSAttribute10 != null) {
/* 1144 */       String str = nSAttribute10.getValue();
/* 1145 */       operationMBeanImpl.setInSecuritySpec(str);
/*      */     } 
/*      */     
/* 1148 */     NSAttribute nSAttribute11 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "out-security-spec");
/*      */ 
/*      */     
/* 1151 */     if (nSAttribute11 != null) {
/* 1152 */       String str = nSAttribute11.getValue();
/* 1153 */       operationMBeanImpl.setOutSecuritySpec(str);
/*      */     } 
/*      */     
/* 1156 */     ParamsMBean paramsMBean = processParamsElement();
/* 1157 */     if (paramsMBean != null) operationMBeanImpl.setParams(paramsMBean);
/*      */     
/* 1159 */     ReliableDeliveryMBean reliableDeliveryMBean = processReliableElement();
/* 1160 */     if (reliableDeliveryMBean != null) operationMBeanImpl.setReliableDelivery(reliableDeliveryMBean);
/*      */     
/* 1162 */     this.ph.matchEndElement("operation");
/*      */     
/* 1164 */     return operationMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ParamsMBean processParamsElement() throws DDProcessingException, XMLStreamException {
/* 1173 */     ParamsMBeanImpl paramsMBeanImpl = null;
/* 1174 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("params");
/* 1175 */     if (xMLEvent != null) {
/* 1176 */       paramsMBeanImpl = new ParamsMBeanImpl();
/*      */       
/* 1178 */       ParamMBean[] arrayOfParamMBean = processParamElements();
/* 1179 */       if (arrayOfParamMBean != null) {
/* 1180 */         paramsMBeanImpl.setParams(arrayOfParamMBean);
/*      */       }
/*      */       
/* 1183 */       ReturnParamMBean returnParamMBean = processReturnElement();
/* 1184 */       if (returnParamMBean != null) paramsMBeanImpl.setReturnParam(returnParamMBean);
/*      */       
/* 1186 */       FaultMBean[] arrayOfFaultMBean = processFaultElements();
/* 1187 */       if (arrayOfFaultMBean != null) {
/* 1188 */         paramsMBeanImpl.setFaults(arrayOfFaultMBean);
/*      */       }
/*      */       
/* 1191 */       this.ph.matchEndElement("params");
/*      */     } 
/*      */     
/* 1194 */     if (paramsMBeanImpl == null || (paramsMBeanImpl.getParams() == null && paramsMBeanImpl.getReturnParam() == null)) {
/* 1195 */       return null;
/*      */     }
/* 1197 */     return paramsMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ParamMBean[] processParamElements() throws DDProcessingException, XMLStreamException {
/* 1207 */     ArrayList arrayList = new ArrayList();
/* 1208 */     ParamMBean paramMBean = processParamElement();
/* 1209 */     while (paramMBean != null) {
/* 1210 */       arrayList.add(paramMBean);
/* 1211 */       paramMBean = processParamElement();
/*      */     } 
/* 1213 */     return (ParamMBean[])arrayList.toArray(new ParamMBean[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ParamMBean processParamElement() throws DDProcessingException, XMLStreamException {
/* 1222 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("param");
/* 1223 */     if (xMLEvent == null) return null;
/*      */ 
/*      */     
/* 1226 */     ParsingHelper.checkAttributes((StartElement)xMLEvent, paramAttributes);
/*      */     
/* 1228 */     ParamMBeanImpl paramMBeanImpl = new ParamMBeanImpl();
/*      */     
/* 1230 */     NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "name");
/* 1231 */     if (nSAttribute1 != null) paramMBeanImpl.setParamName(nSAttribute1.getValue());
/*      */     
/* 1233 */     String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "style").getValue();
/* 1234 */     if (!"in".equalsIgnoreCase(str) && !"inout".equalsIgnoreCase(str) && !"out".equalsIgnoreCase(str))
/*      */     {
/*      */       
/* 1237 */       throw new DDProcessingException("Unrecognized value \"" + str + "\" for " + "style" + " attribute of <" + "param" + ">; the value must be set to either one of \"" + "in" + "\", \"" + "inout" + "\" or \"" + "out" + "\"", xMLEvent.getLocation());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1245 */     paramMBeanImpl.setParamStyle(str);
/*      */ 
/*      */     
/* 1248 */     NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "location");
/*      */     
/* 1250 */     if (nSAttribute2 != null) {
/* 1251 */       String str1 = nSAttribute2.getValue();
/* 1252 */       if (!"header".equals(str1) && !"body".equals(str1) && !"attachment".equals(str1))
/*      */       {
/* 1254 */         throw new DDProcessingException("Unrecognized value \"" + str1 + "\" for " + "location" + " attribute of <" + "param" + ">; the value must be set to either \"" + "body" + "\" or \"" + "header" + "\" or \"" + "attachment" + "\"", xMLEvent.getLocation());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1262 */       paramMBeanImpl.setLocation(str1);
/*      */     } 
/*      */ 
/*      */     
/* 1266 */     NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "implicit");
/*      */     
/* 1268 */     if (nSAttribute3 != null) {
/* 1269 */       if ("true".equalsIgnoreCase(nSAttribute3.getValue())) {
/* 1270 */         paramMBeanImpl.setImplicit(true);
/* 1271 */       } else if ("false".equalsIgnoreCase(nSAttribute3.getValue())) {
/* 1272 */         paramMBeanImpl.setImplicit(false);
/*      */       } else {
/* 1274 */         throw new DDProcessingException("Unrecognized value \"" + nSAttribute3.getValue() + "\" for " + "implicit" + " attribute of <" + "in" + ">; the value must be set to either \"True\" or \"False\"", xMLEvent.getLocation());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1283 */     NSAttribute nSAttribute4 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "type");
/*      */     
/* 1285 */     paramMBeanImpl.setParamType(nSAttribute4.getValueAsXMLName());
/*      */ 
/*      */     
/* 1288 */     NSAttribute nSAttribute5 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "class-name");
/* 1289 */     if (nSAttribute5 != null) paramMBeanImpl.setClassName(nSAttribute5.getValue());
/*      */     
/* 1291 */     this.ph.matchEndElement("param");
/* 1292 */     return paramMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReturnParamMBean processReturnElement() throws DDProcessingException, XMLStreamException {
/* 1301 */     ReturnParamMBeanImpl returnParamMBeanImpl = null;
/* 1302 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("return-param");
/* 1303 */     if (xMLEvent != null) {
/* 1304 */       returnParamMBeanImpl = new ReturnParamMBeanImpl();
/*      */       
/* 1306 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, returnAttributes);
/*      */       
/* 1308 */       NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "name");
/* 1309 */       if (nSAttribute1 != null) returnParamMBeanImpl.setParamName(nSAttribute1.getValue());
/*      */       
/* 1311 */       NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "location");
/*      */       
/* 1313 */       if (nSAttribute2 != null) {
/* 1314 */         String str = nSAttribute2.getValue();
/* 1315 */         if (!"header".equals(str) && !"body".equals(str) && !"attachment".equals(str))
/*      */         {
/* 1317 */           throw new DDProcessingException("Unrecognized value \"" + str + "\" for " + "location" + " attribute of <" + "param" + ">; the value must be set to either \"" + "body" + "\" or \"" + "header" + "\" or " + "attachment", xMLEvent.getLocation());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1325 */         returnParamMBeanImpl.setLocation(str);
/*      */       } 
/*      */ 
/*      */       
/* 1329 */       NSAttribute nSAttribute3 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "type");
/*      */       
/* 1331 */       returnParamMBeanImpl.setParamType(nSAttribute3.getValueAsXMLName());
/*      */       
/* 1333 */       NSAttribute nSAttribute4 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "class-name");
/* 1334 */       if (nSAttribute4 != null) returnParamMBeanImpl.setClassName(nSAttribute4.getValue());
/*      */       
/* 1336 */       this.ph.matchEndElement("return-param");
/*      */     } 
/* 1338 */     return returnParamMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReliableDeliveryMBean processReliableElement() throws DDProcessingException, XMLStreamException {
/* 1347 */     ReliableDeliveryMBeanImpl reliableDeliveryMBeanImpl = null;
/* 1348 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("reliable-delivery");
/* 1349 */     if (xMLEvent != null) {
/* 1350 */       reliableDeliveryMBeanImpl = new ReliableDeliveryMBeanImpl();
/*      */       
/* 1352 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "duplicate-elimination", "retries", "retry-interval", "persist-duration", "in-order-delivery" });
/*      */       
/* 1354 */       NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "duplicate-elimination");
/* 1355 */       if (nSAttribute1 != null) {
/* 1356 */         if ("true".equalsIgnoreCase(nSAttribute1.getValue())) {
/* 1357 */           reliableDeliveryMBeanImpl.setDuplicateElimination(true);
/* 1358 */         } else if ("false".equalsIgnoreCase(nSAttribute1.getValue())) {
/* 1359 */           reliableDeliveryMBeanImpl.setDuplicateElimination(false);
/*      */         } else {
/* 1361 */           throw new DDProcessingException("Unrecognized value \"" + nSAttribute1.getValue() + "\" for " + "duplicate-elimination" + " attribute of <" + "reliable-delivery" + ">; the value must be set to either \"True\" or \"False\"", xMLEvent.getLocation());
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1369 */       NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "retries");
/* 1370 */       if (nSAttribute2 != null) {
/*      */         try {
/* 1372 */           reliableDeliveryMBeanImpl.setRetries(Integer.parseInt(nSAttribute2.getValue()));
/* 1373 */         } catch (NumberFormatException numberFormatException) {
/* 1374 */           throw new DDProcessingException("Unrecognized value \"" + nSAttribute2.getValue() + "\" for " + "retries" + " attribute of <" + "reliable-delivery" + ">; the value must be set to an integer", xMLEvent.getLocation());
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1382 */       NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "retry-interval");
/* 1383 */       if (nSAttribute3 != null) {
/*      */         try {
/* 1385 */           reliableDeliveryMBeanImpl.setRetryInterval(Integer.parseInt(nSAttribute3.getValue()));
/* 1386 */         } catch (NumberFormatException numberFormatException) {
/* 1387 */           throw new DDProcessingException("Unrecognized value \"" + nSAttribute3.getValue() + "\" for " + "retry-interval" + " attribute of <" + "reliable-delivery" + ">; the value must be set to an integer", xMLEvent.getLocation());
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1395 */       NSAttribute nSAttribute4 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "persist-duration");
/* 1396 */       if (nSAttribute4 != null) {
/*      */         try {
/* 1398 */           reliableDeliveryMBeanImpl.setPersistDuration(Integer.parseInt(nSAttribute4.getValue()));
/* 1399 */         } catch (NumberFormatException numberFormatException) {
/* 1400 */           throw new DDProcessingException("Unrecognized value \"" + nSAttribute4.getValue() + "\" for " + "persist-duration" + " attribute of <" + "reliable-delivery" + ">; the value must be set to an integer", xMLEvent.getLocation());
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1408 */       NSAttribute nSAttribute5 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "in-order-delivery");
/* 1409 */       if (nSAttribute5 != null) {
/* 1410 */         if ("true".equalsIgnoreCase(nSAttribute5.getValue())) {
/* 1411 */           reliableDeliveryMBeanImpl.setInOrderDelivery(true);
/* 1412 */         } else if ("false".equalsIgnoreCase(nSAttribute5.getValue())) {
/* 1413 */           reliableDeliveryMBeanImpl.setInOrderDelivery(false);
/*      */         } else {
/* 1415 */           throw new DDProcessingException("Unrecognized value \"" + nSAttribute5.getValue() + "\" for " + "in-order-delivery" + " attribute of <" + "reliable-delivery" + ">; the value must be set to either \"True\" or \"False\"", xMLEvent.getLocation());
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1423 */       this.ph.matchEndElement("reliable-delivery");
/*      */     } 
/* 1425 */     return reliableDeliveryMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FaultMBean[] processFaultElements() throws DDProcessingException, XMLStreamException {
/* 1434 */     ArrayList arrayList = new ArrayList();
/* 1435 */     FaultMBean faultMBean = processFaultElement();
/* 1436 */     while (faultMBean != null) {
/* 1437 */       arrayList.add(faultMBean);
/* 1438 */       faultMBean = processFaultElement();
/*      */     } 
/*      */     
/* 1441 */     if (arrayList.size() == 0) {
/* 1442 */       return null;
/*      */     }
/* 1444 */     return (FaultMBean[])arrayList.toArray(new FaultMBean[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FaultMBean processFaultElement() throws DDProcessingException, XMLStreamException {
/* 1453 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("fault");
/* 1454 */     if (xMLEvent == null) return null;
/*      */     
/* 1456 */     ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "name", "class-name", "type" });
/*      */     
/* 1458 */     FaultMBeanImpl faultMBeanImpl = new FaultMBeanImpl();
/*      */     
/* 1460 */     NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "name");
/* 1461 */     if (nSAttribute1 != null) faultMBeanImpl.setFaultName(nSAttribute1.getValue());
/*      */     
/* 1463 */     NSAttribute nSAttribute2 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "type");
/*      */     
/* 1465 */     faultMBeanImpl.setFaultType(nSAttribute2.getValueAsXMLName());
/*      */ 
/*      */     
/* 1468 */     NSAttribute nSAttribute3 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name");
/* 1469 */     if (nSAttribute3 != null) faultMBeanImpl.setClassName(nSAttribute3.getValue());
/*      */     
/* 1471 */     this.ph.matchEndElement("fault");
/* 1472 */     return faultMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeMappingEntryMBean[] processTypeMappingEntryElements() throws DDProcessingException, XMLStreamException {
/* 1481 */     TypeMappingEntryMBean typeMappingEntryMBean = processTypeMappingEntryElement();
/*      */     
/* 1483 */     ArrayList arrayList = new ArrayList();
/* 1484 */     while (typeMappingEntryMBean != null) {
/* 1485 */       arrayList.add(typeMappingEntryMBean);
/* 1486 */       typeMappingEntryMBean = processTypeMappingEntryElement();
/*      */     } 
/* 1488 */     if (arrayList.size() > 0) {
/* 1489 */       return (TypeMappingEntryMBeanImpl[])arrayList.toArray(new TypeMappingEntryMBeanImpl[0]);
/*      */     }
/* 1491 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeMappingEntryMBean processTypeMappingEntryElement() throws DDProcessingException, XMLStreamException {
/* 1501 */     TypeMappingEntryMBeanImpl typeMappingEntryMBeanImpl = null;
/* 1502 */     XMLEvent xMLEvent = this.ph.matchOptionalStartElement("type-mapping-entry");
/* 1503 */     if (xMLEvent != null) {
/* 1504 */       typeMappingEntryMBeanImpl = new TypeMappingEntryMBeanImpl();
/*      */       
/* 1506 */       ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "class-name", "element", "serializer", "deserializer", "type" });
/*      */       
/* 1508 */       String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name").getValue();
/*      */       
/* 1510 */       typeMappingEntryMBeanImpl.setClassName(str);
/*      */       
/* 1512 */       NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "element");
/*      */       
/* 1514 */       if (nSAttribute1 != null) {
/* 1515 */         typeMappingEntryMBeanImpl.setElementName(nSAttribute1.getValueAsXMLName());
/*      */       } else {
/* 1517 */         NSAttribute nSAttribute = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "type");
/* 1518 */         if (nSAttribute != null) {
/* 1519 */           typeMappingEntryMBeanImpl.setXSDTypeName(nSAttribute.getValueAsXMLName());
/*      */         } else {
/* 1521 */           throw new DDProcessingException("Either attribute type or element must be specified for element <type-mapping>", xMLEvent.getLocation());
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1529 */       NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "serializer");
/* 1530 */       if (nSAttribute2 != null) {
/* 1531 */         typeMappingEntryMBeanImpl.setSerializerName(nSAttribute2.getValue());
/*      */       }
/*      */       
/* 1534 */       NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "deserializer");
/* 1535 */       if (nSAttribute3 != null) {
/* 1536 */         typeMappingEntryMBeanImpl.setDeserializerName(nSAttribute3.getValue());
/*      */       }
/*      */       
/* 1539 */       this.ph.matchEndElement("type-mapping-entry");
/*      */     } 
/*      */     
/* 1542 */     return typeMappingEntryMBeanImpl;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] paramArrayOfString) throws Exception {
/* 1548 */     DDLoader dDLoader = new DDLoader();
/* 1549 */     FileInputStream fileInputStream = new FileInputStream(paramArrayOfString[0]);
/* 1550 */     WebServicesMBeanImpl webServicesMBeanImpl = (WebServicesMBeanImpl)dDLoader.load(fileInputStream);
/* 1551 */     XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(System.out);
/*      */     
/* 1553 */     xMLOutputStream.add(webServicesMBeanImpl.toXML(0));
/* 1554 */     xMLOutputStream.flush();
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\DDLoader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */