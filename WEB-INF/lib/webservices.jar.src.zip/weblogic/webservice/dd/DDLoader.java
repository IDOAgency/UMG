package weblogic.webservice.dd;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import weblogic.management.descriptors.webservice.ComponentMBean;
import weblogic.management.descriptors.webservice.ComponentsMBean;
import weblogic.management.descriptors.webservice.ComponentsMBeanImpl;
import weblogic.management.descriptors.webservice.EJBLinkMBean;
import weblogic.management.descriptors.webservice.EJBLinkMBeanImpl;
import weblogic.management.descriptors.webservice.FaultMBean;
import weblogic.management.descriptors.webservice.FaultMBeanImpl;
import weblogic.management.descriptors.webservice.HandlerChainMBean;
import weblogic.management.descriptors.webservice.HandlerChainMBeanImpl;
import weblogic.management.descriptors.webservice.HandlerChainsMBean;
import weblogic.management.descriptors.webservice.HandlerChainsMBeanImpl;
import weblogic.management.descriptors.webservice.HandlerMBean;
import weblogic.management.descriptors.webservice.HandlerMBeanImpl;
import weblogic.management.descriptors.webservice.InitParamMBean;
import weblogic.management.descriptors.webservice.InitParamMBeanImpl;
import weblogic.management.descriptors.webservice.InitParamsMBean;
import weblogic.management.descriptors.webservice.InitParamsMBeanImpl;
import weblogic.management.descriptors.webservice.JMSReceiveQueueMBean;
import weblogic.management.descriptors.webservice.JMSReceiveQueueMBeanImpl;
import weblogic.management.descriptors.webservice.JMSReceiveTopicMBean;
import weblogic.management.descriptors.webservice.JMSReceiveTopicMBeanImpl;
import weblogic.management.descriptors.webservice.JMSSendDestinationMBean;
import weblogic.management.descriptors.webservice.JMSSendDestinationMBeanImpl;
import weblogic.management.descriptors.webservice.JNDINameMBean;
import weblogic.management.descriptors.webservice.JNDINameMBeanImpl;
import weblogic.management.descriptors.webservice.JavaClassMBean;
import weblogic.management.descriptors.webservice.JavaClassMBeanImpl;
import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.OperationMBeanImpl;
import weblogic.management.descriptors.webservice.OperationsMBean;
import weblogic.management.descriptors.webservice.OperationsMBeanImpl;
import weblogic.management.descriptors.webservice.ParamMBean;
import weblogic.management.descriptors.webservice.ParamMBeanImpl;
import weblogic.management.descriptors.webservice.ParamsMBean;
import weblogic.management.descriptors.webservice.ParamsMBeanImpl;
import weblogic.management.descriptors.webservice.ReliableDeliveryMBean;
import weblogic.management.descriptors.webservice.ReliableDeliveryMBeanImpl;
import weblogic.management.descriptors.webservice.ReturnParamMBean;
import weblogic.management.descriptors.webservice.ReturnParamMBeanImpl;
import weblogic.management.descriptors.webservice.StatefulJavaClassMBean;
import weblogic.management.descriptors.webservice.StatefulJavaClassMBeanImpl;
import weblogic.management.descriptors.webservice.StatelessEJBMBean;
import weblogic.management.descriptors.webservice.StatelessEJBMBeanImpl;
import weblogic.management.descriptors.webservice.TypeMappingEntryMBean;
import weblogic.management.descriptors.webservice.TypeMappingEntryMBeanImpl;
import weblogic.management.descriptors.webservice.TypeMappingMBean;
import weblogic.management.descriptors.webservice.TypeMappingMBeanImpl;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServiceMBeanImpl;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
import weblogic.utils.AssertionError;
import weblogic.utils.jars.VirtualJarFile;
import weblogic.xml.security.specs.SecurityDD;
import weblogic.xml.stream.StartElement;
import weblogic.xml.stream.XMLEvent;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeSet;

public final class DDLoader {
  private static final String WS_DD_PATH = "WEB-INF/web-services.xml";
  
  private static final String WEB_SERVICES = "web-services";
  
  private static final String WEB_SERVICE = "web-service";
  
  private static final String COMPONENTS = "components";
  
  private static final String OPERATIONS = "operations";
  
  private static final String SECURITY = "security";
  
  private static final String TYPES = "types";
  
  private static final String TYPE_MAPPING = "type-mapping";
  
  private static final String TYPE_MAPPING_ENTRY = "type-mapping-entry";
  
  private static final String STATELESS_EJB = "stateless-ejb";
  
  private static final String JAVA_CLASS = "java-class";
  
  private static final String STATEFUL_JAVA_CLASS = "stateful-java-class";
  
  private static final String HANDLER = "handler";
  
  private static final String HANDLER_CHAIN = "handler-chain";
  
  private static final String HANDLER_CHAINS = "handler-chains";
  
  private static final String JMS_SEND_DESTINATION = "jms-send-destination";
  
  private static final String JMS_RECEIVE_TOPIC = "jms-receive-topic";
  
  private static final String JMS_RECEIVE_QUEUE = "jms-receive-queue";
  
  private static final String EJB_LINK = "ejb-link";
  
  private static final String JNDI_NAME = "jndi-name";
  
  private static final String INVOKE_HANDLER = "invoke-handler";
  
  private static final String INIT_PARAM = "init-param";
  
  private static final String INIT_PARAMS = "init-params";
  
  private static final String PARAM = "param";
  
  private static final String FAULT = "fault";
  
  private static final String PARAMS = "params";
  
  private static final String OPERATION = "operation";
  
  private static final String RELIABLE_DELIVERY = "reliable-delivery";
  
  private static final String DUPLICATE_ELIMINATION = "duplicate-elimination";
  
  private static final String RETRIES = "retries";
  
  private static final String RETRY_INTERVAL = "retry-interval";
  
  private static final String PERSIST_DURATION = "persist-duration";
  
  private static final String IN_ORDER_DELIVERY = "in-order-delivery";
  
  private static final String RETURN_PARAM = "return-param";
  
  private static final String ELEMENT = "element";
  
  private static final String TYPE = "type";
  
  private static final String SERIALIZER = "serializer";
  
  private static final String DESERIALIZER = "deserializer";
  
  private static final String NAME = "name";
  
  private static final String CLASS_NAME = "class-name";
  
  private static final String PATH = "path";
  
  private static final String VALUE = "value";
  
  private static final String METHOD = "method";
  
  private static final String COMPONENT = "component";
  
  private static final String URI = "uri";
  
  private static final String TARGET_NAMESPACE = "targetNamespace";
  
  private static final String USE_SOAP12 = "useSOAP12";
  
  private static final String JMS_URI = "jmsUri";
  
  private static final String CHARSET = "charset";
  
  private static final String PORT_TYPE_NAME = "portTypeName";
  
  private static final String CONVERSATION_PHASE = "conversationPhase";
  
  private static final String IN_SECURITY_SPEC = "in-security-spec";
  
  private static final String OUT_SECURITY_SPEC = "out-security-spec";
  
  private static final String PORT_NAME = "portName";
  
  private static final String PROTOCOL = "protocol";
  
  private static final String JAVA_TYPE = "java-type";
  
  private static final String CONNECTION_FACTORY = "connection-factory";
  
  private static final String PROVIDER_URL = "provider-url";
  
  private static final String INITIAL_CONTEXT_FACTORY = "initial-context-factory";
  
  private static final String INVOCATION_STYLE = "invocation-style";
  
  private static final String NAMESPACE = "namespace";
  
  private static final String IMPLICIT = "implicit";
  
  private static final String LOCATION = "location";
  
  private static final String STYLE = "style";
  
  private static final String ONE_WAY = "one-way";
  
  private static final String REQUEST_RESPONSE = "request-response";
  
  private static final String HEADER = "header";
  
  private static final String BODY = "body";
  
  private static final String ATTACHMENT = "attachment";
  
  private static final String IN = "in";
  
  private static final String INOUT = "inout";
  
  private static final String OUT = "out";
  
  private static final String USE_MULTIPLE_PORTS = "useMultiplePorts";
  
  private static final String RESPONSE_BUFFER_SIZE = "responseBufferSize";
  
  private static final String EXPOSE_WSDL = "exposeWSDL";
  
  private static final String EXPOSE_HOME_PAGE = "exposeHomePage";
  
  private static final String IGNORE_AUTH_HEADER = "ignoreAuthHeader";
  
  private static final String HANDLE_ALL_ACTORS = "handleAllActors";
  
  private static final String[] COMPONENT_CHOICES = { "stateless-ejb", "java-class", "stateful-java-class", "handler-chain", "jms-send-destination", "jms-receive-topic", "jms-receive-queue" };
  
  public static final String[] operationAttributes = { "name", "method", "handler-chain", "component", "invocation-style", "namespace", "portTypeName", "conversationPhase", "in-security-spec", "out-security-spec" };
  
  public static final String[] paramAttributes = { "name", "style", "location", "implicit", "class-name", "type" };
  
  public static final String[] webserviceAttributes = { 
      "name", "uri", "targetNamespace", "portTypeName", "portName", "protocol", "style", "useSOAP12", "exposeWSDL", "jmsUri", 
      "charset", "responseBufferSize", "exposeHomePage", "ignoreAuthHeader", "handleAllActors" };
  
  public static final String[] returnAttributes = { "name", "location", "type", "class-name" };
  
  private Map handlerChains = new HashMap();
  
  private Map components = new HashMap();
  
  private ParsingHelper ph;
  
  public WebServicesMBean load(JarFile paramJarFile) throws DDProcessingException {
    inputStream = null;
    try {
      ZipEntry zipEntry = paramJarFile.getEntry("WEB-INF/web-services.xml");
      if (zipEntry == null)
        return null; 
      inputStream = paramJarFile.getInputStream(zipEntry);
      WebServicesMBean webServicesMBean = load(inputStream);
      return webServicesMBean;
    } catch (IOException iOException) {
      throw new DDProcessingException("Could not read deployment descriptor", iOException);
    } finally {
      try {
        if (inputStream != null)
          inputStream.close(); 
      } catch (Throwable throwable) {}
    } 
  }
  
  public WebServicesMBean load(VirtualJarFile paramVirtualJarFile) throws DDProcessingException {
    inputStream = null;
    try {
      ZipEntry zipEntry = paramVirtualJarFile.getEntry("WEB-INF/web-services.xml");
      if (zipEntry == null)
        return null; 
      inputStream = paramVirtualJarFile.getInputStream(zipEntry);
      WebServicesMBean webServicesMBean = load(inputStream);
      return webServicesMBean;
    } catch (IOException iOException) {
      throw new DDProcessingException("Could not read deployment descriptor", iOException);
    } finally {
      try {
        if (inputStream != null)
          inputStream.close(); 
      } catch (Throwable throwable) {}
    } 
  }
  
  public WebServicesMBean load(InputStream paramInputStream) throws DDProcessingException {
    try {
      this.ph = new ParsingHelper(paramInputStream);
      WebServicesMBean webServicesMBean = processWebServicesElement();
      this.ph.matchDocumentEnd();
      return webServicesMBean;
    } catch (XMLStreamException xMLStreamException) {
      throw new DDProcessingException("Problem parsing deployment descriptor", xMLStreamException);
    } 
  }
  
  private WebServicesMBean processWebServicesElement() throws DDProcessingException, XMLStreamException {
    WebServicesMBeanImpl webServicesMBeanImpl = new WebServicesMBeanImpl();
    this.ph.matchStartElement("web-services");
    HandlerChainsMBean handlerChainsMBean = processHandlerChainsElement();
    if (handlerChainsMBean != null)
      webServicesMBeanImpl.setHandlerChains(handlerChainsMBean); 
    WebServiceMBean[] arrayOfWebServiceMBean = processWebServiceElements();
    webServicesMBeanImpl.setWebServices(arrayOfWebServiceMBean);
    this.ph.matchEndElement("web-services");
    return webServicesMBeanImpl;
  }
  
  private WebServiceMBean[] processWebServiceElements() throws DDProcessingException, XMLStreamException {
    WebServiceMBean webServiceMBean = processWebServiceElement();
    if (webServiceMBean == null)
      throw new DDProcessingException("There must be at least one <web-service> element in <web-services>", this.ph.getLocation()); 
    ArrayList arrayList = new ArrayList();
    while (webServiceMBean != null) {
      arrayList.add(webServiceMBean);
      webServiceMBean = processWebServiceElement();
    } 
    if (arrayList.size() > 0)
      return (WebServiceMBeanImpl[])arrayList.toArray(new WebServiceMBeanImpl[0]); 
    return null;
  }
  
  private WebServiceMBean processWebServiceElement() throws DDProcessingException, XMLStreamException {
    WebServiceMBeanImpl webServiceMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("web-service");
    if (xMLEvent != null) {
      webServiceMBeanImpl = new WebServiceMBeanImpl();
      StartElement startElement = (StartElement)xMLEvent;
      ParsingHelper.checkAttributes(startElement, webserviceAttributes);
      String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "name").getValue();
      webServiceMBeanImpl.setWebServiceName(str1);
      String str2 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "uri").getValue();
      webServiceMBeanImpl.setURI(str2);
      String str3 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "targetNamespace").getValue();
      webServiceMBeanImpl.setTargetNamespace(str3);
      NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "portTypeName");
      if (nSAttribute1 != null)
        webServiceMBeanImpl.setPortTypeName(nSAttribute1.getValue()); 
      NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "portName");
      if (nSAttribute2 != null)
        webServiceMBeanImpl.setPortName(nSAttribute2.getValue()); 
      NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "protocol");
      if (nSAttribute3 != null)
        webServiceMBeanImpl.setProtocol(nSAttribute3.getValue()); 
      NSAttribute nSAttribute4 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "style");
      if (nSAttribute4 != null)
        webServiceMBeanImpl.setStyle(nSAttribute4.getValue()); 
      NSAttribute nSAttribute5 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "responseBufferSize");
      if (nSAttribute5 != null)
        try {
          int i = (new Integer(nSAttribute5.getValue())).intValue();
          webServiceMBeanImpl.setResponseBufferSize(i);
        } catch (NumberFormatException numberFormatException) {
          throw new DDProcessingException("Attribute responseBufferSize of element web-service is not an integer.");
        }  
      NSAttribute nSAttribute6 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "exposeWSDL");
      if (nSAttribute6 != null) {
        try {
          boolean bool = (new Boolean(nSAttribute6.getValue())).booleanValue();
          webServiceMBeanImpl.setExposeWSDL(bool);
        } catch (NumberFormatException numberFormatException) {
          throw new DDProcessingException("Attribute exposeWSDL of element web-service should be true | false.");
        } 
      } else {
        webServiceMBeanImpl.setExposeWSDL(true);
      } 
      NSAttribute nSAttribute7 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "exposeHomePage");
      if (nSAttribute7 != null) {
        try {
          boolean bool = (new Boolean(nSAttribute7.getValue())).booleanValue();
          webServiceMBeanImpl.setExposeHomePage(bool);
        } catch (NumberFormatException numberFormatException) {
          throw new DDProcessingException("Attribute exposeHomePage of element web-service should be true | false.");
        } 
      } else {
        webServiceMBeanImpl.setExposeHomePage(true);
      } 
      NSAttribute nSAttribute8 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "ignoreAuthHeader");
      if (nSAttribute8 != null) {
        try {
          boolean bool = (new Boolean(nSAttribute8.getValue())).booleanValue();
          webServiceMBeanImpl.setIgnoreAuthHeader(bool);
        } catch (NumberFormatException numberFormatException) {
          throw new DDProcessingException("Attribute ignoreAuthHeader of element web-service should be true | false.");
        } 
      } else {
        webServiceMBeanImpl.setIgnoreAuthHeader(false);
      } 
      NSAttribute nSAttribute9 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "useSOAP12");
      if (nSAttribute9 != null)
        webServiceMBeanImpl.setUseSOAP12(Boolean.valueOf(nSAttribute9.getValue()).booleanValue()); 
      NSAttribute nSAttribute10 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "jmsUri");
      if (nSAttribute10 != null)
        webServiceMBeanImpl.setJmsURI(nSAttribute10.getValue()); 
      NSAttribute nSAttribute11 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "charset");
      if (nSAttribute11 != null)
        webServiceMBeanImpl.setCharset(nSAttribute11.getValue()); 
      NSAttribute nSAttribute12 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "handleAllActors");
      if (nSAttribute12 != null) {
        boolean bool = (new Boolean(nSAttribute12.getValue())).booleanValue();
        webServiceMBeanImpl.setHandleAllActors(bool);
      } else {
        webServiceMBeanImpl.setHandleAllActors(true);
      } 
      this.components = new HashMap();
      XMLNode xMLNode = processSecurityElement();
      if (xMLNode != null) {
        new SecurityDD(xMLNode.stream());
        webServiceMBeanImpl.setSecurity(xMLNode);
      } 
      XMLNodeSet xMLNodeSet = processTypesElement();
      if (xMLNodeSet != null)
        webServiceMBeanImpl.setTypes(xMLNodeSet); 
      TypeMappingMBean typeMappingMBean = processTypeMappingElement();
      if (typeMappingMBean != null)
        webServiceMBeanImpl.setTypeMapping(typeMappingMBean); 
      ComponentsMBean componentsMBean = processComponentsElement();
      if (componentsMBean != null)
        webServiceMBeanImpl.setComponents(componentsMBean); 
      OperationsMBean operationsMBean = processOperationsElement();
      if (operationsMBean != null) {
        webServiceMBeanImpl.setOperations(operationsMBean);
      } else {
        throw new DDProcessingException("There must be exactly one <operations> element in <web-service>", this.ph.getLocation());
      } 
      this.ph.matchEndElement("web-service");
    } 
    return webServiceMBeanImpl;
  }
  
  private XMLNode processSecurityElement() throws DDProcessingException, XMLStreamException {
    XMLNode xMLNode = null;
    XMLEvent xMLEvent = this.ph.peekStartElement("security");
    if (xMLEvent != null)
      xMLNode = this.ph.forkSubtree(); 
    return xMLNode;
  }
  
  private XMLNodeSet processTypesElement() throws DDProcessingException, XMLStreamException {
    XMLNodeSet xMLNodeSet = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("types");
    if (xMLEvent != null) {
      if (this.ph.peekStartElement() != null)
        xMLNodeSet = this.ph.forkSubtrees(); 
      this.ph.matchEndElement("types");
    } 
    return xMLNodeSet;
  }
  
  private TypeMappingMBean processTypeMappingElement() throws DDProcessingException, XMLStreamException {
    TypeMappingMBeanImpl typeMappingMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("type-mapping");
    if (xMLEvent != null) {
      typeMappingMBeanImpl = new TypeMappingMBeanImpl();
      TypeMappingEntryMBean[] arrayOfTypeMappingEntryMBean = processTypeMappingEntryElements();
      typeMappingMBeanImpl.setTypeMappingEntries(arrayOfTypeMappingEntryMBean);
      this.ph.matchEndElement("type-mapping");
    } 
    return typeMappingMBeanImpl;
  }
  
  private ComponentsMBean processComponentsElement() throws DDProcessingException, XMLStreamException {
    ComponentsMBeanImpl componentsMBeanImpl = new ComponentsMBeanImpl();
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("components");
    if (xMLEvent == null)
      return null; 
    NSAttribute nSAttribute = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "useMultiplePorts");
    if (nSAttribute != null)
      componentsMBeanImpl.setUseMultiplePorts((new Boolean(nSAttribute.getValue())).booleanValue()); 
    ComponentMBean componentMBean = processComponent();
    if (componentMBean == null)
      throw new DDProcessingException("There must be at least one of <stateless-ejb>,<java-class>,<stateful-java-class>,<jms-send-destination>,<jms-receive-topic>,<jms-receive-queue> in <components>", this.ph.getLocation()); 
    while (componentMBean != null) {
      if (componentMBean instanceof StatelessEJBMBean) {
        componentsMBeanImpl.addStatelessEJB((StatelessEJBMBean)componentMBean);
      } else if (componentMBean instanceof JavaClassMBean) {
        componentsMBeanImpl.addJavaClassComponent((JavaClassMBean)componentMBean);
      } else if (componentMBean instanceof StatefulJavaClassMBean) {
        componentsMBeanImpl.addStatefulJavaClassComponent((StatefulJavaClassMBean)componentMBean);
      } else if (componentMBean instanceof JMSSendDestinationMBean) {
        componentsMBeanImpl.addJMSSendDestination((JMSSendDestinationMBean)componentMBean);
      } else if (componentMBean instanceof JMSReceiveTopicMBean) {
        componentsMBeanImpl.addJMSReceiveTopic((JMSReceiveTopicMBean)componentMBean);
      } else if (componentMBean instanceof JMSReceiveQueueMBean) {
        componentsMBeanImpl.addJMSReceiveQueue((JMSReceiveQueueMBean)componentMBean);
      } else {
        throw new AssertionError(componentMBean.getClass().getName());
      } 
      componentMBean = processComponent();
    } 
    this.ph.matchEndElement("components");
    return componentsMBeanImpl;
  }
  
  private ComponentMBean processComponent() throws DDProcessingException, XMLStreamException {
    JMSReceiveQueueMBeanImpl jMSReceiveQueueMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement(COMPONENT_CHOICES);
    if (xMLEvent == null)
      return null; 
    String str = xMLEvent.getName().getLocalName();
    ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "class-name", "connection-factory", "provider-url", "initial-context-factory", "connection-factory", "name" });
    if ("stateless-ejb".equals(str)) {
      StatelessEJBMBeanImpl statelessEJBMBeanImpl = new StatelessEJBMBeanImpl();
      EJBLinkMBean eJBLinkMBean = processEJBLinkElement();
      if (eJBLinkMBean != null) {
        statelessEJBMBeanImpl.setEJBLink(eJBLinkMBean);
      } else {
        JNDINameMBean jNDINameMBean = processOptionalJNDINameElement();
        if (jNDINameMBean != null) {
          statelessEJBMBeanImpl.setJNDIName(jNDINameMBean);
        } else {
          throw new DDProcessingException("Expected an element matching either <ejb-link> or <jndi-name>", this.ph.getLocation());
        } 
      } 
      this.ph.matchEndElement("stateless-ejb");
      jMSReceiveQueueMBeanImpl = statelessEJBMBeanImpl;
    } else if ("java-class".equals(str)) {
      JavaClassMBeanImpl javaClassMBeanImpl2 = new JavaClassMBeanImpl();
      String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name").getValue();
      javaClassMBeanImpl2.setClassName(str1);
      this.ph.matchEndElement("java-class");
      JavaClassMBeanImpl javaClassMBeanImpl1 = javaClassMBeanImpl2;
    } else if ("stateful-java-class".equals(str)) {
      StatefulJavaClassMBeanImpl statefulJavaClassMBeanImpl2 = new StatefulJavaClassMBeanImpl();
      String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name").getValue();
      statefulJavaClassMBeanImpl2.setClassName(str1);
      this.ph.matchEndElement("stateful-java-class");
      StatefulJavaClassMBeanImpl statefulJavaClassMBeanImpl1 = statefulJavaClassMBeanImpl2;
    } else if ("jms-send-destination".equals(str)) {
      JMSSendDestinationMBeanImpl jMSSendDestinationMBeanImpl2 = new JMSSendDestinationMBeanImpl();
      JNDINameMBean jNDINameMBean = processJNDINameElement();
      jMSSendDestinationMBeanImpl2.setJNDIName(jNDINameMBean);
      String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "connection-factory").getValue();
      jMSSendDestinationMBeanImpl2.setConnectionFactory(str1);
      NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "provider-url");
      if (nSAttribute1 != null)
        jMSSendDestinationMBeanImpl2.setProviderUrl(nSAttribute1.getValue()); 
      NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "initial-context-factory");
      if (nSAttribute2 != null)
        jMSSendDestinationMBeanImpl2.setInitialContextFactory(nSAttribute2.getValue()); 
      this.ph.matchEndElement("jms-send-destination");
      JMSSendDestinationMBeanImpl jMSSendDestinationMBeanImpl1 = jMSSendDestinationMBeanImpl2;
    } else if ("jms-receive-topic".equals(str)) {
      JMSReceiveTopicMBeanImpl jMSReceiveTopicMBeanImpl2 = new JMSReceiveTopicMBeanImpl();
      JNDINameMBean jNDINameMBean = processJNDINameElement();
      jMSReceiveTopicMBeanImpl2.setJNDIName(jNDINameMBean);
      String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "connection-factory").getValue();
      jMSReceiveTopicMBeanImpl2.setConnectionFactory(str1);
      NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "provider-url");
      if (nSAttribute1 != null)
        jMSReceiveTopicMBeanImpl2.setProviderUrl(nSAttribute1.getValue()); 
      NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "initial-context-factory");
      if (nSAttribute2 != null)
        jMSReceiveTopicMBeanImpl2.setInitialContextFactory(nSAttribute2.getValue()); 
      this.ph.matchEndElement("jms-receive-topic");
      JMSReceiveTopicMBeanImpl jMSReceiveTopicMBeanImpl1 = jMSReceiveTopicMBeanImpl2;
    } else if ("jms-receive-queue".equals(str)) {
      JMSReceiveQueueMBeanImpl jMSReceiveQueueMBeanImpl1 = new JMSReceiveQueueMBeanImpl();
      JNDINameMBean jNDINameMBean = processJNDINameElement();
      jMSReceiveQueueMBeanImpl1.setJNDIName(jNDINameMBean);
      String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "connection-factory").getValue();
      jMSReceiveQueueMBeanImpl1.setConnectionFactory(str1);
      NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "provider-url");
      if (nSAttribute1 != null)
        jMSReceiveQueueMBeanImpl1.setProviderUrl(nSAttribute1.getValue()); 
      NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "initial-context-factory");
      if (nSAttribute2 != null)
        jMSReceiveQueueMBeanImpl1.setInitialContextFactory(nSAttribute2.getValue()); 
      this.ph.matchEndElement("jms-receive-queue");
      jMSReceiveQueueMBeanImpl = jMSReceiveQueueMBeanImpl1;
    } 
    if (jMSReceiveQueueMBeanImpl != null) {
      String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "name").getValue();
      jMSReceiveQueueMBeanImpl.setComponentName(str1);
      this.components.put(str1, jMSReceiveQueueMBeanImpl);
    } 
    return jMSReceiveQueueMBeanImpl;
  }
  
  private EJBLinkMBean processEJBLinkElement() throws DDProcessingException, XMLStreamException {
    EJBLinkMBeanImpl eJBLinkMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("ejb-link");
    if (xMLEvent != null) {
      ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "path" });
      eJBLinkMBeanImpl = new EJBLinkMBeanImpl();
      String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "path").getValue();
      if (str.indexOf('#') == -1)
        throw new DDProcessingException("The \"path\" attribute of <ejb-link> must have the syntax \"<jar name>#<ejb name>\"", xMLEvent.getLocation()); 
      eJBLinkMBeanImpl.setPath(str);
      this.ph.matchEndElement("ejb-link");
    } 
    return eJBLinkMBeanImpl;
  }
  
  private JNDINameMBean processOptionalJNDINameElement() throws DDProcessingException, XMLStreamException {
    JNDINameMBeanImpl jNDINameMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("jndi-name");
    if (xMLEvent != null) {
      ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "path" });
      jNDINameMBeanImpl = new JNDINameMBeanImpl();
      String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "path").getValue();
      jNDINameMBeanImpl.setPath(str);
      this.ph.matchEndElement("jndi-name");
    } 
    return jNDINameMBeanImpl;
  }
  
  private JNDINameMBean processJNDINameElement() throws DDProcessingException, XMLStreamException {
    JNDINameMBeanImpl jNDINameMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("jndi-name");
    if (xMLEvent != null) {
      ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "path" });
      jNDINameMBeanImpl = new JNDINameMBeanImpl();
      String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "path").getValue();
      jNDINameMBeanImpl.setPath(str);
      this.ph.matchEndElement("jndi-name");
    } 
    return jNDINameMBeanImpl;
  }
  
  private HandlerChainsMBean processHandlerChainsElement() throws DDProcessingException, XMLStreamException {
    HandlerChainsMBeanImpl handlerChainsMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("handler-chains");
    if (xMLEvent != null) {
      handlerChainsMBeanImpl = new HandlerChainsMBeanImpl();
      HandlerChainMBean[] arrayOfHandlerChainMBean = processHandlerChainElements();
      handlerChainsMBeanImpl.setHandlerChains(arrayOfHandlerChainMBean);
      this.ph.matchEndElement("web-services");
    } 
    return handlerChainsMBeanImpl;
  }
  
  private HandlerChainMBean[] processHandlerChainElements() throws DDProcessingException, XMLStreamException {
    HandlerChainMBean handlerChainMBean = processHandlerChainElement();
    if (handlerChainMBean == null)
      throw new DDProcessingException("There must be at least one <handler-chain> element in <handler-chains>", this.ph.getLocation()); 
    ArrayList arrayList = new ArrayList();
    while (handlerChainMBean != null) {
      arrayList.add(handlerChainMBean);
      handlerChainMBean = processHandlerChainElement();
    } 
    return (HandlerChainMBean[])arrayList.toArray(new HandlerChainMBeanImpl[0]);
  }
  
  private HandlerChainMBean processHandlerChainElement() throws DDProcessingException, XMLStreamException {
    HandlerChainMBeanImpl handlerChainMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("handler-chain");
    if (xMLEvent != null) {
      ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "name" });
      handlerChainMBeanImpl = new HandlerChainMBeanImpl();
      String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "name").getValue();
      handlerChainMBeanImpl.setHandlerChainName(str);
      HandlerMBean[] arrayOfHandlerMBean = processHandlerElements();
      handlerChainMBeanImpl.setHandlers(arrayOfHandlerMBean);
      if (this.handlerChains.put(str, handlerChainMBeanImpl) != null)
        throw new DDProcessingException("<handler-chain> must have a unique \"name\" attribute within the scope of a <web-services>; the name \"" + str + "\" was used in a previous <" + "handler-chain" + "> element", xMLEvent.getLocation()); 
      this.ph.matchEndElement("handler-chain");
    } 
    return handlerChainMBeanImpl;
  }
  
  private HandlerMBean[] processHandlerElements() throws DDProcessingException, XMLStreamException {
    ArrayList arrayList = new ArrayList();
    HandlerMBean handlerMBean = processHandlerElement();
    if (handlerMBean == null)
      throw new DDProcessingException("There must be at least one <handler> element in <handler-chain>", this.ph.getLocation()); 
    while (handlerMBean != null) {
      arrayList.add(handlerMBean);
      handlerMBean = processHandlerElement();
    } 
    return (HandlerMBean[])arrayList.toArray(new HandlerMBean[0]);
  }
  
  private HandlerMBean processHandlerElement() throws DDProcessingException, XMLStreamException {
    HandlerMBeanImpl handlerMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("handler");
    if (xMLEvent != null) {
      ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "class-name" });
      handlerMBeanImpl = new HandlerMBeanImpl();
      String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name").getValue();
      handlerMBeanImpl.setClassName(str);
      InitParamsMBean initParamsMBean = processInitParamsElement();
      if (initParamsMBean != null)
        handlerMBeanImpl.setInitParams(initParamsMBean); 
      this.ph.matchEndElement("handler");
    } 
    return handlerMBeanImpl;
  }
  
  private InitParamsMBean processInitParamsElement() throws DDProcessingException, XMLStreamException {
    InitParamsMBeanImpl initParamsMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("init-params");
    if (xMLEvent != null) {
      initParamsMBeanImpl = new InitParamsMBeanImpl();
      InitParamMBean[] arrayOfInitParamMBean = processInitParamElements();
      initParamsMBeanImpl.setInitParams(arrayOfInitParamMBean);
      this.ph.matchEndElement("init-params");
    } 
    return initParamsMBeanImpl;
  }
  
  private InitParamMBean[] processInitParamElements() throws DDProcessingException, XMLStreamException {
    InitParamMBean initParamMBean = processInitParamElement();
    if (initParamMBean == null)
      throw new DDProcessingException("There must be at least one <param> element in <init-params>", this.ph.getLocation()); 
    ArrayList arrayList = new ArrayList();
    while (initParamMBean != null) {
      arrayList.add(initParamMBean);
      initParamMBean = processInitParamElement();
    } 
    return (InitParamMBeanImpl[])arrayList.toArray(new InitParamMBeanImpl[0]);
  }
  
  private InitParamMBean processInitParamElement() throws DDProcessingException, XMLStreamException {
    InitParamMBeanImpl initParamMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("init-param");
    if (xMLEvent != null) {
      ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "name", "value" });
      initParamMBeanImpl = new InitParamMBeanImpl();
      String str1 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "name").getValue();
      initParamMBeanImpl.setParamName(str1);
      String str2 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "value").getValue();
      initParamMBeanImpl.setParamValue(str2);
      this.ph.matchEndElement("init-param");
    } 
    return initParamMBeanImpl;
  }
  
  private OperationsMBean processOperationsElement() throws DDProcessingException, XMLStreamException {
    OperationsMBeanImpl operationsMBeanImpl = new OperationsMBeanImpl();
    this.ph.matchStartElement("operations");
    OperationMBean[] arrayOfOperationMBean = processOperationElements();
    operationsMBeanImpl.setOperations(arrayOfOperationMBean);
    this.ph.matchEndElement("operations");
    return operationsMBeanImpl;
  }
  
  private OperationMBean[] processOperationElements() throws DDProcessingException, XMLStreamException {
    OperationMBean operationMBean = processOperationElement();
    if (operationMBean == null)
      throw new DDProcessingException("There must be at least one <operation> element in <operations>", this.ph.getLocation()); 
    ArrayList arrayList = new ArrayList();
    while (operationMBean != null) {
      arrayList.add(operationMBean);
      operationMBean = processOperationElement();
    } 
    if (arrayList.size() > 0)
      return (OperationMBeanImpl[])arrayList.toArray(new OperationMBeanImpl[0]); 
    return null;
  }
  
  private OperationMBean processOperationElement() throws DDProcessingException, XMLStreamException {
    OperationMBeanImpl operationMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("operation");
    if (xMLEvent == null)
      return null; 
    ParsingHelper.checkAttributes((StartElement)xMLEvent, operationAttributes);
    operationMBeanImpl = new OperationMBeanImpl();
    boolean bool = false;
    NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "name");
    if (nSAttribute1 != null)
      operationMBeanImpl.setOperationName(nSAttribute1.getValue()); 
    if ("*".equals(nSAttribute1))
      bool = true; 
    NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "method");
    if (nSAttribute2 != null && !"*".equals(nSAttribute2)) {
      if (bool)
        throw new DDProcessingException("Cannot set \"method\" attribute on <operation> if setting value of attribute \"name\" to \"*\"", xMLEvent.getLocation()); 
      operationMBeanImpl.setMethod(nSAttribute2.getValue());
    } 
    NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "handler-chain");
    if (nSAttribute3 != null) {
      HandlerChainMBean handlerChainMBean = (HandlerChainMBean)this.handlerChains.get(nSAttribute3.getValue());
      if (handlerChainMBean == null)
        throw new DDProcessingException("Could not locate the referenced <handler-chain> with name = \"" + nSAttribute3.getValue() + "\" when processing <" + "operation" + ">", xMLEvent.getLocation()); 
      operationMBeanImpl.setHandlerChainName(nSAttribute3.getValue());
      operationMBeanImpl.setHandlerChain(handlerChainMBean);
    } 
    if (nSAttribute1 == null && nSAttribute2 == null && nSAttribute3 == null)
      throw new DDProcessingException("At least one of attributes name, method or handler-chain must be specified on <operation>", xMLEvent.getLocation()); 
    NSAttribute nSAttribute4 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "component");
    if (nSAttribute4 != null) {
      ComponentMBean componentMBean = (ComponentMBean)this.components.get(nSAttribute4.getValue());
      if (componentMBean == null)
        throw new DDProcessingException("Could not locate the referenced component with name attribute = " + nSAttribute4.getValue() + " when processing <" + "operation" + ">", xMLEvent.getLocation()); 
      operationMBeanImpl.setComponentName(nSAttribute4.getValue());
      operationMBeanImpl.setComponent(componentMBean);
    } 
    NSAttribute nSAttribute5 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "invocation-style");
    if (nSAttribute5 != null) {
      String str = nSAttribute5.getValue();
      if (!"request-response".equalsIgnoreCase(str) && !"one-way".equalsIgnoreCase(str))
        throw new DDProcessingException("The value \"" + str + "\" of attribute \"" + "invocation-style" + "\" must be either \"" + "one-way" + "\" or \"" + "request-response" + "\"", xMLEvent.getLocation()); 
      operationMBeanImpl.setInvocationStyle(str);
    } 
    NSAttribute nSAttribute6 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "namespace");
    if (nSAttribute6 != null) {
      String str = nSAttribute6.getValue();
      operationMBeanImpl.setNamespace(str);
    } 
    NSAttribute nSAttribute7 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "portTypeName");
    if (nSAttribute7 != null) {
      String str = nSAttribute7.getValue();
      operationMBeanImpl.setPortTypeName(str);
    } 
    NSAttribute nSAttribute8 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "style");
    if (nSAttribute8 != null) {
      String str = nSAttribute8.getValue();
      operationMBeanImpl.setStyle(str);
    } 
    NSAttribute nSAttribute9 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "conversationPhase");
    if (nSAttribute9 != null) {
      String str = nSAttribute9.getValue();
      operationMBeanImpl.setConversationPhase(str);
    } 
    NSAttribute nSAttribute10 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "in-security-spec");
    if (nSAttribute10 != null) {
      String str = nSAttribute10.getValue();
      operationMBeanImpl.setInSecuritySpec(str);
    } 
    NSAttribute nSAttribute11 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "out-security-spec");
    if (nSAttribute11 != null) {
      String str = nSAttribute11.getValue();
      operationMBeanImpl.setOutSecuritySpec(str);
    } 
    ParamsMBean paramsMBean = processParamsElement();
    if (paramsMBean != null)
      operationMBeanImpl.setParams(paramsMBean); 
    ReliableDeliveryMBean reliableDeliveryMBean = processReliableElement();
    if (reliableDeliveryMBean != null)
      operationMBeanImpl.setReliableDelivery(reliableDeliveryMBean); 
    this.ph.matchEndElement("operation");
    return operationMBeanImpl;
  }
  
  private ParamsMBean processParamsElement() throws DDProcessingException, XMLStreamException {
    ParamsMBeanImpl paramsMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("params");
    if (xMLEvent != null) {
      paramsMBeanImpl = new ParamsMBeanImpl();
      ParamMBean[] arrayOfParamMBean = processParamElements();
      if (arrayOfParamMBean != null)
        paramsMBeanImpl.setParams(arrayOfParamMBean); 
      ReturnParamMBean returnParamMBean = processReturnElement();
      if (returnParamMBean != null)
        paramsMBeanImpl.setReturnParam(returnParamMBean); 
      FaultMBean[] arrayOfFaultMBean = processFaultElements();
      if (arrayOfFaultMBean != null)
        paramsMBeanImpl.setFaults(arrayOfFaultMBean); 
      this.ph.matchEndElement("params");
    } 
    if (paramsMBeanImpl == null || (paramsMBeanImpl.getParams() == null && paramsMBeanImpl.getReturnParam() == null))
      return null; 
    return paramsMBeanImpl;
  }
  
  private ParamMBean[] processParamElements() throws DDProcessingException, XMLStreamException {
    ArrayList arrayList = new ArrayList();
    ParamMBean paramMBean = processParamElement();
    while (paramMBean != null) {
      arrayList.add(paramMBean);
      paramMBean = processParamElement();
    } 
    return (ParamMBean[])arrayList.toArray(new ParamMBean[0]);
  }
  
  private ParamMBean processParamElement() throws DDProcessingException, XMLStreamException {
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("param");
    if (xMLEvent == null)
      return null; 
    ParsingHelper.checkAttributes((StartElement)xMLEvent, paramAttributes);
    ParamMBeanImpl paramMBeanImpl = new ParamMBeanImpl();
    NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "name");
    if (nSAttribute1 != null)
      paramMBeanImpl.setParamName(nSAttribute1.getValue()); 
    String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "style").getValue();
    if (!"in".equalsIgnoreCase(str) && !"inout".equalsIgnoreCase(str) && !"out".equalsIgnoreCase(str))
      throw new DDProcessingException("Unrecognized value \"" + str + "\" for " + "style" + " attribute of <" + "param" + ">; the value must be set to either one of \"" + "in" + "\", \"" + "inout" + "\" or \"" + "out" + "\"", xMLEvent.getLocation()); 
    paramMBeanImpl.setParamStyle(str);
    NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "location");
    if (nSAttribute2 != null) {
      String str1 = nSAttribute2.getValue();
      if (!"header".equals(str1) && !"body".equals(str1) && !"attachment".equals(str1))
        throw new DDProcessingException("Unrecognized value \"" + str1 + "\" for " + "location" + " attribute of <" + "param" + ">; the value must be set to either \"" + "body" + "\" or \"" + "header" + "\" or \"" + "attachment" + "\"", xMLEvent.getLocation()); 
      paramMBeanImpl.setLocation(str1);
    } 
    NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "implicit");
    if (nSAttribute3 != null)
      if ("true".equalsIgnoreCase(nSAttribute3.getValue())) {
        paramMBeanImpl.setImplicit(true);
      } else if ("false".equalsIgnoreCase(nSAttribute3.getValue())) {
        paramMBeanImpl.setImplicit(false);
      } else {
        throw new DDProcessingException("Unrecognized value \"" + nSAttribute3.getValue() + "\" for " + "implicit" + " attribute of <" + "in" + ">; the value must be set to either \"True\" or \"False\"", xMLEvent.getLocation());
      }  
    NSAttribute nSAttribute4 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "type");
    paramMBeanImpl.setParamType(nSAttribute4.getValueAsXMLName());
    NSAttribute nSAttribute5 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "class-name");
    if (nSAttribute5 != null)
      paramMBeanImpl.setClassName(nSAttribute5.getValue()); 
    this.ph.matchEndElement("param");
    return paramMBeanImpl;
  }
  
  public ReturnParamMBean processReturnElement() throws DDProcessingException, XMLStreamException {
    ReturnParamMBeanImpl returnParamMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("return-param");
    if (xMLEvent != null) {
      returnParamMBeanImpl = new ReturnParamMBeanImpl();
      ParsingHelper.checkAttributes((StartElement)xMLEvent, returnAttributes);
      NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "name");
      if (nSAttribute1 != null)
        returnParamMBeanImpl.setParamName(nSAttribute1.getValue()); 
      NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "location");
      if (nSAttribute2 != null) {
        String str = nSAttribute2.getValue();
        if (!"header".equals(str) && !"body".equals(str) && !"attachment".equals(str))
          throw new DDProcessingException("Unrecognized value \"" + str + "\" for " + "location" + " attribute of <" + "param" + ">; the value must be set to either \"" + "body" + "\" or \"" + "header" + "\" or " + "attachment", xMLEvent.getLocation()); 
        returnParamMBeanImpl.setLocation(str);
      } 
      NSAttribute nSAttribute3 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "type");
      returnParamMBeanImpl.setParamType(nSAttribute3.getValueAsXMLName());
      NSAttribute nSAttribute4 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "class-name");
      if (nSAttribute4 != null)
        returnParamMBeanImpl.setClassName(nSAttribute4.getValue()); 
      this.ph.matchEndElement("return-param");
    } 
    return returnParamMBeanImpl;
  }
  
  public ReliableDeliveryMBean processReliableElement() throws DDProcessingException, XMLStreamException {
    ReliableDeliveryMBeanImpl reliableDeliveryMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("reliable-delivery");
    if (xMLEvent != null) {
      reliableDeliveryMBeanImpl = new ReliableDeliveryMBeanImpl();
      ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "duplicate-elimination", "retries", "retry-interval", "persist-duration", "in-order-delivery" });
      NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "duplicate-elimination");
      if (nSAttribute1 != null)
        if ("true".equalsIgnoreCase(nSAttribute1.getValue())) {
          reliableDeliveryMBeanImpl.setDuplicateElimination(true);
        } else if ("false".equalsIgnoreCase(nSAttribute1.getValue())) {
          reliableDeliveryMBeanImpl.setDuplicateElimination(false);
        } else {
          throw new DDProcessingException("Unrecognized value \"" + nSAttribute1.getValue() + "\" for " + "duplicate-elimination" + " attribute of <" + "reliable-delivery" + ">; the value must be set to either \"True\" or \"False\"", xMLEvent.getLocation());
        }  
      NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "retries");
      if (nSAttribute2 != null)
        try {
          reliableDeliveryMBeanImpl.setRetries(Integer.parseInt(nSAttribute2.getValue()));
        } catch (NumberFormatException numberFormatException) {
          throw new DDProcessingException("Unrecognized value \"" + nSAttribute2.getValue() + "\" for " + "retries" + " attribute of <" + "reliable-delivery" + ">; the value must be set to an integer", xMLEvent.getLocation());
        }  
      NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "retry-interval");
      if (nSAttribute3 != null)
        try {
          reliableDeliveryMBeanImpl.setRetryInterval(Integer.parseInt(nSAttribute3.getValue()));
        } catch (NumberFormatException numberFormatException) {
          throw new DDProcessingException("Unrecognized value \"" + nSAttribute3.getValue() + "\" for " + "retry-interval" + " attribute of <" + "reliable-delivery" + ">; the value must be set to an integer", xMLEvent.getLocation());
        }  
      NSAttribute nSAttribute4 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "persist-duration");
      if (nSAttribute4 != null)
        try {
          reliableDeliveryMBeanImpl.setPersistDuration(Integer.parseInt(nSAttribute4.getValue()));
        } catch (NumberFormatException numberFormatException) {
          throw new DDProcessingException("Unrecognized value \"" + nSAttribute4.getValue() + "\" for " + "persist-duration" + " attribute of <" + "reliable-delivery" + ">; the value must be set to an integer", xMLEvent.getLocation());
        }  
      NSAttribute nSAttribute5 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "in-order-delivery");
      if (nSAttribute5 != null)
        if ("true".equalsIgnoreCase(nSAttribute5.getValue())) {
          reliableDeliveryMBeanImpl.setInOrderDelivery(true);
        } else if ("false".equalsIgnoreCase(nSAttribute5.getValue())) {
          reliableDeliveryMBeanImpl.setInOrderDelivery(false);
        } else {
          throw new DDProcessingException("Unrecognized value \"" + nSAttribute5.getValue() + "\" for " + "in-order-delivery" + " attribute of <" + "reliable-delivery" + ">; the value must be set to either \"True\" or \"False\"", xMLEvent.getLocation());
        }  
      this.ph.matchEndElement("reliable-delivery");
    } 
    return reliableDeliveryMBeanImpl;
  }
  
  private FaultMBean[] processFaultElements() throws DDProcessingException, XMLStreamException {
    ArrayList arrayList = new ArrayList();
    FaultMBean faultMBean = processFaultElement();
    while (faultMBean != null) {
      arrayList.add(faultMBean);
      faultMBean = processFaultElement();
    } 
    if (arrayList.size() == 0)
      return null; 
    return (FaultMBean[])arrayList.toArray(new FaultMBean[0]);
  }
  
  private FaultMBean processFaultElement() throws DDProcessingException, XMLStreamException {
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("fault");
    if (xMLEvent == null)
      return null; 
    ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "name", "class-name", "type" });
    FaultMBeanImpl faultMBeanImpl = new FaultMBeanImpl();
    NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "name");
    if (nSAttribute1 != null)
      faultMBeanImpl.setFaultName(nSAttribute1.getValue()); 
    NSAttribute nSAttribute2 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "type");
    faultMBeanImpl.setFaultType(nSAttribute2.getValueAsXMLName());
    NSAttribute nSAttribute3 = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name");
    if (nSAttribute3 != null)
      faultMBeanImpl.setClassName(nSAttribute3.getValue()); 
    this.ph.matchEndElement("fault");
    return faultMBeanImpl;
  }
  
  private TypeMappingEntryMBean[] processTypeMappingEntryElements() throws DDProcessingException, XMLStreamException {
    TypeMappingEntryMBean typeMappingEntryMBean = processTypeMappingEntryElement();
    ArrayList arrayList = new ArrayList();
    while (typeMappingEntryMBean != null) {
      arrayList.add(typeMappingEntryMBean);
      typeMappingEntryMBean = processTypeMappingEntryElement();
    } 
    if (arrayList.size() > 0)
      return (TypeMappingEntryMBeanImpl[])arrayList.toArray(new TypeMappingEntryMBeanImpl[0]); 
    return null;
  }
  
  private TypeMappingEntryMBean processTypeMappingEntryElement() throws DDProcessingException, XMLStreamException {
    TypeMappingEntryMBeanImpl typeMappingEntryMBeanImpl = null;
    XMLEvent xMLEvent = this.ph.matchOptionalStartElement("type-mapping-entry");
    if (xMLEvent != null) {
      typeMappingEntryMBeanImpl = new TypeMappingEntryMBeanImpl();
      ParsingHelper.checkAttributes((StartElement)xMLEvent, new String[] { "class-name", "element", "serializer", "deserializer", "type" });
      String str = ParsingHelper.getRequiredAttribute((StartElement)xMLEvent, "class-name").getValue();
      typeMappingEntryMBeanImpl.setClassName(str);
      NSAttribute nSAttribute1 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "element");
      if (nSAttribute1 != null) {
        typeMappingEntryMBeanImpl.setElementName(nSAttribute1.getValueAsXMLName());
      } else {
        NSAttribute nSAttribute = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "type");
        if (nSAttribute != null) {
          typeMappingEntryMBeanImpl.setXSDTypeName(nSAttribute.getValueAsXMLName());
        } else {
          throw new DDProcessingException("Either attribute type or element must be specified for element <type-mapping>", xMLEvent.getLocation());
        } 
      } 
      NSAttribute nSAttribute2 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "serializer");
      if (nSAttribute2 != null)
        typeMappingEntryMBeanImpl.setSerializerName(nSAttribute2.getValue()); 
      NSAttribute nSAttribute3 = ParsingHelper.getOptionalAttribute((StartElement)xMLEvent, "deserializer");
      if (nSAttribute3 != null)
        typeMappingEntryMBeanImpl.setDeserializerName(nSAttribute3.getValue()); 
      this.ph.matchEndElement("type-mapping-entry");
    } 
    return typeMappingEntryMBeanImpl;
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    DDLoader dDLoader = new DDLoader();
    FileInputStream fileInputStream = new FileInputStream(paramArrayOfString[0]);
    WebServicesMBeanImpl webServicesMBeanImpl = (WebServicesMBeanImpl)dDLoader.load(fileInputStream);
    XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(System.out);
    xMLOutputStream.add(webServicesMBeanImpl.toXML(0));
    xMLOutputStream.flush();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\DDLoader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */