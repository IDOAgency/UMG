/*    */ package weblogic.webservice.dd;
/*    */ 
/*    */ import weblogic.utils.NestedException;
/*    */ 
/*    */ 
/*    */ public class EJBProcessingException
/*    */   extends NestedException
/*    */ {
/*    */   public EJBProcessingException() {}
/*    */   
/* 11 */   public EJBProcessingException(Throwable paramThrowable) { super(paramThrowable); }
/* 12 */   public EJBProcessingException(String paramString) { super(paramString); }
/* 13 */   public EJBProcessingException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\EJBProcessingException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */