package weblogic.webservice.dd;

import java.io.File;
import java.io.IOException;
import weblogic.utils.StringUtils;
import weblogic.utils.classloaders.ClasspathClassLoader;
import weblogic.webservice.tools.MethodIterator;

public abstract class ComponentIntrospector {
  private static final boolean debug = false;
  
  protected String componentName;
  
  public ComponentIntrospector() {}
  
  public ComponentIntrospector(String paramString) { this.componentName = paramString; }
  
  protected static ClassLoader setClassLoader(File[] paramArrayOfFile) throws IOException {
    String[] arrayOfString = new String[paramArrayOfFile.length];
    for (byte b = 0; b < paramArrayOfFile.length; b++)
      arrayOfString[b] = paramArrayOfFile[b].getCanonicalPath().replace('\\', '/'); 
    String str = StringUtils.join(arrayOfString, File.pathSeparator);
    ClasspathClassLoader classpathClassLoader = new ClasspathClassLoader(str, ComponentIntrospector.class.getClassLoader());
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    Thread.currentThread().setContextClassLoader(classpathClassLoader);
    return classLoader;
  }
  
  protected static ClassLoader setClassLoader(ClassLoader paramClassLoader) {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    Thread.currentThread().setContextClassLoader(paramClassLoader);
    return classLoader;
  }
  
  protected static Class loadClass(String paramString) throws ClassNotFoundException {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = ComponentIntrospector.class.getClassLoader(); 
    return classLoader.loadClass(paramString);
  }
  
  public String toString() { return this.componentName; }
  
  public abstract MethodIterator getMethods() throws ClassNotFoundException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\ComponentIntrospector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */