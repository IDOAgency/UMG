/*    */ package weblogic.webservice.dd;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import weblogic.utils.StringUtils;
/*    */ import weblogic.utils.classloaders.ClasspathClassLoader;
/*    */ import weblogic.webservice.tools.MethodIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ComponentIntrospector
/*    */ {
/*    */   private static final boolean debug = false;
/*    */   protected String componentName;
/*    */   
/*    */   public ComponentIntrospector() {}
/*    */   
/* 23 */   public ComponentIntrospector(String paramString) { this.componentName = paramString; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected static ClassLoader setClassLoader(File[] paramArrayOfFile) throws IOException {
/* 33 */     String[] arrayOfString = new String[paramArrayOfFile.length];
/* 34 */     for (byte b = 0; b < paramArrayOfFile.length; b++) {
/* 35 */       arrayOfString[b] = paramArrayOfFile[b].getCanonicalPath().replace('\\', '/');
/*    */     }
/* 37 */     String str = StringUtils.join(arrayOfString, File.pathSeparator);
/*    */ 
/*    */     
/* 40 */     ClasspathClassLoader classpathClassLoader = new ClasspathClassLoader(str, ComponentIntrospector.class.getClassLoader());
/*    */     
/* 42 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 43 */     Thread.currentThread().setContextClassLoader(classpathClassLoader);
/* 44 */     return classLoader;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected static ClassLoader setClassLoader(ClassLoader paramClassLoader) {
/* 52 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 53 */     Thread.currentThread().setContextClassLoader(paramClassLoader);
/* 54 */     return classLoader;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected static Class loadClass(String paramString) throws ClassNotFoundException {
/* 60 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 61 */     if (classLoader == null) {
/* 62 */       classLoader = ComponentIntrospector.class.getClassLoader();
/*    */     }
/* 64 */     return classLoader.loadClass(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   public String toString() { return this.componentName; }
/*    */   
/*    */   public abstract MethodIterator getMethods() throws ClassNotFoundException;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\ComponentIntrospector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */