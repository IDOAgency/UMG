/*     */ package weblogic.webservice.dd.verify;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import weblogic.i18n.Localizer;
/*     */ import weblogic.i18ntools.L10nLookup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServiceComplianceTextFormatter
/*     */ {
/*     */   private Localizer l10n;
/*     */   private boolean format = false;
/*     */   
/*  20 */   public WebServiceComplianceTextFormatter() { this.l10n = L10nLookup.getLocalizer(Locale.getDefault(), "weblogic.webservice.dd.verify.WebServiceComplianceTextLocalizer"); }
/*     */ 
/*     */ 
/*     */   
/*  24 */   public WebServiceComplianceTextFormatter(Locale paramLocale) { this.l10n = L10nLookup.getLocalizer(paramLocale, "weblogic.webservice.dd.verify.WebServiceComplianceTextLocalizer"); }
/*     */ 
/*     */ 
/*     */   
/*  28 */   public static WebServiceComplianceTextFormatter getInstance() { return new WebServiceComplianceTextFormatter(); }
/*     */ 
/*     */ 
/*     */   
/*  32 */   public static WebServiceComplianceTextFormatter getInstance(Locale paramLocale) { return new WebServiceComplianceTextFormatter(paramLocale); }
/*     */ 
/*     */ 
/*     */   
/*  36 */   public void setExtendedFormat(boolean paramBoolean) { this.format = paramBoolean; }
/*     */ 
/*     */   
/*  39 */   public boolean getExtendedFormat() { return this.format; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noHandlerChainName() {
/*  46 */     String str1 = "";
/*  47 */     String str2 = "noHandlerChainName";
/*  48 */     String str3 = "WebService Compliance";
/*  49 */     Object[] arrayOfObject = new Object[0];
/*  50 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/*  51 */     if (getExtendedFormat()) {
/*  52 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/*  54 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/*  56 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noHandlerClassName(String paramString) {
/*  63 */     String str1 = "";
/*  64 */     String str2 = "noHandlerClassName";
/*  65 */     String str3 = "WebService Compliance";
/*  66 */     Object[] arrayOfObject = { paramString };
/*  67 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/*  68 */     if (getExtendedFormat()) {
/*  69 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/*  71 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/*  73 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noHandlersInChain(String paramString) {
/*  80 */     String str1 = "";
/*  81 */     String str2 = "noHandlersInChain";
/*  82 */     String str3 = "WebService Compliance";
/*  83 */     Object[] arrayOfObject = { paramString };
/*  84 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/*  85 */     if (getExtendedFormat()) {
/*  86 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/*  88 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/*  90 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String doesntExtendHandler(String paramString1, String paramString2) {
/*  97 */     String str1 = "";
/*  98 */     String str2 = "doesntExtendHandler";
/*  99 */     String str3 = "WebService Compliance";
/* 100 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 101 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 102 */     if (getExtendedFormat()) {
/* 103 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 105 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 107 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String cantLoadHandlerClass(String paramString1, String paramString2) {
/* 114 */     String str1 = "";
/* 115 */     String str2 = "cantLoadHandlerClass";
/* 116 */     String str3 = "WebService Compliance";
/* 117 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 118 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 119 */     if (getExtendedFormat()) {
/* 120 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 122 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 124 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String handlerNeedsDefaultCtor(String paramString1, String paramString2) {
/* 131 */     String str1 = "";
/* 132 */     String str2 = "handlerNeedsDefaultCtor";
/* 133 */     String str3 = "WebService Compliance";
/* 134 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 135 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 136 */     if (getExtendedFormat()) {
/* 137 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 139 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 141 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String javaComponentClassNotFound(String paramString1, String paramString2) {
/* 148 */     String str1 = "";
/* 149 */     String str2 = "javaComponentClassNotFound";
/* 150 */     String str3 = "WebService Compliance";
/* 151 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 152 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 153 */     if (getExtendedFormat()) {
/* 154 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 156 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 158 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String javaComponentNeedsDefaultCtor(String paramString1, String paramString2) {
/* 165 */     String str1 = "";
/* 166 */     String str2 = "javaComponentNeedsDefaultCtor";
/* 167 */     String str3 = "WebService Compliance";
/* 168 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 169 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 170 */     if (getExtendedFormat()) {
/* 171 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 173 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 175 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mustSpecifyJNDIOrEJBLink(String paramString) {
/* 182 */     String str1 = "";
/* 183 */     String str2 = "mustSpecifyJNDIOrEJBLink";
/* 184 */     String str3 = "WebService Compliance";
/* 185 */     Object[] arrayOfObject = { paramString };
/* 186 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 187 */     if (getExtendedFormat()) {
/* 188 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 190 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 192 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String couldntFindEJBLink(String paramString1, String paramString2, Exception paramException) {
/* 199 */     String str1 = "";
/* 200 */     String str2 = "couldntFindEJBLink";
/* 201 */     String str3 = "WebService Compliance";
/* 202 */     Object[] arrayOfObject = { paramString1, paramString2, paramException };
/* 203 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 204 */     if (getExtendedFormat()) {
/* 205 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 207 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 209 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String couldntFindJNDIName(String paramString1, String paramString2, Exception paramException) {
/* 216 */     String str1 = "";
/* 217 */     String str2 = "couldntFindJNDIName";
/* 218 */     String str3 = "WebService Compliance";
/* 219 */     Object[] arrayOfObject = { paramString1, paramString2, paramException };
/* 220 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 221 */     if (getExtendedFormat()) {
/* 222 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 224 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 226 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String ejbLinkWasNotEJBHome(String paramString1, String paramString2) {
/* 233 */     String str1 = "";
/* 234 */     String str2 = "ejbLinkWasNotEJBHome";
/* 235 */     String str3 = "WebService Compliance";
/* 236 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 237 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 238 */     if (getExtendedFormat()) {
/* 239 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 241 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 243 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String jndiNameWasNotEJBHome(String paramString1, String paramString2) {
/* 250 */     String str1 = "";
/* 251 */     String str2 = "jndiNameWasNotEJBHome";
/* 252 */     String str3 = "WebService Compliance";
/* 253 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 254 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 255 */     if (getExtendedFormat()) {
/* 256 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 258 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 260 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String ejbLinkWasNotStateless(String paramString1, String paramString2) {
/* 267 */     String str1 = "";
/* 268 */     String str2 = "ejbLinkWasNotStateless";
/* 269 */     String str3 = "WebService Compliance";
/* 270 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 271 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 272 */     if (getExtendedFormat()) {
/* 273 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 275 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 277 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String jndiNameWasNotStateless(String paramString1, String paramString2) {
/* 284 */     String str1 = "";
/* 285 */     String str2 = "jndiNameWasNotStateless";
/* 286 */     String str3 = "WebService Compliance";
/* 287 */     Object[] arrayOfObject = { paramString1, paramString2 };
/* 288 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 289 */     if (getExtendedFormat()) {
/* 290 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 292 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 294 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noWebServices() {
/* 301 */     String str1 = "";
/* 302 */     String str2 = "noWebServices";
/* 303 */     String str3 = "WebService Compliance";
/* 304 */     Object[] arrayOfObject = new Object[0];
/* 305 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 306 */     if (getExtendedFormat()) {
/* 307 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 309 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 311 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noFileOrDirectorNamed(String paramString) {
/* 318 */     String str1 = "";
/* 319 */     String str2 = "noFileOrDirectorNamed";
/* 320 */     String str3 = "WebService Compliance";
/* 321 */     Object[] arrayOfObject = { paramString };
/* 322 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 323 */     if (getExtendedFormat()) {
/* 324 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 326 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 328 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noReadPermission(String paramString) {
/* 335 */     String str1 = "";
/* 336 */     String str2 = "noReadPermission";
/* 337 */     String str3 = "WebService Compliance";
/* 338 */     Object[] arrayOfObject = { paramString };
/* 339 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 340 */     if (getExtendedFormat()) {
/* 341 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 343 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 345 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String unrecognizedFileType(String paramString) {
/* 352 */     String str1 = "";
/* 353 */     String str2 = "unrecognizedFileType";
/* 354 */     String str3 = "WebService Compliance";
/* 355 */     Object[] arrayOfObject = { paramString };
/* 356 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 357 */     if (getExtendedFormat()) {
/* 358 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 360 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 362 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String complianceCheckerHelp() {
/* 369 */     String str1 = "";
/* 370 */     String str2 = "complianceCheckerHelp";
/* 371 */     String str3 = "WebService Compliance";
/* 372 */     Object[] arrayOfObject = new Object[0];
/* 373 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 374 */     if (getExtendedFormat()) {
/* 375 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 377 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 379 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noFilesGiven() {
/* 386 */     String str1 = "";
/* 387 */     String str2 = "noFilesGiven";
/* 388 */     String str3 = "WebService Compliance";
/* 389 */     Object[] arrayOfObject = new Object[0];
/* 390 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 391 */     if (getExtendedFormat()) {
/* 392 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 394 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 396 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String invalidArgsGiven() {
/* 403 */     String str1 = "";
/* 404 */     String str2 = "invalidArgsGiven";
/* 405 */     String str3 = "WebService Compliance";
/* 406 */     Object[] arrayOfObject = new Object[0];
/* 407 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 408 */     if (getExtendedFormat()) {
/* 409 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 411 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 413 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String normalCompletion() {
/* 420 */     String str1 = "";
/* 421 */     String str2 = "normalCompletion";
/* 422 */     String str3 = "WebService Compliance";
/* 423 */     Object[] arrayOfObject = new Object[0];
/* 424 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 425 */     if (getExtendedFormat()) {
/* 426 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 428 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 430 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noWebServiceMbean(String paramString) {
/* 437 */     String str1 = "";
/* 438 */     String str2 = "noWebServiceMbean";
/* 439 */     String str3 = "WebService Compliance";
/* 440 */     Object[] arrayOfObject = { paramString };
/* 441 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 442 */     if (getExtendedFormat()) {
/* 443 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 445 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 447 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String noWebServiceClassLoader(String paramString) {
/* 454 */     String str1 = "";
/* 455 */     String str2 = "noWebServiceClassLoader";
/* 456 */     String str3 = "WebService Compliance";
/* 457 */     Object[] arrayOfObject = { paramString };
/* 458 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 459 */     if (getExtendedFormat()) {
/* 460 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 462 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 464 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String couldNotFindWARinEAR(String paramString) {
/* 471 */     String str1 = "";
/* 472 */     String str2 = "couldNotFindWARinEAR";
/* 473 */     String str3 = "WebService Compliance";
/* 474 */     Object[] arrayOfObject = { paramString };
/* 475 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 476 */     if (getExtendedFormat()) {
/* 477 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 479 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 481 */     return str1 + str4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String returnParamIsNotAllowed(String paramString) {
/* 488 */     String str1 = "";
/* 489 */     String str2 = "returnParamIsNotAllowed";
/* 490 */     String str3 = "WebService Compliance";
/* 491 */     Object[] arrayOfObject = { paramString };
/* 492 */     String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
/* 493 */     if (getExtendedFormat()) {
/* 494 */       DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
/*     */       
/* 496 */       str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
/*     */     } 
/* 498 */     return str1 + str4;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\WebServiceComplianceTextFormatter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */