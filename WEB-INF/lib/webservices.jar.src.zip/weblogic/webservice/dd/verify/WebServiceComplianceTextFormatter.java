package weblogic.webservice.dd.verify;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Locale;
import weblogic.i18n.Localizer;
import weblogic.i18ntools.L10nLookup;

public class WebServiceComplianceTextFormatter {
  private Localizer l10n;
  
  private boolean format = false;
  
  public WebServiceComplianceTextFormatter() { this.l10n = L10nLookup.getLocalizer(Locale.getDefault(), "weblogic.webservice.dd.verify.WebServiceComplianceTextLocalizer"); }
  
  public WebServiceComplianceTextFormatter(Locale paramLocale) { this.l10n = L10nLookup.getLocalizer(paramLocale, "weblogic.webservice.dd.verify.WebServiceComplianceTextLocalizer"); }
  
  public static WebServiceComplianceTextFormatter getInstance() { return new WebServiceComplianceTextFormatter(); }
  
  public static WebServiceComplianceTextFormatter getInstance(Locale paramLocale) { return new WebServiceComplianceTextFormatter(paramLocale); }
  
  public void setExtendedFormat(boolean paramBoolean) { this.format = paramBoolean; }
  
  public boolean getExtendedFormat() { return this.format; }
  
  public String noHandlerChainName() {
    String str1 = "";
    String str2 = "noHandlerChainName";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = new Object[0];
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String noHandlerClassName(String paramString) {
    String str1 = "";
    String str2 = "noHandlerClassName";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String noHandlersInChain(String paramString) {
    String str1 = "";
    String str2 = "noHandlersInChain";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String doesntExtendHandler(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "doesntExtendHandler";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String cantLoadHandlerClass(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "cantLoadHandlerClass";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String handlerNeedsDefaultCtor(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "handlerNeedsDefaultCtor";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String javaComponentClassNotFound(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "javaComponentClassNotFound";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String javaComponentNeedsDefaultCtor(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "javaComponentNeedsDefaultCtor";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String mustSpecifyJNDIOrEJBLink(String paramString) {
    String str1 = "";
    String str2 = "mustSpecifyJNDIOrEJBLink";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String couldntFindEJBLink(String paramString1, String paramString2, Exception paramException) {
    String str1 = "";
    String str2 = "couldntFindEJBLink";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2, paramException };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String couldntFindJNDIName(String paramString1, String paramString2, Exception paramException) {
    String str1 = "";
    String str2 = "couldntFindJNDIName";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2, paramException };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String ejbLinkWasNotEJBHome(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "ejbLinkWasNotEJBHome";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String jndiNameWasNotEJBHome(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "jndiNameWasNotEJBHome";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String ejbLinkWasNotStateless(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "ejbLinkWasNotStateless";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String jndiNameWasNotStateless(String paramString1, String paramString2) {
    String str1 = "";
    String str2 = "jndiNameWasNotStateless";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString1, paramString2 };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String noWebServices() {
    String str1 = "";
    String str2 = "noWebServices";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = new Object[0];
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String noFileOrDirectorNamed(String paramString) {
    String str1 = "";
    String str2 = "noFileOrDirectorNamed";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String noReadPermission(String paramString) {
    String str1 = "";
    String str2 = "noReadPermission";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String unrecognizedFileType(String paramString) {
    String str1 = "";
    String str2 = "unrecognizedFileType";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String complianceCheckerHelp() {
    String str1 = "";
    String str2 = "complianceCheckerHelp";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = new Object[0];
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String noFilesGiven() {
    String str1 = "";
    String str2 = "noFilesGiven";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = new Object[0];
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String invalidArgsGiven() {
    String str1 = "";
    String str2 = "invalidArgsGiven";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = new Object[0];
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String normalCompletion() {
    String str1 = "";
    String str2 = "normalCompletion";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = new Object[0];
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String noWebServiceMbean(String paramString) {
    String str1 = "";
    String str2 = "noWebServiceMbean";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String noWebServiceClassLoader(String paramString) {
    String str1 = "";
    String str2 = "noWebServiceClassLoader";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String couldNotFindWARinEAR(String paramString) {
    String str1 = "";
    String str2 = "couldNotFindWARinEAR";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
  
  public String returnParamIsNotAllowed(String paramString) {
    String str1 = "";
    String str2 = "returnParamIsNotAllowed";
    String str3 = "WebService Compliance";
    Object[] arrayOfObject = { paramString };
    String str4 = MessageFormat.format(this.l10n.get(str2), arrayOfObject);
    if (getExtendedFormat()) {
      DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 1);
      str1 = "<" + dateFormat.format(new Date()) + "><" + str3 + "><" + str2 + "> ";
    } 
    return str1 + str4;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\WebServiceComplianceTextFormatter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */