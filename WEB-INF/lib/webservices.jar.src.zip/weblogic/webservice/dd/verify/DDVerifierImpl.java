/*     */ package weblogic.webservice.dd.verify;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import weblogic.management.descriptors.webservice.ComponentsMBean;
/*     */ import weblogic.management.descriptors.webservice.HandlerChainsMBean;
/*     */ import weblogic.management.descriptors.webservice.JavaClassMBean;
/*     */ import weblogic.management.descriptors.webservice.OperationMBean;
/*     */ import weblogic.management.descriptors.webservice.OperationsMBean;
/*     */ import weblogic.management.descriptors.webservice.StatelessEJBMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.dd.DDLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DDVerifierImpl
/*     */   implements DDVerifier
/*     */ {
/*     */   private static final boolean debug = true;
/*     */   private static final boolean verbose = true;
/*     */   private ClassLoader cl;
/*     */   private WebServiceComplianceTextFormatter fmt;
/*     */   
/*     */   DDVerifierImpl(ClassLoader paramClassLoader) {
/*  35 */     this.fmt = new WebServiceComplianceTextFormatter();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.cl = paramClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void verifyHandlerChains(WebServicesMBean paramWebServicesMBean) throws VerifyException {
/*  47 */     HandlerChainsMBean handlerChainsMBean = paramWebServicesMBean.getHandlerChains();
/*     */     
/*  49 */     if (handlerChainsMBean != null) {
/*     */       
/*  51 */       HandlerChainChecker handlerChainChecker = new HandlerChainChecker(handlerChainsMBean, this.cl);
/*     */ 
/*     */ 
/*     */       
/*  55 */       handlerChainChecker.verify();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void verifyComponents(ComponentsMBean paramComponentsMBean) throws VerifyException {
/*  63 */     if (paramComponentsMBean == null) {
/*     */       return;
/*     */     }
/*  66 */     JavaClassMBean[] arrayOfJavaClassMBean = paramComponentsMBean.getJavaClassComponents();
/*     */     
/*  68 */     if (arrayOfJavaClassMBean != null && arrayOfJavaClassMBean.length > 0) {
/*  69 */       JavaComponentChecker javaComponentChecker = new JavaComponentChecker(arrayOfJavaClassMBean, this.cl);
/*  70 */       javaComponentChecker.verify();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  75 */     StatelessEJBMBean[] arrayOfStatelessEJBMBean = paramComponentsMBean.getStatelessEJBs();
/*     */     
/*  77 */     if (arrayOfStatelessEJBMBean != null && arrayOfStatelessEJBMBean.length > 0) {
/*  78 */       StatelessComponentChecker statelessComponentChecker = new StatelessComponentChecker(arrayOfStatelessEJBMBean);
/*     */ 
/*     */       
/*  81 */       statelessComponentChecker.verify();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void verifyOperations(OperationsMBean paramOperationsMBean) throws VerifyException {
/*  89 */     if (paramOperationsMBean == null)
/*     */       return; 
/*  91 */     OperationMBean[] arrayOfOperationMBean = paramOperationsMBean.getOperations();
/*  92 */     if (arrayOfOperationMBean != null && arrayOfOperationMBean.length > 0) {
/*  93 */       for (byte b = 0; b < arrayOfOperationMBean.length; b++) {
/*  94 */         OperationChecker operationChecker = new OperationChecker(arrayOfOperationMBean[b]);
/*  95 */         operationChecker.verify();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void verifyWebService(WebServiceMBean paramWebServiceMBean) throws VerifyException {
/* 105 */     verifyComponents(paramWebServiceMBean.getComponents());
/*     */     
/* 107 */     verifyOperations(paramWebServiceMBean.getOperations());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void verify(WebServicesMBean paramWebServicesMBean) throws VerifyException {
/* 113 */     Debug.assertion((paramWebServicesMBean != null));
/*     */     
/* 115 */     verifyHandlerChains(paramWebServicesMBean);
/*     */     
/* 117 */     WebServiceMBean[] arrayOfWebServiceMBean = paramWebServicesMBean.getWebServices();
/*     */     
/* 119 */     if (arrayOfWebServiceMBean == null || arrayOfWebServiceMBean.length == 0) {
/* 120 */       throw new VerifyException(this.fmt.noWebServices());
/*     */     }
/*     */     
/* 123 */     for (byte b = 0; b < arrayOfWebServiceMBean.length; b++) {
/* 124 */       verifyWebService(arrayOfWebServiceMBean[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 133 */     DDLoader dDLoader = new DDLoader();
/*     */     
/* 135 */     InputStream inputStream = null;
/* 136 */     ClassLoader classLoader = null;
/*     */     
/* 138 */     if (paramArrayOfString.length == 0) {
/* 139 */       inputStream = System.in;
/* 140 */       classLoader = DDVerifierImpl.class.getClassLoader();
/* 141 */     } else if (paramArrayOfString[0].endsWith(".xml")) {
/* 142 */       inputStream = new FileInputStream(paramArrayOfString[0]);
/* 143 */       classLoader = DDVerifierImpl.class.getClassLoader();
/* 144 */     } else if (paramArrayOfString[0].endsWith(".war")) {
/* 145 */       classLoader = new URLClassLoader(new URL[] { (new File(paramArrayOfString[0])).toURL() });
/* 146 */       inputStream = classLoader.getResourceAsStream("WEB-INF/web-services.xml");
/*     */     } 
/*     */ 
/*     */     
/* 150 */     WebServicesMBean webServicesMBean = dDLoader.load(inputStream);
/*     */     
/* 152 */     DDVerifier dDVerifier = DDVerifierFactory.newVerifier(classLoader);
/*     */     
/* 154 */     dDVerifier.verify(webServicesMBean);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\DDVerifierImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */