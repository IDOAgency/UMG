package weblogic.webservice.dd.verify;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLClassLoader;
import weblogic.management.descriptors.webservice.ComponentsMBean;
import weblogic.management.descriptors.webservice.HandlerChainsMBean;
import weblogic.management.descriptors.webservice.JavaClassMBean;
import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.OperationsMBean;
import weblogic.management.descriptors.webservice.StatelessEJBMBean;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.utils.Debug;
import weblogic.webservice.dd.DDLoader;

final class DDVerifierImpl implements DDVerifier {
  private static final boolean debug = true;
  
  private static final boolean verbose = true;
  
  private ClassLoader cl;
  
  private WebServiceComplianceTextFormatter fmt;
  
  DDVerifierImpl(ClassLoader paramClassLoader) {
    this.fmt = new WebServiceComplianceTextFormatter();
    this.cl = paramClassLoader;
  }
  
  private void verifyHandlerChains(WebServicesMBean paramWebServicesMBean) throws VerifyException {
    HandlerChainsMBean handlerChainsMBean = paramWebServicesMBean.getHandlerChains();
    if (handlerChainsMBean != null) {
      HandlerChainChecker handlerChainChecker = new HandlerChainChecker(handlerChainsMBean, this.cl);
      handlerChainChecker.verify();
    } 
  }
  
  private void verifyComponents(ComponentsMBean paramComponentsMBean) throws VerifyException {
    if (paramComponentsMBean == null)
      return; 
    JavaClassMBean[] arrayOfJavaClassMBean = paramComponentsMBean.getJavaClassComponents();
    if (arrayOfJavaClassMBean != null && arrayOfJavaClassMBean.length > 0) {
      JavaComponentChecker javaComponentChecker = new JavaComponentChecker(arrayOfJavaClassMBean, this.cl);
      javaComponentChecker.verify();
    } 
    StatelessEJBMBean[] arrayOfStatelessEJBMBean = paramComponentsMBean.getStatelessEJBs();
    if (arrayOfStatelessEJBMBean != null && arrayOfStatelessEJBMBean.length > 0) {
      StatelessComponentChecker statelessComponentChecker = new StatelessComponentChecker(arrayOfStatelessEJBMBean);
      statelessComponentChecker.verify();
    } 
  }
  
  private void verifyOperations(OperationsMBean paramOperationsMBean) throws VerifyException {
    if (paramOperationsMBean == null)
      return; 
    OperationMBean[] arrayOfOperationMBean = paramOperationsMBean.getOperations();
    if (arrayOfOperationMBean != null && arrayOfOperationMBean.length > 0)
      for (byte b = 0; b < arrayOfOperationMBean.length; b++) {
        OperationChecker operationChecker = new OperationChecker(arrayOfOperationMBean[b]);
        operationChecker.verify();
      }  
  }
  
  private void verifyWebService(WebServiceMBean paramWebServiceMBean) throws VerifyException {
    verifyComponents(paramWebServiceMBean.getComponents());
    verifyOperations(paramWebServiceMBean.getOperations());
  }
  
  public void verify(WebServicesMBean paramWebServicesMBean) throws VerifyException {
    Debug.assertion((paramWebServicesMBean != null));
    verifyHandlerChains(paramWebServicesMBean);
    WebServiceMBean[] arrayOfWebServiceMBean = paramWebServicesMBean.getWebServices();
    if (arrayOfWebServiceMBean == null || arrayOfWebServiceMBean.length == 0)
      throw new VerifyException(this.fmt.noWebServices()); 
    for (byte b = 0; b < arrayOfWebServiceMBean.length; b++)
      verifyWebService(arrayOfWebServiceMBean[0]); 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    DDLoader dDLoader = new DDLoader();
    InputStream inputStream = null;
    ClassLoader classLoader = null;
    if (paramArrayOfString.length == 0) {
      inputStream = System.in;
      classLoader = DDVerifierImpl.class.getClassLoader();
    } else if (paramArrayOfString[0].endsWith(".xml")) {
      inputStream = new FileInputStream(paramArrayOfString[0]);
      classLoader = DDVerifierImpl.class.getClassLoader();
    } else if (paramArrayOfString[0].endsWith(".war")) {
      classLoader = new URLClassLoader(new URL[] { (new File(paramArrayOfString[0])).toURL() });
      inputStream = classLoader.getResourceAsStream("WEB-INF/web-services.xml");
    } 
    WebServicesMBean webServicesMBean = dDLoader.load(inputStream);
    DDVerifier dDVerifier = DDVerifierFactory.newVerifier(classLoader);
    dDVerifier.verify(webServicesMBean);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\DDVerifierImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */