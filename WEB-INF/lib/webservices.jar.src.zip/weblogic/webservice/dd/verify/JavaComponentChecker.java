/*    */ package weblogic.webservice.dd.verify;
/*    */ 
/*    */ import weblogic.management.descriptors.webservice.JavaClassMBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JavaComponentChecker
/*    */   extends BaseChecker
/*    */ {
/*    */   private static final boolean debug = true;
/*    */   private static final boolean verbose = true;
/*    */   private JavaClassMBean[] mbeans;
/*    */   private ClassLoader cl;
/*    */   
/*    */   public JavaComponentChecker(JavaClassMBean[] paramArrayOfJavaClassMBean, ClassLoader paramClassLoader) {
/* 22 */     this.mbeans = paramArrayOfJavaClassMBean;
/* 23 */     this.cl = paramClassLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public void verify() throws VerifyException {
/* 28 */     for (byte b = 0; b < this.mbeans.length; b++) {
/*    */       
/* 30 */       String str = this.mbeans[b].getClassName();
/*    */ 
/*    */       
/*    */       try {
/* 34 */         Class clazz = this.cl.loadClass(str);
/*    */         
/* 36 */         if (!hasDefaultCtor(clazz)) {
/* 37 */           throw new VerifyException(this.fmt.javaComponentNeedsDefaultCtor(this.mbeans[b].getComponentName(), str));
/*    */ 
/*    */         
/*    */         }
/*    */       
/*    */       }
/* 43 */       catch (ClassNotFoundException classNotFoundException) {
/*    */         
/* 45 */         throw new VerifyException(this.fmt.javaComponentClassNotFound(this.mbeans[b].getComponentName(), str));
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\JavaComponentChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */