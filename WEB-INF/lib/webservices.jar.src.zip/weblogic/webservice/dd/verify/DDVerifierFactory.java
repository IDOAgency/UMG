/*    */ package weblogic.webservice.dd.verify;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DDVerifierFactory
/*    */ {
/* 13 */   public static DDVerifier newVerifier(ClassLoader paramClassLoader) { return new DDVerifierImpl(paramClassLoader); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\DDVerifierFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */