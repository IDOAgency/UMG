/*     */ package weblogic.webservice.dd.verify;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import weblogic.management.descriptors.webservice.StatelessEJBMBean;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.util.EJBHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StatelessComponentChecker
/*     */   extends BaseChecker
/*     */ {
/*     */   private static final boolean debug = true;
/*     */   private static final boolean verbose = true;
/*     */   private StatelessEJBMBean[] mbeans;
/*     */   
/*  25 */   public StatelessComponentChecker(StatelessEJBMBean[] paramArrayOfStatelessEJBMBean) { this.mbeans = paramArrayOfStatelessEJBMBean; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void verify() throws VerifyException {
/*  30 */     for (byte b = 0; b < this.mbeans.length; b++) {
/*     */ 
/*     */ 
/*     */       
/*  34 */       if (this.mbeans[b].getEJBLink() == null && this.mbeans[b].getJNDIName() == null) {
/*  35 */         throw new VerifyException(this.fmt.mustSpecifyJNDIOrEJBLink(this.mbeans[b].getComponentName()));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  42 */       if (isServer()) {
/*     */         String str;
/*  44 */         boolean bool = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  50 */         if (this.mbeans[b].getEJBLink() != null) {
/*  51 */           bool = true;
/*  52 */           str = this.mbeans[b].getEJBLink().getPath();
/*     */         } else {
/*  54 */           bool = false;
/*  55 */           str = this.mbeans[b].getJNDIName().getPath();
/*     */         } 
/*     */ 
/*     */         
/*  59 */         if (str == null) {
/*  60 */           throw new VerifyException(this.fmt.mustSpecifyJNDIOrEJBLink(this.mbeans[b].getComponentName()));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/*  66 */           Object object = EJBHelper.getEJBHome(this.mbeans[b]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  73 */           object.getClass().getMethod("create", (Class[])null);
/*     */         
/*     */         }
/*  76 */         catch (NamingException namingException) {
/*     */           
/*  78 */           String str1 = WebServiceLogger.logDDverifyStatelessNamingException();
/*  79 */           WebServiceLogger.logStackTrace(str1, namingException);
/*     */           
/*  81 */           if (bool) {
/*  82 */             throw new VerifyException(this.fmt.couldntFindEJBLink(this.mbeans[b].getComponentName(), str, namingException));
/*     */           }
/*     */ 
/*     */           
/*  86 */           throw new VerifyException(this.fmt.couldntFindJNDIName(this.mbeans[b].getComponentName(), str, namingException));
/*     */ 
/*     */         
/*     */         }
/*  90 */         catch (ClassCastException classCastException) {
/*     */           
/*  92 */           if (bool) {
/*  93 */             throw new VerifyException(this.fmt.ejbLinkWasNotEJBHome(this.mbeans[b].getComponentName(), str));
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*  98 */           throw new VerifyException(this.fmt.jndiNameWasNotEJBHome(this.mbeans[b].getComponentName(), str));
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 103 */         catch (NoSuchMethodException noSuchMethodException) {
/*     */           
/* 105 */           if (bool) {
/* 106 */             throw new VerifyException(this.fmt.ejbLinkWasNotStateless(this.mbeans[b].getComponentName(), str));
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 111 */           throw new VerifyException(this.fmt.jndiNameWasNotStateless(this.mbeans[b].getComponentName(), str));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\StatelessComponentChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */