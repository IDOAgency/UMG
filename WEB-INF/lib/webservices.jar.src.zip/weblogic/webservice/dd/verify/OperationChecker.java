/*    */ package weblogic.webservice.dd.verify;
/*    */ 
/*    */ import weblogic.management.descriptors.webservice.OperationMBean;
/*    */ import weblogic.management.descriptors.webservice.ParamMBean;
/*    */ import weblogic.management.descriptors.webservice.ParamsMBean;
/*    */ import weblogic.management.descriptors.webservice.ReliableDeliveryMBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OperationChecker
/*    */   extends BaseChecker
/*    */ {
/*    */   private static final boolean debug = true;
/*    */   private static final boolean verbose = true;
/*    */   private OperationMBean mbean;
/*    */   private String name;
/*    */   
/*    */   public OperationChecker(OperationMBean paramOperationMBean) {
/* 25 */     this.mbean = paramOperationMBean;
/* 26 */     this.name = paramOperationMBean.getOperationName();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void verify() throws VerifyException {
/* 32 */     ParamsMBean paramsMBean = this.mbean.getParams();
/* 33 */     ReliableDeliveryMBean reliableDeliveryMBean = this.mbean.getReliableDelivery();
/* 34 */     if (paramsMBean != null && reliableDeliveryMBean != null) {
/* 35 */       if (paramsMBean.getReturnParam() != null) {
/* 36 */         throw new VerifyException(this.fmt.returnParamIsNotAllowed(this.name));
/*    */       }
/*    */       
/* 39 */       ParamMBean[] arrayOfParamMBean = paramsMBean.getParams();
/* 40 */       if (arrayOfParamMBean != null)
/* 41 */         for (byte b = 0; b < arrayOfParamMBean.length; b++) {
/* 42 */           String str = arrayOfParamMBean[b].getParamStyle();
/* 43 */           if ("out".equals(str) || "inout".equals(str))
/* 44 */             throw new VerifyException(this.fmt.returnParamIsNotAllowed(this.name)); 
/*    */         }  
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\OperationChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */