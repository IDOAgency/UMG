package weblogic.webservice.dd.verify;

import weblogic.management.descriptors.webservice.OperationMBean;
import weblogic.management.descriptors.webservice.ParamMBean;
import weblogic.management.descriptors.webservice.ParamsMBean;
import weblogic.management.descriptors.webservice.ReliableDeliveryMBean;

public final class OperationChecker extends BaseChecker {
  private static final boolean debug = true;
  
  private static final boolean verbose = true;
  
  private OperationMBean mbean;
  
  private String name;
  
  public OperationChecker(OperationMBean paramOperationMBean) {
    this.mbean = paramOperationMBean;
    this.name = paramOperationMBean.getOperationName();
  }
  
  public void verify() throws VerifyException {
    ParamsMBean paramsMBean = this.mbean.getParams();
    ReliableDeliveryMBean reliableDeliveryMBean = this.mbean.getReliableDelivery();
    if (paramsMBean != null && reliableDeliveryMBean != null) {
      if (paramsMBean.getReturnParam() != null)
        throw new VerifyException(this.fmt.returnParamIsNotAllowed(this.name)); 
      ParamMBean[] arrayOfParamMBean = paramsMBean.getParams();
      if (arrayOfParamMBean != null)
        for (byte b = 0; b < arrayOfParamMBean.length; b++) {
          String str = arrayOfParamMBean[b].getParamStyle();
          if ("out".equals(str) || "inout".equals(str))
            throw new VerifyException(this.fmt.returnParamIsNotAllowed(this.name)); 
        }  
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\OperationChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */