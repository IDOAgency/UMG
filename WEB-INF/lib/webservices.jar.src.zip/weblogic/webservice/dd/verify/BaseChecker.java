package weblogic.webservice.dd.verify;

import weblogic.kernel.Kernel;

abstract class BaseChecker {
  protected WebServiceComplianceTextFormatter fmt = new WebServiceComplianceTextFormatter();
  
  private boolean isServer = Kernel.isServer();
  
  protected boolean isServer() { return this.isServer; }
  
  protected boolean hasDefaultCtor(Class paramClass) {
    try {
      paramClass.getConstructor((Class[])null);
      return true;
    } catch (NoSuchMethodException noSuchMethodException) {
      return false;
    } 
  }
  
  abstract void verify();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\BaseChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */