package weblogic.webservice.dd.verify;

import weblogic.utils.NestedException;

public class VerifyException extends NestedException {
  public VerifyException(String paramString) { super(paramString); }
  
  public VerifyException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\VerifyException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */