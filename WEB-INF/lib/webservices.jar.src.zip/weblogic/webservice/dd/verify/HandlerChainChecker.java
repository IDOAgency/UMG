package weblogic.webservice.dd.verify;

import weblogic.management.descriptors.webservice.HandlerChainMBean;
import weblogic.management.descriptors.webservice.HandlerChainsMBean;
import weblogic.management.descriptors.webservice.HandlerMBean;
import weblogic.utils.Debug;

final class HandlerChainChecker extends BaseChecker {
  private static final boolean debug = true;
  
  private static final boolean verbose = true;
  
  private ClassLoader cl;
  
  private HandlerChainsMBean chainsMBean;
  
  public HandlerChainChecker(HandlerChainsMBean paramHandlerChainsMBean, ClassLoader paramClassLoader) {
    Debug.assertion((paramHandlerChainsMBean != null));
    Debug.assertion((paramClassLoader != null));
    this.chainsMBean = paramHandlerChainsMBean;
    this.cl = paramClassLoader;
  }
  
  public void verify() throws VerifyException {
    if (this.chainsMBean == null)
      return; 
    HandlerChainMBean[] arrayOfHandlerChainMBean = this.chainsMBean.getHandlerChains();
    for (byte b = 0; b < arrayOfHandlerChainMBean.length; b++) {
      String str = arrayOfHandlerChainMBean[b].getHandlerChainName();
      if (str == null || "".equals(str))
        throw new VerifyException(this.fmt.noHandlerChainName()); 
      HandlerMBean[] arrayOfHandlerMBean = arrayOfHandlerChainMBean[b].getHandlers();
      if (arrayOfHandlerMBean == null || arrayOfHandlerMBean.length == 0)
        throw new VerifyException(this.fmt.noHandlersInChain(str)); 
      for (byte b1 = 0; b1 < arrayOfHandlerMBean.length; b1++)
        verifyHandler(arrayOfHandlerMBean[b1], str); 
    } 
  }
  
  private void verifyHandler(HandlerMBean paramHandlerMBean, String paramString) throws VerifyException {
    String str = paramHandlerMBean.getClassName();
    if (str == null || "".equals(str))
      throw new VerifyException(this.fmt.noHandlerClassName(paramString)); 
    try {
      Class clazz = this.cl.loadClass(str);
      if (!javax.xml.rpc.handler.Handler.class.isAssignableFrom(clazz))
        throw new VerifyException(this.fmt.doesntExtendHandler(paramString, str)); 
      if (!hasDefaultCtor(clazz))
        throw new VerifyException(this.fmt.handlerNeedsDefaultCtor(paramString, str)); 
    } catch (ClassNotFoundException classNotFoundException) {
      throw new VerifyException(this.fmt.cantLoadHandlerClass(paramString, str));
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\HandlerChainChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */