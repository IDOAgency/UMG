/*    */ package weblogic.webservice.dd.verify;
/*    */ 
/*    */ import weblogic.management.descriptors.webservice.HandlerChainMBean;
/*    */ import weblogic.management.descriptors.webservice.HandlerChainsMBean;
/*    */ import weblogic.management.descriptors.webservice.HandlerMBean;
/*    */ import weblogic.utils.Debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HandlerChainChecker
/*    */   extends BaseChecker
/*    */ {
/*    */   private static final boolean debug = true;
/*    */   private static final boolean verbose = true;
/*    */   private ClassLoader cl;
/*    */   private HandlerChainsMBean chainsMBean;
/*    */   
/*    */   public HandlerChainChecker(HandlerChainsMBean paramHandlerChainsMBean, ClassLoader paramClassLoader) {
/* 30 */     Debug.assertion((paramHandlerChainsMBean != null));
/* 31 */     Debug.assertion((paramClassLoader != null));
/*    */ 
/*    */     
/* 34 */     this.chainsMBean = paramHandlerChainsMBean;
/* 35 */     this.cl = paramClassLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public void verify() throws VerifyException {
/* 40 */     if (this.chainsMBean == null)
/*    */       return; 
/* 42 */     HandlerChainMBean[] arrayOfHandlerChainMBean = this.chainsMBean.getHandlerChains();
/*    */     
/* 44 */     for (byte b = 0; b < arrayOfHandlerChainMBean.length; b++) {
/*    */       
/* 46 */       String str = arrayOfHandlerChainMBean[b].getHandlerChainName();
/*    */ 
/*    */       
/* 49 */       if (str == null || "".equals(str))
/*    */       {
/* 51 */         throw new VerifyException(this.fmt.noHandlerChainName());
/*    */       }
/*    */ 
/*    */       
/* 55 */       HandlerMBean[] arrayOfHandlerMBean = arrayOfHandlerChainMBean[b].getHandlers();
/*    */ 
/*    */       
/* 58 */       if (arrayOfHandlerMBean == null || arrayOfHandlerMBean.length == 0) {
/* 59 */         throw new VerifyException(this.fmt.noHandlersInChain(str));
/*    */       }
/*    */       
/* 62 */       for (byte b1 = 0; b1 < arrayOfHandlerMBean.length; b1++) {
/* 63 */         verifyHandler(arrayOfHandlerMBean[b1], str);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void verifyHandler(HandlerMBean paramHandlerMBean, String paramString) throws VerifyException {
/* 71 */     String str = paramHandlerMBean.getClassName();
/*    */     
/* 73 */     if (str == null || "".equals(str)) {
/* 74 */       throw new VerifyException(this.fmt.noHandlerClassName(paramString));
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 80 */       Class clazz = this.cl.loadClass(str);
/*    */ 
/*    */       
/* 83 */       if (!javax.xml.rpc.handler.Handler.class.isAssignableFrom(clazz)) {
/* 84 */         throw new VerifyException(this.fmt.doesntExtendHandler(paramString, str));
/*    */       }
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 90 */       if (!hasDefaultCtor(clazz)) {
/* 91 */         throw new VerifyException(this.fmt.handlerNeedsDefaultCtor(paramString, str));
/*    */       
/*    */       }
/*    */     
/*    */     }
/* 96 */     catch (ClassNotFoundException classNotFoundException) {
/* 97 */       throw new VerifyException(this.fmt.cantLoadHandlerClass(paramString, str));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\verify\HandlerChainChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */