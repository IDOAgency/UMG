/*    */ package weblogic.webservice.dd;
/*    */ 
/*    */ import weblogic.utils.NestedException;
/*    */ import weblogic.xml.stream.Location;
/*    */ 
/*    */ 
/*    */ public class DDProcessingException
/*    */   extends NestedException
/*    */ {
/* 10 */   private StringBuffer locationString = new StringBuffer();
/*    */   
/*    */   public DDProcessingException() {}
/*    */   
/* 14 */   public DDProcessingException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
/*    */ 
/*    */   
/* 17 */   public DDProcessingException(String paramString) { super(paramString); }
/*    */ 
/*    */   
/*    */   public DDProcessingException(String paramString, Location paramLocation) {
/* 21 */     super(paramString);
/* 22 */     int i = paramLocation.getLineNumber();
/* 23 */     int j = paramLocation.getColumnNumber();
/* 24 */     if (i > 0) {
/* 25 */       this.locationString.append(" (Line ").append(i);
/* 26 */       if (j > 0) {
/* 27 */         this.locationString.append(", Column ").append(j);
/*    */       }
/* 29 */       this.locationString.append(")");
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 34 */     if (this.locationString.length() > 0) {
/* 35 */       return super.getMessage() + this.locationString.toString();
/*    */     }
/* 37 */     return super.getMessage();
/*    */   }
/*    */   
/* 40 */   public String getLocalizedMessage() { return getMessage(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\DDProcessingException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */