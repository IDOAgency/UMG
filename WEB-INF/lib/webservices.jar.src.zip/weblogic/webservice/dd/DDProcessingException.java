package weblogic.webservice.dd;

import weblogic.utils.NestedException;
import weblogic.xml.stream.Location;

public class DDProcessingException extends NestedException {
  private StringBuffer locationString = new StringBuffer();
  
  public DDProcessingException() {}
  
  public DDProcessingException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
  
  public DDProcessingException(String paramString) { super(paramString); }
  
  public DDProcessingException(String paramString, Location paramLocation) {
    super(paramString);
    int i = paramLocation.getLineNumber();
    int j = paramLocation.getColumnNumber();
    if (i > 0) {
      this.locationString.append(" (Line ").append(i);
      if (j > 0)
        this.locationString.append(", Column ").append(j); 
      this.locationString.append(")");
    } 
  }
  
  public String getMessage() {
    if (this.locationString.length() > 0)
      return super.getMessage() + this.locationString.toString(); 
    return super.getMessage();
  }
  
  public String getLocalizedMessage() { return getMessage(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\DDProcessingException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */