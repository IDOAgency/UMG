/*     */ package weblogic.webservice.dd;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.StringTokenizer;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ import weblogic.webservice.server.WebServiceFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodDescriptor
/*     */ {
/*     */   private String methodName;
/*     */   private String methodString;
/*     */   private Class[] params;
/*     */   
/*     */   public MethodDescriptor(String paramString) throws ConfigException {
/*  27 */     this.methodString = paramString;
/*     */     
/*  29 */     int i = paramString.indexOf('(');
/*  30 */     if (i == -1) {
/*  31 */       this.methodName = paramString;
/*     */       return;
/*     */     } 
/*  34 */     int j = paramString.indexOf(')', i);
/*  35 */     if (j == -1) {
/*  36 */       this.methodName = paramString;
/*     */       
/*     */       return;
/*     */     } 
/*  40 */     this.methodName = paramString.substring(0, i);
/*     */     
/*  42 */     String str = paramString.substring(i + 1, j);
/*     */     
/*  44 */     ArrayList arrayList = new ArrayList();
/*  45 */     StringTokenizer stringTokenizer = new StringTokenizer(str, ",");
/*  46 */     while (stringTokenizer.hasMoreTokens()) {
/*  47 */       String str1 = stringTokenizer.nextToken().trim();
/*  48 */       arrayList.add(WebServiceFactory.loadClass(str1));
/*     */     } 
/*     */     
/*  51 */     this.params = (Class[])arrayList.toArray(new Class[0]);
/*     */   }
/*     */   
/*     */   public MethodDescriptor(Method paramMethod) {
/*  55 */     this.methodName = paramMethod.getName();
/*     */     
/*  57 */     Class[] arrayOfClass = paramMethod.getParameterTypes();
/*  58 */     if (arrayOfClass.length > 0) {
/*  59 */       this.methodString = this.methodName + "(";
/*  60 */       for (byte b = 0; b < arrayOfClass.length; b++) {
/*  61 */         this.methodString += arrayOfClass[b].getName() + ",";
/*     */       }
/*  63 */       this.methodString = this.methodString.substring(0, this.methodString.length() - 1) + ")";
/*     */     } else {
/*  65 */       this.methodString = this.methodName;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Method paramMethod) {
/*  74 */     if (!paramMethod.getName().equals(this.methodName)) {
/*  75 */       return false;
/*     */     }
/*  77 */     if (this.params == null) {
/*  78 */       return true;
/*     */     }
/*  80 */     Class[] arrayOfClass = paramMethod.getParameterTypes();
/*  81 */     return isAssignable(arrayOfClass, this.params);
/*     */   }
/*     */   
/*     */   public static boolean isAssignable(Class[] paramArrayOfClass1, Class[] paramArrayOfClass2) {
/*  85 */     if (paramArrayOfClass1 == null || paramArrayOfClass2 == null) return false; 
/*  86 */     if (paramArrayOfClass1.length != paramArrayOfClass2.length) return false;
/*     */     
/*  88 */     for (byte b = 0; b < paramArrayOfClass1.length; b++) {
/*  89 */       if (!isAssignable(paramArrayOfClass1[b], paramArrayOfClass2[b])) {
/*  90 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  94 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean isAssignable(Class paramClass1, Class paramClass2) {
/*  98 */     Class clazz1 = paramClass1;
/*  99 */     Class clazz2 = paramClass2;
/*     */     
/* 101 */     if (clazz1.getName().equals(clazz2.getName())) return true;
/*     */     
/* 103 */     if (clazz2.isAssignableFrom(clazz1)) return true;
/*     */     
/* 105 */     if (!clazz1.isArray() || !clazz2.isArray()) return false;
/*     */     
/* 107 */     byte b1 = 0;
/* 108 */     while (clazz1.getComponentType() != null) {
/* 109 */       b1++;
/* 110 */       clazz1 = clazz1.getComponentType();
/*     */     } 
/*     */     
/* 113 */     byte b2 = 0;
/* 114 */     while (clazz2.getComponentType() != null) {
/* 115 */       b2++;
/* 116 */       clazz2 = clazz2.getComponentType();
/*     */     } 
/*     */     
/* 119 */     return (b1 == b2 && clazz2.isAssignableFrom(clazz1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public Class[] getParams() { return this.params; }
/*     */   
/* 128 */   public String getName() { return this.methodName; }
/*     */   
/* 130 */   public String getMethodString() { return this.methodString; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\MethodDescriptor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */