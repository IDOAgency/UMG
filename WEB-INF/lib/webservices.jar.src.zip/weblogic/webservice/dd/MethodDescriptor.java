package weblogic.webservice.dd;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.StringTokenizer;
import weblogic.webservice.server.ConfigException;
import weblogic.webservice.server.WebServiceFactory;

public class MethodDescriptor {
  private String methodName;
  
  private String methodString;
  
  private Class[] params;
  
  public MethodDescriptor(String paramString) throws ConfigException {
    this.methodString = paramString;
    int i = paramString.indexOf('(');
    if (i == -1) {
      this.methodName = paramString;
      return;
    } 
    int j = paramString.indexOf(')', i);
    if (j == -1) {
      this.methodName = paramString;
      return;
    } 
    this.methodName = paramString.substring(0, i);
    String str = paramString.substring(i + 1, j);
    ArrayList arrayList = new ArrayList();
    StringTokenizer stringTokenizer = new StringTokenizer(str, ",");
    while (stringTokenizer.hasMoreTokens()) {
      String str1 = stringTokenizer.nextToken().trim();
      arrayList.add(WebServiceFactory.loadClass(str1));
    } 
    this.params = (Class[])arrayList.toArray(new Class[0]);
  }
  
  public MethodDescriptor(Method paramMethod) {
    this.methodName = paramMethod.getName();
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    if (arrayOfClass.length > 0) {
      this.methodString = this.methodName + "(";
      for (byte b = 0; b < arrayOfClass.length; b++)
        this.methodString += arrayOfClass[b].getName() + ","; 
      this.methodString = this.methodString.substring(0, this.methodString.length() - 1) + ")";
    } else {
      this.methodString = this.methodName;
    } 
  }
  
  public boolean equals(Method paramMethod) {
    if (!paramMethod.getName().equals(this.methodName))
      return false; 
    if (this.params == null)
      return true; 
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    return isAssignable(arrayOfClass, this.params);
  }
  
  public static boolean isAssignable(Class[] paramArrayOfClass1, Class[] paramArrayOfClass2) {
    if (paramArrayOfClass1 == null || paramArrayOfClass2 == null)
      return false; 
    if (paramArrayOfClass1.length != paramArrayOfClass2.length)
      return false; 
    for (byte b = 0; b < paramArrayOfClass1.length; b++) {
      if (!isAssignable(paramArrayOfClass1[b], paramArrayOfClass2[b]))
        return false; 
    } 
    return true;
  }
  
  private static boolean isAssignable(Class paramClass1, Class paramClass2) {
    Class clazz1 = paramClass1;
    Class clazz2 = paramClass2;
    if (clazz1.getName().equals(clazz2.getName()))
      return true; 
    if (clazz2.isAssignableFrom(clazz1))
      return true; 
    if (!clazz1.isArray() || !clazz2.isArray())
      return false; 
    byte b1 = 0;
    while (clazz1.getComponentType() != null) {
      b1++;
      clazz1 = clazz1.getComponentType();
    } 
    byte b2 = 0;
    while (clazz2.getComponentType() != null) {
      b2++;
      clazz2 = clazz2.getComponentType();
    } 
    return (b1 == b2 && clazz2.isAssignableFrom(clazz1));
  }
  
  public Class[] getParams() { return this.params; }
  
  public String getName() { return this.methodName; }
  
  public String getMethodString() { return this.methodString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\MethodDescriptor.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */