/*    */ package weblogic.webservice.dd;
/*    */ 
/*    */ import weblogic.webservice.tools.MethodIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaClassIntrospector
/*    */   extends ComponentIntrospector
/*    */ {
/*    */   Class clazz;
/*    */   
/*    */   public JavaClassIntrospector(Class paramClass) {
/* 15 */     super(paramClass.getName());
/* 16 */     this.clazz = paramClass;
/*    */   }
/*    */ 
/*    */   
/* 20 */   public MethodIterator getMethods() { return new MethodIterator(this.clazz); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\JavaClassIntrospector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */