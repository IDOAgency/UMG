package weblogic.webservice.dd;

import weblogic.webservice.tools.MethodIterator;

public class JavaClassIntrospector extends ComponentIntrospector {
  Class clazz;
  
  public JavaClassIntrospector(Class paramClass) {
    super(paramClass.getName());
    this.clazz = paramClass;
  }
  
  public MethodIterator getMethods() { return new MethodIterator(this.clazz); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\JavaClassIntrospector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */