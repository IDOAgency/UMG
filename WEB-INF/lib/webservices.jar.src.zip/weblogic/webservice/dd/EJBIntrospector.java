/*    */ package weblogic.webservice.dd;
/*    */ 
/*    */ import weblogic.j2ee.descriptor.SessionBeanBean;
/*    */ import weblogic.j2ee.descriptor.wl.WeblogicEnterpriseBeanBean;
/*    */ import weblogic.webservice.tools.MethodIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EJBIntrospector
/*    */   extends ComponentIntrospector
/*    */ {
/*    */   private static boolean debug = false;
/*    */   private SessionBeanBean mbean;
/*    */   private WeblogicEnterpriseBeanBean wlmbean;
/*    */   
/*    */   public EJBIntrospector(SessionBeanBean paramSessionBeanBean, WeblogicEnterpriseBeanBean paramWeblogicEnterpriseBeanBean) {
/* 22 */     super(paramSessionBeanBean.getEjbName());
/* 23 */     this.wlmbean = paramWeblogicEnterpriseBeanBean;
/* 24 */     this.mbean = paramSessionBeanBean;
/*    */   }
/*    */ 
/*    */   
/* 28 */   public String getEJBName() { return (this.mbean == null) ? null : this.mbean.getEjbName(); }
/*    */ 
/*    */ 
/*    */   
/* 32 */   public String getJNDIName() { return (this.wlmbean == null) ? null : this.wlmbean.getJNDIName(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodIterator getMethods() throws ClassNotFoundException {
/* 42 */     MethodIterator methodIterator = null;
/* 43 */     if (this.mbean != null) {
/* 44 */       Class clazz = loadClass(getRemoteOrLocalInterface(this.mbean));
/* 45 */       methodIterator = new MethodIterator(clazz);
/* 46 */       methodIterator.setEJBExcludes();
/*    */     } 
/* 48 */     return methodIterator;
/*    */   }
/*    */ 
/*    */   
/*    */   private String getRemoteOrLocalInterface(SessionBeanBean paramSessionBeanBean) {
/* 53 */     if (paramSessionBeanBean.getRemote() != null) {
/* 54 */       return paramSessionBeanBean.getRemote();
/*    */     }
/* 56 */     return paramSessionBeanBean.getLocal();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\EJBIntrospector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */