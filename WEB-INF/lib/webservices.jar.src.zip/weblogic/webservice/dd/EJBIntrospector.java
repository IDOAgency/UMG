package weblogic.webservice.dd;

import weblogic.j2ee.descriptor.SessionBeanBean;
import weblogic.j2ee.descriptor.wl.WeblogicEnterpriseBeanBean;
import weblogic.webservice.tools.MethodIterator;

public class EJBIntrospector extends ComponentIntrospector {
  private static boolean debug = false;
  
  private SessionBeanBean mbean;
  
  private WeblogicEnterpriseBeanBean wlmbean;
  
  public EJBIntrospector(SessionBeanBean paramSessionBeanBean, WeblogicEnterpriseBeanBean paramWeblogicEnterpriseBeanBean) {
    super(paramSessionBeanBean.getEjbName());
    this.wlmbean = paramWeblogicEnterpriseBeanBean;
    this.mbean = paramSessionBeanBean;
  }
  
  public String getEJBName() { return (this.mbean == null) ? null : this.mbean.getEjbName(); }
  
  public String getJNDIName() { return (this.wlmbean == null) ? null : this.wlmbean.getJNDIName(); }
  
  public MethodIterator getMethods() throws ClassNotFoundException {
    MethodIterator methodIterator = null;
    if (this.mbean != null) {
      Class clazz = loadClass(getRemoteOrLocalInterface(this.mbean));
      methodIterator = new MethodIterator(clazz);
      methodIterator.setEJBExcludes();
    } 
    return methodIterator;
  }
  
  private String getRemoteOrLocalInterface(SessionBeanBean paramSessionBeanBean) {
    if (paramSessionBeanBean.getRemote() != null)
      return paramSessionBeanBean.getRemote(); 
    return paramSessionBeanBean.getLocal();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\dd\EJBIntrospector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */