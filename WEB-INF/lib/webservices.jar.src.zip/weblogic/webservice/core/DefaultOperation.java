package weblogic.webservice.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import javax.xml.namespace.QName;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.collections.Pool;
import weblogic.utils.collections.StackPool;
import weblogic.utils.encoders.BASE64Encoder;
import weblogic.webservice.HandlerChain;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.async.AsyncInfo;
import weblogic.webservice.async.FutureResult;
import weblogic.webservice.monitoring.OperationStats;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;

public class DefaultOperation implements Operation {
  private static final boolean verbose = getVerboseProp();
  
  private String name;
  
  private String namespace;
  
  private String encodingStyle;
  
  private String soapAction;
  
  private String[] parameterOrder;
  
  private boolean oneway;
  
  private String conversationPhase;
  
  private int persistDuration;
  
  private String style;
  
  private InvocationHandler target;
  
  private Port port;
  
  private TypeMappingRegistry typeMappingRegistry;
  
  private Message input;
  
  private Message output;
  
  private ArrayList faults;
  
  private static final String SOAP_ACTION = "SOAPAction";
  
  private final Pool handlerChainPool;
  
  private HandlerInfo[] handlerInfos;
  
  private OperationStats mStats;
  
  private final HandlerInfo clientHandlerInfo;
  
  private final HandlerInfo reliableHandlerInfo;
  
  private final HandlerInfo rmSendingHandlerInfo;
  
  private final HandlerInfo conversationHandlerInfo;
  
  private final HandlerInfo checkSoapFaultHandlerInfo;
  
  private static boolean getVerboseProp() {
    try {
      return Boolean.getBoolean("weblogic.webservice.verbose");
    } catch (SecurityException securityException) {
      return false;
    } 
  }
  
  DefaultOperation(String paramString, Port paramPort, HandlerInfo[] paramArrayOfHandlerInfo) {
    this.soapAction = "\"\"";
    this.oneway = false;
    this.persistDuration = -1;
    this.style = "rpc";
    this.input = new DefaultMessage(this);
    this.output = new DefaultMessage(this);
    this.faults = new ArrayList();
    this.handlerChainPool = new StackPool(32);
    this.mStats = null;
    this.clientHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.ClientHandler.class, null, null);
    this.reliableHandlerInfo = new HandlerInfo(weblogic.webservice.saf.SAFHandler.class, null, null);
    this.rmSendingHandlerInfo = new HandlerInfo(weblogic.webservice.saf.SendingHandler.class, null, null);
    this.conversationHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.ClientConversationHandler.class, null, null);
    this.checkSoapFaultHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.CheckSoapFaultHandler.class, null, null);
    this.name = paramString;
    this.port = paramPort;
    this.handlerInfos = paramArrayOfHandlerInfo;
    this.input.setName(paramString);
    this.output.setName(paramString + "Response");
  }
  
  public HandlerInfo[] getHandlerInfos() { return this.handlerInfos; }
  
  public void setHandlerInfos(HandlerInfo[] paramArrayOfHandlerInfo) { this.handlerInfos = paramArrayOfHandlerInfo; }
  
  public void destroy() {
    Iterator iterator = this.handlerChainPool.iterator();
    while (iterator.hasNext())
      ((HandlerChain)iterator.next()).destroy(); 
  }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public Port getPort() { return this.port; }
  
  public String getNamespace() { return this.namespace; }
  
  public void setNamespace(String paramString) { this.namespace = paramString; }
  
  public String getEncodingStyle() { return this.encodingStyle; }
  
  public void setEncodingStyle(String paramString) { this.encodingStyle = paramString; }
  
  public TypeMappingRegistry getTypeMappingRegistry() { return this.typeMappingRegistry; }
  
  public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) {
    this.typeMappingRegistry = paramTypeMappingRegistry;
    this.input.setTypeMappingRegistry(paramTypeMappingRegistry);
    this.output.setTypeMappingRegistry(paramTypeMappingRegistry);
    for (Message message : this.faults)
      message.setTypeMappingRegistry(paramTypeMappingRegistry); 
  }
  
  public String getSoapAction() { return this.soapAction; }
  
  public void setSoapAction(String paramString) {
    if ("".equals(paramString)) {
      paramString = "\"\"";
    } else if (paramString != null) {
      if (!paramString.startsWith("\""))
        paramString = "\"" + paramString; 
      if (!paramString.endsWith("\""))
        paramString = paramString + "\""; 
    } 
    this.soapAction = paramString;
  }
  
  public String[] getParameterOrder() { return this.parameterOrder; }
  
  public void setParameterOrder(String paramString) {
    if (paramString != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(paramString);
      int i = stringTokenizer.countTokens();
      String[] arrayOfString = new String[i];
      for (byte b = 0; b < i; b++)
        arrayOfString[b] = stringTokenizer.nextToken(); 
      setParameterOrder(arrayOfString);
    } else {
      setParameterOrder((String[])null);
    } 
  }
  
  public void setParameterOrder(String[] paramArrayOfString) { this.parameterOrder = paramArrayOfString; }
  
  public boolean isDocumentStyle() { return "document".equalsIgnoreCase(this.style); }
  
  public void setDocumentStyle() {
    this.input.useLiteral();
    this.output.useLiteral();
    this.style = "document";
  }
  
  public boolean isRpcStyle() { return "rpc".equals(this.style); }
  
  public void setRpcStyle() {
    this.input.useEncoded();
    this.output.useEncoded();
    this.style = "rpc";
  }
  
  public Message getInput() { return this.input; }
  
  public void setInput(Message paramMessage) { this.input = paramMessage; }
  
  public Message getOutput() { return this.output; }
  
  public void setOutput(Message paramMessage) { this.output = this.output; }
  
  public Iterator getFaults() { return this.faults.iterator(); }
  
  public Message getFault(String paramString) {
    for (Message message : this.faults) {
      if (message.getName().equals(paramString))
        return message; 
    } 
    return null;
  }
  
  public Message addFault() {
    FaultMessage faultMessage = new FaultMessage(this);
    faultMessage.setTypeMappingRegistry(this.typeMappingRegistry);
    this.faults.add(faultMessage);
    return faultMessage;
  }
  
  public boolean isOneway() { return this.oneway; }
  
  public void setOneway(boolean paramBoolean) { this.oneway = paramBoolean; }
  
  public void setStyle(String paramString) {
    if ("rpc".equalsIgnoreCase(paramString) || "document".equalsIgnoreCase(paramString) || "documentwrapped".equalsIgnoreCase(paramString)) {
      this.style = paramString.toLowerCase();
    } else if (paramString == null) {
      this.style = "rpc";
    } else {
      throw new IllegalArgumentException("Invalid operation style: " + paramString);
    } 
  }
  
  public String getStyle() { return this.style; }
  
  public void setConversationPhase(String paramString) { this.conversationPhase = paramString; }
  
  public String getConversationPhase() { return this.conversationPhase; }
  
  public void setPersistDurationTime(int paramInt) { this.persistDuration = paramInt; }
  
  public int getPersistDurationTime() { return this.persistDuration; }
  
  public Part getReturnPart() {
    for (Iterator iterator = this.output.getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.RETURN)
        return part; 
    } 
    return null;
  }
  
  void fillInHeaders(MimeHeaders paramMimeHeaders) {
    if (this.soapAction != null && !"".equals(this.soapAction))
      paramMimeHeaders.addHeader("SOAPAction", this.soapAction); 
    String str1 = this.port.getUserName();
    String str2 = this.port.getPassword();
    if (str1 != null || str2 != null)
      paramMimeHeaders.addHeader("Authorization", "Basic " + getEncodedAuthToken(str1, str2)); 
    String str3 = this.port.getProxyUserName();
    String str4 = this.port.getProxyPassword();
    if (str3 != null || str4 != null)
      paramMimeHeaders.addHeader("Proxy-Authorization", "Basic " + getEncodedAuthToken(str3, str4)); 
    String str5 = this.port.getCookiesAsString();
    if (str5.length() > 0)
      paramMimeHeaders.addHeader("Cookie", this.port.getCookiesAsString()); 
  }
  
  public Object invoke(Map paramMap1, Map paramMap2, PrintStream paramPrintStream) throws TargetInvocationException, SOAPException, IOException {
    Object[] arrayOfObject = this.input.getSortedParameters(paramMap2);
    return invoke(paramMap1, arrayOfObject, paramPrintStream);
  }
  
  public Object invoke(Object[] paramArrayOfObject) throws TargetInvocationException, SOAPException, IOException {
    HashMap hashMap = new HashMap();
    Object object = invoke(hashMap, paramArrayOfObject, null);
    if (hashMap.size() > 1)
      throw new SOAPException("more than one return value, use invoke( outParams, args )"); 
    return object;
  }
  
  public Object invoke(Map paramMap, Object[] paramArrayOfObject) throws TargetInvocationException, SOAPException, IOException { return invoke(paramMap, paramArrayOfObject, null); }
  
  public FutureResult asyncInvoke(Map paramMap, Object[] paramArrayOfObject, AsyncInfo paramAsyncInfo, PrintStream paramPrintStream) throws SOAPException, SOAPFaultException, IOException { return (new ClientDispatcher(this, paramMap, paramPrintStream)).asyncDispatch(paramArrayOfObject, paramAsyncInfo); }
  
  public Object invoke(Map paramMap, Object[] paramArrayOfObject, PrintStream paramPrintStream) throws TargetInvocationException, SOAPException, IOException { return (new ClientDispatcher(this, paramMap, paramPrintStream)).dispatch(paramArrayOfObject); }
  
  public InvocationHandler getInvocationHandler() { return this.target; }
  
  public void setInvocationHandler(InvocationHandler paramInvocationHandler) { this.target = paramInvocationHandler; }
  
  private void dumpRequest(WLMessageContext paramWLMessageContext, PrintStream paramPrintStream) throws SOAPException { dumpMessage("REQUEST TO SERVER", paramWLMessageContext.getMessage(), paramPrintStream); }
  
  private void dumpResponse(WLMessageContext paramWLMessageContext, PrintStream paramPrintStream) throws SOAPException { dumpMessage("RESPONSE FROM SERVER", paramWLMessageContext.getMessage(), paramPrintStream); }
  
  private void dumpMessage(String paramString, SOAPMessage paramSOAPMessage, PrintStream paramPrintStream) {
    if (verbose || paramPrintStream != null) {
      if (paramPrintStream == null)
        paramPrintStream = System.out; 
      paramPrintStream.println("\n<!--" + paramString + ".................-->");
      try {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        paramSOAPMessage.writeTo(byteArrayOutputStream);
        byteArrayOutputStream.flush();
        try {
          XMLInputStream xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
          XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(paramPrintStream);
          xMLOutputStream.add(xMLInputStream);
          xMLOutputStream.flush();
        } catch (Exception exception) {
          paramPrintStream.println(new String(byteArrayOutputStream.toByteArray()));
        } 
        paramPrintStream.flush();
      } catch (Exception exception) {
        exception.printStackTrace(paramPrintStream);
      } 
    } 
  }
  
  public void process(WLMessageContext paramWLMessageContext) throws SOAPException {
    boolean bool = false;
    HandlerChain handlerChain = getServerHandlerChain();
    if (verbose)
      dumpRequest(paramWLMessageContext, null); 
    handlerChain.handleRequest(paramWLMessageContext);
    if (verbose)
      dumpResponse(paramWLMessageContext, null); 
    handlerChain.handleResponse(paramWLMessageContext);
    if (bool) {
      handlerChain.destroy();
    } else {
      freeHandlerChain(handlerChain);
    } 
  }
  
  HandlerChain getClientHandlerChain(boolean paramBoolean1, boolean paramBoolean2) {
    List list = null;
    HandlerRegistry handlerRegistry = this.port.getHandlerRegistry();
    if (handlerRegistry != null)
      list = handlerRegistry.getHandlerChain(QName.valueOf(this.port.getName())); 
    ArrayList arrayList = new ArrayList();
    if (list != null)
      arrayList.addAll(list); 
    if (this.conversationPhase != null)
      arrayList.add(this.conversationHandlerInfo); 
    if (paramBoolean1)
      arrayList.add(this.reliableHandlerInfo); 
    arrayList.add(this.checkSoapFaultHandlerInfo);
    if (paramBoolean2)
      arrayList.add(new HandlerInfo(weblogic.webservice.core.handler.WSSEClientHandler.class, null, null)); 
    if (paramBoolean1)
      arrayList.add(this.rmSendingHandlerInfo); 
    arrayList.add(this.clientHandlerInfo);
    HandlerInfo[] arrayOfHandlerInfo = new HandlerInfo[arrayList.size()];
    return new HandlerChainImpl((HandlerInfo[])arrayList.toArray(arrayOfHandlerInfo));
  }
  
  public HandlerChain getServerHandlerChain() {
    HandlerChain handlerChain = (HandlerChain)this.handlerChainPool.remove();
    if (handlerChain == null)
      handlerChain = new HandlerChainImpl(this.handlerInfos, (this.mStats == null) ? null : this.mStats.getHandlerStats()); 
    return handlerChain;
  }
  
  private void freeHandlerChain(HandlerChain paramHandlerChain) {
    if (!this.handlerChainPool.add(paramHandlerChain))
      paramHandlerChain.destroy(); 
  }
  
  public OperationStats getStats() { return this.mStats; }
  
  public void setStats(OperationStats paramOperationStats) { this.mStats = paramOperationStats; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("DefaultOperation[\n");
    stringBuffer.append("name=").append(this.name).append(",\n");
    stringBuffer.append("style=").append(this.style).append(",\n");
    stringBuffer.append("encodingStyle=").append(this.encodingStyle).append(",\n");
    stringBuffer.append("namespace=").append(this.namespace).append(",\n");
    stringBuffer.append("soapAction=").append(this.soapAction).append(",\n");
    stringBuffer.append(this.input);
    stringBuffer.append(this.output);
    for (Message message : this.faults)
      stringBuffer.append(message); 
    stringBuffer.append("]\n");
    return stringBuffer.toString();
  }
  
  private String getEncodedAuthToken(String paramString1, String paramString2) {
    if (paramString1 == null)
      paramString1 = ""; 
    if (paramString2 == null)
      paramString2 = ""; 
    BASE64Encoder bASE64Encoder = new BASE64Encoder();
    return bASE64Encoder.encodeBuffer((paramString1 + ":" + paramString2).getBytes());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultOperation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */