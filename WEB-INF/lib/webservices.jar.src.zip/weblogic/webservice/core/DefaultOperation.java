/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.handler.HandlerRegistry;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.utils.collections.Pool;
/*     */ import weblogic.utils.collections.StackPool;
/*     */ import weblogic.utils.encoders.BASE64Encoder;
/*     */ import weblogic.webservice.HandlerChain;
/*     */ import weblogic.webservice.InvocationHandler;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.async.AsyncInfo;
/*     */ import weblogic.webservice.async.FutureResult;
/*     */ import weblogic.webservice.monitoring.OperationStats;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultOperation
/*     */   implements Operation
/*     */ {
/*  79 */   private static final boolean verbose = getVerboseProp(); private String name; private String namespace; private String encodingStyle; private String soapAction; private String[] parameterOrder; private boolean oneway; private String conversationPhase; private int persistDuration; private String style; private InvocationHandler target; private Port port; private TypeMappingRegistry typeMappingRegistry;
/*     */   
/*     */   private static boolean getVerboseProp() {
/*     */     try {
/*  83 */       return Boolean.getBoolean("weblogic.webservice.verbose");
/*  84 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */       
/*  88 */       return false;
/*     */     } 
/*     */   }
/*     */   private Message input; private Message output; private ArrayList faults; private static final String SOAP_ACTION = "SOAPAction"; private final Pool handlerChainPool; private HandlerInfo[] handlerInfos; private OperationStats mStats; private final HandlerInfo clientHandlerInfo; private final HandlerInfo reliableHandlerInfo; private final HandlerInfo rmSendingHandlerInfo; private final HandlerInfo conversationHandlerInfo; private final HandlerInfo checkSoapFaultHandlerInfo;
/*     */   
/*     */   DefaultOperation(String paramString, Port paramPort, HandlerInfo[] paramArrayOfHandlerInfo) {
/*  94 */     this.soapAction = "\"\"";
/*     */     
/*  96 */     this.oneway = false;
/*     */     
/*  98 */     this.persistDuration = -1;
/*  99 */     this.style = "rpc";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     this.input = new DefaultMessage(this);
/* 107 */     this.output = new DefaultMessage(this);
/* 108 */     this.faults = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.handlerChainPool = new StackPool(32);
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.mStats = null;
/*     */ 
/*     */     
/* 123 */     this.clientHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.ClientHandler.class, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     this.reliableHandlerInfo = new HandlerInfo(weblogic.webservice.saf.SAFHandler.class, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     this.rmSendingHandlerInfo = new HandlerInfo(weblogic.webservice.saf.SendingHandler.class, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     this.conversationHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.ClientConversationHandler.class, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     this.checkSoapFaultHandlerInfo = new HandlerInfo(weblogic.webservice.core.handler.CheckSoapFaultHandler.class, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     this.name = paramString;
/* 153 */     this.port = paramPort;
/* 154 */     this.handlerInfos = paramArrayOfHandlerInfo;
/*     */     
/* 156 */     this.input.setName(paramString);
/* 157 */     this.output.setName(paramString + "Response");
/*     */   }
/*     */ 
/*     */   
/* 161 */   public HandlerInfo[] getHandlerInfos() { return this.handlerInfos; }
/*     */ 
/*     */ 
/*     */   
/* 165 */   public void setHandlerInfos(HandlerInfo[] paramArrayOfHandlerInfo) { this.handlerInfos = paramArrayOfHandlerInfo; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 170 */     Iterator iterator = this.handlerChainPool.iterator();
/*     */     
/* 172 */     while (iterator.hasNext()) {
/* 173 */       ((HandlerChain)iterator.next()).destroy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 179 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */   
/* 183 */   public void setName(String paramString) { this.name = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 187 */   public Port getPort() { return this.port; }
/*     */ 
/*     */ 
/*     */   
/* 191 */   public String getNamespace() { return this.namespace; }
/*     */ 
/*     */ 
/*     */   
/* 195 */   public void setNamespace(String paramString) { this.namespace = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 199 */   public String getEncodingStyle() { return this.encodingStyle; }
/*     */ 
/*     */ 
/*     */   
/* 203 */   public void setEncodingStyle(String paramString) { this.encodingStyle = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public TypeMappingRegistry getTypeMappingRegistry() { return this.typeMappingRegistry; }
/*     */ 
/*     */   
/*     */   public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) {
/* 214 */     this.typeMappingRegistry = paramTypeMappingRegistry;
/* 215 */     this.input.setTypeMappingRegistry(paramTypeMappingRegistry);
/* 216 */     this.output.setTypeMappingRegistry(paramTypeMappingRegistry);
/*     */     
/* 218 */     for (Message message : this.faults)
/*     */     {
/* 220 */       message.setTypeMappingRegistry(paramTypeMappingRegistry);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 225 */   public String getSoapAction() { return this.soapAction; }
/*     */ 
/*     */   
/*     */   public void setSoapAction(String paramString) {
/* 229 */     if ("".equals(paramString)) {
/* 230 */       paramString = "\"\"";
/*     */     }
/* 232 */     else if (paramString != null) {
/* 233 */       if (!paramString.startsWith("\"")) {
/* 234 */         paramString = "\"" + paramString;
/*     */       }
/* 236 */       if (!paramString.endsWith("\"")) {
/* 237 */         paramString = paramString + "\"";
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 242 */     this.soapAction = paramString;
/*     */   }
/*     */ 
/*     */   
/* 246 */   public String[] getParameterOrder() { return this.parameterOrder; }
/*     */ 
/*     */   
/*     */   public void setParameterOrder(String paramString) {
/* 250 */     if (paramString != null) {
/* 251 */       StringTokenizer stringTokenizer = new StringTokenizer(paramString);
/* 252 */       int i = stringTokenizer.countTokens();
/* 253 */       String[] arrayOfString = new String[i];
/*     */       
/* 255 */       for (byte b = 0; b < i; b++) {
/* 256 */         arrayOfString[b] = stringTokenizer.nextToken();
/*     */       }
/*     */       
/* 259 */       setParameterOrder(arrayOfString);
/*     */     } else {
/* 261 */       setParameterOrder((String[])null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 266 */   public void setParameterOrder(String[] paramArrayOfString) { this.parameterOrder = paramArrayOfString; }
/*     */ 
/*     */ 
/*     */   
/* 270 */   public boolean isDocumentStyle() { return "document".equalsIgnoreCase(this.style); }
/*     */ 
/*     */   
/*     */   public void setDocumentStyle() {
/* 274 */     this.input.useLiteral();
/* 275 */     this.output.useLiteral();
/* 276 */     this.style = "document";
/*     */   }
/*     */ 
/*     */   
/* 280 */   public boolean isRpcStyle() { return "rpc".equals(this.style); }
/*     */ 
/*     */   
/*     */   public void setRpcStyle() {
/* 284 */     this.input.useEncoded();
/* 285 */     this.output.useEncoded();
/* 286 */     this.style = "rpc";
/*     */   }
/*     */ 
/*     */   
/* 290 */   public Message getInput() { return this.input; }
/*     */ 
/*     */ 
/*     */   
/* 294 */   public void setInput(Message paramMessage) { this.input = paramMessage; }
/*     */ 
/*     */ 
/*     */   
/* 298 */   public Message getOutput() { return this.output; }
/*     */ 
/*     */ 
/*     */   
/* 302 */   public void setOutput(Message paramMessage) { this.output = this.output; }
/*     */ 
/*     */ 
/*     */   
/* 306 */   public Iterator getFaults() { return this.faults.iterator(); }
/*     */ 
/*     */   
/*     */   public Message getFault(String paramString) {
/* 310 */     for (Message message : this.faults) {
/*     */       
/* 312 */       if (message.getName().equals(paramString)) return message; 
/*     */     } 
/* 314 */     return null;
/*     */   }
/*     */   
/*     */   public Message addFault() {
/* 318 */     FaultMessage faultMessage = new FaultMessage(this);
/* 319 */     faultMessage.setTypeMappingRegistry(this.typeMappingRegistry);
/* 320 */     this.faults.add(faultMessage);
/* 321 */     return faultMessage;
/*     */   }
/*     */ 
/*     */   
/* 325 */   public boolean isOneway() { return this.oneway; }
/*     */ 
/*     */ 
/*     */   
/* 329 */   public void setOneway(boolean paramBoolean) { this.oneway = paramBoolean; }
/*     */ 
/*     */   
/*     */   public void setStyle(String paramString) {
/* 333 */     if ("rpc".equalsIgnoreCase(paramString) || "document".equalsIgnoreCase(paramString) || "documentwrapped".equalsIgnoreCase(paramString)) {
/*     */ 
/*     */       
/* 336 */       this.style = paramString.toLowerCase();
/* 337 */     } else if (paramString == null) {
/* 338 */       this.style = "rpc";
/*     */     } else {
/* 340 */       throw new IllegalArgumentException("Invalid operation style: " + paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 346 */   public String getStyle() { return this.style; }
/*     */ 
/*     */ 
/*     */   
/* 350 */   public void setConversationPhase(String paramString) { this.conversationPhase = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 354 */   public String getConversationPhase() { return this.conversationPhase; }
/*     */ 
/*     */ 
/*     */   
/* 358 */   public void setPersistDurationTime(int paramInt) { this.persistDuration = paramInt; }
/*     */ 
/*     */ 
/*     */   
/* 362 */   public int getPersistDurationTime() { return this.persistDuration; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Part getReturnPart() {
/* 367 */     for (Iterator iterator = this.output.getParts(); iterator.hasNext(); ) {
/* 368 */       Part part = (Part)iterator.next();
/*     */       
/* 370 */       if (part.getMode() == Part.Mode.RETURN) {
/* 371 */         return part;
/*     */       }
/*     */     } 
/*     */     
/* 375 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   void fillInHeaders(MimeHeaders paramMimeHeaders) {
/* 380 */     if (this.soapAction != null && !"".equals(this.soapAction)) {
/* 381 */       paramMimeHeaders.addHeader("SOAPAction", this.soapAction);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 386 */     String str1 = this.port.getUserName();
/* 387 */     String str2 = this.port.getPassword();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 407 */     if (str1 != null || str2 != null) {
/* 408 */       paramMimeHeaders.addHeader("Authorization", "Basic " + getEncodedAuthToken(str1, str2));
/*     */     }
/*     */     
/* 411 */     String str3 = this.port.getProxyUserName();
/* 412 */     String str4 = this.port.getProxyPassword();
/* 413 */     if (str3 != null || str4 != null) {
/* 414 */       paramMimeHeaders.addHeader("Proxy-Authorization", "Basic " + getEncodedAuthToken(str3, str4));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 427 */     String str5 = this.port.getCookiesAsString();
/* 428 */     if (str5.length() > 0) {
/* 429 */       paramMimeHeaders.addHeader("Cookie", this.port.getCookiesAsString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Map paramMap1, Map paramMap2, PrintStream paramPrintStream) throws TargetInvocationException, SOAPException, IOException {
/* 438 */     Object[] arrayOfObject = this.input.getSortedParameters(paramMap2);
/* 439 */     return invoke(paramMap1, arrayOfObject, paramPrintStream);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object[] paramArrayOfObject) throws TargetInvocationException, SOAPException, IOException {
/* 445 */     HashMap hashMap = new HashMap();
/* 446 */     Object object = invoke(hashMap, paramArrayOfObject, null);
/*     */     
/* 448 */     if (hashMap.size() > 1) {
/* 449 */       throw new SOAPException("more than one return value, use invoke( outParams, args )");
/*     */     }
/*     */ 
/*     */     
/* 453 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 459 */   public Object invoke(Map paramMap, Object[] paramArrayOfObject) throws TargetInvocationException, SOAPException, IOException { return invoke(paramMap, paramArrayOfObject, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 466 */   public FutureResult asyncInvoke(Map paramMap, Object[] paramArrayOfObject, AsyncInfo paramAsyncInfo, PrintStream paramPrintStream) throws SOAPException, SOAPFaultException, IOException { return (new ClientDispatcher(this, paramMap, paramPrintStream)).asyncDispatch(paramArrayOfObject, paramAsyncInfo); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 473 */   public Object invoke(Map paramMap, Object[] paramArrayOfObject, PrintStream paramPrintStream) throws TargetInvocationException, SOAPException, IOException { return (new ClientDispatcher(this, paramMap, paramPrintStream)).dispatch(paramArrayOfObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 479 */   public InvocationHandler getInvocationHandler() { return this.target; }
/*     */ 
/*     */ 
/*     */   
/* 483 */   public void setInvocationHandler(InvocationHandler paramInvocationHandler) { this.target = paramInvocationHandler; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 489 */   private void dumpRequest(WLMessageContext paramWLMessageContext, PrintStream paramPrintStream) throws SOAPException { dumpMessage("REQUEST TO SERVER", paramWLMessageContext.getMessage(), paramPrintStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 495 */   private void dumpResponse(WLMessageContext paramWLMessageContext, PrintStream paramPrintStream) throws SOAPException { dumpMessage("RESPONSE FROM SERVER", paramWLMessageContext.getMessage(), paramPrintStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void dumpMessage(String paramString, SOAPMessage paramSOAPMessage, PrintStream paramPrintStream) {
/* 501 */     if (verbose || paramPrintStream != null) {
/*     */       
/* 503 */       if (paramPrintStream == null) {
/* 504 */         paramPrintStream = System.out;
/*     */       }
/*     */       
/* 507 */       paramPrintStream.println("\n<!--" + paramString + ".................-->");
/*     */       
/*     */       try {
/* 510 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 511 */         paramSOAPMessage.writeTo(byteArrayOutputStream);
/* 512 */         byteArrayOutputStream.flush();
/*     */         
/*     */         try {
/* 515 */           XMLInputStream xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
/*     */ 
/*     */ 
/*     */           
/* 519 */           XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(paramPrintStream);
/*     */ 
/*     */ 
/*     */           
/* 523 */           xMLOutputStream.add(xMLInputStream);
/* 524 */           xMLOutputStream.flush();
/* 525 */         } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 530 */           paramPrintStream.println(new String(byteArrayOutputStream.toByteArray()));
/*     */         } 
/*     */         
/* 533 */         paramPrintStream.flush();
/* 534 */       } catch (Exception exception) {
/* 535 */         exception.printStackTrace(paramPrintStream);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void process(WLMessageContext paramWLMessageContext) throws SOAPException {
/* 542 */     boolean bool = false;
/*     */     
/* 544 */     HandlerChain handlerChain = getServerHandlerChain();
/*     */     
/* 546 */     if (verbose) {
/* 547 */       dumpRequest(paramWLMessageContext, null);
/*     */     }
/*     */ 
/*     */     
/* 551 */     handlerChain.handleRequest(paramWLMessageContext);
/*     */ 
/*     */ 
/*     */     
/* 555 */     if (verbose) {
/* 556 */       dumpResponse(paramWLMessageContext, null);
/*     */     }
/*     */ 
/*     */     
/* 560 */     handlerChain.handleResponse(paramWLMessageContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 569 */     if (bool) {
/* 570 */       handlerChain.destroy();
/*     */     } else {
/* 572 */       freeHandlerChain(handlerChain);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HandlerChain getClientHandlerChain(boolean paramBoolean1, boolean paramBoolean2) {
/* 580 */     List list = null;
/*     */     
/* 582 */     HandlerRegistry handlerRegistry = this.port.getHandlerRegistry();
/*     */     
/* 584 */     if (handlerRegistry != null) {
/* 585 */       list = handlerRegistry.getHandlerChain(QName.valueOf(this.port.getName()));
/*     */     }
/*     */     
/* 588 */     ArrayList arrayList = new ArrayList();
/* 589 */     if (list != null) {
/* 590 */       arrayList.addAll(list);
/*     */     }
/*     */     
/* 593 */     if (this.conversationPhase != null) arrayList.add(this.conversationHandlerInfo);
/*     */     
/* 595 */     if (paramBoolean1) arrayList.add(this.reliableHandlerInfo);
/*     */     
/* 597 */     arrayList.add(this.checkSoapFaultHandlerInfo);
/*     */     
/* 599 */     if (paramBoolean2) {
/* 600 */       arrayList.add(new HandlerInfo(weblogic.webservice.core.handler.WSSEClientHandler.class, null, null));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 605 */     if (paramBoolean1) arrayList.add(this.rmSendingHandlerInfo);
/*     */     
/* 607 */     arrayList.add(this.clientHandlerInfo);
/*     */     
/* 609 */     HandlerInfo[] arrayOfHandlerInfo = new HandlerInfo[arrayList.size()];
/* 610 */     return new HandlerChainImpl((HandlerInfo[])arrayList.toArray(arrayOfHandlerInfo));
/*     */   }
/*     */ 
/*     */   
/*     */   public HandlerChain getServerHandlerChain() {
/* 615 */     HandlerChain handlerChain = (HandlerChain)this.handlerChainPool.remove();
/*     */     
/* 617 */     if (handlerChain == null) {
/* 618 */       handlerChain = new HandlerChainImpl(this.handlerInfos, (this.mStats == null) ? null : this.mStats.getHandlerStats());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 623 */     return handlerChain;
/*     */   }
/*     */ 
/*     */   
/*     */   private void freeHandlerChain(HandlerChain paramHandlerChain) {
/* 628 */     if (!this.handlerChainPool.add(paramHandlerChain)) {
/* 629 */       paramHandlerChain.destroy();
/*     */     }
/*     */   }
/*     */   
/* 633 */   public OperationStats getStats() { return this.mStats; }
/*     */   
/* 635 */   public void setStats(OperationStats paramOperationStats) { this.mStats = paramOperationStats; }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 639 */     StringBuffer stringBuffer = new StringBuffer();
/* 640 */     stringBuffer.append("DefaultOperation[\n");
/* 641 */     stringBuffer.append("name=").append(this.name).append(",\n");
/* 642 */     stringBuffer.append("style=").append(this.style).append(",\n");
/* 643 */     stringBuffer.append("encodingStyle=").append(this.encodingStyle).append(",\n");
/* 644 */     stringBuffer.append("namespace=").append(this.namespace).append(",\n");
/* 645 */     stringBuffer.append("soapAction=").append(this.soapAction).append(",\n");
/*     */     
/* 647 */     stringBuffer.append(this.input);
/* 648 */     stringBuffer.append(this.output);
/* 649 */     for (Message message : this.faults)
/*     */     {
/* 651 */       stringBuffer.append(message);
/*     */     }
/*     */     
/* 654 */     stringBuffer.append("]\n");
/* 655 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private String getEncodedAuthToken(String paramString1, String paramString2) {
/* 660 */     if (paramString1 == null) {
/* 661 */       paramString1 = "";
/*     */     }
/*     */     
/* 664 */     if (paramString2 == null) {
/* 665 */       paramString2 = "";
/*     */     }
/*     */     
/* 668 */     BASE64Encoder bASE64Encoder = new BASE64Encoder();
/*     */     
/* 670 */     return bASE64Encoder.encodeBuffer((paramString1 + ":" + paramString2).getBytes());
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultOperation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */