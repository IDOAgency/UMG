package weblogic.webservice.core;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import weblogic.webservice.Message;
import weblogic.webservice.Part;
import weblogic.webservice.PartFilter;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.context.WebServiceHeader;
import weblogic.webservice.core.soap.SOAPFactoryImpl;
import weblogic.xml.schema.binding.DeserializationContext;
import weblogic.xml.schema.binding.RuntimeUtils;
import weblogic.xml.schema.binding.SerializationContext;
import weblogic.xml.schema.binding.SerializationException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.internal.DeserializationContextImpl;
import weblogic.xml.schema.binding.internal.SerializationContextImpl;
import weblogic.xml.schema.binding.util.NamespacePrefixMap;
import weblogic.xml.schema.binding.util.StdNamespace;
import weblogic.xml.schema.model.ExpName;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeOutputStream;

public class DefaultMessage implements Message {
  private String name;
  
  private String namespace;
  
  private String encodingStyle;
  
  private static String soapNS = StdNamespace.instance().soapEnvelope();
  
  private static final String ACTOR_URI_NEXT = "http://schemas.xmlsoap.org/soap/actor/next";
  
  private String securitySpecRef;
  
  private int use;
  
  private TypeMappingRegistry typeMappingRegistry;
  
  private DefaultOperation operation;
  
  private boolean containsAttachment;
  
  private ArrayList parts;
  
  private static SOAPFactory soapFactory;
  
  private static String PREFIX = "m";
  
  DefaultMessage(DefaultOperation paramDefaultOperation) {
    this.encodingStyle = StdNamespace.instance().soapEncoding();
    this.use = 1;
    this.containsAttachment = false;
    this.parts = new ArrayList();
    this.operation = paramDefaultOperation;
  }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getNamespace() { return this.namespace; }
  
  public void setNamespace(String paramString) { this.namespace = paramString; }
  
  public boolean isLiteral() { return (this.use == 0); }
  
  public void useLiteral() { this.use = 0; }
  
  public boolean isEncoded() { return (this.use == 1); }
  
  public void useEncoded() { this.use = 1; }
  
  public boolean getContainsAttachment() { return this.containsAttachment; }
  
  public void setContainsAttachment(boolean paramBoolean) { this.containsAttachment = paramBoolean; }
  
  public TypeMappingRegistry getTypeMappingRegistry() { return this.typeMappingRegistry; }
  
  public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) { this.typeMappingRegistry = paramTypeMappingRegistry; }
  
  public String getEncodingStyle() { return this.encodingStyle; }
  
  public void setEncodingStyle(String paramString) { this.encodingStyle = paramString; }
  
  public String getSecuritySpecRef() { return this.securitySpecRef; }
  
  public void setSecuritySpecRef(String paramString) { this.securitySpecRef = paramString; }
  
  private SOAPFactory getSOAPFactory() throws SOAPException {
    if (soapFactory == null)
      soapFactory = new SOAPFactoryImpl(); 
    return soapFactory;
  }
  
  public Part getPart(String paramString) {
    for (Part part : this.parts) {
      if (paramString.equals(part.getName()))
        return part; 
    } 
    return null;
  }
  
  private Part getPart(Name paramName) {
    for (Part part : this.parts) {
      if (paramName.getLocalName().equals(part.getXMLName().getLocalName()))
        return part; 
    } 
    return null;
  }
  
  TypeMapping getInternalTypeMapping() {
    TypeMapping typeMapping = this.typeMappingRegistry.getTypeMapping(this.encodingStyle);
    if (typeMapping == null)
      throw new IllegalArgumentException("Unable to find type mapping for encodingStyle " + this.encodingStyle + ". In registry " + this.typeMappingRegistry); 
    if (typeMapping instanceof TypeMapping)
      return (TypeMapping)typeMapping; 
    throw new IllegalArgumentException("unable to find javaType from the specified xmlType. This method can only be called if the TypeMapping used is weblogic.xml.schema.binding.TypeMapping. jaxrpc spec should change to fix this problem. in the mean time you can use the addPart( ..., Class javaType )");
  }
  
  public Part addPart(String paramString1, String paramString2, String paramString3) {
    ExpName expName = new ExpName(paramString3, paramString2);
    return addPart(paramString1, paramString2, paramString3, null);
  }
  
  public Part addPart(String paramString1, String paramString2, String paramString3, Class paramClass) throws JAXRPCException {
    DefaultPart defaultPart = new DefaultPart(paramString1, paramString2, paramString3, paramClass, this);
    this.parts.add(defaultPart);
    return defaultPart;
  }
  
  public Iterator getParts() { return this.parts.iterator(); }
  
  public Part[] getParts(PartFilter paramPartFilter) {
    ArrayList arrayList = new ArrayList();
    for (Part part : this.parts) {
      if (paramPartFilter.accept(part))
        arrayList.add(part); 
    } 
    return (Part[])arrayList.toArray(new Part[0]);
  }
  
  private Part getImplicitPart(String paramString, Class paramClass) {
    XMLName xMLName = getInternalTypeMapping().getXMLNameFromClass(paramClass);
    DefaultPart defaultPart = new DefaultPart(paramString, xMLName.getLocalName(), xMLName.getNamespaceUri(), paramClass, this);
    defaultPart.setHeader();
    return defaultPart;
  }
  
  public boolean isVoid() { return (this.parts.size() == 0); }
  
  public boolean isMultiPart() { return (this.parts.size() > 1); }
  
  public boolean isSinglePart() { return (this.parts.size() == 1); }
  
  public Object[] getSortedParameters(Map paramMap) {
    Object[] arrayOfObject = new Object[this.parts.size()];
    for (byte b = 0; b < arrayOfObject.length; b++) {
      Part part = (Part)this.parts.get(b);
      arrayOfObject[b] = paramMap.get(part.getName());
    } 
    return arrayOfObject;
  }
  
  private Object headerToJava(Map paramMap, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) throws SOAPException {
    Object object = null;
    TypeMapping typeMapping = this.typeMappingRegistry.getTypeMapping(this.encodingStyle);
    for (Part part : this.parts) {
      if (part.isBody() || part.isAttachment())
        continue; 
      Object object1 = null;
      SOAPElement sOAPElement = null;
      if (part.isHeader()) {
        sOAPElement = getChildElement(part.getXMLName().getLocalName(), paramSOAPMessage.getSOAPPart().getEnvelope().getHeader());
        if (sOAPElement != null)
          sOAPElement.detachNode(); 
      } 
      object1 = part.toJava(sOAPElement, paramDeserializationContext, typeMapping);
      if (part.getMode() == Part.Mode.RETURN) {
        object = object1;
        continue;
      } 
      paramMap.put(part.getName(), object1);
    } 
    return object;
  }
  
  private void implicitHeaderToJava(SOAPHeader paramSOAPHeader, DeserializationContext paramDeserializationContext, WebServiceContext paramWebServiceContext, TypeMapping paramTypeMapping) throws SOAPException {
    if (paramSOAPHeader == null)
      return; 
    for (Iterator iterator = getNonSpaceChildElements(paramSOAPHeader); iterator.hasNext(); ) {
      SOAPElement sOAPElement = (SOAPElement)iterator.next();
      checkMustUnderstand(sOAPElement);
      Part part = getImplicitPart(sOAPElement.getElementName().getLocalName(), Object.class);
      Object object = part.toJava(sOAPElement, paramDeserializationContext, paramTypeMapping);
      if (object != null)
        if (!(object instanceof XMLNode))
          paramWebServiceContext.getHeader().put(new QName(sOAPElement.getElementName().getURI(), sOAPElement.getElementName().getLocalName()), object);  
    } 
  }
  
  private void checkMustUnderstand(SOAPElement paramSOAPElement) throws SOAPException {
    soapFactory = getSOAPFactory();
    boolean bool = this.operation.getPort().getService().getHandleAllActors();
    if (!bool) {
      String str1 = paramSOAPElement.getAttributeValue(soapFactory.createName("actor", null, soapNS));
      if (str1 == null)
        str1 = paramSOAPElement.getAttributeValue(soapFactory.createName("actor")); 
      if (str1 != null && !str1.equals("http://schemas.xmlsoap.org/soap/actor/next"))
        return; 
    } 
    String str = paramSOAPElement.getAttributeValue(soapFactory.createName("mustUnderstand", null, soapNS));
    if (str == null)
      str = paramSOAPElement.getAttributeValue(soapFactory.createName("mustUnderstand")); 
    if (str != null) {
      if ("1".equals(str) || "true".equals(str))
        throw new SOAPException("Unable to handle mustUnderstand header: " + paramSOAPElement.getElementName()); 
      if (!"0".equals(str) && !"false".equals(str))
        throw new SOAPException("Invalid value for mustUnderstand attribute in header: " + paramSOAPElement.getElementName()); 
    } 
  }
  
  public Object toJava(Map paramMap, SOAPMessage paramSOAPMessage, WebServiceContext paramWebServiceContext) throws SOAPException {
    TypeMapping typeMapping = this.typeMappingRegistry.getTypeMapping(this.encodingStyle);
    DeserializationContextImpl deserializationContextImpl = new DeserializationContextImpl();
    deserializationContextImpl.setSOAPMessage(paramSOAPMessage);
    Object object = headerToJava(paramMap, paramSOAPMessage, deserializationContextImpl);
    implicitHeaderToJava(paramSOAPMessage.getSOAPPart().getEnvelope().getHeader(), deserializationContextImpl, paramWebServiceContext, typeMapping);
    SOAPBody sOAPBody = paramSOAPMessage.getSOAPPart().getEnvelope().getBody();
    SOAPElement sOAPElement = null;
    if ("document".equals(this.operation.getStyle())) {
      sOAPElement = sOAPBody;
    } else {
      sOAPElement = getFirstChild(sOAPBody);
    } 
    for (Iterator iterator = getNonSpaceChildElements(sOAPElement); iterator.hasNext(); ) {
      SOAPElement sOAPElement1 = (SOAPElement)iterator.next();
      Name name1 = sOAPElement1.getElementName();
      if ("result".equals(name1.getLocalName()) && "http://www.w3.org/2002/06/soap-rpc".equals(name1.getURI()))
        continue; 
      Part part = null;
      if ("documentwrapped".equals(this.operation.getStyle())) {
        part = getPart(sOAPElement1.getElementName().getLocalName());
      } else {
        part = getPart(sOAPElement1.getElementName());
      } 
      if (part == null && 
        object == null)
        part = getReturnPart(); 
      if (part == null) {
        if (iterator.hasNext())
          continue; 
        throw new SOAPException("Found SOAPElement [" + sOAPElement1 + "]. " + "But was not able to find a Part that is registered with this " + "Message which corresponds to this SOAPElement. The name of the " + "element should be one of these[" + getPartNames() + "]");
      } 
      Object object1 = part.toJava(sOAPElement1, deserializationContextImpl, typeMapping);
      if (part.getMode() == Part.Mode.RETURN) {
        object = object1;
        continue;
      } 
      paramMap.put(part.getName(), object1);
    } 
    return object;
  }
  
  private String getPartNames() {
    StringBuffer stringBuffer = new StringBuffer();
    for (Iterator iterator = this.parts.iterator(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      stringBuffer.append(part.getName());
      if (iterator.hasNext())
        stringBuffer.append(","); 
    } 
    return stringBuffer.toString();
  }
  
  private Part getReturnPart() {
    for (Part part : this.parts) {
      if (part.getMode() == Part.Mode.RETURN)
        return part; 
    } 
    return null;
  }
  
  private Iterator getNonSpaceChildElements(SOAPElement paramSOAPElement) { return new NonSpaceIterator(paramSOAPElement.getChildElements()); }
  
  public static class NonSpaceIterator implements Iterator {
    private Iterator it;
    
    private Object next;
    
    public NonSpaceIterator(Iterator param1Iterator) { this.it = param1Iterator; }
    
    public void remove() { throw new Error("not supported"); }
    
    public boolean hasNext() {
      if (this.next != null)
        return true; 
      while (this.it.hasNext()) {
        this.next = this.it.next();
        if (this.next instanceof SOAPElement)
          return true; 
      } 
      return false;
    }
    
    public Object next() {
      Object object;
      if (this.next != null) {
        object = this.next;
        this.next = null;
        return object;
      } 
      do {
        object = this.it.next();
      } while (!(object instanceof SOAPElement));
      return object;
    }
  }
  
  private SOAPElement getChildElement(String paramString, SOAPElement paramSOAPElement) {
    if (paramSOAPElement == null)
      return null; 
    for (Iterator iterator = getNonSpaceChildElements(paramSOAPElement); iterator.hasNext(); ) {
      SOAPElement sOAPElement = (SOAPElement)iterator.next();
      if (paramString.equals(sOAPElement.getElementName().getLocalName()))
        return sOAPElement; 
    } 
    return null;
  }
  
  String getStyle() { return this.operation.getStyle(); }
  
  public void toXML(SOAPMessage paramSOAPMessage, Object[] paramArrayOfObject, WebServiceContext paramWebServiceContext) throws SOAPException {
    SOAPElement sOAPElement;
    SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
    SOAPBody sOAPBody = sOAPEnvelope.getBody();
    if ("document".equals(this.operation.getStyle())) {
      sOAPElement = sOAPBody;
    } else {
      sOAPElement = createWrapElement(sOAPBody);
    } 
    if (isEncoded())
      sOAPBody.setEncodingStyle(this.encodingStyle); 
    if (paramArrayOfObject == null)
      paramArrayOfObject = new Object[0]; 
    Iterator iterator = this.parts.iterator();
    SerializationContextImpl serializationContextImpl = new SerializationContextImpl();
    serializationContextImpl.setSOAPMessage(paramSOAPMessage);
    serializationContextImpl.setNamespacePrefixMap(NamespacePrefixMap.createDefaultMap());
    TypeMapping typeMapping = this.typeMappingRegistry.getTypeMapping(this.encodingStyle);
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      if (!iterator.hasNext())
        throw new SOAPException("Number of arguments do not match the number of parts. No of parts: " + this.parts.size() + ". No of args:" + paramArrayOfObject.length); 
      Part part = (Part)iterator.next();
      if (!this.operation.isDocumentStyle() || !void.class.equals(part.getJavaType()))
        if (part.isHeader()) {
          if (sOAPEnvelope.getHeader() == null)
            sOAPEnvelope.addHeader(); 
          part.toXML(sOAPEnvelope.getHeader(), paramArrayOfObject[b], serializationContextImpl, this.operation.isDocumentStyle(), typeMapping);
        } else {
          part.toXML(sOAPElement, paramArrayOfObject[b], serializationContextImpl, this.operation.isDocumentStyle(), typeMapping);
        }  
    } 
    implicitHeaderToXML(sOAPEnvelope, paramWebServiceContext, serializationContextImpl, this.operation.isDocumentStyle(), typeMapping);
    if (serializationContextImpl.isMultiRefEmpty())
      writeXmlIds(sOAPBody, serializationContextImpl); 
    if (iterator.hasNext())
      throw new SOAPException("The number of arguments passed does not match the number of parts. no of parts =  " + this.parts.size() + " no of args = " + paramArrayOfObject.length); 
  }
  
  private void implicitHeaderToXML(SOAPEnvelope paramSOAPEnvelope, WebServiceContext paramWebServiceContext, SerializationContext paramSerializationContext, boolean paramBoolean, TypeMapping paramTypeMapping) throws SOAPException {
    if (paramWebServiceContext == null)
      return; 
    WebServiceHeader webServiceHeader = paramWebServiceContext.getHeader();
    for (Iterator iterator = webServiceHeader.names(); iterator.hasNext(); ) {
      QName qName = (QName)iterator.next();
      Object object = webServiceHeader.get(qName);
      if (object != null) {
        if (paramSOAPEnvelope.getHeader() == null)
          paramSOAPEnvelope.addHeader(); 
        Part part = getImplicitPart(qName.getLocalPart(), object.getClass());
        part.setNamespace(qName.getNamespaceURI());
        part.toXML(paramSOAPEnvelope.getHeader(), object, paramSerializationContext, paramBoolean, paramTypeMapping);
      } 
    } 
  }
  
  private void writeXmlIds(SOAPElement paramSOAPElement, SerializationContext paramSerializationContext) throws SOAPException {
    try {
      XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream((XMLNode)paramSOAPElement);
      paramSerializationContext.setQualifyElements(true);
      RuntimeUtils.writeTrailingBlocks(xMLNodeOutputStream, paramSerializationContext);
      xMLNodeOutputStream.flush();
    } catch (XMLStreamException xMLStreamException) {
      throw new SOAPException(xMLStreamException);
    } catch (SerializationException serializationException) {
      throw new SOAPException(serializationException);
    } 
  }
  
  private SOAPElement getFirstChild(SOAPElement paramSOAPElement) throws SOAPException {
    for (Iterator iterator = getNonSpaceChildElements(paramSOAPElement); iterator.hasNext(); ) {
      Object object = iterator.next();
      if (object instanceof SOAPElement)
        return (SOAPElement)object; 
    } 
    throw new SOAPException("no element found inside body");
  }
  
  private SOAPElement createWrapElement(SOAPBody paramSOAPBody) throws SOAPException {
    SOAPEnvelope sOAPEnvelope = (SOAPEnvelope)paramSOAPBody.getParentElement();
    Name name1 = (this.namespace == null) ? sOAPEnvelope.createName(this.name) : sOAPEnvelope.createName(this.name, PREFIX, this.namespace);
    SOAPBodyElement sOAPBodyElement = paramSOAPBody.addBodyElement(name1);
    if (this.namespace != null)
      sOAPBodyElement.addNamespaceDeclaration(PREFIX, this.namespace); 
    return sOAPBodyElement;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("DefaultMessage[");
    stringBuffer.append("name=").append(this.name).append(",\n");
    stringBuffer.append("namespace=").append(this.namespace).append(",\n");
    stringBuffer.append("encodingStyle=").append(this.encodingStyle).append(",\n");
    for (Iterator iterator = this.parts.iterator(); iterator.hasNext();)
      stringBuffer.append(iterator.next()); 
    stringBuffer.append("]");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */