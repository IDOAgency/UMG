package weblogic.webservice.core;

import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.Handler;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.soap.SOAPFaultException;
import weblogic.utils.AssertionError;
import weblogic.webservice.HandlerChain;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.monitoring.HandlerStats;
import weblogic.webservice.util.FaultUtil;

public class HandlerChainImpl implements HandlerChain {
  private static final boolean debug = false;
  
  private static final boolean verbose = false;
  
  private Handler[] handlers;
  
  private HandlerStats[] mStats = null;
  
  private int index;
  
  public HandlerChainImpl() {}
  
  public HandlerChainImpl(HandlerInfo paramHandlerInfo) { this(new HandlerInfo[] { paramHandlerInfo }); }
  
  public HandlerChainImpl(HandlerInfo[] paramArrayOfHandlerInfo) { init(paramArrayOfHandlerInfo); }
  
  public HandlerChainImpl(HandlerInfo[] paramArrayOfHandlerInfo, HandlerStats[] paramArrayOfHandlerStats) {
    init(paramArrayOfHandlerInfo);
    this.mStats = paramArrayOfHandlerStats;
  }
  
  public void init(HandlerInfo[] paramArrayOfHandlerInfo) {
    this.handlers = new Handler[paramArrayOfHandlerInfo.length];
    for (byte b = 0; b < paramArrayOfHandlerInfo.length; b++) {
      Class clazz = paramArrayOfHandlerInfo[b].getHandlerClass();
      try {
        this.handlers[b] = (Handler)clazz.newInstance();
      } catch (InstantiationException instantiationException) {
        if (this.mStats != null && this.mStats.length > b && this.mStats[b] != null)
          this.mStats[b].reportInitError(instantiationException); 
        throw new JAXRPCException("Exception in handler:" + clazz.getName(), instantiationException);
      } catch (IllegalAccessException illegalAccessException) {
        throw new AssertionError(illegalAccessException);
      } 
      try {
        this.handlers[b].init(paramArrayOfHandlerInfo[b]);
      } catch (Throwable throwable) {
        byte b1 = b;
        while (--b1 >= 0) {
          try {
            this.handlers[b1].destroy();
          } catch (Throwable throwable1) {}
        } 
        if (throwable instanceof JAXRPCException)
          throw (JAXRPCException)throwable; 
        throw new JAXRPCException("Exception while calling Handler:" + clazz.getName() + "'s init method.", throwable);
      } 
    } 
  }
  
  public void destroy() {
    for (byte b = 0; b < this.handlers.length; b++) {
      try {
        this.handlers[b].destroy();
      } catch (Throwable throwable) {
        WebServiceLogger.logIgnoringDestroyException(this.handlers[b].getClass().getName(), throwable);
      } 
    } 
  }
  
  public boolean handleRequest(MessageContext paramMessageContext) {
    for (this.index = 0; this.index < this.handlers.length; this.index++) {
      try {
        if (!this.handlers[this.index].handleRequest(paramMessageContext)) {
          if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null)
            this.mStats[this.index].reportRequestTermination(); 
          return false;
        } 
      } catch (Throwable throwable) {
        if (!(throwable instanceof SOAPFaultException)) {
          try {
            WebServiceLogger.logExceptionInRequestHandler(this.handlers[this.index].getClass().getName(), throwable);
          } catch (Throwable throwable1) {
            throwable.printStackTrace();
          } 
          if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null)
            this.mStats[this.index].reportRequestError(throwable); 
        } else if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null) {
          this.mStats[this.index].reportRequestSOAPFault((SOAPFaultException)throwable);
        } 
        if (throwable instanceof JAXRPCException && (
          (JAXRPCException)throwable).getLinkedCause() instanceof weblogic.webservice.TargetInvocationException)
          return false; 
        ((WLMessageContext)paramMessageContext).setMessage(FaultUtil.exception2Fault(throwable));
        ((WLMessageContext)paramMessageContext).setFault(true);
        paramMessageContext.setProperty("weblogic.webservice.handler.exception", throwable);
        return false;
      } 
    } 
    this.index--;
    return true;
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    for (; this.index >= 0; this.index--) {
      if (wLMessageContext.hasFault()) {
        try {
          if (!this.handlers[this.index].handleFault(paramMessageContext))
            return false; 
        } catch (Throwable throwable) {
          WebServiceLogger.logExceptionInFaultHandler(this.handlers[this.index].getClass().getName(), throwable);
        } 
      } else {
        try {
          if (!this.handlers[this.index].handleResponse(paramMessageContext)) {
            if (this.mStats != null && this.mStats.length > this.index)
              this.mStats[this.index].reportResponseTermination(); 
            return false;
          } 
        } catch (Throwable throwable) {
          if (!(throwable instanceof SOAPFaultException)) {
            WebServiceLogger.logExceptionInResponseHandler(this.handlers[this.index].getClass().getName(), throwable);
            if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null)
              this.mStats[this.index].reportResponseError(throwable); 
          } else if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null) {
            this.mStats[this.index].reportResponseSOAPFault((SOAPFaultException)throwable);
          } 
          wLMessageContext.setMessage(FaultUtil.exception2Fault(throwable));
          ((WLMessageContext)paramMessageContext).setFault(true);
          paramMessageContext.setProperty("weblogic.webservice.handler.exception", throwable);
        } 
      } 
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\HandlerChainImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */