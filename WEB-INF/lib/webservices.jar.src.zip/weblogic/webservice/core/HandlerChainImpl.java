/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.Handler;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.HandlerChain;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.monitoring.HandlerStats;
/*     */ import weblogic.webservice.util.FaultUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerChainImpl
/*     */   implements HandlerChain
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   private static final boolean verbose = false;
/*     */   private Handler[] handlers;
/*  37 */   private HandlerStats[] mStats = null;
/*     */   
/*     */   private int index;
/*     */ 
/*     */   
/*     */   public HandlerChainImpl() {}
/*     */   
/*  44 */   public HandlerChainImpl(HandlerInfo paramHandlerInfo) { this(new HandlerInfo[] { paramHandlerInfo }); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public HandlerChainImpl(HandlerInfo[] paramArrayOfHandlerInfo) { init(paramArrayOfHandlerInfo); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HandlerChainImpl(HandlerInfo[] paramArrayOfHandlerInfo, HandlerStats[] paramArrayOfHandlerStats) {
/*  58 */     init(paramArrayOfHandlerInfo);
/*  59 */     this.mStats = paramArrayOfHandlerStats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(HandlerInfo[] paramArrayOfHandlerInfo) {
/*  68 */     this.handlers = new Handler[paramArrayOfHandlerInfo.length];
/*     */     
/*  70 */     for (byte b = 0; b < paramArrayOfHandlerInfo.length; b++) {
/*  71 */       Class clazz = paramArrayOfHandlerInfo[b].getHandlerClass();
/*     */ 
/*     */       
/*     */       try {
/*  75 */         this.handlers[b] = (Handler)clazz.newInstance();
/*  76 */       } catch (InstantiationException instantiationException) {
/*  77 */         if (this.mStats != null && this.mStats.length > b && this.mStats[b] != null) {
/*  78 */           this.mStats[b].reportInitError(instantiationException);
/*     */         }
/*     */         
/*  81 */         throw new JAXRPCException("Exception in handler:" + clazz.getName(), instantiationException);
/*     */       }
/*  83 */       catch (IllegalAccessException illegalAccessException) {
/*     */         
/*  85 */         throw new AssertionError(illegalAccessException);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  91 */         this.handlers[b].init(paramArrayOfHandlerInfo[b]);
/*  92 */       } catch (Throwable throwable) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  97 */         byte b1 = b;
/*     */         
/*  99 */         while (--b1 >= 0) {
/*     */           try {
/* 101 */             this.handlers[b1].destroy();
/* 102 */           } catch (Throwable throwable1) {}
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 107 */         if (throwable instanceof JAXRPCException) {
/* 108 */           throw (JAXRPCException)throwable;
/*     */         }
/* 110 */         throw new JAXRPCException("Exception while calling Handler:" + clazz.getName() + "'s init method.", throwable);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 119 */     for (byte b = 0; b < this.handlers.length; b++) {
/*     */       try {
/* 121 */         this.handlers[b].destroy();
/* 122 */       } catch (Throwable throwable) {
/* 123 */         WebServiceLogger.logIgnoringDestroyException(this.handlers[b].getClass().getName(), throwable);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleRequest(MessageContext paramMessageContext) {
/* 141 */     for (this.index = 0; this.index < this.handlers.length; this.index++) {
/*     */       
/*     */       try {
/* 144 */         if (!this.handlers[this.index].handleRequest(paramMessageContext)) {
/* 145 */           if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null)
/*     */           {
/* 147 */             this.mStats[this.index].reportRequestTermination();
/*     */           }
/* 149 */           return false;
/*     */         } 
/* 151 */       } catch (Throwable throwable) {
/*     */         
/* 153 */         if (!(throwable instanceof SOAPFaultException)) {
/*     */ 
/*     */           
/*     */           try {
/* 157 */             WebServiceLogger.logExceptionInRequestHandler(this.handlers[this.index].getClass().getName(), throwable);
/*     */           
/*     */           }
/* 160 */           catch (Throwable throwable1) {
/*     */ 
/*     */ 
/*     */             
/* 164 */             throwable.printStackTrace();
/*     */           } 
/* 166 */           if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null)
/*     */           {
/* 168 */             this.mStats[this.index].reportRequestError(throwable);
/*     */           }
/*     */         }
/* 171 */         else if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null) {
/*     */           
/* 173 */           this.mStats[this.index].reportRequestSOAPFault((SOAPFaultException)throwable);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 184 */         if (throwable instanceof JAXRPCException && (
/* 185 */           (JAXRPCException)throwable).getLinkedCause() instanceof weblogic.webservice.TargetInvocationException)
/*     */         {
/* 187 */           return false;
/*     */         }
/*     */         
/* 190 */         ((WLMessageContext)paramMessageContext).setMessage(FaultUtil.exception2Fault(throwable));
/* 191 */         ((WLMessageContext)paramMessageContext).setFault(true);
/* 192 */         paramMessageContext.setProperty("weblogic.webservice.handler.exception", throwable);
/* 193 */         return false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     this.index--;
/*     */     
/* 207 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleResponse(MessageContext paramMessageContext) {
/* 216 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*     */     
/* 218 */     for (; this.index >= 0; this.index--) {
/*     */       
/* 220 */       if (wLMessageContext.hasFault()) {
/*     */         try {
/* 222 */           if (!this.handlers[this.index].handleFault(paramMessageContext)) {
/* 223 */             return false;
/*     */           }
/* 225 */         } catch (Throwable throwable) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 232 */           WebServiceLogger.logExceptionInFaultHandler(this.handlers[this.index].getClass().getName(), throwable);
/*     */         } 
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 238 */           if (!this.handlers[this.index].handleResponse(paramMessageContext)) {
/* 239 */             if (this.mStats != null && this.mStats.length > this.index) {
/* 240 */               this.mStats[this.index].reportResponseTermination();
/*     */             }
/* 242 */             return false;
/*     */           } 
/* 244 */         } catch (Throwable throwable) {
/*     */           
/* 246 */           if (!(throwable instanceof SOAPFaultException)) {
/*     */             
/* 248 */             WebServiceLogger.logExceptionInResponseHandler(this.handlers[this.index].getClass().getName(), throwable);
/*     */ 
/*     */             
/* 251 */             if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null)
/*     */             {
/* 253 */               this.mStats[this.index].reportResponseError(throwable);
/*     */             }
/*     */           }
/* 256 */           else if (this.mStats != null && this.mStats.length > this.index && this.mStats[this.index] != null) {
/*     */             
/* 258 */             this.mStats[this.index].reportResponseSOAPFault((SOAPFaultException)throwable);
/*     */           } 
/*     */ 
/*     */           
/* 262 */           wLMessageContext.setMessage(FaultUtil.exception2Fault(throwable));
/* 263 */           ((WLMessageContext)paramMessageContext).setFault(true);
/* 264 */           paramMessageContext.setProperty("weblogic.webservice.handler.exception", throwable);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 269 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\HandlerChainImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */