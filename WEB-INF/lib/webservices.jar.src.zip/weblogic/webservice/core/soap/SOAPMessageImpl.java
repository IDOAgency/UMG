package weblogic.webservice.core.soap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.Header;
import javax.mail.MessagingException;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.ParseException;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import weblogic.utils.AssertionError;
import weblogic.utils.CharsetMap;
import weblogic.utils.StackTraceUtils;
import weblogic.webservice.WLSOAPMessage;
import weblogic.webservice.WebServiceLogger;
import weblogic.xml.babel.reader.XmlReader;

public class SOAPMessageImpl extends SOAPMessage implements WLSOAPMessage {
  private String contentDescription;
  
  private SOAPPartImpl soapPart;
  
  private MimeHeaders headers;
  
  private List attachmentParts;
  
  private boolean saveRequired;
  
  private static final boolean debug = false;
  
  private static final String CONTENT_TYPE = "Content-Type";
  
  private static final int SOAP11 = 0;
  
  private static final int SOAP12 = 1;
  
  private MimeMultipart __dont_touch_mimeMessage;
  
  private String contentType;
  
  private String charset;
  
  private int soapVersion;
  
  private static String defaultCharset = getStringProp("weblogic.webservice.i18n.charset", null);
  
  private static String language = getStringProp("user.language", null);
  
  private static String getStringProp(String paramString1, String paramString2) {
    try {
      return System.getProperty(paramString1);
    } catch (SecurityException securityException) {
      return paramString2;
    } 
  }
  
  SOAPMessageImpl() {
    this.attachmentParts = new ArrayList();
    this.saveRequired = true;
    this.soapVersion = 0;
    this.headers = new MimeHeaders();
    this.headers.addHeader("Content-Type", "text/xml");
  }
  
  SOAPMessageImpl(MimeHeaders paramMimeHeaders, InputStream paramInputStream) throws SOAPException, IOException {
    this.attachmentParts = new ArrayList();
    this.saveRequired = true;
    this.soapVersion = 0;
    this.headers = paramMimeHeaders;
    ContentType contentType1 = null;
    if (this.headers == null) {
      contentType1 = getDefaultContentType();
    } else {
      contentType1 = getContentType(this.headers);
    } 
    String str = contentType1.getBaseType();
    if ("text/xml".equalsIgnoreCase(str)) {
      String str1 = "US-ASCII";
      String str2 = contentType1.getParameter("charset");
      if (str2 != null) {
        str1 = CharsetMap.getJavaFromIANA(str2);
        if (str1 == null)
          str1 = str2; 
      } else {
        str1 = getDefaultContentType().getParameter("charset");
      } 
      if (str2 != null) {
        setCharset(str2);
      } else {
        setCharset(str1);
      } 
      this.soapPart = new SOAPPartImpl(this.headers, XmlReader.createReader(paramInputStream, str1), this);
    } else if ("Multipart/Related".equalsIgnoreCase(str)) {
      handleMimeMessage(paramInputStream, contentType1);
    } else if ("application/soap+xml".equalsIgnoreCase(str)) {
      String str1 = null;
      String str2 = contentType1.getParameter("charset");
      if (str2 != null)
        str1 = CharsetMap.getJavaFromIANA(str2); 
      if (str1 != null) {
        this.soapPart = new SOAPPartImpl(this.headers, XmlReader.createReader(paramInputStream, str1), this);
      } else {
        this.soapPart = new SOAPPartImpl(this.headers, XmlReader.createReader(paramInputStream), this);
      } 
      if (str2 != null) {
        setCharset(str2);
      } else {
        setCharset("UTF-8");
      } 
      setSOAP12();
    } else {
      throw new SOAPException("Unsupported Content-Type: " + str);
    } 
  }
  
  private static ContentType getDefaultContentType() {
    ContentType contentType1;
    try {
      contentType1 = new ContentType("text/xml");
    } catch (ParseException parseException) {
      String str = WebServiceLogger.logSoapMessageContentException();
      WebServiceLogger.logStackTrace(str, parseException);
      throw new AssertionError(parseException);
    } 
    return contentType1;
  }
  
  private ContentType getContentType(MimeHeaders paramMimeHeaders) throws SOAPException {
    String[] arrayOfString = paramMimeHeaders.getHeader("Content-Type");
    if (arrayOfString == null || arrayOfString.length == 0)
      throw new SOAPException("There was no Content-Type header"); 
    if (arrayOfString.length > 1)
      throw new SOAPException("There should be only one Content-Type MimeHeader"); 
    try {
      return new ContentType(arrayOfString[0]);
    } catch (ParseException parseException) {
      String str = WebServiceLogger.logSoapMessageGetContentException();
      WebServiceLogger.logStackTrace(str, parseException);
      throw new SOAPException("Error parsing Content-Type header:" + arrayOfString[0], parseException);
    } 
  }
  
  private void handleMimeMessage(InputStream paramInputStream, ContentType paramContentType) throws SOAPException, IOException {
    String str = paramContentType.getParameter("start");
    if (str == null);
    try {
      InputStreamDataSource inputStreamDataSource = new InputStreamDataSource(paramInputStream);
      MimeMultipart mimeMultipart = new MimeMultipart(inputStreamDataSource);
      mimeMultipart.setContentType(paramContentType.toString());
      boolean bool = false;
      for (byte b = 0; b < mimeMultipart.getCount(); b++) {
        BodyPart bodyPart = mimeMultipart.getBodyPart(b);
        if (b == 0) {
          if (bool)
            throw new SOAPException("Found > 1 attachments with the same content id as the start: " + str); 
          bool = true;
          this.soapPart = new SOAPPartImpl(createMimeHeaders(bodyPart), XmlReader.createReader(bodyPart.getInputStream()), this);
        } else {
          AttachmentPart attachmentPart = createAttachmentPart(bodyPart);
          addAttachmentPart(attachmentPart);
        } 
      } 
    } catch (MessagingException messagingException) {
      String str1 = WebServiceLogger.logSoapMessageMimeException();
      WebServiceLogger.logStackTrace(str1, messagingException);
      throw new SOAPException("Error processing MIME message:", messagingException);
    } 
  }
  
  private MimeHeaders createMimeHeaders(BodyPart paramBodyPart) throws MessagingException {
    MimeHeaders mimeHeaders = new MimeHeaders();
    Enumeration enumeration = paramBodyPart.getAllHeaders();
    while (enumeration.hasMoreElements()) {
      Header header = (Header)enumeration.nextElement();
      mimeHeaders.addHeader(header.getName(), header.getValue());
    } 
    return mimeHeaders;
  }
  
  public String getContentDescription() { return this.contentDescription; }
  
  public void setContentDescription(String paramString) { this.contentDescription = paramString; }
  
  public SOAPPart getSOAPPart() {
    if (this.soapPart == null)
      this.soapPart = new SOAPPartImpl(this); 
    return this.soapPart;
  }
  
  public void removeAllAttachments() { this.attachmentParts.clear(); }
  
  public int countAttachments() { return this.attachmentParts.size(); }
  
  public Iterator getAttachments() { return this.attachmentParts.iterator(); }
  
  private boolean containsAllHeaders(AttachmentPart paramAttachmentPart, MimeHeaders paramMimeHeaders) {
    Iterator iterator = paramMimeHeaders.getAllHeaders();
    while (iterator.hasNext()) {
      MimeHeader mimeHeader = (MimeHeader)iterator.next();
      String[] arrayOfString = paramAttachmentPart.getMimeHeader(mimeHeader.getName());
      if (arrayOfString == null)
        return false; 
      boolean bool = false;
      for (byte b = 0; b < arrayOfString.length; b++) {
        if (arrayOfString[b].equals(mimeHeader.getValue())) {
          bool = true;
          break;
        } 
      } 
      if (!bool)
        return false; 
    } 
    return true;
  }
  
  public Iterator getAttachments(MimeHeaders paramMimeHeaders) {
    ArrayList arrayList = new ArrayList();
    Iterator iterator = this.attachmentParts.iterator();
    while (iterator.hasNext()) {
      AttachmentPart attachmentPart = (AttachmentPart)iterator.next();
      if (containsAllHeaders(attachmentPart, paramMimeHeaders))
        arrayList.add(attachmentPart); 
    } 
    return arrayList.iterator();
  }
  
  public void addAttachmentPart(AttachmentPart paramAttachmentPart) { this.attachmentParts.add(paramAttachmentPart); }
  
  public AttachmentPart createAttachmentPart() { return new AttachmentPartImpl(); }
  
  public AttachmentPart createAttachmentPart(BodyPart paramBodyPart) throws MessagingException {
    AttachmentPartImpl attachmentPartImpl = new AttachmentPartImpl();
    attachmentPartImpl.setDataHandler(paramBodyPart.getDataHandler());
    Enumeration enumeration = paramBodyPart.getAllHeaders();
    while (enumeration.hasMoreElements()) {
      Header header = (Header)enumeration.nextElement();
      attachmentPartImpl.addMimeHeader(header.getName(), header.getValue());
    } 
    return attachmentPartImpl;
  }
  
  public MimeHeaders getMimeHeaders() { return this.headers; }
  
  public void saveChanges() { this.saveRequired = false; }
  
  public boolean saveRequired() { return this.saveRequired; }
  
  private MimeMultipart getMimeMessage() {
    if (this.__dont_touch_mimeMessage == null) {
      this.__dont_touch_mimeMessage = new MimeMultipart("related");
      try {
        ContentType contentType1 = new ContentType(this.__dont_touch_mimeMessage.getContentType());
        String str = "multipart/related;type=\"text/xml\";boundary=\"" + contentType1.getParameter("boundary") + "\";start=" + this.soapPart.getContentId();
        this.__dont_touch_mimeMessage.setContentType(str);
        this.headers.setHeader("Content-Type", str);
      } catch (ParseException parseException) {
        throw new AssertionError(parseException);
      } 
    } 
    return this.__dont_touch_mimeMessage;
  }
  
  public boolean isSOAP12() { return (this.soapVersion == 1); }
  
  public void setSOAP12() { this.soapVersion = 1; }
  
  public void setSOAP11() { this.soapVersion = 0; }
  
  public void setCharset(String paramString) { this.charset = paramString; }
  
  public String getCharset() {
    if (this.charset == null)
      if (defaultCharset != null && defaultCharset.length() != 0) {
        this.charset = defaultCharset;
      } else if ("en".equalsIgnoreCase(language)) {
        this.charset = null;
      } else {
        this.charset = "utf-8";
      }  
    return this.charset;
  }
  
  public String getContentType() {
    if (this.contentType == null)
      if (countAttachments() == 0) {
        if (isSOAP12()) {
          this.contentType = "application/soap+xml";
        } else {
          this.contentType = "text/xml";
        } 
      } else {
        MimeMultipart mimeMultipart = getMimeMessage();
        this.contentType = mimeMultipart.getContentType();
      }  
    return this.contentType;
  }
  
  public void writeTo(OutputStream paramOutputStream) throws SOAPException, IOException {
    if (this.soapPart == null)
      getSOAPPart(); 
    if (this.attachmentParts.isEmpty()) {
      this.soapPart.writeTo(paramOutputStream);
    } else {
      try {
        writeMimeMessage(paramOutputStream);
      } catch (MessagingException messagingException) {
        String str = WebServiceLogger.logSoapMessageWriteMimeException();
        WebServiceLogger.logStackTrace(str, messagingException);
        throw new IOException(StackTraceUtils.throwable2StackTrace(messagingException));
      } 
    } 
  }
  
  private MimeBodyPart createMimeBodyPart(AttachmentPart paramAttachmentPart) throws MessagingException, SOAPException {
    MimeBodyPart mimeBodyPart = new MimeBodyPart();
    mimeBodyPart.setDataHandler(paramAttachmentPart.getDataHandler());
    Iterator iterator = paramAttachmentPart.getAllMimeHeaders();
    while (iterator.hasNext()) {
      MimeHeader mimeHeader = (MimeHeader)iterator.next();
      mimeBodyPart.addHeader(mimeHeader.getName(), mimeHeader.getValue());
    } 
    return mimeBodyPart;
  }
  
  private void writeMimeMessage(OutputStream paramOutputStream) throws SOAPException, IOException {
    paramOutputStream.write(10);
    MimeMultipart mimeMultipart = getMimeMessage();
    byte b = 0;
    InternetHeaders internetHeaders = new InternetHeaders();
    internetHeaders.addHeader("Content-Type", "text/xml; charset=utf-8");
    internetHeaders.addHeader("Content-ID", this.soapPart.getContentId());
    internetHeaders.addHeader("Content-Transfer-Encoding", "8bit");
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    this.soapPart.writeTo(byteArrayOutputStream);
    MimeBodyPart mimeBodyPart = new MimeBodyPart(internetHeaders, byteArrayOutputStream.toByteArray());
    mimeMultipart.addBodyPart(mimeBodyPart, b++);
    Iterator iterator = this.attachmentParts.iterator();
    while (iterator.hasNext()) {
      AttachmentPart attachmentPart = (AttachmentPart)iterator.next();
      mimeBodyPart = createMimeBodyPart(attachmentPart);
      mimeMultipart.addBodyPart(mimeBodyPart, b++);
    } 
    mimeMultipart.writeTo(paramOutputStream);
  }
  
  public String toString() { return "SOAPMessageImpl[" + this.soapPart + "]"; }
  
  private static class MimeMultipart extends MimeMultipart {
    public MimeMultipart() {}
    
    public MimeMultipart(String param1String) { super(param1String); }
    
    public MimeMultipart(DataSource param1DataSource) throws MessagingException { super(param1DataSource); }
    
    void setContentType(String param1String) { this.contentType = param1String; }
  }
  
  public SOAPBody getSOAPBody() throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public SOAPHeader getSOAPHeader() throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setProperty(String paramString, Object paramObject) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Object getProperty(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public class InputStreamDataSource implements DataSource {
    private InputStream inputStream;
    
    private OutputStream outputStream;
    
    private final SOAPMessageImpl this$0;
    
    public InputStreamDataSource(InputStream param1InputStream) { this.inputStream = param1InputStream; }
    
    public InputStream getInputStream() { return this.inputStream; }
    
    public String getContentType() { return "text/xml"; }
    
    public String getName() { return "BEA Systems, Inc."; }
    
    public OutputStream getOutputStream() { return this.outputStream; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPMessageImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */