/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.Header;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.InternetHeaders;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.mail.internet.ParseException;
/*     */ import javax.xml.soap.AttachmentPart;
/*     */ import javax.xml.soap.MimeHeader;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeader;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import javax.xml.soap.SOAPPart;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.utils.CharsetMap;
/*     */ import weblogic.utils.StackTraceUtils;
/*     */ import weblogic.webservice.WLSOAPMessage;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.xml.babel.reader.XmlReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPMessageImpl
/*     */   extends SOAPMessage
/*     */   implements WLSOAPMessage
/*     */ {
/*     */   private String contentDescription;
/*     */   private SOAPPartImpl soapPart;
/*     */   private MimeHeaders headers;
/*     */   private List attachmentParts;
/*     */   private boolean saveRequired;
/*     */   private static final boolean debug = false;
/*     */   private static final String CONTENT_TYPE = "Content-Type";
/*     */   private static final int SOAP11 = 0;
/*     */   private static final int SOAP12 = 1;
/*     */   private MimeMultipart __dont_touch_mimeMessage;
/*     */   private String contentType;
/*     */   private String charset;
/*     */   private int soapVersion;
/*  66 */   private static String defaultCharset = getStringProp("weblogic.webservice.i18n.charset", null);
/*     */ 
/*     */   
/*  69 */   private static String language = getStringProp("user.language", null);
/*     */   
/*     */   private static String getStringProp(String paramString1, String paramString2) {
/*     */     try {
/*  73 */       return System.getProperty(paramString1);
/*  74 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */       
/*  78 */       return paramString2;
/*     */     }  } SOAPMessageImpl() {
/*     */     this.attachmentParts = new ArrayList();
/*     */     this.saveRequired = true;
/*     */     this.soapVersion = 0;
/*  83 */     this.headers = new MimeHeaders();
/*     */ 
/*     */ 
/*     */     
/*  87 */     this.headers.addHeader("Content-Type", "text/xml");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SOAPMessageImpl(MimeHeaders paramMimeHeaders, InputStream paramInputStream) throws SOAPException, IOException {
/*     */     this.attachmentParts = new ArrayList();
/*     */     this.saveRequired = true;
/*     */     this.soapVersion = 0;
/*  97 */     this.headers = paramMimeHeaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     ContentType contentType1 = null;
/*     */     
/* 106 */     if (this.headers == null) {
/* 107 */       contentType1 = getDefaultContentType();
/*     */     } else {
/* 109 */       contentType1 = getContentType(this.headers);
/*     */     } 
/*     */     
/* 112 */     String str = contentType1.getBaseType();
/*     */ 
/*     */     
/* 115 */     if ("text/xml".equalsIgnoreCase(str)) {
/*     */ 
/*     */       
/* 118 */       String str1 = "US-ASCII";
/* 119 */       String str2 = contentType1.getParameter("charset");
/*     */       
/* 121 */       if (str2 != null) {
/* 122 */         str1 = CharsetMap.getJavaFromIANA(str2);
/*     */         
/* 124 */         if (str1 == null) {
/* 125 */           str1 = str2;
/*     */         }
/*     */       } else {
/* 128 */         str1 = getDefaultContentType().getParameter("charset");
/*     */       } 
/*     */       
/* 131 */       if (str2 != null) { setCharset(str2); }
/* 132 */       else { setCharset(str1); }
/*     */       
/* 134 */       this.soapPart = new SOAPPartImpl(this.headers, XmlReader.createReader(paramInputStream, str1), this);
/*     */     
/*     */     }
/* 137 */     else if ("Multipart/Related".equalsIgnoreCase(str)) {
/*     */       
/* 139 */       handleMimeMessage(paramInputStream, contentType1);
/* 140 */     } else if ("application/soap+xml".equalsIgnoreCase(str)) {
/*     */ 
/*     */       
/* 143 */       String str1 = null;
/* 144 */       String str2 = contentType1.getParameter("charset");
/*     */       
/* 146 */       if (str2 != null) {
/* 147 */         str1 = CharsetMap.getJavaFromIANA(str2);
/*     */       }
/*     */       
/* 150 */       if (str1 != null) {
/* 151 */         this.soapPart = new SOAPPartImpl(this.headers, XmlReader.createReader(paramInputStream, str1), this);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 156 */         this.soapPart = new SOAPPartImpl(this.headers, XmlReader.createReader(paramInputStream), this);
/*     */       } 
/*     */ 
/*     */       
/* 160 */       if (str2 != null) { setCharset(str2); }
/* 161 */       else { setCharset("UTF-8"); }
/*     */       
/* 163 */       setSOAP12();
/*     */     } else {
/* 165 */       throw new SOAPException("Unsupported Content-Type: " + str);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static ContentType getDefaultContentType() {
/*     */     ContentType contentType1;
/*     */     try {
/* 173 */       contentType1 = new ContentType("text/xml");
/* 174 */     } catch (ParseException parseException) {
/* 175 */       String str = WebServiceLogger.logSoapMessageContentException();
/*     */       
/* 177 */       WebServiceLogger.logStackTrace(str, parseException);
/*     */       
/* 179 */       throw new AssertionError(parseException);
/*     */     } 
/*     */     
/* 182 */     return contentType1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContentType getContentType(MimeHeaders paramMimeHeaders) throws SOAPException {
/* 190 */     String[] arrayOfString = paramMimeHeaders.getHeader("Content-Type");
/*     */     
/* 192 */     if (arrayOfString == null || arrayOfString.length == 0)
/* 193 */       throw new SOAPException("There was no Content-Type header"); 
/* 194 */     if (arrayOfString.length > 1) {
/* 195 */       throw new SOAPException("There should be only one Content-Type MimeHeader");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 200 */       return new ContentType(arrayOfString[0]);
/* 201 */     } catch (ParseException parseException) {
/* 202 */       String str = WebServiceLogger.logSoapMessageGetContentException();
/* 203 */       WebServiceLogger.logStackTrace(str, parseException);
/*     */       
/* 205 */       throw new SOAPException("Error parsing Content-Type header:" + arrayOfString[0], parseException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleMimeMessage(InputStream paramInputStream, ContentType paramContentType) throws SOAPException, IOException {
/* 215 */     String str = paramContentType.getParameter("start");
/*     */     
/* 217 */     if (str == null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 226 */       InputStreamDataSource inputStreamDataSource = new InputStreamDataSource(paramInputStream);
/* 227 */       MimeMultipart mimeMultipart = new MimeMultipart(inputStreamDataSource);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 233 */       mimeMultipart.setContentType(paramContentType.toString());
/*     */       
/* 235 */       boolean bool = false;
/*     */       
/* 237 */       for (byte b = 0; b < mimeMultipart.getCount(); b++) {
/* 238 */         BodyPart bodyPart = mimeMultipart.getBodyPart(b);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 245 */         if (b == 0)
/*     */         {
/* 247 */           if (bool) {
/* 248 */             throw new SOAPException("Found > 1 attachments with the same content id as the start: " + str);
/*     */           }
/*     */           
/* 251 */           bool = true;
/*     */           
/* 253 */           this.soapPart = new SOAPPartImpl(createMimeHeaders(bodyPart), XmlReader.createReader(bodyPart.getInputStream()), this);
/*     */         
/*     */         }
/*     */         else
/*     */         {
/*     */           
/* 259 */           AttachmentPart attachmentPart = createAttachmentPart(bodyPart);
/* 260 */           addAttachmentPart(attachmentPart);
/*     */         }
/*     */       
/*     */       } 
/* 264 */     } catch (MessagingException messagingException) {
/* 265 */       String str1 = WebServiceLogger.logSoapMessageMimeException();
/* 266 */       WebServiceLogger.logStackTrace(str1, messagingException);
/* 267 */       throw new SOAPException("Error processing MIME message:", messagingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeHeaders createMimeHeaders(BodyPart paramBodyPart) throws MessagingException {
/* 275 */     MimeHeaders mimeHeaders = new MimeHeaders();
/*     */     
/* 277 */     Enumeration enumeration = paramBodyPart.getAllHeaders();
/*     */     
/* 279 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 281 */       Header header = (Header)enumeration.nextElement();
/*     */       
/* 283 */       mimeHeaders.addHeader(header.getName(), header.getValue());
/*     */     } 
/*     */     
/* 286 */     return mimeHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   public String getContentDescription() { return this.contentDescription; }
/*     */ 
/*     */ 
/*     */   
/* 296 */   public void setContentDescription(String paramString) { this.contentDescription = paramString; }
/*     */ 
/*     */   
/*     */   public SOAPPart getSOAPPart() {
/* 300 */     if (this.soapPart == null) {
/* 301 */       this.soapPart = new SOAPPartImpl(this);
/*     */     }
/*     */     
/* 304 */     return this.soapPart;
/*     */   }
/*     */ 
/*     */   
/* 308 */   public void removeAllAttachments() { this.attachmentParts.clear(); }
/*     */ 
/*     */ 
/*     */   
/* 312 */   public int countAttachments() { return this.attachmentParts.size(); }
/*     */ 
/*     */ 
/*     */   
/* 316 */   public Iterator getAttachments() { return this.attachmentParts.iterator(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean containsAllHeaders(AttachmentPart paramAttachmentPart, MimeHeaders paramMimeHeaders) {
/* 323 */     Iterator iterator = paramMimeHeaders.getAllHeaders();
/*     */     
/* 325 */     while (iterator.hasNext()) {
/*     */       
/* 327 */       MimeHeader mimeHeader = (MimeHeader)iterator.next();
/*     */       
/* 329 */       String[] arrayOfString = paramAttachmentPart.getMimeHeader(mimeHeader.getName());
/*     */       
/* 331 */       if (arrayOfString == null) return false;
/*     */       
/* 333 */       boolean bool = false;
/*     */       
/* 335 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 336 */         if (arrayOfString[b].equals(mimeHeader.getValue())) {
/* 337 */           bool = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 342 */       if (!bool) return false;
/*     */     
/*     */     } 
/* 345 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getAttachments(MimeHeaders paramMimeHeaders) {
/* 351 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 353 */     Iterator iterator = this.attachmentParts.iterator();
/*     */     
/* 355 */     while (iterator.hasNext()) {
/*     */       
/* 357 */       AttachmentPart attachmentPart = (AttachmentPart)iterator.next();
/*     */       
/* 359 */       if (containsAllHeaders(attachmentPart, paramMimeHeaders)) {
/* 360 */         arrayList.add(attachmentPart);
/*     */       }
/*     */     } 
/*     */     
/* 364 */     return arrayList.iterator();
/*     */   }
/*     */ 
/*     */   
/* 368 */   public void addAttachmentPart(AttachmentPart paramAttachmentPart) { this.attachmentParts.add(paramAttachmentPart); }
/*     */ 
/*     */ 
/*     */   
/* 372 */   public AttachmentPart createAttachmentPart() { return new AttachmentPartImpl(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttachmentPart createAttachmentPart(BodyPart paramBodyPart) throws MessagingException {
/* 379 */     AttachmentPartImpl attachmentPartImpl = new AttachmentPartImpl();
/*     */     
/* 381 */     attachmentPartImpl.setDataHandler(paramBodyPart.getDataHandler());
/*     */     
/* 383 */     Enumeration enumeration = paramBodyPart.getAllHeaders();
/*     */     
/* 385 */     while (enumeration.hasMoreElements()) {
/* 386 */       Header header = (Header)enumeration.nextElement();
/* 387 */       attachmentPartImpl.addMimeHeader(header.getName(), header.getValue());
/*     */     } 
/*     */     
/* 390 */     return attachmentPartImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 395 */   public MimeHeaders getMimeHeaders() { return this.headers; }
/*     */ 
/*     */ 
/*     */   
/* 399 */   public void saveChanges() { this.saveRequired = false; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 404 */   public boolean saveRequired() { return this.saveRequired; }
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeMultipart getMimeMessage() {
/* 409 */     if (this.__dont_touch_mimeMessage == null) {
/* 410 */       this.__dont_touch_mimeMessage = new MimeMultipart("related");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 432 */         ContentType contentType1 = new ContentType(this.__dont_touch_mimeMessage.getContentType());
/*     */ 
/*     */ 
/*     */         
/* 436 */         String str = "multipart/related;type=\"text/xml\";boundary=\"" + contentType1.getParameter("boundary") + "\";start=" + this.soapPart.getContentId();
/*     */ 
/*     */ 
/*     */         
/* 440 */         this.__dont_touch_mimeMessage.setContentType(str);
/*     */         
/* 442 */         this.headers.setHeader("Content-Type", str);
/*     */       }
/* 444 */       catch (ParseException parseException) {
/*     */ 
/*     */         
/* 447 */         throw new AssertionError(parseException);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 452 */     return this.__dont_touch_mimeMessage;
/*     */   }
/*     */ 
/*     */   
/* 456 */   public boolean isSOAP12() { return (this.soapVersion == 1); }
/*     */ 
/*     */ 
/*     */   
/* 460 */   public void setSOAP12() { this.soapVersion = 1; }
/*     */ 
/*     */ 
/*     */   
/* 464 */   public void setSOAP11() { this.soapVersion = 0; }
/*     */ 
/*     */ 
/*     */   
/* 468 */   public void setCharset(String paramString) { this.charset = paramString; }
/*     */ 
/*     */   
/*     */   public String getCharset() {
/* 472 */     if (this.charset == null) {
/* 473 */       if (defaultCharset != null && defaultCharset.length() != 0) {
/* 474 */         this.charset = defaultCharset;
/* 475 */       } else if ("en".equalsIgnoreCase(language)) {
/* 476 */         this.charset = null;
/*     */       } else {
/* 478 */         this.charset = "utf-8";
/*     */       } 
/*     */     }
/*     */     
/* 482 */     return this.charset;
/*     */   }
/*     */   
/*     */   public String getContentType() {
/* 486 */     if (this.contentType == null)
/*     */     {
/* 488 */       if (countAttachments() == 0) {
/*     */         
/* 490 */         if (isSOAP12()) {
/* 491 */           this.contentType = "application/soap+xml";
/*     */         } else {
/* 493 */           this.contentType = "text/xml";
/*     */         } 
/*     */       } else {
/*     */         
/* 497 */         MimeMultipart mimeMultipart = getMimeMessage();
/* 498 */         this.contentType = mimeMultipart.getContentType();
/*     */       } 
/*     */     }
/*     */     
/* 502 */     return this.contentType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream paramOutputStream) throws SOAPException, IOException {
/* 508 */     if (this.soapPart == null) {
/* 509 */       getSOAPPart();
/*     */     }
/*     */     
/* 512 */     if (this.attachmentParts.isEmpty()) {
/* 513 */       this.soapPart.writeTo(paramOutputStream);
/*     */     } else {
/*     */       try {
/* 516 */         writeMimeMessage(paramOutputStream);
/* 517 */       } catch (MessagingException messagingException) {
/* 518 */         String str = WebServiceLogger.logSoapMessageWriteMimeException();
/* 519 */         WebServiceLogger.logStackTrace(str, messagingException);
/* 520 */         throw new IOException(StackTraceUtils.throwable2StackTrace(messagingException));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeBodyPart createMimeBodyPart(AttachmentPart paramAttachmentPart) throws MessagingException, SOAPException {
/* 532 */     MimeBodyPart mimeBodyPart = new MimeBodyPart();
/*     */ 
/*     */ 
/*     */     
/* 536 */     mimeBodyPart.setDataHandler(paramAttachmentPart.getDataHandler());
/*     */ 
/*     */     
/* 539 */     Iterator iterator = paramAttachmentPart.getAllMimeHeaders();
/*     */     
/* 541 */     while (iterator.hasNext()) {
/* 542 */       MimeHeader mimeHeader = (MimeHeader)iterator.next();
/*     */       
/* 544 */       mimeBodyPart.addHeader(mimeHeader.getName(), mimeHeader.getValue());
/*     */     } 
/*     */     
/* 547 */     return mimeBodyPart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeMimeMessage(OutputStream paramOutputStream) throws SOAPException, IOException {
/* 556 */     paramOutputStream.write(10);
/*     */     
/* 558 */     MimeMultipart mimeMultipart = getMimeMessage();
/*     */     
/* 560 */     byte b = 0;
/*     */ 
/*     */ 
/*     */     
/* 564 */     InternetHeaders internetHeaders = new InternetHeaders();
/* 565 */     internetHeaders.addHeader("Content-Type", "text/xml; charset=utf-8");
/* 566 */     internetHeaders.addHeader("Content-ID", this.soapPart.getContentId());
/* 567 */     internetHeaders.addHeader("Content-Transfer-Encoding", "8bit");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 574 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 575 */     this.soapPart.writeTo(byteArrayOutputStream);
/* 576 */     MimeBodyPart mimeBodyPart = new MimeBodyPart(internetHeaders, byteArrayOutputStream.toByteArray());
/*     */     
/* 578 */     mimeMultipart.addBodyPart(mimeBodyPart, b++);
/*     */ 
/*     */ 
/*     */     
/* 582 */     Iterator iterator = this.attachmentParts.iterator();
/*     */     
/* 584 */     while (iterator.hasNext()) {
/*     */       
/* 586 */       AttachmentPart attachmentPart = (AttachmentPart)iterator.next();
/*     */       
/* 588 */       mimeBodyPart = createMimeBodyPart(attachmentPart);
/* 589 */       mimeMultipart.addBodyPart(mimeBodyPart, b++);
/*     */     } 
/*     */     
/* 592 */     mimeMultipart.writeTo(paramOutputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 598 */   public String toString() { return "SOAPMessageImpl[" + this.soapPart + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MimeMultipart
/*     */     extends MimeMultipart
/*     */   {
/*     */     public MimeMultipart() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 614 */     public MimeMultipart(String param1String) { super(param1String); }
/*     */ 
/*     */ 
/*     */     
/* 618 */     public MimeMultipart(DataSource param1DataSource) throws MessagingException { super(param1DataSource); }
/*     */ 
/*     */ 
/*     */     
/* 622 */     void setContentType(String param1String) { this.contentType = param1String; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 628 */   public SOAPBody getSOAPBody() throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 633 */   public SOAPHeader getSOAPHeader() throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 636 */   public void setProperty(String paramString, Object paramObject) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 641 */   public Object getProperty(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/*     */   public class InputStreamDataSource
/*     */     implements DataSource
/*     */   {
/*     */     private InputStream inputStream;
/*     */     
/*     */     private OutputStream outputStream;
/*     */     
/*     */     private final SOAPMessageImpl this$0;
/*     */     
/* 653 */     public InputStreamDataSource(InputStream param1InputStream) { this.inputStream = param1InputStream; }
/*     */ 
/*     */     
/* 656 */     public InputStream getInputStream() { return this.inputStream; }
/*     */ 
/*     */     
/* 659 */     public String getContentType() { return "text/xml"; }
/*     */ 
/*     */     
/* 662 */     public String getName() { return "BEA Systems, Inc."; }
/*     */ 
/*     */     
/* 665 */     public OutputStream getOutputStream() { return this.outputStream; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPMessageImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */