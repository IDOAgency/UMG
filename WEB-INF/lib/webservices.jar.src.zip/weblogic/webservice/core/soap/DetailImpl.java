package weblogic.webservice.core.soap;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPException;
import weblogic.xml.stream.XMLName;
import weblogic.xml.xmlnode.XMLNode;

public final class DetailImpl extends SOAPElementImpl implements Detail, Serializable {
  private static final NameImpl DETAIL_NAME = new NameImpl("detail");
  
  public DetailImpl() { super(DETAIL_NAME); }
  
  public DetailEntry addDetailEntry(Name paramName) throws SOAPException { return (DetailEntry)addChildElement(paramName); }
  
  public Iterator getDetailEntries() {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = getChildElements(); iterator.hasNext(); ) {
      Object object = iterator.next();
      if (object instanceof DetailEntry)
        arrayList.add(object); 
    } 
    return arrayList.iterator();
  }
  
  protected XMLNode createChild(XMLName paramXMLName) { return new DetailEntryImpl(paramXMLName); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\DetailImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */