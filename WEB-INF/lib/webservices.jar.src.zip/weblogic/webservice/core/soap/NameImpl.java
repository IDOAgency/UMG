/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import javax.xml.soap.Name;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NameImpl
/*     */   implements Name, XMLName
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   private final String local;
/*     */   private final String prefix;
/*     */   private final String uri;
/*     */   private final String qualifiedName;
/*     */   private final int hash;
/*     */   
/*  75 */   public NameImpl(String paramString) { this(paramString, null, null); }
/*     */ 
/*     */ 
/*     */   
/*  79 */   public NameImpl(String paramString1, String paramString2) { this(paramString1, paramString2, null); }
/*     */ 
/*     */ 
/*     */   
/*  83 */   public NameImpl(Name paramName) { this(paramName.getLocalName(), paramName.getPrefix(), paramName.getURI()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameImpl(String paramString1, String paramString2, String paramString3) {
/*  90 */     this.local = paramString1;
/*  91 */     this.prefix = paramString2;
/*  92 */     this.uri = paramString3;
/*     */     
/*  94 */     int i = paramString1.hashCode();
/*     */     
/*  96 */     if (paramString3 != null) i ^= paramString3.hashCode();
/*     */     
/*  98 */     this.hash = i;
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.qualifiedName = (paramString2 == null) ? paramString1 : (paramString2 + ":" + paramString1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean seq(String paramString1, String paramString2) {
/* 108 */     if (paramString1 == null) {
/* 109 */       return (paramString2 == null);
/*     */     }
/* 111 */     return paramString1.equals(paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 118 */     if (paramObject == this) return true;
/*     */     
/* 120 */     if (paramObject instanceof Name) {
/* 121 */       Name name = (Name)paramObject;
/*     */       
/* 123 */       return (this.local.equals(name.getLocalName()) && seq(this.uri, name.getURI()));
/*     */     } 
/*     */     
/* 126 */     if (paramObject instanceof XMLName) {
/* 127 */       XMLName xMLName = (XMLName)paramObject;
/*     */       
/* 129 */       return (this.local.equals(xMLName.getLocalName()) && seq(this.uri, xMLName.getNamespaceUri()));
/*     */     } 
/*     */ 
/*     */     
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 138 */   public int hashCode() { return this.hash; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public String getLocalName() { return this.local; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public String getQualifiedName() { return this.qualifiedName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public String getPrefix() { return this.prefix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public String getURI() { return this.uri; }
/*     */ 
/*     */ 
/*     */   
/* 182 */   public String getNamespaceUri() { return this.uri; }
/*     */ 
/*     */ 
/*     */   
/* 186 */   public String toString() { return getQualifiedName(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\NameImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */