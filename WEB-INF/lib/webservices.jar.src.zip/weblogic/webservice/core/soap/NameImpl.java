package weblogic.webservice.core.soap;

import javax.xml.soap.Name;
import weblogic.xml.stream.XMLName;

public final class NameImpl implements Name, XMLName {
  private static final boolean debug = false;
  
  private final String local;
  
  private final String prefix;
  
  private final String uri;
  
  private final String qualifiedName;
  
  private final int hash;
  
  public NameImpl(String paramString) { this(paramString, null, null); }
  
  public NameImpl(String paramString1, String paramString2) { this(paramString1, paramString2, null); }
  
  public NameImpl(Name paramName) { this(paramName.getLocalName(), paramName.getPrefix(), paramName.getURI()); }
  
  public NameImpl(String paramString1, String paramString2, String paramString3) {
    this.local = paramString1;
    this.prefix = paramString2;
    this.uri = paramString3;
    int i = paramString1.hashCode();
    if (paramString3 != null)
      i ^= paramString3.hashCode(); 
    this.hash = i;
    this.qualifiedName = (paramString2 == null) ? paramString1 : (paramString2 + ":" + paramString1);
  }
  
  private boolean seq(String paramString1, String paramString2) {
    if (paramString1 == null)
      return (paramString2 == null); 
    return paramString1.equals(paramString2);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject instanceof Name) {
      Name name = (Name)paramObject;
      return (this.local.equals(name.getLocalName()) && seq(this.uri, name.getURI()));
    } 
    if (paramObject instanceof XMLName) {
      XMLName xMLName = (XMLName)paramObject;
      return (this.local.equals(xMLName.getLocalName()) && seq(this.uri, xMLName.getNamespaceUri()));
    } 
    return false;
  }
  
  public int hashCode() { return this.hash; }
  
  public String getLocalName() { return this.local; }
  
  public String getQualifiedName() { return this.qualifiedName; }
  
  public String getPrefix() { return this.prefix; }
  
  public String getURI() { return this.uri; }
  
  public String getNamespaceUri() { return this.uri; }
  
  public String toString() { return getQualifiedName(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\NameImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */