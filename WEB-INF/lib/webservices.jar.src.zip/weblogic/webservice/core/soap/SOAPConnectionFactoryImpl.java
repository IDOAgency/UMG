/*    */ package weblogic.webservice.core.soap;
/*    */ 
/*    */ import javax.xml.soap.SOAPConnection;
/*    */ import javax.xml.soap.SOAPConnectionFactory;
/*    */ import javax.xml.soap.SOAPException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPConnectionFactoryImpl
/*    */   extends SOAPConnectionFactory
/*    */ {
/* 18 */   public SOAPConnection createConnection() throws SOAPException { return new SOAPConnectionImpl(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPConnectionFactoryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */