package weblogic.webservice.core.soap;

import java.io.IOException;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.binding.BindingFactory;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.core.DefaultMessageContext;

public class SOAPConnectionImpl extends SOAPConnection {
  private boolean closed = false;
  
  public SOAPMessage call(SOAPMessage paramSOAPMessage, Object paramObject) throws SOAPException {
    String str;
    if (this.closed)
      throw new SOAPException("connection already closed"); 
    if (paramObject == null)
      throw new IllegalArgumentException("endpoint can not be null"); 
    if (paramObject instanceof String) {
      str = (String)paramObject;
    } else if (paramObject instanceof java.net.URL) {
      str = paramObject.toString();
    } else {
      throw new IllegalArgumentException("endpoint should be String or URL");
    } 
    try {
      BindingFactory bindingFactory = BindingFactory.getInstance();
      BindingInfo bindingInfo = new BindingInfo();
      bindingInfo.setAddress(str);
      Binding binding = bindingFactory.create(bindingInfo);
      DefaultMessageContext defaultMessageContext = new DefaultMessageContext();
      defaultMessageContext.setMessage(paramSOAPMessage);
      binding.send(defaultMessageContext);
      binding.receive(defaultMessageContext);
      return defaultMessageContext.getMessage();
    } catch (IOException iOException) {
      throw new SOAPException("Failed to send message: " + iOException, iOException);
    } 
  }
  
  public void close() {
    if (this.closed)
      throw new SOAPException("connection already closed"); 
    this.closed = true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPConnectionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */