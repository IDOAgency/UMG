/*    */ package weblogic.webservice.core.soap;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.soap.SOAPConnection;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import javax.xml.soap.SOAPMessage;
/*    */ import weblogic.webservice.binding.Binding;
/*    */ import weblogic.webservice.binding.BindingFactory;
/*    */ import weblogic.webservice.binding.BindingInfo;
/*    */ import weblogic.webservice.core.DefaultMessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPConnectionImpl
/*    */   extends SOAPConnection
/*    */ {
/*    */   private boolean closed = false;
/*    */   
/*    */   public SOAPMessage call(SOAPMessage paramSOAPMessage, Object paramObject) throws SOAPException {
/*    */     String str;
/* 31 */     if (this.closed) {
/* 32 */       throw new SOAPException("connection already closed");
/*    */     }
/*    */     
/* 35 */     if (paramObject == null) {
/* 36 */       throw new IllegalArgumentException("endpoint can not be null");
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 41 */     if (paramObject instanceof String) {
/* 42 */       str = (String)paramObject;
/* 43 */     } else if (paramObject instanceof java.net.URL) {
/* 44 */       str = paramObject.toString();
/*    */     } else {
/* 46 */       throw new IllegalArgumentException("endpoint should be String or URL");
/*    */     } 
/*    */     
/*    */     try {
/* 50 */       BindingFactory bindingFactory = BindingFactory.getInstance();
/* 51 */       BindingInfo bindingInfo = new BindingInfo();
/* 52 */       bindingInfo.setAddress(str);
/*    */       
/* 54 */       Binding binding = bindingFactory.create(bindingInfo);
/*    */       
/* 56 */       DefaultMessageContext defaultMessageContext = new DefaultMessageContext();
/* 57 */       defaultMessageContext.setMessage(paramSOAPMessage);
/*    */       
/* 59 */       binding.send(defaultMessageContext);
/* 60 */       binding.receive(defaultMessageContext);
/*    */       
/* 62 */       return defaultMessageContext.getMessage();
/* 63 */     } catch (IOException iOException) {
/* 64 */       throw new SOAPException("Failed to send message: " + iOException, iOException);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 70 */     if (this.closed) {
/* 71 */       throw new SOAPException("connection already closed");
/*    */     }
/*    */     
/* 74 */     this.closed = true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPConnectionImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */