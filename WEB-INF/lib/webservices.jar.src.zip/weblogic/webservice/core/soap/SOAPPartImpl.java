package weblogic.webservice.core.soap;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.util.Iterator;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.w3c.dom.UserDataHandler;
import weblogic.utils.CharsetMap;
import weblogic.webservice.WLSOAPPart;
import weblogic.webservice.util.NoFlushOutputStreamWriter;
import weblogic.xml.stream.ElementFactory;
import weblogic.xml.stream.XMLEvent;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;

public class SOAPPartImpl extends SOAPPart implements WLSOAPPart {
  private SOAPEnvelopeImpl envelope;
  
  private Reader reader;
  
  private byte[] bytes;
  
  private XMLInputStream xmlInputStream;
  
  private MimeHeaders headers;
  
  private static final int SOAP_ENVELOPE = 0;
  
  private static final int READER = 1;
  
  private static final int XML_INPUT = 2;
  
  private static final int BYTES = 3;
  
  private int sourceType;
  
  private XMLOutputStreamFactory factory;
  
  private SOAPMessageImpl soapMessage;
  
  private static final String CONTENT_TYPE = "Content-Type";
  
  SOAPPartImpl(SOAPMessageImpl paramSOAPMessageImpl) {
    this.sourceType = 0;
    this.factory = XMLOutputStreamFactory.newInstance();
    this.soapMessage = paramSOAPMessageImpl;
    this.headers = new MimeHeaders();
    this.headers.addHeader("Content-Type", "text/xml");
  }
  
  SOAPPartImpl(MimeHeaders paramMimeHeaders, Reader paramReader, SOAPMessageImpl paramSOAPMessageImpl) throws SOAPException, IOException {
    this.sourceType = 0;
    this.factory = XMLOutputStreamFactory.newInstance();
    this.soapMessage = paramSOAPMessageImpl;
    this.headers = paramMimeHeaders;
    this.reader = paramReader;
    this.sourceType = 1;
  }
  
  private String getSoapNS() {
    if (this.soapMessage.isSOAP12())
      return "http://www.w3.org/2003/05/soap-envelope"; 
    return "http://schemas.xmlsoap.org/soap/envelope/";
  }
  
  private String getSoapEncNS() {
    if (this.soapMessage.isSOAP12())
      return "http://www.w3.org/2003/05/soap-encoding"; 
    return "http://schemas.xmlsoap.org/soap/encoding/";
  }
  
  public void setContent(XMLInputStream paramXMLInputStream) {
    this.xmlInputStream = paramXMLInputStream;
    this.envelope = null;
    this.reader = null;
    this.sourceType = 2;
  }
  
  public XMLInputStream getXMLStreamContent() throws SOAPException, XMLStreamException {
    if (this.sourceType == 2)
      return this.xmlInputStream; 
    if (this.sourceType == 1)
      return XMLInputStreamFactory.newInstance().newInputStream(this.reader); 
    if (this.sourceType == 0) {
      if (this.envelope == null)
        getEnvelope(); 
      return this.envelope.stream();
    } 
    throw new SOAPException("unknown source type");
  }
  
  public SOAPEnvelope getEnvelope() throws SOAPException {
    if (this.sourceType == 0) {
      if (this.envelope == null)
        this.envelope = new SOAPEnvelopeImpl(getSoapNS(), getSoapEncNS()); 
    } else if (this.sourceType == 1) {
      try {
        this.envelope = new SOAPEnvelopeImpl(this.reader);
        this.reader.close();
        this.reader = null;
      } catch (IOException iOException) {
        throw new SOAPException(iOException);
      } 
    } else if (this.sourceType == 2) {
      try {
        this.envelope = new SOAPEnvelopeImpl(this.xmlInputStream);
      } catch (IOException iOException) {
        throw new SOAPException(iOException);
      } 
    } else if (this.sourceType == 3) {
      try {
        this.envelope = new SOAPEnvelopeImpl(new ByteArrayInputStream(this.bytes));
        this.bytes = null;
      } catch (IOException iOException) {
        throw new SOAPException(iOException);
      } 
    } 
    this.sourceType = 0;
    return this.envelope;
  }
  
  public String getContentId() {
    String str = super.getContentId();
    if (this.soapMessage.countAttachments() == 0)
      return str; 
    if (str != null)
      return str; 
    str = "__WLS__" + System.currentTimeMillis() + "__SOAP__";
    setContentId(str);
    return str;
  }
  
  public void removeMimeHeader(String paramString) { this.headers.removeHeader(paramString); }
  
  public void removeAllMimeHeaders() { this.headers.removeAllHeaders(); }
  
  public String[] getMimeHeader(String paramString) { return this.headers.getHeader(paramString); }
  
  public void setMimeHeader(String paramString1, String paramString2) { this.headers.setHeader(paramString1, paramString2); }
  
  public void addMimeHeader(String paramString1, String paramString2) { this.headers.addHeader(paramString1, paramString2); }
  
  public Iterator getAllMimeHeaders() { return this.headers.getAllHeaders(); }
  
  public Iterator getMatchingMimeHeaders(String[] paramArrayOfString) { return this.headers.getMatchingHeaders(paramArrayOfString); }
  
  public Iterator getNonMatchingMimeHeaders(String[] paramArrayOfString) { return this.headers.getNonMatchingHeaders(paramArrayOfString); }
  
  public void setContent(Source paramSource) throws SOAPException {
    if (paramSource == null) {
      this.envelope = null;
      return;
    } 
    try {
      XMLInputStream xMLInputStream = getStreamFromSource(paramSource);
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      String str = this.soapMessage.getCharset();
      if (str != null && 
        CharsetMap.getJavaFromIANA(str) != null)
        str = CharsetMap.getJavaFromIANA(str); 
      NoFlushOutputStreamWriter noFlushOutputStreamWriter = null;
      if (str != null) {
        noFlushOutputStreamWriter = new NoFlushOutputStreamWriter(byteArrayOutputStream, str, true);
      } else {
        noFlushOutputStreamWriter = new NoFlushOutputStreamWriter(byteArrayOutputStream);
      } 
      XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newOutputStream(noFlushOutputStreamWriter);
      xMLOutputStream.add(xMLInputStream);
      xMLOutputStream.flush();
      xMLOutputStream.close();
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
      this.envelope = new SOAPEnvelopeImpl(byteArrayInputStream);
    } catch (XMLStreamException xMLStreamException) {
      throw new SOAPException("failed to convert DOM to SOAPEnvelope:" + xMLStreamException, xMLStreamException);
    } catch (IOException iOException) {
      throw new SOAPException("failed to convert DOM to SOAPEnvelope:" + iOException, iOException);
    } 
  }
  
  private XMLInputStream getStreamFromSource(Source paramSource) throws SOAPException, XMLStreamException {
    XMLInputStream xMLInputStream;
    if (paramSource instanceof DOMSource) {
      DOMSource dOMSource = (DOMSource)paramSource;
      Node node = dOMSource.getNode();
      if (!(node instanceof Document))
        throw new SOAPException("Node is not a document"); 
      xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(node);
    } else if (paramSource instanceof StreamSource) {
      StreamSource streamSource = (StreamSource)paramSource;
      InputStream inputStream = streamSource.getInputStream();
      if (inputStream != null) {
        xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(inputStream);
      } else {
        Reader reader1 = streamSource.getReader();
        if (reader1 != null) {
          xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(reader1);
        } else {
          throw new SOAPException("Either InputSource or Reader has to be set on StreamSource.");
        } 
      } 
    } else {
      throw new SOAPException("unknown source type " + paramSource.getClass());
    } 
    return xMLInputStream;
  }
  
  public Source getContent() throws SOAPException {
    if (this.envelope == null)
      getEnvelope(); 
    try {
      XMLInputStream xMLInputStream = this.envelope.stream();
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      documentBuilderFactory.setNamespaceAware(true);
      Document document = documentBuilderFactory.newDocumentBuilder().newDocument();
      XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newOutputStream(document);
      xMLOutputStream.add(xMLInputStream);
      xMLOutputStream.flush();
      xMLOutputStream.close();
      return new DOMSource(document);
    } catch (ParserConfigurationException parserConfigurationException) {
      parserConfigurationException.printStackTrace();
      throw new SOAPException("failed to create Source" + parserConfigurationException, parserConfigurationException);
    } catch (XMLStreamException xMLStreamException) {
      xMLStreamException.printStackTrace();
      throw new SOAPException("failed to parse xml" + xMLStreamException, xMLStreamException);
    } catch (Throwable throwable) {
      throwable.printStackTrace();
      throw new SOAPException(throwable);
    } 
  }
  
  public void writeTo(XMLOutputStream paramXMLOutputStream) throws SOAPException, XMLStreamException {
    if (this.envelope == null)
      getEnvelope(); 
    this.envelope.write(paramXMLOutputStream);
  }
  
  public void writeTo(OutputStream paramOutputStream) throws SOAPException, IOException {
    XMLOutputStream xMLOutputStream = null;
    OutputStreamWriter outputStreamWriter = null;
    ByteArrayOutputStream byteArrayOutputStream = null;
    OutputStream outputStream = null;
    if (this.sourceType == 3) {
      paramOutputStream.write(this.bytes);
      paramOutputStream.flush();
      return;
    } 
    if (this.sourceType == 2) {
      byteArrayOutputStream = new ByteArrayOutputStream();
      outputStream = paramOutputStream;
      paramOutputStream = byteArrayOutputStream;
    } 
    try {
      String str = this.soapMessage.getCharset();
      if (str != null)
        if (CharsetMap.getJavaFromIANA(str) != null)
          str = CharsetMap.getJavaFromIANA(str);  
      if (str != null) {
        try {
          outputStreamWriter = new NoFlushOutputStreamWriter(paramOutputStream, str, true);
        } catch (SecurityException securityException) {
          outputStreamWriter = new OutputStreamWriter(paramOutputStream, str);
        } 
      } else {
        try {
          outputStreamWriter = new NoFlushOutputStreamWriter(paramOutputStream);
        } catch (SecurityException securityException) {
          outputStreamWriter = new OutputStreamWriter(paramOutputStream);
        } 
      } 
      xMLOutputStream = this.factory.newOutputStream(outputStreamWriter, false);
      if (this.sourceType == 2) {
        if (str != null) {
          XMLEvent xMLEvent = this.xmlInputStream.peek();
          if (xMLEvent != null && !xMLEvent.isStartDocument())
            xMLOutputStream.add(ElementFactory.createStartDocument(str, "1.0", null)); 
        } 
        xMLOutputStream.add(this.xmlInputStream);
      } else {
        if (this.soapMessage.getCharset() != null)
          xMLOutputStream.add(ElementFactory.createStartDocument(this.soapMessage.getCharset(), "1.0", null)); 
        if (this.envelope == null)
          getEnvelope(); 
        this.envelope.write(xMLOutputStream);
      } 
    } catch (RuntimeException runtimeException) {
      runtimeException.printStackTrace();
      throw runtimeException;
    } finally {
      if (xMLOutputStream != null)
        try {
          xMLOutputStream.close();
        } catch (XMLStreamException xMLStreamException) {} 
      if (outputStreamWriter != null) {
        try {
          outputStreamWriter.flush();
        } catch (IOException iOException) {}
        try {
          outputStreamWriter.close();
        } catch (IOException iOException) {}
      } 
      if (this.sourceType == 2) {
        this.bytes = byteArrayOutputStream.toByteArray();
        outputStream.write(this.bytes);
        outputStream.flush();
        this.sourceType = 3;
      } 
    } 
  }
  
  public String toString() { return "SOAPPartImpl[" + this.envelope + "]"; }
  
  public String getNodeName() { throw new UnsupportedOperationException("This class does not supportSAAJ 1.1"); }
  
  public void setNodeName(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getNodeValue() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setNodeValue(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setNodeType(short paramShort) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public short getNodeType() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getParentNode() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NodeList getChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getFirstChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getLastChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getPreviousSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getNextSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NamedNodeMap getAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setOwnerDocument(Document paramDocument) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Document getOwnerDocument() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node removeChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node appendChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean hasChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void removeChildren() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node cloneNode(boolean paramBoolean) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void normalize() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean isSupported(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getNamespaceURI() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getPrefix() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setPrefix(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getLocalName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean hasAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setValue(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getData() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setData(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public DOMImplementation getImplementation() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public DocumentType getDoctype() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Element getDocumentElement() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Element createElement(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public DocumentFragment createDocumentFragment() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Text createTextNode(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Comment createComment(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public CDATASection createCDATASection(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public ProcessingInstruction createProcessingInstruction(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Attr createAttribute(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public EntityReference createEntityReference(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NodeList getElementsByTagName(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node importNode(Node paramNode, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Element createElementNS(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Attr createAttributeNS(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NodeList getElementsByTagNameNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Element getElementById(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node renameNode(Node paramNode, String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void normalizeDocument() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public DOMConfiguration getDomConfig() throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setDocumentURI(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getDocumentURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Node adoptNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setStrictErrorChecking(boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean getStrictErrorChecking() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setXmlVersion(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getXmlVersion() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setXmlStandalone(boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean getXmlStandalone() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getXmlEncoding() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getInputEncoding() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Object getUserData(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Object setUserData(String paramString, Object paramObject, UserDataHandler paramUserDataHandler) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Object getFeature(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isEqualNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String lookupNamespaceURI(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isDefaultNamespace(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String lookupPrefix(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isSameNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setTextContent(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getTextContent() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public short compareDocumentPosition(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getBaseURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPPartImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */