/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Reader;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPPart;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.CDATASection;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.DOMConfiguration;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentFragment;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.EntityReference;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ import org.w3c.dom.UserDataHandler;
/*     */ import weblogic.utils.CharsetMap;
/*     */ import weblogic.webservice.WLSOAPPart;
/*     */ import weblogic.webservice.util.NoFlushOutputStreamWriter;
/*     */ import weblogic.xml.stream.ElementFactory;
/*     */ import weblogic.xml.stream.XMLEvent;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPPartImpl
/*     */   extends SOAPPart
/*     */   implements WLSOAPPart
/*     */ {
/*     */   private SOAPEnvelopeImpl envelope;
/*     */   private Reader reader;
/*     */   private byte[] bytes;
/*     */   private XMLInputStream xmlInputStream;
/*     */   private MimeHeaders headers;
/*     */   private static final int SOAP_ENVELOPE = 0;
/*     */   private static final int READER = 1;
/*     */   private static final int XML_INPUT = 2;
/*     */   private static final int BYTES = 3;
/*     */   private int sourceType;
/*     */   private XMLOutputStreamFactory factory;
/*     */   private SOAPMessageImpl soapMessage;
/*     */   private static final String CONTENT_TYPE = "Content-Type";
/*     */   
/*     */   SOAPPartImpl(SOAPMessageImpl paramSOAPMessageImpl) {
/* 107 */     this.sourceType = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.factory = XMLOutputStreamFactory.newInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     this.soapMessage = paramSOAPMessageImpl;
/* 124 */     this.headers = new MimeHeaders();
/* 125 */     this.headers.addHeader("Content-Type", "text/xml");
/*     */   }
/*     */   
/*     */   SOAPPartImpl(MimeHeaders paramMimeHeaders, Reader paramReader, SOAPMessageImpl paramSOAPMessageImpl) throws SOAPException, IOException {
/*     */     this.sourceType = 0;
/*     */     this.factory = XMLOutputStreamFactory.newInstance();
/* 131 */     this.soapMessage = paramSOAPMessageImpl;
/* 132 */     this.headers = paramMimeHeaders;
/* 133 */     this.reader = paramReader;
/*     */     
/* 135 */     this.sourceType = 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getSoapNS() {
/* 140 */     if (this.soapMessage.isSOAP12()) {
/* 141 */       return "http://www.w3.org/2003/05/soap-envelope";
/*     */     }
/* 143 */     return "http://schemas.xmlsoap.org/soap/envelope/";
/*     */   }
/*     */ 
/*     */   
/*     */   private String getSoapEncNS() {
/* 148 */     if (this.soapMessage.isSOAP12()) {
/* 149 */       return "http://www.w3.org/2003/05/soap-encoding";
/*     */     }
/* 151 */     return "http://schemas.xmlsoap.org/soap/encoding/";
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContent(XMLInputStream paramXMLInputStream) {
/* 156 */     this.xmlInputStream = paramXMLInputStream;
/* 157 */     this.envelope = null;
/* 158 */     this.reader = null;
/* 159 */     this.sourceType = 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLInputStream getXMLStreamContent() throws SOAPException, XMLStreamException {
/* 165 */     if (this.sourceType == 2)
/* 166 */       return this.xmlInputStream; 
/* 167 */     if (this.sourceType == 1)
/* 168 */       return XMLInputStreamFactory.newInstance().newInputStream(this.reader); 
/* 169 */     if (this.sourceType == 0) {
/*     */ 
/*     */       
/* 172 */       if (this.envelope == null) {
/* 173 */         getEnvelope();
/*     */       }
/* 175 */       return this.envelope.stream();
/*     */     } 
/* 177 */     throw new SOAPException("unknown source type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPEnvelope getEnvelope() throws SOAPException {
/* 193 */     if (this.sourceType == 0) {
/* 194 */       if (this.envelope == null) {
/* 195 */         this.envelope = new SOAPEnvelopeImpl(getSoapNS(), getSoapEncNS());
/*     */       }
/* 197 */     } else if (this.sourceType == 1) {
/*     */       try {
/* 199 */         this.envelope = new SOAPEnvelopeImpl(this.reader);
/* 200 */         this.reader.close();
/* 201 */         this.reader = null;
/* 202 */       } catch (IOException iOException) {
/* 203 */         throw new SOAPException(iOException);
/*     */       } 
/* 205 */     } else if (this.sourceType == 2) {
/*     */       try {
/* 207 */         this.envelope = new SOAPEnvelopeImpl(this.xmlInputStream);
/* 208 */       } catch (IOException iOException) {
/* 209 */         throw new SOAPException(iOException);
/*     */       } 
/* 211 */     } else if (this.sourceType == 3) {
/*     */       try {
/* 213 */         this.envelope = new SOAPEnvelopeImpl(new ByteArrayInputStream(this.bytes));
/* 214 */         this.bytes = null;
/* 215 */       } catch (IOException iOException) {
/* 216 */         throw new SOAPException(iOException);
/*     */       } 
/*     */     } 
/*     */     
/* 220 */     this.sourceType = 0;
/* 221 */     return this.envelope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentId() {
/* 228 */     String str = super.getContentId();
/*     */     
/* 230 */     if (this.soapMessage.countAttachments() == 0)
/*     */     {
/* 232 */       return str;
/*     */     }
/*     */     
/* 235 */     if (str != null) {
/* 236 */       return str;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     str = "__WLS__" + System.currentTimeMillis() + "__SOAP__";
/* 245 */     setContentId(str);
/* 246 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   public void removeMimeHeader(String paramString) { this.headers.removeHeader(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   public void removeAllMimeHeaders() { this.headers.removeAllHeaders(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 280 */   public String[] getMimeHeader(String paramString) { return this.headers.getHeader(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 309 */   public void setMimeHeader(String paramString1, String paramString2) { this.headers.setHeader(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 328 */   public void addMimeHeader(String paramString1, String paramString2) { this.headers.addHeader(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 339 */   public Iterator getAllMimeHeaders() { return this.headers.getAllHeaders(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 352 */   public Iterator getMatchingMimeHeaders(String[] paramArrayOfString) { return this.headers.getMatchingHeaders(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 367 */   public Iterator getNonMatchingMimeHeaders(String[] paramArrayOfString) { return this.headers.getNonMatchingHeaders(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContent(Source paramSource) throws SOAPException {
/* 382 */     if (paramSource == null) {
/* 383 */       this.envelope = null;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 389 */       XMLInputStream xMLInputStream = getStreamFromSource(paramSource);
/* 390 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */       
/* 392 */       String str = this.soapMessage.getCharset();
/*     */       
/* 394 */       if (str != null && 
/* 395 */         CharsetMap.getJavaFromIANA(str) != null) {
/* 396 */         str = CharsetMap.getJavaFromIANA(str);
/*     */       }
/*     */       
/* 399 */       NoFlushOutputStreamWriter noFlushOutputStreamWriter = null;
/* 400 */       if (str != null) {
/* 401 */         noFlushOutputStreamWriter = new NoFlushOutputStreamWriter(byteArrayOutputStream, str, true);
/*     */       } else {
/* 403 */         noFlushOutputStreamWriter = new NoFlushOutputStreamWriter(byteArrayOutputStream);
/*     */       } 
/*     */       
/* 406 */       XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newOutputStream(noFlushOutputStreamWriter);
/*     */ 
/*     */       
/* 409 */       xMLOutputStream.add(xMLInputStream);
/* 410 */       xMLOutputStream.flush();
/* 411 */       xMLOutputStream.close();
/*     */       
/* 413 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
/* 414 */       this.envelope = new SOAPEnvelopeImpl(byteArrayInputStream);
/* 415 */     } catch (XMLStreamException xMLStreamException) {
/* 416 */       throw new SOAPException("failed to convert DOM to SOAPEnvelope:" + xMLStreamException, xMLStreamException);
/*     */     }
/* 418 */     catch (IOException iOException) {
/* 419 */       throw new SOAPException("failed to convert DOM to SOAPEnvelope:" + iOException, iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private XMLInputStream getStreamFromSource(Source paramSource) throws SOAPException, XMLStreamException {
/*     */     XMLInputStream xMLInputStream;
/* 427 */     if (paramSource instanceof DOMSource) {
/* 428 */       DOMSource dOMSource = (DOMSource)paramSource;
/* 429 */       Node node = dOMSource.getNode();
/*     */       
/* 431 */       if (!(node instanceof Document)) {
/* 432 */         throw new SOAPException("Node is not a document");
/*     */       }
/*     */       
/* 435 */       xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(node);
/* 436 */     } else if (paramSource instanceof StreamSource) {
/* 437 */       StreamSource streamSource = (StreamSource)paramSource;
/*     */       
/* 439 */       InputStream inputStream = streamSource.getInputStream();
/* 440 */       if (inputStream != null) {
/* 441 */         xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(inputStream);
/*     */       } else {
/* 443 */         Reader reader1 = streamSource.getReader();
/* 444 */         if (reader1 != null) {
/* 445 */           xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(reader1);
/*     */         } else {
/* 447 */           throw new SOAPException("Either InputSource or Reader has to be set on StreamSource.");
/*     */         } 
/*     */       } 
/*     */     } else {
/* 451 */       throw new SOAPException("unknown source type " + paramSource.getClass());
/*     */     } 
/*     */     
/* 454 */     return xMLInputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Source getContent() throws SOAPException {
/* 469 */     if (this.envelope == null) {
/* 470 */       getEnvelope();
/*     */     }
/*     */     
/*     */     try {
/* 474 */       XMLInputStream xMLInputStream = this.envelope.stream();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 485 */       DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
/* 486 */       documentBuilderFactory.setNamespaceAware(true);
/* 487 */       Document document = documentBuilderFactory.newDocumentBuilder().newDocument();
/*     */       
/* 489 */       XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newOutputStream(document);
/*     */ 
/*     */       
/* 492 */       xMLOutputStream.add(xMLInputStream);
/* 493 */       xMLOutputStream.flush();
/* 494 */       xMLOutputStream.close();
/*     */       
/* 496 */       return new DOMSource(document);
/* 497 */     } catch (ParserConfigurationException parserConfigurationException) {
/* 498 */       parserConfigurationException.printStackTrace();
/* 499 */       throw new SOAPException("failed to create Source" + parserConfigurationException, parserConfigurationException);
/* 500 */     } catch (XMLStreamException xMLStreamException) {
/* 501 */       xMLStreamException.printStackTrace();
/* 502 */       throw new SOAPException("failed to parse xml" + xMLStreamException, xMLStreamException);
/* 503 */     } catch (Throwable throwable) {
/* 504 */       throwable.printStackTrace();
/* 505 */       throw new SOAPException(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(XMLOutputStream paramXMLOutputStream) throws SOAPException, XMLStreamException {
/* 512 */     if (this.envelope == null) {
/* 513 */       getEnvelope();
/*     */     }
/*     */     
/* 516 */     this.envelope.write(paramXMLOutputStream);
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeTo(OutputStream paramOutputStream) throws SOAPException, IOException {
/* 521 */     XMLOutputStream xMLOutputStream = null;
/* 522 */     OutputStreamWriter outputStreamWriter = null;
/*     */     
/* 524 */     ByteArrayOutputStream byteArrayOutputStream = null;
/* 525 */     OutputStream outputStream = null;
/*     */ 
/*     */     
/* 528 */     if (this.sourceType == 3) {
/* 529 */       paramOutputStream.write(this.bytes);
/* 530 */       paramOutputStream.flush();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 535 */     if (this.sourceType == 2) {
/* 536 */       byteArrayOutputStream = new ByteArrayOutputStream();
/* 537 */       outputStream = paramOutputStream;
/* 538 */       paramOutputStream = byteArrayOutputStream;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 543 */       String str = this.soapMessage.getCharset();
/*     */       
/* 545 */       if (str != null)
/*     */       {
/* 547 */         if (CharsetMap.getJavaFromIANA(str) != null) {
/* 548 */           str = CharsetMap.getJavaFromIANA(str);
/*     */         }
/*     */       }
/*     */       
/* 552 */       if (str != null) {
/*     */         try {
/* 554 */           outputStreamWriter = new NoFlushOutputStreamWriter(paramOutputStream, str, true);
/* 555 */         } catch (SecurityException securityException) {
/*     */ 
/*     */           
/* 558 */           outputStreamWriter = new OutputStreamWriter(paramOutputStream, str);
/*     */         } 
/*     */       } else {
/*     */         try {
/* 562 */           outputStreamWriter = new NoFlushOutputStreamWriter(paramOutputStream);
/* 563 */         } catch (SecurityException securityException) {
/*     */ 
/*     */           
/* 566 */           outputStreamWriter = new OutputStreamWriter(paramOutputStream);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 571 */       xMLOutputStream = this.factory.newOutputStream(outputStreamWriter, false);
/*     */       
/* 573 */       if (this.sourceType == 2) {
/*     */ 
/*     */ 
/*     */         
/* 577 */         if (str != null) {
/* 578 */           XMLEvent xMLEvent = this.xmlInputStream.peek();
/* 579 */           if (xMLEvent != null && !xMLEvent.isStartDocument()) {
/* 580 */             xMLOutputStream.add(ElementFactory.createStartDocument(str, "1.0", null));
/*     */           }
/*     */         } 
/* 583 */         xMLOutputStream.add(this.xmlInputStream);
/*     */       }
/*     */       else {
/*     */         
/* 587 */         if (this.soapMessage.getCharset() != null) {
/* 588 */           xMLOutputStream.add(ElementFactory.createStartDocument(this.soapMessage.getCharset(), "1.0", null));
/*     */         }
/*     */ 
/*     */         
/* 592 */         if (this.envelope == null) {
/* 593 */           getEnvelope();
/*     */         }
/*     */         
/* 596 */         this.envelope.write(xMLOutputStream);
/*     */       } 
/* 598 */     } catch (RuntimeException runtimeException) {
/* 599 */       runtimeException.printStackTrace();
/* 600 */       throw runtimeException;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */       
/* 609 */       if (xMLOutputStream != null) {
/* 610 */         try { xMLOutputStream.close(); } catch (XMLStreamException xMLStreamException) {}
/*     */       }
/*     */       
/* 613 */       if (outputStreamWriter != null) { 
/* 614 */         try { outputStreamWriter.flush(); } catch (IOException iOException) {} 
/* 615 */         try { outputStreamWriter.close(); } catch (IOException iOException) {} }
/*     */ 
/*     */       
/* 618 */       if (this.sourceType == 2) {
/* 619 */         this.bytes = byteArrayOutputStream.toByteArray();
/* 620 */         outputStream.write(this.bytes);
/* 621 */         outputStream.flush();
/* 622 */         this.sourceType = 3;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 628 */   public String toString() { return "SOAPPartImpl[" + this.envelope + "]"; }
/*     */ 
/*     */ 
/*     */   
/* 632 */   public String getNodeName() { throw new UnsupportedOperationException("This class does not supportSAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 636 */   public void setNodeName(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 641 */   public String getNodeValue() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 646 */   public void setNodeValue(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 649 */   public void setNodeType(short paramShort) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 653 */   public short getNodeType() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 657 */   public Node getParentNode() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 661 */   public NodeList getChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 665 */   public Node getFirstChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 669 */   public Node getLastChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 673 */   public Node getPreviousSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 677 */   public Node getNextSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 681 */   public NamedNodeMap getAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 684 */   public void setOwnerDocument(Document paramDocument) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 688 */   public Document getOwnerDocument() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 693 */   public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 698 */   public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 703 */   public Node removeChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 708 */   public Node appendChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 712 */   public boolean hasChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 715 */   public void removeChildren() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 719 */   public Node cloneNode(boolean paramBoolean) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 723 */   public void normalize() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 727 */   public boolean isSupported(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 731 */   public String getNamespaceURI() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 735 */   public String getPrefix() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 740 */   public void setPrefix(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 744 */   public String getLocalName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 748 */   public boolean hasAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 751 */   public void setValue(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 756 */   public String getData() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 761 */   public void setData(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 764 */   public DOMImplementation getImplementation() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 767 */   public DocumentType getDoctype() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 770 */   public Element getDocumentElement() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 775 */   public Element createElement(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 778 */   public DocumentFragment createDocumentFragment() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 781 */   public Text createTextNode(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 784 */   public Comment createComment(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 789 */   public CDATASection createCDATASection(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 795 */   public ProcessingInstruction createProcessingInstruction(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 800 */   public Attr createAttribute(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 805 */   public EntityReference createEntityReference(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 808 */   public NodeList getElementsByTagName(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 813 */   public Node importNode(Node paramNode, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 819 */   public Element createElementNS(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 825 */   public Attr createAttributeNS(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 830 */   public NodeList getElementsByTagNameNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 833 */   public Element getElementById(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 837 */   public Node renameNode(Node paramNode, String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 841 */   public void normalizeDocument() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 845 */   public DOMConfiguration getDomConfig() throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 850 */   public void setDocumentURI(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 855 */   public String getDocumentURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 859 */   public Node adoptNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 863 */   public void setStrictErrorChecking(boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 867 */   public boolean getStrictErrorChecking() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 871 */   public void setXmlVersion(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 876 */   public String getXmlVersion() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 880 */   public void setXmlStandalone(boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 885 */   public boolean getXmlStandalone() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 889 */   public String getXmlEncoding() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 894 */   public String getInputEncoding() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 898 */   public Object getUserData(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 903 */   public Object setUserData(String paramString, Object paramObject, UserDataHandler paramUserDataHandler) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 907 */   public Object getFeature(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 911 */   public boolean isEqualNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 915 */   public String lookupNamespaceURI(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 919 */   public boolean isDefaultNamespace(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 923 */   public String lookupPrefix(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 927 */   public boolean isSameNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 931 */   public void setTextContent(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 936 */   public String getTextContent() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 940 */   public short compareDocumentPosition(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 944 */   public String getBaseURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPPartImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */