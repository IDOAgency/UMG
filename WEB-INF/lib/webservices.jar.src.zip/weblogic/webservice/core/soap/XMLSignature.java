/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.util.BufferStream;
/*     */ import weblogic.xml.security.SecurityAssertion;
/*     */ import weblogic.xml.security.keyinfo.KeyResolver;
/*     */ import weblogic.xml.security.specs.SignatureSpec;
/*     */ import weblogic.xml.security.wsse.BinarySecurityToken;
/*     */ import weblogic.xml.security.wsse.SecureSoapInputStream;
/*     */ import weblogic.xml.security.wsse.SecureSoapOutputStream;
/*     */ import weblogic.xml.security.wsse.Security;
/*     */ import weblogic.xml.security.wsse.SecurityElementFactory;
/*     */ import weblogic.xml.security.wsse.Token;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSignature
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*     */   
/*     */   public static void sign(InputStream paramInputStream, OutputStream paramOutputStream, X509Certificate paramX509Certificate, PrivateKey paramPrivateKey) throws XMLSignatureException {
/*     */     XMLInputStream xMLInputStream;
/*     */     try {
/*  53 */       xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(paramInputStream);
/*  54 */     } catch (XMLStreamException xMLStreamException) {
/*  55 */       throw new XMLSignatureMalformedException(xMLStreamException);
/*     */     } 
/*     */     
/*     */     try {
/*  59 */       SecurityElementFactory securityElementFactory = SecurityElementFactory.getDefaultFactory();
/*     */       
/*  61 */       Token token = securityElementFactory.createToken(paramX509Certificate, paramPrivateKey);
/*  62 */       SignatureSpec signatureSpec = SignatureSpec.getDefaultSpec();
/*     */       
/*  64 */       Security security = securityElementFactory.createSecurity(null);
/*  65 */       security.addSignature(token, signatureSpec);
/*  66 */       security.addToken(token);
/*     */       
/*  68 */       BufferStream bufferStream = new BufferStream();
/*  69 */       SecureSoapOutputStream secureSoapOutputStream = new SecureSoapOutputStream(security, bufferStream, "UTF-8");
/*     */       
/*  71 */       SOAPEnvelopeImpl sOAPEnvelopeImpl = new SOAPEnvelopeImpl(xMLInputStream);
/*  72 */       sOAPEnvelopeImpl.write(secureSoapOutputStream);
/*  73 */       secureSoapOutputStream.close(true);
/*  74 */       XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newOutputStream(paramOutputStream);
/*     */       
/*  76 */       xMLOutputStream.add(bufferStream);
/*  77 */       xMLOutputStream.flush();
/*  78 */       xMLOutputStream.close();
/*  79 */     } catch (XMLStreamException xMLStreamException) {
/*  80 */       throw new XMLSignatureException(xMLStreamException);
/*  81 */     } catch (IOException iOException) {
/*  82 */       throw new XMLSignatureMalformedException(iOException);
/*     */     } 
/*     */   }
/*     */   
/*  86 */   private static final Object LOCK = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ValidateResult validate(InputStream paramInputStream) throws XMLSignatureException {
/*  94 */     ValidateResult validateResult = new ValidateResult();
/*     */     
/*     */     try {
/*  97 */       XMLInputStream xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(paramInputStream);
/*  98 */       KeyResolver keyResolver = new KeyResolver();
/*  99 */       SecureSoapInputStream secureSoapInputStream = new SecureSoapInputStream(xMLInputStream, null, keyResolver);
/*     */       
/* 101 */       SecurityAssertion[] arrayOfSecurityAssertion = null;
/*     */       try {
/* 103 */         arrayOfSecurityAssertion = secureSoapInputStream.getSecurityAssertions();
/* 104 */       } catch (XMLStreamException xMLStreamException) {
/*     */         
/* 106 */         throw new XMLSignatureMalformedException(xMLStreamException);
/* 107 */       } catch (Exception exception) {
/* 108 */         throw new XMLSignatureInvalidException(exception);
/*     */       } 
/*     */       
/* 111 */       if (arrayOfSecurityAssertion == null || arrayOfSecurityAssertion.length == 0) {
/* 112 */         throw new XMLSignatureInvalidException("Signature invalid: 0 length SecurityAssersion");
/*     */       }
/* 114 */       validateResult.setAssertions(arrayOfSecurityAssertion);
/*     */ 
/*     */       
/* 117 */       Security security = secureSoapInputStream.getSecurityElement();
/* 118 */       Iterator iterator = security.getBinarySecurityTokens();
/* 119 */       while (iterator.hasNext()) {
/* 120 */         BinarySecurityToken binarySecurityToken = (BinarySecurityToken)iterator.next();
/* 121 */         X509Certificate x509Certificate = binarySecurityToken.getCertificate();
/* 122 */         validateResult.addCertificate(x509Certificate);
/*     */       } 
/* 124 */     } catch (XMLStreamException xMLStreamException) {
/* 125 */       throw new XMLSignatureMalformedException(xMLStreamException);
/*     */     } 
/* 127 */     return validateResult;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\XMLSignature.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */