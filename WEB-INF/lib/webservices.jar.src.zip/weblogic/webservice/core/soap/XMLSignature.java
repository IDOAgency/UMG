package weblogic.webservice.core.soap;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import weblogic.webservice.util.BufferStream;
import weblogic.xml.security.SecurityAssertion;
import weblogic.xml.security.keyinfo.KeyResolver;
import weblogic.xml.security.specs.SignatureSpec;
import weblogic.xml.security.wsse.BinarySecurityToken;
import weblogic.xml.security.wsse.SecureSoapInputStream;
import weblogic.xml.security.wsse.SecureSoapOutputStream;
import weblogic.xml.security.wsse.Security;
import weblogic.xml.security.wsse.SecurityElementFactory;
import weblogic.xml.security.wsse.Token;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;

public class XMLSignature {
  private static final String DEFAULT_ENCODING = "UTF-8";
  
  public static void sign(InputStream paramInputStream, OutputStream paramOutputStream, X509Certificate paramX509Certificate, PrivateKey paramPrivateKey) throws XMLSignatureException {
    XMLInputStream xMLInputStream;
    try {
      xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(paramInputStream);
    } catch (XMLStreamException xMLStreamException) {
      throw new XMLSignatureMalformedException(xMLStreamException);
    } 
    try {
      SecurityElementFactory securityElementFactory = SecurityElementFactory.getDefaultFactory();
      Token token = securityElementFactory.createToken(paramX509Certificate, paramPrivateKey);
      SignatureSpec signatureSpec = SignatureSpec.getDefaultSpec();
      Security security = securityElementFactory.createSecurity(null);
      security.addSignature(token, signatureSpec);
      security.addToken(token);
      BufferStream bufferStream = new BufferStream();
      SecureSoapOutputStream secureSoapOutputStream = new SecureSoapOutputStream(security, bufferStream, "UTF-8");
      SOAPEnvelopeImpl sOAPEnvelopeImpl = new SOAPEnvelopeImpl(xMLInputStream);
      sOAPEnvelopeImpl.write(secureSoapOutputStream);
      secureSoapOutputStream.close(true);
      XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newOutputStream(paramOutputStream);
      xMLOutputStream.add(bufferStream);
      xMLOutputStream.flush();
      xMLOutputStream.close();
    } catch (XMLStreamException xMLStreamException) {
      throw new XMLSignatureException(xMLStreamException);
    } catch (IOException iOException) {
      throw new XMLSignatureMalformedException(iOException);
    } 
  }
  
  private static final Object LOCK = new Object();
  
  public static ValidateResult validate(InputStream paramInputStream) throws XMLSignatureException {
    ValidateResult validateResult = new ValidateResult();
    try {
      XMLInputStream xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(paramInputStream);
      KeyResolver keyResolver = new KeyResolver();
      SecureSoapInputStream secureSoapInputStream = new SecureSoapInputStream(xMLInputStream, null, keyResolver);
      SecurityAssertion[] arrayOfSecurityAssertion = null;
      try {
        arrayOfSecurityAssertion = secureSoapInputStream.getSecurityAssertions();
      } catch (XMLStreamException xMLStreamException) {
        throw new XMLSignatureMalformedException(xMLStreamException);
      } catch (Exception exception) {
        throw new XMLSignatureInvalidException(exception);
      } 
      if (arrayOfSecurityAssertion == null || arrayOfSecurityAssertion.length == 0)
        throw new XMLSignatureInvalidException("Signature invalid: 0 length SecurityAssersion"); 
      validateResult.setAssertions(arrayOfSecurityAssertion);
      Security security = secureSoapInputStream.getSecurityElement();
      Iterator iterator = security.getBinarySecurityTokens();
      while (iterator.hasNext()) {
        BinarySecurityToken binarySecurityToken = (BinarySecurityToken)iterator.next();
        X509Certificate x509Certificate = binarySecurityToken.getCertificate();
        validateResult.addCertificate(x509Certificate);
      } 
    } catch (XMLStreamException xMLStreamException) {
      throw new XMLSignatureMalformedException(xMLStreamException);
    } 
    return validateResult;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\XMLSignature.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */