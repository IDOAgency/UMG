package weblogic.webservice.core.soap;

import java.util.Locale;
import javax.xml.soap.Detail;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import weblogic.xml.stream.XMLName;
import weblogic.xml.xmlnode.XMLNode;

public final class SOAPFaultImpl extends SOAPElementImpl implements SOAPFault {
  private static final Name nameTag = new NameImpl("Fault", ENV_PREFIX, null);
  
  private XMLNode faultCode;
  
  private XMLNode faultActor;
  
  private XMLNode faultString;
  
  private Detail detail;
  
  public SOAPFaultImpl() { super((XMLName)nameTag); }
  
  public Detail addDetail() throws SOAPException {
    if (this.detail != null)
      throw new SOAPException("detail already set"); 
    this.detail = new DetailImpl();
    addChildElement(this.detail);
    return this.detail;
  }
  
  public void setDetail(Detail paramDetail) throws SOAPException {
    this.detail = paramDetail;
    addChildElement(paramDetail);
  }
  
  public Detail getDetail() throws SOAPException { return this.detail; }
  
  protected XMLNode createChild(XMLName paramXMLName) {
    String str = paramXMLName.getLocalName();
    if ("faultcode".equals(str)) {
      this.faultCode = new SOAPElementImpl(paramXMLName);
      return this.faultCode;
    } 
    if ("faultstring".equals(str)) {
      this.faultString = new SOAPElementImpl(paramXMLName);
      return this.faultString;
    } 
    if ("faultactor".equals(str)) {
      this.faultActor = new SOAPElementImpl(paramXMLName);
      return this.faultActor;
    } 
    if ("detail".equals(str)) {
      this.detail = new DetailImpl();
      return (XMLNode)this.detail;
    } 
    return new SOAPElementImpl(paramXMLName);
  }
  
  public String getFaultActor() {
    if (this.faultActor == null)
      return null; 
    return this.faultActor.getText();
  }
  
  public void setFaultActor(String paramString) {
    if (this.faultActor == null) {
      this.faultActor = addChild("faultactor");
    } else {
      this.faultActor.removeTextNodes();
    } 
    this.faultActor.addText(paramString);
  }
  
  public String getFaultCode() {
    if (this.faultCode == null)
      return null; 
    return this.faultCode.getText();
  }
  
  public void setFaultCode(String paramString) {
    if (this.faultCode == null) {
      this.faultCode = addChild("faultcode");
    } else {
      this.faultCode.removeTextNodes();
    } 
    this.faultCode.addText(paramString);
  }
  
  public String getFaultString() {
    if (this.faultString == null)
      return null; 
    return this.faultString.getText();
  }
  
  public void setFaultString(String paramString) {
    if (this.faultString == null) {
      this.faultString = addChild("faultstring");
    } else {
      this.faultString.removeTextNodes();
    } 
    this.faultString.addText(paramString);
  }
  
  public Locale getFaultStringLocale() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setFaultCode(Name paramName) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Name getFaultCodeAsName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setFaultString(String paramString, Locale paramLocale) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPFaultImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */