/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import javax.xml.soap.Detail;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SOAPFaultImpl
/*     */   extends SOAPElementImpl
/*     */   implements SOAPFault
/*     */ {
/*  20 */   private static final Name nameTag = new NameImpl("Fault", ENV_PREFIX, null);
/*     */   
/*     */   private XMLNode faultCode;
/*     */   
/*     */   private XMLNode faultActor;
/*     */   
/*     */   private XMLNode faultString;
/*     */   
/*     */   private Detail detail;
/*     */   
/*  30 */   public SOAPFaultImpl() { super((XMLName)nameTag); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Detail addDetail() throws SOAPException {
/*  36 */     if (this.detail != null) {
/*  37 */       throw new SOAPException("detail already set");
/*     */     }
/*     */     
/*  40 */     this.detail = new DetailImpl();
/*  41 */     addChildElement(this.detail);
/*  42 */     return this.detail;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDetail(Detail paramDetail) throws SOAPException {
/*  48 */     this.detail = paramDetail;
/*  49 */     addChildElement(paramDetail);
/*     */   }
/*     */   
/*  52 */   public Detail getDetail() throws SOAPException { return this.detail; }
/*     */ 
/*     */   
/*     */   protected XMLNode createChild(XMLName paramXMLName) {
/*  56 */     String str = paramXMLName.getLocalName();
/*     */     
/*  58 */     if ("faultcode".equals(str)) {
/*  59 */       this.faultCode = new SOAPElementImpl(paramXMLName);
/*  60 */       return this.faultCode;
/*  61 */     }  if ("faultstring".equals(str)) {
/*  62 */       this.faultString = new SOAPElementImpl(paramXMLName);
/*  63 */       return this.faultString;
/*  64 */     }  if ("faultactor".equals(str)) {
/*  65 */       this.faultActor = new SOAPElementImpl(paramXMLName);
/*  66 */       return this.faultActor;
/*  67 */     }  if ("detail".equals(str)) {
/*  68 */       this.detail = new DetailImpl();
/*  69 */       return (XMLNode)this.detail;
/*     */     } 
/*  71 */     return new SOAPElementImpl(paramXMLName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFaultActor() {
/*  80 */     if (this.faultActor == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     return this.faultActor.getText();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFaultActor(String paramString) {
/*  88 */     if (this.faultActor == null) {
/*  89 */       this.faultActor = addChild("faultactor");
/*     */     } else {
/*  91 */       this.faultActor.removeTextNodes();
/*     */     } 
/*     */     
/*  94 */     this.faultActor.addText(paramString);
/*     */   }
/*     */   
/*     */   public String getFaultCode() {
/*  98 */     if (this.faultCode == null) {
/*  99 */       return null;
/*     */     }
/* 101 */     return this.faultCode.getText();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setFaultCode(String paramString) {
/* 106 */     if (this.faultCode == null) {
/* 107 */       this.faultCode = addChild("faultcode");
/*     */     } else {
/* 109 */       this.faultCode.removeTextNodes();
/*     */     } 
/*     */     
/* 112 */     this.faultCode.addText(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFaultString() {
/* 117 */     if (this.faultString == null) {
/* 118 */       return null;
/*     */     }
/* 120 */     return this.faultString.getText();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFaultString(String paramString) {
/* 126 */     if (this.faultString == null) {
/* 127 */       this.faultString = addChild("faultstring");
/*     */     } else {
/* 129 */       this.faultString.removeTextNodes();
/*     */     } 
/*     */ 
/*     */     
/* 133 */     this.faultString.addText(paramString);
/*     */   }
/*     */ 
/*     */   
/* 137 */   public Locale getFaultStringLocale() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public void setFaultCode(Name paramName) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 147 */   public Name getFaultCodeAsName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public void setFaultString(String paramString, Locale paramLocale) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPFaultImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */