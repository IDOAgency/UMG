package weblogic.webservice.core.soap;

import java.security.cert.X509Certificate;
import java.util.ArrayList;
import weblogic.xml.security.SecurityAssertion;

public class ValidateResult {
  ArrayList certs = new ArrayList();
  
  SecurityAssertion[] assertions;
  
  void addCertificate(X509Certificate paramX509Certificate) { this.certs.add(paramX509Certificate); }
  
  public ArrayList getCertificates() { return this.certs; }
  
  void setAssertions(SecurityAssertion[] paramArrayOfSecurityAssertion) { this.assertions = paramArrayOfSecurityAssertion; }
  
  SecurityAssertion[] getAssertions() { return this.assertions; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\ValidateResult.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */