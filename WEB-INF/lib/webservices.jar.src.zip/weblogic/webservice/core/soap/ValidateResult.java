/*    */ package weblogic.webservice.core.soap;
/*    */ 
/*    */ import java.security.cert.X509Certificate;
/*    */ import java.util.ArrayList;
/*    */ import weblogic.xml.security.SecurityAssertion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateResult
/*    */ {
/* 21 */   ArrayList certs = new ArrayList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SecurityAssertion[] assertions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   void addCertificate(X509Certificate paramX509Certificate) { this.certs.add(paramX509Certificate); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public ArrayList getCertificates() { return this.certs; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   void setAssertions(SecurityAssertion[] paramArrayOfSecurityAssertion) { this.assertions = paramArrayOfSecurityAssertion; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   SecurityAssertion[] getAssertions() { return this.assertions; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\ValidateResult.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */