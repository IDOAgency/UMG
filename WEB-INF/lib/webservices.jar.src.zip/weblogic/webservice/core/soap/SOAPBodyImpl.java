package weblogic.webservice.core.soap;

import java.util.Iterator;
import java.util.Locale;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import org.w3c.dom.Document;
import weblogic.xml.stream.XMLName;
import weblogic.xml.xmlnode.XMLNode;

public class SOAPBodyImpl extends SOAPElementImpl implements SOAPBody {
  private SOAPFaultImpl fault;
  
  SOAPBodyImpl(String paramString) { setName(new NameImpl("Body", ENV_PREFIX, paramString)); }
  
  public SOAPFault addFault() throws SOAPException {
    this.fault = new SOAPFaultImpl();
    addChild(this.fault);
    return this.fault;
  }
  
  public void removeChild(XMLNode paramXMLNode) {
    super.removeChild(paramXMLNode);
    if (paramXMLNode instanceof SOAPFault)
      this.fault = null; 
  }
  
  public boolean hasFault() { return (this.fault != null); }
  
  public SOAPFault getFault() throws SOAPException { return this.fault; }
  
  public SOAPBodyElement addBodyElement(Name paramName) throws SOAPException { return (SOAPBodyElement)addChild(new SOAPBodyElementImpl((XMLName)paramName)); }
  
  protected XMLNode createChild(XMLName paramXMLName) {
    if ("Fault".equals(paramXMLName.getLocalName())) {
      this.fault = new SOAPFaultImpl();
      return this.fault;
    } 
    return new SOAPBodyElementImpl(paramXMLName);
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SOAPBody[");
    for (Iterator iterator = getChildElements(); iterator.hasNext();)
      stringBuffer.append(iterator.next()); 
    stringBuffer.append("]");
    return stringBuffer.toString();
  }
  
  public SOAPBodyElement addDocument(Document paramDocument) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public SOAPFault addFault(Name paramName, String paramString, Locale paramLocale) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public SOAPFault addFault(Name paramName, String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPBodyImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */