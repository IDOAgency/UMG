/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPBodyElement;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import org.w3c.dom.Document;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPBodyImpl
/*     */   extends SOAPElementImpl
/*     */   implements SOAPBody
/*     */ {
/*     */   private SOAPFaultImpl fault;
/*     */   
/*  36 */   SOAPBodyImpl(String paramString) { setName(new NameImpl("Body", ENV_PREFIX, paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPFault addFault() throws SOAPException {
/*  48 */     this.fault = new SOAPFaultImpl();
/*  49 */     addChild(this.fault);
/*  50 */     return this.fault;
/*     */   }
/*     */   
/*     */   public void removeChild(XMLNode paramXMLNode) {
/*  54 */     super.removeChild(paramXMLNode);
/*     */ 
/*     */     
/*  57 */     if (paramXMLNode instanceof SOAPFault) this.fault = null;
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public boolean hasFault() { return (this.fault != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public SOAPFault getFault() throws SOAPException { return this.fault; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public SOAPBodyElement addBodyElement(Name paramName) throws SOAPException { return (SOAPBodyElement)addChild(new SOAPBodyElementImpl((XMLName)paramName)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLNode createChild(XMLName paramXMLName) {
/* 103 */     if ("Fault".equals(paramXMLName.getLocalName())) {
/* 104 */       this.fault = new SOAPFaultImpl();
/* 105 */       return this.fault;
/*     */     } 
/* 107 */     return new SOAPBodyElementImpl(paramXMLName);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 112 */     StringBuffer stringBuffer = new StringBuffer();
/* 113 */     stringBuffer.append("SOAPBody[");
/*     */     
/* 115 */     for (Iterator iterator = getChildElements(); iterator.hasNext();) {
/* 116 */       stringBuffer.append(iterator.next());
/*     */     }
/*     */     
/* 119 */     stringBuffer.append("]");
/*     */     
/* 121 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 126 */   public SOAPBodyElement addDocument(Document paramDocument) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public SOAPFault addFault(Name paramName, String paramString, Locale paramLocale) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public SOAPFault addFault(Name paramName, String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPBodyImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */