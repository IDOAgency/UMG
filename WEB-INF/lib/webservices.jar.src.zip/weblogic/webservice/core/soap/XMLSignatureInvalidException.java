/*    */ package weblogic.webservice.core.soap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLSignatureInvalidException
/*    */   extends XMLSignatureException
/*    */ {
/* 20 */   public XMLSignatureInvalidException(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   public XMLSignatureInvalidException(Exception paramException) { super(paramException); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\XMLSignatureInvalidException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */