package weblogic.webservice.core.soap;

import javax.xml.soap.DetailEntry;
import weblogic.xml.stream.XMLName;

public class DetailEntryImpl extends SOAPElementImpl implements DetailEntry {
  public DetailEntryImpl(XMLName paramXMLName) { super(paramXMLName); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\DetailEntryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */