/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.soap.AttachmentPart;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AttachmentPartImpl
/*     */   extends AttachmentPart
/*     */ {
/*  26 */   private MimeHeaders mimeHeaders = new MimeHeaders();
/*     */   
/*     */   private DataHandler dataHandler;
/*     */ 
/*     */   
/*     */   public AttachmentPartImpl() {}
/*     */   
/*  33 */   public AttachmentPartImpl(DataHandler paramDataHandler) { this.dataHandler = paramDataHandler; }
/*     */ 
/*     */ 
/*     */   
/*  37 */   public void removeMimeHeader(String paramString) { this.mimeHeaders.removeHeader(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  41 */   public void removeAllMimeHeaders() { this.mimeHeaders.removeAllHeaders(); }
/*     */ 
/*     */ 
/*     */   
/*  45 */   public String[] getMimeHeader(String paramString) { return this.mimeHeaders.getHeader(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  49 */   public Iterator getAllMimeHeaders() { return this.mimeHeaders.getAllHeaders(); }
/*     */ 
/*     */ 
/*     */   
/*  53 */   public Iterator getMatchingMimeHeaders(String[] paramArrayOfString) { return this.mimeHeaders.getMatchingHeaders(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public Iterator getNonMatchingMimeHeaders(String[] paramArrayOfString) { return this.mimeHeaders.getNonMatchingHeaders(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void setMimeHeader(String paramString1, String paramString2) { this.mimeHeaders.setHeader(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void addMimeHeader(String paramString1, String paramString2) { this.mimeHeaders.addHeader(paramString1, paramString2); }
/*     */ 
/*     */   
/*     */   public void setDataHandler(DataHandler paramDataHandler) {
/*  69 */     if (paramDataHandler == null) {
/*  70 */       throw new IllegalArgumentException("DataHandler can not be null");
/*     */     }
/*     */     
/*  73 */     this.dataHandler = paramDataHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler getDataHandler() throws SOAPException {
/*  79 */     if (this.dataHandler == null) {
/*  80 */       throw new SOAPException("There is no data in this AttachmentPart");
/*     */     }
/*  82 */     return this.dataHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContent(Object paramObject, String paramString) {
/*  88 */     if (paramObject == null) {
/*  89 */       throw new JAXRPCException("AttachmentPart.setContent was called with a null content parameter.  If you want to remove the contents of this AttachmentPart, use clearContent() instead.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     setContentType(paramString);
/*  96 */     this.dataHandler = new DataHandler(paramObject, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() throws SOAPException {
/* 101 */     if (this.dataHandler == null) {
/* 102 */       return 0;
/*     */     }
/*     */     
/* 105 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*     */     try {
/* 108 */       this.dataHandler.writeTo(byteArrayOutputStream);
/* 109 */       int i = byteArrayOutputStream.size();
/* 110 */       byteArrayOutputStream.close();
/* 111 */       return i;
/* 112 */     } catch (IOException iOException) {
/* 113 */       throw new SOAPException(iOException);
/*     */     } 
/*     */   }
/*     */   
/* 117 */   public void clearContent() { this.dataHandler = null; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getContent() throws SOAPException {
/* 122 */     if (this.dataHandler == null) {
/* 123 */       throw new SOAPException("There is no data in this AttachmentPart");
/*     */     }
/*     */     
/*     */     try {
/* 127 */       return this.dataHandler.getContent();
/* 128 */     } catch (IOException iOException) {
/* 129 */       throw new SOAPException("Error retrieving Attachment content", iOException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\AttachmentPartImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */