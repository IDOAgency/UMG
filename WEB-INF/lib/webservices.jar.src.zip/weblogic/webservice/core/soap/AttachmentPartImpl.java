package weblogic.webservice.core.soap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Iterator;
import javax.activation.DataHandler;
import javax.xml.rpc.JAXRPCException;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;

public final class AttachmentPartImpl extends AttachmentPart {
  private MimeHeaders mimeHeaders = new MimeHeaders();
  
  private DataHandler dataHandler;
  
  public AttachmentPartImpl() {}
  
  public AttachmentPartImpl(DataHandler paramDataHandler) { this.dataHandler = paramDataHandler; }
  
  public void removeMimeHeader(String paramString) { this.mimeHeaders.removeHeader(paramString); }
  
  public void removeAllMimeHeaders() { this.mimeHeaders.removeAllHeaders(); }
  
  public String[] getMimeHeader(String paramString) { return this.mimeHeaders.getHeader(paramString); }
  
  public Iterator getAllMimeHeaders() { return this.mimeHeaders.getAllHeaders(); }
  
  public Iterator getMatchingMimeHeaders(String[] paramArrayOfString) { return this.mimeHeaders.getMatchingHeaders(paramArrayOfString); }
  
  public Iterator getNonMatchingMimeHeaders(String[] paramArrayOfString) { return this.mimeHeaders.getNonMatchingHeaders(paramArrayOfString); }
  
  public void setMimeHeader(String paramString1, String paramString2) { this.mimeHeaders.setHeader(paramString1, paramString2); }
  
  public void addMimeHeader(String paramString1, String paramString2) { this.mimeHeaders.addHeader(paramString1, paramString2); }
  
  public void setDataHandler(DataHandler paramDataHandler) {
    if (paramDataHandler == null)
      throw new IllegalArgumentException("DataHandler can not be null"); 
    this.dataHandler = paramDataHandler;
  }
  
  public DataHandler getDataHandler() throws SOAPException {
    if (this.dataHandler == null)
      throw new SOAPException("There is no data in this AttachmentPart"); 
    return this.dataHandler;
  }
  
  public void setContent(Object paramObject, String paramString) {
    if (paramObject == null)
      throw new JAXRPCException("AttachmentPart.setContent was called with a null content parameter.  If you want to remove the contents of this AttachmentPart, use clearContent() instead."); 
    setContentType(paramString);
    this.dataHandler = new DataHandler(paramObject, paramString);
  }
  
  public int getSize() throws SOAPException {
    if (this.dataHandler == null)
      return 0; 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      this.dataHandler.writeTo(byteArrayOutputStream);
      int i = byteArrayOutputStream.size();
      byteArrayOutputStream.close();
      return i;
    } catch (IOException iOException) {
      throw new SOAPException(iOException);
    } 
  }
  
  public void clearContent() { this.dataHandler = null; }
  
  public Object getContent() throws SOAPException {
    if (this.dataHandler == null)
      throw new SOAPException("There is no data in this AttachmentPart"); 
    try {
      return this.dataHandler.getContent();
    } catch (IOException iOException) {
      throw new SOAPException("Error retrieving Attachment content", iOException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\AttachmentPartImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */