/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeader;
/*     */ import weblogic.utils.NestedRuntimeException;
/*     */ import weblogic.utils.StackTraceUtils;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.util.RecyclingFactory;
/*     */ import weblogic.xml.stream.util.TypeFilter;
/*     */ import weblogic.xml.xmlnode.NodeBuilder;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPEnvelopeImpl
/*     */   extends SOAPElementImpl
/*     */   implements SOAPEnvelope
/*     */ {
/* 103 */   private static final RecyclingFactory pool = new RecyclingFactory();
/*     */   
/*     */   private static final boolean debug = false;
/*     */   
/*     */   private static final String SCHEMA_PREFIX = "xsd";
/*     */   
/*     */   private static final String SCHEMA_NS = "http://www.w3.org/2001/XMLSchema";
/*     */   
/*     */   private static final String SCHEMA_INSTANCE_PREFIX = "xsi";
/*     */   
/*     */   private static final String SOAPENC_PREFIX = "soapenc";
/*     */   
/*     */   private static final String SCHEMA_INSTANCE_NS = "http://www.w3.org/2001/XMLSchema-instance";
/*     */   private SOAPBodyImpl body;
/*     */   private SOAPHeaderImpl header;
/*     */   private String soapNS;
/*     */   
/*     */   SOAPEnvelopeImpl(String paramString1, String paramString2) throws SOAPException {
/* 121 */     super(new NameImpl("Envelope", ENV_PREFIX, paramString1));
/* 122 */     this.soapNS = paramString1;
/* 123 */     addNamespaceDeclaration(ENV_PREFIX, paramString1);
/* 124 */     addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
/* 125 */     addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
/* 126 */     addNamespaceDeclaration("soapenc", paramString2);
/* 127 */     this.header = new SOAPHeaderImpl(paramString1, ENV_PREFIX);
/* 128 */     this.body = new SOAPBodyImpl(paramString1);
/* 129 */     addChild(this.header);
/* 130 */     addChild(this.body);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   SOAPEnvelopeImpl(InputStream paramInputStream) throws IOException, SOAPException {
/* 136 */     TypeFilter typeFilter = new TypeFilter(86);
/*     */ 
/*     */ 
/*     */     
/* 140 */     XMLInputStream xMLInputStream = pool.remove(paramInputStream, typeFilter);
/* 141 */     processXMLInputStream(xMLInputStream);
/* 142 */     pool.add(xMLInputStream);
/*     */   }
/*     */ 
/*     */   
/* 146 */   SOAPEnvelopeImpl(XMLInputStream paramXMLInputStream) throws IOException { processXMLInputStream(paramXMLInputStream); }
/*     */ 
/*     */ 
/*     */   
/* 150 */   SOAPEnvelopeImpl(Reader paramReader) throws IOException, SOAPException { NodeBuilder nodeBuilder = new NodeBuilder(this, paramReader); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processXMLInputStream(XMLInputStream paramXMLInputStream) throws IOException {
/*     */     try {
/* 193 */       paramXMLInputStream.skip(2);
/* 194 */       read(paramXMLInputStream);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 199 */     catch (NestedRuntimeException nestedRuntimeException) {
/* 200 */       Throwable throwable = nestedRuntimeException.getNestedException();
/*     */       
/* 202 */       if (throwable instanceof IOException) {
/* 203 */         throw (IOException)throwable;
/*     */       }
/* 205 */       String str = WebServiceLogger.logSoapEnvelopeInputException();
/* 206 */       WebServiceLogger.logStackTrace(str, throwable);
/*     */       
/* 208 */       throw new IOException("Unexpected Error: " + StackTraceUtils.throwable2StackTrace(throwable));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public Name createName(String paramString1, String paramString2, String paramString3) throws SOAPException { return new NameImpl(paramString1, paramString2, paramString3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 249 */   public Name createName(String paramString1, String paramString2) throws SOAPException { return new NameImpl(paramString1, paramString2, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 267 */   public Name createName(String paramString) throws SOAPException { return new NameImpl(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 287 */   public SOAPHeader getHeader() throws SOAPException { return this.header; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 308 */   public SOAPBody getBody() throws SOAPException { return this.body; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPHeader addHeader() throws SOAPException {
/* 328 */     if (this.header != null) {
/* 329 */       throw new SOAPException("header already exist");
/*     */     }
/*     */     
/* 332 */     this.header = new SOAPHeaderImpl(this.soapNS, getElementName().getPrefix());
/* 333 */     insertChild(this.header, 0);
/*     */     
/* 335 */     return this.header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPBody addBody() throws SOAPException {
/* 354 */     if (this.body != null) {
/* 355 */       throw new SOAPException("body already exist");
/*     */     }
/*     */     
/* 358 */     this.body = new SOAPBodyImpl(this.soapNS);
/* 359 */     return this.body;
/*     */   }
/*     */   
/*     */   public void removeChild(XMLNode paramXMLNode) {
/* 363 */     super.removeChild(paramXMLNode);
/*     */     
/* 365 */     if (paramXMLNode instanceof SOAPBody) {
/* 366 */       this.body = null;
/* 367 */     } else if (paramXMLNode instanceof SOAPHeader) {
/* 368 */       this.header = null;
/*     */     } else {
/* 370 */       throw new IllegalArgumentException("child removed is not a header or body");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected XMLNode createChild(XMLName paramXMLName) {
/* 376 */     if ("Body".equals(paramXMLName.getLocalName())) {
/* 377 */       this.body = new SOAPBodyImpl(this.soapNS);
/* 378 */       return this.body;
/* 379 */     }  if ("Header".equals(paramXMLName.getLocalName())) {
/*     */       
/* 381 */       this.header = new SOAPHeaderImpl(this.soapNS, getElementName().getPrefix());
/* 382 */       return this.header;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 392 */     throw new NestedRuntimeException(new IOException("The InputStream did not contain a valid SOAP message."));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 400 */   public String toString() { return "SOAPEnvelopeImpl[" + this.header + this.body + "]"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPEnvelopeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */