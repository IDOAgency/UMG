package weblogic.webservice.core.soap;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import weblogic.utils.NestedRuntimeException;
import weblogic.utils.StackTraceUtils;
import weblogic.webservice.WebServiceLogger;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.util.RecyclingFactory;
import weblogic.xml.stream.util.TypeFilter;
import weblogic.xml.xmlnode.NodeBuilder;
import weblogic.xml.xmlnode.XMLNode;

public class SOAPEnvelopeImpl extends SOAPElementImpl implements SOAPEnvelope {
  private static final RecyclingFactory pool = new RecyclingFactory();
  
  private static final boolean debug = false;
  
  private static final String SCHEMA_PREFIX = "xsd";
  
  private static final String SCHEMA_NS = "http://www.w3.org/2001/XMLSchema";
  
  private static final String SCHEMA_INSTANCE_PREFIX = "xsi";
  
  private static final String SOAPENC_PREFIX = "soapenc";
  
  private static final String SCHEMA_INSTANCE_NS = "http://www.w3.org/2001/XMLSchema-instance";
  
  private SOAPBodyImpl body;
  
  private SOAPHeaderImpl header;
  
  private String soapNS;
  
  SOAPEnvelopeImpl(String paramString1, String paramString2) throws SOAPException {
    super(new NameImpl("Envelope", ENV_PREFIX, paramString1));
    this.soapNS = paramString1;
    addNamespaceDeclaration(ENV_PREFIX, paramString1);
    addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
    addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
    addNamespaceDeclaration("soapenc", paramString2);
    this.header = new SOAPHeaderImpl(paramString1, ENV_PREFIX);
    this.body = new SOAPBodyImpl(paramString1);
    addChild(this.header);
    addChild(this.body);
  }
  
  SOAPEnvelopeImpl(InputStream paramInputStream) throws IOException, SOAPException {
    TypeFilter typeFilter = new TypeFilter(86);
    XMLInputStream xMLInputStream = pool.remove(paramInputStream, typeFilter);
    processXMLInputStream(xMLInputStream);
    pool.add(xMLInputStream);
  }
  
  SOAPEnvelopeImpl(XMLInputStream paramXMLInputStream) throws IOException { processXMLInputStream(paramXMLInputStream); }
  
  SOAPEnvelopeImpl(Reader paramReader) throws IOException, SOAPException { NodeBuilder nodeBuilder = new NodeBuilder(this, paramReader); }
  
  private void processXMLInputStream(XMLInputStream paramXMLInputStream) throws IOException {
    try {
      paramXMLInputStream.skip(2);
      read(paramXMLInputStream);
    } catch (NestedRuntimeException nestedRuntimeException) {
      Throwable throwable = nestedRuntimeException.getNestedException();
      if (throwable instanceof IOException)
        throw (IOException)throwable; 
      String str = WebServiceLogger.logSoapEnvelopeInputException();
      WebServiceLogger.logStackTrace(str, throwable);
      throw new IOException("Unexpected Error: " + StackTraceUtils.throwable2StackTrace(throwable));
    } 
  }
  
  public Name createName(String paramString1, String paramString2, String paramString3) throws SOAPException { return new NameImpl(paramString1, paramString2, paramString3); }
  
  public Name createName(String paramString1, String paramString2) throws SOAPException { return new NameImpl(paramString1, paramString2, null); }
  
  public Name createName(String paramString) throws SOAPException { return new NameImpl(paramString); }
  
  public SOAPHeader getHeader() throws SOAPException { return this.header; }
  
  public SOAPBody getBody() throws SOAPException { return this.body; }
  
  public SOAPHeader addHeader() throws SOAPException {
    if (this.header != null)
      throw new SOAPException("header already exist"); 
    this.header = new SOAPHeaderImpl(this.soapNS, getElementName().getPrefix());
    insertChild(this.header, 0);
    return this.header;
  }
  
  public SOAPBody addBody() throws SOAPException {
    if (this.body != null)
      throw new SOAPException("body already exist"); 
    this.body = new SOAPBodyImpl(this.soapNS);
    return this.body;
  }
  
  public void removeChild(XMLNode paramXMLNode) {
    super.removeChild(paramXMLNode);
    if (paramXMLNode instanceof SOAPBody) {
      this.body = null;
    } else if (paramXMLNode instanceof SOAPHeader) {
      this.header = null;
    } else {
      throw new IllegalArgumentException("child removed is not a header or body");
    } 
  }
  
  protected XMLNode createChild(XMLName paramXMLName) {
    if ("Body".equals(paramXMLName.getLocalName())) {
      this.body = new SOAPBodyImpl(this.soapNS);
      return this.body;
    } 
    if ("Header".equals(paramXMLName.getLocalName())) {
      this.header = new SOAPHeaderImpl(this.soapNS, getElementName().getPrefix());
      return this.header;
    } 
    throw new NestedRuntimeException(new IOException("The InputStream did not contain a valid SOAP message."));
  }
  
  public String toString() { return "SOAPEnvelopeImpl[" + this.header + this.body + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPEnvelopeImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */