package weblogic.webservice.core.soap;

public class XMLSignatureMalformedException extends XMLSignatureException {
  public XMLSignatureMalformedException(Exception paramException) { super(paramException); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\XMLSignatureMalformedException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */