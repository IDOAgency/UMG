package weblogic.webservice.core.soap;

import java.io.IOException;
import java.io.InputStream;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

public class MessageFactoryImpl extends MessageFactory {
  public SOAPMessage createMessage() throws SOAPException { return new SOAPMessageImpl(); }
  
  public SOAPMessage createMessage(MimeHeaders paramMimeHeaders, InputStream paramInputStream) throws IOException, SOAPException {
    if (paramInputStream == null)
      throw new SOAPException("InputStream cannot be null."); 
    return new SOAPMessageImpl(paramMimeHeaders, paramInputStream);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\MessageFactoryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */