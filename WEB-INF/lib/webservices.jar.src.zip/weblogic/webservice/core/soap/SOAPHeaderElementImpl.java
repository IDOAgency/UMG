/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeaderElement;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPHeaderElementImpl
/*     */   extends SOAPElementImpl
/*     */   implements SOAPHeaderElement
/*     */ {
/*     */   private static final String soapEnvNS = "http://schemas.xmlsoap.org/soap/envelope/";
/*  29 */   private static final NameImpl actorName = new NameImpl("actor", null, null);
/*     */ 
/*     */   
/*  32 */   private static final NameImpl actorNameNS = new NameImpl("actor", null, "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */   
/*  35 */   private static final NameImpl mustUnderstandName = new NameImpl("mustUnderstand", null, null);
/*     */ 
/*     */   
/*  38 */   private static final NameImpl mustUnderstandNameNS = new NameImpl("mustUnderstand", null, "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */ 
/*     */   
/*  42 */   SOAPHeaderElementImpl(XMLName paramXMLName) { super(paramXMLName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setActor(String paramString) {
/*     */     try {
/*  59 */       addAttribute(actorName, paramString);
/*  60 */     } catch (SOAPException sOAPException) {
/*  61 */       String str = WebServiceLogger.logSoapHeaderActorException();
/*  62 */       WebServiceLogger.logStackTrace(str, sOAPException);
/*  63 */       throw new IllegalArgumentException(sOAPException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActor() {
/*  75 */     String str = getAttributeValue(actorNameNS);
/*  76 */     if (str == null) {
/*  77 */       str = getAttributeValue(actorName);
/*     */     }
/*  79 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMustUnderstand(boolean paramBoolean) {
/*     */     try {
/* 100 */       addAttribute(mustUnderstandName, paramBoolean ? "1" : "0");
/*     */     }
/* 102 */     catch (SOAPException sOAPException) {
/* 103 */       String str = WebServiceLogger.logSoapHeaderMustUnderException();
/* 104 */       WebServiceLogger.logStackTrace(str, sOAPException);
/* 105 */       throw new IllegalArgumentException(sOAPException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getMustUnderstand() {
/* 119 */     String str = getAttribute(mustUnderstandNameNS);
/* 120 */     if (str == null)
/* 121 */       str = getAttribute(mustUnderstandName); 
/* 122 */     if ("1".equals(str) || "true".equals(str))
/* 123 */       return true; 
/* 124 */     return false;
/*     */   }
/*     */   
/*     */   public void setParentElement(SOAPElement paramSOAPElement) {
/* 128 */     if (paramSOAPElement instanceof javax.xml.soap.SOAPHeader) {
/* 129 */       super.setParentElement(paramSOAPElement);
/*     */     } else {
/* 131 */       throw new IllegalArgumentException("parent must be SOAPHeader");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPHeaderElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */