package weblogic.webservice.core.soap;

import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeaderElement;
import weblogic.webservice.WebServiceLogger;
import weblogic.xml.stream.XMLName;

public class SOAPHeaderElementImpl extends SOAPElementImpl implements SOAPHeaderElement {
  private static final String soapEnvNS = "http://schemas.xmlsoap.org/soap/envelope/";
  
  private static final NameImpl actorName = new NameImpl("actor", null, null);
  
  private static final NameImpl actorNameNS = new NameImpl("actor", null, "http://schemas.xmlsoap.org/soap/envelope/");
  
  private static final NameImpl mustUnderstandName = new NameImpl("mustUnderstand", null, null);
  
  private static final NameImpl mustUnderstandNameNS = new NameImpl("mustUnderstand", null, "http://schemas.xmlsoap.org/soap/envelope/");
  
  SOAPHeaderElementImpl(XMLName paramXMLName) { super(paramXMLName); }
  
  public void setActor(String paramString) {
    try {
      addAttribute(actorName, paramString);
    } catch (SOAPException sOAPException) {
      String str = WebServiceLogger.logSoapHeaderActorException();
      WebServiceLogger.logStackTrace(str, sOAPException);
      throw new IllegalArgumentException(sOAPException.getMessage());
    } 
  }
  
  public String getActor() {
    String str = getAttributeValue(actorNameNS);
    if (str == null)
      str = getAttributeValue(actorName); 
    return str;
  }
  
  public void setMustUnderstand(boolean paramBoolean) {
    try {
      addAttribute(mustUnderstandName, paramBoolean ? "1" : "0");
    } catch (SOAPException sOAPException) {
      String str = WebServiceLogger.logSoapHeaderMustUnderException();
      WebServiceLogger.logStackTrace(str, sOAPException);
      throw new IllegalArgumentException(sOAPException.getMessage());
    } 
  }
  
  public boolean getMustUnderstand() {
    String str = getAttribute(mustUnderstandNameNS);
    if (str == null)
      str = getAttribute(mustUnderstandName); 
    if ("1".equals(str) || "true".equals(str))
      return true; 
    return false;
  }
  
  public void setParentElement(SOAPElement paramSOAPElement) {
    if (paramSOAPElement instanceof javax.xml.soap.SOAPHeader) {
      super.setParentElement(paramSOAPElement);
    } else {
      throw new IllegalArgumentException("parent must be SOAPHeader");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPHeaderElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */