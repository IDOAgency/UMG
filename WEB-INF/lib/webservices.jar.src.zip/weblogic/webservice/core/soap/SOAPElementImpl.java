package weblogic.webservice.core.soap;

import java.util.Iterator;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFaultElement;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.TypeInfo;
import org.w3c.dom.UserDataHandler;
import weblogic.xml.stream.XMLName;
import weblogic.xml.xmlnode.XMLNode;

public class SOAPElementImpl extends XMLNode implements SOAPElement, SOAPFaultElement, DetailEntry {
  public static String ENV_PREFIX = "env";
  
  public SOAPElementImpl() {}
  
  public SOAPElementImpl(String paramString1, String paramString2, String paramString3) { this(new NameImpl(paramString1, paramString2, paramString3)); }
  
  SOAPElementImpl(XMLName paramXMLName) { super(paramXMLName); }
  
  public SOAPElement addChildElement(Name paramName) throws SOAPException { return (SOAPElement)addChild((XMLName)paramName); }
  
  public SOAPElement addChildElement(String paramString) throws SOAPException { return (SOAPElement)addChild(paramString); }
  
  public SOAPElement addChildElement(String paramString1, String paramString2) throws SOAPException { return (SOAPElement)addChild(paramString1, paramString2); }
  
  public SOAPElement addChildElement(String paramString1, String paramString2, String paramString3) throws SOAPException { return (SOAPElement)addChild(paramString1, paramString2, paramString3); }
  
  public SOAPElement addChildElement(SOAPElement paramSOAPElement) throws SOAPException { return (SOAPElement)addChild((XMLNode)paramSOAPElement); }
  
  public SOAPElement addTextNode(String paramString) throws SOAPException {
    addText(paramString);
    return this;
  }
  
  public SOAPElement addAttribute(Name paramName, String paramString) throws SOAPException {
    addAttribute((XMLName)paramName, paramString);
    return this;
  }
  
  public SOAPElement addNamespaceDeclaration(String paramString1, String paramString2) throws SOAPException {
    addNamespace(paramString1, paramString2);
    return this;
  }
  
  public String getAttributeValue(Name paramName) { return getAttribute((XMLName)paramName); }
  
  public Iterator getAllAttributes() { return getNodeAttributes(); }
  
  public Iterator getNamespacePrefixes() { return super.getNamespacePrefixes(); }
  
  public Name getElementName() { return (Name)getName(); }
  
  public boolean removeAttribute(Name paramName) { return removeAttribute((XMLName)paramName); }
  
  public boolean removeNamespaceDeclaration(String paramString) { return removeNamespace(paramString); }
  
  public Iterator getChildElements() { return getChildren(); }
  
  public Iterator getChildElements(Name paramName) { return getChildren((XMLName)paramName); }
  
  public void setEncodingStyle(String paramString) throws SOAPException {
    if ("http://schemas.xmlsoap.org/soap/encoding/".equals(paramString) || "http://www.w3.org/2003/05/soap-encoding".equals(paramString)) {
      XMLName xMLName = createXMLName("encodingStyle", ENV_PREFIX, getNamespaceURI(ENV_PREFIX));
      addAttribute(xMLName, paramString);
    } else {
      throw new IllegalArgumentException("unknown encoding style: " + paramString);
    } 
  }
  
  public String getEncodingStyle() {
    XMLName xMLName = createXMLName("encodingStyle", ENV_PREFIX, getNamespaceURI(ENV_PREFIX));
    return getAttribute(xMLName);
  }
  
  public SOAPElement getParentElement() { return (SOAPElement)getParent(); }
  
  public void setParentElement(SOAPElement paramSOAPElement) {
    if (paramSOAPElement == null)
      throw new IllegalArgumentException("parent can not be null"); 
    setParent((XMLNode)paramSOAPElement);
  }
  
  public String getValue() {
    String str = getText();
    if (str == null)
      str = ""; 
    return str;
  }
  
  protected XMLName createXMLName(String paramString1, String paramString2, String paramString3) { return new NameImpl(paramString1, paramString2, paramString3); }
  
  protected XMLNode createChild(XMLName paramXMLName) {
    if (!(paramXMLName instanceof Name))
      paramXMLName = createXMLName(paramXMLName.getLocalName(), paramXMLName.getPrefix(), paramXMLName.getNamespaceUri()); 
    return new SOAPElementImpl(paramXMLName);
  }
  
  protected XMLNode createTextChild(String paramString) { return new SOAPTextElement(paramString); }
  
  public void removeContents() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Iterator getVisibleNamespacePrefixes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getAttribute(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getNodeName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setNodeName(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getNodeValue() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setNodeValue(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setNodeType(short paramShort) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public short getNodeType() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getParentNode() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NodeList getChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getFirstChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getLastChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getPreviousSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getNextSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NamedNodeMap getAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Attr getAttributeNode(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setOwnerDocument(Document paramDocument) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Document getOwnerDocument() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node removeChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node appendChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean hasChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void removeChildren() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node cloneNode(boolean paramBoolean) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void normalize() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean isSupported(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getNamespaceURI() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getPrefix() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setPrefix(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getLocalName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean hasAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public int setNamespaceURI(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Attr setNamespaceURI(Attr paramAttr) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Attr getAttributeNodeNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getAttributeNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NodeList getElementsByTagName(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NodeList getElementsByTagNameNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getTagName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean hasAttribute(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean hasAttributeNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void removeAttribute(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Attr removeAttributeNode(Attr paramAttr) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void removeAttributeNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setAttribute(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Attr setAttributeNode(Attr paramAttr) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Attr setAttributeNodeNS(Attr paramAttr) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setAttributeNS(String paramString1, String paramString2, String paramString3) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setValue(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Object getUserData(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Object setUserData(String paramString, Object paramObject, UserDataHandler paramUserDataHandler) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Object getFeature(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isEqualNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String lookupNamespaceURI(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isDefaultNamespace(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String lookupPrefix(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isSameNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setTextContent(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getTextContent() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public short compareDocumentPosition(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getBaseURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setIdAttributeNode(Attr paramAttr, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setIdAttributeNS(String paramString1, String paramString2, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setIdAttribute(String paramString, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public TypeInfo getSchemaTypeInfo() throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */