/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.xml.soap.DetailEntry;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPFaultElement;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.TypeInfo;
/*     */ import org.w3c.dom.UserDataHandler;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPElementImpl
/*     */   extends XMLNode
/*     */   implements SOAPElement, SOAPFaultElement, DetailEntry
/*     */ {
/*  40 */   public static String ENV_PREFIX = "env";
/*     */ 
/*     */   
/*     */   public SOAPElementImpl() {}
/*     */ 
/*     */   
/*  46 */   public SOAPElementImpl(String paramString1, String paramString2, String paramString3) { this(new NameImpl(paramString1, paramString2, paramString3)); }
/*     */ 
/*     */ 
/*     */   
/*  50 */   SOAPElementImpl(XMLName paramXMLName) { super(paramXMLName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public SOAPElement addChildElement(Name paramName) throws SOAPException { return (SOAPElement)addChild((XMLName)paramName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public SOAPElement addChildElement(String paramString) throws SOAPException { return (SOAPElement)addChild(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public SOAPElement addChildElement(String paramString1, String paramString2) throws SOAPException { return (SOAPElement)addChild(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public SOAPElement addChildElement(String paramString1, String paramString2, String paramString3) throws SOAPException { return (SOAPElement)addChild(paramString1, paramString2, paramString3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public SOAPElement addChildElement(SOAPElement paramSOAPElement) throws SOAPException { return (SOAPElement)addChild((XMLNode)paramSOAPElement); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPElement addTextNode(String paramString) throws SOAPException {
/* 147 */     addText(paramString);
/* 148 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPElement addAttribute(Name paramName, String paramString) throws SOAPException {
/* 167 */     addAttribute((XMLName)paramName, paramString);
/* 168 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPElement addNamespaceDeclaration(String paramString1, String paramString2) throws SOAPException {
/* 186 */     addNamespace(paramString1, paramString2);
/* 187 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public String getAttributeValue(Name paramName) { return getAttribute((XMLName)paramName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public Iterator getAllAttributes() { return getNodeAttributes(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public Iterator getNamespacePrefixes() { return super.getNamespacePrefixes(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   public Name getElementName() { return (Name)getName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 246 */   public boolean removeAttribute(Name paramName) { return removeAttribute((XMLName)paramName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 258 */   public boolean removeNamespaceDeclaration(String paramString) { return removeNamespace(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 270 */   public Iterator getChildElements() { return getChildren(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   public Iterator getChildElements(Name paramName) { return getChildren((XMLName)paramName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncodingStyle(String paramString) throws SOAPException {
/* 301 */     if ("http://schemas.xmlsoap.org/soap/encoding/".equals(paramString) || "http://www.w3.org/2003/05/soap-encoding".equals(paramString)) {
/*     */ 
/*     */ 
/*     */       
/* 305 */       XMLName xMLName = createXMLName("encodingStyle", ENV_PREFIX, getNamespaceURI(ENV_PREFIX));
/*     */ 
/*     */       
/* 308 */       addAttribute(xMLName, paramString);
/*     */     } else {
/*     */       
/* 311 */       throw new IllegalArgumentException("unknown encoding style: " + paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncodingStyle() {
/* 326 */     XMLName xMLName = createXMLName("encodingStyle", ENV_PREFIX, getNamespaceURI(ENV_PREFIX));
/*     */ 
/*     */     
/* 329 */     return getAttribute(xMLName);
/*     */   }
/*     */ 
/*     */   
/* 333 */   public SOAPElement getParentElement() { return (SOAPElement)getParent(); }
/*     */ 
/*     */   
/*     */   public void setParentElement(SOAPElement paramSOAPElement) {
/* 337 */     if (paramSOAPElement == null) {
/* 338 */       throw new IllegalArgumentException("parent can not be null");
/*     */     }
/*     */     
/* 341 */     setParent((XMLNode)paramSOAPElement);
/*     */   }
/*     */   
/*     */   public String getValue() {
/* 345 */     String str = getText();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 350 */     if (str == null) {
/* 351 */       str = "";
/*     */     }
/*     */     
/* 354 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 359 */   protected XMLName createXMLName(String paramString1, String paramString2, String paramString3) { return new NameImpl(paramString1, paramString2, paramString3); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected XMLNode createChild(XMLName paramXMLName) {
/* 364 */     if (!(paramXMLName instanceof Name))
/*     */     {
/* 366 */       paramXMLName = createXMLName(paramXMLName.getLocalName(), paramXMLName.getPrefix(), paramXMLName.getNamespaceUri());
/*     */     }
/*     */ 
/*     */     
/* 370 */     return new SOAPElementImpl(paramXMLName);
/*     */   }
/*     */ 
/*     */   
/* 374 */   protected XMLNode createTextChild(String paramString) { return new SOAPTextElement(paramString); }
/*     */ 
/*     */   
/* 377 */   public void removeContents() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 380 */   public Iterator getVisibleNamespacePrefixes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 383 */   public String getAttribute(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 387 */   public String getNodeName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 390 */   public void setNodeName(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 395 */   public String getNodeValue() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 400 */   public void setNodeValue(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 403 */   public void setNodeType(short paramShort) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 407 */   public short getNodeType() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 411 */   public Node getParentNode() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 415 */   public NodeList getChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 419 */   public Node getFirstChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 423 */   public Node getLastChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 427 */   public Node getPreviousSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 431 */   public Node getNextSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 435 */   public NamedNodeMap getAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 438 */   public Attr getAttributeNode(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 442 */   public void setOwnerDocument(Document paramDocument) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 446 */   public Document getOwnerDocument() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 451 */   public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 456 */   public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 461 */   public Node removeChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 466 */   public Node appendChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 470 */   public boolean hasChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 473 */   public void removeChildren() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 477 */   public Node cloneNode(boolean paramBoolean) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 481 */   public void normalize() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 485 */   public boolean isSupported(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 489 */   public String getNamespaceURI() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 493 */   public String getPrefix() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 498 */   public void setPrefix(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 502 */   public String getLocalName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 506 */   public boolean hasAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 510 */   public int setNamespaceURI(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 514 */   public Attr setNamespaceURI(Attr paramAttr) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 518 */   public Attr getAttributeNodeNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 521 */   public String getAttributeNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 524 */   public NodeList getElementsByTagName(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 527 */   public NodeList getElementsByTagNameNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 530 */   public String getTagName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 533 */   public boolean hasAttribute(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 536 */   public boolean hasAttributeNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 539 */   public void removeAttribute(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 542 */   public Attr removeAttributeNode(Attr paramAttr) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 545 */   public void removeAttributeNS(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 548 */   public void setAttribute(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 551 */   public Attr setAttributeNode(Attr paramAttr) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 554 */   public Attr setAttributeNodeNS(Attr paramAttr) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 560 */   public void setAttributeNS(String paramString1, String paramString2, String paramString3) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 563 */   public void setValue(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 567 */   public Object getUserData(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 572 */   public Object setUserData(String paramString, Object paramObject, UserDataHandler paramUserDataHandler) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 577 */   public Object getFeature(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 581 */   public boolean isEqualNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 585 */   public String lookupNamespaceURI(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 589 */   public boolean isDefaultNamespace(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 593 */   public String lookupPrefix(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 597 */   public boolean isSameNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 601 */   public void setTextContent(String paramString) throws SOAPException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 605 */   public String getTextContent() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 609 */   public short compareDocumentPosition(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 613 */   public String getBaseURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 617 */   public void setIdAttributeNode(Attr paramAttr, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 621 */   public void setIdAttributeNS(String paramString1, String paramString2, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 625 */   public void setIdAttribute(String paramString, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 629 */   public TypeInfo getSchemaTypeInfo() throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */