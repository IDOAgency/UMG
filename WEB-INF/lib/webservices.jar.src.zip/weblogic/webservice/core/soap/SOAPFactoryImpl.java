package weblogic.webservice.core.soap;

import javax.xml.soap.Detail;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;

public class SOAPFactoryImpl extends SOAPFactory {
  public SOAPElement createElement(Name paramName) throws SOAPException { return createElement(paramName.getLocalName(), paramName.getPrefix(), paramName.getURI()); }
  
  public SOAPElement createElement(String paramString) throws SOAPException { return createElement(paramString, null, null); }
  
  public SOAPElement createElement(String paramString1, String paramString2, String paramString3) throws SOAPException { return new SOAPElementImpl(paramString1, paramString2, paramString3); }
  
  public Detail createDetail() throws SOAPException { return new DetailImpl(); }
  
  public Name createName(String paramString1, String paramString2, String paramString3) throws SOAPException { return new NameImpl(paramString1, paramString2, paramString3); }
  
  public Name createName(String paramString) throws SOAPException { return new NameImpl(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPFactoryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */