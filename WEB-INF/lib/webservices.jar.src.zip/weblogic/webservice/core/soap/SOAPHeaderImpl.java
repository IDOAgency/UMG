package weblogic.webservice.core.soap;

import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import weblogic.xml.stream.XMLName;
import weblogic.xml.xmlnode.XMLNode;

public class SOAPHeaderImpl extends SOAPElementImpl implements SOAPHeader {
  SOAPHeaderImpl(String paramString1, String paramString2) { setName(new NameImpl("Header", paramString2, paramString1)); }
  
  public SOAPHeaderElement addHeaderElement(Name paramName) throws SOAPException { return (SOAPHeaderElement)addChild(new SOAPHeaderElementImpl((NameImpl)paramName)); }
  
  public Iterator examineHeaderElements(String paramString) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = getChildElements(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if (xMLNode.isTextNode())
        continue; 
      SOAPHeaderElement sOAPHeaderElement = (SOAPHeaderElement)xMLNode;
      if (paramString.equals(sOAPHeaderElement.getActor()))
        arrayList.add(sOAPHeaderElement); 
    } 
    return arrayList.iterator();
  }
  
  public Iterator extractHeaderElements(String paramString) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = getChildElements(); iterator.hasNext(); ) {
      SOAPHeaderElement sOAPHeaderElement = (SOAPHeaderElement)iterator.next();
      if (paramString.equals(sOAPHeaderElement.getActor()))
        arrayList.add(sOAPHeaderElement); 
    } 
    for (byte b = 0; b < arrayList.size(); b++) {
      SOAPHeaderElement sOAPHeaderElement = (SOAPHeaderElement)arrayList.get(b);
      sOAPHeaderElement.detachNode();
    } 
    return arrayList.iterator();
  }
  
  protected XMLNode createChild(XMLName paramXMLName) { return new SOAPHeaderElementImpl(paramXMLName); }
  
  public Iterator examineAllHeaderElements() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Iterator extractAllHeaderElements() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Iterator examineMustUnderstandHeaderElements(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPHeaderImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */