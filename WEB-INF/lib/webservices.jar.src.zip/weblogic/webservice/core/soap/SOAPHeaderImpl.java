/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeader;
/*     */ import javax.xml.soap.SOAPHeaderElement;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPHeaderImpl
/*     */   extends SOAPElementImpl
/*     */   implements SOAPHeader
/*     */ {
/*  60 */   SOAPHeaderImpl(String paramString1, String paramString2) { setName(new NameImpl("Header", paramString2, paramString1)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public SOAPHeaderElement addHeaderElement(Name paramName) throws SOAPException { return (SOAPHeaderElement)addChild(new SOAPHeaderElementImpl((NameImpl)paramName)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator examineHeaderElements(String paramString) {
/* 104 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 106 */     for (Iterator iterator = getChildElements(); iterator.hasNext(); ) {
/*     */       
/* 108 */       XMLNode xMLNode = (XMLNode)iterator.next();
/* 109 */       if (xMLNode.isTextNode()) {
/*     */         continue;
/*     */       }
/*     */       
/* 113 */       SOAPHeaderElement sOAPHeaderElement = (SOAPHeaderElement)xMLNode;
/*     */       
/* 115 */       if (paramString.equals(sOAPHeaderElement.getActor())) {
/* 116 */         arrayList.add(sOAPHeaderElement);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 121 */     return arrayList.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator extractHeaderElements(String paramString) {
/* 143 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 145 */     for (Iterator iterator = getChildElements(); iterator.hasNext(); ) {
/* 146 */       SOAPHeaderElement sOAPHeaderElement = (SOAPHeaderElement)iterator.next();
/*     */       
/* 148 */       if (paramString.equals(sOAPHeaderElement.getActor())) {
/* 149 */         arrayList.add(sOAPHeaderElement);
/*     */       }
/*     */     } 
/*     */     
/* 153 */     for (byte b = 0; b < arrayList.size(); b++) {
/* 154 */       SOAPHeaderElement sOAPHeaderElement = (SOAPHeaderElement)arrayList.get(b);
/* 155 */       sOAPHeaderElement.detachNode();
/*     */     } 
/*     */     
/* 158 */     return arrayList.iterator();
/*     */   }
/*     */ 
/*     */   
/* 162 */   protected XMLNode createChild(XMLName paramXMLName) { return new SOAPHeaderElementImpl(paramXMLName); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   public Iterator examineAllHeaderElements() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 170 */   public Iterator extractAllHeaderElements() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 173 */   public Iterator examineMustUnderstandHeaderElements(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPHeaderImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */