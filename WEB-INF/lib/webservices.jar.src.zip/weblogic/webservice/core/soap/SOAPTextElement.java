/*     */ package weblogic.webservice.core.soap;
/*     */ 
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.Text;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.DOMConfiguration;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ import org.w3c.dom.TypeInfo;
/*     */ import org.w3c.dom.UserDataHandler;
/*     */ import weblogic.xml.xmlnode.XMLTextNode;
/*     */ 
/*     */ 
/*     */ public class SOAPTextElement
/*     */   extends XMLTextNode
/*     */   implements Text
/*     */ {
/*     */   private SOAPElement parent;
/*     */   
/*     */   public SOAPTextElement() {}
/*     */   
/*  26 */   public SOAPTextElement(String paramString) { super(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  31 */   public String getValue() { return getText(); }
/*     */ 
/*     */ 
/*     */   
/*  35 */   public void setParentElement(SOAPElement paramSOAPElement) { this.parent = paramSOAPElement; }
/*     */ 
/*     */ 
/*     */   
/*  39 */   public SOAPElement getParentElement() { return this.parent; }
/*     */ 
/*     */ 
/*     */   
/*  43 */   public boolean isComment() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  47 */   public String getNodeName() { throw new UnsupportedOperationException("This class does not supportSAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  51 */   public void setNodeName(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public String getNodeValue() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void setNodeValue(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/*  64 */   public void setNodeType(short paramShort) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  68 */   public short getNodeType() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  72 */   public Node getParentNode() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  76 */   public NodeList getChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  80 */   public Node getFirstChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  84 */   public Node getLastChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  88 */   public Node getPreviousSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  92 */   public Node getNextSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/*  96 */   public NamedNodeMap getAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/*  99 */   public void setOwnerDocument(Document paramDocument) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 103 */   public Document getOwnerDocument() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public Node removeChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public Node appendChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 127 */   public boolean hasChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 130 */   public void removeChildren() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 134 */   public Node cloneNode(boolean paramBoolean) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void normalize() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 142 */   public boolean isSupported(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 146 */   public String getNamespaceURI() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 150 */   public String getPrefix() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public void setPrefix(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 159 */   public String getLocalName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */   
/* 163 */   public boolean hasAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 166 */   public void setValue(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public String getData() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public void setData(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 179 */   public int getLength() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public String substringData(int paramInt1, int paramInt2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public void appendData(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public void insertData(int paramInt, String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   public void deleteData(int paramInt1, int paramInt2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public void replaceData(int paramInt1, int paramInt2, String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public Text splitText(int paramInt) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
/*     */ 
/*     */   
/* 212 */   public void recycleNode() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 216 */   public Object getUserData(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   public Object setUserData(String paramString, Object paramObject, UserDataHandler paramUserDataHandler) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public Object getFeature(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public String lookupPrefix(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   public short compareDocumentPosition(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public void setIdAttributeNode(Attr paramAttr, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 246 */   public void setIdAttributeNS(String paramString1, String paramString2, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   public void setIdAttribute(String paramString, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   public TypeInfo getSchemaTypeInfo() throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public boolean isEqualNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   public boolean isSameNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 271 */   public String lookupNamespaceURI(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   public boolean isDefaultNamespace(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public void setTextContent(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   public String getTextContent() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public String getBaseURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 296 */   public Node renameNode(Node paramNode, String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 301 */   public void normalizeDocument() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 306 */   public DOMConfiguration getDomConfig() throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 311 */   public void setDocumentURI(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 316 */   public String getDocumentURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 321 */   public void setXmlVersion(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 326 */   public String getXmlVersion() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   public void setXmlStandalone(boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 336 */   public boolean getXmlStandalone() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 341 */   public String getXmlEncoding() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 346 */   public String getInputEncoding() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 351 */   public Text replaceWholeText(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 355 */   public String getWholeText() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ 
/*     */ 
/*     */   
/* 359 */   public boolean isElementContentWhitespace() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPTextElement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */