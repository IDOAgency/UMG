package weblogic.webservice.core.soap;

import javax.xml.soap.SOAPElement;
import javax.xml.soap.Text;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.w3c.dom.TypeInfo;
import org.w3c.dom.UserDataHandler;
import weblogic.xml.xmlnode.XMLTextNode;

public class SOAPTextElement extends XMLTextNode implements Text {
  private SOAPElement parent;
  
  public SOAPTextElement() {}
  
  public SOAPTextElement(String paramString) { super(paramString); }
  
  public String getValue() { return getText(); }
  
  public void setParentElement(SOAPElement paramSOAPElement) { this.parent = paramSOAPElement; }
  
  public SOAPElement getParentElement() { return this.parent; }
  
  public boolean isComment() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getNodeName() { throw new UnsupportedOperationException("This class does not supportSAAJ 1.1"); }
  
  public void setNodeName(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getNodeValue() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setNodeValue(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setNodeType(short paramShort) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public short getNodeType() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getParentNode() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NodeList getChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getFirstChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getLastChild() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getPreviousSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node getNextSibling() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public NamedNodeMap getAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setOwnerDocument(Document paramDocument) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Document getOwnerDocument() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node insertBefore(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node replaceChild(Node paramNode1, Node paramNode2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node removeChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node appendChild(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean hasChildNodes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void removeChildren() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Node cloneNode(boolean paramBoolean) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void normalize() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean isSupported(String paramString1, String paramString2) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getNamespaceURI() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getPrefix() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setPrefix(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getLocalName() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public boolean hasAttributes() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setValue(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String getData() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void setData(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public int getLength() { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public String substringData(int paramInt1, int paramInt2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void appendData(String paramString) { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void insertData(int paramInt, String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void deleteData(int paramInt1, int paramInt2) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void replaceData(int paramInt1, int paramInt2, String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public Text splitText(int paramInt) throws DOMException { throw new UnsupportedOperationException("This class does not support SAAJ 1.1"); }
  
  public void recycleNode() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Object getUserData(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Object setUserData(String paramString, Object paramObject, UserDataHandler paramUserDataHandler) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Object getFeature(String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String lookupPrefix(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public short compareDocumentPosition(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setIdAttributeNode(Attr paramAttr, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setIdAttributeNS(String paramString1, String paramString2, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setIdAttribute(String paramString, boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public TypeInfo getSchemaTypeInfo() throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isEqualNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isSameNode(Node paramNode) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String lookupNamespaceURI(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isDefaultNamespace(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setTextContent(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getTextContent() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getBaseURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Node renameNode(Node paramNode, String paramString1, String paramString2) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void normalizeDocument() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public DOMConfiguration getDomConfig() throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setDocumentURI(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getDocumentURI() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setXmlVersion(String paramString) { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getXmlVersion() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public void setXmlStandalone(boolean paramBoolean) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean getXmlStandalone() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getXmlEncoding() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getInputEncoding() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public Text replaceWholeText(String paramString) throws DOMException { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public String getWholeText() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
  
  public boolean isElementContentWhitespace() { throw new UnsupportedOperationException("This class does not support JDK1.5"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPTextElement.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */