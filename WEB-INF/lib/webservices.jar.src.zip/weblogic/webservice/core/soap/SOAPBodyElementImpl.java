/*    */ package weblogic.webservice.core.soap;
/*    */ 
/*    */ import javax.xml.soap.SOAPBodyElement;
/*    */ import weblogic.xml.stream.XMLName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPBodyElementImpl
/*    */   extends SOAPElementImpl
/*    */   implements SOAPBodyElement
/*    */ {
/* 29 */   SOAPBodyElementImpl(XMLName paramXMLName) { super(paramXMLName); }
/*    */   
/*    */   SOAPBodyElementImpl() {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\SOAPBodyElementImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */