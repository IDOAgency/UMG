package weblogic.webservice.core.soap;

public class XMLSignatureException extends Exception {
  public XMLSignatureException() {}
  
  public XMLSignatureException(String paramString) { super(paramString); }
  
  public XMLSignatureException(Exception paramException) { super(paramException); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\XMLSignatureException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */