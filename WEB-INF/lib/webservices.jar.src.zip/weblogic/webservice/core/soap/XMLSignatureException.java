/*    */ package weblogic.webservice.core.soap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLSignatureException
/*    */   extends Exception
/*    */ {
/*    */   public XMLSignatureException() {}
/*    */   
/* 21 */   public XMLSignatureException(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   public XMLSignatureException(Exception paramException) { super(paramException); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\soap\XMLSignatureException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */