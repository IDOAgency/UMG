/*     */ package weblogic.webservice.core.encoding;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.TypeMapping;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import weblogic.xml.schema.binding.internal.TypeMappingBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeMappingRegistryImpl
/*     */   implements TypeMappingRegistry, Serializable
/*     */ {
/*  27 */   private Map typeMappings = new HashMap();
/*     */   
/*  29 */   private TypeMapping defaultTypeMapping = null;
/*     */ 
/*     */   
/*     */   public void registerDefault(TypeMapping paramTypeMapping) {
/*  33 */     this.defaultTypeMapping = paramTypeMapping;
/*     */     
/*  35 */     register("http://schemas.xmlsoap.org/soap/encoding/", paramTypeMapping);
/*  36 */     register("http://www.w3.org/2003/05/soap-encoding", paramTypeMapping);
/*     */   }
/*     */   
/*     */   public TypeMapping register(String paramString, TypeMapping paramTypeMapping) {
/*  40 */     if (paramTypeMapping == null) {
/*  41 */       throw new IllegalArgumentException("mapping cannot be null");
/*     */     }
/*  43 */     this.typeMappings.put(paramString, paramTypeMapping);
/*  44 */     return paramTypeMapping;
/*     */   }
/*     */   public TypeMapping getDefaultTypeMapping() {
/*  47 */     if (this.defaultTypeMapping != null) {
/*  48 */       return this.defaultTypeMapping;
/*     */     }
/*  50 */     return getTypeMapping("http://schemas.xmlsoap.org/soap/encoding/");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeTypeMapping(TypeMapping paramTypeMapping) {
/*  55 */     if (paramTypeMapping == null) return false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     ArrayList arrayList = new ArrayList();
/*     */     
/*  62 */     for (Map.Entry entry : this.typeMappings.entrySet()) {
/*     */       
/*  64 */       if (paramTypeMapping.equals(entry.getValue())) {
/*  65 */         arrayList.add(entry.getKey());
/*     */       }
/*     */     } 
/*     */     
/*  69 */     for (Iterator iterator = arrayList.iterator(); iterator.hasNext();) {
/*  70 */       this.typeMappings.remove(iterator.next());
/*     */     }
/*  72 */     return !arrayList.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*  76 */   public TypeMapping unregisterTypeMapping(String paramString) { return (TypeMapping)this.typeMappings.remove(paramString); }
/*     */ 
/*     */   
/*     */   public String[] getRegisteredNamespaces() {
/*  80 */     ArrayList arrayList = new ArrayList();
/*     */     
/*  82 */     for (String str : this.typeMappings.keySet())
/*     */     {
/*  84 */       arrayList.add(str);
/*     */     }
/*     */     
/*  87 */     return (String[])arrayList.toArray(new String[arrayList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void register(TypeMapping paramTypeMapping, String[] paramArrayOfString) throws JAXRPCException {
/*  93 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*  94 */       this.typeMappings.put(paramArrayOfString[b], paramTypeMapping);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  99 */   public void clear() { this.typeMappings.clear(); }
/*     */ 
/*     */ 
/*     */   
/* 103 */   public TypeMapping createTypeMapping() { return new TypeMappingBase(); }
/*     */ 
/*     */ 
/*     */   
/* 107 */   public TypeMapping removeTypeMapping(String paramString) { return (TypeMapping)this.typeMappings.remove(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 111 */   public Iterator getAllTypeMappings() { return this.typeMappings.values().iterator(); }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public String[] getSupportedNamespaces() { return (String[])this.typeMappings.keySet().toArray(new String[0]); }
/*     */ 
/*     */ 
/*     */   
/* 119 */   public TypeMapping getTypeMapping(String paramString) { return (TypeMapping)this.typeMappings.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 123 */   public String[] getRegisteredEncodingStyleURIs() { return getSupportedNamespaces(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\encoding\TypeMappingRegistryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */