package weblogic.webservice.core.encoding;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import weblogic.xml.schema.binding.internal.TypeMappingBase;

public class TypeMappingRegistryImpl implements TypeMappingRegistry, Serializable {
  private Map typeMappings = new HashMap();
  
  private TypeMapping defaultTypeMapping = null;
  
  public void registerDefault(TypeMapping paramTypeMapping) {
    this.defaultTypeMapping = paramTypeMapping;
    register("http://schemas.xmlsoap.org/soap/encoding/", paramTypeMapping);
    register("http://www.w3.org/2003/05/soap-encoding", paramTypeMapping);
  }
  
  public TypeMapping register(String paramString, TypeMapping paramTypeMapping) {
    if (paramTypeMapping == null)
      throw new IllegalArgumentException("mapping cannot be null"); 
    this.typeMappings.put(paramString, paramTypeMapping);
    return paramTypeMapping;
  }
  
  public TypeMapping getDefaultTypeMapping() {
    if (this.defaultTypeMapping != null)
      return this.defaultTypeMapping; 
    return getTypeMapping("http://schemas.xmlsoap.org/soap/encoding/");
  }
  
  public boolean removeTypeMapping(TypeMapping paramTypeMapping) {
    if (paramTypeMapping == null)
      return false; 
    ArrayList arrayList = new ArrayList();
    for (Map.Entry entry : this.typeMappings.entrySet()) {
      if (paramTypeMapping.equals(entry.getValue()))
        arrayList.add(entry.getKey()); 
    } 
    for (Iterator iterator = arrayList.iterator(); iterator.hasNext();)
      this.typeMappings.remove(iterator.next()); 
    return !arrayList.isEmpty();
  }
  
  public TypeMapping unregisterTypeMapping(String paramString) { return (TypeMapping)this.typeMappings.remove(paramString); }
  
  public String[] getRegisteredNamespaces() {
    ArrayList arrayList = new ArrayList();
    for (String str : this.typeMappings.keySet())
      arrayList.add(str); 
    return (String[])arrayList.toArray(new String[arrayList.size()]);
  }
  
  public void register(TypeMapping paramTypeMapping, String[] paramArrayOfString) throws JAXRPCException {
    for (byte b = 0; b < paramArrayOfString.length; b++)
      this.typeMappings.put(paramArrayOfString[b], paramTypeMapping); 
  }
  
  public void clear() { this.typeMappings.clear(); }
  
  public TypeMapping createTypeMapping() { return new TypeMappingBase(); }
  
  public TypeMapping removeTypeMapping(String paramString) { return (TypeMapping)this.typeMappings.remove(paramString); }
  
  public Iterator getAllTypeMappings() { return this.typeMappings.values().iterator(); }
  
  public String[] getSupportedNamespaces() { return (String[])this.typeMappings.keySet().toArray(new String[0]); }
  
  public TypeMapping getTypeMapping(String paramString) { return (TypeMapping)this.typeMappings.get(paramString); }
  
  public String[] getRegisteredEncodingStyleURIs() { return getSupportedNamespaces(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\encoding\TypeMappingRegistryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */