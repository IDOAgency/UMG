package weblogic.webservice.core.encoding;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.TypeMapping;
import weblogic.webservice.client.SSLAdapter;
import weblogic.webservice.client.SSLAdapterFactory;
import weblogic.xml.schema.binding.TypeMappingFactory;
import weblogic.xml.schema.binding.internal.TypeMappingBase;
import weblogic.xml.schema.binding.util.StdNamespace;

public final class DefaultRegistry extends TypeMappingRegistryImpl {
  private static final String SOAP12_ENC = "http://www.w3.org/2003/05/soap-encoding";
  
  public DefaultRegistry(String paramString) throws IOException, JAXRPCException {
    this();
    String str = paramString.replace('.', '/') + ".xml";
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = getClass().getClassLoader(); 
    URL uRL = classLoader.getResource(str);
    if (uRL == null)
      uRL = getClass().getResource(str); 
    InputStream inputStream = null;
    if (uRL != null) {
      if ("https".equalsIgnoreCase(uRL.getProtocol())) {
        SSLAdapter sSLAdapter = SSLAdapterFactory.getDefaultFactory().getSSLAdapter();
        inputStream = sSLAdapter.openConnection(uRL).getInputStream();
      } else {
        inputStream = uRL.openStream();
      } 
    } else {
      try {
        inputStream = new FileInputStream(paramString);
      } catch (IOException iOException) {
        throw new IOException("unable to find the type mapping resource file for:" + paramString);
      } 
    } 
    TypeMappingBase typeMappingBase = (TypeMappingBase)getTypeMapping(StdNamespace.instance().soapEncoding());
    typeMappingBase.readXML(inputStream);
    inputStream.close();
  }
  
  public DefaultRegistry() throws JAXRPCException {
    TypeMappingFactory typeMappingFactory = TypeMappingFactory.newInstance();
    TypeMapping typeMapping = (TypeMapping)typeMappingFactory.createDefaultMapping();
    register(typeMapping, new String[] { StdNamespace.instance().soapEncoding() });
    register(typeMapping, new String[] { "http://www.w3.org/2003/05/soap-encoding" });
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(getClass().getName());
    stringBuffer.append("[ registerd encodingStyle = ");
    String[] arrayOfString = getRegisteredNamespaces();
    for (byte b = 0; b < arrayOfString.length; b++) {
      stringBuffer.append(arrayOfString[b]);
      stringBuffer.append(",");
    } 
    stringBuffer.append("]");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\encoding\DefaultRegistry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */