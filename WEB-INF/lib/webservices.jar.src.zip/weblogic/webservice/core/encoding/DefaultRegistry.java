/*     */ package weblogic.webservice.core.encoding;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.TypeMapping;
/*     */ import weblogic.webservice.client.SSLAdapter;
/*     */ import weblogic.webservice.client.SSLAdapterFactory;
/*     */ import weblogic.xml.schema.binding.TypeMappingFactory;
/*     */ import weblogic.xml.schema.binding.internal.TypeMappingBase;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DefaultRegistry
/*     */   extends TypeMappingRegistryImpl
/*     */ {
/*     */   private static final String SOAP12_ENC = "http://www.w3.org/2003/05/soap-encoding";
/*     */   
/*     */   public DefaultRegistry(String paramString) throws IOException, JAXRPCException {
/*  29 */     this();
/*     */ 
/*     */ 
/*     */     
/*  33 */     String str = paramString.replace('.', '/') + ".xml";
/*     */     
/*  35 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     
/*  37 */     if (classLoader == null) {
/*  38 */       classLoader = getClass().getClassLoader();
/*     */     }
/*     */     
/*  41 */     URL uRL = classLoader.getResource(str);
/*     */     
/*  43 */     if (uRL == null) {
/*  44 */       uRL = getClass().getResource(str);
/*     */     }
/*     */     
/*  47 */     InputStream inputStream = null;
/*     */     
/*  49 */     if (uRL != null) {
/*     */       
/*  51 */       if ("https".equalsIgnoreCase(uRL.getProtocol())) {
/*     */         
/*  53 */         SSLAdapter sSLAdapter = SSLAdapterFactory.getDefaultFactory().getSSLAdapter();
/*     */ 
/*     */         
/*  56 */         inputStream = sSLAdapter.openConnection(uRL).getInputStream();
/*     */       } else {
/*     */         
/*  59 */         inputStream = uRL.openStream();
/*     */       } 
/*     */     } else {
/*     */       try {
/*  63 */         inputStream = new FileInputStream(paramString);
/*  64 */       } catch (IOException iOException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  70 */         throw new IOException("unable to find the type mapping resource file for:" + paramString);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  75 */     TypeMappingBase typeMappingBase = (TypeMappingBase)getTypeMapping(StdNamespace.instance().soapEncoding());
/*     */ 
/*     */     
/*  78 */     typeMappingBase.readXML(inputStream);
/*  79 */     inputStream.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultRegistry() throws JAXRPCException {
/*  84 */     TypeMappingFactory typeMappingFactory = TypeMappingFactory.newInstance();
/*  85 */     TypeMapping typeMapping = (TypeMapping)typeMappingFactory.createDefaultMapping();
/*     */     
/*  87 */     register(typeMapping, new String[] { StdNamespace.instance().soapEncoding() });
/*     */ 
/*     */     
/*  90 */     register(typeMapping, new String[] { "http://www.w3.org/2003/05/soap-encoding" });
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     StringBuffer stringBuffer = new StringBuffer();
/*  96 */     stringBuffer.append(getClass().getName());
/*  97 */     stringBuffer.append("[ registerd encodingStyle = ");
/*     */     
/*  99 */     String[] arrayOfString = getRegisteredNamespaces();
/*     */     
/* 101 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 102 */       stringBuffer.append(arrayOfString[b]);
/* 103 */       stringBuffer.append(",");
/*     */     } 
/*     */     
/* 106 */     stringBuffer.append("]");
/*     */     
/* 108 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\encoding\DefaultRegistry.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */