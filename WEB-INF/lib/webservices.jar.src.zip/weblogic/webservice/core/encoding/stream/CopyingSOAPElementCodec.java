/*    */ package weblogic.webservice.core.encoding.stream;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.soap.SOAPElement;
/*    */ import weblogic.webservice.core.soap.SOAPElementImpl;
/*    */ import weblogic.xml.schema.binding.DeserializationContext;
/*    */ import weblogic.xml.stream.XMLInputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyingSOAPElementCodec
/*    */   extends SOAPElementCodec
/*    */ {
/*    */   protected void skipElement(XMLInputStream paramXMLInputStream) throws IOException {}
/*    */   
/* 28 */   protected SOAPElement getSOAPElement(XMLInputStream paramXMLInputStream, DeserializationContext paramDeserializationContext) throws IOException { return createSOAPElement(paramXMLInputStream); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SOAPElement createSOAPElement(XMLInputStream paramXMLInputStream) throws IOException {
/* 35 */     SOAPElementImpl sOAPElementImpl = new SOAPElementImpl();
/* 36 */     sOAPElementImpl.read(paramXMLInputStream);
/* 37 */     return sOAPElementImpl;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\encoding\stream\CopyingSOAPElementCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */