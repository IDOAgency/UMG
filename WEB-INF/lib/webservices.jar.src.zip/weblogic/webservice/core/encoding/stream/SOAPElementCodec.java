package weblogic.webservice.core.encoding.stream;

import java.io.IOException;
import javax.xml.soap.SOAPElement;
import weblogic.xml.schema.binding.DeserializationContext;
import weblogic.xml.schema.binding.DeserializationException;
import weblogic.xml.schema.binding.JAXRPCCodecBase;
import weblogic.xml.schema.binding.SerializationContext;
import weblogic.xml.schema.binding.SerializationException;
import weblogic.xml.stream.Attribute;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;

public class SOAPElementCodec extends JAXRPCCodecBase {
  public Object deserialize(XMLName paramXMLName, XMLInputStream paramXMLInputStream, DeserializationContext paramDeserializationContext) throws DeserializationException {
    try {
      skipElement(paramXMLInputStream);
      return getSOAPElement(paramXMLInputStream, paramDeserializationContext);
    } catch (XMLStreamException xMLStreamException) {
      throw new DeserializationException("stream error", xMLStreamException);
    } catch (IOException iOException) {
      throw new DeserializationException("io error", iOException);
    } 
  }
  
  protected void skipElement(XMLInputStream paramXMLInputStream) throws IOException { paramXMLInputStream.skipElement(); }
  
  protected SOAPElement getSOAPElement(XMLInputStream paramXMLInputStream, DeserializationContext paramDeserializationContext) throws IOException { return paramDeserializationContext.getSOAPElement(); }
  
  public Object deserialize(XMLName paramXMLName, Attribute paramAttribute, DeserializationContext paramDeserializationContext) throws DeserializationException { return paramDeserializationContext.getSOAPElement(); }
  
  public void serialize(Object paramObject, XMLName paramXMLName, XMLOutputStream paramXMLOutputStream, SerializationContext paramSerializationContext) throws SerializationException {
    if (paramObject instanceof XMLNode) {
      XMLNode xMLNode = (XMLNode)paramObject;
      try {
        xMLNode.write(paramXMLOutputStream);
      } catch (XMLStreamException xMLStreamException) {
        throw new SerializationException("stream error", xMLStreamException);
      } 
    } else {
      throw new SerializationException("input must be an instance of " + XMLNode.class);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\encoding\stream\SOAPElementCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */