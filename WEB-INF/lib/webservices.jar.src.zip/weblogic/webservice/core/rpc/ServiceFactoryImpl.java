package weblogic.webservice.core.rpc;

import java.io.IOException;
import java.net.URL;
import java.util.Properties;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.ServiceFactory;
import weblogic.webservice.WebServiceFactory;

public final class ServiceFactoryImpl extends ServiceFactory {
  private WebServiceFactory factory;
  
  public Service createService(URL paramURL, QName paramQName) throws ServiceException {
    try {
      ServiceImpl serviceImpl = new ServiceImpl(paramURL.toString());
      if ("false".equalsIgnoreCase(System.getProperty("weblogic.webservice.servicenamechecking")))
        return serviceImpl; 
      if (paramQName.getLocalPart().equals(serviceImpl.getWebService().getName()))
        return serviceImpl; 
      throw new ServiceException("Did not find a service with name:" + paramQName + ", but found a service with name:" + serviceImpl.getWebService().getName());
    } catch (IOException iOException) {
      throw new ServiceException("unable to read wsdl file", iOException);
    } 
  }
  
  public Service createService(QName paramQName) throws JAXRPCException { return new ServiceImpl(paramQName); }
  
  public Service loadService(Class paramClass) throws ServiceException { throw new Error("Jaxrpc 1.1 method is not supported."); }
  
  public Service loadService(URL paramURL, Class paramClass, Properties paramProperties) throws ServiceException { throw new Error("Jaxrpc 1.1 method is not supported."); }
  
  public Service loadService(URL paramURL, QName paramQName, Properties paramProperties) throws ServiceException { throw new Error("Jaxrpc 1.1 method is not supported."); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\rpc\ServiceFactoryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */