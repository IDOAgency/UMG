/*    */ package weblogic.webservice.core.rpc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.Properties;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.Service;
/*    */ import javax.xml.rpc.ServiceException;
/*    */ import javax.xml.rpc.ServiceFactory;
/*    */ import weblogic.webservice.WebServiceFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServiceFactoryImpl
/*    */   extends ServiceFactory
/*    */ {
/*    */   private WebServiceFactory factory;
/*    */   
/*    */   public Service createService(URL paramURL, QName paramQName) throws ServiceException {
/*    */     try {
/* 40 */       ServiceImpl serviceImpl = new ServiceImpl(paramURL.toString());
/*    */       
/* 42 */       if ("false".equalsIgnoreCase(System.getProperty("weblogic.webservice.servicenamechecking")))
/*    */       {
/* 44 */         return serviceImpl;
/*    */       }
/* 46 */       if (paramQName.getLocalPart().equals(serviceImpl.getWebService().getName()))
/*    */       {
/* 48 */         return serviceImpl;
/*    */       }
/* 50 */       throw new ServiceException("Did not find a service with name:" + paramQName + ", but found a service with name:" + serviceImpl.getWebService().getName());
/*    */ 
/*    */ 
/*    */     
/*    */     }
/* 55 */     catch (IOException iOException) {
/* 56 */       throw new ServiceException("unable to read wsdl file", iOException);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 61 */   public Service createService(QName paramQName) throws JAXRPCException { return new ServiceImpl(paramQName); }
/*    */ 
/*    */ 
/*    */   
/* 65 */   public Service loadService(Class paramClass) throws ServiceException { throw new Error("Jaxrpc 1.1 method is not supported."); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public Service loadService(URL paramURL, Class paramClass, Properties paramProperties) throws ServiceException { throw new Error("Jaxrpc 1.1 method is not supported."); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   public Service loadService(URL paramURL, QName paramQName, Properties paramProperties) throws ServiceException { throw new Error("Jaxrpc 1.1 method is not supported."); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\rpc\ServiceFactoryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */