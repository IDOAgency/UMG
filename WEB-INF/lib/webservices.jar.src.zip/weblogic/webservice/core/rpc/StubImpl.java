/*     */ package weblogic.webservice.core.rpc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.Stub;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.async.AsyncInfo;
/*     */ import weblogic.webservice.async.FutureResult;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.binding.https.HttpsBindingInfo;
/*     */ import weblogic.webservice.client.SSLAdapter;
/*     */ import weblogic.webservice.core.PortMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StubImpl
/*     */   implements Stub, InvocationHandler
/*     */ {
/*     */   private static final String USERNAME = "javax.xml.rpc.security.auth.username";
/*     */   private static final String PASSWORD = "javax.xml.rpc.security.auth.password";
/*     */   private static final String SSL_ADAPTER = "weblogic.webservice.client.ssladapter";
/*     */   private static final String END_POINT = "javax.xml.rpc.service.endpoint.address";
/*     */   private static final String PROXY_USERNAME = "weblogic.webservice.client.proxyusername";
/*     */   private static final String PROXY_PASSWORD = "weblogic.webservice.client.proxypassword";
/*     */   private static final String BINDING_INFO = "weblogic.webservice.bindinginfo";
/*     */   private static final String TIMEOUT = "weblogic.webservice.rpc.timeoutsecs";
/*     */   private Port port;
/*     */   private String encodingStyle;
/*  86 */   private static final ArrayList propertyNames = new ArrayList();
/*     */   
/*     */   static  {
/*  89 */     propertyNames.add("javax.xml.rpc.security.auth.username");
/*  90 */     propertyNames.add("javax.xml.rpc.security.auth.password");
/*  91 */     propertyNames.add("weblogic.webservice.client.ssladapter");
/*  92 */     propertyNames.add("javax.xml.rpc.service.endpoint.address");
/*  93 */     propertyNames.add("weblogic.webservice.bindinginfo");
/*  94 */     propertyNames.add("weblogic.webservice.rpc.timeoutsecs");
/*  95 */     propertyNames.add("javax.xml.rpc.session.maintain");
/*     */   }
/*     */   
/*     */   public StubImpl(Port paramPort) {
/*  99 */     if (paramPort == null) {
/* 100 */       throw new IllegalArgumentException("port can not be null");
/*     */     }
/*     */     
/* 103 */     this.port = paramPort;
/*     */   }
/*     */   
/*     */   public StubImpl(Port paramPort, Class paramClass) {
/* 107 */     this(paramPort);
/* 108 */     (new PortMapper()).mapInterfaceToPort(paramClass, paramPort);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void _setProperty(String paramString, Object paramObject) throws UnsupportedOperationException {
/* 114 */     if ("javax.xml.rpc.security.auth.username".equals(paramString)) {
/* 115 */       this.port.setUserName((String)paramObject);
/* 116 */     } else if ("javax.xml.rpc.security.auth.password".equals(paramString)) {
/* 117 */       this.port.setPassword((String)paramObject);
/* 118 */     } else if ("weblogic.webservice.client.ssladapter".equals(paramString)) {
/* 119 */       BindingInfo bindingInfo = this.port.getBindingInfo();
/*     */       
/* 121 */       if (bindingInfo instanceof HttpsBindingInfo) {
/* 122 */         ((HttpsBindingInfo)bindingInfo).setSSLAdapter((SSLAdapter)paramObject);
/*     */       } else {
/* 124 */         throw new JAXRPCException("Can not set SSLAdapter on non https binding");
/*     */       }
/*     */     
/* 127 */     } else if ("javax.xml.rpc.service.endpoint.address".equals(paramString)) {
/* 128 */       this.port.getBindingInfo().setAddress((String)paramObject);
/* 129 */     } else if ("weblogic.webservice.client.proxyusername".equals(paramString)) {
/* 130 */       this.port.setProxyUserName((String)paramObject);
/* 131 */     } else if ("weblogic.webservice.client.proxypassword".equals(paramString)) {
/* 132 */       this.port.setProxyPassword((String)paramObject);
/* 133 */     } else if ("weblogic.webservice.bindinginfo".equals(paramString)) {
/* 134 */       this.port.setBindingInfo((BindingInfo)paramObject);
/* 135 */     } else if ("weblogic.webservice.rpc.timeoutsecs".equals(paramString)) {
/* 136 */       BindingInfo bindingInfo = this.port.getBindingInfo();
/* 137 */       if (paramObject instanceof String) {
/* 138 */         bindingInfo.setTimeout(Integer.parseInt((String)paramObject));
/* 139 */       } else if (paramObject instanceof Integer) {
/* 140 */         bindingInfo.setTimeout(((Integer)paramObject).intValue());
/*     */       } 
/* 142 */     } else if ("javax.xml.rpc.session.maintain".equals(paramString)) {
/* 143 */       if (paramObject instanceof String) {
/* 144 */         this.port.setMaintainSession((new Boolean((String)paramObject)).booleanValue());
/* 145 */       } else if (paramObject instanceof Boolean) {
/* 146 */         this.port.setMaintainSession(((Boolean)paramObject).booleanValue());
/*     */       } 
/*     */     } else {
/* 149 */       throw new UnsupportedOperationException("unknow property:" + paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object _getProperty(String paramString) {
/* 155 */     Boolean bool = null;
/*     */     
/* 157 */     if ("javax.xml.rpc.security.auth.username".equals(paramString)) {
/* 158 */       bool = this.port.getUserName();
/* 159 */     } else if ("javax.xml.rpc.security.auth.password".equals(paramString)) {
/* 160 */       bool = this.port.getPassword();
/* 161 */     } else if ("weblogic.webservice.client.ssladapter".equals(paramString)) {
/* 162 */       BindingInfo bindingInfo = this.port.getBindingInfo();
/*     */       
/* 164 */       if (bindingInfo instanceof HttpsBindingInfo) {
/* 165 */         SSLAdapter sSLAdapter = ((HttpsBindingInfo)bindingInfo).getSSLAdapter();
/*     */       }
/* 167 */     } else if ("javax.xml.rpc.service.endpoint.address".equals(paramString)) {
/* 168 */       bool = this.port.getBindingInfo().getAddress();
/* 169 */     } else if ("weblogic.webservice.bindinginfo".equals(paramString)) {
/* 170 */       BindingInfo bindingInfo = this.port.getBindingInfo();
/* 171 */     } else if ("weblogic.webservice.rpc.timeoutsecs".equals(paramString)) {
/* 172 */       bool = String.valueOf(this.port.getBindingInfo().getTimeout());
/* 173 */     } else if ("javax.xml.rpc.session.maintain".equals(paramString)) {
/* 174 */       bool = new Boolean(this.port.getMaintainSession());
/*     */     } 
/*     */     
/* 177 */     return bool;
/*     */   }
/*     */ 
/*     */   
/* 181 */   public Iterator _getPropertyNames() { return propertyNames.iterator(); }
/*     */ 
/*     */ 
/*     */   
/* 185 */   public void _setTargetEndpoint(URL paramURL) { this.port.getBindingInfo().setAddress(paramURL.toString()); }
/*     */ 
/*     */   
/*     */   public URL _getTargetEndpoint() {
/*     */     try {
/* 190 */       return new URL(this.port.getBindingInfo().getAddress());
/* 191 */     } catch (MalformedURLException malformedURLException) {
/* 192 */       String str = WebServiceLogger.logStubImplMalformedURLException();
/* 193 */       WebServiceLogger.logStackTrace(str, malformedURLException);
/* 194 */       throw new IllegalArgumentException("wrong url:" + malformedURLException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 199 */   public void _setEncodingStyle(String paramString) { this.encodingStyle = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 203 */   public String _getEncodingStyle() { return this.encodingStyle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public Reference getReference() throws NamingException { throw new Error("NYI"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Object paramObject, Method paramMethod, Object[] paramArrayOfObject) throws Throwable {
/* 220 */     HashMap hashMap = new HashMap();
/* 221 */     Operation operation = this.port.getOperation(paramMethod.getName());
/*     */     
/* 223 */     if (operation == null) {
/*     */ 
/*     */ 
/*     */       
/* 227 */       if ("toString".equals(paramMethod.getName())) {
/* 228 */         return toString();
/*     */       }
/*     */       
/* 231 */       if ("_setProperty".equals(paramMethod.getName())) {
/* 232 */         return paramMethod.invoke(this, paramArrayOfObject);
/*     */       }
/*     */       
/* 235 */       throw new JAXRPCException("unable to find operation:" + paramMethod);
/*     */     } 
/*     */     
/* 238 */     byte b = 0;
/*     */     
/* 240 */     for (iterator = operation.getInput().getParts(); iterator.hasNext(); b++) {
/* 241 */       Part part = (Part)iterator.next();
/* 242 */       if (b < paramArrayOfObject.length) {
/* 243 */         hashMap.put(part.getName(), paramArrayOfObject[b]);
/*     */       } else {
/* 245 */         throw new JAXRPCException("not enough args");
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 250 */       return _invoke(paramMethod.getName(), hashMap);
/* 251 */     } catch (SOAPFaultException iterator) {
/* 252 */       return throwRemoteException("Failed to invoke", iterator);
/* 253 */     } catch (JAXRPCException iterator) {
/* 254 */       return throwRemoteException("Failed to invoke", iterator);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object throwRemoteException(String paramString, Throwable paramThrowable) throws Throwable {
/* 261 */     Throwable throwable = paramThrowable;
/*     */     
/*     */     try {
/* 264 */       Class clazz = Class.forName("java.rmi.RemoteException");
/*     */       
/* 266 */       Constructor constructor = clazz.getConstructor(new Class[] { String.class, Throwable.class });
/*     */ 
/*     */       
/* 269 */       throwable = (Throwable)constructor.newInstance(new Object[] { paramString, paramThrowable });
/*     */     }
/* 271 */     catch (Throwable throwable1) {
/* 272 */       throwable = paramThrowable;
/*     */     } 
/*     */     
/* 275 */     throw throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public FutureResult _startAsyncInvoke(String paramString, Map paramMap, AsyncInfo paramAsyncInfo) {
/* 281 */     if (paramAsyncInfo != null) {
/* 282 */       paramAsyncInfo.setCaller(this);
/*     */     }
/*     */     
/*     */     try {
/* 286 */       Operation operation = this.port.getOperation(paramString);
/*     */       
/* 288 */       HashMap hashMap = new HashMap();
/*     */       
/* 290 */       return operation.asyncInvoke(hashMap, getArgValueArray(operation, paramMap), paramAsyncInfo, null);
/*     */     
/*     */     }
/* 293 */     catch (IOException iOException) {
/* 294 */       throw new JAXRPCException("web service invoke failed: " + iOException, iOException);
/* 295 */     } catch (SOAPException sOAPException) {
/* 296 */       throw new JAXRPCException("web service invoke failed: " + sOAPException, sOAPException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object _invoke(String paramString, Map paramMap) throws Throwable {
/*     */     try {
/* 302 */       HashMap hashMap = new HashMap();
/*     */       
/* 304 */       Operation operation = this.port.getOperation(paramString);
/*     */       
/* 306 */       Object object = operation.invoke(hashMap, getArgValueArray(operation, paramMap));
/*     */ 
/*     */       
/* 309 */       for (Iterator iterator = operation.getOutput().getParts(); iterator.hasNext(); ) {
/* 310 */         Part part = (Part)iterator.next();
/* 311 */         Object object1 = paramMap.get(part.getName());
/* 312 */         Object object2 = hashMap.get(part.getName());
/*     */         
/* 314 */         if (part.getMode() == Part.Mode.INOUT || part.getMode() == Part.Mode.OUT) {
/*     */ 
/*     */           
/* 317 */           if (object1 == null)
/*     */           {
/* 319 */             throw new JAXRPCException("This is an in-out or out param.but the holder class not passed in:" + part.getName());
/*     */           }
/*     */ 
/*     */           
/* 323 */           _setHolderValue(object1, object2);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 328 */       return object;
/* 329 */     } catch (TargetInvocationException targetInvocationException) {
/* 330 */       throw targetInvocationException.getCause();
/* 331 */     } catch (IOException iOException) {
/* 332 */       throw new JAXRPCException("web service invoke failed: " + iOException, iOException);
/* 333 */     } catch (SOAPException sOAPException) {
/* 334 */       throw new JAXRPCException("web service invoke failed: " + sOAPException, sOAPException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object[] getArgValueArray(Operation paramOperation, Map paramMap) {
/* 339 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 341 */     for (Iterator iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 342 */       Part part = (Part)iterator.next();
/* 343 */       Object object = paramMap.get(part.getName());
/* 344 */       object = _getHolderValue(object);
/* 345 */       arrayList.add(object);
/*     */     } 
/*     */     
/* 348 */     return arrayList.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public void _setHolderValue(Object paramObject1, Object paramObject2) {
/* 353 */     if (paramObject1 == null) {
/* 354 */       throw new JAXRPCException("holder can not be null");
/*     */     }
/*     */     
/*     */     try {
/* 358 */       Field field = paramObject1.getClass().getField("value");
/* 359 */       field.set(paramObject1, paramObject2);
/* 360 */     } catch (NoSuchFieldException noSuchFieldException) {
/* 361 */       throw new JAXRPCException("unable to set value on the holder class", noSuchFieldException);
/* 362 */     } catch (IllegalAccessException illegalAccessException) {
/* 363 */       throw new JAXRPCException("unable to set value on the holder class", illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object _getHolderValue(Object paramObject) {
/* 369 */     if (paramObject == null) {
/* 370 */       return null;
/*     */     }
/*     */     
/* 373 */     if (!(paramObject instanceof javax.xml.rpc.holders.Holder)) {
/* 374 */       return paramObject;
/*     */     }
/*     */     
/*     */     try {
/* 378 */       Field field = paramObject.getClass().getField("value");
/* 379 */       return field.get(paramObject);
/* 380 */     } catch (NoSuchFieldException noSuchFieldException) {
/* 381 */       throw new JAXRPCException("unable to find field 'value' in the holder class " + paramObject.getClass(), noSuchFieldException);
/*     */     }
/* 383 */     catch (IllegalAccessException illegalAccessException) {
/* 384 */       throw new JAXRPCException("unable to get value from holder class", illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object implementInterface(Class paramClass, Port paramPort) throws IOException {
/* 395 */     ClassLoader classLoader = paramClass.getClassLoader();
/* 396 */     Class[] arrayOfClass = { paramClass, java.rmi.Remote.class, Stub.class };
/*     */     
/* 398 */     StubImpl stubImpl = new StubImpl(paramPort, paramClass);
/* 399 */     return Proxy.newProxyInstance(classLoader, arrayOfClass, stubImpl);
/*     */   }
/*     */ 
/*     */   
/* 403 */   public Object _wrap(int paramInt) { return new Integer(paramInt); }
/*     */ 
/*     */ 
/*     */   
/* 407 */   public Object _wrap(float paramFloat) { return new Float(paramFloat); }
/*     */ 
/*     */ 
/*     */   
/* 411 */   public Object _wrap(double paramDouble) { return new Double(paramDouble); }
/*     */ 
/*     */ 
/*     */   
/* 415 */   public Object _wrap(short paramShort) { return new Short(paramShort); }
/*     */ 
/*     */ 
/*     */   
/* 419 */   public Object _wrap(long paramLong) { return new Long(paramLong); }
/*     */ 
/*     */ 
/*     */   
/* 423 */   public Object _wrap(boolean paramBoolean) { return new Boolean(paramBoolean); }
/*     */ 
/*     */ 
/*     */   
/* 427 */   public Object _wrap(Object paramObject) { return paramObject; }
/*     */ 
/*     */ 
/*     */   
/* 431 */   public Object _wrap(char paramChar) { return new Character(paramChar); }
/*     */ 
/*     */ 
/*     */   
/* 435 */   public Object _wrap(byte paramByte) { return new Byte(paramByte); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\rpc\StubImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */