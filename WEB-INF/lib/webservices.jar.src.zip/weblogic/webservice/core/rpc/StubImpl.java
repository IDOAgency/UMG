package weblogic.webservice.core.rpc;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.naming.NamingException;
import javax.naming.Reference;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.Stub;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.SOAPException;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.async.AsyncInfo;
import weblogic.webservice.async.FutureResult;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.binding.https.HttpsBindingInfo;
import weblogic.webservice.client.SSLAdapter;
import weblogic.webservice.core.PortMapper;

public class StubImpl implements Stub, InvocationHandler {
  private static final String USERNAME = "javax.xml.rpc.security.auth.username";
  
  private static final String PASSWORD = "javax.xml.rpc.security.auth.password";
  
  private static final String SSL_ADAPTER = "weblogic.webservice.client.ssladapter";
  
  private static final String END_POINT = "javax.xml.rpc.service.endpoint.address";
  
  private static final String PROXY_USERNAME = "weblogic.webservice.client.proxyusername";
  
  private static final String PROXY_PASSWORD = "weblogic.webservice.client.proxypassword";
  
  private static final String BINDING_INFO = "weblogic.webservice.bindinginfo";
  
  private static final String TIMEOUT = "weblogic.webservice.rpc.timeoutsecs";
  
  private Port port;
  
  private String encodingStyle;
  
  private static final ArrayList propertyNames = new ArrayList();
  
  static  {
    propertyNames.add("javax.xml.rpc.security.auth.username");
    propertyNames.add("javax.xml.rpc.security.auth.password");
    propertyNames.add("weblogic.webservice.client.ssladapter");
    propertyNames.add("javax.xml.rpc.service.endpoint.address");
    propertyNames.add("weblogic.webservice.bindinginfo");
    propertyNames.add("weblogic.webservice.rpc.timeoutsecs");
    propertyNames.add("javax.xml.rpc.session.maintain");
  }
  
  public StubImpl(Port paramPort) {
    if (paramPort == null)
      throw new IllegalArgumentException("port can not be null"); 
    this.port = paramPort;
  }
  
  public StubImpl(Port paramPort, Class paramClass) {
    this(paramPort);
    (new PortMapper()).mapInterfaceToPort(paramClass, paramPort);
  }
  
  public void _setProperty(String paramString, Object paramObject) throws UnsupportedOperationException {
    if ("javax.xml.rpc.security.auth.username".equals(paramString)) {
      this.port.setUserName((String)paramObject);
    } else if ("javax.xml.rpc.security.auth.password".equals(paramString)) {
      this.port.setPassword((String)paramObject);
    } else if ("weblogic.webservice.client.ssladapter".equals(paramString)) {
      BindingInfo bindingInfo = this.port.getBindingInfo();
      if (bindingInfo instanceof HttpsBindingInfo) {
        ((HttpsBindingInfo)bindingInfo).setSSLAdapter((SSLAdapter)paramObject);
      } else {
        throw new JAXRPCException("Can not set SSLAdapter on non https binding");
      } 
    } else if ("javax.xml.rpc.service.endpoint.address".equals(paramString)) {
      this.port.getBindingInfo().setAddress((String)paramObject);
    } else if ("weblogic.webservice.client.proxyusername".equals(paramString)) {
      this.port.setProxyUserName((String)paramObject);
    } else if ("weblogic.webservice.client.proxypassword".equals(paramString)) {
      this.port.setProxyPassword((String)paramObject);
    } else if ("weblogic.webservice.bindinginfo".equals(paramString)) {
      this.port.setBindingInfo((BindingInfo)paramObject);
    } else if ("weblogic.webservice.rpc.timeoutsecs".equals(paramString)) {
      BindingInfo bindingInfo = this.port.getBindingInfo();
      if (paramObject instanceof String) {
        bindingInfo.setTimeout(Integer.parseInt((String)paramObject));
      } else if (paramObject instanceof Integer) {
        bindingInfo.setTimeout(((Integer)paramObject).intValue());
      } 
    } else if ("javax.xml.rpc.session.maintain".equals(paramString)) {
      if (paramObject instanceof String) {
        this.port.setMaintainSession((new Boolean((String)paramObject)).booleanValue());
      } else if (paramObject instanceof Boolean) {
        this.port.setMaintainSession(((Boolean)paramObject).booleanValue());
      } 
    } else {
      throw new UnsupportedOperationException("unknow property:" + paramString);
    } 
  }
  
  public Object _getProperty(String paramString) {
    Boolean bool = null;
    if ("javax.xml.rpc.security.auth.username".equals(paramString)) {
      bool = this.port.getUserName();
    } else if ("javax.xml.rpc.security.auth.password".equals(paramString)) {
      bool = this.port.getPassword();
    } else if ("weblogic.webservice.client.ssladapter".equals(paramString)) {
      BindingInfo bindingInfo = this.port.getBindingInfo();
      if (bindingInfo instanceof HttpsBindingInfo)
        SSLAdapter sSLAdapter = ((HttpsBindingInfo)bindingInfo).getSSLAdapter(); 
    } else if ("javax.xml.rpc.service.endpoint.address".equals(paramString)) {
      bool = this.port.getBindingInfo().getAddress();
    } else if ("weblogic.webservice.bindinginfo".equals(paramString)) {
      BindingInfo bindingInfo = this.port.getBindingInfo();
    } else if ("weblogic.webservice.rpc.timeoutsecs".equals(paramString)) {
      bool = String.valueOf(this.port.getBindingInfo().getTimeout());
    } else if ("javax.xml.rpc.session.maintain".equals(paramString)) {
      bool = new Boolean(this.port.getMaintainSession());
    } 
    return bool;
  }
  
  public Iterator _getPropertyNames() { return propertyNames.iterator(); }
  
  public void _setTargetEndpoint(URL paramURL) { this.port.getBindingInfo().setAddress(paramURL.toString()); }
  
  public URL _getTargetEndpoint() {
    try {
      return new URL(this.port.getBindingInfo().getAddress());
    } catch (MalformedURLException malformedURLException) {
      String str = WebServiceLogger.logStubImplMalformedURLException();
      WebServiceLogger.logStackTrace(str, malformedURLException);
      throw new IllegalArgumentException("wrong url:" + malformedURLException);
    } 
  }
  
  public void _setEncodingStyle(String paramString) { this.encodingStyle = paramString; }
  
  public String _getEncodingStyle() { return this.encodingStyle; }
  
  public Reference getReference() throws NamingException { throw new Error("NYI"); }
  
  public Object invoke(Object paramObject, Method paramMethod, Object[] paramArrayOfObject) throws Throwable {
    HashMap hashMap = new HashMap();
    Operation operation = this.port.getOperation(paramMethod.getName());
    if (operation == null) {
      if ("toString".equals(paramMethod.getName()))
        return toString(); 
      if ("_setProperty".equals(paramMethod.getName()))
        return paramMethod.invoke(this, paramArrayOfObject); 
      throw new JAXRPCException("unable to find operation:" + paramMethod);
    } 
    byte b = 0;
    for (iterator = operation.getInput().getParts(); iterator.hasNext(); b++) {
      Part part = (Part)iterator.next();
      if (b < paramArrayOfObject.length) {
        hashMap.put(part.getName(), paramArrayOfObject[b]);
      } else {
        throw new JAXRPCException("not enough args");
      } 
    } 
    try {
      return _invoke(paramMethod.getName(), hashMap);
    } catch (SOAPFaultException iterator) {
      return throwRemoteException("Failed to invoke", iterator);
    } catch (JAXRPCException iterator) {
      return throwRemoteException("Failed to invoke", iterator);
    } 
  }
  
  private Object throwRemoteException(String paramString, Throwable paramThrowable) throws Throwable {
    Throwable throwable = paramThrowable;
    try {
      Class clazz = Class.forName("java.rmi.RemoteException");
      Constructor constructor = clazz.getConstructor(new Class[] { String.class, Throwable.class });
      throwable = (Throwable)constructor.newInstance(new Object[] { paramString, paramThrowable });
    } catch (Throwable throwable1) {
      throwable = paramThrowable;
    } 
    throw throwable;
  }
  
  public FutureResult _startAsyncInvoke(String paramString, Map paramMap, AsyncInfo paramAsyncInfo) {
    if (paramAsyncInfo != null)
      paramAsyncInfo.setCaller(this); 
    try {
      Operation operation = this.port.getOperation(paramString);
      HashMap hashMap = new HashMap();
      return operation.asyncInvoke(hashMap, getArgValueArray(operation, paramMap), paramAsyncInfo, null);
    } catch (IOException iOException) {
      throw new JAXRPCException("web service invoke failed: " + iOException, iOException);
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("web service invoke failed: " + sOAPException, sOAPException);
    } 
  }
  
  public Object _invoke(String paramString, Map paramMap) throws Throwable {
    try {
      HashMap hashMap = new HashMap();
      Operation operation = this.port.getOperation(paramString);
      Object object = operation.invoke(hashMap, getArgValueArray(operation, paramMap));
      for (Iterator iterator = operation.getOutput().getParts(); iterator.hasNext(); ) {
        Part part = (Part)iterator.next();
        Object object1 = paramMap.get(part.getName());
        Object object2 = hashMap.get(part.getName());
        if (part.getMode() == Part.Mode.INOUT || part.getMode() == Part.Mode.OUT) {
          if (object1 == null)
            throw new JAXRPCException("This is an in-out or out param.but the holder class not passed in:" + part.getName()); 
          _setHolderValue(object1, object2);
        } 
      } 
      return object;
    } catch (TargetInvocationException targetInvocationException) {
      throw targetInvocationException.getCause();
    } catch (IOException iOException) {
      throw new JAXRPCException("web service invoke failed: " + iOException, iOException);
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("web service invoke failed: " + sOAPException, sOAPException);
    } 
  }
  
  private Object[] getArgValueArray(Operation paramOperation, Map paramMap) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      Object object = paramMap.get(part.getName());
      object = _getHolderValue(object);
      arrayList.add(object);
    } 
    return arrayList.toArray();
  }
  
  public void _setHolderValue(Object paramObject1, Object paramObject2) {
    if (paramObject1 == null)
      throw new JAXRPCException("holder can not be null"); 
    try {
      Field field = paramObject1.getClass().getField("value");
      field.set(paramObject1, paramObject2);
    } catch (NoSuchFieldException noSuchFieldException) {
      throw new JAXRPCException("unable to set value on the holder class", noSuchFieldException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new JAXRPCException("unable to set value on the holder class", illegalAccessException);
    } 
  }
  
  public Object _getHolderValue(Object paramObject) {
    if (paramObject == null)
      return null; 
    if (!(paramObject instanceof javax.xml.rpc.holders.Holder))
      return paramObject; 
    try {
      Field field = paramObject.getClass().getField("value");
      return field.get(paramObject);
    } catch (NoSuchFieldException noSuchFieldException) {
      throw new JAXRPCException("unable to find field 'value' in the holder class " + paramObject.getClass(), noSuchFieldException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new JAXRPCException("unable to get value from holder class", illegalAccessException);
    } 
  }
  
  public static Object implementInterface(Class paramClass, Port paramPort) throws IOException {
    ClassLoader classLoader = paramClass.getClassLoader();
    Class[] arrayOfClass = { paramClass, java.rmi.Remote.class, Stub.class };
    StubImpl stubImpl = new StubImpl(paramPort, paramClass);
    return Proxy.newProxyInstance(classLoader, arrayOfClass, stubImpl);
  }
  
  public Object _wrap(int paramInt) { return new Integer(paramInt); }
  
  public Object _wrap(float paramFloat) { return new Float(paramFloat); }
  
  public Object _wrap(double paramDouble) { return new Double(paramDouble); }
  
  public Object _wrap(short paramShort) { return new Short(paramShort); }
  
  public Object _wrap(long paramLong) { return new Long(paramLong); }
  
  public Object _wrap(boolean paramBoolean) { return new Boolean(paramBoolean); }
  
  public Object _wrap(Object paramObject) { return paramObject; }
  
  public Object _wrap(char paramChar) { return new Character(paramChar); }
  
  public Object _wrap(byte paramByte) { return new Byte(paramByte); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\rpc\StubImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */