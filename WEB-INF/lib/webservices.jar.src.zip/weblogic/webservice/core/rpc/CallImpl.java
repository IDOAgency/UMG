/*     */ package weblogic.webservice.core.rpc;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.ParameterMode;
/*     */ import javax.xml.rpc.encoding.TypeMapping;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceFactory;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.binding.https.HttpsBindingInfo;
/*     */ import weblogic.webservice.client.SSLAdapter;
/*     */ import weblogic.webservice.extensions.WLCall;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallImpl
/*     */   implements WLCall
/*     */ {
/*     */   private WebService webservice;
/*     */   private Operation operation;
/*     */   private Port port;
/*     */   private QName name;
/*     */   private QName portName;
/*     */   private String endpoint;
/*     */   private String encodingStyle;
/*     */   private boolean changed;
/*     */   private boolean propertiesChanged;
/*     */   private HashMap properties;
/*     */   private ArrayList parameters;
/*     */   private ParameterInfo returnInfo;
/*     */   private Map lastResult;
/*     */   private ServiceImpl serviceImpl;
/*     */   private static final String SSL_ADAPTER = "weblogic.webservice.client.ssladapter";
/*     */   private static final String TIMEOUT = "weblogic.webservice.rpc.timeoutsecs";
/*     */   private static final String PROXY_USERNAME = "weblogic.webservice.client.proxyusername";
/*     */   private static final String PROXY_PASSWORD = "weblogic.webservice.client.proxypassword";
/*  83 */   private static ArrayList validProperties = new ArrayList();
/*     */   
/*     */   static  {
/*  86 */     validProperties.add("javax.xml.rpc.security.auth.username");
/*  87 */     validProperties.add("javax.xml.rpc.security.auth.password");
/*  88 */     validProperties.add("javax.xml.rpc.soap.operation.style");
/*  89 */     validProperties.add("javax.xml.rpc.soap.http.soapaction.use");
/*  90 */     validProperties.add("javax.xml.rpc.soap.http.soapaction.uri");
/*  91 */     validProperties.add("javax.xml.rpc.encodingstyle.namespace.uri");
/*  92 */     validProperties.add("javax.xml.rpc.session.maintain");
/*  93 */     validProperties.add("weblogic.webservice.client.ssladapter");
/*  94 */     validProperties.add("weblogic.webservice.client.proxyusername");
/*  95 */     validProperties.add("weblogic.webservice.client.proxypassword");
/*  96 */     validProperties.add("weblogic.webservice.rpc.timeoutsecs"); } CallImpl(ServiceImpl paramServiceImpl) { this.encodingStyle = StdNamespace.instance().soapEncoding(); this.changed = false;
/*     */     this.propertiesChanged = false;
/*     */     this.properties = new HashMap();
/*     */     this.parameters = new ArrayList();
/*     */     this.lastResult = new HashMap();
/* 101 */     this.serviceImpl = paramServiceImpl; }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParameterAndReturnSpecRequired(QName paramQName) {
/* 106 */     if (!this.serviceImpl.isCreatedFromWSDL()) {
/* 107 */       return true;
/*     */     }
/*     */     
/* 110 */     if (this.portName == null) {
/* 111 */       return true;
/*     */     }
/*     */     
/* 114 */     Port port1 = this.serviceImpl._getPort(this.portName.getLocalPart());
/*     */     
/* 116 */     if (port1 == null) {
/* 117 */       return true;
/*     */     }
/*     */     
/* 120 */     if (port1.getOperation(paramQName.getLocalPart()) == null) {
/* 121 */       return true;
/*     */     }
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParameter(String paramString, QName paramQName, Class paramClass, ParameterMode paramParameterMode) throws JAXRPCException {
/* 130 */     markChanged();
/* 131 */     ParameterInfo parameterInfo = new ParameterInfo();
/*     */     
/* 133 */     parameterInfo.name = paramString;
/* 134 */     parameterInfo.xmlType = paramQName;
/* 135 */     parameterInfo.javaType = paramClass;
/* 136 */     parameterInfo.mode = paramParameterMode;
/*     */     
/* 138 */     this.parameters.add(parameterInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public void addParameter(String paramString, QName paramQName, ParameterMode paramParameterMode) throws JAXRPCException { addParameter(paramString, paramQName, null, paramParameterMode); }
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getParameterTypeByName(String paramString) {
/* 149 */     for (ParameterInfo parameterInfo : this.parameters) {
/*     */ 
/*     */       
/* 152 */       if (paramString.equals(parameterInfo.name)) {
/* 153 */         return parameterInfo.xmlType;
/*     */       }
/*     */     } 
/*     */     
/* 157 */     if (this.name != null) {
/* 158 */       forceOperationLookup();
/*     */       
/* 160 */       Part part = getPart(paramString);
/* 161 */       return part.getXMLType();
/*     */     } 
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator getParameterNames() {
/* 168 */     forceOperationLookup();
/*     */     
/* 170 */     ArrayList arrayList = new ArrayList();
/*     */     Iterator iterator;
/* 172 */     for (iterator = this.operation.getInput().getParts(); iterator.hasNext(); ) {
/* 173 */       Part part = (Part)iterator.next();
/* 174 */       arrayList.add(part.getName());
/*     */     } 
/*     */     
/* 177 */     for (iterator = this.operation.getOutput().getParts(); iterator.hasNext(); ) {
/* 178 */       Part part = (Part)iterator.next();
/*     */       
/* 180 */       if (part.getMode() == Part.Mode.OUT) {
/* 181 */         arrayList.add(part.getName());
/*     */       }
/*     */     } 
/*     */     
/* 185 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   private Part getPart(String paramString) {
/* 189 */     Part part = this.operation.getInput().getPart(paramString);
/*     */     
/* 191 */     if (part == null) {
/* 192 */       part = this.operation.getOutput().getPart(paramString);
/*     */     }
/*     */     
/* 195 */     if (part == null) {
/* 196 */       throw new JAXRPCException("unable to find part: '" + paramString + "' for operation '" + this.operation + "'. Please check WSDL");
/*     */     }
/*     */ 
/*     */     
/* 200 */     return part;
/*     */   }
/*     */   
/*     */   public Class getParameterJavaType(String paramString) {
/* 204 */     forceOperationLookup();
/* 205 */     Part part = getPart(paramString);
/* 206 */     return part.getJavaType();
/*     */   }
/*     */   
/*     */   public ParameterMode getParameterMode(String paramString) {
/* 210 */     forceOperationLookup();
/* 211 */     Part part = getPart(paramString);
/*     */     
/* 213 */     Part.Mode mode = part.getMode();
/*     */     
/* 215 */     if (Part.Mode.IN == mode)
/* 216 */       return ParameterMode.IN; 
/* 217 */     if (Part.Mode.OUT == mode)
/* 218 */       return ParameterMode.OUT; 
/* 219 */     if (Part.Mode.INOUT == mode) {
/* 220 */       return ParameterMode.INOUT;
/*     */     }
/* 222 */     throw new JAXRPCException("unknown parameter mode for part:" + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReturnType(QName paramQName, Class paramClass) throws JAXRPCException {
/* 229 */     markChanged();
/*     */     
/* 231 */     this.returnInfo = new ParameterInfo();
/*     */     
/* 233 */     String str = "__bea_noname_result";
/*     */     
/* 235 */     this.returnInfo.name = str;
/* 236 */     this.returnInfo.xmlType = paramQName;
/* 237 */     this.returnInfo.javaType = paramClass;
/*     */   }
/*     */ 
/*     */   
/* 241 */   public void setReturnType(QName paramQName) throws JAXRPCException { setReturnType(paramQName, null); }
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getReturnType() {
/* 246 */     if (this.returnInfo == null) {
/*     */       
/* 248 */       if (this.name != null) {
/* 249 */         forceOperationLookup();
/*     */       }
/*     */       
/* 252 */       if (this.operation != null) {
/*     */         
/* 254 */         Part part = this.operation.getReturnPart();
/*     */         
/* 256 */         if (part != null) {
/* 257 */           return part.getXMLType();
/*     */         }
/*     */       } 
/*     */     } else {
/* 261 */       return this.returnInfo.xmlType;
/*     */     } 
/*     */     
/* 264 */     return null;
/*     */   }
/*     */   
/*     */   public void removeAllParameters() {
/* 268 */     markChanged();
/* 269 */     this.parameters.clear();
/*     */   }
/*     */   
/*     */   private void markChanged() {
/* 273 */     if (this.serviceImpl.isCreatedFromWSDL()) {
/* 274 */       throw new JAXRPCException("This call is created from WSDL, you can not add/remove parameters or return type from this call");
/*     */     }
/*     */ 
/*     */     
/* 278 */     this.changed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 283 */   public QName getOperationName() { return this.name; }
/*     */ 
/*     */   
/*     */   public void setOperationName(QName paramQName) throws JAXRPCException {
/* 287 */     this.name = paramQName;
/* 288 */     this.changed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public QName getPortTypeName() {
/* 293 */     if (this.portName == null) {
/* 294 */       return new QName("");
/*     */     }
/*     */     
/* 297 */     return this.portName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPortTypeName(QName paramQName) throws JAXRPCException {
/* 302 */     if (paramQName == null) {
/* 303 */       throw new IllegalArgumentException("port name can not be null");
/*     */     }
/*     */     
/* 306 */     this.portName = paramQName;
/* 307 */     this.changed = true;
/*     */   }
/*     */   
/*     */   public void setTargetEndpointAddress(String paramString) {
/* 311 */     this.endpoint = paramString;
/* 312 */     this.changed = true;
/*     */   }
/*     */ 
/*     */   
/* 316 */   public String getTargetEndpointAddress() { return this.endpoint; }
/*     */ 
/*     */ 
/*     */   
/* 320 */   private boolean isValidProperty(String paramString) { return validProperties.contains(paramString); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProperty(String paramString, Object paramObject) throws JAXRPCException {
/* 325 */     if (!isValidProperty(paramString)) {
/* 326 */       throw new JAXRPCException("unknown property: " + paramString);
/*     */     }
/*     */     
/* 329 */     this.properties.put(paramString, paramObject);
/* 330 */     this.propertiesChanged = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String paramString) {
/* 336 */     if (!isValidProperty(paramString)) {
/* 337 */       throw new JAXRPCException("unknown property: " + paramString);
/*     */     }
/*     */     
/* 340 */     return this.properties.get(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateProperties(Operation paramOperation) {
/* 355 */     if (this.port == null || paramOperation == null) {
/* 356 */       throw new IllegalArgumentException("port/operation can not be null");
/*     */     }
/*     */     
/* 359 */     for (String str : this.properties.keySet()) {
/*     */       
/* 361 */       Object object = this.properties.get(str);
/* 362 */       setPropertyInternal(str, object);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void setPropertyInternal(String paramString, Object paramObject) throws JAXRPCException {
/* 368 */     if ("javax.xml.rpc.security.auth.username".equals(paramString)) {
/* 369 */       this.port.setUserName((String)paramObject);
/* 370 */     } else if ("javax.xml.rpc.security.auth.password".equals(paramString)) {
/* 371 */       this.port.setPassword((String)paramObject);
/* 372 */     } else if ("weblogic.webservice.client.ssladapter".equals(paramString)) {
/* 373 */       BindingInfo bindingInfo = this.port.getBindingInfo();
/*     */       
/* 375 */       if (bindingInfo instanceof HttpsBindingInfo) {
/* 376 */         ((HttpsBindingInfo)bindingInfo).setSSLAdapter((SSLAdapter)paramObject);
/*     */       } else {
/* 378 */         throw new JAXRPCException("Can not set SSLAdapter on non https binding");
/*     */       }
/*     */     
/*     */     }
/* 382 */     else if ("javax.xml.rpc.soap.http.soapaction.uri".equals(paramString)) {
/* 383 */       this.operation.setSoapAction((String)paramObject);
/* 384 */     } else if ("javax.xml.rpc.soap.operation.style".equals(paramString)) {
/* 385 */       if ("document".equals((String)paramObject)) this.operation.setDocumentStyle(); 
/* 386 */       if ("rpc".equals((String)paramObject)) this.operation.setRpcStyle(); 
/* 387 */     } else if ("javax.xml.rpc.encodingstyle.namespace.uri".equals(paramString)) {
/* 388 */       this.operation.getInput().setEncodingStyle((String)paramObject);
/* 389 */       this.operation.getOutput().setEncodingStyle((String)paramObject);
/* 390 */     } else if ("weblogic.webservice.client.proxyusername".equals(paramString)) {
/* 391 */       this.port.setProxyUserName((String)paramObject);
/* 392 */     } else if ("weblogic.webservice.client.proxypassword".equals(paramString)) {
/* 393 */       this.port.setProxyPassword((String)paramObject);
/* 394 */     } else if ("javax.xml.rpc.session.maintain".equals(paramString)) {
/* 395 */       if (paramObject instanceof String) {
/* 396 */         this.port.setMaintainSession((new Boolean((String)paramObject)).booleanValue());
/* 397 */       } else if (paramObject instanceof Boolean) {
/* 398 */         this.port.setMaintainSession(((Boolean)paramObject).booleanValue());
/*     */       } 
/* 400 */     } else if ("weblogic.webservice.rpc.timeoutsecs".equals(paramString)) {
/* 401 */       BindingInfo bindingInfo = this.port.getBindingInfo();
/* 402 */       if (paramObject instanceof String) {
/* 403 */         bindingInfo.setTimeout(Integer.parseInt((String)paramObject));
/* 404 */       } else if (paramObject instanceof Integer) {
/* 405 */         bindingInfo.setTimeout(((Integer)paramObject).intValue());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeProperty(String paramString) {
/* 413 */     this.propertiesChanged = true;
/* 414 */     this.properties.remove(paramString);
/*     */   }
/*     */ 
/*     */   
/* 418 */   public Iterator getPropertyNames() { return this.properties.keySet().iterator(); }
/*     */ 
/*     */ 
/*     */   
/* 422 */   public Object invoke(Object[] paramArrayOfObject) { return invoke(paramArrayOfObject, false); }
/*     */ 
/*     */ 
/*     */   
/* 426 */   private void forceOperationLookup() { getOperation(); }
/*     */ 
/*     */ 
/*     */   
/*     */   private Operation getOperation() {
/* 431 */     if (this.operation != null && !this.changed) {
/*     */       
/* 433 */       if (this.propertiesChanged == true) {
/* 434 */         populateProperties(this.operation);
/* 435 */         this.propertiesChanged = false;
/*     */       } 
/*     */       
/* 438 */       return this.operation;
/*     */     } 
/*     */     
/* 441 */     if (this.name == null) {
/* 442 */       throw new JAXRPCException("operation name not set");
/*     */     }
/*     */ 
/*     */     
/* 446 */     if (this.serviceImpl.isCreatedFromWSDL()) {
/* 447 */       if (this.portName == null) {
/* 448 */         throw new JAXRPCException("port name not set");
/*     */       }
/*     */       
/* 451 */       this.port = this.serviceImpl._getPort(this.portName.getLocalPart());
/*     */       
/* 453 */       if (this.port == null) {
/* 454 */         throw new JAXRPCException("unable to find port : " + this.portName);
/*     */       }
/*     */       
/* 457 */       this.endpoint = this.port.getBindingInfo().getAddress();
/* 458 */       this.operation = this.port.getOperation(this.name.getLocalPart());
/*     */       
/* 460 */       if (this.operation == null) {
/* 461 */         throw new JAXRPCException("Unable to find operation '" + this.operation + "' in port '" + this.port.getName() + "'. Please check the WSDL");
/*     */       }
/*     */     } else {
/*     */       
/* 465 */       String str = (this.port != null) ? this.port.getSessionID() : null;
/*     */       
/* 467 */       WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
/* 468 */       WebService webService = webServiceFactory.create();
/*     */ 
/*     */       
/* 471 */       this.port = webService.addPort((this.portName == null) ? "unnamedPort" : this.portName.getLocalPart(), this.serviceImpl.getHandlerRegistry());
/*     */ 
/*     */       
/* 474 */       this.port.setSessionID(str);
/*     */       
/* 476 */       if (this.endpoint.startsWith("https")) {
/* 477 */         this.port.setBindingInfo(new HttpsBindingInfo());
/*     */       } else {
/* 479 */         this.port.setBindingInfo(new BindingInfo());
/*     */       } 
/*     */       
/* 482 */       this.port.getBindingInfo().setAddress(getTargetEndpointAddress());
/*     */       
/* 484 */       this.operation = this.port.addOperation(this.name.getLocalPart());
/* 485 */       this.operation.setNamespace(this.name.getNamespaceURI());
/* 486 */       this.operation.getInput().setNamespace(this.name.getNamespaceURI());
/* 487 */       this.operation.getOutput().setNamespace(this.name.getNamespaceURI());
/*     */       
/* 489 */       this.operation.getInput().setTypeMappingRegistry(this.serviceImpl.getTypeMappingRegistry());
/*     */ 
/*     */       
/* 492 */       this.operation.getOutput().setTypeMappingRegistry(this.serviceImpl.getTypeMappingRegistry());
/*     */ 
/*     */       
/* 495 */       fillParameter(this.operation);
/*     */     } 
/*     */     
/* 498 */     populateProperties(this.operation);
/*     */     
/* 500 */     return this.operation;
/*     */   }
/*     */ 
/*     */   
/*     */   private void fillParameter(Operation paramOperation) {
/* 505 */     TypeMapping typeMapping = this.serviceImpl.getTypeMappingRegistry().getTypeMapping(this.encodingStyle);
/*     */ 
/*     */     
/* 508 */     if (typeMapping == null) {
/* 509 */       throw new JAXRPCException("encoding style '" + this.encodingStyle + "' " + " is not registered with the type mapping registry.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 514 */     for (ParameterInfo parameterInfo : this.parameters) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 519 */       if (ParameterMode.IN.equals(parameterInfo.mode)) {
/* 520 */         Part part = addPart(paramOperation.getInput(), parameterInfo);
/* 521 */         part.setMode(Part.Mode.IN);
/* 522 */         part.setTypeMapping(typeMapping);
/*     */       } 
/*     */       
/* 525 */       if (ParameterMode.OUT.equals(parameterInfo.mode)) {
/* 526 */         Part part = addPart(paramOperation.getOutput(), parameterInfo);
/* 527 */         part.setMode(Part.Mode.OUT);
/* 528 */         part.setTypeMapping(typeMapping);
/*     */       } 
/*     */       
/* 531 */       if (ParameterMode.INOUT.equals(parameterInfo.mode)) {
/* 532 */         Part part = addPart(paramOperation.getInput(), parameterInfo);
/* 533 */         part.setMode(Part.Mode.INOUT);
/* 534 */         part.setTypeMapping(typeMapping);
/* 535 */         part = addPart(paramOperation.getOutput(), parameterInfo);
/* 536 */         part.setMode(Part.Mode.INOUT);
/* 537 */         part.setTypeMapping(typeMapping);
/*     */       } 
/*     */     } 
/*     */     
/* 541 */     if (this.returnInfo != null) {
/* 542 */       Part part = addPart(paramOperation.getOutput(), this.returnInfo);
/* 543 */       part.setMode(Part.Mode.RETURN);
/* 544 */       part.setTypeMapping(typeMapping);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Part addPart(Message paramMessage, ParameterInfo paramParameterInfo) {
/* 549 */     Part part = null;
/*     */     
/* 551 */     if (paramParameterInfo.javaType == null) {
/* 552 */       part = paramMessage.addPart(paramParameterInfo.name, paramParameterInfo.xmlType.getLocalPart(), paramParameterInfo.xmlType.getNamespaceURI());
/*     */     } else {
/*     */       
/* 555 */       part = paramMessage.addPart(paramParameterInfo.name, paramParameterInfo.xmlType.getLocalPart(), paramParameterInfo.xmlType.getNamespaceURI(), paramParameterInfo.javaType);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 560 */     return part;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object invoke(Object[] paramArrayOfObject, boolean paramBoolean) {
/*     */     try {
/* 566 */       Operation operation1 = getOperation();
/* 567 */       operation1.setOneway(paramBoolean);
/* 568 */       this.lastResult = new HashMap();
/* 569 */       Object object = operation1.invoke(this.lastResult, paramArrayOfObject);
/* 570 */       return paramBoolean ? null : object;
/* 571 */     } catch (TargetInvocationException targetInvocationException1) {
/* 572 */       TargetInvocationException targetInvocationException2 = targetInvocationException1.getCause();
/*     */       
/* 574 */       if (targetInvocationException2 == null) {
/* 575 */         targetInvocationException2 = targetInvocationException1;
/*     */       }
/*     */       
/* 578 */       throw new JAXRPCException("failed to invoke operation '" + this.operation.getName() + "' due to an error in the " + "backend compoent; nested exception is: " + toString(targetInvocationException1), targetInvocationException2);
/*     */ 
/*     */     
/*     */     }
/* 582 */     catch (SOAPException sOAPException) {
/* 583 */       Throwable throwable = sOAPException.getCause();
/*     */       
/* 585 */       if (throwable == null) {
/* 586 */         throwable = sOAPException;
/*     */       }
/*     */       
/* 589 */       throw new JAXRPCException("failed to invoke operation '" + this.operation.getName() + "' due to an error in the " + "soap layer (SAAJ); nested exception is: " + toString(sOAPException), throwable);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 594 */     catch (IOException iOException) {
/* 595 */       throw new JAXRPCException("failed to invoke operation '" + this.operation.getName() + "' due to an error in the " + "transport layer; nested exception is: " + toString(iOException), iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String toString(Throwable paramThrowable) {
/* 602 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 603 */     PrintStream printStream = new PrintStream(byteArrayOutputStream);
/* 604 */     printStream.print("Message[" + paramThrowable.getMessage() + "]");
/* 605 */     printStream.println("StackTrace[\n");
/* 606 */     paramThrowable.printStackTrace(printStream);
/* 607 */     printStream.println("]");
/* 608 */     printStream.flush();
/* 609 */     return new String(byteArrayOutputStream.toByteArray());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(QName paramQName, Object[] paramArrayOfObject) throws JAXRPCException {
/* 615 */     setOperationName(paramQName);
/* 616 */     return invoke(paramArrayOfObject);
/*     */   }
/*     */ 
/*     */   
/* 620 */   public void invokeOneWay(Object[] paramArrayOfObject) throws JAXRPCException { invoke(paramArrayOfObject, true); }
/*     */ 
/*     */ 
/*     */   
/*     */   public List getOutputValues() throws JAXRPCException {
/* 625 */     Map map = getOutputParams();
/*     */     
/* 627 */     if (map == null) {
/* 628 */       return null;
/*     */     }
/*     */     
/* 631 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 633 */     for (Iterator iterator = map.values().iterator(); iterator.hasNext();) {
/* 634 */       arrayList.add(iterator.next());
/*     */     }
/*     */     
/* 637 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/* 641 */   public Map getOutputParams() throws JAXRPCException { return this.lastResult; }
/*     */   
/*     */   static class ParameterInfo {
/*     */     String name;
/*     */     QName xmlType;
/*     */     Class javaType;
/*     */     ParameterMode mode;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\rpc\CallImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */