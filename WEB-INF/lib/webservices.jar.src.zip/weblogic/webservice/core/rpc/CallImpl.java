package weblogic.webservice.core.rpc;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.soap.SOAPException;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceFactory;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.binding.https.HttpsBindingInfo;
import weblogic.webservice.client.SSLAdapter;
import weblogic.webservice.extensions.WLCall;
import weblogic.xml.schema.binding.util.StdNamespace;

public class CallImpl implements WLCall {
  private WebService webservice;
  
  private Operation operation;
  
  private Port port;
  
  private QName name;
  
  private QName portName;
  
  private String endpoint;
  
  private String encodingStyle;
  
  private boolean changed;
  
  private boolean propertiesChanged;
  
  private HashMap properties;
  
  private ArrayList parameters;
  
  private ParameterInfo returnInfo;
  
  private Map lastResult;
  
  private ServiceImpl serviceImpl;
  
  private static final String SSL_ADAPTER = "weblogic.webservice.client.ssladapter";
  
  private static final String TIMEOUT = "weblogic.webservice.rpc.timeoutsecs";
  
  private static final String PROXY_USERNAME = "weblogic.webservice.client.proxyusername";
  
  private static final String PROXY_PASSWORD = "weblogic.webservice.client.proxypassword";
  
  private static ArrayList validProperties = new ArrayList();
  
  static  {
    validProperties.add("javax.xml.rpc.security.auth.username");
    validProperties.add("javax.xml.rpc.security.auth.password");
    validProperties.add("javax.xml.rpc.soap.operation.style");
    validProperties.add("javax.xml.rpc.soap.http.soapaction.use");
    validProperties.add("javax.xml.rpc.soap.http.soapaction.uri");
    validProperties.add("javax.xml.rpc.encodingstyle.namespace.uri");
    validProperties.add("javax.xml.rpc.session.maintain");
    validProperties.add("weblogic.webservice.client.ssladapter");
    validProperties.add("weblogic.webservice.client.proxyusername");
    validProperties.add("weblogic.webservice.client.proxypassword");
    validProperties.add("weblogic.webservice.rpc.timeoutsecs");
  }
  
  CallImpl(ServiceImpl paramServiceImpl) {
    this.encodingStyle = StdNamespace.instance().soapEncoding();
    this.changed = false;
    this.propertiesChanged = false;
    this.properties = new HashMap();
    this.parameters = new ArrayList();
    this.lastResult = new HashMap();
    this.serviceImpl = paramServiceImpl;
  }
  
  public boolean isParameterAndReturnSpecRequired(QName paramQName) {
    if (!this.serviceImpl.isCreatedFromWSDL())
      return true; 
    if (this.portName == null)
      return true; 
    Port port1 = this.serviceImpl._getPort(this.portName.getLocalPart());
    if (port1 == null)
      return true; 
    if (port1.getOperation(paramQName.getLocalPart()) == null)
      return true; 
    return false;
  }
  
  public void addParameter(String paramString, QName paramQName, Class paramClass, ParameterMode paramParameterMode) throws JAXRPCException {
    markChanged();
    ParameterInfo parameterInfo = new ParameterInfo();
    parameterInfo.name = paramString;
    parameterInfo.xmlType = paramQName;
    parameterInfo.javaType = paramClass;
    parameterInfo.mode = paramParameterMode;
    this.parameters.add(parameterInfo);
  }
  
  public void addParameter(String paramString, QName paramQName, ParameterMode paramParameterMode) throws JAXRPCException { addParameter(paramString, paramQName, null, paramParameterMode); }
  
  public QName getParameterTypeByName(String paramString) {
    for (ParameterInfo parameterInfo : this.parameters) {
      if (paramString.equals(parameterInfo.name))
        return parameterInfo.xmlType; 
    } 
    if (this.name != null) {
      forceOperationLookup();
      Part part = getPart(paramString);
      return part.getXMLType();
    } 
    return null;
  }
  
  public Iterator getParameterNames() {
    forceOperationLookup();
    ArrayList arrayList = new ArrayList();
    Iterator iterator;
    for (iterator = this.operation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      arrayList.add(part.getName());
    } 
    for (iterator = this.operation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.OUT)
        arrayList.add(part.getName()); 
    } 
    return arrayList.iterator();
  }
  
  private Part getPart(String paramString) {
    Part part = this.operation.getInput().getPart(paramString);
    if (part == null)
      part = this.operation.getOutput().getPart(paramString); 
    if (part == null)
      throw new JAXRPCException("unable to find part: '" + paramString + "' for operation '" + this.operation + "'. Please check WSDL"); 
    return part;
  }
  
  public Class getParameterJavaType(String paramString) {
    forceOperationLookup();
    Part part = getPart(paramString);
    return part.getJavaType();
  }
  
  public ParameterMode getParameterMode(String paramString) {
    forceOperationLookup();
    Part part = getPart(paramString);
    Part.Mode mode = part.getMode();
    if (Part.Mode.IN == mode)
      return ParameterMode.IN; 
    if (Part.Mode.OUT == mode)
      return ParameterMode.OUT; 
    if (Part.Mode.INOUT == mode)
      return ParameterMode.INOUT; 
    throw new JAXRPCException("unknown parameter mode for part:" + paramString);
  }
  
  public void setReturnType(QName paramQName, Class paramClass) throws JAXRPCException {
    markChanged();
    this.returnInfo = new ParameterInfo();
    String str = "__bea_noname_result";
    this.returnInfo.name = str;
    this.returnInfo.xmlType = paramQName;
    this.returnInfo.javaType = paramClass;
  }
  
  public void setReturnType(QName paramQName) throws JAXRPCException { setReturnType(paramQName, null); }
  
  public QName getReturnType() {
    if (this.returnInfo == null) {
      if (this.name != null)
        forceOperationLookup(); 
      if (this.operation != null) {
        Part part = this.operation.getReturnPart();
        if (part != null)
          return part.getXMLType(); 
      } 
    } else {
      return this.returnInfo.xmlType;
    } 
    return null;
  }
  
  public void removeAllParameters() {
    markChanged();
    this.parameters.clear();
  }
  
  private void markChanged() {
    if (this.serviceImpl.isCreatedFromWSDL())
      throw new JAXRPCException("This call is created from WSDL, you can not add/remove parameters or return type from this call"); 
    this.changed = true;
  }
  
  public QName getOperationName() { return this.name; }
  
  public void setOperationName(QName paramQName) throws JAXRPCException {
    this.name = paramQName;
    this.changed = true;
  }
  
  public QName getPortTypeName() {
    if (this.portName == null)
      return new QName(""); 
    return this.portName;
  }
  
  public void setPortTypeName(QName paramQName) throws JAXRPCException {
    if (paramQName == null)
      throw new IllegalArgumentException("port name can not be null"); 
    this.portName = paramQName;
    this.changed = true;
  }
  
  public void setTargetEndpointAddress(String paramString) {
    this.endpoint = paramString;
    this.changed = true;
  }
  
  public String getTargetEndpointAddress() { return this.endpoint; }
  
  private boolean isValidProperty(String paramString) { return validProperties.contains(paramString); }
  
  public void setProperty(String paramString, Object paramObject) throws JAXRPCException {
    if (!isValidProperty(paramString))
      throw new JAXRPCException("unknown property: " + paramString); 
    this.properties.put(paramString, paramObject);
    this.propertiesChanged = true;
  }
  
  public Object getProperty(String paramString) {
    if (!isValidProperty(paramString))
      throw new JAXRPCException("unknown property: " + paramString); 
    return this.properties.get(paramString);
  }
  
  private void populateProperties(Operation paramOperation) {
    if (this.port == null || paramOperation == null)
      throw new IllegalArgumentException("port/operation can not be null"); 
    for (String str : this.properties.keySet()) {
      Object object = this.properties.get(str);
      setPropertyInternal(str, object);
    } 
  }
  
  private void setPropertyInternal(String paramString, Object paramObject) throws JAXRPCException {
    if ("javax.xml.rpc.security.auth.username".equals(paramString)) {
      this.port.setUserName((String)paramObject);
    } else if ("javax.xml.rpc.security.auth.password".equals(paramString)) {
      this.port.setPassword((String)paramObject);
    } else if ("weblogic.webservice.client.ssladapter".equals(paramString)) {
      BindingInfo bindingInfo = this.port.getBindingInfo();
      if (bindingInfo instanceof HttpsBindingInfo) {
        ((HttpsBindingInfo)bindingInfo).setSSLAdapter((SSLAdapter)paramObject);
      } else {
        throw new JAXRPCException("Can not set SSLAdapter on non https binding");
      } 
    } else if ("javax.xml.rpc.soap.http.soapaction.uri".equals(paramString)) {
      this.operation.setSoapAction((String)paramObject);
    } else if ("javax.xml.rpc.soap.operation.style".equals(paramString)) {
      if ("document".equals((String)paramObject))
        this.operation.setDocumentStyle(); 
      if ("rpc".equals((String)paramObject))
        this.operation.setRpcStyle(); 
    } else if ("javax.xml.rpc.encodingstyle.namespace.uri".equals(paramString)) {
      this.operation.getInput().setEncodingStyle((String)paramObject);
      this.operation.getOutput().setEncodingStyle((String)paramObject);
    } else if ("weblogic.webservice.client.proxyusername".equals(paramString)) {
      this.port.setProxyUserName((String)paramObject);
    } else if ("weblogic.webservice.client.proxypassword".equals(paramString)) {
      this.port.setProxyPassword((String)paramObject);
    } else if ("javax.xml.rpc.session.maintain".equals(paramString)) {
      if (paramObject instanceof String) {
        this.port.setMaintainSession((new Boolean((String)paramObject)).booleanValue());
      } else if (paramObject instanceof Boolean) {
        this.port.setMaintainSession(((Boolean)paramObject).booleanValue());
      } 
    } else if ("weblogic.webservice.rpc.timeoutsecs".equals(paramString)) {
      BindingInfo bindingInfo = this.port.getBindingInfo();
      if (paramObject instanceof String) {
        bindingInfo.setTimeout(Integer.parseInt((String)paramObject));
      } else if (paramObject instanceof Integer) {
        bindingInfo.setTimeout(((Integer)paramObject).intValue());
      } 
    } 
  }
  
  public void removeProperty(String paramString) {
    this.propertiesChanged = true;
    this.properties.remove(paramString);
  }
  
  public Iterator getPropertyNames() { return this.properties.keySet().iterator(); }
  
  public Object invoke(Object[] paramArrayOfObject) { return invoke(paramArrayOfObject, false); }
  
  private void forceOperationLookup() { getOperation(); }
  
  private Operation getOperation() {
    if (this.operation != null && !this.changed) {
      if (this.propertiesChanged == true) {
        populateProperties(this.operation);
        this.propertiesChanged = false;
      } 
      return this.operation;
    } 
    if (this.name == null)
      throw new JAXRPCException("operation name not set"); 
    if (this.serviceImpl.isCreatedFromWSDL()) {
      if (this.portName == null)
        throw new JAXRPCException("port name not set"); 
      this.port = this.serviceImpl._getPort(this.portName.getLocalPart());
      if (this.port == null)
        throw new JAXRPCException("unable to find port : " + this.portName); 
      this.endpoint = this.port.getBindingInfo().getAddress();
      this.operation = this.port.getOperation(this.name.getLocalPart());
      if (this.operation == null)
        throw new JAXRPCException("Unable to find operation '" + this.operation + "' in port '" + this.port.getName() + "'. Please check the WSDL"); 
    } else {
      String str = (this.port != null) ? this.port.getSessionID() : null;
      WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
      WebService webService = webServiceFactory.create();
      this.port = webService.addPort((this.portName == null) ? "unnamedPort" : this.portName.getLocalPart(), this.serviceImpl.getHandlerRegistry());
      this.port.setSessionID(str);
      if (this.endpoint.startsWith("https")) {
        this.port.setBindingInfo(new HttpsBindingInfo());
      } else {
        this.port.setBindingInfo(new BindingInfo());
      } 
      this.port.getBindingInfo().setAddress(getTargetEndpointAddress());
      this.operation = this.port.addOperation(this.name.getLocalPart());
      this.operation.setNamespace(this.name.getNamespaceURI());
      this.operation.getInput().setNamespace(this.name.getNamespaceURI());
      this.operation.getOutput().setNamespace(this.name.getNamespaceURI());
      this.operation.getInput().setTypeMappingRegistry(this.serviceImpl.getTypeMappingRegistry());
      this.operation.getOutput().setTypeMappingRegistry(this.serviceImpl.getTypeMappingRegistry());
      fillParameter(this.operation);
    } 
    populateProperties(this.operation);
    return this.operation;
  }
  
  private void fillParameter(Operation paramOperation) {
    TypeMapping typeMapping = this.serviceImpl.getTypeMappingRegistry().getTypeMapping(this.encodingStyle);
    if (typeMapping == null)
      throw new JAXRPCException("encoding style '" + this.encodingStyle + "' " + " is not registered with the type mapping registry."); 
    for (ParameterInfo parameterInfo : this.parameters) {
      if (ParameterMode.IN.equals(parameterInfo.mode)) {
        Part part = addPart(paramOperation.getInput(), parameterInfo);
        part.setMode(Part.Mode.IN);
        part.setTypeMapping(typeMapping);
      } 
      if (ParameterMode.OUT.equals(parameterInfo.mode)) {
        Part part = addPart(paramOperation.getOutput(), parameterInfo);
        part.setMode(Part.Mode.OUT);
        part.setTypeMapping(typeMapping);
      } 
      if (ParameterMode.INOUT.equals(parameterInfo.mode)) {
        Part part = addPart(paramOperation.getInput(), parameterInfo);
        part.setMode(Part.Mode.INOUT);
        part.setTypeMapping(typeMapping);
        part = addPart(paramOperation.getOutput(), parameterInfo);
        part.setMode(Part.Mode.INOUT);
        part.setTypeMapping(typeMapping);
      } 
    } 
    if (this.returnInfo != null) {
      Part part = addPart(paramOperation.getOutput(), this.returnInfo);
      part.setMode(Part.Mode.RETURN);
      part.setTypeMapping(typeMapping);
    } 
  }
  
  private Part addPart(Message paramMessage, ParameterInfo paramParameterInfo) {
    Part part = null;
    if (paramParameterInfo.javaType == null) {
      part = paramMessage.addPart(paramParameterInfo.name, paramParameterInfo.xmlType.getLocalPart(), paramParameterInfo.xmlType.getNamespaceURI());
    } else {
      part = paramMessage.addPart(paramParameterInfo.name, paramParameterInfo.xmlType.getLocalPart(), paramParameterInfo.xmlType.getNamespaceURI(), paramParameterInfo.javaType);
    } 
    return part;
  }
  
  private Object invoke(Object[] paramArrayOfObject, boolean paramBoolean) {
    try {
      Operation operation1 = getOperation();
      operation1.setOneway(paramBoolean);
      this.lastResult = new HashMap();
      Object object = operation1.invoke(this.lastResult, paramArrayOfObject);
      return paramBoolean ? null : object;
    } catch (TargetInvocationException targetInvocationException1) {
      TargetInvocationException targetInvocationException2 = targetInvocationException1.getCause();
      if (targetInvocationException2 == null)
        targetInvocationException2 = targetInvocationException1; 
      throw new JAXRPCException("failed to invoke operation '" + this.operation.getName() + "' due to an error in the " + "backend compoent; nested exception is: " + toString(targetInvocationException1), targetInvocationException2);
    } catch (SOAPException sOAPException) {
      Throwable throwable = sOAPException.getCause();
      if (throwable == null)
        throwable = sOAPException; 
      throw new JAXRPCException("failed to invoke operation '" + this.operation.getName() + "' due to an error in the " + "soap layer (SAAJ); nested exception is: " + toString(sOAPException), throwable);
    } catch (IOException iOException) {
      throw new JAXRPCException("failed to invoke operation '" + this.operation.getName() + "' due to an error in the " + "transport layer; nested exception is: " + toString(iOException), iOException);
    } 
  }
  
  private String toString(Throwable paramThrowable) {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(byteArrayOutputStream);
    printStream.print("Message[" + paramThrowable.getMessage() + "]");
    printStream.println("StackTrace[\n");
    paramThrowable.printStackTrace(printStream);
    printStream.println("]");
    printStream.flush();
    return new String(byteArrayOutputStream.toByteArray());
  }
  
  public Object invoke(QName paramQName, Object[] paramArrayOfObject) throws JAXRPCException {
    setOperationName(paramQName);
    return invoke(paramArrayOfObject);
  }
  
  public void invokeOneWay(Object[] paramArrayOfObject) throws JAXRPCException { invoke(paramArrayOfObject, true); }
  
  public List getOutputValues() throws JAXRPCException {
    Map map = getOutputParams();
    if (map == null)
      return null; 
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = map.values().iterator(); iterator.hasNext();)
      arrayList.add(iterator.next()); 
    return arrayList;
  }
  
  public Map getOutputParams() throws JAXRPCException { return this.lastResult; }
  
  static class ParameterInfo {
    String name;
    
    QName xmlType;
    
    Class javaType;
    
    ParameterMode mode;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\rpc\CallImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */