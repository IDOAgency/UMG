/*     */ package weblogic.webservice.core.rpc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.rmi.Remote;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.naming.Reference;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.Call;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import javax.xml.rpc.Stub;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import javax.xml.rpc.handler.HandlerRegistry;
/*     */ import weblogic.net.http.Handler;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceFactory;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.core.encoding.DefaultRegistry;
/*     */ import weblogic.webservice.core.handler.HandlerRegistryImpl;
/*     */ import weblogic.webservice.extensions.WLService;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceImpl
/*     */   implements WLService
/*     */ {
/*     */   public static final String WLS_URL_STREAM_HANDLER = "weblogic.webservice.UseWebLogicURLStreamHandler";
/*     */   private WebService webservice;
/*     */   private TypeMappingRegistry registry;
/*     */   private String wsdlLocation;
/*     */   private boolean createdFromWSDL;
/*  61 */   private HandlerRegistry handlerRegistry = new HandlerRegistryImpl();
/*     */ 
/*     */   
/*  64 */   ServiceImpl(String paramString) throws IOException, JAXRPCException { this(paramString, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected ServiceImpl(String paramString1, String paramString2) throws IOException, JAXRPCException { this(paramString1, paramString2, null); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServiceImpl(String paramString1, String paramString2, String paramString3) throws IOException, JAXRPCException {
/*     */     try {
/*  75 */       if (Boolean.getBoolean("weblogic.webservice.UseWebLogicURLStreamHandler")) {
/*  76 */         Handler.init();
/*     */       }
/*  78 */     } catch (SecurityException securityException) {}
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.wsdlLocation = paramString1;
/*  83 */     this.createdFromWSDL = true;
/*  84 */     WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
/*     */     
/*  86 */     if (paramString2 == null) {
/*  87 */       this.registry = new DefaultRegistry();
/*     */     }
/*     */     else {
/*     */       
/*  91 */       this.registry = new DefaultRegistry(paramString2);
/*     */ 
/*     */       
/*  94 */       this.webservice = webServiceFactory.createFromWSDL(paramString1, paramString3, this.registry);
/*     */     } 
/*     */   }
/*     */   
/*     */   ServiceImpl(QName paramQName) {
/*  99 */     if (Boolean.getBoolean("weblogic.webservice.UseWebLogicURLStreamHandler")) {
/* 100 */       Handler.init();
/*     */     }
/* 102 */     this.registry = new DefaultRegistry();
/* 103 */     this.createdFromWSDL = false;
/*     */     
/* 105 */     WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
/* 106 */     this.webservice = webServiceFactory.create();
/*     */     
/* 108 */     this.webservice.setTargetNamespace(paramQName.getNamespaceURI());
/* 109 */     this.webservice.setName(paramQName.getLocalPart());
/* 110 */     this.webservice.setTypeMappingRegistry(this.registry);
/*     */   }
/*     */ 
/*     */   
/*     */   WebService getWebService() {
/* 115 */     if (this.webservice == null) {
/*     */       
/* 117 */       if (this.wsdlLocation == null) {
/* 118 */         throw new JAXRPCException("WSDL location can not be null");
/*     */       }
/*     */       
/* 121 */       WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
/*     */       
/*     */       try {
/* 124 */         this.webservice = webServiceFactory.createFromWSDL(this.wsdlLocation, this.registry);
/* 125 */       } catch (IOException iOException) {
/* 126 */         throw new JAXRPCException("failed to create service", iOException);
/*     */       } 
/*     */     } 
/*     */     
/* 130 */     return this.webservice;
/*     */   }
/*     */ 
/*     */   
/* 134 */   boolean isCreatedFromWSDL() { return this.createdFromWSDL; }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 140 */     stringBuffer.append("ServiceImpl[\n");
/* 141 */     stringBuffer.append(getWebService());
/* 142 */     stringBuffer.append("]\n");
/*     */     
/* 144 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public Reference getReference() { throw new Error("NYI"); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Port _getPort(String paramString) {
/* 157 */     Port port = getWebService().getPort(paramString);
/*     */     
/* 159 */     if (port == null) {
/* 160 */       throw new JAXRPCException("unable to find port:" + paramString + " This may be because the WSDL file and the generated stub is out " + " sync. Doing clientgen again may fix this problem.");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 165 */     port.setHandlerRegistry(this.handlerRegistry);
/*     */     
/* 167 */     return port;
/*     */   }
/*     */ 
/*     */   
/*     */   public Remote getPort(QName paramQName, Class paramClass) throws ServiceException {
/* 172 */     if (paramQName == null) {
/* 173 */       throw new ServiceException("QName can not be null");
/*     */     }
/*     */     
/* 176 */     Port port = null;
/*     */     
/*     */     try {
/* 179 */       port = _getPort(paramQName.getLocalPart());
/* 180 */     } catch (JAXRPCException jAXRPCException) {
/* 181 */       throw new ServiceException(jAXRPCException);
/*     */     } 
/*     */     
/*     */     try {
/* 185 */       return (Remote)StubImpl.implementInterface(paramClass, port);
/* 186 */     } catch (IOException iOException) {
/* 187 */       throw new ServiceException("unable to create run time proxy:" + iOException, iOException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Remote getPort(Class paramClass) throws ServiceException {
/* 192 */     Iterator iterator = getWebService().getPorts();
/*     */ 
/*     */     
/* 195 */     if (iterator.hasNext()) {
/* 196 */       Port port = (Port)iterator.next();
/* 197 */       return getPort(new QName(port.getTypeName()), paramClass);
/*     */     } 
/*     */     
/* 200 */     throw new ServiceException("unable to find port for:" + paramClass);
/*     */   }
/*     */ 
/*     */   
/* 204 */   public HandlerRegistry getHandlerRegistry() { return this.handlerRegistry; }
/*     */ 
/*     */ 
/*     */   
/*     */   private Port _getPortForType(QName paramQName) throws ServiceException {
/* 209 */     for (Iterator iterator = getWebService().getPorts(); iterator.hasNext(); ) {
/* 210 */       Port port = (Port)iterator.next();
/*     */       
/* 212 */       if (paramQName.getLocalPart().equals(port.getTypeName())) {
/* 213 */         return port;
/*     */       }
/*     */     } 
/*     */     
/* 217 */     throw new ServiceException("Unable to find portType:" + paramQName + ". Check the WSDL file to find out the right portType name");
/*     */   }
/*     */ 
/*     */   
/*     */   public Call createCall(QName paramQName) throws JAXRPCException {
/* 222 */     Call call = createCall();
/* 223 */     call.setPortTypeName(paramQName);
/* 224 */     return call;
/*     */   }
/*     */ 
/*     */   
/* 228 */   public Call createCall(QName paramQName, String paramString) throws JAXRPCException { return createCall(paramQName, new QName(null, paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call createCall(QName paramQName1, QName paramQName2) throws JAXRPCException {
/* 234 */     Call call = createCall();
/* 235 */     call.setPortTypeName(paramQName1);
/* 236 */     call.setOperationName(paramQName2);
/*     */     
/* 238 */     return call;
/*     */   }
/*     */ 
/*     */   
/* 242 */   public Call createCall() throws JAXRPCException { return new CallImpl(this); }
/*     */ 
/*     */ 
/*     */   
/* 246 */   public QName getServiceName() { return new QName(getWebService().getTargetNamespace(), getWebService().getName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getPorts() throws ServiceException {
/* 252 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 254 */     for (Iterator iterator = getWebService().getPorts(); iterator.hasNext(); ) {
/* 255 */       Port port = (Port)iterator.next();
/* 256 */       arrayList.add(new QName(null, port.getName()));
/*     */     } 
/*     */     
/* 259 */     if (arrayList.size() == 0) {
/* 260 */       throw new ServiceException("Unable to find port in this web service. Make sure that you have provided the right WSDL url");
/*     */     }
/*     */ 
/*     */     
/* 264 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   public URL getWSDLDocumentLocation() {
/*     */     try {
/* 269 */       return (this.wsdlLocation == null) ? null : new URL(this.wsdlLocation);
/* 270 */     } catch (IOException iOException) {
/* 271 */       throw new IllegalArgumentException("unable to create URL : " + this.wsdlLocation);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) throws JAXRPCException { this.registry = paramTypeMappingRegistry; }
/*     */ 
/*     */ 
/*     */   
/* 283 */   public TypeMappingRegistry getTypeMappingRegistry() throws JAXRPCException { return this.registry; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call[] getCalls(QName paramQName) throws ServiceException {
/* 289 */     if (paramQName == null) {
/* 290 */       throw new ServiceException("portName can not be null");
/*     */     }
/*     */     
/* 293 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 295 */     Port port = null;
/*     */     
/*     */     try {
/* 298 */       port = _getPort(paramQName.getLocalPart());
/* 299 */     } catch (JAXRPCException jAXRPCException) {
/* 300 */       throw new ServiceException(jAXRPCException);
/*     */     } 
/*     */     
/* 303 */     for (Iterator iterator = port.getOperations(); iterator.hasNext(); ) {
/* 304 */       Operation operation = (Operation)iterator.next();
/*     */       
/* 306 */       Call call = createCall(new QName(port.getTypeName()), new QName(operation.getNamespace(), operation.getName()));
/*     */ 
/*     */       
/* 309 */       arrayList.add(call);
/*     */     } 
/*     */     
/* 312 */     return (Call[])arrayList.toArray(new Call[arrayList.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _setUser(String paramString1, String paramString2, Object paramObject) {
/* 317 */     if (paramString1 == null) {
/* 318 */       throw new IllegalArgumentException("No username provided");
/*     */     }
/*     */     
/* 321 */     if (paramString2 == null) {
/* 322 */       throw new IllegalArgumentException("No password provided");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 330 */     if (paramObject == null || !(paramObject instanceof Stub)) {
/* 331 */       throw new IllegalArgumentException("Got a bad stub:" + paramObject);
/*     */     }
/*     */     
/* 334 */     Stub stub = (Stub)paramObject;
/* 335 */     stub._setProperty("javax.xml.rpc.security.auth.username", paramString1);
/* 336 */     stub._setProperty("javax.xml.rpc.security.auth.password", paramString2);
/*     */   }
/*     */ 
/*     */   
/* 340 */   public WebServiceContext context() { return this.webservice.context(); }
/*     */ 
/*     */ 
/*     */   
/* 344 */   public WebServiceContext joinContext() { return this.webservice.joinContext(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\rpc\ServiceImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */