package weblogic.webservice.core.rpc;

import java.io.IOException;
import java.net.URL;
import java.rmi.Remote;
import java.util.ArrayList;
import java.util.Iterator;
import javax.naming.Reference;
import javax.xml.namespace.QName;
import javax.xml.rpc.Call;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.Stub;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.handler.HandlerRegistry;
import weblogic.net.http.Handler;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceFactory;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.core.encoding.DefaultRegistry;
import weblogic.webservice.core.handler.HandlerRegistryImpl;
import weblogic.webservice.extensions.WLService;

public class ServiceImpl implements WLService {
  public static final String WLS_URL_STREAM_HANDLER = "weblogic.webservice.UseWebLogicURLStreamHandler";
  
  private WebService webservice;
  
  private TypeMappingRegistry registry;
  
  private String wsdlLocation;
  
  private boolean createdFromWSDL;
  
  private HandlerRegistry handlerRegistry = new HandlerRegistryImpl();
  
  ServiceImpl(String paramString) throws IOException, JAXRPCException { this(paramString, null); }
  
  protected ServiceImpl(String paramString1, String paramString2) throws IOException, JAXRPCException { this(paramString1, paramString2, null); }
  
  protected ServiceImpl(String paramString1, String paramString2, String paramString3) throws IOException, JAXRPCException {
    try {
      if (Boolean.getBoolean("weblogic.webservice.UseWebLogicURLStreamHandler"))
        Handler.init(); 
    } catch (SecurityException securityException) {}
    this.wsdlLocation = paramString1;
    this.createdFromWSDL = true;
    WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
    if (paramString2 == null) {
      this.registry = new DefaultRegistry();
    } else {
      this.registry = new DefaultRegistry(paramString2);
      this.webservice = webServiceFactory.createFromWSDL(paramString1, paramString3, this.registry);
    } 
  }
  
  ServiceImpl(QName paramQName) {
    if (Boolean.getBoolean("weblogic.webservice.UseWebLogicURLStreamHandler"))
      Handler.init(); 
    this.registry = new DefaultRegistry();
    this.createdFromWSDL = false;
    WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
    this.webservice = webServiceFactory.create();
    this.webservice.setTargetNamespace(paramQName.getNamespaceURI());
    this.webservice.setName(paramQName.getLocalPart());
    this.webservice.setTypeMappingRegistry(this.registry);
  }
  
  WebService getWebService() {
    if (this.webservice == null) {
      if (this.wsdlLocation == null)
        throw new JAXRPCException("WSDL location can not be null"); 
      WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
      try {
        this.webservice = webServiceFactory.createFromWSDL(this.wsdlLocation, this.registry);
      } catch (IOException iOException) {
        throw new JAXRPCException("failed to create service", iOException);
      } 
    } 
    return this.webservice;
  }
  
  boolean isCreatedFromWSDL() { return this.createdFromWSDL; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("ServiceImpl[\n");
    stringBuffer.append(getWebService());
    stringBuffer.append("]\n");
    return stringBuffer.toString();
  }
  
  public Reference getReference() { throw new Error("NYI"); }
  
  protected Port _getPort(String paramString) {
    Port port = getWebService().getPort(paramString);
    if (port == null)
      throw new JAXRPCException("unable to find port:" + paramString + " This may be because the WSDL file and the generated stub is out " + " sync. Doing clientgen again may fix this problem."); 
    port.setHandlerRegistry(this.handlerRegistry);
    return port;
  }
  
  public Remote getPort(QName paramQName, Class paramClass) throws ServiceException {
    if (paramQName == null)
      throw new ServiceException("QName can not be null"); 
    Port port = null;
    try {
      port = _getPort(paramQName.getLocalPart());
    } catch (JAXRPCException jAXRPCException) {
      throw new ServiceException(jAXRPCException);
    } 
    try {
      return (Remote)StubImpl.implementInterface(paramClass, port);
    } catch (IOException iOException) {
      throw new ServiceException("unable to create run time proxy:" + iOException, iOException);
    } 
  }
  
  public Remote getPort(Class paramClass) throws ServiceException {
    Iterator iterator = getWebService().getPorts();
    if (iterator.hasNext()) {
      Port port = (Port)iterator.next();
      return getPort(new QName(port.getTypeName()), paramClass);
    } 
    throw new ServiceException("unable to find port for:" + paramClass);
  }
  
  public HandlerRegistry getHandlerRegistry() { return this.handlerRegistry; }
  
  private Port _getPortForType(QName paramQName) throws ServiceException {
    for (Iterator iterator = getWebService().getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      if (paramQName.getLocalPart().equals(port.getTypeName()))
        return port; 
    } 
    throw new ServiceException("Unable to find portType:" + paramQName + ". Check the WSDL file to find out the right portType name");
  }
  
  public Call createCall(QName paramQName) throws JAXRPCException {
    Call call = createCall();
    call.setPortTypeName(paramQName);
    return call;
  }
  
  public Call createCall(QName paramQName, String paramString) throws JAXRPCException { return createCall(paramQName, new QName(null, paramString)); }
  
  public Call createCall(QName paramQName1, QName paramQName2) throws JAXRPCException {
    Call call = createCall();
    call.setPortTypeName(paramQName1);
    call.setOperationName(paramQName2);
    return call;
  }
  
  public Call createCall() throws JAXRPCException { return new CallImpl(this); }
  
  public QName getServiceName() { return new QName(getWebService().getTargetNamespace(), getWebService().getName()); }
  
  public Iterator getPorts() throws ServiceException {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = getWebService().getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      arrayList.add(new QName(null, port.getName()));
    } 
    if (arrayList.size() == 0)
      throw new ServiceException("Unable to find port in this web service. Make sure that you have provided the right WSDL url"); 
    return arrayList.iterator();
  }
  
  public URL getWSDLDocumentLocation() {
    try {
      return (this.wsdlLocation == null) ? null : new URL(this.wsdlLocation);
    } catch (IOException iOException) {
      throw new IllegalArgumentException("unable to create URL : " + this.wsdlLocation);
    } 
  }
  
  public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) throws JAXRPCException { this.registry = paramTypeMappingRegistry; }
  
  public TypeMappingRegistry getTypeMappingRegistry() throws JAXRPCException { return this.registry; }
  
  public Call[] getCalls(QName paramQName) throws ServiceException {
    if (paramQName == null)
      throw new ServiceException("portName can not be null"); 
    ArrayList arrayList = new ArrayList();
    Port port = null;
    try {
      port = _getPort(paramQName.getLocalPart());
    } catch (JAXRPCException jAXRPCException) {
      throw new ServiceException(jAXRPCException);
    } 
    for (Iterator iterator = port.getOperations(); iterator.hasNext(); ) {
      Operation operation = (Operation)iterator.next();
      Call call = createCall(new QName(port.getTypeName()), new QName(operation.getNamespace(), operation.getName()));
      arrayList.add(call);
    } 
    return (Call[])arrayList.toArray(new Call[arrayList.size()]);
  }
  
  protected void _setUser(String paramString1, String paramString2, Object paramObject) {
    if (paramString1 == null)
      throw new IllegalArgumentException("No username provided"); 
    if (paramString2 == null)
      throw new IllegalArgumentException("No password provided"); 
    if (paramObject == null || !(paramObject instanceof Stub))
      throw new IllegalArgumentException("Got a bad stub:" + paramObject); 
    Stub stub = (Stub)paramObject;
    stub._setProperty("javax.xml.rpc.security.auth.username", paramString1);
    stub._setProperty("javax.xml.rpc.security.auth.password", paramString2);
  }
  
  public WebServiceContext context() { return this.webservice.context(); }
  
  public WebServiceContext joinContext() { return this.webservice.joinContext(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\rpc\ServiceImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */