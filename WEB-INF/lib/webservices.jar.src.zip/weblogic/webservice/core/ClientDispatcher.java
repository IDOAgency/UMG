/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.Detail;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.HandlerChain;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WLSOAPMessage;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.async.AsyncInfo;
/*     */ import weblogic.webservice.async.FutureResult;
/*     */ import weblogic.webservice.async.FutureResultImpl;
/*     */ import weblogic.webservice.async.InvokeCompletedEvent;
/*     */ import weblogic.webservice.async.ResultListener;
/*     */ import weblogic.webservice.async.ThreadPool;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.binding.BindingFactory;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.core.soap.NameImpl;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientDispatcher
/*     */ {
/*  64 */   private static ThreadPool threadPool = null;
/*     */   
/*     */   private Operation operation;
/*     */   
/*     */   private Map outParams;
/*     */   
/*     */   private PrintStream logStream;
/*     */   
/*     */   private HandlerChain chain;
/*     */   
/*     */   private FutureResultImpl futureResult;
/*     */   
/*     */   private AsyncInfo async;
/*     */   private WLMessageContext messageContext;
/*     */   private WebServiceContext wsContext;
/*     */   
/*     */   public ClientDispatcher(Operation paramOperation, Map paramMap, PrintStream paramPrintStream) {
/*  81 */     Debug.assertion((paramOperation != null));
/*  82 */     Debug.assertion((paramMap != null));
/*     */     
/*  84 */     this.operation = paramOperation;
/*  85 */     this.outParams = paramMap;
/*  86 */     this.logStream = paramPrintStream;
/*     */   }
/*     */   
/*     */   public ThreadPool getThreadPool() {
/*  90 */     if (threadPool == null) {
/*  91 */       threadPool = new ThreadPool(2);
/*     */     }
/*     */     
/*  94 */     return threadPool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FutureResult asyncDispatch(Object[] paramArrayOfObject, AsyncInfo paramAsyncInfo) throws SOAPException, IOException {
/* 101 */     this.async = paramAsyncInfo;
/* 102 */     this.futureResult = new FutureResultImpl();
/* 103 */     this.futureResult.setAsyncInfo(paramAsyncInfo);
/*     */     
/* 105 */     send(paramArrayOfObject);
/*     */     
/* 107 */     if (paramAsyncInfo == null || !paramAsyncInfo.isReliableDelivery())
/*     */     {
/* 109 */       getThreadPool().addTask(new Runnable() { private final ClientDispatcher this$0;
/*     */             
/* 111 */             public void run() { ClientDispatcher.this.callReceive(ClientDispatcher.this.messageContext); }
/*     */              }
/*     */         );
/*     */     }
/*     */     
/* 116 */     return this.futureResult;
/*     */   }
/*     */ 
/*     */   
/*     */   public void callReceive(WLMessageContext paramWLMessageContext) {
/*     */     try {
/* 122 */       Object object = receive(paramWLMessageContext);
/* 123 */       this.futureResult.setResult(object);
/* 124 */     } catch (Throwable throwable) {
/* 125 */       String str = WebServiceLogger.logClientDispatcherException();
/* 126 */       WebServiceLogger.logStackTrace(str, throwable);
/* 127 */       this.futureResult.setError(throwable);
/*     */     } 
/*     */     
/* 130 */     if (this.async != null) {
/* 131 */       ResultListener resultListener = this.async.getResultListener();
/*     */       
/* 133 */       if (resultListener != null) {
/* 134 */         InvokeCompletedEvent invokeCompletedEvent = new InvokeCompletedEvent(this.async.getCaller());
/*     */ 
/*     */         
/* 137 */         invokeCompletedEvent.setFutureResult(this.futureResult);
/* 138 */         resultListener.onCompletion(invokeCompletedEvent);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object dispatch(Object[] paramArrayOfObject) throws SOAPException, IOException, TargetInvocationException {
/* 146 */     send(paramArrayOfObject);
/* 147 */     return receive(this.messageContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public void send(Object[] paramArrayOfObject) throws SOAPException, IOException {
/* 152 */     this.messageContext = new DefaultMessageContext(this.operation);
/*     */     
/* 154 */     this.messageContext.setProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP", this.operation.getPort().getService());
/*     */ 
/*     */     
/* 157 */     BindingFactory bindingFactory = BindingFactory.getInstance();
/* 158 */     Binding binding = bindingFactory.create(this.operation.getPort().getBindingInfo());
/*     */ 
/*     */ 
/*     */     
/* 162 */     boolean bool1 = false;
/*     */     
/* 164 */     if (this.futureResult != null) {
/* 165 */       AsyncInfo asyncInfo = this.futureResult.getAsyncInfo();
/*     */       
/* 167 */       if (asyncInfo != null && asyncInfo.isReliableDelivery()) {
/*     */         
/* 169 */         bool1 = true;
/* 170 */         this.messageContext.setProperty("weblogic.webservice.core.client-dispatcher", this);
/*     */         
/* 172 */         this.messageContext.setProperty("__BEA_PRIVATE_FUTURE_RESULT_PROP", this.futureResult);
/*     */ 
/*     */         
/* 175 */         ResultListener resultListener = asyncInfo.getResultListener();
/*     */         
/* 177 */         if (resultListener != null && resultListener instanceof weblogic.webservice.ReliableDelivery)
/*     */         {
/*     */           
/* 180 */           this.messageContext.setProperty("__BEA_PRIVATE_RELIABLE_PROP", resultListener);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 186 */     this.wsContext = this.operation.getPort().getService().context();
/* 187 */     this.messageContext.setProperty("weblogic.webservice.context", this.wsContext);
/*     */     
/* 189 */     boolean bool2 = false;
/*     */     
/* 191 */     if (this.wsContext.getSession().getAttribute("weblogic.webservice.security.request") != null || this.operation.getPort().getService().getSecurity() != null)
/*     */     {
/*     */ 
/*     */       
/* 195 */       bool2 = true;
/*     */     }
/*     */     
/* 198 */     SOAPMessage sOAPMessage = this.messageContext.getMessage();
/*     */     
/* 200 */     if ("SOAP1.2".equals(this.operation.getPort().getBindingInfo().getType()))
/*     */     {
/*     */       
/* 203 */       ((WLSOAPMessage)sOAPMessage).setSOAP12();
/*     */     }
/*     */     
/* 206 */     MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
/*     */     
/* 208 */     ((DefaultOperation)this.operation).fillInHeaders(mimeHeaders);
/* 209 */     this.operation.getInput().toXML(sOAPMessage, paramArrayOfObject, this.wsContext);
/* 210 */     dumpRequest(this.messageContext, this.logStream);
/*     */     
/* 212 */     this.chain = ((DefaultOperation)this.operation).getClientHandlerChain(bool1, bool2);
/*     */ 
/*     */     
/* 215 */     this.messageContext.setProperty("__BEA_PRIVATE_BINDING_PROP", binding);
/*     */ 
/*     */ 
/*     */     
/* 219 */     BindingInfo bindingInfo = binding.getBindingInfo();
/* 220 */     if (bindingInfo != null) {
/* 221 */       String str = bindingInfo.getAddress();
/* 222 */       if (str != null) {
/* 223 */         this.messageContext.setProperty("javax.xml.rpc.service.endpoint.address", str);
/*     */       }
/* 225 */       int i = bindingInfo.getTimeout();
/* 226 */       if (i > -1) {
/* 227 */         this.messageContext.setProperty("weblogic.webservice.rpc.timeoutsecs", String.valueOf(i));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 232 */     this.messageContext.setProperty("__BEA_PRIVATE_ONEWAY_PROP", this.operation.isOneway() ? "true" : "false");
/*     */ 
/*     */     
/* 235 */     this.chain.handleRequest(this.messageContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object receive(WLMessageContext paramWLMessageContext) throws SOAPException, TargetInvocationException {
/*     */     try {
/* 245 */       if (this.chain != null) {
/* 246 */         this.chain.handleResponse(paramWLMessageContext);
/*     */ 
/*     */ 
/*     */         
/* 250 */         BindingInfo bindingInfo = this.operation.getPort().getBindingInfo();
/* 251 */         if (bindingInfo != null) {
/* 252 */           String str1 = (String)paramWLMessageContext.getProperty("javax.xml.rpc.service.endpoint.address");
/* 253 */           if (str1 != null) {
/* 254 */             bindingInfo.setAddress(str1);
/*     */           }
/* 256 */           str1 = (String)paramWLMessageContext.getProperty("weblogic.webservice.rpc.timeoutsecs");
/* 257 */           if (str1 != null) {
/* 258 */             bindingInfo.setTimeout(Integer.parseInt(str1));
/*     */           }
/*     */         } 
/*     */         
/* 262 */         if (this.operation.isOneway()) {
/* 263 */           return null;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 271 */         String str = (String)paramWLMessageContext.getProperty("SessionID");
/*     */         
/* 273 */         if (str != null) {
/* 274 */           this.operation.getPort().addCookies(str);
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 279 */       if (this.chain != null) this.chain.destroy();
/*     */     
/*     */     } 
/* 282 */     dumpResponse(paramWLMessageContext, this.logStream);
/*     */     
/* 284 */     SOAPEnvelope sOAPEnvelope = paramWLMessageContext.getMessage().getSOAPPart().getEnvelope();
/*     */ 
/*     */     
/* 287 */     SOAPBody sOAPBody = sOAPEnvelope.getBody();
/*     */     
/* 289 */     if (sOAPBody == null) {
/* 290 */       return null;
/*     */     }
/*     */     
/* 293 */     if (sOAPBody.hasFault()) {
/* 294 */       SOAPFault sOAPFault = sOAPBody.getFault();
/*     */ 
/*     */       
/* 297 */       QName qName = new QName("Server");
/*     */       
/* 299 */       String str = sOAPFault.getFaultCode();
/*     */       
/* 301 */       if (str != null) {
/* 302 */         if (str.indexOf(":") != -1) {
/* 303 */           String str1 = str.substring(0, str.indexOf(":"));
/* 304 */           String str2 = str.substring(str.indexOf(":") + 1);
/* 305 */           String str3 = sOAPFault.getNamespaceURI(str1);
/*     */           
/* 307 */           if (str3 == null) {
/* 308 */             qName = new QName(str);
/*     */           } else {
/* 310 */             qName = new QName(str3, str2);
/*     */           } 
/*     */         } else {
/* 313 */           qName = new QName(str);
/*     */         } 
/*     */       }
/*     */       
/* 317 */       SOAPFaultException sOAPFaultException = new SOAPFaultException(qName, sOAPFault.getFaultString(), sOAPFault.getFaultActor(), sOAPFault.getDetail());
/*     */ 
/*     */ 
/*     */       
/* 321 */       TargetInvocationException targetInvocationException = deserializeFault(paramWLMessageContext.getMessage(), sOAPFaultException);
/*     */       
/* 323 */       if (targetInvocationException != null) {
/* 324 */         throw targetInvocationException;
/*     */       }
/* 326 */       throw sOAPFaultException;
/*     */     } 
/*     */     
/* 329 */     return this.operation.getOutput().toJava(this.outParams, paramWLMessageContext.getMessage(), this.wsContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TargetInvocationException deserializeFault(SOAPMessage paramSOAPMessage, SOAPFaultException paramSOAPFaultException) throws SOAPException {
/* 340 */     Detail detail = paramSOAPMessage.getSOAPPart().getEnvelope().getBody().getFault().getDetail();
/*     */ 
/*     */     
/* 343 */     if (detail == null) return null;
/*     */     
/* 345 */     SOAPElement sOAPElement = null;
/* 346 */     for (Iterator iterator1 = detail.getChildElements(); iterator1.hasNext(); ) {
/* 347 */       Object object = iterator1.next();
/* 348 */       if (object instanceof SOAPElement) {
/* 349 */         sOAPElement = (SOAPElement)object;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 354 */     if (sOAPElement == null) return null;
/*     */     
/* 356 */     QName qName1 = findXsiType(sOAPElement);
/*     */     
/* 358 */     QName qName2 = new QName(sOAPElement.getElementName().getURI(), sOAPElement.getElementName().getLocalName());
/*     */ 
/*     */     
/* 361 */     Message message = null;
/* 362 */     boolean bool = false;
/* 363 */     byte b = 0;
/*     */     Iterator iterator2;
/* 365 */     for (iterator2 = this.operation.getFaults(); iterator2.hasNext(); ) {
/* 366 */       Message message1 = (Message)iterator2.next();
/*     */       
/* 368 */       Part part = (Part)message1.getParts().next();
/*     */       
/* 370 */       if (part.isElement()) {
/* 371 */         if (part.getXMLType().equals(qName2)) {
/* 372 */           bool = true;
/* 373 */           message = message1; break;
/*     */         }  continue;
/*     */       } 
/* 376 */       if (sOAPElement.getElementName().getLocalName().equals(part.getName())) {
/* 377 */         b++;
/* 378 */         message = message1;
/*     */       } 
/*     */     } 
/*     */     
/* 382 */     if (!bool && b > 1) {
/* 383 */       message = null;
/* 384 */       for (iterator2 = this.operation.getFaults(); iterator2.hasNext(); ) {
/* 385 */         Message message1 = (Message)iterator2.next();
/* 386 */         Part part = (Part)message1.getParts().next();
/* 387 */         if (part.getXMLType().equals(qName1)) {
/* 388 */           message = message1;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 394 */     if (message != null) {
/* 395 */       Object object = message.toJava(null, paramSOAPMessage, null);
/* 396 */       if (!(object instanceof Exception))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 401 */         return null;
/*     */       }
/*     */       
/* 404 */       Exception exception = (Exception)object;
/*     */       
/*     */       try {
/* 407 */         exception.initCause(paramSOAPFaultException);
/* 408 */       } catch (IllegalStateException illegalStateException) {}
/*     */ 
/*     */ 
/*     */       
/* 412 */       return new TargetInvocationException("Service specific exception " + exception, exception);
/*     */     } 
/* 414 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private QName findXsiType(SOAPElement paramSOAPElement) {
/* 419 */     NameImpl nameImpl = new NameImpl("type", null, StdNamespace.instance().schemaInstance());
/*     */ 
/*     */     
/* 422 */     String str = paramSOAPElement.getAttributeValue(nameImpl);
/*     */     
/* 424 */     if (str == null) return null;
/*     */     
/* 426 */     if (str.indexOf(":") != -1) {
/* 427 */       String str1 = str.substring(0, str.indexOf(":"));
/* 428 */       String str2 = str.substring(str.indexOf(":") + 1);
/* 429 */       String str3 = paramSOAPElement.getNamespaceURI(str1);
/*     */       
/* 431 */       if (str3 == null) {
/* 432 */         return new QName(str);
/*     */       }
/* 434 */       return new QName(str3, str2);
/*     */     } 
/*     */     
/* 437 */     return new QName(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 444 */   private void dumpRequest(WLMessageContext paramWLMessageContext, PrintStream paramPrintStream) { dumpMessage("REQUEST", paramWLMessageContext.getMessage(), paramPrintStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 450 */   private void dumpResponse(WLMessageContext paramWLMessageContext, PrintStream paramPrintStream) { dumpMessage("RESPONSE", paramWLMessageContext.getMessage(), paramPrintStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void dumpMessage(String paramString, SOAPMessage paramSOAPMessage, PrintStream paramPrintStream) {
/* 456 */     if (paramPrintStream != null) {
/*     */       
/* 458 */       if (paramPrintStream == null) {
/* 459 */         paramPrintStream = System.out;
/*     */       }
/*     */       
/* 462 */       paramPrintStream.println("\n<!--" + paramString + ".................-->");
/*     */       
/*     */       try {
/* 465 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 466 */         paramSOAPMessage.writeTo(byteArrayOutputStream);
/* 467 */         byteArrayOutputStream.flush();
/*     */         
/*     */         try {
/* 470 */           XMLInputStream xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
/*     */ 
/*     */ 
/*     */           
/* 474 */           XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(paramPrintStream);
/*     */ 
/*     */ 
/*     */           
/* 478 */           xMLOutputStream.add(xMLInputStream);
/* 479 */           xMLOutputStream.flush();
/* 480 */         } catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 485 */           paramPrintStream.println(new String(byteArrayOutputStream.toByteArray()));
/*     */         } 
/* 487 */       } catch (Exception exception) {
/* 488 */         exception.printStackTrace(paramPrintStream);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\ClientDispatcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */