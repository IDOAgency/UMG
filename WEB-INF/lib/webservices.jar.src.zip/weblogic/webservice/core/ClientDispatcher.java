package weblogic.webservice.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.Map;
import javax.xml.namespace.QName;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.Detail;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.Debug;
import weblogic.webservice.HandlerChain;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WLSOAPMessage;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.async.AsyncInfo;
import weblogic.webservice.async.FutureResult;
import weblogic.webservice.async.FutureResultImpl;
import weblogic.webservice.async.InvokeCompletedEvent;
import weblogic.webservice.async.ResultListener;
import weblogic.webservice.async.ThreadPool;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.binding.BindingFactory;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.core.soap.NameImpl;
import weblogic.xml.schema.binding.util.StdNamespace;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;

public class ClientDispatcher {
  private static ThreadPool threadPool = null;
  
  private Operation operation;
  
  private Map outParams;
  
  private PrintStream logStream;
  
  private HandlerChain chain;
  
  private FutureResultImpl futureResult;
  
  private AsyncInfo async;
  
  private WLMessageContext messageContext;
  
  private WebServiceContext wsContext;
  
  public ClientDispatcher(Operation paramOperation, Map paramMap, PrintStream paramPrintStream) {
    Debug.assertion((paramOperation != null));
    Debug.assertion((paramMap != null));
    this.operation = paramOperation;
    this.outParams = paramMap;
    this.logStream = paramPrintStream;
  }
  
  public ThreadPool getThreadPool() {
    if (threadPool == null)
      threadPool = new ThreadPool(2); 
    return threadPool;
  }
  
  public FutureResult asyncDispatch(Object[] paramArrayOfObject, AsyncInfo paramAsyncInfo) throws SOAPException, IOException {
    this.async = paramAsyncInfo;
    this.futureResult = new FutureResultImpl();
    this.futureResult.setAsyncInfo(paramAsyncInfo);
    send(paramArrayOfObject);
    if (paramAsyncInfo == null || !paramAsyncInfo.isReliableDelivery())
      getThreadPool().addTask(new Runnable() {
            private final ClientDispatcher this$0;
            
            public void run() { ClientDispatcher.this.callReceive(ClientDispatcher.this.messageContext); }
          }); 
    return this.futureResult;
  }
  
  public void callReceive(WLMessageContext paramWLMessageContext) {
    try {
      Object object = receive(paramWLMessageContext);
      this.futureResult.setResult(object);
    } catch (Throwable throwable) {
      String str = WebServiceLogger.logClientDispatcherException();
      WebServiceLogger.logStackTrace(str, throwable);
      this.futureResult.setError(throwable);
    } 
    if (this.async != null) {
      ResultListener resultListener = this.async.getResultListener();
      if (resultListener != null) {
        InvokeCompletedEvent invokeCompletedEvent = new InvokeCompletedEvent(this.async.getCaller());
        invokeCompletedEvent.setFutureResult(this.futureResult);
        resultListener.onCompletion(invokeCompletedEvent);
      } 
    } 
  }
  
  public Object dispatch(Object[] paramArrayOfObject) throws SOAPException, IOException, TargetInvocationException {
    send(paramArrayOfObject);
    return receive(this.messageContext);
  }
  
  public void send(Object[] paramArrayOfObject) throws SOAPException, IOException {
    this.messageContext = new DefaultMessageContext(this.operation);
    this.messageContext.setProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP", this.operation.getPort().getService());
    BindingFactory bindingFactory = BindingFactory.getInstance();
    Binding binding = bindingFactory.create(this.operation.getPort().getBindingInfo());
    boolean bool1 = false;
    if (this.futureResult != null) {
      AsyncInfo asyncInfo = this.futureResult.getAsyncInfo();
      if (asyncInfo != null && asyncInfo.isReliableDelivery()) {
        bool1 = true;
        this.messageContext.setProperty("weblogic.webservice.core.client-dispatcher", this);
        this.messageContext.setProperty("__BEA_PRIVATE_FUTURE_RESULT_PROP", this.futureResult);
        ResultListener resultListener = asyncInfo.getResultListener();
        if (resultListener != null && resultListener instanceof weblogic.webservice.ReliableDelivery)
          this.messageContext.setProperty("__BEA_PRIVATE_RELIABLE_PROP", resultListener); 
      } 
    } 
    this.wsContext = this.operation.getPort().getService().context();
    this.messageContext.setProperty("weblogic.webservice.context", this.wsContext);
    boolean bool2 = false;
    if (this.wsContext.getSession().getAttribute("weblogic.webservice.security.request") != null || this.operation.getPort().getService().getSecurity() != null)
      bool2 = true; 
    SOAPMessage sOAPMessage = this.messageContext.getMessage();
    if ("SOAP1.2".equals(this.operation.getPort().getBindingInfo().getType()))
      ((WLSOAPMessage)sOAPMessage).setSOAP12(); 
    MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
    ((DefaultOperation)this.operation).fillInHeaders(mimeHeaders);
    this.operation.getInput().toXML(sOAPMessage, paramArrayOfObject, this.wsContext);
    dumpRequest(this.messageContext, this.logStream);
    this.chain = ((DefaultOperation)this.operation).getClientHandlerChain(bool1, bool2);
    this.messageContext.setProperty("__BEA_PRIVATE_BINDING_PROP", binding);
    BindingInfo bindingInfo = binding.getBindingInfo();
    if (bindingInfo != null) {
      String str = bindingInfo.getAddress();
      if (str != null)
        this.messageContext.setProperty("javax.xml.rpc.service.endpoint.address", str); 
      int i = bindingInfo.getTimeout();
      if (i > -1)
        this.messageContext.setProperty("weblogic.webservice.rpc.timeoutsecs", String.valueOf(i)); 
    } 
    this.messageContext.setProperty("__BEA_PRIVATE_ONEWAY_PROP", this.operation.isOneway() ? "true" : "false");
    this.chain.handleRequest(this.messageContext);
  }
  
  private Object receive(WLMessageContext paramWLMessageContext) throws SOAPException, TargetInvocationException {
    try {
      if (this.chain != null) {
        this.chain.handleResponse(paramWLMessageContext);
        BindingInfo bindingInfo = this.operation.getPort().getBindingInfo();
        if (bindingInfo != null) {
          String str1 = (String)paramWLMessageContext.getProperty("javax.xml.rpc.service.endpoint.address");
          if (str1 != null)
            bindingInfo.setAddress(str1); 
          str1 = (String)paramWLMessageContext.getProperty("weblogic.webservice.rpc.timeoutsecs");
          if (str1 != null)
            bindingInfo.setTimeout(Integer.parseInt(str1)); 
        } 
        if (this.operation.isOneway())
          return null; 
        String str = (String)paramWLMessageContext.getProperty("SessionID");
        if (str != null)
          this.operation.getPort().addCookies(str); 
      } 
    } finally {
      if (this.chain != null)
        this.chain.destroy(); 
    } 
    dumpResponse(paramWLMessageContext, this.logStream);
    SOAPEnvelope sOAPEnvelope = paramWLMessageContext.getMessage().getSOAPPart().getEnvelope();
    SOAPBody sOAPBody = sOAPEnvelope.getBody();
    if (sOAPBody == null)
      return null; 
    if (sOAPBody.hasFault()) {
      SOAPFault sOAPFault = sOAPBody.getFault();
      QName qName = new QName("Server");
      String str = sOAPFault.getFaultCode();
      if (str != null)
        if (str.indexOf(":") != -1) {
          String str1 = str.substring(0, str.indexOf(":"));
          String str2 = str.substring(str.indexOf(":") + 1);
          String str3 = sOAPFault.getNamespaceURI(str1);
          if (str3 == null) {
            qName = new QName(str);
          } else {
            qName = new QName(str3, str2);
          } 
        } else {
          qName = new QName(str);
        }  
      SOAPFaultException sOAPFaultException = new SOAPFaultException(qName, sOAPFault.getFaultString(), sOAPFault.getFaultActor(), sOAPFault.getDetail());
      TargetInvocationException targetInvocationException = deserializeFault(paramWLMessageContext.getMessage(), sOAPFaultException);
      if (targetInvocationException != null)
        throw targetInvocationException; 
      throw sOAPFaultException;
    } 
    return this.operation.getOutput().toJava(this.outParams, paramWLMessageContext.getMessage(), this.wsContext);
  }
  
  private TargetInvocationException deserializeFault(SOAPMessage paramSOAPMessage, SOAPFaultException paramSOAPFaultException) throws SOAPException {
    Detail detail = paramSOAPMessage.getSOAPPart().getEnvelope().getBody().getFault().getDetail();
    if (detail == null)
      return null; 
    SOAPElement sOAPElement = null;
    for (Iterator iterator1 = detail.getChildElements(); iterator1.hasNext(); ) {
      Object object = iterator1.next();
      if (object instanceof SOAPElement) {
        sOAPElement = (SOAPElement)object;
        break;
      } 
    } 
    if (sOAPElement == null)
      return null; 
    QName qName1 = findXsiType(sOAPElement);
    QName qName2 = new QName(sOAPElement.getElementName().getURI(), sOAPElement.getElementName().getLocalName());
    Message message = null;
    boolean bool = false;
    byte b = 0;
    Iterator iterator2;
    for (iterator2 = this.operation.getFaults(); iterator2.hasNext(); ) {
      Message message1 = (Message)iterator2.next();
      Part part = (Part)message1.getParts().next();
      if (part.isElement()) {
        if (part.getXMLType().equals(qName2)) {
          bool = true;
          message = message1;
          break;
        } 
        continue;
      } 
      if (sOAPElement.getElementName().getLocalName().equals(part.getName())) {
        b++;
        message = message1;
      } 
    } 
    if (!bool && b > 1) {
      message = null;
      for (iterator2 = this.operation.getFaults(); iterator2.hasNext(); ) {
        Message message1 = (Message)iterator2.next();
        Part part = (Part)message1.getParts().next();
        if (part.getXMLType().equals(qName1)) {
          message = message1;
          break;
        } 
      } 
    } 
    if (message != null) {
      Object object = message.toJava(null, paramSOAPMessage, null);
      if (!(object instanceof Exception))
        return null; 
      Exception exception = (Exception)object;
      try {
        exception.initCause(paramSOAPFaultException);
      } catch (IllegalStateException illegalStateException) {}
      return new TargetInvocationException("Service specific exception " + exception, exception);
    } 
    return null;
  }
  
  private QName findXsiType(SOAPElement paramSOAPElement) {
    NameImpl nameImpl = new NameImpl("type", null, StdNamespace.instance().schemaInstance());
    String str = paramSOAPElement.getAttributeValue(nameImpl);
    if (str == null)
      return null; 
    if (str.indexOf(":") != -1) {
      String str1 = str.substring(0, str.indexOf(":"));
      String str2 = str.substring(str.indexOf(":") + 1);
      String str3 = paramSOAPElement.getNamespaceURI(str1);
      if (str3 == null)
        return new QName(str); 
      return new QName(str3, str2);
    } 
    return new QName(str);
  }
  
  private void dumpRequest(WLMessageContext paramWLMessageContext, PrintStream paramPrintStream) { dumpMessage("REQUEST", paramWLMessageContext.getMessage(), paramPrintStream); }
  
  private void dumpResponse(WLMessageContext paramWLMessageContext, PrintStream paramPrintStream) { dumpMessage("RESPONSE", paramWLMessageContext.getMessage(), paramPrintStream); }
  
  private void dumpMessage(String paramString, SOAPMessage paramSOAPMessage, PrintStream paramPrintStream) {
    if (paramPrintStream != null) {
      if (paramPrintStream == null)
        paramPrintStream = System.out; 
      paramPrintStream.println("\n<!--" + paramString + ".................-->");
      try {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        paramSOAPMessage.writeTo(byteArrayOutputStream);
        byteArrayOutputStream.flush();
        try {
          XMLInputStream xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
          XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(paramPrintStream);
          xMLOutputStream.add(xMLInputStream);
          xMLOutputStream.flush();
        } catch (Exception exception) {
          paramPrintStream.println(new String(byteArrayOutputStream.toByteArray()));
        } 
      } catch (Exception exception) {
        exception.printStackTrace(paramPrintStream);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\ClientDispatcher.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */