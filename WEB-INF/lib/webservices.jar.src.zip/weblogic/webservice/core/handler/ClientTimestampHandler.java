/*    */ package weblogic.webservice.core.handler;
/*    */ 
/*    */ import javax.xml.rpc.handler.HandlerInfo;
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ import weblogic.xml.security.specs.TimestampConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClientTimestampHandler
/*    */   extends TimestampHandler
/*    */ {
/*    */   public boolean handleRequest(MessageContext paramMessageContext) {
/* 16 */     if (VERBOSE) System.out.println("ClientTimestampHandler: handling request"); 
/* 17 */     return handleSend(paramMessageContext);
/*    */   }
/*    */   
/*    */   public boolean handleResponse(MessageContext paramMessageContext) {
/* 21 */     if (VERBOSE) System.out.println("ClientTimestampHandler: handling request"); 
/* 22 */     return handleReceive(paramMessageContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final void initHandlerInfo(HandlerInfo paramHandlerInfo, boolean paramBoolean1, long paramLong1, boolean paramBoolean2, long paramLong2, boolean paramBoolean3, long paramLong3, boolean paramBoolean4) {
/* 52 */     TimestampConfig timestampConfig = new TimestampConfig(paramBoolean1, paramLong1, paramBoolean2, paramLong2, paramBoolean3, paramLong3, paramBoolean4);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 59 */     initHandlerInfo(paramHandlerInfo, timestampConfig);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 73 */   public static final void initHandlerInfo(HandlerInfo paramHandlerInfo, boolean paramBoolean1, long paramLong1, boolean paramBoolean2, long paramLong2, boolean paramBoolean3, long paramLong3) { initHandlerInfo(paramHandlerInfo, paramBoolean1, paramLong1, paramBoolean2, paramLong2, paramBoolean3, paramLong3, false); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ClientTimestampHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */