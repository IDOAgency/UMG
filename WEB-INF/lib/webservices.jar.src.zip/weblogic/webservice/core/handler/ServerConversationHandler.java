package weblogic.webservice.core.handler;

import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebServiceLogger;

public final class ServerConversationHandler extends GenericHandler {
  public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    try {
      SOAPMessage sOAPMessage = wLMessageContext.getMessage();
      SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
      SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
      if (sOAPHeader != null) {
        ConversationUtil conversationUtil = new ConversationUtil(sOAPEnvelope);
        ConversationContext conversationContext = conversationUtil.createContext();
        if (conversationContext != null) {
          String str = wLMessageContext.getOperation().getConversationPhase();
          if ("START".equals(str) && !"StartHeader".equals(conversationContext.getHeaderType()))
            throw new JAXRPCException("Excpecting conversation start header but get " + conversationContext.getHeaderType()); 
          if ("CONTINUE".equals(str) && !"ContinueHeader".equals(conversationContext.getHeaderType()))
            throw new JAXRPCException("Excpecting conversation continue header but get " + conversationContext.getHeaderType()); 
          if ("FINISH".equals(str) && !"ContinueHeader".equals(conversationContext.getHeaderType())) {
            conversationContext.setHeaderType("FinishHeader");
            throw new JAXRPCException("Excpecting conversation continue header but get " + conversationContext.getHeaderType());
          } 
          if (str != null && str != "NONE")
            wLMessageContext.setProperty("__BEA_PRIVATE_CONVERSATION_PROP", conversationContext); 
        } 
      } 
    } catch (SOAPException sOAPException) {
      String str = WebServiceLogger.logServerConversationSoapException();
      WebServiceLogger.logStackTrace(str, sOAPException);
      throw new JAXRPCException(sOAPException);
    } 
    return true;
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ServerConversationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */