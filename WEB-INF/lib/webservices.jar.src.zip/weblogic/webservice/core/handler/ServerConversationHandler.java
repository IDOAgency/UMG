/*    */ package weblogic.webservice.core.handler;
/*    */ 
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ import javax.xml.soap.SOAPEnvelope;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import javax.xml.soap.SOAPHeader;
/*    */ import javax.xml.soap.SOAPMessage;
/*    */ import weblogic.webservice.GenericHandler;
/*    */ import weblogic.webservice.WLMessageContext;
/*    */ import weblogic.webservice.WebServiceLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ServerConversationHandler
/*    */   extends GenericHandler
/*    */ {
/*    */   public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
/* 28 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*    */     
/*    */     try {
/* 31 */       SOAPMessage sOAPMessage = wLMessageContext.getMessage();
/* 32 */       SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
/* 33 */       SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
/*    */       
/* 35 */       if (sOAPHeader != null) {
/* 36 */         ConversationUtil conversationUtil = new ConversationUtil(sOAPEnvelope);
/* 37 */         ConversationContext conversationContext = conversationUtil.createContext();
/*    */         
/* 39 */         if (conversationContext != null) {
/* 40 */           String str = wLMessageContext.getOperation().getConversationPhase();
/*    */           
/* 42 */           if ("START".equals(str) && !"StartHeader".equals(conversationContext.getHeaderType()))
/*    */           {
/* 44 */             throw new JAXRPCException("Excpecting conversation start header but get " + conversationContext.getHeaderType());
/*    */           }
/* 46 */           if ("CONTINUE".equals(str) && !"ContinueHeader".equals(conversationContext.getHeaderType()))
/*    */           {
/* 48 */             throw new JAXRPCException("Excpecting conversation continue header but get " + conversationContext.getHeaderType());
/*    */           }
/* 50 */           if ("FINISH".equals(str) && !"ContinueHeader".equals(conversationContext.getHeaderType())) {
/*    */ 
/*    */ 
/*    */             
/* 54 */             conversationContext.setHeaderType("FinishHeader");
/* 55 */             throw new JAXRPCException("Excpecting conversation continue header but get " + conversationContext.getHeaderType());
/*    */           } 
/*    */ 
/*    */           
/* 59 */           if (str != null && str != "NONE") {
/* 60 */             wLMessageContext.setProperty("__BEA_PRIVATE_CONVERSATION_PROP", conversationContext);
/*    */           }
/*    */         } 
/*    */       } 
/* 64 */     } catch (SOAPException sOAPException) {
/* 65 */       String str = WebServiceLogger.logServerConversationSoapException();
/* 66 */       WebServiceLogger.logStackTrace(str, sOAPException);
/* 67 */       throw new JAXRPCException(sOAPException);
/*    */     } 
/*    */     
/* 70 */     return true;
/*    */   }
/*    */   
/*    */   public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
/* 74 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 94 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ServerConversationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */