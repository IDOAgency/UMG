/*     */ package weblogic.webservice.core.handler;
/*     */ 
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeader;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.GenericHandler;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.context.WebServiceSession;
/*     */ import weblogic.webservice.conversation.Guid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ClientConversationHandler
/*     */   extends GenericHandler
/*     */ {
/*     */   public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
/*  30 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*     */     
/*     */     try {
/*  33 */       Operation operation = wLMessageContext.getOperation();
/*  34 */       String str = operation.getConversationPhase();
/*     */       
/*  36 */       if (str != null && str != "NONE") {
/*     */         
/*  38 */         ConversationContext conversationContext = new ConversationContext();
/*  39 */         WebServiceContext webServiceContext = (WebServiceContext)wLMessageContext.getProperty("weblogic.webservice.context");
/*     */ 
/*     */         
/*  42 */         WebServiceSession webServiceSession = webServiceContext.getSession();
/*     */         
/*  44 */         if (str.equals("CONTINUE")) {
/*  45 */           conversationContext.setHeaderType("ContinueHeader");
/*     */           
/*  47 */           String str1 = (String)webServiceSession.getAttribute("__BEA_PRIVATE_CONVERSATION_PROP");
/*     */ 
/*     */           
/*  50 */           if (str1 == null) {
/*  51 */             throw new JAXRPCException("There is no conversationID found in WebServiceSession for a continue conversation method. Did you start a conversation?");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*  56 */           conversationContext.setConversationID(str1);
/*     */         }
/*  58 */         else if (str.equals("START")) {
/*     */           
/*  60 */           conversationContext.setHeaderType("StartHeader");
/*     */           
/*  62 */           String str1 = (String)webServiceSession.getAttribute("__BEA_PRIVATE_CONVERSATION_PROP");
/*     */ 
/*     */           
/*  65 */           if (str1 == null) {
/*  66 */             str1 = Guid.generateGuid();
/*     */           }
/*     */           
/*  69 */           webServiceSession.setAttribute("__BEA_PRIVATE_CONVERSATION_PROP", str1);
/*  70 */           conversationContext.setConversationID(str1);
/*     */         }
/*  72 */         else if (str.equals("FINISH")) {
/*  73 */           conversationContext.setHeaderType("FinishHeader");
/*     */           
/*  75 */           String str1 = (String)webServiceSession.getAttribute("__BEA_PRIVATE_CONVERSATION_PROP");
/*     */ 
/*     */           
/*  78 */           if (str1 == null) {
/*  79 */             throw new JAXRPCException("There is no conversationID found in WebServiceSession for a finish conversation method. Did you start a conversation?");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*  84 */           webServiceSession.setAttribute("__BEA_PRIVATE_CONVERSATION_PROP", null);
/*     */           
/*  86 */           conversationContext.setConversationID(str1);
/*     */         } else {
/*     */           
/*  89 */           throw new AssertionError("unknown conversation phase " + str);
/*     */         } 
/*     */ 
/*     */         
/*  93 */         wLMessageContext.setProperty("__BEA_PRIVATE_CONVERSATION_PROP", conversationContext);
/*     */         
/*  95 */         SOAPMessage sOAPMessage = wLMessageContext.getMessage();
/*  96 */         SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
/*  97 */         SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
/*     */         
/*  99 */         ConversationUtil conversationUtil = new ConversationUtil(sOAPEnvelope);
/* 100 */         conversationUtil.addToHeader(conversationContext);
/*     */       } 
/* 102 */     } catch (SOAPException sOAPException) {
/* 103 */       String str = WebServiceLogger.logClientConversationSoapException();
/* 104 */       WebServiceLogger.logStackTrace(str, sOAPException);
/* 105 */       throw new JAXRPCException(sOAPException);
/*     */     } 
/*     */     
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
/* 112 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ClientConversationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */