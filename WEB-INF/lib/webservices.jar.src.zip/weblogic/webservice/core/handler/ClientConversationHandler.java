package weblogic.webservice.core.handler;

import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.AssertionError;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.Operation;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.context.WebServiceSession;
import weblogic.webservice.conversation.Guid;

public final class ClientConversationHandler extends GenericHandler {
  public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    try {
      Operation operation = wLMessageContext.getOperation();
      String str = operation.getConversationPhase();
      if (str != null && str != "NONE") {
        ConversationContext conversationContext = new ConversationContext();
        WebServiceContext webServiceContext = (WebServiceContext)wLMessageContext.getProperty("weblogic.webservice.context");
        WebServiceSession webServiceSession = webServiceContext.getSession();
        if (str.equals("CONTINUE")) {
          conversationContext.setHeaderType("ContinueHeader");
          String str1 = (String)webServiceSession.getAttribute("__BEA_PRIVATE_CONVERSATION_PROP");
          if (str1 == null)
            throw new JAXRPCException("There is no conversationID found in WebServiceSession for a continue conversation method. Did you start a conversation?"); 
          conversationContext.setConversationID(str1);
        } else if (str.equals("START")) {
          conversationContext.setHeaderType("StartHeader");
          String str1 = (String)webServiceSession.getAttribute("__BEA_PRIVATE_CONVERSATION_PROP");
          if (str1 == null)
            str1 = Guid.generateGuid(); 
          webServiceSession.setAttribute("__BEA_PRIVATE_CONVERSATION_PROP", str1);
          conversationContext.setConversationID(str1);
        } else if (str.equals("FINISH")) {
          conversationContext.setHeaderType("FinishHeader");
          String str1 = (String)webServiceSession.getAttribute("__BEA_PRIVATE_CONVERSATION_PROP");
          if (str1 == null)
            throw new JAXRPCException("There is no conversationID found in WebServiceSession for a finish conversation method. Did you start a conversation?"); 
          webServiceSession.setAttribute("__BEA_PRIVATE_CONVERSATION_PROP", null);
          conversationContext.setConversationID(str1);
        } else {
          throw new AssertionError("unknown conversation phase " + str);
        } 
        wLMessageContext.setProperty("__BEA_PRIVATE_CONVERSATION_PROP", conversationContext);
        SOAPMessage sOAPMessage = wLMessageContext.getMessage();
        SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
        SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
        ConversationUtil conversationUtil = new ConversationUtil(sOAPEnvelope);
        conversationUtil.addToHeader(conversationContext);
      } 
    } catch (SOAPException sOAPException) {
      String str = WebServiceLogger.logClientConversationSoapException();
      WebServiceLogger.logStackTrace(str, sOAPException);
      throw new JAXRPCException(sOAPException);
    } 
    return true;
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ClientConversationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */