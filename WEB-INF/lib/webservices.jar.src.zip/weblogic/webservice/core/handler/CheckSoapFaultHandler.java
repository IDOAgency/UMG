/*    */ package weblogic.webservice.core.handler;
/*    */ 
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import weblogic.webservice.GenericHandler;
/*    */ import weblogic.webservice.WLMessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CheckSoapFaultHandler
/*    */   extends GenericHandler
/*    */ {
/*    */   public boolean handleResponse(MessageContext paramMessageContext) {
/* 19 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*    */     
/*    */     try {
/* 22 */       if (wLMessageContext.getMessage().getSOAPPart().getEnvelope().getBody().hasFault()) {
/* 23 */         wLMessageContext.setFault(true);
/*    */       }
/* 25 */     } catch (SOAPException sOAPException) {
/* 26 */       throw new JAXRPCException(sOAPException);
/*    */     } 
/*    */     
/* 29 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\CheckSoapFaultHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */