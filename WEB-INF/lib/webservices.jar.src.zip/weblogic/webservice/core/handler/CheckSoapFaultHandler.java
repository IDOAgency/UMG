package weblogic.webservice.core.handler;

import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.soap.SOAPException;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.WLMessageContext;

public final class CheckSoapFaultHandler extends GenericHandler {
  public boolean handleResponse(MessageContext paramMessageContext) {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    try {
      if (wLMessageContext.getMessage().getSOAPPart().getEnvelope().getBody().hasFault())
        wLMessageContext.setFault(true); 
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException(sOAPException);
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\CheckSoapFaultHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */