package weblogic.webservice.core.handler;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;
import javax.xml.namespace.QName;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.SOAPException;
import weblogic.security.SubjectUtils;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.utils.AssertionError;
import weblogic.utils.CharsetMap;
import weblogic.utils.Debug;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.Operation;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WLSOAPPart;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.context.WebServiceSession;
import weblogic.webservice.core.soap.SOAPMessageImpl;
import weblogic.webservice.server.AuthorizationContext;
import weblogic.webservice.server.ConfigException;
import weblogic.webservice.server.Dispatcher;
import weblogic.webservice.util.BufferStream;
import weblogic.webservice.util.FaultUtil;
import weblogic.webservice.util.ServerKeyStore;
import weblogic.webservice.util.ServerSecurityHelper;
import weblogic.xml.security.InvalidSecurityException;
import weblogic.xml.security.SecurityAssertion;
import weblogic.xml.security.SecurityConfigurationException;
import weblogic.xml.security.SecurityProcessingException;
import weblogic.xml.security.UserInfo;
import weblogic.xml.security.assertion.ElementAssertion;
import weblogic.xml.security.assertion.IdentityAssertion;
import weblogic.xml.security.assertion.IntegrityAssertion;
import weblogic.xml.security.assertion.ServerHelper;
import weblogic.xml.security.keyinfo.KeyProviderFactory;
import weblogic.xml.security.keyinfo.KeyResolver;
import weblogic.xml.security.specs.BinarySecurityTokenSpec;
import weblogic.xml.security.specs.ElementIdentifier;
import weblogic.xml.security.specs.EncryptionKey;
import weblogic.xml.security.specs.EncryptionSpec;
import weblogic.xml.security.specs.OperationSpec;
import weblogic.xml.security.specs.SecurityDD;
import weblogic.xml.security.specs.SecuritySpec;
import weblogic.xml.security.specs.SignatureKey;
import weblogic.xml.security.specs.SignatureSpec;
import weblogic.xml.security.specs.TimestampConfig;
import weblogic.xml.security.specs.User;
import weblogic.xml.security.specs.UsernameTokenSpec;
import weblogic.xml.security.utils.Utils;
import weblogic.xml.security.wsse.BinarySecurityToken;
import weblogic.xml.security.wsse.SecureSoapInputStream;
import weblogic.xml.security.wsse.SecureSoapOutputStream;
import weblogic.xml.security.wsse.Security;
import weblogic.xml.security.wsse.SecurityElementFactory;
import weblogic.xml.security.wsse.Token;
import weblogic.xml.security.wsse.v200207.UsernameTokenImpl;
import weblogic.xml.security.wsse.v200207.WSSEConstants;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLStreamException;

public class WSSEHandler extends GenericHandler implements WSSEConstants {
  public static final String RESPONSE_SECURITY_ATTRIBUTE = "weblogic.webservice.security.request";
  
  public static final String REQUEST_CERTIFICATE_ATTRIBUTE = "__BEA_INTERNAL__request.certificate";
  
  private static final String WSSE_CONFIG = "__BEA_INTERNAL__WSSE.config";
  
  private static final int USE_KEY_ENCIPHERMENT = 2;
  
  private static final QName NO_ELEMENT = Utils.getQName(QNAME_FAULT_SECURITYTOKENUNAVAILBLE);
  
  private static final QName INVALID_SECURITY = Utils.getQName(QNAME_FAULT_INVALIDSECURITY);
  
  private static final QName UNSUPPORTED = Utils.getQName(QNAME_FAULT_UNSUPPORTEDSECURITYTOKEN);
  
  private static final QName FAILED_AUTH = Utils.getQName(QNAME_FAULT_FAILEDAUTHENTICATION);
  
  private static final QName FAILED_CHECK = Utils.getQName(QNAME_FAULT_FAILEDCHECK);
  
  private static final SecurityElementFactory factory = SecurityElementFactory.getDefaultFactory();
  
  private static final boolean DEBUG = Security.WSSE_VERBOSE;
  
  private HandlerConfig config = null;
  
  private String realmName = null;
  
  public void init(HandlerInfo paramHandlerInfo) {
    Map map = paramHandlerInfo.getHandlerConfig();
    AuthorizationContext authorizationContext = (AuthorizationContext)map.get("WSAuthorizationContext");
    this.realmName = authorizationContext.getSecurityRealm();
    this.config = (HandlerConfig)map.get("__BEA_INTERNAL__WSSE.config");
  }
  
  public boolean handleRequest(MessageContext paramMessageContext) {
    if (DEBUG)
      Debug.say("handleRequest called"); 
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    WebServiceContext webServiceContext = (WebServiceContext)wLMessageContext.getProperty("weblogic.webservice.context");
    webServiceContext.getSession().removeAttribute("weblogic.webservice.security.request");
    WLSOAPPart wLSOAPPart = (WLSOAPPart)wLMessageContext.getMessage().getSOAPPart();
    XMLInputStream xMLInputStream = null;
    try {
      xMLInputStream = wLSOAPPart.getXMLStreamContent();
    } catch (XMLStreamException xMLStreamException) {
      throw new AssertionError("Can't get soap as stream. ", xMLStreamException);
    } catch (SOAPException sOAPException) {
      throw new AssertionError("Can't get soap as stream. ", sOAPException);
    } 
    try {
      EncryptionSpec encryptionSpec;
      SignatureSpec signatureSpec;
      SecureSoapInputStream secureSoapInputStream = new SecureSoapInputStream(xMLInputStream, null, this.config.resolver.copy());
      Security security = secureSoapInputStream.getSecurityElement();
      SecurityAssertion[] arrayOfSecurityAssertion = secureSoapInputStream.getSecurityAssertions();
      WebServiceSession webServiceSession = webServiceContext.getSession();
      wLSOAPPart.setContent(secureSoapInputStream);
      Operation operation = getOperation(wLMessageContext);
      SecuritySpec securitySpec1 = getRequestSpec(operation, this.config);
      if (securitySpec1 != null) {
        signatureSpec = securitySpec1.getSignatureSpec();
        encryptionSpec = securitySpec1.getEncryptionSpec();
      } else {
        signatureSpec = null;
        encryptionSpec = null;
      } 
      this.config.getTimestampConfig().checkTimestamps(security, wLMessageContext);
      if (security == null && securitySpec1 != null)
        throw new SOAPFaultException(NO_ELEMENT, "Message did not contain a valid Security Element", null, null); 
      AuthenticatedSubject authenticatedSubject = assertIdentities(this.realmName, arrayOfSecurityAssertion);
      wLMessageContext.setProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP", authenticatedSubject);
      Set set1 = secureSoapInputStream.getHeaderElementNames();
      Set set2 = secureSoapInputStream.getBodyElementNames();
      Set set3 = secureSoapInputStream.getAllElementNames();
      validateSignatureSpec(signatureSpec, arrayOfSecurityAssertion, set1, set2, set3);
      validateEncryptionSpec(encryptionSpec, arrayOfSecurityAssertion, set1, set2, set3);
      wLMessageContext.setProperty("weblogic.webservice.security.assertions.request", arrayOfSecurityAssertion);
      SecuritySpec securitySpec2 = getResponseSpec(operation, this.config);
      if (securitySpec2 != null && securitySpec2.getEncryptionSpec() != null)
        saveClientCert(security, webServiceSession); 
    } catch (XMLStreamException xMLStreamException) {
      throw new SOAPFaultException(INVALID_SECURITY, xMLStreamException.getMessage(), null, DEBUG ? FaultUtil.newDetail(xMLStreamException) : null);
    } catch (InvalidSecurityException invalidSecurityException) {
      throw new SOAPFaultException(FAILED_CHECK, invalidSecurityException.getMessage(), null, null);
    } 
    return true;
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) {
    SecureSoapOutputStream secureSoapOutputStream;
    BufferStream bufferStream;
    if (DEBUG)
      Debug.say("handleResponse called"); 
    WebServiceContext webServiceContext = (WebServiceContext)paramMessageContext.getProperty("weblogic.webservice.context");
    WebServiceSession webServiceSession = webServiceContext.getSession();
    X509Certificate x509Certificate = (X509Certificate)webServiceSession.getAttribute("__BEA_INTERNAL__request.certificate");
    webServiceSession.removeAttribute("__BEA_INTERNAL__request.certificate");
    Operation operation = getOperation(paramMessageContext);
    SecuritySpec securitySpec = getResponseSpec(operation, this.config);
    Security security = (Security)webServiceSession.getAttribute("weblogic.webservice.security.request");
    if (security == null) {
      if (securitySpec == null)
        return true; 
      security = factory.createSecurity(null);
      processSpecs(securitySpec, security, x509Certificate);
    } 
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    WLSOAPPart wLSOAPPart = (WLSOAPPart)wLMessageContext.getMessage().getSOAPPart();
    String str = getEncoding(wLMessageContext);
    try {
      bufferStream = new BufferStream();
      secureSoapOutputStream = new SecureSoapOutputStream(security, bufferStream, str);
    } catch (SecurityProcessingException securityProcessingException) {
      securityProcessingException.printStackTrace();
      throw new SecurityConfigurationException("Unable to secure response", securityProcessingException);
    } catch (XMLStreamException xMLStreamException) {
      xMLStreamException.printStackTrace();
      throw new SecurityConfigurationException("Unable to secure response", xMLStreamException);
    } 
    try {
      wLSOAPPart.writeTo(secureSoapOutputStream);
      secureSoapOutputStream.close();
    } catch (SOAPException sOAPException) {
      throw new AssertionError("Unable to secure response", sOAPException);
    } catch (XMLStreamException xMLStreamException) {
      throw new AssertionError("Unable to secure response", xMLStreamException);
    } 
    wLSOAPPart.setContent(bufferStream);
    return true;
  }
  
  private static String getEncoding(WLMessageContext paramWLMessageContext) {
    String str = paramWLMessageContext.getOperation().getPort().getBindingInfo().getCharset();
    if (str == null)
      str = ((SOAPMessageImpl)paramWLMessageContext.getMessage()).getCharset(); 
    return (str != null) ? CharsetMap.getJavaFromIANA(str) : "UTF-8";
  }
  
  public boolean handleFault(MessageContext paramMessageContext) {
    if (DEBUG)
      Debug.say("handleFault called"); 
    return super.handleFault(paramMessageContext);
  }
  
  private static Operation getOperation(MessageContext paramMessageContext) {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    Operation operation = wLMessageContext.getOperation();
    if (operation == null)
      try {
        operation = Dispatcher.getOperation(wLMessageContext);
      } catch (SOAPException sOAPException) {
        throw new AssertionError(sOAPException);
      }  
    return operation;
  }
  
  private static SecuritySpec getRequestSpec(Operation paramOperation, HandlerConfig paramHandlerConfig) {
    String str = (paramOperation != null) ? paramOperation.getInput().getSecuritySpecRef() : null;
    SecuritySpec securitySpec = (str == null) ? paramHandlerConfig.getSecuritySpec("default-spec") : paramHandlerConfig.getSecuritySpec(str);
    if (DEBUG)
      Debug.say("using this spec for the request -- " + securitySpec); 
    return securitySpec;
  }
  
  private static SecuritySpec getResponseSpec(Operation paramOperation, HandlerConfig paramHandlerConfig) {
    String str = (paramOperation != null) ? paramOperation.getOutput().getSecuritySpecRef() : null;
    SecuritySpec securitySpec = (str == null) ? paramHandlerConfig.getSecuritySpec("default-spec") : paramHandlerConfig.getSecuritySpec(str);
    if (DEBUG)
      Debug.say("using this spec for the response -- " + securitySpec); 
    return securitySpec;
  }
  
  private void saveClientCert(Security paramSecurity, WebServiceSession paramWebServiceSession) {
    Iterator iterator = paramSecurity.getBinarySecurityTokens();
    X509Certificate x509Certificate = null;
    boolean bool = false;
    while (iterator.hasNext()) {
      BinarySecurityToken binarySecurityToken = (BinarySecurityToken)iterator.next();
      x509Certificate = binarySecurityToken.getCertificate();
      if (x509Certificate != null && keyEncryptionAllowed(x509Certificate)) {
        paramWebServiceSession.setAttribute("__BEA_INTERNAL__request.certificate", x509Certificate);
        bool = true;
        break;
      } 
    } 
    if (!bool)
      throw new SOAPFaultException(INVALID_SECURITY, "Response requires encryption; no certificate with suitable key usage was found", null, null); 
  }
  
  private static final AuthenticatedSubject assertIdentities(String paramString, SecurityAssertion[] paramArrayOfSecurityAssertion) {
    HashMap hashMap = new HashMap();
    ArrayList arrayList = new ArrayList(3);
    X509Certificate x509Certificate = null;
    Subject subject = null;
    arrayList.add(ServerSecurityHelper.getCurrentSubject());
    for (byte b = 0; b < paramArrayOfSecurityAssertion.length; b++) {
      UserInfo userInfo;
      IdentityAssertion identityAssertion;
      X509Certificate x509Certificate1;
      IntegrityAssertion integrityAssertion;
      SecurityAssertion securityAssertion = paramArrayOfSecurityAssertion[b];
      switch (securityAssertion.getAssertionTypeCode()) {
        case 1:
        case 2:
          integrityAssertion = (IntegrityAssertion)securityAssertion;
          x509Certificate1 = integrityAssertion.getCertificate();
          if (x509Certificate1 == null)
            break; 
          if (x509Certificate == x509Certificate1) {
            ServerHelper.setSubject(integrityAssertion, subject);
          } else {
            x509Certificate = x509Certificate1;
            subject = (Subject)hashMap.get(x509Certificate1);
            if (subject == null) {
              AuthenticatedSubject authenticatedSubject = assertIdentity(x509Certificate1, paramString);
              subject = authenticatedSubject.getSubject();
              hashMap.put(x509Certificate, subject);
            } 
          } 
          ServerHelper.setSubject(integrityAssertion, subject);
          break;
        case 0:
          identityAssertion = (IdentityAssertion)securityAssertion;
          userInfo = identityAssertion.getUserInfo();
          if (userInfo != null) {
            AuthenticatedSubject authenticatedSubject = assertIdentity(userInfo, paramString);
            if (authenticatedSubject != null)
              arrayList.add(authenticatedSubject); 
            break;
          } 
          throw new AssertionError("Unsupported Identity Assertion " + identityAssertion);
      } 
    } 
    AuthenticatedSubject[] arrayOfAuthenticatedSubject = new AuthenticatedSubject[arrayList.size()];
    arrayOfAuthenticatedSubject = (AuthenticatedSubject[])arrayList.toArray(arrayOfAuthenticatedSubject);
    return SubjectUtils.combineSubjects(arrayOfAuthenticatedSubject);
  }
  
  private static AuthenticatedSubject assertIdentity(X509Certificate paramX509Certificate, String paramString) {
    try {
      X509Certificate[] arrayOfX509Certificate = new X509Certificate[1];
      arrayOfX509Certificate[0] = paramX509Certificate;
      return ServerSecurityHelper.assertIdentity(arrayOfX509Certificate, paramString);
    } catch (LoginException loginException) {
      throw new SOAPFaultException(FAILED_AUTH, loginException.getMessage(), null, null);
    } 
  }
  
  private static AuthenticatedSubject assertIdentity(UserInfo paramUserInfo, String paramString) {
    String str = paramUserInfo.getPassword();
    if (str != null)
      try {
        return ServerSecurityHelper.assertIdentity(paramUserInfo.getUsername(), str, paramString);
      } catch (LoginException loginException) {
        throw new SOAPFaultException(FAILED_AUTH, loginException.getMessage(), null, null);
      }  
    if (paramUserInfo.getPasswordDigest() != null)
      throw new SOAPFaultException(UNSUPPORTED, "Password Digests not supported", null, null); 
    throw new SOAPFaultException(INVALID_SECURITY, "UsernameToken did not contain a password", null, null);
  }
  
  private static final void validateEncryptionSpec(EncryptionSpec paramEncryptionSpec, SecurityAssertion[] paramArrayOfSecurityAssertion, Set paramSet1, Set paramSet2, Set paramSet3) { validateSpec(paramEncryptionSpec, paramArrayOfSecurityAssertion, 4, paramSet1, paramSet2, paramSet3); }
  
  private static void validateSignatureSpec(SignatureSpec paramSignatureSpec, SecurityAssertion[] paramArrayOfSecurityAssertion, Set paramSet1, Set paramSet2, Set paramSet3) { validateSpec(paramSignatureSpec, paramArrayOfSecurityAssertion, 2, paramSet1, paramSet2, paramSet3); }
  
  private static final void validateSpec(OperationSpec paramOperationSpec, SecurityAssertion[] paramArrayOfSecurityAssertion, int paramInt, Set paramSet1, Set paramSet2, Set paramSet3) {
    if (paramOperationSpec == null)
      return; 
    ElementIdentifier[] arrayOfElementIdentifier = paramOperationSpec.getBodyElementSpecs();
    Set set = paramSet2;
    String str = "body";
    ElementAssertion[] arrayOfElementAssertion = subsetAssertions(paramArrayOfSecurityAssertion, paramInt, str);
    if (paramOperationSpec.entireBody()) {
      if (arrayOfElementAssertion.length == 0)
        throw new SOAPFaultException(FAILED_CHECK, "failed security check for message body", null, null); 
    } else {
      compare(arrayOfElementIdentifier, arrayOfElementAssertion, set);
    } 
    arrayOfElementIdentifier = paramOperationSpec.getHeaderElementSpecs();
    set = paramSet1;
    str = "header";
    arrayOfElementAssertion = subsetAssertions(paramArrayOfSecurityAssertion, paramInt, str);
    compare(arrayOfElementIdentifier, arrayOfElementAssertion, set);
    arrayOfElementIdentifier = paramOperationSpec.getUnrestrictedElementSpecs();
    set = paramSet3;
    str = null;
    arrayOfElementAssertion = subsetAssertions(paramArrayOfSecurityAssertion, paramInt, str);
    compare(arrayOfElementIdentifier, arrayOfElementAssertion, set);
  }
  
  private static void compare(ElementIdentifier[] paramArrayOfElementIdentifier, ElementAssertion[] paramArrayOfElementAssertion, Set paramSet) {
    for (byte b = 0; b < paramArrayOfElementIdentifier.length; b++) {
      ElementIdentifier elementIdentifier = paramArrayOfElementIdentifier[b];
      if (!paramSet.contains(elementIdentifier.getXMLName()))
        break; 
      boolean bool = false;
      for (byte b1 = 0; b1 < paramArrayOfElementAssertion.length; b1++) {
        ElementAssertion elementAssertion = paramArrayOfElementAssertion[b1];
        if (elementAssertion.satisfies(elementIdentifier)) {
          bool = true;
          break;
        } 
      } 
      if (!bool)
        throw new SOAPFaultException(FAILED_CHECK, "failed to satisfy security requirements for type " + elementIdentifier, null, null); 
    } 
  }
  
  private static ElementAssertion[] subsetAssertions(SecurityAssertion[] paramArrayOfSecurityAssertion, int paramInt, String paramString) {
    ArrayList arrayList = new ArrayList();
    for (byte b = 0; b < paramArrayOfSecurityAssertion.length; b++) {
      SecurityAssertion securityAssertion = paramArrayOfSecurityAssertion[b];
      if (paramInt == securityAssertion.getAssertionTypeCode()) {
        ElementAssertion elementAssertion = (ElementAssertion)securityAssertion;
        if (satisfiesRestriction(elementAssertion, paramString))
          arrayList.add(elementAssertion); 
      } 
    } 
    null = new ElementAssertion[arrayList.size()];
    return (ElementAssertion[])arrayList.toArray(null);
  }
  
  private static boolean satisfiesRestriction(ElementAssertion paramElementAssertion, String paramString) {
    String str = paramElementAssertion.getRestriction();
    return (str == null || (paramString != null && paramString.equals(str)));
  }
  
  private void processSpecs(SecuritySpec paramSecuritySpec, Security paramSecurity, X509Certificate paramX509Certificate) {
    Token token;
    UsernameTokenSpec usernameTokenSpec = paramSecuritySpec.getUsernameTokenSpec();
    BinarySecurityTokenSpec binarySecurityTokenSpec = paramSecuritySpec.getBinarySecurityTokenSpec();
    SignatureSpec signatureSpec = paramSecuritySpec.getSignatureSpec();
    EncryptionSpec encryptionSpec = paramSecuritySpec.getEncryptionSpec();
    SecurityDD securityDD = this.config.getSecurityDD();
    TimestampConfig timestampConfig = securityDD.getTimestampConfig();
    if (timestampConfig == null) {
      timestampConfig = new TimestampConfig();
      securityDD.setTimestampConfig(timestampConfig);
    } 
    timestampConfig.addTimestamp(paramSecuritySpec, paramSecurity);
    if (usernameTokenSpec != null && this.config.getUsername() != null) {
      token = new UsernameTokenImpl(this.config.getUsername(), this.config.getUsernamePassword(), usernameTokenSpec.getPasswordType());
      paramSecurity.addToken(token);
    } 
    X509Certificate x509Certificate = this.config.getSignatureCert();
    PrivateKey privateKey = this.config.getSignatureKey();
    if (x509Certificate != null && privateKey != null) {
      token = factory.createToken(x509Certificate, privateKey);
    } else {
      token = null;
    } 
    if (signatureSpec != null)
      try {
        if (token == null)
          throw new SecurityConfigurationException("Service requires an identity, but none was loaded"); 
        paramSecurity.addSignature(token, signatureSpec);
        if (binarySecurityTokenSpec != null)
          paramSecurity.addToken(token); 
      } catch (SecurityProcessingException securityProcessingException) {
        throw new AssertionError("Unable to apply required signature", securityProcessingException);
      }  
    if (encryptionSpec != null) {
      if (paramX509Certificate == null)
        throw new RuntimeException("Client certificate was lost"); 
      Token token1 = factory.createToken(paramX509Certificate, null);
      try {
        paramSecurity.addEncryption(token1, encryptionSpec);
      } catch (SecurityProcessingException securityProcessingException) {
        throw new AssertionError("Problem performing encryption on response", securityProcessingException);
      } 
    } 
  }
  
  private static boolean keyEncryptionAllowed(X509Certificate paramX509Certificate) {
    boolean[] arrayOfBoolean = paramX509Certificate.getKeyUsage();
    if (arrayOfBoolean == null)
      return true; 
    return arrayOfBoolean[2];
  }
  
  public static final void initHandlerInfo(SecurityDD paramSecurityDD, HandlerInfo paramHandlerInfo) throws ConfigException {
    Map map = paramHandlerInfo.getHandlerConfig();
    PrivateKey privateKey1 = null;
    PrivateKey privateKey2 = null;
    X509Certificate x509Certificate1 = null;
    X509Certificate x509Certificate2 = null;
    try {
      ServerKeyStore.init();
    } catch (Exception exception) {
      throw new ConfigException("Failed to load server keystore", exception);
    } 
    EncryptionKey encryptionKey = paramSecurityDD.getEncryptionKey();
    if (encryptionKey != null)
      x509Certificate2 = ServerKeyStore.getCertificate(encryptionKey.getName()); 
    if (encryptionKey != null) {
      privateKey1 = ServerKeyStore.getPrivateKey(encryptionKey.getName(), encryptionKey.getPassword());
      addServerCertToWSDL(x509Certificate2, paramSecurityDD);
    } 
    SignatureKey signatureKey = paramSecurityDD.getSigningKey();
    if (signatureKey != null) {
      privateKey2 = ServerKeyStore.getPrivateKey(signatureKey.getName(), signatureKey.getPassword());
      x509Certificate1 = ServerKeyStore.getCertificate(signatureKey.getName());
    } 
    User user = paramSecurityDD.getUser();
    String str1 = null;
    String str2 = null;
    if (user != null) {
      str1 = user.getName();
      str2 = ServerKeyStore.decryptPassword(user.getPassword());
    } 
    HandlerConfig handlerConfig = new HandlerConfig(paramSecurityDD, privateKey1, x509Certificate2, privateKey2, x509Certificate1, str1, str2);
    map.put("__BEA_INTERNAL__WSSE.config", handlerConfig);
  }
  
  private static void addServerCertToWSDL(X509Certificate paramX509Certificate, SecurityDD paramSecurityDD) {
    Iterator iterator = paramSecurityDD.getSecuritySpecs();
    while (iterator.hasNext()) {
      SecuritySpec securitySpec = (SecuritySpec)iterator.next();
      if (securitySpec != null) {
        EncryptionSpec encryptionSpec = securitySpec.getEncryptionSpec();
        if (encryptionSpec != null && encryptionSpec.getCertificate() == null)
          encryptionSpec.setCertificate(paramX509Certificate); 
      } 
    } 
  }
  
  private static final class HandlerConfig {
    private final SecurityDD securityDD;
    
    private final PrivateKey encryptionKey;
    
    private final X509Certificate encryptionCert;
    
    private final PrivateKey signatureKey;
    
    private final X509Certificate signatureCert;
    
    private final String username;
    
    private final String usernamePassword;
    
    private final KeyResolver resolver;
    
    public HandlerConfig(SecurityDD param1SecurityDD, PrivateKey param1PrivateKey1, X509Certificate param1X509Certificate1, PrivateKey param1PrivateKey2, X509Certificate param1X509Certificate2, String param1String1, String param1String2) {
      this.securityDD = param1SecurityDD;
      this.encryptionKey = param1PrivateKey1;
      this.encryptionCert = param1X509Certificate1;
      this.signatureKey = param1PrivateKey2;
      this.signatureCert = param1X509Certificate2;
      this.username = param1String1;
      this.usernamePassword = param1String2;
      this.resolver = new KeyResolver();
      if (param1X509Certificate1 != null || param1PrivateKey1 != null)
        this.resolver.addKeyProvider(KeyProviderFactory.create(param1X509Certificate1, param1PrivateKey1)); 
    }
    
    public SecurityDD getSecurityDD() { return this.securityDD; }
    
    public X509Certificate getEncryptionCert() { return this.encryptionCert; }
    
    public KeyResolver getResolver() { return this.resolver; }
    
    public SecuritySpec getSecuritySpec(String param1String) { return this.securityDD.getSecuritySpec(param1String); }
    
    public PrivateKey getEncryptionKey() { return this.encryptionKey; }
    
    public PrivateKey getSignatureKey() { return this.signatureKey; }
    
    public X509Certificate getSignatureCert() { return this.signatureCert; }
    
    public String getUsername() { return this.username; }
    
    public String getUsernamePassword() { return this.usernamePassword; }
    
    public TimestampConfig getTimestampConfig() { return this.securityDD.getTimestampConfig(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\WSSEHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */