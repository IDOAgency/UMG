/*     */ package weblogic.webservice.core.handler;
/*     */ 
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.security.SubjectUtils;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.utils.CharsetMap;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.GenericHandler;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WLSOAPPart;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.context.WebServiceSession;
/*     */ import weblogic.webservice.core.soap.SOAPMessageImpl;
/*     */ import weblogic.webservice.server.AuthorizationContext;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ import weblogic.webservice.server.Dispatcher;
/*     */ import weblogic.webservice.util.BufferStream;
/*     */ import weblogic.webservice.util.FaultUtil;
/*     */ import weblogic.webservice.util.ServerKeyStore;
/*     */ import weblogic.webservice.util.ServerSecurityHelper;
/*     */ import weblogic.xml.security.InvalidSecurityException;
/*     */ import weblogic.xml.security.SecurityAssertion;
/*     */ import weblogic.xml.security.SecurityConfigurationException;
/*     */ import weblogic.xml.security.SecurityProcessingException;
/*     */ import weblogic.xml.security.UserInfo;
/*     */ import weblogic.xml.security.assertion.ElementAssertion;
/*     */ import weblogic.xml.security.assertion.IdentityAssertion;
/*     */ import weblogic.xml.security.assertion.IntegrityAssertion;
/*     */ import weblogic.xml.security.assertion.ServerHelper;
/*     */ import weblogic.xml.security.keyinfo.KeyProviderFactory;
/*     */ import weblogic.xml.security.keyinfo.KeyResolver;
/*     */ import weblogic.xml.security.specs.BinarySecurityTokenSpec;
/*     */ import weblogic.xml.security.specs.ElementIdentifier;
/*     */ import weblogic.xml.security.specs.EncryptionKey;
/*     */ import weblogic.xml.security.specs.EncryptionSpec;
/*     */ import weblogic.xml.security.specs.OperationSpec;
/*     */ import weblogic.xml.security.specs.SecurityDD;
/*     */ import weblogic.xml.security.specs.SecuritySpec;
/*     */ import weblogic.xml.security.specs.SignatureKey;
/*     */ import weblogic.xml.security.specs.SignatureSpec;
/*     */ import weblogic.xml.security.specs.TimestampConfig;
/*     */ import weblogic.xml.security.specs.User;
/*     */ import weblogic.xml.security.specs.UsernameTokenSpec;
/*     */ import weblogic.xml.security.utils.Utils;
/*     */ import weblogic.xml.security.wsse.BinarySecurityToken;
/*     */ import weblogic.xml.security.wsse.SecureSoapInputStream;
/*     */ import weblogic.xml.security.wsse.SecureSoapOutputStream;
/*     */ import weblogic.xml.security.wsse.Security;
/*     */ import weblogic.xml.security.wsse.SecurityElementFactory;
/*     */ import weblogic.xml.security.wsse.Token;
/*     */ import weblogic.xml.security.wsse.v200207.UsernameTokenImpl;
/*     */ import weblogic.xml.security.wsse.v200207.WSSEConstants;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSSEHandler
/*     */   extends GenericHandler
/*     */   implements WSSEConstants
/*     */ {
/*     */   public static final String RESPONSE_SECURITY_ATTRIBUTE = "weblogic.webservice.security.request";
/*     */   public static final String REQUEST_CERTIFICATE_ATTRIBUTE = "__BEA_INTERNAL__request.certificate";
/*     */   private static final String WSSE_CONFIG = "__BEA_INTERNAL__WSSE.config";
/*     */   private static final int USE_KEY_ENCIPHERMENT = 2;
/*  90 */   private static final QName NO_ELEMENT = Utils.getQName(QNAME_FAULT_SECURITYTOKENUNAVAILBLE);
/*     */ 
/*     */   
/*  93 */   private static final QName INVALID_SECURITY = Utils.getQName(QNAME_FAULT_INVALIDSECURITY);
/*     */ 
/*     */   
/*  96 */   private static final QName UNSUPPORTED = Utils.getQName(QNAME_FAULT_UNSUPPORTEDSECURITYTOKEN);
/*     */ 
/*     */   
/*  99 */   private static final QName FAILED_AUTH = Utils.getQName(QNAME_FAULT_FAILEDAUTHENTICATION);
/*     */ 
/*     */   
/* 102 */   private static final QName FAILED_CHECK = Utils.getQName(QNAME_FAULT_FAILEDCHECK);
/*     */ 
/*     */   
/* 105 */   private static final SecurityElementFactory factory = SecurityElementFactory.getDefaultFactory();
/*     */ 
/*     */   
/* 108 */   private static final boolean DEBUG = Security.WSSE_VERBOSE;
/*     */   
/* 110 */   private HandlerConfig config = null;
/* 111 */   private String realmName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(HandlerInfo paramHandlerInfo) {
/* 119 */     Map map = paramHandlerInfo.getHandlerConfig();
/*     */     
/* 121 */     AuthorizationContext authorizationContext = (AuthorizationContext)map.get("WSAuthorizationContext");
/*     */ 
/*     */     
/* 124 */     this.realmName = authorizationContext.getSecurityRealm();
/* 125 */     this.config = (HandlerConfig)map.get("__BEA_INTERNAL__WSSE.config");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handleRequest(MessageContext paramMessageContext) {
/* 130 */     if (DEBUG) Debug.say("handleRequest called"); 
/* 131 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*     */     
/* 133 */     WebServiceContext webServiceContext = (WebServiceContext)wLMessageContext.getProperty("weblogic.webservice.context");
/*     */ 
/*     */     
/* 136 */     webServiceContext.getSession().removeAttribute("weblogic.webservice.security.request");
/*     */ 
/*     */ 
/*     */     
/* 140 */     WLSOAPPart wLSOAPPart = (WLSOAPPart)wLMessageContext.getMessage().getSOAPPart();
/*     */     
/* 142 */     XMLInputStream xMLInputStream = null;
/*     */     try {
/* 144 */       xMLInputStream = wLSOAPPart.getXMLStreamContent();
/* 145 */     } catch (XMLStreamException xMLStreamException) {
/* 146 */       throw new AssertionError("Can't get soap as stream. ", xMLStreamException);
/* 147 */     } catch (SOAPException sOAPException) {
/* 148 */       throw new AssertionError("Can't get soap as stream. ", sOAPException);
/*     */     } 
/*     */     
/*     */     try {
/*     */       EncryptionSpec encryptionSpec;
/*     */       SignatureSpec signatureSpec;
/* 154 */       SecureSoapInputStream secureSoapInputStream = new SecureSoapInputStream(xMLInputStream, null, this.config.resolver.copy());
/*     */ 
/*     */ 
/*     */       
/* 158 */       Security security = secureSoapInputStream.getSecurityElement();
/*     */       
/* 160 */       SecurityAssertion[] arrayOfSecurityAssertion = secureSoapInputStream.getSecurityAssertions();
/* 161 */       WebServiceSession webServiceSession = webServiceContext.getSession();
/*     */ 
/*     */       
/* 164 */       wLSOAPPart.setContent(secureSoapInputStream);
/*     */ 
/*     */       
/* 167 */       Operation operation = getOperation(wLMessageContext);
/* 168 */       SecuritySpec securitySpec1 = getRequestSpec(operation, this.config);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 173 */       if (securitySpec1 != null) {
/* 174 */         signatureSpec = securitySpec1.getSignatureSpec();
/* 175 */         encryptionSpec = securitySpec1.getEncryptionSpec();
/*     */       } else {
/* 177 */         signatureSpec = null;
/* 178 */         encryptionSpec = null;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       this.config.getTimestampConfig().checkTimestamps(security, wLMessageContext);
/*     */ 
/*     */ 
/*     */       
/* 194 */       if (security == null && securitySpec1 != null) {
/* 195 */         throw new SOAPFaultException(NO_ELEMENT, "Message did not contain a valid Security Element", null, null);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 201 */       AuthenticatedSubject authenticatedSubject = assertIdentities(this.realmName, arrayOfSecurityAssertion);
/*     */ 
/*     */ 
/*     */       
/* 205 */       wLMessageContext.setProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP", authenticatedSubject);
/*     */ 
/*     */       
/* 208 */       Set set1 = secureSoapInputStream.getHeaderElementNames();
/* 209 */       Set set2 = secureSoapInputStream.getBodyElementNames();
/* 210 */       Set set3 = secureSoapInputStream.getAllElementNames();
/*     */ 
/*     */       
/* 213 */       validateSignatureSpec(signatureSpec, arrayOfSecurityAssertion, set1, set2, set3);
/*     */       
/* 215 */       validateEncryptionSpec(encryptionSpec, arrayOfSecurityAssertion, set1, set2, set3);
/*     */ 
/*     */ 
/*     */       
/* 219 */       wLMessageContext.setProperty("weblogic.webservice.security.assertions.request", arrayOfSecurityAssertion);
/*     */ 
/*     */       
/* 222 */       SecuritySpec securitySpec2 = getResponseSpec(operation, this.config);
/*     */       
/* 224 */       if (securitySpec2 != null && securitySpec2.getEncryptionSpec() != null) {
/* 225 */         saveClientCert(security, webServiceSession);
/*     */       }
/*     */     }
/* 228 */     catch (XMLStreamException xMLStreamException) {
/* 229 */       throw new SOAPFaultException(INVALID_SECURITY, xMLStreamException.getMessage(), null, DEBUG ? FaultUtil.newDetail(xMLStreamException) : null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 235 */     catch (InvalidSecurityException invalidSecurityException) {
/* 236 */       throw new SOAPFaultException(FAILED_CHECK, invalidSecurityException.getMessage(), null, null);
/*     */     } 
/* 238 */     return true;
/*     */   }
/*     */   public boolean handleResponse(MessageContext paramMessageContext) {
/*     */     SecureSoapOutputStream secureSoapOutputStream;
/*     */     BufferStream bufferStream;
/* 243 */     if (DEBUG) Debug.say("handleResponse called"); 
/* 244 */     WebServiceContext webServiceContext = (WebServiceContext)paramMessageContext.getProperty("weblogic.webservice.context");
/*     */ 
/*     */     
/* 247 */     WebServiceSession webServiceSession = webServiceContext.getSession();
/*     */     
/* 249 */     X509Certificate x509Certificate = (X509Certificate)webServiceSession.getAttribute("__BEA_INTERNAL__request.certificate");
/*     */     
/* 251 */     webServiceSession.removeAttribute("__BEA_INTERNAL__request.certificate");
/*     */     
/* 253 */     Operation operation = getOperation(paramMessageContext);
/* 254 */     SecuritySpec securitySpec = getResponseSpec(operation, this.config);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     Security security = (Security)webServiceSession.getAttribute("weblogic.webservice.security.request");
/*     */     
/* 263 */     if (security == null) {
/* 264 */       if (securitySpec == null) {
/* 265 */         return true;
/*     */       }
/* 267 */       security = factory.createSecurity(null);
/* 268 */       processSpecs(securitySpec, security, x509Certificate);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/* 278 */     WLSOAPPart wLSOAPPart = (WLSOAPPart)wLMessageContext.getMessage().getSOAPPart();
/*     */     
/* 280 */     String str = getEncoding(wLMessageContext);
/*     */     
/*     */     try {
/* 283 */       bufferStream = new BufferStream();
/*     */       
/* 285 */       secureSoapOutputStream = new SecureSoapOutputStream(security, bufferStream, str);
/* 286 */     } catch (SecurityProcessingException securityProcessingException) {
/* 287 */       securityProcessingException.printStackTrace();
/* 288 */       throw new SecurityConfigurationException("Unable to secure response", securityProcessingException);
/* 289 */     } catch (XMLStreamException xMLStreamException) {
/* 290 */       xMLStreamException.printStackTrace();
/* 291 */       throw new SecurityConfigurationException("Unable to secure response", xMLStreamException);
/*     */     } 
/*     */     
/*     */     try {
/* 295 */       wLSOAPPart.writeTo(secureSoapOutputStream);
/* 296 */       secureSoapOutputStream.close();
/* 297 */     } catch (SOAPException sOAPException) {
/* 298 */       throw new AssertionError("Unable to secure response", sOAPException);
/* 299 */     } catch (XMLStreamException xMLStreamException) {
/* 300 */       throw new AssertionError("Unable to secure response", xMLStreamException);
/*     */     } 
/*     */ 
/*     */     
/* 304 */     wLSOAPPart.setContent(bufferStream);
/* 305 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getEncoding(WLMessageContext paramWLMessageContext) {
/* 311 */     String str = paramWLMessageContext.getOperation().getPort().getBindingInfo().getCharset();
/* 312 */     if (str == null) {
/* 313 */       str = ((SOAPMessageImpl)paramWLMessageContext.getMessage()).getCharset();
/*     */     }
/* 315 */     return (str != null) ? CharsetMap.getJavaFromIANA(str) : "UTF-8";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleFault(MessageContext paramMessageContext) {
/* 324 */     if (DEBUG) Debug.say("handleFault called"); 
/* 325 */     return super.handleFault(paramMessageContext);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Operation getOperation(MessageContext paramMessageContext) {
/* 331 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/* 332 */     Operation operation = wLMessageContext.getOperation();
/* 333 */     if (operation == null) {
/*     */       try {
/* 335 */         operation = Dispatcher.getOperation(wLMessageContext);
/* 336 */       } catch (SOAPException sOAPException) {
/*     */         
/* 338 */         throw new AssertionError(sOAPException);
/*     */       } 
/*     */     }
/* 341 */     return operation;
/*     */   }
/*     */ 
/*     */   
/*     */   private static SecuritySpec getRequestSpec(Operation paramOperation, HandlerConfig paramHandlerConfig) {
/* 346 */     String str = (paramOperation != null) ? paramOperation.getInput().getSecuritySpecRef() : null;
/*     */     
/* 348 */     SecuritySpec securitySpec = (str == null) ? paramHandlerConfig.getSecuritySpec("default-spec") : paramHandlerConfig.getSecuritySpec(str);
/*     */ 
/*     */     
/* 351 */     if (DEBUG)
/* 352 */       Debug.say("using this spec for the request -- " + securitySpec); 
/* 353 */     return securitySpec;
/*     */   }
/*     */ 
/*     */   
/*     */   private static SecuritySpec getResponseSpec(Operation paramOperation, HandlerConfig paramHandlerConfig) {
/* 358 */     String str = (paramOperation != null) ? paramOperation.getOutput().getSecuritySpecRef() : null;
/* 359 */     SecuritySpec securitySpec = (str == null) ? paramHandlerConfig.getSecuritySpec("default-spec") : paramHandlerConfig.getSecuritySpec(str);
/*     */ 
/*     */     
/* 362 */     if (DEBUG)
/* 363 */       Debug.say("using this spec for the response -- " + securitySpec); 
/* 364 */     return securitySpec;
/*     */   }
/*     */ 
/*     */   
/*     */   private void saveClientCert(Security paramSecurity, WebServiceSession paramWebServiceSession) {
/* 369 */     Iterator iterator = paramSecurity.getBinarySecurityTokens();
/* 370 */     X509Certificate x509Certificate = null;
/* 371 */     boolean bool = false;
/* 372 */     while (iterator.hasNext()) {
/* 373 */       BinarySecurityToken binarySecurityToken = (BinarySecurityToken)iterator.next();
/* 374 */       x509Certificate = binarySecurityToken.getCertificate();
/* 375 */       if (x509Certificate != null && keyEncryptionAllowed(x509Certificate)) {
/*     */         
/* 377 */         paramWebServiceSession.setAttribute("__BEA_INTERNAL__request.certificate", x509Certificate);
/*     */         
/* 379 */         bool = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 383 */     if (!bool) {
/* 384 */       throw new SOAPFaultException(INVALID_SECURITY, "Response requires encryption; no certificate with suitable key usage was found", null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final AuthenticatedSubject assertIdentities(String paramString, SecurityAssertion[] paramArrayOfSecurityAssertion) {
/* 398 */     HashMap hashMap = new HashMap();
/* 399 */     ArrayList arrayList = new ArrayList(3);
/*     */     
/* 401 */     X509Certificate x509Certificate = null;
/* 402 */     Subject subject = null;
/*     */ 
/*     */     
/* 405 */     arrayList.add(ServerSecurityHelper.getCurrentSubject());
/*     */     
/* 407 */     for (byte b = 0; b < paramArrayOfSecurityAssertion.length; b++) {
/* 408 */       UserInfo userInfo; IdentityAssertion identityAssertion; X509Certificate x509Certificate1; IntegrityAssertion integrityAssertion; SecurityAssertion securityAssertion = paramArrayOfSecurityAssertion[b];
/* 409 */       switch (securityAssertion.getAssertionTypeCode()) {
/*     */         case 1:
/*     */         case 2:
/* 412 */           integrityAssertion = (IntegrityAssertion)securityAssertion;
/* 413 */           x509Certificate1 = integrityAssertion.getCertificate();
/* 414 */           if (x509Certificate1 == null) {
/*     */             break;
/*     */           }
/*     */           
/* 418 */           if (x509Certificate == x509Certificate1) {
/* 419 */             ServerHelper.setSubject(integrityAssertion, subject);
/*     */           } else {
/* 421 */             x509Certificate = x509Certificate1;
/*     */ 
/*     */             
/* 424 */             subject = (Subject)hashMap.get(x509Certificate1);
/* 425 */             if (subject == null) {
/*     */               
/* 427 */               AuthenticatedSubject authenticatedSubject = assertIdentity(x509Certificate1, paramString);
/* 428 */               subject = authenticatedSubject.getSubject();
/*     */               
/* 430 */               hashMap.put(x509Certificate, subject);
/*     */             } 
/*     */           } 
/*     */           
/* 434 */           ServerHelper.setSubject(integrityAssertion, subject);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 0:
/* 439 */           identityAssertion = (IdentityAssertion)securityAssertion;
/*     */           
/* 441 */           userInfo = identityAssertion.getUserInfo();
/* 442 */           if (userInfo != null) {
/* 443 */             AuthenticatedSubject authenticatedSubject = assertIdentity(userInfo, paramString);
/* 444 */             if (authenticatedSubject != null) arrayList.add(authenticatedSubject); 
/*     */             break;
/*     */           } 
/* 447 */           throw new AssertionError("Unsupported Identity Assertion " + identityAssertion);
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 453 */     AuthenticatedSubject[] arrayOfAuthenticatedSubject = new AuthenticatedSubject[arrayList.size()];
/* 454 */     arrayOfAuthenticatedSubject = (AuthenticatedSubject[])arrayList.toArray(arrayOfAuthenticatedSubject);
/*     */ 
/*     */     
/* 457 */     return SubjectUtils.combineSubjects(arrayOfAuthenticatedSubject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AuthenticatedSubject assertIdentity(X509Certificate paramX509Certificate, String paramString) {
/*     */     try {
/* 465 */       X509Certificate[] arrayOfX509Certificate = new X509Certificate[1];
/* 466 */       arrayOfX509Certificate[0] = paramX509Certificate;
/* 467 */       return ServerSecurityHelper.assertIdentity(arrayOfX509Certificate, paramString);
/* 468 */     } catch (LoginException loginException) {
/* 469 */       throw new SOAPFaultException(FAILED_AUTH, loginException.getMessage(), null, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static AuthenticatedSubject assertIdentity(UserInfo paramUserInfo, String paramString) {
/* 476 */     String str = paramUserInfo.getPassword();
/* 477 */     if (str != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 489 */         return ServerSecurityHelper.assertIdentity(paramUserInfo.getUsername(), str, paramString);
/*     */       
/*     */       }
/* 492 */       catch (LoginException loginException) {
/* 493 */         throw new SOAPFaultException(FAILED_AUTH, loginException.getMessage(), null, null);
/*     */       } 
/*     */     }
/*     */     if (paramUserInfo.getPasswordDigest() != null) {
/*     */       throw new SOAPFaultException(UNSUPPORTED, "Password Digests not supported", null, null);
/*     */     }
/*     */     throw new SOAPFaultException(INVALID_SECURITY, "UsernameToken did not contain a password", null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 504 */   private static final void validateEncryptionSpec(EncryptionSpec paramEncryptionSpec, SecurityAssertion[] paramArrayOfSecurityAssertion, Set paramSet1, Set paramSet2, Set paramSet3) { validateSpec(paramEncryptionSpec, paramArrayOfSecurityAssertion, 4, paramSet1, paramSet2, paramSet3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 519 */   private static void validateSignatureSpec(SignatureSpec paramSignatureSpec, SecurityAssertion[] paramArrayOfSecurityAssertion, Set paramSet1, Set paramSet2, Set paramSet3) { validateSpec(paramSignatureSpec, paramArrayOfSecurityAssertion, 2, paramSet1, paramSet2, paramSet3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void validateSpec(OperationSpec paramOperationSpec, SecurityAssertion[] paramArrayOfSecurityAssertion, int paramInt, Set paramSet1, Set paramSet2, Set paramSet3) {
/* 535 */     if (paramOperationSpec == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 540 */     ElementIdentifier[] arrayOfElementIdentifier = paramOperationSpec.getBodyElementSpecs();
/* 541 */     Set set = paramSet2;
/* 542 */     String str = "body";
/*     */     
/* 544 */     ElementAssertion[] arrayOfElementAssertion = subsetAssertions(paramArrayOfSecurityAssertion, paramInt, str);
/*     */ 
/*     */     
/* 547 */     if (paramOperationSpec.entireBody()) {
/* 548 */       if (arrayOfElementAssertion.length == 0) {
/* 549 */         throw new SOAPFaultException(FAILED_CHECK, "failed security check for message body", null, null);
/*     */       
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 555 */       compare(arrayOfElementIdentifier, arrayOfElementAssertion, set);
/*     */     } 
/*     */     
/* 558 */     arrayOfElementIdentifier = paramOperationSpec.getHeaderElementSpecs();
/* 559 */     set = paramSet1;
/* 560 */     str = "header";
/*     */     
/* 562 */     arrayOfElementAssertion = subsetAssertions(paramArrayOfSecurityAssertion, paramInt, str);
/*     */ 
/*     */     
/* 565 */     compare(arrayOfElementIdentifier, arrayOfElementAssertion, set);
/*     */     
/* 567 */     arrayOfElementIdentifier = paramOperationSpec.getUnrestrictedElementSpecs();
/* 568 */     set = paramSet3;
/* 569 */     str = null;
/*     */     
/* 571 */     arrayOfElementAssertion = subsetAssertions(paramArrayOfSecurityAssertion, paramInt, str);
/*     */ 
/*     */     
/* 574 */     compare(arrayOfElementIdentifier, arrayOfElementAssertion, set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void compare(ElementIdentifier[] paramArrayOfElementIdentifier, ElementAssertion[] paramArrayOfElementAssertion, Set paramSet) {
/* 581 */     for (byte b = 0; b < paramArrayOfElementIdentifier.length; b++) {
/* 582 */       ElementIdentifier elementIdentifier = paramArrayOfElementIdentifier[b];
/*     */ 
/*     */       
/* 585 */       if (!paramSet.contains(elementIdentifier.getXMLName()))
/*     */         break; 
/* 587 */       boolean bool = false;
/* 588 */       for (byte b1 = 0; b1 < paramArrayOfElementAssertion.length; b1++) {
/* 589 */         ElementAssertion elementAssertion = paramArrayOfElementAssertion[b1];
/* 590 */         if (elementAssertion.satisfies(elementIdentifier)) {
/* 591 */           bool = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 595 */       if (!bool) {
/* 596 */         throw new SOAPFaultException(FAILED_CHECK, "failed to satisfy security requirements for type " + elementIdentifier, null, null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ElementAssertion[] subsetAssertions(SecurityAssertion[] paramArrayOfSecurityAssertion, int paramInt, String paramString) {
/* 609 */     ArrayList arrayList = new ArrayList();
/* 610 */     for (byte b = 0; b < paramArrayOfSecurityAssertion.length; b++) {
/* 611 */       SecurityAssertion securityAssertion = paramArrayOfSecurityAssertion[b];
/* 612 */       if (paramInt == securityAssertion.getAssertionTypeCode()) {
/* 613 */         ElementAssertion elementAssertion = (ElementAssertion)securityAssertion;
/* 614 */         if (satisfiesRestriction(elementAssertion, paramString))
/* 615 */           arrayList.add(elementAssertion); 
/*     */       } 
/*     */     } 
/* 618 */     null = new ElementAssertion[arrayList.size()];
/* 619 */     return (ElementAssertion[])arrayList.toArray(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean satisfiesRestriction(ElementAssertion paramElementAssertion, String paramString) {
/* 626 */     String str = paramElementAssertion.getRestriction();
/* 627 */     return (str == null || (paramString != null && paramString.equals(str)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processSpecs(SecuritySpec paramSecuritySpec, Security paramSecurity, X509Certificate paramX509Certificate) {
/*     */     Token token;
/* 638 */     UsernameTokenSpec usernameTokenSpec = paramSecuritySpec.getUsernameTokenSpec();
/* 639 */     BinarySecurityTokenSpec binarySecurityTokenSpec = paramSecuritySpec.getBinarySecurityTokenSpec();
/* 640 */     SignatureSpec signatureSpec = paramSecuritySpec.getSignatureSpec();
/* 641 */     EncryptionSpec encryptionSpec = paramSecuritySpec.getEncryptionSpec();
/*     */     
/* 643 */     SecurityDD securityDD = this.config.getSecurityDD();
/* 644 */     TimestampConfig timestampConfig = securityDD.getTimestampConfig();
/*     */     
/* 646 */     if (timestampConfig == null) {
/* 647 */       timestampConfig = new TimestampConfig();
/* 648 */       securityDD.setTimestampConfig(timestampConfig);
/*     */     } 
/*     */ 
/*     */     
/* 652 */     timestampConfig.addTimestamp(paramSecuritySpec, paramSecurity);
/*     */     
/* 654 */     if (usernameTokenSpec != null && this.config.getUsername() != null) {
/*     */ 
/*     */       
/* 657 */       token = new UsernameTokenImpl(this.config.getUsername(), this.config.getUsernamePassword(), usernameTokenSpec.getPasswordType());
/*     */ 
/*     */       
/* 660 */       paramSecurity.addToken(token);
/*     */     } 
/*     */ 
/*     */     
/* 664 */     X509Certificate x509Certificate = this.config.getSignatureCert();
/* 665 */     PrivateKey privateKey = this.config.getSignatureKey();
/*     */     
/* 667 */     if (x509Certificate != null && privateKey != null) {
/* 668 */       token = factory.createToken(x509Certificate, privateKey);
/*     */     } else {
/* 670 */       token = null;
/*     */     } 
/*     */     
/* 673 */     if (signatureSpec != null) {
/*     */       try {
/* 675 */         if (token == null) {
/* 676 */           throw new SecurityConfigurationException("Service requires an identity, but none was loaded");
/*     */         }
/*     */         
/* 679 */         paramSecurity.addSignature(token, signatureSpec);
/*     */ 
/*     */         
/* 682 */         if (binarySecurityTokenSpec != null) {
/* 683 */           paramSecurity.addToken(token);
/*     */         }
/*     */       }
/* 686 */       catch (SecurityProcessingException securityProcessingException) {
/* 687 */         throw new AssertionError("Unable to apply required signature", securityProcessingException);
/*     */       } 
/*     */     }
/*     */     
/* 691 */     if (encryptionSpec != null) {
/* 692 */       if (paramX509Certificate == null) {
/* 693 */         throw new RuntimeException("Client certificate was lost");
/*     */       }
/* 695 */       Token token1 = factory.createToken(paramX509Certificate, null);
/*     */       try {
/* 697 */         paramSecurity.addEncryption(token1, encryptionSpec);
/* 698 */       } catch (SecurityProcessingException securityProcessingException) {
/* 699 */         throw new AssertionError("Problem performing encryption on response", securityProcessingException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean keyEncryptionAllowed(X509Certificate paramX509Certificate) {
/* 710 */     boolean[] arrayOfBoolean = paramX509Certificate.getKeyUsage();
/* 711 */     if (arrayOfBoolean == null) {
/* 712 */       return true;
/*     */     }
/* 714 */     return arrayOfBoolean[2];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void initHandlerInfo(SecurityDD paramSecurityDD, HandlerInfo paramHandlerInfo) throws ConfigException {
/* 731 */     Map map = paramHandlerInfo.getHandlerConfig();
/* 732 */     PrivateKey privateKey1 = null;
/* 733 */     PrivateKey privateKey2 = null;
/* 734 */     X509Certificate x509Certificate1 = null;
/* 735 */     X509Certificate x509Certificate2 = null;
/*     */     
/*     */     try {
/* 738 */       ServerKeyStore.init();
/* 739 */     } catch (Exception exception) {
/* 740 */       throw new ConfigException("Failed to load server keystore", exception);
/*     */     } 
/*     */     
/* 743 */     EncryptionKey encryptionKey = paramSecurityDD.getEncryptionKey();
/* 744 */     if (encryptionKey != null) {
/* 745 */       x509Certificate2 = ServerKeyStore.getCertificate(encryptionKey.getName());
/*     */     }
/*     */     
/* 748 */     if (encryptionKey != null) {
/* 749 */       privateKey1 = ServerKeyStore.getPrivateKey(encryptionKey.getName(), encryptionKey.getPassword());
/*     */       
/* 751 */       addServerCertToWSDL(x509Certificate2, paramSecurityDD);
/*     */     } 
/*     */     
/* 754 */     SignatureKey signatureKey = paramSecurityDD.getSigningKey();
/* 755 */     if (signatureKey != null) {
/* 756 */       privateKey2 = ServerKeyStore.getPrivateKey(signatureKey.getName(), signatureKey.getPassword());
/*     */ 
/*     */       
/* 759 */       x509Certificate1 = ServerKeyStore.getCertificate(signatureKey.getName());
/*     */     } 
/*     */     
/* 762 */     User user = paramSecurityDD.getUser();
/* 763 */     String str1 = null;
/* 764 */     String str2 = null;
/* 765 */     if (user != null) {
/* 766 */       str1 = user.getName();
/* 767 */       str2 = ServerKeyStore.decryptPassword(user.getPassword());
/*     */     } 
/* 769 */     HandlerConfig handlerConfig = new HandlerConfig(paramSecurityDD, privateKey1, x509Certificate2, privateKey2, x509Certificate1, str1, str2);
/*     */ 
/*     */     
/* 772 */     map.put("__BEA_INTERNAL__WSSE.config", handlerConfig);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addServerCertToWSDL(X509Certificate paramX509Certificate, SecurityDD paramSecurityDD) {
/* 828 */     Iterator iterator = paramSecurityDD.getSecuritySpecs();
/* 829 */     while (iterator.hasNext()) {
/* 830 */       SecuritySpec securitySpec = (SecuritySpec)iterator.next();
/*     */       
/* 832 */       if (securitySpec != null) {
/* 833 */         EncryptionSpec encryptionSpec = securitySpec.getEncryptionSpec();
/* 834 */         if (encryptionSpec != null && encryptionSpec.getCertificate() == null) {
/* 835 */           encryptionSpec.setCertificate(paramX509Certificate);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class HandlerConfig
/*     */   {
/*     */     private final SecurityDD securityDD;
/*     */     
/*     */     private final PrivateKey encryptionKey;
/*     */     
/*     */     private final X509Certificate encryptionCert;
/*     */     
/*     */     private final PrivateKey signatureKey;
/*     */     
/*     */     private final X509Certificate signatureCert;
/*     */     
/*     */     private final String username;
/*     */     
/*     */     private final String usernamePassword;
/*     */     private final KeyResolver resolver;
/*     */     
/*     */     public HandlerConfig(SecurityDD param1SecurityDD, PrivateKey param1PrivateKey1, X509Certificate param1X509Certificate1, PrivateKey param1PrivateKey2, X509Certificate param1X509Certificate2, String param1String1, String param1String2) {
/* 860 */       this.securityDD = param1SecurityDD;
/* 861 */       this.encryptionKey = param1PrivateKey1;
/* 862 */       this.encryptionCert = param1X509Certificate1;
/* 863 */       this.signatureKey = param1PrivateKey2;
/* 864 */       this.signatureCert = param1X509Certificate2;
/* 865 */       this.username = param1String1;
/* 866 */       this.usernamePassword = param1String2;
/* 867 */       this.resolver = new KeyResolver();
/* 868 */       if (param1X509Certificate1 != null || param1PrivateKey1 != null) {
/* 869 */         this.resolver.addKeyProvider(KeyProviderFactory.create(param1X509Certificate1, param1PrivateKey1));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 876 */     public SecurityDD getSecurityDD() { return this.securityDD; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 881 */     public X509Certificate getEncryptionCert() { return this.encryptionCert; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 886 */     public KeyResolver getResolver() { return this.resolver; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 891 */     public SecuritySpec getSecuritySpec(String param1String) { return this.securityDD.getSecuritySpec(param1String); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 896 */     public PrivateKey getEncryptionKey() { return this.encryptionKey; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 901 */     public PrivateKey getSignatureKey() { return this.signatureKey; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 906 */     public X509Certificate getSignatureCert() { return this.signatureCert; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 911 */     public String getUsername() { return this.username; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 916 */     public String getUsernamePassword() { return this.usernamePassword; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 921 */     public TimestampConfig getTimestampConfig() { return this.securityDD.getTimestampConfig(); }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\WSSEHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */