package weblogic.webservice.core.handler;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.UndeclaredThrowableException;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import javax.security.auth.Subject;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.holders.Holder;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.PrivilegedActions;
import weblogic.security.service.SecurityServiceManager;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WLSOAPMessage;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.util.FaultUtil;
import weblogic.webservice.util.OrderedMap;
import weblogic.xml.schema.binding.TypeMapping;

public final class InvokeHandler extends GenericHandler {
  private static final boolean debug = false;
  
  private static final boolean verbose = false;
  
  private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
  
  public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    Operation operation = wLMessageContext.getOperation();
    Message message = operation.getInput();
    final InvocationHandler target = operation.getInvocationHandler();
    WebServiceContext webServiceContext = (WebServiceContext)wLMessageContext.getProperty("weblogic.webservice.context");
    try {
      SOAPMessage sOAPMessage1 = wLMessageContext.getMessage();
      SOAPEnvelope sOAPEnvelope1 = sOAPMessage1.getSOAPPart().getEnvelope();
      SOAPBody sOAPBody1 = sOAPEnvelope1.getBody();
      OrderedMap orderedMap = new OrderedMap();
      message.toJava(orderedMap, wLMessageContext.getMessage(), webServiceContext);
      Message message1 = operation.getOutput();
      Map map = changeToParameterOrder(orderedMap, operation);
      Object object = null;
      Subject subject = (Subject)wLMessageContext.getProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP");
      if (subject == null) {
        object = invocationHandler.invoke(operation.getName(), toArray(map), wLMessageContext);
      } else {
        wLMessageContext.removeProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP");
        AuthenticatedSubject authenticatedSubject = new AuthenticatedSubject(subject);
        final String opName = operation.getName();
        final Object[] params = toArray(map);
        final WLMessageContext mc = wLMessageContext;
        PrivilegedExceptionAction privilegedExceptionAction = new PrivilegedExceptionAction() {
            private final InvocationHandler val$target;
            
            private final String val$opName;
            
            private final Object[] val$params;
            
            private final WLMessageContext val$mc;
            
            private final InvokeHandler this$0;
            
            public Object run() throws SOAPException, IOException, TargetInvocationException { return target.invoke(opName, params, mc); }
          };
        try {
          object = SecurityServiceManager.runAs(getKernelID(), authenticatedSubject, privilegedExceptionAction);
        } catch (PrivilegedActionException privilegedActionException) {
          Exception exception = privilegedActionException.getException();
          if (exception instanceof SOAPException)
            throw (SOAPException)exception; 
          if (exception instanceof RuntimeException)
            throw (RuntimeException)exception; 
          throw new UndeclaredThrowableException(exception);
        } 
      } 
      SOAPMessage sOAPMessage2 = wLMessageContext.clearMessage();
      if (((WLSOAPMessage)sOAPMessage1).isSOAP12())
        ((WLSOAPMessage)sOAPMessage2).setSOAP12(); 
      SOAPEnvelope sOAPEnvelope2 = sOAPMessage2.getSOAPPart().getEnvelope();
      SOAPBody sOAPBody2 = sOAPEnvelope2.getBody();
      Object[] arrayOfObject = getResults(object, map, message1);
      message1.toXML(sOAPMessage2, arrayOfObject, webServiceContext);
    } catch (SOAPException sOAPException) {
      final String opName = WebServiceLogger.logInvokeHandlerSoapException();
      WebServiceLogger.logStackTrace(str, sOAPException);
      throw new JAXRPCException(sOAPException);
    } catch (TargetInvocationException targetInvocationException) {
      wLMessageContext.setFault(true);
      serializeFault(targetInvocationException, operation, wLMessageContext);
      throw new JAXRPCException(targetInvocationException);
    } 
    return true;
  }
  
  private void serializeFault(TargetInvocationException paramTargetInvocationException, Operation paramOperation, WLMessageContext paramWLMessageContext) {
    Message message = null;
    for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
      Message message1 = (Message)iterator.next();
      Part part = (Part)message1.getParts().next();
      if (part.getJavaType().isAssignableFrom(paramTargetInvocationException.getCause().getClass())) {
        message = message1;
        break;
      } 
    } 
    if (message != null) {
      WebServiceContext webServiceContext = (WebServiceContext)paramWLMessageContext.getProperty("weblogic.webservice.context");
      try {
        message.toXML(paramWLMessageContext.clearMessage(), new Object[] { paramTargetInvocationException.getCause() }, webServiceContext);
      } catch (SOAPException sOAPException) {
        String str = WebServiceLogger.logInvokeHandlerSoapException();
        WebServiceLogger.logStackTrace(str, sOAPException);
        throw new JAXRPCException(sOAPException);
      } 
    } else {
      paramWLMessageContext.setMessage(FaultUtil.exception2Fault(paramTargetInvocationException.getCause()));
    } 
  }
  
  private Object[] getResults(Object paramObject, Map paramMap, Message paramMessage) {
    if (paramMessage.isVoid())
      return new Object[0]; 
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = paramMessage.getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.RETURN) {
        arrayList.add(paramObject);
        continue;
      } 
      Object object = paramMap.get(part.getName());
      if (object != null) {
        if (object instanceof Holder) {
          arrayList.add(getValue((Holder)object));
          continue;
        } 
        throw new JAXRPCException("this operation is using multiple output parameter. but type of the parameter is not a holder class.");
      } 
    } 
    return arrayList.toArray();
  }
  
  private Object getValue(Holder paramHolder) {
    try {
      Field field = paramHolder.getClass().getField("value");
      return field.get(paramHolder);
    } catch (NoSuchFieldException noSuchFieldException) {
      throw new JAXRPCException("unable to find value field in the holder class:", noSuchFieldException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new JAXRPCException("member field value is not a public field in the holder class", illegalAccessException);
    } 
  }
  
  private void setValue(Holder paramHolder, Object paramObject) {
    try {
      Field field = paramHolder.getClass().getField("value");
      field.set(paramHolder, paramObject);
    } catch (NoSuchFieldException noSuchFieldException) {
      throw new JAXRPCException("unable to find value field in the holder class:", noSuchFieldException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new JAXRPCException("member field value is not a public field in the holder class", illegalAccessException);
    } 
  }
  
  private Map changeToInputOrder(Map paramMap, Operation paramOperation) {
    if (paramMap.size() == 0)
      return paramMap; 
    OrderedMap orderedMap = new OrderedMap();
    for (Iterator iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      Object object = paramMap.get(part.getName());
      orderedMap.put(part.getName(), object);
    } 
    return orderedMap;
  }
  
  private Map changeToParameterOrder(Map paramMap, Operation paramOperation) {
    String[] arrayOfString = paramOperation.getParameterOrder();
    if (arrayOfString == null || arrayOfString.length == 0)
      return changeToInputOrder(paramMap, paramOperation); 
    OrderedMap orderedMap = new OrderedMap();
    for (byte b = 0; b < arrayOfString.length; b++) {
      Object object = paramMap.get(arrayOfString[b]);
      Part part = getPart(arrayOfString[b], paramOperation);
      if (part.getMode() == Part.Mode.INOUT || part.getMode() == Part.Mode.OUT)
        object = getHolderInstance(part, object); 
      orderedMap.put(part.getName(), object);
    } 
    return orderedMap;
  }
  
  private Part getPart(String paramString, Operation paramOperation) {
    Part part = paramOperation.getInput().getPart(paramString);
    if (part == null)
      part = paramOperation.getOutput().getPart(paramString); 
    if (part == null)
      throw new JAXRPCException("Internal error: part not found:" + paramString); 
    return part;
  }
  
  private Object getHolderInstance(Part paramPart, Object paramObject) {
    if (paramObject != null && paramObject instanceof Holder)
      return paramObject; 
    try {
      Class clazz = paramPart.getJavaType();
      if (!Holder.class.isAssignableFrom(clazz)) {
        TypeMapping typeMapping = (TypeMapping)paramPart.getTypeMapping();
        clazz = typeMapping.getHolderClass(paramPart.getJavaType(), paramPart.getXMLType());
      } 
      Holder holder = (Holder)clazz.newInstance();
      if (paramObject != null)
        setValue(holder, paramObject); 
      return holder;
    } catch (IOException iOException) {
      throw new JAXRPCException("failed to get holder class", iOException);
    } catch (InstantiationException instantiationException) {
      throw new JAXRPCException("failed to create an instance of the holder class:", instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new JAXRPCException("failed to create an instance of the holder class:", illegalAccessException);
    } 
  }
  
  private SOAPBody getBody(SOAPMessage paramSOAPMessage) throws SOAPException {
    SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
    return sOAPEnvelope.getBody();
  }
  
  private Object[] toArray(Map paramMap) { return paramMap.values().toArray(); }
  
  private static AuthenticatedSubject getKernelID() { return kernelID; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\InvokeHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */