/*     */ package weblogic.webservice.core.handler;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.UndeclaredThrowableException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.holders.Holder;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.security.service.SecurityServiceManager;
/*     */ import weblogic.webservice.GenericHandler;
/*     */ import weblogic.webservice.InvocationHandler;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WLSOAPMessage;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.util.FaultUtil;
/*     */ import weblogic.webservice.util.OrderedMap;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InvokeHandler
/*     */   extends GenericHandler
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   private static final boolean verbose = false;
/*  66 */   private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
/*  75 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*     */     
/*  77 */     Operation operation = wLMessageContext.getOperation();
/*     */ 
/*     */ 
/*     */     
/*  81 */     Message message = operation.getInput();
/*     */     
/*  83 */     final InvocationHandler target = operation.getInvocationHandler();
/*     */     
/*  85 */     WebServiceContext webServiceContext = (WebServiceContext)wLMessageContext.getProperty("weblogic.webservice.context");
/*     */ 
/*     */     
/*     */     try {
/*  89 */       SOAPMessage sOAPMessage1 = wLMessageContext.getMessage();
/*  90 */       SOAPEnvelope sOAPEnvelope1 = sOAPMessage1.getSOAPPart().getEnvelope();
/*  91 */       SOAPBody sOAPBody1 = sOAPEnvelope1.getBody();
/*     */       
/*  93 */       OrderedMap orderedMap = new OrderedMap();
/*  94 */       message.toJava(orderedMap, wLMessageContext.getMessage(), webServiceContext);
/*     */       
/*  96 */       Message message1 = operation.getOutput();
/*  97 */       Map map = changeToParameterOrder(orderedMap, operation);
/*     */       
/*  99 */       Object object = null;
/*     */       
/* 101 */       Subject subject = (Subject)wLMessageContext.getProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP");
/*     */ 
/*     */       
/* 104 */       if (subject == null) {
/* 105 */         object = invocationHandler.invoke(operation.getName(), toArray(map), wLMessageContext);
/*     */       } else {
/*     */         
/* 108 */         wLMessageContext.removeProperty("__BEA_PRIVATE_AUTHENTICATED_SUBJECT_PROP");
/*     */         
/* 110 */         AuthenticatedSubject authenticatedSubject = new AuthenticatedSubject(subject);
/*     */         
/* 112 */         final String opName = operation.getName();
/* 113 */         final Object[] params = toArray(map);
/* 114 */         final WLMessageContext mc = wLMessageContext;
/*     */         
/* 116 */         PrivilegedExceptionAction privilegedExceptionAction = new PrivilegedExceptionAction() { private final InvocationHandler val$target; private final String val$opName; private final Object[] val$params;
/*     */             private final WLMessageContext val$mc;
/*     */             
/* 119 */             public Object run() throws SOAPException, IOException, TargetInvocationException { return target.invoke(opName, params, mc); }
/*     */             
/*     */             private final InvokeHandler this$0; }
/*     */           ;
/*     */         try {
/* 124 */           object = SecurityServiceManager.runAs(getKernelID(), authenticatedSubject, privilegedExceptionAction);
/*     */         
/*     */         }
/* 127 */         catch (PrivilegedActionException privilegedActionException) {
/* 128 */           Exception exception = privilegedActionException.getException();
/* 129 */           if (exception instanceof SOAPException)
/* 130 */             throw (SOAPException)exception; 
/* 131 */           if (exception instanceof RuntimeException) {
/* 132 */             throw (RuntimeException)exception;
/*     */           }
/* 134 */           throw new UndeclaredThrowableException(exception);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 139 */       SOAPMessage sOAPMessage2 = wLMessageContext.clearMessage();
/*     */       
/* 141 */       if (((WLSOAPMessage)sOAPMessage1).isSOAP12()) {
/* 142 */         ((WLSOAPMessage)sOAPMessage2).setSOAP12();
/*     */       }
/*     */       
/* 145 */       SOAPEnvelope sOAPEnvelope2 = sOAPMessage2.getSOAPPart().getEnvelope();
/*     */ 
/*     */       
/* 148 */       SOAPBody sOAPBody2 = sOAPEnvelope2.getBody();
/*     */       
/* 150 */       Object[] arrayOfObject = getResults(object, map, message1);
/* 151 */       message1.toXML(sOAPMessage2, arrayOfObject, webServiceContext);
/*     */     }
/* 153 */     catch (SOAPException sOAPException) {
/* 154 */       final String opName = WebServiceLogger.logInvokeHandlerSoapException();
/* 155 */       WebServiceLogger.logStackTrace(str, sOAPException);
/* 156 */       throw new JAXRPCException(sOAPException);
/* 157 */     } catch (TargetInvocationException targetInvocationException) {
/* 158 */       wLMessageContext.setFault(true);
/* 159 */       serializeFault(targetInvocationException, operation, wLMessageContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 168 */       throw new JAXRPCException(targetInvocationException);
/*     */     } 
/*     */     
/* 171 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void serializeFault(TargetInvocationException paramTargetInvocationException, Operation paramOperation, WLMessageContext paramWLMessageContext) {
/* 178 */     Message message = null;
/*     */     
/* 180 */     for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
/* 181 */       Message message1 = (Message)iterator.next();
/*     */       
/* 183 */       Part part = (Part)message1.getParts().next();
/*     */       
/* 185 */       if (part.getJavaType().isAssignableFrom(paramTargetInvocationException.getCause().getClass())) {
/* 186 */         message = message1;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 191 */     if (message != null) {
/* 192 */       WebServiceContext webServiceContext = (WebServiceContext)paramWLMessageContext.getProperty("weblogic.webservice.context");
/*     */ 
/*     */       
/*     */       try {
/* 196 */         message.toXML(paramWLMessageContext.clearMessage(), new Object[] { paramTargetInvocationException.getCause() }, webServiceContext);
/* 197 */       } catch (SOAPException sOAPException) {
/* 198 */         String str = WebServiceLogger.logInvokeHandlerSoapException();
/* 199 */         WebServiceLogger.logStackTrace(str, sOAPException);
/* 200 */         throw new JAXRPCException(sOAPException);
/*     */       } 
/*     */     } else {
/* 203 */       paramWLMessageContext.setMessage(FaultUtil.exception2Fault(paramTargetInvocationException.getCause()));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Object[] getResults(Object paramObject, Map paramMap, Message paramMessage) {
/* 209 */     if (paramMessage.isVoid()) {
/* 210 */       return new Object[0];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 220 */     for (Iterator iterator = paramMessage.getParts(); iterator.hasNext(); ) {
/* 221 */       Part part = (Part)iterator.next();
/*     */       
/* 223 */       if (part.getMode() == Part.Mode.RETURN) {
/* 224 */         arrayList.add(paramObject);
/*     */         continue;
/*     */       } 
/* 227 */       Object object = paramMap.get(part.getName());
/*     */       
/* 229 */       if (object != null) {
/* 230 */         if (object instanceof Holder) {
/* 231 */           arrayList.add(getValue((Holder)object)); continue;
/*     */         } 
/* 233 */         throw new JAXRPCException("this operation is using multiple output parameter. but type of the parameter is not a holder class.");
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     return arrayList.toArray();
/*     */   }
/*     */   
/*     */   private Object getValue(Holder paramHolder) {
/*     */     try {
/* 246 */       Field field = paramHolder.getClass().getField("value");
/* 247 */       return field.get(paramHolder);
/* 248 */     } catch (NoSuchFieldException noSuchFieldException) {
/* 249 */       throw new JAXRPCException("unable to find value field in the holder class:", noSuchFieldException);
/*     */     }
/* 251 */     catch (IllegalAccessException illegalAccessException) {
/* 252 */       throw new JAXRPCException("member field value is not a public field in the holder class", illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void setValue(Holder paramHolder, Object paramObject) {
/*     */     try {
/* 259 */       Field field = paramHolder.getClass().getField("value");
/* 260 */       field.set(paramHolder, paramObject);
/* 261 */     } catch (NoSuchFieldException noSuchFieldException) {
/* 262 */       throw new JAXRPCException("unable to find value field in the holder class:", noSuchFieldException);
/*     */     }
/* 264 */     catch (IllegalAccessException illegalAccessException) {
/* 265 */       throw new JAXRPCException("member field value is not a public field in the holder class", illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map changeToInputOrder(Map paramMap, Operation paramOperation) {
/* 272 */     if (paramMap.size() == 0) {
/* 273 */       return paramMap;
/*     */     }
/*     */     
/* 276 */     OrderedMap orderedMap = new OrderedMap();
/*     */     
/* 278 */     for (Iterator iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 279 */       Part part = (Part)iterator.next();
/*     */       
/* 281 */       Object object = paramMap.get(part.getName());
/* 282 */       orderedMap.put(part.getName(), object);
/*     */     } 
/*     */     
/* 285 */     return orderedMap;
/*     */   }
/*     */ 
/*     */   
/*     */   private Map changeToParameterOrder(Map paramMap, Operation paramOperation) {
/* 290 */     String[] arrayOfString = paramOperation.getParameterOrder();
/*     */     
/* 292 */     if (arrayOfString == null || arrayOfString.length == 0) {
/* 293 */       return changeToInputOrder(paramMap, paramOperation);
/*     */     }
/*     */     
/* 296 */     OrderedMap orderedMap = new OrderedMap();
/*     */     
/* 298 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 299 */       Object object = paramMap.get(arrayOfString[b]);
/* 300 */       Part part = getPart(arrayOfString[b], paramOperation);
/*     */ 
/*     */       
/* 303 */       if (part.getMode() == Part.Mode.INOUT || part.getMode() == Part.Mode.OUT)
/*     */       {
/* 305 */         object = getHolderInstance(part, object);
/*     */       }
/*     */       
/* 308 */       orderedMap.put(part.getName(), object);
/*     */     } 
/*     */     
/* 311 */     return orderedMap;
/*     */   }
/*     */ 
/*     */   
/*     */   private Part getPart(String paramString, Operation paramOperation) {
/* 316 */     Part part = paramOperation.getInput().getPart(paramString);
/*     */     
/* 318 */     if (part == null) {
/* 319 */       part = paramOperation.getOutput().getPart(paramString);
/*     */     }
/*     */     
/* 322 */     if (part == null) {
/* 323 */       throw new JAXRPCException("Internal error: part not found:" + paramString);
/*     */     }
/*     */     
/* 326 */     return part;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object getHolderInstance(Part paramPart, Object paramObject) {
/* 331 */     if (paramObject != null && paramObject instanceof Holder) {
/* 332 */       return paramObject;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 338 */       Class clazz = paramPart.getJavaType();
/*     */       
/* 340 */       if (!Holder.class.isAssignableFrom(clazz)) {
/* 341 */         TypeMapping typeMapping = (TypeMapping)paramPart.getTypeMapping();
/* 342 */         clazz = typeMapping.getHolderClass(paramPart.getJavaType(), paramPart.getXMLType());
/*     */       } 
/*     */ 
/*     */       
/* 346 */       Holder holder = (Holder)clazz.newInstance();
/*     */       
/* 348 */       if (paramObject != null) {
/* 349 */         setValue(holder, paramObject);
/*     */       }
/*     */       
/* 352 */       return holder;
/* 353 */     } catch (IOException iOException) {
/* 354 */       throw new JAXRPCException("failed to get holder class", iOException);
/* 355 */     } catch (InstantiationException instantiationException) {
/* 356 */       throw new JAXRPCException("failed to create an instance of the holder class:", instantiationException);
/*     */     }
/* 358 */     catch (IllegalAccessException illegalAccessException) {
/* 359 */       throw new JAXRPCException("failed to create an instance of the holder class:", illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private SOAPBody getBody(SOAPMessage paramSOAPMessage) throws SOAPException {
/* 365 */     SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
/* 366 */     return sOAPEnvelope.getBody();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 371 */   private Object[] toArray(Map paramMap) { return paramMap.values().toArray(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 377 */   private static AuthenticatedSubject getKernelID() { return kernelID; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\InvokeHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */