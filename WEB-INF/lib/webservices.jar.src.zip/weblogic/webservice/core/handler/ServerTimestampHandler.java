package weblogic.webservice.core.handler;

import javax.xml.rpc.handler.MessageContext;

public class ServerTimestampHandler extends TimestampHandler {
  public boolean handleRequest(MessageContext paramMessageContext) {
    if (VERBOSE)
      System.out.println("ServerTimestampHandler: handling request"); 
    return handleReceive(paramMessageContext);
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) {
    if (VERBOSE)
      System.out.println("ServerTimestampHandler: handling response"); 
    return handleSend(paramMessageContext);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ServerTimestampHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */