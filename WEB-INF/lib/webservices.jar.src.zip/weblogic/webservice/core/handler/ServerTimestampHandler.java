/*    */ package weblogic.webservice.core.handler;
/*    */ 
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerTimestampHandler
/*    */   extends TimestampHandler
/*    */ {
/*    */   public boolean handleRequest(MessageContext paramMessageContext) {
/* 12 */     if (VERBOSE) System.out.println("ServerTimestampHandler: handling request"); 
/* 13 */     return handleReceive(paramMessageContext);
/*    */   }
/*    */   
/*    */   public boolean handleResponse(MessageContext paramMessageContext) {
/* 17 */     if (VERBOSE) System.out.println("ServerTimestampHandler: handling response"); 
/* 18 */     return handleSend(paramMessageContext);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ServerTimestampHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */