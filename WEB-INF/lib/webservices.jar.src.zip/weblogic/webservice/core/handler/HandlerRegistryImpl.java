/*     */ package weblogic.webservice.core.handler;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.handler.HandlerRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HandlerRegistryImpl
/*     */   implements HandlerRegistry
/*     */ {
/*  30 */   private Map chainMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/*     */   
/*     */   public List getHandlerChain(QName paramQName) {
/*  34 */     List list = (List)this.chainMap.get(paramQName.getLocalPart());
/*     */     
/*  36 */     if (list == null) {
/*  37 */       list = new ArrayList();
/*  38 */       setHandlerChain(paramQName, list);
/*     */     } 
/*     */     
/*  41 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHandlerChain(QName paramQName, List paramList) {
/*  48 */     Iterator iterator = paramList.iterator();
/*     */     
/*  50 */     while (iterator.hasNext()) {
/*     */       
/*  52 */       Object object = iterator.next();
/*     */       
/*  54 */       if (object instanceof HandlerInfo) {
/*  55 */         validateHandlerInfo((HandlerInfo)object, paramQName); continue;
/*     */       } 
/*  57 */       throw new JAXRPCException("The List argument to  setHandlerChain must contain instances of javax.xml.rpc.handler.HandlerInfo.  The list contained " + object.getClass().getName() + " which is not an instanceof" + " HandlerInfo.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.chainMap.put(paramQName.getLocalPart(), paramList);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateHandlerInfo(HandlerInfo paramHandlerInfo, QName paramQName) {
/*  71 */     Class clazz = paramHandlerInfo.getHandlerClass();
/*     */     
/*  73 */     if (clazz == null) {
/*  74 */       throw new JAXRPCException("The HandlerInfo for the name:" + paramQName + " had a null HandlerClass.");
/*     */     }
/*     */ 
/*     */     
/*  78 */     if (!javax.xml.rpc.handler.Handler.class.isAssignableFrom(clazz)) {
/*  79 */       throw new JAXRPCException("The HandlerInfo for the name:" + paramQName + " contains a handler class: " + clazz.getName() + " which is not an instanceof javax.xml.rpc.handler.Handler");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  85 */       Constructor constructor = clazz.getConstructor((Class[])null);
/*  86 */       if (!Modifier.isPublic(constructor.getModifiers())) {
/*  87 */         throw new JAXRPCException("The HandlerInfo for the name:" + paramQName + " contains a handler class: " + clazz.getName() + " which has a default, no argument constructor.  However," + "this constructor is not public.");
/*     */       
/*     */       }
/*     */     
/*     */     }
/*  92 */     catch (NoSuchMethodException noSuchMethodException) {
/*  93 */       throw new JAXRPCException("The HandlerInfo for the name:" + paramQName + " contains a handler class: " + clazz.getName() + " which does not have a public, no argument constructor.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public String toString() { return "[HandlerRegistry]: " + this.chainMap.toString(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\HandlerRegistryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */