package weblogic.webservice.core.handler;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;

public final class HandlerRegistryImpl implements HandlerRegistry {
  private Map chainMap = Collections.synchronizedMap(new HashMap());
  
  public List getHandlerChain(QName paramQName) {
    List list = (List)this.chainMap.get(paramQName.getLocalPart());
    if (list == null) {
      list = new ArrayList();
      setHandlerChain(paramQName, list);
    } 
    return list;
  }
  
  public void setHandlerChain(QName paramQName, List paramList) {
    Iterator iterator = paramList.iterator();
    while (iterator.hasNext()) {
      Object object = iterator.next();
      if (object instanceof HandlerInfo) {
        validateHandlerInfo((HandlerInfo)object, paramQName);
        continue;
      } 
      throw new JAXRPCException("The List argument to  setHandlerChain must contain instances of javax.xml.rpc.handler.HandlerInfo.  The list contained " + object.getClass().getName() + " which is not an instanceof" + " HandlerInfo.");
    } 
    this.chainMap.put(paramQName.getLocalPart(), paramList);
  }
  
  private void validateHandlerInfo(HandlerInfo paramHandlerInfo, QName paramQName) {
    Class clazz = paramHandlerInfo.getHandlerClass();
    if (clazz == null)
      throw new JAXRPCException("The HandlerInfo for the name:" + paramQName + " had a null HandlerClass."); 
    if (!javax.xml.rpc.handler.Handler.class.isAssignableFrom(clazz))
      throw new JAXRPCException("The HandlerInfo for the name:" + paramQName + " contains a handler class: " + clazz.getName() + " which is not an instanceof javax.xml.rpc.handler.Handler"); 
    try {
      Constructor constructor = clazz.getConstructor((Class[])null);
      if (!Modifier.isPublic(constructor.getModifiers()))
        throw new JAXRPCException("The HandlerInfo for the name:" + paramQName + " contains a handler class: " + clazz.getName() + " which has a default, no argument constructor.  However," + "this constructor is not public."); 
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new JAXRPCException("The HandlerInfo for the name:" + paramQName + " contains a handler class: " + clazz.getName() + " which does not have a public, no argument constructor.");
    } 
  }
  
  public String toString() { return "[HandlerRegistry]: " + this.chainMap.toString(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\HandlerRegistryImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */