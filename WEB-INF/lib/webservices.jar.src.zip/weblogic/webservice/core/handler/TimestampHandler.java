package weblogic.webservice.core.handler;

import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TimeZone;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.Debug;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.core.soap.NameImpl;
import weblogic.xml.security.specs.TimestampConfig;
import weblogic.xml.security.wsse.v200207.WSSEConstants;
import weblogic.xml.security.wsu.Expires;
import weblogic.xml.security.wsu.Timestamp;
import weblogic.xml.security.wsu.WSUFactory;
import weblogic.xml.security.wsu.v200207.WSUConstants;

public abstract class TimestampHandler extends GenericHandler {
  private static final String TIMESTAMP_CONFIG = "__BEA_INTERNAL__Timestamp.config";
  
  public static final String MESSAGE_EXPIRES_PROPERTY = "weblogic.webservice.timestamp.expires";
  
  public static final String MESSAGE_RECEIVED_PROPERTY = "weblogic.webservice.timestamp.received";
  
  public static final String MESSAGE_CREATED_PROPERTY = "weblogic.webservice.timestamp.created";
  
  private static final String INTEGRATED_TIMESTAMPS_PROPERTY = "timestamp.integrated";
  
  static final boolean INTEGRATED = !"false".equals("timestamp.integrated");
  
  private static final TimeZone TZ_ZULU = TimeZone.getTimeZone("UTC");
  
  public static final long MILLI_PRECISION = 1L;
  
  public static final long SECOND_PRECISION = 1000L;
  
  public static final long MINUTE_PRECISION = 60000L;
  
  public static final long HOUR_PRECISION = 3600000L;
  
  public static final long DAY_PRECISION = 86400000L;
  
  public static final long WEEK_PRECISION = 604800000L;
  
  public static final long MONTH_PRECISION = 2592000000L;
  
  public static final long YEAR_PRECISION = 31536000000L;
  
  public static final long DEFAULT_CLOCK_PRECISION = 60000L;
  
  private static final WSUFactory tsFactory = WSUFactory.getInstance(WSUConstants.WSU_URI);
  
  private static final Name TIMESTAMP_NAME = new NameImpl("Timestamp", null, WSUConstants.WSU_URI);
  
  public static final QName EXPIRED_FAULTCODE = new QName(WSUConstants.WSU_URI, "MessageExpired");
  
  public static final QName NO_TIMESTAMP_FAULTCODE = new QName(WSSEConstants.WSSE_URI, "FailedCheck");
  
  private static final String VERBOSE_PROPERTY = "timestamp.verbose";
  
  protected static final boolean VERBOSE = Boolean.getBoolean("timestamp.verbose");
  
  private TimestampConfig configuration = new TimestampConfig();
  
  public void init(HandlerInfo paramHandlerInfo) {
    super.init(paramHandlerInfo);
    Map map = paramHandlerInfo.getHandlerConfig();
    this.configuration = (TimestampConfig)map.get("__BEA_INTERNAL__Timestamp.config");
    if (this.configuration == null) {
      this.configuration = new TimestampConfig();
      String str = (String)map.get("weblogic.webservice.security.clock.synchronized");
      if (str != null)
        this.configuration.setClockSynchronized("true".equalsIgnoreCase(str)); 
      str = (String)map.get("weblogic.webservice.security.clock.precision");
      if (str != null)
        this.configuration.setClockPrecision(Long.parseLong(str)); 
      str = (String)map.get("weblogic.webservice.security.clock.precision.lax");
      if (str != null)
        this.configuration.setLaxPrecision("true".equalsIgnoreCase(str)); 
      str = (String)map.get("weblogic.webservice.security.delay.max");
      if (str != null)
        this.configuration.setMaxProcessingDelay(Long.parseLong(str)); 
      str = (String)map.get("weblogic.webservice.security.timestamp.include");
      if (str != null)
        this.configuration.setGenerateTimestamp("true".equalsIgnoreCase(str)); 
      str = (String)map.get("weblogic.webservice.security.validity");
      if (str != null)
        this.configuration.setValidityPeriod(Long.parseLong(str)); 
    } 
    if (VERBOSE) {
      Debug.say("TimestampHandler configuration");
      Debug.say("Timestamp integration: " + (INTEGRATED ? "on" : "off"));
      Debug.say(this.configuration.toString());
    } 
  }
  
  public abstract boolean handleRequest(MessageContext paramMessageContext);
  
  public abstract boolean handleResponse(MessageContext paramMessageContext);
  
  public final boolean handleSend(MessageContext paramMessageContext) {
    if (this.configuration.generateTimestamp()) {
      Timestamp timestamp;
      SOAPHeader sOAPHeader;
      SOAPMessage sOAPMessage = ((WLMessageContext)paramMessageContext).getMessage();
      try {
        SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
        sOAPHeader = sOAPEnvelope.getHeader();
      } catch (SOAPException sOAPException) {
        throw new JAXRPCException(sOAPException);
      } 
      Iterator iterator = sOAPHeader.getChildElements(TIMESTAMP_NAME);
      if (iterator.hasNext())
        return true; 
      if (!this.configuration.isClockSynchronized() || !this.configuration.includeExpiry()) {
        timestamp = tsFactory.createTimestamp();
      } else {
        timestamp = tsFactory.createTimestamp(this.configuration.getValidityPeriod());
      } 
      if (VERBOSE)
        Debug.say("Sending " + timestamp); 
      timestamp.toXML(sOAPHeader);
    } 
    return true;
  }
  
  public boolean handleReceive(MessageContext paramMessageContext) {
    Iterator iterator;
    SOAPHeader sOAPHeader;
    Calendar calendar1 = Calendar.getInstance(TZ_ZULU);
    SOAPMessage sOAPMessage = ((WLMessageContext)paramMessageContext).getMessage();
    try {
      SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
      sOAPHeader = sOAPEnvelope.getHeader();
    } catch (SOAPException null) {
      throw new JAXRPCException(iterator);
    } 
    if (sOAPHeader != null) {
      iterator = sOAPHeader.getChildElements(TIMESTAMP_NAME);
    } else {
      iterator = Collections.EMPTY_SET.iterator();
    } 
    if (this.configuration.isTimestampRequired() && !iterator.hasNext())
      throw new SOAPFaultException(NO_TIMESTAMP_FAULTCODE, "message does not contain required Timestamp header", null, null); 
    Calendar calendar2 = null;
    Calendar calendar3 = null;
    while (iterator.hasNext()) {
      Object object;
      SOAPElement sOAPElement = (SOAPElement)iterator.next();
      Timestamp timestamp = tsFactory.createTimestamp(sOAPElement);
      Calendar calendar = timestamp.getCreated().getTime();
      Expires expires = timestamp.getExpires();
      if (expires != null) {
        object = expires.getTime();
      } else {
        object = null;
      } 
      sOAPElement.detachNode();
      if (calendar3 == null || calendar3.after(calendar))
        calendar3 = calendar; 
      if (calendar2 == null || (object != null && calendar2.after(object)))
        calendar2 = object; 
    } 
    if (calendar3 != null)
      checkExpiration(calendar1, calendar3, calendar2); 
    if (VERBOSE) {
      Debug.say("Received " + calendar1);
      Debug.say("Created  " + calendar3);
      Debug.say("Expires  " + calendar2);
    } 
    paramMessageContext.setProperty("weblogic.webservice.timestamp.received", calendar1);
    paramMessageContext.setProperty("weblogic.webservice.timestamp.created", calendar3);
    if (calendar2 != null)
      paramMessageContext.setProperty("weblogic.webservice.timestamp.expires", calendar2); 
    return true;
  }
  
  private void checkExpiration(Calendar paramCalendar1, Calendar paramCalendar2, Calendar paramCalendar3) {
    long l3, l1 = getRoundedTime(paramCalendar1);
    long l2 = getRoundedTime(paramCalendar2);
    if (paramCalendar3 != null) {
      l3 = getRoundedTime(paramCalendar3);
    } else {
      l3 = 0L;
    } 
    if (!this.configuration.isClockSynchronized()) {
      if (paramCalendar3 != null)
        throw new SOAPFaultException(EXPIRED_FAULTCODE, "Message includes expiry but clocks are not synchronized", null, null); 
    } else {
      if (this.configuration.isFreshnessEnforced()) {
        long l = l2 + this.configuration.getRoundedMaxDelay();
        if (l < l1)
          throw new SOAPFaultException(EXPIRED_FAULTCODE, "Message is too old", null, null); 
      } 
      if (l1 < l2)
        throw new SOAPFaultException(EXPIRED_FAULTCODE, "Message Created time in the future", null, null); 
      if (paramCalendar3 != null) {
        if (!this.configuration.laxClockPrecision() && l3 <= l2)
          throw new SOAPFaultException(EXPIRED_FAULTCODE, "Message is expired: clock precision insufficient to distinguish Created time from Expires time", null, null); 
        if (l3 < l1)
          throw new SOAPFaultException(EXPIRED_FAULTCODE, "Message Expires time has passed", null, null); 
      } 
    } 
  }
  
  protected final long getRoundedTime(Calendar paramCalendar) {
    long l = paramCalendar.getTimeInMillis();
    return l / this.configuration.getClockPrecision();
  }
  
  protected static final void initHandlerInfo(HandlerInfo paramHandlerInfo, TimestampConfig paramTimestampConfig) {
    Map map = paramHandlerInfo.getHandlerConfig();
    if (map == null) {
      map = new HashMap();
      paramHandlerInfo.setHandlerConfig(map);
    } 
    if (VERBOSE)
      Debug.say("initializing timestamp handler with " + paramTimestampConfig); 
    map.put("__BEA_INTERNAL__Timestamp.config", paramTimestampConfig);
  }
  
  public TimestampConfig getConfiguration() { return this.configuration; }
  
  public void setConfiguration(TimestampConfig paramTimestampConfig) { this.configuration = paramTimestampConfig; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\TimestampHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */