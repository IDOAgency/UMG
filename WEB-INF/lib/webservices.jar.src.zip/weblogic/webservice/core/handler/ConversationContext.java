/*    */ package weblogic.webservice.core.handler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConversationContext
/*    */ {
/*    */   private String conversationID;
/*    */   private String callbackLocation;
/*    */   private String headerType;
/*    */   
/*    */   public void ConversationContext() {}
/*    */   
/* 18 */   public void setConversationID(String paramString) { this.conversationID = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 22 */   public String getConversationID() { return this.conversationID; }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public void setCallbackLocation(String paramString) { this.callbackLocation = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public String getCallbackLocation() { return this.callbackLocation; }
/*    */ 
/*    */ 
/*    */   
/* 34 */   public void setHeaderType(String paramString) { this.headerType = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public String getHeaderType() { return this.headerType; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ConversationContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */