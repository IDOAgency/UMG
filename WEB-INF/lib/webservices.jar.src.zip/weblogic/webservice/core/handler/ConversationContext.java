package weblogic.webservice.core.handler;

public class ConversationContext {
  private String conversationID;
  
  private String callbackLocation;
  
  private String headerType;
  
  public void ConversationContext() {}
  
  public void setConversationID(String paramString) { this.conversationID = paramString; }
  
  public String getConversationID() { return this.conversationID; }
  
  public void setCallbackLocation(String paramString) { this.callbackLocation = paramString; }
  
  public String getCallbackLocation() { return this.callbackLocation; }
  
  public void setHeaderType(String paramString) { this.headerType = paramString; }
  
  public String getHeaderType() { return this.headerType; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ConversationContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */