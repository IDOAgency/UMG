/*    */ package weblogic.webservice.core.handler;
/*    */ 
/*    */ import java.util.Map;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.handler.HandlerInfo;
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ import javax.xml.rpc.soap.SOAPFaultException;
/*    */ import javax.xml.soap.SOAPConstants;
/*    */ import weblogic.webservice.GenericHandler;
/*    */ import weblogic.webservice.Operation;
/*    */ import weblogic.webservice.WLMessageContext;
/*    */ import weblogic.webservice.server.AuthorizationContext;
/*    */ import weblogic.webservice.server.Authorizer;
/*    */ import weblogic.webservice.server.WLAuthorizer;
/*    */ import weblogic.webservice.util.AccessException;
/*    */ import weblogic.webservice.util.FaultUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthorizationHandler
/*    */   extends GenericHandler
/*    */   implements SOAPConstants
/*    */ {
/*    */   public static final String AUTHORIZATION_CONTEXT = "WSAuthorizationContext";
/* 36 */   private static final QName AUTHENTICATION_FAILURE = new QName("http://schemas.xmlsoap.org/soap/envelope/", "Client.Authentication");
/*    */ 
/*    */   
/* 39 */   private Authorizer authorizer = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public void init(HandlerInfo paramHandlerInfo) {
/* 44 */     Map map = paramHandlerInfo.getHandlerConfig();
/* 45 */     AuthorizationContext authorizationContext = (AuthorizationContext)map.get("WSAuthorizationContext");
/*    */     
/* 47 */     this.authorizer = new WLAuthorizer(authorizationContext);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean handleRequest(MessageContext paramMessageContext) {
/* 52 */     if (this.authorizer == null) throw new RuntimeException("Authorization did not initialize properly");
/*    */ 
/*    */ 
/*    */     
/* 56 */     Operation operation = ((WLMessageContext)paramMessageContext).getOperation();
/*    */     
/* 58 */     if (!this.authorizer.isAccessAllowed(operation, (WLMessageContext)paramMessageContext)) {
/*    */       
/* 60 */       String str = "Access Denied to operation " + operation.getName();
/*    */       
/* 62 */       throw new SOAPFaultException(AUTHENTICATION_FAILURE, str, operation.getSoapAction(), FaultUtil.newDetail(new AccessException(str)));
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\AuthorizationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */