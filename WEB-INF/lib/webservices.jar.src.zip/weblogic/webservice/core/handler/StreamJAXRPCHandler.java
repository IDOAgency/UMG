/*    */ package weblogic.webservice.core.handler;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ import weblogic.webservice.GenericHandler;
/*    */ import weblogic.webservice.StreamHandler;
/*    */ import weblogic.webservice.WLMessageContext;
/*    */ import weblogic.webservice.WLSOAPMessage;
/*    */ import weblogic.xml.stream.XMLInputStream;
/*    */ import weblogic.xml.stream.XMLOutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamJAXRPCHandler
/*    */   extends GenericHandler
/*    */ {
/* 19 */   ArrayList internalHandlers = new ArrayList();
/*    */   
/* 21 */   public void addStreamHandler(StreamHandler paramStreamHandler) { this.internalHandlers.add(paramStreamHandler); }
/*    */   
/*    */   public boolean handleRequest(MessageContext paramMessageContext) {
/* 24 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*    */     
/* 26 */     WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)wLMessageContext.getMessage();
/*    */     
/* 28 */     XMLInputStream xMLInputStream = null;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 33 */     Iterator iterator = this.internalHandlers.iterator();
/* 34 */     while (iterator.hasNext()) {
/* 35 */       xMLInputStream = ((StreamHandler)iterator.next()).wrap(xMLInputStream, wLMessageContext);
/*    */     }
/*    */ 
/*    */     
/* 39 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean handleResponse(MessageContext paramMessageContext) {
/* 44 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*    */     
/* 46 */     WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)wLMessageContext.getMessage();
/*    */     
/* 48 */     XMLOutputStream xMLOutputStream = null;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 53 */     Iterator iterator = this.internalHandlers.iterator();
/* 54 */     while (iterator.hasNext()) {
/* 55 */       xMLOutputStream = ((StreamHandler)iterator.next()).wrap(xMLOutputStream, wLMessageContext);
/*    */     }
/*    */ 
/*    */     
/* 59 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\StreamJAXRPCHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */