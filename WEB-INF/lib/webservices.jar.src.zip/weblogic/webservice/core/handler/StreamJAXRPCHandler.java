package weblogic.webservice.core.handler;

import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.rpc.handler.MessageContext;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.StreamHandler;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WLSOAPMessage;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLOutputStream;

public class StreamJAXRPCHandler extends GenericHandler {
  ArrayList internalHandlers = new ArrayList();
  
  public void addStreamHandler(StreamHandler paramStreamHandler) { this.internalHandlers.add(paramStreamHandler); }
  
  public boolean handleRequest(MessageContext paramMessageContext) {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)wLMessageContext.getMessage();
    XMLInputStream xMLInputStream = null;
    Iterator iterator = this.internalHandlers.iterator();
    while (iterator.hasNext())
      xMLInputStream = ((StreamHandler)iterator.next()).wrap(xMLInputStream, wLMessageContext); 
    return true;
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) {
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)wLMessageContext.getMessage();
    XMLOutputStream xMLOutputStream = null;
    Iterator iterator = this.internalHandlers.iterator();
    while (iterator.hasNext())
      xMLOutputStream = ((StreamHandler)iterator.next()).wrap(xMLOutputStream, wLMessageContext); 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\StreamJAXRPCHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */