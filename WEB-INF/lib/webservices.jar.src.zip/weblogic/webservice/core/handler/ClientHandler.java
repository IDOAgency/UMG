/*    */ package weblogic.webservice.core.handler;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import weblogic.webservice.GenericHandler;
/*    */ import weblogic.webservice.WLMessageContext;
/*    */ import weblogic.webservice.WebServiceLogger;
/*    */ import weblogic.webservice.binding.Binding;
/*    */ import weblogic.webservice.util.FaultUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ClientHandler
/*    */   extends GenericHandler
/*    */ {
/*    */   private static final boolean debug = true;
/*    */   
/*    */   public boolean handleRequest(MessageContext paramMessageContext) {
/* 33 */     Binding binding = (Binding)paramMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 38 */       binding.send((WLMessageContext)paramMessageContext);
/* 39 */     } catch (IOException iOException) {
/* 40 */       String str = WebServiceLogger.logJAXMClientHandlerException();
/* 41 */       WebServiceLogger.logStackTrace(str, iOException);
/*    */       
/* 43 */       FaultUtil.throwSOAPFaultException("Client", "Failed to send request", iOException);
/*    */     
/*    */     }
/* 46 */     catch (SOAPException sOAPException) {
/*    */       
/* 48 */       FaultUtil.throwSOAPFaultException("Client", "Failed to send request", sOAPException);
/*    */     } 
/*    */ 
/*    */     
/* 52 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean handleResponse(MessageContext paramMessageContext) {
/* 57 */     Binding binding = (Binding)paramMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 62 */       WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*    */       
/* 64 */       binding.receive(wLMessageContext);
/*    */     }
/* 66 */     catch (IOException iOException) {
/* 67 */       throw new JAXRPCException(iOException);
/* 68 */     } catch (SOAPException sOAPException) {
/* 69 */       throw new JAXRPCException(sOAPException);
/*    */     } 
/*    */     
/* 72 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ClientHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */