package weblogic.webservice.core.handler;

import java.io.IOException;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.soap.SOAPException;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.util.FaultUtil;

public final class ClientHandler extends GenericHandler {
  private static final boolean debug = true;
  
  public boolean handleRequest(MessageContext paramMessageContext) {
    Binding binding = (Binding)paramMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
    try {
      binding.send((WLMessageContext)paramMessageContext);
    } catch (IOException iOException) {
      String str = WebServiceLogger.logJAXMClientHandlerException();
      WebServiceLogger.logStackTrace(str, iOException);
      FaultUtil.throwSOAPFaultException("Client", "Failed to send request", iOException);
    } catch (SOAPException sOAPException) {
      FaultUtil.throwSOAPFaultException("Client", "Failed to send request", sOAPException);
    } 
    return true;
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) {
    Binding binding = (Binding)paramMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
    try {
      WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
      binding.receive(wLMessageContext);
    } catch (IOException iOException) {
      throw new JAXRPCException(iOException);
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException(sOAPException);
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ClientHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */