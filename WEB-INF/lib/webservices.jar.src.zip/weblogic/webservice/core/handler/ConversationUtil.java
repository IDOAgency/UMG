/*     */ package weblogic.webservice.core.handler;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeader;
/*     */ import javax.xml.soap.SOAPHeaderElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConversationUtil
/*     */ {
/*     */   public static final String CONVERSATION_NAMESPACE = "http://www.openuri.org/2002/04/soap/conversation/";
/*     */   public static final String START_HEADER = "StartHeader";
/*     */   public static final String CONTINUE_HEADER = "ContinueHeader";
/*     */   public static final String CALLBACK_HEADER = "CallbackHeader";
/*     */   public static final String FINISH_HEADER = "FinishHeader";
/*     */   public static final String CONVERSATION_ID = "conversationID";
/*     */   public static final String CALLBACK_LOCATION = "callbackLocation";
/*     */   public static final String PREFIX = "con";
/*     */   private String conversationID;
/*     */   private String callbackLocation;
/*     */   private String headerType;
/*     */   private SOAPHeader header;
/*     */   private SOAPEnvelope envelope;
/*     */   private boolean processed;
/*     */   
/*     */   public ConversationUtil(SOAPEnvelope paramSOAPEnvelope) throws SOAPException {
/*  40 */     this.processed = false;
/*     */ 
/*     */     
/*  43 */     this.envelope = paramSOAPEnvelope;
/*  44 */     this.header = paramSOAPEnvelope.getHeader();
/*     */   }
/*     */   
/*     */   public ConversationContext createContext() throws SOAPException {
/*  48 */     if (!this.processed) process();
/*     */     
/*  50 */     if (this.conversationID == null && this.callbackLocation == null && this.headerType == null) {
/*  51 */       return null;
/*     */     }
/*     */     
/*  54 */     ConversationContext conversationContext = new ConversationContext();
/*  55 */     conversationContext.setConversationID(this.conversationID);
/*  56 */     conversationContext.setCallbackLocation(this.callbackLocation);
/*  57 */     conversationContext.setHeaderType(this.headerType);
/*     */     
/*  59 */     return conversationContext;
/*     */   }
/*     */   
/*     */   public void addToHeader(ConversationContext paramConversationContext) throws SOAPException {
/*  63 */     this.headerType = paramConversationContext.getHeaderType();
/*  64 */     this.conversationID = paramConversationContext.getConversationID();
/*  65 */     this.callbackLocation = paramConversationContext.getCallbackLocation();
/*     */     
/*  67 */     if (this.header == null) this.header = this.envelope.addHeader();
/*     */     
/*  69 */     if (this.headerType == "FinishHeader")
/*     */     {
/*  71 */       this.headerType = "ContinueHeader";
/*     */     }
/*     */     
/*  74 */     this.header.addNamespaceDeclaration("con", "http://www.openuri.org/2002/04/soap/conversation/");
/*  75 */     Name name = this.envelope.createName(this.headerType, "con", "http://www.openuri.org/2002/04/soap/conversation/");
/*     */     
/*  77 */     for (Iterator iterator = this.header.getChildElements(name); iterator.hasNext();) {
/*  78 */       ((SOAPElement)iterator.next()).detachNode();
/*     */     }
/*     */     
/*  81 */     SOAPHeaderElement sOAPHeaderElement = this.header.addHeaderElement(name);
/*     */     
/*  83 */     if (paramConversationContext.getConversationID() != null) {
/*  84 */       SOAPElement sOAPElement = sOAPHeaderElement.addChildElement("conversationID", "con");
/*  85 */       sOAPElement.addTextNode(paramConversationContext.getConversationID());
/*     */     } 
/*     */     
/*  88 */     if (paramConversationContext.getCallbackLocation() != null) {
/*  89 */       SOAPElement sOAPElement = sOAPHeaderElement.addChildElement("callbackLocation", "con");
/*  90 */       sOAPElement.addTextNode(paramConversationContext.getCallbackLocation());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void process() throws SOAPException {
/*  95 */     Name name = this.envelope.createName("ContinueHeader", "junk", "http://www.openuri.org/2002/04/soap/conversation/");
/*  96 */     Iterator iterator = this.header.getChildElements(name);
/*  97 */     if (iterator.hasNext()) {
/*  98 */       processContinueHeader((SOAPElement)iterator.next());
/*  99 */       this.headerType = "ContinueHeader";
/* 100 */       this.processed = true;
/*     */       
/*     */       return;
/*     */     } 
/* 104 */     name = this.envelope.createName("StartHeader", "junk", "http://www.openuri.org/2002/04/soap/conversation/");
/* 105 */     iterator = this.header.getChildElements(name);
/* 106 */     if (iterator.hasNext()) {
/* 107 */       processStartHeader((SOAPElement)iterator.next());
/* 108 */       this.headerType = "StartHeader";
/* 109 */       this.processed = true;
/*     */       
/*     */       return;
/*     */     } 
/* 113 */     name = this.envelope.createName("FinishHeader", "junk", "http://www.openuri.org/2002/04/soap/conversation/");
/* 114 */     iterator = this.header.getChildElements(name);
/* 115 */     if (iterator.hasNext()) {
/* 116 */       processFinishHeader((SOAPElement)iterator.next());
/* 117 */       this.headerType = "FinishHeader";
/* 118 */       this.processed = true;
/*     */       
/*     */       return;
/*     */     } 
/* 122 */     name = this.envelope.createName("CallbackHeader", "junk", "http://www.openuri.org/2002/04/soap/conversation/");
/* 123 */     iterator = this.header.getChildElements(name);
/* 124 */     if (iterator.hasNext()) {
/* 125 */       processCallbackHeader((SOAPElement)iterator.next());
/* 126 */       this.headerType = "CallbackHeader";
/* 127 */       this.processed = true;
/*     */       
/*     */       return;
/*     */     } 
/* 131 */     this.processed = true;
/*     */   }
/*     */   
/*     */   private void processStartHeader(SOAPElement paramSOAPElement) throws SOAPException {
/* 135 */     for (Iterator iterator = paramSOAPElement.getChildElements(); iterator.hasNext(); ) {
/* 136 */       SOAPElement sOAPElement = (SOAPElement)iterator.next();
/* 137 */       if (sOAPElement.getElementName().getLocalName().equals("conversationID")) {
/* 138 */         this.conversationID = sOAPElement.getValue(); continue;
/* 139 */       }  if (sOAPElement.getElementName().getLocalName().equals("callbackLocation")) {
/* 140 */         this.callbackLocation = sOAPElement.getValue();
/*     */       }
/*     */     } 
/*     */     
/* 144 */     paramSOAPElement.detachNode();
/*     */   }
/*     */   
/*     */   private void processFinishHeader(SOAPElement paramSOAPElement) throws SOAPException {
/* 148 */     for (Iterator iterator = paramSOAPElement.getChildElements(); iterator.hasNext(); ) {
/* 149 */       SOAPElement sOAPElement = (SOAPElement)iterator.next();
/* 150 */       if (sOAPElement.getElementName().getLocalName().equals("conversationID")) {
/* 151 */         this.conversationID = sOAPElement.getValue();
/*     */       }
/*     */     } 
/*     */     
/* 155 */     paramSOAPElement.detachNode();
/*     */   }
/*     */   
/*     */   private void processContinueHeader(SOAPElement paramSOAPElement) throws SOAPException {
/* 159 */     for (Iterator iterator = paramSOAPElement.getChildElements(); iterator.hasNext(); ) {
/* 160 */       SOAPElement sOAPElement = (SOAPElement)iterator.next();
/* 161 */       if (sOAPElement.getElementName().getLocalName().equals("conversationID")) {
/* 162 */         this.conversationID = sOAPElement.getValue();
/*     */       }
/*     */     } 
/*     */     
/* 166 */     paramSOAPElement.detachNode();
/*     */   }
/*     */   
/*     */   private void processCallbackHeader(SOAPElement paramSOAPElement) throws SOAPException {
/* 170 */     for (Iterator iterator = paramSOAPElement.getChildElements(); iterator.hasNext(); ) {
/* 171 */       SOAPElement sOAPElement = (SOAPElement)iterator.next();
/* 172 */       if (sOAPElement.getElementName().getLocalName().equals("callbackLocation")) {
/* 173 */         this.conversationID = sOAPElement.getValue();
/*     */       }
/*     */     } 
/*     */     
/* 177 */     paramSOAPElement.detachNode();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ConversationUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */