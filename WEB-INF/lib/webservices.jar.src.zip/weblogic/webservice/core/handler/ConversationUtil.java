package weblogic.webservice.core.handler;

import java.util.Iterator;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;

public class ConversationUtil {
  public static final String CONVERSATION_NAMESPACE = "http://www.openuri.org/2002/04/soap/conversation/";
  
  public static final String START_HEADER = "StartHeader";
  
  public static final String CONTINUE_HEADER = "ContinueHeader";
  
  public static final String CALLBACK_HEADER = "CallbackHeader";
  
  public static final String FINISH_HEADER = "FinishHeader";
  
  public static final String CONVERSATION_ID = "conversationID";
  
  public static final String CALLBACK_LOCATION = "callbackLocation";
  
  public static final String PREFIX = "con";
  
  private String conversationID;
  
  private String callbackLocation;
  
  private String headerType;
  
  private SOAPHeader header;
  
  private SOAPEnvelope envelope;
  
  private boolean processed;
  
  public ConversationUtil(SOAPEnvelope paramSOAPEnvelope) throws SOAPException {
    this.processed = false;
    this.envelope = paramSOAPEnvelope;
    this.header = paramSOAPEnvelope.getHeader();
  }
  
  public ConversationContext createContext() throws SOAPException {
    if (!this.processed)
      process(); 
    if (this.conversationID == null && this.callbackLocation == null && this.headerType == null)
      return null; 
    ConversationContext conversationContext = new ConversationContext();
    conversationContext.setConversationID(this.conversationID);
    conversationContext.setCallbackLocation(this.callbackLocation);
    conversationContext.setHeaderType(this.headerType);
    return conversationContext;
  }
  
  public void addToHeader(ConversationContext paramConversationContext) throws SOAPException {
    this.headerType = paramConversationContext.getHeaderType();
    this.conversationID = paramConversationContext.getConversationID();
    this.callbackLocation = paramConversationContext.getCallbackLocation();
    if (this.header == null)
      this.header = this.envelope.addHeader(); 
    if (this.headerType == "FinishHeader")
      this.headerType = "ContinueHeader"; 
    this.header.addNamespaceDeclaration("con", "http://www.openuri.org/2002/04/soap/conversation/");
    Name name = this.envelope.createName(this.headerType, "con", "http://www.openuri.org/2002/04/soap/conversation/");
    for (Iterator iterator = this.header.getChildElements(name); iterator.hasNext();)
      ((SOAPElement)iterator.next()).detachNode(); 
    SOAPHeaderElement sOAPHeaderElement = this.header.addHeaderElement(name);
    if (paramConversationContext.getConversationID() != null) {
      SOAPElement sOAPElement = sOAPHeaderElement.addChildElement("conversationID", "con");
      sOAPElement.addTextNode(paramConversationContext.getConversationID());
    } 
    if (paramConversationContext.getCallbackLocation() != null) {
      SOAPElement sOAPElement = sOAPHeaderElement.addChildElement("callbackLocation", "con");
      sOAPElement.addTextNode(paramConversationContext.getCallbackLocation());
    } 
  }
  
  private void process() throws SOAPException {
    Name name = this.envelope.createName("ContinueHeader", "junk", "http://www.openuri.org/2002/04/soap/conversation/");
    Iterator iterator = this.header.getChildElements(name);
    if (iterator.hasNext()) {
      processContinueHeader((SOAPElement)iterator.next());
      this.headerType = "ContinueHeader";
      this.processed = true;
      return;
    } 
    name = this.envelope.createName("StartHeader", "junk", "http://www.openuri.org/2002/04/soap/conversation/");
    iterator = this.header.getChildElements(name);
    if (iterator.hasNext()) {
      processStartHeader((SOAPElement)iterator.next());
      this.headerType = "StartHeader";
      this.processed = true;
      return;
    } 
    name = this.envelope.createName("FinishHeader", "junk", "http://www.openuri.org/2002/04/soap/conversation/");
    iterator = this.header.getChildElements(name);
    if (iterator.hasNext()) {
      processFinishHeader((SOAPElement)iterator.next());
      this.headerType = "FinishHeader";
      this.processed = true;
      return;
    } 
    name = this.envelope.createName("CallbackHeader", "junk", "http://www.openuri.org/2002/04/soap/conversation/");
    iterator = this.header.getChildElements(name);
    if (iterator.hasNext()) {
      processCallbackHeader((SOAPElement)iterator.next());
      this.headerType = "CallbackHeader";
      this.processed = true;
      return;
    } 
    this.processed = true;
  }
  
  private void processStartHeader(SOAPElement paramSOAPElement) throws SOAPException {
    for (Iterator iterator = paramSOAPElement.getChildElements(); iterator.hasNext(); ) {
      SOAPElement sOAPElement = (SOAPElement)iterator.next();
      if (sOAPElement.getElementName().getLocalName().equals("conversationID")) {
        this.conversationID = sOAPElement.getValue();
        continue;
      } 
      if (sOAPElement.getElementName().getLocalName().equals("callbackLocation"))
        this.callbackLocation = sOAPElement.getValue(); 
    } 
    paramSOAPElement.detachNode();
  }
  
  private void processFinishHeader(SOAPElement paramSOAPElement) throws SOAPException {
    for (Iterator iterator = paramSOAPElement.getChildElements(); iterator.hasNext(); ) {
      SOAPElement sOAPElement = (SOAPElement)iterator.next();
      if (sOAPElement.getElementName().getLocalName().equals("conversationID"))
        this.conversationID = sOAPElement.getValue(); 
    } 
    paramSOAPElement.detachNode();
  }
  
  private void processContinueHeader(SOAPElement paramSOAPElement) throws SOAPException {
    for (Iterator iterator = paramSOAPElement.getChildElements(); iterator.hasNext(); ) {
      SOAPElement sOAPElement = (SOAPElement)iterator.next();
      if (sOAPElement.getElementName().getLocalName().equals("conversationID"))
        this.conversationID = sOAPElement.getValue(); 
    } 
    paramSOAPElement.detachNode();
  }
  
  private void processCallbackHeader(SOAPElement paramSOAPElement) throws SOAPException {
    for (Iterator iterator = paramSOAPElement.getChildElements(); iterator.hasNext(); ) {
      SOAPElement sOAPElement = (SOAPElement)iterator.next();
      if (sOAPElement.getElementName().getLocalName().equals("callbackLocation"))
        this.conversationID = sOAPElement.getValue(); 
    } 
    paramSOAPElement.detachNode();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\ConversationUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */