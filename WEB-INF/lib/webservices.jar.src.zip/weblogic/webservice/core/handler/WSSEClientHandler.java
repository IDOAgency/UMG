package weblogic.webservice.core.handler;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPPart;
import weblogic.utils.CharsetMap;
import weblogic.utils.Debug;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.Operation;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WLSOAPPart;
import weblogic.webservice.WebService;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.context.WebServiceSession;
import weblogic.webservice.core.DefaultMessageContext;
import weblogic.webservice.core.soap.SOAPMessageImpl;
import weblogic.webservice.util.BufferStream;
import weblogic.xml.security.InvalidSecurityException;
import weblogic.xml.security.SecurityAssertion;
import weblogic.xml.security.SecurityConfigurationException;
import weblogic.xml.security.SecurityProcessingException;
import weblogic.xml.security.UserInfo;
import weblogic.xml.security.encryption.EncryptionException;
import weblogic.xml.security.keyinfo.KeyProviderFactory;
import weblogic.xml.security.keyinfo.KeyResolver;
import weblogic.xml.security.signature.ReferenceValidationException;
import weblogic.xml.security.signature.SignatureValidationException;
import weblogic.xml.security.specs.BinarySecurityTokenSpec;
import weblogic.xml.security.specs.EncryptionSpec;
import weblogic.xml.security.specs.SecurityDD;
import weblogic.xml.security.specs.SecuritySpec;
import weblogic.xml.security.specs.SignatureSpec;
import weblogic.xml.security.specs.TimestampConfig;
import weblogic.xml.security.specs.UsernameTokenSpec;
import weblogic.xml.security.wsse.SecureSoapInputStream;
import weblogic.xml.security.wsse.SecureSoapOutputStream;
import weblogic.xml.security.wsse.Security;
import weblogic.xml.security.wsse.SecurityElementFactory;
import weblogic.xml.security.wsse.Token;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLStreamException;

public class WSSEClientHandler extends GenericHandler {
  private static String WS_SECURITY = "weblogic.webservice.security.";
  
  public static final String REQUEST_SECURITY = WS_SECURITY + "request";
  
  public static final String REQUEST_USERINFO = WS_SECURITY + "request.userinfo";
  
  public static final String REQUEST_ENCRYPTION_CERT = WS_SECURITY + "request.encryption.certificate";
  
  public static final String KEY_ATTRIBUTE = WS_SECURITY + "key";
  
  public static final String CERT_ATTRIBUTE = WS_SECURITY + "certificate";
  
  private static final boolean DEBUG = Security.WSSE_VERBOSE;
  
  private static final SecurityElementFactory factory = SecurityElementFactory.getDefaultFactory();
  
  private boolean initialized = false;
  
  private SecurityDD securityDD = null;
  
  public static final String KEY_RESOLVER_ATTRIBUTE = WS_SECURITY + "keyresolver";
  
  public boolean handleRequest(MessageContext paramMessageContext) {
    if (!this.initialized)
      initialize(getSecurityDD(paramMessageContext)); 
    Operation operation = getOperation(paramMessageContext);
    SecuritySpec securitySpec = getRequestSpec(operation, this.securityDD);
    WebServiceContext webServiceContext = (WebServiceContext)paramMessageContext.getProperty("weblogic.webservice.context");
    WebServiceSession webServiceSession = webServiceContext.getSession();
    Security security = (Security)webServiceSession.getAttribute(REQUEST_SECURITY);
    webServiceSession.removeAttribute(REQUEST_SECURITY);
    if (security == null && securitySpec != null) {
      security = factory.createSecurity(null);
      X509Certificate x509Certificate1 = (X509Certificate)webServiceSession.getAttribute(CERT_ATTRIBUTE);
      PrivateKey privateKey = (PrivateKey)webServiceSession.getAttribute(KEY_ATTRIBUTE);
      UserInfo userInfo = (UserInfo)webServiceSession.getAttribute(REQUEST_USERINFO);
      X509Certificate x509Certificate2 = (X509Certificate)webServiceSession.getAttribute(REQUEST_ENCRYPTION_CERT);
      processSpecs(security, x509Certificate1, privateKey, userInfo, x509Certificate2, securitySpec, getTimestampConfig());
    } 
    if (security != null) {
      SecureSoapOutputStream secureSoapOutputStream;
      BufferStream bufferStream;
      WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
      WLSOAPPart wLSOAPPart = (WLSOAPPart)wLMessageContext.getMessage().getSOAPPart();
      try {
        bufferStream = new BufferStream();
        secureSoapOutputStream = new SecureSoapOutputStream(security, bufferStream, getEncoding(wLMessageContext));
      } catch (XMLStreamException xMLStreamException) {
        if (DEBUG)
          xMLStreamException.printStackTrace(); 
        throw new SecurityConfigurationException("Unable to secure request", xMLStreamException);
      } 
      try {
        wLSOAPPart.writeTo(secureSoapOutputStream);
        secureSoapOutputStream.close(true);
      } catch (SOAPException sOAPException) {
        sOAPException.printStackTrace();
        if (DEBUG)
          sOAPException.printStackTrace(); 
        throw new SecurityConfigurationException("Unable to secure request", sOAPException);
      } catch (XMLStreamException xMLStreamException) {
        if (DEBUG)
          xMLStreamException.printStackTrace(); 
        throw new SecurityConfigurationException("Unable to secure request", xMLStreamException);
      } 
      wLSOAPPart.setContent(bufferStream);
    } 
    return true;
  }
  
  private String getEncoding(WLMessageContext paramWLMessageContext) {
    String str = paramWLMessageContext.getOperation().getPort().getBindingInfo().getCharset();
    if (str == null)
      str = ((SOAPMessageImpl)paramWLMessageContext.getMessage()).getCharset(); 
    return (str != null) ? CharsetMap.getJavaFromIANA(str) : "UTF-8";
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) {
    XMLInputStream xMLInputStream;
    if (!this.initialized)
      initialize(getSecurityDD(paramMessageContext)); 
    WebServiceContext webServiceContext = (WebServiceContext)paramMessageContext.getProperty("weblogic.webservice.context");
    WebServiceSession webServiceSession = webServiceContext.getSession();
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    SOAPPart sOAPPart = wLMessageContext.getMessage().getSOAPPart();
    WLSOAPPart wLSOAPPart = (WLSOAPPart)sOAPPart;
    try {
      xMLInputStream = wLSOAPPart.getXMLStreamContent();
    } catch (XMLStreamException xMLStreamException) {
      if (DEBUG)
        xMLStreamException.printStackTrace(); 
      throw new JAXRPCException("Can't get soapPart as stream. " + xMLStreamException, xMLStreamException);
    } catch (SOAPException sOAPException) {
      if (DEBUG)
        sOAPException.printStackTrace(); 
      throw new JAXRPCException("Can't get soapPart as stream. " + sOAPException, sOAPException);
    } 
    PrivateKey privateKey = (PrivateKey)webServiceSession.getAttribute(KEY_ATTRIBUTE);
    X509Certificate x509Certificate = (X509Certificate)webServiceSession.getAttribute(CERT_ATTRIBUTE);
    KeyResolver keyResolver = (KeyResolver)webServiceSession.getAttribute(KEY_RESOLVER_ATTRIBUTE);
    if (keyResolver == null) {
      keyResolver = new KeyResolver();
      if (privateKey != null || x509Certificate != null)
        keyResolver.addKeyProvider(KeyProviderFactory.create(x509Certificate, privateKey)); 
    } 
    try {
      SecureSoapInputStream secureSoapInputStream = new SecureSoapInputStream(xMLInputStream, null, keyResolver);
      Security security = secureSoapInputStream.getSecurityElement();
      SecurityAssertion[] arrayOfSecurityAssertion = secureSoapInputStream.getSecurityAssertions();
      wLSOAPPart.setContent(secureSoapInputStream);
      if (sOAPPart.getEnvelope().getBody().hasFault()) {
        wLMessageContext.setFault(true);
        return true;
      } 
      Operation operation = getOperation(paramMessageContext);
      SecuritySpec securitySpec = getResponseSpec(operation, this.securityDD);
      if (securitySpec != null && 
        security == null)
        throw new InvalidSecurityException("Response did not contain a valid Security Element"); 
      TimestampConfig timestampConfig = getTimestampConfig();
      if (timestampConfig != null)
        timestampConfig.checkTimestamps(security, wLMessageContext); 
      paramMessageContext.setProperty("weblogic.webservice.security.assertions.response", arrayOfSecurityAssertion);
    } catch (EncryptionException encryptionException) {
      if (DEBUG)
        encryptionException.printStackTrace(); 
      throw new InvalidSecurityException("Encryption failure: ", encryptionException);
    } catch (ReferenceValidationException referenceValidationException) {
      throw new InvalidSecurityException("Signature Reference validation failure", referenceValidationException);
    } catch (SignatureValidationException signatureValidationException) {
      if (DEBUG)
        signatureValidationException.printStackTrace(); 
      throw new InvalidSecurityException("Signature validation failure", signatureValidationException);
    } catch (XMLStreamException xMLStreamException) {
      if (DEBUG)
        xMLStreamException.printStackTrace(); 
      throw new InvalidSecurityException("Security processing failure; ", xMLStreamException);
    } catch (SOAPException sOAPException) {
      if (DEBUG)
        sOAPException.printStackTrace(); 
      throw new JAXRPCException("Unable to process envelope after security processing", sOAPException);
    } 
    return true;
  }
  
  private TimestampConfig getTimestampConfig() {
    TimestampConfig timestampConfig;
    if (this.securityDD != null) {
      timestampConfig = this.securityDD.getTimestampConfig();
    } else {
      timestampConfig = null;
    } 
    if (timestampConfig != null) {
      timestampConfig = new TimestampConfig();
      this.securityDD.setTimestampConfig(timestampConfig);
    } 
    return timestampConfig;
  }
  
  private static void processSpecs(Security paramSecurity, X509Certificate paramX509Certificate1, PrivateKey paramPrivateKey, UserInfo paramUserInfo, X509Certificate paramX509Certificate2, SecuritySpec paramSecuritySpec, TimestampConfig paramTimestampConfig) {
    Token token;
    UsernameTokenSpec usernameTokenSpec = paramSecuritySpec.getUsernameTokenSpec();
    BinarySecurityTokenSpec binarySecurityTokenSpec = paramSecuritySpec.getBinarySecurityTokenSpec();
    SignatureSpec signatureSpec = paramSecuritySpec.getSignatureSpec();
    EncryptionSpec encryptionSpec = paramSecuritySpec.getEncryptionSpec();
    paramTimestampConfig.addTimestamp(paramSecuritySpec, paramSecurity);
    if (usernameTokenSpec != null)
      if (paramUserInfo != null) {
        Token token1 = factory.createToken(paramUserInfo.getUsername(), paramUserInfo.getPassword(), usernameTokenSpec.getPasswordType());
        paramSecurity.addToken(token1);
      } else {
        throw new SecurityConfigurationException("UsernameToken not provided, but required by service");
      }  
    if (paramPrivateKey != null && paramX509Certificate1 != null) {
      token = factory.createToken(paramX509Certificate1, paramPrivateKey);
    } else {
      token = null;
    } 
    if (signatureSpec != null)
      if (token != null) {
        try {
          paramSecurity.addSignature(token, signatureSpec);
        } catch (SecurityProcessingException securityProcessingException) {
          if (DEBUG)
            securityProcessingException.printStackTrace(); 
          throw new SecurityConfigurationException("Unable to add signature to request", securityProcessingException);
        } 
      } else {
        throw new SecurityConfigurationException("Service requires signed requests, but no Token was provided");
      }  
    if (binarySecurityTokenSpec != null)
      if (token != null) {
        paramSecurity.addToken(token);
      } else {
        throw new SecurityConfigurationException("Token not provided, but required by service");
      }  
    if (encryptionSpec != null) {
      Token token1;
      if (paramX509Certificate2 != null) {
        token1 = factory.createToken(paramX509Certificate2, null);
      } else {
        paramX509Certificate2 = encryptionSpec.getCertificate();
        if (paramX509Certificate2 != null) {
          token1 = factory.createToken(encryptionSpec.getCertificate(), null);
        } else {
          token1 = null;
        } 
      } 
      if (token1 == null)
        throw new SecurityConfigurationException("Server requires encryption but no encryption key was was available for server"); 
      try {
        paramSecurity.addEncryption(token1, encryptionSpec);
      } catch (SecurityProcessingException securityProcessingException) {
        if (DEBUG)
          securityProcessingException.printStackTrace(); 
        throw new SecurityConfigurationException("Failed adding encryption to request", securityProcessingException);
      } 
    } 
  }
  
  private void initialize(SecurityDD paramSecurityDD) {
    if (paramSecurityDD != null) {
      this.securityDD = paramSecurityDD;
      TimestampConfig timestampConfig = paramSecurityDD.getTimestampConfig();
      if (timestampConfig == null)
        paramSecurityDD.setTimestampConfig(new TimestampConfig()); 
    } 
    this.initialized = true;
  }
  
  private static SecuritySpec getRequestSpec(Operation paramOperation, SecurityDD paramSecurityDD) {
    SecuritySpec securitySpec;
    if (paramSecurityDD != null) {
      String str = paramOperation.getInput().getSecuritySpecRef();
      securitySpec = (str == null) ? paramSecurityDD.getSecuritySpec("default-spec") : paramSecurityDD.getSecuritySpec(str);
      if (DEBUG)
        Debug.say("Request spec = " + securitySpec); 
    } else {
      securitySpec = null;
    } 
    return securitySpec;
  }
  
  private static SecuritySpec getResponseSpec(Operation paramOperation, SecurityDD paramSecurityDD) {
    SecuritySpec securitySpec;
    if (paramSecurityDD != null) {
      String str = paramOperation.getOutput().getSecuritySpecRef();
      securitySpec = (str == null) ? paramSecurityDD.getSecuritySpec("default-spec") : paramSecurityDD.getSecuritySpec(str);
    } else {
      securitySpec = null;
    } 
    if (DEBUG)
      Debug.say("Response spec = " + securitySpec); 
    return securitySpec;
  }
  
  private static Operation getOperation(MessageContext paramMessageContext) {
    DefaultMessageContext defaultMessageContext = (DefaultMessageContext)paramMessageContext;
    return defaultMessageContext.getOperation();
  }
  
  private static final SecurityDD getSecurityDD(MessageContext paramMessageContext) {
    WebService webService = (WebService)paramMessageContext.getProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP");
    if (webService != null)
      return webService.getSecurity(); 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\WSSEClientHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */