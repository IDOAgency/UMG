/*     */ package weblogic.webservice.core.handler;
/*     */ 
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPPart;
/*     */ import weblogic.utils.CharsetMap;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.GenericHandler;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WLSOAPPart;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.context.WebServiceSession;
/*     */ import weblogic.webservice.core.DefaultMessageContext;
/*     */ import weblogic.webservice.core.soap.SOAPMessageImpl;
/*     */ import weblogic.webservice.util.BufferStream;
/*     */ import weblogic.xml.security.InvalidSecurityException;
/*     */ import weblogic.xml.security.SecurityAssertion;
/*     */ import weblogic.xml.security.SecurityConfigurationException;
/*     */ import weblogic.xml.security.SecurityProcessingException;
/*     */ import weblogic.xml.security.UserInfo;
/*     */ import weblogic.xml.security.encryption.EncryptionException;
/*     */ import weblogic.xml.security.keyinfo.KeyProviderFactory;
/*     */ import weblogic.xml.security.keyinfo.KeyResolver;
/*     */ import weblogic.xml.security.signature.ReferenceValidationException;
/*     */ import weblogic.xml.security.signature.SignatureValidationException;
/*     */ import weblogic.xml.security.specs.BinarySecurityTokenSpec;
/*     */ import weblogic.xml.security.specs.EncryptionSpec;
/*     */ import weblogic.xml.security.specs.SecurityDD;
/*     */ import weblogic.xml.security.specs.SecuritySpec;
/*     */ import weblogic.xml.security.specs.SignatureSpec;
/*     */ import weblogic.xml.security.specs.TimestampConfig;
/*     */ import weblogic.xml.security.specs.UsernameTokenSpec;
/*     */ import weblogic.xml.security.wsse.SecureSoapInputStream;
/*     */ import weblogic.xml.security.wsse.SecureSoapOutputStream;
/*     */ import weblogic.xml.security.wsse.Security;
/*     */ import weblogic.xml.security.wsse.SecurityElementFactory;
/*     */ import weblogic.xml.security.wsse.Token;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSSEClientHandler
/*     */   extends GenericHandler
/*     */ {
/*  56 */   private static String WS_SECURITY = "weblogic.webservice.security.";
/*     */   
/*  58 */   public static final String REQUEST_SECURITY = WS_SECURITY + "request";
/*  59 */   public static final String REQUEST_USERINFO = WS_SECURITY + "request.userinfo";
/*  60 */   public static final String REQUEST_ENCRYPTION_CERT = WS_SECURITY + "request.encryption.certificate";
/*     */   
/*  62 */   public static final String KEY_ATTRIBUTE = WS_SECURITY + "key";
/*  63 */   public static final String CERT_ATTRIBUTE = WS_SECURITY + "certificate";
/*     */   
/*  65 */   private static final boolean DEBUG = Security.WSSE_VERBOSE;
/*     */   
/*  67 */   private static final SecurityElementFactory factory = SecurityElementFactory.getDefaultFactory();
/*     */   
/*     */   private boolean initialized = false;
/*     */   
/*  71 */   private SecurityDD securityDD = null;
/*  72 */   public static final String KEY_RESOLVER_ATTRIBUTE = WS_SECURITY + "keyresolver";
/*     */ 
/*     */   
/*     */   public boolean handleRequest(MessageContext paramMessageContext) {
/*  76 */     if (!this.initialized) initialize(getSecurityDD(paramMessageContext));
/*     */     
/*  78 */     Operation operation = getOperation(paramMessageContext);
/*  79 */     SecuritySpec securitySpec = getRequestSpec(operation, this.securityDD);
/*     */     
/*  81 */     WebServiceContext webServiceContext = (WebServiceContext)paramMessageContext.getProperty("weblogic.webservice.context");
/*     */ 
/*     */     
/*  84 */     WebServiceSession webServiceSession = webServiceContext.getSession();
/*     */     
/*  86 */     Security security = (Security)webServiceSession.getAttribute(REQUEST_SECURITY);
/*  87 */     webServiceSession.removeAttribute(REQUEST_SECURITY);
/*     */     
/*  89 */     if (security == null && securitySpec != null) {
/*  90 */       security = factory.createSecurity(null);
/*     */       
/*  92 */       X509Certificate x509Certificate1 = (X509Certificate)webServiceSession.getAttribute(CERT_ATTRIBUTE);
/*     */       
/*  94 */       PrivateKey privateKey = (PrivateKey)webServiceSession.getAttribute(KEY_ATTRIBUTE);
/*     */ 
/*     */       
/*  97 */       UserInfo userInfo = (UserInfo)webServiceSession.getAttribute(REQUEST_USERINFO);
/*     */ 
/*     */       
/* 100 */       X509Certificate x509Certificate2 = (X509Certificate)webServiceSession.getAttribute(REQUEST_ENCRYPTION_CERT);
/*     */ 
/*     */       
/* 103 */       processSpecs(security, x509Certificate1, privateKey, userInfo, x509Certificate2, securitySpec, getTimestampConfig());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     if (security != null) {
/*     */       SecureSoapOutputStream secureSoapOutputStream;
/*     */ 
/*     */       
/*     */       BufferStream bufferStream;
/*     */       
/* 115 */       WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/* 116 */       WLSOAPPart wLSOAPPart = (WLSOAPPart)wLMessageContext.getMessage().getSOAPPart();
/*     */       
/*     */       try {
/* 119 */         bufferStream = new BufferStream();
/* 120 */         secureSoapOutputStream = new SecureSoapOutputStream(security, bufferStream, getEncoding(wLMessageContext));
/*     */       }
/* 122 */       catch (XMLStreamException xMLStreamException) {
/* 123 */         if (DEBUG) xMLStreamException.printStackTrace(); 
/* 124 */         throw new SecurityConfigurationException("Unable to secure request", xMLStreamException);
/*     */       } 
/*     */       
/*     */       try {
/* 128 */         wLSOAPPart.writeTo(secureSoapOutputStream);
/* 129 */         secureSoapOutputStream.close(true);
/* 130 */       } catch (SOAPException sOAPException) {
/* 131 */         sOAPException.printStackTrace();
/* 132 */         if (DEBUG) sOAPException.printStackTrace(); 
/* 133 */         throw new SecurityConfigurationException("Unable to secure request", sOAPException);
/* 134 */       } catch (XMLStreamException xMLStreamException) {
/* 135 */         if (DEBUG) xMLStreamException.printStackTrace(); 
/* 136 */         throw new SecurityConfigurationException("Unable to secure request", xMLStreamException);
/*     */       } 
/*     */ 
/*     */       
/* 140 */       wLSOAPPart.setContent(bufferStream);
/*     */     } 
/*     */     
/* 143 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getEncoding(WLMessageContext paramWLMessageContext) {
/* 149 */     String str = paramWLMessageContext.getOperation().getPort().getBindingInfo().getCharset();
/* 150 */     if (str == null)
/*     */     {
/* 152 */       str = ((SOAPMessageImpl)paramWLMessageContext.getMessage()).getCharset();
/*     */     }
/* 154 */     return (str != null) ? CharsetMap.getJavaFromIANA(str) : "UTF-8";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleResponse(MessageContext paramMessageContext) {
/*     */     XMLInputStream xMLInputStream;
/* 162 */     if (!this.initialized) initialize(getSecurityDD(paramMessageContext));
/*     */     
/* 164 */     WebServiceContext webServiceContext = (WebServiceContext)paramMessageContext.getProperty("weblogic.webservice.context");
/*     */ 
/*     */     
/* 167 */     WebServiceSession webServiceSession = webServiceContext.getSession();
/*     */     
/* 169 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/*     */     
/* 171 */     SOAPPart sOAPPart = wLMessageContext.getMessage().getSOAPPart();
/* 172 */     WLSOAPPart wLSOAPPart = (WLSOAPPart)sOAPPart;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 177 */       xMLInputStream = wLSOAPPart.getXMLStreamContent();
/* 178 */     } catch (XMLStreamException xMLStreamException) {
/* 179 */       if (DEBUG) xMLStreamException.printStackTrace(); 
/* 180 */       throw new JAXRPCException("Can't get soapPart as stream. " + xMLStreamException, xMLStreamException);
/* 181 */     } catch (SOAPException sOAPException) {
/* 182 */       if (DEBUG) sOAPException.printStackTrace(); 
/* 183 */       throw new JAXRPCException("Can't get soapPart as stream. " + sOAPException, sOAPException);
/*     */     } 
/*     */     
/* 186 */     PrivateKey privateKey = (PrivateKey)webServiceSession.getAttribute(KEY_ATTRIBUTE);
/*     */ 
/*     */     
/* 189 */     X509Certificate x509Certificate = (X509Certificate)webServiceSession.getAttribute(CERT_ATTRIBUTE);
/*     */ 
/*     */     
/* 192 */     KeyResolver keyResolver = (KeyResolver)webServiceSession.getAttribute(KEY_RESOLVER_ATTRIBUTE);
/*     */ 
/*     */     
/* 195 */     if (keyResolver == null) {
/* 196 */       keyResolver = new KeyResolver();
/* 197 */       if (privateKey != null || x509Certificate != null) {
/* 198 */         keyResolver.addKeyProvider(KeyProviderFactory.create(x509Certificate, privateKey));
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 209 */       SecureSoapInputStream secureSoapInputStream = new SecureSoapInputStream(xMLInputStream, null, keyResolver);
/* 210 */       Security security = secureSoapInputStream.getSecurityElement();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 215 */       SecurityAssertion[] arrayOfSecurityAssertion = secureSoapInputStream.getSecurityAssertions();
/*     */       
/* 217 */       wLSOAPPart.setContent(secureSoapInputStream);
/*     */       
/* 219 */       if (sOAPPart.getEnvelope().getBody().hasFault()) {
/* 220 */         wLMessageContext.setFault(true);
/* 221 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 225 */       Operation operation = getOperation(paramMessageContext);
/* 226 */       SecuritySpec securitySpec = getResponseSpec(operation, this.securityDD);
/*     */       
/* 228 */       if (securitySpec != null && 
/* 229 */         security == null) {
/* 230 */         throw new InvalidSecurityException("Response did not contain a valid Security Element");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 237 */       TimestampConfig timestampConfig = getTimestampConfig();
/* 238 */       if (timestampConfig != null) {
/* 239 */         timestampConfig.checkTimestamps(security, wLMessageContext);
/*     */       }
/*     */       
/* 242 */       paramMessageContext.setProperty("weblogic.webservice.security.assertions.response", arrayOfSecurityAssertion);
/*     */     
/*     */     }
/* 245 */     catch (EncryptionException encryptionException) {
/* 246 */       if (DEBUG) encryptionException.printStackTrace(); 
/* 247 */       throw new InvalidSecurityException("Encryption failure: ", encryptionException);
/* 248 */     } catch (ReferenceValidationException referenceValidationException) {
/* 249 */       throw new InvalidSecurityException("Signature Reference validation failure", referenceValidationException);
/*     */     }
/* 251 */     catch (SignatureValidationException signatureValidationException) {
/* 252 */       if (DEBUG) signatureValidationException.printStackTrace(); 
/* 253 */       throw new InvalidSecurityException("Signature validation failure", signatureValidationException);
/* 254 */     } catch (XMLStreamException xMLStreamException) {
/* 255 */       if (DEBUG) xMLStreamException.printStackTrace(); 
/* 256 */       throw new InvalidSecurityException("Security processing failure; ", xMLStreamException);
/* 257 */     } catch (SOAPException sOAPException) {
/* 258 */       if (DEBUG) sOAPException.printStackTrace(); 
/* 259 */       throw new JAXRPCException("Unable to process envelope after security processing", sOAPException);
/*     */     } 
/*     */     
/* 262 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TimestampConfig getTimestampConfig() {
/*     */     TimestampConfig timestampConfig;
/* 269 */     if (this.securityDD != null) { timestampConfig = this.securityDD.getTimestampConfig(); }
/* 270 */     else { timestampConfig = null; }
/*     */ 
/*     */     
/* 273 */     if (timestampConfig != null) {
/* 274 */       timestampConfig = new TimestampConfig();
/* 275 */       this.securityDD.setTimestampConfig(timestampConfig);
/*     */     } 
/*     */     
/* 278 */     return timestampConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void processSpecs(Security paramSecurity, X509Certificate paramX509Certificate1, PrivateKey paramPrivateKey, UserInfo paramUserInfo, X509Certificate paramX509Certificate2, SecuritySpec paramSecuritySpec, TimestampConfig paramTimestampConfig) {
/*     */     Token token;
/* 290 */     UsernameTokenSpec usernameTokenSpec = paramSecuritySpec.getUsernameTokenSpec();
/* 291 */     BinarySecurityTokenSpec binarySecurityTokenSpec = paramSecuritySpec.getBinarySecurityTokenSpec();
/* 292 */     SignatureSpec signatureSpec = paramSecuritySpec.getSignatureSpec();
/* 293 */     EncryptionSpec encryptionSpec = paramSecuritySpec.getEncryptionSpec();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 299 */     paramTimestampConfig.addTimestamp(paramSecuritySpec, paramSecurity);
/*     */     
/* 301 */     if (usernameTokenSpec != null) {
/* 302 */       if (paramUserInfo != null) {
/* 303 */         Token token1 = factory.createToken(paramUserInfo.getUsername(), paramUserInfo.getPassword(), usernameTokenSpec.getPasswordType());
/*     */ 
/*     */         
/* 306 */         paramSecurity.addToken(token1);
/*     */       } else {
/* 308 */         throw new SecurityConfigurationException("UsernameToken not provided, but required by service");
/*     */       } 
/*     */     }
/*     */     
/* 312 */     if (paramPrivateKey != null && paramX509Certificate1 != null) {
/* 313 */       token = factory.createToken(paramX509Certificate1, paramPrivateKey);
/*     */     } else {
/* 315 */       token = null;
/*     */     } 
/* 317 */     if (signatureSpec != null) {
/* 318 */       if (token != null) {
/*     */         try {
/* 320 */           paramSecurity.addSignature(token, signatureSpec);
/* 321 */         } catch (SecurityProcessingException securityProcessingException) {
/* 322 */           if (DEBUG) securityProcessingException.printStackTrace(); 
/* 323 */           throw new SecurityConfigurationException("Unable to add signature to request", securityProcessingException);
/*     */         } 
/*     */       } else {
/*     */         
/* 327 */         throw new SecurityConfigurationException("Service requires signed requests, but no Token was provided");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 333 */     if (binarySecurityTokenSpec != null) {
/* 334 */       if (token != null) {
/* 335 */         paramSecurity.addToken(token);
/*     */       } else {
/* 337 */         throw new SecurityConfigurationException("Token not provided, but required by service");
/*     */       } 
/*     */     }
/*     */     
/* 341 */     if (encryptionSpec != null) {
/* 342 */       Token token1; if (paramX509Certificate2 != null) {
/* 343 */         token1 = factory.createToken(paramX509Certificate2, null);
/*     */       } else {
/* 345 */         paramX509Certificate2 = encryptionSpec.getCertificate();
/* 346 */         if (paramX509Certificate2 != null) {
/* 347 */           token1 = factory.createToken(encryptionSpec.getCertificate(), null);
/*     */         } else {
/* 349 */           token1 = null;
/*     */         } 
/*     */       } 
/*     */       
/* 353 */       if (token1 == null) {
/* 354 */         throw new SecurityConfigurationException("Server requires encryption but no encryption key was was available for server");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 361 */         paramSecurity.addEncryption(token1, encryptionSpec);
/* 362 */       } catch (SecurityProcessingException securityProcessingException) {
/* 363 */         if (DEBUG) securityProcessingException.printStackTrace(); 
/* 364 */         throw new SecurityConfigurationException("Failed adding encryption to request", securityProcessingException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize(SecurityDD paramSecurityDD) {
/* 383 */     if (paramSecurityDD != null) {
/* 384 */       this.securityDD = paramSecurityDD;
/* 385 */       TimestampConfig timestampConfig = paramSecurityDD.getTimestampConfig();
/* 386 */       if (timestampConfig == null) paramSecurityDD.setTimestampConfig(new TimestampConfig()); 
/*     */     } 
/* 388 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SecuritySpec getRequestSpec(Operation paramOperation, SecurityDD paramSecurityDD) {
/*     */     SecuritySpec securitySpec;
/* 409 */     if (paramSecurityDD != null) {
/* 410 */       String str = paramOperation.getInput().getSecuritySpecRef();
/* 411 */       securitySpec = (str == null) ? paramSecurityDD.getSecuritySpec("default-spec") : paramSecurityDD.getSecuritySpec(str);
/*     */ 
/*     */       
/* 414 */       if (DEBUG) Debug.say("Request spec = " + securitySpec); 
/*     */     } else {
/* 416 */       securitySpec = null;
/*     */     } 
/* 418 */     return securitySpec;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static SecuritySpec getResponseSpec(Operation paramOperation, SecurityDD paramSecurityDD) {
/*     */     SecuritySpec securitySpec;
/* 425 */     if (paramSecurityDD != null) {
/* 426 */       String str = paramOperation.getOutput().getSecuritySpecRef();
/* 427 */       securitySpec = (str == null) ? paramSecurityDD.getSecuritySpec("default-spec") : paramSecurityDD.getSecuritySpec(str);
/*     */     }
/*     */     else {
/*     */       
/* 431 */       securitySpec = null;
/* 432 */     }  if (DEBUG) Debug.say("Response spec = " + securitySpec); 
/* 433 */     return securitySpec;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Operation getOperation(MessageContext paramMessageContext) {
/* 438 */     DefaultMessageContext defaultMessageContext = (DefaultMessageContext)paramMessageContext;
/* 439 */     return defaultMessageContext.getOperation();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final SecurityDD getSecurityDD(MessageContext paramMessageContext) {
/* 445 */     WebService webService = (WebService)paramMessageContext.getProperty("__BEA_PRIVATE_WEBSERVICE_RUNTIME_PROP");
/*     */     
/* 447 */     if (webService != null) {
/* 448 */       return webService.getSecurity();
/*     */     }
/* 450 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\handler\WSSEClientHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */