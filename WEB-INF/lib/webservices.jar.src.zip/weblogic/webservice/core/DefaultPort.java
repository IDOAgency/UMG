package weblogic.webservice.core;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;
import javax.xml.soap.SOAPElement;
import weblogic.utils.StringUtils;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebService;
import weblogic.webservice.binding.BindingInfo;

public class DefaultPort implements Port {
  private static final boolean debug = false;
  
  private String name;
  
  private String typeName;
  
  private String address;
  
  private String username;
  
  private String password;
  
  private String sessionID;
  
  private String proxyUsername;
  
  private String proxyPassword;
  
  private boolean maintainSession;
  
  private String style;
  
  private HashMap operations;
  
  private LinkedList orderedOperations;
  
  private BindingInfo bindingInfo;
  
  private TypeMappingRegistry typeMappingRegistry;
  
  private HandlerRegistry registry;
  
  private WebService service;
  
  private Map cookies;
  
  DefaultPort(WebService paramWebService) {
    this.maintainSession = true;
    this.style = "rpc";
    this.operations = new HashMap();
    this.orderedOperations = new LinkedList();
    this.bindingInfo = new BindingInfo();
    this.cookies = new HashMap();
    this.service = paramWebService;
  }
  
  public HandlerRegistry getHandlerRegistry() { return this.registry; }
  
  public void setHandlerRegistry(HandlerRegistry paramHandlerRegistry) { this.registry = paramHandlerRegistry; }
  
  public WebService getService() { return this.service; }
  
  public void destroy() {
    Iterator iterator = this.operations.values().iterator();
    while (iterator.hasNext()) {
      Operation operation = (Operation)iterator.next();
      operation.destroy();
    } 
  }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getTypeName() { return this.typeName; }
  
  public void setTypeName(String paramString) { this.typeName = paramString; }
  
  public String getStyle() { return this.style; }
  
  public void setStyle(String paramString) {
    if ("rpc".equalsIgnoreCase(paramString) || "document".equalsIgnoreCase(paramString) || "documentwrapped".equalsIgnoreCase(paramString)) {
      this.style = paramString.toLowerCase();
    } else if (paramString == null) {
      this.style = "rpc";
    } else {
      throw new IllegalArgumentException("Invalid operation style: " + paramString);
    } 
  }
  
  public boolean isDocumentStyle() { return "document".equals(this.style); }
  
  public boolean isRpcStyle() { return "rpc".equals(this.style); }
  
  public String getAddress() { return this.address; }
  
  public void setAddress(String paramString) { this.address = paramString; }
  
  public String getUserName() { return this.username; }
  
  public void setUserName(String paramString) { this.username = paramString; }
  
  public String getPassword() { return this.password; }
  
  public void setPassword(String paramString) { this.password = paramString; }
  
  public String getProxyUserName() { return this.proxyUsername; }
  
  public void setProxyUserName(String paramString) { this.proxyUsername = paramString; }
  
  public String getProxyPassword() { return this.proxyPassword; }
  
  public void setProxyPassword(String paramString) { this.proxyPassword = paramString; }
  
  public void setMaintainSession(boolean paramBoolean) { this.maintainSession = paramBoolean; }
  
  public boolean getMaintainSession() { return this.maintainSession; }
  
  public String getSessionID() { return this.sessionID; }
  
  public void setSessionID(String paramString) {
    if (this.maintainSession)
      this.sessionID = paramString; 
  }
  
  public BindingInfo getBindingInfo() { return this.bindingInfo; }
  
  public void setBindingInfo(BindingInfo paramBindingInfo) { this.bindingInfo = paramBindingInfo; }
  
  public TypeMappingRegistry getTypeMappingRegistry() { return this.typeMappingRegistry; }
  
  public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) { this.typeMappingRegistry = paramTypeMappingRegistry; }
  
  public Operation getOperation(String paramString) { return (Operation)this.operations.get(paramString); }
  
  public Iterator getOperations() { return this.operations.values().iterator(); }
  
  public Iterator getOrderedOperations() { return this.orderedOperations.listIterator(0); }
  
  public Operation addOperation(String paramString) { return addOperation(paramString, (HandlerInfo[])null); }
  
  public void addOperation(Operation paramOperation) {
    this.operations.put(paramOperation.getName(), paramOperation);
    this.orderedOperations.add(paramOperation);
  }
  
  public Operation addOperation(String paramString, HandlerInfo[] paramArrayOfHandlerInfo) {
    Operation operation = getOperation(paramString);
    if (operation == null) {
      operation = new DefaultOperation(paramString, this, paramArrayOfHandlerInfo);
      operation.setTypeMappingRegistry(this.typeMappingRegistry);
      addOperation(operation);
      if (isRpcStyle()) {
        operation.setRpcStyle();
      } else {
        operation.setDocumentStyle();
      } 
    } 
    return operation;
  }
  
  public void removeOperation(String paramString) { this.operations.remove(paramString); }
  
  public Operation findOperation(SOAPElement paramSOAPElement) {
    if ("rpc".equals(this.style) || "documentwrapped".equals(this.style)) {
      if (paramSOAPElement == null)
        return null; 
      return getOperation(paramSOAPElement.getElementName().getLocalName());
    } 
    for (Iterator iterator = getOperations(); iterator.hasNext(); ) {
      Operation operation = (Operation)iterator.next();
      Iterator iterator1 = operation.getInput().getParts();
      if (iterator1.hasNext()) {
        Part part = (Part)iterator1.next();
        if (iterator1.hasNext());
        if (paramSOAPElement != null && part.getXMLType().getLocalPart().equals(paramSOAPElement.getElementName().getLocalName())) {
          String str1 = part.getXMLType().getNamespaceURI();
          String str2 = paramSOAPElement.getElementName().getURI();
          if ((str1 == null || str1.equals("")) && (str2 == null || str2.equals("")))
            return operation; 
          if (str1 != null && str1.equals(str2))
            return operation; 
        } 
        continue;
      } 
      if (paramSOAPElement == null)
        return operation; 
    } 
    return null;
  }
  
  private void setMessageProps(WLMessageContext paramWLMessageContext, Map paramMap) {
    Iterator iterator = paramMap.keySet().iterator();
    while (iterator.hasNext()) {
      String str = (String)iterator.next();
      paramWLMessageContext.setProperty(str, paramMap.get(str));
    } 
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Port[\n");
    for (Iterator iterator = getOperations(); iterator.hasNext();)
      stringBuffer.append(iterator.next()); 
    stringBuffer.append("]\n");
    return stringBuffer.toString();
  }
  
  public Map getCookies() { return this.cookies; }
  
  public String getCookiesAsString() {
    Iterator iterator = this.cookies.keySet().iterator();
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool = false;
    while (iterator.hasNext()) {
      if (bool)
        stringBuffer.append("; "); 
      String str1 = (String)iterator.next();
      String str2 = (String)this.cookies.get(str1);
      String str3 = str1 + "=" + str2;
      stringBuffer.append(str3);
      bool = true;
    } 
    return stringBuffer.toString();
  }
  
  public void addCookie(String paramString1, String paramString2) {
    if (this.maintainSession)
      this.cookies.put(paramString1, paramString2); 
  }
  
  public void addCookies(String paramString) {
    if (this.maintainSession) {
      String[] arrayOfString = StringUtils.splitCompletely(paramString, ";");
      for (byte b = 0; b < arrayOfString.length; b++) {
        int i = arrayOfString[b].indexOf("=");
        if (i != -1 && i < arrayOfString[b].length() - 1) {
          String str1 = arrayOfString[b].substring(0, i);
          String str2 = arrayOfString[b].substring(i + 1, arrayOfString[b].length());
          addCookie(str1, str2);
        } 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultPort.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */