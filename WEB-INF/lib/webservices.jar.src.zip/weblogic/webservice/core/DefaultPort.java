/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.handler.HandlerRegistry;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import weblogic.utils.StringUtils;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPort
/*     */   implements Port
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   private String name;
/*     */   private String typeName;
/*     */   private String address;
/*     */   private String username;
/*     */   private String password;
/*     */   private String sessionID;
/*     */   private String proxyUsername;
/*     */   private String proxyPassword;
/*     */   private boolean maintainSession;
/*     */   private String style;
/*     */   private HashMap operations;
/*     */   private LinkedList orderedOperations;
/*     */   private BindingInfo bindingInfo;
/*     */   private TypeMappingRegistry typeMappingRegistry;
/*     */   private HandlerRegistry registry;
/*     */   private WebService service;
/*     */   private Map cookies;
/*     */   
/*     */   DefaultPort(WebService paramWebService) {
/*  51 */     this.maintainSession = true;
/*     */     
/*  53 */     this.style = "rpc";
/*  54 */     this.operations = new HashMap();
/*  55 */     this.orderedOperations = new LinkedList();
/*     */     
/*  57 */     this.bindingInfo = new BindingInfo();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.cookies = new HashMap();
/*     */ 
/*     */     
/*  68 */     this.service = paramWebService;
/*     */   }
/*     */ 
/*     */   
/*  72 */   public HandlerRegistry getHandlerRegistry() { return this.registry; }
/*     */ 
/*     */ 
/*     */   
/*  76 */   public void setHandlerRegistry(HandlerRegistry paramHandlerRegistry) { this.registry = paramHandlerRegistry; }
/*     */ 
/*     */ 
/*     */   
/*  80 */   public WebService getService() { return this.service; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  85 */     Iterator iterator = this.operations.values().iterator();
/*     */     
/*  87 */     while (iterator.hasNext()) {
/*  88 */       Operation operation = (Operation)iterator.next();
/*  89 */       operation.destroy();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void setName(String paramString) { this.name = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 103 */   public String getTypeName() { return this.typeName; }
/*     */ 
/*     */ 
/*     */   
/* 107 */   public void setTypeName(String paramString) { this.typeName = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 111 */   public String getStyle() { return this.style; }
/*     */ 
/*     */   
/*     */   public void setStyle(String paramString) {
/* 115 */     if ("rpc".equalsIgnoreCase(paramString) || "document".equalsIgnoreCase(paramString) || "documentwrapped".equalsIgnoreCase(paramString)) {
/*     */ 
/*     */       
/* 118 */       this.style = paramString.toLowerCase();
/* 119 */     } else if (paramString == null) {
/* 120 */       this.style = "rpc";
/*     */     } else {
/* 122 */       throw new IllegalArgumentException("Invalid operation style: " + paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 128 */   public boolean isDocumentStyle() { return "document".equals(this.style); }
/*     */ 
/*     */ 
/*     */   
/* 132 */   public boolean isRpcStyle() { return "rpc".equals(this.style); }
/*     */ 
/*     */ 
/*     */   
/* 136 */   public String getAddress() { return this.address; }
/*     */ 
/*     */ 
/*     */   
/* 140 */   public void setAddress(String paramString) { this.address = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 144 */   public String getUserName() { return this.username; }
/*     */ 
/*     */ 
/*     */   
/* 148 */   public void setUserName(String paramString) { this.username = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 152 */   public String getPassword() { return this.password; }
/*     */ 
/*     */ 
/*     */   
/* 156 */   public void setPassword(String paramString) { this.password = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 160 */   public String getProxyUserName() { return this.proxyUsername; }
/*     */ 
/*     */ 
/*     */   
/* 164 */   public void setProxyUserName(String paramString) { this.proxyUsername = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 168 */   public String getProxyPassword() { return this.proxyPassword; }
/*     */ 
/*     */ 
/*     */   
/* 172 */   public void setProxyPassword(String paramString) { this.proxyPassword = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 176 */   public void setMaintainSession(boolean paramBoolean) { this.maintainSession = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 180 */   public boolean getMaintainSession() { return this.maintainSession; }
/*     */ 
/*     */ 
/*     */   
/* 184 */   public String getSessionID() { return this.sessionID; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSessionID(String paramString) {
/* 189 */     if (this.maintainSession) {
/* 190 */       this.sessionID = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 195 */   public BindingInfo getBindingInfo() { return this.bindingInfo; }
/*     */ 
/*     */ 
/*     */   
/* 199 */   public void setBindingInfo(BindingInfo paramBindingInfo) { this.bindingInfo = paramBindingInfo; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   public TypeMappingRegistry getTypeMappingRegistry() { return this.typeMappingRegistry; }
/*     */ 
/*     */ 
/*     */   
/* 219 */   public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) { this.typeMappingRegistry = paramTypeMappingRegistry; }
/*     */ 
/*     */ 
/*     */   
/* 223 */   public Operation getOperation(String paramString) { return (Operation)this.operations.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 227 */   public Iterator getOperations() { return this.operations.values().iterator(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public Iterator getOrderedOperations() { return this.orderedOperations.listIterator(0); }
/*     */ 
/*     */ 
/*     */   
/* 237 */   public Operation addOperation(String paramString) { return addOperation(paramString, (HandlerInfo[])null); }
/*     */ 
/*     */   
/*     */   public void addOperation(Operation paramOperation) {
/* 241 */     this.operations.put(paramOperation.getName(), paramOperation);
/* 242 */     this.orderedOperations.add(paramOperation);
/*     */   }
/*     */ 
/*     */   
/*     */   public Operation addOperation(String paramString, HandlerInfo[] paramArrayOfHandlerInfo) {
/* 247 */     Operation operation = getOperation(paramString);
/*     */     
/* 249 */     if (operation == null) {
/* 250 */       operation = new DefaultOperation(paramString, this, paramArrayOfHandlerInfo);
/* 251 */       operation.setTypeMappingRegistry(this.typeMappingRegistry);
/* 252 */       addOperation(operation);
/*     */       
/* 254 */       if (isRpcStyle()) {
/* 255 */         operation.setRpcStyle();
/*     */       } else {
/* 257 */         operation.setDocumentStyle();
/*     */       } 
/*     */     } 
/*     */     
/* 261 */     return operation;
/*     */   }
/*     */ 
/*     */   
/* 265 */   public void removeOperation(String paramString) { this.operations.remove(paramString); }
/*     */ 
/*     */ 
/*     */   
/*     */   public Operation findOperation(SOAPElement paramSOAPElement) {
/* 270 */     if ("rpc".equals(this.style) || "documentwrapped".equals(this.style)) {
/* 271 */       if (paramSOAPElement == null) {
/* 272 */         return null;
/*     */       }
/* 274 */       return getOperation(paramSOAPElement.getElementName().getLocalName());
/*     */     } 
/*     */ 
/*     */     
/* 278 */     for (Iterator iterator = getOperations(); iterator.hasNext(); ) {
/* 279 */       Operation operation = (Operation)iterator.next();
/* 280 */       Iterator iterator1 = operation.getInput().getParts();
/*     */       
/* 282 */       if (iterator1.hasNext()) {
/* 283 */         Part part = (Part)iterator1.next();
/*     */         
/* 285 */         if (iterator1.hasNext());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 290 */         if (paramSOAPElement != null && part.getXMLType().getLocalPart().equals(paramSOAPElement.getElementName().getLocalName())) {
/*     */ 
/*     */           
/* 293 */           String str1 = part.getXMLType().getNamespaceURI();
/* 294 */           String str2 = paramSOAPElement.getElementName().getURI();
/*     */           
/* 296 */           if ((str1 == null || str1.equals("")) && (str2 == null || str2.equals("")))
/*     */           {
/*     */             
/* 299 */             return operation;
/*     */           }
/* 301 */           if (str1 != null && str1.equals(str2)) {
/* 302 */             return operation;
/*     */           }
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 308 */       if (paramSOAPElement == null) {
/* 309 */         return operation;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 314 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setMessageProps(WLMessageContext paramWLMessageContext, Map paramMap) {
/* 416 */     Iterator iterator = paramMap.keySet().iterator();
/*     */     
/* 418 */     while (iterator.hasNext()) {
/* 419 */       String str = (String)iterator.next();
/*     */       
/* 421 */       paramWLMessageContext.setProperty(str, paramMap.get(str));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 427 */     StringBuffer stringBuffer = new StringBuffer();
/* 428 */     stringBuffer.append("Port[\n");
/*     */     
/* 430 */     for (Iterator iterator = getOperations(); iterator.hasNext();) {
/* 431 */       stringBuffer.append(iterator.next());
/*     */     }
/*     */     
/* 434 */     stringBuffer.append("]\n");
/* 435 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 445 */   public Map getCookies() { return this.cookies; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCookiesAsString() {
/* 455 */     Iterator iterator = this.cookies.keySet().iterator();
/* 456 */     StringBuffer stringBuffer = new StringBuffer();
/* 457 */     boolean bool = false;
/* 458 */     while (iterator.hasNext()) {
/* 459 */       if (bool) {
/* 460 */         stringBuffer.append("; ");
/*     */       }
/* 462 */       String str1 = (String)iterator.next();
/* 463 */       String str2 = (String)this.cookies.get(str1);
/* 464 */       String str3 = str1 + "=" + str2;
/* 465 */       stringBuffer.append(str3);
/* 466 */       bool = true;
/*     */     } 
/* 468 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCookie(String paramString1, String paramString2) {
/* 478 */     if (this.maintainSession) {
/* 479 */       this.cookies.put(paramString1, paramString2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCookies(String paramString) {
/* 491 */     if (this.maintainSession) {
/* 492 */       String[] arrayOfString = StringUtils.splitCompletely(paramString, ";");
/* 493 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 494 */         int i = arrayOfString[b].indexOf("=");
/* 495 */         if (i != -1 && i < arrayOfString[b].length() - 1) {
/* 496 */           String str1 = arrayOfString[b].substring(0, i);
/* 497 */           String str2 = arrayOfString[b].substring(i + 1, arrayOfString[b].length());
/* 498 */           addCookie(str1, str2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultPort.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */