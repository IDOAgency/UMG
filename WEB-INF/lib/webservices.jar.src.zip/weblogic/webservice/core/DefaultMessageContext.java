/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.soap.MessageFactory;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.util.WLMessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultMessageContext
/*     */   implements WLMessageContext
/*     */ {
/*     */   private SOAPMessage msg;
/*     */   private MessageFactory messageFactory;
/*     */   private Map propertyMap;
/*     */   private Operation operation;
/*     */   private boolean hasFault;
/*     */   
/*  44 */   public DefaultMessageContext() throws SOAPException { this((Operation)null); }
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultMessageContext(Operation paramOperation) throws SOAPException {
/*     */     this.propertyMap = new HashMap();
/*  50 */     this.operation = paramOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
/*     */   }
/*     */ 
/*     */   
/*  59 */   public String[] getRoles() { throw new Error("NIY"); }
/*     */ 
/*     */   
/*     */   public SOAPMessage getMessage() {
/*  63 */     if (this.msg == null) {
/*     */       try {
/*  65 */         this.msg = this.messageFactory.createMessage();
/*  66 */       } catch (SOAPException sOAPException) {
/*  67 */         throw new JAXRPCException(sOAPException);
/*     */       } 
/*     */     }
/*     */     
/*  71 */     return this.msg;
/*     */   }
/*     */ 
/*     */   
/*  75 */   public void setMessage(SOAPMessage paramSOAPMessage) { this.msg = paramSOAPMessage; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPMessage clearMessage() {
/*     */     try {
/*  85 */       setMessage(this.messageFactory.createMessage());
/*  86 */     } catch (SOAPException sOAPException) {
/*  87 */       throw new JAXRPCException(sOAPException);
/*     */     } 
/*     */     
/*  90 */     return this.msg;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public void setProperty(String paramString, Object paramObject) { this.propertyMap.put(paramString, paramObject); }
/*     */ 
/*     */ 
/*     */   
/*  99 */   public Object getProperty(String paramString) { return this.propertyMap.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 103 */   public void removeProperty(String paramString) { this.propertyMap.remove(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 107 */   public boolean containsProperty(String paramString) { return this.propertyMap.containsKey(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 111 */   public Iterator getPropertyNames() { return this.propertyMap.keySet().iterator(); }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public void setFault(boolean paramBoolean) { this.hasFault = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 119 */   public boolean hasFault() { return this.hasFault; }
/*     */ 
/*     */ 
/*     */   
/* 123 */   public Operation getOperation() { return this.operation; }
/*     */ 
/*     */ 
/*     */   
/* 127 */   public void setOperation(Operation paramOperation) throws SOAPException { this.operation = paramOperation; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultMessageContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */