package weblogic.webservice.core;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.xml.rpc.JAXRPCException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.webservice.Operation;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.util.WLMessageFactory;

public class DefaultMessageContext implements WLMessageContext {
  private SOAPMessage msg;
  
  private MessageFactory messageFactory;
  
  private Map propertyMap;
  
  private Operation operation;
  
  private boolean hasFault;
  
  public DefaultMessageContext() throws SOAPException { this((Operation)null); }
  
  DefaultMessageContext(Operation paramOperation) throws SOAPException {
    this.propertyMap = new HashMap();
    this.operation = paramOperation;
    this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
  }
  
  public String[] getRoles() { throw new Error("NIY"); }
  
  public SOAPMessage getMessage() {
    if (this.msg == null)
      try {
        this.msg = this.messageFactory.createMessage();
      } catch (SOAPException sOAPException) {
        throw new JAXRPCException(sOAPException);
      }  
    return this.msg;
  }
  
  public void setMessage(SOAPMessage paramSOAPMessage) { this.msg = paramSOAPMessage; }
  
  public SOAPMessage clearMessage() {
    try {
      setMessage(this.messageFactory.createMessage());
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException(sOAPException);
    } 
    return this.msg;
  }
  
  public void setProperty(String paramString, Object paramObject) { this.propertyMap.put(paramString, paramObject); }
  
  public Object getProperty(String paramString) { return this.propertyMap.get(paramString); }
  
  public void removeProperty(String paramString) { this.propertyMap.remove(paramString); }
  
  public boolean containsProperty(String paramString) { return this.propertyMap.containsKey(paramString); }
  
  public Iterator getPropertyNames() { return this.propertyMap.keySet().iterator(); }
  
  public void setFault(boolean paramBoolean) { this.hasFault = paramBoolean; }
  
  public boolean hasFault() { return this.hasFault; }
  
  public Operation getOperation() { return this.operation; }
  
  public void setOperation(Operation paramOperation) throws SOAPException { this.operation = paramOperation; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultMessageContext.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */