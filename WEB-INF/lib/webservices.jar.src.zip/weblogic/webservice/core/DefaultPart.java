/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.encoding.TypeMapping;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.util.ExceptionUtil;
/*     */ import weblogic.xml.schema.binding.DeserializationContext;
/*     */ import weblogic.xml.schema.binding.DeserializationException;
/*     */ import weblogic.xml.schema.binding.EncodingStyle;
/*     */ import weblogic.xml.schema.binding.RuntimeUtils;
/*     */ import weblogic.xml.schema.binding.SerializationContext;
/*     */ import weblogic.xml.schema.binding.SerializationException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.stream.ElementFactory;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ import weblogic.xml.xmlnode.XMLNodeOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPart
/*     */   implements Part
/*     */ {
/*     */   private static final int BODY = 0;
/*     */   private static final int HEADER = 1;
/*     */   private static final int ATTACHMENT = 2;
/*     */   private static final String xsdNS = "http://www.w3.org/2001/XMLSchema";
/*     */   private String name;
/*     */   private String namespace;
/*     */   private boolean isElement = false;
/*     */   private XMLName xmlType;
/*     */   private Class javaType;
/*     */   private String[] contentType;
/*     */   private DefaultMessage message;
/*  66 */   private int location = 0;
/*  67 */   private Part.Mode mode = Part.Mode.IN;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DefaultPart(String paramString1, String paramString2, String paramString3, Class paramClass, DefaultMessage paramDefaultMessage) {
/*  76 */     if (paramString1 == null) {
/*  77 */       throw new IllegalArgumentException("Name of the part can not be null");
/*     */     }
/*     */     
/*  80 */     if (paramString2 == null) {
/*  81 */       throw new IllegalArgumentException("XML Type can not be null");
/*     */     }
/*     */     
/*  84 */     this.name = paramString1;
/*  85 */     this.javaType = paramClass;
/*  86 */     this.xmlType = ElementFactory.createXMLName(paramString3, paramString2);
/*  87 */     this.message = paramDefaultMessage;
/*     */   }
/*     */ 
/*     */   
/*  91 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */   
/*  95 */   public void setName(String paramString) { this.name = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void setNamespace(String paramString) { this.namespace = paramString; }
/*     */ 
/*     */   
/*     */   public Class getJavaType() {
/* 103 */     if (this.javaType == null) {
/*     */       
/* 105 */       Class clazz = this.message.getInternalTypeMapping().getClassFromXMLName(this.xmlType);
/*     */ 
/*     */       
/* 108 */       if (clazz == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 115 */         clazz = SOAPElement.class;
/*     */       }
/*     */       
/* 118 */       return clazz;
/*     */     } 
/* 120 */     return this.javaType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void setJavaType(Class paramClass) { this.javaType = paramClass; }
/*     */ 
/*     */ 
/*     */   
/* 129 */   public QName getXMLType() { return new QName(this.xmlType.getNamespaceUri(), this.xmlType.getLocalName()); }
/*     */ 
/*     */ 
/*     */   
/* 133 */   public void setXMLType(String paramString1, String paramString2) { this.xmlType = ElementFactory.createXMLName(paramString2, paramString1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public TypeMapping getTypeMapping() { return this.message.getTypeMappingRegistry().getDefaultTypeMapping(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeMapping(TypeMapping paramTypeMapping) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public boolean isHeader() { return (this.location == 1); }
/*     */ 
/*     */ 
/*     */   
/* 153 */   public void setHeader() { this.location = 1; }
/*     */ 
/*     */ 
/*     */   
/* 157 */   public boolean isBody() { return (this.location == 0); }
/*     */ 
/*     */ 
/*     */   
/* 161 */   public void setBody() { this.location = 0; }
/*     */ 
/*     */ 
/*     */   
/* 165 */   public void setAttachment() { this.location = 2; }
/*     */ 
/*     */ 
/*     */   
/* 169 */   public boolean isAttachment() { return (this.location == 2); }
/*     */ 
/*     */ 
/*     */   
/* 173 */   public boolean isElement() { return this.isElement; }
/*     */ 
/*     */ 
/*     */   
/* 177 */   public void setElement() { this.isElement = true; }
/*     */ 
/*     */ 
/*     */   
/* 181 */   public boolean isType() { return !this.isElement; }
/*     */ 
/*     */ 
/*     */   
/* 185 */   public void setType() { this.isElement = false; }
/*     */ 
/*     */ 
/*     */   
/* 189 */   public Part.Mode getMode() { return this.mode; }
/*     */ 
/*     */ 
/*     */   
/* 193 */   public void setMode(Part.Mode paramMode) { this.mode = paramMode; }
/*     */ 
/*     */ 
/*     */   
/* 197 */   public void setContentType(String[] paramArrayOfString) { this.contentType = paramArrayOfString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addContentType(String paramString) {
/* 205 */     if (this.contentType == null) {
/* 206 */       this.contentType = new String[] { paramString };
/*     */     } else {
/* 208 */       String[] arrayOfString = new String[this.contentType.length + 1];
/* 209 */       System.arraycopy(this.contentType, 0, arrayOfString, 0, this.contentType.length);
/* 210 */       arrayOfString[arrayOfString.length - 1] = paramString;
/* 211 */       this.contentType = arrayOfString;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   public String[] getContentType() { return this.contentType; }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 222 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 224 */     stringBuffer.append("DefaultPart[\n");
/* 225 */     stringBuffer.append("javaType=").append(getJavaType()).append(",\n");
/* 226 */     stringBuffer.append("xmlType=").append(this.xmlType).append(",\n");
/* 227 */     stringBuffer.append("location=").append(this.location).append(",\n");
/* 228 */     stringBuffer.append("]\n");
/*     */     
/* 230 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLName getXMLName() {
/*     */     XMLName xMLName;
/* 241 */     if (this.namespace != null) {
/* 242 */       return ElementFactory.createXMLName(this.namespace, this.name);
/*     */     }
/*     */     
/* 245 */     if (isHeader()) {
/* 246 */       if ("http://www.w3.org/2001/XMLSchema".equals(this.xmlType.getNamespaceUri())) {
/* 247 */         xMLName = ElementFactory.createXMLName(this.message.getNamespace(), this.name);
/*     */       } else {
/* 249 */         xMLName = ElementFactory.createXMLName(this.xmlType.getNamespaceUri(), this.name);
/*     */       }
/*     */     
/* 252 */     } else if ("documentwrapped".equals(this.message.getStyle())) {
/* 253 */       if (Exception.class.isAssignableFrom(getJavaType()) && this.isElement) {
/* 254 */         xMLName = this.xmlType;
/*     */       } else {
/* 256 */         xMLName = ElementFactory.createXMLName(this.message.getNamespace(), this.name);
/*     */       } 
/* 258 */     } else if ("document".equals(this.message.getStyle())) {
/* 259 */       xMLName = this.xmlType;
/*     */     } else {
/* 261 */       xMLName = ElementFactory.createXMLName(this.name);
/*     */     } 
/*     */ 
/*     */     
/* 265 */     return xMLName;
/*     */   }
/*     */ 
/*     */   
/* 269 */   private EncodingStyle getEncodingStyle() { return this.message.isLiteral() ? EncodingStyle.LITERAL : EncodingStyle.SOAP; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toXML(SOAPElement paramSOAPElement, Object paramObject, SerializationContext paramSerializationContext, boolean paramBoolean, TypeMapping paramTypeMapping) throws SOAPException {
/*     */     try {
/* 279 */       if (isHeader()) {
/* 280 */         paramSerializationContext.setInTopLevelElement(true);
/*     */       }
/*     */       
/* 283 */       paramSerializationContext.setEncodingStyle(getEncodingStyle());
/* 284 */       paramSerializationContext.setIncludeXsiType(!this.message.isLiteral());
/*     */       
/* 286 */       paramSerializationContext.setMapping((TypeMapping)paramTypeMapping);
/*     */ 
/*     */       
/* 289 */       if ("rpc".equals(this.message.getStyle())) {
/* 290 */         paramSerializationContext.setQualifyElements(false);
/* 291 */       } else if (this.message.isLiteral()) {
/* 292 */         paramSerializationContext.setQualifyElements(true);
/*     */       } else {
/* 294 */         paramSerializationContext.setQualifyElements(false);
/*     */       } 
/*     */       
/* 297 */       XMLNodeOutputStream xMLNodeOutputStream = null;
/* 298 */       xMLNodeOutputStream = new XMLNodeOutputStream((XMLNode)paramSOAPElement);
/*     */       
/* 300 */       invokeSerializer(paramObject, xMLNodeOutputStream, paramSerializationContext);
/*     */       
/* 302 */       if (xMLNodeOutputStream != null) {
/* 303 */         xMLNodeOutputStream.flush();
/*     */       }
/*     */     }
/* 306 */     catch (IOException iOException) {
/* 307 */       throw new SOAPException(" failed to write xml:" + iOException, iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void invokeSerializer(Object paramObject, XMLOutputStream paramXMLOutputStream, SerializationContext paramSerializationContext) throws SOAPException {
/*     */     try {
/* 315 */       if (Exception.class.isAssignableFrom(getJavaType())) {
/* 316 */         Class clazz = ExceptionUtil.getSingleSimpleProperty(getJavaType());
/*     */         
/* 318 */         if (clazz != null) {
/* 319 */           RuntimeUtils.invoke_serializer(ExceptionUtil.getPropertyValue(paramObject, clazz), clazz, this.xmlType, getXMLName(), paramXMLOutputStream, paramSerializationContext);
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 327 */       RuntimeUtils.invoke_serializer(paramObject, getJavaType(), this.xmlType, getXMLName(), paramXMLOutputStream, paramSerializationContext);
/*     */     
/*     */     }
/* 330 */     catch (SerializationException serializationException) {
/* 331 */       throw new SOAPException(" failed to serialize " + getJavaType() + serializationException, serializationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object toJava(SOAPElement paramSOAPElement, DeserializationContext paramDeserializationContext, TypeMapping paramTypeMapping) throws SOAPException {
/* 339 */     if (paramSOAPElement == null) {
/* 340 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 351 */     paramDeserializationContext.setValidateNames(false);
/*     */     
/* 353 */     TypeMapping typeMapping = (TypeMapping)paramTypeMapping;
/*     */ 
/*     */     
/* 356 */     paramDeserializationContext.setMapping(typeMapping);
/*     */     
/* 358 */     paramDeserializationContext.setSOAPElement(paramSOAPElement);
/*     */     
/* 360 */     XMLName xMLName = ElementFactory.createXMLName((paramSOAPElement != null) ? paramSOAPElement.getElementName().getLocalName() : this.name);
/*     */ 
/*     */     
/* 363 */     if (Exception.class.isAssignableFrom(getJavaType()) && !this.xmlType.equals(typeMapping.getXMLNameFromClass(getJavaType()))) {
/*     */ 
/*     */       
/* 366 */       Class clazz = ExceptionUtil.getSingleProperty(getJavaType());
/*     */       
/* 368 */       if (clazz != null) {
/* 369 */         Object object = null;
/*     */         try {
/* 371 */           object = RuntimeUtils.invoke_deserializer(xMLName, this.xmlType, clazz, ((XMLNode)paramSOAPElement).stream(), paramDeserializationContext);
/*     */         }
/* 373 */         catch (DeserializationException deserializationException) {
/* 374 */           throw new SOAPException("failed to deserialize xml:" + deserializationException, deserializationException);
/*     */         } 
/*     */         
/*     */         try {
/* 378 */           Constructor constructor = getJavaType().getConstructor(new Class[] { clazz });
/* 379 */           return constructor.newInstance(new Object[] { object });
/* 380 */         } catch (Exception exception) {
/* 381 */           throw new SOAPException("failed to deserialize xml:" + exception, exception);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 387 */       return RuntimeUtils.invoke_deserializer(xMLName, this.xmlType, getJavaType(), ((XMLNode)paramSOAPElement).stream(), paramDeserializationContext);
/*     */ 
/*     */     
/*     */     }
/* 391 */     catch (DeserializationException deserializationException) {
/* 392 */       throw new SOAPException("failed to deserialize xml:" + deserializationException, deserializationException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultPart.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */