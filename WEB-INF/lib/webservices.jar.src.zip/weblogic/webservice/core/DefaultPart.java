package weblogic.webservice.core;

import java.io.IOException;
import java.lang.reflect.Constructor;
import javax.xml.namespace.QName;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import weblogic.webservice.Part;
import weblogic.webservice.util.ExceptionUtil;
import weblogic.xml.schema.binding.DeserializationContext;
import weblogic.xml.schema.binding.DeserializationException;
import weblogic.xml.schema.binding.EncodingStyle;
import weblogic.xml.schema.binding.RuntimeUtils;
import weblogic.xml.schema.binding.SerializationContext;
import weblogic.xml.schema.binding.SerializationException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.stream.ElementFactory;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeOutputStream;

public class DefaultPart implements Part {
  private static final int BODY = 0;
  
  private static final int HEADER = 1;
  
  private static final int ATTACHMENT = 2;
  
  private static final String xsdNS = "http://www.w3.org/2001/XMLSchema";
  
  private String name;
  
  private String namespace;
  
  private boolean isElement = false;
  
  private XMLName xmlType;
  
  private Class javaType;
  
  private String[] contentType;
  
  private DefaultMessage message;
  
  private int location = 0;
  
  private Part.Mode mode = Part.Mode.IN;
  
  DefaultPart(String paramString1, String paramString2, String paramString3, Class paramClass, DefaultMessage paramDefaultMessage) {
    if (paramString1 == null)
      throw new IllegalArgumentException("Name of the part can not be null"); 
    if (paramString2 == null)
      throw new IllegalArgumentException("XML Type can not be null"); 
    this.name = paramString1;
    this.javaType = paramClass;
    this.xmlType = ElementFactory.createXMLName(paramString3, paramString2);
    this.message = paramDefaultMessage;
  }
  
  public String getName() { return this.name; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public void setNamespace(String paramString) { this.namespace = paramString; }
  
  public Class getJavaType() {
    if (this.javaType == null) {
      Class clazz = this.message.getInternalTypeMapping().getClassFromXMLName(this.xmlType);
      if (clazz == null)
        clazz = SOAPElement.class; 
      return clazz;
    } 
    return this.javaType;
  }
  
  public void setJavaType(Class paramClass) { this.javaType = paramClass; }
  
  public QName getXMLType() { return new QName(this.xmlType.getNamespaceUri(), this.xmlType.getLocalName()); }
  
  public void setXMLType(String paramString1, String paramString2) { this.xmlType = ElementFactory.createXMLName(paramString2, paramString1); }
  
  public TypeMapping getTypeMapping() { return this.message.getTypeMappingRegistry().getDefaultTypeMapping(); }
  
  public void setTypeMapping(TypeMapping paramTypeMapping) {}
  
  public boolean isHeader() { return (this.location == 1); }
  
  public void setHeader() { this.location = 1; }
  
  public boolean isBody() { return (this.location == 0); }
  
  public void setBody() { this.location = 0; }
  
  public void setAttachment() { this.location = 2; }
  
  public boolean isAttachment() { return (this.location == 2); }
  
  public boolean isElement() { return this.isElement; }
  
  public void setElement() { this.isElement = true; }
  
  public boolean isType() { return !this.isElement; }
  
  public void setType() { this.isElement = false; }
  
  public Part.Mode getMode() { return this.mode; }
  
  public void setMode(Part.Mode paramMode) { this.mode = paramMode; }
  
  public void setContentType(String[] paramArrayOfString) { this.contentType = paramArrayOfString; }
  
  public void addContentType(String paramString) {
    if (this.contentType == null) {
      this.contentType = new String[] { paramString };
    } else {
      String[] arrayOfString = new String[this.contentType.length + 1];
      System.arraycopy(this.contentType, 0, arrayOfString, 0, this.contentType.length);
      arrayOfString[arrayOfString.length - 1] = paramString;
      this.contentType = arrayOfString;
    } 
  }
  
  public String[] getContentType() { return this.contentType; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("DefaultPart[\n");
    stringBuffer.append("javaType=").append(getJavaType()).append(",\n");
    stringBuffer.append("xmlType=").append(this.xmlType).append(",\n");
    stringBuffer.append("location=").append(this.location).append(",\n");
    stringBuffer.append("]\n");
    return stringBuffer.toString();
  }
  
  public XMLName getXMLName() {
    XMLName xMLName;
    if (this.namespace != null)
      return ElementFactory.createXMLName(this.namespace, this.name); 
    if (isHeader()) {
      if ("http://www.w3.org/2001/XMLSchema".equals(this.xmlType.getNamespaceUri())) {
        xMLName = ElementFactory.createXMLName(this.message.getNamespace(), this.name);
      } else {
        xMLName = ElementFactory.createXMLName(this.xmlType.getNamespaceUri(), this.name);
      } 
    } else if ("documentwrapped".equals(this.message.getStyle())) {
      if (Exception.class.isAssignableFrom(getJavaType()) && this.isElement) {
        xMLName = this.xmlType;
      } else {
        xMLName = ElementFactory.createXMLName(this.message.getNamespace(), this.name);
      } 
    } else if ("document".equals(this.message.getStyle())) {
      xMLName = this.xmlType;
    } else {
      xMLName = ElementFactory.createXMLName(this.name);
    } 
    return xMLName;
  }
  
  private EncodingStyle getEncodingStyle() { return this.message.isLiteral() ? EncodingStyle.LITERAL : EncodingStyle.SOAP; }
  
  public void toXML(SOAPElement paramSOAPElement, Object paramObject, SerializationContext paramSerializationContext, boolean paramBoolean, TypeMapping paramTypeMapping) throws SOAPException {
    try {
      if (isHeader())
        paramSerializationContext.setInTopLevelElement(true); 
      paramSerializationContext.setEncodingStyle(getEncodingStyle());
      paramSerializationContext.setIncludeXsiType(!this.message.isLiteral());
      paramSerializationContext.setMapping((TypeMapping)paramTypeMapping);
      if ("rpc".equals(this.message.getStyle())) {
        paramSerializationContext.setQualifyElements(false);
      } else if (this.message.isLiteral()) {
        paramSerializationContext.setQualifyElements(true);
      } else {
        paramSerializationContext.setQualifyElements(false);
      } 
      XMLNodeOutputStream xMLNodeOutputStream = null;
      xMLNodeOutputStream = new XMLNodeOutputStream((XMLNode)paramSOAPElement);
      invokeSerializer(paramObject, xMLNodeOutputStream, paramSerializationContext);
      if (xMLNodeOutputStream != null)
        xMLNodeOutputStream.flush(); 
    } catch (IOException iOException) {
      throw new SOAPException(" failed to write xml:" + iOException, iOException);
    } 
  }
  
  private void invokeSerializer(Object paramObject, XMLOutputStream paramXMLOutputStream, SerializationContext paramSerializationContext) throws SOAPException {
    try {
      if (Exception.class.isAssignableFrom(getJavaType())) {
        Class clazz = ExceptionUtil.getSingleSimpleProperty(getJavaType());
        if (clazz != null) {
          RuntimeUtils.invoke_serializer(ExceptionUtil.getPropertyValue(paramObject, clazz), clazz, this.xmlType, getXMLName(), paramXMLOutputStream, paramSerializationContext);
          return;
        } 
      } 
      RuntimeUtils.invoke_serializer(paramObject, getJavaType(), this.xmlType, getXMLName(), paramXMLOutputStream, paramSerializationContext);
    } catch (SerializationException serializationException) {
      throw new SOAPException(" failed to serialize " + getJavaType() + serializationException, serializationException);
    } 
  }
  
  public Object toJava(SOAPElement paramSOAPElement, DeserializationContext paramDeserializationContext, TypeMapping paramTypeMapping) throws SOAPException {
    if (paramSOAPElement == null)
      return null; 
    paramDeserializationContext.setValidateNames(false);
    TypeMapping typeMapping = (TypeMapping)paramTypeMapping;
    paramDeserializationContext.setMapping(typeMapping);
    paramDeserializationContext.setSOAPElement(paramSOAPElement);
    XMLName xMLName = ElementFactory.createXMLName((paramSOAPElement != null) ? paramSOAPElement.getElementName().getLocalName() : this.name);
    if (Exception.class.isAssignableFrom(getJavaType()) && !this.xmlType.equals(typeMapping.getXMLNameFromClass(getJavaType()))) {
      Class clazz = ExceptionUtil.getSingleProperty(getJavaType());
      if (clazz != null) {
        Object object = null;
        try {
          object = RuntimeUtils.invoke_deserializer(xMLName, this.xmlType, clazz, ((XMLNode)paramSOAPElement).stream(), paramDeserializationContext);
        } catch (DeserializationException deserializationException) {
          throw new SOAPException("failed to deserialize xml:" + deserializationException, deserializationException);
        } 
        try {
          Constructor constructor = getJavaType().getConstructor(new Class[] { clazz });
          return constructor.newInstance(new Object[] { object });
        } catch (Exception exception) {
          throw new SOAPException("failed to deserialize xml:" + exception, exception);
        } 
      } 
    } 
    try {
      return RuntimeUtils.invoke_deserializer(xMLName, this.xmlType, getJavaType(), ((XMLNode)paramSOAPElement).stream(), paramDeserializationContext);
    } catch (DeserializationException deserializationException) {
      throw new SOAPException("failed to deserialize xml:" + deserializationException, deserializationException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultPart.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */