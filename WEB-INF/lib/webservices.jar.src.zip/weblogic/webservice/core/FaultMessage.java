package weblogic.webservice.core;

import java.util.Iterator;
import java.util.Map;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.soap.Detail;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.Debug;
import weblogic.webservice.Message;
import weblogic.webservice.Part;
import weblogic.webservice.PartFilter;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.core.soap.SOAPElementImpl;
import weblogic.xml.schema.binding.RuntimeUtils;
import weblogic.xml.schema.binding.SerializationContext;
import weblogic.xml.schema.binding.SerializationException;
import weblogic.xml.schema.binding.internal.DeserializationContextImpl;
import weblogic.xml.schema.binding.internal.SerializationContextImpl;
import weblogic.xml.schema.binding.util.NamespacePrefixMap;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;
import weblogic.xml.xmlnode.XMLNodeOutputStream;

public class FaultMessage implements Message {
  private Message ref;
  
  private Part thePart;
  
  private String faultName;
  
  private DefaultOperation operation;
  
  FaultMessage(DefaultOperation paramDefaultOperation) {
    this.ref = new DefaultMessage(paramDefaultOperation);
    this.operation = paramDefaultOperation;
  }
  
  public void setName(String paramString) { this.ref.setName(paramString); }
  
  public void setFaultName(String paramString) { this.faultName = paramString; }
  
  public void setNamespace(String paramString) { this.ref.setNamespace(paramString); }
  
  public void setEncodingStyle(String paramString) { this.ref.setEncodingStyle(paramString); }
  
  public void setContainsAttachment(boolean paramBoolean) { Debug.assertion(!paramBoolean, "FaultMessage can't contain attachment"); }
  
  public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) { this.ref.setTypeMappingRegistry(paramTypeMappingRegistry); }
  
  public String getName() { return this.ref.getName(); }
  
  public String getFaultName() { return this.faultName; }
  
  public String getNamespace() { return this.ref.getNamespace(); }
  
  public boolean isVoid() { return this.ref.isVoid(); }
  
  public boolean isMultiPart() { return false; }
  
  public boolean isSinglePart() { return true; }
  
  public String getEncodingStyle() { return this.ref.getEncodingStyle(); }
  
  public String getSecuritySpecRef() { return this.ref.getSecuritySpecRef(); }
  
  public void setSecuritySpecRef(String paramString) { this.ref.setSecuritySpecRef(paramString); }
  
  public boolean isLiteral() { return this.ref.isLiteral(); }
  
  public boolean isEncoded() { return this.ref.isEncoded(); }
  
  public boolean getContainsAttachment() { return false; }
  
  public Object[] getSortedParameters(Map paramMap) { return this.ref.getSortedParameters(paramMap); }
  
  public Part getPart(String paramString) {
    if (this.thePart != null && 
      this.thePart.getName().equals(paramString))
      return this.thePart; 
    return null;
  }
  
  public Iterator getParts() { return this.ref.getParts(); }
  
  public Part[] getParts(PartFilter paramPartFilter) {
    if (paramPartFilter.accept(this.thePart))
      return new Part[] { this.thePart }; 
    return new Part[0];
  }
  
  public TypeMappingRegistry getTypeMappingRegistry() { return this.ref.getTypeMappingRegistry(); }
  
  public void useLiteral() { this.ref.useLiteral(); }
  
  public void useEncoded() { this.ref.useEncoded(); }
  
  public Part addPart(String paramString1, String paramString2, String paramString3, Class paramClass) {
    Debug.assertion((this.thePart == null), "FaultMessage can have only one part.");
    this.thePart = this.ref.addPart(paramString1, paramString2, paramString3, paramClass);
    return this.thePart;
  }
  
  public void toXML(SOAPMessage paramSOAPMessage, Object[] paramArrayOfObject, WebServiceContext paramWebServiceContext) throws SOAPException {
    SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
    SOAPBody sOAPBody = sOAPEnvelope.getBody();
    SOAPFault sOAPFault = sOAPBody.addFault();
    sOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":Server");
    sOAPFault.setFaultString("Service specific exception: " + paramArrayOfObject[0]);
    SerializationContextImpl serializationContextImpl = new SerializationContextImpl();
    serializationContextImpl.setSOAPMessage(paramSOAPMessage);
    serializationContextImpl.setIncludeXsiType(true);
    serializationContextImpl.setNamespacePrefixMap(NamespacePrefixMap.createDefaultMap());
    TypeMapping typeMapping = getTypeMappingRegistry().getTypeMapping(getEncodingStyle());
    this.thePart.toXML(sOAPFault.addDetail(), paramArrayOfObject[0], serializationContextImpl, this.operation.isDocumentStyle(), typeMapping);
    if (serializationContextImpl.isMultiRefEmpty())
      writeXmlIds(sOAPBody, serializationContextImpl); 
  }
  
  public Object toJava(Map paramMap, SOAPMessage paramSOAPMessage, WebServiceContext paramWebServiceContext) throws SOAPException {
    SOAPBody sOAPBody = paramSOAPMessage.getSOAPPart().getEnvelope().getBody();
    Detail detail = sOAPBody.getFault().getDetail();
    if (detail == null)
      return null; 
    if (!detail.getChildElements().hasNext())
      return null; 
    SOAPElement sOAPElement = null;
    for (Iterator iterator = detail.getChildElements(); iterator.hasNext(); ) {
      Object object = iterator.next();
      if (object instanceof SOAPElement) {
        sOAPElement = (SOAPElement)object;
        break;
      } 
    } 
    if (sOAPElement == null)
      return null; 
    DeserializationContextImpl deserializationContextImpl = new DeserializationContextImpl();
    deserializationContextImpl.setSOAPMessage(paramSOAPMessage);
    TypeMapping typeMapping = getTypeMappingRegistry().getTypeMapping(getEncodingStyle());
    return this.thePart.toJava(sOAPElement, deserializationContextImpl, typeMapping);
  }
  
  public Part addPart(String paramString1, String paramString2, String paramString3) {
    Debug.assertion((this.thePart == null), "FaultMessage can have only one part.");
    this.thePart = this.ref.addPart(paramString1, paramString2, paramString3);
    return this.thePart;
  }
  
  public String toString() { return "FaultMessage[" + this.ref.toString() + "]"; }
  
  private void writeXmlIds(SOAPElement paramSOAPElement, SerializationContext paramSerializationContext) throws SOAPException {
    try {
      XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream((XMLNode)paramSOAPElement);
      paramSerializationContext.setQualifyElements(true);
      RuntimeUtils.writeTrailingBlocks(xMLNodeOutputStream, paramSerializationContext);
      xMLNodeOutputStream.flush();
    } catch (XMLStreamException xMLStreamException) {
      throw new SOAPException(xMLStreamException);
    } catch (SerializationException serializationException) {
      throw new SOAPException(serializationException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\FaultMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */