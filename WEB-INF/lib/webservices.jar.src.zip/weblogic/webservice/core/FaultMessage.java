/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.rpc.encoding.TypeMapping;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import javax.xml.soap.Detail;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.PartFilter;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.core.soap.SOAPElementImpl;
/*     */ import weblogic.xml.schema.binding.RuntimeUtils;
/*     */ import weblogic.xml.schema.binding.SerializationContext;
/*     */ import weblogic.xml.schema.binding.SerializationException;
/*     */ import weblogic.xml.schema.binding.internal.DeserializationContextImpl;
/*     */ import weblogic.xml.schema.binding.internal.SerializationContextImpl;
/*     */ import weblogic.xml.schema.binding.util.NamespacePrefixMap;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ import weblogic.xml.xmlnode.XMLNodeOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FaultMessage
/*     */   implements Message
/*     */ {
/*     */   private Message ref;
/*     */   private Part thePart;
/*     */   private String faultName;
/*     */   private DefaultOperation operation;
/*     */   
/*     */   FaultMessage(DefaultOperation paramDefaultOperation) {
/*  64 */     this.ref = new DefaultMessage(paramDefaultOperation);
/*  65 */     this.operation = paramDefaultOperation;
/*     */   }
/*     */ 
/*     */   
/*  69 */   public void setName(String paramString) { this.ref.setName(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void setFaultName(String paramString) { this.faultName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  77 */   public void setNamespace(String paramString) { this.ref.setNamespace(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void setEncodingStyle(String paramString) { this.ref.setEncodingStyle(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void setContainsAttachment(boolean paramBoolean) { Debug.assertion(!paramBoolean, "FaultMessage can't contain attachment"); }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) { this.ref.setTypeMappingRegistry(paramTypeMappingRegistry); }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public String getName() { return this.ref.getName(); }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public String getFaultName() { return this.faultName; }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public String getNamespace() { return this.ref.getNamespace(); }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public boolean isVoid() { return this.ref.isVoid(); }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public boolean isMultiPart() { return false; }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public boolean isSinglePart() { return true; }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public String getEncodingStyle() { return this.ref.getEncodingStyle(); }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public String getSecuritySpecRef() { return this.ref.getSecuritySpecRef(); }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void setSecuritySpecRef(String paramString) { this.ref.setSecuritySpecRef(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 129 */   public boolean isLiteral() { return this.ref.isLiteral(); }
/*     */ 
/*     */ 
/*     */   
/* 133 */   public boolean isEncoded() { return this.ref.isEncoded(); }
/*     */ 
/*     */ 
/*     */   
/* 137 */   public boolean getContainsAttachment() { return false; }
/*     */ 
/*     */ 
/*     */   
/* 141 */   public Object[] getSortedParameters(Map paramMap) { return this.ref.getSortedParameters(paramMap); }
/*     */ 
/*     */   
/*     */   public Part getPart(String paramString) {
/* 145 */     if (this.thePart != null && 
/* 146 */       this.thePart.getName().equals(paramString)) {
/* 147 */       return this.thePart;
/*     */     }
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 153 */   public Iterator getParts() { return this.ref.getParts(); }
/*     */ 
/*     */   
/*     */   public Part[] getParts(PartFilter paramPartFilter) {
/* 157 */     if (paramPartFilter.accept(this.thePart)) {
/* 158 */       return new Part[] { this.thePart };
/*     */     }
/* 160 */     return new Part[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 165 */   public TypeMappingRegistry getTypeMappingRegistry() { return this.ref.getTypeMappingRegistry(); }
/*     */ 
/*     */ 
/*     */   
/* 169 */   public void useLiteral() { this.ref.useLiteral(); }
/*     */ 
/*     */ 
/*     */   
/* 173 */   public void useEncoded() { this.ref.useEncoded(); }
/*     */ 
/*     */   
/*     */   public Part addPart(String paramString1, String paramString2, String paramString3, Class paramClass) {
/* 177 */     Debug.assertion((this.thePart == null), "FaultMessage can have only one part.");
/* 178 */     this.thePart = this.ref.addPart(paramString1, paramString2, paramString3, paramClass);
/* 179 */     return this.thePart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toXML(SOAPMessage paramSOAPMessage, Object[] paramArrayOfObject, WebServiceContext paramWebServiceContext) throws SOAPException {
/* 188 */     SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
/* 189 */     SOAPBody sOAPBody = sOAPEnvelope.getBody();
/* 190 */     SOAPFault sOAPFault = sOAPBody.addFault();
/*     */     
/* 192 */     sOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":Server");
/*     */     
/* 194 */     sOAPFault.setFaultString("Service specific exception: " + paramArrayOfObject[0]);
/*     */     
/* 196 */     SerializationContextImpl serializationContextImpl = new SerializationContextImpl();
/* 197 */     serializationContextImpl.setSOAPMessage(paramSOAPMessage);
/* 198 */     serializationContextImpl.setIncludeXsiType(true);
/* 199 */     serializationContextImpl.setNamespacePrefixMap(NamespacePrefixMap.createDefaultMap());
/*     */     
/* 201 */     TypeMapping typeMapping = getTypeMappingRegistry().getTypeMapping(getEncodingStyle());
/*     */ 
/*     */     
/* 204 */     this.thePart.toXML(sOAPFault.addDetail(), paramArrayOfObject[0], serializationContextImpl, this.operation.isDocumentStyle(), typeMapping);
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (serializationContextImpl.isMultiRefEmpty()) {
/* 209 */       writeXmlIds(sOAPBody, serializationContextImpl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object toJava(Map paramMap, SOAPMessage paramSOAPMessage, WebServiceContext paramWebServiceContext) throws SOAPException {
/* 217 */     SOAPBody sOAPBody = paramSOAPMessage.getSOAPPart().getEnvelope().getBody();
/* 218 */     Detail detail = sOAPBody.getFault().getDetail();
/*     */     
/* 220 */     if (detail == null) return null;
/*     */     
/* 222 */     if (!detail.getChildElements().hasNext()) return null;
/*     */     
/* 224 */     SOAPElement sOAPElement = null;
/* 225 */     for (Iterator iterator = detail.getChildElements(); iterator.hasNext(); ) {
/* 226 */       Object object = iterator.next();
/* 227 */       if (object instanceof SOAPElement) {
/* 228 */         sOAPElement = (SOAPElement)object;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 233 */     if (sOAPElement == null) return null;
/*     */     
/* 235 */     DeserializationContextImpl deserializationContextImpl = new DeserializationContextImpl();
/* 236 */     deserializationContextImpl.setSOAPMessage(paramSOAPMessage);
/*     */     
/* 238 */     TypeMapping typeMapping = getTypeMappingRegistry().getTypeMapping(getEncodingStyle());
/*     */ 
/*     */     
/* 241 */     return this.thePart.toJava(sOAPElement, deserializationContextImpl, typeMapping);
/*     */   }
/*     */   
/*     */   public Part addPart(String paramString1, String paramString2, String paramString3) {
/* 245 */     Debug.assertion((this.thePart == null), "FaultMessage can have only one part.");
/* 246 */     this.thePart = this.ref.addPart(paramString1, paramString2, paramString3);
/* 247 */     return this.thePart;
/*     */   }
/*     */ 
/*     */   
/* 251 */   public String toString() { return "FaultMessage[" + this.ref.toString() + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeXmlIds(SOAPElement paramSOAPElement, SerializationContext paramSerializationContext) throws SOAPException {
/*     */     try {
/* 258 */       XMLNodeOutputStream xMLNodeOutputStream = new XMLNodeOutputStream((XMLNode)paramSOAPElement);
/* 259 */       paramSerializationContext.setQualifyElements(true);
/* 260 */       RuntimeUtils.writeTrailingBlocks(xMLNodeOutputStream, paramSerializationContext);
/* 261 */       xMLNodeOutputStream.flush();
/* 262 */     } catch (XMLStreamException xMLStreamException) {
/* 263 */       throw new SOAPException(xMLStreamException);
/* 264 */     } catch (SerializationException serializationException) {
/* 265 */       throw new SOAPException(serializationException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\FaultMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */