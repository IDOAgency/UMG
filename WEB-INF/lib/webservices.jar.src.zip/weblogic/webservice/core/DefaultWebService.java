/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.handler.HandlerRegistry;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.utils.collections.Pool;
/*     */ import weblogic.utils.collections.StackPool;
/*     */ import weblogic.webservice.HandlerChain;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.context.WebServiceContextImpl;
/*     */ import weblogic.webservice.core.encoding.DefaultRegistry;
/*     */ import weblogic.webservice.monitoring.WebServiceStats;
/*     */ import weblogic.xml.security.specs.SecurityDD;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultWebService
/*     */   implements WebService
/*     */ {
/*     */   private static final String DEFAULT_PROTOCOL = "http";
/*     */   private static final boolean debug = false;
/*     */   private static final String DEFAULT_OPERATION = "_default";
/*     */   private String targetNamespace;
/*     */   private String name;
/*     */   private TypeMappingRegistry typeMappingRegistry;
/*     */   private HashMap ports;
/*     */   private XMLNode types;
/*     */   private SecurityDD security;
/*     */   private String protocol;
/*     */   private int responseBufferSize;
/*     */   private boolean exposeHomePage;
/*     */   private boolean exposeWSDL;
/*     */   private boolean handleAllActors;
/*     */   private WebServiceContext context;
/*     */   private boolean localContext;
/*     */   private HandlerInfo[] handlerInfos;
/*     */   private WebServiceStats mStats;
/*     */   private final Pool handlerChainPool;
/*     */   
/*     */   public DefaultWebService(String paramString1, String paramString2) {
/*  65 */     this.ports = new HashMap();
/*     */ 
/*     */ 
/*     */     
/*  69 */     this.responseBufferSize = -1;
/*  70 */     this.exposeHomePage = true;
/*  71 */     this.exposeWSDL = true;
/*  72 */     this.handleAllActors = true;
/*     */     
/*  74 */     this.localContext = false;
/*     */     
/*  76 */     this.mStats = null;
/*     */ 
/*     */     
/*  79 */     this.handlerChainPool = new StackPool(32);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.targetNamespace = paramString1;
/*  86 */     this.name = paramString2;
/*  87 */     this.protocol = "http";
/*     */     try {
/*  89 */       this.typeMappingRegistry = new DefaultRegistry();
/*  90 */     } catch (JAXRPCException jAXRPCException) {
/*  91 */       throw new AssertionError(jAXRPCException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  99 */     Iterator iterator = this.ports.values().iterator();
/* 100 */     while (iterator.hasNext()) {
/* 101 */       Port port = (Port)iterator.next();
/* 102 */       port.destroy();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void setTypes(XMLNode paramXMLNode) { this.types = paramXMLNode; }
/*     */ 
/*     */   
/* 111 */   public XMLNode getTypes() { return this.types; }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */   
/* 119 */   public String getProtocol() { return this.protocol; }
/*     */ 
/*     */ 
/*     */   
/* 123 */   public String getTargetNamespace() { return this.targetNamespace; }
/*     */ 
/*     */ 
/*     */   
/* 127 */   public void setProtocol(String paramString) { this.protocol = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 131 */   public void setName(String paramString) { this.name = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 135 */   public void setResponseBufferSize(int paramInt) { this.responseBufferSize = paramInt; }
/*     */ 
/*     */ 
/*     */   
/* 139 */   public int getResponseBufferSize() { return this.responseBufferSize; }
/*     */ 
/*     */ 
/*     */   
/* 143 */   public boolean getExposeWSDL() { return this.exposeWSDL; }
/*     */ 
/*     */ 
/*     */   
/* 147 */   public void setExposeWSDL(boolean paramBoolean) { this.exposeWSDL = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 151 */   public boolean getExposeHomePage() { return this.exposeHomePage; }
/*     */ 
/*     */ 
/*     */   
/* 155 */   public void setExposeHomePage(boolean paramBoolean) { this.exposeHomePage = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 159 */   public boolean getHandleAllActors() { return this.handleAllActors; }
/*     */ 
/*     */ 
/*     */   
/* 163 */   public void setHandleAllActors(boolean paramBoolean) { this.handleAllActors = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 167 */   public void setTargetNamespace(String paramString) { this.targetNamespace = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 171 */   public TypeMappingRegistry getTypeMappingRegistry() { return this.typeMappingRegistry; }
/*     */ 
/*     */ 
/*     */   
/* 175 */   public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) { this.typeMappingRegistry = paramTypeMappingRegistry; }
/*     */ 
/*     */ 
/*     */   
/* 179 */   public Port addPort(String paramString) { return addPort(paramString, (HandlerRegistry)null); }
/*     */ 
/*     */   
/*     */   public Port addPort(String paramString, HandlerRegistry paramHandlerRegistry) {
/* 183 */     Port port = getPort(paramString);
/*     */     
/* 185 */     if (port == null) {
/* 186 */       port = new DefaultPort(this);
/* 187 */       port.setName(paramString);
/* 188 */       port.setTypeMappingRegistry(this.typeMappingRegistry);
/* 189 */       this.ports.put(paramString, port);
/*     */     } 
/*     */     
/* 192 */     port.setHandlerRegistry(paramHandlerRegistry);
/* 193 */     return port;
/*     */   }
/*     */   
/*     */   public Port getPortForType(String paramString) {
/* 197 */     for (Iterator iterator = getPorts(); iterator.hasNext(); ) {
/* 198 */       Port port = (Port)iterator.next();
/*     */       
/* 200 */       if (paramString.equals(port.getTypeName())) {
/* 201 */         return port;
/*     */       }
/*     */     } 
/*     */     
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 209 */   public Port getPort(String paramString) { return (Port)this.ports.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 213 */   public Iterator getPorts() { return this.ports.values().iterator(); }
/*     */ 
/*     */ 
/*     */   
/* 217 */   public Port getPort(String paramString1, String paramString2) { return getPort(paramString1 + ":" + paramString2); }
/*     */ 
/*     */ 
/*     */   
/*     */   public Operation findOperation(SOAPElement paramSOAPElement) {
/* 222 */     for (Iterator iterator = getPorts(); iterator.hasNext(); ) {
/* 223 */       Port port = (Port)iterator.next();
/* 224 */       Operation operation = port.findOperation(paramSOAPElement);
/*     */       
/* 226 */       if (operation != null) {
/* 227 */         return operation;
/*     */       }
/*     */     } 
/*     */     
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Operation findOperation(String paramString) {
/* 236 */     for (Iterator iterator = getPorts(); iterator.hasNext(); ) {
/* 237 */       Port port = (Port)iterator.next();
/* 238 */       Operation operation = port.getOperation(paramString);
/*     */       
/* 240 */       if (operation != null) {
/* 241 */         return operation;
/*     */       }
/*     */     } 
/*     */     
/* 245 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 249 */   public SecurityDD getSecurity() { return this.security; }
/*     */ 
/*     */ 
/*     */   
/* 253 */   public void setSecurity(SecurityDD paramSecurityDD) { this.security = paramSecurityDD; }
/*     */ 
/*     */   
/*     */   public HandlerChain getServerHandlerChain() {
/* 257 */     if (this.handlerInfos == null) return null;
/*     */ 
/*     */     
/* 260 */     HandlerChain handlerChain = (HandlerChain)this.handlerChainPool.remove();
/*     */     
/* 262 */     if (handlerChain == null) {
/* 263 */       handlerChain = new HandlerChainImpl(this.handlerInfos, (this.mStats == null) ? null : this.mStats.getHandlerStats());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 268 */     return handlerChain;
/*     */   }
/*     */ 
/*     */   
/* 272 */   public void setHandlerInfos(HandlerInfo[] paramArrayOfHandlerInfo) { this.handlerInfos = paramArrayOfHandlerInfo; }
/*     */ 
/*     */ 
/*     */   
/* 276 */   public HandlerInfo[] getHandlerInfos() { return this.handlerInfos; }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setMessageProps(WLMessageContext paramWLMessageContext, Map paramMap) {
/* 281 */     Iterator iterator = paramMap.keySet().iterator();
/*     */     
/* 283 */     while (iterator.hasNext()) {
/* 284 */       String str = (String)iterator.next();
/*     */       
/* 286 */       paramWLMessageContext.setProperty(str, paramMap.get(str));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 291 */   public WebServiceStats getStats() { return this.mStats; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 296 */   public void setStats(WebServiceStats paramWebServiceStats) { this.mStats = paramWebServiceStats; }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceContext context() {
/* 301 */     if (this.context == null) {
/* 302 */       this.context = new WebServiceContextImpl();
/* 303 */       this.localContext = true;
/*     */     } 
/*     */     
/* 306 */     return this.context;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceContext joinContext() {
/* 312 */     if (this.localContext) {
/* 313 */       throw new IllegalStateException("active local context already available. Can not call context() before joinContext() ");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 318 */     this.context = WebServiceContext.currentContext();
/* 319 */     return this.context;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 323 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 325 */     stringBuffer.append("WebService[\n");
/* 326 */     stringBuffer.append("name=").append(this.name).append(",\n");
/* 327 */     stringBuffer.append("targetNamespace=").append(this.targetNamespace).append(",\n");
/*     */     
/* 329 */     stringBuffer.append("protocol=").append(this.protocol).append(",\n");
/*     */     
/* 331 */     if (this.types != null) {
/* 332 */       stringBuffer.append("\ntypes[\n");
/* 333 */       stringBuffer.append(this.types);
/* 334 */       stringBuffer.append("]\n");
/*     */     } 
/*     */     
/* 337 */     for (String str : this.ports.keySet())
/*     */     {
/* 339 */       stringBuffer.append(getPort(str));
/*     */     }
/*     */     
/* 342 */     stringBuffer.append("]\n");
/*     */     
/* 344 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultWebService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */