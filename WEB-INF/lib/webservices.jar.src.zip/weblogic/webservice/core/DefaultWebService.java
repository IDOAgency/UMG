package weblogic.webservice.core;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;
import javax.xml.soap.SOAPElement;
import weblogic.utils.AssertionError;
import weblogic.utils.collections.Pool;
import weblogic.utils.collections.StackPool;
import weblogic.webservice.HandlerChain;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebService;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.context.WebServiceContextImpl;
import weblogic.webservice.core.encoding.DefaultRegistry;
import weblogic.webservice.monitoring.WebServiceStats;
import weblogic.xml.security.specs.SecurityDD;
import weblogic.xml.xmlnode.XMLNode;

public class DefaultWebService implements WebService {
  private static final String DEFAULT_PROTOCOL = "http";
  
  private static final boolean debug = false;
  
  private static final String DEFAULT_OPERATION = "_default";
  
  private String targetNamespace;
  
  private String name;
  
  private TypeMappingRegistry typeMappingRegistry;
  
  private HashMap ports;
  
  private XMLNode types;
  
  private SecurityDD security;
  
  private String protocol;
  
  private int responseBufferSize;
  
  private boolean exposeHomePage;
  
  private boolean exposeWSDL;
  
  private boolean handleAllActors;
  
  private WebServiceContext context;
  
  private boolean localContext;
  
  private HandlerInfo[] handlerInfos;
  
  private WebServiceStats mStats;
  
  private final Pool handlerChainPool;
  
  public DefaultWebService(String paramString1, String paramString2) {
    this.ports = new HashMap();
    this.responseBufferSize = -1;
    this.exposeHomePage = true;
    this.exposeWSDL = true;
    this.handleAllActors = true;
    this.localContext = false;
    this.mStats = null;
    this.handlerChainPool = new StackPool(32);
    this.targetNamespace = paramString1;
    this.name = paramString2;
    this.protocol = "http";
    try {
      this.typeMappingRegistry = new DefaultRegistry();
    } catch (JAXRPCException jAXRPCException) {
      throw new AssertionError(jAXRPCException);
    } 
  }
  
  public void destroy() {
    Iterator iterator = this.ports.values().iterator();
    while (iterator.hasNext()) {
      Port port = (Port)iterator.next();
      port.destroy();
    } 
  }
  
  public void setTypes(XMLNode paramXMLNode) { this.types = paramXMLNode; }
  
  public XMLNode getTypes() { return this.types; }
  
  public String getName() { return this.name; }
  
  public String getProtocol() { return this.protocol; }
  
  public String getTargetNamespace() { return this.targetNamespace; }
  
  public void setProtocol(String paramString) { this.protocol = paramString; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public void setResponseBufferSize(int paramInt) { this.responseBufferSize = paramInt; }
  
  public int getResponseBufferSize() { return this.responseBufferSize; }
  
  public boolean getExposeWSDL() { return this.exposeWSDL; }
  
  public void setExposeWSDL(boolean paramBoolean) { this.exposeWSDL = paramBoolean; }
  
  public boolean getExposeHomePage() { return this.exposeHomePage; }
  
  public void setExposeHomePage(boolean paramBoolean) { this.exposeHomePage = paramBoolean; }
  
  public boolean getHandleAllActors() { return this.handleAllActors; }
  
  public void setHandleAllActors(boolean paramBoolean) { this.handleAllActors = paramBoolean; }
  
  public void setTargetNamespace(String paramString) { this.targetNamespace = paramString; }
  
  public TypeMappingRegistry getTypeMappingRegistry() { return this.typeMappingRegistry; }
  
  public void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry) { this.typeMappingRegistry = paramTypeMappingRegistry; }
  
  public Port addPort(String paramString) { return addPort(paramString, (HandlerRegistry)null); }
  
  public Port addPort(String paramString, HandlerRegistry paramHandlerRegistry) {
    Port port = getPort(paramString);
    if (port == null) {
      port = new DefaultPort(this);
      port.setName(paramString);
      port.setTypeMappingRegistry(this.typeMappingRegistry);
      this.ports.put(paramString, port);
    } 
    port.setHandlerRegistry(paramHandlerRegistry);
    return port;
  }
  
  public Port getPortForType(String paramString) {
    for (Iterator iterator = getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      if (paramString.equals(port.getTypeName()))
        return port; 
    } 
    return null;
  }
  
  public Port getPort(String paramString) { return (Port)this.ports.get(paramString); }
  
  public Iterator getPorts() { return this.ports.values().iterator(); }
  
  public Port getPort(String paramString1, String paramString2) { return getPort(paramString1 + ":" + paramString2); }
  
  public Operation findOperation(SOAPElement paramSOAPElement) {
    for (Iterator iterator = getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      Operation operation = port.findOperation(paramSOAPElement);
      if (operation != null)
        return operation; 
    } 
    return null;
  }
  
  public Operation findOperation(String paramString) {
    for (Iterator iterator = getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      Operation operation = port.getOperation(paramString);
      if (operation != null)
        return operation; 
    } 
    return null;
  }
  
  public SecurityDD getSecurity() { return this.security; }
  
  public void setSecurity(SecurityDD paramSecurityDD) { this.security = paramSecurityDD; }
  
  public HandlerChain getServerHandlerChain() {
    if (this.handlerInfos == null)
      return null; 
    HandlerChain handlerChain = (HandlerChain)this.handlerChainPool.remove();
    if (handlerChain == null)
      handlerChain = new HandlerChainImpl(this.handlerInfos, (this.mStats == null) ? null : this.mStats.getHandlerStats()); 
    return handlerChain;
  }
  
  public void setHandlerInfos(HandlerInfo[] paramArrayOfHandlerInfo) { this.handlerInfos = paramArrayOfHandlerInfo; }
  
  public HandlerInfo[] getHandlerInfos() { return this.handlerInfos; }
  
  private void setMessageProps(WLMessageContext paramWLMessageContext, Map paramMap) {
    Iterator iterator = paramMap.keySet().iterator();
    while (iterator.hasNext()) {
      String str = (String)iterator.next();
      paramWLMessageContext.setProperty(str, paramMap.get(str));
    } 
  }
  
  public WebServiceStats getStats() { return this.mStats; }
  
  public void setStats(WebServiceStats paramWebServiceStats) { this.mStats = paramWebServiceStats; }
  
  public WebServiceContext context() {
    if (this.context == null) {
      this.context = new WebServiceContextImpl();
      this.localContext = true;
    } 
    return this.context;
  }
  
  public WebServiceContext joinContext() {
    if (this.localContext)
      throw new IllegalStateException("active local context already available. Can not call context() before joinContext() "); 
    this.context = WebServiceContext.currentContext();
    return this.context;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("WebService[\n");
    stringBuffer.append("name=").append(this.name).append(",\n");
    stringBuffer.append("targetNamespace=").append(this.targetNamespace).append(",\n");
    stringBuffer.append("protocol=").append(this.protocol).append(",\n");
    if (this.types != null) {
      stringBuffer.append("\ntypes[\n");
      stringBuffer.append(this.types);
      stringBuffer.append("]\n");
    } 
    for (String str : this.ports.keySet())
      stringBuffer.append(getPort(str)); 
    stringBuffer.append("]\n");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\DefaultWebService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */