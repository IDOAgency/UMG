/*     */ package weblogic.webservice.core;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.util.ExceptionUtil;
/*     */ import weblogic.xml.schema.binding.internal.NameUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PortMapper
/*     */ {
/*     */   public void mapInterfaceToPort(Class paramClass, Port paramPort) throws JAXRPCException {
/*  32 */     Method[] arrayOfMethod = paramClass.getDeclaredMethods();
/*     */     
/*  34 */     for (byte b = 0; b < arrayOfMethod.length; b++) {
/*  35 */       Method method = arrayOfMethod[b];
/*  36 */       Operation operation = getOperation(paramPort, method.getName());
/*     */       
/*  38 */       if (operation == null) {
/*  39 */         if (!method.getName().startsWith("end") && !method.getName().startsWith("start"))
/*     */         {
/*     */ 
/*     */           
/*  43 */           throw new JAXRPCException("unable to find operation[" + method + "] in the given port:" + paramPort);
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/*  48 */         mapException(method, operation);
/*     */         
/*  50 */         if (operation.isRpcStyle())
/*  51 */           mapMethodToOperation(method, operation); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Operation getOperation(Port paramPort, String paramString) {
/*  57 */     Operation operation = paramPort.getOperation(paramString);
/*     */     
/*  59 */     if (operation != null) {
/*  60 */       return operation;
/*     */     }
/*     */     
/*  63 */     for (Iterator iterator = paramPort.getOperations(); iterator.hasNext(); ) {
/*  64 */       operation = (Operation)iterator.next();
/*     */       
/*  66 */       if (paramString.equals(NameUtil.getJAXRPCMethodName(operation.getName()))) {
/*  67 */         return operation;
/*     */       }
/*     */     } 
/*     */     
/*  71 */     return null;
/*     */   }
/*     */   
/*     */   private void mapException(Method paramMethod, Operation paramOperation) {
/*  75 */     for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
/*  76 */       Message message = (Message)iterator.next();
/*  77 */       Part part = (Part)message.getParts().next();
/*     */       
/*  79 */       if (Exception.class.isAssignableFrom(part.getJavaType()))
/*     */         continue; 
/*  81 */       Class[] arrayOfClass = paramMethod.getExceptionTypes();
/*  82 */       for (byte b = 0; b < arrayOfClass.length; b++) {
/*  83 */         Class clazz = ExceptionUtil.getSingleProperty(arrayOfClass[b]);
/*     */         
/*  85 */         if (clazz != null && part.getJavaType().equals(clazz))
/*     */         {
/*     */           
/*  88 */           if (arrayOfClass.length > 1) {
/*  89 */             if (arrayOfClass[b].getName().endsWith(message.getName())) {
/*  90 */               part.setJavaType(arrayOfClass[b]);
/*     */               break;
/*     */             } 
/*     */           } else {
/*  94 */             part.setJavaType(arrayOfClass[b]);
/*     */             break;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void mapMethodToOperation(Method paramMethod, Operation paramOperation) {
/* 104 */     Class[] arrayOfClass = paramMethod.getParameterTypes();
/* 105 */     byte b = 0;
/*     */     
/*     */     Iterator iterator;
/*     */     
/* 109 */     for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 110 */       Part part = (Part)iterator.next();
/*     */       
/* 112 */       if (b >= arrayOfClass.length) {
/* 113 */         throw new JAXRPCException("number of params does not match for:" + paramMethod);
/*     */       }
/*     */ 
/*     */       
/* 117 */       Class clazz = arrayOfClass[b];
/* 118 */       b++;
/*     */       
/* 120 */       if (clazz == part.getJavaType()) {
/*     */         continue;
/*     */       }
/*     */       
/* 124 */       mapClassToPart(clazz, part);
/*     */     } 
/*     */     
/* 127 */     for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/* 128 */       Part part = (Part)iterator.next();
/*     */       
/* 130 */       if (part.getMode() == Part.Mode.RETURN) {
/* 131 */         mapClassToPart(paramMethod.getReturnType(), part);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void mapClassToPart(Class paramClass, Part paramPart) { paramPart.setJavaType(getTypeFromHolder(paramClass)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class getTypeFromHolder(Class paramClass) {
/* 161 */     if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass)) {
/*     */       try {
/* 163 */         Field field = paramClass.getField("value");
/* 164 */         paramClass = field.getType();
/* 165 */       } catch (NoSuchFieldException noSuchFieldException) {
/* 166 */         throw new JAXRPCException("no 'value' field defined in the holder class:" + paramClass, noSuchFieldException);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 171 */     return paramClass;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\PortMapper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */