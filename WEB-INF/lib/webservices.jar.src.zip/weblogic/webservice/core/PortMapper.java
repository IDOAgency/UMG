package weblogic.webservice.core;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import javax.xml.rpc.JAXRPCException;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.util.ExceptionUtil;
import weblogic.xml.schema.binding.internal.NameUtil;

public class PortMapper {
  public void mapInterfaceToPort(Class paramClass, Port paramPort) throws JAXRPCException {
    Method[] arrayOfMethod = paramClass.getDeclaredMethods();
    for (byte b = 0; b < arrayOfMethod.length; b++) {
      Method method = arrayOfMethod[b];
      Operation operation = getOperation(paramPort, method.getName());
      if (operation == null) {
        if (!method.getName().startsWith("end") && !method.getName().startsWith("start"))
          throw new JAXRPCException("unable to find operation[" + method + "] in the given port:" + paramPort); 
      } else {
        mapException(method, operation);
        if (operation.isRpcStyle())
          mapMethodToOperation(method, operation); 
      } 
    } 
  }
  
  private Operation getOperation(Port paramPort, String paramString) {
    Operation operation = paramPort.getOperation(paramString);
    if (operation != null)
      return operation; 
    for (Iterator iterator = paramPort.getOperations(); iterator.hasNext(); ) {
      operation = (Operation)iterator.next();
      if (paramString.equals(NameUtil.getJAXRPCMethodName(operation.getName())))
        return operation; 
    } 
    return null;
  }
  
  private void mapException(Method paramMethod, Operation paramOperation) {
    for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
      Message message = (Message)iterator.next();
      Part part = (Part)message.getParts().next();
      if (Exception.class.isAssignableFrom(part.getJavaType()))
        continue; 
      Class[] arrayOfClass = paramMethod.getExceptionTypes();
      for (byte b = 0; b < arrayOfClass.length; b++) {
        Class clazz = ExceptionUtil.getSingleProperty(arrayOfClass[b]);
        if (clazz != null && part.getJavaType().equals(clazz))
          if (arrayOfClass.length > 1) {
            if (arrayOfClass[b].getName().endsWith(message.getName())) {
              part.setJavaType(arrayOfClass[b]);
              break;
            } 
          } else {
            part.setJavaType(arrayOfClass[b]);
            break;
          }  
      } 
    } 
  }
  
  public void mapMethodToOperation(Method paramMethod, Operation paramOperation) {
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    byte b = 0;
    Iterator iterator;
    for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (b >= arrayOfClass.length)
        throw new JAXRPCException("number of params does not match for:" + paramMethod); 
      Class clazz = arrayOfClass[b];
      b++;
      if (clazz == part.getJavaType())
        continue; 
      mapClassToPart(clazz, part);
    } 
    for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.RETURN)
        mapClassToPart(paramMethod.getReturnType(), part); 
    } 
  }
  
  public void mapClassToPart(Class paramClass, Part paramPart) { paramPart.setJavaType(getTypeFromHolder(paramClass)); }
  
  private Class getTypeFromHolder(Class paramClass) {
    if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass))
      try {
        Field field = paramClass.getField("value");
        paramClass = field.getType();
      } catch (NoSuchFieldException noSuchFieldException) {
        throw new JAXRPCException("no 'value' field defined in the holder class:" + paramClass, noSuchFieldException);
      }  
    return paramClass;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\core\PortMapper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */