package weblogic.webservice.util.script;

abstract class Tag {
  private String content;
  
  public String getContent() { return this.content; }
  
  public void setContent(String paramString) { this.content = paramString; }
  
  public abstract String getJavaScript();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Tag.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */