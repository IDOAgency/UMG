package weblogic.webservice.util.script;

import java.util.StringTokenizer;

class Include extends Tag {
  private ResourceProvider provider;
  
  public Include(ResourceProvider paramResourceProvider) { this.provider = paramResourceProvider; }
  
  public String getJavaScript() throws ScriptException {
    String str1 = getContent();
    str1 = str1.substring(3, str1.length() - 2);
    StringTokenizer stringTokenizer = new StringTokenizer(str1);
    String str2 = null;
    if (stringTokenizer.hasMoreTokens()) {
      str2 = stringTokenizer.nextToken();
      if ("include".equals(str2))
        if (stringTokenizer.hasMoreTokens()) {
          str2 = stringTokenizer.nextToken();
          if (str2.startsWith("file=")) {
            str2 = str2.substring("file=".length(), str2.length());
            if (str2.charAt(0) == '"')
              str2 = str2.substring(1, str2.length()); 
            if (str2.charAt(str2.length() - 1) == '"')
              str2 = str2.substring(0, str2.length() - 1); 
            return (new LightJspParser(this.provider.getResource(str2), this.provider)).parse();
          } 
        }  
    } 
    throw new ScriptException("failed to parse: usage <%@ include file=\"filename\" %>");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Include.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */