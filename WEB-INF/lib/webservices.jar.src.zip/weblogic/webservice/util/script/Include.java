/*    */ package weblogic.webservice.util.script;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ class Include
/*    */   extends Tag
/*    */ {
/*    */   private ResourceProvider provider;
/*    */   
/* 10 */   public Include(ResourceProvider paramResourceProvider) { this.provider = paramResourceProvider; }
/*    */ 
/*    */   
/*    */   public String getJavaScript() throws ScriptException {
/* 14 */     String str1 = getContent();
/* 15 */     str1 = str1.substring(3, str1.length() - 2);
/*    */     
/* 17 */     StringTokenizer stringTokenizer = new StringTokenizer(str1);
/* 18 */     String str2 = null;
/*    */     
/* 20 */     if (stringTokenizer.hasMoreTokens()) {
/* 21 */       str2 = stringTokenizer.nextToken();
/*    */       
/* 23 */       if ("include".equals(str2))
/*    */       {
/* 25 */         if (stringTokenizer.hasMoreTokens()) {
/* 26 */           str2 = stringTokenizer.nextToken();
/*    */           
/* 28 */           if (str2.startsWith("file=")) {
/* 29 */             str2 = str2.substring("file=".length(), str2.length());
/*    */             
/* 31 */             if (str2.charAt(0) == '"') {
/* 32 */               str2 = str2.substring(1, str2.length());
/*    */             }
/* 34 */             if (str2.charAt(str2.length() - 1) == '"') {
/* 35 */               str2 = str2.substring(0, str2.length() - 1);
/*    */             }
/*    */             
/* 38 */             return (new LightJspParser(this.provider.getResource(str2), this.provider)).parse();
/*    */           } 
/*    */         } 
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 45 */     throw new ScriptException("failed to parse: usage <%@ include file=\"filename\" %>");
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Include.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */