package weblogic.webservice.util.script;

class Comment extends Tag {
  public String getJavaScript() { return ""; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Comment.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */