package weblogic.webservice.util.script;

import java.io.PrintStream;

public class Output {
  private PrintStream output;
  
  public Output(PrintStream paramPrintStream) { this.output = paramPrintStream; }
  
  public void print(Object paramObject) { this.output.print((paramObject == null) ? "null" : paramObject.toString()); }
  
  public void println(Object paramObject) { this.output.println((paramObject == null) ? "null" : paramObject.toString()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Output.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */