package weblogic.webservice.util.script;

import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.util.HashMap;
import java.util.StringTokenizer;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ImporterTopLevel;
import org.mozilla.javascript.JavaScriptException;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.mozilla.javascript.tools.debugger.Main;

public class GenBase implements ResourceProvider {
  private HashMap vars;
  
  private String cgData;
  
  private String filename;
  
  private boolean debug;
  
  private static final boolean verbose = Boolean.getBoolean("weblogic.webservice.util.script.verbose");
  
  public GenBase(String paramString, boolean paramBoolean) throws IOException, ScriptException {
    this.vars = new HashMap();
    this.debug = true;
    this.debug = paramBoolean;
    this.filename = paramString;
    this.cgData = getResource(paramString);
    setOutput(System.out);
  }
  
  public void setOutput(PrintStream paramPrintStream) { setVar("out", new Output(paramPrintStream)); }
  
  public String getResource(String paramString) throws ScriptException {
    URL uRL = getClass().getResource(paramString);
    if (uRL == null)
      throw new ScriptException("unable to find resource:" + paramString); 
    return Util.fileToString(uRL.toString());
  }
  
  public void setVar(String paramString, Object paramObject) { this.vars.put(paramString, paramObject); }
  
  public Object getVar(String paramString) { return this.vars.get(paramString); }
  
  public void removeVar(String paramString) { this.vars.remove(paramString); }
  
  public void gen() throws ScriptException {
    try {
      generate();
    } catch (JavaScriptException javaScriptException) {
      printDebug(javaScriptException);
      throw new ScriptException("java script error:");
    } catch (RuntimeException runtimeException) {
      printDebug(runtimeException);
      throw runtimeException;
    } 
  }
  
  private void printDebug(Exception paramException) {
    if (verbose) {
      System.out.println("************ javascript ****************");
      printJavaScript(this.cgData);
      System.out.println("************* error ********************");
      paramException.printStackTrace();
      System.out.println("****************************************");
    } else {
      System.out.println("set system property 'weblogic.webservice.util.script.verbose=true' for more details");
    } 
  }
  
  private void printJavaScript(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\n");
    for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
      System.out.print(b + " :  ");
      System.out.println(stringTokenizer.nextToken());
    } 
  }
  
  private void generate() throws ScriptException {
    this.cgData = (new LightJspParser(this.cgData, this)).parse();
    if (this.debug) {
      Util.stringToFile(this.filename + ".js", this.cgData);
      execDebug();
    } else {
      exec();
    } 
  }
  
  public void scopeCreated(ScriptableObject paramScriptableObject) {
    for (String str : this.vars.keySet()) {
      Object object = this.vars.get(str);
      Scriptable scriptable = Context.toObject(object, paramScriptableObject);
      ((ImporterTopLevel)paramScriptableObject).defineProperty(str, scriptable, 2);
    } 
  }
  
  private void execDebug() throws ScriptException {
    String[] arrayOfString = { this.filename + ".js" };
    Main.main(arrayOfString);
  }
  
  private void addGlobalVar(Scriptable paramScriptable) {
    for (String str : this.vars.keySet()) {
      Object object = this.vars.get(str);
      Scriptable scriptable = Context.toObject(object, paramScriptable);
      paramScriptable.put(str, paramScriptable, scriptable);
    } 
  }
  
  private void exec() throws ScriptException {
    Context context = Context.enter();
    Scriptable scriptable = context.initStandardObjects(null);
    addGlobalVar(scriptable);
    Object object = context.evaluateString(scriptable, this.cgData, "<cg>", 1, null);
    Context.exit();
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    if (paramArrayOfString.length != 1) {
      System.out.println("usage: java GenBase <filename.cg>");
    } else {
      GenBase genBase = new GenBase(paramArrayOfString[0], true);
      genBase.gen();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\GenBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */