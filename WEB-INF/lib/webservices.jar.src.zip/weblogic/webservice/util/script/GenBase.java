/*     */ package weblogic.webservice.util.script;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.StringTokenizer;
/*     */ import org.mozilla.javascript.Context;
/*     */ import org.mozilla.javascript.ImporterTopLevel;
/*     */ import org.mozilla.javascript.JavaScriptException;
/*     */ import org.mozilla.javascript.Scriptable;
/*     */ import org.mozilla.javascript.ScriptableObject;
/*     */ import org.mozilla.javascript.tools.debugger.Main;
/*     */ 
/*     */ public class GenBase
/*     */   implements ResourceProvider {
/*     */   private HashMap vars;
/*     */   private String cgData;
/*     */   private String filename;
/*     */   private boolean debug;
/*  21 */   private static final boolean verbose = Boolean.getBoolean("weblogic.webservice.util.script.verbose");
/*     */ 
/*     */   
/*     */   public GenBase(String paramString, boolean paramBoolean) throws IOException, ScriptException {
/*     */     this.vars = new HashMap();
/*     */     this.debug = true;
/*  27 */     this.debug = paramBoolean;
/*  28 */     this.filename = paramString;
/*  29 */     this.cgData = getResource(paramString);
/*  30 */     setOutput(System.out);
/*     */   }
/*     */ 
/*     */   
/*  34 */   public void setOutput(PrintStream paramPrintStream) { setVar("out", new Output(paramPrintStream)); }
/*     */ 
/*     */   
/*     */   public String getResource(String paramString) throws ScriptException {
/*  38 */     URL uRL = getClass().getResource(paramString);
/*     */     
/*  40 */     if (uRL == null) {
/*  41 */       throw new ScriptException("unable to find resource:" + paramString);
/*     */     }
/*     */     
/*  44 */     return Util.fileToString(uRL.toString());
/*     */   }
/*     */ 
/*     */   
/*  48 */   public void setVar(String paramString, Object paramObject) { this.vars.put(paramString, paramObject); }
/*     */ 
/*     */ 
/*     */   
/*  52 */   public Object getVar(String paramString) { return this.vars.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  56 */   public void removeVar(String paramString) { this.vars.remove(paramString); }
/*     */ 
/*     */   
/*     */   public void gen() throws ScriptException {
/*     */     try {
/*  61 */       generate();
/*  62 */     } catch (JavaScriptException javaScriptException) {
/*  63 */       printDebug(javaScriptException);
/*  64 */       throw new ScriptException("java script error:");
/*  65 */     } catch (RuntimeException runtimeException) {
/*  66 */       printDebug(runtimeException);
/*  67 */       throw runtimeException;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void printDebug(Exception paramException) {
/*  73 */     if (verbose) {
/*  74 */       System.out.println("************ javascript ****************");
/*  75 */       printJavaScript(this.cgData);
/*  76 */       System.out.println("************* error ********************");
/*  77 */       paramException.printStackTrace();
/*  78 */       System.out.println("****************************************");
/*     */     } else {
/*  80 */       System.out.println("set system property 'weblogic.webservice.util.script.verbose=true' for more details");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void printJavaScript(String paramString) {
/*  86 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\n");
/*     */     
/*  88 */     for (byte b = 0; stringTokenizer.hasMoreTokens(); b++) {
/*  89 */       System.out.print(b + " :  ");
/*  90 */       System.out.println(stringTokenizer.nextToken());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void generate() throws ScriptException {
/*  97 */     this.cgData = (new LightJspParser(this.cgData, this)).parse();
/*     */     
/*  99 */     if (this.debug) {
/* 100 */       Util.stringToFile(this.filename + ".js", this.cgData);
/* 101 */       execDebug();
/*     */     } else {
/* 103 */       exec();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void scopeCreated(ScriptableObject paramScriptableObject) {
/* 108 */     for (String str : this.vars.keySet()) {
/*     */       
/* 110 */       Object object = this.vars.get(str);
/* 111 */       Scriptable scriptable = Context.toObject(object, paramScriptableObject);
/* 112 */       ((ImporterTopLevel)paramScriptableObject).defineProperty(str, scriptable, 2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void execDebug() throws ScriptException {
/* 119 */     String[] arrayOfString = { this.filename + ".js" };
/* 120 */     Main.main(arrayOfString);
/*     */   }
/*     */   
/*     */   private void addGlobalVar(Scriptable paramScriptable) {
/* 124 */     for (String str : this.vars.keySet()) {
/*     */       
/* 126 */       Object object = this.vars.get(str);
/* 127 */       Scriptable scriptable = Context.toObject(object, paramScriptable);
/* 128 */       paramScriptable.put(str, paramScriptable, scriptable);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void exec() throws ScriptException {
/* 133 */     Context context = Context.enter();
/* 134 */     Scriptable scriptable = context.initStandardObjects(null);
/* 135 */     addGlobalVar(scriptable);
/* 136 */     Object object = context.evaluateString(scriptable, this.cgData, "<cg>", 1, null);
/* 137 */     Context.exit();
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 141 */     if (paramArrayOfString.length != 1) {
/* 142 */       System.out.println("usage: java GenBase <filename.cg>");
/*     */     } else {
/* 144 */       GenBase genBase = new GenBase(paramArrayOfString[0], true);
/* 145 */       genBase.gen();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\GenBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */