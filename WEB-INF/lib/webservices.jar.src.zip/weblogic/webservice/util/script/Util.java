package weblogic.webservice.util.script;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import weblogic.webservice.WebServiceLogger;

public class Util {
  public static String fileToString(String paramString) throws ScriptException {
    try {
      InputStream inputStream = (new URL(paramString)).openConnection().getInputStream();
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      int i;
      while ((i = inputStream.read()) != -1)
        byteArrayOutputStream.write(i); 
      inputStream.close();
      return new String(byteArrayOutputStream.toByteArray(), "UTF-8");
    } catch (IOException iOException) {
      String str = WebServiceLogger.logfileToStringIOException();
      WebServiceLogger.logStackTrace(str, iOException);
      throw new ScriptException("Failed to open include file " + paramString);
    } 
  }
  
  public static void stringToFile(String paramString1, String paramString2) throws ScriptException {
    try {
      FileOutputStream fileOutputStream = new FileOutputStream(paramString1);
      fileOutputStream.write(paramString2.getBytes());
      fileOutputStream.close();
    } catch (IOException iOException) {
      throw new ScriptException("unable to write javascript file:" + paramString1);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */