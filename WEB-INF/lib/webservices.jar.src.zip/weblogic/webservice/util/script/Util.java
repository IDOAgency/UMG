/*    */ package weblogic.webservice.util.script;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import weblogic.webservice.WebServiceLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Util
/*    */ {
/*    */   public static String fileToString(String paramString) throws ScriptException {
/*    */     try {
/* 18 */       InputStream inputStream = (new URL(paramString)).openConnection().getInputStream();
/* 19 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*    */       
/*    */       int i;
/* 22 */       while ((i = inputStream.read()) != -1) {
/* 23 */         byteArrayOutputStream.write(i);
/*    */       }
/*    */       
/* 26 */       inputStream.close();
/* 27 */       return new String(byteArrayOutputStream.toByteArray(), "UTF-8");
/* 28 */     } catch (IOException iOException) {
/* 29 */       String str = WebServiceLogger.logfileToStringIOException();
/* 30 */       WebServiceLogger.logStackTrace(str, iOException);
/* 31 */       throw new ScriptException("Failed to open include file " + paramString);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void stringToFile(String paramString1, String paramString2) throws ScriptException {
/*    */     try {
/* 38 */       FileOutputStream fileOutputStream = new FileOutputStream(paramString1);
/* 39 */       fileOutputStream.write(paramString2.getBytes());
/* 40 */       fileOutputStream.close();
/* 41 */     } catch (IOException iOException) {
/* 42 */       throw new ScriptException("unable to write javascript file:" + paramString1);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */