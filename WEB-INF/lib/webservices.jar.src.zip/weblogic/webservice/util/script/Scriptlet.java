/*   */ package weblogic.webservice.util.script;
/*   */ 
/*   */ class Scriptlet
/*   */   extends Tag {
/*   */   public String getJavaScript() {
/* 6 */     String str = getContent();
/* 7 */     return "\n" + str.substring(2, str.length() - 2);
/*   */   }
/*   */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Scriptlet.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */