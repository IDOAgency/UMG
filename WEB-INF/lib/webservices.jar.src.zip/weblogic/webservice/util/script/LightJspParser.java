/*     */ package weblogic.webservice.util.script;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LightJspParser
/*     */ {
/*     */   private String page;
/*     */   private ResourceProvider provider;
/*     */   
/*     */   public LightJspParser(String paramString, ResourceProvider paramResourceProvider) {
/*  17 */     this.page = paramString;
/*  18 */     this.provider = paramResourceProvider;
/*     */   }
/*     */   
/*     */   public String parse() throws ScriptException {
/*  22 */     Iterator iterator = getTags();
/*  23 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*  25 */     while (iterator.hasNext()) {
/*  26 */       Tag tag = (Tag)iterator.next();
/*  27 */       stringBuffer.append(tag.getJavaScript());
/*     */     } 
/*     */     
/*  30 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   private Iterator getTags() throws ScriptException {
/*  34 */     StringBuffer stringBuffer = new StringBuffer();
/*  35 */     ArrayList arrayList = new ArrayList();
/*  36 */     Iterator iterator = split(this.page);
/*     */     
/*  38 */     while (iterator.hasNext()) {
/*  39 */       String str = (String)iterator.next();
/*  40 */       Tag tag = createTag(str);
/*  41 */       tag.setContent(str);
/*  42 */       arrayList.add(tag);
/*     */     } 
/*     */     
/*  45 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   private Iterator split(String paramString) throws ScriptException {
/*  49 */     String str1 = "<%";
/*  50 */     String str2 = "%>";
/*     */     
/*  52 */     ArrayList arrayList = new ArrayList();
/*     */     
/*  54 */     int i = 0;
/*  55 */     boolean bool = false;
/*     */     
/*  57 */     while (!bool) {
/*  58 */       int j = paramString.indexOf(str1, i);
/*     */ 
/*     */       
/*  61 */       if (j == -1) {
/*  62 */         arrayList.add(paramString.substring(i, paramString.length()));
/*  63 */         bool = true;
/*     */         continue;
/*     */       } 
/*  66 */       if (i != j) {
/*  67 */         arrayList.add(paramString.substring(i, j));
/*     */       }
/*     */       
/*  70 */       i = j;
/*  71 */       int k = paramString.indexOf(str2, i);
/*     */       
/*  73 */       if (k == -1) {
/*  74 */         throw new ScriptException("unable to find the end tag " + i + " " + ((arrayList.size() == 0) ? "at start" : arrayList.get(arrayList.size() - 1)));
/*     */       }
/*     */ 
/*     */       
/*  78 */       arrayList.add(paramString.substring(i, k + 2));
/*  79 */       i = k + 2;
/*     */     } 
/*     */ 
/*     */     
/*  83 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   private Tag createTag(String paramString) {
/*  87 */     if (paramString.startsWith("<%--")) {
/*  88 */       return new Comment();
/*     */     }
/*     */     
/*  91 */     if (paramString.startsWith("<%=")) {
/*  92 */       return new Expression();
/*     */     }
/*     */     
/*  95 */     if (paramString.startsWith("<%!")) {
/*  96 */       return new Declaration();
/*     */     }
/*     */     
/*  99 */     if (paramString.startsWith("<%@")) {
/* 100 */       return new Include(this.provider);
/*     */     }
/*     */     
/* 103 */     if (paramString.startsWith("<%")) {
/* 104 */       return new Scriptlet();
/*     */     }
/*     */     
/* 107 */     return new Text();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\LightJspParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */