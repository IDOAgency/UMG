package weblogic.webservice.util.script;

class Expression extends Tag {
  public String getJavaScript() {
    String str = getContent();
    str = str.substring(3, str.length() - 2);
    return "\n out.print( " + str + " );";
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Expression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */