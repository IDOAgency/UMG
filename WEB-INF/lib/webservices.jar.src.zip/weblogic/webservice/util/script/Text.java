package weblogic.webservice.util.script;

import java.util.StringTokenizer;

class Text extends Tag {
  private String clean(String paramString) {
    if ("\n".equals(paramString))
      return "\\n"; 
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\"", true);
    StringBuffer stringBuffer = new StringBuffer();
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (str.equals("\"")) {
        stringBuffer.append("\\\"");
        continue;
      } 
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public String getJavaScript() {
    if (getContent() == null)
      return ""; 
    StringBuffer stringBuffer = new StringBuffer();
    StringTokenizer stringTokenizer = new StringTokenizer(getContent(), "\r\n\f", true);
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (str.equals("\r") || str.equals("\f"))
        continue; 
      stringBuffer.append("  out.print( \"");
      stringBuffer.append(clean(str));
      stringBuffer.append("\" );\n");
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Text.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */