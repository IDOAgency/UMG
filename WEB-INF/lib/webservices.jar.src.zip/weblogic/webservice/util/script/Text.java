/*    */ package weblogic.webservice.util.script;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ class Text
/*    */   extends Tag
/*    */ {
/*    */   private String clean(String paramString) {
/*  9 */     if ("\n".equals(paramString)) {
/* 10 */       return "\\n";
/*    */     }
/*    */     
/* 13 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\"", true);
/* 14 */     StringBuffer stringBuffer = new StringBuffer();
/*    */     
/* 16 */     while (stringTokenizer.hasMoreTokens()) {
/* 17 */       String str = stringTokenizer.nextToken();
/*    */       
/* 19 */       if (str.equals("\"")) {
/* 20 */         stringBuffer.append("\\\""); continue;
/*    */       } 
/* 22 */       stringBuffer.append(str);
/*    */     } 
/*    */ 
/*    */     
/* 26 */     return stringBuffer.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getJavaScript() {
/* 31 */     if (getContent() == null) {
/* 32 */       return "";
/*    */     }
/*    */     
/* 35 */     StringBuffer stringBuffer = new StringBuffer();
/* 36 */     StringTokenizer stringTokenizer = new StringTokenizer(getContent(), "\r\n\f", true);
/*    */ 
/*    */     
/* 39 */     while (stringTokenizer.hasMoreTokens()) {
/* 40 */       String str = stringTokenizer.nextToken();
/*    */       
/* 42 */       if (str.equals("\r") || str.equals("\f")) {
/*    */         continue;
/*    */       }
/*    */       
/* 46 */       stringBuffer.append("  out.print( \"");
/* 47 */       stringBuffer.append(clean(str));
/* 48 */       stringBuffer.append("\" );\n");
/*    */     } 
/*    */     
/* 51 */     return stringBuffer.toString();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Text.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */