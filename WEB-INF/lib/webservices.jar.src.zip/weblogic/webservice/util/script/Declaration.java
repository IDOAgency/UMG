package weblogic.webservice.util.script;

class Declaration extends Tag {
  public String getJavaScript() throws ScriptException {
    String str = getContent();
    return "\n" + str.substring(3, str.length() - 2);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\script\Declaration.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */