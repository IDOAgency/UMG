/*    */ package weblogic.webservice.util;
/*    */ 
/*    */ import javax.xml.soap.MessageFactory;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import weblogic.webservice.core.soap.MessageFactoryImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WLMessageFactory
/*    */ {
/* 11 */   private static WLMessageFactory wlMessageFactory = null;
/*    */   
/*    */   private MessageFactory messageFactory;
/*    */   
/*    */   private WLMessageFactory() throws SOAPException {
/*    */     try {
/* 17 */       if (System.getProperty("javax.xml.soap.MessageFactory") == null) {
/* 18 */         System.setProperty("javax.xml.soap.MessageFactory", "weblogic.webservice.core.soap.MessageFactoryImpl");
/*    */       }
/* 20 */     } catch (SecurityException securityException) {}
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 25 */     this.messageFactory = new MessageFactoryImpl();
/*    */   }
/*    */ 
/*    */   
/*    */   public static WLMessageFactory getInstance() throws SOAPException {
/* 30 */     if (wlMessageFactory == null) {
/* 31 */       wlMessageFactory = new WLMessageFactory();
/*    */     }
/*    */     
/* 34 */     return wlMessageFactory;
/*    */   }
/*    */ 
/*    */   
/* 38 */   public MessageFactory getMessageFactory() { return this.messageFactory; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WLMessageFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */