package weblogic.webservice.util;

import java.io.CharConversionException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import sun.io.CharToByteConverter;
import sun.io.ConversionBufferFullException;
import weblogic.utils.io.Chunk;

public class NoFlushOutputStreamWriter extends Writer {
  private CharToByteConverter ctb;
  
  private OutputStream out;
  
  private byte[] bb;
  
  private int nextByte = 0;
  
  private int nBytes = 0;
  
  private static boolean doNotConvert = CharToByteConverter.getDefault().getCharacterEncoding().equals("Cp1252");
  
  private boolean doConvert = false;
  
  private Chunk chunk;
  
  public NoFlushOutputStreamWriter(OutputStream paramOutputStream, String paramString, boolean paramBoolean) throws UnsupportedEncodingException {
    this(paramOutputStream, paramString);
    this.doConvert = paramBoolean;
  }
  
  public NoFlushOutputStreamWriter(OutputStream paramOutputStream, String paramString) throws UnsupportedEncodingException { this(paramOutputStream, CharToByteConverter.getConverter(paramString)); }
  
  public NoFlushOutputStreamWriter(OutputStream paramOutputStream) { this(paramOutputStream, doNotConvert ? null : CharToByteConverter.getDefault()); }
  
  private NoFlushOutputStreamWriter(OutputStream paramOutputStream, CharToByteConverter paramCharToByteConverter) {
    super(paramOutputStream);
    if (paramOutputStream == null)
      throw new NullPointerException("out is null"); 
    this.out = paramOutputStream;
    this.ctb = paramCharToByteConverter;
    this.chunk = Chunk.getChunk();
    this.bb = this.chunk.buf;
    this.nBytes = Chunk.CHUNK_SIZE;
  }
  
  public String getEncoding() {
    synchronized (this.lock) {
      if (this.ctb != null)
        return this.ctb.getCharacterEncoding(); 
      return null;
    } 
  }
  
  private void ensureOpen() throws IOException {
    if (this.out == null)
      throw new IOException("Stream closed"); 
  }
  
  public void write(int paramInt) throws IOException {
    char[] arrayOfChar = new char[1];
    arrayOfChar[0] = (char)paramInt;
    write(arrayOfChar, 0, 1);
  }
  
  public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws IOException {
    synchronized (this.lock) {
      ensureOpen();
      if (paramInt1 < 0 || paramInt1 > paramArrayOfChar.length || paramInt2 < 0 || paramInt1 + paramInt2 > paramArrayOfChar.length || paramInt1 + paramInt2 < 0)
        throw new IndexOutOfBoundsException(); 
      if (paramInt2 == 0)
        return; 
      if (doNotConvert && !this.doConvert) {
        for (int k = paramInt1; k < paramInt2; k++)
          this.out.write(paramArrayOfChar[k]); 
        return;
      } 
      int i = paramInt1, j = paramInt1 + paramInt2;
      boolean bool = false;
      while (i < j) {
        boolean bool1 = false;
        try {
          this.nextByte += this.ctb.convertAny(paramArrayOfChar, i, j, this.bb, this.nextByte, this.nBytes);
          i = j;
        } catch (ConversionBufferFullException conversionBufferFullException) {
          int k = this.ctb.nextCharIndex();
          if (k == i && bool)
            throw new CharConversionException("Output buffer too small"); 
          i = k;
          bool1 = true;
          this.nextByte = this.ctb.nextByteIndex();
        } 
        if (this.nextByte >= this.nBytes || bool1) {
          this.out.write(this.bb, 0, this.nextByte);
          this.nextByte = 0;
          bool = true;
        } 
      } 
    } 
  }
  
  public void write(String paramString, int paramInt1, int paramInt2) throws IOException {
    if (paramInt2 < 0)
      throw new IndexOutOfBoundsException(); 
    char[] arrayOfChar = new char[paramInt2];
    paramString.getChars(paramInt1, paramInt1 + paramInt2, arrayOfChar, 0);
    write(arrayOfChar, 0, paramInt2);
  }
  
  void flushBuffer() throws IOException {
    synchronized (this.lock) {
      ensureOpen();
      if (doNotConvert && !this.doConvert)
        return; 
      while (true) {
        try {
          this.nextByte += this.ctb.flushAny(this.bb, this.nextByte, this.nBytes);
        } catch (ConversionBufferFullException conversionBufferFullException) {
          this.nextByte = this.ctb.nextByteIndex();
        } 
        if (this.nextByte == 0)
          break; 
        if (this.nextByte > 0) {
          this.out.write(this.bb, 0, this.nextByte);
          this.nextByte = 0;
        } 
      } 
    } 
  }
  
  public void flush() throws IOException {
    synchronized (this.lock) {
      flushBuffer();
    } 
  }
  
  public void close() throws IOException {
    try {
      synchronized (this.lock) {
        if (this.out == null)
          return; 
        flush();
        this.out = null;
        this.bb = null;
        this.ctb = null;
      } 
    } finally {
      if (this.chunk != null)
        Chunk.releaseChunk(this.chunk); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\NoFlushOutputStreamWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */