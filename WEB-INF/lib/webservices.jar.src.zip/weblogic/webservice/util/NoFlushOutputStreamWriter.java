/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import java.io.CharConversionException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import sun.io.CharToByteConverter;
/*     */ import sun.io.ConversionBufferFullException;
/*     */ import weblogic.utils.io.Chunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoFlushOutputStreamWriter
/*     */   extends Writer
/*     */ {
/*     */   private CharToByteConverter ctb;
/*     */   private OutputStream out;
/*     */   private byte[] bb;
/*  74 */   private int nextByte = 0;
/*     */   
/*  76 */   private int nBytes = 0;
/*     */   
/*  78 */   private static boolean doNotConvert = CharToByteConverter.getDefault().getCharacterEncoding().equals("Cp1252");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean doConvert = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Chunk chunk;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoFlushOutputStreamWriter(OutputStream paramOutputStream, String paramString, boolean paramBoolean) throws UnsupportedEncodingException {
/*  99 */     this(paramOutputStream, paramString);
/* 100 */     this.doConvert = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public NoFlushOutputStreamWriter(OutputStream paramOutputStream, String paramString) throws UnsupportedEncodingException { this(paramOutputStream, CharToByteConverter.getConverter(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public NoFlushOutputStreamWriter(OutputStream paramOutputStream) { this(paramOutputStream, doNotConvert ? null : CharToByteConverter.getDefault()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NoFlushOutputStreamWriter(OutputStream paramOutputStream, CharToByteConverter paramCharToByteConverter) {
/* 126 */     super(paramOutputStream);
/* 127 */     if (paramOutputStream == null)
/* 128 */       throw new NullPointerException("out is null"); 
/* 129 */     this.out = paramOutputStream;
/* 130 */     this.ctb = paramCharToByteConverter;
/*     */     
/* 132 */     this.chunk = Chunk.getChunk();
/*     */     
/* 134 */     this.bb = this.chunk.buf;
/* 135 */     this.nBytes = Chunk.CHUNK_SIZE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 153 */     synchronized (this.lock) {
/* 154 */       if (this.ctb != null) {
/* 155 */         return this.ctb.getCharacterEncoding();
/*     */       }
/* 157 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void ensureOpen() throws IOException {
/* 163 */     if (this.out == null) {
/* 164 */       throw new IOException("Stream closed");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int paramInt) throws IOException {
/* 173 */     char[] arrayOfChar = new char[1];
/* 174 */     arrayOfChar[0] = (char)paramInt;
/* 175 */     write(arrayOfChar, 0, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2) throws IOException {
/* 188 */     synchronized (this.lock) {
/* 189 */       ensureOpen();
/* 190 */       if (paramInt1 < 0 || paramInt1 > paramArrayOfChar.length || paramInt2 < 0 || paramInt1 + paramInt2 > paramArrayOfChar.length || paramInt1 + paramInt2 < 0)
/*     */       {
/* 192 */         throw new IndexOutOfBoundsException(); } 
/* 193 */       if (paramInt2 == 0) {
/*     */         return;
/*     */       }
/* 196 */       if (doNotConvert && !this.doConvert) {
/* 197 */         for (int k = paramInt1; k < paramInt2; k++) {
/* 198 */           this.out.write(paramArrayOfChar[k]);
/*     */         }
/*     */         return;
/*     */       } 
/* 202 */       int i = paramInt1, j = paramInt1 + paramInt2;
/* 203 */       boolean bool = false;
/* 204 */       while (i < j) {
/* 205 */         boolean bool1 = false;
/*     */         try {
/* 207 */           this.nextByte += this.ctb.convertAny(paramArrayOfChar, i, j, this.bb, this.nextByte, this.nBytes);
/*     */           
/* 209 */           i = j;
/*     */         }
/* 211 */         catch (ConversionBufferFullException conversionBufferFullException) {
/* 212 */           int k = this.ctb.nextCharIndex();
/* 213 */           if (k == i && bool)
/*     */           {
/*     */             
/* 216 */             throw new CharConversionException("Output buffer too small");
/*     */           }
/*     */           
/* 219 */           i = k;
/* 220 */           bool1 = true;
/* 221 */           this.nextByte = this.ctb.nextByteIndex();
/*     */         } 
/* 223 */         if (this.nextByte >= this.nBytes || bool1) {
/* 224 */           this.out.write(this.bb, 0, this.nextByte);
/* 225 */           this.nextByte = 0;
/* 226 */           bool = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String paramString, int paramInt1, int paramInt2) throws IOException {
/* 243 */     if (paramInt2 < 0) {
/* 244 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 246 */     char[] arrayOfChar = new char[paramInt2];
/* 247 */     paramString.getChars(paramInt1, paramInt1 + paramInt2, arrayOfChar, 0);
/* 248 */     write(arrayOfChar, 0, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void flushBuffer() throws IOException {
/* 257 */     synchronized (this.lock) {
/* 258 */       ensureOpen();
/*     */       
/* 260 */       if (doNotConvert && !this.doConvert)
/*     */         return;  while (true) {
/*     */         try {
/* 263 */           this.nextByte += this.ctb.flushAny(this.bb, this.nextByte, this.nBytes);
/*     */         }
/* 265 */         catch (ConversionBufferFullException conversionBufferFullException) {
/* 266 */           this.nextByte = this.ctb.nextByteIndex();
/*     */         } 
/* 268 */         if (this.nextByte == 0)
/*     */           break; 
/* 270 */         if (this.nextByte > 0) {
/* 271 */           this.out.write(this.bb, 0, this.nextByte);
/* 272 */           this.nextByte = 0;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 284 */     synchronized (this.lock) {
/* 285 */       flushBuffer();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/* 298 */       synchronized (this.lock) {
/* 299 */         if (this.out == null)
/*     */           return; 
/* 301 */         flush();
/* 302 */         this.out = null;
/* 303 */         this.bb = null;
/* 304 */         this.ctb = null;
/*     */       } 
/*     */     } finally {
/* 307 */       if (this.chunk != null) Chunk.releaseChunk(this.chunk); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\NoFlushOutputStreamWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */