package weblogic.webservice.util;

import java.io.IOException;

public class AccessException extends IOException {
  public AccessException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\AccessException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */