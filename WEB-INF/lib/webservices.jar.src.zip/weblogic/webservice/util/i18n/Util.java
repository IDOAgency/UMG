/*    */ package weblogic.webservice.util.i18n;
/*    */ 
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Util
/*    */ {
/*    */   public String getMethodSignature(XMLNode paramXMLNode) {
/* 11 */     String str = paramXMLNode.getAttribute("method", null);
/* 12 */     str = str.trim();
/*    */     
/* 14 */     int i = str.indexOf("(");
/*    */     
/* 16 */     if (i == -1) {
/* 17 */       str = str + "()";
/*    */     }
/*    */     
/* 20 */     return str;
/*    */   }
/*    */   
/*    */   public String getErrorMessage(XMLNode paramXMLNode) {
/* 24 */     XMLNode xMLNode = paramXMLNode.getChild("messagedetail", null);
/*    */     
/* 26 */     String str = "unknown error";
/*    */     
/* 28 */     if (xMLNode != null && xMLNode.getText() != null) {
/* 29 */       str = xMLNode.getText();
/*    */     }
/*    */     
/* 32 */     return str.trim();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\i18n\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */