package weblogic.webservice.util.i18n;

import weblogic.xml.xmlnode.XMLNode;

public class Util {
  public String getMethodSignature(XMLNode paramXMLNode) {
    String str = paramXMLNode.getAttribute("method", null);
    str = str.trim();
    int i = str.indexOf("(");
    if (i == -1)
      str = str + "()"; 
    return str;
  }
  
  public String getErrorMessage(XMLNode paramXMLNode) {
    XMLNode xMLNode = paramXMLNode.getChild("messagedetail", null);
    String str = "unknown error";
    if (xMLNode != null && xMLNode.getText() != null)
      str = xMLNode.getText(); 
    return str.trim();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\i18n\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */