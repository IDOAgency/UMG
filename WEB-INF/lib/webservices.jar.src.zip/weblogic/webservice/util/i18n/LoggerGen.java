package weblogic.webservice.util.i18n;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import weblogic.webservice.util.script.GenBase;
import weblogic.webservice.util.script.ScriptException;
import weblogic.xml.xmlnode.XMLNode;

public class LoggerGen extends GenBase {
  private PrintStream outputStream;
  
  private FileOutputStream fos;
  
  public LoggerGen(String paramString1, String paramString2) throws IOException {
    super("Logger.cg", false);
    File file = new File(paramString1);
    FileInputStream fileInputStream = new FileInputStream(file);
    XMLNode xMLNode = new XMLNode();
    xMLNode.read(fileInputStream, true);
    if ("message_catalog".equals(xMLNode.getName().getLocalName())) {
      this.fos = new FileOutputStream(paramString2);
      this.outputStream = new PrintStream(this.fos);
      setOutput(this.outputStream);
      setVar("className", getClassName(paramString2));
      setVar("util", new Util());
      setGenVars(xMLNode);
    } else {
      System.err.println("ERROR: " + xMLNode);
    } 
    fileInputStream.close();
  }
  
  public void gen() throws ScriptException {
    super.gen();
    if (this.outputStream != null)
      this.outputStream.close(); 
    if (this.fos != null)
      try {
        this.fos.close();
      } catch (IOException iOException) {
        throw new ScriptException("failed to close file:" + iOException);
      }  
  }
  
  private String getClassName(String paramString) {
    int i = paramString.lastIndexOf("/");
    if (i == -1)
      i = paramString.lastIndexOf("\\"); 
    if (i != -1)
      paramString = paramString.substring(i + 1, paramString.length()); 
    i = paramString.lastIndexOf(".");
    if (i != -1)
      paramString = paramString.substring(0, i); 
    return paramString;
  }
  
  private void setGenVars(XMLNode paramXMLNode) {
    String str = paramXMLNode.getAttribute("i18n_package", null);
    if (str == null)
      str = "weblogic.webservice"; 
    setVar("packageName", str);
    setVar("methods", getLogMessages(paramXMLNode));
  }
  
  private ArrayList getLogMessages(XMLNode paramXMLNode) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("logmessage".equals(xMLNode.getName().getLocalName()))
        arrayList.add(xMLNode); 
    } 
    return arrayList;
  }
  
  public static void main(String[] paramArrayOfString) throws IOException {
    if (paramArrayOfString.length == 2) {
      (new LoggerGen(paramArrayOfString[0], paramArrayOfString[1])).gen();
    } else {
      System.out.println("usage: LoggerGen msgcat_xml_file output_java_file");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\i18n\LoggerGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */