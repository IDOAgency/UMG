/*     */ package weblogic.webservice.util.i18n;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.util.script.GenBase;
/*     */ import weblogic.webservice.util.script.ScriptException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggerGen
/*     */   extends GenBase
/*     */ {
/*     */   private PrintStream outputStream;
/*     */   private FileOutputStream fos;
/*     */   
/*     */   public LoggerGen(String paramString1, String paramString2) throws IOException {
/*  26 */     super("Logger.cg", false);
/*     */     
/*  28 */     File file = new File(paramString1);
/*  29 */     FileInputStream fileInputStream = new FileInputStream(file);
/*  30 */     XMLNode xMLNode = new XMLNode();
/*  31 */     xMLNode.read(fileInputStream, true);
/*     */     
/*  33 */     if ("message_catalog".equals(xMLNode.getName().getLocalName())) {
/*     */       
/*  35 */       this.fos = new FileOutputStream(paramString2);
/*  36 */       this.outputStream = new PrintStream(this.fos);
/*  37 */       setOutput(this.outputStream);
/*     */       
/*  39 */       setVar("className", getClassName(paramString2));
/*  40 */       setVar("util", new Util());
/*  41 */       setGenVars(xMLNode);
/*     */     } else {
/*     */       
/*  44 */       System.err.println("ERROR: " + xMLNode);
/*     */     } 
/*     */     
/*  47 */     fileInputStream.close();
/*     */   }
/*     */   
/*     */   public void gen() throws ScriptException {
/*  51 */     super.gen();
/*     */     
/*  53 */     if (this.outputStream != null) {
/*  54 */       this.outputStream.close();
/*     */     }
/*     */     
/*  57 */     if (this.fos != null) {
/*     */       try {
/*  59 */         this.fos.close();
/*  60 */       } catch (IOException iOException) {
/*  61 */         throw new ScriptException("failed to close file:" + iOException);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private String getClassName(String paramString) {
/*  67 */     int i = paramString.lastIndexOf("/");
/*     */     
/*  69 */     if (i == -1) {
/*  70 */       i = paramString.lastIndexOf("\\");
/*     */     }
/*     */     
/*  73 */     if (i != -1) {
/*  74 */       paramString = paramString.substring(i + 1, paramString.length());
/*     */     }
/*     */     
/*  77 */     i = paramString.lastIndexOf(".");
/*     */     
/*  79 */     if (i != -1) {
/*  80 */       paramString = paramString.substring(0, i);
/*     */     }
/*     */     
/*  83 */     return paramString;
/*     */   }
/*     */   
/*     */   private void setGenVars(XMLNode paramXMLNode) {
/*  87 */     String str = paramXMLNode.getAttribute("i18n_package", null);
/*     */     
/*  89 */     if (str == null) {
/*  90 */       str = "weblogic.webservice";
/*     */     }
/*     */     
/*  93 */     setVar("packageName", str);
/*  94 */     setVar("methods", getLogMessages(paramXMLNode));
/*     */   }
/*     */   
/*     */   private ArrayList getLogMessages(XMLNode paramXMLNode) {
/*  98 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 100 */     for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 101 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 103 */       if ("logmessage".equals(xMLNode.getName().getLocalName())) {
/* 104 */         arrayList.add(xMLNode);
/*     */       }
/*     */     } 
/*     */     
/* 108 */     return arrayList;
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws IOException {
/* 112 */     if (paramArrayOfString.length == 2) {
/* 113 */       (new LoggerGen(paramArrayOfString[0], paramArrayOfString[1])).gen();
/*     */     } else {
/* 115 */       System.out.println("usage: LoggerGen msgcat_xml_file output_java_file");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\i18n\LoggerGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */