package weblogic.webservice.util.bytecode;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class SField {
  private short accessFlag;
  
  private short nameIndex;
  
  private short descriptorIndex;
  
  private ArrayList attributes = new ArrayList();
  
  private ConstantPool pool;
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(getElementName()).append("[\n");
    stringBuffer.append("\naccessFlag=").append(this.accessFlag);
    stringBuffer.append("\nname=").append(this.pool.getValue(this.nameIndex));
    stringBuffer.append("\ndescriptor=").append(this.pool.getValue(this.descriptorIndex));
    stringBuffer.append("\nattributes=");
    for (Iterator iterator = this.attributes.iterator(); iterator.hasNext();)
      stringBuffer.append("\n>>").append(iterator.next()); 
    stringBuffer.append("\n]\n");
    return stringBuffer.toString();
  }
  
  protected String getElementName() { return "Field"; }
  
  public void read(DataInput paramDataInput, ConstantPool paramConstantPool) throws IOException {
    this.pool = paramConstantPool;
    this.accessFlag = paramDataInput.readShort();
    this.nameIndex = paramDataInput.readShort();
    this.descriptorIndex = paramDataInput.readShort();
    short s = paramDataInput.readShort();
    for (byte b = 0; b < s; b++) {
      AttributeInfo attributeInfo = new AttributeInfo();
      attributeInfo.read(paramDataInput, paramConstantPool);
      this.attributes.add(attributeInfo);
    } 
  }
  
  public void write(DataOutput paramDataOutput) throws IOException {
    paramDataOutput.writeShort(this.accessFlag);
    paramDataOutput.writeShort(this.nameIndex);
    paramDataOutput.writeShort(this.descriptorIndex);
    paramDataOutput.writeShort(this.attributes.size());
    for (AttributeInfo attributeInfo : this.attributes)
      attributeInfo.write(paramDataOutput); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\SField.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */