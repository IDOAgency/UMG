/*    */ package weblogic.webservice.util.bytecode;
/*    */ 
/*    */ import java.io.DataInput;
/*    */ import java.io.DataOutput;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SField
/*    */ {
/*    */   private short accessFlag;
/*    */   private short nameIndex;
/*    */   private short descriptorIndex;
/* 19 */   private ArrayList attributes = new ArrayList();
/*    */   private ConstantPool pool;
/*    */   
/*    */   public String toString() {
/* 23 */     StringBuffer stringBuffer = new StringBuffer();
/* 24 */     stringBuffer.append(getElementName()).append("[\n");
/* 25 */     stringBuffer.append("\naccessFlag=").append(this.accessFlag);
/* 26 */     stringBuffer.append("\nname=").append(this.pool.getValue(this.nameIndex));
/* 27 */     stringBuffer.append("\ndescriptor=").append(this.pool.getValue(this.descriptorIndex));
/*    */     
/* 29 */     stringBuffer.append("\nattributes=");
/* 30 */     for (Iterator iterator = this.attributes.iterator(); iterator.hasNext();) {
/* 31 */       stringBuffer.append("\n>>").append(iterator.next());
/*    */     }
/*    */     
/* 34 */     stringBuffer.append("\n]\n");
/*    */     
/* 36 */     return stringBuffer.toString();
/*    */   }
/*    */ 
/*    */   
/* 40 */   protected String getElementName() { return "Field"; }
/*    */ 
/*    */ 
/*    */   
/*    */   public void read(DataInput paramDataInput, ConstantPool paramConstantPool) throws IOException {
/* 45 */     this.pool = paramConstantPool;
/*    */     
/* 47 */     this.accessFlag = paramDataInput.readShort();
/* 48 */     this.nameIndex = paramDataInput.readShort();
/* 49 */     this.descriptorIndex = paramDataInput.readShort();
/* 50 */     short s = paramDataInput.readShort();
/*    */     
/* 52 */     for (byte b = 0; b < s; b++) {
/* 53 */       AttributeInfo attributeInfo = new AttributeInfo();
/* 54 */       attributeInfo.read(paramDataInput, paramConstantPool);
/* 55 */       this.attributes.add(attributeInfo);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void write(DataOutput paramDataOutput) throws IOException {
/* 60 */     paramDataOutput.writeShort(this.accessFlag);
/* 61 */     paramDataOutput.writeShort(this.nameIndex);
/* 62 */     paramDataOutput.writeShort(this.descriptorIndex);
/*    */     
/* 64 */     paramDataOutput.writeShort(this.attributes.size());
/* 65 */     for (AttributeInfo attributeInfo : this.attributes)
/*    */     {
/* 67 */       attributeInfo.write(paramDataOutput);
/*    */     }
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\SField.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */