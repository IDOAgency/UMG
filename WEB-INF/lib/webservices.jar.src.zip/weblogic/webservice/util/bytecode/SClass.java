package weblogic.webservice.util.bytecode;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class SClass {
  private int magic = -889275714;
  
  private short minorVersion = 3;
  
  private short majorVersion = 45;
  
  private ConstantPool pool;
  
  private short accessFlag;
  
  private short thisClassIndex;
  
  private short superClassIndex;
  
  private short[] interfaceIndexes;
  
  private ArrayList fields = new ArrayList();
  
  private ArrayList methods = new ArrayList();
  
  private ArrayList attributes = new ArrayList();
  
  public ConstantPool getConstantPool() { return this.pool; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SClass[\n");
    stringBuffer.append("magic=").append(this.magic);
    stringBuffer.append("\nminorVersion=").append(this.minorVersion);
    stringBuffer.append("\nmajorVersion=").append(this.majorVersion);
    stringBuffer.append("\nconstantPool=").append(this.pool);
    stringBuffer.append("\naccessFlag=").append(this.accessFlag);
    stringBuffer.append("\nthisClass=").append(this.pool.getValue(this.thisClassIndex));
    stringBuffer.append("\nsuperClass=").append(this.pool.getValue(this.superClassIndex));
    stringBuffer.append("\ninterfaces=");
    for (byte b = 0; b < this.interfaceIndexes.length; b++)
      stringBuffer.append("\n>>").append(this.pool.getValue(this.interfaceIndexes[b])); 
    stringBuffer.append("\nfields=");
    Iterator iterator;
    for (iterator = this.fields.iterator(); iterator.hasNext();)
      stringBuffer.append("\n>>").append(iterator.next()); 
    stringBuffer.append("\nmethods=");
    for (iterator = this.methods.iterator(); iterator.hasNext();)
      stringBuffer.append("\n>>").append(iterator.next()); 
    stringBuffer.append("\nattributes=");
    for (iterator = this.attributes.iterator(); iterator.hasNext();)
      stringBuffer.append("\n>>").append(iterator.next()); 
    stringBuffer.append("\n]\n");
    return stringBuffer.toString();
  }
  
  public void write(DataOutput paramDataOutput) throws IOException {
    paramDataOutput.writeInt(this.magic);
    paramDataOutput.writeShort(this.minorVersion);
    paramDataOutput.writeShort(this.majorVersion);
    this.pool.write(paramDataOutput);
    paramDataOutput.writeShort(this.accessFlag);
    paramDataOutput.writeShort(this.thisClassIndex);
    paramDataOutput.writeShort(this.superClassIndex);
    paramDataOutput.writeShort(this.interfaceIndexes.length);
    for (byte b = 0; b < this.interfaceIndexes.length; b++)
      paramDataOutput.writeShort(this.interfaceIndexes[b]); 
    paramDataOutput.writeShort(this.fields.size());
    for (SField sField : this.fields)
      sField.write(paramDataOutput); 
    paramDataOutput.writeShort(this.methods.size());
    for (SMethod sMethod : this.methods)
      sMethod.write(paramDataOutput); 
    paramDataOutput.writeShort(this.attributes.size());
    for (AttributeInfo attributeInfo : this.attributes)
      attributeInfo.write(paramDataOutput); 
  }
  
  public void addMethod(SMethod paramSMethod) { this.methods.add(paramSMethod); }
  
  public void addField(SField paramSField) { this.fields.add(paramSField); }
  
  public void addAttribute(AttributeInfo paramAttributeInfo) { this.attributes.add(paramAttributeInfo); }
  
  public Iterator getAttributes() { return this.attributes.iterator(); }
  
  public AttributeInfo getAttribute(String paramString) {
    for (Iterator iterator = getAttributes(); iterator.hasNext(); ) {
      AttributeInfo attributeInfo = (AttributeInfo)iterator.next();
      if (paramString.equals(attributeInfo.getName()))
        return attributeInfo; 
    } 
    return null;
  }
  
  public byte[] getAttributeBytes(String paramString) {
    AttributeInfo attributeInfo = getAttribute(paramString);
    if (attributeInfo == null)
      throw new RuntimeException("Custom Attribute not found"); 
    return attributeInfo.getAttributeBytes();
  }
  
  public void addCustomAttribute(String paramString, byte[] paramArrayOfByte) {
    short s = this.pool.addUtf8Constant(paramString);
    AttributeInfo attributeInfo = new AttributeInfo();
    attributeInfo.setCustomAttribute(paramString, s, paramArrayOfByte);
    addAttribute(attributeInfo);
  }
  
  public void read(DataInput paramDataInput) throws IOException {
    if (this.magic != paramDataInput.readInt())
      throw new IOException("wrong magic"); 
    if (this.minorVersion != paramDataInput.readShort());
    if (this.majorVersion != paramDataInput.readShort());
    this.pool = new ConstantPool();
    this.pool.read(paramDataInput);
    this.accessFlag = paramDataInput.readShort();
    this.thisClassIndex = paramDataInput.readShort();
    this.superClassIndex = paramDataInput.readShort();
    short s = paramDataInput.readShort();
    this.interfaceIndexes = new short[s];
    short s1;
    for (s1 = 0; s1 < s; s1++)
      this.interfaceIndexes[s1] = paramDataInput.readShort(); 
    s1 = paramDataInput.readShort();
    short s2;
    for (s2 = 0; s2 < s1; s2++) {
      SField sField = new SField();
      sField.read(paramDataInput, this.pool);
      addField(sField);
    } 
    s2 = paramDataInput.readShort();
    short s3;
    for (s3 = 0; s3 < s2; s3++) {
      SMethod sMethod = new SMethod();
      sMethod.read(paramDataInput, this.pool);
      addMethod(sMethod);
    } 
    s3 = paramDataInput.readShort();
    for (byte b = 0; b < s3; b++) {
      AttributeInfo attributeInfo = new AttributeInfo();
      attributeInfo.read(paramDataInput, this.pool);
      addAttribute(attributeInfo);
    } 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    if (paramArrayOfString.length == 0) {
      System.out.println("usage: SClass [file].class");
      return;
    } 
    SClass sClass = new SClass();
    FileInputStream fileInputStream;
    sClass.read(new DataInputStream(fileInputStream = new FileInputStream(paramArrayOfString[0])));
    fileInputStream.close();
    System.out.println("clazz:" + sClass);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\SClass.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */