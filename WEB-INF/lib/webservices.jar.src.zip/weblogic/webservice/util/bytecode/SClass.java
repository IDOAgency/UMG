/*     */ package weblogic.webservice.util.bytecode;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutput;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SClass
/*     */ {
/*  18 */   private int magic = -889275714;
/*  19 */   private short minorVersion = 3;
/*  20 */   private short majorVersion = 45;
/*     */   private ConstantPool pool;
/*     */   private short accessFlag;
/*     */   private short thisClassIndex;
/*     */   private short superClassIndex;
/*     */   private short[] interfaceIndexes;
/*  26 */   private ArrayList fields = new ArrayList();
/*  27 */   private ArrayList methods = new ArrayList();
/*  28 */   private ArrayList attributes = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   public ConstantPool getConstantPool() { return this.pool; }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  38 */     StringBuffer stringBuffer = new StringBuffer();
/*  39 */     stringBuffer.append("SClass[\n");
/*  40 */     stringBuffer.append("magic=").append(this.magic);
/*  41 */     stringBuffer.append("\nminorVersion=").append(this.minorVersion);
/*  42 */     stringBuffer.append("\nmajorVersion=").append(this.majorVersion);
/*  43 */     stringBuffer.append("\nconstantPool=").append(this.pool);
/*  44 */     stringBuffer.append("\naccessFlag=").append(this.accessFlag);
/*  45 */     stringBuffer.append("\nthisClass=").append(this.pool.getValue(this.thisClassIndex));
/*  46 */     stringBuffer.append("\nsuperClass=").append(this.pool.getValue(this.superClassIndex));
/*  47 */     stringBuffer.append("\ninterfaces=");
/*     */     
/*  49 */     for (byte b = 0; b < this.interfaceIndexes.length; b++) {
/*  50 */       stringBuffer.append("\n>>").append(this.pool.getValue(this.interfaceIndexes[b]));
/*     */     }
/*     */     
/*  53 */     stringBuffer.append("\nfields="); Iterator iterator;
/*  54 */     for (iterator = this.fields.iterator(); iterator.hasNext();) {
/*  55 */       stringBuffer.append("\n>>").append(iterator.next());
/*     */     }
/*     */     
/*  58 */     stringBuffer.append("\nmethods=");
/*  59 */     for (iterator = this.methods.iterator(); iterator.hasNext();) {
/*  60 */       stringBuffer.append("\n>>").append(iterator.next());
/*     */     }
/*     */     
/*  63 */     stringBuffer.append("\nattributes=");
/*  64 */     for (iterator = this.attributes.iterator(); iterator.hasNext();) {
/*  65 */       stringBuffer.append("\n>>").append(iterator.next());
/*     */     }
/*     */     
/*  68 */     stringBuffer.append("\n]\n");
/*     */     
/*  70 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public void write(DataOutput paramDataOutput) throws IOException {
/*  74 */     paramDataOutput.writeInt(this.magic);
/*  75 */     paramDataOutput.writeShort(this.minorVersion);
/*  76 */     paramDataOutput.writeShort(this.majorVersion);
/*     */     
/*  78 */     this.pool.write(paramDataOutput);
/*     */     
/*  80 */     paramDataOutput.writeShort(this.accessFlag);
/*  81 */     paramDataOutput.writeShort(this.thisClassIndex);
/*  82 */     paramDataOutput.writeShort(this.superClassIndex);
/*  83 */     paramDataOutput.writeShort(this.interfaceIndexes.length);
/*     */     
/*  85 */     for (byte b = 0; b < this.interfaceIndexes.length; b++) {
/*  86 */       paramDataOutput.writeShort(this.interfaceIndexes[b]);
/*     */     }
/*     */     
/*  89 */     paramDataOutput.writeShort(this.fields.size());
/*  90 */     for (SField sField : this.fields)
/*     */     {
/*  92 */       sField.write(paramDataOutput);
/*     */     }
/*     */     
/*  95 */     paramDataOutput.writeShort(this.methods.size());
/*  96 */     for (SMethod sMethod : this.methods)
/*     */     {
/*  98 */       sMethod.write(paramDataOutput);
/*     */     }
/*     */     
/* 101 */     paramDataOutput.writeShort(this.attributes.size());
/* 102 */     for (AttributeInfo attributeInfo : this.attributes)
/*     */     {
/* 104 */       attributeInfo.write(paramDataOutput);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 109 */   public void addMethod(SMethod paramSMethod) { this.methods.add(paramSMethod); }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public void addField(SField paramSField) { this.fields.add(paramSField); }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void addAttribute(AttributeInfo paramAttributeInfo) { this.attributes.add(paramAttributeInfo); }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public Iterator getAttributes() { return this.attributes.iterator(); }
/*     */ 
/*     */   
/*     */   public AttributeInfo getAttribute(String paramString) {
/* 125 */     for (Iterator iterator = getAttributes(); iterator.hasNext(); ) {
/* 126 */       AttributeInfo attributeInfo = (AttributeInfo)iterator.next();
/* 127 */       if (paramString.equals(attributeInfo.getName())) {
/* 128 */         return attributeInfo;
/*     */       }
/*     */     } 
/*     */     
/* 132 */     return null;
/*     */   }
/*     */   
/*     */   public byte[] getAttributeBytes(String paramString) {
/* 136 */     AttributeInfo attributeInfo = getAttribute(paramString);
/* 137 */     if (attributeInfo == null) {
/* 138 */       throw new RuntimeException("Custom Attribute not found");
/*     */     }
/* 140 */     return attributeInfo.getAttributeBytes();
/*     */   }
/*     */   
/*     */   public void addCustomAttribute(String paramString, byte[] paramArrayOfByte) {
/* 144 */     short s = this.pool.addUtf8Constant(paramString);
/* 145 */     AttributeInfo attributeInfo = new AttributeInfo();
/* 146 */     attributeInfo.setCustomAttribute(paramString, s, paramArrayOfByte);
/* 147 */     addAttribute(attributeInfo);
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(DataInput paramDataInput) throws IOException {
/* 152 */     if (this.magic != paramDataInput.readInt()) {
/* 153 */       throw new IOException("wrong magic");
/*     */     }
/*     */     
/* 156 */     if (this.minorVersion != paramDataInput.readShort());
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (this.majorVersion != paramDataInput.readShort());
/*     */ 
/*     */ 
/*     */     
/* 164 */     this.pool = new ConstantPool();
/* 165 */     this.pool.read(paramDataInput);
/*     */     
/* 167 */     this.accessFlag = paramDataInput.readShort();
/* 168 */     this.thisClassIndex = paramDataInput.readShort();
/* 169 */     this.superClassIndex = paramDataInput.readShort();
/*     */     
/* 171 */     short s = paramDataInput.readShort();
/* 172 */     this.interfaceIndexes = new short[s];
/*     */     short s1;
/* 174 */     for (s1 = 0; s1 < s; s1++) {
/* 175 */       this.interfaceIndexes[s1] = paramDataInput.readShort();
/*     */     }
/*     */     
/* 178 */     s1 = paramDataInput.readShort();
/*     */     short s2;
/* 180 */     for (s2 = 0; s2 < s1; s2++) {
/* 181 */       SField sField = new SField();
/* 182 */       sField.read(paramDataInput, this.pool);
/* 183 */       addField(sField);
/*     */     } 
/*     */     
/* 186 */     s2 = paramDataInput.readShort();
/*     */     short s3;
/* 188 */     for (s3 = 0; s3 < s2; s3++) {
/* 189 */       SMethod sMethod = new SMethod();
/* 190 */       sMethod.read(paramDataInput, this.pool);
/* 191 */       addMethod(sMethod);
/*     */     } 
/*     */     
/* 194 */     s3 = paramDataInput.readShort();
/* 195 */     for (byte b = 0; b < s3; b++) {
/* 196 */       AttributeInfo attributeInfo = new AttributeInfo();
/* 197 */       attributeInfo.read(paramDataInput, this.pool);
/* 198 */       addAttribute(attributeInfo);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 203 */     if (paramArrayOfString.length == 0) {
/* 204 */       System.out.println("usage: SClass [file].class");
/*     */       
/*     */       return;
/*     */     } 
/* 208 */     SClass sClass = new SClass();
/*     */     FileInputStream fileInputStream;
/* 210 */     sClass.read(new DataInputStream(fileInputStream = new FileInputStream(paramArrayOfString[0])));
/*     */     
/* 212 */     fileInputStream.close();
/*     */     
/* 214 */     System.out.println("clazz:" + sClass);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\SClass.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */