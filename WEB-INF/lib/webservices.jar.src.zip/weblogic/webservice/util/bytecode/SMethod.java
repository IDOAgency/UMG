package weblogic.webservice.util.bytecode;

public class SMethod extends SField {
  protected String getElementName() { return "Method"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\SMethod.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */