package weblogic.webservice.util.bytecode;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;

public class AttributeInfo {
  private static HashMap attInfos = new HashMap();
  
  private AttInfo attInfo;
  
  private short nameIndex;
  
  private ArrayList parameterNames;
  
  static  {
    attInfos.put("SourceFile", SourceFile.class);
    attInfos.put("ConstantValue", ConstantValue.class);
    attInfos.put("Code", Code.class);
    attInfos.put("Exceptions", Exceptions.class);
    attInfos.put("LineNumberTable", LineNumberTable.class);
    attInfos.put("LocalVariableTable", LocalVariableTable.class);
  }
  
  public AttributeInfo() { this(null); }
  
  public AttributeInfo(ArrayList paramArrayList) { this.parameterNames = paramArrayList; }
  
  private void addParameterName(String paramString) {
    if (this.parameterNames != null)
      this.parameterNames.add(paramString); 
  }
  
  public String toString() { return "" + this.attInfo; }
  
  public abstract class AttInfo {
    private String name;
    
    private final AttributeInfo this$0;
    
    public void setName(String param1String) { this.name = param1String; }
    
    public String getName() { return this.name; }
    
    public abstract void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException;
    
    public abstract void write(DataOutput param1DataOutput) throws IOException;
  }
  
  public class DefaultAttInfo extends AttInfo {
    byte[] bytes;
    
    private final AttributeInfo this$0;
    
    public DefaultAttInfo() {
      super(AttributeInfo.this);
    }
    
    public byte[] getBytes() { return this.bytes; }
    
    public void setBytes(byte[] param1ArrayOfByte) { this.bytes = param1ArrayOfByte; }
    
    public String toString() { return "AttInfo[" + getName() + "] : " + new String(this.bytes); }
    
    public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
      int i = param1DataInput.readInt();
      this.bytes = new byte[i];
      param1DataInput.readFully(this.bytes);
    }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      param1DataOutput.writeInt(this.bytes.length);
      param1DataOutput.write(this.bytes);
    }
  }
  
  public class SourceFile extends AttInfo {
    private final AttributeInfo this$0;
    
    public SourceFile() {
      super(AttributeInfo.this);
    }
    
    public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
      int i = param1DataInput.readInt();
      String str = param1ConstantPool.getValue(param1DataInput.readShort());
    }
    
    public void write(DataOutput param1DataOutput) throws IOException {}
  }
  
  public class ConstantValue extends AttInfo {
    private final AttributeInfo this$0;
    
    public ConstantValue() {
      super(AttributeInfo.this);
    }
    
    public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
      int i = param1DataInput.readInt();
      String str = param1ConstantPool.getValue(param1DataInput.readShort());
    }
    
    public void write(DataOutput param1DataOutput) throws IOException {}
  }
  
  public class Code extends AttInfo {
    private final AttributeInfo this$0;
    
    public Code() {
      super(AttributeInfo.this);
    }
    
    public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
      int i = param1DataInput.readInt();
      short s1 = param1DataInput.readShort();
      short s2 = param1DataInput.readShort();
      int j = param1DataInput.readInt();
      byte[] arrayOfByte = new byte[j];
      param1DataInput.readFully(arrayOfByte);
      short s3 = param1DataInput.readShort();
      short s;
      for (s = 0; s < s3; s++) {
        short s4 = param1DataInput.readShort();
        short s5 = param1DataInput.readShort();
        short s6 = param1DataInput.readShort();
        short s7 = param1DataInput.readShort();
      } 
      s = param1DataInput.readShort();
      for (byte b = 0; b < s; b++) {
        AttributeInfo attributeInfo = new AttributeInfo(AttributeInfo.this.parameterNames);
        attributeInfo.read(param1DataInput, param1ConstantPool);
      } 
    }
    
    public void write(DataOutput param1DataOutput) throws IOException {}
  }
  
  public class Exceptions extends AttInfo {
    private final AttributeInfo this$0;
    
    public Exceptions() {
      super(AttributeInfo.this);
    }
    
    public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
      int i = param1DataInput.readInt();
      short s = param1DataInput.readShort();
      for (byte b = 0; b < s; b++)
        String str = param1ConstantPool.getValue(param1DataInput.readShort()); 
    }
    
    public void write(DataOutput param1DataOutput) throws IOException {}
  }
  
  public class LineNumberTable extends AttInfo {
    private final AttributeInfo this$0;
    
    public LineNumberTable() {
      super(AttributeInfo.this);
    }
    
    public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
      int i = param1DataInput.readInt();
      short s = param1DataInput.readShort();
      for (byte b = 0; b < s; b++) {
        short s1 = param1DataInput.readShort();
        short s2 = param1DataInput.readShort();
      } 
    }
    
    public void write(DataOutput param1DataOutput) throws IOException {}
  }
  
  public class LocalVariableTable extends AttInfo {
    private final AttributeInfo this$0;
    
    public LocalVariableTable() {
      super(AttributeInfo.this);
    }
    
    public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
      int i = param1DataInput.readInt();
      short s = param1DataInput.readShort();
      for (byte b = 0; b < s; b++) {
        short s1 = param1DataInput.readShort();
        short s2 = param1DataInput.readShort();
        String str1 = param1ConstantPool.getValue(param1DataInput.readShort());
        if (s1 == 0)
          AttributeInfo.this.addParameterName(str1); 
        String str2 = param1ConstantPool.getValue(param1DataInput.readShort());
        short s3 = param1DataInput.readShort();
      } 
    }
    
    public void write(DataOutput param1DataOutput) throws IOException {}
  }
  
  private AttInfo getAttInfoInstance(Class paramClass) throws IOException {
    try {
      Constructor constructor = paramClass.getConstructor(new Class[] { AttributeInfo.class });
      return (AttInfo)constructor.newInstance(new Object[] { this });
    } catch (InstantiationException instantiationException) {
      throw new IOException("new failed: " + instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new IOException("access failed: " + illegalAccessException.getMessage());
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new IOException("constructor not found: " + noSuchMethodException.getMessage());
    } catch (InvocationTargetException invocationTargetException) {
      throw new IOException("target not found: " + invocationTargetException.getMessage());
    } 
  }
  
  public String getName() { return this.attInfo.getName(); }
  
  public void write(DataOutput paramDataOutput) throws IOException {
    paramDataOutput.writeShort(this.nameIndex);
    this.attInfo.write(paramDataOutput);
  }
  
  public void read(DataInput paramDataInput, ConstantPool paramConstantPool) throws IOException {
    this.nameIndex = paramDataInput.readShort();
    String str = paramConstantPool.getValue(this.nameIndex);
    this.attInfo = new DefaultAttInfo();
    this.attInfo.setName(str);
    this.attInfo.read(paramDataInput, paramConstantPool);
  }
  
  public byte[] getAttributeBytes() {
    if (this.attInfo == null || !(this.attInfo instanceof DefaultAttInfo))
      throw new RuntimeException("attInfo error: " + this.attInfo); 
    return ((DefaultAttInfo)this.attInfo).getBytes();
  }
  
  public void setCustomAttribute(String paramString, short paramShort, byte[] paramArrayOfByte) {
    this.nameIndex = paramShort;
    this.attInfo = new DefaultAttInfo();
    this.attInfo.setName(paramString);
    ((DefaultAttInfo)this.attInfo).setBytes(paramArrayOfByte);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\AttributeInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */