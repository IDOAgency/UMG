/*     */ package weblogic.webservice.util.bytecode;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttributeInfo
/*     */ {
/*  20 */   private static HashMap attInfos = new HashMap(); private AttInfo attInfo;
/*     */   private short nameIndex;
/*     */   private ArrayList parameterNames;
/*     */   
/*     */   static  {
/*  25 */     attInfos.put("SourceFile", SourceFile.class);
/*  26 */     attInfos.put("ConstantValue", ConstantValue.class);
/*  27 */     attInfos.put("Code", Code.class);
/*  28 */     attInfos.put("Exceptions", Exceptions.class);
/*  29 */     attInfos.put("LineNumberTable", LineNumberTable.class);
/*  30 */     attInfos.put("LocalVariableTable", LocalVariableTable.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   public AttributeInfo() { this(null); }
/*     */ 
/*     */   
/*  39 */   public AttributeInfo(ArrayList paramArrayList) { this.parameterNames = paramArrayList; }
/*     */ 
/*     */   
/*     */   private void addParameterName(String paramString) {
/*  43 */     if (this.parameterNames != null) {
/*  44 */       this.parameterNames.add(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  49 */   public String toString() { return "" + this.attInfo; }
/*     */ 
/*     */   
/*     */   public abstract class AttInfo
/*     */   {
/*     */     private String name;
/*     */     
/*     */     private final AttributeInfo this$0;
/*     */ 
/*     */     
/*  59 */     public void setName(String param1String) { this.name = param1String; }
/*     */ 
/*     */ 
/*     */     
/*  63 */     public String getName() { return this.name; }
/*     */     
/*     */     public abstract void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException;
/*     */     
/*     */     public abstract void write(DataOutput param1DataOutput) throws IOException;
/*     */   }
/*     */   
/*     */   public class DefaultAttInfo extends AttInfo {
/*     */     byte[] bytes;
/*     */     private final AttributeInfo this$0;
/*     */     
/*     */     public DefaultAttInfo() {
/*  75 */       super(AttributeInfo.this);
/*     */     }
/*     */ 
/*     */     
/*  79 */     public byte[] getBytes() { return this.bytes; }
/*     */ 
/*     */ 
/*     */     
/*  83 */     public void setBytes(byte[] param1ArrayOfByte) { this.bytes = param1ArrayOfByte; }
/*     */ 
/*     */ 
/*     */     
/*  87 */     public String toString() { return "AttInfo[" + getName() + "] : " + new String(this.bytes); }
/*     */ 
/*     */     
/*     */     public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
/*  91 */       int i = param1DataInput.readInt();
/*  92 */       this.bytes = new byte[i];
/*  93 */       param1DataInput.readFully(this.bytes);
/*     */     }
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/*  97 */       param1DataOutput.writeInt(this.bytes.length);
/*  98 */       param1DataOutput.write(this.bytes);
/*     */     }
/*     */   }
/*     */   
/*     */   public class SourceFile extends AttInfo {
/*     */     private final AttributeInfo this$0;
/*     */     
/*     */     public SourceFile() {
/* 106 */       super(AttributeInfo.this);
/*     */     } public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
/* 108 */       int i = param1DataInput.readInt();
/* 109 */       String str = param1ConstantPool.getValue(param1DataInput.readShort());
/*     */     }
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {} }
/*     */   
/*     */   public class ConstantValue extends AttInfo { private final AttributeInfo this$0;
/*     */     
/*     */     public ConstantValue() {
/* 117 */       super(AttributeInfo.this);
/*     */     } public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
/* 119 */       int i = param1DataInput.readInt();
/* 120 */       String str = param1ConstantPool.getValue(param1DataInput.readShort());
/*     */     }
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {} }
/*     */   
/*     */   public class Code extends AttInfo { private final AttributeInfo this$0;
/*     */     
/*     */     public Code() {
/* 128 */       super(AttributeInfo.this);
/*     */     }
/*     */     public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
/* 131 */       int i = param1DataInput.readInt();
/* 132 */       short s1 = param1DataInput.readShort();
/* 133 */       short s2 = param1DataInput.readShort();
/* 134 */       int j = param1DataInput.readInt();
/*     */       
/* 136 */       byte[] arrayOfByte = new byte[j];
/* 137 */       param1DataInput.readFully(arrayOfByte);
/*     */       
/* 139 */       short s3 = param1DataInput.readShort();
/*     */       short s;
/* 141 */       for (s = 0; s < s3; s++) {
/* 142 */         short s4 = param1DataInput.readShort();
/* 143 */         short s5 = param1DataInput.readShort();
/* 144 */         short s6 = param1DataInput.readShort();
/* 145 */         short s7 = param1DataInput.readShort();
/*     */       } 
/*     */       
/* 148 */       s = param1DataInput.readShort();
/*     */       
/* 150 */       for (byte b = 0; b < s; b++) {
/* 151 */         AttributeInfo attributeInfo = new AttributeInfo(AttributeInfo.this.parameterNames);
/* 152 */         attributeInfo.read(param1DataInput, param1ConstantPool);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {} }
/*     */   
/*     */   public class Exceptions extends AttInfo { private final AttributeInfo this$0;
/*     */     
/*     */     public Exceptions() {
/* 161 */       super(AttributeInfo.this);
/*     */     } public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
/* 163 */       int i = param1DataInput.readInt();
/* 164 */       short s = param1DataInput.readShort();
/*     */       
/* 166 */       for (byte b = 0; b < s; b++)
/* 167 */         String str = param1ConstantPool.getValue(param1DataInput.readShort()); 
/*     */     }
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {} }
/*     */ 
/*     */   
/*     */   public class LineNumberTable extends AttInfo { private final AttributeInfo this$0;
/*     */     
/*     */     public LineNumberTable() {
/* 176 */       super(AttributeInfo.this);
/*     */     } public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
/* 178 */       int i = param1DataInput.readInt();
/* 179 */       short s = param1DataInput.readShort();
/*     */       
/* 181 */       for (byte b = 0; b < s; b++) {
/* 182 */         short s1 = param1DataInput.readShort();
/* 183 */         short s2 = param1DataInput.readShort();
/*     */       } 
/*     */     }
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {} }
/*     */   
/*     */   public class LocalVariableTable extends AttInfo { private final AttributeInfo this$0;
/*     */     
/*     */     public LocalVariableTable() {
/* 192 */       super(AttributeInfo.this);
/*     */     } public void read(DataInput param1DataInput, ConstantPool param1ConstantPool) throws IOException {
/* 194 */       int i = param1DataInput.readInt();
/* 195 */       short s = param1DataInput.readShort();
/*     */       
/* 197 */       for (byte b = 0; b < s; b++) {
/* 198 */         short s1 = param1DataInput.readShort();
/* 199 */         short s2 = param1DataInput.readShort();
/* 200 */         String str1 = param1ConstantPool.getValue(param1DataInput.readShort());
/*     */         
/* 202 */         if (s1 == 0) {
/* 203 */           AttributeInfo.this.addParameterName(str1);
/*     */         }
/*     */         
/* 206 */         String str2 = param1ConstantPool.getValue(param1DataInput.readShort());
/* 207 */         short s3 = param1DataInput.readShort();
/*     */       } 
/*     */     }
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {} }
/*     */ 
/*     */   
/*     */   private AttInfo getAttInfoInstance(Class paramClass) throws IOException {
/*     */     try {
/* 216 */       Constructor constructor = paramClass.getConstructor(new Class[] { AttributeInfo.class });
/*     */ 
/*     */       
/* 219 */       return (AttInfo)constructor.newInstance(new Object[] { this });
/* 220 */     } catch (InstantiationException instantiationException) {
/* 221 */       throw new IOException("new failed: " + instantiationException);
/* 222 */     } catch (IllegalAccessException illegalAccessException) {
/* 223 */       throw new IOException("access failed: " + illegalAccessException.getMessage());
/* 224 */     } catch (NoSuchMethodException noSuchMethodException) {
/* 225 */       throw new IOException("constructor not found: " + noSuchMethodException.getMessage());
/* 226 */     } catch (InvocationTargetException invocationTargetException) {
/* 227 */       throw new IOException("target not found: " + invocationTargetException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 232 */   public String getName() { return this.attInfo.getName(); }
/*     */ 
/*     */   
/*     */   public void write(DataOutput paramDataOutput) throws IOException {
/* 236 */     paramDataOutput.writeShort(this.nameIndex);
/* 237 */     this.attInfo.write(paramDataOutput);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(DataInput paramDataInput, ConstantPool paramConstantPool) throws IOException {
/* 243 */     this.nameIndex = paramDataInput.readShort();
/* 244 */     String str = paramConstantPool.getValue(this.nameIndex);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     this.attInfo = new DefaultAttInfo();
/* 251 */     this.attInfo.setName(str);
/* 252 */     this.attInfo.read(paramDataInput, paramConstantPool);
/*     */   }
/*     */   
/*     */   public byte[] getAttributeBytes() {
/* 256 */     if (this.attInfo == null || !(this.attInfo instanceof DefaultAttInfo)) {
/* 257 */       throw new RuntimeException("attInfo error: " + this.attInfo);
/*     */     }
/* 259 */     return ((DefaultAttInfo)this.attInfo).getBytes();
/*     */   }
/*     */   
/*     */   public void setCustomAttribute(String paramString, short paramShort, byte[] paramArrayOfByte) {
/* 263 */     this.nameIndex = paramShort;
/*     */     
/* 265 */     this.attInfo = new DefaultAttInfo();
/* 266 */     this.attInfo.setName(paramString);
/* 267 */     ((DefaultAttInfo)this.attInfo).setBytes(paramArrayOfByte);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\AttributeInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */