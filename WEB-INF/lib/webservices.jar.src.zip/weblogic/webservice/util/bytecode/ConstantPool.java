/*     */ package weblogic.webservice.util.bytecode;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstantPool
/*     */ {
/*  19 */   static HashMap cpInfos = new HashMap(); private int constantPoolCount;
/*     */   
/*     */   static  {
/*  22 */     cpInfos.put(new Byte((byte)7), ConstantClassInfo.class);
/*  23 */     cpInfos.put(new Byte((byte)9), ConstantRefInfo.class);
/*  24 */     cpInfos.put(new Byte((byte)10), ConstantRefInfo.class);
/*  25 */     cpInfos.put(new Byte((byte)11), ConstantRefInfo.class);
/*  26 */     cpInfos.put(new Byte((byte)8), ConstantStringInfo.class);
/*  27 */     cpInfos.put(new Byte((byte)3), ConstantIntFloatInfo.class);
/*  28 */     cpInfos.put(new Byte((byte)4), ConstantIntFloatInfo.class);
/*  29 */     cpInfos.put(new Byte((byte)6), ConstantDoubleInfo.class);
/*  30 */     cpInfos.put(new Byte((byte)5), ConstantLongInfo.class);
/*  31 */     cpInfos.put(new Byte((byte)12), ConstantNameTypeInfo.class);
/*  32 */     cpInfos.put(new Byte((byte)1), ConstantUtf8Info.class);
/*     */   }
/*     */   
/*     */   private ArrayList cpInfoInstances;
/*     */   
/*     */   public abstract class CpInfo
/*     */   {
/*     */     private byte tag;
/*     */     private final ConstantPool this$0;
/*     */     
/*  42 */     public void setTag(byte param1Byte) { this.tag = param1Byte; }
/*     */ 
/*     */     
/*     */     public abstract void read(DataInput param1DataInput) throws IOException;
/*     */ 
/*     */     
/*  48 */     public void write(DataOutput param1DataOutput) throws IOException { param1DataOutput.writeByte(this.tag); }
/*     */   }
/*     */   
/*     */   public class ConstantClassInfo extends CpInfo { short nameIndex;
/*     */     private final ConstantPool this$0;
/*     */     
/*     */     public ConstantClassInfo() {
/*  55 */       super(ConstantPool.this);
/*     */     }
/*     */ 
/*     */     
/*  59 */     public short getIndex() { return this.nameIndex; }
/*     */ 
/*     */ 
/*     */     
/*  63 */     public void read(DataInput param1DataInput) throws IOException { this.nameIndex = param1DataInput.readShort(); }
/*     */ 
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/*  67 */       super.write(param1DataOutput);
/*  68 */       param1DataOutput.writeShort(this.nameIndex);
/*     */     }
/*     */ 
/*     */     
/*  72 */     public String toString() { return "class_info: " + ConstantPool.this.getValue(this.nameIndex); } }
/*     */ 
/*     */   
/*     */   public class ConstantRefInfo extends CpInfo {
/*     */     short classIndex;
/*     */     
/*     */     public ConstantRefInfo() {
/*  79 */       super(ConstantPool.this);
/*     */     }
/*     */     short nameAndTypeIndex; private final ConstantPool this$0;
/*     */     
/*     */     public void read(DataInput param1DataInput) throws IOException {
/*  84 */       this.classIndex = param1DataInput.readShort();
/*  85 */       this.nameAndTypeIndex = param1DataInput.readShort();
/*     */     }
/*     */ 
/*     */     
/*  89 */     public short getNameAndTypeIndex() { return this.nameAndTypeIndex; }
/*     */ 
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/*  93 */       super.write(param1DataOutput);
/*  94 */       param1DataOutput.writeShort(this.classIndex);
/*  95 */       param1DataOutput.writeShort(this.nameAndTypeIndex);
/*     */     }
/*     */ 
/*     */     
/*  99 */     public String toString() { return "ref_info:" + ConstantPool.this.getValue(this.classIndex) + "," + ConstantPool.this.getValue(this.nameAndTypeIndex); }
/*     */   }
/*     */   
/*     */   public class ConstantStringInfo
/*     */     extends CpInfo {
/*     */     short stringIndex;
/*     */     private final ConstantPool this$0;
/*     */     
/*     */     public ConstantStringInfo() {
/* 108 */       super(ConstantPool.this);
/*     */     }
/*     */ 
/*     */     
/* 112 */     public void read(DataInput param1DataInput) throws IOException { this.stringIndex = param1DataInput.readShort(); }
/*     */ 
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/* 116 */       super.write(param1DataOutput);
/* 117 */       param1DataOutput.writeShort(this.stringIndex);
/*     */     }
/*     */ 
/*     */     
/* 121 */     public String toString() { return "String_info:" + ConstantPool.this.getValue(this.stringIndex); }
/*     */   }
/*     */   
/*     */   public class ConstantIntFloatInfo extends CpInfo { int value;
/*     */     private final ConstantPool this$0;
/*     */     
/*     */     public ConstantIntFloatInfo() {
/* 128 */       super(ConstantPool.this);
/*     */     }
/*     */ 
/*     */     
/* 132 */     public void read(DataInput param1DataInput) throws IOException { this.value = param1DataInput.readInt(); }
/*     */ 
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/* 136 */       super.write(param1DataOutput);
/* 137 */       param1DataOutput.writeInt(this.value);
/*     */     }
/*     */ 
/*     */     
/* 141 */     public String toString() { return "float_int_info:" + this.value; } }
/*     */   
/*     */   public class ConstantLongInfo extends CpInfo {
/*     */     long value;
/*     */     private final ConstantPool this$0;
/*     */     
/*     */     public ConstantLongInfo() {
/* 148 */       super(ConstantPool.this);
/*     */     }
/*     */ 
/*     */     
/* 152 */     public void read(DataInput param1DataInput) throws IOException { this.value = param1DataInput.readLong(); }
/*     */ 
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/* 156 */       super.write(param1DataOutput);
/* 157 */       param1DataOutput.writeLong(this.value);
/*     */     }
/*     */ 
/*     */     
/* 161 */     public String toString() { return "long_info:" + this.value; }
/*     */   }
/*     */   
/*     */   public class ConstantDoubleInfo extends CpInfo { double value;
/*     */     private final ConstantPool this$0;
/*     */     
/*     */     public ConstantDoubleInfo() {
/* 168 */       super(ConstantPool.this);
/*     */     }
/*     */ 
/*     */     
/* 172 */     public void read(DataInput param1DataInput) throws IOException { this.value = param1DataInput.readDouble(); }
/*     */ 
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/* 176 */       super.write(param1DataOutput);
/* 177 */       param1DataOutput.writeDouble(this.value);
/*     */     }
/*     */ 
/*     */     
/* 181 */     public String toString() { return "double_info:" + this.value; } }
/*     */   
/*     */   public class ConstantNameTypeInfo extends CpInfo { short nameIndex;
/*     */     short descriptorIndex;
/*     */     private final ConstantPool this$0;
/*     */     
/*     */     public ConstantNameTypeInfo() {
/* 188 */       super(ConstantPool.this);
/*     */     }
/*     */ 
/*     */     
/*     */     public void read(DataInput param1DataInput) throws IOException {
/* 193 */       this.nameIndex = param1DataInput.readShort();
/* 194 */       this.descriptorIndex = param1DataInput.readShort();
/*     */     }
/*     */ 
/*     */     
/* 198 */     public short getDescriptorIndex() { return this.descriptorIndex; }
/*     */ 
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/* 202 */       super.write(param1DataOutput);
/* 203 */       param1DataOutput.writeShort(this.nameIndex);
/* 204 */       param1DataOutput.writeShort(this.descriptorIndex);
/*     */     }
/*     */ 
/*     */     
/* 208 */     public String toString() { return "name_type_info:" + ConstantPool.this.getValue(this.nameIndex) + "," + ConstantPool.this.getValue(this.descriptorIndex); } }
/*     */ 
/*     */   
/*     */   public class ConstantUtf8Info extends CpInfo {
/*     */     private String string;
/*     */     private final ConstantPool this$0;
/*     */     
/*     */     public ConstantUtf8Info() {
/* 216 */       super(ConstantPool.this);
/*     */     }
/*     */ 
/*     */     
/* 220 */     public void setString(String param1String) { this.string = param1String; }
/*     */ 
/*     */ 
/*     */     
/* 224 */     public String getString() { return this.string; }
/*     */ 
/*     */ 
/*     */     
/* 228 */     public void read(DataInput param1DataInput) throws IOException { this.string = param1DataInput.readUTF(); }
/*     */ 
/*     */     
/*     */     public void write(DataOutput param1DataOutput) throws IOException {
/* 232 */       super.write(param1DataOutput);
/* 233 */       param1DataOutput.writeUTF(this.string);
/*     */     }
/*     */ 
/*     */     
/* 237 */     public String toString() { return "utf-8: " + this.string; }
/*     */   }
/*     */ 
/*     */   
/*     */   public ConstantPool() {
/* 242 */     this.cpInfoInstances = new ArrayList();
/*     */ 
/*     */ 
/*     */     
/* 246 */     this.cpInfoInstances.add(Object.class);
/*     */   }
/*     */ 
/*     */   
/* 250 */   public String getValue(int paramInt) { return this.cpInfoInstances.get(paramInt).toString(); }
/*     */ 
/*     */ 
/*     */   
/* 254 */   public Iterator getConstants() { return this.cpInfoInstances.iterator(); }
/*     */ 
/*     */ 
/*     */   
/* 258 */   public CpInfo getConstant(int paramInt) { return (CpInfo)this.cpInfoInstances.get(paramInt); }
/*     */ 
/*     */   
/*     */   public short addUtf8Constant(String paramString) {
/* 262 */     ConstantUtf8Info constantUtf8Info = new ConstantUtf8Info();
/* 263 */     constantUtf8Info.setTag((byte)1);
/* 264 */     constantUtf8Info.setString(paramString);
/* 265 */     this.cpInfoInstances.add(constantUtf8Info);
/* 266 */     return (short)(this.cpInfoInstances.size() - 1);
/*     */   }
/*     */ 
/*     */   
/*     */   private CpInfo getCpInfoInstance(Class paramClass) throws IOException {
/*     */     try {
/* 272 */       Constructor constructor = paramClass.getConstructor(new Class[] { ConstantPool.class });
/*     */ 
/*     */       
/* 275 */       return (CpInfo)constructor.newInstance(new Object[] { this });
/* 276 */     } catch (InstantiationException instantiationException) {
/* 277 */       throw new IOException("new failed: " + instantiationException);
/* 278 */     } catch (IllegalAccessException illegalAccessException) {
/* 279 */       throw new IOException("access failed: " + illegalAccessException.getMessage());
/* 280 */     } catch (NoSuchMethodException noSuchMethodException) {
/* 281 */       throw new IOException("constructor not found: " + noSuchMethodException.getMessage());
/* 282 */     } catch (InvocationTargetException invocationTargetException) {
/* 283 */       throw new IOException("target not found: " + invocationTargetException.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write(DataOutput paramDataOutput) throws IOException {
/* 288 */     paramDataOutput.writeShort(this.constantPoolCount);
/*     */     
/* 290 */     Iterator iterator = this.cpInfoInstances.iterator();
/* 291 */     iterator.next();
/*     */     
/* 293 */     while (iterator.hasNext()) {
/* 294 */       CpInfo cpInfo = (CpInfo)iterator.next();
/* 295 */       if (cpInfo != null) {
/* 296 */         cpInfo.write(paramDataOutput);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void read(DataInput paramDataInput) throws IOException {
/* 302 */     this.constantPoolCount = paramDataInput.readUnsignedShort();
/*     */     
/* 304 */     for (byte b = 0; b < this.constantPoolCount - 1; b++) {
/* 305 */       Byte byte = new Byte(paramDataInput.readByte());
/* 306 */       Class clazz = (Class)cpInfos.get(byte);
/* 307 */       CpInfo cpInfo = getCpInfoInstance(clazz);
/* 308 */       cpInfo.read(paramDataInput);
/* 309 */       cpInfo.setTag(byte.byteValue());
/* 310 */       this.cpInfoInstances.add(cpInfo);
/*     */       
/* 312 */       if (cpInfo instanceof ConstantDoubleInfo || cpInfo instanceof ConstantLongInfo) {
/*     */         
/* 314 */         b++;
/* 315 */         this.cpInfoInstances.add(null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public String toString() {
/* 321 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 323 */     byte b = 1;
/* 324 */     for (Iterator iterator = this.cpInfoInstances.iterator(); iterator.hasNext(); ) {
/* 325 */       stringBuffer.append("\n: " + b + " ").append(iterator.next());
/* 326 */       b++;
/*     */     } 
/*     */     
/* 329 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\ConstantPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */