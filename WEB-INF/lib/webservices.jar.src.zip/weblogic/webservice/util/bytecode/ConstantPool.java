package weblogic.webservice.util.bytecode;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class ConstantPool {
  static HashMap cpInfos = new HashMap();
  
  private int constantPoolCount;
  
  private ArrayList cpInfoInstances;
  
  static  {
    cpInfos.put(new Byte((byte)7), ConstantClassInfo.class);
    cpInfos.put(new Byte((byte)9), ConstantRefInfo.class);
    cpInfos.put(new Byte((byte)10), ConstantRefInfo.class);
    cpInfos.put(new Byte((byte)11), ConstantRefInfo.class);
    cpInfos.put(new Byte((byte)8), ConstantStringInfo.class);
    cpInfos.put(new Byte((byte)3), ConstantIntFloatInfo.class);
    cpInfos.put(new Byte((byte)4), ConstantIntFloatInfo.class);
    cpInfos.put(new Byte((byte)6), ConstantDoubleInfo.class);
    cpInfos.put(new Byte((byte)5), ConstantLongInfo.class);
    cpInfos.put(new Byte((byte)12), ConstantNameTypeInfo.class);
    cpInfos.put(new Byte((byte)1), ConstantUtf8Info.class);
  }
  
  public abstract class CpInfo {
    private byte tag;
    
    private final ConstantPool this$0;
    
    public void setTag(byte param1Byte) { this.tag = param1Byte; }
    
    public abstract void read(DataInput param1DataInput) throws IOException;
    
    public void write(DataOutput param1DataOutput) throws IOException { param1DataOutput.writeByte(this.tag); }
  }
  
  public class ConstantClassInfo extends CpInfo {
    short nameIndex;
    
    private final ConstantPool this$0;
    
    public ConstantClassInfo() {
      super(ConstantPool.this);
    }
    
    public short getIndex() { return this.nameIndex; }
    
    public void read(DataInput param1DataInput) throws IOException { this.nameIndex = param1DataInput.readShort(); }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      super.write(param1DataOutput);
      param1DataOutput.writeShort(this.nameIndex);
    }
    
    public String toString() { return "class_info: " + ConstantPool.this.getValue(this.nameIndex); }
  }
  
  public class ConstantRefInfo extends CpInfo {
    short classIndex;
    
    short nameAndTypeIndex;
    
    private final ConstantPool this$0;
    
    public ConstantRefInfo() {
      super(ConstantPool.this);
    }
    
    public void read(DataInput param1DataInput) throws IOException {
      this.classIndex = param1DataInput.readShort();
      this.nameAndTypeIndex = param1DataInput.readShort();
    }
    
    public short getNameAndTypeIndex() { return this.nameAndTypeIndex; }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      super.write(param1DataOutput);
      param1DataOutput.writeShort(this.classIndex);
      param1DataOutput.writeShort(this.nameAndTypeIndex);
    }
    
    public String toString() { return "ref_info:" + ConstantPool.this.getValue(this.classIndex) + "," + ConstantPool.this.getValue(this.nameAndTypeIndex); }
  }
  
  public class ConstantStringInfo extends CpInfo {
    short stringIndex;
    
    private final ConstantPool this$0;
    
    public ConstantStringInfo() {
      super(ConstantPool.this);
    }
    
    public void read(DataInput param1DataInput) throws IOException { this.stringIndex = param1DataInput.readShort(); }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      super.write(param1DataOutput);
      param1DataOutput.writeShort(this.stringIndex);
    }
    
    public String toString() { return "String_info:" + ConstantPool.this.getValue(this.stringIndex); }
  }
  
  public class ConstantIntFloatInfo extends CpInfo {
    int value;
    
    private final ConstantPool this$0;
    
    public ConstantIntFloatInfo() {
      super(ConstantPool.this);
    }
    
    public void read(DataInput param1DataInput) throws IOException { this.value = param1DataInput.readInt(); }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      super.write(param1DataOutput);
      param1DataOutput.writeInt(this.value);
    }
    
    public String toString() { return "float_int_info:" + this.value; }
  }
  
  public class ConstantLongInfo extends CpInfo {
    long value;
    
    private final ConstantPool this$0;
    
    public ConstantLongInfo() {
      super(ConstantPool.this);
    }
    
    public void read(DataInput param1DataInput) throws IOException { this.value = param1DataInput.readLong(); }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      super.write(param1DataOutput);
      param1DataOutput.writeLong(this.value);
    }
    
    public String toString() { return "long_info:" + this.value; }
  }
  
  public class ConstantDoubleInfo extends CpInfo {
    double value;
    
    private final ConstantPool this$0;
    
    public ConstantDoubleInfo() {
      super(ConstantPool.this);
    }
    
    public void read(DataInput param1DataInput) throws IOException { this.value = param1DataInput.readDouble(); }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      super.write(param1DataOutput);
      param1DataOutput.writeDouble(this.value);
    }
    
    public String toString() { return "double_info:" + this.value; }
  }
  
  public class ConstantNameTypeInfo extends CpInfo {
    short nameIndex;
    
    short descriptorIndex;
    
    private final ConstantPool this$0;
    
    public ConstantNameTypeInfo() {
      super(ConstantPool.this);
    }
    
    public void read(DataInput param1DataInput) throws IOException {
      this.nameIndex = param1DataInput.readShort();
      this.descriptorIndex = param1DataInput.readShort();
    }
    
    public short getDescriptorIndex() { return this.descriptorIndex; }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      super.write(param1DataOutput);
      param1DataOutput.writeShort(this.nameIndex);
      param1DataOutput.writeShort(this.descriptorIndex);
    }
    
    public String toString() { return "name_type_info:" + ConstantPool.this.getValue(this.nameIndex) + "," + ConstantPool.this.getValue(this.descriptorIndex); }
  }
  
  public class ConstantUtf8Info extends CpInfo {
    private String string;
    
    private final ConstantPool this$0;
    
    public ConstantUtf8Info() {
      super(ConstantPool.this);
    }
    
    public void setString(String param1String) { this.string = param1String; }
    
    public String getString() { return this.string; }
    
    public void read(DataInput param1DataInput) throws IOException { this.string = param1DataInput.readUTF(); }
    
    public void write(DataOutput param1DataOutput) throws IOException {
      super.write(param1DataOutput);
      param1DataOutput.writeUTF(this.string);
    }
    
    public String toString() { return "utf-8: " + this.string; }
  }
  
  public ConstantPool() {
    this.cpInfoInstances = new ArrayList();
    this.cpInfoInstances.add(Object.class);
  }
  
  public String getValue(int paramInt) { return this.cpInfoInstances.get(paramInt).toString(); }
  
  public Iterator getConstants() { return this.cpInfoInstances.iterator(); }
  
  public CpInfo getConstant(int paramInt) { return (CpInfo)this.cpInfoInstances.get(paramInt); }
  
  public short addUtf8Constant(String paramString) {
    ConstantUtf8Info constantUtf8Info = new ConstantUtf8Info();
    constantUtf8Info.setTag((byte)1);
    constantUtf8Info.setString(paramString);
    this.cpInfoInstances.add(constantUtf8Info);
    return (short)(this.cpInfoInstances.size() - 1);
  }
  
  private CpInfo getCpInfoInstance(Class paramClass) throws IOException {
    try {
      Constructor constructor = paramClass.getConstructor(new Class[] { ConstantPool.class });
      return (CpInfo)constructor.newInstance(new Object[] { this });
    } catch (InstantiationException instantiationException) {
      throw new IOException("new failed: " + instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new IOException("access failed: " + illegalAccessException.getMessage());
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new IOException("constructor not found: " + noSuchMethodException.getMessage());
    } catch (InvocationTargetException invocationTargetException) {
      throw new IOException("target not found: " + invocationTargetException.getMessage());
    } 
  }
  
  public void write(DataOutput paramDataOutput) throws IOException {
    paramDataOutput.writeShort(this.constantPoolCount);
    Iterator iterator = this.cpInfoInstances.iterator();
    iterator.next();
    while (iterator.hasNext()) {
      CpInfo cpInfo = (CpInfo)iterator.next();
      if (cpInfo != null)
        cpInfo.write(paramDataOutput); 
    } 
  }
  
  public void read(DataInput paramDataInput) throws IOException {
    this.constantPoolCount = paramDataInput.readUnsignedShort();
    for (byte b = 0; b < this.constantPoolCount - 1; b++) {
      Byte byte = new Byte(paramDataInput.readByte());
      Class clazz = (Class)cpInfos.get(byte);
      CpInfo cpInfo = getCpInfoInstance(clazz);
      cpInfo.read(paramDataInput);
      cpInfo.setTag(byte.byteValue());
      this.cpInfoInstances.add(cpInfo);
      if (cpInfo instanceof ConstantDoubleInfo || cpInfo instanceof ConstantLongInfo) {
        b++;
        this.cpInfoInstances.add(null);
      } 
    } 
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    byte b = 1;
    for (Iterator iterator = this.cpInfoInstances.iterator(); iterator.hasNext(); ) {
      stringBuffer.append("\n: " + b + " ").append(iterator.next());
      b++;
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\bytecode\ConstantPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */