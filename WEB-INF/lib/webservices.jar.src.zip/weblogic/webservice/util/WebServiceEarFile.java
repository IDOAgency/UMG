package weblogic.webservice.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import weblogic.j2ee.J2EEUtils;
import weblogic.j2ee.dd.EJBModuleDescriptor;
import weblogic.j2ee.dd.J2EEDeploymentDescriptor;
import weblogic.j2ee.dd.WebModuleDescriptor;
import weblogic.j2ee.dd.xml.DDUtils;
import weblogic.j2ee.dd.xml.J2EEDeploymentDescriptorLoader;
import weblogic.management.descriptors.application.J2EEApplicationDescriptorMBean;
import weblogic.management.descriptors.application.ModuleMBean;
import weblogic.management.descriptors.application.SecurityRoleMBean;
import weblogic.management.descriptors.application.WebModuleMBean;
import weblogic.utils.jars.VirtualJarFile;
import weblogic.xml.process.ProcessorFactory;
import weblogic.xml.process.ProcessorFactoryException;
import weblogic.xml.process.XMLParsingException;
import weblogic.xml.process.XMLProcessingException;

public class WebServiceEarFile extends WebServiceJarFile {
  private static final String APP_DD = "META-INF/application.xml";
  
  private static final boolean debug = false;
  
  private WebServiceWarFile wsWar;
  
  private File wsWarFile;
  
  private Map ejbMap;
  
  private J2EEApplicationDescriptorMBean appDD;
  
  private String warName;
  
  private String contextURI;
  
  private File tmpDir;
  
  public WebServiceEarFile(File paramFile1, File paramFile2, String paramString) throws IOException, WebServiceJarException {
    super(paramFile1, paramFile2);
    this.tmpDir = paramFile1;
    this.wsWarFile = new File(getExploded(), paramString);
    this.warName = paramString;
    this.contextURI = paramString;
    this.appDD = new J2EEDeploymentDescriptor();
    this.ejbMap = new HashMap();
    readDD();
  }
  
  public void setContextURI(String paramString) { this.contextURI = paramString; }
  
  public String getContextURI() { return this.contextURI; }
  
  public WebServiceWarFile getWSWar() throws IOException {
    if (this.wsWar == null)
      this.wsWar = new WebServiceWarFile(this.tmpDir, this.wsWarFile, this); 
    return this.wsWar;
  }
  
  public File getWSWarFile() { return this.wsWarFile; }
  
  public Map getEJBJars() { return this.ejbMap; }
  
  public J2EEApplicationDescriptorMBean getAppDD() { return this.appDD; }
  
  public String toString() { return "WebServiceEarFile[" + super.toString() + "]"; }
  
  public void remove() throws IOException {
    if (this.wsWar != null)
      this.wsWar.remove(); 
    super.remove();
  }
  
  public void createAppDescriptor(Set paramSet) throws IOException {
    if (this.appDD == null)
      this.appDD = new J2EEDeploymentDescriptor(); 
    ModuleMBean[] arrayOfModuleMBean1 = this.appDD.getModules();
    ModuleMBean[] arrayOfModuleMBean2 = new ModuleMBean[paramSet.size() + 1];
    arrayOfModuleMBean2[0] = new WebModuleDescriptor(this.warName, this.contextURI);
    byte b = 1;
    HashSet hashSet = new HashSet();
    for (File file : paramSet) {
      arrayOfModuleMBean2[b] = new EJBModuleDescriptor(file.getName());
      b++;
    } 
    if (arrayOfModuleMBean1 != null)
      arrayOfModuleMBean2 = mergeModules(arrayOfModuleMBean1, arrayOfModuleMBean2); 
    this.appDD.setModules(arrayOfModuleMBean2);
    writeDD();
  }
  
  private void init(J2EEApplicationDescriptorMBean paramJ2EEApplicationDescriptorMBean) throws WebServiceJarException {
    this.ejbMap = new HashMap();
    if (paramJ2EEApplicationDescriptorMBean == null)
      return; 
    File file = getExploded();
    ModuleMBean[] arrayOfModuleMBean = paramJ2EEApplicationDescriptorMBean.getEJBModules();
    if (arrayOfModuleMBean != null)
      for (byte b = 0; b < arrayOfModuleMBean.length; b++) {
        String str = arrayOfModuleMBean[b].getModuleURI();
        File file1 = new File(file, str);
        if (!file1.exists())
          throw new WebServiceJarException("Could not locate ejb-jar with URI " + str + " in EAR file"); 
        VirtualJarFile virtualJarFile = null;
      }  
    arrayOfModuleMBean = paramJ2EEApplicationDescriptorMBean.getWebModules();
    if (arrayOfModuleMBean != null)
      for (byte b = 0; b < arrayOfModuleMBean.length; b++) {
        String str = ((WebModuleMBean)arrayOfModuleMBean[b]).getModuleURI();
        if (this.warName.equals(str)) {
          String str1 = ((WebModuleMBean)arrayOfModuleMBean[b]).getContextRoot();
          if (str1 != null)
            this.contextURI = str1; 
          break;
        } 
      }  
  }
  
  private void readDD() throws IOException {
    ZipEntry zipEntry = getVirtualJarFile().getEntry("/META-INF/application.xml");
    if (zipEntry == null)
      return; 
    inputStream = getVirtualJarFile().getInputStream(zipEntry);
    J2EEDeploymentDescriptorLoader j2EEDeploymentDescriptorLoader = null;
    if (!inputStream.markSupported())
      inputStream = new BufferedInputStream(inputStream); 
    try {
      inputStream.mark(1024);
      ProcessorFactory processorFactory = new ProcessorFactory();
      j2EEDeploymentDescriptorLoader = (J2EEDeploymentDescriptorLoader)processorFactory.getProcessor(inputStream, DDUtils.validPublicIds);
      inputStream.reset();
      this.appDD = new J2EEDeploymentDescriptor();
      j2EEDeploymentDescriptorLoader.setDD(this.appDD);
      j2EEDeploymentDescriptorLoader.process(inputStream);
    } catch (ProcessorFactoryException processorFactoryException) {
      throw new WebServiceJarException("Could not process J2EE deployment descriptor", processorFactoryException);
    } catch (IOException iOException) {
      throw new WebServiceJarException("Could not process J2EE deployment descriptor", iOException);
    } catch (XMLParsingException xMLParsingException) {
      throw new WebServiceJarException("Could not process J2EE deployment descriptor", xMLParsingException);
    } catch (XMLProcessingException xMLProcessingException) {
      throw new WebServiceJarException("Could not process J2EE deployment descriptor", xMLProcessingException);
    } finally {
      if (inputStream != null)
        inputStream.close(); 
    } 
    init(j2EEDeploymentDescriptorLoader.getDD());
  }
  
  private void writeDD() throws IOException {
    File file = new File(getExploded(), "META-INF/application.xml");
    file.getParentFile().mkdirs();
    FileOutputStream fileOutputStream = new FileOutputStream(file);
    PrintStream printStream = new PrintStream(fileOutputStream);
    printStream.print(((J2EEDeploymentDescriptor)this.appDD).toXML());
    printStream.close();
  }
  
  public static J2EEApplicationDescriptorMBean mergeAppDescriptors(J2EEApplicationDescriptorMBean paramJ2EEApplicationDescriptorMBean1, J2EEApplicationDescriptorMBean paramJ2EEApplicationDescriptorMBean2) {
    paramJ2EEApplicationDescriptorMBean2.setDescription(paramJ2EEApplicationDescriptorMBean1.getDescription());
    paramJ2EEApplicationDescriptorMBean2.setDisplayName(paramJ2EEApplicationDescriptorMBean1.getDisplayName());
    paramJ2EEApplicationDescriptorMBean2.setSmallIconFileName(paramJ2EEApplicationDescriptorMBean1.getSmallIconFileName());
    paramJ2EEApplicationDescriptorMBean2.setLargeIconFileName(paramJ2EEApplicationDescriptorMBean1.getLargeIconFileName());
    mergeSecurityRoles(paramJ2EEApplicationDescriptorMBean1.getSecurityRoles(), paramJ2EEApplicationDescriptorMBean2.getSecurityRoles());
    mergeModules(paramJ2EEApplicationDescriptorMBean1.getModules(), paramJ2EEApplicationDescriptorMBean2.getModules());
    return paramJ2EEApplicationDescriptorMBean2;
  }
  
  public static SecurityRoleMBean[] mergeSecurityRoles(SecurityRoleMBean[] paramArrayOfSecurityRoleMBean1, SecurityRoleMBean[] paramArrayOfSecurityRoleMBean2) {
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfSecurityRoleMBean1));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfSecurityRoleMBean2));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext()) {
      SecurityRoleMBean securityRoleMBean = (SecurityRoleMBean)listIterator.next();
      ListIterator listIterator1 = arrayList2.listIterator();
      while (listIterator1.hasNext()) {
        SecurityRoleMBean securityRoleMBean1 = (SecurityRoleMBean)listIterator1.next();
        if (nullableEquals(securityRoleMBean.getRoleName(), securityRoleMBean1.getRoleName())) {
          listIterator1.remove();
          break;
        } 
      } 
      arrayList2.add(securityRoleMBean);
      listIterator.remove();
    } 
    return (SecurityRoleMBean[])arrayList2.toArray(new SecurityRoleMBean[0]);
  }
  
  public static ModuleMBean[] mergeModules(ModuleMBean[] paramArrayOfModuleMBean1, ModuleMBean[] paramArrayOfModuleMBean2) {
    ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfModuleMBean1));
    ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfModuleMBean2));
    ListIterator listIterator = arrayList1.listIterator();
    while (listIterator.hasNext()) {
      ModuleMBean moduleMBean = (ModuleMBean)listIterator.next();
      ListIterator listIterator1 = arrayList2.listIterator();
      while (listIterator1.hasNext()) {
        ModuleMBean moduleMBean1 = (ModuleMBean)listIterator1.next();
        if (nullableEquals(moduleMBean.getModuleURI(), moduleMBean1.getModuleURI())) {
          listIterator1.remove();
          break;
        } 
      } 
      arrayList2.add(moduleMBean);
      listIterator.remove();
    } 
    return (ModuleMBean[])arrayList2.toArray(new ModuleMBean[0]);
  }
  
  public String getApplicationClasspath() {
    StringBuffer stringBuffer = new StringBuffer();
    J2EEUtils.addAppInfToClasspath(stringBuffer, getExploded());
    Set set = this.ejbMap.keySet();
    for (Iterator iterator = set.iterator(); iterator.hasNext(); ) {
      File file = new File(getExploded(), (String)iterator.next());
      stringBuffer.append(file.getAbsolutePath());
      stringBuffer.append(File.pathSeparator);
    } 
    return stringBuffer.toString();
  }
  
  private static boolean nullableEquals(Object paramObject1, Object paramObject2) {
    if (paramObject1 != null)
      return paramObject1.equals(paramObject2); 
    return (paramObject2 == null);
  }
  
  public void save() throws IOException {
    writeDD();
    super.save();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceEarFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */