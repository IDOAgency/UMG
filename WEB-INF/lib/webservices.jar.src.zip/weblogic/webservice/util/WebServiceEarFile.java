/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.zip.ZipEntry;
/*     */ import weblogic.j2ee.J2EEUtils;
/*     */ import weblogic.j2ee.dd.EJBModuleDescriptor;
/*     */ import weblogic.j2ee.dd.J2EEDeploymentDescriptor;
/*     */ import weblogic.j2ee.dd.WebModuleDescriptor;
/*     */ import weblogic.j2ee.dd.xml.DDUtils;
/*     */ import weblogic.j2ee.dd.xml.J2EEDeploymentDescriptorLoader;
/*     */ import weblogic.management.descriptors.application.J2EEApplicationDescriptorMBean;
/*     */ import weblogic.management.descriptors.application.ModuleMBean;
/*     */ import weblogic.management.descriptors.application.SecurityRoleMBean;
/*     */ import weblogic.management.descriptors.application.WebModuleMBean;
/*     */ import weblogic.utils.jars.VirtualJarFile;
/*     */ import weblogic.xml.process.ProcessorFactory;
/*     */ import weblogic.xml.process.ProcessorFactoryException;
/*     */ import weblogic.xml.process.XMLParsingException;
/*     */ import weblogic.xml.process.XMLProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServiceEarFile
/*     */   extends WebServiceJarFile
/*     */ {
/*     */   private static final String APP_DD = "META-INF/application.xml";
/*     */   private static final boolean debug = false;
/*     */   private WebServiceWarFile wsWar;
/*     */   private File wsWarFile;
/*     */   private Map ejbMap;
/*     */   private J2EEApplicationDescriptorMBean appDD;
/*     */   private String warName;
/*     */   private String contextURI;
/*     */   private File tmpDir;
/*     */   
/*     */   public WebServiceEarFile(File paramFile1, File paramFile2, String paramString) throws IOException, WebServiceJarException {
/*  68 */     super(paramFile1, paramFile2);
/*  69 */     this.tmpDir = paramFile1;
/*  70 */     this.wsWarFile = new File(getExploded(), paramString);
/*  71 */     this.warName = paramString;
/*  72 */     this.contextURI = paramString;
/*     */     
/*  74 */     this.appDD = new J2EEDeploymentDescriptor();
/*  75 */     this.ejbMap = new HashMap();
/*     */     
/*  77 */     readDD();
/*     */   }
/*     */ 
/*     */   
/*  81 */   public void setContextURI(String paramString) { this.contextURI = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public String getContextURI() { return this.contextURI; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceWarFile getWSWar() throws IOException {
/*  92 */     if (this.wsWar == null) {
/*  93 */       this.wsWar = new WebServiceWarFile(this.tmpDir, this.wsWarFile, this);
/*     */     }
/*  95 */     return this.wsWar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public File getWSWarFile() { return this.wsWarFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public Map getEJBJars() { return this.ejbMap; }
/*     */ 
/*     */ 
/*     */   
/* 112 */   public J2EEApplicationDescriptorMBean getAppDD() { return this.appDD; }
/*     */ 
/*     */ 
/*     */   
/* 116 */   public String toString() { return "WebServiceEarFile[" + super.toString() + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() throws IOException {
/* 123 */     if (this.wsWar != null) this.wsWar.remove(); 
/* 124 */     super.remove();
/*     */   }
/*     */   
/*     */   public void createAppDescriptor(Set paramSet) throws IOException {
/* 128 */     if (this.appDD == null) {
/* 129 */       this.appDD = new J2EEDeploymentDescriptor();
/*     */     }
/*     */     
/* 132 */     ModuleMBean[] arrayOfModuleMBean1 = this.appDD.getModules();
/*     */     
/* 134 */     ModuleMBean[] arrayOfModuleMBean2 = new ModuleMBean[paramSet.size() + 1];
/*     */     
/* 136 */     arrayOfModuleMBean2[0] = new WebModuleDescriptor(this.warName, this.contextURI);
/*     */     
/* 138 */     byte b = 1;
/* 139 */     HashSet hashSet = new HashSet();
/* 140 */     for (File file : paramSet) {
/*     */       
/* 142 */       arrayOfModuleMBean2[b] = new EJBModuleDescriptor(file.getName());
/*     */       b++;
/*     */     } 
/* 145 */     if (arrayOfModuleMBean1 != null) {
/* 146 */       arrayOfModuleMBean2 = mergeModules(arrayOfModuleMBean1, arrayOfModuleMBean2);
/*     */     }
/*     */     
/* 149 */     this.appDD.setModules(arrayOfModuleMBean2);
/*     */     
/* 151 */     writeDD();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(J2EEApplicationDescriptorMBean paramJ2EEApplicationDescriptorMBean) throws WebServiceJarException {
/* 160 */     this.ejbMap = new HashMap();
/* 161 */     if (paramJ2EEApplicationDescriptorMBean == null)
/*     */       return; 
/* 163 */     File file = getExploded();
/*     */ 
/*     */     
/* 166 */     ModuleMBean[] arrayOfModuleMBean = paramJ2EEApplicationDescriptorMBean.getEJBModules();
/* 167 */     if (arrayOfModuleMBean != null)
/*     */     {
/* 169 */       for (byte b = 0; b < arrayOfModuleMBean.length; b++) {
/* 170 */         String str = arrayOfModuleMBean[b].getModuleURI();
/*     */         
/* 172 */         File file1 = new File(file, str);
/* 173 */         if (!file1.exists()) {
/* 174 */           throw new WebServiceJarException("Could not locate ejb-jar with URI " + str + " in EAR file");
/*     */         }
/*     */         
/* 177 */         VirtualJarFile virtualJarFile = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 195 */     arrayOfModuleMBean = paramJ2EEApplicationDescriptorMBean.getWebModules();
/* 196 */     if (arrayOfModuleMBean != null) {
/* 197 */       for (byte b = 0; b < arrayOfModuleMBean.length; b++) {
/* 198 */         String str = ((WebModuleMBean)arrayOfModuleMBean[b]).getModuleURI();
/* 199 */         if (this.warName.equals(str)) {
/* 200 */           String str1 = ((WebModuleMBean)arrayOfModuleMBean[b]).getContextRoot();
/* 201 */           if (str1 != null) this.contextURI = str1;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void readDD() throws IOException {
/* 210 */     ZipEntry zipEntry = getVirtualJarFile().getEntry("/META-INF/application.xml");
/*     */     
/* 212 */     if (zipEntry == null)
/*     */       return; 
/* 214 */     inputStream = getVirtualJarFile().getInputStream(zipEntry);
/*     */     
/* 216 */     J2EEDeploymentDescriptorLoader j2EEDeploymentDescriptorLoader = null;
/* 217 */     if (!inputStream.markSupported()) inputStream = new BufferedInputStream(inputStream); 
/*     */     try {
/* 219 */       inputStream.mark(1024);
/* 220 */       ProcessorFactory processorFactory = new ProcessorFactory();
/* 221 */       j2EEDeploymentDescriptorLoader = (J2EEDeploymentDescriptorLoader)processorFactory.getProcessor(inputStream, DDUtils.validPublicIds);
/* 222 */       inputStream.reset();
/* 223 */       this.appDD = new J2EEDeploymentDescriptor();
/* 224 */       j2EEDeploymentDescriptorLoader.setDD(this.appDD);
/* 225 */       j2EEDeploymentDescriptorLoader.process(inputStream);
/* 226 */     } catch (ProcessorFactoryException processorFactoryException) {
/* 227 */       throw new WebServiceJarException("Could not process J2EE deployment descriptor", processorFactoryException);
/* 228 */     } catch (IOException iOException) {
/* 229 */       throw new WebServiceJarException("Could not process J2EE deployment descriptor", iOException);
/* 230 */     } catch (XMLParsingException xMLParsingException) {
/* 231 */       throw new WebServiceJarException("Could not process J2EE deployment descriptor", xMLParsingException);
/* 232 */     } catch (XMLProcessingException xMLProcessingException) {
/* 233 */       throw new WebServiceJarException("Could not process J2EE deployment descriptor", xMLProcessingException);
/*     */     } finally {
/* 235 */       if (inputStream != null) inputStream.close();
/*     */     
/*     */     } 
/* 238 */     init(j2EEDeploymentDescriptorLoader.getDD());
/*     */   }
/*     */   
/*     */   private void writeDD() throws IOException {
/* 242 */     File file = new File(getExploded(), "META-INF/application.xml");
/* 243 */     file.getParentFile().mkdirs();
/* 244 */     FileOutputStream fileOutputStream = new FileOutputStream(file);
/* 245 */     PrintStream printStream = new PrintStream(fileOutputStream);
/* 246 */     printStream.print(((J2EEDeploymentDescriptor)this.appDD).toXML());
/* 247 */     printStream.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static J2EEApplicationDescriptorMBean mergeAppDescriptors(J2EEApplicationDescriptorMBean paramJ2EEApplicationDescriptorMBean1, J2EEApplicationDescriptorMBean paramJ2EEApplicationDescriptorMBean2) {
/* 258 */     paramJ2EEApplicationDescriptorMBean2.setDescription(paramJ2EEApplicationDescriptorMBean1.getDescription());
/* 259 */     paramJ2EEApplicationDescriptorMBean2.setDisplayName(paramJ2EEApplicationDescriptorMBean1.getDisplayName());
/* 260 */     paramJ2EEApplicationDescriptorMBean2.setSmallIconFileName(paramJ2EEApplicationDescriptorMBean1.getSmallIconFileName());
/* 261 */     paramJ2EEApplicationDescriptorMBean2.setLargeIconFileName(paramJ2EEApplicationDescriptorMBean1.getLargeIconFileName());
/* 262 */     mergeSecurityRoles(paramJ2EEApplicationDescriptorMBean1.getSecurityRoles(), paramJ2EEApplicationDescriptorMBean2.getSecurityRoles());
/* 263 */     mergeModules(paramJ2EEApplicationDescriptorMBean1.getModules(), paramJ2EEApplicationDescriptorMBean2.getModules());
/* 264 */     return paramJ2EEApplicationDescriptorMBean2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecurityRoleMBean[] mergeSecurityRoles(SecurityRoleMBean[] paramArrayOfSecurityRoleMBean1, SecurityRoleMBean[] paramArrayOfSecurityRoleMBean2) {
/* 270 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfSecurityRoleMBean1));
/* 271 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfSecurityRoleMBean2));
/* 272 */     ListIterator listIterator = arrayList1.listIterator();
/* 273 */     while (listIterator.hasNext()) {
/* 274 */       SecurityRoleMBean securityRoleMBean = (SecurityRoleMBean)listIterator.next();
/* 275 */       ListIterator listIterator1 = arrayList2.listIterator();
/* 276 */       while (listIterator1.hasNext()) {
/* 277 */         SecurityRoleMBean securityRoleMBean1 = (SecurityRoleMBean)listIterator1.next();
/* 278 */         if (nullableEquals(securityRoleMBean.getRoleName(), securityRoleMBean1.getRoleName())) {
/* 279 */           listIterator1.remove();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 284 */       arrayList2.add(securityRoleMBean);
/* 285 */       listIterator.remove();
/*     */     } 
/* 287 */     return (SecurityRoleMBean[])arrayList2.toArray(new SecurityRoleMBean[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ModuleMBean[] mergeModules(ModuleMBean[] paramArrayOfModuleMBean1, ModuleMBean[] paramArrayOfModuleMBean2) {
/* 293 */     ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])paramArrayOfModuleMBean1));
/* 294 */     ArrayList arrayList2 = new ArrayList(Arrays.asList((Object[])paramArrayOfModuleMBean2));
/* 295 */     ListIterator listIterator = arrayList1.listIterator();
/* 296 */     while (listIterator.hasNext()) {
/* 297 */       ModuleMBean moduleMBean = (ModuleMBean)listIterator.next();
/* 298 */       ListIterator listIterator1 = arrayList2.listIterator();
/* 299 */       while (listIterator1.hasNext()) {
/* 300 */         ModuleMBean moduleMBean1 = (ModuleMBean)listIterator1.next();
/* 301 */         if (nullableEquals(moduleMBean.getModuleURI(), moduleMBean1.getModuleURI())) {
/* 302 */           listIterator1.remove();
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 307 */       arrayList2.add(moduleMBean);
/* 308 */       listIterator.remove();
/*     */     } 
/* 310 */     return (ModuleMBean[])arrayList2.toArray(new ModuleMBean[0]);
/*     */   }
/*     */   
/*     */   public String getApplicationClasspath() {
/* 314 */     StringBuffer stringBuffer = new StringBuffer();
/* 315 */     J2EEUtils.addAppInfToClasspath(stringBuffer, getExploded());
/*     */     
/* 317 */     Set set = this.ejbMap.keySet();
/* 318 */     for (Iterator iterator = set.iterator(); iterator.hasNext(); ) {
/* 319 */       File file = new File(getExploded(), (String)iterator.next());
/* 320 */       stringBuffer.append(file.getAbsolutePath());
/* 321 */       stringBuffer.append(File.pathSeparator);
/*     */     } 
/*     */     
/* 324 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   private static boolean nullableEquals(Object paramObject1, Object paramObject2) {
/* 328 */     if (paramObject1 != null) {
/* 329 */       return paramObject1.equals(paramObject2);
/*     */     }
/* 331 */     return (paramObject2 == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void save() throws IOException {
/* 336 */     writeDD();
/* 337 */     super.save();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceEarFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */