package weblogic.webservice.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import weblogic.management.descriptors.webservice.StatelessEJBMBean;

public final class EJBHelper {
  public static Object getEJBHome(StatelessEJBMBean paramStatelessEJBMBean) throws NamingException {
    try {
      InitialContext initialContext = new InitialContext();
      if (paramStatelessEJBMBean.getJNDIName() != null)
        return initialContext.lookup(paramStatelessEJBMBean.getJNDIName().getPath()); 
      String str = paramStatelessEJBMBean.getEJBLink().getPath();
      Object object = null;
      try {
        object = initialContext.lookup("java:/app/ejb/" + str + "/home");
      } catch (NamingException namingException) {}
      try {
        object = initialContext.lookup("java:/app/ejb/" + str + "/local-home");
      } catch (NamingException namingException) {}
      if (object == null)
        throw new NamingException("Could not lookup EJB home, tried java:/app/ejb/" + str + "/home" + " and java:/app/ejb/" + str + "/localhome"); 
      return object;
    } catch (NamingException namingException) {
      namingException.printStackTrace();
      throw namingException;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\EJBHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */