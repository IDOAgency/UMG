/*    */ package weblogic.webservice.util;
/*    */ 
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ import weblogic.management.descriptors.webservice.StatelessEJBMBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EJBHelper
/*    */ {
/*    */   public static Object getEJBHome(StatelessEJBMBean paramStatelessEJBMBean) throws NamingException {
/*    */     try {
/* 27 */       InitialContext initialContext = new InitialContext();
/*    */       
/* 29 */       if (paramStatelessEJBMBean.getJNDIName() != null)
/*    */       {
/* 31 */         return initialContext.lookup(paramStatelessEJBMBean.getJNDIName().getPath());
/*    */       }
/*    */       
/* 34 */       String str = paramStatelessEJBMBean.getEJBLink().getPath();
/*    */       
/* 36 */       Object object = null;
/*    */       try {
/* 38 */         object = initialContext.lookup("java:/app/ejb/" + str + "/home");
/* 39 */       } catch (NamingException namingException) {}
/*    */       
/*    */       try {
/* 42 */         object = initialContext.lookup("java:/app/ejb/" + str + "/local-home");
/* 43 */       } catch (NamingException namingException) {}
/*    */       
/* 45 */       if (object == null) {
/* 46 */         throw new NamingException("Could not lookup EJB home, tried java:/app/ejb/" + str + "/home" + " and java:/app/ejb/" + str + "/localhome");
/*    */       }
/*    */ 
/*    */ 
/*    */       
/* 51 */       return object;
/*    */     }
/* 53 */     catch (NamingException namingException) {
/* 54 */       namingException.printStackTrace();
/* 55 */       throw namingException;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\EJBHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */