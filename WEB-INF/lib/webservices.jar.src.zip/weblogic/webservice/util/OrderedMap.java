package weblogic.webservice.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class OrderedMap implements Map {
  private HashMap map = new HashMap();
  
  private List keys = new ArrayList();
  
  private List values = new ArrayList();
  
  public String toString() { return this.map.toString(); }
  
  public int size() { return this.map.size(); }
  
  public boolean isEmpty() { return this.map.isEmpty(); }
  
  public boolean containsKey(Object paramObject) { return this.map.containsKey(paramObject); }
  
  public boolean containsValue(Object paramObject) { return this.map.containsValue(paramObject); }
  
  public Object get(Object paramObject) { return this.map.get(paramObject); }
  
  public Object put(Object paramObject1, Object paramObject2) {
    this.map.put(paramObject1, paramObject2);
    this.keys.add(paramObject1);
    this.values.add(paramObject2);
    return paramObject2;
  }
  
  public Object remove(Object paramObject) {
    Object object = this.map.get(paramObject);
    this.keys.remove(paramObject);
    this.values.remove(object);
    return this.map.remove(paramObject);
  }
  
  public void putAll(Map paramMap) {
    for (Object object1 : paramMap.keySet()) {
      Object object2 = paramMap.get(object1);
      put(object1, object2);
    } 
  }
  
  public void clear() {
    this.map.clear();
    this.keys.clear();
    this.values.clear();
  }
  
  public Set keySet() { return new OrderedSet(this.keys); }
  
  public Collection values() { return this.values; }
  
  public Set entrySet() { throw new Error("not supported"); }
  
  public class OrderedSet implements Set {
    List list;
    
    private final OrderedMap this$0;
    
    public OrderedSet(List param1List) { this.list = param1List; }
    
    public int size() { return this.list.size(); }
    
    public boolean isEmpty() { return this.list.isEmpty(); }
    
    public boolean contains(Object param1Object) { return this.list.contains(param1Object); }
    
    public Iterator iterator() { return this.list.iterator(); }
    
    public Object[] toArray() { return this.list.toArray(); }
    
    public Object[] toArray(Object[] param1ArrayOfObject) { return this.list.toArray(param1ArrayOfObject); }
    
    public boolean add(Object param1Object) { throw new Error("method not supported"); }
    
    public boolean remove(Object param1Object) { throw new Error("method not supported"); }
    
    public boolean containsAll(Collection param1Collection) { return this.list.containsAll(param1Collection); }
    
    public boolean addAll(Collection param1Collection) { throw new Error("method not supported"); }
    
    public boolean retainAll(Collection param1Collection) { throw new Error("method not supported"); }
    
    public boolean removeAll(Collection param1Collection) { throw new Error("method not supported"); }
    
    public void clear() { throw new Error("method not supported"); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\OrderedMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */