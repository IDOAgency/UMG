/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrderedMap
/*     */   implements Map
/*     */ {
/*  16 */   private HashMap map = new HashMap();
/*  17 */   private List keys = new ArrayList();
/*  18 */   private List values = new ArrayList();
/*     */ 
/*     */   
/*  21 */   public String toString() { return this.map.toString(); }
/*     */ 
/*     */ 
/*     */   
/*  25 */   public int size() { return this.map.size(); }
/*     */ 
/*     */ 
/*     */   
/*  29 */   public boolean isEmpty() { return this.map.isEmpty(); }
/*     */ 
/*     */ 
/*     */   
/*  33 */   public boolean containsKey(Object paramObject) { return this.map.containsKey(paramObject); }
/*     */ 
/*     */ 
/*     */   
/*  37 */   public boolean containsValue(Object paramObject) { return this.map.containsValue(paramObject); }
/*     */ 
/*     */ 
/*     */   
/*  41 */   public Object get(Object paramObject) { return this.map.get(paramObject); }
/*     */ 
/*     */   
/*     */   public Object put(Object paramObject1, Object paramObject2) {
/*  45 */     this.map.put(paramObject1, paramObject2);
/*  46 */     this.keys.add(paramObject1);
/*  47 */     this.values.add(paramObject2);
/*  48 */     return paramObject2;
/*     */   }
/*     */   
/*     */   public Object remove(Object paramObject) {
/*  52 */     Object object = this.map.get(paramObject);
/*  53 */     this.keys.remove(paramObject);
/*  54 */     this.values.remove(object);
/*  55 */     return this.map.remove(paramObject);
/*     */   }
/*     */   
/*     */   public void putAll(Map paramMap) {
/*  59 */     for (Object object1 : paramMap.keySet()) {
/*     */       
/*  61 */       Object object2 = paramMap.get(object1);
/*  62 */       put(object1, object2);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clear() {
/*  67 */     this.map.clear();
/*  68 */     this.keys.clear();
/*  69 */     this.values.clear();
/*     */   }
/*     */ 
/*     */   
/*  73 */   public Set keySet() { return new OrderedSet(this.keys); }
/*     */ 
/*     */ 
/*     */   
/*  77 */   public Collection values() { return this.values; }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public Set entrySet() { throw new Error("not supported"); }
/*     */ 
/*     */   
/*     */   public class OrderedSet
/*     */     implements Set
/*     */   {
/*     */     List list;
/*     */     
/*     */     private final OrderedMap this$0;
/*     */     
/*  91 */     public OrderedSet(List param1List) { this.list = param1List; }
/*     */ 
/*     */ 
/*     */     
/*  95 */     public int size() { return this.list.size(); }
/*     */ 
/*     */ 
/*     */     
/*  99 */     public boolean isEmpty() { return this.list.isEmpty(); }
/*     */ 
/*     */ 
/*     */     
/* 103 */     public boolean contains(Object param1Object) { return this.list.contains(param1Object); }
/*     */ 
/*     */ 
/*     */     
/* 107 */     public Iterator iterator() { return this.list.iterator(); }
/*     */ 
/*     */ 
/*     */     
/* 111 */     public Object[] toArray() { return this.list.toArray(); }
/*     */ 
/*     */ 
/*     */     
/* 115 */     public Object[] toArray(Object[] param1ArrayOfObject) { return this.list.toArray(param1ArrayOfObject); }
/*     */ 
/*     */ 
/*     */     
/* 119 */     public boolean add(Object param1Object) { throw new Error("method not supported"); }
/*     */ 
/*     */ 
/*     */     
/* 123 */     public boolean remove(Object param1Object) { throw new Error("method not supported"); }
/*     */ 
/*     */ 
/*     */     
/* 127 */     public boolean containsAll(Collection param1Collection) { return this.list.containsAll(param1Collection); }
/*     */ 
/*     */ 
/*     */     
/* 131 */     public boolean addAll(Collection param1Collection) { throw new Error("method not supported"); }
/*     */ 
/*     */ 
/*     */     
/* 135 */     public boolean retainAll(Collection param1Collection) { throw new Error("method not supported"); }
/*     */ 
/*     */ 
/*     */     
/* 139 */     public boolean removeAll(Collection param1Collection) { throw new Error("method not supported"); }
/*     */ 
/*     */ 
/*     */     
/* 143 */     public void clear() { throw new Error("method not supported"); }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\OrderedMap.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */