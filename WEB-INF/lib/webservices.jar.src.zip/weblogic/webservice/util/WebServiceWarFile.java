/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
/*     */ import weblogic.webservice.dd.DDLoader;
/*     */ import weblogic.webservice.dd.DDProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WebServiceWarFile
/*     */   extends WebServiceJarFile
/*     */ {
/*  27 */   private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
/*     */ 
/*     */   
/*     */   private static final String WS_DD = "WEB-INF/web-services.xml";
/*     */ 
/*     */   
/*     */   private static final String WEB_DD = "WEB-INF/web.xml";
/*     */ 
/*     */   
/*     */   private static final String WS_CLASSES = "WEB-INF/classes";
/*     */ 
/*     */   
/*     */   private static final String WS_LIB = "WEB-INF/lib";
/*     */   
/*     */   private File classesDir;
/*     */   
/*     */   private File libDir;
/*     */   
/*     */   private WebServiceEarFile parent;
/*     */   
/*     */   private String warname;
/*     */ 
/*     */   
/*     */   public WebServiceWarFile(File paramFile1, File paramFile2, WebServiceEarFile paramWebServiceEarFile) throws IOException {
/*  51 */     super(paramFile1, paramFile2);
/*  52 */     this.classesDir = new File(getExploded(), "WEB-INF/classes");
/*  53 */     this.libDir = new File(getExploded(), "WEB-INF/lib");
/*  54 */     this.classesDir.mkdirs();
/*  55 */     this.libDir.mkdirs();
/*  56 */     this.parent = paramWebServiceEarFile;
/*  57 */     this.warname = paramFile2.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServicesMBean getWSDD() throws WebServiceJarException {
/*  64 */     WebServicesMBean webServicesMBean = null;
/*  65 */     inputStream = null;
/*     */     
/*  67 */     if (this.parent != null) {
/*  68 */       ZipEntry zipEntry = this.parent.getVirtualJarFile().getEntry(this.warname + "/" + "WEB-INF/web-services.xml");
/*  69 */       if (zipEntry != null) {
/*     */         try {
/*  71 */           inputStream = this.parent.getVirtualJarFile().getInputStream(zipEntry);
/*  72 */         } catch (IOException iOException) {
/*  73 */           throw new WebServiceJarException("Could not load web service deployment descriptor", iOException);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  79 */     if (inputStream == null) {
/*     */       try {
/*  81 */         inputStream = new FileInputStream(new File(getExploded(), "WEB-INF/web-services.xml"));
/*  82 */       } catch (FileNotFoundException fileNotFoundException) {}
/*     */     }
/*     */     
/*  85 */     if (inputStream != null) {
/*     */       try {
/*  87 */         webServicesMBean = (new DDLoader()).load(inputStream);
/*  88 */       } catch (DDProcessingException dDProcessingException) {
/*  89 */         throw new WebServiceJarException("Could not load web service deployment descriptor", dDProcessingException);
/*     */       } finally {
/*     */         
/*  92 */         try { inputStream.close(); } catch (IOException iOException) {}
/*     */       } 
/*     */     }
/*     */     
/*  96 */     return webServicesMBean;
/*     */   }
/*     */ 
/*     */   
/* 100 */   public File getWSDDAsFile() { return new File(getExploded(), "WEB-INF/web-services.xml"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public File getClassesDir() { return this.classesDir; }
/*     */   
/* 112 */   public File getLibDir() { return this.libDir; }
/*     */ 
/*     */   
/* 115 */   public String toString() { return "WebServiceWarFile[" + super.toString() + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDD(WebServicesMBean paramWebServicesMBean) throws IOException {
/* 122 */     File file = new File(getExploded(), "WEB-INF/web-services.xml");
/* 123 */     file.getParentFile().mkdirs();
/*     */     
/* 125 */     FileOutputStream fileOutputStream = new FileOutputStream(file);
/* 126 */     PrintStream printStream = null;
/*     */     
/* 128 */     if (charset == null) {
/* 129 */       printStream = new PrintStream(fileOutputStream, false, "UTF-8");
/* 130 */       printStream.print("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
/*     */     } else {
/* 132 */       printStream = new PrintStream(fileOutputStream, false, charset);
/* 133 */       printStream.print("<?xml version=\"1.0\" encoding=\"" + charset + "\"?>\n");
/*     */     } 
/*     */     
/* 136 */     printStream.print(((WebServicesMBeanImpl)paramWebServicesMBean).toXML(0));
/* 137 */     printStream.close();
/*     */   }
/*     */   
/*     */   private static void writeWebXml(File paramFile) throws IOException {
/* 141 */     paramFile.getParentFile().mkdirs();
/* 142 */     PrintStream printStream = new PrintStream(new FileOutputStream(paramFile));
/* 143 */     printStream.println("<!DOCTYPE web-app PUBLIC \"-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN\" \"http://java.sun.com/dtd/web-app_2_3.dtd\">\n<web-app>\n</web-app>");
/* 144 */     printStream.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() throws IOException {
/* 151 */     File file = new File(getExploded(), "WEB-INF/web.xml");
/* 152 */     if (!file.exists()) {
/* 153 */       writeWebXml(file);
/*     */     }
/*     */     
/* 156 */     super.save();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceWarFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */