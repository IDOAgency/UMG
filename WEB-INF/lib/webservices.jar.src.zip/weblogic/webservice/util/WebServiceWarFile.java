package weblogic.webservice.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.zip.ZipEntry;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
import weblogic.webservice.dd.DDLoader;
import weblogic.webservice.dd.DDProcessingException;

public class WebServiceWarFile extends WebServiceJarFile {
  private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
  
  private static final String WS_DD = "WEB-INF/web-services.xml";
  
  private static final String WEB_DD = "WEB-INF/web.xml";
  
  private static final String WS_CLASSES = "WEB-INF/classes";
  
  private static final String WS_LIB = "WEB-INF/lib";
  
  private File classesDir;
  
  private File libDir;
  
  private WebServiceEarFile parent;
  
  private String warname;
  
  public WebServiceWarFile(File paramFile1, File paramFile2, WebServiceEarFile paramWebServiceEarFile) throws IOException {
    super(paramFile1, paramFile2);
    this.classesDir = new File(getExploded(), "WEB-INF/classes");
    this.libDir = new File(getExploded(), "WEB-INF/lib");
    this.classesDir.mkdirs();
    this.libDir.mkdirs();
    this.parent = paramWebServiceEarFile;
    this.warname = paramFile2.getName();
  }
  
  public WebServicesMBean getWSDD() throws WebServiceJarException {
    WebServicesMBean webServicesMBean = null;
    inputStream = null;
    if (this.parent != null) {
      ZipEntry zipEntry = this.parent.getVirtualJarFile().getEntry(this.warname + "/" + "WEB-INF/web-services.xml");
      if (zipEntry != null)
        try {
          inputStream = this.parent.getVirtualJarFile().getInputStream(zipEntry);
        } catch (IOException iOException) {
          throw new WebServiceJarException("Could not load web service deployment descriptor", iOException);
        }  
    } 
    if (inputStream == null)
      try {
        inputStream = new FileInputStream(new File(getExploded(), "WEB-INF/web-services.xml"));
      } catch (FileNotFoundException fileNotFoundException) {} 
    if (inputStream != null)
      try {
        webServicesMBean = (new DDLoader()).load(inputStream);
      } catch (DDProcessingException dDProcessingException) {
        throw new WebServiceJarException("Could not load web service deployment descriptor", dDProcessingException);
      } finally {
        try {
          inputStream.close();
        } catch (IOException iOException) {}
      }  
    return webServicesMBean;
  }
  
  public File getWSDDAsFile() { return new File(getExploded(), "WEB-INF/web-services.xml"); }
  
  public File getClassesDir() { return this.classesDir; }
  
  public File getLibDir() { return this.libDir; }
  
  public String toString() { return "WebServiceWarFile[" + super.toString() + "]"; }
  
  public void writeDD(WebServicesMBean paramWebServicesMBean) throws IOException {
    File file = new File(getExploded(), "WEB-INF/web-services.xml");
    file.getParentFile().mkdirs();
    FileOutputStream fileOutputStream = new FileOutputStream(file);
    PrintStream printStream = null;
    if (charset == null) {
      printStream = new PrintStream(fileOutputStream, false, "UTF-8");
      printStream.print("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    } else {
      printStream = new PrintStream(fileOutputStream, false, charset);
      printStream.print("<?xml version=\"1.0\" encoding=\"" + charset + "\"?>\n");
    } 
    printStream.print(((WebServicesMBeanImpl)paramWebServicesMBean).toXML(0));
    printStream.close();
  }
  
  private static void writeWebXml(File paramFile) throws IOException {
    paramFile.getParentFile().mkdirs();
    PrintStream printStream = new PrintStream(new FileOutputStream(paramFile));
    printStream.println("<!DOCTYPE web-app PUBLIC \"-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN\" \"http://java.sun.com/dtd/web-app_2_3.dtd\">\n<web-app>\n</web-app>");
    printStream.close();
  }
  
  public void save() throws IOException {
    File file = new File(getExploded(), "WEB-INF/web.xml");
    if (!file.exists())
      writeWebXml(file); 
    super.save();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceWarFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */