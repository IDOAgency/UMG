/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Random;
/*     */ import weblogic.application.ApplicationFileManager;
/*     */ import weblogic.utils.FileUtils;
/*     */ import weblogic.utils.jars.JarFileObject;
/*     */ import weblogic.utils.jars.VirtualJarFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WebServiceJarFile
/*     */ {
/*  24 */   protected static final boolean debug = (System.getProperty(DEBUG_PROPERTY()) != null);
/*     */ 
/*     */   
/*     */   private File exploded;
/*     */ 
/*     */   
/*     */   private VirtualJarFile vJarFile;
/*     */ 
/*     */   
/*     */   protected ApplicationFileManager appFileManager;
/*     */ 
/*     */   
/*     */   protected File dest;
/*     */ 
/*     */   
/*  39 */   protected static String DEBUG_PROPERTY() { return "wsjar.debug"; }
/*     */   
/*     */   public WebServiceJarFile(File paramFile1, File paramFile2) throws IOException {
/*  42 */     this.dest = paramFile2;
/*     */ 
/*     */     
/*  45 */     if (paramFile2.exists()) {
/*  46 */       if (debug) System.out.println("Extracting previous contents..."); 
/*  47 */       if (paramFile2.isDirectory()) {
/*  48 */         this.exploded = paramFile2;
/*     */       } else {
/*  50 */         createExploded(paramFile1, paramFile2);
/*  51 */         JarFileObject jarFileObject = new JarFileObject(paramFile2);
/*  52 */         jarFileObject.extract(this.exploded);
/*     */       } 
/*     */     } else {
/*  55 */       createExploded(paramFile1, paramFile2);
/*  56 */       if (paramFile2.getParentFile() != null) {
/*  57 */         paramFile2.getParentFile().mkdirs();
/*     */       }
/*     */     } 
/*     */     
/*  61 */     this.appFileManager = ApplicationFileManager.newInstance(this.exploded);
/*  62 */     this.vJarFile = this.appFileManager.getVirtualJarFile();
/*     */     
/*  64 */     if (debug) {
/*  65 */       System.out.println("*** Creating " + toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove() throws IOException {
/*  74 */     if (debug) System.out.println("*** Removing " + toString());
/*     */     
/*  76 */     this.vJarFile.close();
/*     */     
/*  78 */     if (this.exploded != this.dest && this.exploded != null) {
/*  79 */       FileUtils.remove(this.exploded);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() throws IOException {
/*  87 */     if (this.dest == this.exploded)
/*     */       return; 
/*  89 */     JarFileObject jarFileObject = JarFileObject.makeJar(this.dest.getCanonicalPath(), this.exploded);
/*     */     
/*  91 */     jarFileObject.save();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public File getExploded() { return this.exploded; }
/*     */   
/*  99 */   public VirtualJarFile getVirtualJarFile() { return this.vJarFile; }
/*     */   
/* 101 */   public File getDestJar() { return this.dest; }
/*     */   
/*     */   public static String stripDriveLetter(String paramString) {
/* 104 */     String str = paramString.trim();
/* 105 */     if (paramString == null || paramString.length() <= 1 || str.charAt(1) != ':') {
/* 106 */       return str;
/*     */     }
/* 108 */     return str.substring(2);
/*     */   }
/*     */ 
/*     */   
/*     */   private void createExploded(File paramFile1, File paramFile2) throws IOException {
/* 113 */     Random random = new Random(System.identityHashCode(paramFile2));
/*     */     
/*     */     do {
/* 116 */       this.exploded = new File(paramFile1, paramFile2.getName() + random.nextInt());
/* 117 */     } while (this.exploded.exists());
/*     */     
/* 119 */     this.exploded.mkdirs();
/*     */   }
/*     */ 
/*     */   
/* 123 */   public String toString() { return this.dest + ":" + this.exploded; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceJarFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */