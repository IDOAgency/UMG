package weblogic.webservice.util;

import java.io.File;
import java.io.IOException;
import java.util.Random;
import weblogic.application.ApplicationFileManager;
import weblogic.utils.FileUtils;
import weblogic.utils.jars.JarFileObject;
import weblogic.utils.jars.VirtualJarFile;

public abstract class WebServiceJarFile {
  protected static final boolean debug = (System.getProperty(DEBUG_PROPERTY()) != null);
  
  private File exploded;
  
  private VirtualJarFile vJarFile;
  
  protected ApplicationFileManager appFileManager;
  
  protected File dest;
  
  protected static String DEBUG_PROPERTY() { return "wsjar.debug"; }
  
  public WebServiceJarFile(File paramFile1, File paramFile2) throws IOException {
    this.dest = paramFile2;
    if (paramFile2.exists()) {
      if (debug)
        System.out.println("Extracting previous contents..."); 
      if (paramFile2.isDirectory()) {
        this.exploded = paramFile2;
      } else {
        createExploded(paramFile1, paramFile2);
        JarFileObject jarFileObject = new JarFileObject(paramFile2);
        jarFileObject.extract(this.exploded);
      } 
    } else {
      createExploded(paramFile1, paramFile2);
      if (paramFile2.getParentFile() != null)
        paramFile2.getParentFile().mkdirs(); 
    } 
    this.appFileManager = ApplicationFileManager.newInstance(this.exploded);
    this.vJarFile = this.appFileManager.getVirtualJarFile();
    if (debug)
      System.out.println("*** Creating " + toString()); 
  }
  
  public void remove() throws IOException {
    if (debug)
      System.out.println("*** Removing " + toString()); 
    this.vJarFile.close();
    if (this.exploded != this.dest && this.exploded != null)
      FileUtils.remove(this.exploded); 
  }
  
  public void save() throws IOException {
    if (this.dest == this.exploded)
      return; 
    JarFileObject jarFileObject = JarFileObject.makeJar(this.dest.getCanonicalPath(), this.exploded);
    jarFileObject.save();
  }
  
  public File getExploded() { return this.exploded; }
  
  public VirtualJarFile getVirtualJarFile() { return this.vJarFile; }
  
  public File getDestJar() { return this.dest; }
  
  public static String stripDriveLetter(String paramString) {
    String str = paramString.trim();
    if (paramString == null || paramString.length() <= 1 || str.charAt(1) != ':')
      return str; 
    return str.substring(2);
  }
  
  private void createExploded(File paramFile1, File paramFile2) throws IOException {
    Random random = new Random(System.identityHashCode(paramFile2));
    do {
      this.exploded = new File(paramFile1, paramFile2.getName() + random.nextInt());
    } while (this.exploded.exists());
    this.exploded.mkdirs();
  }
  
  public String toString() { return this.dest + ":" + this.exploded; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceJarFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */