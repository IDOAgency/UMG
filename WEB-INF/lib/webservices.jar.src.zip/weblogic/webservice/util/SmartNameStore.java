package weblogic.webservice.util;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class SmartNameStore {
  private Class clazz;
  
  private static HashMap keywords = new HashMap();
  
  static  {
    keywords.put("int", "intVal");
    keywords.put("class", "clazz");
    keywords.put("float", "floatVal");
    keywords.put("double", "doubleVal");
    keywords.put("short", "shortVal");
    keywords.put("boolean", "booleanVal");
    keywords.put("long", "longVal");
    keywords.put("char", "charVal");
    keywords.put("byte", "byteVal");
  }
  
  public SmartNameStore(Class paramClass) { this.clazz = paramClass; }
  
  public SmartNameStore() { this(null); }
  
  public static String getMangleName(Class paramClass) {
    Class clazz1 = getComponentType(paramClass);
    null = getShortName(clazz1);
    if (paramClass.isArray())
      null = null + "s"; 
    return renameKeword(null);
  }
  
  public Iterator getNames(Method paramMethod) {
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    ArrayList arrayList = new ArrayList();
    for (byte b = 0; b < arrayOfClass.length; b++) {
      String str = getMangleName(arrayOfClass[b]);
      str = uniqueName(str, arrayList);
      arrayList.add(str);
    } 
    return arrayList.iterator();
  }
  
  private static Class getComponentType(Class paramClass) {
    while (paramClass.isArray())
      paramClass = paramClass.getComponentType(); 
    return paramClass;
  }
  
  private String uniqueName(String paramString, ArrayList paramArrayList) {
    String str = paramString;
    byte b = 0;
    while (paramArrayList.contains(str)) {
      str = paramString + b;
      b++;
    } 
    return str;
  }
  
  private static String renameKeword(String paramString) {
    String str = (String)keywords.get(paramString);
    return (str == null) ? paramString : str;
  }
  
  private static String getShortName(Class paramClass) {
    String str = paramClass.getName();
    int i = str.lastIndexOf(".");
    if (i != -1)
      str = str.substring(i + 1, str.length()); 
    if (Character.isUpperCase(str.charAt(0)))
      str = Character.toLowerCase(str.charAt(0)) + str.substring(1, str.length()); 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\SmartNameStore.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */