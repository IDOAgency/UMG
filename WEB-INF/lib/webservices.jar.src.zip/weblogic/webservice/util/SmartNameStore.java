/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SmartNameStore
/*     */ {
/*     */   private Class clazz;
/*  16 */   private static HashMap keywords = new HashMap();
/*     */   
/*     */   static  {
/*  19 */     keywords.put("int", "intVal");
/*  20 */     keywords.put("class", "clazz");
/*  21 */     keywords.put("float", "floatVal");
/*  22 */     keywords.put("double", "doubleVal");
/*  23 */     keywords.put("short", "shortVal");
/*  24 */     keywords.put("boolean", "booleanVal");
/*  25 */     keywords.put("long", "longVal");
/*  26 */     keywords.put("char", "charVal");
/*  27 */     keywords.put("byte", "byteVal");
/*     */   }
/*     */ 
/*     */   
/*  31 */   public SmartNameStore(Class paramClass) { this.clazz = paramClass; }
/*     */ 
/*     */ 
/*     */   
/*  35 */   public SmartNameStore() { this(null); }
/*     */ 
/*     */   
/*     */   public static String getMangleName(Class paramClass) {
/*  39 */     Class clazz1 = getComponentType(paramClass);
/*  40 */     null = getShortName(clazz1);
/*     */     
/*  42 */     if (paramClass.isArray()) {
/*  43 */       null = null + "s";
/*     */     }
/*     */     
/*  46 */     return renameKeword(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator getNames(Method paramMethod) {
/*  51 */     Class[] arrayOfClass = paramMethod.getParameterTypes();
/*     */     
/*  53 */     ArrayList arrayList = new ArrayList();
/*     */     
/*  55 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/*  56 */       String str = getMangleName(arrayOfClass[b]);
/*  57 */       str = uniqueName(str, arrayList);
/*  58 */       arrayList.add(str);
/*     */     } 
/*     */     
/*  61 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   private static Class getComponentType(Class paramClass) {
/*  65 */     while (paramClass.isArray()) {
/*  66 */       paramClass = paramClass.getComponentType();
/*     */     }
/*     */     
/*  69 */     return paramClass;
/*     */   }
/*     */   
/*     */   private String uniqueName(String paramString, ArrayList paramArrayList) {
/*  73 */     String str = paramString;
/*     */     
/*  75 */     byte b = 0;
/*     */     
/*  77 */     while (paramArrayList.contains(str)) {
/*  78 */       str = paramString + b;
/*  79 */       b++;
/*     */     } 
/*     */     
/*  82 */     return str;
/*     */   }
/*     */   
/*     */   private static String renameKeword(String paramString) {
/*  86 */     String str = (String)keywords.get(paramString);
/*  87 */     return (str == null) ? paramString : str;
/*     */   }
/*     */   
/*     */   private static String getShortName(Class paramClass) {
/*  91 */     String str = paramClass.getName();
/*  92 */     int i = str.lastIndexOf(".");
/*     */     
/*  94 */     if (i != -1) {
/*  95 */       str = str.substring(i + 1, str.length());
/*     */     }
/*     */     
/*  98 */     if (Character.isUpperCase(str.charAt(0))) {
/*  99 */       str = Character.toLowerCase(str.charAt(0)) + str.substring(1, str.length());
/*     */     }
/*     */ 
/*     */     
/* 103 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\SmartNameStore.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */