package weblogic.webservice.util;

import weblogic.xml.stream.util.XMLInputOutputStreamBase;

public class BufferStream extends XMLInputOutputStreamBase {
  public void close() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\BufferStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */