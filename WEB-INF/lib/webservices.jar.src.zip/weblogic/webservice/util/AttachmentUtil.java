/*    */ package weblogic.webservice.util;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttachmentUtil
/*    */ {
/* 12 */   private static final HashMap contentTypes = new HashMap();
/*    */ 
/*    */ 
/*    */   
/*    */   static  {
/* 17 */     contentTypes.put("java.lang.String", "text/plain");
/* 18 */     contentTypes.put("javax.xml.transform.Source", "text/xml");
/* 19 */     contentTypes.put("javax.mail.internet.MimeMultipart", "multipart/*");
/* 20 */     contentTypes.put("javax.activation.DataHandler", "*/*");
/* 21 */     contentTypes.put("java.awt.Image", "image/gif");
/*    */     
/* 23 */     contentTypes.put("[Ljava.awt.Image;", "multipart/related; type=image/gif");
/*    */ 
/*    */     
/* 26 */     contentTypes.put("[Ljavax.activation.DataHandler;", "multipart/*; type=*/*");
/*    */ 
/*    */     
/* 29 */     contentTypes.put("[Ljavax.xml.transform.Source;", "multipart/related; type=text/xml");
/*    */ 
/*    */     
/* 32 */     contentTypes.put("[Ljava.lang.String;", "multipart/related; type=text/plain");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getContentType(String paramString) {
/* 38 */     String str = (String)contentTypes.get(paramString);
/*    */     
/* 40 */     if (str == null) {
/* 41 */       str = "text/plain";
/*    */     }
/*    */     
/* 44 */     return str;
/*    */   }
/*    */ 
/*    */   
/*    */   public static Class getJavaType(String paramString) {
/* 49 */     for (Map.Entry entry : contentTypes.entrySet()) {
/*    */ 
/*    */       
/* 52 */       if (paramString.equals(entry.getValue())) {
/*    */         try {
/* 54 */           return Class.forName((String)entry.getKey());
/* 55 */         } catch (ClassNotFoundException classNotFoundException) {
/* 56 */           return null;
/*    */         } 
/*    */       }
/*    */     } 
/*    */     
/* 61 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\AttachmentUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */