package weblogic.webservice.util;

import java.util.HashMap;
import java.util.Map;

public class AttachmentUtil {
  private static final HashMap contentTypes = new HashMap();
  
  static  {
    contentTypes.put("java.lang.String", "text/plain");
    contentTypes.put("javax.xml.transform.Source", "text/xml");
    contentTypes.put("javax.mail.internet.MimeMultipart", "multipart/*");
    contentTypes.put("javax.activation.DataHandler", "*/*");
    contentTypes.put("java.awt.Image", "image/gif");
    contentTypes.put("[Ljava.awt.Image;", "multipart/related; type=image/gif");
    contentTypes.put("[Ljavax.activation.DataHandler;", "multipart/*; type=*/*");
    contentTypes.put("[Ljavax.xml.transform.Source;", "multipart/related; type=text/xml");
    contentTypes.put("[Ljava.lang.String;", "multipart/related; type=text/plain");
  }
  
  public static String getContentType(String paramString) {
    String str = (String)contentTypes.get(paramString);
    if (str == null)
      str = "text/plain"; 
    return str;
  }
  
  public static Class getJavaType(String paramString) {
    for (Map.Entry entry : contentTypes.entrySet()) {
      if (paramString.equals(entry.getValue()))
        try {
          return Class.forName((String)entry.getKey());
        } catch (ClassNotFoundException classNotFoundException) {
          return null;
        }  
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\AttachmentUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */