/*    */ package weblogic.webservice.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import weblogic.xml.schema.binding.TypeMapping;
/*    */ import weblogic.xml.stream.XMLOutputStream;
/*    */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServiceClientJarFile
/*    */   extends WebServiceJarFile
/*    */ {
/* 24 */   private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
/*    */ 
/*    */   
/*    */   public WebServiceClientJarFile(File paramFile1, File paramFile2) throws IOException {
/* 28 */     super(paramFile1, paramFile2);
/* 29 */     if (debug) {
/* 30 */       System.out.println("Creating WebServiceClientJarFile(" + paramFile2.getName() + ")");
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeClientDD(String paramString1, String paramString2, TypeMapping paramTypeMapping) throws IOException {
/* 38 */     String str1 = paramString1.replace('.', '/') + '/' + paramString2 + ".xml";
/* 39 */     File file = new File(getExploded(), str1);
/* 40 */     file.getParentFile().mkdirs();
/*    */     
/* 42 */     String str2 = charset;
/* 43 */     if (str2 == null) {
/* 44 */       str2 = "UTF-8";
/*    */     }
/*    */     
/* 47 */     fileOutputStream = new FileOutputStream(file);
/* 48 */     String str3 = "<?xml version=\"1.0\" encoding=\"" + str2 + "\"?>\n";
/* 49 */     fileOutputStream.write(str3.getBytes(str2));
/*    */ 
/*    */     
/* 52 */     xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(new OutputStreamWriter(fileOutputStream, str2));
/*    */ 
/*    */ 
/*    */     
/* 56 */     try { paramTypeMapping.writeXML(xMLOutputStream);
/* 57 */       xMLOutputStream.flush();
/* 58 */       fileOutputStream.flush(); }
/*    */     finally { 
/* 60 */       try { if (xMLOutputStream != null) fileOutputStream.close();  } catch (IOException iOException) {} 
/* 61 */       try { if (fileOutputStream != null) fileOutputStream.close();  } catch (IOException iOException) {} }
/*    */   
/*    */   }
/*    */ 
/*    */   
/* 66 */   public String toString() { return "WebServiceClientJarFile[" + super.toString() + "]"; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceClientJarFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */