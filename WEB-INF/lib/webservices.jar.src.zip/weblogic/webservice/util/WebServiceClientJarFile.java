package weblogic.webservice.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;

public class WebServiceClientJarFile extends WebServiceJarFile {
  private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
  
  public WebServiceClientJarFile(File paramFile1, File paramFile2) throws IOException {
    super(paramFile1, paramFile2);
    if (debug)
      System.out.println("Creating WebServiceClientJarFile(" + paramFile2.getName() + ")"); 
  }
  
  public void writeClientDD(String paramString1, String paramString2, TypeMapping paramTypeMapping) throws IOException {
    String str1 = paramString1.replace('.', '/') + '/' + paramString2 + ".xml";
    File file = new File(getExploded(), str1);
    file.getParentFile().mkdirs();
    String str2 = charset;
    if (str2 == null)
      str2 = "UTF-8"; 
    fileOutputStream = new FileOutputStream(file);
    String str3 = "<?xml version=\"1.0\" encoding=\"" + str2 + "\"?>\n";
    fileOutputStream.write(str3.getBytes(str2));
    xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(new OutputStreamWriter(fileOutputStream, str2));
    try {
      paramTypeMapping.writeXML(xMLOutputStream);
      xMLOutputStream.flush();
      fileOutputStream.flush();
    } finally {
      try {
        if (xMLOutputStream != null)
          fileOutputStream.close(); 
      } catch (IOException iOException) {}
      try {
        if (fileOutputStream != null)
          fileOutputStream.close(); 
      } catch (IOException iOException) {}
    } 
  }
  
  public String toString() { return "WebServiceClientJarFile[" + super.toString() + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceClientJarFile.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */