package weblogic.webservice.util;

import javax.xml.namespace.QName;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.AssertionError;
import weblogic.utils.StackTraceUtils;
import weblogic.webservice.core.soap.DetailImpl;
import weblogic.webservice.core.soap.NameImpl;
import weblogic.webservice.core.soap.SOAPElementImpl;
import weblogic.webservice.core.soap.SOAPFaultImpl;

public final class FaultUtil {
  private static final String FAULT_URI = "http://www.bea.com/servers/wls70/webservice/fault/1.0.0";
  
  private static final String soapEnvelopeNS = "http://schemas.xmlsoap.org/soap/envelope/";
  
  private static final String FAULT_PREFIX = "bea_fault";
  
  private static final Name FAULT_NAME = new NameImpl("stacktrace", "bea_fault", "http://www.bea.com/servers/wls70/webservice/fault/1.0.0");
  
  private static final boolean isJ2ME = isJ2ME();
  
  private static boolean isJ2ME() {
    try {
      Class.forName("java.rmi.RemoteException");
      return false;
    } catch (Throwable throwable) {
      return true;
    } 
  }
  
  public static Detail newDetail() { return new DetailImpl(); }
  
  public static void throwSOAPFaultException(String paramString1, String paramString2, Throwable paramThrowable) throws SOAPFaultException { throw new SOAPFaultException(new QName("http://schemas.xmlsoap.org/soap/envelope/", paramString1), paramString2, null, newDetail(paramThrowable)); }
  
  public static Detail newDetail(Throwable paramThrowable) {
    if (paramThrowable instanceof SOAPFaultException)
      return ((SOAPFaultException)paramThrowable).getDetail(); 
    Detail detail = newDetail();
    return fillDetail(paramThrowable, detail);
  }
  
  public static Detail fillDetail(Throwable paramThrowable, Detail paramDetail) {
    try {
      DetailEntry detailEntry = paramDetail.addDetailEntry(FAULT_NAME);
      detailEntry.addNamespaceDeclaration("bea_fault", "http://www.bea.com/servers/wls70/webservice/fault/1.0.0");
      StringBuffer stringBuffer = new StringBuffer();
      Throwable throwable = paramThrowable;
      String str = "";
      do {
        stringBuffer.append(str);
        stringBuffer.append(StackTraceUtils.throwable2StackTrace(paramThrowable));
        if (isJ2ME) {
          throwable = null;
        } else {
          try {
            throwable = throwable.getCause();
          } catch (NoSuchMethodError noSuchMethodError) {
            throwable = null;
          } 
        } 
        str = "Caused by: ";
      } while (throwable != null);
      detailEntry.addTextNode(stringBuffer.toString());
    } catch (SOAPException sOAPException) {
      throw new AssertionError(sOAPException);
    } 
    return paramDetail;
  }
  
  public static void fillFault(SOAPFault paramSOAPFault, Throwable paramThrowable) throws SOAPException {
    if (paramThrowable instanceof SOAPFaultException) {
      SOAPFaultException sOAPFaultException = (SOAPFaultException)paramThrowable;
      addFaultCode(paramSOAPFault, sOAPFaultException);
      paramSOAPFault.setFaultString(sOAPFaultException.getFaultString());
      String str = sOAPFaultException.getFaultActor();
      if (str != null)
        paramSOAPFault.setFaultActor(str); 
      if (sOAPFaultException.getDetail() != null)
        ((SOAPFaultImpl)paramSOAPFault).setDetail(sOAPFaultException.getDetail()); 
    } else if (paramThrowable.getClass().getName().endsWith("AccessException")) {
      paramSOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":Client.Authentication");
      paramSOAPFault.setFaultString(paramThrowable.getMessage());
      fillDetail(paramThrowable, paramSOAPFault.addDetail());
    } else {
      paramSOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":Server");
      paramSOAPFault.setFaultString("Exception during processing: " + paramThrowable.toString() + " (see Fault Detail for stacktrace)");
      fillDetail(paramThrowable, paramSOAPFault.addDetail());
    } 
  }
  
  private static void addFaultCode(SOAPFault paramSOAPFault, SOAPFaultException paramSOAPFaultException) throws SOAPException {
    QName qName = paramSOAPFaultException.getFaultCode();
    if (qName == null) {
      paramSOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":Server");
    } else {
      String str1 = qName.getLocalPart();
      String str2 = qName.getNamespaceURI();
      if (str1 == null)
        str1 = "Server"; 
      if (str2 == null) {
        paramSOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":" + str1);
      } else {
        paramSOAPFault.addNamespaceDeclaration("fault", str2);
        paramSOAPFault.setFaultCode("fault:" + str1);
      } 
    } 
  }
  
  public static SOAPMessage exception2Fault(Throwable paramThrowable) {
    try {
      SOAPMessage sOAPMessage = WLMessageFactory.getInstance().getMessageFactory().createMessage();
      SOAPFault sOAPFault = sOAPMessage.getSOAPPart().getEnvelope().getBody().addFault();
      if (!isJ2ME)
        paramThrowable = ExceptionUtil.unwrapException(paramThrowable); 
      fillFault(sOAPFault, paramThrowable);
      return sOAPMessage;
    } catch (SOAPException sOAPException) {
      throw new AssertionError(sOAPException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\FaultUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */