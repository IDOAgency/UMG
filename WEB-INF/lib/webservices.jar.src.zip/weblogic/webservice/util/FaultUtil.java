/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.Detail;
/*     */ import javax.xml.soap.DetailEntry;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPFault;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.utils.StackTraceUtils;
/*     */ import weblogic.webservice.core.soap.DetailImpl;
/*     */ import weblogic.webservice.core.soap.NameImpl;
/*     */ import weblogic.webservice.core.soap.SOAPElementImpl;
/*     */ import weblogic.webservice.core.soap.SOAPFaultImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FaultUtil
/*     */ {
/*     */   private static final String FAULT_URI = "http://www.bea.com/servers/wls70/webservice/fault/1.0.0";
/*     */   private static final String soapEnvelopeNS = "http://schemas.xmlsoap.org/soap/envelope/";
/*     */   private static final String FAULT_PREFIX = "bea_fault";
/*  33 */   private static final Name FAULT_NAME = new NameImpl("stacktrace", "bea_fault", "http://www.bea.com/servers/wls70/webservice/fault/1.0.0");
/*     */ 
/*     */   
/*  36 */   private static final boolean isJ2ME = isJ2ME();
/*     */   
/*     */   private static boolean isJ2ME() {
/*     */     try {
/*  40 */       Class.forName("java.rmi.RemoteException");
/*  41 */       return false;
/*  42 */     } catch (Throwable throwable) {
/*  43 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static Detail newDetail() { return new DetailImpl(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static void throwSOAPFaultException(String paramString1, String paramString2, Throwable paramThrowable) throws SOAPFaultException { throw new SOAPFaultException(new QName("http://schemas.xmlsoap.org/soap/envelope/", paramString1), paramString2, null, newDetail(paramThrowable)); }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Detail newDetail(Throwable paramThrowable) {
/*  61 */     if (paramThrowable instanceof SOAPFaultException) {
/*  62 */       return ((SOAPFaultException)paramThrowable).getDetail();
/*     */     }
/*  64 */     Detail detail = newDetail();
/*  65 */     return fillDetail(paramThrowable, detail);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Detail fillDetail(Throwable paramThrowable, Detail paramDetail) {
/*     */     try {
/*  72 */       DetailEntry detailEntry = paramDetail.addDetailEntry(FAULT_NAME);
/*  73 */       detailEntry.addNamespaceDeclaration("bea_fault", "http://www.bea.com/servers/wls70/webservice/fault/1.0.0");
/*  74 */       StringBuffer stringBuffer = new StringBuffer();
/*  75 */       Throwable throwable = paramThrowable;
/*  76 */       String str = "";
/*     */       
/*     */       do {
/*  79 */         stringBuffer.append(str);
/*  80 */         stringBuffer.append(StackTraceUtils.throwable2StackTrace(paramThrowable));
/*     */         
/*  82 */         if (isJ2ME) {
/*  83 */           throwable = null;
/*     */         } else {
/*     */           try {
/*  86 */             throwable = throwable.getCause();
/*  87 */           } catch (NoSuchMethodError noSuchMethodError) {
/*     */             
/*  89 */             throwable = null;
/*     */           } 
/*     */         } 
/*     */         
/*  93 */         str = "Caused by: ";
/*  94 */       } while (throwable != null);
/*     */       
/*  96 */       detailEntry.addTextNode(stringBuffer.toString());
/*     */     }
/*  98 */     catch (SOAPException sOAPException) {
/*     */       
/* 100 */       throw new AssertionError(sOAPException);
/*     */     } 
/* 102 */     return paramDetail;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fillFault(SOAPFault paramSOAPFault, Throwable paramThrowable) throws SOAPException {
/* 108 */     if (paramThrowable instanceof SOAPFaultException) {
/* 109 */       SOAPFaultException sOAPFaultException = (SOAPFaultException)paramThrowable;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       addFaultCode(paramSOAPFault, sOAPFaultException);
/*     */       
/* 116 */       paramSOAPFault.setFaultString(sOAPFaultException.getFaultString());
/*     */       
/* 118 */       String str = sOAPFaultException.getFaultActor();
/*     */       
/* 120 */       if (str != null) {
/* 121 */         paramSOAPFault.setFaultActor(str);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 127 */       if (sOAPFaultException.getDetail() != null)
/*     */       {
/* 129 */         ((SOAPFaultImpl)paramSOAPFault).setDetail(sOAPFaultException.getDetail());
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 138 */     else if (paramThrowable.getClass().getName().endsWith("AccessException")) {
/* 139 */       paramSOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":Client.Authentication");
/* 140 */       paramSOAPFault.setFaultString(paramThrowable.getMessage());
/* 141 */       fillDetail(paramThrowable, paramSOAPFault.addDetail());
/*     */     } else {
/*     */       
/* 144 */       paramSOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":Server");
/* 145 */       paramSOAPFault.setFaultString("Exception during processing: " + paramThrowable.toString() + " (see Fault Detail for stacktrace)");
/*     */       
/* 147 */       fillDetail(paramThrowable, paramSOAPFault.addDetail());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void addFaultCode(SOAPFault paramSOAPFault, SOAPFaultException paramSOAPFaultException) throws SOAPException {
/* 153 */     QName qName = paramSOAPFaultException.getFaultCode();
/*     */     
/* 155 */     if (qName == null) {
/* 156 */       paramSOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":Server");
/*     */     } else {
/* 158 */       String str1 = qName.getLocalPart();
/* 159 */       String str2 = qName.getNamespaceURI();
/*     */       
/* 161 */       if (str1 == null) str1 = "Server";
/*     */       
/* 163 */       if (str2 == null) {
/* 164 */         paramSOAPFault.setFaultCode(SOAPElementImpl.ENV_PREFIX + ":" + str1);
/*     */       } else {
/* 166 */         paramSOAPFault.addNamespaceDeclaration("fault", str2);
/* 167 */         paramSOAPFault.setFaultCode("fault:" + str1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SOAPMessage exception2Fault(Throwable paramThrowable) {
/*     */     try {
/* 179 */       SOAPMessage sOAPMessage = WLMessageFactory.getInstance().getMessageFactory().createMessage();
/*     */ 
/*     */       
/* 182 */       SOAPFault sOAPFault = sOAPMessage.getSOAPPart().getEnvelope().getBody().addFault();
/*     */ 
/*     */ 
/*     */       
/* 186 */       if (!isJ2ME) {
/* 187 */         paramThrowable = ExceptionUtil.unwrapException(paramThrowable);
/*     */       }
/*     */       
/* 190 */       fillFault(sOAPFault, paramThrowable);
/*     */       
/* 192 */       return sOAPMessage;
/* 193 */     } catch (SOAPException sOAPException) {
/*     */       
/* 195 */       throw new AssertionError(sOAPException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\FaultUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */