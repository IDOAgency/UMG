/*    */ package weblogic.webservice.util;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.cert.X509Certificate;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.security.auth.login.LoginException;
/*    */ import weblogic.security.SimpleCallbackHandler;
/*    */ import weblogic.security.SubjectUtils;
/*    */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*    */ import weblogic.security.service.AuthorizationManager;
/*    */ import weblogic.security.service.PrincipalAuthenticator;
/*    */ import weblogic.security.service.PrivilegedActions;
/*    */ import weblogic.security.service.SecurityService;
/*    */ import weblogic.security.service.SecurityServiceManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServerSecurityHelper
/*    */ {
/* 24 */   private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   private static final Map authenticators = new HashMap();
/*    */ 
/*    */ 
/*    */   
/* 33 */   public static final AuthenticatedSubject getCurrentSubject() { return SecurityServiceManager.getCurrentSubject(getKernelID()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static AuthenticatedSubject assertIdentity(String paramString1, String paramString2, String paramString3) throws LoginException {
/* 42 */     SimpleCallbackHandler simpleCallbackHandler = new SimpleCallbackHandler(paramString1, paramString2);
/*    */ 
/*    */     
/* 45 */     return getPrincipalAuthenticator(paramString3).authenticate(simpleCallbackHandler);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static AuthenticatedSubject assertIdentity(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws LoginException {
/*    */     try {
/* 52 */       return getPrincipalAuthenticator(paramString).assertIdentity("X.509", paramArrayOfX509Certificate);
/*    */     
/*    */     }
/* 55 */     catch (SecurityException securityException) {
/* 56 */       return null;
/* 57 */     } catch (ClassCastException classCastException) {
/* 58 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void assertAnonymousIdentity() {
/* 63 */     AuthenticatedSubject authenticatedSubject = SubjectUtils.getAnonymousSubject();
/* 64 */     SecurityServiceManager.pushSubject(kernelID, authenticatedSubject);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static PrincipalAuthenticator getPrincipalAuthenticator(String paramString) {
/* 70 */     if (paramString == null) paramString = "weblogicDEFAULT";
/*    */     
/* 72 */     PrincipalAuthenticator principalAuthenticator = (PrincipalAuthenticator)authenticators.get(paramString);
/*    */ 
/*    */     
/* 75 */     if (principalAuthenticator == null) {
/* 76 */       principalAuthenticator = (PrincipalAuthenticator)SecurityServiceManager.getSecurityService(getKernelID(), paramString, SecurityService.ServiceType.AUTHENTICATION);
/*    */ 
/*    */ 
/*    */       
/* 80 */       authenticators.put(paramString, principalAuthenticator);
/*    */     } 
/*    */     
/* 83 */     return principalAuthenticator;
/*    */   }
/*    */ 
/*    */   
/* 87 */   public static final AuthorizationManager getAuthManager(String paramString) { return (AuthorizationManager)SecurityServiceManager.getSecurityService(getKernelID(), paramString, SecurityService.ServiceType.AUTHORIZE); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 96 */   private static AuthenticatedSubject getKernelID() { return kernelID; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\ServerSecurityHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */