package weblogic.webservice.util;

import java.security.AccessController;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import javax.security.auth.login.LoginException;
import weblogic.security.SimpleCallbackHandler;
import weblogic.security.SubjectUtils;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.service.AuthorizationManager;
import weblogic.security.service.PrincipalAuthenticator;
import weblogic.security.service.PrivilegedActions;
import weblogic.security.service.SecurityService;
import weblogic.security.service.SecurityServiceManager;

public class ServerSecurityHelper {
  private static final AuthenticatedSubject kernelID = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
  
  private static final Map authenticators = new HashMap();
  
  public static final AuthenticatedSubject getCurrentSubject() { return SecurityServiceManager.getCurrentSubject(getKernelID()); }
  
  public static AuthenticatedSubject assertIdentity(String paramString1, String paramString2, String paramString3) throws LoginException {
    SimpleCallbackHandler simpleCallbackHandler = new SimpleCallbackHandler(paramString1, paramString2);
    return getPrincipalAuthenticator(paramString3).authenticate(simpleCallbackHandler);
  }
  
  public static AuthenticatedSubject assertIdentity(X509Certificate[] paramArrayOfX509Certificate, String paramString) throws LoginException {
    try {
      return getPrincipalAuthenticator(paramString).assertIdentity("X.509", paramArrayOfX509Certificate);
    } catch (SecurityException securityException) {
      return null;
    } catch (ClassCastException classCastException) {
      return null;
    } 
  }
  
  public static void assertAnonymousIdentity() {
    AuthenticatedSubject authenticatedSubject = SubjectUtils.getAnonymousSubject();
    SecurityServiceManager.pushSubject(kernelID, authenticatedSubject);
  }
  
  private static PrincipalAuthenticator getPrincipalAuthenticator(String paramString) {
    if (paramString == null)
      paramString = "weblogicDEFAULT"; 
    PrincipalAuthenticator principalAuthenticator = (PrincipalAuthenticator)authenticators.get(paramString);
    if (principalAuthenticator == null) {
      principalAuthenticator = (PrincipalAuthenticator)SecurityServiceManager.getSecurityService(getKernelID(), paramString, SecurityService.ServiceType.AUTHENTICATION);
      authenticators.put(paramString, principalAuthenticator);
    } 
    return principalAuthenticator;
  }
  
  public static final AuthorizationManager getAuthManager(String paramString) { return (AuthorizationManager)SecurityServiceManager.getSecurityService(getKernelID(), paramString, SecurityService.ServiceType.AUTHORIZE); }
  
  private static AuthenticatedSubject getKernelID() { return kernelID; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\ServerSecurityHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */