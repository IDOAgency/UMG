package weblogic.webservice.util.jspgen;

abstract class Tag {
  private String content;
  
  public String getContent() { return this.content; }
  
  public void setContent(String paramString) { this.content = paramString; }
  
  public abstract void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Tag.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */