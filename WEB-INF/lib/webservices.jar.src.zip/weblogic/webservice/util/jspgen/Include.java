package weblogic.webservice.util.jspgen;

import java.util.StringTokenizer;

class Include extends Tag {
  private ResourceProvider provider;
  
  public Include(ResourceProvider paramResourceProvider) { this.provider = paramResourceProvider; }
  
  public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
    String str = getContent();
    StringTokenizer stringTokenizer = new StringTokenizer(str);
    if (stringTokenizer.hasMoreTokens()) {
      String str1 = stringTokenizer.nextToken();
      if (str1.startsWith("file=")) {
        str1 = str1.substring("file=".length(), str1.length());
        if (str1.charAt(0) == '"')
          str1 = str1.substring(1, str1.length()); 
        if (str1.charAt(str1.length() - 1) == '"')
          str1 = str1.substring(0, str1.length() - 1); 
        (new LightJspParser(this.provider.getResource(str1), this.provider)).generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Include.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */