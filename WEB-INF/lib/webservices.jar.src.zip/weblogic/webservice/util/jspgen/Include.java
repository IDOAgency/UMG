/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ class Include
/*    */   extends Tag
/*    */ {
/*    */   private ResourceProvider provider;
/*    */   
/* 10 */   public Include(ResourceProvider paramResourceProvider) { this.provider = paramResourceProvider; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
/* 16 */     String str = getContent();
/* 17 */     StringTokenizer stringTokenizer = new StringTokenizer(str);
/*    */     
/* 19 */     if (stringTokenizer.hasMoreTokens()) {
/* 20 */       String str1 = stringTokenizer.nextToken();
/*    */       
/* 22 */       if (str1.startsWith("file=")) {
/* 23 */         str1 = str1.substring("file=".length(), str1.length());
/*    */         
/* 25 */         if (str1.charAt(0) == '"') {
/* 26 */           str1 = str1.substring(1, str1.length());
/*    */         }
/* 28 */         if (str1.charAt(str1.length() - 1) == '"') {
/* 29 */           str1 = str1.substring(0, str1.length() - 1);
/*    */         }
/*    */         
/* 32 */         (new LightJspParser(this.provider.getResource(str1), this.provider)).generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Include.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */