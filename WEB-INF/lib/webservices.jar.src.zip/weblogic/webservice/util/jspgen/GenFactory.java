package weblogic.webservice.util.jspgen;

public class GenFactory {
  public static JspGenBase create(String paramString) throws ScriptException {
    try {
      Class clazz = Class.forName(paramString);
      return (JspGenBase)clazz.newInstance();
    } catch (ClassNotFoundException classNotFoundException) {
      throw new ScriptException("unable to find the generated script class:" + paramString);
    } catch (InstantiationException instantiationException) {
      throw new ScriptException("unable to create the generated script class:" + paramString);
    } catch (IllegalAccessException illegalAccessException) {
      throw new ScriptException("unable to create the generated script class:" + paramString);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\GenFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */