/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenFactory
/*    */ {
/*    */   public static JspGenBase create(String paramString) throws ScriptException {
/*    */     try {
/* 11 */       Class clazz = Class.forName(paramString);
/* 12 */       return (JspGenBase)clazz.newInstance();
/* 13 */     } catch (ClassNotFoundException classNotFoundException) {
/* 14 */       throw new ScriptException("unable to find the generated script class:" + paramString);
/*    */     }
/* 16 */     catch (InstantiationException instantiationException) {
/* 17 */       throw new ScriptException("unable to create the generated script class:" + paramString);
/*    */     }
/* 19 */     catch (IllegalAccessException illegalAccessException) {
/* 20 */       throw new ScriptException("unable to create the generated script class:" + paramString);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\GenFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */