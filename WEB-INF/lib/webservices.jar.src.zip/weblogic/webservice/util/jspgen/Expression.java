/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ 
/*    */ class Expression
/*    */   extends Tag
/*    */ {
/*    */   public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
/*  8 */     String str = getContent();
/*  9 */     str = str.substring(3, str.length() - 2);
/* 10 */     paramStringBuffer1.append("\n out.print( " + str + " );");
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Expression.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */