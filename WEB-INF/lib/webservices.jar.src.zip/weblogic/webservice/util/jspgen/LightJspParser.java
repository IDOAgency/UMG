/*     */ package weblogic.webservice.util.jspgen;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LightJspParser
/*     */ {
/*     */   private String page;
/*     */   private ResourceProvider provider;
/*     */   
/*     */   public LightJspParser(String paramString, ResourceProvider paramResourceProvider) {
/*  17 */     this.page = paramString;
/*  18 */     this.provider = paramResourceProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
/*  24 */     paramStringBuffer1.append("  public void generate() \n");
/*  25 */     paramStringBuffer1.append("   throws weblogic.webservice.util");
/*  26 */     paramStringBuffer1.append(".jspgen.ScriptException{\n");
/*     */     
/*  28 */     generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
/*     */     
/*  30 */     paramStringBuffer1.append("  }\n");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
/*  36 */     Iterator iterator = getTags();
/*     */     
/*  38 */     while (iterator.hasNext()) {
/*  39 */       Tag tag = (Tag)iterator.next();
/*  40 */       tag.generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Iterator getTags() throws ScriptException {
/*  46 */     StringBuffer stringBuffer = new StringBuffer();
/*  47 */     ArrayList arrayList = new ArrayList();
/*  48 */     Iterator iterator = split(this.page);
/*     */     
/*  50 */     while (iterator.hasNext()) {
/*  51 */       String str = (String)iterator.next();
/*  52 */       Tag tag = createTag(str);
/*  53 */       tag.setContent(str);
/*  54 */       arrayList.add(tag);
/*     */     } 
/*     */     
/*  57 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   private Iterator split(String paramString) throws ScriptException {
/*  61 */     String str1 = "<%";
/*  62 */     String str2 = "%>";
/*     */     
/*  64 */     ArrayList arrayList = new ArrayList();
/*     */     
/*  66 */     int i = 0;
/*  67 */     boolean bool = false;
/*     */     
/*  69 */     while (!bool) {
/*  70 */       int j = paramString.indexOf(str1, i);
/*     */ 
/*     */       
/*  73 */       if (j == -1) {
/*  74 */         arrayList.add(paramString.substring(i, paramString.length()));
/*  75 */         bool = true;
/*     */         continue;
/*     */       } 
/*  78 */       if (i != j) {
/*  79 */         arrayList.add(paramString.substring(i, j));
/*     */       }
/*     */       
/*  82 */       i = j;
/*  83 */       int k = paramString.indexOf(str2, i);
/*     */       
/*  85 */       if (k == -1) {
/*  86 */         throw new ScriptException("unable to find the end tag " + i + " " + ((arrayList.size() == 0) ? "at start" : arrayList.get(arrayList.size() - 1)));
/*     */       }
/*     */ 
/*     */       
/*  90 */       arrayList.add(paramString.substring(i, k + 2));
/*  91 */       i = k + 2;
/*     */     } 
/*     */ 
/*     */     
/*  95 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   private Tag createTag(String paramString) {
/*  99 */     if (paramString.startsWith("<%--")) {
/* 100 */       return new Comment();
/*     */     }
/*     */     
/* 103 */     if (paramString.startsWith("<%=")) {
/* 104 */       return new Expression();
/*     */     }
/*     */     
/* 107 */     if (paramString.startsWith("<%!")) {
/* 108 */       return new Declaration();
/*     */     }
/*     */     
/* 111 */     if (paramString.startsWith("<%@")) {
/* 112 */       return new Directive(this.provider);
/*     */     }
/*     */     
/* 115 */     if (paramString.startsWith("<%")) {
/* 116 */       return new Scriptlet();
/*     */     }
/*     */     
/* 119 */     return new Text();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\LightJspParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */