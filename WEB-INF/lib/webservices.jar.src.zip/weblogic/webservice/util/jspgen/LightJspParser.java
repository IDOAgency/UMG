package weblogic.webservice.util.jspgen;

import java.util.ArrayList;
import java.util.Iterator;

public class LightJspParser {
  private String page;
  
  private ResourceProvider provider;
  
  public LightJspParser(String paramString, ResourceProvider paramResourceProvider) {
    this.page = paramString;
    this.provider = paramResourceProvider;
  }
  
  public void parse(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
    paramStringBuffer1.append("  public void generate() \n");
    paramStringBuffer1.append("   throws weblogic.webservice.util");
    paramStringBuffer1.append(".jspgen.ScriptException{\n");
    generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
    paramStringBuffer1.append("  }\n");
  }
  
  public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
    Iterator iterator = getTags();
    while (iterator.hasNext()) {
      Tag tag = (Tag)iterator.next();
      tag.generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
    } 
  }
  
  private Iterator getTags() throws ScriptException {
    StringBuffer stringBuffer = new StringBuffer();
    ArrayList arrayList = new ArrayList();
    Iterator iterator = split(this.page);
    while (iterator.hasNext()) {
      String str = (String)iterator.next();
      Tag tag = createTag(str);
      tag.setContent(str);
      arrayList.add(tag);
    } 
    return arrayList.iterator();
  }
  
  private Iterator split(String paramString) throws ScriptException {
    String str1 = "<%";
    String str2 = "%>";
    ArrayList arrayList = new ArrayList();
    int i = 0;
    boolean bool = false;
    while (!bool) {
      int j = paramString.indexOf(str1, i);
      if (j == -1) {
        arrayList.add(paramString.substring(i, paramString.length()));
        bool = true;
        continue;
      } 
      if (i != j)
        arrayList.add(paramString.substring(i, j)); 
      i = j;
      int k = paramString.indexOf(str2, i);
      if (k == -1)
        throw new ScriptException("unable to find the end tag " + i + " " + ((arrayList.size() == 0) ? "at start" : arrayList.get(arrayList.size() - 1))); 
      arrayList.add(paramString.substring(i, k + 2));
      i = k + 2;
    } 
    return arrayList.iterator();
  }
  
  private Tag createTag(String paramString) {
    if (paramString.startsWith("<%--"))
      return new Comment(); 
    if (paramString.startsWith("<%="))
      return new Expression(); 
    if (paramString.startsWith("<%!"))
      return new Declaration(); 
    if (paramString.startsWith("<%@"))
      return new Directive(this.provider); 
    if (paramString.startsWith("<%"))
      return new Scriptlet(); 
    return new Text();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\LightJspParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */