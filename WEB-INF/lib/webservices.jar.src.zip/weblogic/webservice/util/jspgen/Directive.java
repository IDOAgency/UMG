package weblogic.webservice.util.jspgen;

import java.util.StringTokenizer;

class Directive extends Tag {
  private ResourceProvider provider;
  
  public Directive(ResourceProvider paramResourceProvider) { this.provider = paramResourceProvider; }
  
  private String toString(StringTokenizer paramStringTokenizer) {
    StringBuffer stringBuffer = new StringBuffer();
    while (paramStringTokenizer.hasMoreTokens()) {
      stringBuffer.append(paramStringTokenizer.nextToken());
      stringBuffer.append(" ");
    } 
    return stringBuffer.toString();
  }
  
  public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
    String str1 = getContent();
    str1 = str1.substring(3, str1.length() - 2);
    StringTokenizer stringTokenizer = new StringTokenizer(str1);
    String str2 = null;
    if (stringTokenizer.hasMoreTokens()) {
      str2 = stringTokenizer.nextToken();
      if ("include".equals(str2)) {
        Include include = new Include(this.provider);
        include.setContent(toString(stringTokenizer));
        include.generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
      } else if ("page".equals(str2)) {
        Page page = new Page();
        page.setContent(toString(stringTokenizer));
        page.generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
      } 
    } else {
      throw new ScriptException("failed to parse: usage <%@ include|page ... %>");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Directive.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */