/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ class Directive
/*    */   extends Tag
/*    */ {
/*    */   private ResourceProvider provider;
/*    */   
/* 10 */   public Directive(ResourceProvider paramResourceProvider) { this.provider = paramResourceProvider; }
/*    */ 
/*    */   
/*    */   private String toString(StringTokenizer paramStringTokenizer) {
/* 14 */     StringBuffer stringBuffer = new StringBuffer();
/*    */     
/* 16 */     while (paramStringTokenizer.hasMoreTokens()) {
/* 17 */       stringBuffer.append(paramStringTokenizer.nextToken());
/* 18 */       stringBuffer.append(" ");
/*    */     } 
/*    */     
/* 21 */     return stringBuffer.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
/* 27 */     String str1 = getContent();
/* 28 */     str1 = str1.substring(3, str1.length() - 2);
/*    */     
/* 30 */     StringTokenizer stringTokenizer = new StringTokenizer(str1);
/* 31 */     String str2 = null;
/*    */     
/* 33 */     if (stringTokenizer.hasMoreTokens()) {
/* 34 */       str2 = stringTokenizer.nextToken();
/*    */       
/* 36 */       if ("include".equals(str2)) {
/* 37 */         Include include = new Include(this.provider);
/* 38 */         include.setContent(toString(stringTokenizer));
/* 39 */         include.generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
/* 40 */       } else if ("page".equals(str2)) {
/* 41 */         Page page = new Page();
/* 42 */         page.setContent(toString(stringTokenizer));
/* 43 */         page.generate(paramStringBuffer1, paramStringBuffer2, paramStringBuffer3);
/*    */       } 
/*    */     } else {
/* 46 */       throw new ScriptException("failed to parse: usage <%@ include|page ... %>");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Directive.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */