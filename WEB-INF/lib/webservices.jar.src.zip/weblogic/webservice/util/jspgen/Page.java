/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ 
/*    */ class Page
/*    */   extends Tag
/*    */ {
/*    */   public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
/* 10 */     String str1 = getContent();
/* 11 */     String str2 = str1.trim();
/*    */     
/* 13 */     if (str2.startsWith("import=")) {
/* 14 */       str2 = str2.substring("import=".length(), str2.length());
/*    */       
/* 16 */       if (str2.charAt(0) == '"') {
/* 17 */         str2 = str2.substring(1, str2.length());
/*    */       }
/*    */       
/* 20 */       if (str2.charAt(str2.length() - 1) == '"') {
/* 21 */         str2 = str2.substring(0, str2.length() - 1);
/*    */       }
/*    */       
/* 24 */       StringTokenizer stringTokenizer = new StringTokenizer(str2, ",");
/*    */       
/* 26 */       while (stringTokenizer.hasMoreTokens()) {
/* 27 */         String str = stringTokenizer.nextToken().trim();
/* 28 */         paramStringBuffer3.append("import ");
/* 29 */         paramStringBuffer3.append(str);
/* 30 */         paramStringBuffer3.append(";\n");
/*    */       } 
/*    */     } else {
/* 33 */       throw new ScriptException("usage: <%@ page import=\"<className>\" %>");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Page.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */