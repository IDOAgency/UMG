package weblogic.webservice.util.jspgen;

import java.util.StringTokenizer;

class Page extends Tag {
  public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
    String str1 = getContent();
    String str2 = str1.trim();
    if (str2.startsWith("import=")) {
      str2 = str2.substring("import=".length(), str2.length());
      if (str2.charAt(0) == '"')
        str2 = str2.substring(1, str2.length()); 
      if (str2.charAt(str2.length() - 1) == '"')
        str2 = str2.substring(0, str2.length() - 1); 
      StringTokenizer stringTokenizer = new StringTokenizer(str2, ",");
      while (stringTokenizer.hasMoreTokens()) {
        String str = stringTokenizer.nextToken().trim();
        paramStringBuffer3.append("import ");
        paramStringBuffer3.append(str);
        paramStringBuffer3.append(";\n");
      } 
    } else {
      throw new ScriptException("usage: <%@ page import=\"<className>\" %>");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Page.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */