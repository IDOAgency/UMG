package weblogic.webservice.util.jspgen;

public interface ResourceProvider {
  String getResource(String paramString) throws ScriptException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\ResourceProvider.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */