/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Main
/*    */   implements ResourceProvider
/*    */ {
/*    */   private String jspfile;
/*    */   private String outputFileName;
/*    */   private String packageName;
/*    */   private String className;
/*    */   private String baseClassName;
/*    */   private File root;
/*    */   private static final boolean verbose = true;
/*    */   
/*    */   public Main(String paramString1, String paramString2, String paramString3, String paramString4) throws IOException, ScriptException {
/* 26 */     this.jspfile = paramString1;
/* 27 */     this.packageName = paramString3;
/* 28 */     this.baseClassName = paramString4;
/*    */     
/* 30 */     this.root = (new File(paramString1)).getParentFile();
/*    */     
/* 32 */     if (this.root == null) {
/* 33 */       this.root = new File(".");
/*    */     }
/*    */     
/* 36 */     int i = paramString1.lastIndexOf(".");
/*    */     
/* 38 */     String str = (i == -1) ? paramString1 : paramString1.substring(0, i);
/*    */ 
/*    */     
/* 41 */     i = str.lastIndexOf("/");
/*    */     
/* 43 */     this.className = (i == -1) ? str : str.substring(i + 1, str.length());
/*    */ 
/*    */     
/* 46 */     this.outputFileName = paramString2 + File.separator + paramString3.replace('.', File.separatorChar) + File.separator + this.className + ".java";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getResource(String paramString) throws ScriptException {
/* 54 */     File file = paramString.startsWith(File.separator) ? new File(paramString) : new File(this.root, paramString);
/*    */ 
/*    */     
/* 57 */     return Util.fileToString(file.getPath());
/*    */   }
/*    */   
/*    */   private void generate() throws ScriptException {
/* 61 */     String str = Util.fileToString(this.jspfile);
/* 62 */     StringBuffer stringBuffer1 = new StringBuffer();
/* 63 */     StringBuffer stringBuffer2 = new StringBuffer();
/* 64 */     StringBuffer stringBuffer3 = new StringBuffer();
/*    */     
/* 66 */     (new LightJspParser(str, this)).parse(stringBuffer1, stringBuffer3, stringBuffer2);
/*    */     
/* 68 */     StringBuffer stringBuffer4 = new StringBuffer();
/*    */     
/* 70 */     stringBuffer4.append("package " + this.packageName + ";\n\n");
/* 71 */     stringBuffer4.append(stringBuffer2);
/*    */ 
/*    */ 
/*    */     
/* 75 */     stringBuffer4.append("public class ").append(this.className).append(" ");
/* 76 */     stringBuffer4.append("extends ");
/* 77 */     stringBuffer4.append(this.baseClassName).append("{\n");
/* 78 */     stringBuffer4.append(stringBuffer3);
/* 79 */     stringBuffer4.append(stringBuffer1);
/* 80 */     stringBuffer4.append("}");
/*    */     
/* 82 */     Util.stringToFile(this.outputFileName, stringBuffer4.toString());
/*    */   }
/*    */   
/*    */   public static void main(String[] paramArrayOfString) throws Exception {
/* 86 */     if (paramArrayOfString.length != 4) {
/* 87 */       System.out.println("usage: java Main <filename.jspgen> <output-dir> <package-name> <base-class>");
/*    */     } else {
/*    */       
/* 90 */       Main main = new Main(paramArrayOfString[0], paramArrayOfString[1], paramArrayOfString[2], paramArrayOfString[3]);
/* 91 */       main.generate();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Main.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */