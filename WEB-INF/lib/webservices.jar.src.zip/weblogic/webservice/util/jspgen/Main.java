package weblogic.webservice.util.jspgen;

import java.io.File;
import java.io.IOException;

public class Main implements ResourceProvider {
  private String jspfile;
  
  private String outputFileName;
  
  private String packageName;
  
  private String className;
  
  private String baseClassName;
  
  private File root;
  
  private static final boolean verbose = true;
  
  public Main(String paramString1, String paramString2, String paramString3, String paramString4) throws IOException, ScriptException {
    this.jspfile = paramString1;
    this.packageName = paramString3;
    this.baseClassName = paramString4;
    this.root = (new File(paramString1)).getParentFile();
    if (this.root == null)
      this.root = new File("."); 
    int i = paramString1.lastIndexOf(".");
    String str = (i == -1) ? paramString1 : paramString1.substring(0, i);
    i = str.lastIndexOf("/");
    this.className = (i == -1) ? str : str.substring(i + 1, str.length());
    this.outputFileName = paramString2 + File.separator + paramString3.replace('.', File.separatorChar) + File.separator + this.className + ".java";
  }
  
  public String getResource(String paramString) throws ScriptException {
    File file = paramString.startsWith(File.separator) ? new File(paramString) : new File(this.root, paramString);
    return Util.fileToString(file.getPath());
  }
  
  private void generate() throws ScriptException {
    String str = Util.fileToString(this.jspfile);
    StringBuffer stringBuffer1 = new StringBuffer();
    StringBuffer stringBuffer2 = new StringBuffer();
    StringBuffer stringBuffer3 = new StringBuffer();
    (new LightJspParser(str, this)).parse(stringBuffer1, stringBuffer3, stringBuffer2);
    StringBuffer stringBuffer4 = new StringBuffer();
    stringBuffer4.append("package " + this.packageName + ";\n\n");
    stringBuffer4.append(stringBuffer2);
    stringBuffer4.append("public class ").append(this.className).append(" ");
    stringBuffer4.append("extends ");
    stringBuffer4.append(this.baseClassName).append("{\n");
    stringBuffer4.append(stringBuffer3);
    stringBuffer4.append(stringBuffer1);
    stringBuffer4.append("}");
    Util.stringToFile(this.outputFileName, stringBuffer4.toString());
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    if (paramArrayOfString.length != 4) {
      System.out.println("usage: java Main <filename.jspgen> <output-dir> <package-name> <base-class>");
    } else {
      Main main = new Main(paramArrayOfString[0], paramArrayOfString[1], paramArrayOfString[2], paramArrayOfString[3]);
      main.generate();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Main.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */