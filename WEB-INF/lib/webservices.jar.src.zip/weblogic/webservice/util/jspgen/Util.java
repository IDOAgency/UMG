/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import weblogic.webservice.WebServiceLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Util
/*    */ {
/*    */   public static String fileToString(String paramString) throws ScriptException {
/*    */     try {
/* 18 */       FileInputStream fileInputStream = new FileInputStream(paramString);
/*    */       
/* 20 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*    */       
/*    */       int i;
/* 23 */       while ((i = fileInputStream.read()) != -1) {
/* 24 */         byteArrayOutputStream.write(i);
/*    */       }
/*    */       
/* 27 */       fileInputStream.close();
/* 28 */       return new String(byteArrayOutputStream.toByteArray(), "UTF-8");
/* 29 */     } catch (IOException iOException) {
/* 30 */       String str = WebServiceLogger.logfileToStringIOException();
/* 31 */       WebServiceLogger.logStackTrace(str, iOException);
/* 32 */       throw new ScriptException("Failed to open include file " + paramString);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void stringToFile(String paramString1, String paramString2) throws ScriptException {
/*    */     try {
/* 39 */       FileOutputStream fileOutputStream = new FileOutputStream(paramString1);
/* 40 */       fileOutputStream.write(paramString2.getBytes());
/* 41 */       fileOutputStream.close();
/* 42 */     } catch (IOException iOException) {
/* 43 */       throw new ScriptException("unable to write javascript file:" + paramString1);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */