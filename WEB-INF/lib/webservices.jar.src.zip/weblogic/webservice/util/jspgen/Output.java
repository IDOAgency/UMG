/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Output
/*    */ {
/*    */   private PrintStream output;
/*    */   
/* 13 */   public Output(PrintStream paramPrintStream) { this.output = paramPrintStream; }
/*    */ 
/*    */ 
/*    */   
/* 17 */   public void print(Object paramObject) { this.output.print((paramObject == null) ? "null" : paramObject.toString()); }
/*    */ 
/*    */ 
/*    */   
/* 21 */   public void println(Object paramObject) { this.output.println((paramObject == null) ? "null" : paramObject.toString()); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Output.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */