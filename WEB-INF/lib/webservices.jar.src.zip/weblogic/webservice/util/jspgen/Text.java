/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ class Text
/*    */   extends Tag
/*    */ {
/*    */   private String clean(String paramString) {
/*  9 */     if ("\n".equals(paramString)) {
/* 10 */       return "\\n";
/*    */     }
/*    */     
/* 13 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\"", true);
/* 14 */     StringBuffer stringBuffer = new StringBuffer();
/*    */     
/* 16 */     while (stringTokenizer.hasMoreTokens()) {
/* 17 */       String str = stringTokenizer.nextToken();
/*    */       
/* 19 */       if (str.equals("\"")) {
/* 20 */         stringBuffer.append("\\\""); continue;
/*    */       } 
/* 22 */       stringBuffer.append(str);
/*    */     } 
/*    */ 
/*    */     
/* 26 */     return stringBuffer.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
/* 32 */     String str = getContent();
/*    */     
/* 34 */     if (str == null) {
/*    */       return;
/*    */     }
/*    */     
/* 38 */     str = removeNewLines(str);
/*    */     
/* 40 */     StringBuffer stringBuffer = new StringBuffer();
/* 41 */     StringTokenizer stringTokenizer = new StringTokenizer(str, "\r\n\f", true);
/*    */ 
/*    */     
/* 44 */     while (stringTokenizer.hasMoreTokens()) {
/* 45 */       String str1 = stringTokenizer.nextToken();
/*    */       
/* 47 */       if (str1.equals("\r") || str1.equals("\f")) {
/*    */         continue;
/*    */       }
/*    */       
/* 51 */       stringBuffer.append("  out.print( \"");
/* 52 */       stringBuffer.append(clean(str1));
/* 53 */       stringBuffer.append("\" );\n");
/*    */     } 
/*    */     
/* 56 */     paramStringBuffer1.append(stringBuffer);
/*    */   }
/*    */   
/*    */   private String removeNewLines(String paramString) {
/* 60 */     if (paramString.startsWith("\n")) {
/* 61 */       paramString = paramString.substring(1, paramString.length());
/* 62 */     } else if (paramString.startsWith("\r\n")) {
/* 63 */       paramString = paramString.substring(2, paramString.length());
/*    */     } 
/*    */     
/* 66 */     if (paramString.endsWith("\n")) {
/* 67 */       paramString = paramString.substring(0, paramString.length() - 1);
/* 68 */     } else if (paramString.endsWith("\r\n")) {
/* 69 */       paramString = paramString.substring(0, paramString.length() - 2);
/*    */     } 
/* 71 */     return paramString;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Text.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */