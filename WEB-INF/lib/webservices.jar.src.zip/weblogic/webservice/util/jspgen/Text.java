package weblogic.webservice.util.jspgen;

import java.util.StringTokenizer;

class Text extends Tag {
  private String clean(String paramString) {
    if ("\n".equals(paramString))
      return "\\n"; 
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\"", true);
    StringBuffer stringBuffer = new StringBuffer();
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (str.equals("\"")) {
        stringBuffer.append("\\\"");
        continue;
      } 
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public void generate(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws ScriptException {
    String str = getContent();
    if (str == null)
      return; 
    str = removeNewLines(str);
    StringBuffer stringBuffer = new StringBuffer();
    StringTokenizer stringTokenizer = new StringTokenizer(str, "\r\n\f", true);
    while (stringTokenizer.hasMoreTokens()) {
      String str1 = stringTokenizer.nextToken();
      if (str1.equals("\r") || str1.equals("\f"))
        continue; 
      stringBuffer.append("  out.print( \"");
      stringBuffer.append(clean(str1));
      stringBuffer.append("\" );\n");
    } 
    paramStringBuffer1.append(stringBuffer);
  }
  
  private String removeNewLines(String paramString) {
    if (paramString.startsWith("\n")) {
      paramString = paramString.substring(1, paramString.length());
    } else if (paramString.startsWith("\r\n")) {
      paramString = paramString.substring(2, paramString.length());
    } 
    if (paramString.endsWith("\n")) {
      paramString = paramString.substring(0, paramString.length() - 1);
    } else if (paramString.endsWith("\r\n")) {
      paramString = paramString.substring(0, paramString.length() - 2);
    } 
    return paramString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\Text.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */