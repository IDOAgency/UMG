package weblogic.webservice.util.jspgen;

import java.io.IOException;

public class ScriptException extends IOException {
  public ScriptException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\ScriptException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */