/*    */ package weblogic.webservice.util.jspgen;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JspGenBase
/*    */ {
/* 10 */   protected PrintStream out = System.out;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 16 */   public void setOutput(PrintStream paramPrintStream) { this.out = paramPrintStream; }
/*    */   
/*    */   public void preGenerate() {}
/*    */   
/*    */   public abstract void generate();
/*    */   
/*    */   public void postGenerate() {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\jspgen\JspGenBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */