/*    */ package weblogic.webservice.util;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import weblogic.utils.AssertionError;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HolderUtil
/*    */ {
/*    */   public static Class getRealType(Class paramClass) {
/* 16 */     if (!javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass)) {
/* 17 */       return paramClass;
/*    */     }
/*    */     
/*    */     try {
/* 21 */       Field field = paramClass.getField("value");
/* 22 */       return field.getType();
/* 23 */     } catch (NoSuchFieldException noSuchFieldException) {
/* 24 */       throw new AssertionError("Not a holder class", noSuchFieldException);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\HolderUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */