package weblogic.webservice.util;

import java.lang.reflect.Field;
import weblogic.utils.AssertionError;

public class HolderUtil {
  public static Class getRealType(Class paramClass) {
    if (!javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass))
      return paramClass; 
    try {
      Field field = paramClass.getField("value");
      return field.getType();
    } catch (NoSuchFieldException noSuchFieldException) {
      throw new AssertionError("Not a holder class", noSuchFieldException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\HolderUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */