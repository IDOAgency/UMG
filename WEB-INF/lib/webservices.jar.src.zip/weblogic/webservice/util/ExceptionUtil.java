package weblogic.webservice.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.HashSet;
import javax.xml.rpc.JAXRPCException;
import javax.xml.soap.SOAPException;
import weblogic.utils.AssertionError;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.TypeMappingBuilder;
import weblogic.xml.schema.binding.TypeMappingBuilderFactory;

public final class ExceptionUtil {
  public static Throwable unwrapException(Throwable paramThrowable) {
    if (paramThrowable instanceof InvocationTargetException) {
      InvocationTargetException invocationTargetException = (InvocationTargetException)paramThrowable;
      if (invocationTargetException.getTargetException() != null)
        return unwrapException(invocationTargetException.getTargetException()); 
      return paramThrowable;
    } 
    if (paramThrowable instanceof JAXRPCException) {
      JAXRPCException jAXRPCException = (JAXRPCException)paramThrowable;
      if (jAXRPCException.getLinkedCause() != null)
        return unwrapException(jAXRPCException.getLinkedCause()); 
      return paramThrowable;
    } 
    if (paramThrowable instanceof SOAPException) {
      SOAPException sOAPException = (SOAPException)paramThrowable;
      if (sOAPException.getCause() != null)
        return unwrapException(sOAPException.getCause()); 
      return paramThrowable;
    } 
    if (paramThrowable instanceof RemoteException) {
      RemoteException remoteException = (RemoteException)paramThrowable;
      return (remoteException.detail == null) ? remoteException : remoteException.detail;
    } 
    return paramThrowable;
  }
  
  public static Object getPropertyValue(Object paramObject, Class paramClass) {
    Method[] arrayOfMethod = paramObject.getClass().getMethods();
    for (byte b = 0; b < arrayOfMethod.length; b++) {
      if (arrayOfMethod[b].getName().startsWith("get") && arrayOfMethod[b].getReturnType().equals(paramClass) && arrayOfMethod[b].getParameterTypes().length == 0)
        try {
          return arrayOfMethod[b].invoke(paramObject, new Object[0]);
        } catch (IllegalAccessException illegalAccessException) {
          return null;
        } catch (InvocationTargetException invocationTargetException) {
          return null;
        }  
    } 
    return null;
  }
  
  public static Class getSingleSimpleProperty(Class paramClass) {
    Class clazz = getSingleSimpleType(paramClass);
    if (clazz == null)
      return null; 
    if (getPropertyName(paramClass, clazz) != null)
      return clazz; 
    return null;
  }
  
  public static String getSingleSimplePropertyName(Class paramClass) {
    Class clazz = getSingleSimpleType(paramClass);
    if (clazz == null)
      return null; 
    return getPropertyName(paramClass, clazz);
  }
  
  private static String getPropertyName(Class paramClass1, Class paramClass2) {
    Method[] arrayOfMethod = paramClass1.getMethods();
    for (byte b = 0; b < arrayOfMethod.length; b++) {
      String str = arrayOfMethod[b].getName();
      if (str.startsWith("get") && str.length() > 3 && arrayOfMethod[b].getReturnType().equals(paramClass2) && arrayOfMethod[b].getParameterTypes().length == 0)
        return str.substring(3); 
    } 
    return null;
  }
  
  private static Class getSingleSimpleType(Class paramClass) {
    if (!Exception.class.isAssignableFrom(paramClass))
      throw new AssertionError(paramClass.getName() + " is not an exception."); 
    Constructor[] arrayOfConstructor = paramClass.getConstructors();
    HashSet hashSet = new HashSet();
    TypeMappingBuilder typeMappingBuilder = TypeMappingBuilderFactory.newInstance().createTypeMappingBuilder();
    TypeMapping typeMapping = null;
    try {
      typeMapping = typeMappingBuilder.getTypeMapping();
    } catch (BindingException bindingException) {
      return null;
    } 
    for (byte b = 0; b < arrayOfConstructor.length; b++) {
      Class[] arrayOfClass = arrayOfConstructor[b].getParameterTypes();
      if (arrayOfClass.length != 0) {
        if (arrayOfClass.length > 1)
          return null; 
        hashSet.add(arrayOfClass[0]);
      } 
    } 
    for (Class clazz : hashSet) {
      if (typeMapping.getXMLNameFromClass(clazz) != null)
        return clazz; 
    } 
    return null;
  }
  
  public static Class getSingleArrayProperty(Class paramClass) {
    if (!Exception.class.isAssignableFrom(paramClass))
      throw new AssertionError(paramClass.getName() + " is not an exception."); 
    Constructor[] arrayOfConstructor = paramClass.getConstructors();
    HashSet hashSet = new HashSet();
    for (byte b = 0; b < arrayOfConstructor.length; b++) {
      Class[] arrayOfClass = arrayOfConstructor[b].getParameterTypes();
      if (arrayOfClass.length != 0) {
        if (arrayOfClass.length > 1)
          return null; 
        hashSet.add(arrayOfClass[0]);
      } 
    } 
    for (Class clazz : hashSet) {
      if (clazz.getComponentType() != null && 
        getPropertyName(paramClass, clazz) != null)
        return clazz; 
    } 
    return null;
  }
  
  public static Class getSingleProperty(Class paramClass) {
    if (!Exception.class.isAssignableFrom(paramClass))
      throw new AssertionError(paramClass.getName() + " is not an exception."); 
    Constructor[] arrayOfConstructor = paramClass.getConstructors();
    HashSet hashSet = new HashSet();
    for (byte b = 0; b < arrayOfConstructor.length; b++) {
      Class[] arrayOfClass = arrayOfConstructor[b].getParameterTypes();
      if (arrayOfClass.length != 0) {
        if (arrayOfClass.length > 1)
          return null; 
        hashSet.add(arrayOfClass[0]);
      } 
    } 
    for (Class clazz : hashSet) {
      if (getPropertyName(paramClass, clazz) != null)
        return clazz; 
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\ExceptionUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */