/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashSet;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilder;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExceptionUtil
/*     */ {
/*     */   public static Throwable unwrapException(Throwable paramThrowable) {
/*  32 */     if (paramThrowable instanceof InvocationTargetException) {
/*     */       
/*  34 */       InvocationTargetException invocationTargetException = (InvocationTargetException)paramThrowable;
/*  35 */       if (invocationTargetException.getTargetException() != null) {
/*  36 */         return unwrapException(invocationTargetException.getTargetException());
/*     */       }
/*  38 */       return paramThrowable;
/*     */     } 
/*     */     
/*  41 */     if (paramThrowable instanceof JAXRPCException) {
/*     */       
/*  43 */       JAXRPCException jAXRPCException = (JAXRPCException)paramThrowable;
/*  44 */       if (jAXRPCException.getLinkedCause() != null) {
/*  45 */         return unwrapException(jAXRPCException.getLinkedCause());
/*     */       }
/*  47 */       return paramThrowable;
/*     */     } 
/*  49 */     if (paramThrowable instanceof SOAPException) {
/*     */       
/*  51 */       SOAPException sOAPException = (SOAPException)paramThrowable;
/*     */       
/*  53 */       if (sOAPException.getCause() != null) {
/*  54 */         return unwrapException(sOAPException.getCause());
/*     */       }
/*  56 */       return paramThrowable;
/*     */     } 
/*  58 */     if (paramThrowable instanceof RemoteException) {
/*     */       
/*  60 */       RemoteException remoteException = (RemoteException)paramThrowable;
/*  61 */       return (remoteException.detail == null) ? remoteException : remoteException.detail;
/*     */     } 
/*  63 */     return paramThrowable;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object getPropertyValue(Object paramObject, Class paramClass) {
/*  68 */     Method[] arrayOfMethod = paramObject.getClass().getMethods();
/*     */     
/*  70 */     for (byte b = 0; b < arrayOfMethod.length; b++) {
/*  71 */       if (arrayOfMethod[b].getName().startsWith("get") && arrayOfMethod[b].getReturnType().equals(paramClass) && arrayOfMethod[b].getParameterTypes().length == 0) {
/*     */         
/*     */         try {
/*     */ 
/*     */           
/*  76 */           return arrayOfMethod[b].invoke(paramObject, new Object[0]);
/*  77 */         } catch (IllegalAccessException illegalAccessException) {
/*  78 */           return null;
/*  79 */         } catch (InvocationTargetException invocationTargetException) {
/*  80 */           return null;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  85 */     return null;
/*     */   }
/*     */   
/*     */   public static Class getSingleSimpleProperty(Class paramClass) {
/*  89 */     Class clazz = getSingleSimpleType(paramClass);
/*     */     
/*  91 */     if (clazz == null) return null;
/*     */     
/*  93 */     if (getPropertyName(paramClass, clazz) != null) {
/*  94 */       return clazz;
/*     */     }
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getSingleSimplePropertyName(Class paramClass) {
/* 101 */     Class clazz = getSingleSimpleType(paramClass);
/*     */     
/* 103 */     if (clazz == null) return null;
/*     */     
/* 105 */     return getPropertyName(paramClass, clazz);
/*     */   }
/*     */   
/*     */   private static String getPropertyName(Class paramClass1, Class paramClass2) {
/* 109 */     Method[] arrayOfMethod = paramClass1.getMethods();
/*     */     
/* 111 */     for (byte b = 0; b < arrayOfMethod.length; b++) {
/* 112 */       String str = arrayOfMethod[b].getName();
/* 113 */       if (str.startsWith("get") && str.length() > 3 && arrayOfMethod[b].getReturnType().equals(paramClass2) && arrayOfMethod[b].getParameterTypes().length == 0)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 118 */         return str.substring(3);
/*     */       }
/*     */     } 
/*     */     
/* 122 */     return null;
/*     */   }
/*     */   
/*     */   private static Class getSingleSimpleType(Class paramClass) {
/* 126 */     if (!Exception.class.isAssignableFrom(paramClass)) {
/* 127 */       throw new AssertionError(paramClass.getName() + " is not an exception.");
/*     */     }
/*     */     
/* 130 */     Constructor[] arrayOfConstructor = paramClass.getConstructors();
/* 131 */     HashSet hashSet = new HashSet();
/*     */     
/* 133 */     TypeMappingBuilder typeMappingBuilder = TypeMappingBuilderFactory.newInstance().createTypeMappingBuilder();
/*     */ 
/*     */     
/* 136 */     TypeMapping typeMapping = null;
/*     */     try {
/* 138 */       typeMapping = typeMappingBuilder.getTypeMapping();
/* 139 */     } catch (BindingException bindingException) {
/* 140 */       return null;
/*     */     } 
/*     */     
/* 143 */     for (byte b = 0; b < arrayOfConstructor.length; b++) {
/* 144 */       Class[] arrayOfClass = arrayOfConstructor[b].getParameterTypes();
/*     */       
/* 146 */       if (arrayOfClass.length != 0) {
/*     */         
/* 148 */         if (arrayOfClass.length > 1) return null;
/*     */         
/* 150 */         hashSet.add(arrayOfClass[0]);
/*     */       } 
/*     */     } 
/* 153 */     for (Class clazz : hashSet) {
/*     */       
/* 155 */       if (typeMapping.getXMLNameFromClass(clazz) != null) {
/* 156 */         return clazz;
/*     */       }
/*     */     } 
/*     */     
/* 160 */     return null;
/*     */   }
/*     */   
/*     */   public static Class getSingleArrayProperty(Class paramClass) {
/* 164 */     if (!Exception.class.isAssignableFrom(paramClass)) {
/* 165 */       throw new AssertionError(paramClass.getName() + " is not an exception.");
/*     */     }
/*     */     
/* 168 */     Constructor[] arrayOfConstructor = paramClass.getConstructors();
/* 169 */     HashSet hashSet = new HashSet();
/*     */     
/* 171 */     for (byte b = 0; b < arrayOfConstructor.length; b++) {
/* 172 */       Class[] arrayOfClass = arrayOfConstructor[b].getParameterTypes();
/*     */       
/* 174 */       if (arrayOfClass.length != 0) {
/*     */         
/* 176 */         if (arrayOfClass.length > 1) return null;
/*     */         
/* 178 */         hashSet.add(arrayOfClass[0]);
/*     */       } 
/*     */     } 
/* 181 */     for (Class clazz : hashSet) {
/*     */       
/* 183 */       if (clazz.getComponentType() != null && 
/* 184 */         getPropertyName(paramClass, clazz) != null) {
/* 185 */         return clazz;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 190 */     return null;
/*     */   }
/*     */   
/*     */   public static Class getSingleProperty(Class paramClass) {
/* 194 */     if (!Exception.class.isAssignableFrom(paramClass)) {
/* 195 */       throw new AssertionError(paramClass.getName() + " is not an exception.");
/*     */     }
/*     */     
/* 198 */     Constructor[] arrayOfConstructor = paramClass.getConstructors();
/* 199 */     HashSet hashSet = new HashSet();
/*     */     
/* 201 */     for (byte b = 0; b < arrayOfConstructor.length; b++) {
/* 202 */       Class[] arrayOfClass = arrayOfConstructor[b].getParameterTypes();
/*     */       
/* 204 */       if (arrayOfClass.length != 0) {
/*     */         
/* 206 */         if (arrayOfClass.length > 1) return null;
/*     */         
/* 208 */         hashSet.add(arrayOfClass[0]);
/*     */       } 
/*     */     } 
/* 211 */     for (Class clazz : hashSet) {
/*     */       
/* 213 */       if (getPropertyName(paramClass, clazz) != null) {
/* 214 */         return clazz;
/*     */       }
/*     */     } 
/*     */     
/* 218 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\ExceptionUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */