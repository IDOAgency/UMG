/*    */ package weblogic.webservice.util;
/*    */ 
/*    */ import weblogic.utils.NestedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WebServiceJarException
/*    */   extends NestedException
/*    */ {
/*    */   public WebServiceJarException() {}
/*    */   
/* 13 */   public WebServiceJarException(String paramString) { super(paramString); }
/* 14 */   public WebServiceJarException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WebServiceJarException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */