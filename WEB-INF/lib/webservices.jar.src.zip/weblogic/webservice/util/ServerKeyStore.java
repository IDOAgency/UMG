package weblogic.webservice.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.security.AccessController;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import weblogic.security.acl.internal.AuthenticatedSubject;
import weblogic.security.internal.SerializedSystemIni;
import weblogic.security.internal.encryption.ClearOrEncryptedService;
import weblogic.security.internal.encryption.EncryptionService;
import weblogic.security.internal.encryption.EncryptionServiceException;
import weblogic.security.service.PrivilegedActions;
import weblogic.security.service.SecurityServiceManager;
import weblogic.security.utils.KeyStoreInfo;
import weblogic.webservice.server.ConfigException;

public class ServerKeyStore {
  private final KeyStoreInfo ksInfo;
  
  private final KeyStore keystore;
  
  private static ServerKeyStore singleton;
  
  private static final EncryptionService es = SerializedSystemIni.getEncryptionService();
  
  private static final ClearOrEncryptedService encrypter = new ClearOrEncryptedService(es);
  
  private ServerKeyStore() throws ConfigException {
    AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
    this.ksInfo = SecurityServiceManager.getServerIdentityKeyStore(authenticatedSubject);
    try {
      this.keystore = KeyStore.getInstance(this.ksInfo.getType());
      FileInputStream fileInputStream = new FileInputStream(this.ksInfo.getFileName());
      this.keystore.load(fileInputStream, this.ksInfo.getPassPhrase());
    } catch (KeyStoreException keyStoreException) {
      throw new ConfigException("Unsupported keystore type: " + this.ksInfo.getType(), keyStoreException);
    } catch (FileNotFoundException fileNotFoundException) {
      throw new ConfigException("Could not find server keystore file " + this.ksInfo.getFileName(), fileNotFoundException);
    } catch (Exception exception) {
      throw new ConfigException("Failed to load keystore from " + this.ksInfo.getFileName(), exception);
    } 
  }
  
  public static final void init() throws ConfigException { singleton = new ServerKeyStore(); }
  
  private static final PrivateKey getPrivateKeyInternal(String paramString, char[] paramArrayOfChar) throws ConfigException {
    PrivateKey privateKey;
    try {
      if (singleton == null)
        init(); 
      privateKey = (PrivateKey)singleton.keystore.getKey(paramString, paramArrayOfChar);
    } catch (Exception exception) {
      throw new ConfigException("Failed to load key for alias " + paramString, exception);
    } 
    if (privateKey == null)
      throw new ConfigException("Key for alias '" + paramString + "' does not exist in " + "server key store (" + singleton.ksInfo.getFileName() + ")"); 
    return privateKey;
  }
  
  public static final PrivateKey getPrivateKey(String paramString, char[] paramArrayOfChar) throws ConfigException {
    String str = paramArrayOfChar.toString();
    if (encrypter.isEncrypted(str))
      return getPrivateKey(paramString, str); 
    return getPrivateKeyInternal(paramString, paramArrayOfChar);
  }
  
  public static final PrivateKey getPrivateKey(String paramString1, String paramString2) throws ConfigException {
    char[] arrayOfChar = decryptPassword(paramString2).toCharArray();
    return getPrivateKeyInternal(paramString1, arrayOfChar);
  }
  
  public static final X509Certificate getCertificate(String paramString) throws ConfigException {
    try {
      if (singleton == null)
        init(); 
      return (X509Certificate)singleton.keystore.getCertificate(paramString);
    } catch (KeyStoreException keyStoreException) {
      throw new ConfigException("Failed to load certificate with alias " + paramString, keyStoreException);
    } 
  }
  
  public static final String decryptPassword(String paramString) throws ConfigException {
    try {
      return encrypter.decrypt(paramString);
    } catch (EncryptionServiceException encryptionServiceException) {
      throw new ConfigException("WSSE Passwords in DD not encrypted for this server.  Please reset the passwords in the DD for this ear and re-encrypt", encryptionServiceException);
    } 
  }
  
  public static final boolean isEncryptedPassword(String paramString) { return encrypter.isEncrypted(paramString); }
  
  public static final String encryptPassword(String paramString) throws ConfigException { return encrypter.encrypt(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\ServerKeyStore.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */