/*     */ package weblogic.webservice.util;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.security.AccessController;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.cert.X509Certificate;
/*     */ import weblogic.security.acl.internal.AuthenticatedSubject;
/*     */ import weblogic.security.internal.SerializedSystemIni;
/*     */ import weblogic.security.internal.encryption.ClearOrEncryptedService;
/*     */ import weblogic.security.internal.encryption.EncryptionService;
/*     */ import weblogic.security.internal.encryption.EncryptionServiceException;
/*     */ import weblogic.security.service.PrivilegedActions;
/*     */ import weblogic.security.service.SecurityServiceManager;
/*     */ import weblogic.security.utils.KeyStoreInfo;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerKeyStore
/*     */ {
/*     */   private final KeyStoreInfo ksInfo;
/*     */   private final KeyStore keystore;
/*     */   private static ServerKeyStore singleton;
/*  30 */   private static final EncryptionService es = SerializedSystemIni.getEncryptionService();
/*  31 */   private static final ClearOrEncryptedService encrypter = new ClearOrEncryptedService(es);
/*     */ 
/*     */   
/*     */   private ServerKeyStore() throws ConfigException {
/*  35 */     AuthenticatedSubject authenticatedSubject = (AuthenticatedSubject)AccessController.doPrivileged(PrivilegedActions.getKernelIdentityAction());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.ksInfo = SecurityServiceManager.getServerIdentityKeyStore(authenticatedSubject);
/*     */     try {
/*  42 */       this.keystore = KeyStore.getInstance(this.ksInfo.getType());
/*  43 */       FileInputStream fileInputStream = new FileInputStream(this.ksInfo.getFileName());
/*  44 */       this.keystore.load(fileInputStream, this.ksInfo.getPassPhrase());
/*  45 */     } catch (KeyStoreException keyStoreException) {
/*  46 */       throw new ConfigException("Unsupported keystore type: " + this.ksInfo.getType(), keyStoreException);
/*  47 */     } catch (FileNotFoundException fileNotFoundException) {
/*  48 */       throw new ConfigException("Could not find server keystore file " + this.ksInfo.getFileName(), fileNotFoundException);
/*  49 */     } catch (Exception exception) {
/*  50 */       throw new ConfigException("Failed to load keystore from " + this.ksInfo.getFileName(), exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final void init() throws ConfigException { singleton = new ServerKeyStore(); }
/*     */ 
/*     */   
/*     */   private static final PrivateKey getPrivateKeyInternal(String paramString, char[] paramArrayOfChar) throws ConfigException {
/*     */     PrivateKey privateKey;
/*     */     try {
/*  63 */       if (singleton == null) init(); 
/*  64 */       privateKey = (PrivateKey)singleton.keystore.getKey(paramString, paramArrayOfChar);
/*  65 */     } catch (Exception exception) {
/*  66 */       throw new ConfigException("Failed to load key for alias " + paramString, exception);
/*     */     } 
/*  68 */     if (privateKey == null) throw new ConfigException("Key for alias '" + paramString + "' does not exist in " + "server key store (" + singleton.ksInfo.getFileName() + ")");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     return privateKey;
/*     */   }
/*     */   
/*     */   public static final PrivateKey getPrivateKey(String paramString, char[] paramArrayOfChar) throws ConfigException {
/*  77 */     String str = paramArrayOfChar.toString();
/*  78 */     if (encrypter.isEncrypted(str)) {
/*  79 */       return getPrivateKey(paramString, str);
/*     */     }
/*  81 */     return getPrivateKeyInternal(paramString, paramArrayOfChar);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final PrivateKey getPrivateKey(String paramString1, String paramString2) throws ConfigException {
/*  86 */     char[] arrayOfChar = decryptPassword(paramString2).toCharArray();
/*  87 */     return getPrivateKeyInternal(paramString1, arrayOfChar);
/*     */   }
/*     */   
/*     */   public static final X509Certificate getCertificate(String paramString) throws ConfigException {
/*     */     try {
/*  92 */       if (singleton == null) init(); 
/*  93 */       return (X509Certificate)singleton.keystore.getCertificate(paramString);
/*  94 */     } catch (KeyStoreException keyStoreException) {
/*  95 */       throw new ConfigException("Failed to load certificate with alias " + paramString, keyStoreException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final String decryptPassword(String paramString) throws ConfigException {
/*     */     try {
/* 101 */       return encrypter.decrypt(paramString);
/* 102 */     } catch (EncryptionServiceException encryptionServiceException) {
/* 103 */       throw new ConfigException("WSSE Passwords in DD not encrypted for this server.  Please reset the passwords in the DD for this ear and re-encrypt", encryptionServiceException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public static final boolean isEncryptedPassword(String paramString) { return encrypter.isEncrypted(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static final String encryptPassword(String paramString) throws ConfigException { return encrypter.encrypt(paramString); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\ServerKeyStore.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */