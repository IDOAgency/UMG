package weblogic.webservice.util;

import java.io.PrintStream;
import java.io.PrintWriter;
import javax.xml.rpc.JAXRPCException;

public class WLJAXRPCException extends JAXRPCException {
  private static final String error = "------------------ Real exception is: ----------";
  
  public WLJAXRPCException() {}
  
  public WLJAXRPCException(String paramString) { super(paramString); }
  
  public WLJAXRPCException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
  
  public WLJAXRPCException(Throwable paramThrowable) { super(paramThrowable); }
  
  public void printStackTrace() {
    super.printStackTrace();
    Throwable throwable = getLinkedCause();
    if (throwable != null) {
      System.err.println("------------------ Real exception is: ----------");
      throwable.printStackTrace();
    } 
  }
  
  public void printStackTrace(PrintStream paramPrintStream) {
    super.printStackTrace(paramPrintStream);
    Throwable throwable = getLinkedCause();
    if (throwable != null) {
      paramPrintStream.println("------------------ Real exception is: ----------");
      throwable.printStackTrace(paramPrintStream);
    } 
  }
  
  public void printStackTrace(PrintWriter paramPrintWriter) {
    super.printStackTrace(paramPrintWriter);
    Throwable throwable = getLinkedCause();
    if (throwable != null) {
      paramPrintWriter.println("------------------ Real exception is: ----------");
      throwable.printStackTrace(paramPrintWriter);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WLJAXRPCException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */