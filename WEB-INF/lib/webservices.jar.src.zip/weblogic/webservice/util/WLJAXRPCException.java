/*    */ package weblogic.webservice.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WLJAXRPCException
/*    */   extends JAXRPCException
/*    */ {
/*    */   private static final String error = "------------------ Real exception is: ----------";
/*    */   
/*    */   public WLJAXRPCException() {}
/*    */   
/* 20 */   public WLJAXRPCException(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 24 */   public WLJAXRPCException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
/*    */ 
/*    */ 
/*    */   
/* 28 */   public WLJAXRPCException(Throwable paramThrowable) { super(paramThrowable); }
/*    */ 
/*    */   
/*    */   public void printStackTrace() {
/* 32 */     super.printStackTrace();
/*    */     
/* 34 */     Throwable throwable = getLinkedCause();
/*    */     
/* 36 */     if (throwable != null) {
/* 37 */       System.err.println("------------------ Real exception is: ----------");
/* 38 */       throwable.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintStream paramPrintStream) {
/* 43 */     super.printStackTrace(paramPrintStream);
/*    */     
/* 45 */     Throwable throwable = getLinkedCause();
/*    */     
/* 47 */     if (throwable != null) {
/* 48 */       paramPrintStream.println("------------------ Real exception is: ----------");
/* 49 */       throwable.printStackTrace(paramPrintStream);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintWriter paramPrintWriter) {
/* 54 */     super.printStackTrace(paramPrintWriter);
/*    */     
/* 56 */     Throwable throwable = getLinkedCause();
/*    */     
/* 58 */     if (throwable != null) {
/* 59 */       paramPrintWriter.println("------------------ Real exception is: ----------");
/* 60 */       throwable.printStackTrace(paramPrintWriter);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservic\\util\WLJAXRPCException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */