package weblogic.webservice;

import javax.xml.namespace.QName;
import javax.xml.rpc.handler.Handler;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;

public abstract class GenericHandler implements Handler {
  private HandlerInfo handlerInfo;
  
  public void init(HandlerInfo paramHandlerInfo) { this.handlerInfo = paramHandlerInfo; }
  
  protected HandlerInfo getHandlerInfo() { return this.handlerInfo; }
  
  public boolean handleRequest(MessageContext paramMessageContext) { return true; }
  
  public boolean handleResponse(MessageContext paramMessageContext) { return true; }
  
  public boolean handleFault(MessageContext paramMessageContext) { return true; }
  
  public void destroy() {}
  
  public QName[] getHeaders() { return this.handlerInfo.getHeaders(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\GenericHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */