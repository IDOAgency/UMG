/*    */ package weblogic.webservice;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.handler.Handler;
/*    */ import javax.xml.rpc.handler.HandlerInfo;
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class GenericHandler
/*    */   implements Handler
/*    */ {
/*    */   private HandlerInfo handlerInfo;
/*    */   
/* 20 */   public void init(HandlerInfo paramHandlerInfo) { this.handlerInfo = paramHandlerInfo; }
/*    */ 
/*    */   
/* 23 */   protected HandlerInfo getHandlerInfo() { return this.handlerInfo; }
/*    */ 
/*    */   
/* 26 */   public boolean handleRequest(MessageContext paramMessageContext) { return true; }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public boolean handleResponse(MessageContext paramMessageContext) { return true; }
/*    */ 
/*    */ 
/*    */   
/* 34 */   public boolean handleFault(MessageContext paramMessageContext) { return true; }
/*    */   
/*    */   public void destroy() {}
/*    */   
/* 38 */   public QName[] getHeaders() { return this.handlerInfo.getHeaders(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\GenericHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */