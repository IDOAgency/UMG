/*     */ package weblogic.webservice.client;
/*     */ 
/*     */ import weblogic.kernel.KernelStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLAdapterFactory
/*     */ {
/*     */   private static boolean verbose = false;
/*  17 */   private static SSLAdapterFactory defaultFactory = new SSLAdapterFactory();
/*     */   
/*  19 */   private SSLAdapter defaultAdapter = null;
/*     */   
/*     */   private boolean useDefault = false;
/*     */   
/*     */   private boolean sslUnavailable = false;
/*  24 */   private Class adapterClass = null;
/*     */   
/*  26 */   private static final String[] adapterClasses = { "weblogic.webservice.client.WLSSLAdapter", "weblogic.webservice.client.JSSEAdapter", "weblogic.webservice.client.CDC.WLSSLAdapter", "weblogic.webservice.client.NullSSLAdapter" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SSL_ADAPTER_PROPERTY = "weblogic.webservice.client.ssl.adapterclass";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   private static final String userClassName = getUserClassNameProp();
/*     */   
/*     */   private static String getUserClassNameProp() {
/*     */     try {
/*  40 */       return System.getProperty("weblogic.webservice.client.ssl.adapterclass");
/*  41 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  47 */       return null;
/*     */     } 
/*     */   }
/*  50 */   private String adapterClassName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void setDefaultFactory(SSLAdapterFactory paramSSLAdapterFactory) {
/*  63 */     if (paramSSLAdapterFactory != null) {
/*  64 */       defaultFactory = paramSSLAdapterFactory;
/*     */     } else {
/*  66 */       throw new IllegalArgumentException("DefaultFactory cannot be set to null");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final SSLAdapterFactory getDefaultFactory() { return defaultFactory; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SSLAdapter getDefaultAdapter() {
/*  93 */     if (this.defaultAdapter == null) {
/*  94 */       this.defaultAdapter = defaultFactory.createSSLAdapter();
/*     */     }
/*  96 */     return this.defaultAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public final void setDefaultAdapter(SSLAdapter paramSSLAdapter) { this.defaultAdapter = paramSSLAdapter; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public final void setUseDefaultAdapter(boolean paramBoolean) { this.useDefault = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SSLAdapter getSSLAdapter() {
/* 166 */     if (this.useDefault) {
/* 167 */       return getDefaultAdapter();
/*     */     }
/* 169 */     return createSSLAdapter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SSLAdapter createSSLAdapter() {
/* 186 */     if (this.sslUnavailable) {
/* 187 */       throw new SSLConfigurationException("No SSLAdapter class could be found.  The likely cause of this is an incomplete web service client libarary.  If no SSL implementation is available, the client should use NullSSLAdapter");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     Class clazz = getAdapterClass();
/*     */     
/* 196 */     if (verbose) System.out.println("Using SSLAdapter class " + this.adapterClassName);
/*     */     
/* 198 */     Object object = null;
/*     */     try {
/* 200 */       object = clazz.newInstance();
/* 201 */       return (SSLAdapter)object;
/* 202 */     } catch (ClassCastException classCastException) {
/* 203 */       this.sslUnavailable = true;
/* 204 */       throw new IllegalArgumentException("Adapter " + this.adapterClassName + " did not return an instance of" + " SSLAdapter as required (returned " + object.getClass().getName() + " instead)");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 210 */     catch (InstantiationException instantiationException) {
/* 211 */       this.sslUnavailable = true;
/* 212 */       throw new IllegalArgumentException("Adapter " + this.adapterClassName + " failed to return an instance" + " of SSLAdapter as required: " + instantiationException.getMessage());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 218 */     catch (IllegalAccessException illegalAccessException) {
/* 219 */       this.sslUnavailable = true;
/* 220 */       throw new IllegalArgumentException("Adapter " + this.adapterClassName + " failed to return an instance" + " of SSLAdapter as required: " + illegalAccessException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class getAdapterClass() {
/* 235 */     if (this.adapterClass != null) return this.adapterClass;
/*     */     
/* 237 */     if (userClassName != null) {
/*     */       
/*     */       try {
/*     */         
/* 241 */         this.adapterClassName = userClassName;
/* 242 */         this.adapterClass = Class.forName(userClassName);
/* 243 */         return this.adapterClass;
/* 244 */       } catch (ClassNotFoundException classNotFoundException) {
/* 245 */         throw new SSLConfigurationException("Could not find user specified SSLAdapter class " + this.adapterClassName);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 251 */     if (KernelStatus.isApplet()) {
/*     */ 
/*     */ 
/*     */       
/* 255 */       String str = "weblogic.webservice.client.JSSEAdapter";
/*     */       try {
/* 257 */         this.adapterClass = Class.forName(str);
/* 258 */         return this.adapterClass;
/* 259 */       } catch (ClassNotFoundException classNotFoundException) {
/* 260 */         if (verbose) System.out.println("failed to load " + str);
/*     */       
/* 262 */       } catch (NoClassDefFoundError noClassDefFoundError) {
/* 263 */         if (verbose) System.out.println("failed to load " + str);
/*     */       
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 269 */     for (byte b = 0; b < adapterClasses.length; b++) {
/*     */       try {
/* 271 */         this.adapterClassName = adapterClasses[b];
/* 272 */         this.adapterClass = Class.forName(this.adapterClassName);
/* 273 */         return this.adapterClass;
/* 274 */       } catch (ClassNotFoundException classNotFoundException) {
/* 275 */         if (verbose) System.out.println("failed to load " + this.adapterClassName);
/*     */       
/* 277 */       } catch (NoClassDefFoundError noClassDefFoundError) {
/* 278 */         if (verbose) System.out.println("failed to load " + this.adapterClassName);
/*     */       
/*     */       } 
/*     */     } 
/*     */     
/* 283 */     this.sslUnavailable = true;
/* 284 */     this.adapterClassName = null;
/*     */     
/* 286 */     throw new SSLConfigurationException("No SSLAdapter class could be found.  The likely cause of this is an incomplete web service client libarary.  If no SSL implementation is available, the client should use NullSSLAdapter");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 298 */     SSLAdapterFactory sSLAdapterFactory = getDefaultFactory();
/* 299 */     System.out.println("Got default factory: " + sSLAdapterFactory);
/* 300 */     if (sSLAdapterFactory == sSLAdapterFactory.getDefaultFactory()) {
/* 301 */       System.out.println("Got the same adapter the second time");
/*     */     } else {
/* 303 */       System.out.println("!! Did not get same adapter the second time");
/*     */     } 
/*     */     
/* 306 */     SSLAdapter sSLAdapter = sSLAdapterFactory.getDefaultAdapter();
/*     */     
/* 308 */     if (sSLAdapter == null) {
/* 309 */       System.out.println("!! Got null for adapter!");
/*     */     }
/* 311 */     System.out.println("Got defaultAdapter: " + sSLAdapter);
/* 312 */     if (sSLAdapter == sSLAdapterFactory.getDefaultAdapter()) {
/* 313 */       System.out.println("Got the same adapter the second time");
/*     */     } else {
/* 315 */       System.out.println("!! Did not get same adapter the second time");
/*     */     } 
/*     */     
/* 318 */     sSLAdapterFactory.setUseDefaultAdapter(true);
/* 319 */     System.out.println("Factory set to use DefaultAdapter always");
/* 320 */     if (sSLAdapter == sSLAdapterFactory.getSSLAdapter()) {
/* 321 */       System.out.println("Got the same adapter when 'useDefault' enabled.");
/*     */     } else {
/* 323 */       System.out.println("!! Did not get same adapter with useDefault");
/*     */     } 
/*     */     
/* 326 */     setDefaultFactory(new SSLAdapterFactory());
/* 327 */     sSLAdapterFactory = getDefaultFactory();
/*     */     
/* 329 */     System.out.println("Re-set the default factory");
/*     */     
/* 331 */     if (sSLAdapter != sSLAdapterFactory.getSSLAdapter()) {
/* 332 */       System.out.println("Got a new adapter from the new factory");
/*     */     } else {
/* 334 */       System.out.println("!! Got the old Adapter instead of one from the new factory");
/*     */     } 
/*     */     
/* 337 */     sSLAdapter = sSLAdapterFactory.getDefaultAdapter();
/* 338 */     if (sSLAdapter == null) {
/* 339 */       System.out.println("!! Got null for adapter!");
/*     */     }
/* 341 */     System.out.println("Got defaultAdapter: " + sSLAdapter);
/* 342 */     if (sSLAdapter == sSLAdapterFactory.getDefaultAdapter()) {
/* 343 */       System.out.println("Got the same adapter the second time");
/*     */     } else {
/* 345 */       System.out.println("!! Did not get same adapter the second time");
/*     */     } 
/*     */     
/* 348 */     sSLAdapterFactory.setUseDefaultAdapter(false);
/* 349 */     System.out.println("Factory set to create new Adapters each time");
/*     */     
/* 351 */     sSLAdapter = sSLAdapterFactory.getDefaultAdapter();
/* 352 */     System.out.println("Got defaultAdapter: " + sSLAdapter);
/* 353 */     if (sSLAdapter != sSLAdapterFactory.getSSLAdapter()) {
/* 354 */       System.out.println("Did not get same adapter the second time");
/*     */     } else {
/* 356 */       System.out.println("!! Got the same adapter the second time");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\SSLAdapterFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */