package weblogic.webservice.client;

import weblogic.kernel.KernelStatus;

public class SSLAdapterFactory {
  private static boolean verbose = false;
  
  private static SSLAdapterFactory defaultFactory = new SSLAdapterFactory();
  
  private SSLAdapter defaultAdapter = null;
  
  private boolean useDefault = false;
  
  private boolean sslUnavailable = false;
  
  private Class adapterClass = null;
  
  private static final String[] adapterClasses = { "weblogic.webservice.client.WLSSLAdapter", "weblogic.webservice.client.JSSEAdapter", "weblogic.webservice.client.CDC.WLSSLAdapter", "weblogic.webservice.client.NullSSLAdapter" };
  
  public static final String SSL_ADAPTER_PROPERTY = "weblogic.webservice.client.ssl.adapterclass";
  
  private static final String userClassName = getUserClassNameProp();
  
  private static String getUserClassNameProp() {
    try {
      return System.getProperty("weblogic.webservice.client.ssl.adapterclass");
    } catch (SecurityException securityException) {
      return null;
    } 
  }
  
  private String adapterClassName = null;
  
  public static final void setDefaultFactory(SSLAdapterFactory paramSSLAdapterFactory) {
    if (paramSSLAdapterFactory != null) {
      defaultFactory = paramSSLAdapterFactory;
    } else {
      throw new IllegalArgumentException("DefaultFactory cannot be set to null");
    } 
  }
  
  public static final SSLAdapterFactory getDefaultFactory() { return defaultFactory; }
  
  public final SSLAdapter getDefaultAdapter() {
    if (this.defaultAdapter == null)
      this.defaultAdapter = defaultFactory.createSSLAdapter(); 
    return this.defaultAdapter;
  }
  
  public final void setDefaultAdapter(SSLAdapter paramSSLAdapter) { this.defaultAdapter = paramSSLAdapter; }
  
  public final void setUseDefaultAdapter(boolean paramBoolean) { this.useDefault = paramBoolean; }
  
  public final SSLAdapter getSSLAdapter() {
    if (this.useDefault)
      return getDefaultAdapter(); 
    return createSSLAdapter();
  }
  
  public SSLAdapter createSSLAdapter() {
    if (this.sslUnavailable)
      throw new SSLConfigurationException("No SSLAdapter class could be found.  The likely cause of this is an incomplete web service client libarary.  If no SSL implementation is available, the client should use NullSSLAdapter"); 
    Class clazz = getAdapterClass();
    if (verbose)
      System.out.println("Using SSLAdapter class " + this.adapterClassName); 
    Object object = null;
    try {
      object = clazz.newInstance();
      return (SSLAdapter)object;
    } catch (ClassCastException classCastException) {
      this.sslUnavailable = true;
      throw new IllegalArgumentException("Adapter " + this.adapterClassName + " did not return an instance of" + " SSLAdapter as required (returned " + object.getClass().getName() + " instead)");
    } catch (InstantiationException instantiationException) {
      this.sslUnavailable = true;
      throw new IllegalArgumentException("Adapter " + this.adapterClassName + " failed to return an instance" + " of SSLAdapter as required: " + instantiationException.getMessage());
    } catch (IllegalAccessException illegalAccessException) {
      this.sslUnavailable = true;
      throw new IllegalArgumentException("Adapter " + this.adapterClassName + " failed to return an instance" + " of SSLAdapter as required: " + illegalAccessException.getMessage());
    } 
  }
  
  private Class getAdapterClass() {
    if (this.adapterClass != null)
      return this.adapterClass; 
    if (userClassName != null)
      try {
        this.adapterClassName = userClassName;
        this.adapterClass = Class.forName(userClassName);
        return this.adapterClass;
      } catch (ClassNotFoundException classNotFoundException) {
        throw new SSLConfigurationException("Could not find user specified SSLAdapter class " + this.adapterClassName);
      }  
    if (KernelStatus.isApplet()) {
      String str = "weblogic.webservice.client.JSSEAdapter";
      try {
        this.adapterClass = Class.forName(str);
        return this.adapterClass;
      } catch (ClassNotFoundException classNotFoundException) {
        if (verbose)
          System.out.println("failed to load " + str); 
      } catch (NoClassDefFoundError noClassDefFoundError) {
        if (verbose)
          System.out.println("failed to load " + str); 
      } 
    } 
    for (byte b = 0; b < adapterClasses.length; b++) {
      try {
        this.adapterClassName = adapterClasses[b];
        this.adapterClass = Class.forName(this.adapterClassName);
        return this.adapterClass;
      } catch (ClassNotFoundException classNotFoundException) {
        if (verbose)
          System.out.println("failed to load " + this.adapterClassName); 
      } catch (NoClassDefFoundError noClassDefFoundError) {
        if (verbose)
          System.out.println("failed to load " + this.adapterClassName); 
      } 
    } 
    this.sslUnavailable = true;
    this.adapterClassName = null;
    throw new SSLConfigurationException("No SSLAdapter class could be found.  The likely cause of this is an incomplete web service client libarary.  If no SSL implementation is available, the client should use NullSSLAdapter");
  }
  
  public static void main(String[] paramArrayOfString) {
    SSLAdapterFactory sSLAdapterFactory = getDefaultFactory();
    System.out.println("Got default factory: " + sSLAdapterFactory);
    if (sSLAdapterFactory == sSLAdapterFactory.getDefaultFactory()) {
      System.out.println("Got the same adapter the second time");
    } else {
      System.out.println("!! Did not get same adapter the second time");
    } 
    SSLAdapter sSLAdapter = sSLAdapterFactory.getDefaultAdapter();
    if (sSLAdapter == null)
      System.out.println("!! Got null for adapter!"); 
    System.out.println("Got defaultAdapter: " + sSLAdapter);
    if (sSLAdapter == sSLAdapterFactory.getDefaultAdapter()) {
      System.out.println("Got the same adapter the second time");
    } else {
      System.out.println("!! Did not get same adapter the second time");
    } 
    sSLAdapterFactory.setUseDefaultAdapter(true);
    System.out.println("Factory set to use DefaultAdapter always");
    if (sSLAdapter == sSLAdapterFactory.getSSLAdapter()) {
      System.out.println("Got the same adapter when 'useDefault' enabled.");
    } else {
      System.out.println("!! Did not get same adapter with useDefault");
    } 
    setDefaultFactory(new SSLAdapterFactory());
    sSLAdapterFactory = getDefaultFactory();
    System.out.println("Re-set the default factory");
    if (sSLAdapter != sSLAdapterFactory.getSSLAdapter()) {
      System.out.println("Got a new adapter from the new factory");
    } else {
      System.out.println("!! Got the old Adapter instead of one from the new factory");
    } 
    sSLAdapter = sSLAdapterFactory.getDefaultAdapter();
    if (sSLAdapter == null)
      System.out.println("!! Got null for adapter!"); 
    System.out.println("Got defaultAdapter: " + sSLAdapter);
    if (sSLAdapter == sSLAdapterFactory.getDefaultAdapter()) {
      System.out.println("Got the same adapter the second time");
    } else {
      System.out.println("!! Did not get same adapter the second time");
    } 
    sSLAdapterFactory.setUseDefaultAdapter(false);
    System.out.println("Factory set to create new Adapters each time");
    sSLAdapter = sSLAdapterFactory.getDefaultAdapter();
    System.out.println("Got defaultAdapter: " + sSLAdapter);
    if (sSLAdapter != sSLAdapterFactory.getSSLAdapter()) {
      System.out.println("Did not get same adapter the second time");
    } else {
      System.out.println("!! Got the same adapter the second time");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\SSLAdapterFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */