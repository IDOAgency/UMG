/*    */ package weblogic.webservice.client;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.Socket;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullSSLAdapter
/*    */   implements SSLAdapter
/*    */ {
/* 27 */   public Socket createSocket(String paramString, int paramInt) throws IOException { throw new IOException("https unsupported: SSL implementation not available or not configured correctly."); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   public URLConnection openConnection(URL paramURL) throws IOException { return paramURL.openConnection(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\NullSSLAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */