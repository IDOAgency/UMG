package weblogic.webservice.client;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import weblogic.utils.encoders.BASE64Encoder;
import weblogic.webservice.client.https.HostnameVerifier;
import weblogic.webservice.client.https.HttpsURLConnection;

public final class WLSSLAdapter extends BaseWLSSLAdapter {
  private static final HostnameVerifier nonverifier = new NullVerifier(null);
  
  private HostnameVerifier verifier;
  
  public WLSSLAdapter() {
    this.verifier = HttpsURLConnection.getDefaultHostnameVerifier();
    setStrictChecking(getStrictCheckingDefault());
  }
  
  public WLSSLAdapter(boolean paramBoolean) {
    this.verifier = HttpsURLConnection.getDefaultHostnameVerifier();
    setStrictChecking(paramBoolean);
  }
  
  public final URLConnection openConnection(URL paramURL) throws IOException {
    URLConnection uRLConnection = null;
    if ("https".equalsIgnoreCase(paramURL.getProtocol())) {
      HttpsURLConnection httpsURLConnection = new HttpsURLConnection(paramURL);
      httpsURLConnection.setSSLSocketFactory(getSocketFactory());
      fileInputStream = null;
      if (verbose) {
        System.out.println("openConnection(" + paramURL + ") returning " + httpsURLConnection);
        System.out.println("-- using HostnameVerifier " + httpsURLConnection.getHostnameVerifier());
      } 
      if (trustedCertFile != null) {
        try {
          fileInputStream = new FileInputStream(trustedCertFile);
          httpsURLConnection.loadTrustedCertificates(fileInputStream);
          if (verbose)
            System.out.println("-- loaded certs from " + trustedCertFile); 
        } catch (KeyManagementException keyManagementException) {
          throw new IOException(keyManagementException.getMessage());
        } finally {
          if (fileInputStream != null)
            fileInputStream.close(); 
        } 
      } else if (verbose) {
        System.out.println("-- did not receive trusted cert file");
      } 
      uRLConnection = httpsURLConnection;
    } else {
      uRLConnection = paramURL.openConnection();
    } 
    String str = paramURL.getUserInfo();
    if (str != null) {
      if (str.indexOf(':') == -1)
        str = str + ":"; 
      String str1 = (new BASE64Encoder()).encodeBuffer(str.getBytes());
      uRLConnection.setRequestProperty("Authorization", "Basic " + str1);
      if (verbose) {
        System.out.println("-- URL had username/password: " + str);
        System.out.println("-- Set Authorization header on " + uRLConnection + " to " + str1);
      } 
    } 
    return uRLConnection;
  }
  
  public final void setStrictChecking(boolean paramBoolean) {
    if (adapterUsed())
      throw new IllegalArgumentException("Cannot change certificate checking once the adapter has been used"); 
    if ((paramBoolean || this.strictCertChecking) && (!paramBoolean || !this.strictCertChecking)) {
      _setStrictChecking(paramBoolean);
      if (paramBoolean) {
        setHostnameVerifier(this.verifier);
      } else {
        setHostnameVerifier(nonverifier);
      } 
    } 
  }
  
  private final void setHostnameVerifier(HostnameVerifier paramHostnameVerifier) {
    this.verifier = paramHostnameVerifier;
    HttpsURLConnection.setDefaultHostnameVerifier(paramHostnameVerifier);
    if (verbose)
      System.out.println("Set HostnameVerifier to " + paramHostnameVerifier); 
  }
  
  private static class NullVerifier implements HostnameVerifier {
    private NullVerifier() {}
    
    public boolean verify(String param1String1, String param1String2) {
      if (!param1String1.equals(param1String2) && 
        BaseWLSSLAdapter.verbose)
        System.out.println("Warning! Hostname does not match certificate"); 
      if (BaseWLSSLAdapter.verbose)
        System.out.println("URL: " + param1String1 + ";Cert: " + param1String2); 
      return true;
    }
  }
  
  public static void main(String[] paramArrayOfString) {
    try {
      WLSSLAdapter wLSSLAdapter = new WLSSLAdapter();
      wLSSLAdapter.setVerbose(true);
      System.out.println("Got adapter: " + wLSSLAdapter);
      SSLSocket sSLSocket = null;
      HttpsURLConnection httpsURLConnection = null;
      byte[] arrayOfByte = new byte[32];
      wLSSLAdapter.setStrictChecking(false);
      String[] arrayOfString = { "https://miramar:7702/SecureSSLEchoService/SecureSSLEchoService?WSDL" };
      if (paramArrayOfString.length > 0)
        arrayOfString = paramArrayOfString; 
      for (byte b = 0; b < arrayOfString.length; b++) {
        URL uRL = new URL(arrayOfString[b]);
        httpsURLConnection = (HttpsURLConnection)wLSSLAdapter.openConnection(uRL);
        System.out.println("for https, got this URLConnction: " + httpsURLConnection);
        if (httpsURLConnection.getHostnameVerifier() == nonverifier) {
          System.out.println("The connection has the NullVerifier");
        } else {
          System.out.println("!! The connection was not the NullVerifier");
        } 
        try {
          httpsURLConnection.connect();
          InputStream inputStream = httpsURLConnection.getInputStream();
          byte[] arrayOfByte1 = new byte[4096];
          System.out.println("Got input from connection" + httpsURLConnection + ":");
          inputStream.read(arrayOfByte1);
          for (byte b1 = 0; b1 < 32; b1++)
            System.out.print(arrayOfByte[b1]); 
          System.out.println();
          System.out.println("opened and read " + httpsURLConnection);
          SSLSocketFactory sSLSocketFactory = httpsURLConnection.getSSLSocketFactory();
          sSLSocket = (SSLSocket)sSLSocketFactory.createSocket(uRL.getHost(), uRL.getPort());
          System.out.println("created socket " + sSLSocket);
          sSLSocket.startHandshake();
          System.out.println("completed handshake on " + sSLSocket);
        } catch (Throwable throwable) {
          System.out.println("Got exception: " + throwable.getMessage());
        } 
      } 
    } catch (Throwable throwable) {
      System.out.println("Caught exception:" + throwable.getMessage());
      throwable.printStackTrace();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\WLSSLAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */