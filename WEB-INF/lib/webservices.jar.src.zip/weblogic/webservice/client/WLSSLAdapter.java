/*     */ package weblogic.webservice.client;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.KeyManagementException;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import weblogic.utils.encoders.BASE64Encoder;
/*     */ import weblogic.webservice.client.https.HostnameVerifier;
/*     */ import weblogic.webservice.client.https.HttpsURLConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WLSSLAdapter
/*     */   extends BaseWLSSLAdapter
/*     */ {
/*  26 */   private static final HostnameVerifier nonverifier = new NullVerifier(null);
/*     */   
/*     */   public WLSSLAdapter() {
/*  29 */     this.verifier = HttpsURLConnection.getDefaultHostnameVerifier();
/*     */ 
/*     */ 
/*     */     
/*  33 */     setStrictChecking(getStrictCheckingDefault());
/*     */   }
/*     */   private HostnameVerifier verifier;
/*     */   public WLSSLAdapter(boolean paramBoolean) {
/*     */     this.verifier = HttpsURLConnection.getDefaultHostnameVerifier();
/*  38 */     setStrictChecking(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final URLConnection openConnection(URL paramURL) throws IOException {
/*  55 */     URLConnection uRLConnection = null;
/*     */ 
/*     */ 
/*     */     
/*  59 */     if ("https".equalsIgnoreCase(paramURL.getProtocol())) {
/*  60 */       HttpsURLConnection httpsURLConnection = new HttpsURLConnection(paramURL);
/*  61 */       httpsURLConnection.setSSLSocketFactory(getSocketFactory());
/*     */       
/*  63 */       fileInputStream = null;
/*  64 */       if (verbose) {
/*  65 */         System.out.println("openConnection(" + paramURL + ") returning " + httpsURLConnection);
/*  66 */         System.out.println("-- using HostnameVerifier " + httpsURLConnection.getHostnameVerifier());
/*     */       } 
/*     */       
/*  69 */       if (trustedCertFile != null)
/*     */       { try {
/*  71 */           fileInputStream = new FileInputStream(trustedCertFile);
/*  72 */           httpsURLConnection.loadTrustedCertificates(fileInputStream);
/*  73 */           if (verbose) System.out.println("-- loaded certs from " + trustedCertFile); 
/*  74 */         } catch (KeyManagementException keyManagementException) {
/*  75 */           throw new IOException(keyManagementException.getMessage());
/*     */         } finally {
/*  77 */           if (fileInputStream != null) fileInputStream.close();
/*     */           
/*     */         
/*     */         }
/*     */          }
/*     */       
/*  83 */       else if (verbose) { System.out.println("-- did not receive trusted cert file"); }
/*     */ 
/*     */       
/*  86 */       uRLConnection = httpsURLConnection;
/*     */     } else {
/*     */       
/*  89 */       uRLConnection = paramURL.openConnection();
/*     */     } 
/*     */     
/*  92 */     String str = paramURL.getUserInfo();
/*  93 */     if (str != null) {
/*  94 */       if (str.indexOf(':') == -1) {
/*  95 */         str = str + ":";
/*     */       }
/*     */       
/*  98 */       String str1 = (new BASE64Encoder()).encodeBuffer(str.getBytes());
/*     */       
/* 100 */       uRLConnection.setRequestProperty("Authorization", "Basic " + str1);
/* 101 */       if (verbose) {
/* 102 */         System.out.println("-- URL had username/password: " + str);
/* 103 */         System.out.println("-- Set Authorization header on " + uRLConnection + " to " + str1);
/*     */       } 
/*     */     } 
/* 106 */     return uRLConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setStrictChecking(boolean paramBoolean) {
/* 130 */     if (adapterUsed()) throw new IllegalArgumentException("Cannot change certificate checking once the adapter has been used");
/*     */     
/* 132 */     if ((paramBoolean || this.strictCertChecking) && (!paramBoolean || !this.strictCertChecking)) {
/* 133 */       _setStrictChecking(paramBoolean);
/*     */       
/* 135 */       if (paramBoolean) {
/* 136 */         setHostnameVerifier(this.verifier);
/*     */       } else {
/*     */         
/* 139 */         setHostnameVerifier(nonverifier);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void setHostnameVerifier(HostnameVerifier paramHostnameVerifier) {
/* 153 */     this.verifier = paramHostnameVerifier;
/* 154 */     HttpsURLConnection.setDefaultHostnameVerifier(paramHostnameVerifier);
/* 155 */     if (verbose) System.out.println("Set HostnameVerifier to " + paramHostnameVerifier);
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private static class NullVerifier
/*     */     implements HostnameVerifier
/*     */   {
/*     */     private NullVerifier() {}
/*     */     
/*     */     public boolean verify(String param1String1, String param1String2) {
/* 166 */       if (!param1String1.equals(param1String2) && 
/* 167 */         BaseWLSSLAdapter.verbose) System.out.println("Warning! Hostname does not match certificate");
/*     */       
/* 169 */       if (BaseWLSSLAdapter.verbose) System.out.println("URL: " + param1String1 + ";Cert: " + param1String2); 
/* 170 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*     */     try {
/* 179 */       WLSSLAdapter wLSSLAdapter = new WLSSLAdapter();
/*     */       
/* 181 */       wLSSLAdapter.setVerbose(true);
/*     */       
/* 183 */       System.out.println("Got adapter: " + wLSSLAdapter);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 212 */       SSLSocket sSLSocket = null;
/* 213 */       HttpsURLConnection httpsURLConnection = null;
/* 214 */       byte[] arrayOfByte = new byte[32];
/*     */ 
/*     */ 
/*     */       
/* 218 */       wLSSLAdapter.setStrictChecking(false);
/*     */       
/* 220 */       String[] arrayOfString = { "https://miramar:7702/SecureSSLEchoService/SecureSSLEchoService?WSDL" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 226 */       if (paramArrayOfString.length > 0) {
/* 227 */         arrayOfString = paramArrayOfString;
/*     */       }
/*     */       
/* 230 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 231 */         URL uRL = new URL(arrayOfString[b]);
/*     */         
/* 233 */         httpsURLConnection = (HttpsURLConnection)wLSSLAdapter.openConnection(uRL);
/* 234 */         System.out.println("for https, got this URLConnction: " + httpsURLConnection);
/*     */         
/* 236 */         if (httpsURLConnection.getHostnameVerifier() == nonverifier) {
/* 237 */           System.out.println("The connection has the NullVerifier");
/*     */         } else {
/* 239 */           System.out.println("!! The connection was not the NullVerifier");
/*     */         } 
/*     */         try {
/* 242 */           httpsURLConnection.connect();
/*     */           
/* 244 */           InputStream inputStream = httpsURLConnection.getInputStream();
/* 245 */           byte[] arrayOfByte1 = new byte[4096];
/* 246 */           System.out.println("Got input from connection" + httpsURLConnection + ":");
/*     */           
/* 248 */           inputStream.read(arrayOfByte1);
/* 249 */           for (byte b1 = 0; b1 < 32; b1++) {
/* 250 */             System.out.print(arrayOfByte[b1]);
/*     */           }
/* 252 */           System.out.println();
/* 253 */           System.out.println("opened and read " + httpsURLConnection);
/*     */           
/* 255 */           SSLSocketFactory sSLSocketFactory = httpsURLConnection.getSSLSocketFactory();
/* 256 */           sSLSocket = (SSLSocket)sSLSocketFactory.createSocket(uRL.getHost(), uRL.getPort());
/* 257 */           System.out.println("created socket " + sSLSocket);
/* 258 */           sSLSocket.startHandshake();
/* 259 */           System.out.println("completed handshake on " + sSLSocket);
/*     */         
/*     */         }
/* 262 */         catch (Throwable throwable) {
/* 263 */           System.out.println("Got exception: " + throwable.getMessage());
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 274 */     catch (Throwable throwable) {
/* 275 */       System.out.println("Caught exception:" + throwable.getMessage());
/* 276 */       throwable.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\WLSSLAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */