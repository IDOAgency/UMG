/*      */ package weblogic.webservice.client;
/*      */ 
/*      */ import com.certicom.net.ssl.SSLContext;
/*      */ import com.certicom.net.ssl.TrustManager;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.PrintWriter;
/*      */ import java.net.Socket;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.security.KeyManagementException;
/*      */ import java.security.KeyStore;
/*      */ import java.security.Principal;
/*      */ import java.security.PrivateKey;
/*      */ import java.security.cert.Certificate;
/*      */ import java.security.cert.CertificateEncodingException;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.CertificateFactory;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.util.Enumeration;
/*      */ import javax.net.ssl.SSLSocket;
/*      */ import javax.net.ssl.SSLSocketFactory;
/*      */ import javax.security.cert.CertificateEncodingException;
/*      */ import javax.security.cert.CertificateException;
/*      */ import javax.security.cert.X509Certificate;
/*      */ import weblogic.utils.encoders.BASE64Encoder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class BaseWLSSLAdapter
/*      */   implements SSLAdapter
/*      */ {
/*      */   public static final String STRICT_CHECKING_DEFAULT = "weblogic.webservice.client.ssl.strictcertchecking";
/*      */   public static final String VERBOSE_PROPERTY = "weblogic.webservice.client.verbose";
/*      */   public static final String TRUSTED_CERTS = "weblogic.webservice.client.ssl.trustedcertfile";
/*      */   public static final String ENFORCE_CONSTRAINTS = "weblogic.security.SSL.enforceConstraints";
/*      */   private static final String HTTPS_PROXY_HOST = "weblogic.webservice.transport.https.proxy.host";
/*      */   private static final String HTTPS_PROXY_PORT = "weblogic.webservice.transport.https.proxy.port";
/*      */   protected static boolean verbose = false;
/*      */   private static boolean strictCheckingDefault = true;
/*   66 */   protected static String trustedCertFile = null;
/*      */   
/*   68 */   private SSLContext context = null;
/*      */   
/*   70 */   private final TrustManager trustingManager = new NullTrustManager(null);
/*      */   
/*   72 */   private TrustManager strictManager = null;
/*   73 */   private SSLSocketFactory socketFactory = null;
/*      */   
/*      */   protected boolean strictCertChecking = true;
/*   76 */   private String[] enabledCiphers = null;
/*      */   
/*   78 */   private String proxyHost = null;
/*      */   
/*      */   private int proxyPort;
/*   81 */   private static String defaultProxyHost = null;
/*   82 */   private static int defaultProxyPort = 8080;
/*      */   private static final int CONSTRAINTS_OFF = 0;
/*      */   private static final int CONSTRAINTS_STRONG = 1;
/*      */   private static final int CONSTRAINTS_STRICT = 2;
/*      */   private static final CertificateFactory javaCertFactory; public BaseWLSSLAdapter() { if (defaultProxyHost != null) { this.proxyHost = defaultProxyHost; this.proxyPort = defaultProxyPort; }  if (trustedCertFile != null) { fileInputStream = null; try { fileInputStream = new FileInputStream(trustedCertFile); loadTrustedCertificates(fileInputStream); } catch (Exception exception) { System.out.println("Warning: Unable to load trusted certificates from file " + trustedCertFile + ":" + exception.getMessage()); } finally { try { if (fileInputStream != null) fileInputStream.close();  } catch (IOException iOException) { if (verbose) System.out.println("Warning: trusted cert file close error: " + iOException.getMessage());  }  }  }  } public final Socket createSocket(String paramString, int paramInt) throws IOException { SSLSocket sSLSocket = null; try { if (this.proxyHost != null) { sSLSocket = (SSLSocket)createProxySocket(paramString, paramInt); } else { if (paramInt < 0) paramInt = 443;  sSLSocket = (SSLSocket)getSocketFactory().createSocket(paramString, paramInt); }  if (this.enabledCiphers != null) sSLSocket.setEnabledCipherSuites(this.enabledCiphers);  if (verbose) System.out.println("Connecting to:" + paramString + " port:" + paramInt + " socket:" + sSLSocket);  } catch (ClassCastException classCastException) { throw new IOException("Unable to create SSLSocket instance"); }  return sSLSocket; } public static void setStrictCheckingDefault(boolean paramBoolean) { if (verbose) System.out.println("Set default cert checking to " + (paramBoolean ? "strict" : "accepting"));  strictCheckingDefault = paramBoolean; } public void setVerbose(boolean paramBoolean) { this; verbose = paramBoolean; } protected final void _setStrictChecking(boolean paramBoolean) { if (adapterUsed()) throw new IllegalArgumentException("Cannot change certificate checking once the adapter has been used");  if (paramBoolean) { if (verbose)
/*      */         System.out.println("Enabling strict checking on adapter " + this);  setTrustManager(this.strictManager); } else { if (verbose)
/*   88 */         System.out.println("Disabling strict checking on adapter " + this);  setTrustManager(this.trustingManager); }  this.strictCertChecking = paramBoolean; } static int enforceConstraints = 1;
/*      */   public void setTrustedCertificatesFile(String paramString) { if (adapterUsed()) throw new IllegalArgumentException("Cannot change trusted certificate file once the adapter has been used");  boolean bool = false; try { FileInputStream fileInputStream = new FileInputStream(paramString); InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream); BufferedReader bufferedReader = new BufferedReader(inputStreamReader); String str = bufferedReader.readLine(); if (str.equalsIgnoreCase("-----BEGIN CERTIFICATE-----")) bool = true;  fileInputStream.close(); } catch (Exception exception) { throw new IllegalArgumentException("Could not load trusted certificate file: " + paramString + " due to error: " + exception); }  if (!bool) { if (verbose) System.out.println("Could not locate PEM preamble, now trying file as JKS");  File file = null; try { file = doPemCvt(paramString); } catch (Exception exception) { throw new IllegalArgumentException("Could not obtain certificate from file as JKS: " + paramString + " due to error: " + exception); }  if (file != null) { if (verbose) System.out.println("temp PEM file created: " + file.getAbsolutePath());  paramString = file.getAbsolutePath(); bool = true; }  }  if (!bool)
/*      */       throw new IllegalArgumentException("Could not obtain certificate from file: " + paramString);  trustedCertFile = paramString; if (trustedCertFile != null) { fileInputStream = null; try { fileInputStream = new FileInputStream(trustedCertFile); loadTrustedCertificates(fileInputStream); } catch (Exception exception) { System.out.println("Warning: Unable to load trusted certificates from file " + trustedCertFile + ":" + exception.getMessage()); } finally { try { if (fileInputStream != null)
/*      */             fileInputStream.close();  } catch (IOException iOException) { if (verbose)
/*      */             System.out.println("Warning: set trusted cert file close error: " + iOException.getMessage());  }  }  }  }
/*      */   private final void loadTrustedCertificates(InputStream paramInputStream) throws KeyManagementException { getContext().loadTrustedCertificates(paramInputStream); if (verbose)
/*   94 */       System.out.println("Loaded local trusted certificates from " + paramInputStream);  } static  { try { verbose = Boolean.getBoolean("weblogic.webservice.client.verbose");
/*      */       
/*   96 */       if (verbose) {
/*   97 */         System.out.println("SSLAdapter verbose output enabled");
/*      */       }
/*      */ 
/*      */       
/*  101 */       if ("false".equals(System.getProperty("weblogic.webservice.client.ssl.strictcertchecking"))) {
/*  102 */         strictCheckingDefault = false;
/*      */         
/*  104 */         if (verbose) {
/*  105 */           System.out.println("Strict cert checking disabled by default");
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  112 */       trustedCertFile = System.getProperty("weblogic.webservice.client.ssl.trustedcertfile");
/*      */       
/*  114 */       if (trustedCertFile != null && verbose) {
/*  115 */         System.out.println("Trusted certificates will be loaded from " + trustedCertFile);
/*      */       }
/*      */ 
/*      */       
/*  119 */       defaultProxyHost = System.getProperty("weblogic.webservice.transport.https.proxy.host");
/*      */       
/*  121 */       String str1 = System.getProperty("weblogic.webservice.transport.https.proxy.port");
/*      */       
/*  123 */       if (str1 != null) {
/*  124 */         defaultProxyPort = Integer.parseInt(str1);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  130 */       String str2 = System.getProperty("weblogic.security.SSL.enforceConstraints");
/*      */       
/*  132 */       if (str2 != null) {
/*  133 */         if (str2.equalsIgnoreCase("off") || str2.equalsIgnoreCase("false")) {
/*      */           
/*  135 */           enforceConstraints = 0;
/*  136 */         } else if (str2.equalsIgnoreCase("strong") || str2.equalsIgnoreCase("true")) {
/*      */           
/*  138 */           enforceConstraints = 1;
/*  139 */         } else if (str2.equalsIgnoreCase("strict")) {
/*  140 */           enforceConstraints = 2;
/*      */         } 
/*      */       }
/*      */       
/*  144 */       if (enforceConstraints == 0 && verbose) {
/*  145 */         System.out.println("BasicContraints enforcement is disabled");
/*      */       } }
/*      */     
/*  148 */     catch (Throwable throwable)
/*  149 */     { if (verbose) {
/*  150 */         System.out.println("SSLAdapter error: " + throwable.getMessage());
/*  151 */         throwable.printStackTrace();
/*      */       }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  919 */     CertificateFactory certificateFactory = null;
/*      */     
/*      */     try {
/*  922 */       certificateFactory = CertificateFactory.getInstance("X.509");
/*  923 */     } catch (CertificateException certificateException) {
/*      */       
/*  925 */       if (verbose) System.out.println("Warning -- Peer did not provide auth chain");
/*      */     
/*      */     } 
/*  928 */     javaCertFactory = certificateFactory; } public final void loadLocalIdentity(InputStream paramInputStream, char[] paramArrayOfChar) throws KeyManagementException { if (adapterUsed())
/*      */       throw new IllegalArgumentException("Cannot load identities once the adapter has been used");  getContext().loadLocalIdentity(paramInputStream, paramArrayOfChar); if (verbose)
/*      */       System.out.println("Loaded local identity from " + paramInputStream);  }
/*      */   public final X509Certificate[] getIdentity(String paramString, int paramInt) { try { return X509java2javax(getContext().getAuthChain(paramString, paramInt)); } catch (CertificateEncodingException certificateEncodingException) { throw new IllegalArgumentException("failed to process provided certificates: " + certificateEncodingException); } catch (CertificateException certificateException) { throw new IllegalArgumentException("failed to process provided certificates: " + certificateException); }  }
/*      */   public final void addIdentity(X509Certificate[] paramArrayOfX509Certificate, byte[] paramArrayOfByte) { X509Certificate[] arrayOfX509Certificate; try { arrayOfX509Certificate = X509javax2java(paramArrayOfX509Certificate); } catch (CertificateException certificateException) { throw new IllegalArgumentException("failed to process provided certificates: " + certificateException); } catch (CertificateEncodingException certificateEncodingException) { throw new IllegalArgumentException("failed to process provided certificates:" + certificateEncodingException); }  if (adapterUsed())
/*      */       throw new IllegalStateException("Cannot add identities once the adapter has been used");  getContext().addAuthChain(arrayOfX509Certificate, paramArrayOfByte); }
/*      */   public final void addIdentity(X509Certificate[] paramArrayOfX509Certificate, PrivateKey paramPrivateKey) { X509Certificate[] arrayOfX509Certificate; try { arrayOfX509Certificate = X509javax2java(paramArrayOfX509Certificate); } catch (CertificateException certificateException) { throw new IllegalArgumentException("failed to process provided certificates: " + certificateException); } catch (CertificateEncodingException certificateEncodingException) { throw new IllegalArgumentException("failed to process provided certificates:" + certificateEncodingException); }  addIdentity(arrayOfX509Certificate, paramPrivateKey); }
/*      */   public final void addIdentity(X509Certificate[] paramArrayOfX509Certificate, PrivateKey paramPrivateKey) { if (adapterUsed())
/*      */       throw new IllegalStateException("Cannot add identities once the adapter has been used");  getContext().addAuthChain(paramArrayOfX509Certificate, paramPrivateKey); }
/*      */   public final void removeIdentity(X509Certificate paramX509Certificate) { try { removeIdentity(X509javax2java(paramX509Certificate)); } catch (CertificateEncodingException certificateEncodingException) { throw new IllegalArgumentException("failed to process provided certificates: " + certificateEncodingException); }
/*      */     catch (CertificateException certificateException) { throw new IllegalArgumentException("failed to process provided certificates: " + certificateException); }
/*      */      }
/*      */   public final void removeIdentity(X509Certificate paramX509Certificate) { if (adapterUsed())
/*      */       throw new IllegalArgumentException("Cannot add identities once the adapter has been used");  getContext().removeAuthChain(paramX509Certificate); }
/*  942 */   public static final X509Certificate X509java2javax(X509Certificate paramX509Certificate) throws CertificateEncodingException, CertificateException { return X509Certificate.getInstance(paramX509Certificate.getEncoded()); } public final void setProtocolVersion(String paramString) { if (adapterUsed())
/*      */       throw new IllegalArgumentException("Cannot change protocol version once adapter has been used");  getContext().setHelloProtocol(paramString); } public final String getProtocolVersion() { return getContext().getHelloProtocol(); } public final void setTrustManager(TrustManager paramTrustManager) { if (adapterUsed())
/*      */       throw new IllegalArgumentException("Cannot change trust manager once the adapter has been used");  getContext().setTrustManager(new TrustManagerWrapper(paramTrustManager)); if (verbose)
/*      */       System.out.println("Set TrustManager to " + paramTrustManager);  }
/*      */   public final void setTrustManager(TrustManager paramTrustManager, Object paramObject) { if (adapterUsed())
/*      */       throw new IllegalArgumentException("Cannot change trust manager once the adapter has been used");  this.strictManager = paramTrustManager; getContext().setTrustManager(new TrustManagerWrapper(paramTrustManager), paramObject); resetFactory(); if (verbose)
/*      */       System.out.println("Set TrustManager to " + paramTrustManager + " with callback " + paramObject);  }
/*      */   public void setProxy(String paramString, int paramInt) { if (paramString == null)
/*      */       throw new IllegalArgumentException("Must provide a proxy hostname"); 
/*      */     this.proxyHost = paramString;
/*      */     this.proxyPort = paramInt; }
/*      */   public void clearProxy() { this.proxyHost = null; }
/*      */   protected final SSLContext getContext() { if (this.context == null) {
/*      */       this.context = new SSLContext();
/*      */       setX509ConstraintBug(this.context);
/*      */     } 
/*      */     return this.context; }
/*  959 */   public static final X509Certificate X509javax2java(X509Certificate paramX509Certificate) throws CertificateException, CertificateEncodingException { ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramX509Certificate.getEncoded());
/*      */     
/*  961 */     return (X509Certificate)javaCertFactory.generateCertificate(byteArrayInputStream); } private void setX509ConstraintBug(SSLContext paramSSLContext) { if (enforceConstraints == 2) {
/*      */       paramSSLContext.setX509BasicConstraintBug(false);
/*      */       paramSSLContext.setX509StrictConstraints(true);
/*      */     } else if (enforceConstraints == 0) {
/*      */       paramSSLContext.setX509BasicConstraintBug(true);
/*      */       paramSSLContext.setX509StrictConstraints(false);
/*      */     } else {
/*      */       paramSSLContext.setX509BasicConstraintBug(false);
/*      */       paramSSLContext.setX509StrictConstraints(false);
/*      */     }  } protected final boolean getStrictCheckingDefault() { return strictCheckingDefault; } private void resetFactory() { this.socketFactory = null; }
/*      */   protected SSLSocketFactory getSocketFactory() { if (this.socketFactory == null) {
/*      */       this.socketFactory = getContext().getSocketFactory();
/*      */       if (verbose)
/*      */         System.out.println("Got new socketfactory " + this.socketFactory); 
/*      */     } 
/*      */     return this.socketFactory; }
/*  977 */   public static final X509Certificate[] X509java2javax(X509Certificate[] paramArrayOfX509Certificate) throws CertificateException, CertificateEncodingException { X509Certificate[] arrayOfX509Certificate = new X509Certificate[paramArrayOfX509Certificate.length];
/*      */     
/*  979 */     for (byte b = 0; b < paramArrayOfX509Certificate.length; b++) {
/*  980 */       X509Certificate x509Certificate = paramArrayOfX509Certificate[b];
/*      */       
/*  982 */       arrayOfX509Certificate[b] = X509java2javax(x509Certificate);
/*      */     } 
/*      */     
/*  985 */     return arrayOfX509Certificate; } protected boolean adapterUsed() { return (this.socketFactory != null); } private Socket createProxySocket(String paramString, int paramInt) throws IOException { Socket socket = SSLUtil.doTunnelHandshake(this.proxyHost, this.proxyPort, paramString, paramInt); return getSocketFactory().createSocket(socket, paramString, paramInt, false); } private static class TrustManagerWrapper implements TrustManager {
/*      */     private TrustManager tm; public TrustManagerWrapper(TrustManager param1TrustManager) { if (param1TrustManager == null)
/*      */         throw new NullPointerException("null TrustManager");  this.tm = param1TrustManager; }
/*      */     public boolean certificateCallback(X509Certificate[] param1ArrayOfX509Certificate, int param1Int, Object param1Object) { X509Certificate[] arrayOfX509Certificate = null; try { arrayOfX509Certificate = BaseWLSSLAdapter.X509java2javax(param1ArrayOfX509Certificate); } catch (Exception exception) { return false; }  return this.tm.certificateCallback(arrayOfX509Certificate, param1Int, param1Object); } }
/*      */   private static class NullTrustManager implements TrustManager {
/*      */     private NullTrustManager() {}
/*      */     public boolean certificateCallback(X509Certificate[] param1ArrayOfX509Certificate, int param1Int, Object param1Object) { if (BaseWLSSLAdapter.verbose)
/*      */         try { String str = (String)param1Object; if (param1ArrayOfX509Certificate.length == 0) { System.out.println("Warning: empty cert chain"); } else { if ((param1Int & true) != 0)
/*      */               System.out.println("Warning: cert chain invalid");  if ((param1Int & 0x2) != 0)
/*      */               System.out.println("Warning: cert expired");  if ((param1Int & 0x4) != 0)
/*      */               System.out.println("Warning: cert chain incomplete");  if ((param1Int & 0x8) != 0)
/*      */               System.out.println("Warning: cert signature invalid");  if ((param1Int & 0x10) != 0)
/*      */               System.out.println("Warning: cert chain untrusted");  String str1 = getSubjectCN(param1ArrayOfX509Certificate[0].getSubjectDN()); if (!str1.equals(str))
/*      */               System.out.println("Warning: subject (" + str1 + ") does not match server name (" + str + ")");  }  } catch (Throwable throwable) { System.out.println("In Trust manager"); throwable.printStackTrace(); }   return true; }
/*      */     private String getSubjectCN(Principal param1Principal) { int i = param1Principal.getName().indexOf("CN="); return param1Principal.getName().substring(i + "CN=".length()); } }
/* 1000 */   public static final X509Certificate[] X509javax2java(X509Certificate[] paramArrayOfX509Certificate) throws CertificateEncodingException, CertificateException { X509Certificate[] arrayOfX509Certificate = new X509Certificate[paramArrayOfX509Certificate.length];
/*      */ 
/*      */     
/* 1003 */     for (byte b = 0; b < paramArrayOfX509Certificate.length; b++) {
/* 1004 */       X509Certificate x509Certificate = paramArrayOfX509Certificate[b];
/*      */       
/* 1006 */       arrayOfX509Certificate[b] = X509javax2java(x509Certificate);
/*      */     } 
/*      */     
/* 1009 */     return arrayOfX509Certificate; }
/*      */ 
/*      */   
/*      */   private File doPemCvt(String paramString) throws Exception {
/* 1013 */     KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
/* 1014 */     File file = null;
/*      */ 
/*      */     
/*      */     try {
/* 1018 */       file = File.createTempFile("wls", ".pem");
/*      */       
/* 1020 */       file.deleteOnExit();
/*      */       
/* 1022 */       FileOutputStream fileOutputStream = new FileOutputStream(file);
/* 1023 */       PrintWriter printWriter = new PrintWriter(fileOutputStream, true);
/* 1024 */       BASE64Encoder bASE64Encoder = new BASE64Encoder();
/* 1025 */       File file1 = new File(paramString);
/*      */       
/* 1027 */       keyStore.load(new FileInputStream(file1), null);
/*      */       
/* 1029 */       for (Enumeration enumeration = keyStore.aliases(); enumeration.hasMoreElements(); ) {
/* 1030 */         String str1 = (String)enumeration.nextElement();
/* 1031 */         Certificate certificate = keyStore.getCertificate(str1);
/* 1032 */         String str2 = bASE64Encoder.encodeBuffer(certificate.getEncoded());
/*      */         
/* 1034 */         printWriter.println("-----BEGIN CERTIFICATE-----");
/* 1035 */         printWriter.println(str2);
/* 1036 */         printWriter.println("-----END CERTIFICATE-----");
/*      */       } 
/*      */       
/* 1039 */       fileOutputStream.flush();
/* 1040 */       fileOutputStream.close();
/*      */     }
/* 1042 */     catch (Exception exception) {
/* 1043 */       if (verbose) {
/* 1044 */         System.out.println(exception.getMessage());
/*      */       }
/* 1046 */       file = null;
/*      */     } 
/*      */     
/* 1049 */     return file;
/*      */   }
/*      */   
/*      */   public abstract URLConnection openConnection(URL paramURL) throws IOException;
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\BaseWLSSLAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */