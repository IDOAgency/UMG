package weblogic.webservice.client;

import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;

public interface SSLAdapter {
  Socket createSocket(String paramString, int paramInt) throws IOException;
  
  URLConnection openConnection(URL paramURL) throws IOException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\SSLAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */