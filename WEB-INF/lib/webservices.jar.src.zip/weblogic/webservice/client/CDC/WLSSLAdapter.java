package weblogic.webservice.client.CDC;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import javax.net.ssl.SSLSocket;
import weblogic.webservice.client.BaseWLSSLAdapter;

public final class WLSSLAdapter extends BaseWLSSLAdapter {
  public WLSSLAdapter() { setStrictChecking(getStrictCheckingDefault()); }
  
  public final URLConnection openConnection(URL paramURL) throws IOException {
    if ("https".equalsIgnoreCase(paramURL.getProtocol()))
      throw new IOException("HttpsURLConnections not supported under CDC"); 
    return paramURL.openConnection();
  }
  
  public final void setStrictChecking(boolean paramBoolean) { _setStrictChecking(paramBoolean); }
  
  public static void main(String[] paramArrayOfString) {
    try {
      WLSSLAdapter wLSSLAdapter = new WLSSLAdapter();
      wLSSLAdapter.setVerbose(true);
      System.out.println("Got adapter: " + wLSSLAdapter);
      SSLSocket sSLSocket = (SSLSocket)wLSSLAdapter.createSocket("www.wellsfargo.com", 443);
      System.out.println("Got this socket: " + sSLSocket);
      System.out.println("Ciphers " + sSLSocket.getEnabledCipherSuites());
      sSLSocket.startHandshake();
    } catch (Throwable throwable) {
      System.out.println("Caught exception:" + throwable.getMessage());
      throwable.printStackTrace();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\CDC\WLSSLAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */