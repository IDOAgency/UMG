/*    */ package weblogic.webservice.client.CDC;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import javax.net.ssl.SSLSocket;
/*    */ import weblogic.webservice.client.BaseWLSSLAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WLSSLAdapter
/*    */   extends BaseWLSSLAdapter
/*    */ {
/* 24 */   public WLSSLAdapter() { setStrictChecking(getStrictCheckingDefault()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final URLConnection openConnection(URL paramURL) throws IOException {
/* 36 */     if ("https".equalsIgnoreCase(paramURL.getProtocol())) {
/* 37 */       throw new IOException("HttpsURLConnections not supported under CDC");
/*    */     }
/* 39 */     return paramURL.openConnection();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public final void setStrictChecking(boolean paramBoolean) { _setStrictChecking(paramBoolean); }
/*    */ 
/*    */   
/*    */   public static void main(String[] paramArrayOfString) {
/*    */     try {
/* 67 */       WLSSLAdapter wLSSLAdapter = new WLSSLAdapter();
/* 68 */       wLSSLAdapter.setVerbose(true);
/* 69 */       System.out.println("Got adapter: " + wLSSLAdapter);
/* 70 */       SSLSocket sSLSocket = (SSLSocket)wLSSLAdapter.createSocket("www.wellsfargo.com", 443);
/* 71 */       System.out.println("Got this socket: " + sSLSocket);
/* 72 */       System.out.println("Ciphers " + sSLSocket.getEnabledCipherSuites());
/*    */       
/* 74 */       sSLSocket.startHandshake();
/*    */     }
/* 76 */     catch (Throwable throwable) {
/* 77 */       System.out.println("Caught exception:" + throwable.getMessage());
/* 78 */       throwable.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\CDC\WLSSLAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */