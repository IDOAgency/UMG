/*    */ package weblogic.webservice.client.CDC.https;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.ConnectException;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Handler
/*    */   extends URLStreamHandler
/*    */ {
/* 27 */   protected void parseURL(URL paramURL, String paramString, int paramInt1, int paramInt2) { super.parseURL(paramURL, paramString, paramInt1, paramInt2); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   protected URLConnection openConnection(URL paramURL) throws IOException { throw new ConnectException("URLConnections not supported for protocol https under CDC"); }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] paramArrayOfString) {
/* 37 */     String str = System.getProperty("java.protocol.handler.pkgs");
/*    */     
/* 39 */     if (str == null) {
/* 40 */       System.setProperty("java.protocol.handler.pkgs", "weblogic.webservice.client.CDC");
/*    */     } else {
/* 42 */       System.out.println("using user provided pkgs = " + str);
/*    */     } 
/*    */     
/* 45 */     URL uRL = null;
/*    */     
/*    */     try {
/* 48 */       uRL = new URL("https://this.is.a.test:7002/");
/* 49 */     } catch (MalformedURLException malformedURLException) {
/* 50 */       System.out.println("failed to get URL: " + malformedURLException.getMessage());
/*    */     } 
/*    */     
/* 53 */     System.out.println("got URL: [" + uRL + "]");
/* 54 */     System.out.println("Protocol " + uRL.getProtocol());
/* 55 */     System.out.println("Port " + uRL.getPort());
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\CDC\https\Handler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */