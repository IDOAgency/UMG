package weblogic.webservice.client.https;

import com.certicom.net.ssl.HttpsURLConnection;
import com.certicom.net.ssl.SSLContext;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.Permission;
import java.security.cert.Certificate;
import javax.net.ssl.SSLSocketFactory;
import javax.security.cert.X509Certificate;

public class HttpsURLConnection extends HttpURLConnection {
  private final HttpsURLConnection connection;
  
  private final String string;
  
  public HttpsURLConnection(URL paramURL) throws IOException {
    super(paramURL);
    this.string = "weblogic.webservice.client.https.HttpsURLConnection:" + paramURL;
    this.connection = new HttpsURLConnection(paramURL);
  }
  
  public HttpsURLConnection(URL paramURL, SSLContext paramSSLContext) throws IOException {
    super(paramURL);
    this.string = "weblogic.webservice.client.https.HttpsURLConnection:" + paramURL;
    this.connection = new HttpsURLConnection(paramURL, paramSSLContext);
  }
  
  public static void setDefaultHostnameVerifier(HostnameVerifier paramHostnameVerifier) { HttpsURLConnection.setDefaultHostnameVerifier(paramHostnameVerifier); }
  
  public static HostnameVerifier getDefaultHostnameVerifier() {
    try {
      return (HostnameVerifier)HttpsURLConnection.getDefaultHostnameVerifier();
    } catch (ClassCastException classCastException) {
      return null;
    } 
  }
  
  public void setHostnameVerifier(HostnameVerifier paramHostnameVerifier) { this.connection.setHostnameVerifier(paramHostnameVerifier); }
  
  public void connect() throws IOException { this.connection.connect(); }
  
  public String getCipherSuite() { return this.connection.getCipherSuite(); }
  
  public X509Certificate[] getServerCertificateChain() {
    X509Certificate[] arrayOfX509Certificate = null;
    Certificate[] arrayOfCertificate = this.connection.getServerCertificateChain();
    if (arrayOfCertificate != null)
      try {
        arrayOfX509Certificate = new X509Certificate[arrayOfCertificate.length];
        for (byte b = 0; b < arrayOfCertificate.length; b++)
          arrayOfX509Certificate[b] = X509Certificate.getInstance(arrayOfCertificate[b].getEncoded()); 
      } catch (Exception exception) {
        throw new RuntimeException("Failed to convert server certificate", exception);
      }  
    return arrayOfX509Certificate;
  }
  
  public HostnameVerifier getHostnameVerifier() {
    try {
      return (HostnameVerifier)this.connection.getHostnameVerifier();
    } catch (ClassCastException classCastException) {
      return null;
    } 
  }
  
  public void setSSLSocketFactory(SSLSocketFactory paramSSLSocketFactory) { this.connection.setSSLSocketFactory(paramSSLSocketFactory); }
  
  public SSLSocketFactory getSSLSocketFactory() { return this.connection.getSSLSocketFactory(); }
  
  public boolean usingProxy() { return this.connection.usingProxy(); }
  
  public void disconnect() throws IOException { this.connection.disconnect(); }
  
  public OutputStream getOutputStream() throws IOException { return this.connection.getOutputStream(); }
  
  public InputStream getInputStream() throws IOException { return this.connection.getInputStream(); }
  
  public static void setFollowRedirects(boolean paramBoolean) { HttpsURLConnection.setFollowRedirects(paramBoolean); }
  
  public static boolean getFollowRedirects() { return HttpsURLConnection.getFollowRedirects(); }
  
  public void setInstanceFollowRedirects(boolean paramBoolean) { this.connection.setInstanceFollowRedirects(paramBoolean); }
  
  public boolean getInstanceFollowRedirects() { return this.connection.getInstanceFollowRedirects(); }
  
  public void setRequestMethod(String paramString) throws ProtocolException { this.connection.setRequestMethod(paramString); }
  
  public String getRequestMethod() { return this.connection.getRequestMethod(); }
  
  public int getResponseCode() throws IOException { return this.connection.getResponseCode(); }
  
  public String getResponseMessage() { return this.connection.getResponseMessage(); }
  
  public InputStream getErrorStream() throws IOException { return this.connection.getErrorStream(); }
  
  public int getContentLength() throws IOException { return this.connection.getContentLength(); }
  
  public String getContentType() { return this.connection.getContentType(); }
  
  public String getContentEncoding() { return this.connection.getContentEncoding(); }
  
  public long getExpiration() { return this.connection.getExpiration(); }
  
  public long getDate() { return this.connection.getDate(); }
  
  public long getLastModified() { return this.connection.getLastModified(); }
  
  public String getHeaderField(String paramString) { return this.connection.getHeaderField(paramString); }
  
  public int getHeaderFieldInt(String paramString, int paramInt) { return this.connection.getHeaderFieldInt(paramString, paramInt); }
  
  public long getHeaderFieldDate(String paramString, long paramLong) { return this.connection.getHeaderFieldDate(paramString, paramLong); }
  
  public URL getURL() { return this.connection.getURL(); }
  
  public String getHeaderFieldKey(int paramInt) { return this.connection.getHeaderFieldKey(paramInt); }
  
  public String getHeaderField(int paramInt) { return this.connection.getHeaderField(paramInt); }
  
  public Object getContent() throws IOException { return this.connection.getContent(); }
  
  public Object getContent(Class[] paramArrayOfClass) throws IOException { return this.connection.getContent(paramArrayOfClass); }
  
  public Permission getPermission() throws IOException { return this.connection.getPermission(); }
  
  public String toString() { return this.string; }
  
  public void setDoInput(boolean paramBoolean) { this.connection.setDoInput(paramBoolean); }
  
  public boolean getDoInput() { return this.connection.getDoInput(); }
  
  public void setDoOutput(boolean paramBoolean) { this.connection.setDoOutput(paramBoolean); }
  
  public boolean getDoOutput() { return this.connection.getDoOutput(); }
  
  public void setAllowUserInteraction(boolean paramBoolean) { this.connection.setAllowUserInteraction(paramBoolean); }
  
  public boolean getAllowUserInteraction() { return this.connection.getAllowUserInteraction(); }
  
  public static void setDefaultAllowUserInteraction(boolean paramBoolean) { HttpsURLConnection.setDefaultAllowUserInteraction(paramBoolean); }
  
  public static boolean getDefaultAllowUserInteraction() { return HttpsURLConnection.getDefaultAllowUserInteraction(); }
  
  public void setUseCaches(boolean paramBoolean) { this.connection.setUseCaches(paramBoolean); }
  
  public boolean getUseCaches() { return this.connection.getUseCaches(); }
  
  public void setIfModifiedSince(long paramLong) { this.connection.setIfModifiedSince(paramLong); }
  
  public long getIfModifiedSince() { return this.connection.getIfModifiedSince(); }
  
  public boolean getDefaultUseCaches() { return this.connection.getDefaultUseCaches(); }
  
  public void setDefaultUseCaches(boolean paramBoolean) { this.connection.setDefaultUseCaches(paramBoolean); }
  
  public void setRequestProperty(String paramString1, String paramString2) { this.connection.setRequestProperty(paramString1, paramString2); }
  
  public String getRequestProperty(String paramString) { return this.connection.getRequestProperty(paramString); }
  
  public static void setDefaultRequestProperty(String paramString1, String paramString2) { HttpsURLConnection.setDefaultRequestProperty(paramString1, paramString2); }
  
  public void loadTrustedCertificates(InputStream paramInputStream) throws KeyManagementException, IOException { this.connection.loadTrustedCertificates(paramInputStream); }
  
  public void loadLocalIdentity(InputStream paramInputStream, char[] paramArrayOfChar) throws KeyManagementException { this.connection.loadLocalIdentity(paramInputStream, paramArrayOfChar); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\https\HttpsURLConnection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */