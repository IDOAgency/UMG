/*     */ package weblogic.webservice.client.https;
/*     */ 
/*     */ import com.certicom.net.ssl.HttpsURLConnection;
/*     */ import com.certicom.net.ssl.SSLContext;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.URL;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.Permission;
/*     */ import java.security.cert.Certificate;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.security.cert.X509Certificate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpsURLConnection
/*     */   extends HttpURLConnection
/*     */ {
/*     */   private final HttpsURLConnection connection;
/*     */   private final String string;
/*     */   
/*     */   public HttpsURLConnection(URL paramURL) throws IOException {
/*  66 */     super(paramURL);
/*  67 */     this.string = "weblogic.webservice.client.https.HttpsURLConnection:" + paramURL;
/*  68 */     this.connection = new HttpsURLConnection(paramURL);
/*     */   }
/*     */   
/*     */   public HttpsURLConnection(URL paramURL, SSLContext paramSSLContext) throws IOException {
/*  72 */     super(paramURL);
/*  73 */     this.string = "weblogic.webservice.client.https.HttpsURLConnection:" + paramURL;
/*  74 */     this.connection = new HttpsURLConnection(paramURL, paramSSLContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public static void setDefaultHostnameVerifier(HostnameVerifier paramHostnameVerifier) { HttpsURLConnection.setDefaultHostnameVerifier(paramHostnameVerifier); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static HostnameVerifier getDefaultHostnameVerifier() {
/*     */     try {
/*  99 */       return (HostnameVerifier)HttpsURLConnection.getDefaultHostnameVerifier();
/* 100 */     } catch (ClassCastException classCastException) {
/* 101 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void setHostnameVerifier(HostnameVerifier paramHostnameVerifier) { this.connection.setHostnameVerifier(paramHostnameVerifier); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public void connect() throws IOException { this.connection.connect(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public String getCipherSuite() { return this.connection.getCipherSuite(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public X509Certificate[] getServerCertificateChain() {
/* 158 */     X509Certificate[] arrayOfX509Certificate = null;
/* 159 */     Certificate[] arrayOfCertificate = this.connection.getServerCertificateChain();
/* 160 */     if (arrayOfCertificate != null) {
/*     */       try {
/* 162 */         arrayOfX509Certificate = new X509Certificate[arrayOfCertificate.length];
/* 163 */         for (byte b = 0; b < arrayOfCertificate.length; b++) {
/* 164 */           arrayOfX509Certificate[b] = X509Certificate.getInstance(arrayOfCertificate[b].getEncoded());
/*     */         }
/*     */       }
/* 167 */       catch (Exception exception) {
/* 168 */         throw new RuntimeException("Failed to convert server certificate", exception);
/*     */       } 
/*     */     }
/* 171 */     return arrayOfX509Certificate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HostnameVerifier getHostnameVerifier() {
/*     */     try {
/* 183 */       return (HostnameVerifier)this.connection.getHostnameVerifier();
/* 184 */     } catch (ClassCastException classCastException) {
/* 185 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public void setSSLSocketFactory(SSLSocketFactory paramSSLSocketFactory) { this.connection.setSSLSocketFactory(paramSSLSocketFactory); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public SSLSocketFactory getSSLSocketFactory() { return this.connection.getSSLSocketFactory(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   public boolean usingProxy() { return this.connection.usingProxy(); }
/*     */ 
/*     */ 
/*     */   
/* 216 */   public void disconnect() throws IOException { this.connection.disconnect(); }
/*     */ 
/*     */ 
/*     */   
/* 220 */   public OutputStream getOutputStream() throws IOException { return this.connection.getOutputStream(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public InputStream getInputStream() throws IOException { return this.connection.getInputStream(); }
/*     */ 
/*     */ 
/*     */   
/* 235 */   public static void setFollowRedirects(boolean paramBoolean) { HttpsURLConnection.setFollowRedirects(paramBoolean); }
/*     */ 
/*     */ 
/*     */   
/* 239 */   public static boolean getFollowRedirects() { return HttpsURLConnection.getFollowRedirects(); }
/*     */ 
/*     */ 
/*     */   
/* 243 */   public void setInstanceFollowRedirects(boolean paramBoolean) { this.connection.setInstanceFollowRedirects(paramBoolean); }
/*     */ 
/*     */ 
/*     */   
/* 247 */   public boolean getInstanceFollowRedirects() { return this.connection.getInstanceFollowRedirects(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 270 */   public void setRequestMethod(String paramString) throws ProtocolException { this.connection.setRequestMethod(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   public String getRequestMethod() { return this.connection.getRequestMethod(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   public int getResponseCode() throws IOException { return this.connection.getResponseCode(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 312 */   public String getResponseMessage() { return this.connection.getResponseMessage(); }
/*     */ 
/*     */ 
/*     */   
/* 316 */   public InputStream getErrorStream() throws IOException { return this.connection.getErrorStream(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 327 */   public int getContentLength() throws IOException { return this.connection.getContentLength(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 338 */   public String getContentType() { return this.connection.getContentType(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 349 */   public String getContentEncoding() { return this.connection.getContentEncoding(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 361 */   public long getExpiration() { return this.connection.getExpiration(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 373 */   public long getDate() { return this.connection.getDate(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 385 */   public long getLastModified() { return this.connection.getLastModified(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 396 */   public String getHeaderField(String paramString) { return this.connection.getHeaderField(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 414 */   public int getHeaderFieldInt(String paramString, int paramInt) { return this.connection.getHeaderFieldInt(paramString, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 434 */   public long getHeaderFieldDate(String paramString, long paramLong) { return this.connection.getHeaderFieldDate(paramString, paramLong); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 449 */   public URL getURL() { return this.connection.getURL(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 461 */   public String getHeaderFieldKey(int paramInt) { return this.connection.getHeaderFieldKey(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 478 */   public String getHeaderField(int paramInt) { return this.connection.getHeaderField(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 497 */   public Object getContent() throws IOException { return this.connection.getContent(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 520 */   public Object getContent(Class[] paramArrayOfClass) throws IOException { return this.connection.getContent(paramArrayOfClass); }
/*     */ 
/*     */ 
/*     */   
/* 524 */   public Permission getPermission() throws IOException { return this.connection.getPermission(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 533 */   public String toString() { return this.string; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 551 */   public void setDoInput(boolean paramBoolean) { this.connection.setDoInput(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 563 */   public boolean getDoInput() { return this.connection.getDoInput(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 578 */   public void setDoOutput(boolean paramBoolean) { this.connection.setDoOutput(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 590 */   public boolean getDoOutput() { return this.connection.getDoOutput(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 601 */   public void setAllowUserInteraction(boolean paramBoolean) { this.connection.setAllowUserInteraction(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 613 */   public boolean getAllowUserInteraction() { return this.connection.getAllowUserInteraction(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 625 */   public static void setDefaultAllowUserInteraction(boolean paramBoolean) { HttpsURLConnection.setDefaultAllowUserInteraction(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 641 */   public static boolean getDefaultAllowUserInteraction() { return HttpsURLConnection.getDefaultAllowUserInteraction(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 661 */   public void setUseCaches(boolean paramBoolean) { this.connection.setUseCaches(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 673 */   public boolean getUseCaches() { return this.connection.getUseCaches(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 684 */   public void setIfModifiedSince(long paramLong) { this.connection.setIfModifiedSince(paramLong); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 694 */   public long getIfModifiedSince() { return this.connection.getIfModifiedSince(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 710 */   public boolean getDefaultUseCaches() { return this.connection.getDefaultUseCaches(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 721 */   public void setDefaultUseCaches(boolean paramBoolean) { this.connection.setDefaultUseCaches(paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 739 */   public void setRequestProperty(String paramString1, String paramString2) { this.connection.setRequestProperty(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 752 */   public String getRequestProperty(String paramString) { return this.connection.getRequestProperty(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 773 */   public static void setDefaultRequestProperty(String paramString1, String paramString2) { HttpsURLConnection.setDefaultRequestProperty(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */   
/* 777 */   public void loadTrustedCertificates(InputStream paramInputStream) throws KeyManagementException, IOException { this.connection.loadTrustedCertificates(paramInputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 782 */   public void loadLocalIdentity(InputStream paramInputStream, char[] paramArrayOfChar) throws KeyManagementException { this.connection.loadLocalIdentity(paramInputStream, paramArrayOfChar); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\https\HttpsURLConnection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */