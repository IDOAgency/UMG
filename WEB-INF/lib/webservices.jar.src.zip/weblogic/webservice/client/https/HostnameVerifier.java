package weblogic.webservice.client.https;

import com.certicom.net.ssl.HostnameVerifier;

public interface HostnameVerifier extends HostnameVerifier {
  boolean verify(String paramString1, String paramString2);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\https\HostnameVerifier.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */