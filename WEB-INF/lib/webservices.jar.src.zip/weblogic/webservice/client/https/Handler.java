package weblogic.webservice.client.https;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

public class Handler extends URLStreamHandler {
  protected void parseURL(URL paramURL, String paramString, int paramInt1, int paramInt2) { super.parseURL(paramURL, paramString, paramInt1, paramInt2); }
  
  protected URLConnection openConnection(URL paramURL) throws IOException { return new HttpsURLConnection(paramURL); }
  
  public static void main(String[] paramArrayOfString) {
    String str = System.getProperty("java.protocol.handler.pkgs");
    if (str == null) {
      System.setProperty("java.protocol.handler.pkgs", "weblogic.webservice.client");
    } else {
      System.out.println("using user provided pkgs = " + str);
    } 
    URL uRL = null;
    try {
      uRL = new URL("https://this.is.a.test:7002/");
    } catch (MalformedURLException malformedURLException) {
      System.out.println("failed to get URL: " + malformedURLException.getMessage());
    } 
    System.out.println("got URL: [" + uRL + "]");
    System.out.println("Protocol " + uRL.getProtocol());
    System.out.println("Port " + uRL.getPort());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\https\Handler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */