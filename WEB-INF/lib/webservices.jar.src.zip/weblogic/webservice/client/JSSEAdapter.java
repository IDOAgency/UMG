/*     */ package weblogic.webservice.client;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.KeyStore;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.X509Certificate;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSSEAdapter
/*     */   implements SSLAdapter
/*     */ {
/*     */   public static final String STRICT_CHECKING_DEFAULT = "weblogic.webservice.client.ssl.strictcertchecking";
/*     */   public static final String VERBOSE_PROPERTY = "weblogic.webservice.client.verbose";
/*     */   public static final String TRUSTED_CERTS = "weblogic.webservice.client.ssl.trustedcertfile";
/*     */   public static final String ENFORCE_CONSTRAINTS = "weblogic.security.SSL.enforceConstraints";
/*     */   private static final String HTTPS_PROXY_HOST = "weblogic.webservice.transport.https.proxy.host";
/*     */   private static final String HTTPS_PROXY_PORT = "weblogic.webservice.transport.https.proxy.port";
/*     */   private static final String DEFAULT_HTTPS_PROXY_HOST = "https.proxyHost";
/*     */   private static final String DEFAULT_HTTPS_PROXY_PORT = "https.proxyPort";
/*     */   private SSLSocketFactory _factory;
/*     */   SSLSocketFactory factory;
/*  51 */   private static String proxyHost = getStringProp("weblogic.webservice.transport.https.proxy.host", null);
/*  52 */   private static String proxyPort = getStringProp("weblogic.webservice.transport.https.proxy.port", null);
/*     */   
/*  54 */   private static final TrustManager trustingManager = new NullTrustManager(null);
/*  55 */   private static TrustManager strictManager = null;
/*  56 */   private static KeyManager localKeyManager = null;
/*     */   
/*  58 */   private static SSLContext context = null;
/*     */   
/*  60 */   private static final HostnameVerifier nonverifier = new NullVerifier(null);
/*     */   
/*     */   private HostnameVerifier verifier;
/*     */   protected static boolean verbose = false;
/*     */   private static boolean strictCheckingDefault = true;
/*     */   protected boolean strictCertChecking;
/*  66 */   protected static String trustedCertFile = null;
/*     */   
/*     */   private String[] enabledCiphers;
/*     */   private InputStream myKeystream;
/*     */   private char[] myPassword;
/*     */   boolean proxyEnabled;
/*  72 */   private static String defaultProxyHost = null;
/*  73 */   private static int defaultProxyPort = 8080;
/*     */   
/*     */   private static String getStringProp(String paramString1, String paramString2) {
/*     */     try {
/*  77 */       return System.getProperty(paramString1);
/*  78 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */       
/*  82 */       return paramString2;
/*     */     } 
/*     */   }
/*     */   private static boolean getBooleanProp(String paramString, boolean paramBoolean) {
/*     */     try {
/*  87 */       return Boolean.getBoolean(paramString);
/*  88 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */       
/*  92 */       return paramBoolean;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static  {
/*     */     try {
/*  99 */       verbose = getBooleanProp("weblogic.webservice.client.verbose", false);
/* 100 */       if (verbose) {
/* 101 */         System.out.println("JSSEAdapter verbose output enabled");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 107 */       if (!getBooleanProp("weblogic.webservice.client.ssl.strictcertchecking", true)) {
/* 108 */         strictCheckingDefault = false;
/* 109 */         if (verbose) {
/* 110 */           System.out.println("JSSEAdapter strict cert checking disabled by default");
/*     */         }
/*     */       } 
/*     */       
/* 114 */       trustedCertFile = getStringProp("weblogic.webservice.client.ssl.trustedcertfile", null);
/* 115 */       if (trustedCertFile != null && verbose) {
/* 116 */         System.out.println("JSSEAdapter trusted certificates will be loaded from " + trustedCertFile);
/*     */       }
/*     */       
/* 119 */       defaultProxyHost = getStringProp("weblogic.webservice.transport.https.proxy.host", null);
/* 120 */       String str = getStringProp("weblogic.webservice.transport.https.proxy.port", null);
/*     */       
/* 122 */       if (str != null) {
/* 123 */         defaultProxyPort = Integer.parseInt(str);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 128 */       context = SSLContext.getInstance("SSL");
/*     */       
/* 130 */       TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance("SunX509", "SunJSSE");
/* 131 */       trustManagerFactory.init((KeyStore)null);
/* 132 */       strictManager = trustManagerFactory.getTrustManagers()[0];
/*     */     }
/* 134 */     catch (Throwable throwable) {
/* 135 */       if (verbose) {
/* 136 */         System.out.println("JSSEAdapter error: " + throwable.getMessage());
/* 137 */         throwable.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSSEAdapter() {
/*     */     this._factory = null;
/*     */     this.factory = this._factory;
/*     */     this.verifier = null;
/*     */     this.strictCertChecking = true;
/*     */     this.enabledCiphers = null;
/*     */     this.myKeystream = null;
/*     */     this.myPassword = null;
/*     */     this.proxyEnabled = false;
/* 165 */     setStrictChecking(getStrictCheckingDefault());
/* 166 */     if (proxyHost != null && proxyPort != null)
/* 167 */       enableProxy(proxyHost, proxyPort);  } public JSSEAdapter(boolean paramBoolean) { this._factory = null; this.factory = this._factory; this.verifier = null;
/*     */     this.strictCertChecking = true;
/*     */     this.enabledCiphers = null;
/*     */     this.myKeystream = null;
/*     */     this.myPassword = null;
/*     */     this.proxyEnabled = false;
/* 173 */     setStrictChecking(paramBoolean);
/* 174 */     if (proxyHost != null && proxyPort != null) {
/* 175 */       enableProxy(proxyHost, proxyPort);
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   public void enableProxy(String paramString1, String paramString2) {
/* 181 */     this.factory = new SSLTunnelSocketFactory(this._factory, paramString1, paramString2);
/* 182 */     this.proxyEnabled = true;
/*     */   }
/*     */   
/*     */   public void disableProxy() {
/* 186 */     this.factory = this._factory;
/* 187 */     this.proxyEnabled = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Socket createSocket(String paramString, int paramInt) throws IOException {
/* 204 */     SSLSocket sSLSocket = null;
/*     */     
/*     */     try {
/* 207 */       if (proxyHost != null) {
/* 208 */         sSLSocket = (SSLSocket)createProxySocket(paramString, paramInt);
/*     */       } else {
/* 210 */         sSLSocket = (SSLSocket)getSocketFactory().createSocket(paramString, paramInt);
/*     */       } 
/*     */       
/* 213 */       if (this.enabledCiphers != null) {
/* 214 */         sSLSocket.setEnabledCipherSuites(this.enabledCiphers);
/*     */       }
/*     */       
/* 217 */       if (verbose) {
/* 218 */         System.out.println("JSSEAdapter connecting to:" + paramString + " port:" + paramInt + " socket:" + sSLSocket);
/*     */       }
/*     */     }
/* 221 */     catch (ClassCastException classCastException) {
/*     */       
/* 223 */       throw new IOException("JSSEAdapter unable to create SSLSocket instance");
/*     */     } 
/*     */     
/* 226 */     return sSLSocket;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Socket createProxySocket(String paramString, int paramInt) throws IOException {
/* 233 */     Socket socket = SSLUtil.doTunnelHandshake(proxyHost, Integer.valueOf(proxyPort).intValue(), paramString, paramInt);
/*     */ 
/*     */     
/* 236 */     return this.factory.createSocket(socket, paramString, paramInt, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLConnection openConnection(URL paramURL) throws IOException {
/* 253 */     URLConnection uRLConnection = paramURL.openConnection();
/*     */     
/*     */     try {
/* 256 */       HttpsURLConnection httpsURLConnection = (HttpsURLConnection)uRLConnection;
/* 257 */       httpsURLConnection.setSSLSocketFactory(this.factory);
/* 258 */     } catch (ClassCastException classCastException) {
/*     */     
/* 260 */     } catch (Throwable throwable) {
/* 261 */       System.out.println("JSSEAdapter exception: " + throwable.getMessage());
/*     */     } 
/* 263 */     return uRLConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setStrictCheckingDefault(boolean paramBoolean) {
/* 283 */     if (verbose) {
/* 284 */       System.out.println("JSSEAdapter set default cert checking to: " + (paramBoolean ? "STRICT." : "ACCEPTING."));
/*     */     }
/*     */     
/* 287 */     strictCheckingDefault = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/* 291 */   protected final boolean getStrictCheckingDefault() { return strictCheckingDefault; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setStrictChecking(boolean paramBoolean) {
/* 313 */     if (adapterUsed()) throw new IllegalArgumentException("JSSEAdapter cannot change certificate checking once the adapter has been used.");
/*     */ 
/*     */     
/* 316 */     _setStrictChecking(paramBoolean);
/*     */     
/* 318 */     if (paramBoolean) {
/* 319 */       setHostnameVerifier(this.verifier);
/*     */     } else {
/*     */       
/* 322 */       setHostnameVerifier(nonverifier);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setHostnameVerifier(HostnameVerifier paramHostnameVerifier) {
/* 337 */     this.verifier = paramHostnameVerifier;
/* 338 */     if (paramHostnameVerifier != null)
/* 339 */     { HttpsURLConnection.setDefaultHostnameVerifier(paramHostnameVerifier); }
/*     */     
/* 341 */     else if (verbose) { System.out.println("JSSEAdapter using the default JSSE HostnameVerifier."); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 358 */   public void setVerbose(boolean paramBoolean) { this; verbose = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTrustManager(TrustManager paramTrustManager) {
/* 375 */     if (adapterUsed()) {
/* 376 */       throw new IllegalArgumentException("JSSEAdapter cannot change trust manager once the adapter has been used");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 381 */       X509TrustManager[] arrayOfX509TrustManager = { (X509TrustManager)paramTrustManager };
/*     */       
/* 383 */       if (this.myKeystream != null) {
/*     */         
/* 385 */         File file = File.createTempFile("wsjsse", ".fix");
/*     */         
/* 387 */         file.deleteOnExit();
/* 388 */         FileOutputStream fileOutputStream = new FileOutputStream(file);
/*     */         
/* 390 */         KeyStore keyStore = KeyStore.getInstance("JKS");
/*     */         
/* 392 */         keyStore.load(this.myKeystream, this.myPassword);
/* 393 */         keyStore.store(fileOutputStream, this.myPassword);
/* 394 */         fileOutputStream.close();
/* 395 */         System.setProperty("javax.net.ssl.keyStore", file.getAbsolutePath());
/* 396 */         System.setProperty("javax.net.ssl.keyStorePassword", new String(this.myPassword));
/* 397 */         if (verbose) {
/* 398 */           System.out.println("JSSEAdapter setting KeyManager to: " + file.getName());
/*     */         }
/*     */       } else {
/* 401 */         context.init(null, arrayOfX509TrustManager, new SecureRandom());
/* 402 */         if (verbose) {
/* 403 */           System.out.println("JSSEAdapter KeyManager null");
/*     */         }
/*     */       }
/*     */     
/* 407 */     } catch (Exception exception) {
/* 408 */       if (verbose) {
/* 409 */         System.out.println("JSSEAdapter failure in getInstance.");
/* 410 */         exception.printStackTrace();
/*     */       } 
/* 412 */       throw new IllegalArgumentException("JSSEAdapter failed to obtain SSLContext.");
/*     */     } 
/*     */     
/* 415 */     if (verbose) {
/* 416 */       System.out.println("JSSEAdapter setTrustManager to " + paramTrustManager);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void loadLocalIdentity(InputStream paramInputStream, char[] paramArrayOfChar) throws Exception {
/* 434 */     if (adapterUsed()) {
/* 435 */       throw new IllegalArgumentException("JSSEAdapter cannot load identities once the adapter has been used.");
/*     */     }
/*     */     
/* 438 */     this.myKeystream = paramInputStream;
/* 439 */     this.myPassword = paramArrayOfChar;
/*     */     
/* 441 */     if (verbose) {
/* 442 */       System.out.println("JSSEAdapter Loaded local identity from keystore: " + paramInputStream);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _setStrictChecking(boolean paramBoolean) {
/* 456 */     if (adapterUsed()) {
/* 457 */       throw new IllegalArgumentException("JSSEAdapter cannot change strict checking once the adapter has been used");
/*     */     }
/*     */     
/* 460 */     if (paramBoolean) {
/* 461 */       if (verbose) {
/* 462 */         System.out.println("JSSEAdapter enabling strict checking on adapter " + this);
/*     */       }
/* 464 */       setTrustManager(strictManager);
/*     */     } else {
/* 466 */       if (verbose) {
/* 467 */         System.out.println("JSSEAdapter disabling strict checking on adapter " + this);
/*     */       }
/* 469 */       setTrustManager(trustingManager);
/*     */     } 
/* 471 */     this.strictCertChecking = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 480 */   private void resetFactory() { this._factory = null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SSLSocketFactory getSocketFactory() {
/* 489 */     if (this.factory == null) {
/* 490 */       this.factory = (SSLSocketFactory)SSLSocketFactory.getDefault();
/*     */       
/* 492 */       if (verbose) {
/* 493 */         System.out.println("JSSEAdaptger got new socketfactory: " + this.factory);
/*     */       }
/*     */     } 
/* 496 */     return this.factory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSocketFactory(SSLSocketFactory paramSSLSocketFactory) {
/* 505 */     this._factory = paramSSLSocketFactory;
/* 506 */     if (!this.proxyEnabled) {
/* 507 */       this.factory = paramSSLSocketFactory;
/*     */     } else {
/* 509 */       ((SSLTunnelSocketFactory)paramSSLSocketFactory).setDelegateFactory(paramSSLSocketFactory);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 518 */   protected boolean adapterUsed() { return (this.factory != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxy(String paramString, int paramInt) {
/* 526 */     if (paramString == null) {
/* 527 */       throw new IllegalArgumentException("Must provide a proxy hostname");
/*     */     }
/* 529 */     this; proxyHost = paramString;
/* 530 */     this; proxyPort = Integer.toString(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProxyAuth(String paramString1, String paramString2) {
/* 538 */     if (!this.proxyEnabled) {
/* 539 */       throw new IllegalStateException("Cannot set proxy username/password until proxy has been enabled.");
/*     */     }
/* 541 */     if (paramString1 == null || paramString2 == null) {
/* 542 */       throw new IllegalArgumentException("Cannot set username or password to null");
/*     */     }
/* 544 */     ((SSLTunnelSocketFactory)this.factory).setProxyAuth(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 557 */   public String toString() { return "<JSSEAdapter name=\"" + super.toString() + "\" proxyEnabled=" + this.proxyEnabled + " proxyHost=" + proxyHost + " proxyPort=" + proxyPort + ">\n" + this.factory + "\n</JSSEAdapter>"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NullVerifier
/*     */     implements HostnameVerifier
/*     */   {
/*     */     private NullVerifier() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean verify(String param1String, SSLSession param1SSLSession) {
/* 571 */       if (!param1String.equals(param1SSLSession.getPeerHost()))
/* 572 */       { if (JSSEAdapter.verbose) System.out.println("JSSEAdapter certificate <" + param1SSLSession.getPeerHost() + "> does not match host <" + param1String + "> however continuing anyway.");
/*     */         
/*     */          }
/*     */       
/* 576 */       else if (JSSEAdapter.verbose) { System.out.println("JSSEAdapter HostnameVerifier success URL: " + param1String); }
/*     */       
/* 578 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class NullTrustManager
/*     */     implements X509TrustManager
/*     */   {
/*     */     private NullTrustManager() {}
/*     */     
/*     */     public void checkClientTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) {}
/*     */     
/*     */     public void checkServerTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) {}
/*     */     
/* 592 */     public X509Certificate[] getAcceptedIssuers() { return null; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SSLContext getContext() {
/* 603 */     if (context == null) {
/*     */       try {
/* 605 */         context = SSLContext.getInstance("SSL");
/*     */       }
/* 607 */       catch (Exception exception) {
/* 608 */         if (verbose) {
/* 609 */           System.out.println("JSSEAdapter failure in getInstance.");
/* 610 */           exception.printStackTrace();
/*     */         } 
/* 612 */         throw new IllegalArgumentException("JSSEAdapter failed to obtain SSLContext.");
/*     */       } 
/*     */     }
/* 615 */     return context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*     */     try {
/* 628 */       JSSEAdapter jSSEAdapter = new JSSEAdapter();
/* 629 */       jSSEAdapter.setVerbose(true);
/*     */       
/* 631 */       System.out.println("-----------------------------\nraw adapter:\n" + jSSEAdapter);
/*     */       
/* 633 */       jSSEAdapter.disableProxy();
/* 634 */       System.out.println("-----------------------------\nProxy Disabled:\n" + jSSEAdapter);
/*     */       
/*     */       try {
/* 637 */         jSSEAdapter.setStrictChecking(true);
/* 638 */         System.out.println("** success -- setStrictChecking true");
/* 639 */       } catch (Exception exception) {
/* 640 */         System.out.println("Caught exception when setStrictChecking true: " + exception);
/*     */       } 
/*     */       
/*     */       try {
/* 644 */         System.out.println("** success -- Got socket: " + jSSEAdapter.createSocket("127.0.0.1", 7002));
/* 645 */       } catch (IOException iOException) {
/* 646 */         System.out.println("Caught exception when creating socket: " + iOException);
/*     */       } 
/*     */       
/*     */       try {
/* 650 */         jSSEAdapter.setProxyAuth("pete", "password");
/* 651 */         System.out.println("** failure -- set proxy auth when proxy should be disabled");
/* 652 */       } catch (IllegalStateException illegalStateException) {
/* 653 */         System.out.println("** success -- cauth IllegalStateException trying to set proxy when proxy disabled");
/*     */       } 
/*     */       
/* 656 */       jSSEAdapter.enableProxy("127.0.0.1", "3128");
/* 657 */       System.out.println("-----------------------------\nProxy Enabled:\n" + jSSEAdapter);
/*     */       
/*     */       try {
/* 660 */         Socket socket = jSSEAdapter.createSocket("127.0.0.1", 7002);
/*     */         
/* 662 */         System.out.println("** success -- Got socket: " + socket);
/*     */       
/*     */       }
/* 665 */       catch (IOException iOException) {
/* 666 */         System.out.println("Caught exception when creating socket: " + iOException);
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/* 671 */         jSSEAdapter.setProxyAuth("pete", null);
/* 672 */         System.out.println("** failure -- set proxy auth when proxy should be disabled");
/* 673 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 674 */         System.out.println("** success -- cauth IllegalArgumentException trying to set password to null");
/*     */       } 
/*     */       
/*     */       try {
/* 678 */         jSSEAdapter.setProxyAuth(null, "pete");
/* 679 */         System.out.println("** failure -- set proxy auth when proxy should be disabled");
/* 680 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 681 */         System.out.println("** success -- cauth IllegalArgumentException trying to set user to null");
/*     */       } 
/*     */       
/* 684 */       jSSEAdapter.disableProxy();
/*     */       try {
/* 686 */         System.out.println("** success -- Got socket: " + jSSEAdapter.createSocket("127.0.0.1", 7002));
/* 687 */       } catch (IOException iOException) {
/* 688 */         System.out.println("Caught exception when creating socket: " + iOException);
/*     */       }
/*     */     
/* 691 */     } catch (Throwable throwable) {
/* 692 */       System.out.println("Caught exception:" + throwable.getMessage());
/* 693 */       throwable.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\JSSEAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */