package weblogic.webservice.client;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public class JSSEAdapter implements SSLAdapter {
  public static final String STRICT_CHECKING_DEFAULT = "weblogic.webservice.client.ssl.strictcertchecking";
  
  public static final String VERBOSE_PROPERTY = "weblogic.webservice.client.verbose";
  
  public static final String TRUSTED_CERTS = "weblogic.webservice.client.ssl.trustedcertfile";
  
  public static final String ENFORCE_CONSTRAINTS = "weblogic.security.SSL.enforceConstraints";
  
  private static final String HTTPS_PROXY_HOST = "weblogic.webservice.transport.https.proxy.host";
  
  private static final String HTTPS_PROXY_PORT = "weblogic.webservice.transport.https.proxy.port";
  
  private static final String DEFAULT_HTTPS_PROXY_HOST = "https.proxyHost";
  
  private static final String DEFAULT_HTTPS_PROXY_PORT = "https.proxyPort";
  
  private SSLSocketFactory _factory;
  
  SSLSocketFactory factory;
  
  private static String proxyHost = getStringProp("weblogic.webservice.transport.https.proxy.host", null);
  
  private static String proxyPort = getStringProp("weblogic.webservice.transport.https.proxy.port", null);
  
  private static final TrustManager trustingManager = new NullTrustManager(null);
  
  private static TrustManager strictManager = null;
  
  private static KeyManager localKeyManager = null;
  
  private static SSLContext context = null;
  
  private static final HostnameVerifier nonverifier = new NullVerifier(null);
  
  private HostnameVerifier verifier;
  
  protected static boolean verbose = false;
  
  private static boolean strictCheckingDefault = true;
  
  protected boolean strictCertChecking;
  
  protected static String trustedCertFile = null;
  
  private String[] enabledCiphers;
  
  private InputStream myKeystream;
  
  private char[] myPassword;
  
  boolean proxyEnabled;
  
  private static String defaultProxyHost = null;
  
  private static int defaultProxyPort = 8080;
  
  private static String getStringProp(String paramString1, String paramString2) {
    try {
      return System.getProperty(paramString1);
    } catch (SecurityException securityException) {
      return paramString2;
    } 
  }
  
  private static boolean getBooleanProp(String paramString, boolean paramBoolean) {
    try {
      return Boolean.getBoolean(paramString);
    } catch (SecurityException securityException) {
      return paramBoolean;
    } 
  }
  
  static  {
    try {
      verbose = getBooleanProp("weblogic.webservice.client.verbose", false);
      if (verbose)
        System.out.println("JSSEAdapter verbose output enabled"); 
      if (!getBooleanProp("weblogic.webservice.client.ssl.strictcertchecking", true)) {
        strictCheckingDefault = false;
        if (verbose)
          System.out.println("JSSEAdapter strict cert checking disabled by default"); 
      } 
      trustedCertFile = getStringProp("weblogic.webservice.client.ssl.trustedcertfile", null);
      if (trustedCertFile != null && verbose)
        System.out.println("JSSEAdapter trusted certificates will be loaded from " + trustedCertFile); 
      defaultProxyHost = getStringProp("weblogic.webservice.transport.https.proxy.host", null);
      String str = getStringProp("weblogic.webservice.transport.https.proxy.port", null);
      if (str != null)
        defaultProxyPort = Integer.parseInt(str); 
      context = SSLContext.getInstance("SSL");
      TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance("SunX509", "SunJSSE");
      trustManagerFactory.init((KeyStore)null);
      strictManager = trustManagerFactory.getTrustManagers()[0];
    } catch (Throwable throwable) {
      if (verbose) {
        System.out.println("JSSEAdapter error: " + throwable.getMessage());
        throwable.printStackTrace();
      } 
    } 
  }
  
  public JSSEAdapter() {
    this._factory = null;
    this.factory = this._factory;
    this.verifier = null;
    this.strictCertChecking = true;
    this.enabledCiphers = null;
    this.myKeystream = null;
    this.myPassword = null;
    this.proxyEnabled = false;
    setStrictChecking(getStrictCheckingDefault());
    if (proxyHost != null && proxyPort != null)
      enableProxy(proxyHost, proxyPort); 
  }
  
  public JSSEAdapter(boolean paramBoolean) {
    this._factory = null;
    this.factory = this._factory;
    this.verifier = null;
    this.strictCertChecking = true;
    this.enabledCiphers = null;
    this.myKeystream = null;
    this.myPassword = null;
    this.proxyEnabled = false;
    setStrictChecking(paramBoolean);
    if (proxyHost != null && proxyPort != null)
      enableProxy(proxyHost, proxyPort); 
  }
  
  public void enableProxy(String paramString1, String paramString2) {
    this.factory = new SSLTunnelSocketFactory(this._factory, paramString1, paramString2);
    this.proxyEnabled = true;
  }
  
  public void disableProxy() {
    this.factory = this._factory;
    this.proxyEnabled = false;
  }
  
  public Socket createSocket(String paramString, int paramInt) throws IOException {
    SSLSocket sSLSocket = null;
    try {
      if (proxyHost != null) {
        sSLSocket = (SSLSocket)createProxySocket(paramString, paramInt);
      } else {
        sSLSocket = (SSLSocket)getSocketFactory().createSocket(paramString, paramInt);
      } 
      if (this.enabledCiphers != null)
        sSLSocket.setEnabledCipherSuites(this.enabledCiphers); 
      if (verbose)
        System.out.println("JSSEAdapter connecting to:" + paramString + " port:" + paramInt + " socket:" + sSLSocket); 
    } catch (ClassCastException classCastException) {
      throw new IOException("JSSEAdapter unable to create SSLSocket instance");
    } 
    return sSLSocket;
  }
  
  public Socket createProxySocket(String paramString, int paramInt) throws IOException {
    Socket socket = SSLUtil.doTunnelHandshake(proxyHost, Integer.valueOf(proxyPort).intValue(), paramString, paramInt);
    return this.factory.createSocket(socket, paramString, paramInt, false);
  }
  
  public URLConnection openConnection(URL paramURL) throws IOException {
    URLConnection uRLConnection = paramURL.openConnection();
    try {
      HttpsURLConnection httpsURLConnection = (HttpsURLConnection)uRLConnection;
      httpsURLConnection.setSSLSocketFactory(this.factory);
    } catch (ClassCastException classCastException) {
    
    } catch (Throwable throwable) {
      System.out.println("JSSEAdapter exception: " + throwable.getMessage());
    } 
    return uRLConnection;
  }
  
  public static void setStrictCheckingDefault(boolean paramBoolean) {
    if (verbose)
      System.out.println("JSSEAdapter set default cert checking to: " + (paramBoolean ? "STRICT." : "ACCEPTING.")); 
    strictCheckingDefault = paramBoolean;
  }
  
  protected final boolean getStrictCheckingDefault() { return strictCheckingDefault; }
  
  public final void setStrictChecking(boolean paramBoolean) {
    if (adapterUsed())
      throw new IllegalArgumentException("JSSEAdapter cannot change certificate checking once the adapter has been used."); 
    _setStrictChecking(paramBoolean);
    if (paramBoolean) {
      setHostnameVerifier(this.verifier);
    } else {
      setHostnameVerifier(nonverifier);
    } 
  }
  
  public final void setHostnameVerifier(HostnameVerifier paramHostnameVerifier) {
    this.verifier = paramHostnameVerifier;
    if (paramHostnameVerifier != null) {
      HttpsURLConnection.setDefaultHostnameVerifier(paramHostnameVerifier);
    } else if (verbose) {
      System.out.println("JSSEAdapter using the default JSSE HostnameVerifier.");
    } 
  }
  
  public void setVerbose(boolean paramBoolean) { this;
    verbose = paramBoolean; }
  
  public final void setTrustManager(TrustManager paramTrustManager) {
    if (adapterUsed())
      throw new IllegalArgumentException("JSSEAdapter cannot change trust manager once the adapter has been used"); 
    try {
      X509TrustManager[] arrayOfX509TrustManager = { (X509TrustManager)paramTrustManager };
      if (this.myKeystream != null) {
        File file = File.createTempFile("wsjsse", ".fix");
        file.deleteOnExit();
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        KeyStore keyStore = KeyStore.getInstance("JKS");
        keyStore.load(this.myKeystream, this.myPassword);
        keyStore.store(fileOutputStream, this.myPassword);
        fileOutputStream.close();
        System.setProperty("javax.net.ssl.keyStore", file.getAbsolutePath());
        System.setProperty("javax.net.ssl.keyStorePassword", new String(this.myPassword));
        if (verbose)
          System.out.println("JSSEAdapter setting KeyManager to: " + file.getName()); 
      } else {
        context.init(null, arrayOfX509TrustManager, new SecureRandom());
        if (verbose)
          System.out.println("JSSEAdapter KeyManager null"); 
      } 
    } catch (Exception exception) {
      if (verbose) {
        System.out.println("JSSEAdapter failure in getInstance.");
        exception.printStackTrace();
      } 
      throw new IllegalArgumentException("JSSEAdapter failed to obtain SSLContext.");
    } 
    if (verbose)
      System.out.println("JSSEAdapter setTrustManager to " + paramTrustManager); 
  }
  
  public final void loadLocalIdentity(InputStream paramInputStream, char[] paramArrayOfChar) throws Exception {
    if (adapterUsed())
      throw new IllegalArgumentException("JSSEAdapter cannot load identities once the adapter has been used."); 
    this.myKeystream = paramInputStream;
    this.myPassword = paramArrayOfChar;
    if (verbose)
      System.out.println("JSSEAdapter Loaded local identity from keystore: " + paramInputStream); 
  }
  
  protected final void _setStrictChecking(boolean paramBoolean) {
    if (adapterUsed())
      throw new IllegalArgumentException("JSSEAdapter cannot change strict checking once the adapter has been used"); 
    if (paramBoolean) {
      if (verbose)
        System.out.println("JSSEAdapter enabling strict checking on adapter " + this); 
      setTrustManager(strictManager);
    } else {
      if (verbose)
        System.out.println("JSSEAdapter disabling strict checking on adapter " + this); 
      setTrustManager(trustingManager);
    } 
    this.strictCertChecking = paramBoolean;
  }
  
  private void resetFactory() { this._factory = null; }
  
  protected SSLSocketFactory getSocketFactory() {
    if (this.factory == null) {
      this.factory = (SSLSocketFactory)SSLSocketFactory.getDefault();
      if (verbose)
        System.out.println("JSSEAdaptger got new socketfactory: " + this.factory); 
    } 
    return this.factory;
  }
  
  public void setSocketFactory(SSLSocketFactory paramSSLSocketFactory) {
    this._factory = paramSSLSocketFactory;
    if (!this.proxyEnabled) {
      this.factory = paramSSLSocketFactory;
    } else {
      ((SSLTunnelSocketFactory)paramSSLSocketFactory).setDelegateFactory(paramSSLSocketFactory);
    } 
  }
  
  protected boolean adapterUsed() { return (this.factory != null); }
  
  public void setProxy(String paramString, int paramInt) {
    if (paramString == null)
      throw new IllegalArgumentException("Must provide a proxy hostname"); 
    this;
    proxyHost = paramString;
    this;
    proxyPort = Integer.toString(paramInt);
  }
  
  public void setProxyAuth(String paramString1, String paramString2) {
    if (!this.proxyEnabled)
      throw new IllegalStateException("Cannot set proxy username/password until proxy has been enabled."); 
    if (paramString1 == null || paramString2 == null)
      throw new IllegalArgumentException("Cannot set username or password to null"); 
    ((SSLTunnelSocketFactory)this.factory).setProxyAuth(paramString1, paramString2);
  }
  
  public String toString() { return "<JSSEAdapter name=\"" + super.toString() + "\" proxyEnabled=" + this.proxyEnabled + " proxyHost=" + proxyHost + " proxyPort=" + proxyPort + ">\n" + this.factory + "\n</JSSEAdapter>"; }
  
  private static class NullVerifier implements HostnameVerifier {
    private NullVerifier() {}
    
    public boolean verify(String param1String, SSLSession param1SSLSession) {
      if (!param1String.equals(param1SSLSession.getPeerHost())) {
        if (JSSEAdapter.verbose)
          System.out.println("JSSEAdapter certificate <" + param1SSLSession.getPeerHost() + "> does not match host <" + param1String + "> however continuing anyway."); 
      } else if (JSSEAdapter.verbose) {
        System.out.println("JSSEAdapter HostnameVerifier success URL: " + param1String);
      } 
      return true;
    }
  }
  
  private static class NullTrustManager implements X509TrustManager {
    private NullTrustManager() {}
    
    public void checkClientTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) {}
    
    public void checkServerTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) {}
    
    public X509Certificate[] getAcceptedIssuers() { return null; }
  }
  
  protected final SSLContext getContext() {
    if (context == null)
      try {
        context = SSLContext.getInstance("SSL");
      } catch (Exception exception) {
        if (verbose) {
          System.out.println("JSSEAdapter failure in getInstance.");
          exception.printStackTrace();
        } 
        throw new IllegalArgumentException("JSSEAdapter failed to obtain SSLContext.");
      }  
    return context;
  }
  
  public static void main(String[] paramArrayOfString) {
    try {
      JSSEAdapter jSSEAdapter = new JSSEAdapter();
      jSSEAdapter.setVerbose(true);
      System.out.println("-----------------------------\nraw adapter:\n" + jSSEAdapter);
      jSSEAdapter.disableProxy();
      System.out.println("-----------------------------\nProxy Disabled:\n" + jSSEAdapter);
      try {
        jSSEAdapter.setStrictChecking(true);
        System.out.println("** success -- setStrictChecking true");
      } catch (Exception exception) {
        System.out.println("Caught exception when setStrictChecking true: " + exception);
      } 
      try {
        System.out.println("** success -- Got socket: " + jSSEAdapter.createSocket("127.0.0.1", 7002));
      } catch (IOException iOException) {
        System.out.println("Caught exception when creating socket: " + iOException);
      } 
      try {
        jSSEAdapter.setProxyAuth("pete", "password");
        System.out.println("** failure -- set proxy auth when proxy should be disabled");
      } catch (IllegalStateException illegalStateException) {
        System.out.println("** success -- cauth IllegalStateException trying to set proxy when proxy disabled");
      } 
      jSSEAdapter.enableProxy("127.0.0.1", "3128");
      System.out.println("-----------------------------\nProxy Enabled:\n" + jSSEAdapter);
      try {
        Socket socket = jSSEAdapter.createSocket("127.0.0.1", 7002);
        System.out.println("** success -- Got socket: " + socket);
      } catch (IOException iOException) {
        System.out.println("Caught exception when creating socket: " + iOException);
      } 
      try {
        jSSEAdapter.setProxyAuth("pete", null);
        System.out.println("** failure -- set proxy auth when proxy should be disabled");
      } catch (IllegalArgumentException illegalArgumentException) {
        System.out.println("** success -- cauth IllegalArgumentException trying to set password to null");
      } 
      try {
        jSSEAdapter.setProxyAuth(null, "pete");
        System.out.println("** failure -- set proxy auth when proxy should be disabled");
      } catch (IllegalArgumentException illegalArgumentException) {
        System.out.println("** success -- cauth IllegalArgumentException trying to set user to null");
      } 
      jSSEAdapter.disableProxy();
      try {
        System.out.println("** success -- Got socket: " + jSSEAdapter.createSocket("127.0.0.1", 7002));
      } catch (IOException iOException) {
        System.out.println("Caught exception when creating socket: " + iOException);
      } 
    } catch (Throwable throwable) {
      System.out.println("Caught exception:" + throwable.getMessage());
      throwable.printStackTrace();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\JSSEAdapter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */