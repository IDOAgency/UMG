package weblogic.webservice.client;

import javax.security.cert.X509Certificate;

public interface TrustManager {
  public static final int ERR_NONE = 0;
  
  public static final int ERR_CERT_CHAIN_INVALID = 1;
  
  public static final int ERR_CERT_EXPIRED = 2;
  
  public static final int ERR_CERT_CHAIN_INCOMPLETE = 4;
  
  public static final int ERR_SIGNATURE_INVALID = 8;
  
  public static final int ERR_CERT_CHAIN_UNTRUSTED = 16;
  
  boolean certificateCallback(X509Certificate[] paramArrayOfX509Certificate, int paramInt, Object paramObject);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\TrustManager.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */