package weblogic.webservice.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import sun.net.www.protocol.http.HttpURLConnection;
import weblogic.utils.encoders.BASE64Encoder;

public class SSLTunnelSocketFactory extends SSLSocketFactory {
  private SSLSocketFactory dfactory;
  
  private String tunnelHost;
  
  private int tunnelPort;
  
  private String proxyUser;
  
  private String proxyPassword;
  
  public SSLTunnelSocketFactory(SSLSocketFactory paramSSLSocketFactory, String paramString1, String paramString2) {
    this.proxyUser = null;
    this.proxyPassword = null;
    this.tunnelHost = paramString1;
    this.tunnelPort = Integer.parseInt(paramString2);
    this.dfactory = paramSSLSocketFactory;
  }
  
  public Socket createSocket(String paramString, int paramInt) throws IOException, UnknownHostException { return createSocket(null, paramString, paramInt, true); }
  
  public Socket createSocket(String paramString, int paramInt1, InetAddress paramInetAddress, int paramInt2) throws IOException, UnknownHostException { return createSocket(null, paramString, paramInt1, true); }
  
  public Socket createSocket(InetAddress paramInetAddress, int paramInt) throws IOException { return createSocket(null, paramInetAddress.getHostName(), paramInt, true); }
  
  public Socket createSocket(InetAddress paramInetAddress1, int paramInt1, InetAddress paramInetAddress2, int paramInt2) throws IOException { return createSocket(null, paramInetAddress1.getHostName(), paramInt1, true); }
  
  public Socket createSocket(Socket paramSocket, String paramString, int paramInt, boolean paramBoolean) throws IOException, UnknownHostException {
    Socket socket = new Socket(this.tunnelHost, this.tunnelPort);
    doTunnelHandshake(socket, paramString, paramInt);
    SSLSocket sSLSocket = (SSLSocket)this.dfactory.createSocket(socket, paramString, paramInt, paramBoolean);
    sSLSocket.startHandshake();
    return sSLSocket;
  }
  
  public void setDelegateFactory(SSLSocketFactory paramSSLSocketFactory) { this.dfactory = paramSSLSocketFactory; }
  
  public void setProxyAuth(String paramString1, String paramString2) {
    this.proxyUser = paramString1;
    this.proxyPassword = paramString2;
  }
  
  private void doTunnelHandshake(Socket paramSocket, String paramString, int paramInt) throws IOException {
    String str3;
    byte[] arrayOfByte1;
    OutputStream outputStream = paramSocket.getOutputStream();
    String str1 = "";
    if (this.proxyUser != null)
      str1 = "Proxy-Authorization: Basic " + (new BASE64Encoder()).encodeBuffer((this.proxyUser + ":" + this.proxyPassword).getBytes()) + "\r\n"; 
    String str2 = "CONNECT " + paramString + ":" + paramInt + " HTTP/1.0\n" + str1 + "User-Agent: " + HttpURLConnection.userAgent + "\r\n\r\n";
    try {
      arrayOfByte1 = str2.getBytes("ASCII7");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      arrayOfByte1 = str2.getBytes();
    } 
    outputStream.write(arrayOfByte1);
    outputStream.flush();
    byte[] arrayOfByte2 = new byte[200];
    byte b1 = 0;
    byte b2 = 0;
    boolean bool = false;
    InputStream inputStream = paramSocket.getInputStream();
    while (b2 < 2) {
      int i = inputStream.read();
      if (i < 0)
        throw new IOException("Unexpected EOF from proxy"); 
      if (i == 10) {
        bool = true;
        b2++;
        continue;
      } 
      if (i != 13) {
        b2 = 0;
        if (!bool && b1 < arrayOfByte2.length)
          arrayOfByte2[b1++] = (byte)i; 
      } 
    } 
    try {
      str3 = new String(arrayOfByte2, 0, b1, "ASCII7");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      str3 = new String(arrayOfByte2, 0, b1);
    } 
    if (str3.toLowerCase().indexOf(" 200 ") == -1)
      throw new IOException("Unable to tunnel through " + this.tunnelHost + ":" + this.tunnelPort + ".  Proxy returns \"" + str3 + "\""); 
  }
  
  public String[] getDefaultCipherSuites() { return this.dfactory.getDefaultCipherSuites(); }
  
  public String[] getSupportedCipherSuites() { return this.dfactory.getSupportedCipherSuites(); }
  
  public String toString() { return "  <SSLTunnelSocketFactory proxyPort=" + this.tunnelPort + " proxyHost=" + this.tunnelHost + " delegate=" + this.dfactory + "/>"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\SSLTunnelSocketFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */