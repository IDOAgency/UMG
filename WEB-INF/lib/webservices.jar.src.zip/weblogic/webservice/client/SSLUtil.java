package weblogic.webservice.client;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.Socket;
import weblogic.common.ProxyAuthenticator;
import weblogic.utils.StringUtils;
import weblogic.utils.encoders.BASE64Encoder;

public class SSLUtil {
  private static final int MAX_TRIES = 3;
  
  private static String proxyAuthStr = null;
  
  private static boolean debug = Boolean.getBoolean("weblogic.webservice.client.verbose");
  
  protected static Socket doTunnelHandshake(String paramString1, int paramInt1, String paramString2, int paramInt2) throws IOException {
    if (paramInt2 < 0)
      paramInt2 = 443; 
    Socket socket = null;
    if (proxyAuthStr == null)
      try {
        proxyAuthStr = getAuthInfo(paramString1, paramInt1, "Basic");
        proxyAuthStr = "Proxy-Authorization: " + proxyAuthStr;
        if (debug)
          System.out.println("SSLSocket: proxyAuthStr = " + proxyAuthStr); 
      } catch (IOException iOException) {} 
    byte b = 0;
    if (debug)
      System.out.println("Tunneling SSL via proxy: " + paramString1 + ":" + paramInt1); 
    while (true) {
      socket = new Socket(paramString1, paramInt1);
      String str1 = null;
      if (proxyAuthStr == null) {
        str1 = "CONNECT " + paramString2 + ":" + paramInt2 + " HTTP/1.0\r\n\r\n";
      } else {
        str1 = "CONNECT " + paramString2 + ":" + paramInt2 + " HTTP/1.0\r\n" + proxyAuthStr + "\r\n\r\n";
      } 
      if (debug)
        System.out.println("SSLSocket::" + str1); 
      socket.getOutputStream().write(str1.getBytes());
      DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
      String str2 = dataInputStream.readLine();
      if (str2 == null) {
        socket.close();
        throw new IOException("No data when attempting to read from Proxy Server, more than likely the Proxy Server closed the socket.  Check Proxy Server error log.");
      } 
      if (debug)
        System.out.println("First line: " + str2); 
      String[] arrayOfString = StringUtils.splitCompletely(str2);
      if (arrayOfString.length >= 2) {
        if (!arrayOfString[0].equals("HTTP/1.0") && !arrayOfString[0].equals("HTTP/1.1")) {
          socket.close();
          throw new ProtocolException("unrecognized response from SSL proxy: '" + str2 + "'");
        } 
        if (arrayOfString[1].equals("200")) {
          while ((str2 = dataInputStream.readLine()) != null && str2.length() > 0);
          if (debug)
            System.out.println("success"); 
          break;
        } 
        if (arrayOfString[1].equals("407")) {
          if (b > 3)
            throw new ProtocolException("Server redirected too many times (" + b + ")"); 
          while ((str2 = dataInputStream.readLine()) != null && str2.length() > 0) {
            String[] arrayOfString1 = StringUtils.split(str2, ':');
            if (arrayOfString1[0].equalsIgnoreCase("Proxy-Authenticate")) {
              if (debug)
                System.out.println(arrayOfString1[0] + ": " + arrayOfString1[1]); 
              proxyAuthStr = getAuthInfo(paramString1, paramInt1, arrayOfString1[1]);
              if (proxyAuthStr == null)
                throw new IOException("Proxy Authentication required (407)"); 
              proxyAuthStr = "Proxy-Authorization: " + proxyAuthStr;
              if (debug)
                System.out.println(proxyAuthStr); 
            } 
          } 
          b++;
          continue;
        } 
      } else {
        socket.close();
        throw new ProtocolException("unrecognized response from SSL proxy: '" + str2 + "'");
      } 
      throw new ProtocolException("unrecognized response from SSL proxy: '" + str2 + "'");
    } 
    return socket;
  }
  
  public static String getAuthInfo(String paramString1, int paramInt, String paramString2) throws IOException {
    String str1 = System.getProperty("weblogic.net.proxyAuthenticatorClassName");
    if (debug)
      System.out.println("\ngetAuthInfo(" + paramString1 + ", " + paramInt + ", " + paramString2 + ") called"); 
    if (str1 == null || paramString2 == null)
      throw new IOException("Proxy or Server Authentication Required"); 
    if (debug)
      System.out.println(" using ProxyAuthenticator = " + str1); 
    ProxyAuthenticator proxyAuthenticator = null;
    String str2 = null;
    String str3 = null;
    String str4 = paramString2.trim();
    int i = str4.indexOf(' ');
    if (i == -1) {
      str2 = str4;
      str3 = "Login to Proxy";
    } else {
      str2 = str4.substring(0, i);
      str3 = str4.substring(i + 1);
      i = str3.indexOf('=');
      if (i != -1)
        str3 = str3.substring(i + 1); 
    } 
    try {
      proxyAuthenticator = (ProxyAuthenticator)Class.forName(str1).newInstance();
    } catch (Exception exception) {
      throw new IOException("Proxy authenticator " + str1 + " failed: " + exception);
    } 
    proxyAuthenticator.init(paramString1, paramInt, str2, str3);
    String[] arrayOfString = proxyAuthenticator.getLoginAndPassword();
    if (arrayOfString == null || arrayOfString.length != 2)
      throw new IOException("Proxy authentication failed"); 
    String str5 = arrayOfString[0] + ':' + arrayOfString[1];
    byte[] arrayOfByte = str5.getBytes();
    BASE64Encoder bASE64Encoder = new BASE64Encoder();
    String str6 = "Basic " + bASE64Encoder.encodeBuffer(arrayOfByte);
    if (debug)
      System.out.println(" getAuthString() returning '" + str6 + "'"); 
    return str6;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\SSLUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */