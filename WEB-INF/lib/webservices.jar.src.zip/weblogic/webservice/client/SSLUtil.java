/*     */ package weblogic.webservice.client;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.Socket;
/*     */ import weblogic.common.ProxyAuthenticator;
/*     */ import weblogic.utils.StringUtils;
/*     */ import weblogic.utils.encoders.BASE64Encoder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SSLUtil
/*     */ {
/*     */   private static final int MAX_TRIES = 3;
/*  32 */   private static String proxyAuthStr = null;
/*  33 */   private static boolean debug = Boolean.getBoolean("weblogic.webservice.client.verbose");
/*     */   
/*     */   protected static Socket doTunnelHandshake(String paramString1, int paramInt1, String paramString2, int paramInt2) throws IOException {
/*  36 */     if (paramInt2 < 0) paramInt2 = 443; 
/*  37 */     Socket socket = null;
/*     */ 
/*     */ 
/*     */     
/*  41 */     if (proxyAuthStr == null) {
/*     */       try {
/*  43 */         proxyAuthStr = getAuthInfo(paramString1, paramInt1, "Basic");
/*     */         
/*  45 */         proxyAuthStr = "Proxy-Authorization: " + proxyAuthStr;
/*  46 */         if (debug)
/*  47 */           System.out.println("SSLSocket: proxyAuthStr = " + proxyAuthStr); 
/*  48 */       } catch (IOException iOException) {}
/*     */     }
/*  50 */     byte b = 0;
/*     */ 
/*     */     
/*  53 */     if (debug) {
/*  54 */       System.out.println("Tunneling SSL via proxy: " + paramString1 + ":" + paramInt1);
/*     */     }
/*     */     
/*     */     while (true) {
/*  58 */       socket = new Socket(paramString1, paramInt1);
/*  59 */       String str1 = null;
/*  60 */       if (proxyAuthStr == null) {
/*  61 */         str1 = "CONNECT " + paramString2 + ":" + paramInt2 + " HTTP/1.0\r\n\r\n";
/*     */       } else {
/*  63 */         str1 = "CONNECT " + paramString2 + ":" + paramInt2 + " HTTP/1.0\r\n" + proxyAuthStr + "\r\n\r\n";
/*     */       } 
/*     */       
/*  66 */       if (debug) System.out.println("SSLSocket::" + str1); 
/*  67 */       socket.getOutputStream().write(str1.getBytes());
/*  68 */       DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
/*  69 */       String str2 = dataInputStream.readLine();
/*  70 */       if (str2 == null) {
/*     */ 
/*     */ 
/*     */         
/*  74 */         socket.close();
/*  75 */         throw new IOException("No data when attempting to read from Proxy Server, more than likely the Proxy Server closed the socket.  Check Proxy Server error log.");
/*     */       } 
/*     */ 
/*     */       
/*  79 */       if (debug)
/*  80 */         System.out.println("First line: " + str2); 
/*  81 */       String[] arrayOfString = StringUtils.splitCompletely(str2);
/*  82 */       if (arrayOfString.length >= 2) {
/*  83 */         if (!arrayOfString[0].equals("HTTP/1.0") && !arrayOfString[0].equals("HTTP/1.1")) {
/*     */           
/*  85 */           socket.close();
/*  86 */           throw new ProtocolException("unrecognized response from SSL proxy: '" + str2 + "'");
/*     */         } 
/*     */         
/*  89 */         if (arrayOfString[1].equals("200")) {
/*     */ 
/*     */           
/*  92 */           while ((str2 = dataInputStream.readLine()) != null && str2.length() > 0);
/*  93 */           if (debug) System.out.println("success");  break;
/*     */         } 
/*  95 */         if (arrayOfString[1].equals("407")) {
/*  96 */           if (b > 3) {
/*  97 */             throw new ProtocolException("Server redirected too many times (" + b + ")");
/*     */           }
/*     */           
/* 100 */           while ((str2 = dataInputStream.readLine()) != null && str2.length() > 0) {
/* 101 */             String[] arrayOfString1 = StringUtils.split(str2, ':');
/* 102 */             if (arrayOfString1[0].equalsIgnoreCase("Proxy-Authenticate")) {
/* 103 */               if (debug) System.out.println(arrayOfString1[0] + ": " + arrayOfString1[1]); 
/* 104 */               proxyAuthStr = getAuthInfo(paramString1, paramInt1, arrayOfString1[1]);
/*     */               
/* 106 */               if (proxyAuthStr == null)
/* 107 */                 throw new IOException("Proxy Authentication required (407)"); 
/* 108 */               proxyAuthStr = "Proxy-Authorization: " + proxyAuthStr;
/* 109 */               if (debug) System.out.println(proxyAuthStr);
/*     */             
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 116 */           b++;
/*     */           continue;
/*     */         } 
/*     */       } else {
/* 120 */         socket.close();
/* 121 */         throw new ProtocolException("unrecognized response from SSL proxy: '" + str2 + "'");
/*     */       } 
/* 123 */       throw new ProtocolException("unrecognized response from SSL proxy: '" + str2 + "'");
/*     */     } 
/* 125 */     return socket;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getAuthInfo(String paramString1, int paramInt, String paramString2) throws IOException {
/* 131 */     String str1 = System.getProperty("weblogic.net.proxyAuthenticatorClassName");
/*     */ 
/*     */     
/* 134 */     if (debug) {
/* 135 */       System.out.println("\ngetAuthInfo(" + paramString1 + ", " + paramInt + ", " + paramString2 + ") called");
/*     */     }
/*     */     
/* 138 */     if (str1 == null || paramString2 == null) {
/* 139 */       throw new IOException("Proxy or Server Authentication Required");
/*     */     }
/* 141 */     if (debug) {
/* 142 */       System.out.println(" using ProxyAuthenticator = " + str1);
/*     */     }
/* 144 */     ProxyAuthenticator proxyAuthenticator = null;
/*     */ 
/*     */     
/* 147 */     String str2 = null;
/* 148 */     String str3 = null;
/* 149 */     String str4 = paramString2.trim();
/* 150 */     int i = str4.indexOf(' ');
/* 151 */     if (i == -1) {
/* 152 */       str2 = str4;
/* 153 */       str3 = "Login to Proxy";
/*     */     } else {
/* 155 */       str2 = str4.substring(0, i);
/* 156 */       str3 = str4.substring(i + 1);
/* 157 */       i = str3.indexOf('=');
/* 158 */       if (i != -1) {
/* 159 */         str3 = str3.substring(i + 1);
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 164 */       proxyAuthenticator = (ProxyAuthenticator)Class.forName(str1).newInstance();
/*     */     }
/* 166 */     catch (Exception exception) {
/* 167 */       throw new IOException("Proxy authenticator " + str1 + " failed: " + exception);
/*     */     } 
/*     */     
/* 170 */     proxyAuthenticator.init(paramString1, paramInt, str2, str3);
/* 171 */     String[] arrayOfString = proxyAuthenticator.getLoginAndPassword();
/*     */     
/* 173 */     if (arrayOfString == null || arrayOfString.length != 2) {
/* 174 */       throw new IOException("Proxy authentication failed");
/*     */     }
/*     */     
/* 177 */     String str5 = arrayOfString[0] + ':' + arrayOfString[1];
/* 178 */     byte[] arrayOfByte = str5.getBytes();
/* 179 */     BASE64Encoder bASE64Encoder = new BASE64Encoder();
/* 180 */     String str6 = "Basic " + bASE64Encoder.encodeBuffer(arrayOfByte);
/* 181 */     if (debug)
/* 182 */       System.out.println(" getAuthString() returning '" + str6 + "'"); 
/* 183 */     return str6;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\client\SSLUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */