package weblogic.webservice;

import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;

public interface HandlerChain {
  void init(HandlerInfo[] paramArrayOfHandlerInfo);
  
  boolean handleRequest(MessageContext paramMessageContext);
  
  boolean handleResponse(MessageContext paramMessageContext);
  
  void destroy();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\HandlerChain.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */