/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerConfigurationException;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.xml.sax.InputSource;
/*     */ import weblogic.utils.CharsetMap;
/*     */ import weblogic.utils.io.XMLDeclaration;
/*     */ import weblogic.xml.schema.binding.util.runtime.ByteList;
/*     */ import weblogic.xml.schema.binding.util.runtime.CharList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSourceCodec
/*     */   extends AttachmentCodec
/*     */ {
/*  50 */   protected String xmlEncoding = "UTF-8";
/*     */   
/*     */   protected Object deserializeContent(Object paramObject) {
/*  53 */     String str = (String)paramObject;
/*  54 */     return new StreamSource(new StringReader(str));
/*     */   }
/*     */ 
/*     */   
/*  58 */   protected String getContentType() { return "text/xml; charset=" + this.xmlEncoding; }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object serializeContent(Object paramObject) {
/*  63 */     if (!(paramObject instanceof SAXSource) && !(paramObject instanceof StreamSource) && !(paramObject instanceof javax.xml.transform.dom.DOMSource))
/*     */     {
/*     */       
/*  66 */       throw new JAXRPCException("unable to serialize[" + paramObject + "]. " + "input should be of type " + "javax.xml.transform.stream.StreamSource, " + "javax.xml.transform.sax.SAXSource, or " + "javax.xml.transform.dom.DOMSource");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     String str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     if (paramObject instanceof SAXSource) {
/*     */       
/*  80 */       InputSource inputSource = SAXSource.sourceToInputSource((SAXSource)paramObject);
/*  81 */       if (inputSource != null) {
/*  82 */         Reader reader = inputSource.getCharacterStream();
/*  83 */         if (reader != null) {
/*  84 */           getXMLEncoding(reader);
/*  85 */           str = getString(reader);
/*     */         } else {
/*  87 */           InputStream inputStream = inputSource.getByteStream();
/*  88 */           if (inputStream != null) {
/*  89 */             str = getString(inputStream);
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/*  94 */     } else if (paramObject instanceof StreamSource) {
/*     */       
/*  96 */       Reader reader = ((StreamSource)paramObject).getReader();
/*  97 */       if (reader != null) {
/*  98 */         getXMLEncoding(reader);
/*  99 */         str = getString(reader);
/*     */       } else {
/* 101 */         InputStream inputStream = ((StreamSource)paramObject).getInputStream();
/* 102 */         if (inputStream != null) {
/* 103 */           str = getString(inputStream);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (paramObject instanceof javax.xml.transform.dom.DOMSource || str == null) {
/*     */       
/* 113 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 114 */       Transformer transformer = null;
/*     */       
/*     */       try {
/* 117 */         transformer = TransformerFactory.newInstance().newTransformer();
/*     */       }
/* 119 */       catch (TransformerConfigurationException transformerConfigurationException) {
/* 120 */         throw new JAXRPCException(transformerConfigurationException);
/*     */       } 
/*     */       
/* 123 */       StreamResult streamResult = new StreamResult(byteArrayOutputStream);
/*     */       
/*     */       try {
/* 126 */         transformer.transform((Source)paramObject, streamResult);
/* 127 */       } catch (TransformerException transformerException) {
/* 128 */         throw new JAXRPCException("failed to transform:" + transformerException, transformerException);
/*     */       } 
/* 130 */       byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/* 131 */       byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
/*     */       try {
/* 133 */         str1 = getXMLEncoding(byteArrayInputStream);
/* 134 */         str = getString(arrayOfByte, str1);
/* 135 */       } catch (IOException iOException) {
/* 136 */         throw new JAXRPCException("failed to get xml encoding:" + iOException);
/*     */       } finally {
/*     */         try {
/* 139 */           byteArrayInputStream.close();
/* 140 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getXMLEncoding(InputStream paramInputStream) throws IOException {
/* 151 */     String str = null;
/* 152 */     if (paramInputStream.markSupported()) {
/* 153 */       paramInputStream.mark(4080);
/* 154 */       XMLDeclaration xMLDeclaration = new XMLDeclaration();
/* 155 */       xMLDeclaration.parse(paramInputStream);
/* 156 */       str = xMLDeclaration.getEncoding();
/* 157 */       paramInputStream.reset();
/*     */     } 
/* 159 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void getXMLEncoding(Reader paramReader) {
/* 165 */     String str = null;
/* 166 */     if (paramReader.markSupported()) {
/*     */       try {
/* 168 */         paramReader.mark(4080);
/* 169 */         XMLDeclaration xMLDeclaration = new XMLDeclaration();
/* 170 */         xMLDeclaration.parse(paramReader);
/* 171 */         str = xMLDeclaration.getEncoding();
/* 172 */         paramReader.reset();
/* 173 */       } catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (str != null) {
/* 179 */       this.xmlEncoding = str;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getString(Reader paramReader) throws JAXRPCException {
/* 186 */     CharList charList = new CharList();
/*     */     try {
/* 188 */       int i = paramReader.read();
/* 189 */       while (i != -1) {
/* 190 */         charList.add((char)i);
/* 191 */         i = paramReader.read();
/*     */       } 
/* 193 */     } catch (IOException iOException) {
/* 194 */       throw new JAXRPCException("failed to get xml from input stream:" + iOException);
/*     */     } 
/* 196 */     return new String(charList.getMinSizedArray());
/*     */   }
/*     */ 
/*     */   
/*     */   private String getString(InputStream paramInputStream) throws IOException {
/*     */     String str;
/* 202 */     ByteList byteList = new ByteList();
/*     */     
/*     */     try {
/* 205 */       str = getXMLEncoding(paramInputStream);
/* 206 */     } catch (IOException iOException) {
/* 207 */       throw new JAXRPCException("failed to get xml encoding:" + iOException);
/*     */     } 
/*     */     try {
/* 210 */       int i = paramInputStream.read();
/* 211 */       while (i != -1) {
/* 212 */         byteList.add((byte)i);
/* 213 */         i = paramInputStream.read();
/*     */       } 
/* 215 */     } catch (IOException iOException) {
/* 216 */       throw new JAXRPCException("failed to get xml from input stream:" + iOException);
/*     */     } 
/* 218 */     return getString(byteList.getMinSizedArray(), str);
/*     */   }
/*     */   
/*     */   private String getString(byte[] paramArrayOfByte, String paramString) {
/*     */     String str2;
/* 223 */     if (paramString != null) {
/* 224 */       this.xmlEncoding = paramString;
/*     */     }
/* 226 */     String str1 = CharsetMap.getJavaFromIANA(this.xmlEncoding);
/*     */ 
/*     */     
/*     */     try {
/* 230 */       if (str1 != null) {
/* 231 */         str2 = new String(paramArrayOfByte, str1);
/*     */       } else {
/* 233 */         str2 = new String(paramArrayOfByte, "UTF-8");
/*     */       } 
/* 235 */     } catch (IOException iOException) {
/* 236 */       throw new JAXRPCException("failed to get xml from bytes:" + iOException);
/*     */     } 
/* 238 */     return str2;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\XMLSourceCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */