package weblogic.webservice.encoding;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import javax.xml.rpc.JAXRPCException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.xml.sax.InputSource;
import weblogic.utils.CharsetMap;
import weblogic.utils.io.XMLDeclaration;
import weblogic.xml.schema.binding.util.runtime.ByteList;
import weblogic.xml.schema.binding.util.runtime.CharList;

public class XMLSourceCodec extends AttachmentCodec {
  protected String xmlEncoding = "UTF-8";
  
  protected Object deserializeContent(Object paramObject) {
    String str = (String)paramObject;
    return new StreamSource(new StringReader(str));
  }
  
  protected String getContentType() { return "text/xml; charset=" + this.xmlEncoding; }
  
  protected Object serializeContent(Object paramObject) {
    if (!(paramObject instanceof SAXSource) && !(paramObject instanceof StreamSource) && !(paramObject instanceof javax.xml.transform.dom.DOMSource))
      throw new JAXRPCException("unable to serialize[" + paramObject + "]. " + "input should be of type " + "javax.xml.transform.stream.StreamSource, " + "javax.xml.transform.sax.SAXSource, or " + "javax.xml.transform.dom.DOMSource"); 
    String str = null;
    if (paramObject instanceof SAXSource) {
      InputSource inputSource = SAXSource.sourceToInputSource((SAXSource)paramObject);
      if (inputSource != null) {
        Reader reader = inputSource.getCharacterStream();
        if (reader != null) {
          getXMLEncoding(reader);
          str = getString(reader);
        } else {
          InputStream inputStream = inputSource.getByteStream();
          if (inputStream != null)
            str = getString(inputStream); 
        } 
      } 
    } else if (paramObject instanceof StreamSource) {
      Reader reader = ((StreamSource)paramObject).getReader();
      if (reader != null) {
        getXMLEncoding(reader);
        str = getString(reader);
      } else {
        InputStream inputStream = ((StreamSource)paramObject).getInputStream();
        if (inputStream != null)
          str = getString(inputStream); 
      } 
    } 
    if (paramObject instanceof javax.xml.transform.dom.DOMSource || str == null) {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      Transformer transformer = null;
      try {
        transformer = TransformerFactory.newInstance().newTransformer();
      } catch (TransformerConfigurationException transformerConfigurationException) {
        throw new JAXRPCException(transformerConfigurationException);
      } 
      StreamResult streamResult = new StreamResult(byteArrayOutputStream);
      try {
        transformer.transform((Source)paramObject, streamResult);
      } catch (TransformerException transformerException) {
        throw new JAXRPCException("failed to transform:" + transformerException, transformerException);
      } 
      byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
      byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
      try {
        str1 = getXMLEncoding(byteArrayInputStream);
        str = getString(arrayOfByte, str1);
      } catch (IOException iOException) {
        throw new JAXRPCException("failed to get xml encoding:" + iOException);
      } finally {
        try {
          byteArrayInputStream.close();
        } catch (IOException iOException) {}
      } 
    } 
    return str;
  }
  
  private static String getXMLEncoding(InputStream paramInputStream) throws IOException {
    String str = null;
    if (paramInputStream.markSupported()) {
      paramInputStream.mark(4080);
      XMLDeclaration xMLDeclaration = new XMLDeclaration();
      xMLDeclaration.parse(paramInputStream);
      str = xMLDeclaration.getEncoding();
      paramInputStream.reset();
    } 
    return str;
  }
  
  private void getXMLEncoding(Reader paramReader) {
    String str = null;
    if (paramReader.markSupported())
      try {
        paramReader.mark(4080);
        XMLDeclaration xMLDeclaration = new XMLDeclaration();
        xMLDeclaration.parse(paramReader);
        str = xMLDeclaration.getEncoding();
        paramReader.reset();
      } catch (IOException iOException) {} 
    if (str != null)
      this.xmlEncoding = str; 
  }
  
  private String getString(Reader paramReader) throws JAXRPCException {
    CharList charList = new CharList();
    try {
      int i = paramReader.read();
      while (i != -1) {
        charList.add((char)i);
        i = paramReader.read();
      } 
    } catch (IOException iOException) {
      throw new JAXRPCException("failed to get xml from input stream:" + iOException);
    } 
    return new String(charList.getMinSizedArray());
  }
  
  private String getString(InputStream paramInputStream) throws IOException {
    String str;
    ByteList byteList = new ByteList();
    try {
      str = getXMLEncoding(paramInputStream);
    } catch (IOException iOException) {
      throw new JAXRPCException("failed to get xml encoding:" + iOException);
    } 
    try {
      int i = paramInputStream.read();
      while (i != -1) {
        byteList.add((byte)i);
        i = paramInputStream.read();
      } 
    } catch (IOException iOException) {
      throw new JAXRPCException("failed to get xml from input stream:" + iOException);
    } 
    return getString(byteList.getMinSizedArray(), str);
  }
  
  private String getString(byte[] paramArrayOfByte, String paramString) {
    String str2;
    if (paramString != null)
      this.xmlEncoding = paramString; 
    String str1 = CharsetMap.getJavaFromIANA(this.xmlEncoding);
    try {
      if (str1 != null) {
        str2 = new String(paramArrayOfByte, str1);
      } else {
        str2 = new String(paramArrayOfByte, "UTF-8");
      } 
    } catch (IOException iOException) {
      throw new JAXRPCException("failed to get xml from bytes:" + iOException);
    } 
    return str2;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\XMLSourceCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */