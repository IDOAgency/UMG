package weblogic.webservice.encoding;

import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.DeserializerFactory;
import javax.xml.rpc.encoding.SerializerFactory;
import weblogic.webservice.core.encoding.stream.SOAPElementCodec;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.ClassContext;
import weblogic.xml.schema.binding.SchemaContext;
import weblogic.xml.schema.binding.TypeMappingEntry;
import weblogic.xml.schema.binding.internal.TypeMappingBase;
import weblogic.xml.schema.binding.internal.XSDTypeMapping;
import weblogic.xml.schema.model.ExpName;
import weblogic.xml.stream.XMLName;

public class GenericTypeMapping extends TypeMappingBase {
  private SOAPElementCodec genericCodec = new SOAPElementCodec();
  
  private static final QName anyType = new QName("http://www.w3.org/2001/XMLSchema", "anyType");
  
  private static final ExpName anyTypeExp = new ExpName("http://www.w3.org/2001/XMLSchema", "anyType");
  
  public GenericTypeMapping() {
    try {
      setParent(XSDTypeMapping.createXSDMapping());
      register(javax.xml.soap.SOAPElement.class, anyType, this.genericCodec, this.genericCodec);
    } catch (BindingException bindingException) {
      throw new JAXRPCException("Failed to create binding", bindingException);
    } 
  }
  
  public boolean isRegistered(Class paramClass, QName paramQName) {
    if (javax.xml.soap.SOAPElement.class.isAssignableFrom(paramClass))
      return true; 
    return super.isRegistered(paramClass, paramQName);
  }
  
  public SerializerFactory getSerializer(Class paramClass, QName paramQName) {
    SOAPElementCodec sOAPElementCodec = super.getSerializer(paramClass, paramQName);
    if (sOAPElementCodec == null && javax.xml.soap.SOAPElement.class.equals(paramClass))
      sOAPElementCodec = this.genericCodec; 
    return sOAPElementCodec;
  }
  
  public TypeMappingEntry get(XMLName paramXMLName, SchemaContext paramSchemaContext) {
    TypeMappingEntry typeMappingEntry = super.get(paramXMLName, paramSchemaContext);
    if (typeMappingEntry == null) {
      paramSchemaContext.setJavaType(javax.xml.soap.SOAPElement.class.getName());
      typeMappingEntry = super.get(anyTypeExp, paramSchemaContext);
    } 
    return typeMappingEntry;
  }
  
  public Class getClassFromXMLName(XMLName paramXMLName) {
    Class clazz = super.getClassFromXMLName(paramXMLName);
    if (clazz == null)
      clazz = javax.xml.soap.SOAPElement.class; 
    return clazz;
  }
  
  public TypeMappingEntry get(Class paramClass, ClassContext paramClassContext) {
    TypeMappingEntry typeMappingEntry = super.get(paramClass, paramClassContext);
    if (typeMappingEntry == null) {
      paramClassContext.setSchemaType(anyTypeExp);
      typeMappingEntry = super.get(paramClass, paramClassContext);
    } 
    return typeMappingEntry;
  }
  
  public DeserializerFactory getDeserializer(Class paramClass, QName paramQName) {
    SOAPElementCodec sOAPElementCodec = super.getDeserializer(paramClass, paramQName);
    if (sOAPElementCodec == null && javax.xml.soap.SOAPElement.class.isAssignableFrom(paramClass))
      sOAPElementCodec = this.genericCodec; 
    return sOAPElementCodec;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\GenericTypeMapping.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */