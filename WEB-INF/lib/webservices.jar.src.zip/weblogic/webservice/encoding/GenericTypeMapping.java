/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.DeserializerFactory;
/*     */ import javax.xml.rpc.encoding.SerializerFactory;
/*     */ import weblogic.webservice.core.encoding.stream.SOAPElementCodec;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.ClassContext;
/*     */ import weblogic.xml.schema.binding.SchemaContext;
/*     */ import weblogic.xml.schema.binding.TypeMappingEntry;
/*     */ import weblogic.xml.schema.binding.internal.TypeMappingBase;
/*     */ import weblogic.xml.schema.binding.internal.XSDTypeMapping;
/*     */ import weblogic.xml.schema.model.ExpName;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericTypeMapping
/*     */   extends TypeMappingBase
/*     */ {
/*  39 */   private SOAPElementCodec genericCodec = new SOAPElementCodec();
/*     */   
/*  41 */   private static final QName anyType = new QName("http://www.w3.org/2001/XMLSchema", "anyType");
/*     */ 
/*     */   
/*  44 */   private static final ExpName anyTypeExp = new ExpName("http://www.w3.org/2001/XMLSchema", "anyType");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GenericTypeMapping() {
/*     */     try {
/*  52 */       setParent(XSDTypeMapping.createXSDMapping());
/*  53 */       register(javax.xml.soap.SOAPElement.class, anyType, this.genericCodec, this.genericCodec);
/*  54 */     } catch (BindingException bindingException) {
/*  55 */       throw new JAXRPCException("Failed to create binding", bindingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRegistered(Class paramClass, QName paramQName) {
/*  63 */     if (javax.xml.soap.SOAPElement.class.isAssignableFrom(paramClass)) {
/*  64 */       return true;
/*     */     }
/*  66 */     return super.isRegistered(paramClass, paramQName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializerFactory getSerializer(Class paramClass, QName paramQName) {
/*  76 */     SOAPElementCodec sOAPElementCodec = super.getSerializer(paramClass, paramQName);
/*     */ 
/*     */     
/*  79 */     if (sOAPElementCodec == null && javax.xml.soap.SOAPElement.class.equals(paramClass)) {
/*  80 */       sOAPElementCodec = this.genericCodec;
/*     */     }
/*     */     
/*  83 */     return sOAPElementCodec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMappingEntry get(XMLName paramXMLName, SchemaContext paramSchemaContext) {
/*  90 */     TypeMappingEntry typeMappingEntry = super.get(paramXMLName, paramSchemaContext);
/*     */     
/*  92 */     if (typeMappingEntry == null) {
/*  93 */       paramSchemaContext.setJavaType(javax.xml.soap.SOAPElement.class.getName());
/*  94 */       typeMappingEntry = super.get(anyTypeExp, paramSchemaContext);
/*     */     } 
/*     */     
/*  97 */     return typeMappingEntry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getClassFromXMLName(XMLName paramXMLName) {
/* 104 */     Class clazz = super.getClassFromXMLName(paramXMLName);
/*     */     
/* 106 */     if (clazz == null) {
/* 107 */       clazz = javax.xml.soap.SOAPElement.class;
/*     */     }
/*     */     
/* 110 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeMappingEntry get(Class paramClass, ClassContext paramClassContext) {
/* 117 */     TypeMappingEntry typeMappingEntry = super.get(paramClass, paramClassContext);
/*     */     
/* 119 */     if (typeMappingEntry == null) {
/* 120 */       paramClassContext.setSchemaType(anyTypeExp);
/* 121 */       typeMappingEntry = super.get(paramClass, paramClassContext);
/*     */     } 
/*     */     
/* 124 */     return typeMappingEntry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeserializerFactory getDeserializer(Class paramClass, QName paramQName) {
/* 133 */     SOAPElementCodec sOAPElementCodec = super.getDeserializer(paramClass, paramQName);
/*     */ 
/*     */     
/* 136 */     if (sOAPElementCodec == null && javax.xml.soap.SOAPElement.class.isAssignableFrom(paramClass))
/*     */     {
/*     */       
/* 139 */       sOAPElementCodec = this.genericCodec;
/*     */     }
/*     */     
/* 142 */     return sOAPElementCodec;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\GenericTypeMapping.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */