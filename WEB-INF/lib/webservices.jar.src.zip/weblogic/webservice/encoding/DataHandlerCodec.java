/*    */ package weblogic.webservice.encoding;
/*    */ 
/*    */ import javax.activation.DataHandler;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.soap.SOAPFaultException;
/*    */ import javax.xml.soap.AttachmentPart;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import javax.xml.soap.SOAPMessage;
/*    */ import weblogic.xml.schema.binding.DeserializationContext;
/*    */ import weblogic.xml.schema.binding.SerializationContext;
/*    */ import weblogic.xml.stream.XMLName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataHandlerCodec
/*    */   extends AttachmentCodec
/*    */ {
/* 29 */   protected String getContentType() { throw new Error("should not be called"); }
/*    */ 
/*    */ 
/*    */   
/* 33 */   protected Object serializeContent(Object paramObject) { throw new Error("should not be called"); }
/*    */ 
/*    */ 
/*    */   
/* 37 */   protected Object deserializeContent(Object paramObject) { throw new Error("should not be called"); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object deserialize(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) throws JAXRPCException {
/* 43 */     AttachmentPart attachmentPart = getAttachmentPart(paramXMLName, paramSOAPMessage, paramDeserializationContext);
/*    */ 
/*    */     
/* 46 */     if (attachmentPart == null) {
/* 47 */       return null;
/*    */     }
/*    */     
/*    */     try {
/* 51 */       return attachmentPart.getDataHandler();
/*    */     }
/* 53 */     catch (SOAPException sOAPException) {
/* 54 */       throw new JAXRPCException("unable to deserialize", sOAPException);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void serialize(Object paramObject, XMLName paramXMLName, SOAPMessage paramSOAPMessage, SerializationContext paramSerializationContext) throws SOAPFaultException {
/*    */     try {
/* 63 */       addBodyElement(paramXMLName, paramSOAPMessage);
/* 64 */     } catch (SOAPException sOAPException) {
/* 65 */       throw new JAXRPCException("failed to serialize the attachment " + paramXMLName, sOAPException);
/*    */     } 
/*    */ 
/*    */     
/* 69 */     if (paramObject == null) {
/*    */       return;
/*    */     }
/*    */     
/* 73 */     DataHandler dataHandler = (DataHandler)paramObject;
/* 74 */     AttachmentPart attachmentPart = paramSOAPMessage.createAttachmentPart();
/* 75 */     attachmentPart.setDataHandler(dataHandler);
/* 76 */     attachmentPart.setContentId("<" + paramXMLName.getLocalName() + ">");
/* 77 */     attachmentPart.addMimeHeader("Content-Type", dataHandler.getContentType());
/* 78 */     paramSOAPMessage.addAttachmentPart(attachmentPart);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\DataHandlerCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */