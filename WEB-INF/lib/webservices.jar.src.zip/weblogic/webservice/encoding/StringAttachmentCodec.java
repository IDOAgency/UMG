/*    */ package weblogic.webservice.encoding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StringAttachmentCodec
/*    */   extends AttachmentCodec
/*    */ {
/* 29 */   protected String getContentType() { return "text/plain"; }
/*    */ 
/*    */ 
/*    */   
/* 33 */   protected Object serializeContent(Object paramObject) { return (String)paramObject; }
/*    */ 
/*    */ 
/*    */   
/* 37 */   protected Object deserializeContent(Object paramObject) { return (String)paramObject; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\StringAttachmentCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */