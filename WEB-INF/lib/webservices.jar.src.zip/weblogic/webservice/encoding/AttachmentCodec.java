package weblogic.webservice.encoding;

import java.util.Iterator;
import javax.mail.internet.MimeMultipart;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.xml.schema.binding.DeserializationContext;
import weblogic.xml.schema.binding.DeserializationException;
import weblogic.xml.schema.binding.SerializationContext;
import weblogic.xml.schema.binding.SerializationException;
import weblogic.xml.stream.Attribute;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLOutputStream;

public abstract class AttachmentCodec extends AbstractCodec {
  protected Object deserialize(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) throws JAXRPCException {
    AttachmentPart attachmentPart = getAttachmentPart(paramXMLName, paramSOAPMessage, paramDeserializationContext);
    if (attachmentPart == null)
      return null; 
    try {
      return deserializeContent(attachmentPart.getContent());
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("failed to deserialize:" + attachmentPart, sOAPException);
    } 
  }
  
  protected abstract Object deserializeContent(Object paramObject);
  
  private SOAPElement getFirstChild(SOAPElement paramSOAPElement) throws SOAPException {
    Iterator iterator = paramSOAPElement.getChildElements();
    if (iterator.hasNext())
      return (SOAPElement)iterator.next(); 
    return null;
  }
  
  protected void addBodyElement(XMLName paramXMLName, SOAPMessage paramSOAPMessage) throws SOAPException {
    SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
    String str1 = paramXMLName.getPrefix();
    String str2 = paramXMLName.getNamespaceUri();
    if (str2 != null)
      str1 = (str1 == null) ? "ns" : str1; 
    Name name1 = sOAPEnvelope.createName(paramXMLName.getLocalName(), str1, str2);
    SOAPBody sOAPBody = sOAPEnvelope.getBody();
    SOAPElement sOAPElement = getFirstChild(sOAPBody);
    if (sOAPElement == null) {
      sOAPElement = sOAPBody.addChildElement(name1);
    } else {
      sOAPElement = sOAPElement.addChildElement(name1);
    } 
    Name name2 = sOAPEnvelope.createName("href");
    sOAPElement.addAttribute(name2, "cid:" + paramXMLName.getLocalName());
  }
  
  protected void serialize(Object paramObject, XMLName paramXMLName, SOAPMessage paramSOAPMessage, SerializationContext paramSerializationContext) throws SOAPFaultException {
    try {
      addBodyElement(paramXMLName, paramSOAPMessage);
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("failed to serialize the attachment " + paramXMLName, sOAPException);
    } 
    if (paramObject == null)
      return; 
    Object object = serializeContent(paramObject);
    AttachmentPart attachmentPart = paramSOAPMessage.createAttachmentPart();
    attachmentPart.setContent(object, getContentType());
    attachmentPart.setContentId("<" + paramXMLName.getLocalName() + ">");
    if (object instanceof MimeMultipart)
      attachmentPart.setMimeHeader("Content-Type", ((MimeMultipart)object).getContentType()); 
    paramSOAPMessage.addAttachmentPart(attachmentPart);
  }
  
  protected abstract Object serializeContent(Object paramObject);
  
  protected abstract String getContentType();
  
  protected AttachmentPart getAttachmentPart(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) {
    SOAPElement sOAPElement = paramDeserializationContext.getSOAPElement();
    String str = null;
    if (sOAPElement != null)
      try {
        SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
        Name name = sOAPEnvelope.createName("href");
        str = cleanHrefId(sOAPElement.getAttributeValue(name));
      } catch (SOAPException sOAPException) {
        throw new JAXRPCException(sOAPException);
      }  
    AttachmentPart attachmentPart = null;
    if (str != null)
      attachmentPart = getAttachmentPartFromName(str, paramSOAPMessage); 
    if (attachmentPart == null)
      attachmentPart = getAttachmentPartFromName(paramXMLName.getLocalName(), paramSOAPMessage); 
    return attachmentPart;
  }
  
  private String cleanHrefId(String paramString) {
    if (paramString != null && paramString.startsWith("cid:"))
      paramString = paramString.substring("cid:".length(), paramString.length()); 
    return paramString;
  }
  
  private AttachmentPart getAttachmentPartFromName(String paramString, SOAPMessage paramSOAPMessage) {
    Iterator iterator = paramSOAPMessage.getAttachments();
    while (iterator.hasNext()) {
      AttachmentPart attachmentPart = (AttachmentPart)iterator.next();
      if (paramString.equals(attachmentPart.getContentId()))
        return attachmentPart; 
      if (paramString.equals(cleanId(attachmentPart.getContentId())))
        return attachmentPart; 
    } 
    return null;
  }
  
  private String cleanId(String paramString) {
    if (paramString != null && paramString.startsWith("<"))
      paramString = paramString.substring(1, paramString.length()); 
    if (paramString != null && paramString.endsWith(">"))
      paramString = paramString.substring(0, paramString.length() - 1); 
    return paramString;
  }
  
  public final Object deserialize(XMLName paramXMLName, XMLInputStream paramXMLInputStream, DeserializationContext paramDeserializationContext) throws DeserializationException {
    SOAPMessage sOAPMessage = paramDeserializationContext.getSOAPMessage();
    if (sOAPMessage == null)
      throw new DeserializationException("Unable to find message inside the DeserializationContext"); 
    return deserialize(paramXMLName, sOAPMessage, paramDeserializationContext);
  }
  
  public final Object deserialize(XMLName paramXMLName, Attribute paramAttribute, DeserializationContext paramDeserializationContext) throws DeserializationException { throw new DeserializationException("SOAPElementCodec does not support Attribute deserialization"); }
  
  public final void serialize(Object paramObject, XMLName paramXMLName, XMLOutputStream paramXMLOutputStream, SerializationContext paramSerializationContext) throws SerializationException {
    SOAPMessage sOAPMessage = paramSerializationContext.getSOAPMessage();
    if (sOAPMessage == null)
      throw new SerializationException("Unable to find message inside the SerializationContext"); 
    serialize(paramObject, paramXMLName, sOAPMessage, paramSerializationContext);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\AttachmentCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */