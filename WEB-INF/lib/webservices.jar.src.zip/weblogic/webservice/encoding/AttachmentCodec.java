/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.AttachmentPart;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.xml.schema.binding.DeserializationContext;
/*     */ import weblogic.xml.schema.binding.DeserializationException;
/*     */ import weblogic.xml.schema.binding.SerializationContext;
/*     */ import weblogic.xml.schema.binding.SerializationException;
/*     */ import weblogic.xml.stream.Attribute;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AttachmentCodec
/*     */   extends AbstractCodec
/*     */ {
/*     */   protected Object deserialize(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) throws JAXRPCException {
/*  41 */     AttachmentPart attachmentPart = getAttachmentPart(paramXMLName, paramSOAPMessage, paramDeserializationContext);
/*     */     
/*  43 */     if (attachmentPart == null) {
/*  44 */       return null;
/*     */     }
/*     */     
/*     */     try {
/*  48 */       return deserializeContent(attachmentPart.getContent());
/*  49 */     } catch (SOAPException sOAPException) {
/*  50 */       throw new JAXRPCException("failed to deserialize:" + attachmentPart, sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract Object deserializeContent(Object paramObject);
/*     */   
/*     */   private SOAPElement getFirstChild(SOAPElement paramSOAPElement) throws SOAPException {
/*  58 */     Iterator iterator = paramSOAPElement.getChildElements(); if (iterator.hasNext()) {
/*  59 */       return (SOAPElement)iterator.next();
/*     */     }
/*     */     
/*  62 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addBodyElement(XMLName paramXMLName, SOAPMessage paramSOAPMessage) throws SOAPException {
/*  69 */     SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
/*     */ 
/*     */     
/*  72 */     String str1 = paramXMLName.getPrefix();
/*  73 */     String str2 = paramXMLName.getNamespaceUri();
/*  74 */     if (str2 != null) {
/*  75 */       str1 = (str1 == null) ? "ns" : str1;
/*     */     }
/*  77 */     Name name1 = sOAPEnvelope.createName(paramXMLName.getLocalName(), str1, str2);
/*     */     
/*  79 */     SOAPBody sOAPBody = sOAPEnvelope.getBody();
/*     */     
/*  81 */     SOAPElement sOAPElement = getFirstChild(sOAPBody);
/*  82 */     if (sOAPElement == null) {
/*  83 */       sOAPElement = sOAPBody.addChildElement(name1);
/*     */     } else {
/*  85 */       sOAPElement = sOAPElement.addChildElement(name1);
/*     */     } 
/*     */     
/*  88 */     Name name2 = sOAPEnvelope.createName("href");
/*  89 */     sOAPElement.addAttribute(name2, "cid:" + paramXMLName.getLocalName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void serialize(Object paramObject, XMLName paramXMLName, SOAPMessage paramSOAPMessage, SerializationContext paramSerializationContext) throws SOAPFaultException {
/*     */     try {
/*  98 */       addBodyElement(paramXMLName, paramSOAPMessage);
/*  99 */     } catch (SOAPException sOAPException) {
/* 100 */       throw new JAXRPCException("failed to serialize the attachment " + paramXMLName, sOAPException);
/*     */     } 
/*     */ 
/*     */     
/* 104 */     if (paramObject == null) {
/*     */       return;
/*     */     }
/*     */     
/* 108 */     Object object = serializeContent(paramObject);
/*     */     
/* 110 */     AttachmentPart attachmentPart = paramSOAPMessage.createAttachmentPart();
/* 111 */     attachmentPart.setContent(object, getContentType());
/* 112 */     attachmentPart.setContentId("<" + paramXMLName.getLocalName() + ">");
/*     */ 
/*     */     
/* 115 */     if (object instanceof MimeMultipart) {
/* 116 */       attachmentPart.setMimeHeader("Content-Type", ((MimeMultipart)object).getContentType());
/*     */     }
/*     */ 
/*     */     
/* 120 */     paramSOAPMessage.addAttachmentPart(attachmentPart);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract Object serializeContent(Object paramObject);
/*     */   
/*     */   protected abstract String getContentType();
/*     */   
/*     */   protected AttachmentPart getAttachmentPart(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) {
/* 129 */     SOAPElement sOAPElement = paramDeserializationContext.getSOAPElement();
/* 130 */     String str = null;
/*     */     
/* 132 */     if (sOAPElement != null) {
/*     */       try {
/* 134 */         SOAPEnvelope sOAPEnvelope = paramSOAPMessage.getSOAPPart().getEnvelope();
/* 135 */         Name name = sOAPEnvelope.createName("href");
/* 136 */         str = cleanHrefId(sOAPElement.getAttributeValue(name));
/* 137 */       } catch (SOAPException sOAPException) {
/* 138 */         throw new JAXRPCException(sOAPException);
/*     */       } 
/*     */     }
/*     */     
/* 142 */     AttachmentPart attachmentPart = null;
/*     */     
/* 144 */     if (str != null) {
/* 145 */       attachmentPart = getAttachmentPartFromName(str, paramSOAPMessage);
/*     */     }
/*     */     
/* 148 */     if (attachmentPart == null)
/*     */     {
/* 150 */       attachmentPart = getAttachmentPartFromName(paramXMLName.getLocalName(), paramSOAPMessage);
/*     */     }
/*     */ 
/*     */     
/* 154 */     return attachmentPart;
/*     */   }
/*     */ 
/*     */   
/*     */   private String cleanHrefId(String paramString) {
/* 159 */     if (paramString != null && paramString.startsWith("cid:")) {
/* 160 */       paramString = paramString.substring("cid:".length(), paramString.length());
/*     */     }
/*     */     
/* 163 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private AttachmentPart getAttachmentPartFromName(String paramString, SOAPMessage paramSOAPMessage) {
/* 169 */     Iterator iterator = paramSOAPMessage.getAttachments();
/*     */     
/* 171 */     while (iterator.hasNext()) {
/* 172 */       AttachmentPart attachmentPart = (AttachmentPart)iterator.next();
/*     */       
/* 174 */       if (paramString.equals(attachmentPart.getContentId())) {
/* 175 */         return attachmentPart;
/*     */       }
/*     */       
/* 178 */       if (paramString.equals(cleanId(attachmentPart.getContentId()))) {
/* 179 */         return attachmentPart;
/*     */       }
/*     */     } 
/*     */     
/* 183 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private String cleanId(String paramString) {
/* 188 */     if (paramString != null && paramString.startsWith("<")) {
/* 189 */       paramString = paramString.substring(1, paramString.length());
/*     */     }
/*     */     
/* 192 */     if (paramString != null && paramString.endsWith(">")) {
/* 193 */       paramString = paramString.substring(0, paramString.length() - 1);
/*     */     }
/*     */     
/* 196 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object deserialize(XMLName paramXMLName, XMLInputStream paramXMLInputStream, DeserializationContext paramDeserializationContext) throws DeserializationException {
/* 202 */     SOAPMessage sOAPMessage = paramDeserializationContext.getSOAPMessage();
/*     */     
/* 204 */     if (sOAPMessage == null) {
/* 205 */       throw new DeserializationException("Unable to find message inside the DeserializationContext");
/*     */     }
/*     */ 
/*     */     
/* 209 */     return deserialize(paramXMLName, sOAPMessage, paramDeserializationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public final Object deserialize(XMLName paramXMLName, Attribute paramAttribute, DeserializationContext paramDeserializationContext) throws DeserializationException { throw new DeserializationException("SOAPElementCodec does not support Attribute deserialization"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(Object paramObject, XMLName paramXMLName, XMLOutputStream paramXMLOutputStream, SerializationContext paramSerializationContext) throws SerializationException {
/* 232 */     SOAPMessage sOAPMessage = paramSerializationContext.getSOAPMessage();
/*     */     
/* 234 */     if (sOAPMessage == null) {
/* 235 */       throw new SerializationException("Unable to find message inside the SerializationContext");
/*     */     }
/*     */ 
/*     */     
/* 239 */     serialize(paramObject, paramXMLName, sOAPMessage, paramSerializationContext);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\AttachmentCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */