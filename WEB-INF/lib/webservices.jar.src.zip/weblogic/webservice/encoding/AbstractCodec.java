package weblogic.webservice.encoding;

import java.util.Collections;
import java.util.Iterator;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.Deserializer;
import javax.xml.rpc.encoding.DeserializerFactory;
import javax.xml.rpc.encoding.Serializer;
import javax.xml.rpc.encoding.SerializerFactory;
import weblogic.xml.schema.binding.Deserializer;
import weblogic.xml.schema.binding.Serializer;

public abstract class AbstractCodec implements Serializer, Deserializer, SerializerFactory, DeserializerFactory {
  public String getMechanismType() { return "stream"; }
  
  public Deserializer getDeserializerAs(String paramString) throws JAXRPCException {
    if (getMechanismType().equals(paramString))
      return this; 
    throw new JAXRPCException("unsupported mechanism: " + paramString);
  }
  
  public Serializer getSerializerAs(String paramString) throws JAXRPCException {
    if (getMechanismType().equals(paramString))
      return this; 
    throw new JAXRPCException("unsupported mechanism: " + paramString);
  }
  
  public Iterator getSupportedMechanismTypes() { return Collections.singletonList("stream").iterator(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\AbstractCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */