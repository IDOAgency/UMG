package weblogic.webservice.encoding;

import java.io.IOException;
import java.util.ArrayList;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.xml.schema.binding.DeserializationContext;
import weblogic.xml.schema.binding.SerializationContext;
import weblogic.xml.stream.XMLName;

public class MimeMultipartArrayCodec extends AttachmentCodec {
  private static final boolean debug = true;
  
  private static final boolean verbose = true;
  
  protected String getContentType() { throw new Error("should not be called"); }
  
  protected Object serializeContent(Object paramObject) { throw new Error("should not be called"); }
  
  protected Object deserializeContent(Object paramObject) { throw new Error("should not be called"); }
  
  protected Object deserialize(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) {
    AttachmentPart attachmentPart = getAttachmentPart(paramXMLName, paramSOAPMessage, paramDeserializationContext);
    if (attachmentPart == null)
      return null; 
    try {
      MimeMultipart mimeMultipart = (MimeMultipart)attachmentPart.getContent();
      int i = mimeMultipart.getCount();
      ArrayList arrayList = new ArrayList();
      for (byte b = 0; b < i; b++) {
        BodyPart bodyPart = mimeMultipart.getBodyPart(b);
        Object object = bodyPart.getContent();
        MimeMultipart mimeMultipart1 = (MimeMultipart)object;
        arrayList.add(mimeMultipart1);
      } 
      return arrayList.toArray(new MimeMultipart[arrayList.size()]);
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("failed to deserialize:" + attachmentPart, sOAPException);
    } catch (MessagingException messagingException) {
      throw new JAXRPCException("failed to deserialize mime multipart", messagingException);
    } catch (IOException iOException) {
      throw new JAXRPCException("failed to deserialize mime multipart", iOException);
    } 
  }
  
  protected void serialize(Object paramObject, XMLName paramXMLName, SOAPMessage paramSOAPMessage, SerializationContext paramSerializationContext) throws SOAPFaultException {
    ArrayList arrayList = new ArrayList();
    try {
      addBodyElement(paramXMLName, paramSOAPMessage);
      if (paramObject != null) {
        MimeMultipart[] arrayOfMimeMultipart = (MimeMultipart[])paramObject;
        MimeMultipart mimeMultipart = new MimeMultipart();
        for (byte b = 0; b < arrayOfMimeMultipart.length; b++) {
          MimeBodyPart mimeBodyPart = new MimeBodyPart();
          mimeBodyPart.setContent(arrayOfMimeMultipart[b]);
          mimeBodyPart.addHeader("Content-Type", arrayOfMimeMultipart[b].getContentType());
          mimeMultipart.addBodyPart(mimeBodyPart);
        } 
        AttachmentPart attachmentPart = paramSOAPMessage.createAttachmentPart();
        attachmentPart.setContent(mimeMultipart, "multipart/*");
        attachmentPart.setContentId("<" + paramXMLName.getLocalName() + ">");
        attachmentPart.setMimeHeader("Content-Type", mimeMultipart.getContentType());
        paramSOAPMessage.addAttachmentPart(attachmentPart);
      } 
    } catch (MessagingException messagingException) {
      throw new JAXRPCException("failed to serialize mime multipart", messagingException);
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("failed to serialize mime multipart", sOAPException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\MimeMultipartArrayCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */