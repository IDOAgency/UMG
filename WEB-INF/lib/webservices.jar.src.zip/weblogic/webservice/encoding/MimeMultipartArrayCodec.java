/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.AttachmentPart;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.xml.schema.binding.DeserializationContext;
/*     */ import weblogic.xml.schema.binding.SerializationContext;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MimeMultipartArrayCodec
/*     */   extends AttachmentCodec
/*     */ {
/*     */   private static final boolean debug = true;
/*     */   private static final boolean verbose = true;
/*     */   
/*  38 */   protected String getContentType() { throw new Error("should not be called"); }
/*     */ 
/*     */ 
/*     */   
/*  42 */   protected Object serializeContent(Object paramObject) { throw new Error("should not be called"); }
/*     */ 
/*     */ 
/*     */   
/*  46 */   protected Object deserializeContent(Object paramObject) { throw new Error("should not be called"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserialize(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) {
/*  52 */     AttachmentPart attachmentPart = getAttachmentPart(paramXMLName, paramSOAPMessage, paramDeserializationContext);
/*     */ 
/*     */     
/*  55 */     if (attachmentPart == null) {
/*  56 */       return null;
/*     */     }
/*     */     
/*     */     try {
/*  60 */       MimeMultipart mimeMultipart = (MimeMultipart)attachmentPart.getContent();
/*  61 */       int i = mimeMultipart.getCount();
/*     */       
/*  63 */       ArrayList arrayList = new ArrayList();
/*     */       
/*  65 */       for (byte b = 0; b < i; b++) {
/*  66 */         BodyPart bodyPart = mimeMultipart.getBodyPart(b);
/*  67 */         Object object = bodyPart.getContent();
/*  68 */         MimeMultipart mimeMultipart1 = (MimeMultipart)object;
/*  69 */         arrayList.add(mimeMultipart1);
/*     */       } 
/*     */       
/*  72 */       return arrayList.toArray(new MimeMultipart[arrayList.size()]);
/*  73 */     } catch (SOAPException sOAPException) {
/*  74 */       throw new JAXRPCException("failed to deserialize:" + attachmentPart, sOAPException);
/*  75 */     } catch (MessagingException messagingException) {
/*  76 */       throw new JAXRPCException("failed to deserialize mime multipart", messagingException);
/*  77 */     } catch (IOException iOException) {
/*  78 */       throw new JAXRPCException("failed to deserialize mime multipart", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void serialize(Object paramObject, XMLName paramXMLName, SOAPMessage paramSOAPMessage, SerializationContext paramSerializationContext) throws SOAPFaultException {
/*  86 */     ArrayList arrayList = new ArrayList();
/*     */ 
/*     */     
/*     */     try {
/*  90 */       addBodyElement(paramXMLName, paramSOAPMessage);
/*  91 */       if (paramObject != null) {
/*  92 */         MimeMultipart[] arrayOfMimeMultipart = (MimeMultipart[])paramObject;
/*  93 */         MimeMultipart mimeMultipart = new MimeMultipart();
/*     */         
/*  95 */         for (byte b = 0; b < arrayOfMimeMultipart.length; b++) {
/*  96 */           MimeBodyPart mimeBodyPart = new MimeBodyPart();
/*  97 */           mimeBodyPart.setContent(arrayOfMimeMultipart[b]);
/*  98 */           mimeBodyPart.addHeader("Content-Type", arrayOfMimeMultipart[b].getContentType());
/*  99 */           mimeMultipart.addBodyPart(mimeBodyPart);
/*     */         } 
/*     */         
/* 102 */         AttachmentPart attachmentPart = paramSOAPMessage.createAttachmentPart();
/* 103 */         attachmentPart.setContent(mimeMultipart, "multipart/*");
/* 104 */         attachmentPart.setContentId("<" + paramXMLName.getLocalName() + ">");
/*     */         
/* 106 */         attachmentPart.setMimeHeader("Content-Type", mimeMultipart.getContentType());
/*     */ 
/*     */         
/* 109 */         paramSOAPMessage.addAttachmentPart(attachmentPart);
/*     */       } 
/* 111 */     } catch (MessagingException messagingException) {
/* 112 */       throw new JAXRPCException("failed to serialize mime multipart", messagingException);
/* 113 */     } catch (SOAPException sOAPException) {
/* 114 */       throw new JAXRPCException("failed to serialize mime multipart", sOAPException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\MimeMultipartArrayCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */