/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.AttachmentPart;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.xml.schema.binding.DeserializationContext;
/*     */ import weblogic.xml.schema.binding.SerializationContext;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataHandlerArrayCodec
/*     */   extends AttachmentCodec
/*     */ {
/*  37 */   protected String getContentType() { throw new Error("should not be called"); }
/*     */ 
/*     */ 
/*     */   
/*  41 */   protected Object serializeContent(Object paramObject) { throw new Error("should not be called"); }
/*     */ 
/*     */ 
/*     */   
/*  45 */   protected Object deserializeContent(Object paramObject) { throw new Error("should not be called"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserialize(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) {
/*  51 */     AttachmentPart attachmentPart = getAttachmentPart(paramXMLName, paramSOAPMessage, paramDeserializationContext);
/*     */ 
/*     */     
/*  54 */     if (attachmentPart == null) {
/*  55 */       return null;
/*     */     }
/*     */     
/*     */     try {
/*  59 */       MimeMultipart mimeMultipart = (MimeMultipart)attachmentPart.getContent();
/*  60 */       ArrayList arrayList = new ArrayList();
/*     */       
/*  62 */       for (byte b = 0; b < mimeMultipart.getCount(); b++) {
/*  63 */         BodyPart bodyPart = mimeMultipart.getBodyPart(b);
/*  64 */         DataHandler dataHandler = bodyPart.getDataHandler();
/*  65 */         arrayList.add(dataHandler);
/*     */       } 
/*     */       
/*  68 */       return arrayList.toArray(new DataHandler[arrayList.size()]);
/*  69 */     } catch (SOAPException sOAPException) {
/*  70 */       throw new JAXRPCException("failed to deserialize:" + attachmentPart, sOAPException);
/*  71 */     } catch (MessagingException messagingException) {
/*  72 */       throw new JAXRPCException("failed to deserialize mime multipart", messagingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void serialize(Object paramObject, XMLName paramXMLName, SOAPMessage paramSOAPMessage, SerializationContext paramSerializationContext) throws SOAPFaultException {
/*     */     try {
/*  81 */       addBodyElement(paramXMLName, paramSOAPMessage);
/*  82 */     } catch (SOAPException sOAPException) {
/*  83 */       throw new JAXRPCException("failed to serialize the attachment " + paramXMLName, sOAPException);
/*     */     } 
/*     */ 
/*     */     
/*  87 */     if (paramObject == null) {
/*     */       return;
/*     */     }
/*     */     
/*  91 */     DataHandler[] arrayOfDataHandler = (DataHandler[])paramObject;
/*  92 */     MimeMultipart mimeMultipart = new MimeMultipart();
/*     */     
/*  94 */     for (byte b = 0; b < arrayOfDataHandler.length; b++) {
/*  95 */       MimeBodyPart mimeBodyPart = new MimeBodyPart();
/*     */       try {
/*  97 */         mimeBodyPart.setDataHandler(arrayOfDataHandler[b]);
/*  98 */         mimeMultipart.addBodyPart(mimeBodyPart);
/*  99 */       } catch (MessagingException messagingException) {
/* 100 */         throw new JAXRPCException("failed to serialize", messagingException);
/*     */       } 
/*     */     } 
/*     */     
/* 104 */     AttachmentPart attachmentPart = paramSOAPMessage.createAttachmentPart();
/* 105 */     attachmentPart.setContent(mimeMultipart, mimeMultipart.getContentType());
/* 106 */     attachmentPart.setContentId("<" + paramXMLName.getLocalName() + ">");
/*     */     
/* 108 */     attachmentPart.setMimeHeader("Content-Type", mimeMultipart.getContentType());
/*     */     
/* 110 */     paramSOAPMessage.addAttachmentPart(attachmentPart);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\DataHandlerArrayCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */