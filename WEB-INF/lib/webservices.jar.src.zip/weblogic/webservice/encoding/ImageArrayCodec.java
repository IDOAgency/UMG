/*    */ package weblogic.webservice.encoding;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import javax.activation.DataHandler;
/*    */ import javax.mail.BodyPart;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.internet.MimeBodyPart;
/*    */ import javax.mail.internet.MimeMultipart;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import weblogic.webservice.WebServiceLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageArrayCodec
/*    */   extends AttachmentCodec
/*    */ {
/* 42 */   private ImageCodec codec = new ImageCodec();
/*    */   
/*    */   protected Object deserializeContent(Object paramObject) {
/* 45 */     MimeMultipart mimeMultipart = (MimeMultipart)paramObject;
/*    */     try {
/* 47 */       int i = mimeMultipart.getCount();
/*    */       
/* 49 */       ArrayList arrayList = new ArrayList();
/*    */       
/* 51 */       for (byte b = 0; b < i; b++) {
/* 52 */         BodyPart bodyPart = mimeMultipart.getBodyPart(b);
/* 53 */         Object object = bodyPart.getContent();
/* 54 */         Image image = (Image)this.codec.deserializeContent(object);
/* 55 */         arrayList.add(image);
/*    */       } 
/*    */       
/* 58 */       return arrayList.toArray(new Image[arrayList.size()]);
/* 59 */     } catch (MessagingException messagingException) {
/* 60 */       String str = WebServiceLogger.logImageEncodingMessageException();
/* 61 */       WebServiceLogger.logStackTrace(str, messagingException);
/* 62 */       throw new JAXRPCException("failed to deserialize mime multipart", messagingException);
/* 63 */     } catch (IOException iOException) {
/* 64 */       String str = WebServiceLogger.logImageEncodingIOException();
/* 65 */       WebServiceLogger.logStackTrace(str, iOException);
/* 66 */       throw new JAXRPCException("failed to deserialize mime multipart", iOException);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 72 */   protected String getContentType() { return "multipart/*"; }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object serializeContent(Object paramObject) {
/* 77 */     if (!(paramObject instanceof Image[])) {
/* 78 */       throw new JAXRPCException("input is not Image[] :" + paramObject);
/*    */     }
/*    */     
/* 81 */     Image[] arrayOfImage = (Image[])paramObject;
/*    */     
/* 83 */     MimeMultipart mimeMultipart = new MimeMultipart();
/*    */     
/* 85 */     for (byte b = 0; b < arrayOfImage.length; b++) {
/* 86 */       MimeBodyPart mimeBodyPart = new MimeBodyPart();
/* 87 */       DataHandler dataHandler = new DataHandler(this.codec.serializeContent(arrayOfImage[b]), "text/xml");
/*    */       
/*    */       try {
/* 90 */         mimeBodyPart.setDataHandler(dataHandler);
/* 91 */         mimeMultipart.addBodyPart(mimeBodyPart, b);
/* 92 */       } catch (MessagingException messagingException) {
/* 93 */         throw new JAXRPCException("failed to set data handler " + messagingException, messagingException);
/*    */       } 
/*    */     } 
/*    */     
/* 97 */     return mimeMultipart;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\ImageArrayCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */