package weblogic.webservice.encoding;

import java.awt.Image;
import java.io.IOException;
import java.util.ArrayList;
import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.xml.rpc.JAXRPCException;
import weblogic.webservice.WebServiceLogger;

public class ImageArrayCodec extends AttachmentCodec {
  private ImageCodec codec = new ImageCodec();
  
  protected Object deserializeContent(Object paramObject) {
    MimeMultipart mimeMultipart = (MimeMultipart)paramObject;
    try {
      int i = mimeMultipart.getCount();
      ArrayList arrayList = new ArrayList();
      for (byte b = 0; b < i; b++) {
        BodyPart bodyPart = mimeMultipart.getBodyPart(b);
        Object object = bodyPart.getContent();
        Image image = (Image)this.codec.deserializeContent(object);
        arrayList.add(image);
      } 
      return arrayList.toArray(new Image[arrayList.size()]);
    } catch (MessagingException messagingException) {
      String str = WebServiceLogger.logImageEncodingMessageException();
      WebServiceLogger.logStackTrace(str, messagingException);
      throw new JAXRPCException("failed to deserialize mime multipart", messagingException);
    } catch (IOException iOException) {
      String str = WebServiceLogger.logImageEncodingIOException();
      WebServiceLogger.logStackTrace(str, iOException);
      throw new JAXRPCException("failed to deserialize mime multipart", iOException);
    } 
  }
  
  protected String getContentType() { return "multipart/*"; }
  
  protected Object serializeContent(Object paramObject) {
    if (!(paramObject instanceof Image[]))
      throw new JAXRPCException("input is not Image[] :" + paramObject); 
    Image[] arrayOfImage = (Image[])paramObject;
    MimeMultipart mimeMultipart = new MimeMultipart();
    for (byte b = 0; b < arrayOfImage.length; b++) {
      MimeBodyPart mimeBodyPart = new MimeBodyPart();
      DataHandler dataHandler = new DataHandler(this.codec.serializeContent(arrayOfImage[b]), "text/xml");
      try {
        mimeBodyPart.setDataHandler(dataHandler);
        mimeMultipart.addBodyPart(mimeBodyPart, b);
      } catch (MessagingException messagingException) {
        throw new JAXRPCException("failed to set data handler " + messagingException, messagingException);
      } 
    } 
    return mimeMultipart;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\ImageArrayCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */