package weblogic.webservice.encoding;

import java.io.IOException;
import java.util.ArrayList;
import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.xml.rpc.JAXRPCException;
import javax.xml.transform.Source;
import weblogic.webservice.WebServiceLogger;

public class XMLSourceArrayCodec extends AttachmentCodec {
  private XMLSourceCodec codec = new XMLSourceCodec();
  
  protected Object deserializeContent(Object paramObject) {
    MimeMultipart mimeMultipart = (MimeMultipart)paramObject;
    try {
      int i = mimeMultipart.getCount();
      ArrayList arrayList = new ArrayList();
      for (byte b = 0; b < i; b++) {
        BodyPart bodyPart = mimeMultipart.getBodyPart(b);
        Object object = bodyPart.getContent();
        Source source = (Source)this.codec.deserializeContent(object);
        arrayList.add(source);
      } 
      return arrayList.toArray(new Source[arrayList.size()]);
    } catch (MessagingException messagingException) {
      String str = WebServiceLogger.logXMLSourceEncodingMessageException();
      WebServiceLogger.logStackTrace(str, messagingException);
      throw new JAXRPCException("failed to deserialize mime multipart", messagingException);
    } catch (IOException iOException) {
      String str = WebServiceLogger.logXMLSourceEncodingIOException();
      WebServiceLogger.logStackTrace(str, iOException);
      throw new JAXRPCException("failed to deserialize mime multipart", iOException);
    } 
  }
  
  protected String getContentType() { return "multipart/*"; }
  
  protected Object serializeContent(Object paramObject) {
    if (!(paramObject instanceof Source[]))
      throw new JAXRPCException("input is not Source[] :" + paramObject); 
    Source[] arrayOfSource = (Source[])paramObject;
    MimeMultipart mimeMultipart = new MimeMultipart();
    for (byte b = 0; b < arrayOfSource.length; b++) {
      MimeBodyPart mimeBodyPart = new MimeBodyPart();
      DataHandler dataHandler = new DataHandler(this.codec.serializeContent(arrayOfSource[b]), "text/xml");
      try {
        mimeBodyPart.setDataHandler(dataHandler);
        mimeMultipart.addBodyPart(mimeBodyPart, b);
      } catch (MessagingException messagingException) {
        throw new JAXRPCException("failed to set data handler " + messagingException, messagingException);
      } 
    } 
    return mimeMultipart;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\XMLSourceArrayCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */