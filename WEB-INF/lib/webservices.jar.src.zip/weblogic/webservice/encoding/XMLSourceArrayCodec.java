/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.BodyPart;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.transform.Source;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLSourceArrayCodec
/*     */   extends AttachmentCodec
/*     */ {
/*  53 */   private XMLSourceCodec codec = new XMLSourceCodec();
/*     */   
/*     */   protected Object deserializeContent(Object paramObject) {
/*  56 */     MimeMultipart mimeMultipart = (MimeMultipart)paramObject;
/*     */     try {
/*  58 */       int i = mimeMultipart.getCount();
/*     */       
/*  60 */       ArrayList arrayList = new ArrayList();
/*     */       
/*  62 */       for (byte b = 0; b < i; b++) {
/*  63 */         BodyPart bodyPart = mimeMultipart.getBodyPart(b);
/*  64 */         Object object = bodyPart.getContent();
/*  65 */         Source source = (Source)this.codec.deserializeContent(object);
/*  66 */         arrayList.add(source);
/*     */       } 
/*     */       
/*  69 */       return arrayList.toArray(new Source[arrayList.size()]);
/*  70 */     } catch (MessagingException messagingException) {
/*  71 */       String str = WebServiceLogger.logXMLSourceEncodingMessageException();
/*  72 */       WebServiceLogger.logStackTrace(str, messagingException);
/*  73 */       throw new JAXRPCException("failed to deserialize mime multipart", messagingException);
/*  74 */     } catch (IOException iOException) {
/*  75 */       String str = WebServiceLogger.logXMLSourceEncodingIOException();
/*  76 */       WebServiceLogger.logStackTrace(str, iOException);
/*  77 */       throw new JAXRPCException("failed to deserialize mime multipart", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  83 */   protected String getContentType() { return "multipart/*"; }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object serializeContent(Object paramObject) {
/*  88 */     if (!(paramObject instanceof Source[])) {
/*  89 */       throw new JAXRPCException("input is not Source[] :" + paramObject);
/*     */     }
/*     */     
/*  92 */     Source[] arrayOfSource = (Source[])paramObject;
/*     */     
/*  94 */     MimeMultipart mimeMultipart = new MimeMultipart();
/*     */     
/*  96 */     for (byte b = 0; b < arrayOfSource.length; b++) {
/*  97 */       MimeBodyPart mimeBodyPart = new MimeBodyPart();
/*  98 */       DataHandler dataHandler = new DataHandler(this.codec.serializeContent(arrayOfSource[b]), "text/xml");
/*     */       
/*     */       try {
/* 101 */         mimeBodyPart.setDataHandler(dataHandler);
/* 102 */         mimeMultipart.addBodyPart(mimeBodyPart, b);
/* 103 */       } catch (MessagingException messagingException) {
/* 104 */         throw new JAXRPCException("failed to set data handler " + messagingException, messagingException);
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     return mimeMultipart;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\XMLSourceArrayCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */