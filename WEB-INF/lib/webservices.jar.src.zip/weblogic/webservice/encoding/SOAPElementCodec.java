/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import weblogic.xml.schema.binding.DeserializationContext;
/*     */ import weblogic.xml.schema.binding.DeserializationException;
/*     */ import weblogic.xml.schema.binding.SerializationContext;
/*     */ import weblogic.xml.schema.binding.SerializationException;
/*     */ import weblogic.xml.stream.Attribute;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SOAPElementCodec
/*     */   extends AbstractCodec
/*     */ {
/*     */   protected abstract Object deserializeSOAPElement(SOAPElement paramSOAPElement, DeserializationContext paramDeserializationContext) throws SOAPFaultException;
/*     */   
/*     */   protected abstract SOAPElement serializeToSOAPElement(Object paramObject, XMLName paramXMLName, SOAPElement paramSOAPElement, SerializationContext paramSerializationContext) throws SOAPFaultException;
/*     */   
/*     */   public final Object deserialize(XMLName paramXMLName, XMLInputStream paramXMLInputStream, DeserializationContext paramDeserializationContext) throws DeserializationException {
/*     */     try {
/*  75 */       paramXMLInputStream.skipElement();
/*  76 */     } catch (XMLStreamException xMLStreamException) {
/*  77 */       throw new DeserializationException("stream error", xMLStreamException);
/*     */     } 
/*  79 */     return deserializeSOAPElement(paramDeserializationContext.getSOAPElement(), paramDeserializationContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public final Object deserialize(XMLName paramXMLName, Attribute paramAttribute, DeserializationContext paramDeserializationContext) throws DeserializationException { throw new DeserializationException("SOAPElementCodec does not support Attribute deserialization"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(Object paramObject, XMLName paramXMLName, XMLOutputStream paramXMLOutputStream, SerializationContext paramSerializationContext) throws SerializationException {
/*  99 */     SOAPElement sOAPElement1 = null;
/*     */     
/* 101 */     SOAPElement sOAPElement2 = serializeToSOAPElement(paramObject, paramXMLName, sOAPElement1, paramSerializationContext);
/*     */     
/* 103 */     if (sOAPElement2 instanceof XMLNode) {
/* 104 */       XMLNode xMLNode = (XMLNode)sOAPElement2;
/*     */       try {
/* 106 */         xMLNode.write(paramXMLOutputStream);
/* 107 */       } catch (XMLStreamException xMLStreamException) {
/* 108 */         throw new SerializationException("stream error", xMLStreamException);
/*     */       } 
/*     */     } else {
/* 111 */       throw new SerializationException("child must be an instance of " + XMLNode.class);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\SOAPElementCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */