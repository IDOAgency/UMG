package weblogic.webservice.encoding;

import java.awt.Image;
import java.awt.Panel;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OptionalDataException;
import javax.xml.rpc.JAXRPCException;
import weblogic.utils.encoders.BASE64Encoder;
import weblogic.xml.schema.types.XSDBase64Binary;

public class ImageCodec extends AttachmentCodec {
  protected Object deserializeContent(Object paramObject) {
    if (paramObject == null)
      return null; 
    try {
      String str = (String)paramObject;
      byte[] arrayOfByte = XSDBase64Binary.convertXml(str);
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
      ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
      int i = objectInputStream.readInt();
      int j = objectInputStream.readInt();
      int[] arrayOfInt = (int[])objectInputStream.readObject();
      MemoryImageSource memoryImageSource = new MemoryImageSource(i, j, arrayOfInt, 0, i);
      Panel panel = new Panel();
      return panel.createImage(memoryImageSource);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new JAXRPCException(classNotFoundException);
    } catch (OptionalDataException optionalDataException) {
      throw new JAXRPCException(optionalDataException);
    } catch (IOException iOException) {
      throw new JAXRPCException(iOException);
    } 
  }
  
  protected String getContentType() { return "text/xml"; }
  
  protected Object serializeContent(Object paramObject) {
    Image image = null;
    if (paramObject instanceof Image) {
      image = (Image)paramObject;
    } else {
      throw new JAXRPCException("Dont know how to serialize:" + paramObject);
    } 
    PixelGrabber pixelGrabber = new PixelGrabber(image, 0, 0, -1, -1, true);
    try {
      pixelGrabber.grabPixels();
    } catch (InterruptedException interruptedException) {}
    int[] arrayOfInt = (int[])pixelGrabber.getPixels();
    int i = pixelGrabber.getWidth();
    int j = pixelGrabber.getHeight();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    try {
      ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
      objectOutputStream.writeInt(i);
      objectOutputStream.writeInt(j);
      objectOutputStream.writeObject(arrayOfInt);
    } catch (IOException iOException) {
      throw new JAXRPCException("failed to serialize:" + iOException, iOException);
    } 
    BASE64Encoder bASE64Encoder = new BASE64Encoder();
    return bASE64Encoder.encodeBuffer(byteArrayOutputStream.toByteArray());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\ImageCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */