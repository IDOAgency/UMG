/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.awt.Panel;
/*     */ import java.awt.image.MemoryImageSource;
/*     */ import java.awt.image.PixelGrabber;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OptionalDataException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.utils.encoders.BASE64Encoder;
/*     */ import weblogic.xml.schema.types.XSDBase64Binary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageCodec
/*     */   extends AttachmentCodec
/*     */ {
/*     */   protected Object deserializeContent(Object paramObject) {
/*  42 */     if (paramObject == null) {
/*  43 */       return null;
/*     */     }
/*     */     
/*     */     try {
/*  47 */       String str = (String)paramObject;
/*  48 */       byte[] arrayOfByte = XSDBase64Binary.convertXml(str);
/*  49 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
/*  50 */       ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
/*     */       
/*  52 */       int i = objectInputStream.readInt();
/*  53 */       int j = objectInputStream.readInt();
/*     */       
/*  55 */       int[] arrayOfInt = (int[])objectInputStream.readObject();
/*     */       
/*  57 */       MemoryImageSource memoryImageSource = new MemoryImageSource(i, j, arrayOfInt, 0, i);
/*     */ 
/*     */       
/*  60 */       Panel panel = new Panel();
/*  61 */       return panel.createImage(memoryImageSource);
/*     */     
/*     */     }
/*  64 */     catch (ClassNotFoundException classNotFoundException) {
/*  65 */       throw new JAXRPCException(classNotFoundException);
/*  66 */     } catch (OptionalDataException optionalDataException) {
/*  67 */       throw new JAXRPCException(optionalDataException);
/*  68 */     } catch (IOException iOException) {
/*  69 */       throw new JAXRPCException(iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  74 */   protected String getContentType() { return "text/xml"; }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object serializeContent(Object paramObject) {
/*  79 */     Image image = null;
/*     */     
/*  81 */     if (paramObject instanceof Image) {
/*  82 */       image = (Image)paramObject;
/*     */     } else {
/*  84 */       throw new JAXRPCException("Dont know how to serialize:" + paramObject);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  89 */     PixelGrabber pixelGrabber = new PixelGrabber(image, 0, 0, -1, -1, true);
/*     */     
/*     */     try {
/*  92 */       pixelGrabber.grabPixels();
/*  93 */     } catch (InterruptedException interruptedException) {}
/*     */     
/*  95 */     int[] arrayOfInt = (int[])pixelGrabber.getPixels();
/*     */     
/*  97 */     int i = pixelGrabber.getWidth();
/*  98 */     int j = pixelGrabber.getHeight();
/*     */     
/* 100 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*     */     try {
/* 103 */       ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
/*     */       
/* 105 */       objectOutputStream.writeInt(i);
/* 106 */       objectOutputStream.writeInt(j);
/* 107 */       objectOutputStream.writeObject(arrayOfInt);
/* 108 */     } catch (IOException iOException) {
/* 109 */       throw new JAXRPCException("failed to serialize:" + iOException, iOException);
/*     */     } 
/*     */     
/* 112 */     BASE64Encoder bASE64Encoder = new BASE64Encoder();
/* 113 */     return bASE64Encoder.encodeBuffer(byteArrayOutputStream.toByteArray());
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\ImageCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */