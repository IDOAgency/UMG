package weblogic.webservice.encoding;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.activation.MimeType;
import javax.activation.MimeTypeParseException;

public class ImageDataContentHandler implements DataContentHandler {
  private static final String IMAGE_GIF = "image/gif";
  
  private static final String IMAGE_JPEG = "image/jpeg";
  
  static Class array$B;
  
  public DataFlavor[] getTransferDataFlavors() {
    DataFlavor[] arrayOfDataFlavor = new DataFlavor[2];
    arrayOfDataFlavor[0] = new ActivationDataFlavor((array$B == null) ? (array$B = class$("[B")) : array$B, "image/gif", "image/gif");
    arrayOfDataFlavor[1] = new ActivationDataFlavor((array$B == null) ? (array$B = class$("[B")) : array$B, "image/jpeg", "image/jpeg");
    return arrayOfDataFlavor;
  }
  
  static Class class$(String paramString) { try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw (new NoClassDefFoundError()).initCause(classNotFoundException);
    }  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource) throws UnsupportedFlavorException, IOException {
    if (!paramDataFlavor.isMimeTypeEqual("image/gif") && !paramDataFlavor.isMimeTypeEqual("image/jpeg"))
      throw new UnsupportedFlavorException(paramDataFlavor); 
    if (paramDataFlavor.getRepresentationClass().isAssignableFrom(byte.class)) {
      InputStream inputStream = paramDataSource.getInputStream();
      return getByteArrayFromInputStream(inputStream);
    } 
    throw new UnsupportedFlavorException(paramDataFlavor);
  }
  
  public Object getContent(DataSource paramDataSource) throws IOException {
    InputStream inputStream = paramDataSource.getInputStream();
    return getByteArrayFromInputStream(inputStream);
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException {
    MimeType mimeType = null;
    try {
      mimeType = new MimeType(paramString);
      if (!mimeType.match("image/gif") && !mimeType.match("image/jpeg"))
        throw new IOException("MimeType should be image/gif or image/jpeg, and " + paramString + "is not suported."); 
    } catch (MimeTypeParseException mimeTypeParseException) {
      throw new IOException(mimeTypeParseException.toString());
    } 
    if (paramObject instanceof byte[]) {
      paramOutputStream.write((byte[])paramObject);
      paramOutputStream.flush();
    } else if (paramObject instanceof InputStream) {
      InputStream inputStream = (InputStream)paramObject;
      write(inputStream, paramOutputStream);
      inputStream.close();
      paramOutputStream.close();
    } else if (paramObject instanceof FileDataSource) {
      FileDataSource fileDataSource = (FileDataSource)paramObject;
      InputStream inputStream = fileDataSource.getInputStream();
      write(inputStream, paramOutputStream);
      inputStream.close();
      paramOutputStream.close();
    } else {
      throw new IOException(paramObject.getClass().getName() + ":is not supported.");
    } 
  }
  
  private void write(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    byte[] arrayOfByte = new byte[2048];
    int i;
    while ((i = paramInputStream.read(arrayOfByte)) != -1)
      paramOutputStream.write(arrayOfByte, 0, i); 
  }
  
  private static byte[] getByteArrayFromInputStream(InputStream paramInputStream) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    byte[] arrayOfByte = new byte[2048];
    int i;
    while ((i = paramInputStream.read(arrayOfByte)) != -1)
      byteArrayOutputStream.write(arrayOfByte, 0, i); 
    return byteArrayOutputStream.toByteArray();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\ImageDataContentHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */