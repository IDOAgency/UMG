/*     */ package weblogic.webservice.encoding;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.UnsupportedFlavorException;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.activation.ActivationDataFlavor;
/*     */ import javax.activation.DataContentHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.activation.FileDataSource;
/*     */ import javax.activation.MimeType;
/*     */ import javax.activation.MimeTypeParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageDataContentHandler
/*     */   implements DataContentHandler
/*     */ {
/*     */   private static final String IMAGE_GIF = "image/gif";
/*     */   private static final String IMAGE_JPEG = "image/jpeg";
/*     */   static Class array$B;
/*     */   
/*     */   public DataFlavor[] getTransferDataFlavors() {
/*  32 */     DataFlavor[] arrayOfDataFlavor = new DataFlavor[2];
/*  33 */     arrayOfDataFlavor[0] = new ActivationDataFlavor((array$B == null) ? (array$B = class$("[B")) : array$B, "image/gif", "image/gif");
/*  34 */     arrayOfDataFlavor[1] = new ActivationDataFlavor((array$B == null) ? (array$B = class$("[B")) : array$B, "image/jpeg", "image/jpeg");
/*     */ 
/*     */     
/*  37 */     return arrayOfDataFlavor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource) throws UnsupportedFlavorException, IOException {
/*  44 */     if (!paramDataFlavor.isMimeTypeEqual("image/gif") && !paramDataFlavor.isMimeTypeEqual("image/jpeg")) {
/*  45 */       throw new UnsupportedFlavorException(paramDataFlavor);
/*     */     }
/*     */ 
/*     */     
/*  49 */     if (paramDataFlavor.getRepresentationClass().isAssignableFrom(byte.class)) {
/*  50 */       InputStream inputStream = paramDataSource.getInputStream();
/*  51 */       return getByteArrayFromInputStream(inputStream);
/*     */     } 
/*     */     
/*  54 */     throw new UnsupportedFlavorException(paramDataFlavor);
/*     */   } static Class class$(String paramString) { try {
/*     */       return Class.forName(paramString);
/*     */     } catch (ClassNotFoundException classNotFoundException) {
/*     */       throw (new NoClassDefFoundError()).initCause(classNotFoundException);
/*     */     }  }
/*     */   public Object getContent(DataSource paramDataSource) throws IOException {
/*  61 */     InputStream inputStream = paramDataSource.getInputStream();
/*  62 */     return getByteArrayFromInputStream(inputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream) throws IOException {
/*  69 */     MimeType mimeType = null;
/*     */     
/*     */     try {
/*  72 */       mimeType = new MimeType(paramString);
/*     */       
/*  74 */       if (!mimeType.match("image/gif") && !mimeType.match("image/jpeg")) {
/*  75 */         throw new IOException("MimeType should be image/gif or image/jpeg, and " + paramString + "is not suported.");
/*     */       
/*     */       }
/*     */     }
/*  79 */     catch (MimeTypeParseException mimeTypeParseException) {
/*  80 */       throw new IOException(mimeTypeParseException.toString());
/*     */     } 
/*     */     
/*  83 */     if (paramObject instanceof byte[]) {
/*  84 */       paramOutputStream.write((byte[])paramObject);
/*  85 */       paramOutputStream.flush();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  91 */     else if (paramObject instanceof InputStream) {
/*  92 */       InputStream inputStream = (InputStream)paramObject;
/*  93 */       write(inputStream, paramOutputStream);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       inputStream.close();
/* 104 */       paramOutputStream.close();
/* 105 */     } else if (paramObject instanceof FileDataSource) {
/* 106 */       FileDataSource fileDataSource = (FileDataSource)paramObject;
/* 107 */       InputStream inputStream = fileDataSource.getInputStream();
/* 108 */       write(inputStream, paramOutputStream);
/* 109 */       inputStream.close();
/* 110 */       paramOutputStream.close();
/*     */     } else {
/*     */       
/* 113 */       throw new IOException(paramObject.getClass().getName() + ":is not supported.");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void write(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
/* 119 */     byte[] arrayOfByte = new byte[2048];
/*     */     int i;
/* 121 */     while ((i = paramInputStream.read(arrayOfByte)) != -1) {
/* 122 */       paramOutputStream.write(arrayOfByte, 0, i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getByteArrayFromInputStream(InputStream paramInputStream) throws IOException {
/* 129 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 130 */     byte[] arrayOfByte = new byte[2048];
/*     */     int i;
/* 132 */     while ((i = paramInputStream.read(arrayOfByte)) != -1) {
/* 133 */       byteArrayOutputStream.write(arrayOfByte, 0, i);
/*     */     }
/*     */     
/* 136 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\ImageDataContentHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */