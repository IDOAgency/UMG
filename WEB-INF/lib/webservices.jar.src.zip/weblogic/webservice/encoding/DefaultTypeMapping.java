/*    */ package weblogic.webservice.encoding;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import weblogic.xml.schema.binding.BindingException;
/*    */ import weblogic.xml.schema.binding.internal.TypeMappingBase;
/*    */ import weblogic.xml.schema.binding.internal.XSDTypeMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultTypeMapping
/*    */   extends TypeMappingBase
/*    */ {
/*    */   public DefaultTypeMapping(String paramString) {
/*    */     try {
/* 53 */       setParent(XSDTypeMapping.createXSDMapping());
/* 54 */     } catch (BindingException bindingException) {
/* 55 */       throw new JAXRPCException("Failed to create binding", bindingException);
/*    */     } 
/*    */     
/* 58 */     loadTypeMapping(paramString);
/*    */   }
/*    */   
/*    */   private URL loadFromClasspath(String paramString) {
/* 62 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*    */     
/* 64 */     if (classLoader == null) {
/* 65 */       classLoader = getClass().getClassLoader();
/*    */     }
/*    */     
/* 68 */     URL uRL = classLoader.getResource(paramString);
/*    */     
/* 70 */     if (uRL == null) {
/* 71 */       uRL = getClass().getResource(paramString);
/*    */     }
/*    */     
/* 74 */     return uRL;
/*    */   }
/*    */ 
/*    */   
/*    */   private void loadTypeMapping(String paramString) {
/* 79 */     fileInputStream = null;
/*    */ 
/*    */     
/*    */     try {
/* 83 */       uRL = loadFromClasspath(paramString);
/*    */       
/* 85 */       fileInputStream = (uRL == null) ? new FileInputStream(paramString) : uRL.openStream();
/*    */ 
/*    */       
/* 88 */       readXML(fileInputStream);
/*    */     }
/* 90 */     catch (IOException iOException) {
/* 91 */       throw new JAXRPCException("Failed to open file " + iOException, iOException);
/*    */     } finally {
/*    */       try {
/* 94 */         if (fileInputStream != null) {
/* 95 */           fileInputStream.close();
/*    */         }
/* 97 */       } catch (IOException iOException) {}
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\DefaultTypeMapping.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */