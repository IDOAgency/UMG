package weblogic.webservice.encoding;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import javax.xml.rpc.JAXRPCException;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.internal.TypeMappingBase;
import weblogic.xml.schema.binding.internal.XSDTypeMapping;

public class DefaultTypeMapping extends TypeMappingBase {
  public DefaultTypeMapping(String paramString) {
    try {
      setParent(XSDTypeMapping.createXSDMapping());
    } catch (BindingException bindingException) {
      throw new JAXRPCException("Failed to create binding", bindingException);
    } 
    loadTypeMapping(paramString);
  }
  
  private URL loadFromClasspath(String paramString) {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = getClass().getClassLoader(); 
    URL uRL = classLoader.getResource(paramString);
    if (uRL == null)
      uRL = getClass().getResource(paramString); 
    return uRL;
  }
  
  private void loadTypeMapping(String paramString) {
    fileInputStream = null;
    try {
      uRL = loadFromClasspath(paramString);
      fileInputStream = (uRL == null) ? new FileInputStream(paramString) : uRL.openStream();
      readXML(fileInputStream);
    } catch (IOException iOException) {
      throw new JAXRPCException("Failed to open file " + iOException, iOException);
    } finally {
      try {
        if (fileInputStream != null)
          fileInputStream.close(); 
      } catch (IOException iOException) {}
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\DefaultTypeMapping.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */