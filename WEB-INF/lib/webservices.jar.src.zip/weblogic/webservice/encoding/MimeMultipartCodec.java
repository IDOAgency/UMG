/*    */ package weblogic.webservice.encoding;
/*    */ 
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.internet.MimeBodyPart;
/*    */ import javax.mail.internet.MimeMultipart;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.soap.SOAPFaultException;
/*    */ import javax.xml.soap.AttachmentPart;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import javax.xml.soap.SOAPMessage;
/*    */ import weblogic.xml.schema.binding.DeserializationContext;
/*    */ import weblogic.xml.schema.binding.SerializationContext;
/*    */ import weblogic.xml.stream.XMLName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MimeMultipartCodec
/*    */   extends AttachmentCodec
/*    */ {
/* 33 */   protected String getContentType() { throw new Error("should not be called"); }
/*    */ 
/*    */ 
/*    */   
/* 37 */   protected Object serializeContent(Object paramObject) { throw new Error("should not be called"); }
/*    */ 
/*    */ 
/*    */   
/* 41 */   protected Object deserializeContent(Object paramObject) { throw new Error("should not be called"); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object deserialize(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) throws JAXRPCException {
/* 47 */     AttachmentPart attachmentPart = getAttachmentPart(paramXMLName, paramSOAPMessage, paramDeserializationContext);
/*    */ 
/*    */     
/* 50 */     if (attachmentPart == null) {
/* 51 */       return null;
/*    */     }
/*    */     
/*    */     try {
/* 55 */       return (MimeMultipart)attachmentPart.getContent();
/*    */     
/*    */     }
/* 58 */     catch (SOAPException sOAPException) {
/* 59 */       throw new JAXRPCException("unable to deserialize", sOAPException);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void serialize(Object paramObject, XMLName paramXMLName, SOAPMessage paramSOAPMessage, SerializationContext paramSerializationContext) throws SOAPFaultException {
/*    */     try {
/* 68 */       addBodyElement(paramXMLName, paramSOAPMessage);
/* 69 */     } catch (SOAPException sOAPException) {
/* 70 */       throw new JAXRPCException("failed to serialize the attachment " + paramXMLName, sOAPException);
/*    */     } 
/*    */     
/* 73 */     if (paramObject == null) {
/*    */       return;
/*    */     }
/*    */     
/* 77 */     MimeMultipart mimeMultipart = (MimeMultipart)paramObject;
/* 78 */     AttachmentPart attachmentPart = paramSOAPMessage.createAttachmentPart();
/* 79 */     attachmentPart.setContent(mimeMultipart, mimeMultipart.getContentType());
/* 80 */     attachmentPart.setContentId("<" + paramXMLName.getLocalName() + ">");
/*    */     
/*    */     try {
/* 83 */       int i = mimeMultipart.getCount();
/* 84 */       for (byte b = 0; b < i; b++) {
/* 85 */         MimeBodyPart mimeBodyPart = (MimeBodyPart)mimeMultipart.getBodyPart(b);
/* 86 */         String str = mimeBodyPart.getDataHandler().getContentType();
/* 87 */         mimeBodyPart.setHeader("Content-Type", str);
/*    */       } 
/* 89 */     } catch (MessagingException messagingException) {
/* 90 */       throw new JAXRPCException("failed to set the contentType to the attachment part", messagingException);
/*    */     } 
/* 92 */     paramSOAPMessage.addAttachmentPart(attachmentPart);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\MimeMultipartCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */