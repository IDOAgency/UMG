package weblogic.webservice.encoding;

import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.xml.schema.binding.DeserializationContext;
import weblogic.xml.schema.binding.SerializationContext;
import weblogic.xml.stream.XMLName;

public class MimeMultipartCodec extends AttachmentCodec {
  protected String getContentType() { throw new Error("should not be called"); }
  
  protected Object serializeContent(Object paramObject) { throw new Error("should not be called"); }
  
  protected Object deserializeContent(Object paramObject) { throw new Error("should not be called"); }
  
  protected Object deserialize(XMLName paramXMLName, SOAPMessage paramSOAPMessage, DeserializationContext paramDeserializationContext) throws JAXRPCException {
    AttachmentPart attachmentPart = getAttachmentPart(paramXMLName, paramSOAPMessage, paramDeserializationContext);
    if (attachmentPart == null)
      return null; 
    try {
      return (MimeMultipart)attachmentPart.getContent();
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("unable to deserialize", sOAPException);
    } 
  }
  
  protected void serialize(Object paramObject, XMLName paramXMLName, SOAPMessage paramSOAPMessage, SerializationContext paramSerializationContext) throws SOAPFaultException {
    try {
      addBodyElement(paramXMLName, paramSOAPMessage);
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("failed to serialize the attachment " + paramXMLName, sOAPException);
    } 
    if (paramObject == null)
      return; 
    MimeMultipart mimeMultipart = (MimeMultipart)paramObject;
    AttachmentPart attachmentPart = paramSOAPMessage.createAttachmentPart();
    attachmentPart.setContent(mimeMultipart, mimeMultipart.getContentType());
    attachmentPart.setContentId("<" + paramXMLName.getLocalName() + ">");
    try {
      int i = mimeMultipart.getCount();
      for (byte b = 0; b < i; b++) {
        MimeBodyPart mimeBodyPart = (MimeBodyPart)mimeMultipart.getBodyPart(b);
        String str = mimeBodyPart.getDataHandler().getContentType();
        mimeBodyPart.setHeader("Content-Type", str);
      } 
    } catch (MessagingException messagingException) {
      throw new JAXRPCException("failed to set the contentType to the attachment part", messagingException);
    } 
    paramSOAPMessage.addAttachmentPart(attachmentPart);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\encoding\MimeMultipartCodec.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */