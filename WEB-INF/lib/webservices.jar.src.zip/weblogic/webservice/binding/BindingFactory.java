package weblogic.webservice.binding;

import java.io.IOException;
import java.util.HashMap;
import javax.xml.rpc.JAXRPCException;

public class BindingFactory {
  private static BindingFactory factory = new BindingFactory();
  
  private HashMap bindings;
  
  private BindingFactory() {
    this.bindings = new HashMap();
    this.bindings.put("http", weblogic.webservice.binding.soap.HttpClientBinding.class);
    this.bindings.put("https", weblogic.webservice.binding.https.HttpsClientBinding.class);
    this.bindings.put("http11", weblogic.webservice.binding.http11.Http11ClientBinding.class);
    this.bindings.put("jms", weblogic.webservice.binding.jms.JMSClientBinding.class);
  }
  
  public static BindingFactory getInstance() { return factory; }
  
  public Binding create(BindingInfo paramBindingInfo) throws IOException {
    Class clazz = (Class)this.bindings.get(paramBindingInfo.getTransport());
    if (clazz == null)
      throw new JAXRPCException("unknown binding:" + paramBindingInfo.getTransport() + "[" + paramBindingInfo + "]"); 
    try {
      Binding binding = (Binding)clazz.newInstance();
      binding.init(paramBindingInfo);
      return binding;
    } catch (InstantiationException instantiationException) {
      throw new JAXRPCException(instantiationException);
    } catch (IllegalAccessException illegalAccessException) {
      throw new JAXRPCException(illegalAccessException);
    } 
  }
  
  public void register(String paramString, Class paramClass) {
    if (paramString == null)
      throw new IllegalArgumentException("transport can not be null"); 
    if (paramClass == null)
      throw new IllegalArgumentException("binding class can not be null"); 
    if (!Binding.class.isAssignableFrom(paramClass))
      throw new IllegalArgumentException(paramClass + " is not an instance of " + Binding.class); 
    this.bindings.put(paramString, paramClass);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\BindingFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */