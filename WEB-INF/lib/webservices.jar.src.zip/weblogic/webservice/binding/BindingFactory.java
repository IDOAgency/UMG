/*    */ package weblogic.webservice.binding;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BindingFactory
/*    */ {
/* 24 */   private static BindingFactory factory = new BindingFactory();
/*    */   private BindingFactory() {
/* 26 */     this.bindings = new HashMap();
/*    */ 
/*    */     
/* 29 */     this.bindings.put("http", weblogic.webservice.binding.soap.HttpClientBinding.class);
/* 30 */     this.bindings.put("https", weblogic.webservice.binding.https.HttpsClientBinding.class);
/* 31 */     this.bindings.put("http11", weblogic.webservice.binding.http11.Http11ClientBinding.class);
/* 32 */     this.bindings.put("jms", weblogic.webservice.binding.jms.JMSClientBinding.class);
/*    */   }
/*    */   private HashMap bindings;
/*    */   
/* 36 */   public static BindingFactory getInstance() { return factory; }
/*    */ 
/*    */ 
/*    */   
/*    */   public Binding create(BindingInfo paramBindingInfo) throws IOException {
/* 41 */     Class clazz = (Class)this.bindings.get(paramBindingInfo.getTransport());
/*    */     
/* 43 */     if (clazz == null) {
/* 44 */       throw new JAXRPCException("unknown binding:" + paramBindingInfo.getTransport() + "[" + paramBindingInfo + "]");
/*    */     }
/*    */ 
/*    */     
/*    */     try {
/* 49 */       Binding binding = (Binding)clazz.newInstance();
/* 50 */       binding.init(paramBindingInfo);
/* 51 */       return binding;
/* 52 */     } catch (InstantiationException instantiationException) {
/* 53 */       throw new JAXRPCException(instantiationException);
/* 54 */     } catch (IllegalAccessException illegalAccessException) {
/* 55 */       throw new JAXRPCException(illegalAccessException);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void register(String paramString, Class paramClass) {
/* 61 */     if (paramString == null) {
/* 62 */       throw new IllegalArgumentException("transport can not be null");
/*    */     }
/*    */     
/* 65 */     if (paramClass == null) {
/* 66 */       throw new IllegalArgumentException("binding class can not be null");
/*    */     }
/*    */     
/* 69 */     if (!Binding.class.isAssignableFrom(paramClass)) {
/* 70 */       throw new IllegalArgumentException(paramClass + " is not an instance of " + Binding.class);
/*    */     }
/*    */ 
/*    */     
/* 74 */     this.bindings.put(paramString, paramClass);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\BindingFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */