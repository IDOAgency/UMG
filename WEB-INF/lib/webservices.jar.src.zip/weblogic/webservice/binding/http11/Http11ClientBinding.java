/*     */ package weblogic.webservice.binding.http11;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.ParseException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.MessageFactory;
/*     */ import javax.xml.soap.MimeHeader;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.net.http.HttpURLConnection;
/*     */ import weblogic.utils.net.InetAddressHelper;
/*     */ import weblogic.webservice.WLSOAPMessage;
/*     */ import weblogic.webservice.binding.AbstractBinding;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.util.AccessException;
/*     */ import weblogic.webservice.util.WLMessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Http11ClientBinding
/*     */   extends AbstractBinding
/*     */ {
/*     */   private URL url;
/*     */   private HttpURLConnection connection;
/*     */   private InputStream inputStream;
/*     */   private OutputStream outputStream;
/*     */   private PrintStream out;
/*  61 */   private int bufferSize = 4000;
/*     */ 
/*     */   
/*     */   private static final String WEBSERVICE_VERBOSE = "weblogic.webservice.verbose";
/*     */ 
/*     */   
/*     */   private static final String HTTP_FULL_URL = "weblogic.webservice.transport.http.full-url";
/*     */   
/*  69 */   private static boolean verbose = getBooleanProp("weblogic.webservice.verbose", false);
/*     */ 
/*     */ 
/*     */   
/*  73 */   private static final boolean fullUrl = getBooleanProp("weblogic.webservice.transport.http.full-url", false);
/*     */ 
/*     */   
/*     */   private static boolean getBooleanProp(String paramString, boolean paramBoolean) {
/*     */     try {
/*  78 */       return Boolean.getBoolean(paramString);
/*  79 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */       
/*  83 */       return paramBoolean;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private MessageFactory messageFactory = WLMessageFactory.getInstance().getMessageFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(BindingInfo paramBindingInfo) throws IOException {
/* 104 */     String str = InetAddressHelper.convertIfIPV6URL(paramBindingInfo.getAddress());
/* 105 */     this.url = new URL(str);
/* 106 */     this.out = System.out;
/* 107 */     setBindingInfo(paramBindingInfo);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean validContentType(String paramString) throws IOException {
/* 112 */     if (paramString == null) {
/* 113 */       return false;
/*     */     }
/*     */     
/* 116 */     String str = null;
/*     */     
/*     */     try {
/* 119 */       str = (new ContentType(paramString)).getBaseType();
/* 120 */     } catch (ParseException parseException) {
/* 121 */       return false;
/*     */     } 
/*     */     
/* 124 */     str = str.trim().toLowerCase();
/*     */     
/* 126 */     return ("text/xml".startsWith(str) || "application/soap+xml".startsWith(str) || "multipart/related".startsWith(str));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleErrorResponse() throws SOAPException {
/* 135 */     int i = this.connection.getResponseCode();
/*     */     
/* 137 */     switch (i) {
/*     */       
/*     */       case 500:
/* 140 */         throw new IOException("The server at " + this.url.toString() + " returned a 500 error code (Internal Server Error).  Please ensure" + " that your URL is correct, and the web service has deployed. ");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 404:
/* 146 */         throw new IOException("The server at " + this.url.toString() + " returned a 404 error code (Not Found).  Please ensure that your" + " URL is correct, and the web service has deployed " + "without error.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 403:
/* 153 */         throw new AccessException("The server at " + this.url.toString() + " returned a 403 error code (Forbidden).  Please ensure that your " + "URL is correct and that the correct protocol is in use.");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 401:
/* 159 */         throw new AccessException("The server at " + this.url.toString() + " returned a 401 error code (Unauthorized).  Please check that" + " username and password are set correctly and that you have" + " permission to access the requested method.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 301:
/*     */       case 302:
/* 167 */         throw new IOException("Redirection not supported: The server at " + this.url.toString() + " returned a " + i + " response code indicating this resource has moved.");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     throw new IOException("Received a response from url: " + this.url + " which did not have a valid SOAP content-type: " + this.connection.getContentType() + ".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream getStream() throws IOException {
/*     */     InputStream inputStream1;
/*     */     try {
/* 183 */       inputStream1 = this.connection.getInputStream();
/* 184 */     } catch (IOException iOException) {
/* 185 */       inputStream1 = this.connection.getErrorStream();
/*     */     } 
/*     */     
/* 188 */     return inputStream1;
/*     */   }
/*     */ 
/*     */   
/* 192 */   private boolean isVerbose() { return (verbose || getBindingInfo().isVerbose()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
/*     */     SOAPMessageContext sOAPMessageContext;
/* 207 */     if (paramMessageContext instanceof SOAPMessageContext) {
/* 208 */       sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     } else {
/* 210 */       throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
/*     */     } 
/*     */ 
/*     */     
/* 214 */     boolean bool = "true".equals(sOAPMessageContext.getProperty("__BEA_PRIVATE_ONEWAY_PROP"));
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 219 */       if (!validContentType(this.connection.getContentType())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 227 */         if (isVerbose()) {
/* 228 */           dumpResponse(getStream());
/*     */         }
/*     */         
/* 231 */         if (this.connection.getResponseCode() == 400)
/*     */         {
/* 233 */           throw new IOException("Received a response from url: " + this.url + " which did not have a valid SOAP content-type: " + this.connection.getContentType() + ". ");
/*     */         }
/*     */ 
/*     */         
/* 237 */         handleErrorResponse();
/*     */       } 
/*     */ 
/*     */       
/* 241 */       if (bool) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       StringBuffer stringBuffer = new StringBuffer();
/*     */       String str;
/* 250 */       for (b = 1; (str = this.connection.getHeaderFieldKey(b)) != null; b++) {
/* 251 */         if (str.equalsIgnoreCase("set-cookie")) {
/* 252 */           String str1 = this.connection.getHeaderField(b);
/* 253 */           stringBuffer.append(cleanupCookie(str1));
/* 254 */           stringBuffer.append(";");
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       if (stringBuffer.length() > 0) {
/* 263 */         sOAPMessageContext.setProperty("SessionID", stringBuffer.substring(0, stringBuffer.length() - 1));
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 268 */         this.inputStream = getStream();
/*     */         
/* 270 */         if (isVerbose()) {
/* 271 */           this.inputStream = dumpResponse(this.inputStream);
/*     */         }
/*     */         
/* 274 */         sOAPMessageContext.setMessage(this.messageFactory.createMessage(getMimeHeaders(), this.inputStream));
/*     */       
/*     */       }
/* 277 */       catch (IOException b) {
/* 278 */         IOException iOException; throw new IOException("Error reading the response from: " + this.url + ".  Please ensure that this is a " + "valid SOAP response.");
/*     */       } 
/*     */     } finally {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String cleanupCookie(String paramString) {
/* 292 */     paramString = paramString.trim();
/*     */     
/* 294 */     int i = paramString.indexOf(';');
/*     */     
/* 296 */     if (i != -1) {
/* 297 */       paramString = paramString.substring(0, i);
/*     */     }
/* 299 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MimeHeaders getMimeHeaders() {
/* 306 */     MimeHeaders mimeHeaders = new MimeHeaders();
/* 307 */     byte b = 1;
/*     */     
/*     */     String str;
/* 310 */     while ((str = this.connection.getHeaderFieldKey(b)) != null) {
/* 311 */       String str1 = this.connection.getHeaderField(b++);
/*     */       
/* 313 */       if (str1 != null && str1.length() != 0) {
/* 314 */         mimeHeaders.setHeader(str, str1);
/*     */       }
/*     */     } 
/*     */     
/* 318 */     return mimeHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
/*     */     SOAPMessageContext sOAPMessageContext;
/* 333 */     if (paramMessageContext instanceof SOAPMessageContext) {
/* 334 */       sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     } else {
/* 336 */       throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
/*     */     } 
/*     */ 
/*     */     
/* 340 */     SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 341 */     WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)sOAPMessage;
/*     */     
/* 343 */     MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
/*     */     
/* 345 */     if (getBindingInfo().getCharset() != null) {
/* 346 */       wLSOAPMessage.setCharset(getBindingInfo().getCharset());
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 351 */       String str1 = (String)sOAPMessageContext.getProperty("javax.xml.rpc.service.endpoint.address");
/* 352 */       str1 = InetAddressHelper.convertIfIPV6URL(str1);
/* 353 */       if (str1 != null) {
/* 354 */         this.url = new URL(str1);
/*     */       }
/*     */       
/* 357 */       this.connection = (HttpURLConnection)this.url.openConnection();
/* 358 */       this.connection.setDoOutput(true);
/* 359 */       this.connection.setDoInput(true);
/*     */ 
/*     */ 
/*     */       
/* 363 */       String str2 = (String)sOAPMessageContext.getProperty("weblogic.webservice.rpc.timeoutsecs");
/* 364 */       if (str2 != null && 
/* 365 */         this.connection instanceof HttpURLConnection) {
/* 366 */         int i = Integer.parseInt(str2) * 1000;
/* 367 */         ((HttpURLConnection)this.connection).setConnectTimeout(i);
/*     */       } 
/*     */ 
/*     */       
/* 371 */       String str3 = wLSOAPMessage.getContentType();
/*     */       
/* 373 */       if (wLSOAPMessage.getCharset() != null) {
/* 374 */         str3 = str3 + "; charset=" + wLSOAPMessage.getCharset();
/*     */       }
/*     */       
/* 377 */       this.connection.setRequestProperty("Content-Type", str3);
/*     */       
/* 379 */       if (getBindingInfo().getAcceptCharset() != null)
/*     */       {
/* 381 */         this.connection.setRequestProperty("Accept-Charset", getBindingInfo().getAcceptCharset());
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 386 */       if (mimeHeaders != null) {
/*     */         
/* 388 */         Iterator iterator = mimeHeaders.getAllHeaders();
/* 389 */         while (iterator.hasNext()) {
/*     */           
/* 391 */           MimeHeader mimeHeader = (MimeHeader)iterator.next();
/*     */ 
/*     */           
/* 394 */           if (!"Content-Type".equals(mimeHeader.getName())) {
/* 395 */             this.connection.setRequestProperty(mimeHeader.getName(), mimeHeader.getValue());
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 404 */       if (isVerbose()) {
/* 405 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */         
/* 407 */         sOAPMessage.writeTo(byteArrayOutputStream);
/* 408 */         byteArrayOutputStream.flush();
/* 409 */         byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */         
/* 411 */         dumpRequest(this.connection, arrayOfByte);
/* 412 */         this.outputStream = this.connection.getOutputStream();
/* 413 */         this.outputStream.write(arrayOfByte);
/*     */       } else {
/* 415 */         this.outputStream = this.connection.getOutputStream();
/* 416 */         sOAPMessage.writeTo(this.outputStream);
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 421 */       if (this.outputStream != null) {
/* 422 */         this.outputStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void dumpRequest(HttpURLConnection paramHttpURLConnection, byte[] paramArrayOfByte) {
/* 429 */     this.out.println("<!-------------------- REQUEST FROM CLIENT ---------------->");
/*     */     
/* 431 */     this.out.println("URL        :  " + this.url);
/* 432 */     this.out.println("Headers    :");
/*     */     
/* 434 */     Map map = paramHttpURLConnection.getRequestProperties();
/*     */     
/* 436 */     for (String str : map.keySet())
/*     */     {
/* 438 */       this.out.println("  " + str + ": " + map.get(str));
/*     */     }
/*     */     
/* 441 */     this.out.println("");
/* 442 */     this.out.println(new String(paramArrayOfByte));
/*     */     
/* 444 */     this.out.println("<!-------------------- END REQUEST FROM CLIENT ------------>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream dumpResponse(InputStream paramInputStream) throws IOException {
/* 478 */     this.out.println("<!-------------------- RESPONSE TO CLIENT --------------->");
/* 479 */     this.out.println("URL           : " + this.url);
/* 480 */     this.out.println("Response Code :" + this.connection.getResponseCode());
/* 481 */     this.out.println("Headers       :");
/*     */     
/* 483 */     for (Iterator iterator = getMimeHeaders().getAllHeaders(); iterator.hasNext(); ) {
/* 484 */       MimeHeader mimeHeader = (MimeHeader)iterator.next();
/* 485 */       this.out.println("  " + mimeHeader.getName() + "=" + mimeHeader.getValue());
/*     */     } 
/*     */     
/* 488 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*     */     int i;
/* 491 */     while ((i = paramInputStream.read()) != -1) {
/* 492 */       byteArrayOutputStream.write(i);
/*     */     }
/*     */     
/* 495 */     this.out.println("Envelope   :");
/* 496 */     this.out.println(new String(byteArrayOutputStream.toByteArray()));
/*     */     
/* 498 */     this.out.println("<!-------------------- END RESPONSE TO CLIENT ----------->");
/*     */     
/* 500 */     return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
/*     */   }
/*     */ 
/*     */   
/*     */   private String makeContentType() {
/*     */     String str;
/* 506 */     if ("SOAP1.1".equals(getBindingInfo().getType())) {
/* 507 */       str = "text/xml";
/*     */     } else {
/* 509 */       str = "application/soap+xml";
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 514 */     if (getBindingInfo().getCharset() != null) {
/* 515 */       str = str + "; charset=" + getBindingInfo().getCharset();
/*     */     }
/*     */     
/* 518 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getContentType(MimeHeaders paramMimeHeaders) {
/* 524 */     String[] arrayOfString = paramMimeHeaders.getHeader("Content-Type");
/*     */     
/* 526 */     if (arrayOfString == null || arrayOfString.length == 0)
/* 527 */       return makeContentType(); 
/* 528 */     if (arrayOfString.length == 1) {
/* 529 */       return arrayOfString[0];
/*     */     }
/* 531 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 533 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 534 */       stringBuffer.append(arrayOfString[b]);
/*     */     }
/*     */     
/* 537 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeToStream(OutputStream paramOutputStream, byte[] paramArrayOfByte) throws IOException {
/* 545 */     BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramOutputStream);
/* 546 */     bufferedOutputStream.write(paramArrayOfByte);
/* 547 */     bufferedOutputStream.flush();
/* 548 */     paramOutputStream.flush();
/*     */   }
/*     */ 
/*     */   
/* 552 */   private int getPort(URL paramURL) { return (paramURL.getPort() == -1) ? 80 : paramURL.getPort(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\http11\Http11ClientBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */