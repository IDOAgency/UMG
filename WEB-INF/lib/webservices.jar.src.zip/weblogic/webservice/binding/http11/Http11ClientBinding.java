package weblogic.webservice.binding.http11;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import javax.mail.internet.ContentType;
import javax.mail.internet.ParseException;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.net.http.HttpURLConnection;
import weblogic.utils.net.InetAddressHelper;
import weblogic.webservice.WLSOAPMessage;
import weblogic.webservice.binding.AbstractBinding;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.util.AccessException;
import weblogic.webservice.util.WLMessageFactory;

public class Http11ClientBinding extends AbstractBinding {
  private URL url;
  
  private HttpURLConnection connection;
  
  private InputStream inputStream;
  
  private OutputStream outputStream;
  
  private PrintStream out;
  
  private int bufferSize = 4000;
  
  private static final String WEBSERVICE_VERBOSE = "weblogic.webservice.verbose";
  
  private static final String HTTP_FULL_URL = "weblogic.webservice.transport.http.full-url";
  
  private static boolean verbose = getBooleanProp("weblogic.webservice.verbose", false);
  
  private static final boolean fullUrl = getBooleanProp("weblogic.webservice.transport.http.full-url", false);
  
  private static boolean getBooleanProp(String paramString, boolean paramBoolean) {
    try {
      return Boolean.getBoolean(paramString);
    } catch (SecurityException securityException) {
      return paramBoolean;
    } 
  }
  
  private MessageFactory messageFactory = WLMessageFactory.getInstance().getMessageFactory();
  
  public void init(BindingInfo paramBindingInfo) throws IOException {
    String str = InetAddressHelper.convertIfIPV6URL(paramBindingInfo.getAddress());
    this.url = new URL(str);
    this.out = System.out;
    setBindingInfo(paramBindingInfo);
  }
  
  private boolean validContentType(String paramString) throws IOException {
    if (paramString == null)
      return false; 
    String str = null;
    try {
      str = (new ContentType(paramString)).getBaseType();
    } catch (ParseException parseException) {
      return false;
    } 
    str = str.trim().toLowerCase();
    return ("text/xml".startsWith(str) || "application/soap+xml".startsWith(str) || "multipart/related".startsWith(str));
  }
  
  private void handleErrorResponse() throws SOAPException {
    int i = this.connection.getResponseCode();
    switch (i) {
      case 500:
        throw new IOException("The server at " + this.url.toString() + " returned a 500 error code (Internal Server Error).  Please ensure" + " that your URL is correct, and the web service has deployed. ");
      case 404:
        throw new IOException("The server at " + this.url.toString() + " returned a 404 error code (Not Found).  Please ensure that your" + " URL is correct, and the web service has deployed " + "without error.");
      case 403:
        throw new AccessException("The server at " + this.url.toString() + " returned a 403 error code (Forbidden).  Please ensure that your " + "URL is correct and that the correct protocol is in use.");
      case 401:
        throw new AccessException("The server at " + this.url.toString() + " returned a 401 error code (Unauthorized).  Please check that" + " username and password are set correctly and that you have" + " permission to access the requested method.");
      case 301:
      case 302:
        throw new IOException("Redirection not supported: The server at " + this.url.toString() + " returned a " + i + " response code indicating this resource has moved.");
    } 
    throw new IOException("Received a response from url: " + this.url + " which did not have a valid SOAP content-type: " + this.connection.getContentType() + ".");
  }
  
  private InputStream getStream() throws IOException {
    InputStream inputStream1;
    try {
      inputStream1 = this.connection.getInputStream();
    } catch (IOException iOException) {
      inputStream1 = this.connection.getErrorStream();
    } 
    return inputStream1;
  }
  
  private boolean isVerbose() { return (verbose || getBindingInfo().isVerbose()); }
  
  public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext;
    if (paramMessageContext instanceof SOAPMessageContext) {
      sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    } else {
      throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
    } 
    boolean bool = "true".equals(sOAPMessageContext.getProperty("__BEA_PRIVATE_ONEWAY_PROP"));
    try {
      if (!validContentType(this.connection.getContentType())) {
        if (isVerbose())
          dumpResponse(getStream()); 
        if (this.connection.getResponseCode() == 400)
          throw new IOException("Received a response from url: " + this.url + " which did not have a valid SOAP content-type: " + this.connection.getContentType() + ". "); 
        handleErrorResponse();
      } 
      if (bool)
        return; 
      StringBuffer stringBuffer = new StringBuffer();
      String str;
      for (b = 1; (str = this.connection.getHeaderFieldKey(b)) != null; b++) {
        if (str.equalsIgnoreCase("set-cookie")) {
          String str1 = this.connection.getHeaderField(b);
          stringBuffer.append(cleanupCookie(str1));
          stringBuffer.append(";");
        } 
      } 
      if (stringBuffer.length() > 0)
        sOAPMessageContext.setProperty("SessionID", stringBuffer.substring(0, stringBuffer.length() - 1)); 
      try {
        this.inputStream = getStream();
        if (isVerbose())
          this.inputStream = dumpResponse(this.inputStream); 
        sOAPMessageContext.setMessage(this.messageFactory.createMessage(getMimeHeaders(), this.inputStream));
      } catch (IOException b) {
        IOException iOException;
        throw new IOException("Error reading the response from: " + this.url + ".  Please ensure that this is a " + "valid SOAP response.");
      } 
    } finally {}
  }
  
  private String cleanupCookie(String paramString) {
    paramString = paramString.trim();
    int i = paramString.indexOf(';');
    if (i != -1)
      paramString = paramString.substring(0, i); 
    return paramString;
  }
  
  private MimeHeaders getMimeHeaders() {
    MimeHeaders mimeHeaders = new MimeHeaders();
    byte b = 1;
    String str;
    while ((str = this.connection.getHeaderFieldKey(b)) != null) {
      String str1 = this.connection.getHeaderField(b++);
      if (str1 != null && str1.length() != 0)
        mimeHeaders.setHeader(str, str1); 
    } 
    return mimeHeaders;
  }
  
  public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext;
    if (paramMessageContext instanceof SOAPMessageContext) {
      sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    } else {
      throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
    } 
    SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
    WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)sOAPMessage;
    MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
    if (getBindingInfo().getCharset() != null)
      wLSOAPMessage.setCharset(getBindingInfo().getCharset()); 
    try {
      String str1 = (String)sOAPMessageContext.getProperty("javax.xml.rpc.service.endpoint.address");
      str1 = InetAddressHelper.convertIfIPV6URL(str1);
      if (str1 != null)
        this.url = new URL(str1); 
      this.connection = (HttpURLConnection)this.url.openConnection();
      this.connection.setDoOutput(true);
      this.connection.setDoInput(true);
      String str2 = (String)sOAPMessageContext.getProperty("weblogic.webservice.rpc.timeoutsecs");
      if (str2 != null && 
        this.connection instanceof HttpURLConnection) {
        int i = Integer.parseInt(str2) * 1000;
        ((HttpURLConnection)this.connection).setConnectTimeout(i);
      } 
      String str3 = wLSOAPMessage.getContentType();
      if (wLSOAPMessage.getCharset() != null)
        str3 = str3 + "; charset=" + wLSOAPMessage.getCharset(); 
      this.connection.setRequestProperty("Content-Type", str3);
      if (getBindingInfo().getAcceptCharset() != null)
        this.connection.setRequestProperty("Accept-Charset", getBindingInfo().getAcceptCharset()); 
      if (mimeHeaders != null) {
        Iterator iterator = mimeHeaders.getAllHeaders();
        while (iterator.hasNext()) {
          MimeHeader mimeHeader = (MimeHeader)iterator.next();
          if (!"Content-Type".equals(mimeHeader.getName()))
            this.connection.setRequestProperty(mimeHeader.getName(), mimeHeader.getValue()); 
        } 
      } 
      if (isVerbose()) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        sOAPMessage.writeTo(byteArrayOutputStream);
        byteArrayOutputStream.flush();
        byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
        dumpRequest(this.connection, arrayOfByte);
        this.outputStream = this.connection.getOutputStream();
        this.outputStream.write(arrayOfByte);
      } else {
        this.outputStream = this.connection.getOutputStream();
        sOAPMessage.writeTo(this.outputStream);
      } 
    } finally {
      if (this.outputStream != null)
        this.outputStream.close(); 
    } 
  }
  
  private void dumpRequest(HttpURLConnection paramHttpURLConnection, byte[] paramArrayOfByte) {
    this.out.println("<!-------------------- REQUEST FROM CLIENT ---------------->");
    this.out.println("URL        :  " + this.url);
    this.out.println("Headers    :");
    Map map = paramHttpURLConnection.getRequestProperties();
    for (String str : map.keySet())
      this.out.println("  " + str + ": " + map.get(str)); 
    this.out.println("");
    this.out.println(new String(paramArrayOfByte));
    this.out.println("<!-------------------- END REQUEST FROM CLIENT ------------>");
  }
  
  private InputStream dumpResponse(InputStream paramInputStream) throws IOException {
    this.out.println("<!-------------------- RESPONSE TO CLIENT --------------->");
    this.out.println("URL           : " + this.url);
    this.out.println("Response Code :" + this.connection.getResponseCode());
    this.out.println("Headers       :");
    for (Iterator iterator = getMimeHeaders().getAllHeaders(); iterator.hasNext(); ) {
      MimeHeader mimeHeader = (MimeHeader)iterator.next();
      this.out.println("  " + mimeHeader.getName() + "=" + mimeHeader.getValue());
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    while ((i = paramInputStream.read()) != -1)
      byteArrayOutputStream.write(i); 
    this.out.println("Envelope   :");
    this.out.println(new String(byteArrayOutputStream.toByteArray()));
    this.out.println("<!-------------------- END RESPONSE TO CLIENT ----------->");
    return new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
  }
  
  private String makeContentType() {
    String str;
    if ("SOAP1.1".equals(getBindingInfo().getType())) {
      str = "text/xml";
    } else {
      str = "application/soap+xml";
    } 
    if (getBindingInfo().getCharset() != null)
      str = str + "; charset=" + getBindingInfo().getCharset(); 
    return str;
  }
  
  private String getContentType(MimeHeaders paramMimeHeaders) {
    String[] arrayOfString = paramMimeHeaders.getHeader("Content-Type");
    if (arrayOfString == null || arrayOfString.length == 0)
      return makeContentType(); 
    if (arrayOfString.length == 1)
      return arrayOfString[0]; 
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < arrayOfString.length; b++)
      stringBuffer.append(arrayOfString[b]); 
    return stringBuffer.toString();
  }
  
  private void writeToStream(OutputStream paramOutputStream, byte[] paramArrayOfByte) throws IOException {
    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramOutputStream);
    bufferedOutputStream.write(paramArrayOfByte);
    bufferedOutputStream.flush();
    paramOutputStream.flush();
  }
  
  private int getPort(URL paramURL) { return (paramURL.getPort() == -1) ? 80 : paramURL.getPort(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\http11\Http11ClientBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */