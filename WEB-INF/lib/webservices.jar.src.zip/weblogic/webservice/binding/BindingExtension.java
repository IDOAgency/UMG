package weblogic.webservice.binding;

public abstract class BindingExtension {
  public static final int MAX_NUM_BIND = 2;
  
  public static int RELIABLE = 0;
  
  public static int DIME = 1;
  
  private int key;
  
  public int getKey() { return this.key; }
  
  public void setKey(int paramInt) { this.key = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\BindingExtension.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */