package weblogic.webservice.binding.httpnb;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.util.HashMap;
import java.util.Map;

class HttpConnection {
  private static int INIT = 0;
  
  private static int CONNECTING = 1;
  
  private InetSocketAddress socketAddress;
  
  private CharsetDecoder decoder;
  
  private CharsetEncoder encoder;
  
  private SocketChannel channel;
  
  private ConnectionSelector selector;
  
  private int state;
  
  private String uriToSend;
  
  private HashMap headersToSend;
  
  private byte[] envelopeToSend;
  
  private Throwable error;
  
  private HttpResponse response;
  
  HttpConnection(String paramString1, int paramInt, String paramString2, ConnectionSelector paramConnectionSelector) {
    this.state = INIT;
    this.selector = paramConnectionSelector;
    this.socketAddress = new InetSocketAddress(paramString1, paramInt);
    Charset charset = Charset.forName(paramString2);
    this.decoder = charset.newDecoder();
    this.encoder = charset.newEncoder();
    this.response = new HttpResponse(this);
  }
  
  public void send(String paramString, HashMap paramHashMap, byte[] paramArrayOfByte) throws IOException {
    this.uriToSend = paramString;
    this.headersToSend = paramHashMap;
    this.envelopeToSend = paramArrayOfByte;
    if (isConnected())
      connect(); 
    write();
  }
  
  private boolean isConnected() { return (this.channel == null); }
  
  void write() throws IOException {
    StringBuffer stringBuffer = createRequestLine();
    if (this.headersToSend != null) {
      this.headersToSend.put("Connection", "Keep-Alive");
      if (this.envelopeToSend != null)
        this.headersToSend.put("Content-Length", "" + this.envelopeToSend.length); 
      addHeaders(stringBuffer);
    } 
    stringBuffer.append("\r\n");
    this.channel.write(this.encoder.encode(CharBuffer.wrap(stringBuffer.toString())));
    this.channel.write(ByteBuffer.wrap(this.envelopeToSend));
  }
  
  private StringBuffer createRequestLine() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("POST ");
    stringBuffer.append(this.uriToSend);
    stringBuffer.append(" HTTP/1.0\r\n");
    return stringBuffer;
  }
  
  private void addHeaders(StringBuffer paramStringBuffer) {
    for (Map.Entry entry : this.headersToSend.entrySet()) {
      String str1 = (String)entry.getKey();
      String str2 = (String)entry.getValue();
      addHeader(paramStringBuffer, str1, str2);
    } 
  }
  
  private void addHeader(StringBuffer paramStringBuffer, String paramString1, String paramString2) { paramStringBuffer.append(paramString1).append(": ").append(paramString2).append("\r\n"); }
  
  void setError(Throwable paramThrowable) throws IOException {
    this.error = paramThrowable;
    close();
  }
  
  private void connect() throws IOException {
    this.state = CONNECTING;
    this.channel = SocketChannel.open();
    this.channel.configureBlocking(false);
    this.channel.connect(this.socketAddress);
    this.selector.register(this);
    while (!this.channel.finishConnect());
  }
  
  SocketChannel getChannel() { return this.channel; }
  
  void close() throws IOException {
    this.selector.unregister(this);
    if (this.channel != null)
      this.channel.close(); 
  }
  
  void read(ByteBuffer paramByteBuffer) throws IOException {
    paramByteBuffer.flip();
    this.response.addData(paramByteBuffer);
    paramByteBuffer.clear();
    System.out.println(this.response);
    this.response.parse();
    System.out.println(this.response);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\HttpConnection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */