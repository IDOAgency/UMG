/*     */ package weblogic.webservice.binding.httpnb;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.CharsetDecoder;
/*     */ import java.nio.charset.CharsetEncoder;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HttpConnection
/*     */ {
/*  32 */   private static int INIT = 0;
/*  33 */   private static int CONNECTING = 1;
/*     */   private InetSocketAddress socketAddress;
/*     */   private CharsetDecoder decoder;
/*     */   private CharsetEncoder encoder;
/*     */   private SocketChannel channel;
/*     */   private ConnectionSelector selector;
/*     */   
/*     */   HttpConnection(String paramString1, int paramInt, String paramString2, ConnectionSelector paramConnectionSelector) {
/*  41 */     this.state = INIT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     this.selector = paramConnectionSelector;
/*  55 */     this.socketAddress = new InetSocketAddress(paramString1, paramInt);
/*     */ 
/*     */     
/*  58 */     Charset charset = Charset.forName(paramString2);
/*  59 */     this.decoder = charset.newDecoder();
/*  60 */     this.encoder = charset.newEncoder();
/*  61 */     this.response = new HttpResponse(this);
/*     */   }
/*     */   private int state; private String uriToSend;
/*     */   private HashMap headersToSend;
/*     */   
/*     */   public void send(String paramString, HashMap paramHashMap, byte[] paramArrayOfByte) throws IOException {
/*  67 */     this.uriToSend = paramString;
/*  68 */     this.headersToSend = paramHashMap;
/*  69 */     this.envelopeToSend = paramArrayOfByte;
/*     */     
/*  71 */     if (isConnected()) {
/*  72 */       connect();
/*     */     }
/*     */     
/*  75 */     write();
/*     */   }
/*     */   private byte[] envelopeToSend; private Throwable error; private HttpResponse response;
/*     */   
/*  79 */   private boolean isConnected() { return (this.channel == null); }
/*     */ 
/*     */ 
/*     */   
/*     */   void write() throws IOException {
/*  84 */     StringBuffer stringBuffer = createRequestLine();
/*     */     
/*  86 */     if (this.headersToSend != null) {
/*     */       
/*  88 */       this.headersToSend.put("Connection", "Keep-Alive");
/*     */       
/*  90 */       if (this.envelopeToSend != null) {
/*  91 */         this.headersToSend.put("Content-Length", "" + this.envelopeToSend.length);
/*     */       }
/*     */       
/*  94 */       addHeaders(stringBuffer);
/*     */     } 
/*     */     
/*  97 */     stringBuffer.append("\r\n");
/*     */     
/*  99 */     this.channel.write(this.encoder.encode(CharBuffer.wrap(stringBuffer.toString())));
/* 100 */     this.channel.write(ByteBuffer.wrap(this.envelopeToSend));
/*     */   }
/*     */ 
/*     */   
/*     */   private StringBuffer createRequestLine() {
/* 105 */     StringBuffer stringBuffer = new StringBuffer();
/* 106 */     stringBuffer.append("POST ");
/* 107 */     stringBuffer.append(this.uriToSend);
/* 108 */     stringBuffer.append(" HTTP/1.0\r\n");
/*     */     
/* 110 */     return stringBuffer;
/*     */   }
/*     */   
/*     */   private void addHeaders(StringBuffer paramStringBuffer) {
/* 114 */     for (Map.Entry entry : this.headersToSend.entrySet()) {
/*     */ 
/*     */       
/* 117 */       String str1 = (String)entry.getKey();
/* 118 */       String str2 = (String)entry.getValue();
/*     */       
/* 120 */       addHeader(paramStringBuffer, str1, str2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 125 */   private void addHeader(StringBuffer paramStringBuffer, String paramString1, String paramString2) { paramStringBuffer.append(paramString1).append(": ").append(paramString2).append("\r\n"); }
/*     */ 
/*     */   
/*     */   void setError(Throwable paramThrowable) throws IOException {
/* 129 */     this.error = paramThrowable;
/* 130 */     close();
/*     */   }
/*     */   
/*     */   private void connect() throws IOException {
/* 134 */     this.state = CONNECTING;
/*     */     
/* 136 */     this.channel = SocketChannel.open();
/* 137 */     this.channel.configureBlocking(false);
/* 138 */     this.channel.connect(this.socketAddress);
/*     */     
/* 140 */     this.selector.register(this);
/*     */     
/* 142 */     while (!this.channel.finishConnect());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   SocketChannel getChannel() { return this.channel; }
/*     */ 
/*     */   
/*     */   void close() throws IOException {
/* 152 */     this.selector.unregister(this);
/*     */     
/* 154 */     if (this.channel != null) {
/* 155 */       this.channel.close();
/*     */     }
/*     */   }
/*     */   
/*     */   void read(ByteBuffer paramByteBuffer) throws IOException {
/* 160 */     paramByteBuffer.flip();
/* 161 */     this.response.addData(paramByteBuffer);
/* 162 */     paramByteBuffer.clear();
/* 163 */     System.out.println(this.response);
/*     */     
/* 165 */     this.response.parse();
/* 166 */     System.out.println(this.response);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\HttpConnection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */