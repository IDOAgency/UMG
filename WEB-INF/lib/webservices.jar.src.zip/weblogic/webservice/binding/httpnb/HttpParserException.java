/*    */ package weblogic.webservice.binding.httpnb;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpParserException
/*    */   extends IOException
/*    */ {
/* 17 */   public HttpParserException(String paramString) { super(paramString); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\HttpParserException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */