/*    */ package weblogic.webservice.binding.httpnb;
/*    */ 
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ import weblogic.webservice.binding.AbstractBinding;
/*    */ import weblogic.webservice.binding.BindingInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpNonBlockingBinding
/*    */   extends AbstractBinding
/*    */ {
/*    */   private BindingInfo info;
/*    */   private ResponseListener listener;
/*    */   
/* 25 */   public void init(BindingInfo paramBindingInfo) { this.info = paramBindingInfo; }
/*    */ 
/*    */ 
/*    */   
/*    */   public void send(MessageContext paramMessageContext) {}
/*    */ 
/*    */   
/* 32 */   public void setListener(ResponseListener paramResponseListener) { this.listener = paramResponseListener; }
/*    */   
/*    */   public void receive(MessageContext paramMessageContext) {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\HttpNonBlockingBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */