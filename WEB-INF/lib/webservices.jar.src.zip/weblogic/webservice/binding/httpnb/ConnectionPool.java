package weblogic.webservice.binding.httpnb;

import java.io.IOException;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;
import weblogic.webservice.WebServiceLogger;

public final class ConnectionPool extends TimerTask {
  private static final boolean debug = false;
  
  private static final boolean verbose = false;
  
  private static final ConnectionPool theOne = new ConnectionPool(16);
  
  private static final long DEFAULT_KEEP_ALIVE_TIMEOUT = 15L;
  
  private static final String KEEP_ALIVE_PROP = "weblogic.http.KeepAliveTimeoutSeconds";
  
  private HttpConnectionHolder[] pool;
  
  private boolean useKeepAlive;
  
  private ConnectionPool(int paramInt) {
    this.useKeepAlive = true;
    this.pool = new HttpConnectionHolder[paramInt];
    long l = 15L;
    String str = System.getProperty("weblogic.http.KeepAliveTimeoutSeconds");
    if (str != null)
      try {
        l = (new Long(str)).longValue();
      } catch (NumberFormatException numberFormatException) {
        WebServiceLogger.logInvalidKeepAlive("weblogic.http.KeepAliveTimeoutSeconds", str, "15 seconds");
      }  
    l *= 500L;
    if (l == 0L)
      this.useKeepAlive = false; 
    if (this.useKeepAlive)
      (new Timer(true)).scheduleAtFixedRate(this, l, l); 
  }
  
  public void run() {
    synchronized (this.pool) {
      for (byte b = 0; b < this.pool.length; b++) {
        HttpConnectionHolder httpConnectionHolder = this.pool[b];
        if (httpConnectionHolder != null)
          if (httpConnectionHolder.mark) {
            HttpConnection httpConnection = httpConnectionHolder.connection;
            cleanup(httpConnection);
            this.pool[b] = null;
          } else {
            httpConnectionHolder.mark = true;
          }  
      } 
    } 
  }
  
  private void cleanup(HttpConnection paramHttpConnection) {
    try {
      paramHttpConnection.close();
    } catch (IOException iOException) {}
  }
  
  public static ConnectionPool getConnectionPool() { return theOne; }
  
  public HttpConnection getConnection(URL paramURL) {
    if (!this.useKeepAlive)
      return null; 
    synchronized (this.pool) {
      for (byte b = 0; b < this.pool.length; b++) {
        HttpConnectionHolder httpConnectionHolder = this.pool[b];
        if (httpConnectionHolder != null && httpConnectionHolder.url.equals(paramURL)) {
          this.pool[b] = null;
          return httpConnectionHolder.connection;
        } 
      } 
    } 
    return null;
  }
  
  public boolean releaseConnection(URL paramURL, HttpConnection paramHttpConnection) {
    if (!this.useKeepAlive) {
      cleanup(paramHttpConnection);
      return false;
    } 
    HttpConnectionHolder httpConnectionHolder = new HttpConnectionHolder(paramURL, paramHttpConnection, null);
    synchronized (this.pool) {
      for (byte b = 0; b < this.pool.length; b++) {
        if (this.pool[b] == null) {
          this.pool[b] = httpConnectionHolder;
          return true;
        } 
      } 
    } 
    return false;
  }
  
  private static class HttpConnectionHolder {
    private URL url;
    
    private HttpConnection connection;
    
    private HttpConnectionHolder(URL param1URL, HttpConnection param1HttpConnection) {
      this.url = param1URL;
      this.connection = param1HttpConnection;
      this.mark = false;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\ConnectionPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */