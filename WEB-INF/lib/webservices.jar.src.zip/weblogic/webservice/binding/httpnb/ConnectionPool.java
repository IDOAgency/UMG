/*     */ package weblogic.webservice.binding.httpnb;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectionPool
/*     */   extends TimerTask
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   private static final boolean verbose = false;
/*  26 */   private static final ConnectionPool theOne = new ConnectionPool(16);
/*     */   
/*     */   private static final long DEFAULT_KEEP_ALIVE_TIMEOUT = 15L;
/*     */   private static final String KEEP_ALIVE_PROP = "weblogic.http.KeepAliveTimeoutSeconds";
/*     */   private HttpConnectionHolder[] pool;
/*     */   private boolean useKeepAlive;
/*     */   
/*     */   private ConnectionPool(int paramInt) {
/*  34 */     this.useKeepAlive = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  42 */     this.pool = new HttpConnectionHolder[paramInt];
/*     */     
/*  44 */     long l = 15L;
/*  45 */     String str = System.getProperty("weblogic.http.KeepAliveTimeoutSeconds");
/*     */     
/*  47 */     if (str != null) {
/*     */       try {
/*  49 */         l = (new Long(str)).longValue();
/*  50 */       } catch (NumberFormatException numberFormatException) {
/*  51 */         WebServiceLogger.logInvalidKeepAlive("weblogic.http.KeepAliveTimeoutSeconds", str, "15 seconds");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     l *= 500L;
/*     */     
/*  62 */     if (l == 0L) {
/*  63 */       this.useKeepAlive = false;
/*     */     }
/*     */     
/*  66 */     if (this.useKeepAlive) {
/*  67 */       (new Timer(true)).scheduleAtFixedRate(this, l, l);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  73 */     synchronized (this.pool) {
/*     */       
/*  75 */       for (byte b = 0; b < this.pool.length; b++) {
/*     */         
/*  77 */         HttpConnectionHolder httpConnectionHolder = this.pool[b];
/*     */         
/*  79 */         if (httpConnectionHolder != null)
/*     */         {
/*  81 */           if (httpConnectionHolder.mark) {
/*  82 */             HttpConnection httpConnection = httpConnectionHolder.connection;
/*  83 */             cleanup(httpConnection);
/*  84 */             this.pool[b] = null;
/*     */           } else {
/*  86 */             httpConnectionHolder.mark = true;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cleanup(HttpConnection paramHttpConnection) {
/*     */     try {
/*  95 */       paramHttpConnection.close();
/*  96 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */   
/* 100 */   public static ConnectionPool getConnectionPool() { return theOne; }
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpConnection getConnection(URL paramURL) {
/* 105 */     if (!this.useKeepAlive) {
/* 106 */       return null;
/*     */     }
/*     */     
/* 109 */     synchronized (this.pool) {
/*     */       
/* 111 */       for (byte b = 0; b < this.pool.length; b++) {
/* 112 */         HttpConnectionHolder httpConnectionHolder = this.pool[b];
/*     */         
/* 114 */         if (httpConnectionHolder != null && httpConnectionHolder.url.equals(paramURL)) {
/* 115 */           this.pool[b] = null;
/* 116 */           return httpConnectionHolder.connection;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean releaseConnection(URL paramURL, HttpConnection paramHttpConnection) {
/* 127 */     if (!this.useKeepAlive) {
/* 128 */       cleanup(paramHttpConnection);
/* 129 */       return false;
/*     */     } 
/*     */     
/* 132 */     HttpConnectionHolder httpConnectionHolder = new HttpConnectionHolder(paramURL, paramHttpConnection, null);
/*     */     
/* 134 */     synchronized (this.pool) {
/*     */       
/* 136 */       for (byte b = 0; b < this.pool.length; b++) {
/*     */         
/* 138 */         if (this.pool[b] == null) {
/* 139 */           this.pool[b] = httpConnectionHolder;
/* 140 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HttpConnectionHolder
/*     */   {
/*     */     private URL url;
/*     */     private HttpConnection connection;
/*     */     
/*     */     private HttpConnectionHolder(URL param1URL, HttpConnection param1HttpConnection) {
/* 155 */       this.url = param1URL;
/* 156 */       this.connection = param1HttpConnection;
/* 157 */       this.mark = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\ConnectionPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */