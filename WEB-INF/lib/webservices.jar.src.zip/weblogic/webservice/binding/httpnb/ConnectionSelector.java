package weblogic.webservice.binding.httpnb;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import weblogic.utils.Debug;
import weblogic.webservice.async.ThreadPool;

public class ConnectionSelector implements Runnable {
  private Selector selector;
  
  private boolean close;
  
  private ArrayList toUnregister;
  
  private ArrayList toRegister;
  
  private ThreadPool threadPool;
  
  private ByteBuffer buffer;
  
  ConnectionSelector(ThreadPool paramThreadPool) throws IOException {
    this.close = false;
    this.toUnregister = new ArrayList();
    this.toRegister = new ArrayList();
    this.buffer = ByteBuffer.allocateDirect(1024);
    this.threadPool = paramThreadPool;
    this.selector = Selector.open();
    this.threadPool.addTask(this);
  }
  
  void register(HttpConnection paramHttpConnection) throws IOException {
    this.toRegister.add(paramHttpConnection);
    this.selector.wakeup();
  }
  
  void unregister(HttpConnection paramHttpConnection) throws IOException { this.toUnregister.add(paramHttpConnection); }
  
  public void close() {
    this.close = true;
    this.selector.wakeup();
  }
  
  public void run() {
    try {
      select();
    } catch (Throwable throwable) {
      close();
      System.out.println(throwable);
      throwable.printStackTrace();
    } 
  }
  
  public void select() {
    if (this.selector.select() > 0) {
      Set set = this.selector.selectedKeys();
      Iterator iterator1 = set.iterator();
      while (iterator1.hasNext()) {
        SelectionKey selectionKey = (SelectionKey)iterator1.next();
        iterator1.remove();
        HttpConnection httpConnection = (HttpConnection)selectionKey.attachment();
        if (selectionKey.isConnectable()) {
          handleConnection(httpConnection);
          continue;
        } 
        if (selectionKey.isReadable()) {
          handleRead(httpConnection);
          continue;
        } 
        Debug.say("(Internal error: unknow key):" + selectionKey);
      } 
    } 
    for (Iterator iterator = this.toRegister.iterator(); iterator.hasNext(); ) {
      HttpConnection httpConnection = (HttpConnection)iterator.next();
      iterator.remove();
      httpConnection.getChannel().register(this.selector, 1, httpConnection);
    } 
    this.threadPool.addTask(this);
  }
  
  private void handleConnection(HttpConnection paramHttpConnection) throws IOException {
    try {
      boolean bool = false;
      while (!bool)
        bool = paramHttpConnection.getChannel().finishConnect(); 
      if (bool)
        paramHttpConnection.write(); 
    } catch (IOException iOException) {
      try {
        paramHttpConnection.setError(iOException);
      } catch (IOException iOException1) {
        iOException1.printStackTrace();
      } 
    } 
  }
  
  private void handleRead(HttpConnection paramHttpConnection) throws IOException {
    try {
      int i = paramHttpConnection.getChannel().read(this.buffer);
      if (i == -1) {
        paramHttpConnection.close();
      } else if (i > 0) {
        paramHttpConnection.read(this.buffer);
      } 
    } catch (IOException iOException) {
      try {
        paramHttpConnection.setError(iOException);
      } catch (IOException iOException1) {
        iOException1.printStackTrace();
      } 
    } 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    String str = "<?xml version=\"1.0\" encoding=\"utf-8\"?> \n <soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soapenc='http://schemas.xmlsoap.org/soap/encoding/' xmlns:tns='http://soapinterop.org/' xmlns:types='http://soapinterop.org/encodedTypes' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'> <soap:Body soap:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'> <tns:echoString> <inputString xsi:type='xsd:string'>string</inputString> </tns:echoString> </soap:Body> </soap:Envelope>";
    HashMap hashMap = new HashMap();
    hashMap.put("Host", "www.mssoapinterop.org");
    hashMap.put("Content-Type", "text/xml");
    hashMap.put("SOAPAction", "\"http://soapinterop.org/\"");
    ConnectionSelector connectionSelector = new ConnectionSelector(new ThreadPool(1));
    HttpConnection httpConnection = new HttpConnection(paramArrayOfString[0], 80, "ASCII", connectionSelector);
    httpConnection.send("/asmx/simple.asmx", hashMap, str.getBytes());
    while (true) {
      try {
        while (true)
          Thread.sleep(500L); 
        break;
      } catch (Exception exception) {}
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\ConnectionSelector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */