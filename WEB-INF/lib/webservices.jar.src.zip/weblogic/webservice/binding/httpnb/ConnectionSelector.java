/*     */ package weblogic.webservice.binding.httpnb;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.async.ThreadPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConnectionSelector
/*     */   implements Runnable
/*     */ {
/*     */   private Selector selector;
/*     */   private boolean close;
/*     */   private ArrayList toUnregister;
/*     */   private ArrayList toRegister;
/*     */   private ThreadPool threadPool;
/*     */   private ByteBuffer buffer;
/*     */   
/*     */   ConnectionSelector(ThreadPool paramThreadPool) throws IOException {
/*  28 */     this.close = false;
/*     */     
/*  30 */     this.toUnregister = new ArrayList();
/*  31 */     this.toRegister = new ArrayList();
/*     */ 
/*     */     
/*  34 */     this.buffer = ByteBuffer.allocateDirect(1024);
/*     */ 
/*     */     
/*  37 */     this.threadPool = paramThreadPool;
/*  38 */     this.selector = Selector.open();
/*  39 */     this.threadPool.addTask(this);
/*     */   }
/*     */   
/*     */   void register(HttpConnection paramHttpConnection) throws IOException {
/*  43 */     this.toRegister.add(paramHttpConnection);
/*  44 */     this.selector.wakeup();
/*     */   }
/*     */ 
/*     */   
/*  48 */   void unregister(HttpConnection paramHttpConnection) throws IOException { this.toUnregister.add(paramHttpConnection); }
/*     */ 
/*     */   
/*     */   public void close() {
/*  52 */     this.close = true;
/*  53 */     this.selector.wakeup();
/*     */   }
/*     */   
/*     */   public void run() {
/*     */     try {
/*  58 */       select();
/*  59 */     } catch (Throwable throwable) {
/*  60 */       close();
/*  61 */       System.out.println(throwable);
/*  62 */       throwable.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void select() {
/*  68 */     if (this.selector.select() > 0) {
/*  69 */       Set set = this.selector.selectedKeys();
/*     */       
/*  71 */       Iterator iterator1 = set.iterator();
/*     */       
/*  73 */       while (iterator1.hasNext()) {
/*  74 */         SelectionKey selectionKey = (SelectionKey)iterator1.next();
/*  75 */         iterator1.remove();
/*     */         
/*  77 */         HttpConnection httpConnection = (HttpConnection)selectionKey.attachment();
/*     */         
/*  79 */         if (selectionKey.isConnectable()) {
/*     */ 
/*     */           
/*  82 */           handleConnection(httpConnection); continue;
/*  83 */         }  if (selectionKey.isReadable()) {
/*  84 */           handleRead(httpConnection); continue;
/*     */         } 
/*  86 */         Debug.say("(Internal error: unknow key):" + selectionKey);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  91 */     for (Iterator iterator = this.toRegister.iterator(); iterator.hasNext(); ) {
/*  92 */       HttpConnection httpConnection = (HttpConnection)iterator.next();
/*  93 */       iterator.remove();
/*     */       
/*  95 */       httpConnection.getChannel().register(this.selector, 1, httpConnection);
/*     */     } 
/*     */ 
/*     */     
/*  99 */     this.threadPool.addTask(this);
/*     */   }
/*     */   
/*     */   private void handleConnection(HttpConnection paramHttpConnection) throws IOException {
/*     */     try {
/* 104 */       boolean bool = false;
/*     */       
/* 106 */       while (!bool) {
/* 107 */         bool = paramHttpConnection.getChannel().finishConnect();
/*     */       }
/*     */       
/* 110 */       if (bool) {
/* 111 */         paramHttpConnection.write();
/*     */       }
/* 113 */     } catch (IOException iOException) {
/*     */       try {
/* 115 */         paramHttpConnection.setError(iOException);
/* 116 */       } catch (IOException iOException1) {
/* 117 */         iOException1.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleRead(HttpConnection paramHttpConnection) throws IOException {
/*     */     try {
/* 124 */       int i = paramHttpConnection.getChannel().read(this.buffer);
/*     */       
/* 126 */       if (i == -1) {
/* 127 */         paramHttpConnection.close();
/* 128 */       } else if (i > 0) {
/* 129 */         paramHttpConnection.read(this.buffer);
/*     */       }
/*     */     
/* 132 */     } catch (IOException iOException) {
/*     */       try {
/* 134 */         paramHttpConnection.setError(iOException);
/* 135 */       } catch (IOException iOException1) {
/* 136 */         iOException1.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 143 */     String str = "<?xml version=\"1.0\" encoding=\"utf-8\"?> \n <soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soapenc='http://schemas.xmlsoap.org/soap/encoding/' xmlns:tns='http://soapinterop.org/' xmlns:types='http://soapinterop.org/encodedTypes' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'> <soap:Body soap:encodingStyle='http://schemas.xmlsoap.org/soap/encoding/'> <tns:echoString> <inputString xsi:type='xsd:string'>string</inputString> </tns:echoString> </soap:Body> </soap:Envelope>";
/*     */     
/* 145 */     HashMap hashMap = new HashMap();
/* 146 */     hashMap.put("Host", "www.mssoapinterop.org");
/* 147 */     hashMap.put("Content-Type", "text/xml");
/* 148 */     hashMap.put("SOAPAction", "\"http://soapinterop.org/\"");
/*     */ 
/*     */     
/* 151 */     ConnectionSelector connectionSelector = new ConnectionSelector(new ThreadPool(1));
/*     */     
/* 153 */     HttpConnection httpConnection = new HttpConnection(paramArrayOfString[0], 80, "ASCII", connectionSelector);
/*     */ 
/*     */     
/* 156 */     httpConnection.send("/asmx/simple.asmx", hashMap, str.getBytes());
/*     */     
/*     */     while (true) {
/*     */       try {
/*     */         while (true)
/* 161 */           Thread.sleep(500L);  break;
/* 162 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\ConnectionSelector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */