package weblogic.webservice.binding.httpnb;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import weblogic.utils.Debug;
import weblogic.utils.io.Chunk;
import weblogic.utils.io.ChunkedInputStream;

public class HttpResponse {
  private HttpConnection connection;
  
  private HashMap headers;
  
  private String message;
  
  private int statusCode;
  
  private int minorVersion;
  
  private int majorVersion;
  
  private String contentType;
  
  private int contentLength;
  
  private static final char[] STATUS = { 'H', 'T', 'T', 'P', '/' };
  
  private static final int INIT = 0;
  
  private static final int HEADER = 1;
  
  private static final int BODY = 2;
  
  private static final String CONTENT_TYPE = "CONTENT-TYPE";
  
  private static final String CONTENT_LENGTH = "CONTENT-LENGTH";
  
  private int state;
  
  private Chunk last;
  
  private ChunkedInputStream stream;
  
  private static final boolean debug = true;
  
  HttpResponse(HttpConnection paramHttpConnection) {
    this.headers = new HashMap();
    this.contentLength = -1;
    this.state = 0;
    this.connection = paramHttpConnection;
  }
  
  public void addData(ByteBuffer paramByteBuffer) {
    if (this.last == null) {
      this.last = Chunk.getChunk();
      this.stream = new ChunkedInputStream(this.last, 0);
    } 
    int i;
    while ((i = paramByteBuffer.remaining()) > 0) {
      this.last;
      int j = Chunk.CHUNK_SIZE - this.last.end;
      if (j == 0) {
        this.last = newChunk(this.last);
        this.last;
        j = Chunk.CHUNK_SIZE;
      } 
      int k = (i < j) ? i : j;
      paramByteBuffer.get(this.last.buf, this.last.end, k);
      this.last.end += k;
    } 
  }
  
  private Chunk newChunk(Chunk paramChunk) {
    Chunk chunk = Chunk.getChunk();
    paramChunk.next = chunk;
    return chunk;
  }
  
  public void parse() throws IOException {
    if (this.state == 0)
      parseResponseLine(); 
    if (this.state == 1) {
      parseHeaders();
      updateHeaderState();
    } 
    if (this.state == 2)
      parseBody(); 
  }
  
  private void parseBody() throws IOException {
    Debug.assertion((this.stream != null));
    Debug.assertion((this.state == 2));
    if (this.contentLength > -1) {
      int i = this.stream.available();
      if (i == this.contentLength);
      if (i > this.contentLength)
        throw new HttpParserException("Got more data than content length "); 
    } 
  }
  
  private void parseHeaders() throws IOException {
    Debug.assertion((this.stream != null));
    Debug.assertion((this.state == 1));
    boolean bool = true;
    while (true) {
      StringBuffer stringBuffer1 = new StringBuffer();
      StringBuffer stringBuffer2 = new StringBuffer();
      boolean bool1 = parseHeader(stringBuffer1, stringBuffer2);
      if (bool1) {
        if (stringBuffer1.length() == 0) {
          this.state = 2;
          return;
        } 
        this.headers.put(stringBuffer1.toString().trim().toUpperCase(), stringBuffer2.toString().trim());
      } 
    } 
  }
  
  private void updateHeaderState() throws IOException {
    String str = (String)this.headers.get("CONTENT-LENGTH");
    if (str != null)
      this.contentLength = Integer.parseInt(str); 
    this.contentType = (String)this.headers.get("CONTENT-TYPE");
  }
  
  private boolean parseHeader(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2) throws IOException {
    byte b = 0;
    boolean bool = true;
    while (true) {
      int i;
      if ((i = this.stream.peek(b++)) == -1)
        return false; 
      if (i == 13)
        continue; 
      if (i == 10) {
        this.stream.skip(b);
        return true;
      } 
      if (i == 58) {
        bool = false;
        continue;
      } 
      if (bool) {
        paramStringBuffer1.append((char)i);
        continue;
      } 
      paramStringBuffer2.append((char)i);
    } 
  }
  
  private void parseResponseLine() throws IOException {
    Debug.assertion((this.stream != null));
    Debug.assertion((this.state == 0));
    byte b = 0;
    int j;
    for (j = 0; j < STATUS.length; j++) {
      int n = this.stream.peek(b);
      b++;
      if (n == -1)
        return; 
      if (n != STATUS[j])
        throw new HttpParserException("Not an HTTP request : " + toString()); 
    } 
    int i;
    if ((i = this.stream.peek(b++)) == -1)
      return; 
    this.majorVersion = i - 48;
    if ((i = this.stream.peek(b++)) == -1)
      return; 
    if ((i = this.stream.peek(b++)) == -1)
      return; 
    this.minorVersion = i - 48;
    if ((i = this.stream.peek(b++)) == -1)
      return; 
    if ((i = this.stream.peek(b++)) == -1)
      return; 
    j = i;
    if ((i = this.stream.peek(b++)) == -1)
      return; 
    int k = i;
    if ((i = this.stream.peek(b++)) == -1)
      return; 
    int m = i;
    this.statusCode = (j - 48) * 100 + (k - 48) * 10 + m - 48;
    StringBuffer stringBuffer = new StringBuffer();
    while (true) {
      if ((i = this.stream.peek(b++)) == -1)
        return; 
      if (i == 10)
        break; 
      stringBuffer.append((char)i);
    } 
    this.message = stringBuffer.toString().trim();
    this.state = 1;
    this.stream.skip(b);
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(getClass().getName());
    stringBuffer.append("[ID=");
    stringBuffer.append(System.identityHashCode(this));
    stringBuffer.append("]");
    stringBuffer.append("[Size=").append(this.stream.available()).append("]");
    stringBuffer.append("[statusCode=").append(this.statusCode).append("]");
    stringBuffer.append("[minorVersion=").append(this.minorVersion).append("]");
    stringBuffer.append("[majorVersion=").append(this.majorVersion).append("]");
    stringBuffer.append("[message=").append(this.message).append("]");
    stringBuffer.append("[Content-Type=").append(this.contentType).append("]");
    stringBuffer.append("[Content-Length=").append(this.contentLength).append("]");
    stringBuffer.append("[Headers").append("]{\n");
    for (Map.Entry entry : this.headers.entrySet()) {
      stringBuffer.append(entry.getKey()).append(": ").append(entry.getValue());
      stringBuffer.append("\n");
    } 
    stringBuffer.append("\n}\n");
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\HttpResponse.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */