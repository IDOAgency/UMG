/*     */ package weblogic.webservice.binding.httpnb;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.utils.io.Chunk;
/*     */ import weblogic.utils.io.ChunkedInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpResponse
/*     */ {
/*     */   private HttpConnection connection;
/*     */   private HashMap headers;
/*     */   private String message;
/*     */   private int statusCode;
/*     */   private int minorVersion;
/*     */   private int majorVersion;
/*     */   private String contentType;
/*     */   private int contentLength;
/*  37 */   private static final char[] STATUS = { 'H', 'T', 'T', 'P', '/' };
/*     */   private static final int INIT = 0;
/*     */   private static final int HEADER = 1;
/*     */   private static final int BODY = 2;
/*     */   private static final String CONTENT_TYPE = "CONTENT-TYPE";
/*     */   
/*     */   HttpResponse(HttpConnection paramHttpConnection) {
/*     */     this.headers = new HashMap();
/*     */     this.contentLength = -1;
/*  46 */     this.state = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     this.connection = paramHttpConnection;
/*     */   }
/*     */   private static final String CONTENT_LENGTH = "CONTENT-LENGTH"; private int state; private Chunk last; private ChunkedInputStream stream; private static final boolean debug = true;
/*     */   
/*     */   public void addData(ByteBuffer paramByteBuffer) {
/*  61 */     if (this.last == null) {
/*  62 */       this.last = Chunk.getChunk();
/*  63 */       this.stream = new ChunkedInputStream(this.last, 0);
/*     */     } 
/*     */     
/*     */     int i;
/*     */     
/*  68 */     while ((i = paramByteBuffer.remaining()) > 0) {
/*     */       
/*  70 */       this.last; int j = Chunk.CHUNK_SIZE - this.last.end;
/*     */       
/*  72 */       if (j == 0) {
/*  73 */         this.last = newChunk(this.last);
/*  74 */         this.last; j = Chunk.CHUNK_SIZE;
/*     */       } 
/*     */       
/*  77 */       int k = (i < j) ? i : j;
/*  78 */       paramByteBuffer.get(this.last.buf, this.last.end, k);
/*  79 */       this.last.end += k;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Chunk newChunk(Chunk paramChunk) {
/*  84 */     Chunk chunk = Chunk.getChunk();
/*  85 */     paramChunk.next = chunk;
/*  86 */     return chunk;
/*     */   }
/*     */   
/*     */   public void parse() throws IOException {
/*  90 */     if (this.state == 0) {
/*  91 */       parseResponseLine();
/*     */     }
/*     */     
/*  94 */     if (this.state == 1) {
/*  95 */       parseHeaders();
/*  96 */       updateHeaderState();
/*     */     } 
/*     */     
/*  99 */     if (this.state == 2) {
/* 100 */       parseBody();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseBody() throws IOException {
/* 106 */     Debug.assertion((this.stream != null));
/* 107 */     Debug.assertion((this.state == 2));
/*     */ 
/*     */     
/* 110 */     if (this.contentLength > -1) {
/* 111 */       int i = this.stream.available();
/*     */       
/* 113 */       if (i == this.contentLength);
/*     */ 
/*     */       
/* 116 */       if (i > this.contentLength) {
/* 117 */         throw new HttpParserException("Got more data than content length ");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseHeaders() throws IOException {
/* 124 */     Debug.assertion((this.stream != null));
/* 125 */     Debug.assertion((this.state == 1));
/*     */ 
/*     */ 
/*     */     
/* 129 */     boolean bool = true;
/*     */ 
/*     */     
/*     */     while (true) {
/* 133 */       StringBuffer stringBuffer1 = new StringBuffer();
/* 134 */       StringBuffer stringBuffer2 = new StringBuffer();
/*     */       
/* 136 */       boolean bool1 = parseHeader(stringBuffer1, stringBuffer2);
/*     */       
/* 138 */       if (bool1) {
/* 139 */         if (stringBuffer1.length() == 0) {
/* 140 */           this.state = 2;
/*     */           
/*     */           return;
/*     */         } 
/* 144 */         this.headers.put(stringBuffer1.toString().trim().toUpperCase(), stringBuffer2.toString().trim());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void updateHeaderState() throws IOException {
/* 151 */     String str = (String)this.headers.get("CONTENT-LENGTH");
/*     */     
/* 153 */     if (str != null) {
/* 154 */       this.contentLength = Integer.parseInt(str);
/*     */     }
/*     */     
/* 157 */     this.contentType = (String)this.headers.get("CONTENT-TYPE");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean parseHeader(StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2) throws IOException {
/* 164 */     byte b = 0;
/* 165 */     boolean bool = true;
/*     */     while (true) {
/*     */       int i;
/* 168 */       if ((i = this.stream.peek(b++)) == -1) return false;
/*     */       
/* 170 */       if (i == 13) {
/*     */         continue;
/*     */       }
/*     */       
/* 174 */       if (i == 10) {
/* 175 */         this.stream.skip(b);
/* 176 */         return true;
/*     */       } 
/*     */       
/* 179 */       if (i == 58) {
/* 180 */         bool = false;
/*     */         
/*     */         continue;
/*     */       } 
/* 184 */       if (bool) {
/* 185 */         paramStringBuffer1.append((char)i); continue;
/*     */       } 
/* 187 */       paramStringBuffer2.append((char)i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseResponseLine() throws IOException {
/* 195 */     Debug.assertion((this.stream != null));
/* 196 */     Debug.assertion((this.state == 0));
/*     */ 
/*     */     
/* 199 */     byte b = 0;
/*     */     
/*     */     int j;
/*     */     
/* 203 */     for (j = 0; j < STATUS.length; j++) {
/* 204 */       int n = this.stream.peek(b);
/* 205 */       b++;
/*     */       
/* 207 */       if (n == -1) {
/*     */         return;
/*     */       }
/*     */       
/* 211 */       if (n != STATUS[j]) {
/* 212 */         throw new HttpParserException("Not an HTTP request : " + toString());
/*     */       }
/*     */     } 
/*     */     
/*     */     int i;
/*     */     
/* 218 */     if ((i = this.stream.peek(b++)) == -1)
/* 219 */       return;  this.majorVersion = i - 48;
/*     */ 
/*     */     
/* 222 */     if ((i = this.stream.peek(b++)) == -1)
/*     */       return; 
/* 224 */     if ((i = this.stream.peek(b++)) == -1)
/* 225 */       return;  this.minorVersion = i - 48;
/*     */ 
/*     */     
/* 228 */     if ((i = this.stream.peek(b++)) == -1) {
/*     */       return;
/*     */     }
/* 231 */     if ((i = this.stream.peek(b++)) == -1)
/* 232 */       return;  j = i;
/*     */     
/* 234 */     if ((i = this.stream.peek(b++)) == -1)
/* 235 */       return;  int k = i;
/*     */     
/* 237 */     if ((i = this.stream.peek(b++)) == -1)
/* 238 */       return;  int m = i;
/*     */     
/* 240 */     this.statusCode = (j - 48) * 100 + (k - 48) * 10 + m - 48;
/*     */     
/* 242 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*     */     while (true) {
/* 245 */       if ((i = this.stream.peek(b++)) == -1)
/*     */         return; 
/* 247 */       if (i == 10) {
/*     */         break;
/*     */       }
/*     */       
/* 251 */       stringBuffer.append((char)i);
/*     */     } 
/*     */     
/* 254 */     this.message = stringBuffer.toString().trim();
/* 255 */     this.state = 1;
/* 256 */     this.stream.skip(b);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 262 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 264 */     stringBuffer.append(getClass().getName());
/* 265 */     stringBuffer.append("[ID=");
/* 266 */     stringBuffer.append(System.identityHashCode(this));
/* 267 */     stringBuffer.append("]");
/*     */     
/* 269 */     stringBuffer.append("[Size=").append(this.stream.available()).append("]");
/* 270 */     stringBuffer.append("[statusCode=").append(this.statusCode).append("]");
/* 271 */     stringBuffer.append("[minorVersion=").append(this.minorVersion).append("]");
/* 272 */     stringBuffer.append("[majorVersion=").append(this.majorVersion).append("]");
/* 273 */     stringBuffer.append("[message=").append(this.message).append("]");
/* 274 */     stringBuffer.append("[Content-Type=").append(this.contentType).append("]");
/* 275 */     stringBuffer.append("[Content-Length=").append(this.contentLength).append("]");
/*     */     
/* 277 */     stringBuffer.append("[Headers").append("]{\n");
/*     */     
/* 279 */     for (Map.Entry entry : this.headers.entrySet()) {
/*     */       
/* 281 */       stringBuffer.append(entry.getKey()).append(": ").append(entry.getValue());
/* 282 */       stringBuffer.append("\n");
/*     */     } 
/*     */     
/* 285 */     stringBuffer.append("\n}\n");
/*     */     
/* 287 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\httpnb\HttpResponse.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */