package weblogic.webservice.binding.jms;

import java.util.HashMap;
import java.util.TimerTask;
import javax.jms.JMSException;
import javax.naming.NamingException;
import weblogic.utils.collections.StackPool;

public class ConnectionPool extends TimerTask {
  private static ConnectionPool instance = new ConnectionPool();
  
  private HashMap connections = new HashMap();
  
  public static ConnectionPool getInstance() { return instance; }
  
  public void close() {
    synchronized (this.connections) {
      for (StackPool stackPool : this.connections.values()) {
        JMSConnection jMSConnection;
        while ((jMSConnection = (JMSConnection)stackPool.remove()) != null) {
          try {
            jMSConnection.close();
          } catch (JMSException jMSException) {}
        } 
      } 
      this.connections.clear();
    } 
  }
  
  JMSConnection getConnection(JMSBindingInfo paramJMSBindingInfo) throws NamingException, JMSException {
    StackPool stackPool = (StackPool)this.connections.get(paramJMSBindingInfo);
    if (stackPool == null) {
      stackPool = new StackPool(32);
      this.connections.put(paramJMSBindingInfo, stackPool);
    } 
    JMSConnection jMSConnection = (JMSConnection)stackPool.remove();
    if (jMSConnection == null) {
      jMSConnection = new JMSConnection(paramJMSBindingInfo);
      jMSConnection.setPool(stackPool);
    } 
    return jMSConnection;
  }
  
  public void run() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\ConnectionPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */