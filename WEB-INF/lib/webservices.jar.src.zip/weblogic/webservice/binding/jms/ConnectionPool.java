/*    */ package weblogic.webservice.binding.jms;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.TimerTask;
/*    */ import javax.jms.JMSException;
/*    */ import javax.naming.NamingException;
/*    */ import weblogic.utils.collections.StackPool;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectionPool
/*    */   extends TimerTask
/*    */ {
/* 25 */   private static ConnectionPool instance = new ConnectionPool();
/*    */   
/* 27 */   private HashMap connections = new HashMap();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public static ConnectionPool getInstance() { return instance; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() {
/* 44 */     synchronized (this.connections) {
/* 45 */       for (StackPool stackPool : this.connections.values()) {
/*    */         JMSConnection jMSConnection;
/*    */ 
/*    */ 
/*    */         
/* 50 */         while ((jMSConnection = (JMSConnection)stackPool.remove()) != null) {
/*    */           try {
/* 52 */             jMSConnection.close();
/* 53 */           } catch (JMSException jMSException) {}
/*    */         } 
/*    */       } 
/*    */ 
/*    */ 
/*    */       
/* 59 */       this.connections.clear();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   JMSConnection getConnection(JMSBindingInfo paramJMSBindingInfo) throws NamingException, JMSException {
/* 69 */     StackPool stackPool = (StackPool)this.connections.get(paramJMSBindingInfo);
/*    */     
/* 71 */     if (stackPool == null) {
/* 72 */       stackPool = new StackPool(32);
/* 73 */       this.connections.put(paramJMSBindingInfo, stackPool);
/*    */     } 
/*    */     
/* 76 */     JMSConnection jMSConnection = (JMSConnection)stackPool.remove();
/*    */     
/* 78 */     if (jMSConnection == null) {
/* 79 */       jMSConnection = new JMSConnection(paramJMSBindingInfo);
/* 80 */       jMSConnection.setPool(stackPool);
/*    */     } 
/*    */     
/* 83 */     return jMSConnection;
/*    */   }
/*    */   
/*    */   public void run() {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\ConnectionPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */