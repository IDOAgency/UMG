package weblogic.webservice.binding.jms;

import javax.xml.rpc.JAXRPCException;
import weblogic.webservice.binding.BindingInfo;

public class JMSBindingInfo extends BindingInfo {
  private String host;
  
  private int port;
  
  private String factoryName;
  
  private String queueName;
  
  private String serviceURI;
  
  private static final boolean verbose = Boolean.getBoolean("weblogic.webservice.verbose");
  
  public static final String TRANSPORT = "http://www.openuri.org/2002/04/soap/jms/";
  
  public String getTransport() { return "jms"; }
  
  public void setAddress(String paramString) {
    parseAddress(paramString);
    super.setAddress(paramString);
  }
  
  public String getAddress() { return "jms://" + this.host + ":" + this.port + "/" + this.factoryName + "/" + this.queueName + "?URI=" + this.serviceURI; }
  
  public void setHost(String paramString) { this.host = paramString; }
  
  public String getHost() { return this.host; }
  
  public int getPort() { return this.port; }
  
  public void setPort(int paramInt) { this.port = paramInt; }
  
  public String getServiceURI() { return this.serviceURI; }
  
  public void setServiceURI(String paramString) { this.serviceURI = paramString; }
  
  public String getFactoryName() { return this.factoryName; }
  
  public String getQueueName() { return this.queueName; }
  
  private void throwParseError(String paramString) { throw new JAXRPCException("the address [" + paramString + "] is not " + "a JMS valid address. It should be of the from " + "'jms://host:port/factoryName/queueName?URI=serviceURI"); }
  
  private void parseAddress(String paramString) {
    if (!paramString.startsWith("jms://"))
      throwParseError(paramString); 
    String str = paramString.substring("jms://".length(), paramString.length());
    int i = str.indexOf(":");
    if (i == -1)
      throwParseError(paramString); 
    this.host = str.substring(0, i);
    str = str.substring(i + 1, str.length());
    i = str.indexOf("/");
    if (i == -1)
      throwParseError(paramString); 
    try {
      this.port = Integer.parseInt(str.substring(0, i));
    } catch (NumberFormatException numberFormatException) {
      if (verbose)
        numberFormatException.printStackTrace(); 
      throwParseError(paramString);
    } 
    str = str.substring(i + 1, str.length());
    i = str.indexOf("/");
    if (i == -1)
      throwParseError(paramString); 
    this.factoryName = str.substring(0, i);
    str = str.substring(i + 1, str.length());
    i = str.indexOf("?");
    if (i == -1)
      throwParseError(paramString); 
    this.queueName = str.substring(0, i);
    str = str.substring(i + 1, str.length());
    if (!str.startsWith("URI="))
      throwParseError(paramString); 
    this.serviceURI = str.substring("URI=".length());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\JMSBindingInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */