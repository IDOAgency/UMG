/*     */ package weblogic.webservice.binding.jms;
/*     */ 
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSBindingInfo
/*     */   extends BindingInfo
/*     */ {
/*     */   private String host;
/*     */   private int port;
/*     */   private String factoryName;
/*     */   private String queueName;
/*     */   private String serviceURI;
/*  22 */   private static final boolean verbose = Boolean.getBoolean("weblogic.webservice.verbose");
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String TRANSPORT = "http://www.openuri.org/2002/04/soap/jms/";
/*     */ 
/*     */ 
/*     */   
/*  30 */   public String getTransport() { return "jms"; }
/*     */ 
/*     */   
/*     */   public void setAddress(String paramString) {
/*  34 */     parseAddress(paramString);
/*  35 */     super.setAddress(paramString);
/*     */   }
/*     */ 
/*     */   
/*  39 */   public String getAddress() { return "jms://" + this.host + ":" + this.port + "/" + this.factoryName + "/" + this.queueName + "?URI=" + this.serviceURI; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public void setHost(String paramString) { this.host = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  48 */   public String getHost() { return this.host; }
/*     */ 
/*     */ 
/*     */   
/*  52 */   public int getPort() { return this.port; }
/*     */ 
/*     */ 
/*     */   
/*  56 */   public void setPort(int paramInt) { this.port = paramInt; }
/*     */ 
/*     */ 
/*     */   
/*  60 */   public String getServiceURI() { return this.serviceURI; }
/*     */ 
/*     */ 
/*     */   
/*  64 */   public void setServiceURI(String paramString) { this.serviceURI = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public String getFactoryName() { return this.factoryName; }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public String getQueueName() { return this.queueName; }
/*     */ 
/*     */ 
/*     */   
/*  77 */   private void throwParseError(String paramString) { throw new JAXRPCException("the address [" + paramString + "] is not " + "a JMS valid address. It should be of the from " + "'jms://host:port/factoryName/queueName?URI=serviceURI"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseAddress(String paramString) {
/*  83 */     if (!paramString.startsWith("jms://")) {
/*  84 */       throwParseError(paramString);
/*     */     }
/*     */     
/*  87 */     String str = paramString.substring("jms://".length(), paramString.length());
/*     */ 
/*     */     
/*  90 */     int i = str.indexOf(":");
/*     */     
/*  92 */     if (i == -1) {
/*  93 */       throwParseError(paramString);
/*     */     }
/*     */     
/*  96 */     this.host = str.substring(0, i);
/*     */     
/*  98 */     str = str.substring(i + 1, str.length());
/*     */     
/* 100 */     i = str.indexOf("/");
/*     */     
/* 102 */     if (i == -1) {
/* 103 */       throwParseError(paramString);
/*     */     }
/*     */     
/*     */     try {
/* 107 */       this.port = Integer.parseInt(str.substring(0, i));
/* 108 */     } catch (NumberFormatException numberFormatException) {
/* 109 */       if (verbose) numberFormatException.printStackTrace(); 
/* 110 */       throwParseError(paramString);
/*     */     } 
/*     */     
/* 113 */     str = str.substring(i + 1, str.length());
/*     */     
/* 115 */     i = str.indexOf("/");
/*     */     
/* 117 */     if (i == -1) {
/* 118 */       throwParseError(paramString);
/*     */     }
/*     */     
/* 121 */     this.factoryName = str.substring(0, i);
/*     */     
/* 123 */     str = str.substring(i + 1, str.length());
/*     */     
/* 125 */     i = str.indexOf("?");
/*     */     
/* 127 */     if (i == -1) {
/* 128 */       throwParseError(paramString);
/*     */     }
/*     */     
/* 131 */     this.queueName = str.substring(0, i);
/*     */     
/* 133 */     str = str.substring(i + 1, str.length());
/*     */     
/* 135 */     if (!str.startsWith("URI=")) {
/* 136 */       throwParseError(paramString);
/*     */     }
/*     */     
/* 139 */     this.serviceURI = str.substring("URI=".length());
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\JMSBindingInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */