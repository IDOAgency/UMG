/*     */ package weblogic.webservice.binding.jms;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.jms.TextMessage;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.MessageFactory;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.webservice.binding.AbstractBinding;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.util.WLMessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSServerBinding
/*     */   extends AbstractBinding
/*     */ {
/*     */   private String url;
/*     */   private JMSBindingInfo bindingInfo;
/*     */   private MessageFactory messageFactory;
/*     */   private TextMessage message;
/*     */   private QueueConnectionFactory queueFactory;
/*     */   private Queue responseQueue;
/*     */   
/*     */   public JMSServerBinding(TextMessage paramTextMessage, QueueConnectionFactory paramQueueConnectionFactory) throws SOAPException {
/*  77 */     this.message = paramTextMessage;
/*  78 */     this.queueFactory = paramQueueConnectionFactory;
/*  79 */     this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
/*     */     
/*     */     try {
/*  82 */       this.responseQueue = (Queue)paramTextMessage.getJMSReplyTo();
/*  83 */     } catch (JMSException jMSException) {
/*  84 */       throw new SOAPException("Failed to get Reply queue:" + jMSException, jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(BindingInfo paramBindingInfo) throws IOException {
/*  96 */     if (paramBindingInfo == null) {
/*  97 */       throw new NullPointerException("info can not be null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
/*     */     SOAPMessageContext sOAPMessageContext;
/* 120 */     if (paramMessageContext instanceof SOAPMessageContext) {
/* 121 */       sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     } else {
/* 123 */       throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 129 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.message.getText().getBytes());
/*     */ 
/*     */       
/* 132 */       sOAPMessageContext.setMessage(this.messageFactory.createMessage(null, byteArrayInputStream));
/* 133 */     } catch (JMSException jMSException) {
/* 134 */       throw new SOAPException("failed to get soap message from JMS queue", jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
/*     */     SOAPMessageContext sOAPMessageContext;
/* 149 */     if (paramMessageContext instanceof SOAPMessageContext) {
/* 150 */       sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     } else {
/* 152 */       throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
/*     */     } 
/*     */ 
/*     */     
/* 156 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 157 */     SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 158 */     MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
/*     */     
/* 160 */     sOAPMessage.writeTo(byteArrayOutputStream);
/* 161 */     byteArrayOutputStream.flush();
/* 162 */     byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */     
/*     */     try {
/* 165 */       QueueConnection queueConnection = this.queueFactory.createQueueConnection();
/*     */       
/* 167 */       QueueSession queueSession = queueConnection.createQueueSession(false, 1);
/*     */ 
/*     */       
/* 170 */       TextMessage textMessage = queueSession.createTextMessage();
/* 171 */       textMessage.setText(new String(arrayOfByte));
/*     */       
/* 173 */       QueueSender queueSender = queueSession.createSender(this.responseQueue);
/* 174 */       queueSender.send(textMessage);
/*     */       
/* 176 */       queueSession.close();
/* 177 */       queueConnection.close();
/* 178 */     } catch (JMSException jMSException) {
/* 179 */       jMSException.printStackTrace(System.out);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\JMSServerBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */