package weblogic.webservice.binding.jms;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.webservice.binding.AbstractBinding;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.util.WLMessageFactory;

public class JMSServerBinding extends AbstractBinding {
  private String url;
  
  private JMSBindingInfo bindingInfo;
  
  private MessageFactory messageFactory;
  
  private TextMessage message;
  
  private QueueConnectionFactory queueFactory;
  
  private Queue responseQueue;
  
  public JMSServerBinding(TextMessage paramTextMessage, QueueConnectionFactory paramQueueConnectionFactory) throws SOAPException {
    this.message = paramTextMessage;
    this.queueFactory = paramQueueConnectionFactory;
    this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
    try {
      this.responseQueue = (Queue)paramTextMessage.getJMSReplyTo();
    } catch (JMSException jMSException) {
      throw new SOAPException("Failed to get Reply queue:" + jMSException, jMSException);
    } 
  }
  
  public void init(BindingInfo paramBindingInfo) throws IOException {
    if (paramBindingInfo == null)
      throw new NullPointerException("info can not be null"); 
  }
  
  public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext;
    if (paramMessageContext instanceof SOAPMessageContext) {
      sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    } else {
      throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
    } 
    try {
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.message.getText().getBytes());
      sOAPMessageContext.setMessage(this.messageFactory.createMessage(null, byteArrayInputStream));
    } catch (JMSException jMSException) {
      throw new SOAPException("failed to get soap message from JMS queue", jMSException);
    } 
  }
  
  public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext;
    if (paramMessageContext instanceof SOAPMessageContext) {
      sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    } else {
      throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
    MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
    sOAPMessage.writeTo(byteArrayOutputStream);
    byteArrayOutputStream.flush();
    byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
    try {
      QueueConnection queueConnection = this.queueFactory.createQueueConnection();
      QueueSession queueSession = queueConnection.createQueueSession(false, 1);
      TextMessage textMessage = queueSession.createTextMessage();
      textMessage.setText(new String(arrayOfByte));
      QueueSender queueSender = queueSession.createSender(this.responseQueue);
      queueSender.send(textMessage);
      queueSession.close();
      queueConnection.close();
    } catch (JMSException jMSException) {
      jMSException.printStackTrace(System.out);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\JMSServerBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */