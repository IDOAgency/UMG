package weblogic.webservice.binding.jms;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.TextMessage;
import javax.naming.NamingException;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.webservice.binding.AbstractBinding;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.util.WLMessageFactory;

public class JMSClientBinding extends AbstractBinding {
  private static final boolean verbose = getBooleanProp("weblogic.webservice.verbose", false);
  
  public static final String URI = "URI";
  
  private String url;
  
  private static boolean getBooleanProp(String paramString, boolean paramBoolean) {
    try {
      return Boolean.getBoolean(paramString);
    } catch (SecurityException securityException) {
      return paramBoolean;
    } 
  }
  
  private MessageFactory messageFactory = WLMessageFactory.getInstance().getMessageFactory();
  
  private JMSConnection connection;
  
  public void init(BindingInfo paramBindingInfo) throws IOException {
    if (paramBindingInfo == null)
      throw new NullPointerException("info can not be null"); 
    if (!(paramBindingInfo instanceof JMSBindingInfo))
      throw new IllegalArgumentException("info is not a JMSBindingInfo"); 
    setBindingInfo(paramBindingInfo);
  }
  
  public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext;
    if (paramMessageContext instanceof SOAPMessageContext) {
      sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    } else {
      throw new SOAPException("This binding only supports SOAPMessageContext. " + paramMessageContext);
    } 
    try {
      QueueReceiver queueReceiver = this.connection.getReceiver();
      Message message = queueReceiver.receive();
      if (message instanceof TextMessage) {
        String str = ((TextMessage)message).getText();
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(str.getBytes());
        sOAPMessageContext.setMessage(this.messageFactory.createMessage(null, byteArrayInputStream));
      } 
      this.connection.release();
    } catch (JMSException jMSException) {
      throw new SOAPException("Failed to receive message:" + jMSException, jMSException);
    } 
  }
  
  public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext;
    if (paramMessageContext instanceof SOAPMessageContext) {
      sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    } else {
      throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
    MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
    sOAPMessage.writeTo(byteArrayOutputStream);
    byteArrayOutputStream.flush();
    byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
    try {
      sendToQueue(arrayOfByte);
    } catch (NamingException namingException) {
      failed(namingException);
    } catch (JMSException jMSException) {
      sendAgain(arrayOfByte);
    } 
  }
  
  private void sendAgain(byte[] paramArrayOfByte) {
    try {
      if (this.connection != null)
        this.connection.close(); 
    } catch (JMSException jMSException) {}
    try {
      sendToQueue(paramArrayOfByte);
    } catch (JMSException jMSException) {
      failed(jMSException);
    } catch (NamingException namingException) {
      failed(namingException);
    } 
  }
  
  private void failed(Throwable paramThrowable) { throw new JAXRPCException("unable to send the message to JMS Queue at: " + (JMSBindingInfo)getBindingInfo() + "\n due to :" + paramThrowable, paramThrowable); }
  
  private void sendToQueue(byte[] paramArrayOfByte) {
    this.connection = ConnectionPool.getInstance().getConnection((JMSBindingInfo)getBindingInfo());
    TextMessage textMessage = this.connection.getMessage();
    textMessage.setStringProperty("URI", ((JMSBindingInfo)getBindingInfo()).getServiceURI());
    textMessage.setJMSReplyTo(this.connection.getResponseQueue());
    textMessage.setText(new String(paramArrayOfByte));
    QueueSender queueSender = this.connection.getSender();
    queueSender.send(textMessage);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\JMSClientBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */