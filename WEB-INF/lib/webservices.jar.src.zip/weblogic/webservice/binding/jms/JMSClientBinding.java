/*     */ package weblogic.webservice.binding.jms;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.TextMessage;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.MessageFactory;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.webservice.binding.AbstractBinding;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.util.WLMessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSClientBinding
/*     */   extends AbstractBinding
/*     */ {
/*  58 */   private static final boolean verbose = getBooleanProp("weblogic.webservice.verbose", false);
/*     */   public static final String URI = "URI";
/*     */   
/*     */   private static boolean getBooleanProp(String paramString, boolean paramBoolean) {
/*     */     try {
/*  63 */       return Boolean.getBoolean(paramString);
/*  64 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */       
/*  68 */       return paramBoolean;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String url;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private MessageFactory messageFactory = WLMessageFactory.getInstance().getMessageFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JMSConnection connection;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(BindingInfo paramBindingInfo) throws IOException {
/*  94 */     if (paramBindingInfo == null) {
/*  95 */       throw new NullPointerException("info can not be null");
/*     */     }
/*     */     
/*  98 */     if (!(paramBindingInfo instanceof JMSBindingInfo)) {
/*  99 */       throw new IllegalArgumentException("info is not a JMSBindingInfo");
/*     */     }
/* 101 */     setBindingInfo(paramBindingInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
/*     */     SOAPMessageContext sOAPMessageContext;
/* 116 */     if (paramMessageContext instanceof SOAPMessageContext) {
/* 117 */       sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     } else {
/* 119 */       throw new SOAPException("This binding only supports SOAPMessageContext. " + paramMessageContext);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 125 */       QueueReceiver queueReceiver = this.connection.getReceiver();
/* 126 */       Message message = queueReceiver.receive();
/*     */       
/* 128 */       if (message instanceof TextMessage) {
/* 129 */         String str = ((TextMessage)message).getText();
/*     */         
/* 131 */         ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(str.getBytes());
/*     */ 
/*     */         
/* 134 */         sOAPMessageContext.setMessage(this.messageFactory.createMessage(null, byteArrayInputStream));
/*     */       } 
/*     */       
/* 137 */       this.connection.release();
/* 138 */     } catch (JMSException jMSException) {
/* 139 */       throw new SOAPException("Failed to receive message:" + jMSException, jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
/*     */     SOAPMessageContext sOAPMessageContext;
/* 154 */     if (paramMessageContext instanceof SOAPMessageContext) {
/* 155 */       sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     } else {
/* 157 */       throw new JAXRPCException("This binding only supports SOAPMessageContext. " + paramMessageContext);
/*     */     } 
/*     */ 
/*     */     
/* 161 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 162 */     SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 163 */     MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
/*     */     
/* 165 */     sOAPMessage.writeTo(byteArrayOutputStream);
/* 166 */     byteArrayOutputStream.flush();
/* 167 */     byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */     
/*     */     try {
/* 170 */       sendToQueue(arrayOfByte);
/* 171 */     } catch (NamingException namingException) {
/* 172 */       failed(namingException);
/* 173 */     } catch (JMSException jMSException) {
/* 174 */       sendAgain(arrayOfByte);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendAgain(byte[] paramArrayOfByte) {
/*     */     try {
/* 180 */       if (this.connection != null) {
/* 181 */         this.connection.close();
/*     */       }
/* 183 */     } catch (JMSException jMSException) {}
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 188 */       sendToQueue(paramArrayOfByte);
/* 189 */     } catch (JMSException jMSException) {
/* 190 */       failed(jMSException);
/* 191 */     } catch (NamingException namingException) {
/* 192 */       failed(namingException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 197 */   private void failed(Throwable paramThrowable) { throw new JAXRPCException("unable to send the message to JMS Queue at: " + (JMSBindingInfo)getBindingInfo() + "\n due to :" + paramThrowable, paramThrowable); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendToQueue(byte[] paramArrayOfByte) {
/* 204 */     this.connection = ConnectionPool.getInstance().getConnection((JMSBindingInfo)getBindingInfo());
/* 205 */     TextMessage textMessage = this.connection.getMessage();
/* 206 */     textMessage.setStringProperty("URI", ((JMSBindingInfo)getBindingInfo()).getServiceURI());
/* 207 */     textMessage.setJMSReplyTo(this.connection.getResponseQueue());
/* 208 */     textMessage.setText(new String(paramArrayOfByte));
/*     */     
/* 210 */     QueueSender queueSender = this.connection.getSender();
/* 211 */     queueSender.send(textMessage);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\JMSClientBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */