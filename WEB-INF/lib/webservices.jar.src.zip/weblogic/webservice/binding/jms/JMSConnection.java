package weblogic.webservice.binding.jms;

import java.util.Hashtable;
import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TemporaryQueue;
import javax.jms.TextMessage;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import weblogic.utils.collections.Pool;

public class JMSConnection {
  private QueueConnectionFactory factory;
  
  private QueueConnection connection;
  
  private QueueSession session;
  
  private QueueSender sender;
  
  private TextMessage message;
  
  private TemporaryQueue responseQueue;
  
  private QueueReceiver receiver;
  
  private Pool pool;
  
  private JMSBindingInfo bindingInfo;
  
  public static final String JNDI_FACTORY = "weblogic.jndi.WLInitialContextFactory";
  
  public JMSConnection(JMSBindingInfo paramJMSBindingInfo) throws NamingException, JMSException {
    Hashtable hashtable = new Hashtable();
    hashtable.put("java.naming.factory.initial", "weblogic.jndi.WLInitialContextFactory");
    hashtable.put("java.naming.provider.url", "t3://" + paramJMSBindingInfo.getHost() + ":" + paramJMSBindingInfo.getPort());
    InitialContext initialContext = new InitialContext(hashtable);
    this.factory = (QueueConnectionFactory)initialContext.lookup(paramJMSBindingInfo.getFactoryName());
    this.connection = this.factory.createQueueConnection();
    this.session = this.connection.createQueueSession(false, 1);
    Queue queue = (Queue)initialContext.lookup(paramJMSBindingInfo.getQueueName());
    this.sender = this.session.createSender(queue);
    this.message = this.session.createTextMessage();
    this.responseQueue = this.session.createTemporaryQueue();
    this.receiver = this.session.createReceiver(this.responseQueue);
    this.connection.start();
  }
  
  QueueReceiver getReceiver() { return this.receiver; }
  
  Queue getResponseQueue() { return this.responseQueue; }
  
  public QueueSender getSender() { return this.sender; }
  
  public TextMessage getMessage() { return this.message; }
  
  void setPool(Pool paramPool) { this.pool = paramPool; }
  
  void release() { this.pool.add(this); }
  
  public void close() {
    this.sender.close();
    this.session.close();
    this.connection.close();
    this.receiver.close();
    this.responseQueue.delete();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\JMSConnection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */