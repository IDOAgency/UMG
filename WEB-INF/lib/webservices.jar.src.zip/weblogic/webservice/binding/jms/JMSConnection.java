/*     */ package weblogic.webservice.binding.jms;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.jms.TemporaryQueue;
/*     */ import javax.jms.TextMessage;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import weblogic.utils.collections.Pool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JMSConnection
/*     */ {
/*     */   private QueueConnectionFactory factory;
/*     */   private QueueConnection connection;
/*     */   private QueueSession session;
/*     */   private QueueSender sender;
/*     */   private TextMessage message;
/*     */   private TemporaryQueue responseQueue;
/*     */   private QueueReceiver receiver;
/*     */   private Pool pool;
/*     */   private JMSBindingInfo bindingInfo;
/*     */   public static final String JNDI_FACTORY = "weblogic.jndi.WLInitialContextFactory";
/*     */   
/*     */   public JMSConnection(JMSBindingInfo paramJMSBindingInfo) throws NamingException, JMSException {
/*  48 */     Hashtable hashtable = new Hashtable();
/*  49 */     hashtable.put("java.naming.factory.initial", "weblogic.jndi.WLInitialContextFactory");
/*     */ 
/*     */     
/*  52 */     hashtable.put("java.naming.provider.url", "t3://" + paramJMSBindingInfo.getHost() + ":" + paramJMSBindingInfo.getPort());
/*     */ 
/*     */     
/*  55 */     InitialContext initialContext = new InitialContext(hashtable);
/*     */     
/*  57 */     this.factory = (QueueConnectionFactory)initialContext.lookup(paramJMSBindingInfo.getFactoryName());
/*     */ 
/*     */     
/*  60 */     this.connection = this.factory.createQueueConnection();
/*     */     
/*  62 */     this.session = this.connection.createQueueSession(false, 1);
/*     */     
/*  64 */     Queue queue = (Queue)initialContext.lookup(paramJMSBindingInfo.getQueueName());
/*  65 */     this.sender = this.session.createSender(queue);
/*  66 */     this.message = this.session.createTextMessage();
/*  67 */     this.responseQueue = this.session.createTemporaryQueue();
/*  68 */     this.receiver = this.session.createReceiver(this.responseQueue);
/*  69 */     this.connection.start();
/*     */   }
/*     */ 
/*     */   
/*  73 */   QueueReceiver getReceiver() { return this.receiver; }
/*     */ 
/*     */ 
/*     */   
/*  77 */   Queue getResponseQueue() { return this.responseQueue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public QueueSender getSender() { return this.sender; }
/*     */ 
/*     */ 
/*     */   
/*  87 */   public TextMessage getMessage() { return this.message; }
/*     */ 
/*     */ 
/*     */   
/*  91 */   void setPool(Pool paramPool) { this.pool = paramPool; }
/*     */ 
/*     */ 
/*     */   
/*  95 */   void release() { this.pool.add(this); }
/*     */ 
/*     */   
/*     */   public void close() {
/*  99 */     this.sender.close();
/* 100 */     this.session.close();
/* 101 */     this.connection.close();
/* 102 */     this.receiver.close();
/* 103 */     this.responseQueue.delete();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\jms\JMSConnection.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */