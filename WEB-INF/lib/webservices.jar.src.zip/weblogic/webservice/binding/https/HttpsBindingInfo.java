/*     */ package weblogic.webservice.binding.https;
/*     */ 
/*     */ import java.net.Socket;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.client.SSLAdapter;
/*     */ import weblogic.webservice.client.SSLAdapterFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpsBindingInfo
/*     */   extends BindingInfo
/*     */ {
/*  19 */   private SSLAdapter sslAdapter = SSLAdapterFactory.getDefaultFactory().getSSLAdapter();
/*     */   
/*     */   private boolean pooling = false;
/*     */   
/*  23 */   private Socket secureSocket = null;
/*  24 */   private String secureHost = null;
/*  25 */   private int securePort = 0;
/*  26 */   private long secureTimeOK = 0L;
/*  27 */   private long secureTimeKO = 15000L;
/*     */   
/*     */   private static final String HTTPS_SOCKET_SHARING = "https.sharedsocket";
/*  30 */   private boolean socketSharingEnabled = Boolean.getBoolean("https.sharedsocket");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   public String getTransport() { return "https"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public SSLAdapter getSSLAdapter() { return this.sslAdapter; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSSLAdapter(SSLAdapter paramSSLAdapter) {
/*  63 */     this.sslAdapter = paramSSLAdapter;
/*  64 */     setSSLSecureSocket((Socket)null, null, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSSLSocketPooling(boolean paramBoolean) {
/*  72 */     this.pooling = paramBoolean;
/*  73 */     if (!this.pooling) setSSLSecureSocket((Socket)null, null, 0);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public boolean getSSLSocketPooling() { return this.pooling; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSSLSecureSocket(Socket paramSocket, String paramString, int paramInt) {
/*  92 */     if (paramSocket == null && this.secureSocket != null) {
/*  93 */       try { this.secureSocket.close(); } catch (Exception exception) {}
/*     */     }
/*  95 */     this.secureSocket = paramSocket;
/*  96 */     this.secureHost = paramString;
/*  97 */     this.securePort = paramInt;
/*  98 */     this.secureTimeOK = System.currentTimeMillis() + this.secureTimeKO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Socket getSSLSecureSocket(String paramString, int paramInt) {
/* 108 */     if (this.secureSocket != null)
/*     */     {
/*     */       
/* 111 */       if (this.secureHost.equals(paramString) && this.securePort == paramInt && this.secureSocket.isConnected() && this.secureSocket.isBound() && !this.secureSocket.isClosed() && !this.secureSocket.isInputShutdown() && !this.secureSocket.isOutputShutdown() && this.secureTimeOK > System.currentTimeMillis()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 120 */         this.secureTimeOK = System.currentTimeMillis() + this.secureTimeKO;
/*     */       } else {
/*     */         
/* 123 */         closeSharedSocket();
/*     */       } 
/*     */     }
/* 126 */     return this.secureSocket;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   void setSSLSecureSocketTimeOut() { this.secureTimeOK = System.currentTimeMillis() + this.secureTimeKO; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeSharedSocket() {
/*     */     
/* 146 */     try { this.secureSocket.close(); } catch (Exception exception) {}
/* 147 */     setSSLSecureSocket((Socket)null, null, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public void setSharedSocketTimeout(long paramLong) { this.secureTimeKO = paramLong * 1000L; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public long getSharedSocketTimeout() { return this.secureTimeKO / 1000L; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSocketSharing(boolean paramBoolean) {
/* 183 */     this.socketSharingEnabled = paramBoolean;
/* 184 */     if (!this.socketSharingEnabled) setSSLSecureSocket((Socket)null, null, 0);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public boolean getSocketSharing() { return this.socketSharingEnabled; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\https\HttpsBindingInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */