package weblogic.webservice.binding.https;

import java.net.Socket;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.client.SSLAdapter;
import weblogic.webservice.client.SSLAdapterFactory;

public class HttpsBindingInfo extends BindingInfo {
  private SSLAdapter sslAdapter = SSLAdapterFactory.getDefaultFactory().getSSLAdapter();
  
  private boolean pooling = false;
  
  private Socket secureSocket = null;
  
  private String secureHost = null;
  
  private int securePort = 0;
  
  private long secureTimeOK = 0L;
  
  private long secureTimeKO = 15000L;
  
  private static final String HTTPS_SOCKET_SHARING = "https.sharedsocket";
  
  private boolean socketSharingEnabled = Boolean.getBoolean("https.sharedsocket");
  
  public String getTransport() { return "https"; }
  
  public SSLAdapter getSSLAdapter() { return this.sslAdapter; }
  
  public void setSSLAdapter(SSLAdapter paramSSLAdapter) {
    this.sslAdapter = paramSSLAdapter;
    setSSLSecureSocket((Socket)null, null, 0);
  }
  
  public void setSSLSocketPooling(boolean paramBoolean) {
    this.pooling = paramBoolean;
    if (!this.pooling)
      setSSLSecureSocket((Socket)null, null, 0); 
  }
  
  public boolean getSSLSocketPooling() { return this.pooling; }
  
  void setSSLSecureSocket(Socket paramSocket, String paramString, int paramInt) {
    if (paramSocket == null && this.secureSocket != null)
      try {
        this.secureSocket.close();
      } catch (Exception exception) {} 
    this.secureSocket = paramSocket;
    this.secureHost = paramString;
    this.securePort = paramInt;
    this.secureTimeOK = System.currentTimeMillis() + this.secureTimeKO;
  }
  
  Socket getSSLSecureSocket(String paramString, int paramInt) {
    if (this.secureSocket != null)
      if (this.secureHost.equals(paramString) && this.securePort == paramInt && this.secureSocket.isConnected() && this.secureSocket.isBound() && !this.secureSocket.isClosed() && !this.secureSocket.isInputShutdown() && !this.secureSocket.isOutputShutdown() && this.secureTimeOK > System.currentTimeMillis()) {
        this.secureTimeOK = System.currentTimeMillis() + this.secureTimeKO;
      } else {
        closeSharedSocket();
      }  
    return this.secureSocket;
  }
  
  void setSSLSecureSocketTimeOut() { this.secureTimeOK = System.currentTimeMillis() + this.secureTimeKO; }
  
  public void closeSharedSocket() {
    try {
      this.secureSocket.close();
    } catch (Exception exception) {}
    setSSLSecureSocket((Socket)null, null, 0);
  }
  
  public void setSharedSocketTimeout(long paramLong) { this.secureTimeKO = paramLong * 1000L; }
  
  public long getSharedSocketTimeout() { return this.secureTimeKO / 1000L; }
  
  public void setSocketSharing(boolean paramBoolean) {
    this.socketSharingEnabled = paramBoolean;
    if (!this.socketSharingEnabled)
      setSSLSecureSocket((Socket)null, null, 0); 
  }
  
  public boolean getSocketSharing() { return this.socketSharingEnabled; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\https\HttpsBindingInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */