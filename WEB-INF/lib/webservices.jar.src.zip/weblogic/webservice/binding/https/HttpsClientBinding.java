/*    */ package weblogic.webservice.binding.https;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.Socket;
/*    */ import java.net.URL;
/*    */ import javax.xml.soap.SOAPException;
/*    */ import weblogic.webservice.binding.BindingInfo;
/*    */ import weblogic.webservice.binding.soap.HttpClientBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HttpsClientBinding
/*    */   extends HttpClientBinding
/*    */ {
/*    */   private HttpsBindingInfo bindingInfo;
/*    */   private static final String HTTPS_SOCKET_SHARING_TIMEOUT = "https.sharedsocket.timeout";
/*    */   
/*    */   public void init(BindingInfo paramBindingInfo) throws IOException {
/* 32 */     super.init(paramBindingInfo);
/*    */     
/* 34 */     if (!(paramBindingInfo instanceof HttpsBindingInfo)) {
/* 35 */       throw new IllegalArgumentException("info should be HttpsBindingInfo");
/*    */     }
/* 37 */     this.bindingInfo = (HttpsBindingInfo)paramBindingInfo;
/*    */     
/* 39 */     String str = System.getProperty("https.sharedsocket.timeout");
/* 40 */     if (str != null)
/* 41 */       this.bindingInfo.setSharedSocketTimeout(Integer.parseInt(str)); 
/*    */   }
/*    */   
/*    */   protected Socket createSocket(String paramString, int paramInt) throws IOException {
/* 45 */     Socket socket = this.bindingInfo.getSSLAdapter().createSocket(paramString, paramInt);
/* 46 */     socket.setTcpNoDelay(true);
/* 47 */     int i = getBindingInfo().getTimeout();
/* 48 */     if (i > -1) {
/* 49 */       socket.setSoTimeout(i * 1000);
/*    */     }
/* 51 */     if (!this.bindingInfo.getSSLSocketPooling()) this.bindingInfo.setSSLSecureSocket(socket, paramString, paramInt); 
/* 52 */     return socket;
/*    */   }
/*    */   
/*    */   protected Socket createSocket(URL paramURL) throws IOException {
/* 56 */     if (this.bindingInfo.getSSLSocketPooling()) {
/* 57 */       return super.createSocket(paramURL);
/*    */     }
/* 59 */     Socket socket = this.bindingInfo.getSSLSecureSocket(paramURL.getHost(), getPort(paramURL));
/* 60 */     if (socket != null && this.bindingInfo.getSocketSharing()) {
/* 61 */       return socket;
/*    */     }
/* 63 */     return createSocket(paramURL.getHost(), getPort(paramURL));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void releaseSocket() throws SOAPException {
/* 68 */     if (this.bindingInfo.getSocketSharing()) {
/* 69 */       this.bindingInfo.setSSLSecureSocketTimeOut();
/*    */       return;
/*    */     } 
/* 72 */     if (this.bindingInfo.getSSLSocketPooling()) {
/* 73 */       super.releaseSocket();
/*    */     } else {
/*    */       
/* 76 */       this.bindingInfo.closeSharedSocket();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 81 */   private int getPort(URL paramURL) { return (paramURL.getPort() == -1) ? 443 : paramURL.getPort(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\https\HttpsClientBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */