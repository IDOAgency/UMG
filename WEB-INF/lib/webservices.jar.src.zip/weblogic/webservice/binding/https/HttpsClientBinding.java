package weblogic.webservice.binding.https;

import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import javax.xml.soap.SOAPException;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.binding.soap.HttpClientBinding;

public class HttpsClientBinding extends HttpClientBinding {
  private HttpsBindingInfo bindingInfo;
  
  private static final String HTTPS_SOCKET_SHARING_TIMEOUT = "https.sharedsocket.timeout";
  
  public void init(BindingInfo paramBindingInfo) throws IOException {
    super.init(paramBindingInfo);
    if (!(paramBindingInfo instanceof HttpsBindingInfo))
      throw new IllegalArgumentException("info should be HttpsBindingInfo"); 
    this.bindingInfo = (HttpsBindingInfo)paramBindingInfo;
    String str = System.getProperty("https.sharedsocket.timeout");
    if (str != null)
      this.bindingInfo.setSharedSocketTimeout(Integer.parseInt(str)); 
  }
  
  protected Socket createSocket(String paramString, int paramInt) throws IOException {
    Socket socket = this.bindingInfo.getSSLAdapter().createSocket(paramString, paramInt);
    socket.setTcpNoDelay(true);
    int i = getBindingInfo().getTimeout();
    if (i > -1)
      socket.setSoTimeout(i * 1000); 
    if (!this.bindingInfo.getSSLSocketPooling())
      this.bindingInfo.setSSLSecureSocket(socket, paramString, paramInt); 
    return socket;
  }
  
  protected Socket createSocket(URL paramURL) throws IOException {
    if (this.bindingInfo.getSSLSocketPooling())
      return super.createSocket(paramURL); 
    Socket socket = this.bindingInfo.getSSLSecureSocket(paramURL.getHost(), getPort(paramURL));
    if (socket != null && this.bindingInfo.getSocketSharing())
      return socket; 
    return createSocket(paramURL.getHost(), getPort(paramURL));
  }
  
  protected void releaseSocket() throws SOAPException {
    if (this.bindingInfo.getSocketSharing()) {
      this.bindingInfo.setSSLSecureSocketTimeOut();
      return;
    } 
    if (this.bindingInfo.getSSLSocketPooling()) {
      super.releaseSocket();
    } else {
      this.bindingInfo.closeSharedSocket();
    } 
  }
  
  private int getPort(URL paramURL) { return (paramURL.getPort() == -1) ? 443 : paramURL.getPort(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\https\HttpsClientBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */