/*    */ package weblogic.webservice.binding;
/*    */ 
/*    */ public class ReliableBindingExtension
/*    */   extends BindingExtension
/*    */ {
/*    */   private boolean dupElim;
/*    */   private int retries;
/*    */   private int retryIntervalSecs;
/*    */   private int persistIntervalSecs;
/*    */   
/*    */   public ReliableBindingExtension() {
/* 12 */     this.dupElim = true;
/* 13 */     this.retries = 10;
/* 14 */     this.retryIntervalSecs = 60;
/* 15 */     this.persistIntervalSecs = 600;
/*    */ 
/*    */     
/* 18 */     setKey(BindingExtension.RELIABLE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReliableBindingExtension(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
/* 25 */     this();
/* 26 */     this.dupElim = paramBoolean;
/* 27 */     this.retries = paramInt1;
/* 28 */     this.retryIntervalSecs = paramInt2;
/* 29 */     this.persistIntervalSecs = paramInt3;
/*    */   }
/*    */   
/* 32 */   public boolean isDuplicateElimination() { return this.dupElim; }
/*    */   
/* 34 */   public void setDuplicateElimination(boolean paramBoolean) { this.dupElim = paramBoolean; }
/*    */ 
/*    */   
/* 37 */   public int getRetryCount() { return this.retries; }
/*    */   
/* 39 */   public void setRetryCount(int paramInt) { this.retries = paramInt; }
/*    */ 
/*    */   
/* 42 */   public int getRetryInterval() { return this.retryIntervalSecs; }
/*    */   
/* 44 */   public void setRetryInterval(int paramInt) { this.retryIntervalSecs = paramInt; }
/*    */ 
/*    */   
/* 47 */   public int getPersistInterval() { return this.persistIntervalSecs; }
/*    */   
/* 49 */   public void setPersistInterval(int paramInt) { this.persistIntervalSecs = paramInt; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\ReliableBindingExtension.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */