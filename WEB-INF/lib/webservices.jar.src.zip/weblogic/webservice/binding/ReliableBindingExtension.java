package weblogic.webservice.binding;

public class ReliableBindingExtension extends BindingExtension {
  private boolean dupElim;
  
  private int retries;
  
  private int retryIntervalSecs;
  
  private int persistIntervalSecs;
  
  public ReliableBindingExtension() {
    this.dupElim = true;
    this.retries = 10;
    this.retryIntervalSecs = 60;
    this.persistIntervalSecs = 600;
    setKey(BindingExtension.RELIABLE);
  }
  
  public ReliableBindingExtension(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    this();
    this.dupElim = paramBoolean;
    this.retries = paramInt1;
    this.retryIntervalSecs = paramInt2;
    this.persistIntervalSecs = paramInt3;
  }
  
  public boolean isDuplicateElimination() { return this.dupElim; }
  
  public void setDuplicateElimination(boolean paramBoolean) { this.dupElim = paramBoolean; }
  
  public int getRetryCount() { return this.retries; }
  
  public void setRetryCount(int paramInt) { this.retries = paramInt; }
  
  public int getRetryInterval() { return this.retryIntervalSecs; }
  
  public void setRetryInterval(int paramInt) { this.retryIntervalSecs = paramInt; }
  
  public int getPersistInterval() { return this.persistIntervalSecs; }
  
  public void setPersistInterval(int paramInt) { this.persistIntervalSecs = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\ReliableBindingExtension.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */