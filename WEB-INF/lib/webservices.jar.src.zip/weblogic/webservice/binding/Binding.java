package weblogic.webservice.binding;

import java.io.IOException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.soap.SOAPException;

public interface Binding {
  String getReplyTo();
  
  void setReplyTo(String paramString);
  
  String getSender();
  
  void setSender(String paramString);
  
  String getDestination();
  
  void setDestination(String paramString);
  
  void init(BindingInfo paramBindingInfo) throws IOException;
  
  BindingInfo getBindingInfo();
  
  void receive(MessageContext paramMessageContext) throws IOException, SOAPException;
  
  void send(MessageContext paramMessageContext) throws IOException, SOAPException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\Binding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */