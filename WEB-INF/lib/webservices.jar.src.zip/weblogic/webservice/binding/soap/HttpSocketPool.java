/*     */ package weblogic.webservice.binding.soap;
/*     */ 
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpSocketPool
/*     */   extends TimerTask
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   private static final boolean verbose = false;
/*  26 */   private static final HttpSocketPool theOne = new HttpSocketPool(16);
/*     */   
/*     */   private static final long DEFAULT_KEEP_ALIVE_TIMEOUT = 15L;
/*     */   private static final String KEEP_ALIVE_PROP = "weblogic.http.KeepAliveTimeoutSeconds";
/*     */   private SocketNode[] socketPool;
/*     */   private boolean useKeepAlive;
/*     */   
/*     */   private HttpSocketPool(int paramInt) {
/*  34 */     this.useKeepAlive = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.socketPool = new SocketNode[paramInt];
/*     */     
/*  42 */     long l = 15L;
/*     */     
/*  44 */     String str = System.getProperty("weblogic.http.KeepAliveTimeoutSeconds");
/*  45 */     if (str != null) {
/*     */       try {
/*  47 */         l = (new Long(str)).longValue();
/*  48 */       } catch (NumberFormatException numberFormatException) {
/*  49 */         WebServiceLogger.logInvalidKeepAlive("weblogic.http.KeepAliveTimeoutSeconds", str, "15 seconds");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     l *= 500L;
/*     */     
/*  62 */     if (l == 0L) {
/*  63 */       this.useKeepAlive = false;
/*     */     }
/*     */     
/*  66 */     if (this.useKeepAlive) {
/*  67 */       (new Timer(true)).scheduleAtFixedRate(this, l, l);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  73 */     synchronized (this.socketPool) {
/*  74 */       for (byte b = 0; b < this.socketPool.length; b++) {
/*  75 */         SocketNode socketNode = this.socketPool[b];
/*  76 */         if (socketNode != null)
/*  77 */           if (socketNode.mark) {
/*  78 */             Socket socket = socketNode.socket;
/*  79 */             cleanup(socket);
/*  80 */             this.socketPool[b] = null;
/*     */           } else {
/*  82 */             socketNode.mark = true;
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cleanup(Socket paramSocket) {
/*     */     
/*  90 */     try { paramSocket.getOutputStream().close(); } catch (Exception exception) {} 
/*  91 */     try { paramSocket.getInputStream().close(); } catch (Exception exception) {} 
/*  92 */     try { paramSocket.close(); } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*  96 */   public static HttpSocketPool getHttpSocketPool() { return theOne; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Socket getSocket(URL paramURL) {
/* 101 */     if (!this.useKeepAlive) {
/* 102 */       return null;
/*     */     }
/*     */     
/* 105 */     synchronized (this.socketPool) {
/*     */       
/* 107 */       for (byte b = 0; b < this.socketPool.length; b++) {
/* 108 */         SocketNode socketNode = this.socketPool[b];
/* 109 */         if (socketNode != null && socketNode.url.equals(paramURL)) {
/* 110 */           this.socketPool[b] = null;
/* 111 */           return socketNode.socket;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean releaseSocket(URL paramURL, Socket paramSocket) {
/* 122 */     if (!this.useKeepAlive) {
/* 123 */       cleanup(paramSocket);
/* 124 */       return false;
/*     */     } 
/*     */     
/* 127 */     SocketNode socketNode = new SocketNode(paramURL, paramSocket, null);
/*     */     
/* 129 */     synchronized (this.socketPool) {
/* 130 */       for (byte b = 0; b < this.socketPool.length; b++) {
/* 131 */         if (this.socketPool[b] == null) {
/* 132 */           this.socketPool[b] = socketNode;
/* 133 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 140 */     cleanup(paramSocket);
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SocketNode
/*     */   {
/*     */     private URL url;
/*     */     private Socket socket;
/*     */     private SocketNode next;
/*     */     
/*     */     private SocketNode(URL param1URL, Socket param1Socket) {
/* 152 */       this.url = param1URL;
/* 153 */       this.socket = param1Socket;
/* 154 */       this.mark = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpSocketPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */