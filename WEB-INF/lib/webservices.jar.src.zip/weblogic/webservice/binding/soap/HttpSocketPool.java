package weblogic.webservice.binding.soap;

import java.net.Socket;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;
import weblogic.webservice.WebServiceLogger;

public final class HttpSocketPool extends TimerTask {
  private static final boolean debug = false;
  
  private static final boolean verbose = false;
  
  private static final HttpSocketPool theOne = new HttpSocketPool(16);
  
  private static final long DEFAULT_KEEP_ALIVE_TIMEOUT = 15L;
  
  private static final String KEEP_ALIVE_PROP = "weblogic.http.KeepAliveTimeoutSeconds";
  
  private SocketNode[] socketPool;
  
  private boolean useKeepAlive;
  
  private HttpSocketPool(int paramInt) {
    this.useKeepAlive = true;
    this.socketPool = new SocketNode[paramInt];
    long l = 15L;
    String str = System.getProperty("weblogic.http.KeepAliveTimeoutSeconds");
    if (str != null)
      try {
        l = (new Long(str)).longValue();
      } catch (NumberFormatException numberFormatException) {
        WebServiceLogger.logInvalidKeepAlive("weblogic.http.KeepAliveTimeoutSeconds", str, "15 seconds");
      }  
    l *= 500L;
    if (l == 0L)
      this.useKeepAlive = false; 
    if (this.useKeepAlive)
      (new Timer(true)).scheduleAtFixedRate(this, l, l); 
  }
  
  public void run() {
    synchronized (this.socketPool) {
      for (byte b = 0; b < this.socketPool.length; b++) {
        SocketNode socketNode = this.socketPool[b];
        if (socketNode != null)
          if (socketNode.mark) {
            Socket socket = socketNode.socket;
            cleanup(socket);
            this.socketPool[b] = null;
          } else {
            socketNode.mark = true;
          }  
      } 
    } 
  }
  
  private void cleanup(Socket paramSocket) {
    try {
      paramSocket.getOutputStream().close();
    } catch (Exception exception) {}
    try {
      paramSocket.getInputStream().close();
    } catch (Exception exception) {}
    try {
      paramSocket.close();
    } catch (Exception exception) {}
  }
  
  public static HttpSocketPool getHttpSocketPool() { return theOne; }
  
  public Socket getSocket(URL paramURL) {
    if (!this.useKeepAlive)
      return null; 
    synchronized (this.socketPool) {
      for (byte b = 0; b < this.socketPool.length; b++) {
        SocketNode socketNode = this.socketPool[b];
        if (socketNode != null && socketNode.url.equals(paramURL)) {
          this.socketPool[b] = null;
          return socketNode.socket;
        } 
      } 
    } 
    return null;
  }
  
  public boolean releaseSocket(URL paramURL, Socket paramSocket) {
    if (!this.useKeepAlive) {
      cleanup(paramSocket);
      return false;
    } 
    SocketNode socketNode = new SocketNode(paramURL, paramSocket, null);
    synchronized (this.socketPool) {
      for (byte b = 0; b < this.socketPool.length; b++) {
        if (this.socketPool[b] == null) {
          this.socketPool[b] = socketNode;
          return true;
        } 
      } 
    } 
    cleanup(paramSocket);
    return false;
  }
  
  private static class SocketNode {
    private URL url;
    
    private Socket socket;
    
    private SocketNode next;
    
    private SocketNode(URL param1URL, Socket param1Socket) {
      this.url = param1URL;
      this.socket = param1Socket;
      this.mark = false;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpSocketPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */