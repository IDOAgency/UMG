/*     */ package weblogic.webservice.binding.soap;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import weblogic.utils.io.Chunk;
/*     */ import weblogic.utils.io.ChunkedInputStream;
/*     */ 
/*     */ 
/*     */ public final class HttpResponse
/*     */ {
/*     */   private URL url;
/*     */   private Chunk body;
/*     */   private int bodyStart;
/*     */   private boolean keepAliveEnabled;
/*     */   private int minorVersion;
/*     */   private int majorVersion;
/*     */   private int statusCode;
/*     */   private Map headers;
/*     */   
/*     */   public HttpResponse(URL paramURL) {
/*  25 */     this.keepAliveEnabled = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  30 */     this.headers = new HashMap();
/*     */ 
/*     */     
/*  33 */     this.url = paramURL;
/*     */   }
/*     */   
/*  36 */   public URL getURL() { return this.url; }
/*     */   
/*     */   public void setBody(Chunk paramChunk, int paramInt) {
/*  39 */     this.body = paramChunk;
/*  40 */     this.bodyStart = paramInt;
/*     */   }
/*     */ 
/*     */   
/*  44 */   public InputStream getBodyAsStream() { return new ChunkedInputStream(this.body, this.bodyStart); }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBodyAsString() {
/*  49 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*  51 */     stringBuffer.append(new String(this.body.buf, this.bodyStart, this.body.end - this.bodyStart));
/*     */     
/*  53 */     for (Chunk chunk = this.body.next; chunk != null; chunk = chunk.next) {
/*  54 */       stringBuffer.append(new String(chunk.buf, 0, chunk.end));
/*     */     }
/*     */     
/*  57 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public void setKeepAliveEnabled(boolean paramBoolean) { this.keepAliveEnabled = paramBoolean; }
/*     */ 
/*     */   
/*  67 */   public boolean isKeepAliveEnabled() { return this.keepAliveEnabled; }
/*     */   
/*  69 */   public void setMajorVersion(int paramInt) { this.majorVersion = paramInt; }
/*  70 */   public int getMajorVersion() { return this.majorVersion; }
/*     */   
/*  72 */   public void setMinorVersion(int paramInt) { this.minorVersion = paramInt; }
/*  73 */   public int getMinorVersion() { return this.minorVersion; }
/*     */   
/*  75 */   public void setStatusCode(int paramInt) { this.statusCode = paramInt; }
/*  76 */   public int getStatusCode() { return this.statusCode; }
/*     */ 
/*     */   
/*  79 */   public String getContentType() { return getHeader("Content-Type"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void addHeader(String paramString1, String paramString2) { this.headers.put(paramString1.toUpperCase(), paramString2.trim()); }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public String getHeader(String paramString) { return (String)this.headers.get(paramString.toUpperCase()); }
/*     */ 
/*     */   
/*  92 */   public Map getHeaders() { return this.headers; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MimeHeaders getMimeHeaders() {
/*  98 */     MimeHeaders mimeHeaders = new MimeHeaders();
/*     */     
/* 100 */     Iterator iterator = this.headers.keySet().iterator();
/*     */     
/* 102 */     while (iterator.hasNext()) {
/* 103 */       String str1 = (String)iterator.next();
/* 104 */       String str2 = (String)this.headers.get(str1);
/*     */       
/* 106 */       if (str2 != null && str2.length() != 0) {
/* 107 */         mimeHeaders.setHeader(str1, str2);
/*     */       }
/*     */     } 
/* 110 */     return mimeHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public String toString() { return "HTTP Request to: " + this.url.toString() + " version: " + this.majorVersion + "." + this.minorVersion + " status code: " + this.statusCode + " keep-alive: " + this.keepAliveEnabled + " headers:\n" + this.headers + "\n\n body:\n" + getBodyAsString(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpResponse.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */