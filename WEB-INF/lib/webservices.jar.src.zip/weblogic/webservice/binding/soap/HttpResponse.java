package weblogic.webservice.binding.soap;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.xml.soap.MimeHeaders;
import weblogic.utils.io.Chunk;
import weblogic.utils.io.ChunkedInputStream;

public final class HttpResponse {
  private URL url;
  
  private Chunk body;
  
  private int bodyStart;
  
  private boolean keepAliveEnabled;
  
  private int minorVersion;
  
  private int majorVersion;
  
  private int statusCode;
  
  private Map headers;
  
  public HttpResponse(URL paramURL) {
    this.keepAliveEnabled = false;
    this.headers = new HashMap();
    this.url = paramURL;
  }
  
  public URL getURL() { return this.url; }
  
  public void setBody(Chunk paramChunk, int paramInt) {
    this.body = paramChunk;
    this.bodyStart = paramInt;
  }
  
  public InputStream getBodyAsStream() { return new ChunkedInputStream(this.body, this.bodyStart); }
  
  public String getBodyAsString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(new String(this.body.buf, this.bodyStart, this.body.end - this.bodyStart));
    for (Chunk chunk = this.body.next; chunk != null; chunk = chunk.next)
      stringBuffer.append(new String(chunk.buf, 0, chunk.end)); 
    return stringBuffer.toString();
  }
  
  public void setKeepAliveEnabled(boolean paramBoolean) { this.keepAliveEnabled = paramBoolean; }
  
  public boolean isKeepAliveEnabled() { return this.keepAliveEnabled; }
  
  public void setMajorVersion(int paramInt) { this.majorVersion = paramInt; }
  
  public int getMajorVersion() { return this.majorVersion; }
  
  public void setMinorVersion(int paramInt) { this.minorVersion = paramInt; }
  
  public int getMinorVersion() { return this.minorVersion; }
  
  public void setStatusCode(int paramInt) { this.statusCode = paramInt; }
  
  public int getStatusCode() { return this.statusCode; }
  
  public String getContentType() { return getHeader("Content-Type"); }
  
  public void addHeader(String paramString1, String paramString2) { this.headers.put(paramString1.toUpperCase(), paramString2.trim()); }
  
  public String getHeader(String paramString) { return (String)this.headers.get(paramString.toUpperCase()); }
  
  public Map getHeaders() { return this.headers; }
  
  public MimeHeaders getMimeHeaders() {
    MimeHeaders mimeHeaders = new MimeHeaders();
    Iterator iterator = this.headers.keySet().iterator();
    while (iterator.hasNext()) {
      String str1 = (String)iterator.next();
      String str2 = (String)this.headers.get(str1);
      if (str2 != null && str2.length() != 0)
        mimeHeaders.setHeader(str1, str2); 
    } 
    return mimeHeaders;
  }
  
  public String toString() { return "HTTP Request to: " + this.url.toString() + " version: " + this.majorVersion + "." + this.minorVersion + " status code: " + this.statusCode + " keep-alive: " + this.keepAliveEnabled + " headers:\n" + this.headers + "\n\n body:\n" + getBodyAsString(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpResponse.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */