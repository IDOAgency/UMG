package weblogic.webservice.binding.soap;

import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.webservice.WLSOAPMessage;
import weblogic.webservice.binding.AbstractBinding;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.context.WebServiceContext;
import weblogic.webservice.context.WebServiceContextImpl;
import weblogic.webservice.context.WebServiceHttpSessionImpl;
import weblogic.webservice.core.DefaultMessageContext;
import weblogic.webservice.util.WLMessageFactory;

public class HttpServerBinding extends AbstractBinding {
  public static final String HTTP_REQUEST = "weblogic.webservice.transport.http.request";
  
  public static final String HTTP_RESPONSE = "weblogic.webservice.transport.http.response";
  
  private HttpServletRequest req;
  
  private HttpServletResponse res;
  
  private String[] acceptCharset;
  
  private MessageFactory messageFactory;
  
  public HttpServerBinding(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws SOAPException {
    this.req = paramHttpServletRequest;
    this.res = paramHttpServletResponse;
    this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
  }
  
  public void init(BindingInfo paramBindingInfo) { setBindingInfo(paramBindingInfo); }
  
  public HttpServletRequest getRequest() { return this.req; }
  
  public HttpServletResponse getResponse() { return this.res; }
  
  public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    sOAPMessageContext.setMessage(this.messageFactory.createMessage(createMimeHeaders(this.req), this.req.getInputStream()));
    MimeHeaders mimeHeaders = sOAPMessageContext.getMessage().getMimeHeaders();
    this.req.getSession();
    this.acceptCharset = mimeHeaders.getHeader("Accept-Charset");
    WebServiceContextImpl webServiceContextImpl = new WebServiceContextImpl();
    webServiceContextImpl.setSession(new WebServiceHttpSessionImpl(this.req));
    webServiceContextImpl.setLastMessageContext(sOAPMessageContext);
    WebServiceContext.register(webServiceContextImpl);
    sOAPMessageContext.setProperty("weblogic.webservice.context", webServiceContextImpl);
  }
  
  private MimeHeaders createMimeHeaders(HttpServletRequest paramHttpServletRequest) {
    MimeHeaders mimeHeaders = new MimeHeaders();
    Enumeration enumeration = paramHttpServletRequest.getHeaderNames();
    while (enumeration.hasMoreElements()) {
      String str1 = (String)enumeration.nextElement();
      String str2 = paramHttpServletRequest.getHeader(str1);
      if (str2 != null && str2.length() > 0)
        mimeHeaders.addHeader(str1, str2); 
    } 
    return mimeHeaders;
  }
  
  public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
    DefaultMessageContext defaultMessageContext = (DefaultMessageContext)paramMessageContext;
    SOAPMessage sOAPMessage = defaultMessageContext.getMessage();
    WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)sOAPMessage;
    if (getBindingInfo().getCharset() != null) {
      wLSOAPMessage.setCharset(getBindingInfo().getCharset());
    } else if (this.acceptCharset != null && this.acceptCharset.length > 0) {
      String str1 = getDecodedCharset(this.acceptCharset[0], ';');
      str1 = getDecodedCharset(str1, ',');
      wLSOAPMessage.setCharset(str1);
    } 
    String str = ((WLSOAPMessage)sOAPMessage).getContentType();
    if (wLSOAPMessage.getCharset() != null)
      str = str + "; charset=" + wLSOAPMessage.getCharset(); 
    this.res.setContentType(str);
    SOAPBody sOAPBody = sOAPMessage.getSOAPPart().getEnvelope().getBody();
    if (sOAPBody.hasFault()) {
      String str1 = sOAPBody.getFault().getFaultCode();
      if (str1.endsWith(":Client.Authentication") || str1.equals("Client.Authentication")) {
        this.res.setStatus(401);
      } else {
        this.res.setStatus(500);
      } 
    } 
    boolean bool = (defaultMessageContext.getOperation() == null) ? 0 : defaultMessageContext.getOperation().isOneway();
    if (bool) {
      this.res.setStatus(202);
      this.res.flushBuffer();
    } else {
      sOAPMessage.writeTo(this.res.getOutputStream());
    } 
    WebServiceContext.register(null);
  }
  
  private String getDecodedCharset(String paramString, char paramChar) {
    int i = paramString.indexOf(paramChar);
    if (i > 0)
      return paramString.substring(0, i); 
    return paramString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpServerBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */