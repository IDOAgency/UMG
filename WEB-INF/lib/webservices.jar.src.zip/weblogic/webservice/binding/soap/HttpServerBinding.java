/*     */ package weblogic.webservice.binding.soap;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Enumeration;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.MessageFactory;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.webservice.WLSOAPMessage;
/*     */ import weblogic.webservice.binding.AbstractBinding;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.context.WebServiceContext;
/*     */ import weblogic.webservice.context.WebServiceContextImpl;
/*     */ import weblogic.webservice.context.WebServiceHttpSessionImpl;
/*     */ import weblogic.webservice.core.DefaultMessageContext;
/*     */ import weblogic.webservice.util.WLMessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpServerBinding
/*     */   extends AbstractBinding
/*     */ {
/*     */   public static final String HTTP_REQUEST = "weblogic.webservice.transport.http.request";
/*     */   public static final String HTTP_RESPONSE = "weblogic.webservice.transport.http.response";
/*     */   private HttpServletRequest req;
/*     */   private HttpServletResponse res;
/*     */   private String[] acceptCharset;
/*     */   private MessageFactory messageFactory;
/*     */   
/*     */   public HttpServerBinding(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws SOAPException {
/*  52 */     this.req = paramHttpServletRequest;
/*  53 */     this.res = paramHttpServletResponse;
/*  54 */     this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
/*     */   }
/*     */ 
/*     */   
/*  58 */   public void init(BindingInfo paramBindingInfo) { setBindingInfo(paramBindingInfo); }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public HttpServletRequest getRequest() { return this.req; }
/*     */ 
/*     */ 
/*     */   
/*  66 */   public HttpServletResponse getResponse() { return this.res; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
/*  72 */     SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     sOAPMessageContext.setMessage(this.messageFactory.createMessage(createMimeHeaders(this.req), this.req.getInputStream()));
/*     */ 
/*     */     
/*  83 */     MimeHeaders mimeHeaders = sOAPMessageContext.getMessage().getMimeHeaders();
/*     */ 
/*     */ 
/*     */     
/*  87 */     this.req.getSession();
/*     */     
/*  89 */     this.acceptCharset = mimeHeaders.getHeader("Accept-Charset");
/*     */     
/*  91 */     WebServiceContextImpl webServiceContextImpl = new WebServiceContextImpl();
/*  92 */     webServiceContextImpl.setSession(new WebServiceHttpSessionImpl(this.req));
/*     */     
/*  94 */     webServiceContextImpl.setLastMessageContext(sOAPMessageContext);
/*     */     
/*  96 */     WebServiceContext.register(webServiceContextImpl);
/*  97 */     sOAPMessageContext.setProperty("weblogic.webservice.context", webServiceContextImpl);
/*     */   }
/*     */ 
/*     */   
/*     */   private MimeHeaders createMimeHeaders(HttpServletRequest paramHttpServletRequest) {
/* 102 */     MimeHeaders mimeHeaders = new MimeHeaders();
/* 103 */     Enumeration enumeration = paramHttpServletRequest.getHeaderNames();
/*     */     
/* 105 */     while (enumeration.hasMoreElements()) {
/* 106 */       String str1 = (String)enumeration.nextElement();
/* 107 */       String str2 = paramHttpServletRequest.getHeader(str1);
/*     */       
/* 109 */       if (str2 != null && str2.length() > 0) {
/* 110 */         mimeHeaders.addHeader(str1, str2);
/*     */       }
/*     */     } 
/*     */     
/* 114 */     return mimeHeaders;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
/* 121 */     DefaultMessageContext defaultMessageContext = (DefaultMessageContext)paramMessageContext;
/*     */     
/* 123 */     SOAPMessage sOAPMessage = defaultMessageContext.getMessage();
/* 124 */     WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)sOAPMessage;
/*     */     
/* 126 */     if (getBindingInfo().getCharset() != null) {
/* 127 */       wLSOAPMessage.setCharset(getBindingInfo().getCharset());
/*     */     
/*     */     }
/* 130 */     else if (this.acceptCharset != null && this.acceptCharset.length > 0) {
/*     */ 
/*     */       
/* 133 */       String str1 = getDecodedCharset(this.acceptCharset[0], ';');
/* 134 */       str1 = getDecodedCharset(str1, ',');
/* 135 */       wLSOAPMessage.setCharset(str1);
/*     */     } 
/*     */ 
/*     */     
/* 139 */     String str = ((WLSOAPMessage)sOAPMessage).getContentType();
/*     */     
/* 141 */     if (wLSOAPMessage.getCharset() != null) {
/* 142 */       str = str + "; charset=" + wLSOAPMessage.getCharset();
/*     */     }
/*     */     
/* 145 */     this.res.setContentType(str);
/* 146 */     SOAPBody sOAPBody = sOAPMessage.getSOAPPart().getEnvelope().getBody();
/*     */     
/* 148 */     if (sOAPBody.hasFault()) {
/* 149 */       String str1 = sOAPBody.getFault().getFaultCode();
/* 150 */       if (str1.endsWith(":Client.Authentication") || str1.equals("Client.Authentication")) {
/*     */         
/* 152 */         this.res.setStatus(401);
/*     */       } else {
/* 154 */         this.res.setStatus(500);
/*     */       } 
/*     */     } 
/*     */     
/* 158 */     boolean bool = (defaultMessageContext.getOperation() == null) ? 0 : defaultMessageContext.getOperation().isOneway();
/*     */ 
/*     */     
/* 161 */     if (bool) {
/* 162 */       this.res.setStatus(202);
/* 163 */       this.res.flushBuffer();
/*     */     } else {
/* 165 */       sOAPMessage.writeTo(this.res.getOutputStream());
/*     */     } 
/*     */     
/* 168 */     WebServiceContext.register(null);
/*     */   }
/*     */   
/*     */   private String getDecodedCharset(String paramString, char paramChar) {
/* 172 */     int i = paramString.indexOf(paramChar);
/* 173 */     if (i > 0) {
/* 174 */       return paramString.substring(0, i);
/*     */     }
/* 176 */     return paramString;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpServerBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */