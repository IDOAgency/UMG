package weblogic.webservice.binding.soap;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import javax.mail.internet.ContentType;
import javax.mail.internet.ParseException;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.net.InetAddressHelper;
import weblogic.webservice.WLSOAPMessage;
import weblogic.webservice.binding.AbstractBinding;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.util.AccessException;
import weblogic.webservice.util.WLMessageFactory;

public class HttpClientBinding extends AbstractBinding {
  private URL url;
  
  private InputStream sis;
  
  private OutputStream sos;
  
  private Socket socket;
  
  private PrintStream out;
  
  private final MessageFactory messageFactory;
  
  private final HttpSocketPool socketPool;
  
  private static final String HTTP_PROXY_HOST = "weblogic.webservice.transport.http.proxy.host";
  
  private static final String HTTP_PROXY_PORT = "weblogic.webservice.transport.http.proxy.port";
  
  private static final String WEBSERVICE_VERBOSE = "weblogic.webservice.binding.verbose";
  
  private static final String WEBSERVICE_VERBOSE_NORMAL = "weblogic.webservice.verbose";
  
  private static final String WEBSERVICE_CHARSET = "weblogic.webservice.i18n.charset";
  
  private static final String WEBSERVICE_LANGUAGE = "user.language";
  
  private static final String charset = getStringProp("weblogic.webservice.i18n.charset", null);
  
  private static final String language = getStringProp("user.language", null);
  
  private static final boolean verbose = (getBooleanProp("weblogic.webservice.binding.verbose", false) || getBooleanProp("weblogic.webservice.verbose", false));
  
  private static final String proxyHost;
  
  private static final int proxyPort;
  
  private static int socketKeepAlives;
  
  private static boolean keepAliveCountingEnabled;
  
  private static String getStringProp(String paramString1, String paramString2) {
    try {
      return System.getProperty(paramString1);
    } catch (SecurityException securityException) {
      return paramString2;
    } 
  }
  
  private static boolean getBooleanProp(String paramString, boolean paramBoolean) {
    try {
      return Boolean.getBoolean(paramString);
    } catch (SecurityException securityException) {
      return paramBoolean;
    } 
  }
  
  static  {
    String str = null;
    int i = 8080;
    try {
      str = getStringProp("weblogic.webservice.transport.http.proxy.host", null);
      if (str != null) {
        String str1 = getStringProp("weblogic.webservice.transport.http.proxy.port", null);
        if (str1 != null)
          i = Integer.parseInt(str1); 
      } 
    } catch (Exception exception) {}
    proxyHost = str;
    proxyPort = i;
    socketKeepAlives = 0;
    keepAliveCountingEnabled = false;
  }
  
  public static void setKeepAliveCountingEnabled(boolean paramBoolean) { keepAliveCountingEnabled = paramBoolean; }
  
  public static int getSocketKeepAlives() { return socketKeepAlives; }
  
  public HttpClientBinding(String paramString) throws SOAPException, IOException {
    this.socketPool = HttpSocketPool.getHttpSocketPool();
    this.url = new URL(paramString);
    this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
  }
  
  public HttpClientBinding() throws SOAPException {
    this.socketPool = HttpSocketPool.getHttpSocketPool();
    this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
  }
  
  public void init(BindingInfo paramBindingInfo) throws IOException {
    setBindingInfo(paramBindingInfo);
    String str = InetAddressHelper.convertIfIPV6URL(paramBindingInfo.getAddress());
    this.url = new URL(str);
    this.out = System.out;
  }
  
  public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext;
    if (paramMessageContext instanceof SOAPMessageContext) {
      sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    } else {
      throw new JAXRPCException("unknow message context :" + paramMessageContext);
    } 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
    WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)sOAPMessage;
    MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
    if (getBindingInfo().getCharset() != null)
      wLSOAPMessage.setCharset(getBindingInfo().getCharset()); 
    sOAPMessage.writeTo(byteArrayOutputStream);
    byteArrayOutputStream.flush();
    byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
    this.socket = createSocket(this.url);
    bool = true;
    String str = wLSOAPMessage.getContentType();
    if (wLSOAPMessage.getCharset() != null)
      str = str + "; charset=" + wLSOAPMessage.getCharset(); 
    try {
      this.sis = this.socket.getInputStream();
      this.sos = this.socket.getOutputStream();
      StringBuffer stringBuffer = createRequest(this.url);
      addHeader(stringBuffer, "Host", this.url.getHost() + ":" + getPort(this.url));
      addHeader(stringBuffer, "Connection", "Keep-Alive");
      addHeader(stringBuffer, "Content-Length", "" + arrayOfByte.length);
      addHeader(stringBuffer, "Content-Type", str);
      if (mimeHeaders != null) {
        Iterator iterator = mimeHeaders.getAllHeaders();
        while (iterator.hasNext()) {
          MimeHeader mimeHeader = (MimeHeader)iterator.next();
          if (!"Content-Type".equals(mimeHeader.getName()))
            addHeader(stringBuffer, mimeHeader.getName(), mimeHeader.getValue()); 
        } 
      } 
      stringBuffer.append("\r\n");
      if (verbose)
        dumpRequest(str, stringBuffer, arrayOfByte); 
      writeToStream(this.sos, stringBuffer, arrayOfByte);
      bool = false;
    } finally {
      if (bool)
        cleanupSocket(); 
    } 
  }
  
  public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
    SOAPMessageContext sOAPMessageContext;
    if (paramMessageContext instanceof SOAPMessageContext) {
      sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    } else {
      throw new JAXRPCException("unknow message context :" + paramMessageContext);
    } 
    try {
      HttpResponse httpResponse = HttpResponseParser.parse(this.url, new BufferedInputStream(this.sis, 256));
      if (verbose)
        dumpResponse(httpResponse); 
      if (!validContentType(httpResponse.getContentType())) {
        if (httpResponse.getStatusCode() == 400)
          throw new IOException("Received a response from url: " + this.url + " which did not have a valid SOAP content-type: " + httpResponse.getContentType() + ".  The full message was: " + httpResponse.getBodyAsString()); 
        handleErrorResponse(httpResponse);
      } 
      String str = httpResponse.getHeader("set-cookie");
      if (str != null)
        sOAPMessageContext.setProperty("SessionID", str); 
      try {
        sOAPMessageContext.setMessage(this.messageFactory.createMessage(httpResponse.getMimeHeaders(), httpResponse.getBodyAsStream()));
      } catch (IOException iOException) {
        throw new IOException("Error reading the response from: " + this.url + ".  Please ensure that this is a " + "valid SOAP response.  The message was: \n\n" + httpResponse.getBodyAsString());
      } 
      if (httpResponse.isKeepAliveEnabled()) {
        releaseSocket();
        this.socket = null;
        if (keepAliveCountingEnabled)
          synchronized (HttpClientBinding.class) {
            socketKeepAlives++;
          }  
      } 
    } finally {
      if (this.socket != null)
        cleanupSocket(); 
    } 
  }
  
  protected void releaseSocket() throws SOAPException { this.socketPool.releaseSocket(this.url, this.socket); }
  
  private boolean validContentType(String paramString) throws IOException {
    if (paramString == null)
      return false; 
    String str = null;
    try {
      str = (new ContentType(paramString)).getBaseType();
    } catch (ParseException parseException) {
      return false;
    } 
    str = str.trim().toLowerCase();
    return ("text/xml".startsWith(str) || "application/soap+xml".startsWith(str) || "multipart/related".startsWith(str));
  }
  
  private String getContentType(MimeHeaders paramMimeHeaders) {
    String[] arrayOfString = paramMimeHeaders.getHeader("Content-Type");
    if (arrayOfString == null || arrayOfString.length == 0) {
      if ("SOAP1.1".equals(getBindingInfo().getType()))
        return useCharset() ? ("text/xml; charset=" + charset) : "text/xml"; 
      return "application/soap+xml; charset=utf-8";
    } 
    if (arrayOfString.length == 1)
      return arrayOfString[0]; 
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < arrayOfString.length; b++)
      stringBuffer.append(arrayOfString[b]); 
    return stringBuffer.toString();
  }
  
  private String getDefaultContentType() {
    String str;
    if ("SOAP1.1".equals(getBindingInfo().getType())) {
      if (useCharset()) {
        str = "text/xml; charset=" + charset;
      } else if ("en".equalsIgnoreCase(language)) {
        str = "text/xml";
      } else {
        str = "text/xml; charset=utf-8";
      } 
    } else if (useCharset()) {
      str = "application/soap; charset=" + charset;
    } else if ("en".equalsIgnoreCase(language)) {
      str = "application/soap";
    } else {
      str = "application/soap; charset=utf-8";
    } 
    return str;
  }
  
  private boolean useCharset() { return (charset != null && charset.length() != 0); }
  
  private void handleErrorResponse(HttpResponse paramHttpResponse) throws IOException {
    int i = paramHttpResponse.getStatusCode();
    switch (i) {
      case 404:
        throw new IOException("The server at " + this.url.toString() + " returned a 404 error code (Not Found).  Please ensure that your" + " URL is correct, and the web service has deployed " + "without error.");
      case 403:
        throw new AccessException("The server at " + this.url.toString() + " returned a 403 error code (Forbidden).  Please ensure that your " + "URL is correct and that the correct protocol is in use.");
      case 401:
        throw new AccessException("The server at " + this.url.toString() + " returned a 401 error code (Unauthorized).  Please check that" + " username and password are set correctly and that you have" + " permission to access the requested method.");
      case 301:
      case 302:
        throw new IOException("Redirection not supported: The server at " + this.url.toString() + " returned a " + i + " response code indicating this resource has moved.");
    } 
    throw new IOException("Received a response from url: " + this.url + " which did not have a valid SOAP content-type: " + paramHttpResponse.getContentType() + ".  The full message was: " + paramHttpResponse.getBodyAsString());
  }
  
  private void writeToStream(OutputStream paramOutputStream, StringBuffer paramStringBuffer, byte[] paramArrayOfByte) throws IOException {
    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramOutputStream);
    bufferedOutputStream.write(paramStringBuffer.toString().getBytes());
    bufferedOutputStream.write(paramArrayOfByte);
    bufferedOutputStream.flush();
    paramOutputStream.flush();
  }
  
  private void addHeader(StringBuffer paramStringBuffer, String paramString1, String paramString2) { paramStringBuffer.append(paramString1).append(": ").append(paramString2).append("\r\n"); }
  
  private StringBuffer createRequest(URL paramURL) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("POST ");
    if (proxyHost != null) {
      stringBuffer.append(paramURL.toString());
    } else {
      stringBuffer.append(paramURL.getPath());
      String str1 = paramURL.getQuery();
      if (str1 != null) {
        stringBuffer.append('?');
        stringBuffer.append(str1);
      } 
      String str2 = paramURL.getRef();
      if (str2 != null) {
        stringBuffer.append('#');
        stringBuffer.append(str2);
      } 
    } 
    stringBuffer.append(" HTTP/1.0\r\n");
    return stringBuffer;
  }
  
  protected Socket createSocket(URL paramURL) throws IOException {
    Socket socket1 = this.socketPool.getSocket(paramURL);
    if (socket1 != null)
      return socket1; 
    String str1 = paramURL.getProtocol();
    String str2 = paramURL.getHost();
    int i = getPort(paramURL);
    return createSocket(str2, i);
  }
  
  protected Socket createSocket(String paramString, int paramInt) throws IOException {
    Socket socket1 = (proxyHost != null) ? new Socket(proxyHost, proxyPort) : new Socket(paramString, paramInt);
    socket1.setTcpNoDelay(true);
    return socket1;
  }
  
  private void cleanupSocket() throws SOAPException {
    try {
      this.sos.close();
    } catch (Exception exception) {}
    try {
      this.sis.close();
    } catch (Exception exception) {}
    try {
      this.socket.close();
    } catch (Exception exception) {}
    this.socket = null;
    this.sos = null;
    this.sis = null;
  }
  
  private int getPort(URL paramURL) { return (paramURL.getPort() == -1) ? 80 : paramURL.getPort(); }
  
  private void dumpRequest(String paramString, StringBuffer paramStringBuffer, byte[] paramArrayOfByte) {
    this.out.println("<!-------------------- REQUEST FROM CLIENT ---------------->");
    this.out.println("URL        :  " + this.url);
    this.out.println("ContentType:  " + paramString);
    this.out.println("Headers    :");
    this.out.println(paramStringBuffer);
    this.out.println("Envelope   :");
    this.out.println(new String(paramArrayOfByte));
    this.out.println("<!-------------------- END REQUEST FROM CLIENT ------------>");
  }
  
  private void dumpResponse(HttpResponse paramHttpResponse) throws IOException {
    this.out.println("<!-------------------- RESPONSE TO CLIENT --------------->");
    this.out.println("URL        : " + this.url);
    this.out.println("StatusCode : " + paramHttpResponse.getStatusCode());
    this.out.println("Headers    :");
    Map map = paramHttpResponse.getHeaders();
    for (Map.Entry entry : map.entrySet())
      this.out.println("  " + entry.getKey() + " = " + entry.getValue()); 
    this.out.println("Envelope   :");
    this.out.println(paramHttpResponse.getBodyAsString());
    this.out.println("<!-------------------- END RESPONSE TO CLIENT ----------->");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpClientBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */