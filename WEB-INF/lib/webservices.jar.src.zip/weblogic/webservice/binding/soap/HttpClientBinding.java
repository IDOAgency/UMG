/*     */ package weblogic.webservice.binding.soap;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.ParseException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.MessageFactory;
/*     */ import javax.xml.soap.MimeHeader;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.utils.net.InetAddressHelper;
/*     */ import weblogic.webservice.WLSOAPMessage;
/*     */ import weblogic.webservice.binding.AbstractBinding;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.util.AccessException;
/*     */ import weblogic.webservice.util.WLMessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HttpClientBinding
/*     */   extends AbstractBinding
/*     */ {
/*     */   private URL url;
/*     */   private InputStream sis;
/*     */   private OutputStream sos;
/*     */   private Socket socket;
/*     */   private PrintStream out;
/*     */   private final MessageFactory messageFactory;
/*     */   private final HttpSocketPool socketPool;
/*     */   private static final String HTTP_PROXY_HOST = "weblogic.webservice.transport.http.proxy.host";
/*     */   private static final String HTTP_PROXY_PORT = "weblogic.webservice.transport.http.proxy.port";
/*     */   private static final String WEBSERVICE_VERBOSE = "weblogic.webservice.binding.verbose";
/*     */   private static final String WEBSERVICE_VERBOSE_NORMAL = "weblogic.webservice.verbose";
/*     */   private static final String WEBSERVICE_CHARSET = "weblogic.webservice.i18n.charset";
/*     */   private static final String WEBSERVICE_LANGUAGE = "user.language";
/*  75 */   private static final String charset = getStringProp("weblogic.webservice.i18n.charset", null);
/*     */   
/*  77 */   private static final String language = getStringProp("user.language", null);
/*     */   private static final String proxyHost;
/*  79 */   private static final boolean verbose = (getBooleanProp("weblogic.webservice.binding.verbose", false) || getBooleanProp("weblogic.webservice.verbose", false)); private static final int proxyPort;
/*     */   private static int socketKeepAlives;
/*     */   private static boolean keepAliveCountingEnabled;
/*     */   
/*     */   private static String getStringProp(String paramString1, String paramString2) {
/*     */     try {
/*  85 */       return System.getProperty(paramString1);
/*  86 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */       
/*  90 */       return paramString2;
/*     */     } 
/*     */   }
/*     */   private static boolean getBooleanProp(String paramString, boolean paramBoolean) {
/*     */     try {
/*  95 */       return Boolean.getBoolean(paramString);
/*  96 */     } catch (SecurityException securityException) {
/*     */ 
/*     */ 
/*     */       
/* 100 */       return paramBoolean;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/* 107 */     String str = null;
/* 108 */     int i = 8080;
/*     */     try {
/* 110 */       str = getStringProp("weblogic.webservice.transport.http.proxy.host", null);
/* 111 */       if (str != null) {
/* 112 */         String str1 = getStringProp("weblogic.webservice.transport.http.proxy.port", null);
/* 113 */         if (str1 != null) i = Integer.parseInt(str1);
/*     */       
/*     */       } 
/* 116 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 120 */     proxyHost = str;
/* 121 */     proxyPort = i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     socketKeepAlives = 0;
/*     */     
/* 129 */     keepAliveCountingEnabled = false;
/*     */   }
/*     */   
/* 132 */   public static void setKeepAliveCountingEnabled(boolean paramBoolean) { keepAliveCountingEnabled = paramBoolean; }
/*     */ 
/*     */   
/* 135 */   public static int getSocketKeepAlives() { return socketKeepAlives; }
/*     */ 
/*     */   
/*     */   public HttpClientBinding(String paramString) throws SOAPException, IOException {
/*     */     this.socketPool = HttpSocketPool.getHttpSocketPool();
/* 140 */     this.url = new URL(paramString);
/* 141 */     this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
/*     */   }
/*     */   public HttpClientBinding() throws SOAPException {
/*     */     this.socketPool = HttpSocketPool.getHttpSocketPool();
/* 145 */     this.messageFactory = WLMessageFactory.getInstance().getMessageFactory();
/*     */   }
/*     */   
/*     */   public void init(BindingInfo paramBindingInfo) throws IOException {
/* 149 */     setBindingInfo(paramBindingInfo);
/* 150 */     String str = InetAddressHelper.convertIfIPV6URL(paramBindingInfo.getAddress());
/* 151 */     this.url = new URL(str);
/* 152 */     this.out = System.out;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void send(MessageContext paramMessageContext) throws IOException, SOAPException {
/*     */     SOAPMessageContext sOAPMessageContext;
/* 161 */     if (paramMessageContext instanceof SOAPMessageContext) {
/* 162 */       sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     } else {
/* 164 */       throw new JAXRPCException("unknow message context :" + paramMessageContext);
/*     */     } 
/*     */     
/* 167 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/* 169 */     SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 170 */     WLSOAPMessage wLSOAPMessage = (WLSOAPMessage)sOAPMessage;
/*     */     
/* 172 */     MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
/*     */     
/* 174 */     if (getBindingInfo().getCharset() != null) {
/* 175 */       wLSOAPMessage.setCharset(getBindingInfo().getCharset());
/*     */     }
/*     */     
/* 178 */     sOAPMessage.writeTo(byteArrayOutputStream);
/* 179 */     byteArrayOutputStream.flush();
/* 180 */     byte[] arrayOfByte = byteArrayOutputStream.toByteArray();
/*     */     
/* 182 */     this.socket = createSocket(this.url);
/*     */ 
/*     */     
/* 185 */     bool = true;
/*     */ 
/*     */     
/* 188 */     String str = wLSOAPMessage.getContentType();
/*     */     
/* 190 */     if (wLSOAPMessage.getCharset() != null) {
/* 191 */       str = str + "; charset=" + wLSOAPMessage.getCharset();
/*     */     }
/*     */     
/*     */     try {
/* 195 */       this.sis = this.socket.getInputStream();
/* 196 */       this.sos = this.socket.getOutputStream();
/*     */       
/* 198 */       StringBuffer stringBuffer = createRequest(this.url);
/*     */       
/* 200 */       addHeader(stringBuffer, "Host", this.url.getHost() + ":" + getPort(this.url));
/* 201 */       addHeader(stringBuffer, "Connection", "Keep-Alive");
/* 202 */       addHeader(stringBuffer, "Content-Length", "" + arrayOfByte.length);
/*     */       
/* 204 */       addHeader(stringBuffer, "Content-Type", str);
/*     */ 
/*     */       
/* 207 */       if (mimeHeaders != null) {
/*     */         
/* 209 */         Iterator iterator = mimeHeaders.getAllHeaders();
/* 210 */         while (iterator.hasNext()) {
/*     */           
/* 212 */           MimeHeader mimeHeader = (MimeHeader)iterator.next();
/*     */ 
/*     */           
/* 215 */           if (!"Content-Type".equals(mimeHeader.getName())) {
/* 216 */             addHeader(stringBuffer, mimeHeader.getName(), mimeHeader.getValue());
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 222 */       stringBuffer.append("\r\n");
/* 223 */       if (verbose) dumpRequest(str, stringBuffer, arrayOfByte); 
/* 224 */       writeToStream(this.sos, stringBuffer, arrayOfByte);
/*     */       
/* 226 */       bool = false;
/*     */     } finally {
/* 228 */       if (bool) cleanupSocket();
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receive(MessageContext paramMessageContext) throws IOException, SOAPException {
/*     */     SOAPMessageContext sOAPMessageContext;
/* 238 */     if (paramMessageContext instanceof SOAPMessageContext) {
/* 239 */       sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     } else {
/* 241 */       throw new JAXRPCException("unknow message context :" + paramMessageContext);
/*     */     } 
/*     */     
/*     */     try {
/* 245 */       HttpResponse httpResponse = HttpResponseParser.parse(this.url, new BufferedInputStream(this.sis, 256));
/*     */ 
/*     */       
/* 248 */       if (verbose) dumpResponse(httpResponse);
/*     */ 
/*     */       
/* 251 */       if (!validContentType(httpResponse.getContentType())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 258 */         if (httpResponse.getStatusCode() == 400) {
/* 259 */           throw new IOException("Received a response from url: " + this.url + " which did not have a valid SOAP content-type: " + httpResponse.getContentType() + ".  The full message was: " + httpResponse.getBodyAsString());
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 265 */         handleErrorResponse(httpResponse);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 271 */       String str = httpResponse.getHeader("set-cookie");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 278 */       if (str != null) {
/* 279 */         sOAPMessageContext.setProperty("SessionID", str);
/*     */       }
/*     */       
/*     */       try {
/* 283 */         sOAPMessageContext.setMessage(this.messageFactory.createMessage(httpResponse.getMimeHeaders(), httpResponse.getBodyAsStream()));
/*     */ 
/*     */       
/*     */       }
/* 287 */       catch (IOException iOException) {
/* 288 */         throw new IOException("Error reading the response from: " + this.url + ".  Please ensure that this is a " + "valid SOAP response.  The message was: \n\n" + httpResponse.getBodyAsString());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 294 */       if (httpResponse.isKeepAliveEnabled()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 300 */         releaseSocket();
/* 301 */         this.socket = null;
/*     */ 
/*     */         
/* 304 */         if (keepAliveCountingEnabled) {
/* 305 */           synchronized (HttpClientBinding.class) {
/* 306 */             socketKeepAlives++;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 312 */       if (this.socket != null) cleanupSocket();
/*     */     
/*     */     } 
/*     */   }
/*     */   
/* 317 */   protected void releaseSocket() throws SOAPException { this.socketPool.releaseSocket(this.url, this.socket); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validContentType(String paramString) throws IOException {
/* 324 */     if (paramString == null) return false;
/*     */     
/* 326 */     String str = null;
/*     */     
/*     */     try {
/* 329 */       str = (new ContentType(paramString)).getBaseType();
/* 330 */     } catch (ParseException parseException) {
/* 331 */       return false;
/*     */     } 
/*     */     
/* 334 */     str = str.trim().toLowerCase();
/*     */     
/* 336 */     return ("text/xml".startsWith(str) || "application/soap+xml".startsWith(str) || "multipart/related".startsWith(str));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getContentType(MimeHeaders paramMimeHeaders) {
/* 343 */     String[] arrayOfString = paramMimeHeaders.getHeader("Content-Type");
/*     */     
/* 345 */     if (arrayOfString == null || arrayOfString.length == 0) {
/* 346 */       if ("SOAP1.1".equals(getBindingInfo().getType())) {
/* 347 */         return useCharset() ? ("text/xml; charset=" + charset) : "text/xml";
/*     */       }
/* 349 */       return "application/soap+xml; charset=utf-8";
/*     */     } 
/* 351 */     if (arrayOfString.length == 1) {
/* 352 */       return arrayOfString[0];
/*     */     }
/* 354 */     StringBuffer stringBuffer = new StringBuffer();
/* 355 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 356 */       stringBuffer.append(arrayOfString[b]);
/*     */     }
/* 358 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getDefaultContentType() {
/*     */     String str;
/* 366 */     if ("SOAP1.1".equals(getBindingInfo().getType())) {
/* 367 */       if (useCharset()) {
/* 368 */         str = "text/xml; charset=" + charset;
/* 369 */       } else if ("en".equalsIgnoreCase(language)) {
/* 370 */         str = "text/xml";
/*     */       } else {
/* 372 */         str = "text/xml; charset=utf-8";
/*     */       }
/*     */     
/* 375 */     } else if (useCharset()) {
/* 376 */       str = "application/soap; charset=" + charset;
/* 377 */     } else if ("en".equalsIgnoreCase(language)) {
/* 378 */       str = "application/soap";
/*     */     } else {
/* 380 */       str = "application/soap; charset=utf-8";
/*     */     } 
/*     */     
/* 383 */     return str;
/*     */   }
/*     */ 
/*     */   
/* 387 */   private boolean useCharset() { return (charset != null && charset.length() != 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleErrorResponse(HttpResponse paramHttpResponse) throws IOException {
/* 395 */     int i = paramHttpResponse.getStatusCode();
/*     */     
/* 397 */     switch (i) {
/*     */       case 404:
/* 399 */         throw new IOException("The server at " + this.url.toString() + " returned a 404 error code (Not Found).  Please ensure that your" + " URL is correct, and the web service has deployed " + "without error.");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 403:
/* 405 */         throw new AccessException("The server at " + this.url.toString() + " returned a 403 error code (Forbidden).  Please ensure that your " + "URL is correct and that the correct protocol is in use.");
/*     */ 
/*     */ 
/*     */       
/*     */       case 401:
/* 410 */         throw new AccessException("The server at " + this.url.toString() + " returned a 401 error code (Unauthorized).  Please check that" + " username and password are set correctly and that you have" + " permission to access the requested method.");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 301:
/*     */       case 302:
/* 417 */         throw new IOException("Redirection not supported: The server at " + this.url.toString() + " returned a " + i + " response code indicating this resource has moved.");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 422 */     throw new IOException("Received a response from url: " + this.url + " which did not have a valid SOAP content-type: " + paramHttpResponse.getContentType() + ".  The full message was: " + paramHttpResponse.getBodyAsString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeToStream(OutputStream paramOutputStream, StringBuffer paramStringBuffer, byte[] paramArrayOfByte) throws IOException {
/* 433 */     BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramOutputStream);
/* 434 */     bufferedOutputStream.write(paramStringBuffer.toString().getBytes());
/* 435 */     bufferedOutputStream.write(paramArrayOfByte);
/* 436 */     bufferedOutputStream.flush();
/* 437 */     paramOutputStream.flush();
/*     */   }
/*     */ 
/*     */   
/* 441 */   private void addHeader(StringBuffer paramStringBuffer, String paramString1, String paramString2) { paramStringBuffer.append(paramString1).append(": ").append(paramString2).append("\r\n"); }
/*     */ 
/*     */   
/*     */   private StringBuffer createRequest(URL paramURL) {
/* 445 */     StringBuffer stringBuffer = new StringBuffer();
/* 446 */     stringBuffer.append("POST ");
/*     */     
/* 448 */     if (proxyHost != null) {
/* 449 */       stringBuffer.append(paramURL.toString());
/*     */     } else {
/* 451 */       stringBuffer.append(paramURL.getPath());
/* 452 */       String str1 = paramURL.getQuery();
/* 453 */       if (str1 != null) {
/* 454 */         stringBuffer.append('?');
/* 455 */         stringBuffer.append(str1);
/*     */       } 
/* 457 */       String str2 = paramURL.getRef();
/* 458 */       if (str2 != null) {
/* 459 */         stringBuffer.append('#');
/* 460 */         stringBuffer.append(str2);
/*     */       } 
/*     */     } 
/*     */     
/* 464 */     stringBuffer.append(" HTTP/1.0\r\n");
/* 465 */     return stringBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Socket createSocket(URL paramURL) throws IOException {
/* 470 */     Socket socket1 = this.socketPool.getSocket(paramURL);
/*     */     
/* 472 */     if (socket1 != null) {
/* 473 */       return socket1;
/*     */     }
/*     */ 
/*     */     
/* 477 */     String str1 = paramURL.getProtocol();
/* 478 */     String str2 = paramURL.getHost();
/* 479 */     int i = getPort(paramURL);
/*     */     
/* 481 */     return createSocket(str2, i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Socket createSocket(String paramString, int paramInt) throws IOException {
/* 487 */     Socket socket1 = (proxyHost != null) ? new Socket(proxyHost, proxyPort) : new Socket(paramString, paramInt);
/*     */ 
/*     */     
/* 490 */     socket1.setTcpNoDelay(true);
/* 491 */     return socket1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanupSocket() throws SOAPException {
/*     */     
/* 501 */     try { this.sos.close(); } catch (Exception exception) {} 
/* 502 */     try { this.sis.close(); } catch (Exception exception) {} 
/* 503 */     try { this.socket.close(); } catch (Exception exception) {}
/*     */     
/* 505 */     this.socket = null;
/* 506 */     this.sos = null;
/* 507 */     this.sis = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 512 */   private int getPort(URL paramURL) { return (paramURL.getPort() == -1) ? 80 : paramURL.getPort(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void dumpRequest(String paramString, StringBuffer paramStringBuffer, byte[] paramArrayOfByte) {
/* 519 */     this.out.println("<!-------------------- REQUEST FROM CLIENT ---------------->");
/*     */     
/* 521 */     this.out.println("URL        :  " + this.url);
/* 522 */     this.out.println("ContentType:  " + paramString);
/*     */     
/* 524 */     this.out.println("Headers    :");
/* 525 */     this.out.println(paramStringBuffer);
/*     */     
/* 527 */     this.out.println("Envelope   :");
/* 528 */     this.out.println(new String(paramArrayOfByte));
/*     */     
/* 530 */     this.out.println("<!-------------------- END REQUEST FROM CLIENT ------------>");
/*     */   }
/*     */   
/*     */   private void dumpResponse(HttpResponse paramHttpResponse) throws IOException {
/* 534 */     this.out.println("<!-------------------- RESPONSE TO CLIENT --------------->");
/* 535 */     this.out.println("URL        : " + this.url);
/* 536 */     this.out.println("StatusCode : " + paramHttpResponse.getStatusCode());
/* 537 */     this.out.println("Headers    :");
/*     */     
/* 539 */     Map map = paramHttpResponse.getHeaders();
/*     */     
/* 541 */     for (Map.Entry entry : map.entrySet())
/*     */     {
/* 543 */       this.out.println("  " + entry.getKey() + " = " + entry.getValue());
/*     */     }
/*     */     
/* 546 */     this.out.println("Envelope   :");
/* 547 */     this.out.println(paramHttpResponse.getBodyAsString());
/*     */     
/* 549 */     this.out.println("<!-------------------- END RESPONSE TO CLIENT ----------->");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpClientBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */