/*     */ package weblogic.webservice.binding.soap;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import weblogic.utils.io.Chunk;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpResponseParser
/*     */ {
/*     */   private static final boolean debug = false;
/*  25 */   private static final char[] HTTP_STATUS = { 'H', 'T', 'T', 'P', '/' };
/*     */ 
/*     */ 
/*     */   
/*     */   public static HttpResponse parse(URL paramURL, InputStream paramInputStream) throws IOException {
/*  30 */     HttpResponse httpResponse = new HttpResponse(paramURL);
/*     */     
/*  32 */     Chunk chunk1 = newChunk();
/*     */     
/*     */     try {
/*  35 */       readLine(chunk1, paramInputStream);
/*  36 */     } catch (EOFException eOFException) {
/*  37 */       throwEOF(chunk1, paramURL);
/*     */     } 
/*     */     
/*  40 */     Chunk chunk2 = parseFirstLine(chunk1, httpResponse);
/*     */ 
/*     */ 
/*     */     
/*  44 */     chunk2 = parseHTTPHeaders(chunk2, httpResponse, paramInputStream);
/*     */     
/*  46 */     if (chunk2.end == Chunk.CHUNK_SIZE)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  51 */       chunk2.end = 0;
/*     */     }
/*     */ 
/*     */     
/*  55 */     checkKeepAlive(httpResponse);
/*     */ 
/*     */     
/*  58 */     int i = chunk2.end;
/*     */     
/*  60 */     if (httpResponse.isKeepAliveEnabled()) {
/*     */       
/*  62 */       String str = httpResponse.getHeader("content-length");
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  67 */         int j = Integer.parseInt(str);
/*     */         
/*  69 */         fillKeepAliveChunk(chunk2, j, paramInputStream);
/*     */       }
/*  71 */       catch (NumberFormatException numberFormatException) {
/*  72 */         throw new IOException("Content-length was not a number:" + str);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  77 */       fillChunkUntilEOF(chunk2, paramInputStream);
/*     */     } 
/*     */     
/*  80 */     httpResponse.setBody(chunk2, i);
/*     */     
/*  82 */     return httpResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkKeepAlive(HttpResponse paramHttpResponse) throws IOException {
/*  90 */     String str = paramHttpResponse.getHeader("CONNECTION");
/*     */     
/*  92 */     if (str == null) {
/*     */       
/*  94 */       paramHttpResponse.setKeepAliveEnabled((paramHttpResponse.getMinorVersion() == 1));
/*     */     } else {
/*  96 */       paramHttpResponse.setKeepAliveEnabled("keep-alive".equalsIgnoreCase(str));
/*     */     } 
/*     */     
/*  99 */     if (paramHttpResponse.isKeepAliveEnabled())
/*     */     {
/*     */ 
/*     */       
/* 103 */       if ("chunked".equalsIgnoreCase(paramHttpResponse.getHeader("Transfer-Encoding"))) {
/* 104 */         throw new IOException("The server at: " + paramHttpResponse.getURL() + " specified Transfer-Encoding: chunked.  This HTTP client" + " does not currently support chunked transfer encoding.");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 110 */     if (paramHttpResponse.getHeader("content-length") == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 121 */       paramHttpResponse.setKeepAliveEnabled(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 126 */   private static String msg2String(Chunk paramChunk) { return msg2String(paramChunk, 0); }
/*     */ 
/*     */   
/*     */   private static String msg2String(Chunk paramChunk, int paramInt) {
/* 130 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 132 */     stringBuffer.append(new String(paramChunk.buf, paramInt, paramChunk.end));
/*     */     
/* 134 */     for (Chunk chunk = paramChunk.next; chunk != null; chunk = chunk.next) {
/* 135 */       stringBuffer.append(new String(chunk.buf, 0, chunk.end));
/*     */     }
/*     */     
/* 138 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 142 */   private static Chunk newChunk() { return newChunk((Chunk)null); }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Chunk newChunk(Chunk paramChunk) {
/* 147 */     Chunk chunk = Chunk.getChunk();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (paramChunk != null) paramChunk.next = chunk;
/*     */     
/* 159 */     return chunk;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Chunk parseFirstLine(Chunk paramChunk, HttpResponse paramHttpResponse) throws IOException {
/*     */     byte b;
/* 166 */     for (b = 0; b < HTTP_STATUS.length; b++) {
/* 167 */       if (paramChunk.buf[b] != HTTP_STATUS[b]) {
/* 168 */         WebServiceLogger.logInvalidHttpResponse2(paramHttpResponse.getURL().toString(), msg2String(paramChunk));
/*     */         
/* 170 */         throw new IOException("The server at :" + paramHttpResponse.getURL() + " did not provide a valid HTTP response: " + msg2String(paramChunk));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 176 */     b = paramChunk.buf[5] - 48;
/* 177 */     byte b1 = paramChunk.buf[7] - 48;
/*     */     
/* 179 */     paramHttpResponse.setMajorVersion(b);
/* 180 */     paramHttpResponse.setMinorVersion(b1);
/*     */     
/* 182 */     if (b != 1) {
/* 183 */       WebServiceLogger.logUnexpectedHTTPVersion(paramHttpResponse.getURL().toString(), b, b1, msg2String(paramChunk));
/*     */ 
/*     */       
/* 186 */       throw new IOException("The server at :" + paramHttpResponse.getURL() + " did not provide a valid HTTP response: " + msg2String(paramChunk));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 191 */     if (b1 == 1 || b1 == 0) {
/*     */ 
/*     */       
/* 194 */       byte b2 = (paramChunk.buf[9] - 48) * 100 + (paramChunk.buf[10] - 48) * 10 + paramChunk.buf[11] - 48;
/*     */ 
/*     */       
/* 197 */       paramHttpResponse.setStatusCode(b2);
/*     */       
/* 199 */       return paramChunk;
/*     */     } 
/*     */     
/* 202 */     WebServiceLogger.logUnexpectedHTTPVersion(paramHttpResponse.getURL().toString(), b, b1, msg2String(paramChunk));
/*     */ 
/*     */     
/* 205 */     throw new IOException("The server at :" + paramHttpResponse.getURL() + " did not provide a valid HTTP response: " + msg2String(paramChunk));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Chunk parseHTTPHeaders(Chunk paramChunk, HttpResponse paramHttpResponse, InputStream paramInputStream) throws IOException {
/* 218 */     Chunk chunk = paramChunk;
/*     */ 
/*     */     
/*     */     label33: while (true) {
/* 222 */       if (chunk.end == Chunk.CHUNK_SIZE) {
/* 223 */         chunk = newChunk(chunk);
/*     */       }
/*     */       
/* 226 */       int i = chunk.end;
/*     */       
/* 228 */       readLine(chunk, paramInputStream);
/*     */ 
/*     */       
/* 231 */       if (chunk.buf[i] == 13)
/*     */       {
/* 233 */         if (i + 1 == Chunk.CHUNK_SIZE) {
/*     */ 
/*     */           
/* 236 */           Chunk chunk1 = chunk.next;
/*     */           
/* 238 */           if (chunk1.buf[0] == 10) {
/* 239 */             return chunk1;
/*     */           }
/*     */         }
/* 242 */         else if (chunk.buf[i + 1] == 10) {
/* 243 */           return chunk;
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 250 */       StringBuffer stringBuffer1 = new StringBuffer();
/* 251 */       StringBuffer stringBuffer2 = new StringBuffer();
/*     */       
/* 253 */       boolean bool = true;
/*     */       
/* 255 */       for (int j = i;; j++) {
/*     */         
/* 257 */         if (j == chunk.end) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 262 */           if (j < Chunk.CHUNK_SIZE || chunk.next == null) {
/*     */             
/* 264 */             paramHttpResponse.addHeader(stringBuffer1.toString(), stringBuffer2.toString());
/*     */             continue label33;
/*     */           } 
/* 267 */           j = 0;
/* 268 */           Chunk chunk1 = chunk;
/* 269 */           chunk = chunk.next;
/* 270 */           Chunk.releaseChunk(chunk1);
/*     */         
/*     */         }
/* 273 */         else if (chunk.buf[j] == 58) {
/* 274 */           bool = false;
/* 275 */         } else if (bool) {
/* 276 */           stringBuffer1.append((char)chunk.buf[j]);
/*     */         } else {
/* 278 */           stringBuffer2.append((char)chunk.buf[j]);
/*     */         } 
/*     */       } 
/*     */       break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static int msgSize(Chunk paramChunk) {
/* 287 */     int i = 0;
/*     */     
/* 289 */     for (Chunk chunk = paramChunk; chunk != null; chunk = chunk.next) {
/* 290 */       i += chunk.end;
/*     */     }
/*     */     
/* 293 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void throwEOF(Chunk paramChunk, URL paramURL) throws EOFException {
/* 299 */     WebServiceLogger.logUnexpectedEOF(paramURL.getProtocol(), paramURL.getHost(), paramURL.getPort(), msgSize(paramChunk));
/*     */ 
/*     */     
/* 302 */     throw new EOFException("Received EOF from: " + paramURL + " after reading " + msgSize(paramChunk) + " bytes.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void readLine(Chunk paramChunk, InputStream paramInputStream) throws IOException {
/* 322 */     boolean bool = false;
/*     */     
/* 324 */     Chunk chunk = paramChunk;
/*     */ 
/*     */     
/*     */     while (true) {
/* 328 */       while (chunk.end == Chunk.CHUNK_SIZE) {
/* 329 */         chunk = newChunk(chunk);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 334 */       int i = paramInputStream.read();
/* 335 */       if (i == -1) {
/* 336 */         throw new EOFException();
/*     */       }
/* 338 */       chunk.buf[chunk.end++] = (byte)i;
/*     */       
/* 340 */       if (i == 13) { bool = true; continue; }
/* 341 */        if (bool && i == 10)
/* 342 */         return;  bool = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fillKeepAliveChunk(Chunk paramChunk, int paramInt, InputStream paramInputStream) throws IOException {
/* 354 */     int i = 0;
/*     */     
/* 356 */     Chunk chunk = paramChunk;
/*     */     
/* 358 */     while (i < paramInt) {
/* 359 */       if (chunk.end == Chunk.CHUNK_SIZE) {
/* 360 */         chunk = newChunk(chunk);
/*     */       }
/*     */       
/* 363 */       int j = Math.min(paramInt - i, Chunk.CHUNK_SIZE - chunk.end);
/*     */ 
/*     */       
/* 366 */       int k = paramInputStream.read(chunk.buf, chunk.end, j);
/*     */       
/* 368 */       if (k == -1) {
/* 369 */         WebServiceLogger.logInvalidHttpResponse9();
/* 370 */         throw new IOException("Received EOF before reading entire message from server");
/*     */       } 
/*     */       
/* 373 */       chunk.end += k;
/* 374 */       i += k;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fillChunkUntilEOF(Chunk paramChunk, InputStream paramInputStream) throws IOException {
/* 383 */     Chunk chunk = paramChunk;
/*     */ 
/*     */     
/*     */     while (true) {
/* 387 */       if (chunk.end == Chunk.CHUNK_SIZE) {
/* 388 */         chunk = newChunk(chunk);
/*     */       }
/*     */       
/* 391 */       int i = paramInputStream.read(chunk.buf, chunk.end, Chunk.CHUNK_SIZE - chunk.end);
/*     */ 
/*     */       
/* 394 */       if (i == -1)
/*     */         return; 
/* 396 */       chunk.end += i;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpResponseParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */