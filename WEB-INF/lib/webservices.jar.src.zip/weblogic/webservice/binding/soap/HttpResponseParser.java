package weblogic.webservice.binding.soap;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import weblogic.utils.io.Chunk;
import weblogic.webservice.WebServiceLogger;

public final class HttpResponseParser {
  private static final boolean debug = false;
  
  private static final char[] HTTP_STATUS = { 'H', 'T', 'T', 'P', '/' };
  
  public static HttpResponse parse(URL paramURL, InputStream paramInputStream) throws IOException {
    HttpResponse httpResponse = new HttpResponse(paramURL);
    Chunk chunk1 = newChunk();
    try {
      readLine(chunk1, paramInputStream);
    } catch (EOFException eOFException) {
      throwEOF(chunk1, paramURL);
    } 
    Chunk chunk2 = parseFirstLine(chunk1, httpResponse);
    chunk2 = parseHTTPHeaders(chunk2, httpResponse, paramInputStream);
    if (chunk2.end == Chunk.CHUNK_SIZE)
      chunk2.end = 0; 
    checkKeepAlive(httpResponse);
    int i = chunk2.end;
    if (httpResponse.isKeepAliveEnabled()) {
      String str = httpResponse.getHeader("content-length");
      try {
        int j = Integer.parseInt(str);
        fillKeepAliveChunk(chunk2, j, paramInputStream);
      } catch (NumberFormatException numberFormatException) {
        throw new IOException("Content-length was not a number:" + str);
      } 
    } else {
      fillChunkUntilEOF(chunk2, paramInputStream);
    } 
    httpResponse.setBody(chunk2, i);
    return httpResponse;
  }
  
  private static void checkKeepAlive(HttpResponse paramHttpResponse) throws IOException {
    String str = paramHttpResponse.getHeader("CONNECTION");
    if (str == null) {
      paramHttpResponse.setKeepAliveEnabled((paramHttpResponse.getMinorVersion() == 1));
    } else {
      paramHttpResponse.setKeepAliveEnabled("keep-alive".equalsIgnoreCase(str));
    } 
    if (paramHttpResponse.isKeepAliveEnabled())
      if ("chunked".equalsIgnoreCase(paramHttpResponse.getHeader("Transfer-Encoding")))
        throw new IOException("The server at: " + paramHttpResponse.getURL() + " specified Transfer-Encoding: chunked.  This HTTP client" + " does not currently support chunked transfer encoding.");  
    if (paramHttpResponse.getHeader("content-length") == null)
      paramHttpResponse.setKeepAliveEnabled(false); 
  }
  
  private static String msg2String(Chunk paramChunk) { return msg2String(paramChunk, 0); }
  
  private static String msg2String(Chunk paramChunk, int paramInt) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(new String(paramChunk.buf, paramInt, paramChunk.end));
    for (Chunk chunk = paramChunk.next; chunk != null; chunk = chunk.next)
      stringBuffer.append(new String(chunk.buf, 0, chunk.end)); 
    return stringBuffer.toString();
  }
  
  private static Chunk newChunk() { return newChunk((Chunk)null); }
  
  private static Chunk newChunk(Chunk paramChunk) {
    Chunk chunk = Chunk.getChunk();
    if (paramChunk != null)
      paramChunk.next = chunk; 
    return chunk;
  }
  
  private static Chunk parseFirstLine(Chunk paramChunk, HttpResponse paramHttpResponse) throws IOException {
    byte b;
    for (b = 0; b < HTTP_STATUS.length; b++) {
      if (paramChunk.buf[b] != HTTP_STATUS[b]) {
        WebServiceLogger.logInvalidHttpResponse2(paramHttpResponse.getURL().toString(), msg2String(paramChunk));
        throw new IOException("The server at :" + paramHttpResponse.getURL() + " did not provide a valid HTTP response: " + msg2String(paramChunk));
      } 
    } 
    b = paramChunk.buf[5] - 48;
    byte b1 = paramChunk.buf[7] - 48;
    paramHttpResponse.setMajorVersion(b);
    paramHttpResponse.setMinorVersion(b1);
    if (b != 1) {
      WebServiceLogger.logUnexpectedHTTPVersion(paramHttpResponse.getURL().toString(), b, b1, msg2String(paramChunk));
      throw new IOException("The server at :" + paramHttpResponse.getURL() + " did not provide a valid HTTP response: " + msg2String(paramChunk));
    } 
    if (b1 == 1 || b1 == 0) {
      byte b2 = (paramChunk.buf[9] - 48) * 100 + (paramChunk.buf[10] - 48) * 10 + paramChunk.buf[11] - 48;
      paramHttpResponse.setStatusCode(b2);
      return paramChunk;
    } 
    WebServiceLogger.logUnexpectedHTTPVersion(paramHttpResponse.getURL().toString(), b, b1, msg2String(paramChunk));
    throw new IOException("The server at :" + paramHttpResponse.getURL() + " did not provide a valid HTTP response: " + msg2String(paramChunk));
  }
  
  private static Chunk parseHTTPHeaders(Chunk paramChunk, HttpResponse paramHttpResponse, InputStream paramInputStream) throws IOException {
    Chunk chunk = paramChunk;
    label33: while (true) {
      if (chunk.end == Chunk.CHUNK_SIZE)
        chunk = newChunk(chunk); 
      int i = chunk.end;
      readLine(chunk, paramInputStream);
      if (chunk.buf[i] == 13)
        if (i + 1 == Chunk.CHUNK_SIZE) {
          Chunk chunk1 = chunk.next;
          if (chunk1.buf[0] == 10)
            return chunk1; 
        } else if (chunk.buf[i + 1] == 10) {
          return chunk;
        }  
      StringBuffer stringBuffer1 = new StringBuffer();
      StringBuffer stringBuffer2 = new StringBuffer();
      boolean bool = true;
      for (int j = i;; j++) {
        if (j == chunk.end) {
          if (j < Chunk.CHUNK_SIZE || chunk.next == null) {
            paramHttpResponse.addHeader(stringBuffer1.toString(), stringBuffer2.toString());
            continue label33;
          } 
          j = 0;
          Chunk chunk1 = chunk;
          chunk = chunk.next;
          Chunk.releaseChunk(chunk1);
        } else if (chunk.buf[j] == 58) {
          bool = false;
        } else if (bool) {
          stringBuffer1.append((char)chunk.buf[j]);
        } else {
          stringBuffer2.append((char)chunk.buf[j]);
        } 
      } 
      break;
    } 
  }
  
  private static int msgSize(Chunk paramChunk) {
    int i = 0;
    for (Chunk chunk = paramChunk; chunk != null; chunk = chunk.next)
      i += chunk.end; 
    return i;
  }
  
  private static void throwEOF(Chunk paramChunk, URL paramURL) throws EOFException {
    WebServiceLogger.logUnexpectedEOF(paramURL.getProtocol(), paramURL.getHost(), paramURL.getPort(), msgSize(paramChunk));
    throw new EOFException("Received EOF from: " + paramURL + " after reading " + msgSize(paramChunk) + " bytes.");
  }
  
  private static void readLine(Chunk paramChunk, InputStream paramInputStream) throws IOException {
    boolean bool = false;
    Chunk chunk = paramChunk;
    while (true) {
      while (chunk.end == Chunk.CHUNK_SIZE)
        chunk = newChunk(chunk); 
      int i = paramInputStream.read();
      if (i == -1)
        throw new EOFException(); 
      chunk.buf[chunk.end++] = (byte)i;
      if (i == 13) {
        bool = true;
        continue;
      } 
      if (bool && i == 10)
        return; 
      bool = false;
    } 
  }
  
  private static void fillKeepAliveChunk(Chunk paramChunk, int paramInt, InputStream paramInputStream) throws IOException {
    int i = 0;
    Chunk chunk = paramChunk;
    while (i < paramInt) {
      if (chunk.end == Chunk.CHUNK_SIZE)
        chunk = newChunk(chunk); 
      int j = Math.min(paramInt - i, Chunk.CHUNK_SIZE - chunk.end);
      int k = paramInputStream.read(chunk.buf, chunk.end, j);
      if (k == -1) {
        WebServiceLogger.logInvalidHttpResponse9();
        throw new IOException("Received EOF before reading entire message from server");
      } 
      chunk.end += k;
      i += k;
    } 
  }
  
  private static void fillChunkUntilEOF(Chunk paramChunk, InputStream paramInputStream) throws IOException {
    Chunk chunk = paramChunk;
    while (true) {
      if (chunk.end == Chunk.CHUNK_SIZE)
        chunk = newChunk(chunk); 
      int i = paramInputStream.read(chunk.buf, chunk.end, Chunk.CHUNK_SIZE - chunk.end);
      if (i == -1)
        return; 
      chunk.end += i;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\soap\HttpResponseParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */