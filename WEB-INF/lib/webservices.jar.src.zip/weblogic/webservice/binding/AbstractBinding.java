package weblogic.webservice.binding;

public abstract class AbstractBinding implements Binding {
  private String replyTo;
  
  private String sender;
  
  private String destination;
  
  private BindingInfo bindingInfo;
  
  private int type;
  
  public static final int CLIENT_SIDE = 0;
  
  public static final int SERVER_SIDE = 1;
  
  public void setServerSide() { this.type = 1; }
  
  public void setClientSide() { this.type = 0; }
  
  public boolean isServerSide() { return (this.type == 1); }
  
  public boolean isClientSide() { return (this.type == 0); }
  
  public String getReplyTo() { return this.replyTo; }
  
  public void setReplyTo(String paramString) { this.replyTo = paramString; }
  
  public String getSender() { return this.sender; }
  
  public void setSender(String paramString) { this.sender = paramString; }
  
  public String getDestination() { return this.destination; }
  
  public void setDestination(String paramString) { this.destination = paramString; }
  
  protected void setBindingInfo(BindingInfo paramBindingInfo) { this.bindingInfo = paramBindingInfo; }
  
  public BindingInfo getBindingInfo() { return this.bindingInfo; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\AbstractBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */