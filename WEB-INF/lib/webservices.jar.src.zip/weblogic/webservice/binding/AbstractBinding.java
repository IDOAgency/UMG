/*    */ package weblogic.webservice.binding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBinding
/*    */   implements Binding
/*    */ {
/*    */   private String replyTo;
/*    */   private String sender;
/*    */   private String destination;
/*    */   private BindingInfo bindingInfo;
/*    */   private int type;
/*    */   public static final int CLIENT_SIDE = 0;
/*    */   public static final int SERVER_SIDE = 1;
/*    */   
/* 23 */   public void setServerSide() { this.type = 1; }
/*    */ 
/*    */ 
/*    */   
/* 27 */   public void setClientSide() { this.type = 0; }
/*    */ 
/*    */ 
/*    */   
/* 31 */   public boolean isServerSide() { return (this.type == 1); }
/*    */ 
/*    */ 
/*    */   
/* 35 */   public boolean isClientSide() { return (this.type == 0); }
/*    */ 
/*    */ 
/*    */   
/* 39 */   public String getReplyTo() { return this.replyTo; }
/*    */ 
/*    */ 
/*    */   
/* 43 */   public void setReplyTo(String paramString) { this.replyTo = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 47 */   public String getSender() { return this.sender; }
/*    */ 
/*    */ 
/*    */   
/* 51 */   public void setSender(String paramString) { this.sender = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 55 */   public String getDestination() { return this.destination; }
/*    */ 
/*    */ 
/*    */   
/* 59 */   public void setDestination(String paramString) { this.destination = paramString; }
/*    */ 
/*    */ 
/*    */   
/* 63 */   protected void setBindingInfo(BindingInfo paramBindingInfo) { this.bindingInfo = paramBindingInfo; }
/*    */ 
/*    */ 
/*    */   
/* 67 */   public BindingInfo getBindingInfo() { return this.bindingInfo; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\AbstractBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */