/*     */ package weblogic.webservice.binding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindingInfo
/*     */ {
/*     */   public static final String SOAP11 = "SOAP1.1";
/*     */   public static final String SOAP12 = "SOAP1.2";
/*     */   public static final String DEFAULT_TRANSPORT = "http11";
/*     */   private String transport;
/*     */   private String address;
/*     */   private String type;
/*     */   private String acceptCharset;
/*     */   private String charset;
/*     */   private int timeout;
/*     */   private boolean verbose;
/*     */   private BindingExtension[] allBindings;
/*     */   
/*  30 */   public BindingInfo() { this("http11"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTransport() { return this.transport; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAddress() { return this.address; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAddress(String paramString) { this.address = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String paramString) { this.type = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() { return this.type; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSoap12() { return "SOAP1.2".equals(getType()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BindingInfo(String paramString) {
/*     */     this.type = "SOAP1.1";
/*     */     this.charset = null;
/*     */     this.timeout = -1;
/* 170 */     this.allBindings = new BindingExtension[2];
/*     */     this.transport = paramString;
/*     */   }
/*     */   
/*     */   public String getCharset() { return this.charset; }
/*     */   
/*     */   public BindingExtension getExtension(int paramInt) {
/* 177 */     if (paramInt < 0 || paramInt >= 2) {
/* 178 */       throw new IllegalArgumentException("Binding key is out of range");
/*     */     }
/* 180 */     return this.allBindings[paramInt];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharset(String paramString) { this.charset = paramString; }
/*     */   
/*     */   public void addExtension(BindingExtension paramBindingExtension) {
/* 187 */     if (paramBindingExtension == null) {
/* 188 */       throw new IllegalArgumentException("ext cannot be null");
/*     */     }
/* 190 */     int i = paramBindingExtension.getKey();
/* 191 */     if (i < 0 || i >= 2) {
/* 192 */       throw new IllegalArgumentException("Binding key is out of range");
/*     */     }
/* 194 */     this.allBindings[i] = paramBindingExtension;
/*     */   }
/*     */   
/*     */   public int getTimeout() { return this.timeout; }
/*     */   
/*     */   public void setTimeout(int paramInt) { this.timeout = paramInt; }
/*     */   
/*     */   public String getAcceptCharset() { return this.acceptCharset; }
/*     */   
/*     */   public void setAcceptCharset(String paramString) { this.acceptCharset = paramString; }
/*     */   
/*     */   public boolean isVerbose() { return this.verbose; }
/*     */   
/*     */   public void setVerbose(boolean paramBoolean) { this.verbose = paramBoolean; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\binding\BindingInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */