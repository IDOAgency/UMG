package weblogic.webservice.component.jms;

import java.io.Serializable;
import java.lang.reflect.Method;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.rpc.JAXRPCException;
import weblogic.jms.common.DestinationImpl;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.server.ConfigException;

public final class JMSSendInvocationHandler implements InvocationHandler {
  private Destination destination;
  
  private ConnectionFactory factory;
  
  private String destName;
  
  private String connectionFactoryName;
  
  private int numFailed;
  
  public JMSSendInvocationHandler(String paramString1, String paramString2) throws ConfigException {
    this.connectionFactoryName = paramString1;
    this.destName = paramString2;
    this.numFailed = 0;
    init();
  }
  
  private void init() throws ConfigException {
    InitialContext initialContext = null;
    try {
      initialContext = new InitialContext();
    } catch (NamingException namingException) {
      this.numFailed++;
      if (this.numFailed == 1) {
        WebServiceLogger.logJMSQueueNamingWarning();
        return;
      } 
      if (this.numFailed == 2) {
        String str = WebServiceLogger.logJMSQueueNamingException();
        WebServiceLogger.logStackTrace(str, namingException);
      } 
      throw new ConfigException(namingException.getMessage(), namingException);
    } 
    try {
      this.factory = (ConnectionFactory)initialContext.lookup(this.connectionFactoryName);
    } catch (Exception exception) {
      try {
        String str = "java:/comp/env/" + this.connectionFactoryName;
        this.factory = (QueueConnectionFactory)initialContext.lookup(str);
      } catch (Exception exception1) {
        this.numFailed++;
        if (this.numFailed == 1) {
          WebServiceLogger.logJMSQueueFactoryWarning();
          return;
        } 
        if (this.numFailed == 2) {
          String str = WebServiceLogger.logJMSQueueFactoryException();
          WebServiceLogger.logStackTrace(str, exception1);
        } 
        throw new ConfigException(exception1.getMessage(), exception1);
      } 
    } 
    try {
      this.destination = (Destination)initialContext.lookup(this.destName);
    } catch (Exception exception) {
      try {
        String str = "java:/comp/env/" + this.destName;
        this.destination = (Destination)initialContext.lookup(str);
      } catch (Exception exception1) {
        this.numFailed++;
        if (this.numFailed == 1) {
          WebServiceLogger.logJMSQueueLocateWarning();
          return;
        } 
        if (this.numFailed == 2) {
          String str = WebServiceLogger.logJMSQueueLocateException();
          WebServiceLogger.logStackTrace(str, exception1);
        } 
        throw new ConfigException(exception1.getMessage(), exception1);
      } 
    } 
  }
  
  public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
    if (paramArrayOfObject == null || paramArrayOfObject.length == 0)
      throw new JAXRPCException("No send payload"); 
    if (this.destination == null)
      try {
        init();
      } catch (ConfigException configException) {
        throw new JAXRPCException(configException);
      }  
    Object object = paramArrayOfObject[0];
    if (!(object instanceof Serializable))
      throw new JAXRPCException("Payload not Serializable.  Java type is " + String.valueOf(object)); 
    try {
      boolean bool1 = false;
      boolean bool2 = false;
      if (this.destination instanceof DestinationImpl) {
        DestinationImpl destinationImpl = (DestinationImpl)this.destination;
        bool1 = destinationImpl.isQueue();
        bool2 = destinationImpl.isTopic();
      } else if (this.destination instanceof Queue) {
        bool1 = true;
      } else if (this.destination instanceof Topic) {
        bool2 = true;
      } 
      if (bool1) {
        sendToQueue((QueueConnectionFactory)this.factory, (Queue)this.destination, (Serializable)object);
      } else if (bool2) {
        sendToTopic((TopicConnectionFactory)this.factory, (Topic)this.destination, (Serializable)object);
      } 
    } catch (JMSException jMSException) {
      throw new JAXRPCException(jMSException);
    } 
    return null;
  }
  
  public Method[] getAllMethods() { return null; }
  
  public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {}
  
  private static void sendToQueue(QueueConnectionFactory paramQueueConnectionFactory, Queue paramQueue, Serializable paramSerializable) throws JMSException {
    queueConnection = null;
    queueSession = null;
    queueSender = null;
    try {
      queueConnection = paramQueueConnectionFactory.createQueueConnection();
      queueSession = queueConnection.createQueueSession(false, 1);
      queueSender = queueSession.createSender(paramQueue);
      objectMessage = queueSession.createObjectMessage();
      objectMessage.setObject(paramSerializable);
      queueConnection.start();
      queueSender.send(objectMessage);
    } finally {
      try {
        if (queueSender != null)
          queueSender.close(); 
      } catch (JMSException jMSException) {}
      try {
        if (queueSession != null)
          queueSession.close(); 
      } catch (JMSException jMSException) {}
      try {
        if (queueConnection != null)
          queueConnection.close(); 
      } catch (JMSException jMSException) {}
    } 
  }
  
  private static void sendToTopic(TopicConnectionFactory paramTopicConnectionFactory, Topic paramTopic, Serializable paramSerializable) throws JMSException {
    topicConnection = null;
    topicSession = null;
    topicPublisher = null;
    try {
      topicConnection = paramTopicConnectionFactory.createTopicConnection();
      topicSession = topicConnection.createTopicSession(false, 1);
      topicPublisher = topicSession.createPublisher(paramTopic);
      objectMessage = topicSession.createObjectMessage();
      objectMessage.setObject(paramSerializable);
      topicConnection.start();
      topicPublisher.publish(objectMessage);
    } finally {
      try {
        if (topicPublisher != null)
          topicPublisher.close(); 
      } catch (JMSException jMSException) {}
      try {
        if (topicSession != null)
          topicSession.close(); 
      } catch (JMSException jMSException) {}
      try {
        if (topicConnection != null)
          topicConnection.close(); 
      } catch (JMSException jMSException) {}
    } 
  }
  
  public int getType() {
    try {
      return ((DestinationImpl)this.destination).isTopic() ? 5 : 6;
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public String getInfo() { return "ConnectionFactory: " + this.connectionFactoryName + "  Destination: " + this.destName; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\jms\JMSSendInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */