/*     */ package weblogic.webservice.component.jms;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.ObjectMessage;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicConnection;
/*     */ import javax.jms.TopicConnectionFactory;
/*     */ import javax.jms.TopicPublisher;
/*     */ import javax.jms.TopicSession;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.jms.common.DestinationImpl;
/*     */ import weblogic.webservice.InvocationHandler;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ 
/*     */ public final class JMSSendInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*     */   private Destination destination;
/*     */   private ConnectionFactory factory;
/*     */   
/*     */   public JMSSendInvocationHandler(String paramString1, String paramString2) throws ConfigException {
/*  36 */     this.connectionFactoryName = paramString1;
/*  37 */     this.destName = paramString2;
/*  38 */     this.numFailed = 0;
/*     */     
/*  40 */     init();
/*     */   }
/*     */   private String destName; private String connectionFactoryName;
/*     */   private int numFailed;
/*     */   
/*     */   private void init() throws ConfigException {
/*  46 */     InitialContext initialContext = null;
/*     */     
/*     */     try {
/*  49 */       initialContext = new InitialContext();
/*  50 */     } catch (NamingException namingException) {
/*  51 */       this.numFailed++;
/*  52 */       if (this.numFailed == 1) {
/*  53 */         WebServiceLogger.logJMSQueueNamingWarning(); return;
/*     */       } 
/*  55 */       if (this.numFailed == 2) {
/*  56 */         String str = WebServiceLogger.logJMSQueueNamingException();
/*  57 */         WebServiceLogger.logStackTrace(str, namingException);
/*     */       } 
/*  59 */       throw new ConfigException(namingException.getMessage(), namingException);
/*     */     } 
/*     */     
/*     */     try {
/*  63 */       this.factory = (ConnectionFactory)initialContext.lookup(this.connectionFactoryName);
/*  64 */     } catch (Exception exception) {
/*     */       try {
/*  66 */         String str = "java:/comp/env/" + this.connectionFactoryName;
/*     */         
/*  68 */         this.factory = (QueueConnectionFactory)initialContext.lookup(str);
/*     */       }
/*  70 */       catch (Exception exception1) {
/*  71 */         this.numFailed++;
/*  72 */         if (this.numFailed == 1) {
/*  73 */           WebServiceLogger.logJMSQueueFactoryWarning(); return;
/*     */         } 
/*  75 */         if (this.numFailed == 2) {
/*  76 */           String str = WebServiceLogger.logJMSQueueFactoryException();
/*  77 */           WebServiceLogger.logStackTrace(str, exception1);
/*     */         } 
/*  79 */         throw new ConfigException(exception1.getMessage(), exception1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/*  84 */       this.destination = (Destination)initialContext.lookup(this.destName);
/*  85 */     } catch (Exception exception) {
/*     */       try {
/*  87 */         String str = "java:/comp/env/" + this.destName;
/*  88 */         this.destination = (Destination)initialContext.lookup(str);
/*  89 */       } catch (Exception exception1) {
/*  90 */         this.numFailed++;
/*  91 */         if (this.numFailed == 1) {
/*  92 */           WebServiceLogger.logJMSQueueLocateWarning(); return;
/*     */         } 
/*  94 */         if (this.numFailed == 2) {
/*  95 */           String str = WebServiceLogger.logJMSQueueLocateException();
/*  96 */           WebServiceLogger.logStackTrace(str, exception1);
/*     */         } 
/*  98 */         throw new ConfigException(exception1.getMessage(), exception1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
/* 106 */     if (paramArrayOfObject == null || paramArrayOfObject.length == 0) {
/* 107 */       throw new JAXRPCException("No send payload");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (this.destination == null) {
/*     */       try {
/* 114 */         init();
/* 115 */       } catch (ConfigException configException) {
/* 116 */         throw new JAXRPCException(configException);
/*     */       } 
/*     */     }
/*     */     
/* 120 */     Object object = paramArrayOfObject[0];
/*     */     
/* 122 */     if (!(object instanceof Serializable)) {
/* 123 */       throw new JAXRPCException("Payload not Serializable.  Java type is " + String.valueOf(object));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 130 */       boolean bool1 = false;
/* 131 */       boolean bool2 = false;
/*     */       
/* 133 */       if (this.destination instanceof DestinationImpl) {
/* 134 */         DestinationImpl destinationImpl = (DestinationImpl)this.destination;
/* 135 */         bool1 = destinationImpl.isQueue();
/* 136 */         bool2 = destinationImpl.isTopic();
/* 137 */       } else if (this.destination instanceof Queue) {
/* 138 */         bool1 = true;
/* 139 */       } else if (this.destination instanceof Topic) {
/* 140 */         bool2 = true;
/*     */       } 
/* 142 */       if (bool1) {
/* 143 */         sendToQueue((QueueConnectionFactory)this.factory, (Queue)this.destination, (Serializable)object);
/*     */       }
/* 145 */       else if (bool2) {
/* 146 */         sendToTopic((TopicConnectionFactory)this.factory, (Topic)this.destination, (Serializable)object);
/*     */       }
/*     */     
/* 149 */     } catch (JMSException jMSException) {
/* 150 */       throw new JAXRPCException(jMSException);
/*     */     } 
/*     */     
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 157 */   public Method[] getAllMethods() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static void sendToQueue(QueueConnectionFactory paramQueueConnectionFactory, Queue paramQueue, Serializable paramSerializable) throws JMSException {
/* 167 */     queueConnection = null;
/* 168 */     queueSession = null;
/* 169 */     queueSender = null;
/*     */     try {
/* 171 */       queueConnection = paramQueueConnectionFactory.createQueueConnection();
/* 172 */       queueSession = queueConnection.createQueueSession(false, 1);
/*     */       
/* 174 */       queueSender = queueSession.createSender(paramQueue);
/* 175 */       objectMessage = queueSession.createObjectMessage();
/* 176 */       objectMessage.setObject(paramSerializable);
/* 177 */       queueConnection.start();
/* 178 */       queueSender.send(objectMessage);
/*     */     } finally {
/*     */       try {
/* 181 */         if (queueSender != null) queueSender.close(); 
/* 182 */       } catch (JMSException jMSException) {}
/*     */       try {
/* 184 */         if (queueSession != null) queueSession.close(); 
/* 185 */       } catch (JMSException jMSException) {}
/*     */       try {
/* 187 */         if (queueConnection != null) queueConnection.close(); 
/* 188 */       } catch (JMSException jMSException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void sendToTopic(TopicConnectionFactory paramTopicConnectionFactory, Topic paramTopic, Serializable paramSerializable) throws JMSException {
/* 196 */     topicConnection = null;
/* 197 */     topicSession = null;
/* 198 */     topicPublisher = null;
/*     */     try {
/* 200 */       topicConnection = paramTopicConnectionFactory.createTopicConnection();
/* 201 */       topicSession = topicConnection.createTopicSession(false, 1);
/*     */       
/* 203 */       topicPublisher = topicSession.createPublisher(paramTopic);
/* 204 */       objectMessage = topicSession.createObjectMessage();
/* 205 */       objectMessage.setObject(paramSerializable);
/* 206 */       topicConnection.start();
/* 207 */       topicPublisher.publish(objectMessage);
/*     */     } finally {
/*     */       try {
/* 210 */         if (topicPublisher != null) topicPublisher.close(); 
/* 211 */       } catch (JMSException jMSException) {}
/*     */       try {
/* 213 */         if (topicSession != null) topicSession.close(); 
/* 214 */       } catch (JMSException jMSException) {}
/*     */       try {
/* 216 */         if (topicConnection != null) topicConnection.close(); 
/* 217 */       } catch (JMSException jMSException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/*     */     try {
/* 225 */       return ((DestinationImpl)this.destination).isTopic() ? 5 : 6;
/*     */     }
/* 227 */     catch (Exception exception) {
/* 228 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 233 */   public String getInfo() { return "ConnectionFactory: " + this.connectionFactoryName + "  Destination: " + this.destName; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\jms\JMSSendInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */