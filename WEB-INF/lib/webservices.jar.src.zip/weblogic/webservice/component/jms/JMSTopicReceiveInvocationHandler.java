package weblogic.webservice.component.jms;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.xml.rpc.JAXRPCException;
import weblogic.utils.AssertionError;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.binding.soap.HttpServerBinding;
import weblogic.webservice.server.ConfigException;

public final class JMSTopicReceiveInvocationHandler implements InvocationHandler {
  private Topic topic;
  
  private TopicConnectionFactory factory;
  
  private String topicName;
  
  private String connectionFactoryName;
  
  public JMSTopicReceiveInvocationHandler(String paramString1, String paramString2) throws ConfigException {
    InitialContext initialContext = null;
    try {
      initialContext = new InitialContext();
    } catch (NamingException namingException) {
      String str = WebServiceLogger.logJMSTopicNamingException();
      WebServiceLogger.logStackTrace(str, namingException);
      throw new ConfigException(namingException.getMessage(), namingException);
    } 
    this.connectionFactoryName = paramString1;
    try {
      this.factory = (TopicConnectionFactory)initialContext.lookup(this.connectionFactoryName);
    } catch (Exception exception) {
      try {
        this.connectionFactoryName = "java:/comp/env/" + paramString1;
        this.factory = (TopicConnectionFactory)initialContext.lookup(this.connectionFactoryName);
      } catch (Exception exception1) {
        String str = WebServiceLogger.logJMSTopicFactoryException();
        WebServiceLogger.logStackTrace(str, exception1);
        throw new ConfigException(exception1.getMessage(), exception1);
      } 
    } 
    this.topicName = paramString2;
    try {
      this.topic = (Topic)initialContext.lookup(this.topicName);
    } catch (Exception exception) {
      try {
        this.topicName = "java:/comp/env/" + paramString2;
        this.topic = (Topic)initialContext.lookup(this.topicName);
      } catch (Exception exception1) {
        String str = WebServiceLogger.logJMSTopicContextException();
        WebServiceLogger.logStackTrace(str, exception1);
        throw new ConfigException(exception1.getMessage(), exception1);
      } 
    } 
  }
  
  public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
    Binding binding = (Binding)paramWLMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
    if (binding == null)
      throw new AssertionError("binding can not be null"); 
    if (!(binding instanceof HttpServerBinding))
      throw new JAXRPCException("This end component only supports HTTP transport"); 
    HttpServerBinding httpServerBinding = (HttpServerBinding)binding;
    HttpServletRequest httpServletRequest = httpServerBinding.getRequest();
    HttpSession httpSession = httpServletRequest.getSession();
    Rendezvous rendezvous = (Rendezvous)httpSession.getAttribute("rendezvous");
    if (rendezvous == null)
      try {
        rendezvous = subscribe(this.factory, this.topic);
        httpSession.setAttribute("rendezvous", rendezvous);
      } catch (JMSException jMSException) {
        throw new JAXRPCException(jMSException);
      }  
    return rendezvous.send();
  }
  
  public Method[] getAllMethods() { return null; }
  
  public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {}
  
  private static Rendezvous subscribe(TopicConnectionFactory paramTopicConnectionFactory, Topic paramTopic) throws JMSException {
    TopicConnection topicConnection = null;
    TopicSession topicSession = null;
    TopicSubscriber topicSubscriber = null;
    try {
      topicConnection = paramTopicConnectionFactory.createTopicConnection();
      topicSession = topicConnection.createTopicSession(false, 1);
      topicSubscriber = topicSession.createSubscriber(paramTopic);
      topicConnection.start();
      return new Rendezvous(topicSubscriber);
    } catch (JMSException jMSException) {
      if (topicSubscriber != null)
        try {
          topicSubscriber.close();
        } catch (JMSException jMSException1) {} 
      if (topicSession != null)
        try {
          topicSession.close();
        } catch (JMSException jMSException1) {} 
      if (topicConnection != null)
        try {
          topicConnection.close();
        } catch (JMSException jMSException1) {} 
      throw jMSException;
    } 
  }
  
  private static class Rendezvous implements MessageListener, HttpSessionBindingListener {
    private TopicSubscriber sub;
    
    private List messages;
    
    Rendezvous(TopicSubscriber param1TopicSubscriber) throws JMSException {
      this.sub = param1TopicSubscriber;
      this.sub.setMessageListener(this);
    }
    
    public void valueBound(HttpSessionBindingEvent param1HttpSessionBindingEvent) {}
    
    public void valueUnbound(HttpSessionBindingEvent param1HttpSessionBindingEvent) {
      try {
        this.sub.close();
      } catch (JMSException jMSException) {}
    }
    
    public void onMessage(Message param1Message) {
      Serializable serializable;
      try {
        serializable = ((ObjectMessage)param1Message).getObject();
      } catch (JMSException jMSException) {
        String str = WebServiceLogger.logJMSTopicJMSException();
        WebServiceLogger.logStackTrace(str, jMSException);
        return;
      } 
      if (this.messages == null)
        this.messages = new ArrayList(); 
      this.messages.add(serializable);
    }
    
    public Object send() {
      if (this.messages == null)
        return null; 
      Object object = null;
      if (this.messages.size() > 0) {
        object = this.messages.remove(0);
      } else {
        this.messages = null;
      } 
      return object;
    }
  }
  
  public int getType() { return 4; }
  
  public String getInfo() { return "ConnectionFactory: " + this.connectionFactoryName + "  Topic: " + this.topicName; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\jms\JMSTopicReceiveInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */