/*     */ package weblogic.webservice.component.jms;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.ObjectMessage;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicConnection;
/*     */ import javax.jms.TopicConnectionFactory;
/*     */ import javax.jms.TopicSession;
/*     */ import javax.jms.TopicSubscriber;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.servlet.http.HttpSessionBindingEvent;
/*     */ import javax.servlet.http.HttpSessionBindingListener;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.InvocationHandler;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.binding.soap.HttpServerBinding;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ 
/*     */ 
/*     */ public final class JMSTopicReceiveInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*     */   private Topic topic;
/*     */   private TopicConnectionFactory factory;
/*     */   private String topicName;
/*     */   private String connectionFactoryName;
/*     */   
/*     */   public JMSTopicReceiveInvocationHandler(String paramString1, String paramString2) throws ConfigException {
/*  42 */     InitialContext initialContext = null;
/*     */     
/*     */     try {
/*  45 */       initialContext = new InitialContext();
/*  46 */     } catch (NamingException namingException) {
/*  47 */       String str = WebServiceLogger.logJMSTopicNamingException();
/*  48 */       WebServiceLogger.logStackTrace(str, namingException);
/*  49 */       throw new ConfigException(namingException.getMessage(), namingException);
/*     */     } 
/*     */     
/*  52 */     this.connectionFactoryName = paramString1;
/*     */     try {
/*  54 */       this.factory = (TopicConnectionFactory)initialContext.lookup(this.connectionFactoryName);
/*  55 */     } catch (Exception exception) {
/*     */       try {
/*  57 */         this.connectionFactoryName = "java:/comp/env/" + paramString1;
/*  58 */         this.factory = (TopicConnectionFactory)initialContext.lookup(this.connectionFactoryName);
/*  59 */       } catch (Exception exception1) {
/*  60 */         String str = WebServiceLogger.logJMSTopicFactoryException();
/*  61 */         WebServiceLogger.logStackTrace(str, exception1);
/*  62 */         throw new ConfigException(exception1.getMessage(), exception1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  67 */     this.topicName = paramString2;
/*     */     try {
/*  69 */       this.topic = (Topic)initialContext.lookup(this.topicName);
/*  70 */     } catch (Exception exception) {
/*     */       try {
/*  72 */         this.topicName = "java:/comp/env/" + paramString2;
/*  73 */         this.topic = (Topic)initialContext.lookup(this.topicName);
/*  74 */       } catch (Exception exception1) {
/*  75 */         String str = WebServiceLogger.logJMSTopicContextException();
/*  76 */         WebServiceLogger.logStackTrace(str, exception1);
/*  77 */         throw new ConfigException(exception1.getMessage(), exception1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
/*  89 */     Binding binding = (Binding)paramWLMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
/*     */     
/*  91 */     if (binding == null) {
/*  92 */       throw new AssertionError("binding can not be null");
/*     */     }
/*     */     
/*  95 */     if (!(binding instanceof HttpServerBinding)) {
/*  96 */       throw new JAXRPCException("This end component only supports HTTP transport");
/*     */     }
/*     */ 
/*     */     
/* 100 */     HttpServerBinding httpServerBinding = (HttpServerBinding)binding;
/* 101 */     HttpServletRequest httpServletRequest = httpServerBinding.getRequest();
/* 102 */     HttpSession httpSession = httpServletRequest.getSession();
/*     */     
/* 104 */     Rendezvous rendezvous = (Rendezvous)httpSession.getAttribute("rendezvous");
/*     */     
/* 106 */     if (rendezvous == null) {
/*     */       try {
/* 108 */         rendezvous = subscribe(this.factory, this.topic);
/* 109 */         httpSession.setAttribute("rendezvous", rendezvous);
/* 110 */       } catch (JMSException jMSException) {
/* 111 */         throw new JAXRPCException(jMSException);
/*     */       } 
/*     */     }
/*     */     
/* 115 */     return rendezvous.send();
/*     */   }
/*     */ 
/*     */   
/* 119 */   public Method[] getAllMethods() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static Rendezvous subscribe(TopicConnectionFactory paramTopicConnectionFactory, Topic paramTopic) throws JMSException {
/* 129 */     TopicConnection topicConnection = null;
/* 130 */     TopicSession topicSession = null;
/* 131 */     TopicSubscriber topicSubscriber = null;
/*     */     try {
/* 133 */       topicConnection = paramTopicConnectionFactory.createTopicConnection();
/* 134 */       topicSession = topicConnection.createTopicSession(false, 1);
/*     */       
/* 136 */       topicSubscriber = topicSession.createSubscriber(paramTopic);
/* 137 */       topicConnection.start();
/* 138 */       return new Rendezvous(topicSubscriber);
/* 139 */     } catch (JMSException jMSException) {
/* 140 */       if (topicSubscriber != null) {
/*     */         try {
/* 142 */           topicSubscriber.close();
/* 143 */         } catch (JMSException jMSException1) {}
/*     */       }
/* 145 */       if (topicSession != null) {
/*     */         try {
/* 147 */           topicSession.close();
/* 148 */         } catch (JMSException jMSException1) {}
/*     */       }
/* 150 */       if (topicConnection != null) {
/*     */         try {
/* 152 */           topicConnection.close();
/* 153 */         } catch (JMSException jMSException1) {}
/*     */       }
/*     */       
/* 156 */       throw jMSException;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static class Rendezvous
/*     */     implements MessageListener, HttpSessionBindingListener
/*     */   {
/*     */     private TopicSubscriber sub;
/*     */     private List messages;
/*     */     
/*     */     Rendezvous(TopicSubscriber param1TopicSubscriber) throws JMSException {
/* 168 */       this.sub = param1TopicSubscriber;
/* 169 */       this.sub.setMessageListener(this);
/*     */     }
/*     */     
/*     */     public void valueBound(HttpSessionBindingEvent param1HttpSessionBindingEvent) {}
/*     */     
/*     */     public void valueUnbound(HttpSessionBindingEvent param1HttpSessionBindingEvent) {
/*     */       try {
/* 176 */         this.sub.close();
/* 177 */       } catch (JMSException jMSException) {}
/*     */     }
/*     */     
/*     */     public void onMessage(Message param1Message) {
/*     */       Serializable serializable;
/*     */       try {
/* 183 */         serializable = ((ObjectMessage)param1Message).getObject();
/* 184 */       } catch (JMSException jMSException) {
/* 185 */         String str = WebServiceLogger.logJMSTopicJMSException();
/* 186 */         WebServiceLogger.logStackTrace(str, jMSException);
/*     */         
/*     */         return;
/*     */       } 
/* 190 */       if (this.messages == null) {
/* 191 */         this.messages = new ArrayList();
/*     */       }
/* 193 */       this.messages.add(serializable);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object send() {
/* 198 */       if (this.messages == null) {
/* 199 */         return null;
/*     */       }
/* 201 */       Object object = null;
/* 202 */       if (this.messages.size() > 0) {
/* 203 */         object = this.messages.remove(0);
/*     */       } else {
/* 205 */         this.messages = null;
/*     */       } 
/* 207 */       return object;
/*     */     }
/*     */   }
/*     */   
/* 211 */   public int getType() { return 4; }
/*     */ 
/*     */   
/* 214 */   public String getInfo() { return "ConnectionFactory: " + this.connectionFactoryName + "  Topic: " + this.topicName; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\jms\JMSTopicReceiveInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */