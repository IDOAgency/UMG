/*     */ package weblogic.webservice.component.jms;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.ObjectMessage;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.webservice.InvocationHandler;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JMSQueueReceiveInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*     */   private Queue queue;
/*     */   private QueueConnectionFactory factory;
/*     */   private String queueName;
/*     */   private String connectionFactoryName;
/*     */   private int numFailed;
/*     */   
/*     */   public JMSQueueReceiveInvocationHandler(String paramString1, String paramString2) throws ConfigException {
/*  34 */     this.connectionFactoryName = paramString1;
/*  35 */     this.queueName = paramString2;
/*  36 */     this.numFailed = 0;
/*     */     
/*  38 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() throws ConfigException {
/*  44 */     InitialContext initialContext = null;
/*     */     
/*     */     try {
/*  47 */       initialContext = new InitialContext();
/*  48 */     } catch (NamingException namingException) {
/*  49 */       this.numFailed++;
/*  50 */       if (this.numFailed == 1) {
/*  51 */         WebServiceLogger.logJMSQueueNamingWarning(); return;
/*     */       } 
/*  53 */       if (this.numFailed == 2) {
/*  54 */         String str = WebServiceLogger.logJMSQueueNamingException();
/*  55 */         WebServiceLogger.logStackTrace(str, namingException);
/*     */       } 
/*  57 */       throw new ConfigException(namingException.getMessage(), namingException);
/*     */     } 
/*     */     
/*     */     try {
/*  61 */       this.factory = (QueueConnectionFactory)initialContext.lookup(this.connectionFactoryName);
/*  62 */     } catch (Exception exception) {
/*     */       try {
/*  64 */         String str = "java:/comp/env/" + this.connectionFactoryName;
/*     */         
/*  66 */         this.factory = (QueueConnectionFactory)initialContext.lookup(str);
/*     */       }
/*  68 */       catch (Exception exception1) {
/*  69 */         this.numFailed++;
/*  70 */         if (this.numFailed == 1) {
/*  71 */           WebServiceLogger.logJMSQueueFactoryWarning(); return;
/*     */         } 
/*  73 */         if (this.numFailed == 2) {
/*  74 */           String str = WebServiceLogger.logJMSQueueFactoryException();
/*  75 */           WebServiceLogger.logStackTrace(str, exception1);
/*     */         } 
/*  77 */         throw new ConfigException(exception1.getMessage(), exception1);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/*  82 */       this.queue = (Queue)initialContext.lookup(this.queueName);
/*  83 */     } catch (Exception exception) {
/*     */       try {
/*  85 */         String str = "java:/comp/env/" + this.queueName;
/*  86 */         this.queue = (Queue)initialContext.lookup(str);
/*  87 */       } catch (Exception exception1) {
/*  88 */         this.numFailed++;
/*  89 */         if (this.numFailed == 1) {
/*  90 */           WebServiceLogger.logJMSQueueLocateWarning(); return;
/*     */         } 
/*  92 */         if (this.numFailed == 2) {
/*  93 */           String str = WebServiceLogger.logJMSQueueLocateException();
/*  94 */           WebServiceLogger.logStackTrace(str, exception1);
/*     */         } 
/*  96 */         throw new ConfigException(exception1.getMessage(), exception1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
/*     */     Serializable serializable;
/* 108 */     if (this.queue == null) {
/*     */       try {
/* 110 */         init();
/* 111 */       } catch (ConfigException configException) {
/* 112 */         throw new JAXRPCException(configException);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 118 */       Object object = receive(this.factory, this.queue);
/*     */ 
/*     */       
/* 121 */       if (object == null) {
/* 122 */         serializable = null;
/*     */       } else {
/* 124 */         serializable = ((ObjectMessage)object).getObject();
/*     */       } 
/* 126 */     } catch (JMSException jMSException) {
/* 127 */       throw new JAXRPCException(jMSException);
/*     */     } 
/* 129 */     return serializable;
/*     */   }
/*     */ 
/*     */   
/* 133 */   public Method[] getAllMethods() { return null; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object receive(QueueConnectionFactory paramQueueConnectionFactory, Queue paramQueue) throws JMSException {
/* 142 */     queueConnection = null;
/* 143 */     queueSession = null;
/* 144 */     queueReceiver = null;
/*     */     try {
/* 146 */       queueConnection = paramQueueConnectionFactory.createQueueConnection();
/* 147 */       queueSession = queueConnection.createQueueSession(false, 1);
/*     */       
/* 149 */       queueReceiver = queueSession.createReceiver(paramQueue);
/* 150 */       queueConnection.start();
/* 151 */       return queueReceiver.receiveNoWait();
/* 152 */     } catch (JMSException jMSException) {
/* 153 */       throw jMSException;
/*     */     } finally {
/* 155 */       if (queueReceiver != null) {
/*     */         try {
/* 157 */           queueReceiver.close();
/* 158 */         } catch (JMSException jMSException) {}
/*     */       }
/* 160 */       if (queueSession != null) {
/*     */         try {
/* 162 */           queueSession.close();
/* 163 */         } catch (JMSException jMSException) {}
/*     */       }
/* 165 */       if (queueConnection != null) {
/*     */         try {
/* 167 */           queueConnection.close();
/* 168 */         } catch (JMSException jMSException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 174 */   public int getType() { return 3; }
/*     */ 
/*     */   
/* 177 */   public String getInfo() { return "ConnectionFactory: " + this.connectionFactoryName + "  Queue: " + this.queueName; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\jms\JMSQueueReceiveInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */