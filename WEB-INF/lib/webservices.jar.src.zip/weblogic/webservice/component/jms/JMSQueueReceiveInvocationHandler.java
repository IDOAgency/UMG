package weblogic.webservice.component.jms;

import java.io.Serializable;
import java.lang.reflect.Method;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.xml.rpc.JAXRPCException;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.server.ConfigException;

public final class JMSQueueReceiveInvocationHandler implements InvocationHandler {
  private Queue queue;
  
  private QueueConnectionFactory factory;
  
  private String queueName;
  
  private String connectionFactoryName;
  
  private int numFailed;
  
  public JMSQueueReceiveInvocationHandler(String paramString1, String paramString2) throws ConfigException {
    this.connectionFactoryName = paramString1;
    this.queueName = paramString2;
    this.numFailed = 0;
    init();
  }
  
  private void init() throws ConfigException {
    InitialContext initialContext = null;
    try {
      initialContext = new InitialContext();
    } catch (NamingException namingException) {
      this.numFailed++;
      if (this.numFailed == 1) {
        WebServiceLogger.logJMSQueueNamingWarning();
        return;
      } 
      if (this.numFailed == 2) {
        String str = WebServiceLogger.logJMSQueueNamingException();
        WebServiceLogger.logStackTrace(str, namingException);
      } 
      throw new ConfigException(namingException.getMessage(), namingException);
    } 
    try {
      this.factory = (QueueConnectionFactory)initialContext.lookup(this.connectionFactoryName);
    } catch (Exception exception) {
      try {
        String str = "java:/comp/env/" + this.connectionFactoryName;
        this.factory = (QueueConnectionFactory)initialContext.lookup(str);
      } catch (Exception exception1) {
        this.numFailed++;
        if (this.numFailed == 1) {
          WebServiceLogger.logJMSQueueFactoryWarning();
          return;
        } 
        if (this.numFailed == 2) {
          String str = WebServiceLogger.logJMSQueueFactoryException();
          WebServiceLogger.logStackTrace(str, exception1);
        } 
        throw new ConfigException(exception1.getMessage(), exception1);
      } 
    } 
    try {
      this.queue = (Queue)initialContext.lookup(this.queueName);
    } catch (Exception exception) {
      try {
        String str = "java:/comp/env/" + this.queueName;
        this.queue = (Queue)initialContext.lookup(str);
      } catch (Exception exception1) {
        this.numFailed++;
        if (this.numFailed == 1) {
          WebServiceLogger.logJMSQueueLocateWarning();
          return;
        } 
        if (this.numFailed == 2) {
          String str = WebServiceLogger.logJMSQueueLocateException();
          WebServiceLogger.logStackTrace(str, exception1);
        } 
        throw new ConfigException(exception1.getMessage(), exception1);
      } 
    } 
  }
  
  public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
    Serializable serializable;
    if (this.queue == null)
      try {
        init();
      } catch (ConfigException configException) {
        throw new JAXRPCException(configException);
      }  
    try {
      Object object = receive(this.factory, this.queue);
      if (object == null) {
        serializable = null;
      } else {
        serializable = ((ObjectMessage)object).getObject();
      } 
    } catch (JMSException jMSException) {
      throw new JAXRPCException(jMSException);
    } 
    return serializable;
  }
  
  public Method[] getAllMethods() { return null; }
  
  public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {}
  
  private static Object receive(QueueConnectionFactory paramQueueConnectionFactory, Queue paramQueue) throws JMSException {
    queueConnection = null;
    queueSession = null;
    queueReceiver = null;
    try {
      queueConnection = paramQueueConnectionFactory.createQueueConnection();
      queueSession = queueConnection.createQueueSession(false, 1);
      queueReceiver = queueSession.createReceiver(paramQueue);
      queueConnection.start();
      return queueReceiver.receiveNoWait();
    } catch (JMSException jMSException) {
      throw jMSException;
    } finally {
      if (queueReceiver != null)
        try {
          queueReceiver.close();
        } catch (JMSException jMSException) {} 
      if (queueSession != null)
        try {
          queueSession.close();
        } catch (JMSException jMSException) {} 
      if (queueConnection != null)
        try {
          queueConnection.close();
        } catch (JMSException jMSException) {} 
    } 
  }
  
  public int getType() { return 3; }
  
  public String getInfo() { return "ConnectionFactory: " + this.connectionFactoryName + "  Queue: " + this.queueName; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\jms\JMSQueueReceiveInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */