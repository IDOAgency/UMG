package weblogic.webservice.component.javaclass;

import java.io.Serializable;
import java.rmi.RemoteException;
import javax.xml.rpc.JAXRPCException;
import weblogic.webservice.Operation;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.conversation.ConversationException;
import weblogic.webservice.conversation.ConversationManagerFactory;
import weblogic.webservice.conversation.ConversationState;
import weblogic.webservice.core.handler.ConversationContext;

public final class StatefulInvocationHandler extends JavaClassInvocationHandler {
  private Class targetClazz;
  
  private int maxRetries = 100;
  
  public StatefulInvocationHandler(Class paramClass) throws InstantiationException {
    super(paramClass);
    this.targetClazz = paramClass;
    ConversationManagerFactory.getManager();
  }
  
  private ConversationState createConversation(String paramString) throws JAXRPCException {
    Serializable serializable = null;
    try {
      serializable = (Serializable)createTarget(this.targetClazz);
    } catch (InstantiationException instantiationException) {
      throw new JAXRPCException("Failed to create a new instance of " + this.targetClazz.getName());
    } 
    try {
      return ConversationManagerFactory.getManager().createConversation(paramString, serializable);
    } catch (ConversationException conversationException) {
      throw new JAXRPCException("Failed to create conversation with ID " + paramString, conversationException);
    } 
  }
  
  private void destroyConversation(String paramString) throws JAXRPCException {
    try {
      ConversationManagerFactory.getManager().removeConversation(paramString);
    } catch (ConversationException conversationException) {
      throw new JAXRPCException("Failed to destroy conversation with ID " + paramString, conversationException);
    } 
  }
  
  public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
    ConversationContext conversationContext = (ConversationContext)paramWLMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
    if (conversationContext == null)
      return super.invoke(paramString, paramArrayOfObject, paramWLMessageContext); 
    String str = conversationContext.getConversationID();
    Operation operation = paramWLMessageContext.getOperation();
    ConversationState conversationState = null;
    Object object = null;
    if (str != null) {
      if ("START".equals(operation.getConversationPhase())) {
        conversationState = createConversation(str);
      } else {
        conversationState = ConversationManagerFactory.getManager().getConversation(str);
        if (conversationState == null)
          throw new JAXRPCException("Can't find state for conversation. ID is " + str); 
      } 
      boolean bool = false;
      byte b = 0;
      if (conversationState == null) {
        object = super.invoke(paramString, paramArrayOfObject, paramWLMessageContext);
      } else {
        while (!bool) {
          try {
            b++;
            while (conversationState.isLocked())
              Thread.sleep(1000L); 
            Serializable serializable = conversationState.getComponent();
            object = invoke(paramString, paramArrayOfObject, paramWLMessageContext, serializable);
            conversationState.setComponent(serializable);
            bool = true;
          } catch (RemoteException remoteException) {
            if (b > this.maxRetries)
              throw new JAXRPCException(remoteException); 
            bool = false;
          } catch (InterruptedException interruptedException) {
            throw new JAXRPCException(interruptedException);
          } 
        } 
      } 
    } else {
      throw new JAXRPCException("Invoking a conversation with no conversationID");
    } 
    if ("FINISH".equals(operation.getConversationPhase()))
      destroyConversation(str); 
    return object;
  }
  
  public int getType() { return 2; }
  
  public String getInfo() { return this.targetClazz.getName(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\javaclass\StatefulInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */