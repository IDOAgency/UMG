/*     */ package weblogic.webservice.component.javaclass;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.conversation.ConversationException;
/*     */ import weblogic.webservice.conversation.ConversationManagerFactory;
/*     */ import weblogic.webservice.conversation.ConversationState;
/*     */ import weblogic.webservice.core.handler.ConversationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StatefulInvocationHandler
/*     */   extends JavaClassInvocationHandler
/*     */ {
/*     */   private Class targetClazz;
/*  31 */   private int maxRetries = 100;
/*     */ 
/*     */   
/*     */   public StatefulInvocationHandler(Class paramClass) throws InstantiationException {
/*  35 */     super(paramClass);
/*     */     
/*  37 */     this.targetClazz = paramClass;
/*  38 */     ConversationManagerFactory.getManager();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ConversationState createConversation(String paramString) throws JAXRPCException {
/*  44 */     Serializable serializable = null;
/*     */     
/*     */     try {
/*  47 */       serializable = (Serializable)createTarget(this.targetClazz);
/*  48 */     } catch (InstantiationException instantiationException) {
/*  49 */       throw new JAXRPCException("Failed to create a new instance of " + this.targetClazz.getName());
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  54 */       return ConversationManagerFactory.getManager().createConversation(paramString, serializable);
/*  55 */     } catch (ConversationException conversationException) {
/*  56 */       throw new JAXRPCException("Failed to create conversation with ID " + paramString, conversationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void destroyConversation(String paramString) throws JAXRPCException {
/*     */     try {
/*  64 */       ConversationManagerFactory.getManager().removeConversation(paramString);
/*  65 */     } catch (ConversationException conversationException) {
/*  66 */       throw new JAXRPCException("Failed to destroy conversation with ID " + paramString, conversationException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
/*  72 */     ConversationContext conversationContext = (ConversationContext)paramWLMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
/*     */ 
/*     */     
/*  75 */     if (conversationContext == null) {
/*  76 */       return super.invoke(paramString, paramArrayOfObject, paramWLMessageContext);
/*     */     }
/*     */     
/*  79 */     String str = conversationContext.getConversationID();
/*  80 */     Operation operation = paramWLMessageContext.getOperation();
/*     */ 
/*     */     
/*  83 */     ConversationState conversationState = null;
/*  84 */     Object object = null;
/*  85 */     if (str != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       if ("START".equals(operation.getConversationPhase())) {
/*  92 */         conversationState = createConversation(str);
/*     */       } else {
/*  94 */         conversationState = ConversationManagerFactory.getManager().getConversation(str);
/*  95 */         if (conversationState == null) {
/*  96 */           throw new JAXRPCException("Can't find state for conversation. ID is " + str);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 101 */       boolean bool = false;
/* 102 */       byte b = 0;
/*     */       
/* 104 */       if (conversationState == null) {
/* 105 */         object = super.invoke(paramString, paramArrayOfObject, paramWLMessageContext);
/*     */       } else {
/* 107 */         while (!bool) {
/*     */           try {
/* 109 */             b++;
/* 110 */             while (conversationState.isLocked()) {
/* 111 */               Thread.sleep(1000L);
/*     */             }
/* 113 */             Serializable serializable = conversationState.getComponent();
/* 114 */             object = invoke(paramString, paramArrayOfObject, paramWLMessageContext, serializable);
/* 115 */             conversationState.setComponent(serializable);
/* 116 */             bool = true;
/* 117 */           } catch (RemoteException remoteException) {
/* 118 */             if (b > this.maxRetries)
/* 119 */               throw new JAXRPCException(remoteException); 
/* 120 */             bool = false;
/* 121 */           } catch (InterruptedException interruptedException) {
/* 122 */             throw new JAXRPCException(interruptedException);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 128 */       throw new JAXRPCException("Invoking a conversation with no conversationID");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if ("FINISH".equals(operation.getConversationPhase())) {
/* 137 */       destroyConversation(str);
/*     */     }
/*     */     
/* 140 */     return object;
/*     */   }
/*     */   
/* 143 */   public int getType() { return 2; }
/*     */   
/* 145 */   public String getInfo() { return this.targetClazz.getName(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\javaclass\StatefulInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */