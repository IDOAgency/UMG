/*     */ package weblogic.webservice.component.javaclass;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import javax.xml.rpc.server.ServiceLifecycle;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.InvocationHandler;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.dd.MethodDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaClassInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*     */   private HashMap operations;
/*     */   private Method[] methods;
/*     */   private Object target;
/*     */   
/*     */   public JavaClassInvocationHandler(Class paramClass) throws InstantiationException {
/*  27 */     this.operations = new HashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  34 */     this.target = createTarget(paramClass);
/*  35 */     this.methods = paramClass.getMethods();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Object createTarget(Class paramClass) throws InstantiationException {
/*  41 */     Object object = null;
/*     */     
/*     */     try {
/*  44 */       object = paramClass.newInstance();
/*     */       
/*  46 */       if (object instanceof ServiceLifecycle) {
/*  47 */         ServiceLifecycle serviceLifecycle = (ServiceLifecycle)object;
/*     */ 
/*     */         
/*     */         try {
/*  51 */           serviceLifecycle.init(null);
/*  52 */         } catch (ServiceException serviceException) {
/*  53 */           throw new InstantiationException("failed to call init method on the target:" + serviceException);
/*     */         }
/*     */       
/*     */       } 
/*  57 */     } catch (IllegalAccessException illegalAccessException) {
/*     */       
/*  59 */       throw new AssertionError(illegalAccessException);
/*     */     } 
/*     */     
/*  62 */     return object;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {
/*  67 */     if (paramString1 == null || paramString2 == null) {
/*     */       return;
/*     */     }
/*  70 */     for (byte b = 0; b < this.methods.length; b++) {
/*  71 */       if (paramString2.equals(this.methods[b].getName())) {
/*  72 */         if (paramArrayOfClass == null) {
/*  73 */           this.operations.put(paramString1, this.methods[b]);
/*     */           return;
/*     */         } 
/*  76 */         Class[] arrayOfClass = this.methods[b].getParameterTypes();
/*  77 */         if (MethodDescriptor.isAssignable(paramArrayOfClass, arrayOfClass)) {
/*  78 */           this.operations.put(paramString1, this.methods[b]);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  85 */     throw new NoSuchMethodException("Can't find method \"" + paramString2 + "\".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext, Object paramObject) throws JAXRPCException, TargetInvocationException {
/*  93 */     Method method = (Method)this.operations.get(paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     if (method != null) {
/*     */       try {
/* 100 */         return method.invoke(paramObject, paramArrayOfObject);
/* 101 */       } catch (IllegalAccessException illegalAccessException) {
/* 102 */         throw new AssertionError(illegalAccessException);
/* 103 */       } catch (InvocationTargetException invocationTargetException) {
/*     */         
/* 105 */         Throwable throwable = invocationTargetException.getTargetException();
/* 106 */         if (throwable == null) throwable = invocationTargetException;
/*     */         
/* 108 */         throw new TargetInvocationException("Failed to invoke the target:" + paramObject + " operation name:" + paramString + " method:" + method + " exception:" + throwable, throwable);
/*     */       
/*     */       }
/* 111 */       catch (IllegalArgumentException illegalArgumentException) {
/* 112 */         throw new JAXRPCException("Failed to invoke the target:" + paramObject + " operation name:" + paramString + " method:" + method + " args:" + paramArrayOfObject + "arg.length:" + ((paramArrayOfObject == null) ? 0 : paramArrayOfObject.length) + " Due to " + "exception:" + illegalArgumentException, illegalArgumentException);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
/* 127 */     Method method = (Method)this.operations.get(paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     if (method != null) {
/*     */       try {
/* 134 */         return method.invoke(this.target, paramArrayOfObject);
/* 135 */       } catch (IllegalAccessException illegalAccessException) {
/* 136 */         throw new AssertionError(illegalAccessException);
/* 137 */       } catch (InvocationTargetException invocationTargetException) {
/*     */         
/* 139 */         Throwable throwable = invocationTargetException.getTargetException();
/* 140 */         if (throwable == null) throwable = invocationTargetException;
/*     */         
/* 142 */         throw new TargetInvocationException("Failed to invoke the target:" + this.target + " operation name:" + paramString + " method:" + method + " exception:" + throwable, throwable);
/*     */       
/*     */       }
/* 145 */       catch (IllegalArgumentException illegalArgumentException) {
/* 146 */         throw new JAXRPCException("Failed to invoke the target:" + this.target + " operation name:" + paramString + " method:" + method + " args:" + paramArrayOfObject + "arg.length:" + ((paramArrayOfObject == null) ? 0 : paramArrayOfObject.length) + " Due to " + "exception:" + illegalArgumentException, illegalArgumentException);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 158 */   public Method[] getAllMethods() { return this.methods; }
/*     */   
/*     */   public Method[] getOperations() {
/* 161 */     Method[] arrayOfMethod = new Method[0];
/* 162 */     return (Method[])this.operations.values().toArray(arrayOfMethod);
/*     */   }
/*     */ 
/*     */   
/* 166 */   public void setTarget(Object paramObject) { this.target = paramObject; }
/*     */ 
/*     */ 
/*     */   
/* 170 */   public Object getTarget() { return this.target; }
/*     */ 
/*     */   
/* 173 */   public String getInfo() { return this.target.getClass().getName(); }
/*     */   
/* 175 */   public int getType() { return 1; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\javaclass\JavaClassInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */