package weblogic.webservice.component.javaclass;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.server.ServiceLifecycle;
import weblogic.utils.AssertionError;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.dd.MethodDescriptor;

public class JavaClassInvocationHandler implements InvocationHandler {
  private HashMap operations;
  
  private Method[] methods;
  
  private Object target;
  
  public JavaClassInvocationHandler(Class paramClass) throws InstantiationException {
    this.operations = new HashMap();
    this.target = createTarget(paramClass);
    this.methods = paramClass.getMethods();
  }
  
  protected static Object createTarget(Class paramClass) throws InstantiationException {
    Object object = null;
    try {
      object = paramClass.newInstance();
      if (object instanceof ServiceLifecycle) {
        ServiceLifecycle serviceLifecycle = (ServiceLifecycle)object;
        try {
          serviceLifecycle.init(null);
        } catch (ServiceException serviceException) {
          throw new InstantiationException("failed to call init method on the target:" + serviceException);
        } 
      } 
    } catch (IllegalAccessException illegalAccessException) {
      throw new AssertionError(illegalAccessException);
    } 
    return object;
  }
  
  public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {
    if (paramString1 == null || paramString2 == null)
      return; 
    for (byte b = 0; b < this.methods.length; b++) {
      if (paramString2.equals(this.methods[b].getName())) {
        if (paramArrayOfClass == null) {
          this.operations.put(paramString1, this.methods[b]);
          return;
        } 
        Class[] arrayOfClass = this.methods[b].getParameterTypes();
        if (MethodDescriptor.isAssignable(paramArrayOfClass, arrayOfClass)) {
          this.operations.put(paramString1, this.methods[b]);
          return;
        } 
      } 
    } 
    throw new NoSuchMethodException("Can't find method \"" + paramString2 + "\".");
  }
  
  public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext, Object paramObject) throws JAXRPCException, TargetInvocationException {
    Method method = (Method)this.operations.get(paramString);
    if (method != null)
      try {
        return method.invoke(paramObject, paramArrayOfObject);
      } catch (IllegalAccessException illegalAccessException) {
        throw new AssertionError(illegalAccessException);
      } catch (InvocationTargetException invocationTargetException) {
        Throwable throwable = invocationTargetException.getTargetException();
        if (throwable == null)
          throwable = invocationTargetException; 
        throw new TargetInvocationException("Failed to invoke the target:" + paramObject + " operation name:" + paramString + " method:" + method + " exception:" + throwable, throwable);
      } catch (IllegalArgumentException illegalArgumentException) {
        throw new JAXRPCException("Failed to invoke the target:" + paramObject + " operation name:" + paramString + " method:" + method + " args:" + paramArrayOfObject + "arg.length:" + ((paramArrayOfObject == null) ? 0 : paramArrayOfObject.length) + " Due to " + "exception:" + illegalArgumentException, illegalArgumentException);
      }  
    return null;
  }
  
  public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
    Method method = (Method)this.operations.get(paramString);
    if (method != null)
      try {
        return method.invoke(this.target, paramArrayOfObject);
      } catch (IllegalAccessException illegalAccessException) {
        throw new AssertionError(illegalAccessException);
      } catch (InvocationTargetException invocationTargetException) {
        Throwable throwable = invocationTargetException.getTargetException();
        if (throwable == null)
          throwable = invocationTargetException; 
        throw new TargetInvocationException("Failed to invoke the target:" + this.target + " operation name:" + paramString + " method:" + method + " exception:" + throwable, throwable);
      } catch (IllegalArgumentException illegalArgumentException) {
        throw new JAXRPCException("Failed to invoke the target:" + this.target + " operation name:" + paramString + " method:" + method + " args:" + paramArrayOfObject + "arg.length:" + ((paramArrayOfObject == null) ? 0 : paramArrayOfObject.length) + " Due to " + "exception:" + illegalArgumentException, illegalArgumentException);
      }  
    return null;
  }
  
  public Method[] getAllMethods() { return this.methods; }
  
  public Method[] getOperations() {
    Method[] arrayOfMethod = new Method[0];
    return (Method[])this.operations.values().toArray(arrayOfMethod);
  }
  
  public void setTarget(Object paramObject) { this.target = paramObject; }
  
  public Object getTarget() { return this.target; }
  
  public String getInfo() { return this.target.getClass().getName(); }
  
  public int getType() { return 1; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\javaclass\JavaClassInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */