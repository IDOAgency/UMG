/*     */ package weblogic.webservice.component.slsb;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.InvocationHandler;
/*     */ import weblogic.webservice.TargetInvocationException;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.dd.MethodDescriptor;
/*     */ import weblogic.webservice.server.ConfigException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SLSBInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*  24 */   private HashMap operations = new HashMap();
/*     */   private Method[] methods;
/*     */   private Method ejbCreate;
/*     */   private Object ejbHome;
/*     */   
/*     */   public SLSBInvocationHandler(Object paramObject) throws ConfigException {
/*     */     try {
/*  31 */       this.ejbHome = paramObject;
/*  32 */       this.ejbCreate = paramObject.getClass().getMethod("create", new Class[0]);
/*  33 */       this.methods = this.ejbCreate.getReturnType().getMethods();
/*     */       
/*  35 */       this.ejbCreate.invoke(paramObject, new Object[0]);
/*     */     }
/*  37 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       
/*  39 */       throw new AssertionError(noSuchMethodException);
/*  40 */     } catch (InvocationTargetException invocationTargetException) {
/*     */ 
/*     */       
/*  43 */       Throwable throwable = invocationTargetException.getTargetException();
/*     */ 
/*     */       
/*  46 */       if (throwable == null) throwable = invocationTargetException;
/*     */       
/*  48 */       throw new ConfigException("The EJB named: " + paramObject.getClass().getName() + " threw an exception during its create method:", throwable);
/*     */     
/*     */     }
/*  51 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/*  53 */       throw new AssertionError(illegalAccessException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {
/*  60 */     if (paramString1 == null || paramString2 == null) {
/*     */       return;
/*     */     }
/*  63 */     for (byte b = 0; b < this.methods.length; b++) {
/*  64 */       if (paramString2.equals(this.methods[b].getName())) {
/*  65 */         if (paramArrayOfClass == null) {
/*  66 */           this.operations.put(paramString1, this.methods[b]);
/*     */           return;
/*     */         } 
/*  69 */         Class[] arrayOfClass = this.methods[b].getParameterTypes();
/*  70 */         if (MethodDescriptor.isAssignable(paramArrayOfClass, arrayOfClass)) {
/*  71 */           this.operations.put(paramString1, this.methods[b]);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  78 */     throw new NoSuchMethodException("Can't find method \"" + paramString2 + "\".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
/*  85 */     Method method = (Method)this.operations.get(paramString);
/*     */     
/*  87 */     Object object = null;
/*     */     try {
/*  89 */       object = this.ejbCreate.invoke(this.ejbHome, new Object[0]);
/*     */       
/*  91 */       return method.invoke(object, paramArrayOfObject);
/*  92 */     } catch (IllegalAccessException illegalAccessException) {
/*  93 */       throw new AssertionError(illegalAccessException);
/*  94 */     } catch (InvocationTargetException invocationTargetException) {
/*     */       
/*  96 */       Throwable throwable = invocationTargetException.getTargetException();
/*     */       
/*  98 */       if (throwable == null) throwable = invocationTargetException;
/*     */       
/* 100 */       throw new TargetInvocationException("Failed to invoke the target:" + object + " operation name:" + paramString + " method:" + method + " exception:" + throwable, throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public Method[] getAllMethods() { return this.methods; }
/*     */   
/*     */   public Method[] getOperations() {
/* 112 */     Method[] arrayOfMethod = new Method[0];
/* 113 */     return (Method[])this.operations.values().toArray(arrayOfMethod);
/*     */   }
/*     */ 
/*     */   
/* 117 */   public int getType() { return 7; }
/*     */   
/* 119 */   public String getInfo() { return this.ejbHome.getClass().getName(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\slsb\SLSBInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */