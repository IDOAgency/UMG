package weblogic.webservice.component.slsb;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import javax.xml.rpc.JAXRPCException;
import weblogic.utils.AssertionError;
import weblogic.webservice.InvocationHandler;
import weblogic.webservice.TargetInvocationException;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.dd.MethodDescriptor;
import weblogic.webservice.server.ConfigException;

public final class SLSBInvocationHandler implements InvocationHandler {
  private HashMap operations = new HashMap();
  
  private Method[] methods;
  
  private Method ejbCreate;
  
  private Object ejbHome;
  
  public SLSBInvocationHandler(Object paramObject) throws ConfigException {
    try {
      this.ejbHome = paramObject;
      this.ejbCreate = paramObject.getClass().getMethod("create", new Class[0]);
      this.methods = this.ejbCreate.getReturnType().getMethods();
      this.ejbCreate.invoke(paramObject, new Object[0]);
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new AssertionError(noSuchMethodException);
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getTargetException();
      if (throwable == null)
        throwable = invocationTargetException; 
      throw new ConfigException("The EJB named: " + paramObject.getClass().getName() + " threw an exception during its create method:", throwable);
    } catch (IllegalAccessException illegalAccessException) {
      throw new AssertionError(illegalAccessException);
    } 
  }
  
  public void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException {
    if (paramString1 == null || paramString2 == null)
      return; 
    for (byte b = 0; b < this.methods.length; b++) {
      if (paramString2.equals(this.methods[b].getName())) {
        if (paramArrayOfClass == null) {
          this.operations.put(paramString1, this.methods[b]);
          return;
        } 
        Class[] arrayOfClass = this.methods[b].getParameterTypes();
        if (MethodDescriptor.isAssignable(paramArrayOfClass, arrayOfClass)) {
          this.operations.put(paramString1, this.methods[b]);
          return;
        } 
      } 
    } 
    throw new NoSuchMethodException("Can't find method \"" + paramString2 + "\".");
  }
  
  public Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException {
    Method method = (Method)this.operations.get(paramString);
    Object object = null;
    try {
      object = this.ejbCreate.invoke(this.ejbHome, new Object[0]);
      return method.invoke(object, paramArrayOfObject);
    } catch (IllegalAccessException illegalAccessException) {
      throw new AssertionError(illegalAccessException);
    } catch (InvocationTargetException invocationTargetException) {
      Throwable throwable = invocationTargetException.getTargetException();
      if (throwable == null)
        throwable = invocationTargetException; 
      throw new TargetInvocationException("Failed to invoke the target:" + object + " operation name:" + paramString + " method:" + method + " exception:" + throwable, throwable);
    } 
  }
  
  public Method[] getAllMethods() { return this.methods; }
  
  public Method[] getOperations() {
    Method[] arrayOfMethod = new Method[0];
    return (Method[])this.operations.values().toArray(arrayOfMethod);
  }
  
  public int getType() { return 7; }
  
  public String getInfo() { return this.ejbHome.getClass().getName(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\component\slsb\SLSBInvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */