package weblogic.webservice.saf;

import java.util.HashMap;
import java.util.Iterator;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.XAQueueConnection;
import javax.jms.XAQueueConnectionFactory;
import javax.jms.XAQueueSession;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;
import weblogic.t3.srvr.T3Srvr;
import weblogic.time.common.Schedulable;
import weblogic.time.common.ScheduledTriggerDef;
import weblogic.time.common.TimeTriggerException;
import weblogic.time.common.Triggerable;
import weblogic.utils.Debug;
import weblogic.webservice.WebServiceLogger;

public class WSDupsEliminationAgent implements DupsEliminationAgent {
  private static boolean debug = false;
  
  private HashMap receivedMessages = new HashMap();
  
  private HashMap conversations = new HashMap();
  
  private HashMap soapMessages = new HashMap();
  
  public static final String DUPS_ELIMINATION_HISTORY_QUEUE_NAME = "jms.internal.queue.WSDupsEliminationHistoryQueue";
  
  public static final String DUPS_ELIMINATION_MESSAGE_QUEUE_NAME = "jms.internal.queue.WSDupsEliminationMessageQueue";
  
  private Context ctx;
  
  private Queue historyDestination;
  
  private Queue messageDestination;
  
  private Connection connection;
  
  private Connection xaConnection;
  
  private ConnectionFactory cf;
  
  private ConnectionFactory xaCf;
  
  private long defaultPersistDuration;
  
  private static WSDupsEliminationAgent dupsEliminationAgent;
  
  private boolean started;
  
  private boolean recovered;
  
  private boolean repeatIt;
  
  private String lastMessageId;
  
  private String name;
  
  static WSDupsEliminationAgent getDupsEliminationAgent() { return dupsEliminationAgent; }
  
  public static WSDupsEliminationAgent createAgent(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean) {
    if (dupsEliminationAgent != null)
      return dupsEliminationAgent; 
    dupsEliminationAgent = new WSDupsEliminationAgent();
    dupsEliminationAgent.init(paramWSReliableDeliveryPolicyMBean);
    try {
      dupsEliminationAgent.start();
    } catch (Exception exception) {}
    return dupsEliminationAgent;
  }
  
  boolean isStarted() { return this.started; }
  
  public String getName() { return this.name; }
  
  public void init(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean) {
    this.name = paramWSReliableDeliveryPolicyMBean.getName() + "DupsEliminationAgent";
    this.defaultPersistDuration = (paramWSReliableDeliveryPolicyMBean.getDefaultTimeToLive() * 1000);
    if (debug)
      Debug.say(" == init(): PersistDuration = " + this.defaultPersistDuration); 
  }
  
  private void start() {
    if (this.started)
      return; 
    this.ctx = Util.getInitialContext();
    this.cf = Util.getConnectionFactory();
    this.xaCf = Util.getXAConnectionFactory();
    this.historyDestination = (Queue)this.ctx.lookup("jms.internal.queue.WSDupsEliminationHistoryQueue");
    debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
    if (!this.recovered) {
      recoverHistoryRecords();
      this.recovered = true;
    } 
    this.xaConnection = ((XAQueueConnectionFactory)this.xaCf).createXAQueueConnection();
    this.connection = ((QueueConnectionFactory)this.cf).createQueueConnection();
    this.connection.start();
    this.xaConnection.start();
    this.started = true;
  }
  
  public boolean storeHistoryRecord(String paramString) throws StoreForwardException { return storeHistoryRecord(paramString, this.defaultPersistDuration); }
  
  public void waitForStart() {
    boolean bool = false;
    while (!bool) {
      try {
        start();
        bool = true;
      } catch (NamingException namingException) {
      
      } catch (StoreForwardException storeForwardException) {
        WebServiceLogger.logFailedAccessStore(storeForwardException.getLinkedException());
        throw storeForwardException;
      } catch (JMSException jMSException) {
        WebServiceLogger.logFailedAccessStore(jMSException);
        throw new StoreForwardException("Failed to start the reliable agent", jMSException);
      } 
      if (!bool)
        try {
          Thread.sleep(500L);
        } catch (InterruptedException interruptedException) {} 
    } 
  }
  
  public boolean storeHistoryRecord(String paramString, long paramLong) throws StoreForwardException {
    waitForStart();
    if (!addReceivedMessage(paramString, false, paramLong))
      return false; 
    try {
      XAQueueSession xAQueueSession = ((XAQueueConnection)this.xaConnection).createXAQueueSession();
      QueueSession queueSession = xAQueueSession.getQueueSession();
      TextMessage textMessage = queueSession.createTextMessage(paramString);
      textMessage.setStringProperty("WSSAFID", paramString);
      QueueSender queueSender = queueSession.createSender(this.historyDestination);
      queueSender.send(textMessage, 2, 4, paramLong);
      queueSession.close();
      if (debug)
        Debug.say("== storeHistoryRecord(): MessageID stored: " + paramString); 
    } catch (JMSException jMSException) {
      Debug.say(" ===  storeHistoryRecord() got Exception:" + jMSException);
      synchronized (this) {
        close();
        this.started = false;
      } 
      throw new StoreForwardException("Failed to store the history record for message: " + paramString, jMSException);
    } 
    return true;
  }
  
  public void storeMessageOnly(String paramString, Object paramObject) throws StoreForwardException { storeMessageOnly(paramString, paramObject, this.defaultPersistDuration); }
  
  public void storeMessageOnly(String paramString, Object paramObject, long paramLong) throws StoreForwardException {
    waitForStart();
    addSOAPMessage(paramString, paramObject);
    try {
      QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(true, 1);
      QueueSender queueSender = queueSession.createSender(this.messageDestination);
      Message message = createMessage(queueSession, paramObject);
      message.setStringProperty("WSSAFID", paramString);
      queueSender.send(message, 2, 4, paramLong);
      queueSession.close();
      if (debug)
        Debug.say("=== storeMessageOnly(): MessageID stored: " + paramString); 
    } catch (JMSException jMSException) {
      Debug.say(" ===  storeMessageOnly() got Exception:" + jMSException);
      synchronized (this) {
        close();
        this.started = false;
      } 
      throw new StoreForwardException("Failed to store the message: " + paramString, jMSException);
    } 
  }
  
  public void storeHistoryRecordAndMessage(String paramString, Object paramObject) throws StoreForwardException { storeHistoryRecordAndMessage(paramString, paramObject, this.defaultPersistDuration); }
  
  public void storeHistoryRecordAndMessage(String paramString, Object paramObject, long paramLong) throws StoreForwardException {
    waitForStart();
    addReceivedMessage(paramString, false, paramLong);
    addSOAPMessage(paramString, paramObject);
    try {
      QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(true, 2);
      TextMessage textMessage = queueSession.createTextMessage(paramString);
      textMessage.setStringProperty("WSSAFID", paramString);
      QueueSender queueSender = queueSession.createSender(this.historyDestination);
      queueSender.send(textMessage, 2, 4, paramLong);
      queueSender = queueSession.createSender(this.messageDestination);
      Message message = createMessage(queueSession, paramObject);
      message.setStringProperty("WSSAFID", paramString);
      queueSender.send(message, 2, 4, paramLong);
      queueSession.close();
      if (debug)
        Debug.say("=== storeHistoryRecordAndMEssage(): MessageID stored: " + paramString); 
    } catch (JMSException jMSException) {
      Debug.say(" ===  storeHistoryRecordAndMessage() got Exception:" + jMSException);
      synchronized (this) {
        close();
        this.started = false;
      } 
      throw new StoreForwardException("Failed to store the history record and the message itself: " + paramString, jMSException);
    } 
  }
  
  public void removeHistoryRecordInMemoryOnly(String paramString) {
    if (paramString == null)
      return; 
    removeReceivedMessage(paramString);
  }
  
  public void removeHistoryRecord(String paramString) {
    if (paramString == null)
      return; 
    removeReceivedMessage(paramString);
    waitForStart();
    try {
      QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(false, 1);
      String str = "WSSAFID = '" + paramString + "'";
      QueueReceiver queueReceiver = queueSession.createReceiver(this.historyDestination, str);
      Message message = queueReceiver.receiveNoWait();
      queueSession.close();
      if (debug)
        Debug.say("=== removeHistoryRecord() removed: " + message); 
    } catch (JMSException jMSException) {
      Debug.say(" === removeHistoryRecord() got Exception:" + jMSException);
      synchronized (this) {
        close();
        this.started = false;
      } 
      throw new StoreForwardException("Failed to remove the history record for message: " + paramString, jMSException);
    } 
  }
  
  public void removeMessageOnly(String paramString) {
    if (paramString == null)
      return; 
    waitForStart();
    try {
      QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(false, 1);
      String str = "WSSAFID = '" + paramString + "'";
      QueueReceiver queueReceiver = queueSession.createReceiver(this.messageDestination, str);
      Message message = queueReceiver.receiveNoWait();
      queueSession.close();
      if (debug)
        Debug.say("=== removeMessageOnly() removed: " + message); 
    } catch (JMSException jMSException) {
      Debug.say(" === removeMessageOnly() got Exception:" + jMSException);
      synchronized (this) {
        close();
        this.started = false;
      } 
      throw new StoreForwardException("Failed to remove message: " + paramString, jMSException);
    } 
  }
  
  public void removeHistoryRecordAndMessage(String paramString) {
    if (paramString == null)
      return; 
    waitForStart();
    removeReceivedMessage(paramString);
    try {
      QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(false, 1);
      String str = "WSSAFID = '" + paramString + "'";
      QueueReceiver queueReceiver = queueSession.createReceiver(this.historyDestination, str);
      Message message = queueReceiver.receiveNoWait();
      if (debug)
        Debug.say("=== removed the history record: " + message); 
      queueReceiver = queueSession.createReceiver(this.messageDestination, str);
      message = queueReceiver.receiveNoWait();
      queueSession.close();
      if (debug)
        Debug.say("=== removed the message: " + message); 
    } catch (JMSException jMSException) {
      Debug.say(" === removeHistoryRecord() got Exception:" + jMSException);
      synchronized (this) {
        close();
        this.started = false;
      } 
      throw new StoreForwardException("Failed to remove the history record and the message: " + paramString, jMSException);
    } 
  }
  
  public void removeHistoryRecordForConversation(String paramString) {
    if (paramString == null)
      return; 
    waitForStart();
    Iterator iterator = ((ConversationReassembler)getConversation(paramString)).getMessages().iterator();
    QueueSession queueSession = null;
    QueueReceiver queueReceiver = null;
    Message message = null;
    while (iterator.hasNext()) {
      String str = (String)iterator.next();
      try {
        removeReceivedMessage(str);
        queueSession = ((QueueConnection)this.connection).createQueueSession(false, 1);
        String str1 = "WSSAFID = '" + str + "'";
        queueReceiver = queueSession.createReceiver(this.historyDestination, str1);
        message = queueReceiver.receiveNoWait();
        queueSession.close();
        if (debug)
          Debug.say("=== removed: " + message); 
      } catch (JMSException jMSException) {
        Debug.say(" === remove() got Exception:" + jMSException);
        synchronized (this) {
          close();
          this.started = false;
        } 
        throw new StoreForwardException("Failed to remove the history record for conversation: " + paramString, jMSException);
      } 
    } 
  }
  
  public Object process(String paramString) throws StoreForwardException { return getSOAPMessage(paramString); }
  
  public void close() {
    if (this.connection != null) {
      try {
        this.connection.close();
      } catch (JMSException jMSException) {}
      this.connection = null;
    } 
    if (this.xaConnection != null) {
      try {
        this.xaConnection.close();
      } catch (JMSException jMSException) {}
      this.xaConnection = null;
    } 
    this.receivedMessages.clear();
    this.soapMessages.clear();
    Iterator iterator = this.conversations.values().iterator();
    while (iterator.hasNext())
      ((ConversationReassembler)iterator.next()).close(); 
    this.conversations.clear();
  }
  
  private boolean addReceivedMessage(String paramString, boolean paramBoolean, long paramLong) {
    if (this.receivedMessages.get(paramString) != null)
      return false; 
    long l = paramLong;
    if (!paramBoolean)
      l = System.currentTimeMillis() + paramLong; 
    HistoryRecord historyRecord = new HistoryRecord(paramString, l);
    this.receivedMessages.put(paramString, historyRecord);
    try {
      historyRecord.init();
    } catch (TimeTriggerException timeTriggerException) {
      if (debug)
        Debug.say("==addReceivedMessage(): failed to init the trigger"); 
    } 
    return true;
  }
  
  private void removeReceivedMessage(String paramString) { this.receivedMessages.remove(paramString); }
  
  public boolean isDuplicate(String paramString) throws StoreForwardException {
    if (this.receivedMessages.get(paramString) != null)
      return true; 
    return false;
  }
  
  public long getDefaultPersistDuration() { return this.defaultPersistDuration; }
  
  public ConversationReassembler createConversation(String paramString, boolean paramBoolean) {
    ConversationReassembler conversationReassembler = new ConversationReassembler(paramString, paramBoolean);
    this.conversations.put(paramString, conversationReassembler);
    return conversationReassembler;
  }
  
  public Conversation getConversation(String paramString) { return (Conversation)this.conversations.get(paramString); }
  
  public void removeConversation(String paramString) { this.conversations.remove(paramString); }
  
  public void addSOAPMessage(String paramString, Object paramObject) throws StoreForwardException { this.soapMessages.put(paramString, paramObject); }
  
  public void removeSOAPMessage(String paramString) { this.soapMessages.remove(paramString); }
  
  public MessageContext getSOAPMessage(String paramString) { return (MessageContext)this.soapMessages.get(paramString); }
  
  private Message createMessage(Session paramSession, Object paramObject) throws StoreForwardException {
    if (!(paramObject instanceof SOAPMessageContext))
      throw new StoreForwardException("Invalid message"); 
    SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramObject;
    try {
      byte[] arrayOfByte = Util.soapMessage2Bytes(sOAPMessageContext);
      BytesMessage bytesMessage = paramSession.createBytesMessage();
      bytesMessage.writeBytes(arrayOfByte);
      return bytesMessage;
    } catch (JMSException jMSException) {
      throw new StoreForwardException("Failed to create message", jMSException);
    } 
  }
  
  private void recoverHistoryRecords() {
    try {
      QueueConnection queueConnection = ((QueueConnectionFactory)this.cf).createQueueConnection();
      QueueSession queueSession = queueConnection.createQueueSession(false, 2);
      QueueReceiver queueReceiver = queueSession.createReceiver(this.historyDestination);
      queueConnection.start();
      Message message = null;
      do {
        message = queueReceiver.receiveNoWait();
        if (message == null || !(message instanceof TextMessage))
          continue; 
        String str = ((TextMessage)message).getText();
        addReceivedMessage(str, true, message.getJMSExpiration());
        if (!debug)
          continue; 
        Debug.say("== recoverHistoryRecords(): MessageID restored: " + str);
      } while (message != null);
      queueSession.close();
      queueConnection.close();
    } catch (JMSException jMSException) {
      if (debug)
        Debug.say(" ===  storeHistoryRecord() got Exception:" + jMSException); 
      throw new StoreForwardException("Failed to recover the history record", jMSException);
    } 
  }
  
  void run(String paramString) {
    if (debug)
      Debug.say("== Expiring history record for message: " + paramString); 
    removeReceivedMessage(paramString);
    try {
      removeHistoryRecord(paramString);
    } catch (StoreForwardException storeForwardException) {}
  }
  
  private class HistoryRecord implements Schedulable, Triggerable {
    private String messageId;
    
    private ScheduledTriggerDef trigger;
    
    private boolean cancelled;
    
    private long timeout;
    
    private boolean done;
    
    private final WSDupsEliminationAgent this$0;
    
    HistoryRecord(String param1String, long param1Long) {
      this.done = false;
      this.messageId = param1String;
      this.timeout = param1Long;
    }
    
    void init() {
      this.trigger = T3Srvr.getT3Srvr().getT3Services().time().getScheduledTrigger(this, this);
      this.trigger.schedule();
    }
    
    public long schedule(long param1Long) {
      if (!this.done)
        return this.timeout; 
      return 0L;
    }
    
    public void trigger(Schedulable param1Schedulable) {
      WSDupsEliminationAgent.this.run(this.messageId);
      this.done = true;
    }
    
    void cancel() {
      if (!this.cancelled) {
        this.trigger.cancel();
        this.cancelled = true;
      } 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\WSDupsEliminationAgent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */