/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import javax.jms.BytesMessage;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.TextMessage;
/*     */ import javax.jms.XAQueueConnection;
/*     */ import javax.jms.XAQueueConnectionFactory;
/*     */ import javax.jms.XAQueueSession;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;
/*     */ import weblogic.t3.srvr.T3Srvr;
/*     */ import weblogic.time.common.Schedulable;
/*     */ import weblogic.time.common.ScheduledTriggerDef;
/*     */ import weblogic.time.common.TimeTriggerException;
/*     */ import weblogic.time.common.Triggerable;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSDupsEliminationAgent
/*     */   implements DupsEliminationAgent
/*     */ {
/*     */   private static boolean debug = false;
/*  93 */   private HashMap receivedMessages = new HashMap();
/*  94 */   private HashMap conversations = new HashMap();
/*  95 */   private HashMap soapMessages = new HashMap(); public static final String DUPS_ELIMINATION_HISTORY_QUEUE_NAME = "jms.internal.queue.WSDupsEliminationHistoryQueue"; public static final String DUPS_ELIMINATION_MESSAGE_QUEUE_NAME = "jms.internal.queue.WSDupsEliminationMessageQueue"; private Context ctx; private Queue historyDestination; private Queue messageDestination; private Connection connection;
/*     */   private Connection xaConnection;
/*     */   private ConnectionFactory cf;
/*     */   
/*  99 */   static WSDupsEliminationAgent getDupsEliminationAgent() { return dupsEliminationAgent; }
/*     */   private ConnectionFactory xaCf; private long defaultPersistDuration; private static WSDupsEliminationAgent dupsEliminationAgent;
/*     */   private boolean started;
/*     */   
/*     */   public static WSDupsEliminationAgent createAgent(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean) {
/* 104 */     if (dupsEliminationAgent != null) return dupsEliminationAgent;
/*     */     
/* 106 */     dupsEliminationAgent = new WSDupsEliminationAgent();
/* 107 */     dupsEliminationAgent.init(paramWSReliableDeliveryPolicyMBean);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 113 */       dupsEliminationAgent.start();
/* 114 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 118 */     return dupsEliminationAgent;
/*     */   }
/*     */   private boolean recovered; private boolean repeatIt; private String lastMessageId; private String name;
/*     */   
/* 122 */   boolean isStarted() { return this.started; }
/*     */ 
/*     */ 
/*     */   
/* 126 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean) {
/* 139 */     this.name = paramWSReliableDeliveryPolicyMBean.getName() + "DupsEliminationAgent";
/*     */ 
/*     */     
/* 142 */     this.defaultPersistDuration = (paramWSReliableDeliveryPolicyMBean.getDefaultTimeToLive() * 1000);
/*     */     
/* 144 */     if (debug) {
/* 145 */       Debug.say(" == init(): PersistDuration = " + this.defaultPersistDuration);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void start() {
/* 155 */     if (this.started)
/*     */       return; 
/* 157 */     this.ctx = Util.getInitialContext();
/*     */     
/* 159 */     this.cf = Util.getConnectionFactory();
/*     */ 
/*     */     
/* 162 */     this.xaCf = Util.getXAConnectionFactory();
/*     */     
/* 164 */     this.historyDestination = (Queue)this.ctx.lookup("jms.internal.queue.WSDupsEliminationHistoryQueue");
/*     */ 
/*     */ 
/*     */     
/* 168 */     debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     if (!this.recovered) {
/* 174 */       recoverHistoryRecords();
/* 175 */       this.recovered = true;
/*     */     } 
/*     */     
/* 178 */     this.xaConnection = ((XAQueueConnectionFactory)this.xaCf).createXAQueueConnection();
/*     */ 
/*     */     
/* 181 */     this.connection = ((QueueConnectionFactory)this.cf).createQueueConnection();
/*     */ 
/*     */     
/* 184 */     this.connection.start();
/* 185 */     this.xaConnection.start();
/*     */     
/* 187 */     this.started = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public boolean storeHistoryRecord(String paramString) throws StoreForwardException { return storeHistoryRecord(paramString, this.defaultPersistDuration); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForStart() {
/* 210 */     boolean bool = false;
/*     */     
/* 212 */     while (!bool) {
/*     */       try {
/* 214 */         start();
/* 215 */         bool = true;
/* 216 */       } catch (NamingException namingException) {
/*     */ 
/*     */       
/* 219 */       } catch (StoreForwardException storeForwardException) {
/*     */ 
/*     */         
/* 222 */         WebServiceLogger.logFailedAccessStore(storeForwardException.getLinkedException());
/* 223 */         throw storeForwardException;
/* 224 */       } catch (JMSException jMSException) {
/*     */ 
/*     */         
/* 227 */         WebServiceLogger.logFailedAccessStore(jMSException);
/* 228 */         throw new StoreForwardException("Failed to start the reliable agent", jMSException);
/*     */       } 
/*     */       
/* 231 */       if (!bool) {
/*     */         try {
/* 233 */           Thread.sleep(500L);
/* 234 */         } catch (InterruptedException interruptedException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean storeHistoryRecord(String paramString, long paramLong) throws StoreForwardException {
/* 250 */     waitForStart();
/*     */     
/* 252 */     if (!addReceivedMessage(paramString, false, paramLong)) {
/* 253 */       return false;
/*     */     }
/*     */     try {
/* 256 */       XAQueueSession xAQueueSession = ((XAQueueConnection)this.xaConnection).createXAQueueSession();
/*     */ 
/*     */       
/* 259 */       QueueSession queueSession = xAQueueSession.getQueueSession();
/*     */       
/* 261 */       TextMessage textMessage = queueSession.createTextMessage(paramString);
/* 262 */       textMessage.setStringProperty("WSSAFID", paramString);
/*     */       
/* 264 */       QueueSender queueSender = queueSession.createSender(this.historyDestination);
/*     */       
/* 266 */       queueSender.send(textMessage, 2, 4, paramLong);
/*     */       
/* 268 */       queueSession.close();
/*     */       
/* 270 */       if (debug) {
/* 271 */         Debug.say("== storeHistoryRecord(): MessageID stored: " + paramString);
/*     */       }
/* 273 */     } catch (JMSException jMSException) {
/* 274 */       Debug.say(" ===  storeHistoryRecord() got Exception:" + jMSException);
/*     */ 
/*     */       
/* 277 */       synchronized (this) {
/* 278 */         close();
/* 279 */         this.started = false;
/*     */       } 
/* 281 */       throw new StoreForwardException("Failed to store the history record for message: " + paramString, jMSException);
/*     */     } 
/*     */ 
/*     */     
/* 285 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public void storeMessageOnly(String paramString, Object paramObject) throws StoreForwardException { storeMessageOnly(paramString, paramObject, this.defaultPersistDuration); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void storeMessageOnly(String paramString, Object paramObject, long paramLong) throws StoreForwardException {
/* 314 */     waitForStart();
/* 315 */     addSOAPMessage(paramString, paramObject);
/*     */     
/*     */     try {
/* 318 */       QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(true, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 324 */       QueueSender queueSender = queueSession.createSender(this.messageDestination);
/*     */ 
/*     */       
/* 327 */       Message message = createMessage(queueSession, paramObject);
/*     */       
/* 329 */       message.setStringProperty("WSSAFID", paramString);
/*     */       
/* 331 */       queueSender.send(message, 2, 4, paramLong);
/* 332 */       queueSession.close();
/*     */       
/* 334 */       if (debug) {
/* 335 */         Debug.say("=== storeMessageOnly(): MessageID stored: " + paramString);
/*     */       }
/* 337 */     } catch (JMSException jMSException) {
/* 338 */       Debug.say(" ===  storeMessageOnly() got Exception:" + jMSException);
/*     */ 
/*     */       
/* 341 */       synchronized (this) {
/* 342 */         close();
/* 343 */         this.started = false;
/*     */       } 
/*     */       
/* 346 */       throw new StoreForwardException("Failed to store the message: " + paramString, jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 363 */   public void storeHistoryRecordAndMessage(String paramString, Object paramObject) throws StoreForwardException { storeHistoryRecordAndMessage(paramString, paramObject, this.defaultPersistDuration); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void storeHistoryRecordAndMessage(String paramString, Object paramObject, long paramLong) throws StoreForwardException {
/* 377 */     waitForStart();
/*     */     
/* 379 */     addReceivedMessage(paramString, false, paramLong);
/* 380 */     addSOAPMessage(paramString, paramObject);
/*     */     
/*     */     try {
/* 383 */       QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(true, 2);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 388 */       TextMessage textMessage = queueSession.createTextMessage(paramString);
/* 389 */       textMessage.setStringProperty("WSSAFID", paramString);
/*     */       
/* 391 */       QueueSender queueSender = queueSession.createSender(this.historyDestination);
/*     */       
/* 393 */       queueSender.send(textMessage, 2, 4, paramLong);
/*     */       
/* 395 */       queueSender = queueSession.createSender(this.messageDestination);
/*     */       
/* 397 */       Message message = createMessage(queueSession, paramObject);
/*     */       
/* 399 */       message.setStringProperty("WSSAFID", paramString);
/*     */       
/* 401 */       queueSender.send(message, 2, 4, paramLong);
/* 402 */       queueSession.close();
/*     */       
/* 404 */       if (debug) Debug.say("=== storeHistoryRecordAndMEssage(): MessageID stored: " + paramString);
/*     */       
/*     */     
/*     */     }
/* 408 */     catch (JMSException jMSException) {
/* 409 */       Debug.say(" ===  storeHistoryRecordAndMessage() got Exception:" + jMSException);
/*     */ 
/*     */       
/* 412 */       synchronized (this) {
/* 413 */         close();
/* 414 */         this.started = false;
/*     */       } 
/*     */       
/* 417 */       throw new StoreForwardException("Failed to store the history record and the message itself: " + paramString, jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHistoryRecordInMemoryOnly(String paramString) {
/* 432 */     if (paramString == null) {
/*     */       return;
/*     */     }
/* 435 */     removeReceivedMessage(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHistoryRecord(String paramString) {
/* 447 */     if (paramString == null) {
/*     */       return;
/*     */     }
/* 450 */     removeReceivedMessage(paramString);
/*     */     
/* 452 */     waitForStart();
/*     */     
/*     */     try {
/* 455 */       QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(false, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 461 */       String str = "WSSAFID = '" + paramString + "'";
/*     */       
/* 463 */       QueueReceiver queueReceiver = queueSession.createReceiver(this.historyDestination, str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 469 */       Message message = queueReceiver.receiveNoWait();
/*     */       
/* 471 */       queueSession.close();
/*     */       
/* 473 */       if (debug) Debug.say("=== removeHistoryRecord() removed: " + message);
/*     */     
/* 475 */     } catch (JMSException jMSException) {
/* 476 */       Debug.say(" === removeHistoryRecord() got Exception:" + jMSException);
/*     */ 
/*     */       
/* 479 */       synchronized (this) {
/* 480 */         close();
/* 481 */         this.started = false;
/*     */       } 
/*     */       
/* 484 */       throw new StoreForwardException("Failed to remove the history record for message: " + paramString, jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMessageOnly(String paramString) {
/* 498 */     if (paramString == null)
/*     */       return; 
/* 500 */     waitForStart();
/*     */     
/*     */     try {
/* 503 */       QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(false, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 509 */       String str = "WSSAFID = '" + paramString + "'";
/*     */       
/* 511 */       QueueReceiver queueReceiver = queueSession.createReceiver(this.messageDestination, str);
/*     */ 
/*     */       
/* 514 */       Message message = queueReceiver.receiveNoWait();
/*     */       
/* 516 */       queueSession.close();
/*     */       
/* 518 */       if (debug) Debug.say("=== removeMessageOnly() removed: " + message);
/*     */     
/* 520 */     } catch (JMSException jMSException) {
/* 521 */       Debug.say(" === removeMessageOnly() got Exception:" + jMSException);
/*     */ 
/*     */       
/* 524 */       synchronized (this) {
/* 525 */         close();
/* 526 */         this.started = false;
/*     */       } 
/*     */       
/* 529 */       throw new StoreForwardException("Failed to remove message: " + paramString, jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHistoryRecordAndMessage(String paramString) {
/* 544 */     if (paramString == null)
/*     */       return; 
/* 546 */     waitForStart();
/*     */ 
/*     */     
/* 549 */     removeReceivedMessage(paramString);
/*     */     
/*     */     try {
/* 552 */       QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(false, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 558 */       String str = "WSSAFID = '" + paramString + "'";
/*     */       
/* 560 */       QueueReceiver queueReceiver = queueSession.createReceiver(this.historyDestination, str);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 565 */       Message message = queueReceiver.receiveNoWait();
/*     */       
/* 567 */       if (debug) Debug.say("=== removed the history record: " + message);
/*     */       
/* 569 */       queueReceiver = queueSession.createReceiver(this.messageDestination, str);
/*     */       
/* 571 */       message = queueReceiver.receiveNoWait();
/*     */       
/* 573 */       queueSession.close();
/*     */       
/* 575 */       if (debug) Debug.say("=== removed the message: " + message);
/*     */     
/* 577 */     } catch (JMSException jMSException) {
/* 578 */       Debug.say(" === removeHistoryRecord() got Exception:" + jMSException);
/*     */ 
/*     */       
/* 581 */       synchronized (this) {
/* 582 */         close();
/* 583 */         this.started = false;
/*     */       } 
/*     */       
/* 586 */       throw new StoreForwardException("Failed to remove the history record and the message: " + paramString, jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeHistoryRecordForConversation(String paramString) {
/* 600 */     if (paramString == null)
/*     */       return; 
/* 602 */     waitForStart();
/*     */     
/* 604 */     Iterator iterator = ((ConversationReassembler)getConversation(paramString)).getMessages().iterator();
/*     */ 
/*     */     
/* 607 */     QueueSession queueSession = null;
/* 608 */     QueueReceiver queueReceiver = null;
/* 609 */     Message message = null;
/*     */     
/* 611 */     while (iterator.hasNext()) {
/* 612 */       String str = (String)iterator.next();
/*     */ 
/*     */       
/*     */       try {
/* 616 */         removeReceivedMessage(str);
/*     */         
/* 618 */         queueSession = ((QueueConnection)this.connection).createQueueSession(false, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 624 */         String str1 = "WSSAFID = '" + str + "'";
/*     */         
/* 626 */         queueReceiver = queueSession.createReceiver(this.historyDestination, str1);
/*     */         
/* 628 */         message = queueReceiver.receiveNoWait();
/*     */         
/* 630 */         queueSession.close();
/*     */         
/* 632 */         if (debug) Debug.say("=== removed: " + message);
/*     */       
/* 634 */       } catch (JMSException jMSException) {
/* 635 */         Debug.say(" === remove() got Exception:" + jMSException);
/*     */ 
/*     */         
/* 638 */         synchronized (this) {
/* 639 */           close();
/* 640 */           this.started = false;
/*     */         } 
/*     */         
/* 643 */         throw new StoreForwardException("Failed to remove the history record for conversation: " + paramString, jMSException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 659 */   public Object process(String paramString) throws StoreForwardException { return getSOAPMessage(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 668 */     if (this.connection != null) {
/*     */       try {
/* 670 */         this.connection.close();
/* 671 */       } catch (JMSException jMSException) {}
/* 672 */       this.connection = null;
/*     */     } 
/* 674 */     if (this.xaConnection != null) {
/*     */       try {
/* 676 */         this.xaConnection.close();
/* 677 */       } catch (JMSException jMSException) {}
/* 678 */       this.xaConnection = null;
/*     */     } 
/*     */ 
/*     */     
/* 682 */     this.receivedMessages.clear();
/* 683 */     this.soapMessages.clear();
/* 684 */     Iterator iterator = this.conversations.values().iterator();
/* 685 */     while (iterator.hasNext()) {
/* 686 */       ((ConversationReassembler)iterator.next()).close();
/*     */     }
/* 688 */     this.conversations.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean addReceivedMessage(String paramString, boolean paramBoolean, long paramLong) {
/* 696 */     if (this.receivedMessages.get(paramString) != null) return false;
/*     */     
/* 698 */     long l = paramLong;
/* 699 */     if (!paramBoolean) l = System.currentTimeMillis() + paramLong;
/*     */     
/* 701 */     HistoryRecord historyRecord = new HistoryRecord(paramString, l);
/*     */     
/* 703 */     this.receivedMessages.put(paramString, historyRecord);
/*     */ 
/*     */     
/*     */     try {
/* 707 */       historyRecord.init();
/* 708 */     } catch (TimeTriggerException timeTriggerException) {
/* 709 */       if (debug) {
/* 710 */         Debug.say("==addReceivedMessage(): failed to init the trigger");
/*     */       }
/*     */     } 
/*     */     
/* 714 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 720 */   private void removeReceivedMessage(String paramString) { this.receivedMessages.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDuplicate(String paramString) throws StoreForwardException {
/* 730 */     if (this.receivedMessages.get(paramString) != null) {
/* 731 */       return true;
/*     */     }
/* 733 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 738 */   public long getDefaultPersistDuration() { return this.defaultPersistDuration; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConversationReassembler createConversation(String paramString, boolean paramBoolean) {
/* 748 */     ConversationReassembler conversationReassembler = new ConversationReassembler(paramString, paramBoolean);
/* 749 */     this.conversations.put(paramString, conversationReassembler);
/* 750 */     return conversationReassembler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 759 */   public Conversation getConversation(String paramString) { return (Conversation)this.conversations.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 768 */   public void removeConversation(String paramString) { this.conversations.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 778 */   public void addSOAPMessage(String paramString, Object paramObject) throws StoreForwardException { this.soapMessages.put(paramString, paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 787 */   public void removeSOAPMessage(String paramString) { this.soapMessages.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 796 */   public MessageContext getSOAPMessage(String paramString) { return (MessageContext)this.soapMessages.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Message createMessage(Session paramSession, Object paramObject) throws StoreForwardException {
/* 804 */     if (!(paramObject instanceof SOAPMessageContext)) {
/* 805 */       throw new StoreForwardException("Invalid message");
/*     */     }
/* 807 */     SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramObject;
/*     */     
/*     */     try {
/* 810 */       byte[] arrayOfByte = Util.soapMessage2Bytes(sOAPMessageContext);
/*     */       
/* 812 */       BytesMessage bytesMessage = paramSession.createBytesMessage();
/* 813 */       bytesMessage.writeBytes(arrayOfByte);
/* 814 */       return bytesMessage;
/* 815 */     } catch (JMSException jMSException) {
/* 816 */       throw new StoreForwardException("Failed to create message", jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void recoverHistoryRecords() {
/*     */     try {
/* 828 */       QueueConnection queueConnection = ((QueueConnectionFactory)this.cf).createQueueConnection();
/*     */ 
/*     */       
/* 831 */       QueueSession queueSession = queueConnection.createQueueSession(false, 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 837 */       QueueReceiver queueReceiver = queueSession.createReceiver(this.historyDestination);
/*     */ 
/*     */       
/* 840 */       queueConnection.start();
/*     */       
/* 842 */       Message message = null;
/*     */       
/*     */       do {
/* 845 */         message = queueReceiver.receiveNoWait();
/* 846 */         if (message == null || !(message instanceof TextMessage))
/* 847 */           continue;  String str = ((TextMessage)message).getText();
/* 848 */         addReceivedMessage(str, true, message.getJMSExpiration());
/* 849 */         if (!debug) continue;  Debug.say("== recoverHistoryRecords(): MessageID restored: " + str);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 855 */       while (message != null);
/*     */       
/* 857 */       queueSession.close();
/* 858 */       queueConnection.close();
/*     */     }
/* 860 */     catch (JMSException jMSException) {
/* 861 */       if (debug) {
/* 862 */         Debug.say(" ===  storeHistoryRecord() got Exception:" + jMSException);
/*     */       }
/* 864 */       throw new StoreForwardException("Failed to recover the history record", jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void run(String paramString) {
/* 871 */     if (debug) Debug.say("== Expiring history record for message: " + paramString);
/*     */ 
/*     */     
/* 874 */     removeReceivedMessage(paramString);
/*     */     try {
/* 876 */       removeHistoryRecord(paramString);
/* 877 */     } catch (StoreForwardException storeForwardException) {}
/*     */   }
/*     */   
/*     */   private class HistoryRecord implements Schedulable, Triggerable { private String messageId;
/*     */     private ScheduledTriggerDef trigger;
/*     */     private boolean cancelled;
/*     */     private long timeout;
/*     */     private boolean done;
/*     */     private final WSDupsEliminationAgent this$0;
/*     */     
/*     */     HistoryRecord(String param1String, long param1Long) {
/* 888 */       this.done = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 894 */       this.messageId = param1String;
/* 895 */       this.timeout = param1Long;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void init() {
/* 903 */       this.trigger = T3Srvr.getT3Srvr().getT3Services().time().getScheduledTrigger(this, this);
/*     */ 
/*     */ 
/*     */       
/* 907 */       this.trigger.schedule();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long schedule(long param1Long) {
/* 915 */       if (!this.done) return this.timeout; 
/* 916 */       return 0L;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void trigger(Schedulable param1Schedulable) {
/* 922 */       WSDupsEliminationAgent.this.run(this.messageId);
/* 923 */       this.done = true;
/*     */     }
/*     */     
/*     */     void cancel() {
/* 927 */       if (!this.cancelled) {
/* 928 */         this.trigger.cancel();
/* 929 */         this.cancelled = true;
/*     */       } 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\WSDupsEliminationAgent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */