/*    */ package weblogic.webservice.saf;
/*    */ 
/*    */ import weblogic.t3.srvr.T3Srvr;
/*    */ import weblogic.time.common.Schedulable;
/*    */ import weblogic.time.common.ScheduledTriggerDef;
/*    */ import weblogic.time.common.TimeTriggerException;
/*    */ import weblogic.time.common.Triggerable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RetryTrigger
/*    */   implements Schedulable, Triggerable
/*    */ {
/*    */   private Conversation conversation;
/*    */   private ScheduledTriggerDef trigger;
/*    */   private boolean cancelled;
/*    */   private long delay;
/*    */   
/*    */   RetryTrigger(Conversation paramConversation, long paramLong) {
/* 30 */     this.conversation = paramConversation;
/* 31 */     this.delay = paramLong;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void init() throws TimeTriggerException {
/* 39 */     this.trigger = T3Srvr.getT3Srvr().getT3Services().time().getScheduledTrigger(this, this);
/*    */ 
/*    */     
/* 42 */     this.trigger.schedule();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   public long schedule(long paramLong) { return paramLong + this.delay; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   public void trigger(Schedulable paramSchedulable) { this.conversation.run(); }
/*    */ 
/*    */   
/*    */   void cancel() throws TimeTriggerException {
/* 61 */     if (!this.cancelled) {
/* 62 */       this.trigger.cancel();
/* 63 */       this.cancelled = true;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   void updateInterval(long paramLong) { this.delay = paramLong; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\RetryTrigger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */