package weblogic.webservice.saf;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Enumeration;
import javax.jms.BytesMessage;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import weblogic.jms.extensions.WLSession;
import weblogic.utils.Debug;
import weblogic.webservice.ReliableDelivery;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.core.DefaultMessageContext;
import weblogic.webservice.util.WLMessageFactory;

class MessageReader implements MessageListener, ExceptionListener {
  private WSAgent agent;
  
  private QueueConnection connection;
  
  private QueueSession session;
  
  private QueueReceiver consumer;
  
  private ConnectionFactory cf;
  
  private Destination destination;
  
  private static boolean debug = false;
  
  MessageReader(WSAgent paramWSAgent, ConnectionFactory paramConnectionFactory, Destination paramDestination) {
    this.agent = paramWSAgent;
    this.cf = paramConnectionFactory;
    this.destination = paramDestination;
    debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
  }
  
  void start() throws JMSException {
    this.connection = ((QueueConnectionFactory)this.cf).createQueueConnection();
    this.session = this.connection.createQueueSession(false, 2);
    QueueReceiver queueReceiver = this.session.createReceiver((Queue)this.destination);
    ((WLSession)this.session).setExceptionListener(this);
    queueReceiver.setMessageListener(this);
    this.connection.start();
    if (debug)
      Debug.say(" == message reader is started"); 
  }
  
  void restart() throws JMSException {
    close();
    try {
      start();
    } catch (JMSException jMSException) {
      WebServiceLogger.logFailedAccessStore(jMSException);
    } 
  }
  
  void close() throws JMSException {
    try {
      this.connection.close();
    } catch (JMSException jMSException) {}
  }
  
  public void onMessage(Message paramMessage) {
    String str1 = null;
    if (debug)
      Debug.say(" == received a message " + paramMessage); 
    try {
      str1 = paramMessage.getStringProperty("WSSAFID");
    } catch (JMSException jMSException) {
      Debug.say("faile to get WSSAFID");
    } 
    if (debug)
      Debug.say("WSSAFID = " + str1); 
    String str2 = Util.getMessageId(str1);
    int i = Util.getSequenceNumber(str1);
    String str3 = Util.getConversationId(str1);
    String str4 = Util.getHeaderType(str1);
    if (debug)
      Debug.say("messageId = " + str2 + " sequenceNumber = " + i + " conversationId = " + str3 + " headerType = " + str4); 
    boolean bool1 = false;
    boolean bool2 = true;
    if (str3.equals("con" + str2)) {
      bool1 = true;
      bool2 = false;
    } 
    Conversation conversation = this.agent.getConversation(str3);
    if (conversation == null)
      conversation = ((SAFAgent)this.agent).createConversation(str3, bool1, bool2, -1, -1L, -1L, null); 
    MessageContext messageContext = this.agent.getSOAPMessage(str2);
    if (messageContext == null) {
      if (debug)
        Debug.say("Failed to find the message context, will create one"); 
      try {
        messageContext = createMessageContext(str2, str3, i, paramMessage);
      } catch (Exception exception) {
        WebServiceLogger.logFailedCreateContext(exception);
        if (debug)
          Debug.say("Failed to create the message context, exception:" + exception); 
        return;
      } 
      ((SAFAgent)this.agent).restoreMessage(str2, messageContext);
    } 
    ((WSSAFAgent)this.agent).addUnackedMsg(str2, paramMessage);
    conversation.addMessage(str2, i, messageContext);
    if (messageContext != null && str3.equals("con" + str2))
      conversation.setSeenLastMsg(true); 
    if (str4 != null && str4.equals("FinishHeader"))
      conversation.setSeenLastMsg(true); 
    if (debug)
      Debug.say("*** run the conversation ***"); 
    conversation.run();
  }
  
  public void onException(JMSException paramJMSException) {
    if (debug)
      Debug.say("Got exception " + paramJMSException); 
    synchronized (this) {
      restart();
    } 
  }
  
  private MessageContext createMessageContext(String paramString1, String paramString2, int paramInt, Message paramMessage) throws IOException, JMSException, SOAPException, StoreForwardException {
    DefaultMessageContext defaultMessageContext = new DefaultMessageContext();
    if (!(paramMessage instanceof BytesMessage))
      throw new SOAPException("internal error: invalid message type"); 
    try {
      String str1 = paramMessage.getStringProperty("WSSAFBindingAddress");
      String str2 = paramMessage.getStringProperty("WSSAFBindingTransport");
      String str3 = paramMessage.getStringProperty("WSSAFBindingCharset");
      String str4 = paramMessage.getStringProperty("WSSAFBindingType");
      Binding binding = Util.createBinding(str1, str2, str4, str3);
      defaultMessageContext.setProperty("__BEA_PRIVATE_BINDING_PROP", binding);
      int i = paramMessage.getIntProperty("WSSAFEnvelopeSize");
      if (debug)
        Debug.say("createMessageContext(): size= " + i); 
      byte[] arrayOfByte = new byte[i];
      ((BytesMessage)paramMessage).readBytes(arrayOfByte, i);
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
      MimeHeaders mimeHeaders = new MimeHeaders();
      Enumeration enumeration = paramMessage.getPropertyNames();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        if (str.startsWith("WSSAFMimeHeader")) {
          String str5 = paramMessage.getStringProperty(str);
          String str6 = str.substring("WSSAFMimeHeader".length());
          if (!str6.equals("Content-Type"))
            mimeHeaders.setHeader(str6, str5); 
          if (debug)
            Debug.say("createMessageContext(): mime header= " + str6 + " mime header value = " + str5); 
        } 
      } 
      mimeHeaders.setHeader("Content-Type", paramMessage.getStringProperty("WSSAFSOAPMsgContentType"));
      MessageFactory messageFactory = WLMessageFactory.getInstance().getMessageFactory();
      ((DefaultMessageContext)defaultMessageContext).setMessage(messageFactory.createMessage(mimeHeaders, byteArrayInputStream));
      if (paramMessage.propertyExists("WSSAFListenerSize"))
        try {
          int j = paramMessage.getIntProperty("WSSAFListenerSize");
          byte[] arrayOfByte1 = new byte[j];
          ((BytesMessage)paramMessage).readBytes(arrayOfByte1, j);
          ByteArrayInputStream byteArrayInputStream1 = new ByteArrayInputStream(arrayOfByte1);
          ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream1);
          ReliableDelivery reliableDelivery = (ReliableDelivery)objectInputStream.readObject();
          defaultMessageContext.setProperty("__BEA_PRIVATE_RELIABLE_PROP", reliableDelivery);
        } catch (Exception exception) {
          if (debug)
            Debug.say("Could not recreate ReliableDelivery listener" + exception); 
          throw new IOException("Could not recreate ReliableDelivery listener. " + exception.getMessage());
        }  
      return defaultMessageContext;
    } catch (IOException iOException) {
      throw iOException;
    } catch (JMSException jMSException) {
      throw jMSException;
    } catch (SOAPException sOAPException) {
      throw sOAPException;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\MessageReader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */