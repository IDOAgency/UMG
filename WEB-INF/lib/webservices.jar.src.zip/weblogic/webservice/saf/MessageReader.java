/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.Enumeration;
/*     */ import javax.jms.BytesMessage;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.ExceptionListener;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.soap.MessageFactory;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.jms.extensions.WLSession;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.ReliableDelivery;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.core.DefaultMessageContext;
/*     */ import weblogic.webservice.util.WLMessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MessageReader
/*     */   implements MessageListener, ExceptionListener
/*     */ {
/*     */   private WSAgent agent;
/*     */   private QueueConnection connection;
/*     */   private QueueSession session;
/*     */   private QueueReceiver consumer;
/*     */   private ConnectionFactory cf;
/*     */   private Destination destination;
/*     */   private static boolean debug = false;
/*     */   
/*     */   MessageReader(WSAgent paramWSAgent, ConnectionFactory paramConnectionFactory, Destination paramDestination) {
/*  83 */     this.agent = paramWSAgent;
/*  84 */     this.cf = paramConnectionFactory;
/*  85 */     this.destination = paramDestination;
/*     */     
/*  87 */     debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void start() throws JMSException {
/*  93 */     this.connection = ((QueueConnectionFactory)this.cf).createQueueConnection();
/*     */     
/*  95 */     this.session = this.connection.createQueueSession(false, 2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     QueueReceiver queueReceiver = this.session.createReceiver((Queue)this.destination);
/* 101 */     ((WLSession)this.session).setExceptionListener(this);
/*     */     
/* 103 */     queueReceiver.setMessageListener(this);
/* 104 */     this.connection.start();
/*     */     
/* 106 */     if (debug) Debug.say(" == message reader is started"); 
/*     */   }
/*     */   
/*     */   void restart() throws JMSException {
/* 110 */     close();
/*     */     try {
/* 112 */       start();
/* 113 */     } catch (JMSException jMSException) {
/*     */       
/* 115 */       WebServiceLogger.logFailedAccessStore(jMSException);
/*     */     } 
/*     */   }
/*     */   
/*     */   void close() throws JMSException {
/*     */     try {
/* 121 */       this.connection.close();
/* 122 */     } catch (JMSException jMSException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onMessage(Message paramMessage) {
/* 129 */     String str1 = null;
/*     */     
/* 131 */     if (debug) Debug.say(" == received a message " + paramMessage);
/*     */     
/*     */     try {
/* 134 */       str1 = paramMessage.getStringProperty("WSSAFID");
/* 135 */     } catch (JMSException jMSException) {
/*     */       
/* 137 */       Debug.say("faile to get WSSAFID");
/*     */     } 
/*     */     
/* 140 */     if (debug) Debug.say("WSSAFID = " + str1);
/*     */ 
/*     */     
/* 143 */     String str2 = Util.getMessageId(str1);
/* 144 */     int i = Util.getSequenceNumber(str1);
/* 145 */     String str3 = Util.getConversationId(str1);
/* 146 */     String str4 = Util.getHeaderType(str1);
/*     */     
/* 148 */     if (debug) Debug.say("messageId = " + str2 + " sequenceNumber = " + i + " conversationId = " + str3 + " headerType = " + str4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     boolean bool1 = false;
/* 156 */     boolean bool2 = true;
/*     */     
/* 158 */     if (str3.equals("con" + str2)) {
/* 159 */       bool1 = true;
/* 160 */       bool2 = false;
/*     */     } 
/*     */     
/* 163 */     Conversation conversation = this.agent.getConversation(str3);
/*     */ 
/*     */     
/* 166 */     if (conversation == null)
/*     */     {
/* 168 */       conversation = ((SAFAgent)this.agent).createConversation(str3, bool1, bool2, -1, -1L, -1L, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     MessageContext messageContext = this.agent.getSOAPMessage(str2);
/*     */ 
/*     */     
/* 177 */     if (messageContext == null) {
/* 178 */       if (debug)
/* 179 */         Debug.say("Failed to find the message context, will create one"); 
/*     */       try {
/* 181 */         messageContext = createMessageContext(str2, str3, i, paramMessage);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 187 */       catch (Exception exception) {
/*     */ 
/*     */ 
/*     */         
/* 191 */         WebServiceLogger.logFailedCreateContext(exception);
/*     */         
/* 193 */         if (debug) {
/* 194 */           Debug.say("Failed to create the message context, exception:" + exception);
/*     */         }
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 202 */       ((SAFAgent)this.agent).restoreMessage(str2, messageContext);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 207 */     ((WSSAFAgent)this.agent).addUnackedMsg(str2, paramMessage);
/*     */ 
/*     */     
/* 210 */     conversation.addMessage(str2, i, messageContext);
/*     */ 
/*     */ 
/*     */     
/* 214 */     if (messageContext != null && str3.equals("con" + str2)) {
/* 215 */       conversation.setSeenLastMsg(true);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 220 */     if (str4 != null && str4.equals("FinishHeader"))
/*     */     {
/* 222 */       conversation.setSeenLastMsg(true);
/*     */     }
/*     */     
/* 225 */     if (debug) Debug.say("*** run the conversation ***");
/*     */     
/* 227 */     conversation.run();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onException(JMSException paramJMSException) {
/* 232 */     if (debug) Debug.say("Got exception " + paramJMSException);
/*     */     
/* 234 */     synchronized (this) {
/* 235 */       restart();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MessageContext createMessageContext(String paramString1, String paramString2, int paramInt, Message paramMessage) throws IOException, JMSException, SOAPException, StoreForwardException {
/* 245 */     DefaultMessageContext defaultMessageContext = new DefaultMessageContext();
/*     */     
/* 247 */     if (!(paramMessage instanceof BytesMessage)) {
/* 248 */       throw new SOAPException("internal error: invalid message type");
/*     */     }
/*     */     
/*     */     try {
/* 252 */       String str1 = paramMessage.getStringProperty("WSSAFBindingAddress");
/* 253 */       String str2 = paramMessage.getStringProperty("WSSAFBindingTransport");
/* 254 */       String str3 = paramMessage.getStringProperty("WSSAFBindingCharset");
/* 255 */       String str4 = paramMessage.getStringProperty("WSSAFBindingType");
/*     */       
/* 257 */       Binding binding = Util.createBinding(str1, str2, str4, str3);
/*     */       
/* 259 */       defaultMessageContext.setProperty("__BEA_PRIVATE_BINDING_PROP", binding);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 264 */       int i = paramMessage.getIntProperty("WSSAFEnvelopeSize");
/*     */       
/* 266 */       if (debug) {
/* 267 */         Debug.say("createMessageContext(): size= " + i);
/*     */       }
/*     */       
/* 270 */       byte[] arrayOfByte = new byte[i];
/* 271 */       ((BytesMessage)paramMessage).readBytes(arrayOfByte, i);
/* 272 */       ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
/*     */       
/* 274 */       MimeHeaders mimeHeaders = new MimeHeaders();
/* 275 */       Enumeration enumeration = paramMessage.getPropertyNames();
/* 276 */       while (enumeration.hasMoreElements()) {
/* 277 */         String str = (String)enumeration.nextElement();
/* 278 */         if (str.startsWith("WSSAFMimeHeader")) {
/* 279 */           String str5 = paramMessage.getStringProperty(str);
/* 280 */           String str6 = str.substring("WSSAFMimeHeader".length());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 286 */           if (!str6.equals("Content-Type")) {
/* 287 */             mimeHeaders.setHeader(str6, str5);
/*     */           }
/*     */           
/* 290 */           if (debug) {
/* 291 */             Debug.say("createMessageContext(): mime header= " + str6 + " mime header value = " + str5);
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 297 */       mimeHeaders.setHeader("Content-Type", paramMessage.getStringProperty("WSSAFSOAPMsgContentType"));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 302 */       MessageFactory messageFactory = WLMessageFactory.getInstance().getMessageFactory();
/*     */       
/* 304 */       ((DefaultMessageContext)defaultMessageContext).setMessage(messageFactory.createMessage(mimeHeaders, byteArrayInputStream));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 310 */       if (paramMessage.propertyExists("WSSAFListenerSize")) {
/*     */         try {
/* 312 */           int j = paramMessage.getIntProperty("WSSAFListenerSize");
/* 313 */           byte[] arrayOfByte1 = new byte[j];
/* 314 */           ((BytesMessage)paramMessage).readBytes(arrayOfByte1, j);
/*     */           
/* 316 */           ByteArrayInputStream byteArrayInputStream1 = new ByteArrayInputStream(arrayOfByte1);
/* 317 */           ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream1);
/*     */           
/* 319 */           ReliableDelivery reliableDelivery = (ReliableDelivery)objectInputStream.readObject();
/* 320 */           defaultMessageContext.setProperty("__BEA_PRIVATE_RELIABLE_PROP", reliableDelivery);
/* 321 */         } catch (Exception exception) {
/* 322 */           if (debug) {
/* 323 */             Debug.say("Could not recreate ReliableDelivery listener" + exception);
/*     */           }
/* 325 */           throw new IOException("Could not recreate ReliableDelivery listener. " + exception.getMessage());
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 330 */       return defaultMessageContext;
/* 331 */     } catch (IOException iOException) {
/* 332 */       throw iOException;
/* 333 */     } catch (JMSException jMSException) {
/* 334 */       throw jMSException;
/* 335 */     } catch (SOAPException sOAPException) {
/* 336 */       throw sOAPException;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\MessageReader.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */