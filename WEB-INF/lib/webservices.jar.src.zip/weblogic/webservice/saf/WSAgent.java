package weblogic.webservice.saf;

import javax.xml.rpc.handler.MessageContext;
import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;

public interface WSAgent {
  String getName();
  
  void init(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean);
  
  void close();
  
  void waitForStart();
  
  Conversation getConversation(String paramString);
  
  void removeConversation(String paramString);
  
  MessageContext getSOAPMessage(String paramString);
  
  void removeSOAPMessage(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\WSAgent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */