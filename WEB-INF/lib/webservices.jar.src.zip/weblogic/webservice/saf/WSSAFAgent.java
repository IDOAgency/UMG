/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import javax.jms.BytesMessage;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.jms.Session;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.MimeHeader;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;
/*     */ import weblogic.time.common.TimeTriggerException;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.ReliableDelivery;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.WLSOAPMessage;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.binding.AbstractBinding;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.client.SSLAdapter;
/*     */ import weblogic.webservice.conversation.ConversationListener;
/*     */ import weblogic.webservice.conversation.ConversationManager;
/*     */ import weblogic.webservice.conversation.ConversationManagerFactory;
/*     */ import weblogic.webservice.core.handler.ConversationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSSAFAgent
/*     */   implements SAFAgent, ConversationListener
/*     */ {
/*     */   public static final String STORE_AND_FORWARD_QUEUE_NAME = "jms.internal.queue.WSStoreForwardQueue";
/*     */   public static final String WSSAF_ID_PROP = "WSSAFID";
/*     */   public static final String ENVELOPE_SIZE_PROP = "WSSAFEnvelopeSize";
/*     */   public static final String LISTENER_SIZE_PROP = "WSSAFListenerSize";
/*     */   public static final String BINDING_ADDRESS_PROP = "WSSAFBindingAddress";
/*     */   public static final String BINDING_TYPE_PROP = "WSSAFBindingType";
/*     */   public static final String BINDING_CHARSET_PROP = "WSSAFBindingCharset";
/*     */   public static final String BINDING_TRANSPORT_PROP = "WSSAFBindingTransport";
/*     */   public static final String BINDING_SOAP12_PROP = "WSSAFBindingIsSoap12";
/*     */   public static final String BINDINGINFO_TYPE_PROP = "WSSAFBindingInfoType";
/*     */   public static final String SOAP_CONTENT_TYPE_PROP = "WSSAFSOAPMsgContentType";
/*     */   static final String MIMEHEADER_NAME_PREFIX = "WSSAFMimeHeader";
/*     */   private String name;
/*     */   private HashMap unackedMessages;
/*     */   private HashMap soapMessages;
/*     */   private HashMap conversations;
/*     */   private Context ctx;
/*     */   private Queue destination;
/*     */   private Connection connection;
/*     */   private ConnectionFactory cf;
/*     */   private int retryNumber;
/*     */   private long retryInterval;
/*     */   private long persistDuration;
/*     */   private static WSSAFAgent safAgent;
/*     */   private boolean started;
/*     */   private boolean repeatIt;
/*     */   private String lastMessageId;
/*     */   private static int sinceStart;
/*     */   private int idSeed;
/*     */   private int idCounter;
/*     */   private MessageReader reader;
/*     */   private static boolean debug = false;
/*     */   private static boolean falseStartWorkAround = true;
/*     */   
/*     */   WSSAFAgent() {
/* 125 */     this.unackedMessages = new HashMap();
/* 126 */     this.soapMessages = new HashMap();
/* 127 */     this.conversations = new HashMap();
/*     */     
/* 129 */     setupId();
/*     */   }
/*     */ 
/*     */   
/* 133 */   static WSSAFAgent getSAFAgent() { return safAgent; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static WSSAFAgent createAgent(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean) {
/* 138 */     debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
/*     */ 
/*     */     
/* 141 */     falseStartWorkAround = !"true".equalsIgnoreCase(System.getProperty("weblogic.debug.CR096152"));
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (safAgent != null) return safAgent;
/*     */     
/* 147 */     sinceStart = 5;
/* 148 */     safAgent = new WSSAFAgent();
/* 149 */     safAgent.init(paramWSReliableDeliveryPolicyMBean);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 155 */       safAgent.start();
/* 156 */     } catch (Exception exception) {
/*     */       
/* 158 */       StartAgentRetryTimer startAgentRetryTimer = new StartAgentRetryTimer();
/*     */       try {
/* 160 */         startAgentRetryTimer.init(safAgent, 1000L);
/* 161 */       } catch (TimeTriggerException timeTriggerException) {}
/*     */     } 
/*     */ 
/*     */     
/* 165 */     return safAgent;
/*     */   }
/*     */ 
/*     */   
/* 169 */   boolean isStarted() { return this.started; }
/*     */ 
/*     */ 
/*     */   
/* 173 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean) {
/* 186 */     this.name = paramWSReliableDeliveryPolicyMBean.getName() + "SAFAgent";
/* 187 */     this.retryNumber = paramWSReliableDeliveryPolicyMBean.getDefaultRetryCount();
/*     */ 
/*     */     
/* 190 */     this.retryInterval = (paramWSReliableDeliveryPolicyMBean.getDefaultRetryInterval() * 1000);
/* 191 */     this.persistDuration = (paramWSReliableDeliveryPolicyMBean.getDefaultTimeToLive() * 1000);
/*     */     
/* 193 */     if (debug) {
/* 194 */       Debug.say(" == init(): retryInternal = " + this.retryInterval + " persistDuration = " + this.persistDuration);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void start() {
/* 207 */     if (this.started)
/*     */       return; 
/* 209 */     this.ctx = Util.getInitialContext();
/* 210 */     this.cf = Util.getConnectionFactory();
/* 211 */     this.destination = (Queue)this.ctx.lookup("jms.internal.queue.WSStoreForwardQueue");
/*     */     
/* 213 */     this.connection = ((QueueConnectionFactory)this.cf).createQueueConnection();
/*     */     
/* 215 */     this.connection.start();
/*     */ 
/*     */     
/* 218 */     this.reader = new MessageReader(this, this.cf, this.destination);
/*     */     
/*     */     try {
/* 221 */       this.reader.start();
/* 222 */     } catch (JMSException jMSException) {
/*     */       try {
/* 224 */         this.connection.close();
/* 225 */       } catch (JMSException jMSException1) {}
/* 226 */       throw jMSException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 231 */     ConversationManager conversationManager = ConversationManagerFactory.getManager();
/* 232 */     conversationManager.registerConversationListener(this);
/*     */     
/* 234 */     this.started = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForStart() {
/* 245 */     boolean bool = false;
/* 246 */     while (!bool) {
/*     */       try {
/* 248 */         start();
/* 249 */         bool = true;
/* 250 */       } catch (NamingException namingException) {
/* 251 */         if (debug) Debug.say(" waitForStart(): got exception: " + namingException);
/*     */       
/*     */       }
/* 254 */       catch (JMSException jMSException) {
/*     */ 
/*     */         
/* 257 */         WebServiceLogger.logFailedAccessStore(jMSException);
/* 258 */         if (debug) Debug.say(" waitForStart(): got exception: " + jMSException); 
/* 259 */         throw new StoreForwardException("Failed to access the store", jMSException);
/*     */       } 
/* 261 */       if (!bool) {
/*     */         try {
/* 263 */           Thread.sleep(500L);
/* 264 */         } catch (InterruptedException interruptedException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 272 */   public void resetSinceStart() { sinceStart = 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void store(String paramString1, String paramString2, String paramString3, Object paramObject, ReliableDelivery paramReliableDelivery, long paramLong) throws StoreForwardException {
/* 288 */     if (debug) Debug.say(" == store(): waiting for the agent to start");
/*     */     
/* 290 */     waitForStart();
/*     */     
/* 292 */     if (debug) Debug.say(" == store(): agent is started");
/*     */     
/*     */     try {
/* 295 */       if (paramObject instanceof SOAPMessageContext) {
/*     */ 
/*     */         
/* 298 */         SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramObject;
/* 299 */         InputStream inputStream = (InputStream)sOAPMessageContext.getProperty("__BEA_PRIVATE_SOAP_MESSAGE_PROP");
/* 300 */         if (inputStream != null) {
/* 301 */           HashMap hashMap = (HashMap)sOAPMessageContext.getProperty("__BEA_PRIVATE_MIME_HEADERS_PROP");
/* 302 */           SOAPMessage sOAPMessage = Util.inputStream2SOAPMessage(inputStream, hashMap);
/* 303 */           sOAPMessageContext.setMessage(sOAPMessage);
/*     */         } 
/*     */ 
/*     */         
/* 307 */         Binding binding = (Binding)sOAPMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
/*     */         
/* 309 */         if (binding == null) {
/* 310 */           String str = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_ENDPOINT_PROP");
/* 311 */           if (str == null)
/* 312 */             throw new StoreForwardException("Could not find endpoint URL."); 
/* 313 */           SSLAdapter sSLAdapter = (SSLAdapter)sOAPMessageContext.getProperty("__BEA_PRIVATE_SSLADAPTER_PROP");
/*     */           
/* 315 */           binding = Util.createBinding(str, "http11", null, null, sSLAdapter);
/* 316 */           sOAPMessageContext.setProperty("__BEA_PRIVATE_BINDING_PROP", binding);
/*     */         } 
/*     */         
/* 319 */         addSOAPMessage(paramString1, sOAPMessageContext);
/*     */       } 
/*     */       
/* 322 */       QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(false, 2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 330 */       Message message = createMessage(queueSession, paramObject, paramString1, paramString2, paramString3, paramReliableDelivery);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 339 */       QueueSender queueSender = queueSession.createSender(this.destination);
/*     */ 
/*     */ 
/*     */       
/* 343 */       if (paramLong != -1L) {
/* 344 */         if (debug) Debug.say(" === store(): expiration time (1): " + paramLong); 
/* 345 */         queueSender.send(message, 2, 4, paramLong);
/*     */       } else {
/* 347 */         if (debug) {
/* 348 */           Debug.say(" === store(): expiration time (2): " + this.persistDuration);
/*     */         }
/* 350 */         queueSender.send(message, 2, 4, this.persistDuration);
/*     */       } 
/*     */       
/* 353 */       queueSession.close();
/*     */       
/* 355 */       if (debug) Debug.say(" === store(): Message stored: " + paramObject);
/*     */     
/* 357 */     } catch (JMSException jMSException) {
/* 358 */       if (debug) jMSException.printStackTrace(); 
/* 359 */       throw new StoreForwardException("Failed to store the message", jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String paramString) throws StoreForwardException {
/* 371 */     if (paramString == null) {
/*     */       return;
/*     */     }
/* 374 */     removeSOAPMessage(paramString);
/*     */ 
/*     */     
/*     */     try {
/* 378 */       Message message = getAndRemoveUnackedMsg(paramString);
/*     */       
/* 380 */       if (message != null) message.acknowledge();
/*     */       
/* 382 */       if (debug) Debug.say(" === remove(): messageId: " + paramString + " is removed");
/*     */       
/*     */     
/*     */     }
/* 386 */     catch (JMSException jMSException) {
/* 387 */       throw new StoreForwardException("Failed to remove the message from the store", jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int forward(String paramString) throws StoreForwardException {
/* 402 */     if (debug) Debug.say("forward(): This messageId = " + paramString);
/*     */ 
/*     */ 
/*     */     
/* 406 */     MessageContext messageContext = getSOAPMessage(paramString);
/*     */     
/* 408 */     Binding binding = (Binding)messageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
/*     */ 
/*     */     
/* 411 */     binding.getBindingInfo().setTimeout((int)this.retryInterval);
/*     */ 
/*     */     
/*     */     try {
/* 415 */       binding.send((WLMessageContext)messageContext);
/*     */ 
/*     */ 
/*     */       
/* 419 */       if (sinceStart < 5 && falseStartWorkAround) {
/* 420 */         sinceStart++;
/* 421 */         return -1;
/*     */       } 
/* 423 */     } catch (IOException iOException) {
/* 424 */       throw new StoreForwardException("Failed to send request:" + iOException, iOException);
/* 425 */     } catch (SOAPException sOAPException) {
/* 426 */       throw new StoreForwardException("Failed to send request:" + sOAPException, sOAPException);
/*     */     }
/* 428 */     catch (Exception exception) {
/* 429 */       throw new StoreForwardException("Failed to send request:" + exception, exception);
/*     */     } 
/* 431 */     if (debug) Debug.say("forward(): message " + paramString + " is sent"); 
/* 432 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 443 */   public void restoreMessage(String paramString, MessageContext paramMessageContext) { addSOAPMessage(paramString, paramMessageContext); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 454 */   void addUnackedMsg(String paramString, Message paramMessage) { this.unackedMessages.put(paramString, paramMessage); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 464 */   private Message getAndRemoveUnackedMsg(String paramString) { return (Message)this.unackedMessages.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessageId() {
/* 473 */     long l = System.currentTimeMillis();
/*     */     
/* 475 */     this.lastMessageId = Integer.toString(this.idSeed) + "." + Long.toString(l) + "." + Integer.toString(this.idCounter++);
/*     */ 
/*     */ 
/*     */     
/* 479 */     if (debug) {
/* 480 */       Debug.say(" === getMessageId(): messageId = " + this.lastMessageId);
/*     */     }
/* 482 */     return this.lastMessageId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 491 */     if (this.reader != null) this.reader.close();
/*     */ 
/*     */     
/* 494 */     if (this.connection != null) {
/*     */       try {
/* 496 */         this.connection.close();
/* 497 */       } catch (JMSException jMSException) {}
/* 498 */       this.connection = null;
/*     */     } 
/*     */ 
/*     */     
/* 502 */     this.unackedMessages.clear();
/* 503 */     this.soapMessages.clear();
/* 504 */     Iterator iterator = this.conversations.values().iterator();
/* 505 */     while (iterator.hasNext()) {
/* 506 */       ((ConversationAssembler)iterator.next()).close();
/*     */     }
/* 508 */     this.conversations.clear();
/*     */     
/* 510 */     this.started = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConversationAssembler createConversation(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt, long paramLong1, long paramLong2, ReliableDelivery paramReliableDelivery) {
/* 526 */     ConversationAssembler conversationAssembler = new ConversationAssembler(paramString, paramBoolean1, paramBoolean2, paramInt, paramLong1, paramLong2, paramReliableDelivery);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 532 */     this.conversations.put(paramString, conversationAssembler);
/* 533 */     return conversationAssembler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 542 */   public Conversation getConversation(String paramString) { return (ConversationAssembler)this.conversations.get(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 551 */   public void removeConversation(String paramString) throws StoreForwardException { this.conversations.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 563 */   public void addSOAPMessage(String paramString, MessageContext paramMessageContext) { this.soapMessages.put(paramString, paramMessageContext); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 572 */   public void removeSOAPMessage(String paramString) throws StoreForwardException { this.soapMessages.remove(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 581 */   public MessageContext getSOAPMessage(String paramString) { return (MessageContext)this.soapMessages.get(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 585 */   int getDefaultRetryNumber() { return this.retryNumber; }
/*     */ 
/*     */ 
/*     */   
/* 589 */   long getDefaultRetryInterval() { return this.retryInterval; }
/*     */ 
/*     */ 
/*     */   
/* 593 */   long getDefaultPersistDuration() { return this.persistDuration; }
/*     */ 
/*     */   
/*     */   private void setupId() {
/* 597 */     this.idCounter = 0;
/*     */ 
/*     */     
/* 600 */     SecureRandom secureRandom = new SecureRandom();
/*     */ 
/*     */     
/* 603 */     secureRandom.setSeed(Runtime.getRuntime().freeMemory());
/* 604 */     secureRandom.setSeed(System.currentTimeMillis());
/* 605 */     secureRandom.setSeed(Runtime.getRuntime().totalMemory());
/* 606 */     secureRandom.setSeed(System.currentTimeMillis());
/*     */ 
/*     */     
/* 609 */     byte[] arrayOfByte = new byte[4];
/* 610 */     secureRandom.nextBytes(arrayOfByte);
/*     */     
/* 612 */     for (byte b = 0; b < 4; b++) {
/* 613 */       this.idSeed = this.idSeed << 4 | arrayOfByte[b] & 0xFF;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Message createMessage(Session paramSession, Object paramObject, String paramString1, String paramString2, String paramString3, ReliableDelivery paramReliableDelivery) throws StoreForwardException {
/* 631 */     if (debug) Debug.say(" == createMessage(): request = " + paramObject);
/*     */     
/* 633 */     if (!(paramObject instanceof SOAPMessageContext)) {
/* 634 */       throw new StoreForwardException("Invalid message");
/*     */     }
/* 636 */     SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramObject;
/*     */     
/* 638 */     Binding binding = (Binding)sOAPMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
/*     */ 
/*     */     
/* 641 */     BindingInfo bindingInfo = ((AbstractBinding)binding).getBindingInfo();
/*     */     
/* 643 */     Debug.assertion((bindingInfo != null), "binding info is null for " + binding);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 650 */       ConversationContext conversationContext = (ConversationContext)sOAPMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 655 */       String str = "FinishHeader";
/* 656 */       if (conversationContext != null) {
/* 657 */         str = conversationContext.getHeaderType();
/*     */       }
/*     */ 
/*     */       
/* 661 */       byte[] arrayOfByte = Util.soapMessage2Bytes(sOAPMessageContext);
/*     */       
/* 663 */       BytesMessage bytesMessage = paramSession.createBytesMessage();
/* 664 */       bytesMessage.writeBytes(arrayOfByte);
/*     */ 
/*     */       
/* 667 */       bytesMessage.setStringProperty("WSSAFID", paramString1 + ":" + paramString3 + ":" + paramString2 + ":" + str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 674 */       bytesMessage.setIntProperty("WSSAFEnvelopeSize", arrayOfByte.length);
/*     */ 
/*     */       
/* 677 */       if (debug) {
/* 678 */         Debug.say(" === createMessage(): Address = " + bindingInfo.getAddress());
/*     */       }
/*     */ 
/*     */       
/* 682 */       bytesMessage.setStringProperty("WSSAFBindingAddress", bindingInfo.getAddress());
/*     */       
/* 684 */       bytesMessage.setStringProperty("WSSAFBindingTransport", bindingInfo.getTransport());
/*     */       
/* 686 */       bytesMessage.setStringProperty("WSSAFBindingType", bindingInfo.getType());
/* 687 */       bytesMessage.setStringProperty("WSSAFBindingCharset", bindingInfo.getCharset());
/* 688 */       if (bindingInfo.isSoap12()) {
/* 689 */         bytesMessage.setStringProperty("WSSAFBindingIsSoap12", "true");
/*     */       } else {
/* 691 */         bytesMessage.setStringProperty("WSSAFBindingIsSoap12", "false");
/*     */       } 
/*     */       
/* 694 */       if (bindingInfo instanceof weblogic.webservice.binding.jms.JMSBindingInfo) {
/*     */ 
/*     */         
/* 697 */         bytesMessage.setStringProperty("WSSAFBindingInfoType", "jms");
/*     */       } else {
/* 699 */         bytesMessage.setStringProperty("WSSAFBindingInfoType", "normal");
/*     */       } 
/*     */       
/* 702 */       SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/*     */       
/* 704 */       if (sOAPMessage instanceof WLSOAPMessage) {
/* 705 */         bytesMessage.setStringProperty("WSSAFSOAPMsgContentType", ((WLSOAPMessage)sOAPMessage).getContentType());
/*     */ 
/*     */ 
/*     */         
/* 709 */         if (debug) {
/* 710 */           Debug.say(" == createMessage(): ContentType = " + ((WLSOAPMessage)sOAPMessage).getContentType());
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 716 */       MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
/* 717 */       if (mimeHeaders != null) {
/*     */         
/* 719 */         Iterator iterator = mimeHeaders.getAllHeaders();
/* 720 */         while (iterator.hasNext()) {
/*     */           
/* 722 */           MimeHeader mimeHeader = (MimeHeader)iterator.next();
/*     */           
/* 724 */           if (debug) {
/* 725 */             Debug.say(" == createMessage(): mime header = " + mimeHeader.getName() + " value = " + mimeHeader.getValue());
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 732 */           if (!mimeHeader.getName().equals("Content-Type") && mimeHeader.getValue() != null)
/*     */           {
/* 734 */             bytesMessage.setStringProperty("WSSAFMimeHeader" + mimeHeader.getName(), mimeHeader.getValue());
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 741 */       if (paramReliableDelivery instanceof java.io.Serializable) {
/*     */         
/*     */         try {
/* 744 */           ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 745 */           ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
/*     */ 
/*     */           
/* 748 */           objectOutputStream.writeObject(paramReliableDelivery);
/*     */ 
/*     */ 
/*     */           
/* 752 */           byte[] arrayOfByte1 = byteArrayOutputStream.toByteArray();
/* 753 */           bytesMessage.writeBytes(arrayOfByte1);
/*     */           
/* 755 */           bytesMessage.setIntProperty("WSSAFListenerSize", arrayOfByte1.length);
/* 756 */         } catch (IOException iOException) {
/* 757 */           throw new StoreForwardException("Failed to store ReliableDelivery listener.", iOException);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 762 */       if (debug) {
/* 763 */         Debug.say(" == createMessage(): successfully created message");
/*     */       }
/*     */       
/* 766 */       return bytesMessage;
/* 767 */     } catch (JMSException jMSException) {
/* 768 */       if (debug) jMSException.printStackTrace(); 
/* 769 */       throw new StoreForwardException("Failed to create message", jMSException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void conversationStart(String paramString) throws StoreForwardException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void conversationEnd(String paramString) throws StoreForwardException {
/* 786 */     Conversation conversation = getConversation(paramString);
/* 787 */     if (conversation != null) conversation.setSeenLastMsg(true); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\WSSAFAgent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */