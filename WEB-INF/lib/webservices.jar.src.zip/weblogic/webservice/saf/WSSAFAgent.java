package weblogic.webservice.saf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Iterator;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;
import weblogic.time.common.TimeTriggerException;
import weblogic.utils.Debug;
import weblogic.webservice.ReliableDelivery;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.WLSOAPMessage;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.binding.AbstractBinding;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.client.SSLAdapter;
import weblogic.webservice.conversation.ConversationListener;
import weblogic.webservice.conversation.ConversationManager;
import weblogic.webservice.conversation.ConversationManagerFactory;
import weblogic.webservice.core.handler.ConversationContext;

public class WSSAFAgent implements SAFAgent, ConversationListener {
  public static final String STORE_AND_FORWARD_QUEUE_NAME = "jms.internal.queue.WSStoreForwardQueue";
  
  public static final String WSSAF_ID_PROP = "WSSAFID";
  
  public static final String ENVELOPE_SIZE_PROP = "WSSAFEnvelopeSize";
  
  public static final String LISTENER_SIZE_PROP = "WSSAFListenerSize";
  
  public static final String BINDING_ADDRESS_PROP = "WSSAFBindingAddress";
  
  public static final String BINDING_TYPE_PROP = "WSSAFBindingType";
  
  public static final String BINDING_CHARSET_PROP = "WSSAFBindingCharset";
  
  public static final String BINDING_TRANSPORT_PROP = "WSSAFBindingTransport";
  
  public static final String BINDING_SOAP12_PROP = "WSSAFBindingIsSoap12";
  
  public static final String BINDINGINFO_TYPE_PROP = "WSSAFBindingInfoType";
  
  public static final String SOAP_CONTENT_TYPE_PROP = "WSSAFSOAPMsgContentType";
  
  static final String MIMEHEADER_NAME_PREFIX = "WSSAFMimeHeader";
  
  private String name;
  
  private HashMap unackedMessages;
  
  private HashMap soapMessages;
  
  private HashMap conversations;
  
  private Context ctx;
  
  private Queue destination;
  
  private Connection connection;
  
  private ConnectionFactory cf;
  
  private int retryNumber;
  
  private long retryInterval;
  
  private long persistDuration;
  
  private static WSSAFAgent safAgent;
  
  private boolean started;
  
  private boolean repeatIt;
  
  private String lastMessageId;
  
  private static int sinceStart;
  
  private int idSeed;
  
  private int idCounter;
  
  private MessageReader reader;
  
  private static boolean debug = false;
  
  private static boolean falseStartWorkAround = true;
  
  WSSAFAgent() {
    this.unackedMessages = new HashMap();
    this.soapMessages = new HashMap();
    this.conversations = new HashMap();
    setupId();
  }
  
  static WSSAFAgent getSAFAgent() { return safAgent; }
  
  public static WSSAFAgent createAgent(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean) {
    debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
    falseStartWorkAround = !"true".equalsIgnoreCase(System.getProperty("weblogic.debug.CR096152"));
    if (safAgent != null)
      return safAgent; 
    sinceStart = 5;
    safAgent = new WSSAFAgent();
    safAgent.init(paramWSReliableDeliveryPolicyMBean);
    try {
      safAgent.start();
    } catch (Exception exception) {
      StartAgentRetryTimer startAgentRetryTimer = new StartAgentRetryTimer();
      try {
        startAgentRetryTimer.init(safAgent, 1000L);
      } catch (TimeTriggerException timeTriggerException) {}
    } 
    return safAgent;
  }
  
  boolean isStarted() { return this.started; }
  
  public String getName() { return this.name; }
  
  public void init(WSReliableDeliveryPolicyMBean paramWSReliableDeliveryPolicyMBean) {
    this.name = paramWSReliableDeliveryPolicyMBean.getName() + "SAFAgent";
    this.retryNumber = paramWSReliableDeliveryPolicyMBean.getDefaultRetryCount();
    this.retryInterval = (paramWSReliableDeliveryPolicyMBean.getDefaultRetryInterval() * 1000);
    this.persistDuration = (paramWSReliableDeliveryPolicyMBean.getDefaultTimeToLive() * 1000);
    if (debug)
      Debug.say(" == init(): retryInternal = " + this.retryInterval + " persistDuration = " + this.persistDuration); 
  }
  
  void start() {
    if (this.started)
      return; 
    this.ctx = Util.getInitialContext();
    this.cf = Util.getConnectionFactory();
    this.destination = (Queue)this.ctx.lookup("jms.internal.queue.WSStoreForwardQueue");
    this.connection = ((QueueConnectionFactory)this.cf).createQueueConnection();
    this.connection.start();
    this.reader = new MessageReader(this, this.cf, this.destination);
    try {
      this.reader.start();
    } catch (JMSException jMSException) {
      try {
        this.connection.close();
      } catch (JMSException jMSException1) {}
      throw jMSException;
    } 
    ConversationManager conversationManager = ConversationManagerFactory.getManager();
    conversationManager.registerConversationListener(this);
    this.started = true;
  }
  
  public void waitForStart() {
    boolean bool = false;
    while (!bool) {
      try {
        start();
        bool = true;
      } catch (NamingException namingException) {
        if (debug)
          Debug.say(" waitForStart(): got exception: " + namingException); 
      } catch (JMSException jMSException) {
        WebServiceLogger.logFailedAccessStore(jMSException);
        if (debug)
          Debug.say(" waitForStart(): got exception: " + jMSException); 
        throw new StoreForwardException("Failed to access the store", jMSException);
      } 
      if (!bool)
        try {
          Thread.sleep(500L);
        } catch (InterruptedException interruptedException) {} 
    } 
  }
  
  public void resetSinceStart() { sinceStart = 0; }
  
  public void store(String paramString1, String paramString2, String paramString3, Object paramObject, ReliableDelivery paramReliableDelivery, long paramLong) throws StoreForwardException {
    if (debug)
      Debug.say(" == store(): waiting for the agent to start"); 
    waitForStart();
    if (debug)
      Debug.say(" == store(): agent is started"); 
    try {
      if (paramObject instanceof SOAPMessageContext) {
        SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramObject;
        InputStream inputStream = (InputStream)sOAPMessageContext.getProperty("__BEA_PRIVATE_SOAP_MESSAGE_PROP");
        if (inputStream != null) {
          HashMap hashMap = (HashMap)sOAPMessageContext.getProperty("__BEA_PRIVATE_MIME_HEADERS_PROP");
          SOAPMessage sOAPMessage = Util.inputStream2SOAPMessage(inputStream, hashMap);
          sOAPMessageContext.setMessage(sOAPMessage);
        } 
        Binding binding = (Binding)sOAPMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
        if (binding == null) {
          String str = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_ENDPOINT_PROP");
          if (str == null)
            throw new StoreForwardException("Could not find endpoint URL."); 
          SSLAdapter sSLAdapter = (SSLAdapter)sOAPMessageContext.getProperty("__BEA_PRIVATE_SSLADAPTER_PROP");
          binding = Util.createBinding(str, "http11", null, null, sSLAdapter);
          sOAPMessageContext.setProperty("__BEA_PRIVATE_BINDING_PROP", binding);
        } 
        addSOAPMessage(paramString1, sOAPMessageContext);
      } 
      QueueSession queueSession = ((QueueConnection)this.connection).createQueueSession(false, 2);
      Message message = createMessage(queueSession, paramObject, paramString1, paramString2, paramString3, paramReliableDelivery);
      QueueSender queueSender = queueSession.createSender(this.destination);
      if (paramLong != -1L) {
        if (debug)
          Debug.say(" === store(): expiration time (1): " + paramLong); 
        queueSender.send(message, 2, 4, paramLong);
      } else {
        if (debug)
          Debug.say(" === store(): expiration time (2): " + this.persistDuration); 
        queueSender.send(message, 2, 4, this.persistDuration);
      } 
      queueSession.close();
      if (debug)
        Debug.say(" === store(): Message stored: " + paramObject); 
    } catch (JMSException jMSException) {
      if (debug)
        jMSException.printStackTrace(); 
      throw new StoreForwardException("Failed to store the message", jMSException);
    } 
  }
  
  public void remove(String paramString) throws StoreForwardException {
    if (paramString == null)
      return; 
    removeSOAPMessage(paramString);
    try {
      Message message = getAndRemoveUnackedMsg(paramString);
      if (message != null)
        message.acknowledge(); 
      if (debug)
        Debug.say(" === remove(): messageId: " + paramString + " is removed"); 
    } catch (JMSException jMSException) {
      throw new StoreForwardException("Failed to remove the message from the store", jMSException);
    } 
  }
  
  public int forward(String paramString) throws StoreForwardException {
    if (debug)
      Debug.say("forward(): This messageId = " + paramString); 
    MessageContext messageContext = getSOAPMessage(paramString);
    Binding binding = (Binding)messageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
    binding.getBindingInfo().setTimeout((int)this.retryInterval);
    try {
      binding.send((WLMessageContext)messageContext);
      if (sinceStart < 5 && falseStartWorkAround) {
        sinceStart++;
        return -1;
      } 
    } catch (IOException iOException) {
      throw new StoreForwardException("Failed to send request:" + iOException, iOException);
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to send request:" + sOAPException, sOAPException);
    } catch (Exception exception) {
      throw new StoreForwardException("Failed to send request:" + exception, exception);
    } 
    if (debug)
      Debug.say("forward(): message " + paramString + " is sent"); 
    return 0;
  }
  
  public void restoreMessage(String paramString, MessageContext paramMessageContext) { addSOAPMessage(paramString, paramMessageContext); }
  
  void addUnackedMsg(String paramString, Message paramMessage) { this.unackedMessages.put(paramString, paramMessage); }
  
  private Message getAndRemoveUnackedMsg(String paramString) { return (Message)this.unackedMessages.remove(paramString); }
  
  public String getMessageId() {
    long l = System.currentTimeMillis();
    this.lastMessageId = Integer.toString(this.idSeed) + "." + Long.toString(l) + "." + Integer.toString(this.idCounter++);
    if (debug)
      Debug.say(" === getMessageId(): messageId = " + this.lastMessageId); 
    return this.lastMessageId;
  }
  
  public void close() {
    if (this.reader != null)
      this.reader.close(); 
    if (this.connection != null) {
      try {
        this.connection.close();
      } catch (JMSException jMSException) {}
      this.connection = null;
    } 
    this.unackedMessages.clear();
    this.soapMessages.clear();
    Iterator iterator = this.conversations.values().iterator();
    while (iterator.hasNext())
      ((ConversationAssembler)iterator.next()).close(); 
    this.conversations.clear();
    this.started = false;
  }
  
  public ConversationAssembler createConversation(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt, long paramLong1, long paramLong2, ReliableDelivery paramReliableDelivery) {
    ConversationAssembler conversationAssembler = new ConversationAssembler(paramString, paramBoolean1, paramBoolean2, paramInt, paramLong1, paramLong2, paramReliableDelivery);
    this.conversations.put(paramString, conversationAssembler);
    return conversationAssembler;
  }
  
  public Conversation getConversation(String paramString) { return (ConversationAssembler)this.conversations.get(paramString); }
  
  public void removeConversation(String paramString) throws StoreForwardException { this.conversations.remove(paramString); }
  
  public void addSOAPMessage(String paramString, MessageContext paramMessageContext) { this.soapMessages.put(paramString, paramMessageContext); }
  
  public void removeSOAPMessage(String paramString) throws StoreForwardException { this.soapMessages.remove(paramString); }
  
  public MessageContext getSOAPMessage(String paramString) { return (MessageContext)this.soapMessages.get(paramString); }
  
  int getDefaultRetryNumber() { return this.retryNumber; }
  
  long getDefaultRetryInterval() { return this.retryInterval; }
  
  long getDefaultPersistDuration() { return this.persistDuration; }
  
  private void setupId() {
    this.idCounter = 0;
    SecureRandom secureRandom = new SecureRandom();
    secureRandom.setSeed(Runtime.getRuntime().freeMemory());
    secureRandom.setSeed(System.currentTimeMillis());
    secureRandom.setSeed(Runtime.getRuntime().totalMemory());
    secureRandom.setSeed(System.currentTimeMillis());
    byte[] arrayOfByte = new byte[4];
    secureRandom.nextBytes(arrayOfByte);
    for (byte b = 0; b < 4; b++)
      this.idSeed = this.idSeed << 4 | arrayOfByte[b] & 0xFF; 
  }
  
  private Message createMessage(Session paramSession, Object paramObject, String paramString1, String paramString2, String paramString3, ReliableDelivery paramReliableDelivery) throws StoreForwardException {
    if (debug)
      Debug.say(" == createMessage(): request = " + paramObject); 
    if (!(paramObject instanceof SOAPMessageContext))
      throw new StoreForwardException("Invalid message"); 
    SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramObject;
    Binding binding = (Binding)sOAPMessageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
    BindingInfo bindingInfo = ((AbstractBinding)binding).getBindingInfo();
    Debug.assertion((bindingInfo != null), "binding info is null for " + binding);
    try {
      ConversationContext conversationContext = (ConversationContext)sOAPMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
      String str = "FinishHeader";
      if (conversationContext != null)
        str = conversationContext.getHeaderType(); 
      byte[] arrayOfByte = Util.soapMessage2Bytes(sOAPMessageContext);
      BytesMessage bytesMessage = paramSession.createBytesMessage();
      bytesMessage.writeBytes(arrayOfByte);
      bytesMessage.setStringProperty("WSSAFID", paramString1 + ":" + paramString3 + ":" + paramString2 + ":" + str);
      bytesMessage.setIntProperty("WSSAFEnvelopeSize", arrayOfByte.length);
      if (debug)
        Debug.say(" === createMessage(): Address = " + bindingInfo.getAddress()); 
      bytesMessage.setStringProperty("WSSAFBindingAddress", bindingInfo.getAddress());
      bytesMessage.setStringProperty("WSSAFBindingTransport", bindingInfo.getTransport());
      bytesMessage.setStringProperty("WSSAFBindingType", bindingInfo.getType());
      bytesMessage.setStringProperty("WSSAFBindingCharset", bindingInfo.getCharset());
      if (bindingInfo.isSoap12()) {
        bytesMessage.setStringProperty("WSSAFBindingIsSoap12", "true");
      } else {
        bytesMessage.setStringProperty("WSSAFBindingIsSoap12", "false");
      } 
      if (bindingInfo instanceof weblogic.webservice.binding.jms.JMSBindingInfo) {
        bytesMessage.setStringProperty("WSSAFBindingInfoType", "jms");
      } else {
        bytesMessage.setStringProperty("WSSAFBindingInfoType", "normal");
      } 
      SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
      if (sOAPMessage instanceof WLSOAPMessage) {
        bytesMessage.setStringProperty("WSSAFSOAPMsgContentType", ((WLSOAPMessage)sOAPMessage).getContentType());
        if (debug)
          Debug.say(" == createMessage(): ContentType = " + ((WLSOAPMessage)sOAPMessage).getContentType()); 
      } 
      MimeHeaders mimeHeaders = sOAPMessage.getMimeHeaders();
      if (mimeHeaders != null) {
        Iterator iterator = mimeHeaders.getAllHeaders();
        while (iterator.hasNext()) {
          MimeHeader mimeHeader = (MimeHeader)iterator.next();
          if (debug)
            Debug.say(" == createMessage(): mime header = " + mimeHeader.getName() + " value = " + mimeHeader.getValue()); 
          if (!mimeHeader.getName().equals("Content-Type") && mimeHeader.getValue() != null)
            bytesMessage.setStringProperty("WSSAFMimeHeader" + mimeHeader.getName(), mimeHeader.getValue()); 
        } 
      } 
      if (paramReliableDelivery instanceof java.io.Serializable)
        try {
          ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
          ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
          objectOutputStream.writeObject(paramReliableDelivery);
          byte[] arrayOfByte1 = byteArrayOutputStream.toByteArray();
          bytesMessage.writeBytes(arrayOfByte1);
          bytesMessage.setIntProperty("WSSAFListenerSize", arrayOfByte1.length);
        } catch (IOException iOException) {
          throw new StoreForwardException("Failed to store ReliableDelivery listener.", iOException);
        }  
      if (debug)
        Debug.say(" == createMessage(): successfully created message"); 
      return bytesMessage;
    } catch (JMSException jMSException) {
      if (debug)
        jMSException.printStackTrace(); 
      throw new StoreForwardException("Failed to create message", jMSException);
    } 
  }
  
  public void conversationStart(String paramString) throws StoreForwardException {}
  
  public void conversationEnd(String paramString) throws StoreForwardException {
    Conversation conversation = getConversation(paramString);
    if (conversation != null)
      conversation.setSeenLastMsg(true); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\WSSAFAgent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */