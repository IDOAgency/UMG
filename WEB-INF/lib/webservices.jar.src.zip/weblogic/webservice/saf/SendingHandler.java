package weblogic.webservice.saf;

import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import weblogic.utils.Debug;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.ReliableDelivery;

public final class SendingHandler extends GenericHandler implements ReliableMessagingConstants {
  private SAFAgent saf;
  
  private static boolean debug = false;
  
  public void init(HandlerInfo paramHandlerInfo) {
    super.init(paramHandlerInfo);
    debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || "true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.debug")) || debug);
    this.saf = WSSAFAgent.getSAFAgent();
  }
  
  public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
    if (debug)
      Debug.say("** handleRequest called"); 
    String str1 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_MSG_ID");
    String str2 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_CONV_ID");
    String str3 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_SEQ_NUM");
    Long long = (Long)paramMessageContext.getProperty("__BEA_INTERNAL_PERSIST_DUR");
    long l = long.longValue();
    ReliableDelivery reliableDelivery = (ReliableDelivery)paramMessageContext.getProperty("__BEA_PRIVATE_RELIABLE_PROP");
    try {
      this.saf.store(str1, str2, str3, paramMessageContext, reliableDelivery, l);
      if (debug)
        Debug.say("*** Sucessfully stored the message:  messageId = " + str1 + "***"); 
      return false;
    } catch (StoreForwardException storeForwardException) {
      throw new JAXRPCException("Failed to store the message", storeForwardException);
    } 
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
    if (debug)
      Debug.say("** handleResponse called"); 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\SendingHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */