/*    */ package weblogic.webservice.saf;
/*    */ 
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.handler.HandlerInfo;
/*    */ import javax.xml.rpc.handler.MessageContext;
/*    */ import weblogic.utils.Debug;
/*    */ import weblogic.webservice.GenericHandler;
/*    */ import weblogic.webservice.ReliableDelivery;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SendingHandler
/*    */   extends GenericHandler
/*    */   implements ReliableMessagingConstants
/*    */ {
/*    */   private SAFAgent saf;
/*    */   private static boolean debug = false;
/*    */   
/*    */   public void init(HandlerInfo paramHandlerInfo) {
/* 42 */     super.init(paramHandlerInfo);
/*    */     
/* 44 */     debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || "true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.debug")) || debug);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 51 */     this.saf = WSSAFAgent.getSAFAgent();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
/* 58 */     if (debug) Debug.say("** handleRequest called");
/*    */ 
/*    */ 
/*    */     
/* 62 */     String str1 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_MSG_ID");
/* 63 */     String str2 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_CONV_ID");
/* 64 */     String str3 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_SEQ_NUM");
/* 65 */     Long long = (Long)paramMessageContext.getProperty("__BEA_INTERNAL_PERSIST_DUR");
/* 66 */     long l = long.longValue();
/*    */     
/* 68 */     ReliableDelivery reliableDelivery = (ReliableDelivery)paramMessageContext.getProperty("__BEA_PRIVATE_RELIABLE_PROP");
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 73 */       this.saf.store(str1, str2, str3, paramMessageContext, reliableDelivery, l);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 81 */       if (debug) {
/* 82 */         Debug.say("*** Sucessfully stored the message:  messageId = " + str1 + "***");
/*    */       }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 89 */       return false;
/*    */     }
/* 91 */     catch (StoreForwardException storeForwardException) {
/* 92 */       throw new JAXRPCException("Failed to store the message", storeForwardException);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
/* 98 */     if (debug) Debug.say("** handleResponse called"); 
/* 99 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\SendingHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */