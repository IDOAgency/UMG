/*    */ package weblogic.webservice.saf;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import weblogic.xml.stream.ElementFactory;
/*    */ import weblogic.xml.stream.XMLName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ReliableMessagingConstants
/*    */ {
/*    */   public static final String WSMD_NS_PFX = "wsmd";
/*    */   public static final String WSR_NS_PFX = "wsr";
/*    */   public static final String WSMD_NS_URL = "http://openuri.org/2002/soap/messagedata/";
/*    */   public static final String WSR_NS_URL = "http://www.openuri.org/2002/10/soap/reliability/";
/*    */   public static final String WSMD_VERSION = "1.0";
/*    */   public static final String WSR_VERSION = "1.0";
/*    */   public static final String MSG_DATA_HEADER = "MessageData";
/*    */   public static final String ACK_HEADER = "Acknowledgement";
/*    */   public static final String ACK_REQ_HEADER = "AckRequested";
/*    */   public static final String MSG_ORDER_HEADER = "MessageOrder";
/*    */   public static final String MSG_ID_ELEMENT = "MessageID";
/*    */   public static final String REF_TO_MSG_ID_ELEMENT = "RefToMessageID";
/*    */   public static final String SEQ_NUMBER_ELEMENT = "SequenceNumber";
/*    */   public static final String STATUS_ATTRIBUTE = "Status";
/*    */   public static final String VERSION_ATTRIBUTE = "Version";
/* 39 */   public static final XMLName MSG_DATA_NAME = ElementFactory.createXMLName("MessageData");
/*    */   
/* 41 */   public static final XMLName ACK_NAME = ElementFactory.createXMLName("Acknowledgement");
/*    */   
/* 43 */   public static final XMLName ACK_REQ_NAME = ElementFactory.createXMLName("AckRequested");
/*    */   
/* 45 */   public static final XMLName MSG_ORDER_NAME = ElementFactory.createXMLName("MessageOrder");
/*    */   
/* 47 */   public static final XMLName MSG_ID_NAME = ElementFactory.createXMLName("MessageID");
/*    */   
/* 49 */   public static final XMLName SEQ_NUMBER_NAME = ElementFactory.createXMLName("SequenceNumber");
/*    */   
/* 51 */   public static final XMLName VERSION_NAME = ElementFactory.createXMLName("Version");
/*    */ 
/*    */ 
/*    */   
/* 55 */   public static final QName OUT_OF_ORDER_FAULT = new QName("http://www.openuri.org/2002/10/soap/reliability/", "MessageOutOfOrder");
/*    */   public static final String OUT_OF_ORDER_MESSAGE = "Message is out of order";
/*    */   public static final String DF_EXPIRED_CODE = "DF_EXPIRED_CODE";
/*    */   public static final String DF_PROTOCOL_CODE = "DF_PROTOCOL_CODE";
/*    */   public static final String DF_UNKNOWN_CODE = "DF_UNKNOWN_CODE";
/*    */   public static final String MESSAGE_ID_PROP = "__BEA_INTERNAL_MSG_ID";
/*    */   public static final String SEQ_NUM_PROP = "__BEA_INTERNAL_SEQ_NUM";
/*    */   public static final String CONVERSATION_ID_PROP = "__BEA_INTERNAL_CONV_ID";
/*    */   public static final String PERSIST_DURATION_PROP = "__BEA_INTERNAL_PERSIST_DUR";
/*    */   public static final String SOAP_ENV_PREFIX_PROP = "__BEA_INTERNAL_SOAP_ENV_PREFIX";
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\ReliableMessagingConstants.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */