package weblogic.webservice.saf;

import java.util.HashSet;
import java.util.Iterator;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import weblogic.utils.Debug;
import weblogic.work.ContextWrap;
import weblogic.work.WorkAdapter;
import weblogic.work.WorkManagerFactory;

final class ConversationReassembler extends Conversation {
  private int expectedId;
  
  private WSDupsEliminationAgent dupsEliminationAgent;
  
  protected HashSet messages;
  
  ConversationReassembler(String paramString, boolean paramBoolean) {
    super(paramString, paramBoolean);
    this.messages = new HashSet();
    this.dupsEliminationAgent = WSDupsEliminationAgent.getDupsEliminationAgent();
    this.persistDuration = this.dupsEliminationAgent.getDefaultPersistDuration();
    this.expectedId = 0;
  }
  
  void addMessage(String paramString, int paramInt, Object paramObject) {
    this.messages.add(paramString);
    MessageReference messageReference = null;
    if (paramObject instanceof MessageContext)
      messageReference = new MessageReference(paramString, paramInt, (MessageContext)paramObject, this.persistDuration); 
    if (messageReference == null)
      return; 
    synchronized (this) {
      addMessageToListInorder(messageReference);
    } 
  }
  
  void removeMessage(MessageReference paramMessageReference) { removeMessageFromList(paramMessageReference); }
  
  HashSet getMessages() { return this.messages; }
  
  final void close() {
    synchronized (this) {
      if (this.running)
        this.running = false; 
      this.firstMessage = this.lastMessage = null;
    } 
  }
  
  final int getExpectedSequenceNumber() { return this.expectedId; }
  
  final void updateExpectedSequenceNumber(int paramInt) { this.expectedId = paramInt; }
  
  void run() {
    synchronized (this) {
      if (this.running)
        return; 
      this.running = true;
    } 
    ContextWrap contextWrap = new ContextWrap(new WorkRequest(this));
    WorkManagerFactory.getInstance().getSystem().schedule(contextWrap);
  }
  
  final class WorkRequest extends WorkAdapter {
    private final ConversationReassembler this$0;
    
    public final void run() {
      synchronized (this) {
        int i = ConversationReassembler.this.expectedId;
        while (ConversationReassembler.this.firstMessage != null && ConversationReassembler.this.firstMessage.getSequenceNumber() == i++) {
          if (Conversation.debug)
            Debug.say("== execute(): running = " + ConversationReassembler.this.running + " nextMessage = " + ((ConversationReassembler.this.firstMessage.getNext() != null) ? ConversationReassembler.this.firstMessage.getNext().getMessageId() : null)); 
          if (ConversationReassembler.this.firstMessage.isExpired()) {
            if (Conversation.debug)
              Debug.say("== execute() firstMessage (" + ConversationReassembler.this.firstMessage.getMessageId() + ") is expired"); 
            try {
              ConversationReassembler.this.dupsEliminationAgent.removeHistoryRecord(ConversationReassembler.this.firstMessage.getMessageId());
            } catch (StoreForwardException storeForwardException) {}
            ConversationReassembler.this.removeMessage(ConversationReassembler.this.firstMessage);
          } 
          MessageContext messageContext = null;
          try {
            messageContext = (MessageContext)ConversationReassembler.this.dupsEliminationAgent.process(ConversationReassembler.this.firstMessage.getMessageId());
          } catch (Exception exception) {
            if (Conversation.debug)
              exception.printStackTrace(); 
            break;
          } 
          ConversationReassembler.this.handleResponse(messageContext);
          ConversationReassembler.this.removeMessage(ConversationReassembler.this.firstMessage);
        } 
        ConversationReassembler.this.running = false;
        if (ConversationReassembler.this.isDone()) {
          try {
            ConversationReassembler.this.dupsEliminationAgent.removeHistoryRecordForConversation(ConversationReassembler.this.id);
          } catch (StoreForwardException storeForwardException) {}
          return;
        } 
        if (Conversation.debug)
          Debug.say("== execute(): update expected to " + (i - 1)); 
        ConversationReassembler.this.updateExpectedSequenceNumber(i - 1);
      } 
    }
  }
  
  private boolean handleResponse(MessageContext paramMessageContext) {
    SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    if (debug)
      Debug.say("** handleResponse called"); 
    try {
      SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
      SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
      SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
      if (sOAPHeader == null)
        sOAPEnvelope.addHeader(); 
      String str = null;
      Iterator iterator = sOAPHeader.getChildElements(sOAPEnvelope.createName("AckRequested"));
      if (iterator != null && iterator.hasNext()) {
        SOAPElement sOAPElement = (SOAPElement)iterator.next();
        str = sOAPElement.getAttributeValue(sOAPEnvelope.createName("id"));
        sOAPElement.detachNode();
      } 
      SOAPHeaderElement sOAPHeaderElement = sOAPHeader.addHeaderElement(sOAPEnvelope.createName("Acknowledgement"));
      if (str != null) {
        sOAPHeaderElement.addAttribute(sOAPEnvelope.createName("id"), str);
        if (debug)
          Debug.say("Added messageId '" + str + "' to Acknowledgement header"); 
      } 
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException(sOAPException);
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\ConversationReassembler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */