/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeader;
/*     */ import javax.xml.soap.SOAPHeaderElement;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.work.ContextWrap;
/*     */ import weblogic.work.WorkAdapter;
/*     */ import weblogic.work.WorkManagerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ConversationReassembler
/*     */   extends Conversation
/*     */ {
/*     */   private int expectedId;
/*     */   private WSDupsEliminationAgent dupsEliminationAgent;
/*     */   protected HashSet messages;
/*     */   
/*     */   ConversationReassembler(String paramString, boolean paramBoolean) {
/*  61 */     super(paramString, paramBoolean);
/*     */     
/*  63 */     this.messages = new HashSet();
/*  64 */     this.dupsEliminationAgent = WSDupsEliminationAgent.getDupsEliminationAgent();
/*  65 */     this.persistDuration = this.dupsEliminationAgent.getDefaultPersistDuration();
/*  66 */     this.expectedId = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addMessage(String paramString, int paramInt, Object paramObject) {
/*  84 */     this.messages.add(paramString);
/*     */     
/*  86 */     MessageReference messageReference = null;
/*  87 */     if (paramObject instanceof MessageContext) {
/*  88 */       messageReference = new MessageReference(paramString, paramInt, (MessageContext)paramObject, this.persistDuration);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     if (messageReference == null)
/*     */       return; 
/*  98 */     synchronized (this) {
/*  99 */       addMessageToListInorder(messageReference);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   void removeMessage(MessageReference paramMessageReference) { removeMessageFromList(paramMessageReference); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   HashSet getMessages() { return this.messages; }
/*     */ 
/*     */ 
/*     */   
/*     */   final void close() {
/* 124 */     synchronized (this) {
/* 125 */       if (this.running) this.running = false; 
/* 126 */       this.firstMessage = this.lastMessage = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   final int getExpectedSequenceNumber() { return this.expectedId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   final void updateExpectedSequenceNumber(int paramInt) { this.expectedId = paramInt; }
/*     */ 
/*     */ 
/*     */   
/*     */   void run() {
/* 145 */     synchronized (this) {
/* 146 */       if (this.running)
/* 147 */         return;  this.running = true;
/*     */     } 
/* 149 */     ContextWrap contextWrap = new ContextWrap(new WorkRequest(this));
/* 150 */     WorkManagerFactory.getInstance().getSystem().schedule(contextWrap);
/*     */   }
/*     */   
/*     */   final class WorkRequest extends WorkAdapter { private final ConversationReassembler this$0;
/*     */     
/*     */     public final void run() {
/* 156 */       synchronized (this) {
/*     */         
/* 158 */         int i = ConversationReassembler.this.expectedId;
/*     */ 
/*     */         
/* 161 */         while (ConversationReassembler.this.firstMessage != null && ConversationReassembler.this.firstMessage.getSequenceNumber() == i++) {
/*     */           
/* 163 */           if (Conversation.debug) {
/* 164 */             Debug.say("== execute(): running = " + ConversationReassembler.this.running + " nextMessage = " + ((ConversationReassembler.this.firstMessage.getNext() != null) ? ConversationReassembler.this.firstMessage.getNext().getMessageId() : null));
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 170 */           if (ConversationReassembler.this.firstMessage.isExpired()) {
/*     */             
/* 172 */             if (Conversation.debug) {
/* 173 */               Debug.say("== execute() firstMessage (" + ConversationReassembler.this.firstMessage.getMessageId() + ") is expired");
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 179 */               ConversationReassembler.this.dupsEliminationAgent.removeHistoryRecord(ConversationReassembler.this.firstMessage.getMessageId());
/*     */             
/*     */             }
/* 182 */             catch (StoreForwardException storeForwardException) {}
/*     */ 
/*     */ 
/*     */             
/* 186 */             ConversationReassembler.this.removeMessage(ConversationReassembler.this.firstMessage);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 194 */           MessageContext messageContext = null;
/*     */           
/*     */           try {
/* 197 */             messageContext = (MessageContext)ConversationReassembler.this.dupsEliminationAgent.process(ConversationReassembler.this.firstMessage.getMessageId());
/*     */           }
/* 199 */           catch (Exception exception) {
/*     */             
/* 201 */             if (Conversation.debug) {
/* 202 */               exception.printStackTrace();
/*     */             }
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */ 
/*     */           
/* 210 */           ConversationReassembler.this.handleResponse(messageContext);
/*     */ 
/*     */ 
/*     */           
/* 214 */           ConversationReassembler.this.removeMessage(ConversationReassembler.this.firstMessage);
/*     */         } 
/*     */         
/* 217 */         ConversationReassembler.this.running = false;
/*     */ 
/*     */         
/* 220 */         if (ConversationReassembler.this.isDone()) {
/*     */           
/*     */           try {
/* 223 */             ConversationReassembler.this.dupsEliminationAgent.removeHistoryRecordForConversation(ConversationReassembler.this.id);
/* 224 */           } catch (StoreForwardException storeForwardException) {}
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 230 */         if (Conversation.debug) {
/* 231 */           Debug.say("== execute(): update expected to " + (i - 1));
/*     */         }
/*     */         
/* 234 */         ConversationReassembler.this.updateExpectedSequenceNumber(i - 1);
/*     */       } 
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean handleResponse(MessageContext paramMessageContext) {
/* 242 */     SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     
/* 244 */     if (debug) Debug.say("** handleResponse called");
/*     */     
/*     */     try {
/* 247 */       SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/*     */       
/* 249 */       SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
/*     */       
/* 251 */       SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
/*     */       
/* 253 */       if (sOAPHeader == null) {
/* 254 */         sOAPEnvelope.addHeader();
/*     */       }
/*     */       
/* 257 */       String str = null;
/* 258 */       Iterator iterator = sOAPHeader.getChildElements(sOAPEnvelope.createName("AckRequested"));
/* 259 */       if (iterator != null && iterator.hasNext()) {
/* 260 */         SOAPElement sOAPElement = (SOAPElement)iterator.next();
/* 261 */         str = sOAPElement.getAttributeValue(sOAPEnvelope.createName("id"));
/* 262 */         sOAPElement.detachNode();
/*     */       } 
/*     */       
/* 265 */       SOAPHeaderElement sOAPHeaderElement = sOAPHeader.addHeaderElement(sOAPEnvelope.createName("Acknowledgement"));
/*     */       
/* 267 */       if (str != null) {
/* 268 */         sOAPHeaderElement.addAttribute(sOAPEnvelope.createName("id"), str);
/*     */         
/* 270 */         if (debug) Debug.say("Added messageId '" + str + "' to Acknowledgement header");
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 275 */     catch (SOAPException sOAPException) {
/* 276 */       throw new JAXRPCException(sOAPException);
/*     */     } 
/* 278 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\ConversationReassembler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */