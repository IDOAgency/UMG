package weblogic.webservice.saf;

interface DupsEliminationAgent extends WSAgent {
  boolean storeHistoryRecord(String paramString) throws StoreForwardException;
  
  boolean storeHistoryRecord(String paramString, long paramLong) throws StoreForwardException;
  
  void storeMessageOnly(String paramString, Object paramObject) throws StoreForwardException;
  
  void storeMessageOnly(String paramString, Object paramObject, long paramLong) throws StoreForwardException;
  
  void storeHistoryRecordAndMessage(String paramString, Object paramObject) throws StoreForwardException;
  
  void storeHistoryRecordAndMessage(String paramString, Object paramObject, long paramLong) throws StoreForwardException;
  
  Object process(String paramString) throws StoreForwardException;
  
  void removeHistoryRecord(String paramString) throws StoreForwardException;
  
  void removeHistoryRecordInMemoryOnly(String paramString) throws StoreForwardException;
  
  void removeMessageOnly(String paramString) throws StoreForwardException;
  
  void removeHistoryRecordAndMessage(String paramString) throws StoreForwardException;
  
  void removeHistoryRecordForConversation(String paramString) throws StoreForwardException;
  
  boolean isDuplicate(String paramString) throws StoreForwardException;
  
  ConversationReassembler createConversation(String paramString, boolean paramBoolean);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\DupsEliminationAgent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */