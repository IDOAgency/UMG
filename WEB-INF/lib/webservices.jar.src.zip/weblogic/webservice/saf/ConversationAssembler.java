package weblogic.webservice.saf;

import java.io.IOException;
import java.util.HashMap;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import weblogic.time.common.TimeTriggerException;
import weblogic.utils.Debug;
import weblogic.webservice.ReliableDelivery;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.async.ReliableDeliveryFailureEvent;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.core.ClientDispatcher;
import weblogic.webservice.util.FaultUtil;
import weblogic.work.WorkAdapter;
import weblogic.work.WorkManagerFactory;

final class ConversationAssembler extends Conversation implements ReliableMessagingConstants {
  private boolean individual;
  
  private int nextSequenceNumber;
  
  private RetryTrigger trigger;
  
  private int retryCount;
  
  private long retryInterval;
  
  private HashMap dispatchers;
  
  private ReliableDelivery listener;
  
  private WSSAFAgent safAgent;
  
  private boolean poisoned;
  
  ConversationAssembler(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt, long paramLong1, long paramLong2, ReliableDelivery paramReliableDelivery) {
    super(paramString, paramBoolean2);
    this.individual = paramBoolean1;
    this.dispatchers = new HashMap();
    this.listener = paramReliableDelivery;
    this.safAgent = WSSAFAgent.getSAFAgent();
    if (paramInt != -1) {
      this.retryCount = paramInt;
    } else {
      this.retryCount = this.safAgent.getDefaultRetryNumber();
    } 
    if (paramLong1 != -1L) {
      this.retryInterval = paramLong1;
    } else {
      this.retryInterval = this.safAgent.getDefaultRetryInterval();
    } 
    if (paramLong2 != -1L) {
      this.persistDuration = paramLong2;
    } else {
      this.persistDuration = this.safAgent.getDefaultPersistDuration();
    } 
    this.nextSequenceNumber = 0;
  }
  
  void addMessage(String paramString, int paramInt, Object paramObject) {
    MessageReference messageReference = null;
    if (paramObject instanceof MessageContext)
      messageReference = new MessageReference(paramString, paramInt, (MessageContext)paramObject, this.retryCount, this.retryInterval, this.persistDuration); 
    if (messageReference == null)
      return; 
    boolean bool = false;
    synchronized (this) {
      if (this.poisoned) {
        rejectOneMessage(messageReference);
        return;
      } 
      addMessageToList(messageReference);
      if (this.firstMessage == messageReference && this.firstMessage == this.lastMessage)
        bool = true; 
    } 
    if (bool) {
      if (this.trigger == null)
        this.trigger = new RetryTrigger(this, this.retryInterval); 
      try {
        this.trigger.init();
      } catch (TimeTriggerException timeTriggerException) {}
    } 
  }
  
  void moveMessageToEnd(MessageReference paramMessageReference) {
    synchronized (this) {
      if (paramMessageReference == this.firstMessage) {
        this.firstMessage = paramMessageReference.getNext();
        if (this.firstMessage != null)
          this.firstMessage.setPrev(null); 
      } 
      paramMessageReference.setNext(null);
      this.lastMessage.setNext(paramMessageReference);
      paramMessageReference.setPrev(this.lastMessage);
    } 
  }
  
  void removeMessage(MessageReference paramMessageReference) { removeMessageFromList(paramMessageReference); }
  
  void rejectOneMessage(MessageReference paramMessageReference) {
    MessageContext messageContext = paramMessageReference.getMessage();
    if (messageContext instanceof SOAPMessageContext) {
      StoreForwardException storeForwardException = new StoreForwardException("Request failed to be delivered to the remote side either because the message was expired or it exceeded the maximum number of retries");
      ((SOAPMessageContext)messageContext).setMessage(FaultUtil.exception2Fault(storeForwardException));
      ClientDispatcher clientDispatcher = getAndRemoveClientDispatcher(paramMessageReference.getMessageId());
      if (clientDispatcher != null)
        clientDispatcher.callReceive((WLMessageContext)messageContext); 
      if (this.listener != null) {
        this.listener.onDeliveryFailure(storeForwardException.getMessage(), "DF_EXPIRED_CODE");
        this.listener.onCompletion(new ReliableDeliveryFailureEvent(storeForwardException));
      } 
    } 
  }
  
  void rejectAllMessages() {
    MessageReference messageReference = null;
    synchronized (this) {
      this.poisoned = true;
      messageReference = this.firstMessage;
    } 
    while (messageReference != null) {
      rejectOneMessage(messageReference);
      removeMessage(messageReference);
      synchronized (this) {
        messageReference = this.firstMessage;
      } 
    } 
  }
  
  public void getResponse(String paramString) throws StoreForwardException {
    if (debug)
      Debug.say("getResponse(): This messageId = " + paramString); 
    MessageContext messageContext = this.safAgent.getSOAPMessage(paramString);
    Binding binding = (Binding)messageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
    boolean bool = "true".equals(messageContext.getProperty("__BEA_PRIVATE_ONEWAY_PROP"));
    try {
      binding.receive((WLMessageContext)messageContext);
      ClientDispatcher clientDispatcher = getAndRemoveClientDispatcher(paramString);
      if (debug)
        Debug.say(" === getResponse() dispatcher =" + clientDispatcher); 
      if (clientDispatcher != null) {
        clientDispatcher.callReceive((WLMessageContext)messageContext);
      } else {
        String str1 = getSOAPFault(messageContext);
        if (str1 != null) {
          ReliableDelivery reliableDelivery = (ReliableDelivery)((WLMessageContext)messageContext).getProperty("__BEA_PRIVATE_RELIABLE_PROP");
          reliableDelivery.onDeliveryFailure(str1, "DF_UNKNOWN_CODE");
          reliableDelivery.onCompletion(new ReliableDeliveryFailureEvent("Receiver returned SOAP Fault: " + str1));
          return;
        } 
        String str2 = getAckStatus(messageContext);
        if (str2 == null)
          throw new StoreForwardException("No Ack headers in SOAP response"); 
      } 
    } catch (IOException iOException) {
      throw new StoreForwardException("Failed to get response:" + iOException, iOException);
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to get response:" + sOAPException, sOAPException);
    } catch (JAXRPCException jAXRPCException) {
      throw new StoreForwardException("Failed to process response:" + jAXRPCException, jAXRPCException);
    } 
  }
  
  void addClientDispatcher(String paramString, ClientDispatcher paramClientDispatcher) { this.dispatchers.put(paramString, paramClientDispatcher); }
  
  private ClientDispatcher getAndRemoveClientDispatcher(String paramString) { return (ClientDispatcher)this.dispatchers.remove(paramString); }
  
  final void close() {
    synchronized (this) {
      this.dispatchers.clear();
      if (this.running)
        this.running = false; 
      this.firstMessage = this.lastMessage = null;
    } 
    if (this.trigger != null)
      try {
        this.trigger.cancel();
        this.trigger = null;
      } catch (TimeTriggerException timeTriggerException) {} 
  }
  
  final String getNextSequenceNumberString() {
    String str = Integer.toString(this.nextSequenceNumber, 10);
    this.nextSequenceNumber++;
    return str;
  }
  
  final boolean isIndividual() { return this.individual; }
  
  private final String getAckStatus(MessageContext paramMessageContext) throws StoreForwardException {
    try {
      SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
      SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
      SOAPPart sOAPPart = sOAPMessage.getSOAPPart();
      SOAPEnvelope sOAPEnvelope = sOAPPart.getEnvelope();
      return SAFHandler.getStatus(sOAPEnvelope, false);
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to get the acknowledgement", sOAPException);
    } 
  }
  
  private final String getSOAPFault(MessageContext paramMessageContext) throws StoreForwardException {
    try {
      SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
      SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
      SOAPPart sOAPPart = sOAPMessage.getSOAPPart();
      SOAPEnvelope sOAPEnvelope = sOAPPart.getEnvelope();
      SOAPBody sOAPBody = sOAPEnvelope.getBody();
      if (sOAPBody.hasFault())
        return sOAPBody.getFault().getFaultString(); 
      return null;
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to get the SOAP Fault", sOAPException);
    } 
  }
  
  void run() {
    synchronized (this) {
      if (this.running)
        return; 
      this.running = true;
    } 
    WorkManagerFactory.getInstance().getSystem().schedule(new WorkRequest());
  }
  
  final class WorkRequest extends WorkAdapter {
    private final ConversationAssembler this$0;
    
    public final void run() {
      MessageReference messageReference = null;
      synchronized (this) {
        messageReference = ConversationAssembler.this.firstMessage;
      } 
      while (messageReference != null) {
        String str = messageReference.getMessageId();
        if (Conversation.debug)
          Debug.say("== in execute(): running = " + ConversationAssembler.this.running + " firstMessage = " + str); 
        if (messageReference.isExpired() || messageReference.getRetryLeft() == 0) {
          if (Conversation.debug)
            Debug.say("== execute() firstMessage is expired or exceeds retries"); 
          try {
            ConversationAssembler.this.safAgent.remove(str);
          } catch (StoreForwardException storeForwardException) {}
          if (ConversationAssembler.this.isOrdered()) {
            ConversationAssembler.this.rejectAllMessages();
            break;
          } 
          ConversationAssembler.this.rejectOneMessage(messageReference);
          ConversationAssembler.this.removeMessage(messageReference);
          ConversationAssembler.this.reScheduleConversationTrigger();
          synchronized (this) {
            messageReference = ConversationAssembler.this.firstMessage;
            continue;
          } 
        } 
        messageReference.decreaseRetryCount();
        try {
          if (ConversationAssembler.this.safAgent.forward(str) == -1) {
            if (Conversation.debug)
              Debug.say("Could not send message successfully"); 
            if (!ConversationAssembler.this.ordered && !ConversationAssembler.this.isIndividual()) {
              ConversationAssembler.this.moveMessageToEnd(messageReference);
              ConversationAssembler.this.reScheduleConversationTrigger();
            } 
            break;
          } 
        } catch (Exception exception) {
          if (Conversation.debug)
            exception.printStackTrace(); 
          if (!ConversationAssembler.this.ordered && !ConversationAssembler.this.isIndividual()) {
            ConversationAssembler.this.moveMessageToEnd(messageReference);
            ConversationAssembler.this.reScheduleConversationTrigger();
          } 
          ConversationAssembler.this.safAgent.resetSinceStart();
          break;
        } 
        if (Conversation.debug)
          Debug.say("== execute(): successfully forwarded message: " + str); 
        try {
          ConversationAssembler.this.getResponse(str);
          ConversationAssembler.this.safAgent.remove(str);
        } catch (StoreForwardException storeForwardException) {
          if (Conversation.debug)
            storeForwardException.printStackTrace(); 
          if (!ConversationAssembler.this.ordered && !ConversationAssembler.this.isIndividual()) {
            ConversationAssembler.this.moveMessageToEnd(messageReference);
            ConversationAssembler.this.reScheduleConversationTrigger();
          } 
          break;
        } 
        if (Conversation.debug)
          Debug.say("== execute(): response is received"); 
        ConversationAssembler.this.removeMessage(messageReference);
        ConversationAssembler.this.reScheduleConversationTrigger();
        if (ConversationAssembler.this.ordered || ConversationAssembler.this.individual)
          synchronized (this) {
            messageReference = ConversationAssembler.this.firstMessage;
            continue;
          }  
        if (Conversation.debug)
          Debug.say("== execute() con is not ordered"); 
      } 
      synchronized (this) {
        ConversationAssembler.this.running = false;
        if (ConversationAssembler.this.isDone())
          ConversationAssembler.this.close(); 
      } 
    }
  }
  
  private void reScheduleConversationTrigger() {
    if (this.firstMessage == null) {
      try {
        this.trigger.cancel();
      } catch (TimeTriggerException timeTriggerException) {
        if (debug)
          Debug.say("== trigger.cancel() got exception" + timeTriggerException); 
      } 
      return;
    } 
    if (debug)
      Debug.say("== reSchedule() next time:" + this.firstMessage.getNextScheduleInterval()); 
    try {
      this.trigger.cancel();
      this.trigger.updateInterval(this.firstMessage.getNextScheduleInterval());
      this.trigger.init();
    } catch (TimeTriggerException timeTriggerException) {
      if (debug)
        Debug.say("== reSchedule() got exception" + timeTriggerException); 
    } 
  }
  
  void setRetryCount(int paramInt) { this.retryCount = paramInt; }
  
  void setRetryInterval(long paramLong) { this.retryInterval = paramLong; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\ConversationAssembler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */