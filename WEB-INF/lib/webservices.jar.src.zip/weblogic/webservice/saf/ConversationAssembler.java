/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.SOAPBody;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import javax.xml.soap.SOAPPart;
/*     */ import weblogic.time.common.TimeTriggerException;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.ReliableDelivery;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.async.ReliableDeliveryFailureEvent;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.core.ClientDispatcher;
/*     */ import weblogic.webservice.util.FaultUtil;
/*     */ import weblogic.work.WorkAdapter;
/*     */ import weblogic.work.WorkManagerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ConversationAssembler
/*     */   extends Conversation
/*     */   implements ReliableMessagingConstants
/*     */ {
/*     */   private boolean individual;
/*     */   private int nextSequenceNumber;
/*     */   private RetryTrigger trigger;
/*     */   private int retryCount;
/*     */   private long retryInterval;
/*     */   private HashMap dispatchers;
/*     */   private ReliableDelivery listener;
/*     */   private WSSAFAgent safAgent;
/*     */   private boolean poisoned;
/*     */   
/*     */   ConversationAssembler(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt, long paramLong1, long paramLong2, ReliableDelivery paramReliableDelivery) {
/*  84 */     super(paramString, paramBoolean2);
/*     */     
/*  86 */     this.individual = paramBoolean1;
/*  87 */     this.dispatchers = new HashMap();
/*  88 */     this.listener = paramReliableDelivery;
/*     */     
/*  90 */     this.safAgent = WSSAFAgent.getSAFAgent();
/*     */     
/*  92 */     if (paramInt != -1) {
/*  93 */       this.retryCount = paramInt;
/*     */     } else {
/*  95 */       this.retryCount = this.safAgent.getDefaultRetryNumber();
/*     */     } 
/*  97 */     if (paramLong1 != -1L) {
/*  98 */       this.retryInterval = paramLong1;
/*     */     } else {
/* 100 */       this.retryInterval = this.safAgent.getDefaultRetryInterval();
/*     */     } 
/* 102 */     if (paramLong2 != -1L) {
/* 103 */       this.persistDuration = paramLong2;
/*     */     } else {
/* 105 */       this.persistDuration = this.safAgent.getDefaultPersistDuration();
/*     */     } 
/*     */ 
/*     */     
/* 109 */     this.nextSequenceNumber = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addMessage(String paramString, int paramInt, Object paramObject) {
/* 125 */     MessageReference messageReference = null;
/* 126 */     if (paramObject instanceof MessageContext) {
/* 127 */       messageReference = new MessageReference(paramString, paramInt, (MessageContext)paramObject, this.retryCount, this.retryInterval, this.persistDuration);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (messageReference == null)
/*     */       return; 
/* 138 */     boolean bool = false;
/*     */     
/* 140 */     synchronized (this) {
/*     */ 
/*     */ 
/*     */       
/* 144 */       if (this.poisoned) {
/* 145 */         rejectOneMessage(messageReference);
/*     */         
/*     */         return;
/*     */       } 
/* 149 */       addMessageToList(messageReference);
/*     */       
/* 151 */       if (this.firstMessage == messageReference && this.firstMessage == this.lastMessage)
/*     */       {
/* 153 */         bool = true;
/*     */       }
/*     */     } 
/*     */     
/* 157 */     if (bool) {
/* 158 */       if (this.trigger == null) this.trigger = new RetryTrigger(this, this.retryInterval); 
/*     */       try {
/* 160 */         this.trigger.init();
/* 161 */       } catch (TimeTriggerException timeTriggerException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void moveMessageToEnd(MessageReference paramMessageReference) {
/* 175 */     synchronized (this) {
/* 176 */       if (paramMessageReference == this.firstMessage) {
/* 177 */         this.firstMessage = paramMessageReference.getNext();
/* 178 */         if (this.firstMessage != null) this.firstMessage.setPrev(null);
/*     */       
/*     */       } 
/* 181 */       paramMessageReference.setNext(null);
/* 182 */       this.lastMessage.setNext(paramMessageReference);
/* 183 */       paramMessageReference.setPrev(this.lastMessage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   void removeMessage(MessageReference paramMessageReference) { removeMessageFromList(paramMessageReference); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rejectOneMessage(MessageReference paramMessageReference) {
/* 211 */     MessageContext messageContext = paramMessageReference.getMessage();
/* 212 */     if (messageContext instanceof SOAPMessageContext) {
/* 213 */       StoreForwardException storeForwardException = new StoreForwardException("Request failed to be delivered to the remote side either because the message was expired or it exceeded the maximum number of retries");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 218 */       ((SOAPMessageContext)messageContext).setMessage(FaultUtil.exception2Fault(storeForwardException));
/*     */ 
/*     */       
/* 221 */       ClientDispatcher clientDispatcher = getAndRemoveClientDispatcher(paramMessageReference.getMessageId());
/*     */ 
/*     */       
/* 224 */       if (clientDispatcher != null) clientDispatcher.callReceive((WLMessageContext)messageContext);
/*     */       
/* 226 */       if (this.listener != null) {
/* 227 */         this.listener.onDeliveryFailure(storeForwardException.getMessage(), "DF_EXPIRED_CODE");
/* 228 */         this.listener.onCompletion(new ReliableDeliveryFailureEvent(storeForwardException));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rejectAllMessages() {
/* 243 */     MessageReference messageReference = null;
/* 244 */     synchronized (this) {
/* 245 */       this.poisoned = true;
/* 246 */       messageReference = this.firstMessage;
/*     */     } 
/* 248 */     while (messageReference != null) {
/*     */       
/* 250 */       rejectOneMessage(messageReference);
/* 251 */       removeMessage(messageReference);
/* 252 */       synchronized (this) {
/* 253 */         messageReference = this.firstMessage;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getResponse(String paramString) throws StoreForwardException {
/* 265 */     if (debug) Debug.say("getResponse(): This messageId = " + paramString);
/*     */     
/* 267 */     MessageContext messageContext = this.safAgent.getSOAPMessage(paramString);
/*     */     
/* 269 */     Binding binding = (Binding)messageContext.getProperty("__BEA_PRIVATE_BINDING_PROP");
/*     */ 
/*     */     
/* 272 */     boolean bool = "true".equals(messageContext.getProperty("__BEA_PRIVATE_ONEWAY_PROP"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 282 */       binding.receive((WLMessageContext)messageContext);
/*     */       
/* 284 */       ClientDispatcher clientDispatcher = getAndRemoveClientDispatcher(paramString);
/*     */       
/* 286 */       if (debug) Debug.say(" === getResponse() dispatcher =" + clientDispatcher);
/*     */       
/* 288 */       if (clientDispatcher != null) {
/* 289 */         clientDispatcher.callReceive((WLMessageContext)messageContext);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 295 */         String str1 = getSOAPFault(messageContext);
/* 296 */         if (str1 != null) {
/* 297 */           ReliableDelivery reliableDelivery = (ReliableDelivery)((WLMessageContext)messageContext).getProperty("__BEA_PRIVATE_RELIABLE_PROP");
/*     */ 
/*     */           
/* 300 */           reliableDelivery.onDeliveryFailure(str1, "DF_UNKNOWN_CODE");
/* 301 */           reliableDelivery.onCompletion(new ReliableDeliveryFailureEvent("Receiver returned SOAP Fault: " + str1));
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 306 */         String str2 = getAckStatus(messageContext);
/* 307 */         if (str2 == null) {
/* 308 */           throw new StoreForwardException("No Ack headers in SOAP response");
/*     */         }
/*     */       }
/*     */     
/* 312 */     } catch (IOException iOException) {
/* 313 */       throw new StoreForwardException("Failed to get response:" + iOException, iOException);
/* 314 */     } catch (SOAPException sOAPException) {
/* 315 */       throw new StoreForwardException("Failed to get response:" + sOAPException, sOAPException);
/*     */     }
/* 317 */     catch (JAXRPCException jAXRPCException) {
/* 318 */       throw new StoreForwardException("Failed to process response:" + jAXRPCException, jAXRPCException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   void addClientDispatcher(String paramString, ClientDispatcher paramClientDispatcher) { this.dispatchers.put(paramString, paramClientDispatcher); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 340 */   private ClientDispatcher getAndRemoveClientDispatcher(String paramString) { return (ClientDispatcher)this.dispatchers.remove(paramString); }
/*     */ 
/*     */   
/*     */   final void close() {
/* 344 */     synchronized (this) {
/* 345 */       this.dispatchers.clear();
/* 346 */       if (this.running) this.running = false; 
/* 347 */       this.firstMessage = this.lastMessage = null;
/*     */     } 
/*     */ 
/*     */     
/* 351 */     if (this.trigger != null) {
/*     */       try {
/* 353 */         this.trigger.cancel();
/* 354 */         this.trigger = null;
/* 355 */       } catch (TimeTriggerException timeTriggerException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final String getNextSequenceNumberString() {
/* 361 */     String str = Integer.toString(this.nextSequenceNumber, 10);
/* 362 */     this.nextSequenceNumber++;
/* 363 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 368 */   final boolean isIndividual() { return this.individual; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getAckStatus(MessageContext paramMessageContext) throws StoreForwardException {
/*     */     try {
/* 376 */       SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/* 377 */       SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 378 */       SOAPPart sOAPPart = sOAPMessage.getSOAPPart();
/* 379 */       SOAPEnvelope sOAPEnvelope = sOAPPart.getEnvelope();
/*     */       
/* 381 */       return SAFHandler.getStatus(sOAPEnvelope, false);
/*     */     }
/* 383 */     catch (SOAPException sOAPException) {
/* 384 */       throw new StoreForwardException("Failed to get the acknowledgement", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getSOAPFault(MessageContext paramMessageContext) throws StoreForwardException {
/*     */     try {
/* 393 */       SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/* 394 */       SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 395 */       SOAPPart sOAPPart = sOAPMessage.getSOAPPart();
/* 396 */       SOAPEnvelope sOAPEnvelope = sOAPPart.getEnvelope();
/* 397 */       SOAPBody sOAPBody = sOAPEnvelope.getBody();
/*     */       
/* 399 */       if (sOAPBody.hasFault()) {
/* 400 */         return sOAPBody.getFault().getFaultString();
/*     */       }
/*     */       
/* 403 */       return null;
/*     */     
/*     */     }
/* 406 */     catch (SOAPException sOAPException) {
/* 407 */       throw new StoreForwardException("Failed to get the SOAP Fault", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void run() {
/* 413 */     synchronized (this) {
/* 414 */       if (this.running)
/* 415 */         return;  this.running = true;
/*     */     } 
/*     */     
/* 418 */     WorkManagerFactory.getInstance().getSystem().schedule(new WorkRequest());
/*     */   }
/*     */   
/*     */   final class WorkRequest extends WorkAdapter {
/*     */     public final void run() {
/* 423 */       MessageReference messageReference = null;
/* 424 */       synchronized (this) {
/* 425 */         messageReference = ConversationAssembler.this.firstMessage;
/*     */       } 
/*     */       
/* 428 */       while (messageReference != null) {
/* 429 */         String str = messageReference.getMessageId();
/*     */         
/* 431 */         if (Conversation.debug) {
/* 432 */           Debug.say("== in execute(): running = " + ConversationAssembler.this.running + " firstMessage = " + str);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 437 */         if (messageReference.isExpired() || messageReference.getRetryLeft() == 0) {
/*     */           
/* 439 */           if (Conversation.debug) {
/* 440 */             Debug.say("== execute() firstMessage is expired or exceeds retries");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 446 */             ConversationAssembler.this.safAgent.remove(str);
/* 447 */           } catch (StoreForwardException storeForwardException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 453 */           if (ConversationAssembler.this.isOrdered()) {
/* 454 */             ConversationAssembler.this.rejectAllMessages();
/*     */             break;
/*     */           } 
/* 457 */           ConversationAssembler.this.rejectOneMessage(messageReference);
/* 458 */           ConversationAssembler.this.removeMessage(messageReference);
/*     */ 
/*     */           
/* 461 */           ConversationAssembler.this.reScheduleConversationTrigger();
/*     */ 
/*     */           
/* 464 */           synchronized (this) {
/* 465 */             messageReference = ConversationAssembler.this.firstMessage;
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } 
/*     */         
/* 472 */         messageReference.decreaseRetryCount();
/*     */ 
/*     */         
/*     */         try {
/* 476 */           if (ConversationAssembler.this.safAgent.forward(str) == -1) {
/* 477 */             if (Conversation.debug) {
/* 478 */               Debug.say("Could not send message successfully");
/*     */             }
/*     */             
/* 481 */             if (!ConversationAssembler.this.ordered && !ConversationAssembler.this.isIndividual()) {
/*     */               
/* 483 */               ConversationAssembler.this.moveMessageToEnd(messageReference);
/* 484 */               ConversationAssembler.this.reScheduleConversationTrigger();
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/* 492 */         } catch (Exception exception) {
/*     */           
/* 494 */           if (Conversation.debug) {
/* 495 */             exception.printStackTrace();
/*     */           }
/*     */           
/* 498 */           if (!ConversationAssembler.this.ordered && !ConversationAssembler.this.isIndividual()) {
/*     */             
/* 500 */             ConversationAssembler.this.moveMessageToEnd(messageReference);
/* 501 */             ConversationAssembler.this.reScheduleConversationTrigger();
/*     */           } 
/* 503 */           ConversationAssembler.this.safAgent.resetSinceStart();
/*     */ 
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */ 
/*     */         
/* 511 */         if (Conversation.debug) {
/* 512 */           Debug.say("== execute(): successfully forwarded message: " + str);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 518 */           ConversationAssembler.this.getResponse(str);
/*     */ 
/*     */           
/* 521 */           ConversationAssembler.this.safAgent.remove(str);
/*     */         }
/* 523 */         catch (StoreForwardException storeForwardException) {
/* 524 */           if (Conversation.debug) storeForwardException.printStackTrace();
/*     */           
/* 526 */           if (!ConversationAssembler.this.ordered && !ConversationAssembler.this.isIndividual()) {
/*     */             
/* 528 */             ConversationAssembler.this.moveMessageToEnd(messageReference);
/* 529 */             ConversationAssembler.this.reScheduleConversationTrigger();
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */ 
/*     */         
/* 538 */         if (Conversation.debug) {
/* 539 */           Debug.say("== execute(): response is received");
/*     */         }
/* 541 */         ConversationAssembler.this.removeMessage(messageReference);
/* 542 */         ConversationAssembler.this.reScheduleConversationTrigger();
/*     */         
/* 544 */         if (ConversationAssembler.this.ordered || ConversationAssembler.this.individual) {
/* 545 */           synchronized (this) {
/* 546 */             messageReference = ConversationAssembler.this.firstMessage;
/*     */             
/*     */             continue;
/*     */           } 
/*     */         }
/* 551 */         if (Conversation.debug) {
/* 552 */           Debug.say("== execute() con is not ordered");
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 557 */       synchronized (this) {
/* 558 */         ConversationAssembler.this.running = false;
/*     */ 
/*     */         
/* 561 */         if (ConversationAssembler.this.isDone()) {
/* 562 */           ConversationAssembler.this.close();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     private final ConversationAssembler this$0;
/*     */   }
/*     */ 
/*     */   
/*     */   private void reScheduleConversationTrigger() {
/* 573 */     if (this.firstMessage == null) {
/*     */       try {
/* 575 */         this.trigger.cancel();
/* 576 */       } catch (TimeTriggerException timeTriggerException) {
/*     */         
/* 578 */         if (debug) {
/* 579 */           Debug.say("== trigger.cancel() got exception" + timeTriggerException);
/*     */         }
/*     */       } 
/*     */       return;
/*     */     } 
/* 584 */     if (debug) {
/* 585 */       Debug.say("== reSchedule() next time:" + this.firstMessage.getNextScheduleInterval());
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 590 */       this.trigger.cancel();
/* 591 */       this.trigger.updateInterval(this.firstMessage.getNextScheduleInterval());
/* 592 */       this.trigger.init();
/* 593 */     } catch (TimeTriggerException timeTriggerException) {
/*     */       
/* 595 */       if (debug) {
/* 596 */         Debug.say("== reSchedule() got exception" + timeTriggerException);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 603 */   void setRetryCount(int paramInt) { this.retryCount = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 609 */   void setRetryInterval(long paramLong) { this.retryInterval = paramLong; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\ConversationAssembler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */