package weblogic.webservice.saf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;
import javax.jms.ConnectionFactory;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import org.w3c.dom.Element;
import weblogic.apache.xerces.dom.DocumentImpl;
import weblogic.jms.JMSService;
import weblogic.jndi.Environment;
import weblogic.management.configuration.TargetMBean;
import weblogic.webservice.Operation;
import weblogic.webservice.binding.Binding;
import weblogic.webservice.binding.BindingFactory;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.binding.https.HttpsBindingInfo;
import weblogic.webservice.binding.jms.JMSBindingInfo;
import weblogic.webservice.client.SSLAdapter;
import weblogic.webservice.core.DefaultMessageContext;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;

public final class Util {
  private static boolean debug = false;
  
  public static Context getInitialContext() throws NamingException {
    Environment environment = new Environment();
    environment.setCreateIntermediateContexts(true);
    return environment.getInitialContext();
  }
  
  static MessageContext copyMessageContext(MessageContext paramMessageContext) {
    DefaultMessageContext defaultMessageContext = null;
    if (paramMessageContext instanceof weblogic.webservice.WLMessageContext)
      try {
        defaultMessageContext = new DefaultMessageContext();
      } catch (SOAPException sOAPException) {} 
    if (defaultMessageContext == null)
      return null; 
    Iterator iterator = paramMessageContext.getPropertyNames();
    while (iterator.hasNext()) {
      String str = (String)iterator.next();
      Object object = paramMessageContext.getProperty(str);
      defaultMessageContext.setProperty(str, object);
    } 
    if (paramMessageContext instanceof DefaultMessageContext) {
      Operation operation = ((DefaultMessageContext)paramMessageContext).getOperation();
      ((DefaultMessageContext)defaultMessageContext).setOperation(operation);
      SOAPMessage sOAPMessage = ((DefaultMessageContext)paramMessageContext).getMessage();
      ((DefaultMessageContext)defaultMessageContext).setMessage(sOAPMessage);
    } 
    return defaultMessageContext;
  }
  
  static String getMessageId(String paramString) {
    int i = paramString.indexOf(":");
    if (i < 0)
      return paramString; 
    return paramString.substring(0, i);
  }
  
  static int getSequenceNumber(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ":");
    String str = stringTokenizer.nextToken();
    if (stringTokenizer.hasMoreElements())
      str = stringTokenizer.nextToken(); 
    if (str == null)
      return -1; 
    try {
      return Integer.parseInt(str);
    } catch (NumberFormatException numberFormatException) {
      return -1;
    } 
  }
  
  static String getConversationId(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ":");
    String str = stringTokenizer.nextToken();
    str = stringTokenizer.nextToken();
    if (stringTokenizer.hasMoreElements())
      return stringTokenizer.nextToken(); 
    return null;
  }
  
  static String getHeaderType(String paramString) {
    int i = paramString.indexOf(":");
    if (i < 0)
      return null; 
    String str1 = paramString.substring(i + 1);
    i = str1.indexOf(":");
    if (i < 0)
      return null; 
    String str2 = str1.substring(i + 1);
    int j = str2.indexOf(":");
    if (j < 0)
      return null; 
    return str2.substring(j + 1);
  }
  
  public static SOAPElement getChildSOAPElement(SOAPElement paramSOAPElement, Name paramName) {
    Iterator iterator = paramSOAPElement.getChildElements(paramName);
    if (iterator == null || !iterator.hasNext())
      return null; 
    return (SOAPElement)iterator.next();
  }
  
  static byte[] soapMessage2Bytes(SOAPMessageContext paramSOAPMessageContext) throws StoreForwardException {
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      SOAPMessage sOAPMessage = paramSOAPMessageContext.getMessage();
      sOAPMessage.writeTo(byteArrayOutputStream);
      byteArrayOutputStream.flush();
      return byteArrayOutputStream.toByteArray();
    } catch (IOException iOException) {
      throw new StoreForwardException("Failed to create message", iOException);
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to create message", sOAPException);
    } 
  }
  
  static SOAPMessage inputStream2SOAPMessage(InputStream paramInputStream, HashMap paramHashMap) throws StoreForwardException {
    try {
      MimeHeaders mimeHeaders = null;
      if (paramHashMap != null) {
        mimeHeaders = new MimeHeaders();
        Iterator iterator = paramHashMap.keySet().iterator();
        while (iterator.hasNext()) {
          String str1 = (String)iterator.next();
          String str2 = (String)paramHashMap.get(str1);
          mimeHeaders.addHeader(str1, str2);
        } 
      } 
      MessageFactory messageFactory = MessageFactory.newInstance();
      return messageFactory.createMessage(mimeHeaders, paramInputStream);
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to create SOAPMessage", sOAPException);
    } catch (IOException iOException) {
      throw new StoreForwardException("Failed to create SOAPMessage", iOException);
    } 
  }
  
  static Element xmlNode2DOMElement(XMLNode paramXMLNode) throws XMLStreamException {
    XMLInputStream xMLInputStream = paramXMLNode.stream();
    XMLOutputStreamFactory xMLOutputStreamFactory = XMLOutputStreamFactory.newInstance();
    DocumentImpl documentImpl = new DocumentImpl();
    XMLOutputStream xMLOutputStream = xMLOutputStreamFactory.newOutputStream(documentImpl);
    xMLOutputStream.add(xMLInputStream);
    xMLOutputStream.flush();
    return documentImpl.getDocumentElement();
  }
  
  static Binding createBinding(String paramString1, String paramString2, String paramString3, String paramString4) throws StoreForwardException { return createBinding(paramString1, paramString2, paramString3, paramString4, null); }
  
  static Binding createBinding(String paramString1, String paramString2, String paramString3, String paramString4, SSLAdapter paramSSLAdapter) throws StoreForwardException {
    try {
      BindingFactory bindingFactory = BindingFactory.getInstance();
      BindingInfo bindingInfo = null;
      if (paramSSLAdapter != null) {
        HttpsBindingInfo httpsBindingInfo = new HttpsBindingInfo();
        httpsBindingInfo.setSSLAdapter(paramSSLAdapter);
        bindingInfo = httpsBindingInfo;
      } else if ("jms".equals(paramString2)) {
        JMSBindingInfo jMSBindingInfo = new JMSBindingInfo();
      } else {
        bindingInfo = new BindingInfo();
      } 
      bindingInfo.setAddress(paramString1);
      if (paramString3 != null)
        bindingInfo.setType(paramString3); 
      if (paramString4 != null)
        bindingInfo.setCharset(paramString4); 
      return bindingFactory.create(bindingInfo);
    } catch (IOException iOException) {
      throw new StoreForwardException("Failed to create transport Binding", iOException);
    } 
  }
  
  static ConnectionFactory getXAConnectionFactory() { return JMSService.getJMSService().getDefaultConnectionFactory("DefaultXAConnectionFactory").getJMSConnectionFactory(); }
  
  static ConnectionFactory getConnectionFactory() { return JMSService.getJMSService().getDefaultConnectionFactory("DefaultConnectionFactory").getJMSConnectionFactory(); }
  
  static String generateQueueName(String paramString, TargetMBean paramTargetMBean) { return "WSInternal" + paramString + paramTargetMBean.getName(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */