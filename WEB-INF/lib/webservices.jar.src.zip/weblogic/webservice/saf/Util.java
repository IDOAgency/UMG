/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.MessageFactory;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import org.w3c.dom.Element;
/*     */ import weblogic.apache.xerces.dom.DocumentImpl;
/*     */ import weblogic.jms.JMSService;
/*     */ import weblogic.jndi.Environment;
/*     */ import weblogic.management.configuration.TargetMBean;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.binding.Binding;
/*     */ import weblogic.webservice.binding.BindingFactory;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.binding.https.HttpsBindingInfo;
/*     */ import weblogic.webservice.binding.jms.JMSBindingInfo;
/*     */ import weblogic.webservice.client.SSLAdapter;
/*     */ import weblogic.webservice.core.DefaultMessageContext;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Util
/*     */ {
/*     */   private static boolean debug = false;
/*     */   
/*     */   public static Context getInitialContext() throws NamingException {
/*  67 */     Environment environment = new Environment();
/*  68 */     environment.setCreateIntermediateContexts(true);
/*  69 */     return environment.getInitialContext();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static MessageContext copyMessageContext(MessageContext paramMessageContext) {
/*  75 */     DefaultMessageContext defaultMessageContext = null;
/*     */     
/*  77 */     if (paramMessageContext instanceof weblogic.webservice.WLMessageContext) {
/*     */       try {
/*  79 */         defaultMessageContext = new DefaultMessageContext();
/*  80 */       } catch (SOAPException sOAPException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  85 */     if (defaultMessageContext == null) return null;
/*     */     
/*  87 */     Iterator iterator = paramMessageContext.getPropertyNames();
/*  88 */     while (iterator.hasNext()) {
/*  89 */       String str = (String)iterator.next();
/*  90 */       Object object = paramMessageContext.getProperty(str);
/*  91 */       defaultMessageContext.setProperty(str, object);
/*     */     } 
/*     */     
/*  94 */     if (paramMessageContext instanceof DefaultMessageContext) {
/*  95 */       Operation operation = ((DefaultMessageContext)paramMessageContext).getOperation();
/*  96 */       ((DefaultMessageContext)defaultMessageContext).setOperation(operation);
/*  97 */       SOAPMessage sOAPMessage = ((DefaultMessageContext)paramMessageContext).getMessage();
/*  98 */       ((DefaultMessageContext)defaultMessageContext).setMessage(sOAPMessage);
/*     */     } 
/*     */     
/* 101 */     return defaultMessageContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getMessageId(String paramString) {
/* 111 */     int i = paramString.indexOf(":");
/* 112 */     if (i < 0) return paramString; 
/* 113 */     return paramString.substring(0, i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getSequenceNumber(String paramString) {
/* 123 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ":");
/* 124 */     String str = stringTokenizer.nextToken();
/*     */     
/* 126 */     if (stringTokenizer.hasMoreElements()) {
/* 127 */       str = stringTokenizer.nextToken();
/*     */     }
/* 129 */     if (str == null) return -1; 
/*     */     try {
/* 131 */       return Integer.parseInt(str);
/* 132 */     } catch (NumberFormatException numberFormatException) {
/* 133 */       return -1;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getConversationId(String paramString) {
/* 144 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ":");
/* 145 */     String str = stringTokenizer.nextToken();
/* 146 */     str = stringTokenizer.nextToken();
/*     */     
/* 148 */     if (stringTokenizer.hasMoreElements()) {
/* 149 */       return stringTokenizer.nextToken();
/*     */     }
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getHeaderType(String paramString) {
/* 161 */     int i = paramString.indexOf(":");
/* 162 */     if (i < 0) return null; 
/* 163 */     String str1 = paramString.substring(i + 1);
/* 164 */     i = str1.indexOf(":");
/* 165 */     if (i < 0) return null; 
/* 166 */     String str2 = str1.substring(i + 1);
/* 167 */     int j = str2.indexOf(":");
/* 168 */     if (j < 0) return null; 
/* 169 */     return str2.substring(j + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SOAPElement getChildSOAPElement(SOAPElement paramSOAPElement, Name paramName) {
/* 179 */     Iterator iterator = paramSOAPElement.getChildElements(paramName);
/* 180 */     if (iterator == null || !iterator.hasNext()) {
/* 181 */       return null;
/*     */     }
/* 183 */     return (SOAPElement)iterator.next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] soapMessage2Bytes(SOAPMessageContext paramSOAPMessageContext) throws StoreForwardException {
/*     */     try {
/* 195 */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */       
/* 197 */       SOAPMessage sOAPMessage = paramSOAPMessageContext.getMessage();
/*     */       
/* 199 */       sOAPMessage.writeTo(byteArrayOutputStream);
/* 200 */       byteArrayOutputStream.flush();
/* 201 */       return byteArrayOutputStream.toByteArray();
/*     */ 
/*     */     
/*     */     }
/* 205 */     catch (IOException iOException) {
/* 206 */       throw new StoreForwardException("Failed to create message", iOException);
/* 207 */     } catch (SOAPException sOAPException) {
/* 208 */       throw new StoreForwardException("Failed to create message", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SOAPMessage inputStream2SOAPMessage(InputStream paramInputStream, HashMap paramHashMap) throws StoreForwardException {
/*     */     try {
/* 221 */       MimeHeaders mimeHeaders = null;
/* 222 */       if (paramHashMap != null) {
/* 223 */         mimeHeaders = new MimeHeaders();
/* 224 */         Iterator iterator = paramHashMap.keySet().iterator();
/* 225 */         while (iterator.hasNext()) {
/* 226 */           String str1 = (String)iterator.next();
/* 227 */           String str2 = (String)paramHashMap.get(str1);
/* 228 */           mimeHeaders.addHeader(str1, str2);
/*     */         } 
/*     */       } 
/* 231 */       MessageFactory messageFactory = MessageFactory.newInstance();
/* 232 */       return messageFactory.createMessage(mimeHeaders, paramInputStream);
/* 233 */     } catch (SOAPException sOAPException) {
/* 234 */       throw new StoreForwardException("Failed to create SOAPMessage", sOAPException);
/* 235 */     } catch (IOException iOException) {
/* 236 */       throw new StoreForwardException("Failed to create SOAPMessage", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Element xmlNode2DOMElement(XMLNode paramXMLNode) throws XMLStreamException {
/* 247 */     XMLInputStream xMLInputStream = paramXMLNode.stream();
/* 248 */     XMLOutputStreamFactory xMLOutputStreamFactory = XMLOutputStreamFactory.newInstance();
/*     */     
/* 250 */     DocumentImpl documentImpl = new DocumentImpl();
/* 251 */     XMLOutputStream xMLOutputStream = xMLOutputStreamFactory.newOutputStream(documentImpl);
/* 252 */     xMLOutputStream.add(xMLInputStream);
/* 253 */     xMLOutputStream.flush();
/*     */     
/* 255 */     return documentImpl.getDocumentElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   static Binding createBinding(String paramString1, String paramString2, String paramString3, String paramString4) throws StoreForwardException { return createBinding(paramString1, paramString2, paramString3, paramString4, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Binding createBinding(String paramString1, String paramString2, String paramString3, String paramString4, SSLAdapter paramSSLAdapter) throws StoreForwardException {
/*     */     try {
/* 278 */       BindingFactory bindingFactory = BindingFactory.getInstance();
/* 279 */       BindingInfo bindingInfo = null;
/*     */       
/* 281 */       if (paramSSLAdapter != null) {
/* 282 */         HttpsBindingInfo httpsBindingInfo = new HttpsBindingInfo();
/* 283 */         httpsBindingInfo.setSSLAdapter(paramSSLAdapter);
/* 284 */         bindingInfo = httpsBindingInfo;
/* 285 */       } else if ("jms".equals(paramString2)) {
/* 286 */         JMSBindingInfo jMSBindingInfo = new JMSBindingInfo();
/*     */       } else {
/* 288 */         bindingInfo = new BindingInfo();
/*     */       } 
/*     */       
/* 291 */       bindingInfo.setAddress(paramString1);
/* 292 */       if (paramString3 != null)
/* 293 */         bindingInfo.setType(paramString3); 
/* 294 */       if (paramString4 != null) {
/* 295 */         bindingInfo.setCharset(paramString4);
/*     */       }
/* 297 */       return bindingFactory.create(bindingInfo);
/* 298 */     } catch (IOException iOException) {
/* 299 */       throw new StoreForwardException("Failed to create transport Binding", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 310 */   static ConnectionFactory getXAConnectionFactory() { return JMSService.getJMSService().getDefaultConnectionFactory("DefaultXAConnectionFactory").getJMSConnectionFactory(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 322 */   static ConnectionFactory getConnectionFactory() { return JMSService.getJMSService().getDefaultConnectionFactory("DefaultConnectionFactory").getJMSConnectionFactory(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   static String generateQueueName(String paramString, TargetMBean paramTargetMBean) { return "WSInternal" + paramString + paramTargetMBean.getName(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */