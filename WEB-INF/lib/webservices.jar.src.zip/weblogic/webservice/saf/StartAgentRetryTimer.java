package weblogic.webservice.saf;

import javax.jms.JMSException;
import javax.naming.NamingException;
import weblogic.t3.srvr.T3Srvr;
import weblogic.time.common.Schedulable;
import weblogic.time.common.ScheduledTriggerDef;
import weblogic.time.common.TimeTriggerException;
import weblogic.time.common.Triggerable;
import weblogic.webservice.WebServiceLogger;

class StartAgentRetryTimer implements Schedulable, Triggerable {
  ScheduledTriggerDef trigger;
  
  private long delay;
  
  private WSSAFAgent agent;
  
  public void init(WSSAFAgent paramWSSAFAgent, long paramLong) throws TimeTriggerException {
    this.trigger = T3Srvr.getT3Srvr().getT3Services().time().getScheduledTrigger(this, this);
    this.delay = paramLong;
    this.agent = paramWSSAFAgent;
    this.trigger.schedule();
  }
  
  public long schedule(long paramLong) { return paramLong + this.delay; }
  
  public void trigger(Schedulable paramSchedulable) {
    try {
      if (this.agent != null)
        this.agent.start(); 
      try {
        cancel();
      } catch (TimeTriggerException timeTriggerException) {}
    } catch (JMSException jMSException) {
      WebServiceLogger.logFailedAccessStore(jMSException);
      try {
        cancel();
      } catch (TimeTriggerException timeTriggerException) {}
    } catch (NamingException namingException) {}
  }
  
  public void cancel() { this.trigger.cancel(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\StartAgentRetryTimer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */