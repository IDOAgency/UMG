package weblogic.webservice.saf;

import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;

public class StoreForwardException extends Exception {
  static final long serialVersionUID = -7167007358028207744L;
  
  private Throwable throwable;
  
  public StoreForwardException(String paramString) {
    super(paramString);
    this.throwable = null;
  }
  
  StoreForwardException(String paramString, Throwable paramThrowable) {
    super(paramString);
    this.throwable = paramThrowable;
  }
  
  void setLinkedException(Exception paramException) { this.throwable = paramException; }
  
  void setLinkedThrowable(Throwable paramThrowable) { this.throwable = paramThrowable; }
  
  public Exception getLinkedException() {
    if (this.throwable instanceof Exception)
      return (Exception)this.throwable; 
    StringWriter stringWriter = new StringWriter();
    StoreForwardException storeForwardException = new StoreForwardException(this.throwable.getMessage());
    storeForwardException.setLinkedException(new Exception(stringWriter.toString()));
    return storeForwardException;
  }
  
  public void printStackTrace() {
    super.printStackTrace();
    printWLJMSStackTrace(this.throwable);
  }
  
  public void printStackTrace(PrintStream paramPrintStream) {
    super.printStackTrace(paramPrintStream);
    printWLJMSStackTrace(this.throwable, paramPrintStream);
  }
  
  public void printStackTrace(PrintWriter paramPrintWriter) {
    super.printStackTrace(paramPrintWriter);
    printWLJMSStackTrace(this.throwable, paramPrintWriter);
  }
  
  static void printWLJMSStackTrace(Throwable paramThrowable) {
    if (paramThrowable != null) {
      System.out.println("----------- Linked Exception -----------");
      paramThrowable.printStackTrace();
    } 
  }
  
  static void printWLJMSStackTrace(Throwable paramThrowable, PrintStream paramPrintStream) {
    if (paramThrowable != null) {
      paramPrintStream.println("----------- Linked Exception -----------");
      paramThrowable.printStackTrace(paramPrintStream);
    } 
  }
  
  static void printWLJMSStackTrace(Throwable paramThrowable, PrintWriter paramPrintWriter) {
    if (paramThrowable != null) {
      paramPrintWriter.println("----------- Linked Exception -----------");
      paramThrowable.printStackTrace(paramPrintWriter);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\StoreForwardException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */