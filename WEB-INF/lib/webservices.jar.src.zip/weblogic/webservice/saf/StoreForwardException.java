/*    */ package weblogic.webservice.saf;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StoreForwardException
/*    */   extends Exception
/*    */ {
/*    */   static final long serialVersionUID = -7167007358028207744L;
/*    */   private Throwable throwable;
/*    */   
/*    */   public StoreForwardException(String paramString) {
/* 20 */     super(paramString);
/* 21 */     this.throwable = null;
/*    */   }
/*    */   
/*    */   StoreForwardException(String paramString, Throwable paramThrowable) {
/* 25 */     super(paramString);
/* 26 */     this.throwable = paramThrowable;
/*    */   }
/*    */ 
/*    */   
/* 30 */   void setLinkedException(Exception paramException) { this.throwable = paramException; }
/*    */ 
/*    */ 
/*    */   
/* 34 */   void setLinkedThrowable(Throwable paramThrowable) { this.throwable = paramThrowable; }
/*    */ 
/*    */ 
/*    */   
/*    */   public Exception getLinkedException() {
/* 39 */     if (this.throwable instanceof Exception) {
/* 40 */       return (Exception)this.throwable;
/*    */     }
/* 42 */     StringWriter stringWriter = new StringWriter();
/* 43 */     StoreForwardException storeForwardException = new StoreForwardException(this.throwable.getMessage());
/*    */     
/* 45 */     storeForwardException.setLinkedException(new Exception(stringWriter.toString()));
/* 46 */     return storeForwardException;
/*    */   }
/*    */   
/*    */   public void printStackTrace() {
/* 50 */     super.printStackTrace();
/* 51 */     printWLJMSStackTrace(this.throwable);
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintStream paramPrintStream) {
/* 55 */     super.printStackTrace(paramPrintStream);
/* 56 */     printWLJMSStackTrace(this.throwable, paramPrintStream);
/*    */   }
/*    */   
/*    */   public void printStackTrace(PrintWriter paramPrintWriter) {
/* 60 */     super.printStackTrace(paramPrintWriter);
/* 61 */     printWLJMSStackTrace(this.throwable, paramPrintWriter);
/*    */   }
/*    */   
/*    */   static void printWLJMSStackTrace(Throwable paramThrowable) {
/* 65 */     if (paramThrowable != null) {
/* 66 */       System.out.println("----------- Linked Exception -----------");
/* 67 */       paramThrowable.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/*    */   static void printWLJMSStackTrace(Throwable paramThrowable, PrintStream paramPrintStream) {
/* 72 */     if (paramThrowable != null) {
/* 73 */       paramPrintStream.println("----------- Linked Exception -----------");
/* 74 */       paramThrowable.printStackTrace(paramPrintStream);
/*    */     } 
/*    */   }
/*    */   
/*    */   static void printWLJMSStackTrace(Throwable paramThrowable, PrintWriter paramPrintWriter) {
/* 79 */     if (paramThrowable != null) {
/* 80 */       paramPrintWriter.println("----------- Linked Exception -----------");
/* 81 */       paramThrowable.printStackTrace(paramPrintWriter);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\StoreForwardException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */