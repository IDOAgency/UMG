package weblogic.webservice.saf;

import java.util.Iterator;
import java.util.Map;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import org.w3c.dom.Element;
import weblogic.apache.xerces.dom.DocumentImpl;
import weblogic.utils.Debug;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.ReliableDelivery;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.async.AsyncInfo;
import weblogic.webservice.async.FutureResultImpl;
import weblogic.webservice.async.InvokeCompletedEvent;
import weblogic.webservice.async.ReliableDeliveryFailureEvent;
import weblogic.webservice.core.ClientDispatcher;
import weblogic.webservice.core.handler.ConversationContext;
import weblogic.webservice.core.soap.SOAPElementImpl;
import weblogic.webservice.core.soap.SOAPFactoryImpl;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;

public final class SAFHandler extends GenericHandler implements ReliableMessagingConstants {
  private String messageId;
  
  private String sequenceNumber;
  
  private SAFAgent saf;
  
  private ConversationAssembler conversation;
  
  private ReliableDelivery listener;
  
  private FutureResultImpl futureResult;
  
  private int retryCount = -1;
  
  private long retryInterval = -1L;
  
  private long persistDuration = -1L;
  
  private static boolean debug = false;
  
  public void init(HandlerInfo paramHandlerInfo) {
    super.init(paramHandlerInfo);
    debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || "true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.debug")) || debug);
    Map map = paramHandlerInfo.getHandlerConfig();
    if (debug)
      Debug.say("** init called with: " + map); 
    if (map != null) {
      Integer integer1 = (Integer)map.get("retries_param");
      if (integer1 != null)
        this.retryCount = integer1.intValue(); 
      Integer integer2 = (Integer)map.get("retry_interval_param");
      if (integer2 != null)
        this.retryInterval = (integer2.intValue() * 1000); 
      Integer integer3 = (Integer)map.get("persist_interval_param");
      if (integer3 != null)
        this.persistDuration = (integer3.intValue() * 1000); 
    } 
    if (debug)
      Debug.say("== init(): retryCount = " + this.retryCount + "retryInterval  = " + this.retryInterval + "persistDuration  = " + this.persistDuration); 
    this.saf = WSSAFAgent.getSAFAgent();
  }
  
  public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
    if (debug)
      Debug.say("** handleRequest called"); 
    boolean bool1 = false;
    boolean bool2 = false;
    AsyncInfo asyncInfo = null;
    if (paramMessageContext instanceof WLMessageContext) {
      this.listener = (ReliableDelivery)((WLMessageContext)paramMessageContext).getProperty("__BEA_PRIVATE_RELIABLE_PROP");
      if (debug)
        Debug.say("== listener = " + this.listener); 
      this.futureResult = (FutureResultImpl)((WLMessageContext)paramMessageContext).getProperty("__BEA_PRIVATE_FUTURE_RESULT_PROP");
      if (debug)
        Debug.say("== futureResult = " + this.futureResult); 
      if (this.futureResult != null) {
        asyncInfo = this.futureResult.getAsyncInfo();
        if (debug)
          Debug.say("== wsCtx = " + asyncInfo); 
        if (asyncInfo != null) {
          bool2 = asyncInfo.isReliableDelivery();
          bool1 = asyncInfo.isInOrderDelivery();
        } 
      } 
    } 
    try {
      if (this.saf == null)
        throw new JAXRPCException("Reliable SOAP message is not supported"); 
      SOAPElement sOAPElement = generateHeaders(paramMessageContext);
      this.messageId = (String)paramMessageContext.getProperty("__BEA_INTERNAL_MSG_ID");
      SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
      SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
      SOAPPart sOAPPart = sOAPMessage.getSOAPPart();
      SOAPEnvelope sOAPEnvelope = sOAPPart.getEnvelope();
      SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
      if (sOAPHeader == null)
        sOAPHeader = sOAPEnvelope.addHeader(); 
      Iterator iterator = sOAPElement.getChildElements();
      while (iterator.hasNext())
        sOAPHeader.addChildElement((SOAPElement)iterator.next()); 
      ConversationContext conversationContext = (ConversationContext)sOAPMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
      String str1 = null;
      String str2 = null;
      if (conversationContext != null) {
        str1 = conversationContext.getConversationID();
        str2 = conversationContext.getHeaderType();
      } 
      boolean bool = false;
      if (str1 == null || !bool1) {
        str1 = "con" + this.messageId;
        bool = true;
      } 
      this.conversation = (ConversationAssembler)this.saf.getConversation(str1);
      if (this.conversation == null)
        this.conversation = this.saf.createConversation(str1, bool, bool1, this.retryCount, this.retryInterval, this.persistDuration, this.listener); 
      if (bool1) {
        this.sequenceNumber = this.conversation.getNextSequenceNumberString();
        Name name1 = sOAPEnvelope.createName("MessageOrder", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
        Name name2 = sOAPEnvelope.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
        SOAPHeaderElement sOAPHeaderElement = sOAPHeader.addHeaderElement(name1);
        sOAPHeaderElement.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
        sOAPHeaderElement.addAttribute(name2, "1.0");
        sOAPHeaderElement.setMustUnderstand(true);
        SOAPElement sOAPElement1 = sOAPHeaderElement.addChildElement("SequenceNumber", "wsr");
        sOAPElement1.addTextNode(this.sequenceNumber);
        if (debug)
          Debug.say("*** Added  sequenceNumber '" + this.sequenceNumber + "' to MessageOrder header \n" + sOAPHeaderElement + "\n******\n(conversationId=" + str1 + ")***"); 
      } 
      ClientDispatcher clientDispatcher = (ClientDispatcher)sOAPMessageContext.getProperty("weblogic.webservice.core.client-dispatcher");
      if (clientDispatcher != null)
        this.conversation.addClientDispatcher(this.messageId, clientDispatcher); 
      paramMessageContext.setProperty("__BEA_INTERNAL_CONV_ID", str1);
      paramMessageContext.setProperty("__BEA_INTERNAL_SEQ_NUM", this.sequenceNumber);
      paramMessageContext.setProperty("__BEA_INTERNAL_PERSIST_DUR", new Long(this.persistDuration));
      return true;
    } catch (StoreForwardException storeForwardException) {
      throw new JAXRPCException("Failed to store the message", storeForwardException);
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("Failed to store the message", sOAPException);
    } 
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
    if (debug)
      Debug.say("** handleResponse called"); 
    try {
      SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
      SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
      SOAPPart sOAPPart = sOAPMessage.getSOAPPart();
      SOAPEnvelope sOAPEnvelope = sOAPPart.getEnvelope();
      String str1 = getStatus(sOAPEnvelope, true);
      String str2 = getRefToMessageId(sOAPEnvelope);
      if ("OutOfOrder".equals(str1))
        throw new JAXRPCException("Needs retry -- message is out of order"); 
      if ("OK".equals(str1)) {
        if (debug)
          Debug.say("*** Got OK acknowledgement for '" + str2 + "'***"); 
        if (this.listener != null) {
          this.listener.onDeliverySuccess();
          this.listener.onCompletion(new InvokeCompletedEvent(this));
        } 
      } else {
        if ("Dup".equals(str1))
          return false; 
        if (debug)
          Debug.say("*** No OK acknowledgement for '" + this.messageId + "'***"); 
        throw new JAXRPCException("No Acknowledgement headers in the response");
      } 
      cleanupConversation();
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("Failed to handle the response", sOAPException);
    } catch (StoreForwardException storeForwardException) {
      throw new JAXRPCException("Failed to handle the response", storeForwardException);
    } 
    return true;
  }
  
  public boolean handleFault(MessageContext paramMessageContext) throws JAXRPCException {
    if (debug)
      Debug.say("** handleFault called"); 
    if (this.listener != null) {
      this.listener.onDeliveryFailure("Failed to deliver message", "DF_UNKNOWN_CODE");
      this.listener.onCompletion(new ReliableDeliveryFailureEvent("Failed to deliver message"));
    } 
    try {
      cleanupConversation();
    } catch (StoreForwardException storeForwardException) {
      throw new JAXRPCException("Failed to remove a message from store", storeForwardException);
    } 
    return true;
  }
  
  public static Element generateDOMHeaders(MessageContext paramMessageContext) throws StoreForwardException {
    XMLNode xMLNode = (XMLNode)generateHeaders(paramMessageContext);
    XMLInputStream xMLInputStream = xMLNode.stream();
    XMLOutputStreamFactory xMLOutputStreamFactory = XMLOutputStreamFactory.newInstance();
    try {
      DocumentImpl documentImpl = new DocumentImpl();
      XMLOutputStream xMLOutputStream = xMLOutputStreamFactory.newOutputStream(documentImpl);
      xMLOutputStream.add(xMLInputStream);
      xMLOutputStream.flush();
      return documentImpl.getDocumentElement();
    } catch (XMLStreamException xMLStreamException) {
      throw new StoreForwardException("Cannot create RM headers", xMLStreamException);
    } 
  }
  
  private static SOAPElement generateHeaders(MessageContext paramMessageContext) throws StoreForwardException {
    try {
      String str1 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_SOAP_ENV_PREFIX");
      if (str1 == null)
        str1 = SOAPElementImpl.ENV_PREFIX; 
      SOAPFactoryImpl sOAPFactoryImpl = new SOAPFactoryImpl();
      SOAPElement sOAPElement1 = sOAPFactoryImpl.createElement("Header", str1, "http://schemas.xmlsoap.org/soap/envelope/");
      sOAPElement1.addNamespaceDeclaration(str1, "http://schemas.xmlsoap.org/soap/envelope/");
      Name name1 = sOAPFactoryImpl.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name2 = sOAPFactoryImpl.createName("MessageID", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name3 = sOAPFactoryImpl.createName("Version", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name4 = sOAPFactoryImpl.createName("AckRequested", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name5 = sOAPFactoryImpl.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name6 = sOAPFactoryImpl.createName("mustUnderstand", str1, "http://schemas.xmlsoap.org/soap/envelope/");
      WSSAFAgent wSSAFAgent = WSSAFAgent.getSAFAgent();
      if (wSSAFAgent == null)
        throw new StoreForwardException("Store-And-Forward Agent was not initialized properly. Check your config.xml file"); 
      String str2 = wSSAFAgent.getMessageId();
      paramMessageContext.setProperty("__BEA_INTERNAL_MSG_ID", str2);
      SOAPElement sOAPElement2 = sOAPElement1.addChildElement(name1);
      sOAPElement2.addNamespaceDeclaration("wsmd", "http://openuri.org/2002/soap/messagedata/");
      sOAPElement2.addAttribute(name3, "1.0");
      SOAPElement sOAPElement3 = sOAPElement2.addChildElement(name2);
      sOAPElement3.addTextNode(str2);
      SOAPElement sOAPElement4 = sOAPElement1.addChildElement(name4);
      sOAPElement4.addAttribute(name6, "1");
      sOAPElement4.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      sOAPElement4.addAttribute(name5, "1.0");
      if (debug) {
        Debug.say("*** Generated MessageData header ****\n" + sOAPElement2 + "\n*********\n and AckRequested header *****\n" + sOAPElement4 + "\n*******");
        Debug.say("*** Added messageId '" + str2 + "' to AckRequested header***");
      } 
      return sOAPElement1;
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Cannot create RM headers", sOAPException);
    } 
  }
  
  public static void storeAndForwardMessage(MessageContext paramMessageContext) throws StoreForwardException {
    if (debug)
      Debug.say("** storeAndForwardMessage called"); 
    int i = -1;
    long l1 = -1L;
    long l2 = -1L;
    boolean bool1 = false;
    boolean bool = false;
    Object object = null;
    Integer integer1 = (Integer)paramMessageContext.getProperty("retries_param");
    if (integer1 != null)
      i = integer1.intValue(); 
    Integer integer2 = (Integer)paramMessageContext.getProperty("retry_interval_param");
    if (integer2 != null)
      l1 = (integer2.intValue() * 1000); 
    Integer integer3 = (Integer)paramMessageContext.getProperty("persist_interval_param");
    if (integer3 != null)
      l2 = (integer3.intValue() * 1000); 
    ReliableDelivery reliableDelivery = (ReliableDelivery)paramMessageContext.getProperty("__BEA_PRIVATE_RELIABLE_PROP");
    if (debug)
      Debug.say("== listener = " + reliableDelivery); 
    WSSAFAgent wSSAFAgent = WSSAFAgent.getSAFAgent();
    String str1 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_MSG_ID");
    ConversationContext conversationContext = (ConversationContext)paramMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
    String str2 = null;
    String str3 = null;
    if (conversationContext != null) {
      str2 = conversationContext.getConversationID();
      str3 = conversationContext.getHeaderType();
    } 
    boolean bool2 = false;
    if (str2 == null || !bool1) {
      str2 = "con" + str1;
      bool2 = true;
    } 
    ConversationAssembler conversationAssembler = (ConversationAssembler)wSSAFAgent.getConversation(str2);
    if (conversationAssembler == null)
      conversationAssembler = wSSAFAgent.createConversation(str2, bool2, bool1, i, l1, l2, reliableDelivery); 
    ClientDispatcher clientDispatcher = (ClientDispatcher)paramMessageContext.getProperty("weblogic.webservice.core.client-dispatcher");
    if (clientDispatcher != null)
      conversationAssembler.addClientDispatcher(str1, clientDispatcher); 
    wSSAFAgent.store(str1, str2, null, paramMessageContext, reliableDelivery, l2);
    if (debug)
      Debug.say("*** Sucessfully stored the message:  messageId = " + str1 + "***"); 
  }
  
  private void cleanupConversation() {
    if (this.conversation != null && this.conversation.isDone()) {
      this.conversation.close();
      this.saf.removeConversation(this.conversation.getId());
      this.conversation = null;
    } 
  }
  
  static String getStatus(SOAPEnvelope paramSOAPEnvelope, boolean paramBoolean) throws StoreForwardException {
    try {
      SOAPHeader sOAPHeader = paramSOAPEnvelope.getHeader();
      if (sOAPHeader == null)
        sOAPHeader = paramSOAPEnvelope.addHeader(); 
      Name name1 = paramSOAPEnvelope.createName("Acknowledgement", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name2 = paramSOAPEnvelope.createName("Status", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      SOAPElement sOAPElement = Util.getChildSOAPElement(sOAPHeader, name1);
      if (sOAPElement == null) {
        if (debug)
          Debug.say("*** No acknowledgement in SOAPHeader ***"); 
        return null;
      } 
      if (paramBoolean)
        sOAPElement.detachNode(); 
      return sOAPElement.getAttributeValue(name2);
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to get the status in aknowledgement", sOAPException);
    } 
  }
  
  private static String getRefToMessageId(SOAPEnvelope paramSOAPEnvelope) throws StoreForwardException {
    try {
      SOAPHeader sOAPHeader = paramSOAPEnvelope.getHeader();
      if (sOAPHeader == null)
        sOAPHeader = paramSOAPEnvelope.addHeader(); 
      Name name1 = paramSOAPEnvelope.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name2 = paramSOAPEnvelope.createName("RefToMessageID", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      SOAPElement sOAPElement1 = Util.getChildSOAPElement(sOAPHeader, name1);
      if (sOAPElement1 == null) {
        if (debug)
          Debug.say("*** No MessageData in SOAPHeader ***"); 
        throw new StoreForwardException("Could not find MessageData header in aknowledgement.");
      } 
      SOAPElement sOAPElement2 = Util.getChildSOAPElement(sOAPElement1, name2);
      if (sOAPElement2 == null) {
        if (debug)
          Debug.say("*** No RefToMessageID in SOAPHeader ***"); 
        return null;
      } 
      sOAPElement1.detachNode();
      return sOAPElement2.getValue();
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to get the RefTo message id in aknowledgement", sOAPException);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\SAFHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */