/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeader;
/*     */ import javax.xml.soap.SOAPHeaderElement;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import javax.xml.soap.SOAPPart;
/*     */ import org.w3c.dom.Element;
/*     */ import weblogic.apache.xerces.dom.DocumentImpl;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.GenericHandler;
/*     */ import weblogic.webservice.ReliableDelivery;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.async.AsyncInfo;
/*     */ import weblogic.webservice.async.FutureResultImpl;
/*     */ import weblogic.webservice.async.InvokeCompletedEvent;
/*     */ import weblogic.webservice.async.ReliableDeliveryFailureEvent;
/*     */ import weblogic.webservice.core.ClientDispatcher;
/*     */ import weblogic.webservice.core.handler.ConversationContext;
/*     */ import weblogic.webservice.core.soap.SOAPElementImpl;
/*     */ import weblogic.webservice.core.soap.SOAPFactoryImpl;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SAFHandler
/*     */   extends GenericHandler
/*     */   implements ReliableMessagingConstants
/*     */ {
/*     */   private String messageId;
/*     */   private String sequenceNumber;
/*     */   private SAFAgent saf;
/*     */   private ConversationAssembler conversation;
/*     */   private ReliableDelivery listener;
/*     */   private FutureResultImpl futureResult;
/*  73 */   private int retryCount = -1;
/*  74 */   private long retryInterval = -1L;
/*  75 */   private long persistDuration = -1L;
/*     */   
/*     */   private static boolean debug = false;
/*     */   
/*     */   public void init(HandlerInfo paramHandlerInfo) {
/*  80 */     super.init(paramHandlerInfo);
/*     */     
/*  82 */     debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || "true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.debug")) || debug);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     Map map = paramHandlerInfo.getHandlerConfig();
/*     */     
/*  91 */     if (debug) Debug.say("** init called with: " + map);
/*     */     
/*  93 */     if (map != null) {
/*  94 */       Integer integer1 = (Integer)map.get("retries_param");
/*     */       
/*  96 */       if (integer1 != null) {
/*  97 */         this.retryCount = integer1.intValue();
/*     */       }
/*     */       
/* 100 */       Integer integer2 = (Integer)map.get("retry_interval_param");
/*     */       
/* 102 */       if (integer2 != null) {
/* 103 */         this.retryInterval = (integer2.intValue() * 1000);
/*     */       }
/*     */       
/* 106 */       Integer integer3 = (Integer)map.get("persist_interval_param");
/*     */ 
/*     */       
/* 109 */       if (integer3 != null) {
/* 110 */         this.persistDuration = (integer3.intValue() * 1000);
/*     */       }
/*     */     } 
/*     */     
/* 114 */     if (debug) Debug.say("== init(): retryCount = " + this.retryCount + "retryInterval  = " + this.retryInterval + "persistDuration  = " + this.persistDuration);
/*     */ 
/*     */ 
/*     */     
/* 118 */     this.saf = WSSAFAgent.getSAFAgent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
/* 125 */     if (debug) Debug.say("** handleRequest called");
/*     */     
/* 127 */     boolean bool1 = false;
/* 128 */     boolean bool2 = false;
/* 129 */     AsyncInfo asyncInfo = null;
/*     */     
/* 131 */     if (paramMessageContext instanceof WLMessageContext) {
/* 132 */       this.listener = (ReliableDelivery)((WLMessageContext)paramMessageContext).getProperty("__BEA_PRIVATE_RELIABLE_PROP");
/*     */ 
/*     */ 
/*     */       
/* 136 */       if (debug) Debug.say("== listener = " + this.listener);
/*     */       
/* 138 */       this.futureResult = (FutureResultImpl)((WLMessageContext)paramMessageContext).getProperty("__BEA_PRIVATE_FUTURE_RESULT_PROP");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (debug) Debug.say("== futureResult = " + this.futureResult);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 148 */       if (this.futureResult != null) {
/* 149 */         asyncInfo = this.futureResult.getAsyncInfo();
/* 150 */         if (debug) Debug.say("== wsCtx = " + asyncInfo);
/*     */         
/* 152 */         if (asyncInfo != null) {
/* 153 */           bool2 = asyncInfo.isReliableDelivery();
/* 154 */           bool1 = asyncInfo.isInOrderDelivery();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 160 */       if (this.saf == null) {
/* 161 */         throw new JAXRPCException("Reliable SOAP message is not supported");
/*     */       }
/*     */       
/* 164 */       SOAPElement sOAPElement = generateHeaders(paramMessageContext);
/* 165 */       this.messageId = (String)paramMessageContext.getProperty("__BEA_INTERNAL_MSG_ID");
/*     */ 
/*     */       
/* 168 */       SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/* 169 */       SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 170 */       SOAPPart sOAPPart = sOAPMessage.getSOAPPart();
/* 171 */       SOAPEnvelope sOAPEnvelope = sOAPPart.getEnvelope();
/* 172 */       SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
/*     */       
/* 174 */       if (sOAPHeader == null) {
/* 175 */         sOAPHeader = sOAPEnvelope.addHeader();
/*     */       }
/*     */       
/* 178 */       Iterator iterator = sOAPElement.getChildElements();
/* 179 */       while (iterator.hasNext()) {
/* 180 */         sOAPHeader.addChildElement((SOAPElement)iterator.next());
/*     */       }
/*     */ 
/*     */       
/* 184 */       ConversationContext conversationContext = (ConversationContext)sOAPMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 189 */       String str1 = null;
/* 190 */       String str2 = null;
/*     */       
/* 192 */       if (conversationContext != null) {
/* 193 */         str1 = conversationContext.getConversationID();
/* 194 */         str2 = conversationContext.getHeaderType();
/*     */       } 
/*     */       
/* 197 */       boolean bool = false;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 202 */       if (str1 == null || !bool1) {
/* 203 */         str1 = "con" + this.messageId;
/* 204 */         bool = true;
/*     */       } 
/*     */       
/* 207 */       this.conversation = (ConversationAssembler)this.saf.getConversation(str1);
/*     */ 
/*     */       
/* 210 */       if (this.conversation == null) {
/* 211 */         this.conversation = this.saf.createConversation(str1, bool, bool1, this.retryCount, this.retryInterval, this.persistDuration, this.listener);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 218 */       if (bool1) {
/*     */         
/* 220 */         this.sequenceNumber = this.conversation.getNextSequenceNumberString();
/*     */         
/* 222 */         Name name1 = sOAPEnvelope.createName("MessageOrder", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 223 */         Name name2 = sOAPEnvelope.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/*     */         
/* 225 */         SOAPHeaderElement sOAPHeaderElement = sOAPHeader.addHeaderElement(name1);
/* 226 */         sOAPHeaderElement.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 227 */         sOAPHeaderElement.addAttribute(name2, "1.0");
/* 228 */         sOAPHeaderElement.setMustUnderstand(true);
/* 229 */         SOAPElement sOAPElement1 = sOAPHeaderElement.addChildElement("SequenceNumber", "wsr");
/* 230 */         sOAPElement1.addTextNode(this.sequenceNumber);
/*     */         
/* 232 */         if (debug) {
/* 233 */           Debug.say("*** Added  sequenceNumber '" + this.sequenceNumber + "' to MessageOrder header \n" + sOAPHeaderElement + "\n******\n(conversationId=" + str1 + ")***");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 242 */       ClientDispatcher clientDispatcher = (ClientDispatcher)sOAPMessageContext.getProperty("weblogic.webservice.core.client-dispatcher");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 247 */       if (clientDispatcher != null) {
/* 248 */         this.conversation.addClientDispatcher(this.messageId, clientDispatcher);
/*     */       }
/*     */ 
/*     */       
/* 252 */       paramMessageContext.setProperty("__BEA_INTERNAL_CONV_ID", str1);
/* 253 */       paramMessageContext.setProperty("__BEA_INTERNAL_SEQ_NUM", this.sequenceNumber);
/* 254 */       paramMessageContext.setProperty("__BEA_INTERNAL_PERSIST_DUR", new Long(this.persistDuration));
/*     */       
/* 256 */       return true;
/*     */     }
/* 258 */     catch (StoreForwardException storeForwardException) {
/* 259 */       throw new JAXRPCException("Failed to store the message", storeForwardException);
/* 260 */     } catch (SOAPException sOAPException) {
/* 261 */       throw new JAXRPCException("Failed to store the message", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
/* 267 */     if (debug) Debug.say("** handleResponse called");
/*     */     
/*     */     try {
/* 270 */       SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/* 271 */       SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 272 */       SOAPPart sOAPPart = sOAPMessage.getSOAPPart();
/* 273 */       SOAPEnvelope sOAPEnvelope = sOAPPart.getEnvelope();
/*     */       
/* 275 */       String str1 = getStatus(sOAPEnvelope, true);
/* 276 */       String str2 = getRefToMessageId(sOAPEnvelope);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 285 */       if ("OutOfOrder".equals(str1)) {
/* 286 */         throw new JAXRPCException("Needs retry -- message is out of order");
/*     */       }
/*     */       
/* 289 */       if ("OK".equals(str1)) {
/* 290 */         if (debug) {
/* 291 */           Debug.say("*** Got OK acknowledgement for '" + str2 + "'***");
/*     */         }
/*     */ 
/*     */         
/* 295 */         if (this.listener != null) {
/* 296 */           this.listener.onDeliverySuccess();
/* 297 */           this.listener.onCompletion(new InvokeCompletedEvent(this));
/*     */         } 
/*     */       } else {
/* 300 */         if ("Dup".equals(str1)) {
/* 301 */           return false;
/*     */         }
/*     */ 
/*     */         
/* 305 */         if (debug) {
/* 306 */           Debug.say("*** No OK acknowledgement for '" + this.messageId + "'***");
/*     */         }
/*     */         
/* 309 */         throw new JAXRPCException("No Acknowledgement headers in the response");
/*     */       } 
/*     */ 
/*     */       
/* 313 */       cleanupConversation();
/*     */     }
/* 315 */     catch (SOAPException sOAPException) {
/* 316 */       throw new JAXRPCException("Failed to handle the response", sOAPException);
/* 317 */     } catch (StoreForwardException storeForwardException) {
/* 318 */       throw new JAXRPCException("Failed to handle the response", storeForwardException);
/*     */     } 
/*     */     
/* 321 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handleFault(MessageContext paramMessageContext) throws JAXRPCException {
/* 326 */     if (debug) Debug.say("** handleFault called");
/*     */ 
/*     */ 
/*     */     
/* 330 */     if (this.listener != null) {
/* 331 */       this.listener.onDeliveryFailure("Failed to deliver message", "DF_UNKNOWN_CODE");
/*     */       
/* 333 */       this.listener.onCompletion(new ReliableDeliveryFailureEvent("Failed to deliver message"));
/*     */     } 
/*     */     
/*     */     try {
/* 337 */       cleanupConversation();
/* 338 */     } catch (StoreForwardException storeForwardException) {
/* 339 */       throw new JAXRPCException("Failed to remove a message from store", storeForwardException);
/*     */     } 
/* 341 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Element generateDOMHeaders(MessageContext paramMessageContext) throws StoreForwardException {
/* 348 */     XMLNode xMLNode = (XMLNode)generateHeaders(paramMessageContext);
/*     */     
/* 350 */     XMLInputStream xMLInputStream = xMLNode.stream();
/* 351 */     XMLOutputStreamFactory xMLOutputStreamFactory = XMLOutputStreamFactory.newInstance();
/*     */     
/*     */     try {
/* 354 */       DocumentImpl documentImpl = new DocumentImpl();
/* 355 */       XMLOutputStream xMLOutputStream = xMLOutputStreamFactory.newOutputStream(documentImpl);
/* 356 */       xMLOutputStream.add(xMLInputStream);
/* 357 */       xMLOutputStream.flush();
/*     */       
/* 359 */       return documentImpl.getDocumentElement();
/* 360 */     } catch (XMLStreamException xMLStreamException) {
/* 361 */       throw new StoreForwardException("Cannot create RM headers", xMLStreamException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static SOAPElement generateHeaders(MessageContext paramMessageContext) throws StoreForwardException {
/*     */     try {
/* 369 */       String str1 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_SOAP_ENV_PREFIX");
/* 370 */       if (str1 == null) str1 = SOAPElementImpl.ENV_PREFIX;
/*     */       
/* 372 */       SOAPFactoryImpl sOAPFactoryImpl = new SOAPFactoryImpl();
/*     */       
/* 374 */       SOAPElement sOAPElement1 = sOAPFactoryImpl.createElement("Header", str1, "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */       
/* 377 */       sOAPElement1.addNamespaceDeclaration(str1, "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */ 
/*     */       
/* 381 */       Name name1 = sOAPFactoryImpl.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 382 */       Name name2 = sOAPFactoryImpl.createName("MessageID", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 383 */       Name name3 = sOAPFactoryImpl.createName("Version", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 384 */       Name name4 = sOAPFactoryImpl.createName("AckRequested", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 385 */       Name name5 = sOAPFactoryImpl.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 386 */       Name name6 = sOAPFactoryImpl.createName("mustUnderstand", str1, "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 391 */       WSSAFAgent wSSAFAgent = WSSAFAgent.getSAFAgent();
/* 392 */       if (wSSAFAgent == null) {
/* 393 */         throw new StoreForwardException("Store-And-Forward Agent was not initialized properly. Check your config.xml file");
/*     */       }
/*     */ 
/*     */       
/* 397 */       String str2 = wSSAFAgent.getMessageId();
/* 398 */       paramMessageContext.setProperty("__BEA_INTERNAL_MSG_ID", str2);
/*     */ 
/*     */       
/* 401 */       SOAPElement sOAPElement2 = sOAPElement1.addChildElement(name1);
/* 402 */       sOAPElement2.addNamespaceDeclaration("wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 403 */       sOAPElement2.addAttribute(name3, "1.0");
/* 404 */       SOAPElement sOAPElement3 = sOAPElement2.addChildElement(name2);
/* 405 */       sOAPElement3.addTextNode(str2);
/*     */       
/* 407 */       SOAPElement sOAPElement4 = sOAPElement1.addChildElement(name4);
/* 408 */       sOAPElement4.addAttribute(name6, "1");
/* 409 */       sOAPElement4.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 410 */       sOAPElement4.addAttribute(name5, "1.0");
/*     */       
/* 412 */       if (debug) {
/* 413 */         Debug.say("*** Generated MessageData header ****\n" + sOAPElement2 + "\n*********\n and AckRequested header *****\n" + sOAPElement4 + "\n*******");
/*     */         
/* 415 */         Debug.say("*** Added messageId '" + str2 + "' to AckRequested header***");
/*     */       } 
/*     */       
/* 418 */       return sOAPElement1;
/* 419 */     } catch (SOAPException sOAPException) {
/* 420 */       throw new StoreForwardException("Cannot create RM headers", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void storeAndForwardMessage(MessageContext paramMessageContext) throws StoreForwardException {
/* 427 */     if (debug) Debug.say("** storeAndForwardMessage called");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     int i = -1;
/* 435 */     long l1 = -1L;
/* 436 */     long l2 = -1L;
/*     */     
/* 438 */     boolean bool1 = false;
/* 439 */     boolean bool = false;
/* 440 */     Object object = null;
/*     */ 
/*     */     
/* 443 */     Integer integer1 = (Integer)paramMessageContext.getProperty("retries_param");
/*     */     
/* 445 */     if (integer1 != null) {
/* 446 */       i = integer1.intValue();
/*     */     }
/*     */     
/* 449 */     Integer integer2 = (Integer)paramMessageContext.getProperty("retry_interval_param");
/*     */     
/* 451 */     if (integer2 != null) {
/* 452 */       l1 = (integer2.intValue() * 1000);
/*     */     }
/*     */     
/* 455 */     Integer integer3 = (Integer)paramMessageContext.getProperty("persist_interval_param");
/*     */     
/* 457 */     if (integer3 != null) {
/* 458 */       l2 = (integer3.intValue() * 1000);
/*     */     }
/*     */     
/* 461 */     ReliableDelivery reliableDelivery = (ReliableDelivery)paramMessageContext.getProperty("__BEA_PRIVATE_RELIABLE_PROP");
/*     */ 
/*     */     
/* 464 */     if (debug) Debug.say("== listener = " + reliableDelivery);
/*     */     
/* 466 */     WSSAFAgent wSSAFAgent = WSSAFAgent.getSAFAgent();
/*     */     
/* 468 */     String str1 = (String)paramMessageContext.getProperty("__BEA_INTERNAL_MSG_ID");
/*     */ 
/*     */     
/* 471 */     ConversationContext conversationContext = (ConversationContext)paramMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 476 */     String str2 = null;
/* 477 */     String str3 = null;
/*     */     
/* 479 */     if (conversationContext != null) {
/* 480 */       str2 = conversationContext.getConversationID();
/* 481 */       str3 = conversationContext.getHeaderType();
/*     */     } 
/*     */     
/* 484 */     boolean bool2 = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 489 */     if (str2 == null || !bool1) {
/* 490 */       str2 = "con" + str1;
/* 491 */       bool2 = true;
/*     */     } 
/*     */     
/* 494 */     ConversationAssembler conversationAssembler = (ConversationAssembler)wSSAFAgent.getConversation(str2);
/*     */ 
/*     */     
/* 497 */     if (conversationAssembler == null) {
/* 498 */       conversationAssembler = wSSAFAgent.createConversation(str2, bool2, bool1, i, l1, l2, reliableDelivery);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 506 */     ClientDispatcher clientDispatcher = (ClientDispatcher)paramMessageContext.getProperty("weblogic.webservice.core.client-dispatcher");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 511 */     if (clientDispatcher != null) {
/* 512 */       conversationAssembler.addClientDispatcher(str1, clientDispatcher);
/*     */     }
/* 514 */     wSSAFAgent.store(str1, str2, null, paramMessageContext, reliableDelivery, l2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 523 */     if (debug) {
/* 524 */       Debug.say("*** Sucessfully stored the message:  messageId = " + str1 + "***");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanupConversation() {
/* 534 */     if (this.conversation != null && this.conversation.isDone()) {
/* 535 */       this.conversation.close();
/* 536 */       this.saf.removeConversation(this.conversation.getId());
/* 537 */       this.conversation = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static String getStatus(SOAPEnvelope paramSOAPEnvelope, boolean paramBoolean) throws StoreForwardException {
/*     */     try {
/* 545 */       SOAPHeader sOAPHeader = paramSOAPEnvelope.getHeader();
/*     */       
/* 547 */       if (sOAPHeader == null) {
/* 548 */         sOAPHeader = paramSOAPEnvelope.addHeader();
/*     */       }
/*     */       
/* 551 */       Name name1 = paramSOAPEnvelope.createName("Acknowledgement", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 552 */       Name name2 = paramSOAPEnvelope.createName("Status", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/*     */ 
/*     */       
/* 555 */       SOAPElement sOAPElement = Util.getChildSOAPElement(sOAPHeader, name1);
/* 556 */       if (sOAPElement == null) {
/*     */         
/* 558 */         if (debug) {
/* 559 */           Debug.say("*** No acknowledgement in SOAPHeader ***");
/*     */         }
/* 561 */         return null;
/*     */       } 
/* 563 */       if (paramBoolean) {
/* 564 */         sOAPElement.detachNode();
/*     */       }
/* 566 */       return sOAPElement.getAttributeValue(name2);
/*     */     }
/* 568 */     catch (SOAPException sOAPException) {
/* 569 */       throw new StoreForwardException("Failed to get the status in aknowledgement", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getRefToMessageId(SOAPEnvelope paramSOAPEnvelope) throws StoreForwardException {
/*     */     try {
/* 577 */       SOAPHeader sOAPHeader = paramSOAPEnvelope.getHeader();
/*     */       
/* 579 */       if (sOAPHeader == null) {
/* 580 */         sOAPHeader = paramSOAPEnvelope.addHeader();
/*     */       }
/*     */       
/* 583 */       Name name1 = paramSOAPEnvelope.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 584 */       Name name2 = paramSOAPEnvelope.createName("RefToMessageID", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/*     */ 
/*     */       
/* 587 */       SOAPElement sOAPElement1 = Util.getChildSOAPElement(sOAPHeader, name1);
/* 588 */       if (sOAPElement1 == null) {
/* 589 */         if (debug) {
/* 590 */           Debug.say("*** No MessageData in SOAPHeader ***");
/*     */         }
/* 592 */         throw new StoreForwardException("Could not find MessageData header in aknowledgement.");
/*     */       } 
/* 594 */       SOAPElement sOAPElement2 = Util.getChildSOAPElement(sOAPElement1, name2);
/* 595 */       if (sOAPElement2 == null) {
/*     */         
/* 597 */         if (debug) {
/* 598 */           Debug.say("*** No RefToMessageID in SOAPHeader ***");
/*     */         }
/* 600 */         return null;
/*     */       } 
/* 602 */       sOAPElement1.detachNode();
/* 603 */       return sOAPElement2.getValue();
/*     */     }
/* 605 */     catch (SOAPException sOAPException) {
/* 606 */       throw new StoreForwardException("Failed to get the RefTo message id in aknowledgement", sOAPException);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\SAFHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */