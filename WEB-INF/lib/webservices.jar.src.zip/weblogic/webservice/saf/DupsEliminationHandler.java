/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.transaction.NotSupportedException;
/*     */ import javax.transaction.RollbackException;
/*     */ import javax.transaction.Synchronization;
/*     */ import javax.transaction.SystemException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.handler.HandlerInfo;
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ import javax.xml.rpc.handler.soap.SOAPMessageContext;
/*     */ import javax.xml.rpc.soap.SOAPFaultException;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPEnvelope;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.soap.SOAPHeader;
/*     */ import javax.xml.soap.SOAPHeaderElement;
/*     */ import javax.xml.soap.SOAPMessage;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import weblogic.transaction.TransactionManager;
/*     */ import weblogic.transaction.TxHelper;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.GenericHandler;
/*     */ import weblogic.webservice.WLMessageContext;
/*     */ import weblogic.webservice.core.handler.ConversationContext;
/*     */ import weblogic.webservice.core.soap.SOAPFactoryImpl;
/*     */ import weblogic.webservice.util.FaultUtil;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DupsEliminationHandler
/*     */   extends GenericHandler
/*     */   implements Synchronization, ReliableMessagingConstants
/*     */ {
/*     */   public static final String DUPS_ELIMINATION_PARAM = "dup_elim_param";
/*     */   public static final String RETRIES_PARAM = "retries_param";
/*     */   public static final String RETRY_INTERVAL_PARAM = "retry_interval_param";
/*     */   public static final String PERSIST_INTERVAL_PARAM = "persist_interval_param";
/*     */   public static final String IN_ORDER_DELIVERY_PARAM = "in_order_delivery_param";
/*     */   private static final String RM_RESULT_STATUS_PROP = "__BEA_PRIVATE_RM_RESULT_STATUS_PROP";
/*     */   private static final String MSG_ID_PROP = "__BEA_PRIVATE_RM_MSG_ID_PROP";
/*     */   private static final String ACK_NOT_REQED = "AckNotRequired";
/*     */   private static final String STATUS_DUP = "Duplicate";
/*     */   private static final String STATUS_OUTOFORDER = "OutOfOrder";
/*     */   private static final String STATUS_OK = "OK";
/*     */   private String messageId;
/*     */   private String sequenceNumber;
/*     */   private DupsEliminationAgent dupsEliminationAgent;
/*     */   private ConversationReassembler conversation;
/*     */   private boolean dupsEliminationRequested;
/*     */   private boolean inorder;
/*     */   private TransactionManager tm;
/*  97 */   private long persistDuration = -2L;
/*     */   
/*     */   private static boolean debug = false;
/*     */   
/*     */   public void init(HandlerInfo paramHandlerInfo) {
/* 102 */     super.init(paramHandlerInfo);
/*     */     
/* 104 */     debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.debug")) || "true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     Map map = paramHandlerInfo.getHandlerConfig();
/*     */     
/* 113 */     if (debug) Debug.say("** init called with: " + map);
/*     */     
/* 115 */     Boolean bool1 = (Boolean)map.get("dup_elim_param");
/* 116 */     if (bool1 != null) {
/* 117 */       this.dupsEliminationRequested = bool1.booleanValue();
/*     */       
/* 119 */       if (debug) {
/* 120 */         Debug.say("dupsEliminationRequested = " + this.dupsEliminationRequested);
/*     */       }
/*     */     } 
/* 123 */     Integer integer = (Integer)map.get("persist_interval_param");
/* 124 */     if (integer != null) {
/* 125 */       this.persistDuration = (integer.intValue() * 1000);
/*     */       
/* 127 */       if (debug) Debug.say("persistDuration  = " + this.persistDuration);
/*     */     
/*     */     } 
/* 130 */     Boolean bool2 = (Boolean)map.get("in_order_delivery_param");
/* 131 */     if (bool2 != null) {
/* 132 */       this.inorder = bool2.booleanValue();
/* 133 */       if (debug) Debug.say("inorder  = " + this.inorder);
/*     */     
/*     */     } 
/* 136 */     this.dupsEliminationAgent = WSDupsEliminationAgent.getDupsEliminationAgent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
/* 141 */     if (debug) Debug.say("** handleRequest called, messagecontext = " + paramMessageContext);
/*     */     
/* 143 */     WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
/* 144 */     SOAPMessage sOAPMessage = wLMessageContext.getMessage();
/*     */     
/* 146 */     SOAPEnvelope sOAPEnvelope = null;
/* 147 */     SOAPHeader sOAPHeader = null;
/*     */ 
/*     */     
/*     */     try {
/* 151 */       sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
/* 152 */       sOAPHeader = sOAPEnvelope.getHeader();
/*     */       
/* 154 */       if (sOAPHeader == null) {
/* 155 */         sOAPHeader = sOAPEnvelope.addHeader();
/*     */       }
/*     */ 
/*     */       
/* 159 */       Name name1 = sOAPEnvelope.createName("AckRequested", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 160 */       SOAPElement sOAPElement1 = Util.getChildSOAPElement(sOAPHeader, name1);
/* 161 */       if (sOAPElement1 == null) {
/*     */         
/* 163 */         wLMessageContext.setProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP", "AckNotRequired");
/* 164 */         return true;
/*     */       } 
/* 166 */       sOAPElement1.detachNode();
/*     */       
/* 168 */       Name name2 = sOAPEnvelope.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 169 */       SOAPElement sOAPElement2 = Util.getChildSOAPElement(sOAPHeader, name2);
/* 170 */       if (sOAPElement2 == null)
/*     */       {
/* 172 */         throw new JAXRPCException("Could not find MessageData header");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 177 */       Name name3 = sOAPEnvelope.createName("MessageID", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 178 */       SOAPElement sOAPElement3 = Util.getChildSOAPElement(sOAPElement2, name3);
/* 179 */       if (sOAPElement3 == null)
/*     */       {
/* 181 */         throw new JAXRPCException("Could not find MessageId element in MessageData header");
/*     */       }
/*     */ 
/*     */       
/* 185 */       this.messageId = sOAPElement3.getValue();
/* 186 */       wLMessageContext.setProperty("__BEA_PRIVATE_RM_MSG_ID_PROP", this.messageId);
/*     */       
/* 188 */       if (this.inorder) {
/* 189 */         Name name4 = sOAPEnvelope.createName("MessageOrder", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 190 */         SOAPElement sOAPElement4 = Util.getChildSOAPElement(sOAPHeader, name4);
/* 191 */         if (sOAPElement4 == null)
/*     */         {
/* 193 */           throw new JAXRPCException("Could not find MessageOrder header");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 198 */         Name name5 = sOAPEnvelope.createName("SequenceNumber", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 199 */         SOAPElement sOAPElement5 = Util.getChildSOAPElement(sOAPElement4, name5);
/* 200 */         if (sOAPElement5 == null)
/*     */         {
/* 202 */           throw new JAXRPCException("Could not find SequenceNumber element in MessageOrder header");
/*     */         }
/*     */ 
/*     */         
/* 206 */         this.sequenceNumber = sOAPElement5.getValue();
/* 207 */         sOAPElement4.detachNode();
/*     */       } 
/* 209 */       sOAPElement2.detachNode();
/*     */       
/* 211 */       if (debug) {
/* 212 */         Debug.say("*** Found messageId '" + this.messageId + "' and sequenceNumber '" + this.sequenceNumber + "' in AckRequested header***");
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 217 */     catch (SOAPException sOAPException) {
/* 218 */       throw new JAXRPCException("Failed to access the SOAP header" + sOAPException);
/*     */     } 
/*     */ 
/*     */     
/* 222 */     if (this.dupsEliminationRequested) {
/* 223 */       if (this.dupsEliminationAgent == null) {
/* 224 */         throw new JAXRPCException("Internal error: Could not find the reliable agent");
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 230 */         this.dupsEliminationAgent.waitForStart();
/* 231 */       } catch (StoreForwardException storeForwardException) {
/* 232 */         throw new JAXRPCException("Failed to start the reliable agent");
/*     */       } 
/*     */ 
/*     */       
/* 236 */       if (this.dupsEliminationAgent.isDuplicate(this.messageId)) {
/*     */         
/* 238 */         wLMessageContext.setProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP", "Duplicate");
/* 239 */         wLMessageContext.clearMessage();
/*     */ 
/*     */         
/* 242 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 246 */     ConversationContext conversationContext = (ConversationContext)wLMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
/*     */     
/* 248 */     String str1 = null;
/* 249 */     String str2 = null;
/* 250 */     if (conversationContext != null) {
/* 251 */       str1 = conversationContext.getConversationID();
/* 252 */       str2 = conversationContext.getHeaderType();
/*     */     } 
/*     */ 
/*     */     
/* 256 */     if (str1 != null && this.inorder) {
/* 257 */       this.conversation = (ConversationReassembler)this.dupsEliminationAgent.getConversation(str1);
/*     */ 
/*     */       
/* 260 */       if (this.conversation == null) {
/* 261 */         if ("StartHeader".equals(str2)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 267 */           this.conversation = this.dupsEliminationAgent.createConversation(str1, true);
/*     */         }
/* 269 */         else if ("FinishHeader".equals(str2)) {
/*     */           
/* 271 */           this.conversation.setSeenLastMsg(true);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 276 */     if (this.conversation != null && this.conversation.isOrdered()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 281 */       int i = Integer.parseInt(this.sequenceNumber);
/*     */       
/* 283 */       if (i != this.conversation.getExpectedSequenceNumber()) {
/* 284 */         if (debug) {
/* 285 */           Debug.say("== Message: " + this.messageId + " is out of order");
/*     */         }
/* 287 */         wLMessageContext.setProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP", "OutOfOrder");
/* 288 */         wLMessageContext.clearMessage();
/*     */         
/* 290 */         String str = "Expected sequence number: '" + this.conversation.getExpectedSequenceNumber() + "' but received '" + i + "'";
/*     */ 
/*     */ 
/*     */         
/* 294 */         throw new SOAPFaultException(OUT_OF_ORDER_FAULT, "Message is out of order", str, FaultUtil.newDetail(new StoreForwardException(str)));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 301 */       this.conversation.updateExpectedSequenceNumber(i + 1);
/*     */     } 
/*     */ 
/*     */     
/* 305 */     if (this.dupsEliminationRequested) {
/*     */       try {
/* 307 */         this.tm = TxHelper.getTransactionManager();
/* 308 */         this.tm.begin();
/*     */ 
/*     */         
/* 311 */         this.tm.getTransaction().registerSynchronization(this);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 316 */         boolean bool = !storeHistoryRecord(this.messageId, this.persistDuration) ? 1 : 0;
/*     */         
/* 318 */         if (bool)
/*     */         {
/* 320 */           wLMessageContext.setProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP", "Duplicate");
/* 321 */           wLMessageContext.clearMessage();
/*     */ 
/*     */           
/* 324 */           this.tm.rollback();
/* 325 */           this.tm = null;
/*     */ 
/*     */           
/* 328 */           return false;
/*     */         }
/*     */       
/* 331 */       } catch (SystemException systemException) {
/*     */         
/* 333 */         throw new JAXRPCException("Failed to save the history record", systemException);
/* 334 */       } catch (RollbackException rollbackException) {
/*     */         
/* 336 */         throw new JAXRPCException("Failed to save the history record", rollbackException);
/* 337 */       } catch (NotSupportedException notSupportedException) {
/* 338 */         throw new JAXRPCException("Failed to save the history record", notSupportedException);
/* 339 */       } catch (StoreForwardException storeForwardException) {
/* 340 */         throw new JAXRPCException("Failed to save the history record", storeForwardException);
/*     */       } 
/*     */     }
/*     */     
/* 344 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
/* 349 */     SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     
/* 351 */     if (debug) Debug.say("** handleResponse called");
/*     */     
/* 353 */     String str = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP");
/* 354 */     if ("AckNotRequired".equals(str))
/*     */     {
/* 356 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 360 */     if (this.tm != null && !"Duplicate".equals(str) && !"OutOfOrder".equals(str)) {
/*     */       
/*     */       try {
/* 363 */         int i = this.tm.getStatus();
/* 364 */         if (i == 1 || i == 4 || i == 9)
/*     */         {
/*     */           
/* 367 */           return true;
/*     */         }
/* 369 */       } catch (SystemException systemException) {}
/*     */     }
/*     */     
/*     */     try {
/* 373 */       SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 374 */       SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
/* 375 */       SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
/*     */       
/* 377 */       if (sOAPHeader == null) {
/* 378 */         sOAPHeader = sOAPEnvelope.addHeader();
/*     */       }
/*     */       
/* 381 */       this.messageId = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_MSG_ID_PROP");
/*     */ 
/*     */ 
/*     */       
/* 385 */       Name name1 = sOAPEnvelope.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 386 */       Name name2 = sOAPEnvelope.createName("Version", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 387 */       Name name3 = sOAPEnvelope.createName("Acknowledgement", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 388 */       Name name4 = sOAPEnvelope.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 389 */       Name name5 = sOAPEnvelope.createName("Status", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 394 */       SOAPElement sOAPElement1 = Util.getChildSOAPElement(sOAPHeader, name1);
/* 395 */       if (sOAPElement1 == null)
/* 396 */         sOAPElement1 = sOAPHeader.addHeaderElement(name1); 
/* 397 */       sOAPElement1.addNamespaceDeclaration("wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 398 */       sOAPElement1.addAttribute(name2, "1.0");
/* 399 */       SOAPElement sOAPElement2 = sOAPElement1.addChildElement("RefToMessageID", "wsmd");
/* 400 */       sOAPElement2.addTextNode(this.messageId);
/*     */ 
/*     */ 
/*     */       
/* 404 */       SOAPHeaderElement sOAPHeaderElement = sOAPHeader.addHeaderElement(name3);
/* 405 */       sOAPHeaderElement.setMustUnderstand(true);
/* 406 */       sOAPHeaderElement.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 407 */       sOAPHeaderElement.addAttribute(name4, "1.0");
/*     */ 
/*     */       
/* 410 */       String str1 = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP");
/* 411 */       if ("Duplicate".equals(str1)) {
/* 412 */         sOAPHeaderElement.addAttribute(name5, "Duplicate");
/*     */ 
/*     */         
/* 415 */         if (this.tm != null) {
/*     */           try {
/* 417 */             this.tm.rollback();
/* 418 */             this.tm = null;
/* 419 */           } catch (SystemException systemException) {}
/*     */         
/*     */         }
/*     */       }
/* 423 */       else if ("OutOfOrder".equals(str1)) {
/* 424 */         sOAPHeaderElement.addAttribute(name5, "OutOfOrder");
/*     */ 
/*     */         
/* 427 */         if (this.tm != null) {
/*     */           try {
/* 429 */             this.tm.rollback();
/* 430 */             this.dupsEliminationAgent.removeHistoryRecordInMemoryOnly(this.messageId);
/* 431 */             this.tm = null;
/* 432 */           } catch (SystemException systemException) {}
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 437 */         sOAPHeaderElement.addAttribute(name5, "OK");
/*     */ 
/*     */         
/* 440 */         if (this.tm != null) {
/*     */           try {
/* 442 */             this.tm.commit();
/* 443 */             this.tm = null;
/* 444 */           } catch (Exception exception) {}
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 461 */         if (this.conversation != null && this.conversation.isDone()) {
/* 462 */           this.conversation.close();
/* 463 */           if (this.dupsEliminationAgent != null) {
/* 464 */             this.dupsEliminationAgent.removeConversation(this.conversation.getId());
/*     */           }
/* 466 */           this.conversation = null;
/*     */         } 
/*     */       } 
/* 469 */     } catch (SOAPException sOAPException) {
/* 470 */       if (this.tm != null) {
/*     */         try {
/* 472 */           this.tm.rollback();
/* 473 */           this.tm = null;
/* 474 */         } catch (SystemException systemException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 480 */       throw new JAXRPCException("Failed to handle response", sOAPException);
/*     */     } 
/*     */     
/* 483 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handleFault(MessageContext paramMessageContext) throws JAXRPCException {
/* 488 */     if (debug) Debug.say("** handleFault called");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 495 */     SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
/*     */     
/* 497 */     String str = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP");
/* 498 */     if ("AckNotRequired".equals(str))
/*     */     {
/* 500 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 504 */     if (this.tm != null && !"Duplicate".equals(str) && !"OutOfOrder".equals(str)) {
/*     */       
/*     */       try {
/* 507 */         int i = this.tm.getStatus();
/* 508 */         if (i == 1 || i == 4 || i == 9)
/*     */         {
/*     */           
/* 511 */           return true;
/*     */         }
/* 513 */       } catch (SystemException systemException) {}
/*     */     }
/*     */     
/*     */     try {
/* 517 */       SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
/* 518 */       SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
/* 519 */       SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
/*     */       
/* 521 */       if (sOAPHeader == null) {
/* 522 */         sOAPHeader = sOAPEnvelope.addHeader();
/*     */       }
/*     */       
/* 525 */       this.messageId = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_MSG_ID_PROP");
/*     */ 
/*     */ 
/*     */       
/* 529 */       Name name1 = sOAPEnvelope.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 530 */       Name name2 = sOAPEnvelope.createName("Version", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 531 */       Name name3 = sOAPEnvelope.createName("Acknowledgement", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 532 */       Name name4 = sOAPEnvelope.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 533 */       Name name5 = sOAPEnvelope.createName("Status", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 538 */       SOAPElement sOAPElement1 = Util.getChildSOAPElement(sOAPHeader, name1);
/* 539 */       if (sOAPElement1 == null)
/* 540 */         sOAPElement1 = sOAPHeader.addHeaderElement(name1); 
/* 541 */       sOAPElement1.addNamespaceDeclaration("wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 542 */       sOAPElement1.addAttribute(name2, "1.0");
/* 543 */       SOAPElement sOAPElement2 = sOAPElement1.addChildElement("RefToMessageID", "wsmd");
/* 544 */       sOAPElement2.addTextNode(this.messageId);
/*     */ 
/*     */       
/* 547 */       SOAPHeaderElement sOAPHeaderElement = sOAPHeader.addHeaderElement(name3);
/* 548 */       sOAPHeaderElement.setMustUnderstand(true);
/* 549 */       sOAPHeaderElement.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 550 */       sOAPHeaderElement.addAttribute(name4, "1.0");
/*     */ 
/*     */       
/* 553 */       String str1 = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP");
/* 554 */       if ("OutOfOrder".equals(str1)) {
/* 555 */         sOAPHeaderElement.addAttribute(name5, "OutOfOrder");
/*     */ 
/*     */         
/* 558 */         if (this.tm != null) {
/*     */           try {
/* 560 */             this.tm.rollback();
/* 561 */             this.dupsEliminationAgent.removeHistoryRecordInMemoryOnly(this.messageId);
/* 562 */             this.tm = null;
/* 563 */           } catch (SystemException systemException) {}
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 568 */         sOAPHeaderElement.addAttribute(name5, "OK");
/* 569 */         if (this.tm != null) {
/*     */           try {
/* 571 */             this.tm.commit();
/* 572 */             this.tm = null;
/* 573 */           } catch (Exception exception) {}
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 591 */       if (this.conversation != null && this.conversation.isDone()) {
/* 592 */         this.conversation.close();
/* 593 */         if (this.dupsEliminationAgent != null) {
/* 594 */           this.dupsEliminationAgent.removeConversation(this.conversation.getId());
/*     */         }
/* 596 */         this.conversation = null;
/*     */       } 
/* 598 */     } catch (SOAPException sOAPException) {
/* 599 */       if (this.tm != null) {
/*     */         try {
/* 601 */           this.tm.rollback();
/* 602 */           this.tm = null;
/* 603 */         } catch (SystemException systemException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 609 */       throw new JAXRPCException("Failed to handle response", sOAPException);
/*     */     } 
/*     */     
/* 612 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DupsEliminationResult checkForDups(Element[] paramArrayOfElement, long paramLong) {
/*     */     try {
/* 620 */       String str1 = getMessageId(paramArrayOfElement);
/* 621 */       if (str1 == null) {
/* 622 */         if (debug) Debug.say("messageId=null");
/*     */         
/* 624 */         DupsEliminationResult dupsEliminationResult1 = new DupsEliminationResult(false);
/* 625 */         dupsEliminationResult1.setFaultString("Could not find message ID in received headers");
/* 626 */         dupsEliminationResult1.setFaultCode("HEADER_FAULT_CODE");
/* 627 */         return dupsEliminationResult1;
/*     */       } 
/*     */       
/* 630 */       WSDupsEliminationAgent wSDupsEliminationAgent = WSDupsEliminationAgent.getDupsEliminationAgent();
/*     */       
/* 632 */       if (wSDupsEliminationAgent == null) {
/* 633 */         DupsEliminationResult dupsEliminationResult1 = new DupsEliminationResult(false);
/* 634 */         dupsEliminationResult1.setFaultString("Misconfiguration: check your config.xml");
/* 635 */         dupsEliminationResult1.setFaultCode("CONFIG_FAULT_CODE");
/* 636 */         return dupsEliminationResult1;
/*     */       } 
/*     */       
/* 639 */       boolean bool = !wSDupsEliminationAgent.storeHistoryRecord(str1, paramLong * 1000L);
/*     */       
/* 641 */       String str2 = bool ? "Duplicate" : "OK";
/* 642 */       XMLNode xMLNode = (XMLNode)generateResponseHeaders(str1, str2);
/* 643 */       if (debug) Debug.say("Generated SOAP-Header:" + xMLNode);
/*     */       
/* 645 */       Element element = Util.xmlNode2DOMElement(xMLNode);
/*     */ 
/*     */ 
/*     */       
/* 649 */       DupsEliminationResult dupsEliminationResult = new DupsEliminationResult(bool, 1);
/*     */       
/* 651 */       dupsEliminationResult.addResponseHeader(element);
/* 652 */       if (debug) Debug.say("Adding the following header to array:" + element);
/*     */       
/* 654 */       return dupsEliminationResult;
/*     */     }
/* 656 */     catch (Exception exception) {
/* 657 */       DupsEliminationResult dupsEliminationResult = new DupsEliminationResult(false);
/* 658 */       dupsEliminationResult.setFaultString(exception.getMessage());
/* 659 */       dupsEliminationResult.setFaultCode("HEADER_FAULT_CODE");
/* 660 */       return dupsEliminationResult;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean storeHistoryRecord(String paramString, long paramLong) throws StoreForwardException {
/* 668 */     if (paramLong != -1L) {
/* 669 */       return this.dupsEliminationAgent.storeHistoryRecord(paramString, paramLong);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 674 */     return this.dupsEliminationAgent.storeHistoryRecord(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void storeHistoryRecordAndMessage(String paramString, Object paramObject, long paramLong) throws StoreForwardException {
/* 685 */     if (paramLong != -1L) {
/* 686 */       this.dupsEliminationAgent.storeHistoryRecordAndMessage(paramString, paramObject, paramLong);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 692 */       this.dupsEliminationAgent.storeHistoryRecordAndMessage(paramString, paramObject);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getMessageId(Element[] paramArrayOfElement) {
/* 702 */     for (byte b = 0; b < paramArrayOfElement.length; b++) {
/* 703 */       NodeList nodeList = paramArrayOfElement[b].getChildNodes();
/* 704 */       int i = nodeList.getLength();
/*     */ 
/*     */       
/* 707 */       for (byte b1 = 0; b1 < i; b1++) {
/* 708 */         Node node = nodeList.item(b1);
/*     */ 
/*     */         
/* 711 */         if ("MessageData".equals(node.getLocalName()) && "wsmd".equals(node.getPrefix())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 717 */           Node node1 = node.getFirstChild();
/*     */           
/* 719 */           if ("MessageID".equals(node1.getLocalName()) && "wsmd".equals(node1.getPrefix())) {
/*     */             
/* 721 */             String str = node1.getFirstChild().getNodeValue();
/* 722 */             if (debug) Debug.say("Found message ID: " + str); 
/* 723 */             return str;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 728 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static SOAPElement generateResponseHeaders(String paramString1, String paramString2) throws StoreForwardException {
/*     */     try {
/* 736 */       SOAPFactoryImpl sOAPFactoryImpl = new SOAPFactoryImpl();
/* 737 */       SOAPElement sOAPElement1 = sOAPFactoryImpl.createElement("Header", "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */       
/* 740 */       sOAPElement1.addNamespaceDeclaration("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */ 
/*     */       
/* 744 */       Name name1 = sOAPFactoryImpl.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 745 */       Name name2 = sOAPFactoryImpl.createName("MessageID", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 746 */       Name name3 = sOAPFactoryImpl.createName("Version", "wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 747 */       Name name4 = sOAPFactoryImpl.createName("Acknowledgement", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 748 */       Name name5 = sOAPFactoryImpl.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 749 */       Name name6 = sOAPFactoryImpl.createName("Status", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 750 */       Name name7 = sOAPFactoryImpl.createName("mustUnderstand", "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 755 */       SOAPElement sOAPElement2 = sOAPElement1.addChildElement(name1);
/* 756 */       sOAPElement2.addNamespaceDeclaration("wsmd", "http://openuri.org/2002/soap/messagedata/");
/* 757 */       sOAPElement2.addAttribute(name3, "1.0");
/* 758 */       SOAPElement sOAPElement3 = sOAPElement2.addChildElement(name2);
/* 759 */       sOAPElement3.addTextNode(paramString1);
/*     */ 
/*     */       
/* 762 */       SOAPElement sOAPElement4 = sOAPElement1.addChildElement(name4);
/* 763 */       sOAPElement4.addAttribute(name7, "1");
/* 764 */       sOAPElement4.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/* 765 */       sOAPElement4.addAttribute(name5, "1.0");
/*     */ 
/*     */       
/* 768 */       sOAPElement4.addAttribute(name6, paramString2);
/*     */       
/* 770 */       return sOAPElement1;
/*     */     }
/* 772 */     catch (SOAPException sOAPException) {
/*     */       
/* 774 */       throw new StoreForwardException("Failed to handle response", sOAPException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterCompletion(int paramInt) {
/* 780 */     if (paramInt == 4)
/* 781 */       this.dupsEliminationAgent.removeHistoryRecordInMemoryOnly(this.messageId); 
/*     */   }
/*     */   
/*     */   public void beforeCompletion() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\DupsEliminationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */