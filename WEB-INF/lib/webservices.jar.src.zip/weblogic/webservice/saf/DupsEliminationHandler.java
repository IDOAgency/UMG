package weblogic.webservice.saf;

import java.util.Map;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.Synchronization;
import javax.transaction.SystemException;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import weblogic.transaction.TransactionManager;
import weblogic.transaction.TxHelper;
import weblogic.utils.Debug;
import weblogic.webservice.GenericHandler;
import weblogic.webservice.WLMessageContext;
import weblogic.webservice.core.handler.ConversationContext;
import weblogic.webservice.core.soap.SOAPFactoryImpl;
import weblogic.webservice.util.FaultUtil;
import weblogic.xml.xmlnode.XMLNode;

public final class DupsEliminationHandler extends GenericHandler implements Synchronization, ReliableMessagingConstants {
  public static final String DUPS_ELIMINATION_PARAM = "dup_elim_param";
  
  public static final String RETRIES_PARAM = "retries_param";
  
  public static final String RETRY_INTERVAL_PARAM = "retry_interval_param";
  
  public static final String PERSIST_INTERVAL_PARAM = "persist_interval_param";
  
  public static final String IN_ORDER_DELIVERY_PARAM = "in_order_delivery_param";
  
  private static final String RM_RESULT_STATUS_PROP = "__BEA_PRIVATE_RM_RESULT_STATUS_PROP";
  
  private static final String MSG_ID_PROP = "__BEA_PRIVATE_RM_MSG_ID_PROP";
  
  private static final String ACK_NOT_REQED = "AckNotRequired";
  
  private static final String STATUS_DUP = "Duplicate";
  
  private static final String STATUS_OUTOFORDER = "OutOfOrder";
  
  private static final String STATUS_OK = "OK";
  
  private String messageId;
  
  private String sequenceNumber;
  
  private DupsEliminationAgent dupsEliminationAgent;
  
  private ConversationReassembler conversation;
  
  private boolean dupsEliminationRequested;
  
  private boolean inorder;
  
  private TransactionManager tm;
  
  private long persistDuration = -2L;
  
  private static boolean debug = false;
  
  public void init(HandlerInfo paramHandlerInfo) {
    super.init(paramHandlerInfo);
    debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.debug")) || "true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
    Map map = paramHandlerInfo.getHandlerConfig();
    if (debug)
      Debug.say("** init called with: " + map); 
    Boolean bool1 = (Boolean)map.get("dup_elim_param");
    if (bool1 != null) {
      this.dupsEliminationRequested = bool1.booleanValue();
      if (debug)
        Debug.say("dupsEliminationRequested = " + this.dupsEliminationRequested); 
    } 
    Integer integer = (Integer)map.get("persist_interval_param");
    if (integer != null) {
      this.persistDuration = (integer.intValue() * 1000);
      if (debug)
        Debug.say("persistDuration  = " + this.persistDuration); 
    } 
    Boolean bool2 = (Boolean)map.get("in_order_delivery_param");
    if (bool2 != null) {
      this.inorder = bool2.booleanValue();
      if (debug)
        Debug.say("inorder  = " + this.inorder); 
    } 
    this.dupsEliminationAgent = WSDupsEliminationAgent.getDupsEliminationAgent();
  }
  
  public boolean handleRequest(MessageContext paramMessageContext) throws JAXRPCException {
    if (debug)
      Debug.say("** handleRequest called, messagecontext = " + paramMessageContext); 
    WLMessageContext wLMessageContext = (WLMessageContext)paramMessageContext;
    SOAPMessage sOAPMessage = wLMessageContext.getMessage();
    SOAPEnvelope sOAPEnvelope = null;
    SOAPHeader sOAPHeader = null;
    try {
      sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
      sOAPHeader = sOAPEnvelope.getHeader();
      if (sOAPHeader == null)
        sOAPHeader = sOAPEnvelope.addHeader(); 
      Name name1 = sOAPEnvelope.createName("AckRequested", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      SOAPElement sOAPElement1 = Util.getChildSOAPElement(sOAPHeader, name1);
      if (sOAPElement1 == null) {
        wLMessageContext.setProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP", "AckNotRequired");
        return true;
      } 
      sOAPElement1.detachNode();
      Name name2 = sOAPEnvelope.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      SOAPElement sOAPElement2 = Util.getChildSOAPElement(sOAPHeader, name2);
      if (sOAPElement2 == null)
        throw new JAXRPCException("Could not find MessageData header"); 
      Name name3 = sOAPEnvelope.createName("MessageID", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      SOAPElement sOAPElement3 = Util.getChildSOAPElement(sOAPElement2, name3);
      if (sOAPElement3 == null)
        throw new JAXRPCException("Could not find MessageId element in MessageData header"); 
      this.messageId = sOAPElement3.getValue();
      wLMessageContext.setProperty("__BEA_PRIVATE_RM_MSG_ID_PROP", this.messageId);
      if (this.inorder) {
        Name name4 = sOAPEnvelope.createName("MessageOrder", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
        SOAPElement sOAPElement4 = Util.getChildSOAPElement(sOAPHeader, name4);
        if (sOAPElement4 == null)
          throw new JAXRPCException("Could not find MessageOrder header"); 
        Name name5 = sOAPEnvelope.createName("SequenceNumber", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
        SOAPElement sOAPElement5 = Util.getChildSOAPElement(sOAPElement4, name5);
        if (sOAPElement5 == null)
          throw new JAXRPCException("Could not find SequenceNumber element in MessageOrder header"); 
        this.sequenceNumber = sOAPElement5.getValue();
        sOAPElement4.detachNode();
      } 
      sOAPElement2.detachNode();
      if (debug)
        Debug.say("*** Found messageId '" + this.messageId + "' and sequenceNumber '" + this.sequenceNumber + "' in AckRequested header***"); 
    } catch (SOAPException sOAPException) {
      throw new JAXRPCException("Failed to access the SOAP header" + sOAPException);
    } 
    if (this.dupsEliminationRequested) {
      if (this.dupsEliminationAgent == null)
        throw new JAXRPCException("Internal error: Could not find the reliable agent"); 
      try {
        this.dupsEliminationAgent.waitForStart();
      } catch (StoreForwardException storeForwardException) {
        throw new JAXRPCException("Failed to start the reliable agent");
      } 
      if (this.dupsEliminationAgent.isDuplicate(this.messageId)) {
        wLMessageContext.setProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP", "Duplicate");
        wLMessageContext.clearMessage();
        return false;
      } 
    } 
    ConversationContext conversationContext = (ConversationContext)wLMessageContext.getProperty("__BEA_PRIVATE_CONVERSATION_PROP");
    String str1 = null;
    String str2 = null;
    if (conversationContext != null) {
      str1 = conversationContext.getConversationID();
      str2 = conversationContext.getHeaderType();
    } 
    if (str1 != null && this.inorder) {
      this.conversation = (ConversationReassembler)this.dupsEliminationAgent.getConversation(str1);
      if (this.conversation == null)
        if ("StartHeader".equals(str2)) {
          this.conversation = this.dupsEliminationAgent.createConversation(str1, true);
        } else if ("FinishHeader".equals(str2)) {
          this.conversation.setSeenLastMsg(true);
        }  
    } 
    if (this.conversation != null && this.conversation.isOrdered()) {
      int i = Integer.parseInt(this.sequenceNumber);
      if (i != this.conversation.getExpectedSequenceNumber()) {
        if (debug)
          Debug.say("== Message: " + this.messageId + " is out of order"); 
        wLMessageContext.setProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP", "OutOfOrder");
        wLMessageContext.clearMessage();
        String str = "Expected sequence number: '" + this.conversation.getExpectedSequenceNumber() + "' but received '" + i + "'";
        throw new SOAPFaultException(OUT_OF_ORDER_FAULT, "Message is out of order", str, FaultUtil.newDetail(new StoreForwardException(str)));
      } 
      this.conversation.updateExpectedSequenceNumber(i + 1);
    } 
    if (this.dupsEliminationRequested)
      try {
        this.tm = TxHelper.getTransactionManager();
        this.tm.begin();
        this.tm.getTransaction().registerSynchronization(this);
        boolean bool = !storeHistoryRecord(this.messageId, this.persistDuration) ? 1 : 0;
        if (bool) {
          wLMessageContext.setProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP", "Duplicate");
          wLMessageContext.clearMessage();
          this.tm.rollback();
          this.tm = null;
          return false;
        } 
      } catch (SystemException systemException) {
        throw new JAXRPCException("Failed to save the history record", systemException);
      } catch (RollbackException rollbackException) {
        throw new JAXRPCException("Failed to save the history record", rollbackException);
      } catch (NotSupportedException notSupportedException) {
        throw new JAXRPCException("Failed to save the history record", notSupportedException);
      } catch (StoreForwardException storeForwardException) {
        throw new JAXRPCException("Failed to save the history record", storeForwardException);
      }  
    return true;
  }
  
  public boolean handleResponse(MessageContext paramMessageContext) throws JAXRPCException {
    SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    if (debug)
      Debug.say("** handleResponse called"); 
    String str = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP");
    if ("AckNotRequired".equals(str))
      return true; 
    if (this.tm != null && !"Duplicate".equals(str) && !"OutOfOrder".equals(str))
      try {
        int i = this.tm.getStatus();
        if (i == 1 || i == 4 || i == 9)
          return true; 
      } catch (SystemException systemException) {} 
    try {
      SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
      SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
      SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
      if (sOAPHeader == null)
        sOAPHeader = sOAPEnvelope.addHeader(); 
      this.messageId = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_MSG_ID_PROP");
      Name name1 = sOAPEnvelope.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name2 = sOAPEnvelope.createName("Version", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name3 = sOAPEnvelope.createName("Acknowledgement", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name4 = sOAPEnvelope.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name5 = sOAPEnvelope.createName("Status", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      SOAPElement sOAPElement1 = Util.getChildSOAPElement(sOAPHeader, name1);
      if (sOAPElement1 == null)
        sOAPElement1 = sOAPHeader.addHeaderElement(name1); 
      sOAPElement1.addNamespaceDeclaration("wsmd", "http://openuri.org/2002/soap/messagedata/");
      sOAPElement1.addAttribute(name2, "1.0");
      SOAPElement sOAPElement2 = sOAPElement1.addChildElement("RefToMessageID", "wsmd");
      sOAPElement2.addTextNode(this.messageId);
      SOAPHeaderElement sOAPHeaderElement = sOAPHeader.addHeaderElement(name3);
      sOAPHeaderElement.setMustUnderstand(true);
      sOAPHeaderElement.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      sOAPHeaderElement.addAttribute(name4, "1.0");
      String str1 = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP");
      if ("Duplicate".equals(str1)) {
        sOAPHeaderElement.addAttribute(name5, "Duplicate");
        if (this.tm != null)
          try {
            this.tm.rollback();
            this.tm = null;
          } catch (SystemException systemException) {} 
      } else if ("OutOfOrder".equals(str1)) {
        sOAPHeaderElement.addAttribute(name5, "OutOfOrder");
        if (this.tm != null)
          try {
            this.tm.rollback();
            this.dupsEliminationAgent.removeHistoryRecordInMemoryOnly(this.messageId);
            this.tm = null;
          } catch (SystemException systemException) {} 
      } else {
        sOAPHeaderElement.addAttribute(name5, "OK");
        if (this.tm != null)
          try {
            this.tm.commit();
            this.tm = null;
          } catch (Exception exception) {} 
        if (this.conversation != null && this.conversation.isDone()) {
          this.conversation.close();
          if (this.dupsEliminationAgent != null)
            this.dupsEliminationAgent.removeConversation(this.conversation.getId()); 
          this.conversation = null;
        } 
      } 
    } catch (SOAPException sOAPException) {
      if (this.tm != null)
        try {
          this.tm.rollback();
          this.tm = null;
        } catch (SystemException systemException) {} 
      throw new JAXRPCException("Failed to handle response", sOAPException);
    } 
    return true;
  }
  
  public boolean handleFault(MessageContext paramMessageContext) throws JAXRPCException {
    if (debug)
      Debug.say("** handleFault called"); 
    SOAPMessageContext sOAPMessageContext = (SOAPMessageContext)paramMessageContext;
    String str = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP");
    if ("AckNotRequired".equals(str))
      return true; 
    if (this.tm != null && !"Duplicate".equals(str) && !"OutOfOrder".equals(str))
      try {
        int i = this.tm.getStatus();
        if (i == 1 || i == 4 || i == 9)
          return true; 
      } catch (SystemException systemException) {} 
    try {
      SOAPMessage sOAPMessage = sOAPMessageContext.getMessage();
      SOAPEnvelope sOAPEnvelope = sOAPMessage.getSOAPPart().getEnvelope();
      SOAPHeader sOAPHeader = sOAPEnvelope.getHeader();
      if (sOAPHeader == null)
        sOAPHeader = sOAPEnvelope.addHeader(); 
      this.messageId = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_MSG_ID_PROP");
      Name name1 = sOAPEnvelope.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name2 = sOAPEnvelope.createName("Version", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name3 = sOAPEnvelope.createName("Acknowledgement", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name4 = sOAPEnvelope.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name5 = sOAPEnvelope.createName("Status", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      SOAPElement sOAPElement1 = Util.getChildSOAPElement(sOAPHeader, name1);
      if (sOAPElement1 == null)
        sOAPElement1 = sOAPHeader.addHeaderElement(name1); 
      sOAPElement1.addNamespaceDeclaration("wsmd", "http://openuri.org/2002/soap/messagedata/");
      sOAPElement1.addAttribute(name2, "1.0");
      SOAPElement sOAPElement2 = sOAPElement1.addChildElement("RefToMessageID", "wsmd");
      sOAPElement2.addTextNode(this.messageId);
      SOAPHeaderElement sOAPHeaderElement = sOAPHeader.addHeaderElement(name3);
      sOAPHeaderElement.setMustUnderstand(true);
      sOAPHeaderElement.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      sOAPHeaderElement.addAttribute(name4, "1.0");
      String str1 = (String)sOAPMessageContext.getProperty("__BEA_PRIVATE_RM_RESULT_STATUS_PROP");
      if ("OutOfOrder".equals(str1)) {
        sOAPHeaderElement.addAttribute(name5, "OutOfOrder");
        if (this.tm != null)
          try {
            this.tm.rollback();
            this.dupsEliminationAgent.removeHistoryRecordInMemoryOnly(this.messageId);
            this.tm = null;
          } catch (SystemException systemException) {} 
      } else {
        sOAPHeaderElement.addAttribute(name5, "OK");
        if (this.tm != null)
          try {
            this.tm.commit();
            this.tm = null;
          } catch (Exception exception) {} 
      } 
      if (this.conversation != null && this.conversation.isDone()) {
        this.conversation.close();
        if (this.dupsEliminationAgent != null)
          this.dupsEliminationAgent.removeConversation(this.conversation.getId()); 
        this.conversation = null;
      } 
    } catch (SOAPException sOAPException) {
      if (this.tm != null)
        try {
          this.tm.rollback();
          this.tm = null;
        } catch (SystemException systemException) {} 
      throw new JAXRPCException("Failed to handle response", sOAPException);
    } 
    return true;
  }
  
  public static DupsEliminationResult checkForDups(Element[] paramArrayOfElement, long paramLong) {
    try {
      String str1 = getMessageId(paramArrayOfElement);
      if (str1 == null) {
        if (debug)
          Debug.say("messageId=null"); 
        DupsEliminationResult dupsEliminationResult1 = new DupsEliminationResult(false);
        dupsEliminationResult1.setFaultString("Could not find message ID in received headers");
        dupsEliminationResult1.setFaultCode("HEADER_FAULT_CODE");
        return dupsEliminationResult1;
      } 
      WSDupsEliminationAgent wSDupsEliminationAgent = WSDupsEliminationAgent.getDupsEliminationAgent();
      if (wSDupsEliminationAgent == null) {
        DupsEliminationResult dupsEliminationResult1 = new DupsEliminationResult(false);
        dupsEliminationResult1.setFaultString("Misconfiguration: check your config.xml");
        dupsEliminationResult1.setFaultCode("CONFIG_FAULT_CODE");
        return dupsEliminationResult1;
      } 
      boolean bool = !wSDupsEliminationAgent.storeHistoryRecord(str1, paramLong * 1000L);
      String str2 = bool ? "Duplicate" : "OK";
      XMLNode xMLNode = (XMLNode)generateResponseHeaders(str1, str2);
      if (debug)
        Debug.say("Generated SOAP-Header:" + xMLNode); 
      Element element = Util.xmlNode2DOMElement(xMLNode);
      DupsEliminationResult dupsEliminationResult = new DupsEliminationResult(bool, 1);
      dupsEliminationResult.addResponseHeader(element);
      if (debug)
        Debug.say("Adding the following header to array:" + element); 
      return dupsEliminationResult;
    } catch (Exception exception) {
      DupsEliminationResult dupsEliminationResult = new DupsEliminationResult(false);
      dupsEliminationResult.setFaultString(exception.getMessage());
      dupsEliminationResult.setFaultCode("HEADER_FAULT_CODE");
      return dupsEliminationResult;
    } 
  }
  
  private boolean storeHistoryRecord(String paramString, long paramLong) throws StoreForwardException {
    if (paramLong != -1L)
      return this.dupsEliminationAgent.storeHistoryRecord(paramString, paramLong); 
    return this.dupsEliminationAgent.storeHistoryRecord(paramString);
  }
  
  private void storeHistoryRecordAndMessage(String paramString, Object paramObject, long paramLong) throws StoreForwardException {
    if (paramLong != -1L) {
      this.dupsEliminationAgent.storeHistoryRecordAndMessage(paramString, paramObject, paramLong);
    } else {
      this.dupsEliminationAgent.storeHistoryRecordAndMessage(paramString, paramObject);
    } 
  }
  
  private static String getMessageId(Element[] paramArrayOfElement) {
    for (byte b = 0; b < paramArrayOfElement.length; b++) {
      NodeList nodeList = paramArrayOfElement[b].getChildNodes();
      int i = nodeList.getLength();
      for (byte b1 = 0; b1 < i; b1++) {
        Node node = nodeList.item(b1);
        if ("MessageData".equals(node.getLocalName()) && "wsmd".equals(node.getPrefix())) {
          Node node1 = node.getFirstChild();
          if ("MessageID".equals(node1.getLocalName()) && "wsmd".equals(node1.getPrefix())) {
            String str = node1.getFirstChild().getNodeValue();
            if (debug)
              Debug.say("Found message ID: " + str); 
            return str;
          } 
        } 
      } 
    } 
    return null;
  }
  
  private static SOAPElement generateResponseHeaders(String paramString1, String paramString2) throws StoreForwardException {
    try {
      SOAPFactoryImpl sOAPFactoryImpl = new SOAPFactoryImpl();
      SOAPElement sOAPElement1 = sOAPFactoryImpl.createElement("Header", "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
      sOAPElement1.addNamespaceDeclaration("SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
      Name name1 = sOAPFactoryImpl.createName("MessageData", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name2 = sOAPFactoryImpl.createName("MessageID", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name3 = sOAPFactoryImpl.createName("Version", "wsmd", "http://openuri.org/2002/soap/messagedata/");
      Name name4 = sOAPFactoryImpl.createName("Acknowledgement", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name5 = sOAPFactoryImpl.createName("Version", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name6 = sOAPFactoryImpl.createName("Status", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      Name name7 = sOAPFactoryImpl.createName("mustUnderstand", "SOAP-ENV", "http://schemas.xmlsoap.org/soap/envelope/");
      SOAPElement sOAPElement2 = sOAPElement1.addChildElement(name1);
      sOAPElement2.addNamespaceDeclaration("wsmd", "http://openuri.org/2002/soap/messagedata/");
      sOAPElement2.addAttribute(name3, "1.0");
      SOAPElement sOAPElement3 = sOAPElement2.addChildElement(name2);
      sOAPElement3.addTextNode(paramString1);
      SOAPElement sOAPElement4 = sOAPElement1.addChildElement(name4);
      sOAPElement4.addAttribute(name7, "1");
      sOAPElement4.addNamespaceDeclaration("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      sOAPElement4.addAttribute(name5, "1.0");
      sOAPElement4.addAttribute(name6, paramString2);
      return sOAPElement1;
    } catch (SOAPException sOAPException) {
      throw new StoreForwardException("Failed to handle response", sOAPException);
    } 
  }
  
  public void afterCompletion(int paramInt) {
    if (paramInt == 4)
      this.dupsEliminationAgent.removeHistoryRecordInMemoryOnly(this.messageId); 
  }
  
  public void beforeCompletion() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\DupsEliminationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */