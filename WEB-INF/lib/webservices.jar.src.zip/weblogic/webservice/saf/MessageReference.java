package weblogic.webservice.saf;

import javax.xml.rpc.handler.MessageContext;

class MessageReference {
  private MessageContext message;
  
  private String messageId;
  
  private int sequenceNumber;
  
  private int retryCount;
  
  private long retryInterval;
  
  private long persistDuration;
  
  private long timestamp;
  
  private MessageReference prev;
  
  private MessageReference next;
  
  MessageReference(String paramString, int paramInt1, MessageContext paramMessageContext, int paramInt2, long paramLong1, long paramLong2) {
    this.messageId = paramString;
    this.sequenceNumber = paramInt1;
    this.message = paramMessageContext;
    this.retryCount = paramInt2;
    this.retryInterval = paramLong1;
    this.persistDuration = paramLong2;
    this.timestamp = getTimeStamp();
  }
  
  MessageReference(String paramString, int paramInt, MessageContext paramMessageContext, long paramLong) {
    this.messageId = paramString;
    this.sequenceNumber = paramInt;
    this.message = paramMessageContext;
    this.persistDuration = paramLong;
    this.timestamp = getTimeStamp();
  }
  
  void setMessage(MessageContext paramMessageContext) { this.message = paramMessageContext; }
  
  MessageContext getMessage() { return this.message; }
  
  String getMessageId() { return this.messageId; }
  
  int getSequenceNumber() { return this.sequenceNumber; }
  
  long getTimeStamp() {
    int i = this.messageId.indexOf(".");
    if (i > 0) {
      String str = this.messageId.substring(i + 1);
      int j = str.indexOf(".");
      if (j > 0)
        return Long.parseLong(str.substring(0, j)); 
    } 
    return 0L;
  }
  
  long getNextScheduleInterval() {
    long l = System.currentTimeMillis() - this.timestamp;
    if (l >= this.retryInterval)
      return 0L; 
    return this.retryInterval - l;
  }
  
  boolean isExpired() { return (System.currentTimeMillis() - this.timestamp > this.persistDuration); }
  
  int getRetryLeft() { return this.retryCount; }
  
  void decreaseRetryCount() { this.retryCount--; }
  
  void setPrev(MessageReference paramMessageReference) { this.prev = paramMessageReference; }
  
  MessageReference getPrev() { return this.prev; }
  
  void setNext(MessageReference paramMessageReference) { this.next = paramMessageReference; }
  
  MessageReference getNext() { return this.next; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\MessageReference.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */