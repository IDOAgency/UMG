/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import javax.xml.rpc.handler.MessageContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MessageReference
/*     */ {
/*     */   private MessageContext message;
/*     */   private String messageId;
/*     */   private int sequenceNumber;
/*     */   private int retryCount;
/*     */   private long retryInterval;
/*     */   private long persistDuration;
/*     */   private long timestamp;
/*     */   private MessageReference prev;
/*     */   private MessageReference next;
/*     */   
/*     */   MessageReference(String paramString, int paramInt1, MessageContext paramMessageContext, int paramInt2, long paramLong1, long paramLong2) {
/*  46 */     this.messageId = paramString;
/*  47 */     this.sequenceNumber = paramInt1;
/*  48 */     this.message = paramMessageContext;
/*  49 */     this.retryCount = paramInt2;
/*  50 */     this.retryInterval = paramLong1;
/*  51 */     this.persistDuration = paramLong2;
/*  52 */     this.timestamp = getTimeStamp();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MessageReference(String paramString, int paramInt, MessageContext paramMessageContext, long paramLong) {
/*  69 */     this.messageId = paramString;
/*  70 */     this.sequenceNumber = paramInt;
/*  71 */     this.message = paramMessageContext;
/*  72 */     this.persistDuration = paramLong;
/*  73 */     this.timestamp = getTimeStamp();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   void setMessage(MessageContext paramMessageContext) { this.message = paramMessageContext; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   MessageContext getMessage() { return this.message; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   String getMessageId() { return this.messageId; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   int getSequenceNumber() { return this.sequenceNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getTimeStamp() {
/* 118 */     int i = this.messageId.indexOf(".");
/*     */     
/* 120 */     if (i > 0) {
/* 121 */       String str = this.messageId.substring(i + 1);
/*     */       
/* 123 */       int j = str.indexOf(".");
/*     */       
/* 125 */       if (j > 0) {
/* 126 */         return Long.parseLong(str.substring(0, j));
/*     */       }
/*     */     } 
/* 129 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getNextScheduleInterval() {
/* 139 */     long l = System.currentTimeMillis() - this.timestamp;
/*     */     
/* 141 */     if (l >= this.retryInterval) {
/* 142 */       return 0L;
/*     */     }
/* 144 */     return this.retryInterval - l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   boolean isExpired() { return (System.currentTimeMillis() - this.timestamp > this.persistDuration); }
/*     */ 
/*     */ 
/*     */   
/* 155 */   int getRetryLeft() { return this.retryCount; }
/*     */ 
/*     */ 
/*     */   
/* 159 */   void decreaseRetryCount() { this.retryCount--; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   void setPrev(MessageReference paramMessageReference) { this.prev = paramMessageReference; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   MessageReference getPrev() { return this.prev; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   void setNext(MessageReference paramMessageReference) { this.next = paramMessageReference; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   MessageReference getNext() { return this.next; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\MessageReference.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */