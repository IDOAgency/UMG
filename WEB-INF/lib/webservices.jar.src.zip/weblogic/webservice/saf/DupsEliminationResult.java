package weblogic.webservice.saf;

import java.util.ArrayList;
import org.w3c.dom.Element;

public class DupsEliminationResult {
  public static final String CONFIG_FAULT_CODE = "CONFIG_FAULT_CODE";
  
  public static final String HEADER_FAULT_CODE = "HEADER_FAULT_CODE";
  
  private boolean isDup;
  
  private ArrayList responseHeaders;
  
  private String faultString;
  
  private String faultDetail;
  
  private String faultCode;
  
  DupsEliminationResult(boolean paramBoolean) { this(paramBoolean, 0); }
  
  DupsEliminationResult(boolean paramBoolean, int paramInt) {
    this.isDup = paramBoolean;
    this.responseHeaders = new ArrayList(paramInt);
    this.faultCode = null;
    this.faultString = null;
    this.faultDetail = null;
  }
  
  public boolean isDup() { return this.isDup; }
  
  public void setDup(boolean paramBoolean) { this.isDup = paramBoolean; }
  
  public boolean isValid() {
    if (this.isDup || this.faultString != null)
      return false; 
    return true;
  }
  
  public Element[] getResponseHeaders() {
    Element[] arrayOfElement = new Element[this.responseHeaders.size()];
    return (Element[])this.responseHeaders.toArray(arrayOfElement);
  }
  
  public void addResponseHeader(Element paramElement) { this.responseHeaders.add(paramElement); }
  
  public String getFaultString() { return this.faultString; }
  
  public void setFaultString(String paramString) { this.faultString = paramString; }
  
  public String getFaultCode() { return this.faultCode; }
  
  public void setFaultCode(String paramString) { this.faultCode = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\DupsEliminationResult.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */