/*    */ package weblogic.webservice.saf;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DupsEliminationResult
/*    */ {
/*    */   public static final String CONFIG_FAULT_CODE = "CONFIG_FAULT_CODE";
/*    */   public static final String HEADER_FAULT_CODE = "HEADER_FAULT_CODE";
/*    */   private boolean isDup;
/*    */   private ArrayList responseHeaders;
/*    */   private String faultString;
/*    */   private String faultDetail;
/*    */   private String faultCode;
/*    */   
/* 21 */   DupsEliminationResult(boolean paramBoolean) { this(paramBoolean, 0); }
/*    */ 
/*    */   
/*    */   DupsEliminationResult(boolean paramBoolean, int paramInt) {
/* 25 */     this.isDup = paramBoolean;
/* 26 */     this.responseHeaders = new ArrayList(paramInt);
/* 27 */     this.faultCode = null;
/* 28 */     this.faultString = null;
/* 29 */     this.faultDetail = null;
/*    */   }
/*    */   
/* 32 */   public boolean isDup() { return this.isDup; }
/* 33 */   public void setDup(boolean paramBoolean) { this.isDup = paramBoolean; }
/*    */   
/*    */   public boolean isValid() {
/* 36 */     if (this.isDup || this.faultString != null) {
/* 37 */       return false;
/*    */     }
/* 39 */     return true;
/*    */   }
/*    */   
/*    */   public Element[] getResponseHeaders() {
/* 43 */     Element[] arrayOfElement = new Element[this.responseHeaders.size()];
/* 44 */     return (Element[])this.responseHeaders.toArray(arrayOfElement);
/*    */   }
/*    */   
/* 47 */   public void addResponseHeader(Element paramElement) { this.responseHeaders.add(paramElement); }
/*    */ 
/*    */   
/* 50 */   public String getFaultString() { return this.faultString; }
/* 51 */   public void setFaultString(String paramString) { this.faultString = paramString; }
/*    */   
/* 53 */   public String getFaultCode() { return this.faultCode; }
/* 54 */   public void setFaultCode(String paramString) { this.faultCode = paramString; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\DupsEliminationResult.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */