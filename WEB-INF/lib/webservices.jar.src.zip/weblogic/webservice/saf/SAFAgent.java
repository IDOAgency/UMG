package weblogic.webservice.saf;

import javax.xml.rpc.handler.MessageContext;
import weblogic.webservice.ReliableDelivery;

interface SAFAgent extends WSAgent {
  void store(String paramString1, String paramString2, String paramString3, Object paramObject, ReliableDelivery paramReliableDelivery, long paramLong) throws StoreForwardException;
  
  void remove(String paramString) throws StoreForwardException;
  
  int forward(String paramString) throws StoreForwardException;
  
  String getMessageId();
  
  ConversationAssembler createConversation(String paramString, boolean paramBoolean1, boolean paramBoolean2, int paramInt, long paramLong1, long paramLong2, ReliableDelivery paramReliableDelivery);
  
  void restoreMessage(String paramString, MessageContext paramMessageContext);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\SAFAgent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */