package weblogic.webservice.saf;

import java.util.HashSet;

abstract class Conversation {
  protected HashSet messages;
  
  protected int numWaiting;
  
  protected boolean running;
  
  protected boolean ordered;
  
  protected String id;
  
  protected MessageReference firstMessage;
  
  protected MessageReference lastMessage;
  
  protected long persistDuration;
  
  protected boolean seenLastMsg;
  
  protected int msgCount;
  
  protected static boolean debug = false;
  
  Conversation(String paramString, boolean paramBoolean) {
    this.id = paramString;
    this.ordered = paramBoolean;
    this.messages = new HashSet();
    debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
  }
  
  abstract void addMessage(String paramString, int paramInt, Object paramObject);
  
  abstract void removeMessage(MessageReference paramMessageReference);
  
  abstract void close();
  
  abstract void run();
  
  protected void addMessageToList(MessageReference paramMessageReference) {
    if (paramMessageReference == null)
      return; 
    if (this.firstMessage == null) {
      this.firstMessage = paramMessageReference;
      this.lastMessage = paramMessageReference;
    } else {
      this.lastMessage.setNext(paramMessageReference);
      paramMessageReference.setPrev(this.lastMessage);
      this.lastMessage = paramMessageReference;
    } 
    this.msgCount++;
  }
  
  protected void addMessageToListInorder(MessageReference paramMessageReference) {
    if (paramMessageReference == null)
      return; 
    this.msgCount++;
    if (this.firstMessage == null) {
      this.firstMessage = paramMessageReference;
      this.lastMessage = paramMessageReference;
      return;
    } 
    MessageReference messageReference = this.firstMessage;
    while (messageReference != this.lastMessage && 
      messageReference.getSequenceNumber() <= paramMessageReference.getSequenceNumber())
      messageReference = messageReference.getNext(); 
    if (messageReference == this.lastMessage) {
      this.lastMessage.setNext(paramMessageReference);
      paramMessageReference.setPrev(this.lastMessage);
      this.lastMessage = paramMessageReference;
      return;
    } 
    paramMessageReference.setNext(messageReference);
    paramMessageReference.setPrev(messageReference.getPrev());
    if (messageReference.getPrev() != null)
      messageReference.getPrev().setNext(paramMessageReference); 
    messageReference.setPrev(paramMessageReference);
  }
  
  protected void removeMessageFromList(MessageReference paramMessageReference) {
    if (paramMessageReference == null)
      return; 
    if (paramMessageReference == this.firstMessage) {
      this.firstMessage = paramMessageReference.getNext();
      paramMessageReference.setPrev(null);
      if (paramMessageReference == this.lastMessage)
        this.lastMessage = this.firstMessage; 
    } else {
      if (paramMessageReference.getNext() != null)
        paramMessageReference.getNext().setPrev(paramMessageReference.getPrev()); 
      if (paramMessageReference.getPrev() != null)
        paramMessageReference.getPrev().setNext(paramMessageReference.getNext()); 
    } 
    this.msgCount--;
  }
  
  final boolean isOrdered() { return this.ordered; }
  
  final boolean isEmpty() { return (this.firstMessage == null); }
  
  final boolean isDone() { return (this.firstMessage == null && this.seenLastMsg); }
  
  String getId() { return this.id; }
  
  void setSeenLastMsg(boolean paramBoolean) { this.seenLastMsg = paramBoolean; }
  
  void putMessage(String paramString) { this.messages.add(paramString); }
  
  HashSet getMessages() { return this.messages; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\Conversation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */