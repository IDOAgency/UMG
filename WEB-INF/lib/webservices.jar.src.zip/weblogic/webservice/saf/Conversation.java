/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Conversation
/*     */ {
/*     */   protected HashSet messages;
/*     */   protected int numWaiting;
/*     */   protected boolean running;
/*     */   protected boolean ordered;
/*     */   protected String id;
/*     */   protected MessageReference firstMessage;
/*     */   protected MessageReference lastMessage;
/*     */   protected long persistDuration;
/*     */   protected boolean seenLastMsg;
/*     */   protected int msgCount;
/*     */   protected static boolean debug = false;
/*     */   
/*     */   Conversation(String paramString, boolean paramBoolean) {
/*  44 */     this.id = paramString;
/*  45 */     this.ordered = paramBoolean;
/*  46 */     this.messages = new HashSet();
/*  47 */     debug = ("true".equalsIgnoreCase(System.getProperty("weblogic.webservice.reliable.verbose")) || debug);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void addMessage(String paramString, int paramInt, Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void removeMessage(MessageReference paramMessageReference);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void close();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void run();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addMessageToList(MessageReference paramMessageReference) {
/*  80 */     if (paramMessageReference == null)
/*     */       return; 
/*  82 */     if (this.firstMessage == null) {
/*  83 */       this.firstMessage = paramMessageReference;
/*  84 */       this.lastMessage = paramMessageReference;
/*     */     } else {
/*  86 */       this.lastMessage.setNext(paramMessageReference);
/*  87 */       paramMessageReference.setPrev(this.lastMessage);
/*  88 */       this.lastMessage = paramMessageReference;
/*     */     } 
/*     */     
/*  91 */     this.msgCount++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addMessageToListInorder(MessageReference paramMessageReference) {
/* 103 */     if (paramMessageReference == null)
/*     */       return; 
/* 105 */     this.msgCount++;
/*     */     
/* 107 */     if (this.firstMessage == null) {
/* 108 */       this.firstMessage = paramMessageReference;
/* 109 */       this.lastMessage = paramMessageReference;
/*     */       
/*     */       return;
/*     */     } 
/* 113 */     MessageReference messageReference = this.firstMessage;
/* 114 */     while (messageReference != this.lastMessage && 
/* 115 */       messageReference.getSequenceNumber() <= paramMessageReference.getSequenceNumber())
/*     */     {
/*     */       
/* 118 */       messageReference = messageReference.getNext();
/*     */     }
/*     */     
/* 121 */     if (messageReference == this.lastMessage) {
/*     */       
/* 123 */       this.lastMessage.setNext(paramMessageReference);
/* 124 */       paramMessageReference.setPrev(this.lastMessage);
/* 125 */       this.lastMessage = paramMessageReference;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 130 */     paramMessageReference.setNext(messageReference);
/* 131 */     paramMessageReference.setPrev(messageReference.getPrev());
/*     */     
/* 133 */     if (messageReference.getPrev() != null) {
/* 134 */       messageReference.getPrev().setNext(paramMessageReference);
/*     */     }
/* 136 */     messageReference.setPrev(paramMessageReference);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeMessageFromList(MessageReference paramMessageReference) {
/* 148 */     if (paramMessageReference == null)
/*     */       return; 
/* 150 */     if (paramMessageReference == this.firstMessage) {
/* 151 */       this.firstMessage = paramMessageReference.getNext();
/* 152 */       paramMessageReference.setPrev(null);
/* 153 */       if (paramMessageReference == this.lastMessage) this.lastMessage = this.firstMessage; 
/*     */     } else {
/* 155 */       if (paramMessageReference.getNext() != null) {
/* 156 */         paramMessageReference.getNext().setPrev(paramMessageReference.getPrev());
/*     */       }
/* 158 */       if (paramMessageReference.getPrev() != null) {
/* 159 */         paramMessageReference.getPrev().setNext(paramMessageReference.getNext());
/*     */       }
/*     */     } 
/*     */     
/* 163 */     this.msgCount--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   final boolean isOrdered() { return this.ordered; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   final boolean isEmpty() { return (this.firstMessage == null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   final boolean isDone() { return (this.firstMessage == null && this.seenLastMsg); }
/*     */ 
/*     */ 
/*     */   
/* 192 */   String getId() { return this.id; }
/*     */ 
/*     */ 
/*     */   
/* 196 */   void setSeenLastMsg(boolean paramBoolean) { this.seenLastMsg = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/* 200 */   void putMessage(String paramString) { this.messages.add(paramString); }
/*     */ 
/*     */ 
/*     */   
/* 204 */   HashSet getMessages() { return this.messages; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\Conversation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */