/*     */ package weblogic.webservice.saf;
/*     */ 
/*     */ import javax.management.InvalidAttributeValueException;
/*     */ import weblogic.management.DistributedManagementException;
/*     */ import weblogic.management.configuration.DomainMBean;
/*     */ import weblogic.management.configuration.JMSQueueMBean;
/*     */ import weblogic.management.configuration.JMSServerMBean;
/*     */ import weblogic.management.configuration.JMSStoreMBean;
/*     */ import weblogic.management.configuration.ServerMBean;
/*     */ import weblogic.management.configuration.TargetMBean;
/*     */ import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;
/*     */ import weblogic.management.provider.ConfigurationProcessor;
/*     */ import weblogic.management.provider.UpdateException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSConfigUpdater
/*     */   implements ConfigurationProcessor
/*     */ {
/*  25 */   String[] queueNames = { "jms.internal.queue.WSStoreForwardQueue", "jms.internal.queue.WSDupsEliminationHistoryQueue", "jms.internal.queue.WSDupsEliminationMessageQueue" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateConfiguration(DomainMBean paramDomainMBean) throws UpdateException {
/*  33 */     WSReliableDeliveryPolicyMBean[] arrayOfWSReliableDeliveryPolicyMBean = paramDomainMBean.getWSReliableDeliveryPolicies();
/*     */ 
/*     */     
/*  36 */     if (arrayOfWSReliableDeliveryPolicyMBean == null)
/*     */       return; 
/*  38 */     for (byte b = 0; b < arrayOfWSReliableDeliveryPolicyMBean.length; b++) {
/*     */       
/*  40 */       WSReliableDeliveryPolicyMBean wSReliableDeliveryPolicyMBean = arrayOfWSReliableDeliveryPolicyMBean[b];
/*  41 */       JMSServerMBean jMSServerMBean = wSReliableDeliveryPolicyMBean.getJMSServer();
/*  42 */       JMSStoreMBean jMSStoreMBean = wSReliableDeliveryPolicyMBean.getStore();
/*     */       
/*  44 */       if (jMSServerMBean == null && jMSStoreMBean != null) {
/*     */ 
/*     */         
/*  47 */         jMSServerMBean = jMSStoreMBean.getJMSServer();
/*  48 */         if (jMSServerMBean == null) {
/*  49 */           jMSServerMBean = findJMSServerFor(jMSStoreMBean, paramDomainMBean);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  56 */         if (jMSServerMBean == null) {
/*  57 */           ServerMBean serverMBean = findServerFor(wSReliableDeliveryPolicyMBean.getName(), paramDomainMBean);
/*  58 */           if (serverMBean != null) {
/*  59 */             jMSServerMBean = paramDomainMBean.createJMSServer("WSStoreForwardInternalJMSServer" + serverMBean.getName());
/*     */             
/*     */             try {
/*  62 */               TargetMBean[] arrayOfTargetMBean = { serverMBean };
/*  63 */               jMSServerMBean.setTargets(arrayOfTargetMBean);
/*     */             }
/*  65 */             catch (DistributedManagementException distributedManagementException) {
/*  66 */               throw new UpdateException(distributedManagementException);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/*  71 */         if (jMSStoreMBean != null && jMSServerMBean.getPersistentStore() == null && jMSServerMBean.getStore() == null) {
/*     */ 
/*     */           
/*  74 */           jMSServerMBean.setStore(jMSStoreMBean);
/*  75 */           jMSStoreMBean.setJMSServer(jMSServerMBean);
/*     */         } 
/*     */         
/*  78 */         if (jMSServerMBean != null) {
/*     */           
/*  80 */           wSReliableDeliveryPolicyMBean.setJMSServer(jMSServerMBean);
/*  81 */           wSReliableDeliveryPolicyMBean.setStore(null);
/*  82 */           ensureQueues(jMSServerMBean);
/*     */         } 
/*  84 */       } catch (InvalidAttributeValueException invalidAttributeValueException) {
/*  85 */         throw new UpdateException(invalidAttributeValueException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void ensureQueues(JMSServerMBean paramJMSServerMBean) {
/*  91 */     TargetMBean[] arrayOfTargetMBean = paramJMSServerMBean.getTargets();
/*  92 */     if (arrayOfTargetMBean == null) {
/*     */       return;
/*     */     }
/*  95 */     for (byte b = 0; b < arrayOfTargetMBean.length; b++) {
/*  96 */       ensureQueues(paramJMSServerMBean, arrayOfTargetMBean[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   private void ensureQueues(JMSServerMBean paramJMSServerMBean, TargetMBean paramTargetMBean) {
/* 101 */     for (byte b = 0; b < this.queueNames.length; b++) {
/* 102 */       ensureQueue(paramJMSServerMBean, paramTargetMBean, this.queueNames[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void ensureQueue(JMSServerMBean paramJMSServerMBean, TargetMBean paramTargetMBean, String paramString) {
/* 108 */     String str = Util.generateQueueName(paramString, paramTargetMBean);
/*     */     
/* 110 */     if (paramJMSServerMBean.lookupJMSQueue(str) == null) {
/* 111 */       JMSQueueMBean jMSQueueMBean = paramJMSServerMBean.createJMSQueue(str);
/*     */       try {
/* 113 */         jMSQueueMBean.setJNDIName(paramString);
/* 114 */         jMSQueueMBean.setJNDINameReplicated(false);
/* 115 */       } catch (InvalidAttributeValueException invalidAttributeValueException) {
/* 116 */         throw new AssertionError(invalidAttributeValueException);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private ServerMBean findServerFor(String paramString, DomainMBean paramDomainMBean) {
/* 122 */     ServerMBean[] arrayOfServerMBean = paramDomainMBean.getServers();
/* 123 */     if (arrayOfServerMBean == null) return null; 
/* 124 */     for (byte b = 0; b < arrayOfServerMBean.length; b++) {
/* 125 */       WSReliableDeliveryPolicyMBean wSReliableDeliveryPolicyMBean = arrayOfServerMBean[b].getReliableDeliveryPolicy();
/*     */       
/* 127 */       if (wSReliableDeliveryPolicyMBean != null)
/*     */       {
/*     */         
/* 130 */         if (wSReliableDeliveryPolicyMBean.getName().equals(paramString))
/* 131 */           return arrayOfServerMBean[b]; 
/*     */       }
/*     */     } 
/* 134 */     return null;
/*     */   }
/*     */   
/*     */   private JMSServerMBean findJMSServerFor(JMSStoreMBean paramJMSStoreMBean, DomainMBean paramDomainMBean) {
/* 138 */     JMSServerMBean[] arrayOfJMSServerMBean = paramDomainMBean.getJMSServers();
/* 139 */     if (arrayOfJMSServerMBean == null) return null; 
/* 140 */     for (byte b = 0; b < arrayOfJMSServerMBean.length; b++) {
/* 141 */       JMSStoreMBean jMSStoreMBean = arrayOfJMSServerMBean[b].getStore();
/* 142 */       if (jMSStoreMBean != null)
/*     */       {
/*     */         
/* 145 */         if (jMSStoreMBean == paramJMSStoreMBean)
/* 146 */           return arrayOfJMSServerMBean[b]; 
/*     */       }
/*     */     } 
/* 149 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\WSConfigUpdater.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */