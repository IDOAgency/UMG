package weblogic.webservice.saf;

import javax.management.InvalidAttributeValueException;
import weblogic.management.DistributedManagementException;
import weblogic.management.configuration.DomainMBean;
import weblogic.management.configuration.JMSQueueMBean;
import weblogic.management.configuration.JMSServerMBean;
import weblogic.management.configuration.JMSStoreMBean;
import weblogic.management.configuration.ServerMBean;
import weblogic.management.configuration.TargetMBean;
import weblogic.management.configuration.WSReliableDeliveryPolicyMBean;
import weblogic.management.provider.ConfigurationProcessor;
import weblogic.management.provider.UpdateException;

public class WSConfigUpdater implements ConfigurationProcessor {
  String[] queueNames = { "jms.internal.queue.WSStoreForwardQueue", "jms.internal.queue.WSDupsEliminationHistoryQueue", "jms.internal.queue.WSDupsEliminationMessageQueue" };
  
  public void updateConfiguration(DomainMBean paramDomainMBean) throws UpdateException {
    WSReliableDeliveryPolicyMBean[] arrayOfWSReliableDeliveryPolicyMBean = paramDomainMBean.getWSReliableDeliveryPolicies();
    if (arrayOfWSReliableDeliveryPolicyMBean == null)
      return; 
    for (byte b = 0; b < arrayOfWSReliableDeliveryPolicyMBean.length; b++) {
      WSReliableDeliveryPolicyMBean wSReliableDeliveryPolicyMBean = arrayOfWSReliableDeliveryPolicyMBean[b];
      JMSServerMBean jMSServerMBean = wSReliableDeliveryPolicyMBean.getJMSServer();
      JMSStoreMBean jMSStoreMBean = wSReliableDeliveryPolicyMBean.getStore();
      if (jMSServerMBean == null && jMSStoreMBean != null) {
        jMSServerMBean = jMSStoreMBean.getJMSServer();
        if (jMSServerMBean == null)
          jMSServerMBean = findJMSServerFor(jMSStoreMBean, paramDomainMBean); 
      } 
      try {
        if (jMSServerMBean == null) {
          ServerMBean serverMBean = findServerFor(wSReliableDeliveryPolicyMBean.getName(), paramDomainMBean);
          if (serverMBean != null) {
            jMSServerMBean = paramDomainMBean.createJMSServer("WSStoreForwardInternalJMSServer" + serverMBean.getName());
            try {
              TargetMBean[] arrayOfTargetMBean = { serverMBean };
              jMSServerMBean.setTargets(arrayOfTargetMBean);
            } catch (DistributedManagementException distributedManagementException) {
              throw new UpdateException(distributedManagementException);
            } 
          } 
        } 
        if (jMSStoreMBean != null && jMSServerMBean.getPersistentStore() == null && jMSServerMBean.getStore() == null) {
          jMSServerMBean.setStore(jMSStoreMBean);
          jMSStoreMBean.setJMSServer(jMSServerMBean);
        } 
        if (jMSServerMBean != null) {
          wSReliableDeliveryPolicyMBean.setJMSServer(jMSServerMBean);
          wSReliableDeliveryPolicyMBean.setStore(null);
          ensureQueues(jMSServerMBean);
        } 
      } catch (InvalidAttributeValueException invalidAttributeValueException) {
        throw new UpdateException(invalidAttributeValueException);
      } 
    } 
  }
  
  private void ensureQueues(JMSServerMBean paramJMSServerMBean) {
    TargetMBean[] arrayOfTargetMBean = paramJMSServerMBean.getTargets();
    if (arrayOfTargetMBean == null)
      return; 
    for (byte b = 0; b < arrayOfTargetMBean.length; b++)
      ensureQueues(paramJMSServerMBean, arrayOfTargetMBean[b]); 
  }
  
  private void ensureQueues(JMSServerMBean paramJMSServerMBean, TargetMBean paramTargetMBean) {
    for (byte b = 0; b < this.queueNames.length; b++)
      ensureQueue(paramJMSServerMBean, paramTargetMBean, this.queueNames[b]); 
  }
  
  private void ensureQueue(JMSServerMBean paramJMSServerMBean, TargetMBean paramTargetMBean, String paramString) {
    String str = Util.generateQueueName(paramString, paramTargetMBean);
    if (paramJMSServerMBean.lookupJMSQueue(str) == null) {
      JMSQueueMBean jMSQueueMBean = paramJMSServerMBean.createJMSQueue(str);
      try {
        jMSQueueMBean.setJNDIName(paramString);
        jMSQueueMBean.setJNDINameReplicated(false);
      } catch (InvalidAttributeValueException invalidAttributeValueException) {
        throw new AssertionError(invalidAttributeValueException);
      } 
    } 
  }
  
  private ServerMBean findServerFor(String paramString, DomainMBean paramDomainMBean) {
    ServerMBean[] arrayOfServerMBean = paramDomainMBean.getServers();
    if (arrayOfServerMBean == null)
      return null; 
    for (byte b = 0; b < arrayOfServerMBean.length; b++) {
      WSReliableDeliveryPolicyMBean wSReliableDeliveryPolicyMBean = arrayOfServerMBean[b].getReliableDeliveryPolicy();
      if (wSReliableDeliveryPolicyMBean != null)
        if (wSReliableDeliveryPolicyMBean.getName().equals(paramString))
          return arrayOfServerMBean[b];  
    } 
    return null;
  }
  
  private JMSServerMBean findJMSServerFor(JMSStoreMBean paramJMSStoreMBean, DomainMBean paramDomainMBean) {
    JMSServerMBean[] arrayOfJMSServerMBean = paramDomainMBean.getJMSServers();
    if (arrayOfJMSServerMBean == null)
      return null; 
    for (byte b = 0; b < arrayOfJMSServerMBean.length; b++) {
      JMSStoreMBean jMSStoreMBean = arrayOfJMSServerMBean[b].getStore();
      if (jMSStoreMBean != null)
        if (jMSStoreMBean == paramJMSStoreMBean)
          return arrayOfJMSServerMBean[b];  
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\saf\WSConfigUpdater.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */