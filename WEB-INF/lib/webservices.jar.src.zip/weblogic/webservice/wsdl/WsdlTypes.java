/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsdlTypes
/*    */ {
/*    */   void parseTypes(WebService paramWebService, XMLNode paramXMLNode) {
/* 22 */     if (paramXMLNode != null) {
/* 23 */       for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 24 */         XMLNode xMLNode = (XMLNode)iterator.next();
/* 25 */         xMLNode.inheritNamespace();
/*    */       } 
/* 27 */       paramWebService.setTypes(paramXMLNode);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlTypes.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */