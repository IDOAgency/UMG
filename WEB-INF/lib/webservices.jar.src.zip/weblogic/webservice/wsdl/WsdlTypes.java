package weblogic.webservice.wsdl;

import java.util.Iterator;
import weblogic.webservice.WebService;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlTypes {
  void parseTypes(WebService paramWebService, XMLNode paramXMLNode) {
    if (paramXMLNode != null) {
      for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
        XMLNode xMLNode = (XMLNode)iterator.next();
        xMLNode.inheritNamespace();
      } 
      paramWebService.setTypes(paramXMLNode);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlTypes.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */