/*     */ package weblogic.webservice.wsdl;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterModeHelper
/*     */ {
/*     */   public void updateParameterMode(Operation paramOperation) throws WSDLParseException {
/*  19 */     setParameterMode(paramOperation);
/*     */     
/*  21 */     if (paramOperation.getParameterOrder() != null) {
/*  22 */       handleParamOrder(paramOperation);
/*     */     } else {
/*  24 */       handleNullParamOrder(paramOperation);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleNullParamOrder(Operation paramOperation) throws WSDLParseException {
/*  30 */     Part part = null;
/*     */     
/*  32 */     for (Iterator iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/*  33 */       Part part1 = (Part)iterator.next();
/*     */       
/*  35 */       if (!part1.isHeader()) {
/*  36 */         if (part == null) {
/*  37 */           part = part1;
/*     */           
/*     */           continue;
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     } 
/*  44 */     if (part != null) {
/*  45 */       part.setMode(Part.Mode.RETURN);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleParamOrder(Operation paramOperation) throws WSDLParseException {
/*  52 */     String[] arrayOfString = paramOperation.getParameterOrder();
/*     */     
/*  54 */     if (arrayOfString == null) {
/*     */       return;
/*     */     }
/*     */     
/*  58 */     checkMissingPart(paramOperation, arrayOfString);
/*  59 */     findReturnPart(paramOperation, arrayOfString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void findReturnPart(Operation paramOperation, String[] paramArrayOfString) throws WSDLParseException {
/*  65 */     boolean bool = false;
/*     */     
/*  67 */     for (Iterator iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/*  68 */       Part part = (Part)iterator.next();
/*     */       
/*  70 */       if (!containsString(part.getName(), paramArrayOfString)) {
/*     */         
/*  72 */         if (bool) {
/*     */           
/*  74 */           if (part.isBody()) {
/*  75 */             System.err.println("WARNING: Parameter order [" + toString(paramArrayOfString) + "] for Operation [" + paramOperation.getName() + "] miss more than one part name. " + "Missing part in the parameter order is taken as the return" + "type. Hence there should be only one missing part in " + "the parameterOrder");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  83 */           paramOperation.setParameterOrder((String)null);
/*     */           
/*     */           return;
/*     */         } 
/*  87 */         if (part.getMode() == Part.Mode.INOUT) {
/*  88 */           throw new WSDLParseException("Return part " + part.getName() + " can not be an inout parameter. It should be defined as " + "an out parameter");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  93 */         part.setMode(Part.Mode.RETURN);
/*  94 */         bool = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String toString(String[] paramArrayOfString) {
/* 100 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 102 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 103 */       stringBuffer.append(paramArrayOfString[b]);
/*     */       
/* 105 */       if (b < paramArrayOfString.length - 2) {
/* 106 */         stringBuffer.append(",");
/*     */       }
/*     */     } 
/*     */     
/* 110 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   private boolean containsString(String paramString, String[] paramArrayOfString) {
/* 114 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 115 */       if (paramString.equals(paramArrayOfString[b])) {
/* 116 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkMissingPart(Operation paramOperation, String[] paramArrayOfString) throws WSDLParseException {
/* 126 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/* 127 */       Part part1 = paramOperation.getInput().getPart(paramArrayOfString[b]);
/* 128 */       Part part2 = paramOperation.getOutput().getPart(paramArrayOfString[b]);
/*     */       
/* 130 */       if (part1 == null && part2 == null) {
/* 131 */         throw new WSDLParseException("part specified in the parameterOrder:" + paramArrayOfString[b] + " not defined in in or out message." + paramOperation);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void setParameterMode(Operation paramOperation) throws WSDLParseException {
/*     */     Iterator iterator;
/* 139 */     for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 140 */       Part part1 = (Part)iterator.next();
/* 141 */       Part part2 = paramOperation.getOutput().getPart(part1.getName());
/*     */       
/* 143 */       if (isSamePart(part1, part2)) {
/* 144 */         part1.setMode(Part.Mode.INOUT);
/* 145 */         part2.setMode(Part.Mode.INOUT); continue;
/*     */       } 
/* 147 */       part1.setMode(Part.Mode.IN);
/*     */     } 
/*     */ 
/*     */     
/* 151 */     for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/* 152 */       Part part1 = (Part)iterator.next();
/* 153 */       Part part2 = paramOperation.getInput().getPart(part1.getName());
/*     */       
/* 155 */       if (isSamePart(part2, part1)) {
/* 156 */         part1.setMode(Part.Mode.INOUT); continue;
/*     */       } 
/* 158 */       part1.setMode(Part.Mode.OUT);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSamePart(Part paramPart1, Part paramPart2) {
/* 165 */     if (paramPart1 == null || paramPart2 == null) {
/* 166 */       return false;
/*     */     }
/*     */     
/* 169 */     if (paramPart1.getName().equals(paramPart2.getName())) {
/*     */       
/* 171 */       if (paramPart1.getJavaType() != null && paramPart1.getJavaType().equals(paramPart2.getJavaType()))
/*     */       {
/*     */         
/* 174 */         return true;
/*     */       }
/* 176 */       return false;
/*     */     } 
/*     */     
/* 179 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\ParameterModeHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */