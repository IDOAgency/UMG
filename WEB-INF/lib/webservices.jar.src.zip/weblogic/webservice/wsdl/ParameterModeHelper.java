package weblogic.webservice.wsdl;

import java.util.Iterator;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;

public class ParameterModeHelper {
  public void updateParameterMode(Operation paramOperation) throws WSDLParseException {
    setParameterMode(paramOperation);
    if (paramOperation.getParameterOrder() != null) {
      handleParamOrder(paramOperation);
    } else {
      handleNullParamOrder(paramOperation);
    } 
  }
  
  private void handleNullParamOrder(Operation paramOperation) throws WSDLParseException {
    Part part = null;
    for (Iterator iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part1 = (Part)iterator.next();
      if (!part1.isHeader()) {
        if (part == null) {
          part = part1;
          continue;
        } 
        return;
      } 
    } 
    if (part != null)
      part.setMode(Part.Mode.RETURN); 
  }
  
  private void handleParamOrder(Operation paramOperation) throws WSDLParseException {
    String[] arrayOfString = paramOperation.getParameterOrder();
    if (arrayOfString == null)
      return; 
    checkMissingPart(paramOperation, arrayOfString);
    findReturnPart(paramOperation, arrayOfString);
  }
  
  private void findReturnPart(Operation paramOperation, String[] paramArrayOfString) throws WSDLParseException {
    boolean bool = false;
    for (Iterator iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (!containsString(part.getName(), paramArrayOfString)) {
        if (bool) {
          if (part.isBody())
            System.err.println("WARNING: Parameter order [" + toString(paramArrayOfString) + "] for Operation [" + paramOperation.getName() + "] miss more than one part name. " + "Missing part in the parameter order is taken as the return" + "type. Hence there should be only one missing part in " + "the parameterOrder"); 
          paramOperation.setParameterOrder((String)null);
          return;
        } 
        if (part.getMode() == Part.Mode.INOUT)
          throw new WSDLParseException("Return part " + part.getName() + " can not be an inout parameter. It should be defined as " + "an out parameter"); 
        part.setMode(Part.Mode.RETURN);
        bool = true;
      } 
    } 
  }
  
  private String toString(String[] paramArrayOfString) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      stringBuffer.append(paramArrayOfString[b]);
      if (b < paramArrayOfString.length - 2)
        stringBuffer.append(","); 
    } 
    return stringBuffer.toString();
  }
  
  private boolean containsString(String paramString, String[] paramArrayOfString) {
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramString.equals(paramArrayOfString[b]))
        return true; 
    } 
    return false;
  }
  
  private void checkMissingPart(Operation paramOperation, String[] paramArrayOfString) throws WSDLParseException {
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      Part part1 = paramOperation.getInput().getPart(paramArrayOfString[b]);
      Part part2 = paramOperation.getOutput().getPart(paramArrayOfString[b]);
      if (part1 == null && part2 == null)
        throw new WSDLParseException("part specified in the parameterOrder:" + paramArrayOfString[b] + " not defined in in or out message." + paramOperation); 
    } 
  }
  
  private void setParameterMode(Operation paramOperation) throws WSDLParseException {
    Iterator iterator;
    for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part1 = (Part)iterator.next();
      Part part2 = paramOperation.getOutput().getPart(part1.getName());
      if (isSamePart(part1, part2)) {
        part1.setMode(Part.Mode.INOUT);
        part2.setMode(Part.Mode.INOUT);
        continue;
      } 
      part1.setMode(Part.Mode.IN);
    } 
    for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part1 = (Part)iterator.next();
      Part part2 = paramOperation.getInput().getPart(part1.getName());
      if (isSamePart(part2, part1)) {
        part1.setMode(Part.Mode.INOUT);
        continue;
      } 
      part1.setMode(Part.Mode.OUT);
    } 
  }
  
  private boolean isSamePart(Part paramPart1, Part paramPart2) {
    if (paramPart1 == null || paramPart2 == null)
      return false; 
    if (paramPart1.getName().equals(paramPart2.getName())) {
      if (paramPart1.getJavaType() != null && paramPart1.getJavaType().equals(paramPart2.getJavaType()))
        return true; 
      return false;
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\ParameterModeHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */