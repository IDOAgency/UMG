/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import weblogic.xml.schema.binding.util.StdNamespace;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface WsdlConstants
/*    */ {
/*    */   public static final String SOAP11 = "http://schemas.xmlsoap.org/wsdl/soap/";
/*    */   public static final String SOAP12 = "http://schemas.xmlsoap.org/wsdl/soap12/";
/*    */   public static final String SOAP12_ENC = "http://www.w3.org/2002/12/soap-envelope";
/* 23 */   public static final String wsdlNS = StdNamespace.instance().wsdl();
/*    */   public static final String mimeNS = "http://schemas.xmlsoap.org/wsdl/mime/";
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlConstants.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */