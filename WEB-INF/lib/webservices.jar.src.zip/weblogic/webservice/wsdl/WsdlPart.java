package weblogic.webservice.wsdl;

import javax.xml.rpc.encoding.TypeMapping;
import weblogic.webservice.Message;
import weblogic.webservice.Part;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlPart {
  void parsePart(WSDLParser paramWSDLParser, Message paramMessage, XMLNode paramXMLNode, boolean paramBoolean) throws WSDLParseException {
    boolean bool = true;
    String str1 = paramWSDLParser.getMustAttribute("name", paramXMLNode);
    String str2 = paramXMLNode.getAttribute("type", null);
    if (str2 == null) {
      bool = false;
      str2 = paramWSDLParser.getMustAttribute("element", paramXMLNode);
    } 
    String str3 = paramWSDLParser.getNamespace(str2, paramXMLNode);
    String str4 = paramWSDLParser.removePrefix(str2);
    String str5 = paramMessage.getEncodingStyle();
    if (str5 == null)
      str5 = paramWSDLParser.defaultEncodingStyle; 
    TypeMapping typeMapping = paramWSDLParser.registry.getTypeMapping(str5);
    paramWSDLParser.assertion(typeMapping, "encoding style not supported" + str5);
    Part part = paramMessage.getPart(str1);
    if (part != null && !str4.equals(part.getXMLName().getLocalName())) {
      str1 = str1 + str4;
      part = paramMessage.addPart(str1, str4, str3);
    } 
    if (part == null)
      part = paramMessage.addPart(str1, str4, str3); 
    if (bool) {
      part.setType();
    } else {
      part.setElement();
    } 
    if (paramBoolean)
      part.setHeader(); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlPart.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */