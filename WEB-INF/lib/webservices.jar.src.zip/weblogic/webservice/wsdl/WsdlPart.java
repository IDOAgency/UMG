/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import javax.xml.rpc.encoding.TypeMapping;
/*    */ import weblogic.webservice.Message;
/*    */ import weblogic.webservice.Part;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsdlPart
/*    */ {
/*    */   void parsePart(WSDLParser paramWSDLParser, Message paramMessage, XMLNode paramXMLNode, boolean paramBoolean) throws WSDLParseException {
/* 27 */     boolean bool = true;
/* 28 */     String str1 = paramWSDLParser.getMustAttribute("name", paramXMLNode);
/* 29 */     String str2 = paramXMLNode.getAttribute("type", null);
/*    */     
/* 31 */     if (str2 == null) {
/* 32 */       bool = false;
/* 33 */       str2 = paramWSDLParser.getMustAttribute("element", paramXMLNode);
/*    */     } 
/*    */     
/* 36 */     String str3 = paramWSDLParser.getNamespace(str2, paramXMLNode);
/*    */     
/* 38 */     String str4 = paramWSDLParser.removePrefix(str2);
/*    */ 
/*    */     
/* 41 */     String str5 = paramMessage.getEncodingStyle();
/*    */     
/* 43 */     if (str5 == null) {
/* 44 */       str5 = paramWSDLParser.defaultEncodingStyle;
/*    */     }
/*    */     
/* 47 */     TypeMapping typeMapping = paramWSDLParser.registry.getTypeMapping(str5);
/* 48 */     paramWSDLParser.assertion(typeMapping, "encoding style not supported" + str5);
/*    */     
/* 50 */     Part part = paramMessage.getPart(str1);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 55 */     if (part != null && !str4.equals(part.getXMLName().getLocalName())) {
/* 56 */       str1 = str1 + str4;
/* 57 */       part = paramMessage.addPart(str1, str4, str3);
/*    */     } 
/*    */ 
/*    */     
/* 61 */     if (part == null) {
/* 62 */       part = paramMessage.addPart(str1, str4, str3);
/*    */     }
/*    */     
/* 65 */     if (bool) {
/* 66 */       part.setType();
/*    */     } else {
/* 68 */       part.setElement();
/*    */     } 
/*    */     
/* 71 */     if (paramBoolean)
/* 72 */       part.setHeader(); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlPart.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */