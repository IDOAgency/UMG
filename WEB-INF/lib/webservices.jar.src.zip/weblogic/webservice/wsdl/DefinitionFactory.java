/*     */ package weblogic.webservice.wsdl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Iterator;
/*     */ import weblogic.utils.encoders.BASE64Encoder;
/*     */ import weblogic.utils.net.InetAddressHelper;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.client.SSLAdapter;
/*     */ import weblogic.webservice.client.SSLAdapterFactory;
/*     */ import weblogic.webservice.client.WLSSLAdapter;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefinitionFactory
/*     */ {
/*  28 */   private static String httpsProxyHost = System.getProperty("weblogic.webservice.transport.https.proxy.host");
/*     */   public DefinitionFactory() {
/*  30 */     this.adapter = null;
/*     */ 
/*     */ 
/*     */     
/*  34 */     this.adapter = SSLAdapterFactory.getDefaultFactory().getSSLAdapter();
/*     */   }
/*     */   private SSLAdapter adapter;
/*     */   public DefinitionFactory(SSLAdapter paramSSLAdapter) {
/*     */     this.adapter = null;
/*  39 */     this.adapter = paramSSLAdapter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private URL getWsdlURL(String paramString) throws IOException {
/*     */     try {
/*  47 */       paramString = InetAddressHelper.convertIfIPV6URL(paramString);
/*  48 */       return new URL(paramString);
/*     */     }
/*  50 */     catch (MalformedURLException malformedURLException) {
/*     */ 
/*     */       
/*  53 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */       
/*  55 */       if (classLoader == null) {
/*  56 */         classLoader = getClass().getClassLoader();
/*     */       }
/*     */       
/*  59 */       URL uRL = classLoader.getResource(paramString);
/*     */       
/*  61 */       if (uRL != null) {
/*  62 */         return uRL;
/*     */       }
/*     */       
/*  65 */       uRL = getClass().getResource(paramString);
/*     */       
/*  67 */       if (uRL != null) {
/*  68 */         return uRL;
/*     */       }
/*     */       
/*  71 */       throw new IOException("unable to find resource:" + paramString);
/*     */     } 
/*     */   }
/*     */   public XMLNode createDefinition(String paramString) throws IOException {
/*  75 */     inputStream = null;
/*     */     
/*     */     try {
/*  78 */       URL uRL = getWsdlURL(paramString);
/*     */       
/*  80 */       String str = uRL.getUserInfo();
/*     */       
/*  82 */       if (str != null) {
/*  83 */         uRL = new URL(uRL.getProtocol() + "://" + uRL.getHost() + ":" + uRL.getPort() + uRL.getPath() + "?" + uRL.getQuery());
/*     */         
/*  85 */         BASE64Encoder bASE64Encoder = new BASE64Encoder();
/*  86 */         str = "Basic " + bASE64Encoder.encodeBuffer(str.getBytes());
/*     */       } 
/*     */       
/*  89 */       URLConnection uRLConnection = null;
/*     */       
/*  91 */       if ("https".equalsIgnoreCase(uRL.getProtocol())) {
/*  92 */         if (httpsProxyHost != null && this.adapter instanceof WLSSLAdapter) {
/*  93 */           WLSSLAdapter wLSSLAdapter = (WLSSLAdapter)this.adapter;
/*  94 */           Socket socket = wLSSLAdapter.createSocket(uRL.getHost(), uRL.getPort());
/*  95 */           StringBuffer stringBuffer = new StringBuffer(128);
/*  96 */           if (str == null) {
/*  97 */             stringBuffer.append("GET " + uRL.getFile() + " HTTP/1.0\r\n\r\n");
/*     */           } else {
/*  99 */             stringBuffer.append("GET " + uRL.getFile() + " HTTP/1.0\r\n");
/* 100 */             stringBuffer.append("Authorization: " + str + "\r\n\r\n");
/*     */           } 
/* 102 */           OutputStream outputStream = socket.getOutputStream();
/* 103 */           outputStream.write(stringBuffer.toString().getBytes());
/* 104 */           outputStream.flush();
/* 105 */           outputStream.close();
/* 106 */           inputStream = socket.getInputStream();
/*     */         } else {
/* 108 */           uRLConnection = this.adapter.openConnection(uRL);
/* 109 */           if (str != null)
/* 110 */             uRLConnection.setRequestProperty("Authorization", str); 
/* 111 */           inputStream = uRLConnection.getInputStream();
/*     */         } 
/*     */       } else {
/*     */         
/* 115 */         uRLConnection = uRL.openConnection();
/* 116 */         if (str != null)
/* 117 */           uRLConnection.setRequestProperty("Authorization", str); 
/* 118 */         inputStream = uRLConnection.getInputStream();
/*     */       } 
/*     */       
/* 121 */       XMLNode xMLNode = new XMLNode();
/* 122 */       xMLNode.read(inputStream, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 148 */       resolveImports(paramString, xMLNode);
/*     */       
/* 150 */       return xMLNode;
/*     */     
/*     */     }
/* 153 */     catch (IOException iOException) {
/*     */       
/* 155 */       String str = WebServiceLogger.logDefinitionFactoryIOException();
/* 156 */       WebServiceLogger.logStackTrace(str, iOException);
/*     */       
/* 158 */       throw new WSDLParseException("Failed to retrieve WSDL from " + paramString + ". Please check the URL and make sure " + "that it is a valid XML file [" + iOException + "]");
/*     */     }
/*     */     finally {
/*     */       
/* 162 */       if (inputStream != null) {
/* 163 */         inputStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void resolveImports(String paramString, XMLNode paramXMLNode) throws IOException {
/* 171 */     XMLNode xMLNode1 = paramXMLNode.getChild("import", WsdlConstants.wsdlNS);
/*     */     
/* 173 */     if (xMLNode1 == null) {
/*     */       return;
/*     */     }
/*     */     
/* 177 */     paramXMLNode.removeChild(xMLNode1);
/*     */     
/* 179 */     String str1 = xMLNode1.getAttribute("location", null);
/* 180 */     URL uRL = findImportedWSDL(paramString, str1);
/*     */ 
/*     */     
/* 183 */     if (str1 != null) {
/* 184 */       int i = str1.lastIndexOf('/');
/* 185 */       if (i != -1) {
/* 186 */         str1 = str1.substring(0, i);
/*     */       }
/*     */       else {
/*     */         
/* 190 */         str1 = null;
/*     */       } 
/*     */     } 
/*     */     
/* 194 */     XMLNode xMLNode2 = new XMLNode(str1);
/*     */     
/* 196 */     InputStream inputStream = null;
/*     */     
/* 198 */     if (this.adapter != null) {
/* 199 */       inputStream = this.adapter.openConnection(uRL).getInputStream();
/*     */     } else {
/* 201 */       inputStream = uRL.openStream();
/*     */     } 
/* 203 */     xMLNode2.read(inputStream, true);
/*     */     
/* 205 */     String str2 = xMLNode2.getName().getLocalName();
/*     */     
/* 207 */     if ("schema".equals(str2)) {
/* 208 */       addToTypes(paramXMLNode, xMLNode2);
/* 209 */     } else if ("definitions".equals(str2)) {
/* 210 */       resolveImports(uRL.toString(), xMLNode2);
/* 211 */       addToDefinition(paramXMLNode, xMLNode2);
/*     */     } else {
/* 213 */       throw new WSDLParseException("unknown element in the imported wsdl:" + str2);
/*     */     } 
/*     */ 
/*     */     
/* 217 */     resolveImports(paramString, paramXMLNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private URL findImportedWSDL(String paramString1, String paramString2) throws WSDLParseException, IOException {
/* 223 */     if (paramString2 == null) {
/* 224 */       throw new WSDLParseException("location must be specified in import:");
/*     */     }
/*     */     
/*     */     try {
/* 228 */       return new URL(paramString2);
/* 229 */     } catch (IOException iOException) {
/* 230 */       return new URL(removeFile(paramString1) + "/" + paramString2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String removeFile(String paramString) {
/* 235 */     int i = paramString.lastIndexOf("/");
/*     */     
/* 237 */     if (i != -1) {
/* 238 */       paramString = paramString.substring(0, i);
/*     */     }
/*     */     
/* 241 */     return paramString;
/*     */   }
/*     */   
/*     */   private void addToTypes(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
/* 245 */     XMLNode xMLNode = paramXMLNode1.getChild("types", WsdlConstants.wsdlNS);
/*     */ 
/*     */     
/* 248 */     if (xMLNode == null) {
/* 249 */       xMLNode = paramXMLNode1.addChild("types", paramXMLNode1.getName().getPrefix(), WsdlConstants.wsdlNS);
/*     */     }
/*     */ 
/*     */     
/* 253 */     xMLNode.addChild(paramXMLNode2);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addToDefinition(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
/* 258 */     for (Iterator iterator = paramXMLNode2.getChildren(); iterator.hasNext(); ) {
/* 259 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 261 */       if ("types".equals(xMLNode.getName().getLocalName())) {
/*     */         
/* 263 */         for (Iterator iterator1 = xMLNode.getChildren(); iterator1.hasNext();)
/* 264 */           addToTypes(paramXMLNode1, (XMLNode)iterator1.next()); 
/*     */         continue;
/*     */       } 
/* 267 */       paramXMLNode1.addChild(xMLNode);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\DefinitionFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */