package weblogic.webservice.wsdl;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.util.Iterator;
import weblogic.utils.encoders.BASE64Encoder;
import weblogic.utils.net.InetAddressHelper;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.client.SSLAdapter;
import weblogic.webservice.client.SSLAdapterFactory;
import weblogic.webservice.client.WLSSLAdapter;
import weblogic.xml.xmlnode.XMLNode;

public class DefinitionFactory {
  private static String httpsProxyHost = System.getProperty("weblogic.webservice.transport.https.proxy.host");
  
  private SSLAdapter adapter;
  
  public DefinitionFactory() {
    this.adapter = null;
    this.adapter = SSLAdapterFactory.getDefaultFactory().getSSLAdapter();
  }
  
  public DefinitionFactory(SSLAdapter paramSSLAdapter) {
    this.adapter = null;
    this.adapter = paramSSLAdapter;
  }
  
  private URL getWsdlURL(String paramString) throws IOException {
    try {
      paramString = InetAddressHelper.convertIfIPV6URL(paramString);
      return new URL(paramString);
    } catch (MalformedURLException malformedURLException) {
      ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
      if (classLoader == null)
        classLoader = getClass().getClassLoader(); 
      URL uRL = classLoader.getResource(paramString);
      if (uRL != null)
        return uRL; 
      uRL = getClass().getResource(paramString);
      if (uRL != null)
        return uRL; 
      throw new IOException("unable to find resource:" + paramString);
    } 
  }
  
  public XMLNode createDefinition(String paramString) throws IOException {
    inputStream = null;
    try {
      URL uRL = getWsdlURL(paramString);
      String str = uRL.getUserInfo();
      if (str != null) {
        uRL = new URL(uRL.getProtocol() + "://" + uRL.getHost() + ":" + uRL.getPort() + uRL.getPath() + "?" + uRL.getQuery());
        BASE64Encoder bASE64Encoder = new BASE64Encoder();
        str = "Basic " + bASE64Encoder.encodeBuffer(str.getBytes());
      } 
      URLConnection uRLConnection = null;
      if ("https".equalsIgnoreCase(uRL.getProtocol())) {
        if (httpsProxyHost != null && this.adapter instanceof WLSSLAdapter) {
          WLSSLAdapter wLSSLAdapter = (WLSSLAdapter)this.adapter;
          Socket socket = wLSSLAdapter.createSocket(uRL.getHost(), uRL.getPort());
          StringBuffer stringBuffer = new StringBuffer(128);
          if (str == null) {
            stringBuffer.append("GET " + uRL.getFile() + " HTTP/1.0\r\n\r\n");
          } else {
            stringBuffer.append("GET " + uRL.getFile() + " HTTP/1.0\r\n");
            stringBuffer.append("Authorization: " + str + "\r\n\r\n");
          } 
          OutputStream outputStream = socket.getOutputStream();
          outputStream.write(stringBuffer.toString().getBytes());
          outputStream.flush();
          outputStream.close();
          inputStream = socket.getInputStream();
        } else {
          uRLConnection = this.adapter.openConnection(uRL);
          if (str != null)
            uRLConnection.setRequestProperty("Authorization", str); 
          inputStream = uRLConnection.getInputStream();
        } 
      } else {
        uRLConnection = uRL.openConnection();
        if (str != null)
          uRLConnection.setRequestProperty("Authorization", str); 
        inputStream = uRLConnection.getInputStream();
      } 
      XMLNode xMLNode = new XMLNode();
      xMLNode.read(inputStream, true);
      resolveImports(paramString, xMLNode);
      return xMLNode;
    } catch (IOException iOException) {
      String str = WebServiceLogger.logDefinitionFactoryIOException();
      WebServiceLogger.logStackTrace(str, iOException);
      throw new WSDLParseException("Failed to retrieve WSDL from " + paramString + ". Please check the URL and make sure " + "that it is a valid XML file [" + iOException + "]");
    } finally {
      if (inputStream != null)
        inputStream.close(); 
    } 
  }
  
  private void resolveImports(String paramString, XMLNode paramXMLNode) throws IOException {
    XMLNode xMLNode1 = paramXMLNode.getChild("import", WsdlConstants.wsdlNS);
    if (xMLNode1 == null)
      return; 
    paramXMLNode.removeChild(xMLNode1);
    String str1 = xMLNode1.getAttribute("location", null);
    URL uRL = findImportedWSDL(paramString, str1);
    if (str1 != null) {
      int i = str1.lastIndexOf('/');
      if (i != -1) {
        str1 = str1.substring(0, i);
      } else {
        str1 = null;
      } 
    } 
    XMLNode xMLNode2 = new XMLNode(str1);
    InputStream inputStream = null;
    if (this.adapter != null) {
      inputStream = this.adapter.openConnection(uRL).getInputStream();
    } else {
      inputStream = uRL.openStream();
    } 
    xMLNode2.read(inputStream, true);
    String str2 = xMLNode2.getName().getLocalName();
    if ("schema".equals(str2)) {
      addToTypes(paramXMLNode, xMLNode2);
    } else if ("definitions".equals(str2)) {
      resolveImports(uRL.toString(), xMLNode2);
      addToDefinition(paramXMLNode, xMLNode2);
    } else {
      throw new WSDLParseException("unknown element in the imported wsdl:" + str2);
    } 
    resolveImports(paramString, paramXMLNode);
  }
  
  private URL findImportedWSDL(String paramString1, String paramString2) throws WSDLParseException, IOException {
    if (paramString2 == null)
      throw new WSDLParseException("location must be specified in import:"); 
    try {
      return new URL(paramString2);
    } catch (IOException iOException) {
      return new URL(removeFile(paramString1) + "/" + paramString2);
    } 
  }
  
  private String removeFile(String paramString) {
    int i = paramString.lastIndexOf("/");
    if (i != -1)
      paramString = paramString.substring(0, i); 
    return paramString;
  }
  
  private void addToTypes(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
    XMLNode xMLNode = paramXMLNode1.getChild("types", WsdlConstants.wsdlNS);
    if (xMLNode == null)
      xMLNode = paramXMLNode1.addChild("types", paramXMLNode1.getName().getPrefix(), WsdlConstants.wsdlNS); 
    xMLNode.addChild(paramXMLNode2);
  }
  
  private void addToDefinition(XMLNode paramXMLNode1, XMLNode paramXMLNode2) {
    for (Iterator iterator = paramXMLNode2.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("types".equals(xMLNode.getName().getLocalName())) {
        for (Iterator iterator1 = xMLNode.getChildren(); iterator1.hasNext();)
          addToTypes(paramXMLNode1, (XMLNode)iterator1.next()); 
        continue;
      } 
      paramXMLNode1.addChild(xMLNode);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\DefinitionFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */