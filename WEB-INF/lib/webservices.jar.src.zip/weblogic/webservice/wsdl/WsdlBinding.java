package weblogic.webservice.wsdl;

import java.io.IOException;
import java.util.Iterator;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.binding.jms.JMSBindingInfo;
import weblogic.xml.security.specs.SecurityDD;
import weblogic.xml.security.specs.SecuritySpec;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlBinding {
  void parseBinding(WSDLParser paramWSDLParser, WebService paramWebService, Port paramPort, XMLNode paramXMLNode) throws IOException {
    String str1 = paramWSDLParser.getMustAttribute("type", paramXMLNode);
    XMLNode xMLNode1 = paramWSDLParser.getNodeWithName("portType", str1, paramWSDLParser.definition);
    paramWSDLParser.assertion(xMLNode1, "portType not found:" + str1);
    XMLNode xMLNode2 = paramXMLNode.getChild("binding", paramWSDLParser.soapNS);
    paramWSDLParser.assertion(xMLNode2, "soap binding not found");
    String str2 = parseSoapBinding(paramWSDLParser, paramPort, xMLNode2);
    parseSecBindingExtension(paramWebService, paramXMLNode);
    (new WsdlPortType()).parsePortType(paramWSDLParser, xMLNode1, paramPort);
    for (Iterator iterator = xMLNode1.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode3 = (XMLNode)iterator.next();
      String str = paramWSDLParser.getMustAttribute("name", xMLNode3);
      if (!paramWSDLParser.canHandleMethod(xMLNode3))
        continue; 
      XMLNode xMLNode4 = paramWSDLParser.getNodeWithName("operation", str, paramXMLNode);
      paramWSDLParser.assertion(xMLNode4, "binding.operation not found:" + str);
      Operation operation = paramPort.getOperation(str);
      paramWSDLParser.assertion(operation, "unable to find operation:" + str);
      (new WsdlBindingOperation()).parseBindingOperation(paramWSDLParser, str2, operation, xMLNode4);
      paramWSDLParser.parameterModeHelper.updateParameterMode(operation);
      if (operation.isDocumentStyle())
        operation.setParameterOrder(new String[0]); 
    } 
  }
  
  String parseSoapBinding(WSDLParser paramWSDLParser, Port paramPort, XMLNode paramXMLNode) throws WSDLParseException {
    String str1 = paramWSDLParser.getMustAttribute("transport", paramXMLNode);
    String str2 = paramXMLNode.getAttribute("style", null);
    if (str2 == null)
      str2 = "document"; 
    paramPort.setStyle(str2);
    if (str1.equals("http://schemas.xmlsoap.org/soap/http") || str1.equals("http://schemas.xmlsoap.org/soap/http/") || str1.equals("http://schemas.xmlsoap.org/soap12/http") || str1.equals("http://schemas.xmlsoap.org/soap12/http/")) {
      paramPort.setBindingInfo(new BindingInfo());
    } else if ("http://www.openuri.org/2002/04/soap/jms/".equals(str1)) {
      paramPort.setBindingInfo(new JMSBindingInfo());
    } else {
      throw new WSDLParseException("transport not supported:" + str1);
    } 
    return str2;
  }
  
  void parseSecBindingExtension(WebService paramWebService, XMLNode paramXMLNode) throws IOException {
    Iterator iterator = paramXMLNode.getChildren("SecuritySpec", "http://www.openuri.org/2002/11/wsse/spec");
    SecurityDD securityDD = null;
    while (iterator.hasNext()) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      SecuritySpec securitySpec = new SecuritySpec(xMLNode.stream());
      if (securityDD == null) {
        securityDD = new SecurityDD(securitySpec);
        continue;
      } 
      securityDD.addSecuritySpec(securitySpec);
    } 
    paramWebService.setSecurity(securityDD);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */