/*     */ package weblogic.webservice.wsdl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.binding.jms.JMSBindingInfo;
/*     */ import weblogic.xml.security.specs.SecurityDD;
/*     */ import weblogic.xml.security.specs.SecuritySpec;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsdlBinding
/*     */ {
/*     */   void parseBinding(WSDLParser paramWSDLParser, WebService paramWebService, Port paramPort, XMLNode paramXMLNode) throws IOException {
/*  31 */     String str1 = paramWSDLParser.getMustAttribute("type", paramXMLNode);
/*     */     
/*  33 */     XMLNode xMLNode1 = paramWSDLParser.getNodeWithName("portType", str1, paramWSDLParser.definition);
/*     */ 
/*     */     
/*  36 */     paramWSDLParser.assertion(xMLNode1, "portType not found:" + str1);
/*     */     
/*  38 */     XMLNode xMLNode2 = paramXMLNode.getChild("binding", paramWSDLParser.soapNS);
/*  39 */     paramWSDLParser.assertion(xMLNode2, "soap binding not found");
/*     */     
/*  41 */     String str2 = parseSoapBinding(paramWSDLParser, paramPort, xMLNode2);
/*     */     
/*  43 */     parseSecBindingExtension(paramWebService, paramXMLNode);
/*     */     
/*  45 */     (new WsdlPortType()).parsePortType(paramWSDLParser, xMLNode1, paramPort);
/*     */     
/*  47 */     for (Iterator iterator = xMLNode1.getChildren(); iterator.hasNext(); ) {
/*  48 */       XMLNode xMLNode3 = (XMLNode)iterator.next();
/*  49 */       String str = paramWSDLParser.getMustAttribute("name", xMLNode3);
/*     */       
/*  51 */       if (!paramWSDLParser.canHandleMethod(xMLNode3)) {
/*     */         continue;
/*     */       }
/*     */       
/*  55 */       XMLNode xMLNode4 = paramWSDLParser.getNodeWithName("operation", str, paramXMLNode);
/*     */ 
/*     */       
/*  58 */       paramWSDLParser.assertion(xMLNode4, "binding.operation not found:" + str);
/*     */ 
/*     */       
/*  61 */       Operation operation = paramPort.getOperation(str);
/*     */       
/*  63 */       paramWSDLParser.assertion(operation, "unable to find operation:" + str);
/*     */ 
/*     */       
/*  66 */       (new WsdlBindingOperation()).parseBindingOperation(paramWSDLParser, str2, operation, xMLNode4);
/*     */ 
/*     */       
/*  69 */       paramWSDLParser.parameterModeHelper.updateParameterMode(operation);
/*     */       
/*  71 */       if (operation.isDocumentStyle()) {
/*  72 */         operation.setParameterOrder(new String[0]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String parseSoapBinding(WSDLParser paramWSDLParser, Port paramPort, XMLNode paramXMLNode) throws WSDLParseException {
/*  81 */     String str1 = paramWSDLParser.getMustAttribute("transport", paramXMLNode);
/*  82 */     String str2 = paramXMLNode.getAttribute("style", null);
/*     */     
/*  84 */     if (str2 == null) {
/*  85 */       str2 = "document";
/*     */     }
/*     */     
/*  88 */     paramPort.setStyle(str2);
/*     */     
/*  90 */     if (str1.equals("http://schemas.xmlsoap.org/soap/http") || str1.equals("http://schemas.xmlsoap.org/soap/http/") || str1.equals("http://schemas.xmlsoap.org/soap12/http") || str1.equals("http://schemas.xmlsoap.org/soap12/http/")) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       paramPort.setBindingInfo(new BindingInfo());
/*     */     }
/*  97 */     else if ("http://www.openuri.org/2002/04/soap/jms/".equals(str1)) {
/*     */       
/*  99 */       paramPort.setBindingInfo(new JMSBindingInfo());
/*     */     } else {
/* 101 */       throw new WSDLParseException("transport not supported:" + str1);
/*     */     } 
/*     */     
/* 104 */     return str2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void parseSecBindingExtension(WebService paramWebService, XMLNode paramXMLNode) throws IOException {
/* 110 */     Iterator iterator = paramXMLNode.getChildren("SecuritySpec", "http://www.openuri.org/2002/11/wsse/spec");
/*     */ 
/*     */     
/* 113 */     SecurityDD securityDD = null;
/* 114 */     while (iterator.hasNext()) {
/* 115 */       XMLNode xMLNode = (XMLNode)iterator.next();
/* 116 */       SecuritySpec securitySpec = new SecuritySpec(xMLNode.stream());
/* 117 */       if (securityDD == null) {
/* 118 */         securityDD = new SecurityDD(securitySpec); continue;
/*     */       } 
/* 120 */       securityDD.addSecuritySpec(securitySpec);
/*     */     } 
/*     */ 
/*     */     
/* 124 */     paramWebService.setSecurity(securityDD);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlBinding.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */