/*     */ package weblogic.webservice.wsdl;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.core.FaultMessage;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WsdlBindingOperation
/*     */ {
/*     */   void parseBindingOperation(WSDLParser paramWSDLParser, String paramString, Operation paramOperation, XMLNode paramXMLNode) throws WSDLParseException {
/*  29 */     XMLNode xMLNode1 = paramXMLNode.getChild("operation", paramWSDLParser.soapNS);
/*     */ 
/*     */     
/*  32 */     if (xMLNode1 != null) {
/*  33 */       String str1 = xMLNode1.getAttribute("soapAction", null);
/*     */       
/*  35 */       if (str1 != null) {
/*  36 */         paramOperation.setSoapAction(str1);
/*     */       }
/*     */       
/*  39 */       String str2 = xMLNode1.getAttribute("style", null);
/*     */       
/*  41 */       if (str2 == null) {
/*  42 */         str2 = paramString;
/*     */       }
/*     */       
/*  45 */       if ("rpc".equals(str2)) {
/*  46 */         paramOperation.setRpcStyle();
/*     */       }
/*     */       
/*  49 */       if ("document".equals(str2)) {
/*  50 */         paramOperation.setDocumentStyle();
/*     */       }
/*     */     } 
/*     */     
/*  54 */     parseReliabilityExtension(paramWSDLParser, paramOperation, paramXMLNode);
/*  55 */     parseConversationPhase(paramWSDLParser, paramOperation, paramXMLNode);
/*     */     
/*  57 */     XMLNode xMLNode2 = paramXMLNode.getChild("input", WsdlConstants.wsdlNS);
/*     */     
/*  59 */     if (xMLNode2 != null) {
/*  60 */       WSDLParser.parseBindingMessage(paramWSDLParser, paramOperation, xMLNode2, paramOperation.getInput());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  65 */     XMLNode xMLNode3 = paramXMLNode.getChild("output", WsdlConstants.wsdlNS);
/*     */     
/*  67 */     if (xMLNode3 != null) {
/*  68 */       WSDLParser.parseBindingMessage(paramWSDLParser, paramOperation, xMLNode3, paramOperation.getOutput());
/*     */     }
/*     */ 
/*     */     
/*  72 */     Name name = new Name(WsdlConstants.wsdlNS, "fault");
/*     */     
/*  74 */     for (Iterator iterator = paramXMLNode.getChildren(name); iterator.hasNext(); ) {
/*  75 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/*  77 */       if (!xMLNode.getChildren().hasNext()) {
/*  78 */         paramWSDLParser.assertion(null, "There is no child found for wsdl:fault in binding operation " + paramXMLNode);
/*     */       }
/*     */ 
/*     */       
/*  82 */       String str = ((XMLNode)xMLNode.getChildren().next()).getAttribute("name", null);
/*     */ 
/*     */       
/*  85 */       paramWSDLParser.assertion(str, "There is no name attribute found for soap:fault in binding operation " + paramXMLNode);
/*     */ 
/*     */       
/*  88 */       FaultMessage faultMessage = null;
/*  89 */       for (Iterator iterator1 = paramOperation.getFaults(); iterator1.hasNext(); ) {
/*  90 */         faultMessage = (FaultMessage)iterator1.next();
/*  91 */         if (str.equals(faultMessage.getFaultName())) {
/*     */           break;
/*     */         }
/*  94 */         faultMessage = null;
/*     */       } 
/*     */ 
/*     */       
/*  98 */       paramWSDLParser.assertion(faultMessage, "wsdl:fault with name " + str + " in wsdl:binding is not found in portType");
/*     */       
/* 100 */       WSDLParser.parseBindingMessage(paramWSDLParser, paramOperation, xMLNode, faultMessage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void parseReliabilityExtension(WSDLParser paramWSDLParser, Operation paramOperation, XMLNode paramXMLNode) throws WSDLParseException {
/* 107 */     XMLNode xMLNode = paramXMLNode.getChild("reliability", "http://www.openuri.org/2002/10/soap/reliability/");
/*     */     
/* 109 */     if (xMLNode != null) {
/* 110 */       String str = paramWSDLParser.getMustAttribute("persistDuration", xMLNode);
/* 111 */       paramOperation.setPersistDurationTime(Integer.parseInt(str));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void parseConversationPhase(WSDLParser paramWSDLParser, Operation paramOperation, XMLNode paramXMLNode) throws WSDLParseException {
/* 118 */     XMLNode xMLNode = paramXMLNode.getChild("transition", "http://www.openuri.org/2002/04/wsdl/conversation/");
/*     */     
/* 120 */     if (xMLNode != null) {
/* 121 */       String str = paramWSDLParser.getMustAttribute("phase", xMLNode);
/* 122 */       if ("continue".equals(str)) {
/* 123 */         paramOperation.setConversationPhase("CONTINUE");
/* 124 */       } else if ("start".equals(str)) {
/* 125 */         paramOperation.setConversationPhase("START");
/* 126 */       } else if ("finish".equals(str)) {
/* 127 */         paramOperation.setConversationPhase("FINISH");
/*     */       } else {
/* 129 */         throw new WSDLParseException("unknown conversation phase \"" + str + "\"");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlBindingOperation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */