package weblogic.webservice.wsdl;

import java.util.Iterator;
import weblogic.webservice.Operation;
import weblogic.webservice.core.FaultMessage;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlBindingOperation {
  void parseBindingOperation(WSDLParser paramWSDLParser, String paramString, Operation paramOperation, XMLNode paramXMLNode) throws WSDLParseException {
    XMLNode xMLNode1 = paramXMLNode.getChild("operation", paramWSDLParser.soapNS);
    if (xMLNode1 != null) {
      String str1 = xMLNode1.getAttribute("soapAction", null);
      if (str1 != null)
        paramOperation.setSoapAction(str1); 
      String str2 = xMLNode1.getAttribute("style", null);
      if (str2 == null)
        str2 = paramString; 
      if ("rpc".equals(str2))
        paramOperation.setRpcStyle(); 
      if ("document".equals(str2))
        paramOperation.setDocumentStyle(); 
    } 
    parseReliabilityExtension(paramWSDLParser, paramOperation, paramXMLNode);
    parseConversationPhase(paramWSDLParser, paramOperation, paramXMLNode);
    XMLNode xMLNode2 = paramXMLNode.getChild("input", WsdlConstants.wsdlNS);
    if (xMLNode2 != null)
      WSDLParser.parseBindingMessage(paramWSDLParser, paramOperation, xMLNode2, paramOperation.getInput()); 
    XMLNode xMLNode3 = paramXMLNode.getChild("output", WsdlConstants.wsdlNS);
    if (xMLNode3 != null)
      WSDLParser.parseBindingMessage(paramWSDLParser, paramOperation, xMLNode3, paramOperation.getOutput()); 
    Name name = new Name(WsdlConstants.wsdlNS, "fault");
    for (Iterator iterator = paramXMLNode.getChildren(name); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if (!xMLNode.getChildren().hasNext())
        paramWSDLParser.assertion(null, "There is no child found for wsdl:fault in binding operation " + paramXMLNode); 
      String str = ((XMLNode)xMLNode.getChildren().next()).getAttribute("name", null);
      paramWSDLParser.assertion(str, "There is no name attribute found for soap:fault in binding operation " + paramXMLNode);
      FaultMessage faultMessage = null;
      for (Iterator iterator1 = paramOperation.getFaults(); iterator1.hasNext(); ) {
        faultMessage = (FaultMessage)iterator1.next();
        if (str.equals(faultMessage.getFaultName()))
          break; 
        faultMessage = null;
      } 
      paramWSDLParser.assertion(faultMessage, "wsdl:fault with name " + str + " in wsdl:binding is not found in portType");
      WSDLParser.parseBindingMessage(paramWSDLParser, paramOperation, xMLNode, faultMessage);
    } 
  }
  
  void parseReliabilityExtension(WSDLParser paramWSDLParser, Operation paramOperation, XMLNode paramXMLNode) throws WSDLParseException {
    XMLNode xMLNode = paramXMLNode.getChild("reliability", "http://www.openuri.org/2002/10/soap/reliability/");
    if (xMLNode != null) {
      String str = paramWSDLParser.getMustAttribute("persistDuration", xMLNode);
      paramOperation.setPersistDurationTime(Integer.parseInt(str));
    } 
  }
  
  void parseConversationPhase(WSDLParser paramWSDLParser, Operation paramOperation, XMLNode paramXMLNode) throws WSDLParseException {
    XMLNode xMLNode = paramXMLNode.getChild("transition", "http://www.openuri.org/2002/04/wsdl/conversation/");
    if (xMLNode != null) {
      String str = paramWSDLParser.getMustAttribute("phase", xMLNode);
      if ("continue".equals(str)) {
        paramOperation.setConversationPhase("CONTINUE");
      } else if ("start".equals(str)) {
        paramOperation.setConversationPhase("START");
      } else if ("finish".equals(str)) {
        paramOperation.setConversationPhase("FINISH");
      } else {
        throw new WSDLParseException("unknown conversation phase \"" + str + "\"");
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlBindingOperation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */