/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.Message;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsdlMessage
/*    */ {
/* 21 */   private ArrayList parts = new ArrayList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void parseMessage(WSDLParser paramWSDLParser, Message paramMessage, XMLNode paramXMLNode, boolean paramBoolean) throws WSDLParseException {
/* 30 */     for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 31 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*    */       
/* 33 */       if ("documentation".equals(xMLNode.getName().getLocalName())) {
/*    */         continue;
/*    */       }
/*    */       
/* 37 */       WsdlPart wsdlPart = new WsdlPart();
/* 38 */       wsdlPart.parsePart(paramWSDLParser, paramMessage, xMLNode, paramBoolean);
/* 39 */       this.parts.add(wsdlPart);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   static void populateMessage(Message paramMessage, XMLNode paramXMLNode) {
/* 45 */     String str1 = paramXMLNode.getAttribute("encodingStyle", null);
/* 46 */     String str2 = paramXMLNode.getAttribute("use", null);
/*    */     
/* 48 */     if ("literal".equals(str2)) {
/* 49 */       paramMessage.useLiteral();
/*    */     }
/*    */     
/* 52 */     if ("encoded".equals(str2)) {
/* 53 */       paramMessage.useEncoded();
/*    */     }
/*    */     
/* 56 */     if (str1 != null) {
/* 57 */       paramMessage.setEncodingStyle(str1);
/*    */     }
/*    */     
/* 60 */     paramMessage.setNamespace(paramXMLNode.getAttribute("namespace", null));
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */