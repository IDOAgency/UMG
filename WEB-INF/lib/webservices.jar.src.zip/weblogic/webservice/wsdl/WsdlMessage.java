package weblogic.webservice.wsdl;

import java.util.ArrayList;
import java.util.Iterator;
import weblogic.webservice.Message;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlMessage {
  private ArrayList parts = new ArrayList();
  
  void parseMessage(WSDLParser paramWSDLParser, Message paramMessage, XMLNode paramXMLNode, boolean paramBoolean) throws WSDLParseException {
    for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("documentation".equals(xMLNode.getName().getLocalName()))
        continue; 
      WsdlPart wsdlPart = new WsdlPart();
      wsdlPart.parsePart(paramWSDLParser, paramMessage, xMLNode, paramBoolean);
      this.parts.add(wsdlPart);
    } 
  }
  
  static void populateMessage(Message paramMessage, XMLNode paramXMLNode) {
    String str1 = paramXMLNode.getAttribute("encodingStyle", null);
    String str2 = paramXMLNode.getAttribute("use", null);
    if ("literal".equals(str2))
      paramMessage.useLiteral(); 
    if ("encoded".equals(str2))
      paramMessage.useEncoded(); 
    if (str1 != null)
      paramMessage.setEncodingStyle(str1); 
    paramMessage.setNamespace(paramXMLNode.getAttribute("namespace", null));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlMessage.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */