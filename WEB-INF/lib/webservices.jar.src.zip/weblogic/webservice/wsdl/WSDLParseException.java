/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSDLParseException
/*    */   extends IOException
/*    */ {
/* 11 */   public WSDLParseException(String paramString) { super(paramString); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WSDLParseException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */