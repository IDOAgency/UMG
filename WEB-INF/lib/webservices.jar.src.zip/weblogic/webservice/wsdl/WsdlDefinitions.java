package weblogic.webservice.wsdl;

import java.io.IOException;
import java.util.Iterator;
import weblogic.webservice.WebService;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlDefinitions {
  private WsdlTypes wsdlTypes;
  
  private WsdlService wsdlService;
  
  void parseDefinition(WSDLParser paramWSDLParser, WebService paramWebService) throws IOException {
    paramWebService.setTargetNamespace(paramWSDLParser.definition.getAttribute("targetNamespace", null));
    XMLNode xMLNode1 = paramWSDLParser.definition.getChild("types", WsdlConstants.wsdlNS);
    this.wsdlTypes = new WsdlTypes();
    this.wsdlTypes.parseTypes(paramWebService, xMLNode1);
    XMLNode xMLNode2 = getService(paramWSDLParser, paramWSDLParser.definition);
    this.wsdlService = new WsdlService();
    this.wsdlService.parseService(paramWSDLParser, paramWebService, xMLNode2);
  }
  
  XMLNode getService(WSDLParser paramWSDLParser, XMLNode paramXMLNode) throws IOException {
    for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("service".equals(xMLNode.getName().getLocalName())) {
        if (paramWSDLParser.serviceName == null)
          return xMLNode; 
        String str1 = xMLNode.getAttribute("name", null);
        if (paramWSDLParser.serviceName.equals(str1))
          return xMLNode; 
      } 
    } 
    String str = "unable to find service";
    str = (paramWSDLParser.serviceName == null) ? str : (str + " \"" + paramWSDLParser.serviceName + "\"");
    throw new WSDLParseException(str);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlDefinitions.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */