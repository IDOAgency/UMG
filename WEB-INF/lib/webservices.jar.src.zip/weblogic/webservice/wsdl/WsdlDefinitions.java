/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsdlDefinitions
/*    */ {
/*    */   private WsdlTypes wsdlTypes;
/*    */   private WsdlService wsdlService;
/*    */   
/*    */   void parseDefinition(WSDLParser paramWSDLParser, WebService paramWebService) throws IOException {
/* 27 */     paramWebService.setTargetNamespace(paramWSDLParser.definition.getAttribute("targetNamespace", null));
/*    */ 
/*    */     
/* 30 */     XMLNode xMLNode1 = paramWSDLParser.definition.getChild("types", WsdlConstants.wsdlNS);
/*    */ 
/*    */     
/* 33 */     this.wsdlTypes = new WsdlTypes();
/* 34 */     this.wsdlTypes.parseTypes(paramWebService, xMLNode1);
/*    */     
/* 36 */     XMLNode xMLNode2 = getService(paramWSDLParser, paramWSDLParser.definition);
/* 37 */     this.wsdlService = new WsdlService();
/* 38 */     this.wsdlService.parseService(paramWSDLParser, paramWebService, xMLNode2);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   XMLNode getService(WSDLParser paramWSDLParser, XMLNode paramXMLNode) throws IOException {
/* 44 */     for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 45 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*    */       
/* 47 */       if ("service".equals(xMLNode.getName().getLocalName())) {
/*    */         
/* 49 */         if (paramWSDLParser.serviceName == null) {
/* 50 */           return xMLNode;
/*    */         }
/* 52 */         String str1 = xMLNode.getAttribute("name", null);
/*    */         
/* 54 */         if (paramWSDLParser.serviceName.equals(str1)) {
/* 55 */           return xMLNode;
/*    */         }
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 61 */     String str = "unable to find service";
/*    */     
/* 63 */     str = (paramWSDLParser.serviceName == null) ? str : (str + " \"" + paramWSDLParser.serviceName + "\"");
/*    */ 
/*    */     
/* 66 */     throw new WSDLParseException(str);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlDefinitions.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */