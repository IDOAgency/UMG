package weblogic.webservice.wsdl;

import java.io.IOException;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.binding.https.HttpsBindingInfo;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlPort {
  void parsePort(WSDLParser paramWSDLParser, WebService paramWebService, XMLNode paramXMLNode) throws IOException {
    String str1 = paramWSDLParser.getMustAttribute("binding", paramXMLNode);
    XMLNode xMLNode1 = paramWSDLParser.getNodeWithName("binding", str1, paramWSDLParser.definition);
    paramWSDLParser.assertion(xMLNode1, "binding not found" + str1);
    XMLNode xMLNode2 = paramXMLNode.getChild("address", paramWSDLParser.soapNS);
    paramWSDLParser.assertion(xMLNode2, "unable to find soap address");
    String str2 = paramWSDLParser.getMustAttribute("location", xMLNode2);
    Port port = paramWebService.addPort(paramWSDLParser.getMustAttribute("name", paramXMLNode));
    String str3 = paramWSDLParser.removePrefix(paramWSDLParser.getMustAttribute("type", xMLNode1));
    port.setTypeName(str3);
    (new WsdlBinding()).parseBinding(paramWSDLParser, paramWebService, port, xMLNode1);
    String str4 = "http";
    if (str2.indexOf(":") != -1)
      str4 = str2.substring(0, str2.indexOf(':')); 
    paramWebService.setProtocol(str4);
    if ("https".equals(str4))
      port.setBindingInfo(new HttpsBindingInfo()); 
    port.getBindingInfo().setAddress(str2);
    if ("http://schemas.xmlsoap.org/wsdl/soap/".equals(paramWSDLParser.soapNS))
      port.getBindingInfo().setType("SOAP1.1"); 
    if ("http://schemas.xmlsoap.org/wsdl/soap12/".equals(paramWSDLParser.soapNS))
      port.getBindingInfo().setType("SOAP1.2"); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlPort.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */