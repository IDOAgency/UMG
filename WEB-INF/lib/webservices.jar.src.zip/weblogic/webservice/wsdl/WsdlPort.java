/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import weblogic.webservice.Port;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.binding.https.HttpsBindingInfo;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsdlPort
/*    */ {
/*    */   void parsePort(WSDLParser paramWSDLParser, WebService paramWebService, XMLNode paramXMLNode) throws IOException {
/* 26 */     String str1 = paramWSDLParser.getMustAttribute("binding", paramXMLNode);
/*    */     
/* 28 */     XMLNode xMLNode1 = paramWSDLParser.getNodeWithName("binding", str1, paramWSDLParser.definition);
/*    */ 
/*    */     
/* 31 */     paramWSDLParser.assertion(xMLNode1, "binding not found" + str1);
/*    */     
/* 33 */     XMLNode xMLNode2 = paramXMLNode.getChild("address", paramWSDLParser.soapNS);
/* 34 */     paramWSDLParser.assertion(xMLNode2, "unable to find soap address");
/*    */     
/* 36 */     String str2 = paramWSDLParser.getMustAttribute("location", xMLNode2);
/*    */     
/* 38 */     Port port = paramWebService.addPort(paramWSDLParser.getMustAttribute("name", paramXMLNode));
/*    */ 
/*    */     
/* 41 */     String str3 = paramWSDLParser.removePrefix(paramWSDLParser.getMustAttribute("type", xMLNode1));
/*    */ 
/*    */     
/* 44 */     port.setTypeName(str3);
/*    */     
/* 46 */     (new WsdlBinding()).parseBinding(paramWSDLParser, paramWebService, port, xMLNode1);
/*    */     
/* 48 */     String str4 = "http";
/*    */     
/* 50 */     if (str2.indexOf(":") != -1) {
/* 51 */       str4 = str2.substring(0, str2.indexOf(':'));
/*    */     }
/*    */     
/* 54 */     paramWebService.setProtocol(str4);
/*    */     
/* 56 */     if ("https".equals(str4)) {
/* 57 */       port.setBindingInfo(new HttpsBindingInfo());
/*    */     }
/*    */     
/* 60 */     port.getBindingInfo().setAddress(str2);
/*    */     
/* 62 */     if ("http://schemas.xmlsoap.org/wsdl/soap/".equals(paramWSDLParser.soapNS)) {
/* 63 */       port.getBindingInfo().setType("SOAP1.1");
/*    */     }
/*    */     
/* 66 */     if ("http://schemas.xmlsoap.org/wsdl/soap12/".equals(paramWSDLParser.soapNS))
/* 67 */       port.getBindingInfo().setType("SOAP1.2"); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlPort.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */