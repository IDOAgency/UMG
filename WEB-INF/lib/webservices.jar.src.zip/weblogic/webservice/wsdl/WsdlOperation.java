package weblogic.webservice.wsdl;

import java.util.ArrayList;
import java.util.Iterator;
import weblogic.webservice.Operation;
import weblogic.webservice.core.FaultMessage;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlOperation {
  private WsdlMessage wsdlInput;
  
  private WsdlMessage wsdlOutput;
  
  private ArrayList wsdlFaults = new ArrayList();
  
  void parseOperation(WSDLParser paramWSDLParser, Operation paramOperation, XMLNode paramXMLNode) throws WSDLParseException {
    paramOperation.setParameterOrder(paramXMLNode.getAttribute("parameterOrder", null));
    XMLNode xMLNode1 = paramXMLNode.getChild("input", WsdlConstants.wsdlNS);
    if (xMLNode1 != null) {
      String str = paramWSDLParser.getMustAttribute("message", xMLNode1);
      XMLNode xMLNode = paramWSDLParser.getNodeWithName("message", str, paramWSDLParser.definition);
      paramWSDLParser.assertion(xMLNode, "message not found:" + str);
      this.wsdlInput = new WsdlMessage();
      this.wsdlInput.parseMessage(paramWSDLParser, paramOperation.getInput(), xMLNode, false);
    } 
    XMLNode xMLNode2 = paramXMLNode.getChild("output", WsdlConstants.wsdlNS);
    if (xMLNode2 != null) {
      String str = paramWSDLParser.getMustAttribute("message", xMLNode2);
      XMLNode xMLNode = paramWSDLParser.getNodeWithName("message", str, paramWSDLParser.definition);
      paramWSDLParser.assertion(xMLNode, "message not found:" + str);
      this.wsdlOutput = new WsdlMessage();
      this.wsdlOutput.parseMessage(paramWSDLParser, paramOperation.getOutput(), xMLNode, false);
    } else {
      paramOperation.setOneway(true);
    } 
    Name name = new Name(WsdlConstants.wsdlNS, "fault");
    for (Iterator iterator = paramXMLNode.getChildren(name); iterator.hasNext(); ) {
      XMLNode xMLNode3 = (XMLNode)iterator.next();
      String str1 = paramWSDLParser.getMustAttribute("name", xMLNode3);
      String str2 = paramWSDLParser.getMustAttribute("message", xMLNode3);
      XMLNode xMLNode4 = paramWSDLParser.getNodeWithName("message", str2, paramWSDLParser.definition);
      paramWSDLParser.assertion(xMLNode4, "message not found:" + str2);
      FaultMessage faultMessage = (FaultMessage)paramOperation.addFault();
      faultMessage.setName(paramWSDLParser.removePrefix(str2));
      faultMessage.setFaultName(str1);
      WsdlMessage wsdlMessage = new WsdlMessage();
      wsdlMessage.parseMessage(paramWSDLParser, faultMessage, xMLNode4, false);
      this.wsdlFaults.add(wsdlMessage);
      if (!faultMessage.getParts().hasNext())
        throw new WSDLParseException("Fault message " + str1 + " Must have a single part."); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlOperation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */