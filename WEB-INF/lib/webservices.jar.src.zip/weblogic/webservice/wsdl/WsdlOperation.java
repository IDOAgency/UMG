/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.Operation;
/*    */ import weblogic.webservice.core.FaultMessage;
/*    */ import weblogic.xml.stream.events.Name;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsdlOperation
/*    */ {
/*    */   private WsdlMessage wsdlInput;
/*    */   private WsdlMessage wsdlOutput;
/* 26 */   private ArrayList wsdlFaults = new ArrayList();
/*    */ 
/*    */ 
/*    */   
/*    */   void parseOperation(WSDLParser paramWSDLParser, Operation paramOperation, XMLNode paramXMLNode) throws WSDLParseException {
/* 31 */     paramOperation.setParameterOrder(paramXMLNode.getAttribute("parameterOrder", null));
/*    */ 
/*    */     
/* 34 */     XMLNode xMLNode1 = paramXMLNode.getChild("input", WsdlConstants.wsdlNS);
/*    */     
/* 36 */     if (xMLNode1 != null) {
/* 37 */       String str = paramWSDLParser.getMustAttribute("message", xMLNode1);
/*    */       
/* 39 */       XMLNode xMLNode = paramWSDLParser.getNodeWithName("message", str, paramWSDLParser.definition);
/*    */ 
/*    */       
/* 42 */       paramWSDLParser.assertion(xMLNode, "message not found:" + str);
/* 43 */       this.wsdlInput = new WsdlMessage();
/*    */       
/* 45 */       this.wsdlInput.parseMessage(paramWSDLParser, paramOperation.getInput(), xMLNode, false);
/*    */     } 
/*    */ 
/*    */     
/* 49 */     XMLNode xMLNode2 = paramXMLNode.getChild("output", WsdlConstants.wsdlNS);
/*    */     
/* 51 */     if (xMLNode2 != null) {
/* 52 */       String str = paramWSDLParser.getMustAttribute("message", xMLNode2);
/*    */       
/* 54 */       XMLNode xMLNode = paramWSDLParser.getNodeWithName("message", str, paramWSDLParser.definition);
/*    */ 
/*    */       
/* 57 */       paramWSDLParser.assertion(xMLNode, "message not found:" + str);
/*    */       
/* 59 */       this.wsdlOutput = new WsdlMessage();
/* 60 */       this.wsdlOutput.parseMessage(paramWSDLParser, paramOperation.getOutput(), xMLNode, false);
/*    */     } else {
/*    */       
/* 63 */       paramOperation.setOneway(true);
/*    */     } 
/*    */     
/* 66 */     Name name = new Name(WsdlConstants.wsdlNS, "fault");
/*    */     
/* 68 */     for (Iterator iterator = paramXMLNode.getChildren(name); iterator.hasNext(); ) {
/* 69 */       XMLNode xMLNode3 = (XMLNode)iterator.next();
/* 70 */       String str1 = paramWSDLParser.getMustAttribute("name", xMLNode3);
/* 71 */       String str2 = paramWSDLParser.getMustAttribute("message", xMLNode3);
/*    */       
/* 73 */       XMLNode xMLNode4 = paramWSDLParser.getNodeWithName("message", str2, paramWSDLParser.definition);
/*    */ 
/*    */       
/* 76 */       paramWSDLParser.assertion(xMLNode4, "message not found:" + str2);
/*    */       
/* 78 */       FaultMessage faultMessage = (FaultMessage)paramOperation.addFault();
/* 79 */       faultMessage.setName(paramWSDLParser.removePrefix(str2));
/* 80 */       faultMessage.setFaultName(str1);
/*    */       
/* 82 */       WsdlMessage wsdlMessage = new WsdlMessage();
/* 83 */       wsdlMessage.parseMessage(paramWSDLParser, faultMessage, xMLNode4, false);
/* 84 */       this.wsdlFaults.add(wsdlMessage);
/*    */       
/* 86 */       if (!faultMessage.getParts().hasNext())
/* 87 */         throw new WSDLParseException("Fault message " + str1 + " Must have a single part."); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlOperation.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */