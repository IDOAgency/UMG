/*     */ package weblogic.webservice.wsdl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.core.encoding.DefaultRegistry;
/*     */ import weblogic.webservice.util.AttachmentUtil;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSDLParser
/*     */   implements WsdlConstants
/*     */ {
/*     */   XMLNode definition;
/*     */   String serviceName;
/*     */   TypeMappingRegistry registry;
/*  39 */   String defaultEncodingStyle = StdNamespace.instance().soapEncoding();
/*     */   
/*  41 */   String soapNS = "http://schemas.xmlsoap.org/wsdl/soap/";
/*     */   
/*  43 */   ParameterModeHelper parameterModeHelper = new ParameterModeHelper();
/*     */   
/*     */   private boolean implicitConversation = true;
/*     */ 
/*     */   
/*     */   public WSDLParser(String paramString) throws IOException {
/*  49 */     DefinitionFactory definitionFactory = new DefinitionFactory();
/*  50 */     this.definition = definitionFactory.createDefinition(paramString);
/*     */     
/*     */     try {
/*  53 */       this.registry = new DefaultRegistry();
/*  54 */     } catch (JAXRPCException jAXRPCException) {
/*  55 */       throw new WSDLParseException("failed to create type mapping registry");
/*     */     } 
/*     */     
/*  58 */     if (!"definitions".equals(this.definition.getName().getLocalName())) {
/*  59 */       assertion(null, "first element is not definitions");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void visit(WebService paramWebService) throws IOException {
/*  65 */     if (paramWebService.getTypeMappingRegistry() == null) {
/*  66 */       paramWebService.setTypeMappingRegistry(this.registry);
/*     */     } else {
/*  68 */       this.registry = paramWebService.getTypeMappingRegistry();
/*     */     } 
/*     */     
/*  71 */     (new WsdlDefinitions()).parseDefinition(this, paramWebService);
/*     */   }
/*     */ 
/*     */   
/*  75 */   public void setImplicitConversation(boolean paramBoolean) { this.implicitConversation = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  79 */   public void setServiceName(String paramString) throws IOException { this.serviceName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean canHandleMethod(XMLNode paramXMLNode) {
/*  85 */     if (isNotification(paramXMLNode) || isSolicitResponse(paramXMLNode)) {
/*  86 */       System.err.print("WARNING: Skipping operation[" + paramXMLNode.getName());
/*  87 */       System.err.print("] clientgen does not support notification or ");
/*  88 */       System.err.println("solicit-response WSDL operations yet");
/*     */       
/*  90 */       return false;
/*     */     } 
/*     */     
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   String getNamespace(String paramString, XMLNode paramXMLNode) {
/*  97 */     int i = paramString.indexOf(":");
/*     */     
/*  99 */     String str = (i == -1) ? "" : paramString.substring(0, i);
/* 100 */     return paramXMLNode.getNamespaceURI(str);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void parseBindingMessage(WSDLParser paramWSDLParser, Operation paramOperation, XMLNode paramXMLNode, Message paramMessage) throws WSDLParseException {
/* 106 */     XMLNode xMLNode1 = paramXMLNode.getChild("multipartRelated", "http://schemas.xmlsoap.org/wsdl/mime/");
/* 107 */     XMLNode xMLNode2 = null;
/* 108 */     XMLNode xMLNode3 = null;
/* 109 */     Iterator iterator = null;
/*     */     
/* 111 */     if (xMLNode1 == null) {
/* 112 */       xMLNode2 = paramXMLNode.getChild("body", paramWSDLParser.soapNS);
/* 113 */       xMLNode3 = paramXMLNode.getChild("fault", paramWSDLParser.soapNS);
/*     */     } else {
/* 115 */       paramMessage.setContainsAttachment(true);
/* 116 */       iterator = xMLNode1.getChildren();
/*     */ 
/*     */       
/* 119 */       if (iterator.hasNext()) {
/* 120 */         XMLNode xMLNode = (XMLNode)iterator.next();
/*     */         
/* 122 */         paramWSDLParser.assertion(xMLNode, "mime:part not found inside mime:multipartRelated");
/*     */ 
/*     */         
/* 125 */         xMLNode2 = xMLNode.getChild("body", paramWSDLParser.soapNS);
/* 126 */         xMLNode3 = xMLNode.getChild("fault", paramWSDLParser.soapNS);
/*     */       } 
/*     */     } 
/*     */     
/* 130 */     if (xMLNode2 == null && xMLNode3 == null) {
/* 131 */       paramWSDLParser.assertion(null, "unable to find soap:body or soap:fault inside binding operation:" + paramXMLNode);
/*     */     }
/*     */ 
/*     */     
/* 135 */     populateSecSpecRef(paramOperation, paramMessage, paramXMLNode);
/* 136 */     WsdlMessage.populateMessage(paramMessage, (xMLNode2 != null) ? xMLNode2 : xMLNode3);
/* 137 */     populateHeader(paramWSDLParser, paramMessage, paramXMLNode);
/*     */     
/* 139 */     while (iterator != null && iterator.hasNext()) {
/* 140 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 142 */       if ("part".equals(xMLNode.getName().getLocalName())) {
/* 143 */         for (Iterator iterator1 = xMLNode.getChildren(); iterator1.hasNext(); ) {
/* 144 */           XMLNode xMLNode4 = (XMLNode)iterator1.next();
/*     */           
/* 146 */           if ("content".equals(xMLNode4.getName().getLocalName())) {
/* 147 */             String str1 = paramWSDLParser.getMustAttribute("part", xMLNode4);
/* 148 */             String str2 = paramWSDLParser.getMustAttribute("type", xMLNode4);
/* 149 */             Part part = paramMessage.getPart(str1);
/* 150 */             paramWSDLParser.assertion(part, "unable to find part:" + str1);
/* 151 */             part.setAttachment();
/* 152 */             part.addContentType(str2);
/* 153 */             Class clazz = AttachmentUtil.getJavaType(str2);
/* 154 */             part.setJavaType(clazz);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void populateSecSpecRef(Operation paramOperation, Message paramMessage, XMLNode paramXMLNode) throws WSDLParseException {
/* 164 */     XMLNode xMLNode = paramXMLNode.getChild("SecuritySpecRef", "http://www.openuri.org/2002/11/wsse/spec");
/*     */ 
/*     */     
/* 167 */     if (xMLNode != null) {
/* 168 */       String str = xMLNode.getAttribute("RefId", null);
/* 169 */       if (paramOperation.getPort().getService().getSecurity() == null || paramOperation.getPort().getService().getSecurity().getSecuritySpec(str) == null)
/*     */       {
/* 171 */         throw new WSDLParseException("Operation " + paramOperation.getName() + " is trying to refer to " + "a undefined security spec named " + str);
/*     */       }
/*     */ 
/*     */       
/* 175 */       paramMessage.setSecuritySpecRef(str);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void populateHeader(WSDLParser paramWSDLParser, Message paramMessage, XMLNode paramXMLNode) throws WSDLParseException {
/* 183 */     for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 184 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 186 */       if ("header".equals(xMLNode.getName().getLocalName()) && paramWSDLParser.soapNS.equals(xMLNode.getName().getNamespaceUri())) {
/*     */ 
/*     */         
/* 189 */         String str1 = paramWSDLParser.getMustAttribute("message", xMLNode);
/* 190 */         String str2 = paramWSDLParser.getMustAttribute("part", xMLNode);
/*     */         
/* 192 */         if ("ContinueHeader".equals(str2) && (str1.endsWith("ContinueHeader_rpc") || str1.endsWith("ContinueHeader_literal")))
/*     */         
/*     */         { 
/*     */           
/* 196 */           if (paramWSDLParser.implicitConversation)
/* 197 */             continue;  } else if ("StartHeader".equals(str2) && (str1.endsWith("StartHeader_rpc") || str1.endsWith("StartHeader_literal")))
/*     */         
/*     */         { 
/*     */           
/* 201 */           if (paramWSDLParser.implicitConversation)
/* 202 */             continue;  } else if ("FinishHeader".equals(str2) && (str1.endsWith("FinishHeader_rpc") || str1.endsWith("FinishHeader_literal")))
/*     */         
/*     */         { 
/*     */           
/* 206 */           if (paramWSDLParser.implicitConversation)
/*     */             continue;  }
/*     */         
/* 209 */         XMLNode xMLNode1 = paramWSDLParser.getNodeWithName("message", str1, paramWSDLParser.definition);
/*     */ 
/*     */         
/* 212 */         paramWSDLParser.assertion(xMLNode1, "message not found:" + str1);
/*     */         
/* 214 */         String str3 = paramWSDLParser.getMustAttribute("part", xMLNode);
/* 215 */         XMLNode xMLNode2 = paramWSDLParser.getNodeWithName("part", str3, xMLNode1);
/*     */         
/* 217 */         paramWSDLParser.assertion(xMLNode2, "part [" + str3 + "] not found inside " + "the message:" + str1);
/*     */ 
/*     */         
/* 220 */         (new WsdlPart()).parsePart(paramWSDLParser, paramMessage, xMLNode2, true);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XMLNode getNodeWithName(String paramString1, String paramString2, XMLNode paramXMLNode) {
/* 232 */     paramString2 = removePrefix(paramString2);
/*     */     
/* 234 */     for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 235 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 237 */       if (paramString1.equals(xMLNode.getName().getLocalName()) && 
/* 238 */         paramString2.equals(xMLNode.getAttribute("name", null))) {
/* 239 */         return xMLNode;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 244 */     return null;
/*     */   }
/*     */   
/*     */   String removePrefix(String paramString) {
/* 248 */     int i = paramString.indexOf(":");
/*     */     
/* 250 */     if (i != -1) {
/* 251 */       paramString = paramString.substring(i + 1, paramString.length());
/*     */     }
/*     */     
/* 254 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String getMustAttribute(String paramString, XMLNode paramXMLNode) {
/* 260 */     String str = paramXMLNode.getAttribute(paramString, null);
/*     */     
/* 262 */     if (str == null) {
/* 263 */       throw new WSDLParseException("ERROR[WSDL Parser] Attribute '" + paramString + "' not found at:" + paramXMLNode);
/*     */     }
/*     */ 
/*     */     
/* 267 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void assertion(Object paramObject, String paramString) throws WSDLParseException {
/* 273 */     if (paramObject == null) {
/* 274 */       throw new WSDLParseException("ERROR[WSDL Parser]:" + paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSolicitResponse(XMLNode paramXMLNode) {
/* 280 */     Iterator iterator = paramXMLNode.getChildren();
/*     */     
/* 282 */     if (!iterator.hasNext()) {
/* 283 */       return false;
/*     */     }
/*     */     
/* 286 */     while (iterator.hasNext()) {
/* 287 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 289 */       if ("input".equals(xMLNode.getName().getLocalName())) {
/* 290 */         return false;
/*     */       }
/*     */       
/* 293 */       if ("output".equals(xMLNode.getName().getLocalName())) {
/* 294 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 298 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isNotification(XMLNode paramXMLNode) {
/* 303 */     Iterator iterator = paramXMLNode.getChildren();
/*     */     
/* 305 */     if (!iterator.hasNext()) {
/* 306 */       return false;
/*     */     }
/*     */     
/* 309 */     while (iterator.hasNext()) {
/* 310 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 312 */       if ("input".equals(xMLNode.getName().getLocalName())) {
/* 313 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 317 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WSDLParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */