package weblogic.webservice.wsdl;

import java.io.IOException;
import java.util.Iterator;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.WebService;
import weblogic.webservice.core.encoding.DefaultRegistry;
import weblogic.webservice.util.AttachmentUtil;
import weblogic.xml.schema.binding.util.StdNamespace;
import weblogic.xml.xmlnode.XMLNode;

public class WSDLParser implements WsdlConstants {
  XMLNode definition;
  
  String serviceName;
  
  TypeMappingRegistry registry;
  
  String defaultEncodingStyle = StdNamespace.instance().soapEncoding();
  
  String soapNS = "http://schemas.xmlsoap.org/wsdl/soap/";
  
  ParameterModeHelper parameterModeHelper = new ParameterModeHelper();
  
  private boolean implicitConversation = true;
  
  public WSDLParser(String paramString) throws IOException {
    DefinitionFactory definitionFactory = new DefinitionFactory();
    this.definition = definitionFactory.createDefinition(paramString);
    try {
      this.registry = new DefaultRegistry();
    } catch (JAXRPCException jAXRPCException) {
      throw new WSDLParseException("failed to create type mapping registry");
    } 
    if (!"definitions".equals(this.definition.getName().getLocalName()))
      assertion(null, "first element is not definitions"); 
  }
  
  public void visit(WebService paramWebService) throws IOException {
    if (paramWebService.getTypeMappingRegistry() == null) {
      paramWebService.setTypeMappingRegistry(this.registry);
    } else {
      this.registry = paramWebService.getTypeMappingRegistry();
    } 
    (new WsdlDefinitions()).parseDefinition(this, paramWebService);
  }
  
  public void setImplicitConversation(boolean paramBoolean) { this.implicitConversation = paramBoolean; }
  
  public void setServiceName(String paramString) throws IOException { this.serviceName = paramString; }
  
  boolean canHandleMethod(XMLNode paramXMLNode) {
    if (isNotification(paramXMLNode) || isSolicitResponse(paramXMLNode)) {
      System.err.print("WARNING: Skipping operation[" + paramXMLNode.getName());
      System.err.print("] clientgen does not support notification or ");
      System.err.println("solicit-response WSDL operations yet");
      return false;
    } 
    return true;
  }
  
  String getNamespace(String paramString, XMLNode paramXMLNode) {
    int i = paramString.indexOf(":");
    String str = (i == -1) ? "" : paramString.substring(0, i);
    return paramXMLNode.getNamespaceURI(str);
  }
  
  static void parseBindingMessage(WSDLParser paramWSDLParser, Operation paramOperation, XMLNode paramXMLNode, Message paramMessage) throws WSDLParseException {
    XMLNode xMLNode1 = paramXMLNode.getChild("multipartRelated", "http://schemas.xmlsoap.org/wsdl/mime/");
    XMLNode xMLNode2 = null;
    XMLNode xMLNode3 = null;
    Iterator iterator = null;
    if (xMLNode1 == null) {
      xMLNode2 = paramXMLNode.getChild("body", paramWSDLParser.soapNS);
      xMLNode3 = paramXMLNode.getChild("fault", paramWSDLParser.soapNS);
    } else {
      paramMessage.setContainsAttachment(true);
      iterator = xMLNode1.getChildren();
      if (iterator.hasNext()) {
        XMLNode xMLNode = (XMLNode)iterator.next();
        paramWSDLParser.assertion(xMLNode, "mime:part not found inside mime:multipartRelated");
        xMLNode2 = xMLNode.getChild("body", paramWSDLParser.soapNS);
        xMLNode3 = xMLNode.getChild("fault", paramWSDLParser.soapNS);
      } 
    } 
    if (xMLNode2 == null && xMLNode3 == null)
      paramWSDLParser.assertion(null, "unable to find soap:body or soap:fault inside binding operation:" + paramXMLNode); 
    populateSecSpecRef(paramOperation, paramMessage, paramXMLNode);
    WsdlMessage.populateMessage(paramMessage, (xMLNode2 != null) ? xMLNode2 : xMLNode3);
    populateHeader(paramWSDLParser, paramMessage, paramXMLNode);
    while (iterator != null && iterator.hasNext()) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("part".equals(xMLNode.getName().getLocalName()))
        for (Iterator iterator1 = xMLNode.getChildren(); iterator1.hasNext(); ) {
          XMLNode xMLNode4 = (XMLNode)iterator1.next();
          if ("content".equals(xMLNode4.getName().getLocalName())) {
            String str1 = paramWSDLParser.getMustAttribute("part", xMLNode4);
            String str2 = paramWSDLParser.getMustAttribute("type", xMLNode4);
            Part part = paramMessage.getPart(str1);
            paramWSDLParser.assertion(part, "unable to find part:" + str1);
            part.setAttachment();
            part.addContentType(str2);
            Class clazz = AttachmentUtil.getJavaType(str2);
            part.setJavaType(clazz);
          } 
        }  
    } 
  }
  
  private static void populateSecSpecRef(Operation paramOperation, Message paramMessage, XMLNode paramXMLNode) throws WSDLParseException {
    XMLNode xMLNode = paramXMLNode.getChild("SecuritySpecRef", "http://www.openuri.org/2002/11/wsse/spec");
    if (xMLNode != null) {
      String str = xMLNode.getAttribute("RefId", null);
      if (paramOperation.getPort().getService().getSecurity() == null || paramOperation.getPort().getService().getSecurity().getSecuritySpec(str) == null)
        throw new WSDLParseException("Operation " + paramOperation.getName() + " is trying to refer to " + "a undefined security spec named " + str); 
      paramMessage.setSecuritySpecRef(str);
    } 
  }
  
  private static void populateHeader(WSDLParser paramWSDLParser, Message paramMessage, XMLNode paramXMLNode) throws WSDLParseException {
    for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("header".equals(xMLNode.getName().getLocalName()) && paramWSDLParser.soapNS.equals(xMLNode.getName().getNamespaceUri())) {
        String str1 = paramWSDLParser.getMustAttribute("message", xMLNode);
        String str2 = paramWSDLParser.getMustAttribute("part", xMLNode);
        if ("ContinueHeader".equals(str2) && (str1.endsWith("ContinueHeader_rpc") || str1.endsWith("ContinueHeader_literal"))) {
          if (paramWSDLParser.implicitConversation)
            continue; 
        } else if ("StartHeader".equals(str2) && (str1.endsWith("StartHeader_rpc") || str1.endsWith("StartHeader_literal"))) {
          if (paramWSDLParser.implicitConversation)
            continue; 
        } else if ("FinishHeader".equals(str2) && (str1.endsWith("FinishHeader_rpc") || str1.endsWith("FinishHeader_literal"))) {
          if (paramWSDLParser.implicitConversation)
            continue; 
        } 
        XMLNode xMLNode1 = paramWSDLParser.getNodeWithName("message", str1, paramWSDLParser.definition);
        paramWSDLParser.assertion(xMLNode1, "message not found:" + str1);
        String str3 = paramWSDLParser.getMustAttribute("part", xMLNode);
        XMLNode xMLNode2 = paramWSDLParser.getNodeWithName("part", str3, xMLNode1);
        paramWSDLParser.assertion(xMLNode2, "part [" + str3 + "] not found inside " + "the message:" + str1);
        (new WsdlPart()).parsePart(paramWSDLParser, paramMessage, xMLNode2, true);
      } 
    } 
  }
  
  XMLNode getNodeWithName(String paramString1, String paramString2, XMLNode paramXMLNode) {
    paramString2 = removePrefix(paramString2);
    for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if (paramString1.equals(xMLNode.getName().getLocalName()) && 
        paramString2.equals(xMLNode.getAttribute("name", null)))
        return xMLNode; 
    } 
    return null;
  }
  
  String removePrefix(String paramString) {
    int i = paramString.indexOf(":");
    if (i != -1)
      paramString = paramString.substring(i + 1, paramString.length()); 
    return paramString;
  }
  
  String getMustAttribute(String paramString, XMLNode paramXMLNode) {
    String str = paramXMLNode.getAttribute(paramString, null);
    if (str == null)
      throw new WSDLParseException("ERROR[WSDL Parser] Attribute '" + paramString + "' not found at:" + paramXMLNode); 
    return str;
  }
  
  void assertion(Object paramObject, String paramString) throws WSDLParseException {
    if (paramObject == null)
      throw new WSDLParseException("ERROR[WSDL Parser]:" + paramString); 
  }
  
  private boolean isSolicitResponse(XMLNode paramXMLNode) {
    Iterator iterator = paramXMLNode.getChildren();
    if (!iterator.hasNext())
      return false; 
    while (iterator.hasNext()) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("input".equals(xMLNode.getName().getLocalName()))
        return false; 
      if ("output".equals(xMLNode.getName().getLocalName()))
        return true; 
    } 
    return false;
  }
  
  private boolean isNotification(XMLNode paramXMLNode) {
    Iterator iterator = paramXMLNode.getChildren();
    if (!iterator.hasNext())
      return false; 
    while (iterator.hasNext()) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("input".equals(xMLNode.getName().getLocalName()))
        return false; 
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WSDLParser.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */