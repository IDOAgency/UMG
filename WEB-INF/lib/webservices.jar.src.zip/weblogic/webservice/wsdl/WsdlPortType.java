package weblogic.webservice.wsdl;

import java.util.ArrayList;
import java.util.Iterator;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlPortType {
  private ArrayList operations = new ArrayList();
  
  void parsePortType(WSDLParser paramWSDLParser, XMLNode paramXMLNode, Port paramPort) throws WSDLParseException {
    for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      String str = paramWSDLParser.getMustAttribute("name", xMLNode);
      if (!paramWSDLParser.canHandleMethod(xMLNode))
        continue; 
      Operation operation = paramPort.addOperation(str);
      WsdlOperation wsdlOperation = new WsdlOperation();
      wsdlOperation.parseOperation(paramWSDLParser, operation, xMLNode);
      this.operations.add(wsdlOperation);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlPortType.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */