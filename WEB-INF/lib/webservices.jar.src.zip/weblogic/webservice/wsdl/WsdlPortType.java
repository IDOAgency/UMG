/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.Operation;
/*    */ import weblogic.webservice.Port;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsdlPortType
/*    */ {
/* 22 */   private ArrayList operations = new ArrayList();
/*    */ 
/*    */ 
/*    */   
/*    */   void parsePortType(WSDLParser paramWSDLParser, XMLNode paramXMLNode, Port paramPort) throws WSDLParseException {
/* 27 */     for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 28 */       XMLNode xMLNode = (XMLNode)iterator.next();
/* 29 */       String str = paramWSDLParser.getMustAttribute("name", xMLNode);
/*    */       
/* 31 */       if (!paramWSDLParser.canHandleMethod(xMLNode)) {
/*    */         continue;
/*    */       }
/*    */       
/* 35 */       Operation operation = paramPort.addOperation(str);
/*    */       
/* 37 */       WsdlOperation wsdlOperation = new WsdlOperation();
/* 38 */       wsdlOperation.parseOperation(paramWSDLParser, operation, xMLNode);
/* 39 */       this.operations.add(wsdlOperation);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlPortType.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */