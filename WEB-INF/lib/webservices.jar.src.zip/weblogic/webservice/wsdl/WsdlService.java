/*    */ package weblogic.webservice.wsdl;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WsdlService
/*    */ {
/* 22 */   private ArrayList ports = new ArrayList();
/*    */ 
/*    */ 
/*    */   
/*    */   void parseService(WSDLParser paramWSDLParser, WebService paramWebService, XMLNode paramXMLNode) throws IOException {
/* 27 */     paramWebService.setName(paramWSDLParser.getMustAttribute("name", paramXMLNode));
/*    */     
/* 29 */     boolean bool = false;
/*    */     
/* 31 */     for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
/* 32 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*    */       
/* 34 */       if (canParsePort(paramWSDLParser, xMLNode)) {
/* 35 */         bool = true;
/* 36 */         WsdlPort wsdlPort = new WsdlPort();
/* 37 */         wsdlPort.parsePort(paramWSDLParser, paramWebService, xMLNode);
/* 38 */         this.ports.add(wsdlPort);
/*    */       } 
/*    */     } 
/*    */     
/* 42 */     if (!bool) {
/* 43 */       throw new WSDLParseException("unable to find any soap port:" + paramXMLNode);
/*    */     }
/*    */   }
/*    */   
/*    */   private boolean canParsePort(WSDLParser paramWSDLParser, XMLNode paramXMLNode) {
/* 48 */     if ("port".equals(paramXMLNode.getName().getLocalName())) {
/*    */       
/* 50 */       XMLNode xMLNode = paramXMLNode.getChild("address", "http://schemas.xmlsoap.org/wsdl/soap/");
/*    */       
/* 52 */       if (xMLNode != null) {
/* 53 */         paramWSDLParser.soapNS = "http://schemas.xmlsoap.org/wsdl/soap/";
/* 54 */         return true;
/*    */       } 
/*    */       
/* 57 */       xMLNode = paramXMLNode.getChild("address", "http://schemas.xmlsoap.org/wsdl/soap12/");
/*    */       
/* 59 */       if (xMLNode != null) {
/* 60 */         paramWSDLParser.soapNS = "http://schemas.xmlsoap.org/wsdl/soap12/";
/* 61 */         return true;
/*    */       } 
/*    */     } 
/*    */     
/* 65 */     return false;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */