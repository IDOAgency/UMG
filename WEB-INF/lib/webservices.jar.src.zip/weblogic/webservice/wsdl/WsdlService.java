package weblogic.webservice.wsdl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import weblogic.webservice.WebService;
import weblogic.xml.xmlnode.XMLNode;

public class WsdlService {
  private ArrayList ports = new ArrayList();
  
  void parseService(WSDLParser paramWSDLParser, WebService paramWebService, XMLNode paramXMLNode) throws IOException {
    paramWebService.setName(paramWSDLParser.getMustAttribute("name", paramXMLNode));
    boolean bool = false;
    for (Iterator iterator = paramXMLNode.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if (canParsePort(paramWSDLParser, xMLNode)) {
        bool = true;
        WsdlPort wsdlPort = new WsdlPort();
        wsdlPort.parsePort(paramWSDLParser, paramWebService, xMLNode);
        this.ports.add(wsdlPort);
      } 
    } 
    if (!bool)
      throw new WSDLParseException("unable to find any soap port:" + paramXMLNode); 
  }
  
  private boolean canParsePort(WSDLParser paramWSDLParser, XMLNode paramXMLNode) {
    if ("port".equals(paramXMLNode.getName().getLocalName())) {
      XMLNode xMLNode = paramXMLNode.getChild("address", "http://schemas.xmlsoap.org/wsdl/soap/");
      if (xMLNode != null) {
        paramWSDLParser.soapNS = "http://schemas.xmlsoap.org/wsdl/soap/";
        return true;
      } 
      xMLNode = paramXMLNode.getChild("address", "http://schemas.xmlsoap.org/wsdl/soap12/");
      if (xMLNode != null) {
        paramWSDLParser.soapNS = "http://schemas.xmlsoap.org/wsdl/soap12/";
        return true;
      } 
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\wsdl\WsdlService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */