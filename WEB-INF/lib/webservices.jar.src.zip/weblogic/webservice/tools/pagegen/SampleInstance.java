/*     */ package weblogic.webservice.tools.pagegen;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.core.soap.SOAPElementImpl;
/*     */ import weblogic.xml.schema.binding.RuntimeUtils;
/*     */ import weblogic.xml.schema.binding.internal.DeserializationContextImpl;
/*     */ import weblogic.xml.schema.binding.internal.SerializationContextImpl;
/*     */ import weblogic.xml.schema.binding.util.NamespacePrefixMap;
/*     */ import weblogic.xml.stream.XMLInputOutputStream;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SampleInstance
/*     */ {
/*  57 */   private static final HashMap buildin = new HashMap();
/*     */   
/*     */   public static final boolean booleanVar = true;
/*     */   public static final byte byteVar = 1;
/*     */   public static final short shortVar = 10;
/*     */   public static final int intVar = 100;
/*     */   public static final long longVar = 1000L;
/*     */   public static final float floatVar = 10.1F;
/*     */   public static final double doubleVar = 20.2D;
/*     */   
/*     */   static  {
/*  68 */     buildin.put(int.class, new Integer(100));
/*  69 */     buildin.put(float.class, new Float(10.1F));
/*  70 */     buildin.put(long.class, new Long(1000L));
/*  71 */     buildin.put(double.class, new Double(20.2D));
/*  72 */     buildin.put(short.class, new Short((short)10));
/*  73 */     buildin.put(boolean.class, new Boolean(true));
/*  74 */     buildin.put(byte.class, new Byte((byte)1));
/*  75 */     buildin.put(char.class, new Character('c'));
/*  76 */     buildin.put(Integer.class, new Integer(100));
/*  77 */     buildin.put(Float.class, new Float(10.1F));
/*  78 */     buildin.put(Double.class, new Double(20.2D));
/*  79 */     buildin.put(Long.class, new Long(1000L));
/*  80 */     buildin.put(Short.class, new Short((short)10));
/*  81 */     buildin.put(Boolean.class, new Boolean(true));
/*  82 */     buildin.put(String.class, "sample string");
/*  83 */     buildin.put(Byte.class, new Byte((byte)1));
/*  84 */     buildin.put(Character.class, new Character('C'));
/*     */     
/*  86 */     buildin.put(BigDecimal.class, new BigDecimal(10000));
/*     */ 
/*     */     
/*  89 */     buildin.put(BigInteger.class, new BigInteger("10000"));
/*     */ 
/*     */     
/*  92 */     buildin.put(Calendar.class, new Date());
/*  93 */     buildin.put(Date.class, new Date());
/*     */   }
/*     */   
/*     */   public boolean isBuildIn(Part paramPart) {
/*  97 */     if (buildin.containsKey(paramPart.getJavaType())) {
/*  98 */       return true;
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object castToBuildIn(String paramString, Part paramPart) {
/* 105 */     Object object = buildin.get(paramPart.getJavaType());
/*     */     
/* 107 */     if (object == null) {
/* 108 */       throw new IllegalArgumentException("Not a build in type");
/*     */     }
/*     */     
/* 111 */     Class clazz = object.getClass();
/*     */     
/* 113 */     if (Calendar.class.isAssignableFrom(clazz)) {
/* 114 */       Date date = new Date(paramString);
/* 115 */       Calendar calendar = Calendar.getInstance();
/* 116 */       calendar.setTime(date);
/* 117 */       return calendar;
/*     */     } 
/*     */     
/* 120 */     if (Character.class.isAssignableFrom(clazz)) {
/* 121 */       if (paramString != null) {
/* 122 */         if (paramString.length() == 1) {
/* 123 */           return new Character(paramString.charAt(0));
/*     */         }
/* 125 */         throw new IllegalArgumentException(paramString + " is not a char");
/*     */       } 
/* 127 */       return null;
/*     */     } 
/*     */     
/*     */     try {
/* 131 */       Constructor constructor = clazz.getConstructor(new Class[] { String.class });
/* 132 */       if (paramString != null && (paramString.length() > 0 || String.class.isAssignableFrom(clazz))) {
/* 133 */         return constructor.newInstance(new Object[] { paramString });
/*     */       }
/* 135 */       return null;
/* 136 */     } catch (RuntimeException runtimeException) {
/* 137 */       throw runtimeException;
/* 138 */     } catch (Exception exception) {
/* 139 */       throw new IllegalArgumentException("failed to cast to " + clazz.getName() + " with exception:" + exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getJavaObject(String paramString, Part paramPart) {
/* 146 */     if (isBuildIn(paramPart)) {
/* 147 */       return castToBuildIn(paramString, paramPart);
/*     */     }
/*     */     
/* 150 */     SOAPElementImpl sOAPElementImpl = new SOAPElementImpl();
/*     */     
/*     */     try {
/* 153 */       sOAPElementImpl.read(new ByteArrayInputStream(paramString.getBytes()));
/* 154 */     } catch (IOException iOException) {
/* 155 */       throw new SOAPException("Failed to read a xml element from " + paramString);
/*     */     } 
/*     */     
/* 158 */     return paramPart.toJava(sOAPElementImpl, new DeserializationContextImpl(), paramPart.getTypeMapping());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getXMLInput(Part paramPart) {
/*     */     try {
/* 165 */       Object object = buildin.get(paramPart.getJavaType());
/*     */       
/* 167 */       if (object != null) {
/* 168 */         return object.toString();
/*     */       }
/*     */       
/* 171 */       object = getSampleInstance(paramPart.getJavaType(), new HashMap());
/*     */       
/* 173 */       SOAPElementImpl sOAPElementImpl1 = new SOAPElementImpl();
/*     */       
/* 175 */       boolean bool = false;
/* 176 */       SerializationContextImpl serializationContextImpl = new SerializationContextImpl();
/* 177 */       serializationContextImpl.setNamespacePrefixMap(NamespacePrefixMap.createDefaultMap());
/*     */       
/* 179 */       paramPart.toXML(sOAPElementImpl1, object, serializationContextImpl, bool, paramPart.getTypeMapping());
/*     */       
/* 181 */       Iterator iterator = sOAPElementImpl1.getChildren();
/*     */       
/* 183 */       if (!iterator.hasNext()) {
/* 184 */         return "<!-- error no data found -->";
/*     */       }
/*     */       
/* 187 */       SOAPElementImpl sOAPElementImpl2 = (SOAPElementImpl)iterator.next();
/*     */       
/* 189 */       XMLInputOutputStream xMLInputOutputStream = XMLOutputStreamFactory.newInstance().newInputOutputStream();
/*     */ 
/*     */       
/* 192 */       serializationContextImpl.setQualifyElements(true);
/* 193 */       RuntimeUtils.writeTrailingBlocks(xMLInputOutputStream, serializationContextImpl);
/*     */       
/* 195 */       while (xMLInputOutputStream.skip(2)) {
/* 196 */         SOAPElementImpl sOAPElementImpl = new SOAPElementImpl();
/* 197 */         sOAPElementImpl2.addChild(sOAPElementImpl);
/* 198 */         sOAPElementImpl.read(xMLInputOutputStream);
/*     */       } 
/*     */       
/* 201 */       sOAPElementImpl2.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
/*     */ 
/*     */       
/* 204 */       sOAPElementImpl2.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
/*     */ 
/*     */       
/* 207 */       sOAPElementImpl2.addNamespaceDeclaration("soapenc", "http://schemas.xmlsoap.org/soap/encoding/");
/*     */ 
/*     */       
/* 210 */       return format(sOAPElementImpl2.stream());
/* 211 */     } catch (Exception exception) {
/*     */       
/* 213 */       return "<!-- Do not know how to create a sample instance for this part due to the following exception:" + exception + ". Pls replace this " + "with the correct XML before invoking the service. --->\n" + "<" + paramPart.getXMLName() + "/>";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String format(XMLInputStream paramXMLInputStream) throws XMLStreamException {
/* 222 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/* 224 */     XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(byteArrayOutputStream);
/*     */ 
/*     */     
/* 227 */     xMLOutputStream.add(paramXMLInputStream);
/* 228 */     xMLOutputStream.flush();
/*     */     
/* 230 */     return new String(byteArrayOutputStream.toByteArray());
/*     */   }
/*     */   
/*     */   private String clean(String paramString) {
/* 234 */     StringBuffer stringBuffer = new StringBuffer();
/* 235 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\"", true);
/*     */     
/* 237 */     while (stringTokenizer.hasMoreTokens()) {
/* 238 */       String str = stringTokenizer.nextToken();
/*     */       
/* 240 */       if ("\"".equals(str)) {
/* 241 */         stringBuffer.append("&quot;"); continue;
/*     */       } 
/* 243 */       stringBuffer.append(str);
/*     */     } 
/*     */ 
/*     */     
/* 247 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSampleInstance(Class paramClass, HashMap paramHashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
/* 256 */     if (paramClass.isArray()) {
/* 257 */       return getArrayInstance(paramClass.getComponentType(), paramHashMap);
/*     */     }
/*     */     
/* 260 */     Object object = buildin.get(paramClass);
/*     */     
/* 262 */     if (object != null) {
/* 263 */       return object;
/*     */     }
/*     */     
/* 266 */     return getBeanInstance(paramClass, paramHashMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   public Object getBeanInstance(Class paramClass) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException { return getBeanInstance(paramClass, new HashMap()); }
/*     */ 
/*     */   
/*     */   private void addToTypes(HashMap paramHashMap, Class paramClass) {
/* 278 */     Integer integer = (Integer)paramHashMap.get(paramClass);
/* 279 */     int i = 0;
/*     */     
/* 281 */     if (integer != null) {
/* 282 */       i = integer.intValue();
/*     */     }
/*     */     
/* 285 */     paramHashMap.put(paramClass, new Integer(i + 1));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean containsType(HashMap paramHashMap, Class paramClass) {
/* 290 */     Integer integer = (Integer)paramHashMap.get(paramClass);
/*     */     
/* 292 */     if (integer == null) {
/* 293 */       return false;
/*     */     }
/*     */     
/* 296 */     return (integer.intValue() > 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getBeanInstance(Class paramClass, HashMap paramHashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
/* 304 */     if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass)) {
/* 305 */       return getHolderInstance(paramClass, paramHashMap);
/*     */     }
/*     */     
/* 308 */     if (containsType(paramHashMap, paramClass)) {
/* 309 */       return null;
/*     */     }
/* 311 */     addToTypes(paramHashMap, paramClass);
/*     */ 
/*     */     
/* 314 */     Object object = getSpecialInstance(paramClass);
/*     */     
/* 316 */     if (object == null) {
/*     */       
/* 318 */       object = paramClass.isInterface() ? getInstanceFromInterface(paramClass) : paramClass.newInstance();
/*     */ 
/*     */       
/* 321 */       setSampleValues(object, paramHashMap);
/*     */     } 
/*     */     
/* 324 */     return object;
/*     */   }
/*     */ 
/*     */   
/*     */   private Object getSpecialInstance(Class paramClass) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
/* 329 */     if (Calendar.class.isAssignableFrom(paramClass)) {
/* 330 */       return Calendar.getInstance();
/*     */     }
/*     */     
/* 333 */     if (QName.class.equals(paramClass)) {
/* 334 */       return new QName("http://some.namespace/", "someName");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 343 */     if (javax.xml.soap.SOAPElement.class.equals(paramClass)) {
/* 344 */       return null;
/*     */     }
/*     */     
/* 347 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getHolderInstance(Class paramClass, HashMap paramHashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
/* 355 */     Object object1 = paramClass.newInstance();
/* 356 */     Field field = paramClass.getField("value");
/* 357 */     Object object2 = getBeanInstance(field.getType(), paramHashMap);
/* 358 */     field.set(object1, object2);
/* 359 */     return object1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSampleValues(Object paramObject, HashMap paramHashMap) throws ClassNotFoundException, IllegalAccessException, InstantiationException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
/* 367 */     BeanInfo beanInfo = Introspector.getBeanInfo(paramObject.getClass(), Object.class);
/*     */ 
/*     */     
/* 370 */     PropertyDescriptor[] arrayOfPropertyDescriptor = beanInfo.getPropertyDescriptors();
/*     */     
/* 372 */     for (byte b = 0; b < arrayOfPropertyDescriptor.length; b++) {
/*     */       
/* 374 */       Method method = arrayOfPropertyDescriptor[b].getWriteMethod();
/*     */       
/* 376 */       if (method != null) {
/*     */         
/* 378 */         Object[] arrayOfObject = { getSampleInstance(arrayOfPropertyDescriptor[b].getPropertyType(), paramHashMap) };
/*     */ 
/*     */         
/* 381 */         method.invoke(paramObject, arrayOfObject);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getInstanceFromInterface(Class paramClass) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
/* 390 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */     
/* 392 */     if (classLoader == null) {
/* 393 */       classLoader = getClass().getClassLoader();
/*     */     }
/*     */     
/* 396 */     Class clazz = classLoader.loadClass(paramClass.getName());
/* 397 */     return clazz.newInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getArrayInstance(Class paramClass, HashMap paramHashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
/* 406 */     Object object = Array.newInstance(paramClass, 1);
/*     */     
/* 408 */     for (byte b = 0; b < Array.getLength(object); b++) {
/* 409 */       Array.set(object, b, getSampleInstance(paramClass, paramHashMap));
/*     */     }
/*     */     
/* 412 */     return object;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\SampleInstance.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */