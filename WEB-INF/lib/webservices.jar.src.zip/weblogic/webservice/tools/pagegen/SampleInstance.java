package weblogic.webservice.tools.pagegen;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import weblogic.webservice.Part;
import weblogic.webservice.core.soap.SOAPElementImpl;
import weblogic.xml.schema.binding.RuntimeUtils;
import weblogic.xml.schema.binding.internal.DeserializationContextImpl;
import weblogic.xml.schema.binding.internal.SerializationContextImpl;
import weblogic.xml.schema.binding.util.NamespacePrefixMap;
import weblogic.xml.stream.XMLInputOutputStream;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;

public class SampleInstance {
  private static final HashMap buildin = new HashMap();
  
  public static final boolean booleanVar = true;
  
  public static final byte byteVar = 1;
  
  public static final short shortVar = 10;
  
  public static final int intVar = 100;
  
  public static final long longVar = 1000L;
  
  public static final float floatVar = 10.1F;
  
  public static final double doubleVar = 20.2D;
  
  static  {
    buildin.put(int.class, new Integer(100));
    buildin.put(float.class, new Float(10.1F));
    buildin.put(long.class, new Long(1000L));
    buildin.put(double.class, new Double(20.2D));
    buildin.put(short.class, new Short((short)10));
    buildin.put(boolean.class, new Boolean(true));
    buildin.put(byte.class, new Byte((byte)1));
    buildin.put(char.class, new Character('c'));
    buildin.put(Integer.class, new Integer(100));
    buildin.put(Float.class, new Float(10.1F));
    buildin.put(Double.class, new Double(20.2D));
    buildin.put(Long.class, new Long(1000L));
    buildin.put(Short.class, new Short((short)10));
    buildin.put(Boolean.class, new Boolean(true));
    buildin.put(String.class, "sample string");
    buildin.put(Byte.class, new Byte((byte)1));
    buildin.put(Character.class, new Character('C'));
    buildin.put(BigDecimal.class, new BigDecimal(10000));
    buildin.put(BigInteger.class, new BigInteger("10000"));
    buildin.put(Calendar.class, new Date());
    buildin.put(Date.class, new Date());
  }
  
  public boolean isBuildIn(Part paramPart) {
    if (buildin.containsKey(paramPart.getJavaType()))
      return true; 
    return false;
  }
  
  private Object castToBuildIn(String paramString, Part paramPart) {
    Object object = buildin.get(paramPart.getJavaType());
    if (object == null)
      throw new IllegalArgumentException("Not a build in type"); 
    Class clazz = object.getClass();
    if (Calendar.class.isAssignableFrom(clazz)) {
      Date date = new Date(paramString);
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(date);
      return calendar;
    } 
    if (Character.class.isAssignableFrom(clazz)) {
      if (paramString != null) {
        if (paramString.length() == 1)
          return new Character(paramString.charAt(0)); 
        throw new IllegalArgumentException(paramString + " is not a char");
      } 
      return null;
    } 
    try {
      Constructor constructor = clazz.getConstructor(new Class[] { String.class });
      if (paramString != null && (paramString.length() > 0 || String.class.isAssignableFrom(clazz)))
        return constructor.newInstance(new Object[] { paramString }); 
      return null;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (Exception exception) {
      throw new IllegalArgumentException("failed to cast to " + clazz.getName() + " with exception:" + exception);
    } 
  }
  
  public Object getJavaObject(String paramString, Part paramPart) {
    if (isBuildIn(paramPart))
      return castToBuildIn(paramString, paramPart); 
    SOAPElementImpl sOAPElementImpl = new SOAPElementImpl();
    try {
      sOAPElementImpl.read(new ByteArrayInputStream(paramString.getBytes()));
    } catch (IOException iOException) {
      throw new SOAPException("Failed to read a xml element from " + paramString);
    } 
    return paramPart.toJava(sOAPElementImpl, new DeserializationContextImpl(), paramPart.getTypeMapping());
  }
  
  public String getXMLInput(Part paramPart) {
    try {
      Object object = buildin.get(paramPart.getJavaType());
      if (object != null)
        return object.toString(); 
      object = getSampleInstance(paramPart.getJavaType(), new HashMap());
      SOAPElementImpl sOAPElementImpl1 = new SOAPElementImpl();
      boolean bool = false;
      SerializationContextImpl serializationContextImpl = new SerializationContextImpl();
      serializationContextImpl.setNamespacePrefixMap(NamespacePrefixMap.createDefaultMap());
      paramPart.toXML(sOAPElementImpl1, object, serializationContextImpl, bool, paramPart.getTypeMapping());
      Iterator iterator = sOAPElementImpl1.getChildren();
      if (!iterator.hasNext())
        return "<!-- error no data found -->"; 
      SOAPElementImpl sOAPElementImpl2 = (SOAPElementImpl)iterator.next();
      XMLInputOutputStream xMLInputOutputStream = XMLOutputStreamFactory.newInstance().newInputOutputStream();
      serializationContextImpl.setQualifyElements(true);
      RuntimeUtils.writeTrailingBlocks(xMLInputOutputStream, serializationContextImpl);
      while (xMLInputOutputStream.skip(2)) {
        SOAPElementImpl sOAPElementImpl = new SOAPElementImpl();
        sOAPElementImpl2.addChild(sOAPElementImpl);
        sOAPElementImpl.read(xMLInputOutputStream);
      } 
      sOAPElementImpl2.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
      sOAPElementImpl2.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");
      sOAPElementImpl2.addNamespaceDeclaration("soapenc", "http://schemas.xmlsoap.org/soap/encoding/");
      return format(sOAPElementImpl2.stream());
    } catch (Exception exception) {
      return "<!-- Do not know how to create a sample instance for this part due to the following exception:" + exception + ". Pls replace this " + "with the correct XML before invoking the service. --->\n" + "<" + paramPart.getXMLName() + "/>";
    } 
  }
  
  private String format(XMLInputStream paramXMLInputStream) throws XMLStreamException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(byteArrayOutputStream);
    xMLOutputStream.add(paramXMLInputStream);
    xMLOutputStream.flush();
    return new String(byteArrayOutputStream.toByteArray());
  }
  
  private String clean(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\"", true);
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if ("\"".equals(str)) {
        stringBuffer.append("&quot;");
        continue;
      } 
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public Object getSampleInstance(Class paramClass, HashMap paramHashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
    if (paramClass.isArray())
      return getArrayInstance(paramClass.getComponentType(), paramHashMap); 
    Object object = buildin.get(paramClass);
    if (object != null)
      return object; 
    return getBeanInstance(paramClass, paramHashMap);
  }
  
  public Object getBeanInstance(Class paramClass) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException { return getBeanInstance(paramClass, new HashMap()); }
  
  private void addToTypes(HashMap paramHashMap, Class paramClass) {
    Integer integer = (Integer)paramHashMap.get(paramClass);
    int i = 0;
    if (integer != null)
      i = integer.intValue(); 
    paramHashMap.put(paramClass, new Integer(i + 1));
  }
  
  private boolean containsType(HashMap paramHashMap, Class paramClass) {
    Integer integer = (Integer)paramHashMap.get(paramClass);
    if (integer == null)
      return false; 
    return (integer.intValue() > 2);
  }
  
  public Object getBeanInstance(Class paramClass, HashMap paramHashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
    if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass))
      return getHolderInstance(paramClass, paramHashMap); 
    if (containsType(paramHashMap, paramClass))
      return null; 
    addToTypes(paramHashMap, paramClass);
    Object object = getSpecialInstance(paramClass);
    if (object == null) {
      object = paramClass.isInterface() ? getInstanceFromInterface(paramClass) : paramClass.newInstance();
      setSampleValues(object, paramHashMap);
    } 
    return object;
  }
  
  private Object getSpecialInstance(Class paramClass) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
    if (Calendar.class.isAssignableFrom(paramClass))
      return Calendar.getInstance(); 
    if (QName.class.equals(paramClass))
      return new QName("http://some.namespace/", "someName"); 
    if (javax.xml.soap.SOAPElement.class.equals(paramClass))
      return null; 
    return null;
  }
  
  private Object getHolderInstance(Class paramClass, HashMap paramHashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
    Object object1 = paramClass.newInstance();
    Field field = paramClass.getField("value");
    Object object2 = getBeanInstance(field.getType(), paramHashMap);
    field.set(object1, object2);
    return object1;
  }
  
  private void setSampleValues(Object paramObject, HashMap paramHashMap) throws ClassNotFoundException, IllegalAccessException, InstantiationException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
    BeanInfo beanInfo = Introspector.getBeanInfo(paramObject.getClass(), Object.class);
    PropertyDescriptor[] arrayOfPropertyDescriptor = beanInfo.getPropertyDescriptors();
    for (byte b = 0; b < arrayOfPropertyDescriptor.length; b++) {
      Method method = arrayOfPropertyDescriptor[b].getWriteMethod();
      if (method != null) {
        Object[] arrayOfObject = { getSampleInstance(arrayOfPropertyDescriptor[b].getPropertyType(), paramHashMap) };
        method.invoke(paramObject, arrayOfObject);
      } 
    } 
  }
  
  private Object getInstanceFromInterface(Class paramClass) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = getClass().getClassLoader(); 
    Class clazz = classLoader.loadClass(paramClass.getName());
    return clazz.newInstance();
  }
  
  public Object getArrayInstance(Class paramClass, HashMap paramHashMap) throws InstantiationException, IllegalAccessException, ClassNotFoundException, InvocationTargetException, IntrospectionException, NoSuchFieldException {
    Object object = Array.newInstance(paramClass, 1);
    for (byte b = 0; b < Array.getLength(object); b++)
      Array.set(object, b, getSampleInstance(paramClass, paramHashMap)); 
    return object;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\SampleInstance.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */