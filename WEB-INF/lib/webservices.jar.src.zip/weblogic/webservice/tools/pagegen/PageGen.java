package weblogic.webservice.tools.pagegen;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.http.HttpServletRequest;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.util.jspgen.JspGenBase;

public abstract class PageGen extends JspGenBase {
  protected Util util = new Util();
  
  protected WebService service;
  
  protected Operation[] operations;
  
  protected Port[] ports;
  
  protected HttpServletRequest request;
  
  public void setRequest(HttpServletRequest paramHttpServletRequest) { this.request = paramHttpServletRequest; }
  
  public void visit(WebService paramWebService) throws IOException {
    this.service = paramWebService;
    this.operations = getOperations(paramWebService);
    this.ports = getPorts(paramWebService);
    generate();
  }
  
  private Port[] getPorts(WebService paramWebService) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext();)
      arrayList.add(iterator.next()); 
    return (Port[])arrayList.toArray(new Port[arrayList.size()]);
  }
  
  private Operation[] getOperations(WebService paramWebService) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      BindingInfo bindingInfo = port.getBindingInfo();
      bindingInfo;
      if (bindingInfo.getTransport().equals("http11") && bindingInfo.isSoap12() != true)
        for (Iterator iterator1 = port.getOperations(); iterator1.hasNext();)
          arrayList.add(iterator1.next());  
    } 
    return (Operation[])arrayList.toArray(new Operation[arrayList.size()]);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\PageGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */