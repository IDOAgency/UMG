/*    */ package weblogic.webservice.tools.pagegen;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import weblogic.webservice.Operation;
/*    */ import weblogic.webservice.Port;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.binding.BindingInfo;
/*    */ import weblogic.webservice.util.jspgen.JspGenBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PageGen
/*    */   extends JspGenBase
/*    */ {
/* 23 */   protected Util util = new Util();
/*    */   
/*    */   protected WebService service;
/*    */   
/*    */   protected Operation[] operations;
/*    */   
/*    */   protected Port[] ports;
/*    */   
/*    */   protected HttpServletRequest request;
/*    */   
/* 33 */   public void setRequest(HttpServletRequest paramHttpServletRequest) { this.request = paramHttpServletRequest; }
/*    */ 
/*    */   
/*    */   public void visit(WebService paramWebService) throws IOException {
/* 37 */     this.service = paramWebService;
/* 38 */     this.operations = getOperations(paramWebService);
/* 39 */     this.ports = getPorts(paramWebService);
/* 40 */     generate();
/*    */   }
/*    */ 
/*    */   
/*    */   private Port[] getPorts(WebService paramWebService) {
/* 45 */     ArrayList arrayList = new ArrayList();
/*    */     
/* 47 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext();) {
/* 48 */       arrayList.add(iterator.next());
/*    */     }
/*    */     
/* 51 */     return (Port[])arrayList.toArray(new Port[arrayList.size()]);
/*    */   }
/*    */ 
/*    */   
/*    */   private Operation[] getOperations(WebService paramWebService) {
/* 56 */     ArrayList arrayList = new ArrayList();
/*    */     
/* 58 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 59 */       Port port = (Port)iterator.next();
/*    */       
/* 61 */       BindingInfo bindingInfo = port.getBindingInfo();
/*    */       
/* 63 */       bindingInfo; if (bindingInfo.getTransport().equals("http11") && bindingInfo.isSoap12() != true)
/*    */       {
/*    */         
/* 66 */         for (Iterator iterator1 = port.getOperations(); iterator1.hasNext();) {
/* 67 */           arrayList.add(iterator1.next());
/*    */         }
/*    */       }
/*    */     } 
/*    */     
/* 72 */     return (Operation[])arrayList.toArray(new Operation[arrayList.size()]);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\PageGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */