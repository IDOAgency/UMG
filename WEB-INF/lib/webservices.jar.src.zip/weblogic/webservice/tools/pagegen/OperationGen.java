/*    */ package weblogic.webservice.tools.pagegen;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import weblogic.webservice.Operation;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.util.jspgen.JspGenBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class OperationGen
/*    */   extends JspGenBase
/*    */ {
/* 35 */   protected SampleInstance sample = new SampleInstance();
/* 36 */   protected Util util = new Util();
/*    */ 
/*    */   
/*    */   protected Operation operation;
/*    */ 
/*    */   
/*    */   protected WebService service;
/*    */ 
/*    */   
/*    */   protected HttpServletRequest request;
/*    */ 
/*    */   
/* 48 */   public void setRequest(HttpServletRequest paramHttpServletRequest) { this.request = paramHttpServletRequest; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void visit(WebService paramWebService, Operation paramOperation) throws IOException {
/* 54 */     this.service = paramWebService;
/* 55 */     this.operation = paramOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 62 */     generate();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\OperationGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */