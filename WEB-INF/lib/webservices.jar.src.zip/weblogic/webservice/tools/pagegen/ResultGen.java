package weblogic.webservice.tools.pagegen;

import java.io.IOException;
import java.util.Map;
import java.util.StringTokenizer;
import weblogic.webservice.Operation;
import weblogic.webservice.WebService;
import weblogic.webservice.util.jspgen.JspGenBase;

public abstract class ResultGen extends JspGenBase {
  protected Util util = new Util();
  
  protected WebService service;
  
  protected Operation operation;
  
  protected Map results;
  
  protected String envelope;
  
  protected boolean isFault;
  
  protected String responseEnvelope;
  
  protected String requestEnvelope;
  
  public void visit(WebService paramWebService, Operation paramOperation, Map paramMap, String paramString, boolean paramBoolean) throws IOException {
    this.service = paramWebService;
    this.operation = paramOperation;
    this.results = paramMap;
    this.isFault = paramBoolean;
    int i = paramString.indexOf("<!--RESPONSE..");
    if (i != -1) {
      this.requestEnvelope = clean(paramString.substring(0, i));
      this.responseEnvelope = clean(paramString.substring(i, paramString.length()));
    } else {
      this.requestEnvelope = clean(paramString);
      this.responseEnvelope = "NO RESPONSE";
    } 
    generate();
  }
  
  private String clean(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, "<>", true);
    StringBuffer stringBuffer = new StringBuffer();
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if ("<".equals(str)) {
        stringBuffer.append("&lt;");
        continue;
      } 
      if (">".equals(str)) {
        stringBuffer.append("&gt;");
        continue;
      } 
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\ResultGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */