/*    */ package weblogic.webservice.tools.pagegen;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import java.util.StringTokenizer;
/*    */ import weblogic.webservice.Operation;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.util.jspgen.JspGenBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResultGen
/*    */   extends JspGenBase
/*    */ {
/* 27 */   protected Util util = new Util();
/*    */ 
/*    */   
/*    */   protected WebService service;
/*    */ 
/*    */   
/*    */   protected Operation operation;
/*    */ 
/*    */   
/*    */   protected Map results;
/*    */ 
/*    */   
/*    */   protected String envelope;
/*    */ 
/*    */   
/*    */   protected boolean isFault;
/*    */   
/*    */   protected String responseEnvelope;
/*    */   
/*    */   protected String requestEnvelope;
/*    */ 
/*    */   
/*    */   public void visit(WebService paramWebService, Operation paramOperation, Map paramMap, String paramString, boolean paramBoolean) throws IOException {
/* 50 */     this.service = paramWebService;
/* 51 */     this.operation = paramOperation;
/* 52 */     this.results = paramMap;
/* 53 */     this.isFault = paramBoolean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     int i = paramString.indexOf("<!--RESPONSE..");
/*    */     
/* 63 */     if (i != -1) {
/* 64 */       this.requestEnvelope = clean(paramString.substring(0, i));
/* 65 */       this.responseEnvelope = clean(paramString.substring(i, paramString.length()));
/*    */ 
/*    */     
/*    */     }
/*    */     else {
/*    */ 
/*    */ 
/*    */       
/* 73 */       this.requestEnvelope = clean(paramString);
/* 74 */       this.responseEnvelope = "NO RESPONSE";
/*    */     } 
/*    */     
/* 77 */     generate();
/*    */   }
/*    */   
/*    */   private String clean(String paramString) {
/* 81 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "<>", true);
/* 82 */     StringBuffer stringBuffer = new StringBuffer();
/*    */     
/* 84 */     while (stringTokenizer.hasMoreTokens()) {
/* 85 */       String str = stringTokenizer.nextToken();
/* 86 */       if ("<".equals(str)) {
/* 87 */         stringBuffer.append("&lt;"); continue;
/* 88 */       }  if (">".equals(str)) {
/* 89 */         stringBuffer.append("&gt;"); continue;
/*    */       } 
/* 91 */       stringBuffer.append(str);
/*    */     } 
/*    */ 
/*    */     
/* 95 */     return stringBuffer.toString();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\ResultGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */