package weblogic.webservice.tools.pagegen;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.net.URL;
import javax.servlet.http.HttpServletRequest;
import weblogic.xml.schema.binding.internal.codegen.ArrayUtils;

public class Util {
  public String getPrintableName(Class paramClass) {
    String str = paramClass.isArray() ? ArrayUtils.getArrayDeclString(paramClass.getName()) : paramClass.getName();
    int i = str.lastIndexOf(".");
    if (i != -1)
      str = str.substring(i + 1, str.length()); 
    return str;
  }
  
  public boolean isValidClientJar(HttpServletRequest paramHttpServletRequest, String paramString) {
    String str = getDocumentURL(paramHttpServletRequest, paramString);
    try {
      URL uRL = new URL(str);
      InputStream inputStream = uRL.openStream();
      inputStream.close();
      return true;
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  public String getDocumentURL(HttpServletRequest paramHttpServletRequest, String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(paramHttpServletRequest.getScheme());
    stringBuffer.append("://");
    stringBuffer.append(paramHttpServletRequest.getServerName());
    stringBuffer.append(":");
    stringBuffer.append(paramHttpServletRequest.getServerPort());
    stringBuffer.append(paramHttpServletRequest.getContextPath());
    stringBuffer.append("/");
    stringBuffer.append(paramString);
    return stringBuffer.toString();
  }
  
  public String printResult(Object paramObject) {
    if (paramObject == null)
      return "null"; 
    StringBuffer stringBuffer = new StringBuffer();
    if (paramObject.getClass().isArray()) {
      stringBuffer.append("<OL>");
      for (byte b = 0; b < Array.getLength(paramObject); b++) {
        stringBuffer.append("<LI>");
        Object object = Array.get(paramObject, b);
        stringBuffer.append((object == null) ? "null" : object);
        stringBuffer.append("</LI>");
      } 
      stringBuffer.append("</OL>");
    } else {
      stringBuffer.append(paramObject);
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */