/*    */ package weblogic.webservice.tools.pagegen;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.lang.reflect.Array;
/*    */ import java.net.URL;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import weblogic.xml.schema.binding.internal.codegen.ArrayUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Util
/*    */ {
/*    */   public String getPrintableName(Class paramClass) {
/* 20 */     String str = paramClass.isArray() ? ArrayUtils.getArrayDeclString(paramClass.getName()) : paramClass.getName();
/*    */ 
/*    */     
/* 23 */     int i = str.lastIndexOf(".");
/* 24 */     if (i != -1) {
/* 25 */       str = str.substring(i + 1, str.length());
/*    */     }
/*    */     
/* 28 */     return str;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isValidClientJar(HttpServletRequest paramHttpServletRequest, String paramString) {
/* 34 */     String str = getDocumentURL(paramHttpServletRequest, paramString);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 40 */       URL uRL = new URL(str);
/* 41 */       InputStream inputStream = uRL.openStream();
/* 42 */       inputStream.close();
/* 43 */       return true;
/* 44 */     } catch (IOException iOException) {
/*    */ 
/*    */ 
/*    */       
/* 48 */       return false;
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getDocumentURL(HttpServletRequest paramHttpServletRequest, String paramString) {
/* 53 */     StringBuffer stringBuffer = new StringBuffer();
/*    */     
/* 55 */     stringBuffer.append(paramHttpServletRequest.getScheme());
/* 56 */     stringBuffer.append("://");
/* 57 */     stringBuffer.append(paramHttpServletRequest.getServerName());
/* 58 */     stringBuffer.append(":");
/* 59 */     stringBuffer.append(paramHttpServletRequest.getServerPort());
/* 60 */     stringBuffer.append(paramHttpServletRequest.getContextPath());
/* 61 */     stringBuffer.append("/");
/* 62 */     stringBuffer.append(paramString);
/*    */     
/* 64 */     return stringBuffer.toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public String printResult(Object paramObject) {
/* 69 */     if (paramObject == null) {
/* 70 */       return "null";
/*    */     }
/*    */     
/* 73 */     StringBuffer stringBuffer = new StringBuffer();
/*    */     
/* 75 */     if (paramObject.getClass().isArray()) {
/* 76 */       stringBuffer.append("<OL>");
/* 77 */       for (byte b = 0; b < Array.getLength(paramObject); b++) {
/* 78 */         stringBuffer.append("<LI>");
/* 79 */         Object object = Array.get(paramObject, b);
/* 80 */         stringBuffer.append((object == null) ? "null" : object);
/* 81 */         stringBuffer.append("</LI>");
/*    */       } 
/* 83 */       stringBuffer.append("</OL>");
/*    */     } else {
/* 85 */       stringBuffer.append(paramObject);
/*    */     } 
/*    */     
/* 88 */     return stringBuffer.toString();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\pagegen\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */