package weblogic.webservice.tools.cmdline;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import weblogic.xml.schema.binding.ClassLoadingUtils;

public class Utils {
  public static Class loadClass(String paramString) throws ClassNotFoundException {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader == null)
      classLoader = Utils.class.getClassLoader(); 
    return ClassLoadingUtils.loadClass(paramString, classLoader);
  }
  
  public static String getResourceURL(String paramString) throws MalformedURLException {
    try {
      URL uRL = new URL(paramString);
      if (uRL != null)
        return uRL.toString(); 
    } catch (MalformedURLException malformedURLException) {}
    File file = new File(paramString);
    if (file != null && file.exists())
      return file.toURL().toString(); 
    String str = "Can't locate resource '" + paramString + "'.";
    throw new MalformedURLException(str);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cmdline\Utils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */