/*    */ package weblogic.webservice.tools.cmdline;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import weblogic.xml.schema.binding.ClassLoadingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Utils
/*    */ {
/*    */   public static Class loadClass(String paramString) throws ClassNotFoundException {
/* 19 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*    */     
/* 21 */     if (classLoader == null) classLoader = Utils.class.getClassLoader();
/*    */     
/* 23 */     return ClassLoadingUtils.loadClass(paramString, classLoader);
/*    */   }
/*    */ 
/*    */   
/*    */   public static String getResourceURL(String paramString) throws MalformedURLException {
/*    */     try {
/* 29 */       URL uRL = new URL(paramString);
/* 30 */       if (uRL != null) return uRL.toString(); 
/* 31 */     } catch (MalformedURLException malformedURLException) {}
/*    */ 
/*    */     
/* 34 */     File file = new File(paramString);
/* 35 */     if (file != null && file.exists()) {
/* 36 */       return file.toURL().toString();
/*    */     }
/*    */     
/* 39 */     String str = "Can't locate resource '" + paramString + "'.";
/*    */     
/* 41 */     throw new MalformedURLException(str);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cmdline\Utils.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */