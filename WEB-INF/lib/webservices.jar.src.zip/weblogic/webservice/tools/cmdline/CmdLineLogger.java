/*    */ package weblogic.webservice.tools.cmdline;
/*    */ 
/*    */ import weblogic.webservice.tools.build.BuildLogger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CmdLineLogger
/*    */   implements BuildLogger
/*    */ {
/*    */   private boolean verbose = false;
/*    */   
/* 17 */   public final void logError(String paramString) { System.err.println(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 21 */   public final void logWarning(String paramString) { System.err.println(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 25 */   public final void logInfo(String paramString) { System.out.println(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 29 */   public final void logVerbose(String paramString) { if (this.verbose) System.out.println(paramString);
/*    */      }
/*    */ 
/*    */   
/* 33 */   public final void logDebug(String paramString) { if (this.verbose) System.out.println(paramString);
/*    */      }
/*    */ 
/*    */   
/* 37 */   public void setVerbose(boolean paramBoolean) { this.verbose = paramBoolean; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cmdline\CmdLineLogger.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */