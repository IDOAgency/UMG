/*     */ package weblogic.webservice.tools.clientgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import weblogic.webservice.tools.build.BuildToolsFactory;
/*     */ import weblogic.webservice.tools.build.ClientGen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClientGen
/*     */ {
/*     */   private String wsdlURI;
/*     */   private File ear;
/*     */   private File clientJar;
/*     */   private String packageName;
/*     */   private String typePackageBase;
/*     */   private String typePackageName;
/*     */   private String serviceName;
/*     */   private boolean autotype = true;
/*     */   private boolean overwrite = true;
/*     */   private String defaultEndpoint;
/*     */   private String warName;
/*     */   private File typeMappingFile;
/*     */   private boolean useServerTypes = false;
/*     */   private String compilerClasspath;
/*     */   private boolean isJ2ME = false;
/*     */   private boolean saveWSDL = true;
/*     */   private boolean keepGenerated = true;
/*     */   private String portInterfaces;
/*     */   private boolean useLowerCaseMethodNames = true;
/*     */   private boolean usePortNameAsMethodName = false;
/*     */   private boolean generateAsyncMethods = false;
/*     */   private boolean generatePublicFields = false;
/*     */   private boolean onlyConvenienceMethod = false;
/*     */   
/*  67 */   public void setWSDL(String paramString) { this.wsdlURI = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public void setEar(File paramFile) { this.ear = paramFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public void setWarName(String paramString) { this.warName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public void setClientJar(File paramFile) { this.clientJar = paramFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public void setClientPackageName(String paramString) { this.packageName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void setTypePackageBase(String paramString) { this.typePackageBase = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public void setTypePackageName(String paramString) { this.typePackageName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public void setServiceName(String paramString) { this.serviceName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public void setTypeMappingFile(File paramFile) { this.typeMappingFile = paramFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public void setAutotype(boolean paramBoolean) { this.autotype = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public void setUseServerTypes(boolean paramBoolean) { this.useServerTypes = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public void setJ2ME(boolean paramBoolean) { this.isJ2ME = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   void setGenerateAsyncMethods(boolean paramBoolean) { this.generateAsyncMethods = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   void setOnlyConvenienceMethod(boolean paramBoolean) { this.onlyConvenienceMethod = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   void setGeneratePublicFields(boolean paramBoolean) { this.generatePublicFields = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 243 */   public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public void setSaveWSDL(boolean paramBoolean) { this.saveWSDL = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultendpoint(String paramString) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   public void setClasspath(String paramString) { this.compilerClasspath = System.getProperty("java.class.path") + File.separatorChar + paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateClientJar() {
/*     */     try {
/* 284 */       BuildToolsFactory buildToolsFactory = null;
/* 285 */       if (this.isJ2ME) {
/* 286 */         buildToolsFactory; buildToolsFactory = BuildToolsFactory.getInstance("j2me");
/*     */       } else {
/* 288 */         buildToolsFactory = buildToolsFactory.getInstance();
/*     */       } 
/* 290 */       ClientGen clientGen = buildToolsFactory.getClientGen();
/*     */       
/* 292 */       clientGen.setWsdlUrl(this.wsdlURI);
/* 293 */       clientGen.setEarFile(this.ear);
/* 294 */       clientGen.setWarName(this.warName);
/* 295 */       clientGen.setServiceName(this.serviceName);
/* 296 */       clientGen.setClientJar(this.clientJar);
/* 297 */       clientGen.setClientPackageName(this.packageName);
/* 298 */       clientGen.setTypePackageName(this.typePackageName);
/* 299 */       clientGen.setTypePackageBase(this.typePackageBase);
/* 300 */       clientGen.setTypeMappingFile(this.typeMappingFile);
/* 301 */       clientGen.setAutotype(this.autotype);
/* 302 */       clientGen.setUseServerTypes(this.useServerTypes);
/* 303 */       clientGen.setSaveWSDL(this.saveWSDL);
/* 304 */       clientGen.setCompilerClasspath(this.compilerClasspath);
/* 305 */       clientGen.setGenerateAsyncMethods(this.generateAsyncMethods);
/* 306 */       clientGen.setGeneratePublicFields(this.generatePublicFields);
/* 307 */       clientGen.setKeepGenerated(this.keepGenerated);
/* 308 */       clientGen.setOnlyConvenienceMethod(this.onlyConvenienceMethod);
/* 309 */       clientGen.run();
/* 310 */     } catch (Throwable throwable) {
/* 311 */       throw new ClientGenException(throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 317 */   private static String getNormalizedPath(File paramFile) { return paramFile.getAbsolutePath().replace('\\', '/'); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\clientgen\ClientGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */