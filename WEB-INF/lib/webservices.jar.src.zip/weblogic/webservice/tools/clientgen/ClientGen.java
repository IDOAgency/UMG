package weblogic.webservice.tools.clientgen;

import java.io.File;
import weblogic.webservice.tools.build.BuildToolsFactory;
import weblogic.webservice.tools.build.ClientGen;

public class ClientGen {
  private String wsdlURI;
  
  private File ear;
  
  private File clientJar;
  
  private String packageName;
  
  private String typePackageBase;
  
  private String typePackageName;
  
  private String serviceName;
  
  private boolean autotype = true;
  
  private boolean overwrite = true;
  
  private String defaultEndpoint;
  
  private String warName;
  
  private File typeMappingFile;
  
  private boolean useServerTypes = false;
  
  private String compilerClasspath;
  
  private boolean isJ2ME = false;
  
  private boolean saveWSDL = true;
  
  private boolean keepGenerated = true;
  
  private String portInterfaces;
  
  private boolean useLowerCaseMethodNames = true;
  
  private boolean usePortNameAsMethodName = false;
  
  private boolean generateAsyncMethods = false;
  
  private boolean generatePublicFields = false;
  
  private boolean onlyConvenienceMethod = false;
  
  public void setWSDL(String paramString) { this.wsdlURI = paramString; }
  
  public void setEar(File paramFile) { this.ear = paramFile; }
  
  public void setWarName(String paramString) { this.warName = paramString; }
  
  public void setClientJar(File paramFile) { this.clientJar = paramFile; }
  
  public void setClientPackageName(String paramString) { this.packageName = paramString; }
  
  public void setTypePackageBase(String paramString) { this.typePackageBase = paramString; }
  
  public void setTypePackageName(String paramString) { this.typePackageName = paramString; }
  
  public void setServiceName(String paramString) { this.serviceName = paramString; }
  
  public void setTypeMappingFile(File paramFile) { this.typeMappingFile = paramFile; }
  
  public void setAutotype(boolean paramBoolean) { this.autotype = paramBoolean; }
  
  public void setUseServerTypes(boolean paramBoolean) { this.useServerTypes = paramBoolean; }
  
  public void setOverwrite(boolean paramBoolean) { this.overwrite = paramBoolean; }
  
  public void setJ2ME(boolean paramBoolean) { this.isJ2ME = paramBoolean; }
  
  void setGenerateAsyncMethods(boolean paramBoolean) { this.generateAsyncMethods = paramBoolean; }
  
  void setOnlyConvenienceMethod(boolean paramBoolean) { this.onlyConvenienceMethod = paramBoolean; }
  
  void setGeneratePublicFields(boolean paramBoolean) { this.generatePublicFields = paramBoolean; }
  
  public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
  
  public void setSaveWSDL(boolean paramBoolean) { this.saveWSDL = paramBoolean; }
  
  public void setDefaultendpoint(String paramString) {}
  
  public void setClasspath(String paramString) { this.compilerClasspath = System.getProperty("java.class.path") + File.separatorChar + paramString; }
  
  public void generateClientJar() {
    try {
      BuildToolsFactory buildToolsFactory = null;
      if (this.isJ2ME) {
        buildToolsFactory;
        buildToolsFactory = BuildToolsFactory.getInstance("j2me");
      } else {
        buildToolsFactory = buildToolsFactory.getInstance();
      } 
      ClientGen clientGen = buildToolsFactory.getClientGen();
      clientGen.setWsdlUrl(this.wsdlURI);
      clientGen.setEarFile(this.ear);
      clientGen.setWarName(this.warName);
      clientGen.setServiceName(this.serviceName);
      clientGen.setClientJar(this.clientJar);
      clientGen.setClientPackageName(this.packageName);
      clientGen.setTypePackageName(this.typePackageName);
      clientGen.setTypePackageBase(this.typePackageBase);
      clientGen.setTypeMappingFile(this.typeMappingFile);
      clientGen.setAutotype(this.autotype);
      clientGen.setUseServerTypes(this.useServerTypes);
      clientGen.setSaveWSDL(this.saveWSDL);
      clientGen.setCompilerClasspath(this.compilerClasspath);
      clientGen.setGenerateAsyncMethods(this.generateAsyncMethods);
      clientGen.setGeneratePublicFields(this.generatePublicFields);
      clientGen.setKeepGenerated(this.keepGenerated);
      clientGen.setOnlyConvenienceMethod(this.onlyConvenienceMethod);
      clientGen.run();
    } catch (Throwable throwable) {
      throw new ClientGenException(throwable);
    } 
  }
  
  private static String getNormalizedPath(File paramFile) { return paramFile.getAbsolutePath().replace('\\', '/'); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\clientgen\ClientGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */