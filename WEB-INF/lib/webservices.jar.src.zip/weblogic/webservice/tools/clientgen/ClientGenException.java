/*    */ package weblogic.webservice.tools.clientgen;
/*    */ 
/*    */ import weblogic.utils.NestedException;
/*    */ 
/*    */ public class ClientGenException
/*    */   extends NestedException
/*    */ {
/*    */   public ClientGenException() {}
/*    */   
/* 10 */   public ClientGenException(Throwable paramThrowable) { super(paramThrowable); }
/* 11 */   public ClientGenException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
/* 12 */   public ClientGenException(String paramString) { super(paramString); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\clientgen\ClientGenException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */