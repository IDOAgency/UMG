package weblogic.webservice.tools.clientgen;

import weblogic.utils.NestedException;

public class ClientGenException extends NestedException {
  public ClientGenException() {}
  
  public ClientGenException(Throwable paramThrowable) { super(paramThrowable); }
  
  public ClientGenException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
  
  public ClientGenException(String paramString) { super(paramString); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\clientgen\ClientGenException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */