/*     */ package weblogic.webservice.tools.ddgen;
/*     */ 
/*     */ import com.sun.javadoc.ClassDoc;
/*     */ import com.sun.javadoc.MethodDoc;
/*     */ import com.sun.javadoc.Tag;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DDGenException
/*     */   extends Exception
/*     */ {
/*     */   private ClassDoc classDoc;
/*     */   private MethodDoc methodDoc;
/*     */   private Tag tag;
/*  26 */   private static final boolean verbose = Boolean.getBoolean("weblogic.webservice.tools.verbose");
/*     */ 
/*     */ 
/*     */   
/*  30 */   public Tag getTag() { return this.tag; }
/*     */ 
/*     */ 
/*     */   
/*  34 */   public void setTag(Tag paramTag) { this.tag = paramTag; }
/*     */ 
/*     */ 
/*     */   
/*  38 */   public MethodDoc getMethodDoc() { return this.methodDoc; }
/*     */ 
/*     */ 
/*     */   
/*  42 */   public void setMethodDoc(MethodDoc paramMethodDoc) { this.methodDoc = paramMethodDoc; }
/*     */ 
/*     */ 
/*     */   
/*  46 */   public ClassDoc getClassDoc() { return this.classDoc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public void setClassDoc(ClassDoc paramClassDoc) { this.classDoc = paramClassDoc; }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public DDGenException(String paramString) { super(paramString); }
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void printStackTrace() { printStackTrace(System.out); }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void printStackTrace(PrintStream paramPrintStream) { printStackTrace(new PrintWriter(paramPrintStream, true)); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter paramPrintWriter) {
/*  70 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*  72 */     stringBuffer.append("-----------------E--R--R--O--R-------------------\n");
/*     */ 
/*     */     
/*  75 */     printMessage(stringBuffer);
/*     */     
/*  77 */     if (!verbose) {
/*  78 */       stringBuffer.append("For details : ");
/*  79 */       stringBuffer.append("'weblogic.webservice.tools.verbose=true'\n");
/*     */     } 
/*     */     
/*  82 */     stringBuffer.append("-------------------------------------------------\n");
/*     */     
/*  84 */     printNeat(stringBuffer.toString(), paramPrintWriter);
/*     */     
/*  86 */     if (verbose) {
/*  87 */       super.printStackTrace(paramPrintWriter);
/*     */     }
/*     */     
/*  90 */     paramPrintWriter.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   private void printNeat(String paramString, PrintWriter paramPrintWriter) {
/*  95 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, " \n\t\r", true);
/*  96 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*  98 */     while (stringTokenizer.hasMoreTokens()) {
/*  99 */       String str = stringTokenizer.nextToken();
/*     */       
/* 101 */       if ("\n".equals(str) || "\r".equals(str)) {
/* 102 */         paramPrintWriter.println(stringBuffer);
/* 103 */         stringBuffer = new StringBuffer();
/*     */         
/*     */         continue;
/*     */       } 
/* 107 */       if (stringBuffer.length() + str.length() > 50) {
/* 108 */         stringBuffer.append("\n            : ");
/* 109 */         paramPrintWriter.print(stringBuffer.toString());
/* 110 */         stringBuffer = new StringBuffer();
/* 111 */         stringBuffer.append(str); continue;
/*     */       } 
/* 113 */       stringBuffer.append(str);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void printMessage(StringBuffer paramStringBuffer) {
/* 119 */     paramStringBuffer.append("Message     : ");
/* 120 */     paramStringBuffer.append(getMessage() + "\n\n");
/*     */     
/* 122 */     if (this.classDoc != null) {
/* 123 */       paramStringBuffer.append("Class       : ");
/* 124 */       paramStringBuffer.append(this.classDoc.name() + "\n\n");
/*     */     } 
/*     */     
/* 127 */     if (this.methodDoc != null) {
/* 128 */       paramStringBuffer.append("Method      : ");
/* 129 */       paramStringBuffer.append(this.methodDoc.name() + "\n\n");
/*     */     } 
/*     */     
/* 132 */     if (this.tag != null) {
/* 133 */       paramStringBuffer.append("JavaDoc tag : ");
/* 134 */       paramStringBuffer.append(this.tag.name() + "\n\n");
/* 135 */       paramStringBuffer.append("Tag text    : ");
/* 136 */       paramStringBuffer.append(this.tag.text().replace('\n', ' ') + "\n\n");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\DDGenException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */