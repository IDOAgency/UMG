package weblogic.webservice.tools.ddgen;

import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.Tag;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class DDGenException extends Exception {
  private ClassDoc classDoc;
  
  private MethodDoc methodDoc;
  
  private Tag tag;
  
  private static final boolean verbose = Boolean.getBoolean("weblogic.webservice.tools.verbose");
  
  public Tag getTag() { return this.tag; }
  
  public void setTag(Tag paramTag) { this.tag = paramTag; }
  
  public MethodDoc getMethodDoc() { return this.methodDoc; }
  
  public void setMethodDoc(MethodDoc paramMethodDoc) { this.methodDoc = paramMethodDoc; }
  
  public ClassDoc getClassDoc() { return this.classDoc; }
  
  public void setClassDoc(ClassDoc paramClassDoc) { this.classDoc = paramClassDoc; }
  
  public DDGenException(String paramString) { super(paramString); }
  
  public void printStackTrace() { printStackTrace(System.out); }
  
  public void printStackTrace(PrintStream paramPrintStream) { printStackTrace(new PrintWriter(paramPrintStream, true)); }
  
  public void printStackTrace(PrintWriter paramPrintWriter) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("-----------------E--R--R--O--R-------------------\n");
    printMessage(stringBuffer);
    if (!verbose) {
      stringBuffer.append("For details : ");
      stringBuffer.append("'weblogic.webservice.tools.verbose=true'\n");
    } 
    stringBuffer.append("-------------------------------------------------\n");
    printNeat(stringBuffer.toString(), paramPrintWriter);
    if (verbose)
      super.printStackTrace(paramPrintWriter); 
    paramPrintWriter.flush();
  }
  
  private void printNeat(String paramString, PrintWriter paramPrintWriter) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, " \n\t\r", true);
    StringBuffer stringBuffer = new StringBuffer();
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if ("\n".equals(str) || "\r".equals(str)) {
        paramPrintWriter.println(stringBuffer);
        stringBuffer = new StringBuffer();
        continue;
      } 
      if (stringBuffer.length() + str.length() > 50) {
        stringBuffer.append("\n            : ");
        paramPrintWriter.print(stringBuffer.toString());
        stringBuffer = new StringBuffer();
        stringBuffer.append(str);
        continue;
      } 
      stringBuffer.append(str);
    } 
  }
  
  private void printMessage(StringBuffer paramStringBuffer) {
    paramStringBuffer.append("Message     : ");
    paramStringBuffer.append(getMessage() + "\n\n");
    if (this.classDoc != null) {
      paramStringBuffer.append("Class       : ");
      paramStringBuffer.append(this.classDoc.name() + "\n\n");
    } 
    if (this.methodDoc != null) {
      paramStringBuffer.append("Method      : ");
      paramStringBuffer.append(this.methodDoc.name() + "\n\n");
    } 
    if (this.tag != null) {
      paramStringBuffer.append("JavaDoc tag : ");
      paramStringBuffer.append(this.tag.name() + "\n\n");
      paramStringBuffer.append("Tag text    : ");
      paramStringBuffer.append(this.tag.text().replace('\n', ' ') + "\n\n");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\DDGenException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */