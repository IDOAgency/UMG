/*     */ package weblogic.webservice.tools.ddgen;
/*     */ 
/*     */ import com.sun.javadoc.Tag;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TagBase
/*     */ {
/*     */   static final String EXCLUDE = "wlws:exclude";
/*     */   static final String WEBSERVICE = "wlws:webservice";
/*     */   static final String OPERATION = "wlws:operation";
/*     */   static final String PART = "wlws:part";
/*  28 */   private static String marker = " \n\r\t,\"=";
/*     */ 
/*     */   
/*     */   private Tag currentTag;
/*     */ 
/*     */   
/*     */   protected void parseTag(String paramString, XMLNode paramXMLNode, String[] paramArrayOfString) throws DDGenException {
/*  35 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, marker, true);
/*     */     
/*  37 */     while (stringTokenizer.hasMoreTokens()) {
/*  38 */       String str1 = nextNonSpaceToken(stringTokenizer);
/*     */       
/*  40 */       if (str1 == null) {
/*     */         break;
/*     */       }
/*     */       
/*  44 */       if (!nextNonSpaceToken(stringTokenizer).equals("=")) {
/*  45 */         throw new DDGenException("= not found after the name");
/*     */       }
/*     */       
/*  48 */       if (!nextNonSpaceToken(stringTokenizer).equals("\"")) {
/*  49 */         throw new DDGenException("missing \" for attribute values.");
/*     */       }
/*     */       
/*  52 */       String str2 = nextToken(stringTokenizer, "\"");
/*     */       
/*  54 */       checkAttributeNames(str1, paramArrayOfString);
/*     */       
/*  56 */       paramXMLNode.addAttribute(new Name(str1), str2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkAttributeNames(String paramString, String[] paramArrayOfString) throws DDGenException {
/*  63 */     for (byte b1 = 0; b1 < paramArrayOfString.length; b1++) {
/*  64 */       if (paramArrayOfString[b1].equals(paramString)) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/*  69 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*  71 */     for (byte b2 = 0; b2 < paramArrayOfString.length; b2++) {
/*  72 */       stringBuffer.append(paramArrayOfString[b2]).append(" | ");
/*     */     }
/*     */     
/*  75 */     throw new DDGenException("Invalide attribute '" + paramString + "' found. " + "Supported attributes are " + stringBuffer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String nextNonSpaceToken(StringTokenizer paramStringTokenizer) {
/*  81 */     while (paramStringTokenizer.hasMoreTokens()) {
/*  82 */       String str = paramStringTokenizer.nextToken();
/*     */       
/*  84 */       if (" ".equals(str) || "\n".equals(str) || "\r".equals(str) || "\t".equals(str)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/*  89 */       return str;
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String nextToken(StringTokenizer paramStringTokenizer, String paramString) throws DDGenException {
/*  99 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 101 */     while (paramStringTokenizer.hasMoreTokens()) {
/* 102 */       String str = paramStringTokenizer.nextToken();
/*     */       
/* 104 */       if (str.equals(paramString)) {
/* 105 */         return stringBuffer.toString();
/*     */       }
/* 107 */       stringBuffer.append(str);
/*     */     } 
/*     */ 
/*     */     
/* 111 */     throw new DDGenException("Not able to find [" + paramString + "] at the " + "end of the attribute");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String trimTagName(String paramString) {
/* 117 */     int i = paramString.indexOf("@");
/*     */     
/* 119 */     return (i == -1) ? paramString.trim() : paramString.substring(i + 1, paramString.length()).trim();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Iterator getWlwsTags(Tag[] paramArrayOfTag) throws DDGenException {
/* 125 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 127 */     for (byte b = 0; b < paramArrayOfTag.length; b++) {
/* 128 */       String str = trimTagName(paramArrayOfTag[b].name());
/*     */       
/* 130 */       if (str.startsWith("wlws:")) {
/* 131 */         arrayList.add(paramArrayOfTag[b]);
/*     */       }
/*     */     } 
/*     */     
/* 135 */     return arrayList.iterator();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\TagBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */