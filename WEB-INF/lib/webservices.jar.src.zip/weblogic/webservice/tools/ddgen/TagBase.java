package weblogic.webservice.tools.ddgen;

import com.sun.javadoc.Tag;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;

class TagBase {
  static final String EXCLUDE = "wlws:exclude";
  
  static final String WEBSERVICE = "wlws:webservice";
  
  static final String OPERATION = "wlws:operation";
  
  static final String PART = "wlws:part";
  
  private static String marker = " \n\r\t,\"=";
  
  private Tag currentTag;
  
  protected void parseTag(String paramString, XMLNode paramXMLNode, String[] paramArrayOfString) throws DDGenException {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, marker, true);
    while (stringTokenizer.hasMoreTokens()) {
      String str1 = nextNonSpaceToken(stringTokenizer);
      if (str1 == null)
        break; 
      if (!nextNonSpaceToken(stringTokenizer).equals("="))
        throw new DDGenException("= not found after the name"); 
      if (!nextNonSpaceToken(stringTokenizer).equals("\""))
        throw new DDGenException("missing \" for attribute values."); 
      String str2 = nextToken(stringTokenizer, "\"");
      checkAttributeNames(str1, paramArrayOfString);
      paramXMLNode.addAttribute(new Name(str1), str2);
    } 
  }
  
  private void checkAttributeNames(String paramString, String[] paramArrayOfString) throws DDGenException {
    for (byte b1 = 0; b1 < paramArrayOfString.length; b1++) {
      if (paramArrayOfString[b1].equals(paramString))
        return; 
    } 
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b2 = 0; b2 < paramArrayOfString.length; b2++)
      stringBuffer.append(paramArrayOfString[b2]).append(" | "); 
    throw new DDGenException("Invalide attribute '" + paramString + "' found. " + "Supported attributes are " + stringBuffer);
  }
  
  protected String nextNonSpaceToken(StringTokenizer paramStringTokenizer) {
    while (paramStringTokenizer.hasMoreTokens()) {
      String str = paramStringTokenizer.nextToken();
      if (" ".equals(str) || "\n".equals(str) || "\r".equals(str) || "\t".equals(str))
        continue; 
      return str;
    } 
    return null;
  }
  
  private String nextToken(StringTokenizer paramStringTokenizer, String paramString) throws DDGenException {
    StringBuffer stringBuffer = new StringBuffer();
    while (paramStringTokenizer.hasMoreTokens()) {
      String str = paramStringTokenizer.nextToken();
      if (str.equals(paramString))
        return stringBuffer.toString(); 
      stringBuffer.append(str);
    } 
    throw new DDGenException("Not able to find [" + paramString + "] at the " + "end of the attribute");
  }
  
  protected String trimTagName(String paramString) {
    int i = paramString.indexOf("@");
    return (i == -1) ? paramString.trim() : paramString.substring(i + 1, paramString.length()).trim();
  }
  
  protected Iterator getWlwsTags(Tag[] paramArrayOfTag) throws DDGenException {
    ArrayList arrayList = new ArrayList();
    for (byte b = 0; b < paramArrayOfTag.length; b++) {
      String str = trimTagName(paramArrayOfTag[b].name());
      if (str.startsWith("wlws:"))
        arrayList.add(paramArrayOfTag[b]); 
    } 
    return arrayList.iterator();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\TagBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */