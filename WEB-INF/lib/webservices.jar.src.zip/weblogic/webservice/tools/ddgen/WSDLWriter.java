package weblogic.webservice.tools.ddgen;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.webservice.WebService;
import weblogic.webservice.dd.DDLoader;
import weblogic.webservice.dd.DDProcessingException;
import weblogic.webservice.server.ConfigException;
import weblogic.webservice.server.WebServiceFactory;
import weblogic.webservice.tools.wsdlgen.WSDLGen;
import weblogic.xml.xmlnode.XMLNode;

public class WSDLWriter {
  private String wsdlFile;
  
  WSDLWriter(XMLNode paramXMLNode, String paramString) throws IOException, DDProcessingException, ConfigException {
    this.wsdlFile = paramString;
    String str = paramXMLNode.toString();
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(str.getBytes());
    DDLoader dDLoader = new DDLoader();
    WebServicesMBean webServicesMBean = dDLoader.load(byteArrayInputStream);
    WebServiceMBean[] arrayOfWebServiceMBean = webServicesMBean.getWebServices();
    WebServiceFactory webServiceFactory = WebServiceFactory.newFactoryInstance();
    if (arrayOfWebServiceMBean.length == 0)
      throw new DDProcessingException("Did not find any webservice inside the DD"); 
    if (arrayOfWebServiceMBean.length != 1)
      throw new DDProcessingException("Dont know how to handle more than one webservice per DD"); 
    WebService webService = webServiceFactory.createFromMBean(arrayOfWebServiceMBean[0], new HashMap());
    write(webService);
  }
  
  private void write(WebService paramWebService) throws IOException {
    PrintStream printStream = new PrintStream(new FileOutputStream(this.wsdlFile));
    WSDLGen wSDLGen = new WSDLGen(printStream);
    wSDLGen.setDefaultEndpoint("http://pls.set.the.end.point.address/");
    wSDLGen.visit(paramWebService);
    printStream.close();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\WSDLWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */