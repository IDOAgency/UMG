/*    */ package weblogic.webservice.tools.ddgen;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashMap;
/*    */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*    */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.dd.DDLoader;
/*    */ import weblogic.webservice.dd.DDProcessingException;
/*    */ import weblogic.webservice.server.ConfigException;
/*    */ import weblogic.webservice.server.WebServiceFactory;
/*    */ import weblogic.webservice.tools.wsdlgen.WSDLGen;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSDLWriter
/*    */ {
/*    */   private String wsdlFile;
/*    */   
/*    */   WSDLWriter(XMLNode paramXMLNode, String paramString) throws IOException, DDProcessingException, ConfigException {
/* 35 */     this.wsdlFile = paramString;
/*    */     
/* 37 */     String str = paramXMLNode.toString();
/* 38 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(str.getBytes());
/*    */     
/* 40 */     DDLoader dDLoader = new DDLoader();
/* 41 */     WebServicesMBean webServicesMBean = dDLoader.load(byteArrayInputStream);
/* 42 */     WebServiceMBean[] arrayOfWebServiceMBean = webServicesMBean.getWebServices();
/*    */     
/* 44 */     WebServiceFactory webServiceFactory = WebServiceFactory.newFactoryInstance();
/*    */     
/* 46 */     if (arrayOfWebServiceMBean.length == 0) {
/* 47 */       throw new DDProcessingException("Did not find any webservice inside the DD");
/*    */     }
/*    */ 
/*    */     
/* 51 */     if (arrayOfWebServiceMBean.length != 1) {
/* 52 */       throw new DDProcessingException("Dont know how to handle more than one webservice per DD");
/*    */     }
/*    */ 
/*    */     
/* 56 */     WebService webService = webServiceFactory.createFromMBean(arrayOfWebServiceMBean[0], new HashMap());
/*    */ 
/*    */     
/* 59 */     write(webService);
/*    */   }
/*    */   
/*    */   private void write(WebService paramWebService) throws IOException {
/* 63 */     PrintStream printStream = new PrintStream(new FileOutputStream(this.wsdlFile));
/* 64 */     WSDLGen wSDLGen = new WSDLGen(printStream);
/* 65 */     wSDLGen.setDefaultEndpoint("http://pls.set.the.end.point.address/");
/* 66 */     wSDLGen.visit(paramWebService);
/* 67 */     printStream.close();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\WSDLWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */