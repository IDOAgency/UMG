package weblogic.webservice.tools.ddgen;

import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.Parameter;
import com.sun.javadoc.Tag;
import java.util.HashSet;
import java.util.Iterator;
import weblogic.webservice.dd.DDLoader;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;

class WebServiceTag extends TagBase {
  private ClassDoc classDoc;
  
  private XMLNode webservice;
  
  private TypeMapping typeMapping;
  
  private Tag currentTag;
  
  private boolean isEjb;
  
  private static HashSet excludedSet = excludedSet();
  
  public WebServiceTag(ClassDoc paramClassDoc, XMLNode paramXMLNode, TypeMapping paramTypeMapping, boolean paramBoolean) throws DDGenException {
    this.classDoc = paramClassDoc;
    this.webservice = paramXMLNode;
    this.typeMapping = paramTypeMapping;
    this.isEjb = paramBoolean;
    try {
      parse();
    } catch (DDGenException dDGenException) {
      if (dDGenException.getTag() == null)
        dDGenException.setTag(this.currentTag); 
      dDGenException.setClassDoc(paramClassDoc);
      throw dDGenException;
    } 
  }
  
  private static HashSet excludedSet() {
    HashSet hashSet = new HashSet();
    hashSet.add("setSessionContext(javax.ejb.SessionContext)");
    hashSet.add("ejbCreate()");
    hashSet.add("ejbActivate()");
    hashSet.add("ejbPassivate()");
    hashSet.add("ejbRemove()");
    return hashSet;
  }
  
  private void parse() throws DDGenException {
    Tag tag = getTag("wlws:webservice", this.classDoc.tags());
    this.currentTag = tag;
    if (tag != null)
      parseTag(tag.text(), this.webservice, DDLoader.webserviceAttributes); 
    populateMethods();
  }
  
  private boolean isInclude(MethodDoc paramMethodDoc) {
    Tag[] arrayOfTag = paramMethodDoc.tags("wlws:exclude");
    boolean bool = (arrayOfTag == null || arrayOfTag.length == 0);
    if (bool && this.isEjb) {
      String str = paramMethodDoc.name() + paramMethodDoc.signature();
      if (excludedSet.contains(str))
        bool = false; 
    } 
    return bool;
  }
  
  private void populateMethods() throws DDGenException {
    XMLNode xMLNode = this.webservice.addChild("operations");
    MethodDoc[] arrayOfMethodDoc = this.classDoc.methods();
    for (byte b = 0; b < arrayOfMethodDoc.length; b++) {
      MethodDoc methodDoc = arrayOfMethodDoc[b];
      if (isInclude(methodDoc)) {
        XMLNode xMLNode1 = xMLNode.addChild("operation");
        xMLNode1.addAttribute(new Name("name"), methodDoc.name());
        xMLNode1.addAttribute(new Name("method"), getMethodName(methodDoc));
        xMLNode1.addAttribute(new Name("component"), this.classDoc.name());
        new MethodTag(methodDoc, xMLNode1, this.typeMapping);
      } 
    } 
  }
  
  private String getMethodName(MethodDoc paramMethodDoc) {
    Parameter[] arrayOfParameter = paramMethodDoc.parameters();
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(paramMethodDoc.name());
    stringBuffer.append("(");
    for (byte b = 0; b < arrayOfParameter.length; b++) {
      Parameter parameter = arrayOfParameter[b];
      stringBuffer.append(parameter.type().qualifiedTypeName());
      stringBuffer.append(parameter.type().dimension());
      if (b < arrayOfParameter.length - 1)
        stringBuffer.append(","); 
    } 
    stringBuffer.append(")");
    return stringBuffer.toString();
  }
  
  private Tag getTag(String paramString, Tag[] paramArrayOfTag) throws DDGenException {
    Tag tag = null;
    for (Iterator iterator = getWlwsTags(paramArrayOfTag); iterator.hasNext(); ) {
      Tag tag1 = (Tag)iterator.next();
      String str = trimTagName(tag1.name());
      if (paramString.equals(str)) {
        if (tag != null)
          throw new DDGenException("Tag [" + paramString + "] specified more than once - '" + tag + "' and '" + tag1 + "'"); 
        tag = tag1;
        continue;
      } 
      throw new DDGenException("Can not use this tag [" + tag1 + "] for class. '" + "wlws:webservice" + "' is the only tag allowed for class javadoc");
    } 
    return tag;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\WebServiceTag.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */