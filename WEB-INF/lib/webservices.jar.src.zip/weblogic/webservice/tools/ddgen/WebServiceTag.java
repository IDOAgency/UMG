/*     */ package weblogic.webservice.tools.ddgen;
/*     */ 
/*     */ import com.sun.javadoc.ClassDoc;
/*     */ import com.sun.javadoc.MethodDoc;
/*     */ import com.sun.javadoc.Parameter;
/*     */ import com.sun.javadoc.Tag;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.dd.DDLoader;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WebServiceTag
/*     */   extends TagBase
/*     */ {
/*     */   private ClassDoc classDoc;
/*     */   private XMLNode webservice;
/*     */   private TypeMapping typeMapping;
/*     */   private Tag currentTag;
/*     */   private boolean isEjb;
/*  37 */   private static HashSet excludedSet = excludedSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebServiceTag(ClassDoc paramClassDoc, XMLNode paramXMLNode, TypeMapping paramTypeMapping, boolean paramBoolean) throws DDGenException {
/*  46 */     this.classDoc = paramClassDoc;
/*  47 */     this.webservice = paramXMLNode;
/*  48 */     this.typeMapping = paramTypeMapping;
/*  49 */     this.isEjb = paramBoolean;
/*     */     
/*     */     try {
/*  52 */       parse();
/*  53 */     } catch (DDGenException dDGenException) {
/*     */       
/*  55 */       if (dDGenException.getTag() == null) {
/*  56 */         dDGenException.setTag(this.currentTag);
/*     */       }
/*     */       
/*  59 */       dDGenException.setClassDoc(paramClassDoc);
/*     */       
/*  61 */       throw dDGenException;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static HashSet excludedSet() {
/*  66 */     HashSet hashSet = new HashSet();
/*  67 */     hashSet.add("setSessionContext(javax.ejb.SessionContext)");
/*  68 */     hashSet.add("ejbCreate()");
/*  69 */     hashSet.add("ejbActivate()");
/*  70 */     hashSet.add("ejbPassivate()");
/*  71 */     hashSet.add("ejbRemove()");
/*  72 */     return hashSet;
/*     */   }
/*     */   
/*     */   private void parse() throws DDGenException {
/*  76 */     Tag tag = getTag("wlws:webservice", this.classDoc.tags());
/*     */     
/*  78 */     this.currentTag = tag;
/*     */     
/*  80 */     if (tag != null) {
/*  81 */       parseTag(tag.text(), this.webservice, DDLoader.webserviceAttributes);
/*     */     }
/*     */     
/*  84 */     populateMethods();
/*     */   }
/*     */   
/*     */   private boolean isInclude(MethodDoc paramMethodDoc) {
/*  88 */     Tag[] arrayOfTag = paramMethodDoc.tags("wlws:exclude");
/*     */     
/*  90 */     boolean bool = (arrayOfTag == null || arrayOfTag.length == 0);
/*     */ 
/*     */     
/*  93 */     if (bool && this.isEjb) {
/*  94 */       String str = paramMethodDoc.name() + paramMethodDoc.signature();
/*     */       
/*  96 */       if (excludedSet.contains(str)) {
/*  97 */         bool = false;
/*     */       }
/*     */     } 
/*     */     
/* 101 */     return bool;
/*     */   }
/*     */   
/*     */   private void populateMethods() throws DDGenException {
/* 105 */     XMLNode xMLNode = this.webservice.addChild("operations");
/*     */     
/* 107 */     MethodDoc[] arrayOfMethodDoc = this.classDoc.methods();
/*     */ 
/*     */     
/* 110 */     for (byte b = 0; b < arrayOfMethodDoc.length; b++) {
/* 111 */       MethodDoc methodDoc = arrayOfMethodDoc[b];
/*     */       
/* 113 */       if (isInclude(methodDoc)) {
/* 114 */         XMLNode xMLNode1 = xMLNode.addChild("operation");
/*     */         
/* 116 */         xMLNode1.addAttribute(new Name("name"), methodDoc.name());
/*     */         
/* 118 */         xMLNode1.addAttribute(new Name("method"), getMethodName(methodDoc));
/*     */ 
/*     */         
/* 121 */         xMLNode1.addAttribute(new Name("component"), this.classDoc.name());
/*     */         
/* 123 */         new MethodTag(methodDoc, xMLNode1, this.typeMapping);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getMethodName(MethodDoc paramMethodDoc) {
/* 129 */     Parameter[] arrayOfParameter = paramMethodDoc.parameters();
/*     */     
/* 131 */     StringBuffer stringBuffer = new StringBuffer();
/* 132 */     stringBuffer.append(paramMethodDoc.name());
/* 133 */     stringBuffer.append("(");
/*     */     
/* 135 */     for (byte b = 0; b < arrayOfParameter.length; b++) {
/* 136 */       Parameter parameter = arrayOfParameter[b];
/* 137 */       stringBuffer.append(parameter.type().qualifiedTypeName());
/* 138 */       stringBuffer.append(parameter.type().dimension());
/*     */       
/* 140 */       if (b < arrayOfParameter.length - 1) {
/* 141 */         stringBuffer.append(",");
/*     */       }
/*     */     } 
/*     */     
/* 145 */     stringBuffer.append(")");
/* 146 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private Tag getTag(String paramString, Tag[] paramArrayOfTag) throws DDGenException {
/* 151 */     Tag tag = null;
/*     */     
/* 153 */     for (Iterator iterator = getWlwsTags(paramArrayOfTag); iterator.hasNext(); ) {
/* 154 */       Tag tag1 = (Tag)iterator.next();
/*     */       
/* 156 */       String str = trimTagName(tag1.name());
/*     */       
/* 158 */       if (paramString.equals(str)) {
/*     */         
/* 160 */         if (tag != null) {
/* 161 */           throw new DDGenException("Tag [" + paramString + "] specified more than once - '" + tag + "' and '" + tag1 + "'");
/*     */         }
/*     */ 
/*     */         
/* 165 */         tag = tag1;
/*     */         continue;
/*     */       } 
/* 168 */       throw new DDGenException("Can not use this tag [" + tag1 + "] for class. '" + "wlws:webservice" + "' is the only tag allowed for class javadoc");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     return tag;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\WebServiceTag.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */