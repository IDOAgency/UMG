/*     */ package weblogic.webservice.tools.ddgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import weblogic.utils.compiler.Tool;
/*     */ import weblogic.utils.compiler.ToolFailureException;
/*     */ import weblogic.webservice.tools.MethodIterator;
/*     */ import weblogic.webservice.tools.ParamIterator;
/*     */ import weblogic.xml.schema.binding.BindingConfiguration;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilder;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilderFactory;
/*     */ import weblogic.xml.schema.binding.internal.codegen.ArrayUtils;
/*     */ import weblogic.xml.stream.ElementFactory;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DDGen
/*     */   extends Tool
/*     */ {
/*     */   private TypeMappingBuilder builder;
/*  34 */   private Set alreadyAdded = new HashSet();
/*     */   
/*     */   private boolean verbose = false;
/*     */   
/*     */   private boolean merge = false;
/*     */   private String serviceName;
/*     */   private String targetNamespace;
/*     */   private String serviceUri;
/*     */   private String registryName;
/*     */   private String componentName;
/*     */   private String componentClass;
/*     */   private String outputDirectory;
/*     */   private String outputFileName;
/*     */   private static final String ROOT_TAG = "web-services";
/*     */   private static final String SERVICE_TAG = "web-service";
/*     */   private static final String TYPES_TAG = "types";
/*     */   private static final String SCHEMA_NS = "http://www.w3.org/2001/XMLSchema";
/*     */   private static final String COMPONENTS_TAG = "components";
/*     */   private static final String CLASS_COMPONENT_TAG = "java-class";
/*     */   private static final String OPERATIONS_TAG = "operations";
/*     */   private static final String OPERATION_TAG = "operation";
/*     */   
/*     */   public DDGen(String[] paramArrayOfString) {
/*  57 */     super(paramArrayOfString);
/*  58 */     fillInOptions();
/*     */   }
/*     */   
/*     */   private void fillInOptions() {
/*  62 */     this.opts.setUsageArgs("<options>");
/*  63 */     this.opts.addFlag("v", "Turn on verbose.");
/*  64 */     this.opts.addOption("directory", "directory", "target directory to generate files");
/*  65 */     this.opts.addOption("outputFileName", "outputFileName", "The class of the component");
/*  66 */     this.opts.addOption("serviceName", "serviceName", "The name of the service in the deployment descriptor");
/*  67 */     this.opts.addOption("targetNamespace", "targetNamespace", "The target namespace.");
/*  68 */     this.opts.addOption("registryName", "registryName", "The name of the types registry");
/*  69 */     this.opts.addOption("serviceUri", "serviceUri", "The uri of the service");
/*  70 */     this.opts.addOption("componentName", "componentName", "The name of the component");
/*  71 */     this.opts.addOption("componentClass", "componentClass", "The class of the component");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkOptions() {
/*  77 */     String[] arrayOfString = { "directory", "serviceName", "targetNamespace", "serviceUri", "componentName", "componentClass", "registryName" };
/*  78 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  79 */       if (this.opts.getOption(arrayOfString[b]) == null) {
/*  80 */         throw new ToolFailureException(arrayOfString[b] + " not specified\n" + this.opts.usageMessage());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void prepare() {
/*  86 */     this.verbose = this.opts.getBooleanOption("v");
/*  87 */     this.outputDirectory = this.opts.getOption("directory");
/*  88 */     this.outputFileName = this.opts.getOption("outputFileName");
/*  89 */     if (this.outputFileName == null)
/*  90 */       this.outputFileName = "web-services.xml"; 
/*  91 */     this.serviceName = this.opts.getOption("serviceName");
/*  92 */     this.targetNamespace = this.opts.getOption("targetNamespace");
/*  93 */     this.registryName = this.opts.getOption("registryName");
/*  94 */     this.serviceUri = this.opts.getOption("serviceUri");
/*  95 */     this.componentName = this.opts.getOption("componentName");
/*  96 */     this.componentClass = this.opts.getOption("componentClass");
/*     */   }
/*     */ 
/*     */   
/*     */   public void printOptions() {
/* 101 */     System.out.println("OutputDirectory: " + this.outputDirectory);
/* 102 */     System.out.println("OutputFileName: " + this.outputFileName);
/* 103 */     System.out.println("ServiceName: " + this.serviceName);
/* 104 */     System.out.println("TargetNamespace: " + this.targetNamespace);
/* 105 */     System.out.println("RegistryName: " + this.registryName);
/* 106 */     System.out.println("ServiceUri: " + this.serviceUri);
/* 107 */     System.out.println("ComponentName: " + this.componentName);
/* 108 */     System.out.println("ComponentClass: " + this.componentClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public void runBody() {
/* 113 */     checkOptions();
/* 114 */     prepare();
/* 115 */     if (this.verbose) printOptions(); 
/* 116 */     File file = new File(this.outputDirectory, this.outputFileName);
/* 117 */     XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(new FileOutputStream(file));
/* 118 */     generate(xMLOutputStream, Class.forName(this.componentClass));
/* 119 */     xMLOutputStream.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void generate(XMLOutputStream paramXMLOutputStream, Class paramClass) throws BindingException, XMLStreamException, IOException { genRoot(paramXMLOutputStream, paramClass); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initBuilder() {
/* 131 */     this.builder = TypeMappingBuilderFactory.newInstance().createTypeMappingBuilder();
/*     */     
/* 133 */     BindingConfiguration bindingConfiguration = this.builder.getBindingConfiguration();
/* 134 */     bindingConfiguration.setAutoCreateSerials(true);
/* 135 */     bindingConfiguration.setBeanOutputDirectory(this.outputDirectory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRoot(Class paramClass) throws BindingException {
/* 142 */     MethodIterator methodIterator = new MethodIterator(paramClass);
/* 143 */     while (methodIterator.hasNext()) {
/* 144 */       add(methodIterator.next());
/*     */     }
/*     */   }
/*     */   
/*     */   private void addMapping(Class paramClass) throws BindingException {
/* 149 */     if (!this.alreadyAdded.contains(paramClass)) {
/* 150 */       if (this.verbose) System.out.println("Adding:" + paramClass); 
/* 151 */       this.alreadyAdded.add(paramClass);
/* 152 */       this.builder.addMapping(paramClass);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Class paramClass) throws BindingException {
/* 158 */     addMapping(paramClass);
/* 159 */     MethodIterator methodIterator = new MethodIterator(paramClass);
/* 160 */     while (methodIterator.hasNext()) {
/* 161 */       add(methodIterator.next());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Method paramMethod) throws BindingException {
/* 167 */     ParamIterator paramIterator = new ParamIterator(paramMethod);
/* 168 */     Class clazz = paramIterator.getReturnType();
/* 169 */     if (clazz != null && !clazz.equals(void.class)) {
/* 170 */       addMapping(clazz);
/*     */     }
/* 172 */     while (paramIterator.hasNext()) {
/* 173 */       Class clazz1 = paramIterator.next();
/*     */       
/* 175 */       addMapping(clazz1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getJavaName(String paramString) {
/* 180 */     if (paramString.charAt(0) == '[') {
/* 181 */       return ArrayUtils.getArrayDeclString(paramString);
/*     */     }
/* 183 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void genRoot(XMLOutputStream paramXMLOutputStream, Class paramClass) throws BindingException, XMLStreamException, IOException {
/* 189 */     initBuilder();
/* 190 */     addRoot(paramClass);
/*     */     
/* 192 */     paramXMLOutputStream.add(ElementFactory.createStartElement("web-services"));
/* 193 */     paramXMLOutputStream.add(ElementFactory.createNamespaceAttribute("xsd", "http://www.w3.org/2001/XMLSchema"));
/* 194 */     paramXMLOutputStream.add(ElementFactory.createStartElement("web-service"));
/* 195 */     paramXMLOutputStream.add(ElementFactory.createAttribute("name", this.serviceName));
/* 196 */     paramXMLOutputStream.add(ElementFactory.createAttribute("targetNamespace", this.targetNamespace));
/* 197 */     paramXMLOutputStream.add(ElementFactory.createAttribute("uri", this.serviceUri));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     TypeMapping typeMapping = this.builder.getTypeMapping();
/* 205 */     if (typeMapping.getEntries().length > 0) {
/*     */       
/* 207 */       paramXMLOutputStream.add(ElementFactory.createStartElement("types"));
/* 208 */       this.builder.writeGeneratedSchemas(paramXMLOutputStream);
/* 209 */       paramXMLOutputStream.add(ElementFactory.createEndElement("types"));
/* 210 */       typeMapping.writeXML(paramXMLOutputStream);
/*     */     } 
/*     */     
/* 213 */     paramXMLOutputStream.add(ElementFactory.createStartElement("components"));
/* 214 */     paramXMLOutputStream.add(ElementFactory.createStartElement("java-class"));
/* 215 */     paramXMLOutputStream.add(ElementFactory.createAttribute("name", this.componentName));
/* 216 */     paramXMLOutputStream.add(ElementFactory.createAttribute("class-name", getJavaName(paramClass.getName())));
/* 217 */     paramXMLOutputStream.add(ElementFactory.createEndElement("java-class"));
/* 218 */     paramXMLOutputStream.add(ElementFactory.createEndElement("components"));
/*     */ 
/*     */     
/* 221 */     paramXMLOutputStream.add(ElementFactory.createStartElement("operations"));
/* 222 */     gen(paramXMLOutputStream, paramClass);
/* 223 */     paramXMLOutputStream.add(ElementFactory.createEndElement("operations"));
/* 224 */     paramXMLOutputStream.add(ElementFactory.createEndElement("web-service"));
/* 225 */     paramXMLOutputStream.add(ElementFactory.createEndElement("web-services"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void gen(XMLOutputStream paramXMLOutputStream, Class paramClass) throws BindingException, XMLStreamException, IOException {
/* 231 */     MethodIterator methodIterator = new MethodIterator(paramClass);
/* 232 */     while (methodIterator.hasNext()) {
/* 233 */       gen(paramXMLOutputStream, methodIterator.next());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void gen(XMLOutputStream paramXMLOutputStream, Method paramMethod) throws BindingException, XMLStreamException {
/* 239 */     paramXMLOutputStream.add(ElementFactory.createStartElement("operation"));
/* 240 */     paramXMLOutputStream.add(ElementFactory.createAttribute("method", paramMethod.getName()));
/* 241 */     paramXMLOutputStream.add(ElementFactory.createAttribute("component", this.componentName));
/* 242 */     paramXMLOutputStream.add(ElementFactory.createAttribute("type-mapping-registry", this.registryName));
/*     */     
/* 244 */     ParamIterator paramIterator = new ParamIterator(paramMethod);
/* 245 */     TypeMapping typeMapping = this.builder.getTypeMapping();
/* 246 */     Class clazz = paramIterator.getReturnType();
/* 247 */     byte b = 0;
/* 248 */     paramXMLOutputStream.add(ElementFactory.createStartElement("params"));
/* 249 */     while (paramIterator.hasNext()) {
/* 250 */       Class clazz1 = paramIterator.next();
/* 251 */       if (typeMapping.getXMLNameFromClass(clazz1) == null)
/* 252 */         throw new BindingException("xml name is null"); 
/* 253 */       paramXMLOutputStream.add(ElementFactory.createStartElement("param"));
/* 254 */       paramXMLOutputStream.add(ElementFactory.createNamespaceAttribute("mytypes", typeMapping.getXMLNameFromClass(clazz1).getNamespaceUri()));
/* 255 */       paramXMLOutputStream.add(ElementFactory.createAttribute("name", "param" + b));
/* 256 */       paramXMLOutputStream.add(ElementFactory.createAttribute("type", "mytypes:" + typeMapping.getXMLNameFromClass(clazz1).getLocalName()));
/* 257 */       if (clazz1.isAssignableFrom(javax.xml.rpc.holders.Holder.class)) {
/* 258 */         paramXMLOutputStream.add(ElementFactory.createAttribute("style", "inout"));
/*     */       } else {
/* 260 */         paramXMLOutputStream.add(ElementFactory.createAttribute("style", "in"));
/*     */       } 
/* 262 */       paramXMLOutputStream.add(ElementFactory.createAttribute("location", "body"));
/* 263 */       paramXMLOutputStream.add(ElementFactory.createEndElement("param"));
/* 264 */       b++;
/*     */     } 
/*     */     
/* 267 */     if (clazz != null && !clazz.equals(void.class)) {
/* 268 */       if (typeMapping.getXMLNameFromClass(clazz) == null)
/* 269 */         throw new BindingException("xml name is null"); 
/* 270 */       paramXMLOutputStream.add(ElementFactory.createStartElement("return-param"));
/* 271 */       paramXMLOutputStream.add(ElementFactory.createNamespaceAttribute("mytypes", typeMapping.getXMLNameFromClass(clazz).getNamespaceUri()));
/* 272 */       paramXMLOutputStream.add(ElementFactory.createAttribute("name", "result"));
/* 273 */       paramXMLOutputStream.add(ElementFactory.createAttribute("type", "mytypes:" + typeMapping.getXMLNameFromClass(clazz).getLocalName()));
/* 274 */       paramXMLOutputStream.add(ElementFactory.createAttribute("location", "body"));
/* 275 */       paramXMLOutputStream.add(ElementFactory.createEndElement("return-param"));
/*     */     } 
/* 277 */     paramXMLOutputStream.add(ElementFactory.createEndElement("params"));
/* 278 */     paramXMLOutputStream.add(ElementFactory.createEndElement("operation"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 287 */   public static void main(String[] paramArrayOfString) { (new DDGen(paramArrayOfString)).run(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\DDGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */