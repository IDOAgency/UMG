/*     */ package weblogic.webservice.tools.ddgen;
/*     */ 
/*     */ import com.sun.javadoc.ClassDoc;
/*     */ import com.sun.javadoc.DocErrorReporter;
/*     */ import com.sun.javadoc.RootDoc;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.encoding.TypeMapping;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import weblogic.utils.classloaders.ClasspathClassLoader;
/*     */ import weblogic.webservice.core.encoding.DefaultRegistry;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.util.ClassUtil;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceGen
/*     */ {
/*  41 */   private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
/*     */ 
/*     */   
/*  44 */   private static String FILE_NAME = "-fileName";
/*  45 */   private static String URI = "-uri";
/*  46 */   private static String TARGET_NAMESPACE = "-targetNamespace";
/*  47 */   private static String TYPES_INFO = "-typesInfo";
/*  48 */   private static String HANDLER_INFO = "-handlerInfo";
/*  49 */   private static String EJB_LINK = "-ejbLink";
/*  50 */   private static String WSDL_FILE = "-wsdlFile";
/*  51 */   private static String MERGE_WS = "-mergeWithExistingWS";
/*  52 */   private static String CLASSPATH = "-classpath";
/*  53 */   private static String IGNORE_AUTH_HEADER = "-ignoreAuthHeader";
/*  54 */   private static String SECURITY_INFO = "-securityInfo";
/*     */   
/*     */   private static ServiceGen gen;
/*     */   
/*     */   private String fileName;
/*     */   private ClassDoc classDoc;
/*     */   private String uri;
/*     */   private String typesInfo;
/*     */   private String securityInfo;
/*     */   private String classpath;
/*  64 */   private String targetNamespace = "http://tempuri.org/";
/*     */   
/*     */   private String handlerInfo;
/*     */   
/*     */   private String ejbLink;
/*     */   private String ignoreAuthHeader;
/*     */   private String wsdlFile;
/*     */   private boolean isEjb = false;
/*     */   private boolean mergeWithExistingWS = false;
/*  73 */   private TypeMappingRegistry registry = new DefaultRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   TypeMapping getTypeMapping() { return this.registry.getDefaultTypeMapping(); }
/*     */ 
/*     */ 
/*     */   
/*     */   private void generate() {
/*  84 */     validate();
/*     */     
/*  86 */     classpathClassLoader = new ClasspathClassLoader(this.classpath);
/*  87 */     classLoader = Thread.currentThread().getContextClassLoader();
/*  88 */     Thread.currentThread().setContextClassLoader(classpathClassLoader);
/*     */     
/*     */     try {
/*  91 */       if (this.typesInfo != null) {
/*  92 */         this.registry = new DefaultRegistry(this.typesInfo);
/*     */       }
/*     */       
/*  95 */       XMLNode xMLNode = getWebServices();
/*     */       
/*  97 */       populateHandlerChain(xMLNode);
/*  98 */       populateWebServices(xMLNode);
/*     */       
/* 100 */       String str = charset;
/* 101 */       if (str == null) str = "UTF-8";
/*     */       
/* 103 */       PrintStream printStream = (this.fileName == null) ? System.out : new PrintStream(new FileOutputStream(this.fileName), false, str);
/*     */ 
/*     */       
/* 106 */       printStream.print("<?xml version=\"1.0\" encoding=\"" + str + "\"?>\n");
/* 107 */       printStream.print(xMLNode);
/* 108 */       printStream.close();
/*     */       
/* 110 */       if (this.wsdlFile != null) {
/* 111 */         new WSDLWriter(xMLNode, this.wsdlFile);
/*     */       }
/*     */     } finally {
/*     */       
/* 115 */       classpathClassLoader.close();
/* 116 */       Thread.currentThread().setContextClassLoader(classLoader);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private XMLNode getWebServices() throws IOException {
/* 122 */     File file = new File(this.fileName);
/*     */     
/* 124 */     XMLNode xMLNode = new XMLNode();
/*     */     
/* 126 */     if (file.exists() && this.mergeWithExistingWS) {
/* 127 */       xMLNode.read(new FileInputStream(file));
/*     */     } else {
/* 129 */       xMLNode.setName("web-services", null, null);
/*     */     } 
/*     */     
/* 132 */     return xMLNode;
/*     */   }
/*     */ 
/*     */   
/*     */   private void validate() {
/* 137 */     if (this.uri == null) {
/* 138 */       throw new DDGenException("-uri not specified");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateHandlerChain(XMLNode paramXMLNode) throws IOException, DDGenException {
/* 145 */     if (this.handlerInfo == null) {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     FileInputStream fileInputStream = new FileInputStream(this.handlerInfo);
/* 150 */     XMLNode xMLNode = new XMLNode();
/* 151 */     xMLNode.read(fileInputStream);
/* 152 */     fileInputStream.close();
/*     */     
/* 154 */     paramXMLNode.addChild(xMLNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateWebServices(XMLNode paramXMLNode) throws IOException, DDGenException {
/* 160 */     XMLNode xMLNode = paramXMLNode.addChild("web-service");
/* 161 */     populateSecurityInfo(xMLNode);
/*     */     
/* 163 */     if (this.typesInfo != null) {
/* 164 */       populateTypes(xMLNode, this.typesInfo);
/*     */     }
/*     */ 
/*     */     
/* 168 */     populateComponent(xMLNode);
/* 169 */     xMLNode.addAttribute(new Name("name"), this.classDoc.name());
/* 170 */     xMLNode.addAttribute(new Name("uri"), this.uri);
/* 171 */     xMLNode.addAttribute(new Name("targetNamespace"), this.targetNamespace);
/*     */     
/* 173 */     if (this.ignoreAuthHeader != null) {
/* 174 */       xMLNode.addAttribute(new Name("ignoreAuthHeader"), this.ignoreAuthHeader);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 179 */     new WebServiceTag(this.classDoc, xMLNode, (TypeMapping)getTypeMapping(), this.isEjb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateTypes(XMLNode paramXMLNode, String paramString) throws IOException {
/* 187 */     XMLNode xMLNode1 = new XMLNode();
/* 188 */     xMLNode1.read(new FileInputStream(paramString), true);
/*     */     
/* 190 */     XMLNode xMLNode2 = paramXMLNode.addChild("types");
/*     */     
/* 192 */     for (Iterator iterator = xMLNode1.getChildren(); iterator.hasNext(); ) {
/* 193 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 195 */       if ("schema".equals(xMLNode.getName().getLocalName())) {
/* 196 */         xMLNode2.addChild(xMLNode);
/*     */       }
/*     */       
/* 199 */       if ("type-mapping".equals(xMLNode.getName().getLocalName())) {
/* 200 */         paramXMLNode.addChild(xMLNode);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateSecurityInfo(XMLNode paramXMLNode) throws IOException, DDGenException {
/* 208 */     if (this.securityInfo == null) {
/*     */       return;
/*     */     }
/*     */     
/* 212 */     FileInputStream fileInputStream = new FileInputStream(this.securityInfo);
/* 213 */     XMLNode xMLNode = new XMLNode();
/* 214 */     xMLNode.read(fileInputStream);
/* 215 */     fileInputStream.close();
/*     */     
/* 217 */     paramXMLNode.addChild(xMLNode);
/*     */   }
/*     */ 
/*     */   
/*     */   private void populateComponent(XMLNode paramXMLNode) throws IOException, DDGenException {
/* 222 */     XMLNode xMLNode = paramXMLNode.addChild("components");
/*     */     
/* 224 */     if (this.ejbLink == null) {
/* 225 */       this.isEjb = false;
/* 226 */       XMLNode xMLNode1 = xMLNode.addChild("java-class");
/*     */       
/* 228 */       xMLNode1.addAttribute(new Name("name"), this.classDoc.name());
/*     */       
/* 230 */       String str = this.classDoc.qualifiedName();
/*     */       
/* 232 */       if (!canCreate(str)) {
/* 233 */         throw new DDGenException("The end component class specified [" + str + "] do not have a public default constructor. " + "If this is an EJB back end component, please specify 'ejbLink' " + "attribute in source2wsdd ant task");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       xMLNode1.addAttribute(new Name("class-name"), this.classDoc.qualifiedName());
/*     */     } else {
/*     */       
/* 242 */       this.isEjb = true;
/* 243 */       XMLNode xMLNode1 = xMLNode.addChild("stateless-ejb");
/* 244 */       xMLNode1.addAttribute(new Name("name"), this.classDoc.name());
/*     */       
/* 246 */       XMLNode xMLNode2 = xMLNode1.addChild("ejb-link");
/* 247 */       xMLNode2.addAttribute(new Name("path"), this.ejbLink);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean canCreate(String paramString) throws DDGenException {
/* 252 */     Class clazz = ClassUtil.loadClass(paramString);
/*     */     
/* 254 */     if (clazz == null) {
/* 255 */       throw new DDGenException("Unable to load class :" + paramString);
/*     */     }
/*     */     
/* 258 */     if (clazz.isInterface()) {
/* 259 */       return false;
/*     */     }
/*     */     
/*     */     try {
/* 263 */       Constructor constructor = clazz.getDeclaredConstructor((Class[])null);
/* 264 */     } catch (NoSuchMethodException noSuchMethodException) {
/* 265 */       return false;
/*     */     } 
/*     */     
/* 268 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean start(RootDoc paramRootDoc) throws Exception {
/* 279 */     ClassDoc[] arrayOfClassDoc = paramRootDoc.classes();
/*     */     
/* 281 */     if (arrayOfClassDoc == null || arrayOfClassDoc.length == 0) {
/* 282 */       throw new IllegalArgumentException("Unable to find javadoc. source fileName should be of the form: /my/pakcage/name/SourceFile.java");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 287 */     if (arrayOfClassDoc.length != 1) {
/* 288 */       throw new IllegalArgumentException("Only knows how to handle one java source file, but got ... " + arrayOfClassDoc.length);
/*     */     }
/*     */ 
/*     */     
/* 292 */     ServiceGen serviceGen = new ServiceGen();
/*     */     
/* 294 */     String[][] arrayOfString = paramRootDoc.options();
/* 295 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 296 */       String str1 = arrayOfString[b][0];
/* 297 */       String str2 = arrayOfString[b][1];
/*     */       
/* 299 */       if (FILE_NAME.equals(str1)) {
/* 300 */         serviceGen.fileName = str2;
/* 301 */       } else if (URI.equals(str1)) {
/* 302 */         serviceGen.uri = str2;
/* 303 */       } else if (TARGET_NAMESPACE.equals(str1)) {
/* 304 */         serviceGen.targetNamespace = str2;
/* 305 */       } else if (TYPES_INFO.equals(str1)) {
/* 306 */         serviceGen.typesInfo = str2;
/* 307 */       } else if (CLASSPATH.equals(str1)) {
/* 308 */         serviceGen.classpath = str2;
/* 309 */       } else if (HANDLER_INFO.equals(str1)) {
/* 310 */         serviceGen.handlerInfo = str2;
/* 311 */       } else if (WSDL_FILE.equals(str1)) {
/* 312 */         serviceGen.wsdlFile = str2;
/* 313 */       } else if (EJB_LINK.equals(str1)) {
/* 314 */         serviceGen.ejbLink = str2;
/* 315 */       } else if (IGNORE_AUTH_HEADER.equals(str1)) {
/* 316 */         serviceGen.ignoreAuthHeader = str2;
/* 317 */       } else if (MERGE_WS.equals(str1)) {
/* 318 */         serviceGen.mergeWithExistingWS = Boolean.valueOf(str2).booleanValue();
/* 319 */       } else if (SECURITY_INFO.equals(str1)) {
/* 320 */         serviceGen.securityInfo = str2;
/*     */       } 
/*     */     } 
/*     */     
/* 324 */     serviceGen.classDoc = arrayOfClassDoc[0];
/* 325 */     serviceGen.generate();
/* 326 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int optionLength(String paramString) {
/* 333 */     if (FILE_NAME.equals(paramString) || URI.equals(paramString) || TYPES_INFO.equals(paramString) || IGNORE_AUTH_HEADER.equals(paramString) || SECURITY_INFO.equals(paramString) || EJB_LINK.equals(paramString) || WSDL_FILE.equals(paramString) || HANDLER_INFO.equals(paramString) || MERGE_WS.equals(paramString) || CLASSPATH.equals(paramString) || TARGET_NAMESPACE.equals(paramString))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 344 */       return 2;
/*     */     }
/* 346 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean validOptions(String[][] paramArrayOfString, DocErrorReporter paramDocErrorReporter) {
/* 356 */     if (gen == null) {
/* 357 */       gen = new ServiceGen();
/*     */     }
/*     */     
/* 360 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*     */       
/* 362 */       String str1 = paramArrayOfString[b][0];
/* 363 */       String str2 = paramArrayOfString[b][1];
/*     */       
/* 365 */       if (FILE_NAME.equals(str1)) {
/* 366 */         gen.fileName = str2;
/*     */       }
/*     */       
/* 369 */       if (URI.equals(str1)) {
/* 370 */         gen.uri = str2;
/*     */       }
/*     */       
/* 373 */       if (TARGET_NAMESPACE.equals(str1)) {
/* 374 */         gen.targetNamespace = str2;
/*     */       }
/*     */       
/* 377 */       if (TYPES_INFO.equals(str1)) {
/* 378 */         gen.typesInfo = str2;
/*     */       }
/*     */       
/* 381 */       if (SECURITY_INFO.equals(str1)) {
/* 382 */         gen.securityInfo = str2;
/*     */       }
/*     */       
/* 385 */       if (EJB_LINK.equals(str1)) {
/* 386 */         gen.ejbLink = str2;
/*     */       }
/*     */       
/* 389 */       if (HANDLER_INFO.equals(str1)) {
/* 390 */         gen.handlerInfo = str2;
/*     */       }
/*     */       
/* 393 */       if (IGNORE_AUTH_HEADER.equals(str1)) {
/* 394 */         gen.ignoreAuthHeader = str2;
/*     */       }
/*     */       
/* 397 */       if (MERGE_WS.equals(str1)) {
/* 398 */         gen.mergeWithExistingWS = Boolean.valueOf(str2).booleanValue();
/*     */       }
/*     */     } 
/*     */     
/* 402 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\ServiceGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */