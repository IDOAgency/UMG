package weblogic.webservice.tools.ddgen;

import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.DocErrorReporter;
import com.sun.javadoc.RootDoc;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.util.Iterator;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import weblogic.utils.classloaders.ClasspathClassLoader;
import weblogic.webservice.core.encoding.DefaultRegistry;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.util.ClassUtil;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;

public class ServiceGen {
  private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
  
  private static String FILE_NAME = "-fileName";
  
  private static String URI = "-uri";
  
  private static String TARGET_NAMESPACE = "-targetNamespace";
  
  private static String TYPES_INFO = "-typesInfo";
  
  private static String HANDLER_INFO = "-handlerInfo";
  
  private static String EJB_LINK = "-ejbLink";
  
  private static String WSDL_FILE = "-wsdlFile";
  
  private static String MERGE_WS = "-mergeWithExistingWS";
  
  private static String CLASSPATH = "-classpath";
  
  private static String IGNORE_AUTH_HEADER = "-ignoreAuthHeader";
  
  private static String SECURITY_INFO = "-securityInfo";
  
  private static ServiceGen gen;
  
  private String fileName;
  
  private ClassDoc classDoc;
  
  private String uri;
  
  private String typesInfo;
  
  private String securityInfo;
  
  private String classpath;
  
  private String targetNamespace = "http://tempuri.org/";
  
  private String handlerInfo;
  
  private String ejbLink;
  
  private String ignoreAuthHeader;
  
  private String wsdlFile;
  
  private boolean isEjb = false;
  
  private boolean mergeWithExistingWS = false;
  
  private TypeMappingRegistry registry = new DefaultRegistry();
  
  TypeMapping getTypeMapping() { return this.registry.getDefaultTypeMapping(); }
  
  private void generate() {
    validate();
    classpathClassLoader = new ClasspathClassLoader(this.classpath);
    classLoader = Thread.currentThread().getContextClassLoader();
    Thread.currentThread().setContextClassLoader(classpathClassLoader);
    try {
      if (this.typesInfo != null)
        this.registry = new DefaultRegistry(this.typesInfo); 
      XMLNode xMLNode = getWebServices();
      populateHandlerChain(xMLNode);
      populateWebServices(xMLNode);
      String str = charset;
      if (str == null)
        str = "UTF-8"; 
      PrintStream printStream = (this.fileName == null) ? System.out : new PrintStream(new FileOutputStream(this.fileName), false, str);
      printStream.print("<?xml version=\"1.0\" encoding=\"" + str + "\"?>\n");
      printStream.print(xMLNode);
      printStream.close();
      if (this.wsdlFile != null)
        new WSDLWriter(xMLNode, this.wsdlFile); 
    } finally {
      classpathClassLoader.close();
      Thread.currentThread().setContextClassLoader(classLoader);
    } 
  }
  
  private XMLNode getWebServices() throws IOException {
    File file = new File(this.fileName);
    XMLNode xMLNode = new XMLNode();
    if (file.exists() && this.mergeWithExistingWS) {
      xMLNode.read(new FileInputStream(file));
    } else {
      xMLNode.setName("web-services", null, null);
    } 
    return xMLNode;
  }
  
  private void validate() {
    if (this.uri == null)
      throw new DDGenException("-uri not specified"); 
  }
  
  private void populateHandlerChain(XMLNode paramXMLNode) throws IOException, DDGenException {
    if (this.handlerInfo == null)
      return; 
    FileInputStream fileInputStream = new FileInputStream(this.handlerInfo);
    XMLNode xMLNode = new XMLNode();
    xMLNode.read(fileInputStream);
    fileInputStream.close();
    paramXMLNode.addChild(xMLNode);
  }
  
  private void populateWebServices(XMLNode paramXMLNode) throws IOException, DDGenException {
    XMLNode xMLNode = paramXMLNode.addChild("web-service");
    populateSecurityInfo(xMLNode);
    if (this.typesInfo != null)
      populateTypes(xMLNode, this.typesInfo); 
    populateComponent(xMLNode);
    xMLNode.addAttribute(new Name("name"), this.classDoc.name());
    xMLNode.addAttribute(new Name("uri"), this.uri);
    xMLNode.addAttribute(new Name("targetNamespace"), this.targetNamespace);
    if (this.ignoreAuthHeader != null)
      xMLNode.addAttribute(new Name("ignoreAuthHeader"), this.ignoreAuthHeader); 
    new WebServiceTag(this.classDoc, xMLNode, (TypeMapping)getTypeMapping(), this.isEjb);
  }
  
  private void populateTypes(XMLNode paramXMLNode, String paramString) throws IOException {
    XMLNode xMLNode1 = new XMLNode();
    xMLNode1.read(new FileInputStream(paramString), true);
    XMLNode xMLNode2 = paramXMLNode.addChild("types");
    for (Iterator iterator = xMLNode1.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if ("schema".equals(xMLNode.getName().getLocalName()))
        xMLNode2.addChild(xMLNode); 
      if ("type-mapping".equals(xMLNode.getName().getLocalName()))
        paramXMLNode.addChild(xMLNode); 
    } 
  }
  
  private void populateSecurityInfo(XMLNode paramXMLNode) throws IOException, DDGenException {
    if (this.securityInfo == null)
      return; 
    FileInputStream fileInputStream = new FileInputStream(this.securityInfo);
    XMLNode xMLNode = new XMLNode();
    xMLNode.read(fileInputStream);
    fileInputStream.close();
    paramXMLNode.addChild(xMLNode);
  }
  
  private void populateComponent(XMLNode paramXMLNode) throws IOException, DDGenException {
    XMLNode xMLNode = paramXMLNode.addChild("components");
    if (this.ejbLink == null) {
      this.isEjb = false;
      XMLNode xMLNode1 = xMLNode.addChild("java-class");
      xMLNode1.addAttribute(new Name("name"), this.classDoc.name());
      String str = this.classDoc.qualifiedName();
      if (!canCreate(str))
        throw new DDGenException("The end component class specified [" + str + "] do not have a public default constructor. " + "If this is an EJB back end component, please specify 'ejbLink' " + "attribute in source2wsdd ant task"); 
      xMLNode1.addAttribute(new Name("class-name"), this.classDoc.qualifiedName());
    } else {
      this.isEjb = true;
      XMLNode xMLNode1 = xMLNode.addChild("stateless-ejb");
      xMLNode1.addAttribute(new Name("name"), this.classDoc.name());
      XMLNode xMLNode2 = xMLNode1.addChild("ejb-link");
      xMLNode2.addAttribute(new Name("path"), this.ejbLink);
    } 
  }
  
  private boolean canCreate(String paramString) throws DDGenException {
    Class clazz = ClassUtil.loadClass(paramString);
    if (clazz == null)
      throw new DDGenException("Unable to load class :" + paramString); 
    if (clazz.isInterface())
      return false; 
    try {
      Constructor constructor = clazz.getDeclaredConstructor((Class[])null);
    } catch (NoSuchMethodException noSuchMethodException) {
      return false;
    } 
    return true;
  }
  
  public static boolean start(RootDoc paramRootDoc) throws Exception {
    ClassDoc[] arrayOfClassDoc = paramRootDoc.classes();
    if (arrayOfClassDoc == null || arrayOfClassDoc.length == 0)
      throw new IllegalArgumentException("Unable to find javadoc. source fileName should be of the form: /my/pakcage/name/SourceFile.java"); 
    if (arrayOfClassDoc.length != 1)
      throw new IllegalArgumentException("Only knows how to handle one java source file, but got ... " + arrayOfClassDoc.length); 
    ServiceGen serviceGen = new ServiceGen();
    String[][] arrayOfString = paramRootDoc.options();
    for (byte b = 0; b < arrayOfString.length; b++) {
      String str1 = arrayOfString[b][0];
      String str2 = arrayOfString[b][1];
      if (FILE_NAME.equals(str1)) {
        serviceGen.fileName = str2;
      } else if (URI.equals(str1)) {
        serviceGen.uri = str2;
      } else if (TARGET_NAMESPACE.equals(str1)) {
        serviceGen.targetNamespace = str2;
      } else if (TYPES_INFO.equals(str1)) {
        serviceGen.typesInfo = str2;
      } else if (CLASSPATH.equals(str1)) {
        serviceGen.classpath = str2;
      } else if (HANDLER_INFO.equals(str1)) {
        serviceGen.handlerInfo = str2;
      } else if (WSDL_FILE.equals(str1)) {
        serviceGen.wsdlFile = str2;
      } else if (EJB_LINK.equals(str1)) {
        serviceGen.ejbLink = str2;
      } else if (IGNORE_AUTH_HEADER.equals(str1)) {
        serviceGen.ignoreAuthHeader = str2;
      } else if (MERGE_WS.equals(str1)) {
        serviceGen.mergeWithExistingWS = Boolean.valueOf(str2).booleanValue();
      } else if (SECURITY_INFO.equals(str1)) {
        serviceGen.securityInfo = str2;
      } 
    } 
    serviceGen.classDoc = arrayOfClassDoc[0];
    serviceGen.generate();
    return true;
  }
  
  public static int optionLength(String paramString) {
    if (FILE_NAME.equals(paramString) || URI.equals(paramString) || TYPES_INFO.equals(paramString) || IGNORE_AUTH_HEADER.equals(paramString) || SECURITY_INFO.equals(paramString) || EJB_LINK.equals(paramString) || WSDL_FILE.equals(paramString) || HANDLER_INFO.equals(paramString) || MERGE_WS.equals(paramString) || CLASSPATH.equals(paramString) || TARGET_NAMESPACE.equals(paramString))
      return 2; 
    return 0;
  }
  
  public static boolean validOptions(String[][] paramArrayOfString, DocErrorReporter paramDocErrorReporter) {
    if (gen == null)
      gen = new ServiceGen(); 
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      String str1 = paramArrayOfString[b][0];
      String str2 = paramArrayOfString[b][1];
      if (FILE_NAME.equals(str1))
        gen.fileName = str2; 
      if (URI.equals(str1))
        gen.uri = str2; 
      if (TARGET_NAMESPACE.equals(str1))
        gen.targetNamespace = str2; 
      if (TYPES_INFO.equals(str1))
        gen.typesInfo = str2; 
      if (SECURITY_INFO.equals(str1))
        gen.securityInfo = str2; 
      if (EJB_LINK.equals(str1))
        gen.ejbLink = str2; 
      if (HANDLER_INFO.equals(str1))
        gen.handlerInfo = str2; 
      if (IGNORE_AUTH_HEADER.equals(str1))
        gen.ignoreAuthHeader = str2; 
      if (MERGE_WS.equals(str1))
        gen.mergeWithExistingWS = Boolean.valueOf(str2).booleanValue(); 
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\ServiceGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */