/*     */ package weblogic.webservice.tools.ddgen;
/*     */ 
/*     */ import com.sun.javadoc.ClassDoc;
/*     */ import com.sun.javadoc.MethodDoc;
/*     */ import com.sun.javadoc.Parameter;
/*     */ import com.sun.javadoc.Tag;
/*     */ import com.sun.javadoc.Type;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import weblogic.webservice.dd.DDLoader;
/*     */ import weblogic.webservice.util.ExceptionUtil;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.util.ClassUtil;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MethodTag
/*     */   extends TagBase
/*     */ {
/*     */   private MethodDoc methodDoc;
/*     */   private XMLNode operation;
/*     */   private XMLNode params;
/*     */   private TypeMapping typeMapping;
/*     */   private Tag currentTag;
/*  42 */   private static final String[] returnAttributes = addTypeNS(DDLoader.returnAttributes);
/*     */ 
/*     */   
/*  45 */   private static final String[] paramAttributes = addTypeNS(DDLoader.paramAttributes);
/*     */ 
/*     */   
/*  48 */   private static HashSet supportedTags = new HashSet();
/*     */   
/*     */   static  {
/*  51 */     supportedTags.add("wlws:operation");
/*  52 */     supportedTags.add("wlws:part");
/*  53 */     supportedTags.add("wlws:exclude");
/*     */   }
/*     */   
/*     */   private static String[] addTypeNS(String[] paramArrayOfString) {
/*  57 */     String[] arrayOfString = new String[paramArrayOfString.length + 1];
/*     */     
/*  59 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*  60 */       arrayOfString[b] = paramArrayOfString[b];
/*     */     }
/*     */     
/*  63 */     arrayOfString[arrayOfString.length - 1] = "xmlns:typeNS";
/*     */     
/*  65 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodTag(MethodDoc paramMethodDoc, XMLNode paramXMLNode, TypeMapping paramTypeMapping) throws DDGenException {
/*  71 */     this.methodDoc = paramMethodDoc;
/*  72 */     this.operation = paramXMLNode;
/*  73 */     this.typeMapping = paramTypeMapping;
/*     */     
/*     */     try {
/*  76 */       parse();
/*  77 */     } catch (DDGenException dDGenException) {
/*  78 */       dDGenException.setMethodDoc(paramMethodDoc);
/*  79 */       dDGenException.setTag(this.currentTag);
/*     */       
/*  81 */       throw dDGenException;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void parse() throws DDGenException {
/*  86 */     Tag tag = getOperationTag(this.methodDoc.tags());
/*  87 */     this.currentTag = tag;
/*     */     
/*  89 */     if (tag != null) {
/*  90 */       parseTag(tag.text(), this.operation, DDLoader.operationAttributes);
/*     */     }
/*     */     
/*  93 */     populateParameters();
/*  94 */     parsePartTags();
/*  95 */     populateExceptions();
/*     */   }
/*     */ 
/*     */   
/*     */   private void populateExceptions() throws DDGenException {
/* 100 */     ClassDoc[] arrayOfClassDoc = this.methodDoc.thrownExceptions();
/*     */     
/* 102 */     for (byte b = 0; b < arrayOfClassDoc.length; b++) {
/* 103 */       ClassDoc classDoc = arrayOfClassDoc[b];
/*     */       
/* 105 */       String str = classDoc.qualifiedName();
/*     */       
/* 107 */       Class clazz = ClassUtil.loadClass(str);
/*     */       
/* 109 */       if (!str.startsWith("java.") && !str.startsWith("javax.") && !str.equals("java.lang.Exception") && !java.rmi.RemoteException.class.isAssignableFrom(clazz) && !RuntimeException.class.isAssignableFrom(clazz)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 118 */         XMLNode xMLNode = this.params.addChild("fault");
/* 119 */         xMLNode.addAttribute(new Name("name"), classDoc.name());
/* 120 */         xMLNode.addAttribute(new Name("class-name"), str);
/*     */         
/* 122 */         setExceptionTypeInfo(xMLNode, clazz);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void setExceptionTypeInfo(XMLNode paramXMLNode, Class paramClass) throws DDGenException {
/* 129 */     XMLName xMLName = this.typeMapping.getXMLNameFromClass(paramClass);
/*     */     
/* 131 */     if (xMLName == null) {
/* 132 */       Class clazz = ExceptionUtil.getSingleSimpleProperty(paramClass);
/* 133 */       if (clazz != null) {
/* 134 */         xMLName = this.typeMapping.getXMLNameFromClass(clazz);
/*     */       }
/*     */     } 
/*     */     
/* 138 */     if (xMLName == null) {
/* 139 */       throw new DDGenException("unable to find xml type for exception class:" + paramClass + " in the type mapping specified: " + this.typeMapping);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 144 */     paramXMLNode.addAttribute(new Name("xmlns:typeNS"), xMLName.getNamespaceUri());
/* 145 */     paramXMLNode.addAttribute(new Name("type"), "typeNS:" + xMLName.getLocalName());
/*     */   }
/*     */   
/*     */   private void parsePartTags() throws DDGenException {
/* 149 */     Tag[] arrayOfTag = this.methodDoc.tags("wlws:part");
/*     */     
/* 151 */     for (byte b = 0; b < arrayOfTag.length; b++) {
/* 152 */       Tag tag = arrayOfTag[b];
/*     */       
/* 154 */       this.currentTag = tag;
/*     */       
/* 156 */       StringTokenizer stringTokenizer = new StringTokenizer(tag.text(), " \n\t\r", true);
/*     */ 
/*     */       
/* 159 */       String str = getPartName(stringTokenizer);
/* 160 */       XMLNode xMLNode = getPartNode(str);
/*     */       
/* 162 */       if ("return".equals(str)) {
/* 163 */         parseTag(toString(stringTokenizer), xMLNode, returnAttributes);
/*     */       } else {
/* 165 */         parseTag(toString(stringTokenizer), xMLNode, paramAttributes);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String toString(StringTokenizer paramStringTokenizer) {
/* 171 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 173 */     while (paramStringTokenizer.hasMoreTokens()) {
/* 174 */       stringBuffer.append(paramStringTokenizer.nextToken());
/* 175 */       stringBuffer.append(" ");
/*     */     } 
/*     */     
/* 178 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private XMLNode getPartNode(String paramString) throws DDGenException {
/* 183 */     if ("return".equals(paramString)) {
/* 184 */       XMLNode xMLNode = this.params.getChild("return-param", null);
/*     */       
/* 186 */       if (xMLNode == null) {
/* 187 */         throw new DDGenException("can not specify wlws:part return for void methods");
/*     */       }
/*     */       
/* 190 */       return xMLNode;
/*     */     } 
/*     */ 
/*     */     
/* 194 */     for (Iterator iterator = this.params.getChildren(); iterator.hasNext(); ) {
/* 195 */       XMLNode xMLNode = (XMLNode)iterator.next();
/*     */       
/* 197 */       if (paramString.equals(xMLNode.getAttribute("name", null))) {
/* 198 */         return xMLNode;
/*     */       }
/*     */     } 
/*     */     
/* 202 */     throw new DDGenException("unable to find method parameter named:" + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPartName(StringTokenizer paramStringTokenizer) {
/* 208 */     if (paramStringTokenizer.hasMoreTokens()) {
/* 209 */       return nextNonSpaceToken(paramStringTokenizer);
/*     */     }
/*     */     
/* 212 */     throw new DDGenException("found a wlws:part without name " + paramStringTokenizer);
/*     */   }
/*     */   
/*     */   private void populateParameters() throws DDGenException {
/* 216 */     Parameter[] arrayOfParameter = this.methodDoc.parameters();
/*     */     
/* 218 */     this.params = this.operation.addChild("params");
/*     */     
/* 220 */     for (byte b = 0; b < arrayOfParameter.length; b++) {
/* 221 */       Parameter parameter = arrayOfParameter[b];
/* 222 */       populateParameter(parameter);
/*     */     } 
/*     */     
/* 225 */     populateReturnType(this.methodDoc.returnType());
/*     */   }
/*     */ 
/*     */   
/*     */   private void populateReturnType(Type paramType) throws DDGenException {
/* 230 */     if ("void".equals(paramType.qualifiedTypeName())) {
/*     */       return;
/*     */     }
/*     */     
/* 234 */     XMLNode xMLNode = this.params.addChild("return-param");
/*     */     
/* 236 */     xMLNode.addAttribute(new Name("name"), "result");
/* 237 */     xMLNode.addAttribute(new Name("location"), "body");
/*     */     
/* 239 */     xMLNode.addAttribute(new Name("class-name"), paramType.qualifiedTypeName() + paramType.dimension());
/*     */ 
/*     */     
/* 242 */     setTypeInfo(xMLNode, paramType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateParameter(Parameter paramParameter) throws DDGenException {
/* 248 */     XMLNode xMLNode = this.params.addChild("param");
/*     */     
/* 250 */     xMLNode.addAttribute(new Name("name"), paramParameter.name());
/* 251 */     xMLNode.addAttribute(new Name("location"), "body");
/* 252 */     xMLNode.addAttribute(new Name("style"), "in");
/*     */     
/* 254 */     Type type = paramParameter.type();
/*     */     
/* 256 */     xMLNode.addAttribute(new Name("class-name"), type.qualifiedTypeName() + type.dimension());
/*     */ 
/*     */     
/* 259 */     setTypeInfo(xMLNode, type);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setTypeInfo(XMLNode paramXMLNode, Type paramType) throws DDGenException {
/* 264 */     Class clazz = ClassUtil.loadClass(paramType.qualifiedTypeName() + paramType.dimension());
/*     */ 
/*     */     
/* 267 */     setTypeInfo(paramXMLNode, clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setTypeInfo(XMLNode paramXMLNode, Class paramClass) throws DDGenException {
/* 273 */     if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass)) {
/* 274 */       paramXMLNode.addAttribute(new Name("style"), "inout");
/* 275 */       paramClass = getHolderType(paramClass);
/*     */     } 
/*     */     
/* 278 */     XMLName xMLName = this.typeMapping.getXMLNameFromClass(paramClass);
/*     */     
/* 280 */     if (xMLName == null) {
/* 281 */       throw new DDGenException("unable to find xml type for java class:" + paramClass + " in the type mapping specified: " + this.typeMapping);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 287 */     if (xMLName.getNamespaceUri() == null || xMLName.getNamespaceUri() == "") {
/*     */       
/* 289 */       paramXMLNode.addAttribute(new Name("xmlns"), "");
/* 290 */       paramXMLNode.addAttribute(new Name("type"), xMLName.getLocalName());
/*     */     } else {
/* 292 */       paramXMLNode.addAttribute(new Name("xmlns:typeNS"), xMLName.getNamespaceUri());
/* 293 */       paramXMLNode.addAttribute(new Name("type"), "typeNS:" + xMLName.getLocalName());
/*     */     } 
/*     */   }
/*     */   
/*     */   private Class getHolderType(Class paramClass) {
/*     */     try {
/* 299 */       Field field = paramClass.getField("value");
/* 300 */       return field.getType();
/* 301 */     } catch (NoSuchFieldException noSuchFieldException) {
/* 302 */       throw new IllegalArgumentException(paramClass + " is not a holder class");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkTagNames(String paramString, Tag paramTag) throws DDGenException {
/* 308 */     if (!supportedTags.contains(paramString))
/*     */     {
/* 310 */       throw new DDGenException("Can not use this tag [" + paramTag + "] for method. The javadoc tag " + "should be '" + "wlws:operation" + "' or '" + "wlws:part" + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Tag getOperationTag(Tag[] paramArrayOfTag) throws DDGenException {
/* 318 */     Tag tag = null;
/*     */     
/* 320 */     for (Iterator iterator = getWlwsTags(paramArrayOfTag); iterator.hasNext(); ) {
/* 321 */       Tag tag1 = (Tag)iterator.next();
/*     */       
/* 323 */       String str = trimTagName(tag1.name());
/* 324 */       checkTagNames(str, tag1);
/*     */       
/* 326 */       if ("wlws:operation".equals(str)) {
/*     */         
/* 328 */         if (tag != null)
/*     */         {
/* 330 */           throw new DDGenException("Tag [" + str + "] specified more than once - '" + tag + "' and '" + tag1 + "'");
/*     */         }
/*     */ 
/*     */         
/* 334 */         tag = tag1;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 339 */     return tag;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\MethodTag.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */