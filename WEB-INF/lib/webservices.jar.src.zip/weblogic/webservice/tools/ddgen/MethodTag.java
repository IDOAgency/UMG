package weblogic.webservice.tools.ddgen;

import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.Parameter;
import com.sun.javadoc.Tag;
import com.sun.javadoc.Type;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Iterator;
import java.util.StringTokenizer;
import weblogic.webservice.dd.DDLoader;
import weblogic.webservice.util.ExceptionUtil;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.util.ClassUtil;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;

class MethodTag extends TagBase {
  private MethodDoc methodDoc;
  
  private XMLNode operation;
  
  private XMLNode params;
  
  private TypeMapping typeMapping;
  
  private Tag currentTag;
  
  private static final String[] returnAttributes = addTypeNS(DDLoader.returnAttributes);
  
  private static final String[] paramAttributes = addTypeNS(DDLoader.paramAttributes);
  
  private static HashSet supportedTags = new HashSet();
  
  static  {
    supportedTags.add("wlws:operation");
    supportedTags.add("wlws:part");
    supportedTags.add("wlws:exclude");
  }
  
  private static String[] addTypeNS(String[] paramArrayOfString) {
    String[] arrayOfString = new String[paramArrayOfString.length + 1];
    for (byte b = 0; b < paramArrayOfString.length; b++)
      arrayOfString[b] = paramArrayOfString[b]; 
    arrayOfString[arrayOfString.length - 1] = "xmlns:typeNS";
    return arrayOfString;
  }
  
  public MethodTag(MethodDoc paramMethodDoc, XMLNode paramXMLNode, TypeMapping paramTypeMapping) throws DDGenException {
    this.methodDoc = paramMethodDoc;
    this.operation = paramXMLNode;
    this.typeMapping = paramTypeMapping;
    try {
      parse();
    } catch (DDGenException dDGenException) {
      dDGenException.setMethodDoc(paramMethodDoc);
      dDGenException.setTag(this.currentTag);
      throw dDGenException;
    } 
  }
  
  private void parse() throws DDGenException {
    Tag tag = getOperationTag(this.methodDoc.tags());
    this.currentTag = tag;
    if (tag != null)
      parseTag(tag.text(), this.operation, DDLoader.operationAttributes); 
    populateParameters();
    parsePartTags();
    populateExceptions();
  }
  
  private void populateExceptions() throws DDGenException {
    ClassDoc[] arrayOfClassDoc = this.methodDoc.thrownExceptions();
    for (byte b = 0; b < arrayOfClassDoc.length; b++) {
      ClassDoc classDoc = arrayOfClassDoc[b];
      String str = classDoc.qualifiedName();
      Class clazz = ClassUtil.loadClass(str);
      if (!str.startsWith("java.") && !str.startsWith("javax.") && !str.equals("java.lang.Exception") && !java.rmi.RemoteException.class.isAssignableFrom(clazz) && !RuntimeException.class.isAssignableFrom(clazz)) {
        XMLNode xMLNode = this.params.addChild("fault");
        xMLNode.addAttribute(new Name("name"), classDoc.name());
        xMLNode.addAttribute(new Name("class-name"), str);
        setExceptionTypeInfo(xMLNode, clazz);
      } 
    } 
  }
  
  private void setExceptionTypeInfo(XMLNode paramXMLNode, Class paramClass) throws DDGenException {
    XMLName xMLName = this.typeMapping.getXMLNameFromClass(paramClass);
    if (xMLName == null) {
      Class clazz = ExceptionUtil.getSingleSimpleProperty(paramClass);
      if (clazz != null)
        xMLName = this.typeMapping.getXMLNameFromClass(clazz); 
    } 
    if (xMLName == null)
      throw new DDGenException("unable to find xml type for exception class:" + paramClass + " in the type mapping specified: " + this.typeMapping); 
    paramXMLNode.addAttribute(new Name("xmlns:typeNS"), xMLName.getNamespaceUri());
    paramXMLNode.addAttribute(new Name("type"), "typeNS:" + xMLName.getLocalName());
  }
  
  private void parsePartTags() throws DDGenException {
    Tag[] arrayOfTag = this.methodDoc.tags("wlws:part");
    for (byte b = 0; b < arrayOfTag.length; b++) {
      Tag tag = arrayOfTag[b];
      this.currentTag = tag;
      StringTokenizer stringTokenizer = new StringTokenizer(tag.text(), " \n\t\r", true);
      String str = getPartName(stringTokenizer);
      XMLNode xMLNode = getPartNode(str);
      if ("return".equals(str)) {
        parseTag(toString(stringTokenizer), xMLNode, returnAttributes);
      } else {
        parseTag(toString(stringTokenizer), xMLNode, paramAttributes);
      } 
    } 
  }
  
  private String toString(StringTokenizer paramStringTokenizer) {
    StringBuffer stringBuffer = new StringBuffer();
    while (paramStringTokenizer.hasMoreTokens()) {
      stringBuffer.append(paramStringTokenizer.nextToken());
      stringBuffer.append(" ");
    } 
    return stringBuffer.toString();
  }
  
  private XMLNode getPartNode(String paramString) throws DDGenException {
    if ("return".equals(paramString)) {
      XMLNode xMLNode = this.params.getChild("return-param", null);
      if (xMLNode == null)
        throw new DDGenException("can not specify wlws:part return for void methods"); 
      return xMLNode;
    } 
    for (Iterator iterator = this.params.getChildren(); iterator.hasNext(); ) {
      XMLNode xMLNode = (XMLNode)iterator.next();
      if (paramString.equals(xMLNode.getAttribute("name", null)))
        return xMLNode; 
    } 
    throw new DDGenException("unable to find method parameter named:" + paramString);
  }
  
  private String getPartName(StringTokenizer paramStringTokenizer) {
    if (paramStringTokenizer.hasMoreTokens())
      return nextNonSpaceToken(paramStringTokenizer); 
    throw new DDGenException("found a wlws:part without name " + paramStringTokenizer);
  }
  
  private void populateParameters() throws DDGenException {
    Parameter[] arrayOfParameter = this.methodDoc.parameters();
    this.params = this.operation.addChild("params");
    for (byte b = 0; b < arrayOfParameter.length; b++) {
      Parameter parameter = arrayOfParameter[b];
      populateParameter(parameter);
    } 
    populateReturnType(this.methodDoc.returnType());
  }
  
  private void populateReturnType(Type paramType) throws DDGenException {
    if ("void".equals(paramType.qualifiedTypeName()))
      return; 
    XMLNode xMLNode = this.params.addChild("return-param");
    xMLNode.addAttribute(new Name("name"), "result");
    xMLNode.addAttribute(new Name("location"), "body");
    xMLNode.addAttribute(new Name("class-name"), paramType.qualifiedTypeName() + paramType.dimension());
    setTypeInfo(xMLNode, paramType);
  }
  
  private void populateParameter(Parameter paramParameter) throws DDGenException {
    XMLNode xMLNode = this.params.addChild("param");
    xMLNode.addAttribute(new Name("name"), paramParameter.name());
    xMLNode.addAttribute(new Name("location"), "body");
    xMLNode.addAttribute(new Name("style"), "in");
    Type type = paramParameter.type();
    xMLNode.addAttribute(new Name("class-name"), type.qualifiedTypeName() + type.dimension());
    setTypeInfo(xMLNode, type);
  }
  
  private void setTypeInfo(XMLNode paramXMLNode, Type paramType) throws DDGenException {
    Class clazz = ClassUtil.loadClass(paramType.qualifiedTypeName() + paramType.dimension());
    setTypeInfo(paramXMLNode, clazz);
  }
  
  private void setTypeInfo(XMLNode paramXMLNode, Class paramClass) throws DDGenException {
    if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(paramClass)) {
      paramXMLNode.addAttribute(new Name("style"), "inout");
      paramClass = getHolderType(paramClass);
    } 
    XMLName xMLName = this.typeMapping.getXMLNameFromClass(paramClass);
    if (xMLName == null)
      throw new DDGenException("unable to find xml type for java class:" + paramClass + " in the type mapping specified: " + this.typeMapping); 
    if (xMLName.getNamespaceUri() == null || xMLName.getNamespaceUri() == "") {
      paramXMLNode.addAttribute(new Name("xmlns"), "");
      paramXMLNode.addAttribute(new Name("type"), xMLName.getLocalName());
    } else {
      paramXMLNode.addAttribute(new Name("xmlns:typeNS"), xMLName.getNamespaceUri());
      paramXMLNode.addAttribute(new Name("type"), "typeNS:" + xMLName.getLocalName());
    } 
  }
  
  private Class getHolderType(Class paramClass) {
    try {
      Field field = paramClass.getField("value");
      return field.getType();
    } catch (NoSuchFieldException noSuchFieldException) {
      throw new IllegalArgumentException(paramClass + " is not a holder class");
    } 
  }
  
  private void checkTagNames(String paramString, Tag paramTag) throws DDGenException {
    if (!supportedTags.contains(paramString))
      throw new DDGenException("Can not use this tag [" + paramTag + "] for method. The javadoc tag " + "should be '" + "wlws:operation" + "' or '" + "wlws:part" + "'"); 
  }
  
  private Tag getOperationTag(Tag[] paramArrayOfTag) throws DDGenException {
    Tag tag = null;
    for (Iterator iterator = getWlwsTags(paramArrayOfTag); iterator.hasNext(); ) {
      Tag tag1 = (Tag)iterator.next();
      String str = trimTagName(tag1.name());
      checkTagNames(str, tag1);
      if ("wlws:operation".equals(str)) {
        if (tag != null)
          throw new DDGenException("Tag [" + str + "] specified more than once - '" + tag + "' and '" + tag1 + "'"); 
        tag = tag1;
      } 
    } 
    return tag;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\MethodTag.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */