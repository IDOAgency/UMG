/*     */ package weblogic.webservice.tools.ddgen;
/*     */ 
/*     */ import com.sun.javadoc.ClassDoc;
/*     */ import com.sun.javadoc.MethodDoc;
/*     */ import com.sun.javadoc.Parameter;
/*     */ import com.sun.javadoc.Type;
/*     */ import java.lang.reflect.Field;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.util.ClassUtil;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OperationsGen
/*     */ {
/*     */   private ServiceGen serviceGen;
/*     */   
/*  39 */   OperationsGen(ServiceGen paramServiceGen) { this.serviceGen = paramServiceGen; }
/*     */ 
/*     */   
/*     */   void populateOperations(XMLNode paramXMLNode, ClassDoc paramClassDoc) {
/*  43 */     String str = paramClassDoc.name();
/*  44 */     MethodDoc[] arrayOfMethodDoc = paramClassDoc.methods();
/*     */     
/*  46 */     for (byte b = 0; b < arrayOfMethodDoc.length; b++) {
/*  47 */       MethodDoc methodDoc = arrayOfMethodDoc[b];
/*  48 */       populateOperation(str, paramXMLNode, methodDoc);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateOperation(String paramString, XMLNode paramXMLNode, MethodDoc paramMethodDoc) {
/*  55 */     XMLNode xMLNode1 = paramXMLNode.addChild("operation");
/*     */     
/*  57 */     xMLNode1.addAttribute(new Name("name"), paramMethodDoc.name());
/*  58 */     xMLNode1.addAttribute(new Name("method"), paramMethodDoc.name());
/*  59 */     xMLNode1.addAttribute(new Name("component"), paramString);
/*     */     
/*  61 */     Parameter[] arrayOfParameter = paramMethodDoc.parameters();
/*     */     
/*  63 */     XMLNode xMLNode2 = xMLNode1.addChild("params");
/*     */     
/*  65 */     for (byte b = 0; b < arrayOfParameter.length; b++) {
/*  66 */       Parameter parameter = arrayOfParameter[b];
/*  67 */       populateParameter(xMLNode2, parameter);
/*     */     } 
/*     */     
/*  70 */     populateReturnType(xMLNode2, paramMethodDoc.returnType());
/*     */   }
/*     */ 
/*     */   
/*     */   private void populateReturnType(XMLNode paramXMLNode, Type paramType) {
/*  75 */     if ("void".equals(paramType.qualifiedTypeName())) {
/*     */       return;
/*     */     }
/*     */     
/*  79 */     XMLNode xMLNode = paramXMLNode.addChild("return-param");
/*     */     
/*  81 */     xMLNode.addAttribute(new Name("name"), "result");
/*  82 */     xMLNode.addAttribute(new Name("location"), "body");
/*     */     
/*  84 */     xMLNode.addAttribute(new Name("class-name"), paramType.qualifiedTypeName() + paramType.dimension());
/*     */ 
/*     */     
/*  87 */     setTypeInfo(xMLNode, paramType);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setTypeInfo(XMLNode paramXMLNode, Type paramType) {
/*  92 */     TypeMapping typeMapping = (TypeMapping)this.serviceGen.getTypeMapping();
/*     */     
/*  94 */     Class clazz = ClassUtil.loadClass(paramType.qualifiedTypeName() + paramType.dimension());
/*     */ 
/*     */     
/*  97 */     if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(clazz)) {
/*  98 */       paramXMLNode.addAttribute(new Name("style"), "inout");
/*  99 */       clazz = getHolderType(clazz);
/*     */     } 
/*     */     
/* 102 */     XMLName xMLName = typeMapping.getXMLNameFromClass(clazz);
/*     */     
/* 104 */     if (xMLName == null) {
/* 105 */       System.err.println("WARNING: Can't find XML type from type mapping for java type " + clazz + ". Using default \"xsd:anyType\".");
/*     */       
/* 107 */       paramXMLNode.addAttribute(new Name("type"), "xsd:anyType");
/*     */     } else {
/* 109 */       paramXMLNode.addAttribute(new Name("xmlns:parms"), xMLName.getNamespaceUri());
/* 110 */       paramXMLNode.addAttribute(new Name("type"), "parms:" + xMLName.getLocalName());
/*     */     } 
/*     */   }
/*     */   
/*     */   private Class getHolderType(Class paramClass) {
/*     */     try {
/* 116 */       Field field = paramClass.getField("value");
/* 117 */       return field.getType();
/* 118 */     } catch (NoSuchFieldException noSuchFieldException) {
/* 119 */       throw new IllegalArgumentException(paramClass + " is not a holder class");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void populateParameter(XMLNode paramXMLNode, Parameter paramParameter) {
/* 124 */     XMLNode xMLNode = paramXMLNode.addChild("param");
/*     */     
/* 126 */     xMLNode.addAttribute(new Name("name"), paramParameter.name());
/* 127 */     xMLNode.addAttribute(new Name("location"), "body");
/* 128 */     xMLNode.addAttribute(new Name("style"), "in");
/*     */     
/* 130 */     Type type = paramParameter.type();
/*     */     
/* 132 */     xMLNode.addAttribute(new Name("class-name"), type.qualifiedTypeName() + type.dimension());
/*     */ 
/*     */     
/* 135 */     setTypeInfo(xMLNode, type);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\OperationsGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */