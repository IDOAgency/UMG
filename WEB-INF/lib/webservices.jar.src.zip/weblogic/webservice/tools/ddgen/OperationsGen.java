package weblogic.webservice.tools.ddgen;

import com.sun.javadoc.ClassDoc;
import com.sun.javadoc.MethodDoc;
import com.sun.javadoc.Parameter;
import com.sun.javadoc.Type;
import java.lang.reflect.Field;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.util.ClassUtil;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;

public class OperationsGen {
  private ServiceGen serviceGen;
  
  OperationsGen(ServiceGen paramServiceGen) { this.serviceGen = paramServiceGen; }
  
  void populateOperations(XMLNode paramXMLNode, ClassDoc paramClassDoc) {
    String str = paramClassDoc.name();
    MethodDoc[] arrayOfMethodDoc = paramClassDoc.methods();
    for (byte b = 0; b < arrayOfMethodDoc.length; b++) {
      MethodDoc methodDoc = arrayOfMethodDoc[b];
      populateOperation(str, paramXMLNode, methodDoc);
    } 
  }
  
  private void populateOperation(String paramString, XMLNode paramXMLNode, MethodDoc paramMethodDoc) {
    XMLNode xMLNode1 = paramXMLNode.addChild("operation");
    xMLNode1.addAttribute(new Name("name"), paramMethodDoc.name());
    xMLNode1.addAttribute(new Name("method"), paramMethodDoc.name());
    xMLNode1.addAttribute(new Name("component"), paramString);
    Parameter[] arrayOfParameter = paramMethodDoc.parameters();
    XMLNode xMLNode2 = xMLNode1.addChild("params");
    for (byte b = 0; b < arrayOfParameter.length; b++) {
      Parameter parameter = arrayOfParameter[b];
      populateParameter(xMLNode2, parameter);
    } 
    populateReturnType(xMLNode2, paramMethodDoc.returnType());
  }
  
  private void populateReturnType(XMLNode paramXMLNode, Type paramType) {
    if ("void".equals(paramType.qualifiedTypeName()))
      return; 
    XMLNode xMLNode = paramXMLNode.addChild("return-param");
    xMLNode.addAttribute(new Name("name"), "result");
    xMLNode.addAttribute(new Name("location"), "body");
    xMLNode.addAttribute(new Name("class-name"), paramType.qualifiedTypeName() + paramType.dimension());
    setTypeInfo(xMLNode, paramType);
  }
  
  private void setTypeInfo(XMLNode paramXMLNode, Type paramType) {
    TypeMapping typeMapping = (TypeMapping)this.serviceGen.getTypeMapping();
    Class clazz = ClassUtil.loadClass(paramType.qualifiedTypeName() + paramType.dimension());
    if (javax.xml.rpc.holders.Holder.class.isAssignableFrom(clazz)) {
      paramXMLNode.addAttribute(new Name("style"), "inout");
      clazz = getHolderType(clazz);
    } 
    XMLName xMLName = typeMapping.getXMLNameFromClass(clazz);
    if (xMLName == null) {
      System.err.println("WARNING: Can't find XML type from type mapping for java type " + clazz + ". Using default \"xsd:anyType\".");
      paramXMLNode.addAttribute(new Name("type"), "xsd:anyType");
    } else {
      paramXMLNode.addAttribute(new Name("xmlns:parms"), xMLName.getNamespaceUri());
      paramXMLNode.addAttribute(new Name("type"), "parms:" + xMLName.getLocalName());
    } 
  }
  
  private Class getHolderType(Class paramClass) {
    try {
      Field field = paramClass.getField("value");
      return field.getType();
    } catch (NoSuchFieldException noSuchFieldException) {
      throw new IllegalArgumentException(paramClass + " is not a holder class");
    } 
  }
  
  private void populateParameter(XMLNode paramXMLNode, Parameter paramParameter) {
    XMLNode xMLNode = paramXMLNode.addChild("param");
    xMLNode.addAttribute(new Name("name"), paramParameter.name());
    xMLNode.addAttribute(new Name("location"), "body");
    xMLNode.addAttribute(new Name("style"), "in");
    Type type = paramParameter.type();
    xMLNode.addAttribute(new Name("class-name"), type.qualifiedTypeName() + type.dimension());
    setTypeInfo(xMLNode, type);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ddgen\OperationsGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */