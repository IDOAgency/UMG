/*     */ package weblogic.webservice.tools.wsdl2service;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.tools.build.WSBuildException;
/*     */ import weblogic.webservice.tools.build.internal.WSDL2ServiceHelper;
/*     */ import weblogic.webservice.util.jspgen.GenFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSDL2Service
/*     */ {
/*  23 */   private String targetDir = ".";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   private ServiceBase serviceBase = (ServiceBase)GenFactory.create("weblogic.webservice.tools.wsdl2service.ServiceClass");
/*     */   
/*  34 */   private ServiceBase serviceImpl = (ServiceBase)GenFactory.create("weblogic.webservice.tools.wsdl2service.ServiceImplClass");
/*     */   private File ddFile;
/*     */   private String componentName;
/*     */   
/*     */   public void setPackage(String paramString) {
/*  39 */     this.serviceBase.packageName = paramString;
/*  40 */     this.serviceBase.util.setPackageName(this.serviceBase.packageName);
/*     */     
/*  42 */     this.serviceImpl.packageName = paramString;
/*  43 */     this.serviceImpl.util.setPackageName(this.serviceImpl.packageName);
/*     */   }
/*     */   private boolean keepGenerated; private boolean generateImpl;
/*     */   
/*  47 */   public void setTargetDir(String paramString) { this.targetDir = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  51 */   public void setComponentName(String paramString) { this.componentName = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  55 */   public void setDDFile(File paramFile) { this.ddFile = paramFile; }
/*     */ 
/*     */ 
/*     */   
/*  59 */   public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  63 */   public void setGenerateImpl(boolean paramBoolean) { this.generateImpl = paramBoolean; }
/*     */ 
/*     */   
/*     */   public void visit(WebService paramWebService) throws IOException, WSBuildException {
/*  67 */     this.serviceBase.service = paramWebService;
/*  68 */     Port port = getPort(paramWebService);
/*  69 */     this.serviceBase.port = port;
/*     */     
/*  71 */     this.serviceImpl.service = paramWebService;
/*  72 */     this.serviceImpl.port = port;
/*     */     
/*  74 */     WSDL2ServiceHelper wSDL2ServiceHelper = new WSDL2ServiceHelper(this.targetDir, this.serviceBase.packageName, this.keepGenerated);
/*     */     
/*  76 */     wSDL2ServiceHelper.generateException(paramWebService);
/*  77 */     writeService();
/*  78 */     writeWebServiceXML();
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeWebServiceXML() throws IOException {
/*  83 */     if (this.ddFile == null) {
/*  84 */       this.ddFile = new File(this.targetDir + File.separator + "web-services.xml");
/*     */     }
/*     */     
/*  87 */     new WSDDWriter(this.serviceBase.service, this.ddFile, this.serviceBase.port, this.serviceBase.packageName, this.componentName);
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeService() throws IOException {
/*  92 */     PrintStream printStream = getPrintStream(this.serviceBase.service.getName());
/*  93 */     this.serviceBase.setOutput(printStream);
/*  94 */     this.serviceBase.generate();
/*  95 */     printStream.close();
/*     */     
/*  97 */     if (this.generateImpl) {
/*  98 */       PrintStream printStream1 = getPrintStream(this.serviceImpl.service.getName() + "Impl");
/*  99 */       this.serviceImpl.setOutput(printStream1);
/* 100 */       this.serviceImpl.generate();
/* 101 */       printStream1.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private PrintStream getPrintStream(String paramString) throws IOException {
/* 107 */     File file = new File(this.targetDir + File.separator + this.serviceBase.packageName.replace('.', File.separatorChar) + File.separator + paramString + ".java");
/*     */ 
/*     */ 
/*     */     
/* 111 */     return new PrintStream(new FileOutputStream(file));
/*     */   }
/*     */   
/*     */   private Port getPort(WebService paramWebService) throws IOException {
/* 115 */     Iterator iterator = paramWebService.getPorts();
/*     */     
/* 117 */     if (iterator.hasNext()) {
/* 118 */       return (Port)iterator.next();
/*     */     }
/*     */     
/* 121 */     throw new IOException("port not found");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdl2service\WSDL2Service.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */