package weblogic.webservice.tools.wsdl2service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Iterator;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.tools.build.WSBuildException;
import weblogic.webservice.tools.build.internal.WSDL2ServiceHelper;
import weblogic.webservice.util.jspgen.GenFactory;

public class WSDL2Service {
  private String targetDir = ".";
  
  private ServiceBase serviceBase = (ServiceBase)GenFactory.create("weblogic.webservice.tools.wsdl2service.ServiceClass");
  
  private ServiceBase serviceImpl = (ServiceBase)GenFactory.create("weblogic.webservice.tools.wsdl2service.ServiceImplClass");
  
  private File ddFile;
  
  private String componentName;
  
  private boolean keepGenerated;
  
  private boolean generateImpl;
  
  public void setPackage(String paramString) {
    this.serviceBase.packageName = paramString;
    this.serviceBase.util.setPackageName(this.serviceBase.packageName);
    this.serviceImpl.packageName = paramString;
    this.serviceImpl.util.setPackageName(this.serviceImpl.packageName);
  }
  
  public void setTargetDir(String paramString) { this.targetDir = paramString; }
  
  public void setComponentName(String paramString) { this.componentName = paramString; }
  
  public void setDDFile(File paramFile) { this.ddFile = paramFile; }
  
  public void setKeepGenerated(boolean paramBoolean) { this.keepGenerated = paramBoolean; }
  
  public void setGenerateImpl(boolean paramBoolean) { this.generateImpl = paramBoolean; }
  
  public void visit(WebService paramWebService) throws IOException, WSBuildException {
    this.serviceBase.service = paramWebService;
    Port port = getPort(paramWebService);
    this.serviceBase.port = port;
    this.serviceImpl.service = paramWebService;
    this.serviceImpl.port = port;
    WSDL2ServiceHelper wSDL2ServiceHelper = new WSDL2ServiceHelper(this.targetDir, this.serviceBase.packageName, this.keepGenerated);
    wSDL2ServiceHelper.generateException(paramWebService);
    writeService();
    writeWebServiceXML();
  }
  
  private void writeWebServiceXML() throws IOException {
    if (this.ddFile == null)
      this.ddFile = new File(this.targetDir + File.separator + "web-services.xml"); 
    new WSDDWriter(this.serviceBase.service, this.ddFile, this.serviceBase.port, this.serviceBase.packageName, this.componentName);
  }
  
  private void writeService() throws IOException {
    PrintStream printStream = getPrintStream(this.serviceBase.service.getName());
    this.serviceBase.setOutput(printStream);
    this.serviceBase.generate();
    printStream.close();
    if (this.generateImpl) {
      PrintStream printStream1 = getPrintStream(this.serviceImpl.service.getName() + "Impl");
      this.serviceImpl.setOutput(printStream1);
      this.serviceImpl.generate();
      printStream1.close();
    } 
  }
  
  private PrintStream getPrintStream(String paramString) throws IOException {
    File file = new File(this.targetDir + File.separator + this.serviceBase.packageName.replace('.', File.separatorChar) + File.separator + paramString + ".java");
    return new PrintStream(new FileOutputStream(file));
  }
  
  private Port getPort(WebService paramWebService) throws IOException {
    Iterator iterator = paramWebService.getPorts();
    if (iterator.hasNext())
      return (Port)iterator.next(); 
    throw new IOException("port not found");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdl2service\WSDL2Service.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */