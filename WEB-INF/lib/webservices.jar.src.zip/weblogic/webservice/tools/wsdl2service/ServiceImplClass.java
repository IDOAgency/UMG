package weblogic.webservice.tools.wsdl2service;

import java.util.Iterator;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.Part;
public class ServiceImplClass extends weblogic.webservice.tools.wsdl2service.ServiceBase{
  public void generate() 
   throws weblogic.webservice.util.jspgen.ScriptException{
  out.print( "package " );

 out.print( packageName );  out.print( ";" );
  out.print( "\n" );
  out.print( "\n" );
  out.print( "/**" );
  out.print( "\n" );
  out.print( " * generated from WSDL : todo: (print location of wsdl)" );
  out.print( "\n" );
  out.print( " * @author Copyright (c) 2002 by BEA Systems. All Rights Reserved." );
  out.print( "\n" );
  out.print( " */" );
  out.print( "\n" );
  out.print( "\n" );
  out.print( "public class " );

 out.print( service.getName() );  out.print( "Impl implements " );

 out.print( service.getName() );  out.print( " {" );
  out.print( "\n" );

 for( Iterator it=port.getOperations(); it.hasNext(); ){
     Operation operation = (Operation)it.next(); 

  Iterator parts = operation.getOutput().getParts();
  Class returnType;

  if (operation.getReturnPart()!=null){
    returnType = operation.getReturnPart().getJavaType();
  }else{
    returnType = null;
  }
  out.print( "\n" );
  out.print( "  /**" );
  out.print( "\n" );
  out.print( "   * " );

 out.print( operation.getName() );  out.print( " " );
  out.print( "\n" );
  out.print( "   */" );
  out.print( "\n" );
  out.print( "  public " );

 out.print( util.getJavaTypeName(returnType) );  out.print( " " );

 out.print( operation.getName() );  out.print( "(" );

 out.print( util.getArgStatement(operation)  );  out.print( ")" );
  out.print( "\n" );
  out.print( "    " );

 out.print( util.throwException( operation ) );  out.print( " {" );
  out.print( "\n" );
  out.print( "  }" );

 }   out.print( "\n" );
  out.print( "}" );
  }
}