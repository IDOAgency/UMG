package weblogic.webservice.tools.wsdl2service;

import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.tools.stubgen.StubGenHelper;
import weblogic.webservice.util.jspgen.JspGenBase;

public abstract class ServiceBase extends JspGenBase {
  protected String packageName;
  
  protected WebService service;
  
  protected Port port;
  
  protected StubGenHelper util = new StubGenHelper();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdl2service\ServiceBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */