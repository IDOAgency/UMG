package weblogic.webservice.tools.wsdl2service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.tools.stubgen.StubGenHelper;
import weblogic.webservice.util.ExceptionUtil;
import weblogic.webservice.wsdl.WSDLParseException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.internal.NameUtil;
import weblogic.xml.schema.binding.util.ClassUtil;
import weblogic.xml.stream.XMLName;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.events.Name;
import weblogic.xml.xmlnode.XMLNode;

public class WSDDWriter {
  private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
  
  private WebService service;
  
  private Port port;
  
  private File ddFile;
  
  private XMLNode xwebservices;
  
  private String packageName;
  
  private String componentName;
  
  private StubGenHelper helper;
  
  private static final Name name = new Name("name");
  
  public WSDDWriter(WebService paramWebService, File paramFile, Port paramPort, String paramString1, String paramString2) throws IOException {
    this.helper = new StubGenHelper();
    this.service = paramWebService;
    this.ddFile = paramFile;
    this.port = paramPort;
    this.packageName = paramString1;
    this.componentName = paramString2;
    this.xwebservices = getWebServices();
    if (this.componentName == null)
      this.componentName = paramString1 + "." + paramWebService.getName() + "Impl"; 
    populateWebService();
    writeDDFile();
  }
  
  private void populateWebService() throws IOException {
    String str2;
    XMLNode xMLNode = this.xwebservices.addChild("web-service");
    xMLNode.addAttribute(name, this.service.getName());
    xMLNode.addAttribute(new Name("targetNamespace"), this.service.getTargetNamespace());
    String str1 = this.port.getBindingInfo().getAddress();
    if (str1 != null && str1.startsWith("http")) {
      str2 = str1.substring(str1.lastIndexOf('/'));
    } else {
      str2 = "/" + this.service.getName();
    } 
    xMLNode.addAttribute(new Name("uri"), str2);
    xMLNode.addAttribute(new Name("portTypeName"), this.port.getTypeName());
    xMLNode.addAttribute(new Name("portName"), this.port.getName());
    xMLNode.addAttribute(new Name("style"), this.port.isRpcStyle() ? "rpc" : "document");
    if (this.service.getTypes() != null)
      xMLNode.addChild(this.service.getTypes()); 
    populateTypeMapping(xMLNode);
    populateComponents(xMLNode);
    populateOperations(xMLNode);
  }
  
  private void populateOperations(XMLNode paramXMLNode) throws WSDLParseException {
    XMLNode xMLNode = paramXMLNode.addChild("operations");
    String str = null;
    boolean bool = false;
    for (Iterator iterator = this.port.getOperations(); iterator.hasNext(); ) {
      Operation operation = (Operation)iterator.next();
      if (str == null) {
        bool = operation.isDocumentStyle();
        str = operation.getName();
        this.port.setStyle(bool ? "document" : "rpc");
      } else if (bool != operation.isDocumentStyle()) {
        throw new WSDLParseException("Style of soap:operation \"" + operation.getName() + "\" does not match with \"" + str + "\"");
      } 
      populateOperation(xMLNode, operation);
    } 
  }
  
  private void populateOperation(XMLNode paramXMLNode, Operation paramOperation) {
    XMLNode xMLNode1 = paramXMLNode.addChild("operation");
    xMLNode1.addAttribute(new Name("method"), paramOperation.getName());
    xMLNode1.addAttribute(new Name("component"), this.service.getName());
    XMLNode xMLNode2 = xMLNode1.addChild("params");
    populateParams(xMLNode2, paramOperation);
    if (paramOperation.getReturnPart() != null)
      populateReturn(xMLNode2, paramOperation.getReturnPart()); 
    populateExceptions(xMLNode2, paramOperation);
  }
  
  private void populateExceptions(XMLNode paramXMLNode, Operation paramOperation) {
    TypeMappingRegistry typeMappingRegistry = this.service.getTypeMappingRegistry();
    TypeMapping typeMapping = (TypeMapping)typeMappingRegistry.getDefaultTypeMapping();
    for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
      Message message = (Message)iterator.next();
      String str = getFaultName(message);
      XMLNode xMLNode = paramXMLNode.addChild("fault");
      xMLNode.addAttribute(new Name("name"), message.getName());
      xMLNode.addAttribute(new Name("class-name"), str);
      Class clazz = ClassUtil.loadClass(str);
      if (str.startsWith("java.") || str.startsWith("javax.") || str.equals("java.lang.Exception") || java.rmi.RemoteException.class.isAssignableFrom(clazz) || RuntimeException.class.isAssignableFrom(clazz))
        continue; 
      XMLName xMLName = typeMapping.getXMLNameFromClass(clazz);
      if (xMLName == null) {
        Class clazz1 = ExceptionUtil.getSingleSimpleProperty(clazz);
        if (clazz1 != null)
          xMLName = typeMapping.getXMLNameFromClass(clazz1); 
      } 
      if (xMLName != null) {
        String str1 = xMLName.getPrefix();
        String str2 = xMLName.getQualifiedName();
        if (str1 == null) {
          str1 = "partns";
          str2 = str1 + ":" + str2;
        } 
        String str3 = xMLName.getNamespaceUri();
        xMLNode.addNamespace(str1, str3);
        xMLNode.addAttribute(new Name("xmlns:" + str1), str3);
        xMLNode.addAttribute(new Name("type"), str2);
      } 
    } 
  }
  
  private String getFaultName(Message paramMessage) {
    Part part = (Part)paramMessage.getParts().next();
    String str = null;
    Class clazz = part.getJavaType();
    if (Exception.class.isAssignableFrom(clazz)) {
      str = part.getJavaType().getName();
    } else {
      str = this.packageName + "." + NameUtil.getJAXRPCClassName(paramMessage.getName());
    } 
    return str;
  }
  
  private void populateReturn(XMLNode paramXMLNode, Part paramPart) {
    XMLNode xMLNode = paramXMLNode.addChild("return-param");
    populateParam(xMLNode, paramPart);
  }
  
  private void populateParams(XMLNode paramXMLNode, Operation paramOperation) {
    Iterator iterator = getArgParts(paramOperation);
    while (iterator.hasNext()) {
      Part part = (Part)iterator.next();
      XMLNode xMLNode = paramXMLNode.addChild("param");
      xMLNode.addAttribute(new Name("style"), getStyle(part));
      xMLNode.addAttribute(new Name("location"), getLocation(part));
      populateParam(xMLNode, part);
    } 
  }
  
  private void populateParam(XMLNode paramXMLNode, Part paramPart) {
    paramXMLNode.addAttribute(name, paramPart.getName());
    paramXMLNode.addNamespace("param-prefix", paramPart.getXMLType().getNamespaceURI());
    paramXMLNode.addAttribute(new Name("type"), "param-prefix:" + paramPart.getXMLType().getLocalPart());
    paramXMLNode.addAttribute(new Name("class-name"), this.helper.getJavaTypeName(paramPart.getJavaType()));
  }
  
  public String getLocation(Part paramPart) {
    if (paramPart.isBody())
      return "body"; 
    if (paramPart.isAttachment())
      return "attachment"; 
    return "header";
  }
  
  private String getStyle(Part paramPart) {
    if (paramPart.getMode() == Part.Mode.IN)
      return "in"; 
    if (paramPart.getMode() == Part.Mode.OUT)
      return "out"; 
    if (paramPart.getMode() == Part.Mode.INOUT)
      return "inout"; 
    throw new IllegalArgumentException("unknow part type: " + paramPart);
  }
  
  private Iterator getArgParts(Operation paramOperation) {
    ArrayList arrayList = new ArrayList();
    Iterator iterator;
    for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      arrayList.add(part);
    } 
    for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.OUT)
        arrayList.add(part); 
    } 
    return arrayList.iterator();
  }
  
  private void populateComponents(XMLNode paramXMLNode) throws WSDLParseException {
    XMLNode xMLNode1 = paramXMLNode.addChild("components");
    XMLNode xMLNode2 = xMLNode1.addChild("java-class");
    xMLNode2.addAttribute(name, this.service.getName());
    xMLNode2.addAttribute(new Name("class-name"), this.packageName + "." + this.service.getName() + "Impl");
  }
  
  private void populateTypeMapping(XMLNode paramXMLNode) throws WSDLParseException {
    TypeMappingRegistry typeMappingRegistry = this.service.getTypeMappingRegistry();
    TypeMapping typeMapping = (TypeMapping)typeMappingRegistry.getDefaultTypeMapping();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(byteArrayOutputStream);
    typeMapping.writeXML(xMLOutputStream);
    xMLOutputStream.flush();
    XMLNode xMLNode = new XMLNode();
    xMLNode.read(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
    paramXMLNode.addChild(xMLNode);
  }
  
  private void writeDDFile() throws IOException {
    String str = charset;
    if (str == null)
      str = "UTF-8"; 
    FileOutputStream fileOutputStream = new FileOutputStream(this.ddFile);
    PrintStream printStream = new PrintStream(fileOutputStream, false, str);
    printStream.print("<?xml version=\"1.0\" encoding=\"" + str + "\"?>\n");
    printStream.print(this.xwebservices);
    printStream.close();
    fileOutputStream.close();
  }
  
  private XMLNode getWebServices() throws IOException {
    XMLNode xMLNode = new XMLNode();
    xMLNode.setName("web-services", null, null);
    return xMLNode;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdl2service\WSDDWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */