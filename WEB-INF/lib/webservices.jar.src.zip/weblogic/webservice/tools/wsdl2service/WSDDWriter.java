/*     */ package weblogic.webservice.tools.wsdl2service;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.tools.stubgen.StubGenHelper;
/*     */ import weblogic.webservice.util.ExceptionUtil;
/*     */ import weblogic.webservice.wsdl.WSDLParseException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.internal.NameUtil;
/*     */ import weblogic.xml.schema.binding.util.ClassUtil;
/*     */ import weblogic.xml.stream.XMLName;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.events.Name;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSDDWriter
/*     */ {
/*  42 */   private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
/*     */   
/*     */   private WebService service;
/*     */   
/*     */   private Port port;
/*     */   
/*     */   private File ddFile;
/*     */   private XMLNode xwebservices;
/*     */   private String packageName;
/*     */   private String componentName;
/*     */   private StubGenHelper helper;
/*  53 */   private static final Name name = new Name("name");
/*     */ 
/*     */   
/*     */   public WSDDWriter(WebService paramWebService, File paramFile, Port paramPort, String paramString1, String paramString2) throws IOException {
/*     */     this.helper = new StubGenHelper();
/*  58 */     this.service = paramWebService;
/*  59 */     this.ddFile = paramFile;
/*  60 */     this.port = paramPort;
/*  61 */     this.packageName = paramString1;
/*  62 */     this.componentName = paramString2;
/*     */     
/*  64 */     this.xwebservices = getWebServices();
/*     */     
/*  66 */     if (this.componentName == null) {
/*  67 */       this.componentName = paramString1 + "." + paramWebService.getName() + "Impl";
/*     */     }
/*     */     
/*  70 */     populateWebService();
/*  71 */     writeDDFile();
/*     */   }
/*     */   private void populateWebService() throws IOException {
/*     */     String str2;
/*  75 */     XMLNode xMLNode = this.xwebservices.addChild("web-service");
/*  76 */     xMLNode.addAttribute(name, this.service.getName());
/*     */     
/*  78 */     xMLNode.addAttribute(new Name("targetNamespace"), this.service.getTargetNamespace());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     String str1 = this.port.getBindingInfo().getAddress();
/*     */     
/*  87 */     if (str1 != null && str1.startsWith("http")) {
/*  88 */       str2 = str1.substring(str1.lastIndexOf('/'));
/*     */     } else {
/*  90 */       str2 = "/" + this.service.getName();
/*  91 */     }  xMLNode.addAttribute(new Name("uri"), str2);
/*     */     
/*  93 */     xMLNode.addAttribute(new Name("portTypeName"), this.port.getTypeName());
/*     */ 
/*     */     
/*  96 */     xMLNode.addAttribute(new Name("portName"), this.port.getName());
/*     */ 
/*     */     
/*  99 */     xMLNode.addAttribute(new Name("style"), this.port.isRpcStyle() ? "rpc" : "document");
/*     */ 
/*     */     
/* 102 */     if (this.service.getTypes() != null) {
/* 103 */       xMLNode.addChild(this.service.getTypes());
/*     */     }
/*     */     
/* 106 */     populateTypeMapping(xMLNode);
/* 107 */     populateComponents(xMLNode);
/* 108 */     populateOperations(xMLNode);
/*     */   }
/*     */   
/*     */   private void populateOperations(XMLNode paramXMLNode) throws WSDLParseException {
/* 112 */     XMLNode xMLNode = paramXMLNode.addChild("operations");
/* 113 */     String str = null;
/* 114 */     boolean bool = false;
/* 115 */     for (Iterator iterator = this.port.getOperations(); iterator.hasNext(); ) {
/* 116 */       Operation operation = (Operation)iterator.next();
/* 117 */       if (str == null) {
/* 118 */         bool = operation.isDocumentStyle();
/* 119 */         str = operation.getName();
/*     */         
/* 121 */         this.port.setStyle(bool ? "document" : "rpc");
/* 122 */       } else if (bool != operation.isDocumentStyle()) {
/*     */ 
/*     */         
/* 125 */         throw new WSDLParseException("Style of soap:operation \"" + operation.getName() + "\" does not match with \"" + str + "\"");
/*     */       } 
/*     */       
/* 128 */       populateOperation(xMLNode, operation);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void populateOperation(XMLNode paramXMLNode, Operation paramOperation) {
/* 133 */     XMLNode xMLNode1 = paramXMLNode.addChild("operation");
/* 134 */     xMLNode1.addAttribute(new Name("method"), paramOperation.getName());
/* 135 */     xMLNode1.addAttribute(new Name("component"), this.service.getName());
/* 136 */     XMLNode xMLNode2 = xMLNode1.addChild("params");
/* 137 */     populateParams(xMLNode2, paramOperation);
/*     */     
/* 139 */     if (paramOperation.getReturnPart() != null) {
/* 140 */       populateReturn(xMLNode2, paramOperation.getReturnPart());
/*     */     }
/* 142 */     populateExceptions(xMLNode2, paramOperation);
/*     */   }
/*     */   
/*     */   private void populateExceptions(XMLNode paramXMLNode, Operation paramOperation) {
/* 146 */     TypeMappingRegistry typeMappingRegistry = this.service.getTypeMappingRegistry();
/* 147 */     TypeMapping typeMapping = (TypeMapping)typeMappingRegistry.getDefaultTypeMapping();
/*     */     
/* 149 */     for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
/* 150 */       Message message = (Message)iterator.next();
/*     */       
/* 152 */       String str = getFaultName(message);
/* 153 */       XMLNode xMLNode = paramXMLNode.addChild("fault");
/*     */       
/* 155 */       xMLNode.addAttribute(new Name("name"), message.getName());
/* 156 */       xMLNode.addAttribute(new Name("class-name"), str);
/* 157 */       Class clazz = ClassUtil.loadClass(str);
/*     */       
/* 159 */       if (str.startsWith("java.") || str.startsWith("javax.") || str.equals("java.lang.Exception") || java.rmi.RemoteException.class.isAssignableFrom(clazz) || RuntimeException.class.isAssignableFrom(clazz)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 167 */       XMLName xMLName = typeMapping.getXMLNameFromClass(clazz);
/* 168 */       if (xMLName == null) {
/* 169 */         Class clazz1 = ExceptionUtil.getSingleSimpleProperty(clazz);
/* 170 */         if (clazz1 != null) {
/* 171 */           xMLName = typeMapping.getXMLNameFromClass(clazz1);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       if (xMLName != null) {
/* 183 */         String str1 = xMLName.getPrefix();
/* 184 */         String str2 = xMLName.getQualifiedName();
/* 185 */         if (str1 == null) {
/* 186 */           str1 = "partns";
/* 187 */           str2 = str1 + ":" + str2;
/*     */         } 
/* 189 */         String str3 = xMLName.getNamespaceUri();
/* 190 */         xMLNode.addNamespace(str1, str3);
/* 191 */         xMLNode.addAttribute(new Name("xmlns:" + str1), str3);
/* 192 */         xMLNode.addAttribute(new Name("type"), str2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getFaultName(Message paramMessage) {
/* 198 */     Part part = (Part)paramMessage.getParts().next();
/* 199 */     String str = null;
/* 200 */     Class clazz = part.getJavaType();
/*     */     
/* 202 */     if (Exception.class.isAssignableFrom(clazz)) {
/* 203 */       str = part.getJavaType().getName();
/*     */     } else {
/* 205 */       str = this.packageName + "." + NameUtil.getJAXRPCClassName(paramMessage.getName());
/*     */     } 
/* 207 */     return str;
/*     */   }
/*     */   
/*     */   private void populateReturn(XMLNode paramXMLNode, Part paramPart) {
/* 211 */     XMLNode xMLNode = paramXMLNode.addChild("return-param");
/* 212 */     populateParam(xMLNode, paramPart);
/*     */   }
/*     */   
/*     */   private void populateParams(XMLNode paramXMLNode, Operation paramOperation) {
/* 216 */     Iterator iterator = getArgParts(paramOperation);
/*     */     
/* 218 */     while (iterator.hasNext()) {
/* 219 */       Part part = (Part)iterator.next();
/* 220 */       XMLNode xMLNode = paramXMLNode.addChild("param");
/* 221 */       xMLNode.addAttribute(new Name("style"), getStyle(part));
/* 222 */       xMLNode.addAttribute(new Name("location"), getLocation(part));
/* 223 */       populateParam(xMLNode, part);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void populateParam(XMLNode paramXMLNode, Part paramPart) {
/* 228 */     paramXMLNode.addAttribute(name, paramPart.getName());
/* 229 */     paramXMLNode.addNamespace("param-prefix", paramPart.getXMLType().getNamespaceURI());
/*     */ 
/*     */     
/* 232 */     paramXMLNode.addAttribute(new Name("type"), "param-prefix:" + paramPart.getXMLType().getLocalPart());
/*     */ 
/*     */     
/* 235 */     paramXMLNode.addAttribute(new Name("class-name"), this.helper.getJavaTypeName(paramPart.getJavaType()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation(Part paramPart) {
/* 241 */     if (paramPart.isBody())
/* 242 */       return "body"; 
/* 243 */     if (paramPart.isAttachment()) {
/* 244 */       return "attachment";
/*     */     }
/* 246 */     return "header";
/*     */   }
/*     */ 
/*     */   
/*     */   private String getStyle(Part paramPart) {
/* 251 */     if (paramPart.getMode() == Part.Mode.IN) {
/* 252 */       return "in";
/*     */     }
/*     */     
/* 255 */     if (paramPart.getMode() == Part.Mode.OUT) {
/* 256 */       return "out";
/*     */     }
/*     */     
/* 259 */     if (paramPart.getMode() == Part.Mode.INOUT) {
/* 260 */       return "inout";
/*     */     }
/*     */     
/* 263 */     throw new IllegalArgumentException("unknow part type: " + paramPart);
/*     */   }
/*     */   
/*     */   private Iterator getArgParts(Operation paramOperation) {
/* 267 */     ArrayList arrayList = new ArrayList();
/*     */     Iterator iterator;
/* 269 */     for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 270 */       Part part = (Part)iterator.next();
/* 271 */       arrayList.add(part);
/*     */     } 
/*     */     
/* 274 */     for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/* 275 */       Part part = (Part)iterator.next();
/*     */       
/* 277 */       if (part.getMode() == Part.Mode.OUT) {
/* 278 */         arrayList.add(part);
/*     */       }
/*     */     } 
/*     */     
/* 282 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   private void populateComponents(XMLNode paramXMLNode) throws WSDLParseException {
/* 286 */     XMLNode xMLNode1 = paramXMLNode.addChild("components");
/* 287 */     XMLNode xMLNode2 = xMLNode1.addChild("java-class");
/* 288 */     xMLNode2.addAttribute(name, this.service.getName());
/* 289 */     xMLNode2.addAttribute(new Name("class-name"), this.packageName + "." + this.service.getName() + "Impl");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void populateTypeMapping(XMLNode paramXMLNode) throws WSDLParseException {
/* 295 */     TypeMappingRegistry typeMappingRegistry = this.service.getTypeMappingRegistry();
/* 296 */     TypeMapping typeMapping = (TypeMapping)typeMappingRegistry.getDefaultTypeMapping();
/*     */     
/* 298 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/* 300 */     XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(byteArrayOutputStream);
/*     */ 
/*     */     
/* 303 */     typeMapping.writeXML(xMLOutputStream);
/* 304 */     xMLOutputStream.flush();
/*     */     
/* 306 */     XMLNode xMLNode = new XMLNode();
/* 307 */     xMLNode.read(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()));
/* 308 */     paramXMLNode.addChild(xMLNode);
/*     */   }
/*     */   
/*     */   private void writeDDFile() throws IOException {
/* 312 */     String str = charset;
/* 313 */     if (str == null) str = "UTF-8";
/*     */     
/* 315 */     FileOutputStream fileOutputStream = new FileOutputStream(this.ddFile);
/* 316 */     PrintStream printStream = new PrintStream(fileOutputStream, false, str);
/* 317 */     printStream.print("<?xml version=\"1.0\" encoding=\"" + str + "\"?>\n");
/* 318 */     printStream.print(this.xwebservices);
/* 319 */     printStream.close();
/* 320 */     fileOutputStream.close();
/*     */   }
/*     */   
/*     */   private XMLNode getWebServices() throws IOException {
/* 324 */     XMLNode xMLNode = new XMLNode();
/* 325 */     xMLNode.setName("web-services", null, null);
/* 326 */     return xMLNode;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdl2service\WSDDWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */