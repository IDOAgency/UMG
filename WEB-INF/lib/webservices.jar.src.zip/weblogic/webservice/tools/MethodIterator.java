/*     */ package weblogic.webservice.tools;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import weblogic.utils.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodIterator
/*     */ {
/*     */   Class clazz;
/*     */   private boolean hasNext;
/*     */   private int counter;
/*     */   private int max;
/*     */   private Method[] methods;
/*     */   private HashMap objectMethods;
/*     */   private Set excludes;
/*     */   private static final Set EJB_EXCLUDES;
/*     */   
/*     */   static  {
/*  46 */     new String[7][0] = "void remove()"; new String[7][1] = "javax.ejb.EJBHome getEJBHome()"; new String[7][2] = "javax.ejb.EJBLocalHome getEJBLocalHome()"; new String[7][3] = "java.lang.Object getPrimaryKey()"; new String[7][4] = "javax.ejb.Handle getHandle()"; new String[7][5] = "boolean isIdentical(javax.ejb.EJBObject)"; new String[7][6] = "boolean isIdentical(javax.ejb.EJBLocalObject)"; EJB_EXCLUDES = new HashSet(Arrays.asList((Object[])new String[7]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodIterator(Class paramClass) {
/*     */     this.hasNext = false;
/*     */     this.counter = 0;
/*     */     this.max = 0;
/*     */     this.excludes = new HashSet();
/*  58 */     this.objectMethods = getObjectMethods();
/*  59 */     this.clazz = paramClass;
/*     */     
/*  61 */     if (paramClass == null) {
/*     */       return;
/*     */     }
/*     */     
/*  65 */     this.methods = sortMethods(paramClass.getMethods());
/*  66 */     this.max = this.methods.length; } public MethodIterator(Method[] paramArrayOfMethod) { this.hasNext = false;
/*     */     this.counter = 0;
/*     */     this.max = 0;
/*     */     this.excludes = new HashSet();
/*  70 */     this.objectMethods = getObjectMethods();
/*  71 */     this.methods = sortMethods(paramArrayOfMethod);
/*  72 */     this.max = paramArrayOfMethod.length; }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  76 */     if (this.counter >= this.max) return false; 
/*  77 */     if (isValid(this.methods[this.counter])) return true; 
/*  78 */     while (this.counter < this.max && !isValid(this.methods[this.counter]))
/*  79 */       this.counter++; 
/*  80 */     return (this.counter < this.max);
/*     */   }
/*     */   public Method next() {
/*  83 */     this.counter++;
/*  84 */     return this.methods[this.counter - 1];
/*     */   }
/*     */   public void reset() {
/*  87 */     this.counter = 0;
/*  88 */     if (this.clazz == null)
/*  89 */       this.hasNext = false; 
/*     */   }
/*     */   public void setExcludedMethods(Method[] paramArrayOfMethod) {
/*  92 */     for (byte b = 0; b < paramArrayOfMethod.length; b++) {
/*  93 */       this.excludes.add(getMethodKey(paramArrayOfMethod[b]));
/*     */     }
/*     */   }
/*     */   
/*  97 */   public void setEJBExcludes() { this.excludes.addAll(EJB_EXCLUDES); }
/*     */ 
/*     */   
/* 100 */   public void removeEJBExcludes() { this.excludes.removeAll(EJB_EXCLUDES); }
/*     */   
/* 102 */   public void removeExcludedMethods() { this.excludes.clear(); }
/*     */   
/*     */   private HashMap getObjectMethods() {
/* 105 */     if (this.objectMethods == null) {
/* 106 */       this.objectMethods = new HashMap();
/* 107 */       Method[] arrayOfMethod = Object.class.getMethods();
/* 108 */       for (byte b = 0; b < arrayOfMethod.length; b++) {
/* 109 */         this.objectMethods.put(arrayOfMethod[b], null);
/*     */       }
/*     */     } 
/* 112 */     return this.objectMethods;
/*     */   }
/*     */   
/*     */   private boolean isValid(Method paramMethod) {
/* 116 */     if (paramMethod == null) return false;
/*     */     
/* 118 */     int i = paramMethod.getModifiers();
/* 119 */     if (Modifier.isPrivate(i) || Modifier.isProtected(i) || Modifier.isStatic(i) || this.excludes.contains(getMethodKey(paramMethod)))
/*     */     {
/*     */ 
/*     */       
/* 123 */       return false;
/*     */     }
/* 125 */     if (this.objectMethods.containsKey(paramMethod)) return false; 
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getMethodKey(Method paramMethod) {
/* 133 */     String str1 = paramMethod.getReturnType().getName();
/* 134 */     String str2 = paramMethod.getName();
/* 135 */     Class[] arrayOfClass = paramMethod.getParameterTypes();
/* 136 */     String[] arrayOfString = new String[arrayOfClass.length];
/* 137 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/* 138 */       arrayOfString[b] = arrayOfClass[b].getName();
/*     */     }
/* 140 */     String str3 = StringUtils.join(arrayOfString, ",");
/* 141 */     return str1 + " " + str2 + "(" + str3 + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValid(Class paramClass) {
/* 147 */     if (paramClass == Class.class) {
/* 148 */       return false;
/*     */     }
/* 150 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private Method[] sortMethods(Method[] paramArrayOfMethod) {
/* 155 */     TreeMap treeMap = new TreeMap();
/*     */     
/* 157 */     for (byte b = 0; b < paramArrayOfMethod.length; b++) {
/* 158 */       treeMap.put(getMethodKey(paramArrayOfMethod[b]), paramArrayOfMethod[b]);
/*     */     }
/*     */     
/* 161 */     return (Method[])treeMap.values().toArray(paramArrayOfMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws Exception {
/* 167 */     MethodIterator methodIterator = new MethodIterator(Class.forName(paramArrayOfString[0]));
/* 168 */     while (methodIterator.hasNext())
/* 169 */       System.out.println(methodIterator.next()); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\MethodIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */