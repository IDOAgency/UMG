package weblogic.webservice.tools;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeMap;
import weblogic.utils.StringUtils;

public class MethodIterator {
  Class clazz;
  
  private boolean hasNext;
  
  private int counter;
  
  private int max;
  
  private Method[] methods;
  
  private HashMap objectMethods;
  
  private Set excludes;
  
  private static final Set EJB_EXCLUDES;
  
  static  {
    new String[7][0] = "void remove()";
    new String[7][1] = "javax.ejb.EJBHome getEJBHome()";
    new String[7][2] = "javax.ejb.EJBLocalHome getEJBLocalHome()";
    new String[7][3] = "java.lang.Object getPrimaryKey()";
    new String[7][4] = "javax.ejb.Handle getHandle()";
    new String[7][5] = "boolean isIdentical(javax.ejb.EJBObject)";
    new String[7][6] = "boolean isIdentical(javax.ejb.EJBLocalObject)";
    EJB_EXCLUDES = new HashSet(Arrays.asList((Object[])new String[7]));
  }
  
  public MethodIterator(Class paramClass) {
    this.hasNext = false;
    this.counter = 0;
    this.max = 0;
    this.excludes = new HashSet();
    this.objectMethods = getObjectMethods();
    this.clazz = paramClass;
    if (paramClass == null)
      return; 
    this.methods = sortMethods(paramClass.getMethods());
    this.max = this.methods.length;
  }
  
  public MethodIterator(Method[] paramArrayOfMethod) {
    this.hasNext = false;
    this.counter = 0;
    this.max = 0;
    this.excludes = new HashSet();
    this.objectMethods = getObjectMethods();
    this.methods = sortMethods(paramArrayOfMethod);
    this.max = paramArrayOfMethod.length;
  }
  
  public boolean hasNext() {
    if (this.counter >= this.max)
      return false; 
    if (isValid(this.methods[this.counter]))
      return true; 
    while (this.counter < this.max && !isValid(this.methods[this.counter]))
      this.counter++; 
    return (this.counter < this.max);
  }
  
  public Method next() {
    this.counter++;
    return this.methods[this.counter - 1];
  }
  
  public void reset() {
    this.counter = 0;
    if (this.clazz == null)
      this.hasNext = false; 
  }
  
  public void setExcludedMethods(Method[] paramArrayOfMethod) {
    for (byte b = 0; b < paramArrayOfMethod.length; b++)
      this.excludes.add(getMethodKey(paramArrayOfMethod[b])); 
  }
  
  public void setEJBExcludes() { this.excludes.addAll(EJB_EXCLUDES); }
  
  public void removeEJBExcludes() { this.excludes.removeAll(EJB_EXCLUDES); }
  
  public void removeExcludedMethods() { this.excludes.clear(); }
  
  private HashMap getObjectMethods() {
    if (this.objectMethods == null) {
      this.objectMethods = new HashMap();
      Method[] arrayOfMethod = Object.class.getMethods();
      for (byte b = 0; b < arrayOfMethod.length; b++)
        this.objectMethods.put(arrayOfMethod[b], null); 
    } 
    return this.objectMethods;
  }
  
  private boolean isValid(Method paramMethod) {
    if (paramMethod == null)
      return false; 
    int i = paramMethod.getModifiers();
    if (Modifier.isPrivate(i) || Modifier.isProtected(i) || Modifier.isStatic(i) || this.excludes.contains(getMethodKey(paramMethod)))
      return false; 
    if (this.objectMethods.containsKey(paramMethod))
      return false; 
    return true;
  }
  
  public static String getMethodKey(Method paramMethod) {
    String str1 = paramMethod.getReturnType().getName();
    String str2 = paramMethod.getName();
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    String[] arrayOfString = new String[arrayOfClass.length];
    for (byte b = 0; b < arrayOfClass.length; b++)
      arrayOfString[b] = arrayOfClass[b].getName(); 
    String str3 = StringUtils.join(arrayOfString, ",");
    return str1 + " " + str2 + "(" + str3 + ")";
  }
  
  public static boolean isValid(Class paramClass) {
    if (paramClass == Class.class)
      return false; 
    return true;
  }
  
  private Method[] sortMethods(Method[] paramArrayOfMethod) {
    TreeMap treeMap = new TreeMap();
    for (byte b = 0; b < paramArrayOfMethod.length; b++)
      treeMap.put(getMethodKey(paramArrayOfMethod[b]), paramArrayOfMethod[b]); 
    return (Method[])treeMap.values().toArray(paramArrayOfMethod);
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    MethodIterator methodIterator = new MethodIterator(Class.forName(paramArrayOfString[0]));
    while (methodIterator.hasNext())
      System.out.println(methodIterator.next()); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\MethodIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */