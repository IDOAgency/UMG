package weblogic.webservice.tools;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class ParamIterator {
  Method method;
  
  private boolean hasNext;
  
  private int counter;
  
  private int max;
  
  private Class[] params;
  
  private HashMap objectMethods;
  
  public ParamIterator(Method paramMethod) {
    this.hasNext = false;
    this.counter = 0;
    this.max = 0;
    this.method = paramMethod;
    this.params = paramMethod.getParameterTypes();
    if (paramMethod == null)
      return; 
    this.max = this.params.length;
  }
  
  public boolean hasNext() {
    if (this.counter >= this.max)
      return false; 
    if (MethodIterator.isValid(this.params[this.counter]))
      return true; 
    while (this.counter < this.max && !MethodIterator.isValid(this.params[this.counter]))
      this.counter++; 
    return (this.counter < this.max);
  }
  
  public Class getReturnType() {
    if (MethodIterator.isValid(this.method.getReturnType()))
      return this.method.getReturnType(); 
    return null;
  }
  
  public Set getExceptions() {
    HashSet hashSet = new HashSet();
    Class[] arrayOfClass = this.method.getExceptionTypes();
    for (byte b = 0; b < arrayOfClass.length; b++) {
      if (!RuntimeException.class.isAssignableFrom(arrayOfClass[b]))
        if (!java.rmi.RemoteException.class.isAssignableFrom(arrayOfClass[b]))
          if (!Exception.class.equals(arrayOfClass[b]))
            hashSet.add(arrayOfClass[b]);   
    } 
    return hashSet;
  }
  
  public Class next() {
    this.counter++;
    return this.params[this.counter - 1];
  }
  
  public void reset() {
    this.counter = 0;
    if (this.method == null)
      this.hasNext = false; 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    MethodIterator methodIterator = new MethodIterator(Class.forName(paramArrayOfString[0]));
    while (methodIterator.hasNext()) {
      Method method1 = methodIterator.next();
      System.out.println(method1);
      ParamIterator paramIterator = new ParamIterator(method1);
      if (paramIterator.getReturnType() != null)
        System.out.println(paramIterator.getReturnType()); 
      while (paramIterator.hasNext())
        System.out.println(paramIterator.next()); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ParamIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */