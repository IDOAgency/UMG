/*    */ package weblogic.webservice.tools;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParamIterator
/*    */ {
/*    */   Method method;
/*    */   private boolean hasNext;
/*    */   private int counter;
/*    */   private int max;
/*    */   private Class[] params;
/*    */   private HashMap objectMethods;
/*    */   
/*    */   public ParamIterator(Method paramMethod) {
/* 35 */     this.hasNext = false;
/* 36 */     this.counter = 0;
/* 37 */     this.max = 0;
/*    */ 
/*    */ 
/*    */     
/* 41 */     this.method = paramMethod;
/* 42 */     this.params = paramMethod.getParameterTypes();
/* 43 */     if (paramMethod == null)
/*    */       return; 
/* 45 */     this.max = this.params.length;
/*    */   }
/*    */   public boolean hasNext() {
/* 48 */     if (this.counter >= this.max) return false; 
/* 49 */     if (MethodIterator.isValid(this.params[this.counter])) return true; 
/* 50 */     while (this.counter < this.max && !MethodIterator.isValid(this.params[this.counter]))
/* 51 */       this.counter++; 
/* 52 */     return (this.counter < this.max);
/*    */   }
/*    */   public Class getReturnType() {
/* 55 */     if (MethodIterator.isValid(this.method.getReturnType())) {
/* 56 */       return this.method.getReturnType();
/*    */     }
/* 58 */     return null;
/*    */   }
/*    */   
/*    */   public Set getExceptions() {
/* 62 */     HashSet hashSet = new HashSet();
/* 63 */     Class[] arrayOfClass = this.method.getExceptionTypes();
/*    */     
/* 65 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/* 66 */       if (!RuntimeException.class.isAssignableFrom(arrayOfClass[b]))
/*    */       {
/* 68 */         if (!java.rmi.RemoteException.class.isAssignableFrom(arrayOfClass[b]))
/*    */         {
/* 70 */           if (!Exception.class.equals(arrayOfClass[b]))
/*    */           {
/* 72 */             hashSet.add(arrayOfClass[b]); }  } 
/*    */       }
/*    */     } 
/* 75 */     return hashSet;
/*    */   }
/*    */   
/*    */   public Class next() {
/* 79 */     this.counter++;
/* 80 */     return this.params[this.counter - 1];
/*    */   }
/*    */   public void reset() {
/* 83 */     this.counter = 0;
/* 84 */     if (this.method == null) {
/* 85 */       this.hasNext = false;
/*    */     }
/*    */   }
/*    */   
/*    */   public static void main(String[] paramArrayOfString) throws Exception {
/* 90 */     MethodIterator methodIterator = new MethodIterator(Class.forName(paramArrayOfString[0]));
/* 91 */     while (methodIterator.hasNext()) {
/* 92 */       Method method1 = methodIterator.next();
/* 93 */       System.out.println(method1);
/* 94 */       ParamIterator paramIterator = new ParamIterator(method1);
/* 95 */       if (paramIterator.getReturnType() != null)
/* 96 */         System.out.println(paramIterator.getReturnType()); 
/* 97 */       while (paramIterator.hasNext())
/* 98 */         System.out.println(paramIterator.next()); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ParamIterator.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */