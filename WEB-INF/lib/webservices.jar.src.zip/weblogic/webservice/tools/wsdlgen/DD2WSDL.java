/*    */ package weblogic.webservice.tools.wsdlgen;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Map;
/*    */ import weblogic.management.descriptors.webservice.WebServicesMBeanImpl;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.dd.DDLoader;
/*    */ import weblogic.webservice.server.WebServiceFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DD2WSDL
/*    */ {
/*    */   public static void usage() {
/* 17 */     System.out.println("DD2WSDL [deployment-descriptor-file] [wsdl-file]");
/* 18 */     System.exit(0);
/*    */   }
/*    */   
/*    */   public static void main(String[] paramArrayOfString) throws Exception {
/* 22 */     if (paramArrayOfString.length != 2) usage(); 
/* 23 */     DDLoader dDLoader = new DDLoader();
/* 24 */     FileInputStream fileInputStream = new FileInputStream(paramArrayOfString[0]);
/* 25 */     WebServicesMBeanImpl webServicesMBeanImpl = (WebServicesMBeanImpl)dDLoader.load(fileInputStream);
/*    */     
/* 27 */     WebService webService = WebServiceFactory.newFactoryInstance().createFromMBean(webServicesMBeanImpl.getWebServices()[0], (Map)null);
/* 28 */     WSDLGen wSDLGen = new WSDLGen(new PrintStream(new FileOutputStream(paramArrayOfString[1])));
/*    */ 
/*    */     
/* 31 */     wSDLGen.visit(webService);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\DD2WSDL.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */