/*     */ package weblogic.webservice.tools.wsdlgen;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindingOperationWriter
/*     */   implements WSDLConstants
/*     */ {
/*  19 */   private static Util util = new Util();
/*     */   
/*     */   public void write(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
/*  22 */     XMLNode xMLNode1 = paramXMLNode.addChild("operation", null, "http://schemas.xmlsoap.org/wsdl/");
/*     */ 
/*     */     
/*  25 */     xMLNode1.addAttribute("name", null, null, paramOperation.getName());
/*     */     
/*  27 */     XMLNode xMLNode2 = paramBoolean ? xMLNode1.addChild("operation", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/") : xMLNode1.addChild("operation", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*     */ 
/*     */ 
/*     */     
/*  31 */     xMLNode2.addAttribute("soapAction", null, null, util.cleanSoapAction(paramOperation.getSoapAction()));
/*     */ 
/*     */     
/*  34 */     xMLNode2.addAttribute("style", null, null, paramOperation.isRpcStyle() ? "rpc" : "document");
/*     */ 
/*     */     
/*  37 */     writeReliabilityExtension(xMLNode1, paramOperation);
/*  38 */     writeConOpExtension(xMLNode1, paramOperation);
/*     */     
/*  40 */     writeInput(xMLNode1, paramOperation, paramBoolean);
/*  41 */     if (!paramOperation.isOneway())
/*  42 */       writeOutput(xMLNode1, paramOperation, paramBoolean); 
/*  43 */     writeFault(xMLNode1, paramOperation, paramBoolean);
/*     */   }
/*     */   
/*     */   private void writeReliabilityExtension(XMLNode paramXMLNode, Operation paramOperation) {
/*  47 */     if (paramOperation.getPersistDurationTime() != -1) {
/*  48 */       int i = paramOperation.getPersistDurationTime();
/*  49 */       XMLNode xMLNode = paramXMLNode.addChild("reliability", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/*     */ 
/*     */       
/*  52 */       xMLNode.addAttribute("persistDuration", null, null, String.valueOf(i));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeConOpExtension(XMLNode paramXMLNode, Operation paramOperation) {
/*  58 */     if (paramOperation.getConversationPhase() != null) {
/*  59 */       String str = paramOperation.getConversationPhase();
/*  60 */       if ("CONTINUE".equals(str)) {
/*  61 */         XMLNode xMLNode = paramXMLNode.addChild("transition", "conv", "http://www.openuri.org/2002/04/wsdl/conversation/");
/*  62 */         xMLNode.addAttribute("phase", null, null, "continue");
/*  63 */       } else if ("START".equals(str)) {
/*  64 */         XMLNode xMLNode = paramXMLNode.addChild("transition", "conv", "http://www.openuri.org/2002/04/wsdl/conversation/");
/*  65 */         xMLNode.addAttribute("phase", null, null, "start");
/*  66 */       } else if ("FINISH".equals(str)) {
/*  67 */         XMLNode xMLNode = paramXMLNode.addChild("transition", "conv", "http://www.openuri.org/2002/04/wsdl/conversation/");
/*  68 */         xMLNode.addAttribute("phase", null, null, "finish");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeFault(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
/*  76 */     for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
/*  77 */       Message message = (Message)iterator.next();
/*     */       
/*  79 */       XMLNode xMLNode1 = paramXMLNode.addChild("fault", null, "http://schemas.xmlsoap.org/wsdl/");
/*  80 */       xMLNode1.addAttribute("name", null, null, message.getName());
/*     */       
/*  82 */       XMLNode xMLNode2 = paramBoolean ? xMLNode1.addChild("fault", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/") : xMLNode1.addChild("fault", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*     */ 
/*     */ 
/*     */       
/*  86 */       xMLNode2.addAttribute("name", null, null, message.getName());
/*     */       
/*  88 */       xMLNode2.addAttribute("use", null, null, paramOperation.isRpcStyle() ? "encoded" : "literal");
/*     */ 
/*     */       
/*  91 */       if (message.getNamespace() != null) {
/*  92 */         xMLNode2.addAttribute("namespace", null, null, message.getNamespace());
/*     */       }
/*     */       
/*  95 */       if (paramOperation.isRpcStyle()) {
/*  96 */         xMLNode2.addAttribute("encodingStyle", null, null, paramBoolean ? "http://www.w3.org/2003/05/soap-encoding" : "http://schemas.xmlsoap.org/soap/encoding/");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeInput(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
/* 105 */     XMLNode xMLNode = paramXMLNode.addChild("input", null, "http://schemas.xmlsoap.org/wsdl/");
/* 106 */     Message message = paramOperation.getInput();
/*     */     
/* 108 */     if (util.isMimeMessage(message)) {
/* 109 */       writeMimeParts(xMLNode, message, paramOperation.isRpcStyle(), paramBoolean);
/*     */     } else {
/* 111 */       writeSecRefExtension(xMLNode, message);
/* 112 */       writeConMsgExtension(xMLNode, paramOperation, paramBoolean);
/* 113 */       writeParts(xMLNode, message, paramOperation.isRpcStyle(), paramBoolean);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeOutput(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
/* 120 */     XMLNode xMLNode = paramXMLNode.addChild("output", null, "http://schemas.xmlsoap.org/wsdl/");
/* 121 */     Message message = paramOperation.getOutput();
/*     */     
/* 123 */     if (util.isMimeMessage(message)) {
/* 124 */       writeMimeParts(xMLNode, message, paramOperation.isRpcStyle(), paramBoolean);
/*     */     } else {
/* 126 */       writeSecRefExtension(xMLNode, message);
/* 127 */       writeParts(xMLNode, message, paramOperation.isRpcStyle(), paramBoolean);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeSecRefExtension(XMLNode paramXMLNode, Message paramMessage) {
/* 132 */     if (paramMessage.getSecuritySpecRef() == null)
/*     */       return; 
/* 134 */     XMLNode xMLNode = paramXMLNode.addChild("SecuritySpecRef", "spec", "http://www.openuri.org/2002/11/wsse/spec");
/*     */ 
/*     */     
/* 137 */     xMLNode.addNamespace("spec", "http://www.openuri.org/2002/11/wsse/spec");
/* 138 */     xMLNode.addAttribute("RefId", null, null, paramMessage.getSecuritySpecRef());
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeConMsgExtension(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
/* 143 */     String str = paramOperation.getConversationPhase();
/*     */     
/* 145 */     if ("CONTINUE".equals(str) || "FINISH".equals(str)) {
/*     */       
/* 147 */       XMLNode xMLNode = null;
/* 148 */       if (paramBoolean) {
/* 149 */         xMLNode = paramXMLNode.addChild("header", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
/*     */       } else {
/* 151 */         xMLNode = paramXMLNode.addChild("header", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*     */       } 
/* 153 */       xMLNode.addNamespace("wsdl", "http://schemas.xmlsoap.org/wsdl/");
/* 154 */       xMLNode.addAttribute("required", "wsdl", null, "true");
/* 155 */       xMLNode.addAttribute("message", null, null, "tns:ContinueHeader_" + (paramOperation.isRpcStyle() ? "rpc" : "literal"));
/*     */       
/* 157 */       xMLNode.addAttribute("part", null, null, "ContinueHeader");
/* 158 */       xMLNode.addAttribute("use", null, null, paramOperation.isRpcStyle() ? "encoded" : "literal");
/* 159 */     } else if ("START".equals(str)) {
/* 160 */       XMLNode xMLNode = null;
/* 161 */       if (paramBoolean) {
/* 162 */         xMLNode = paramXMLNode.addChild("header", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
/*     */       } else {
/* 164 */         xMLNode = paramXMLNode.addChild("header", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*     */       } 
/* 166 */       xMLNode.addNamespace("wsdl", "http://schemas.xmlsoap.org/wsdl/");
/* 167 */       xMLNode.addAttribute("required", "wsdl", null, "true");
/* 168 */       xMLNode.addAttribute("message", null, null, "tns:StartHeader_" + (paramOperation.isRpcStyle() ? "rpc" : "literal"));
/*     */       
/* 170 */       xMLNode.addAttribute("part", null, null, "StartHeader");
/* 171 */       xMLNode.addAttribute("use", null, null, paramOperation.isRpcStyle() ? "encoded" : "literal");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeMimeParts(XMLNode paramXMLNode, Message paramMessage, boolean paramBoolean1, boolean paramBoolean2) {
/* 178 */     XMLNode xMLNode1 = paramXMLNode.addChild("multipartRelated", "mime", "http://schemas.xmlsoap.org/wsdl/mime/");
/*     */ 
/*     */     
/* 181 */     XMLNode xMLNode2 = xMLNode1.addChild("part", "mime", "http://schemas.xmlsoap.org/wsdl/mime/");
/* 182 */     writeParts(xMLNode2, paramMessage, paramBoolean1, paramBoolean2);
/*     */     
/* 184 */     Iterator iterator = util.getMimeParts(paramMessage);
/* 185 */     while (iterator.hasNext()) {
/*     */       
/* 187 */       Part part = (Part)iterator.next();
/* 188 */       XMLNode xMLNode = xMLNode1.addChild("part", "mime", "http://schemas.xmlsoap.org/wsdl/mime/");
/*     */       
/* 190 */       String[] arrayOfString = part.getContentType();
/*     */       
/* 192 */       if (arrayOfString == null || arrayOfString.length == 0) {
/* 193 */         arrayOfString = new String[] { "text/plain" };
/*     */       }
/*     */       
/* 196 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 197 */         XMLNode xMLNode3 = xMLNode.addChild("content", "mime", "http://schemas.xmlsoap.org/wsdl/mime/");
/* 198 */         xMLNode3.addAttribute("part", null, null, part.getName());
/* 199 */         xMLNode3.addAttribute("type", null, null, arrayOfString[b]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeParts(XMLNode paramXMLNode, Message paramMessage, boolean paramBoolean1, boolean paramBoolean2) {
/* 207 */     XMLNode xMLNode = paramBoolean2 ? paramXMLNode.addChild("body", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/") : paramXMLNode.addChild("body", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*     */ 
/*     */ 
/*     */     
/* 211 */     xMLNode.addAttribute("use", null, null, paramBoolean1 ? "encoded" : "literal");
/*     */     
/* 213 */     if (paramMessage.getNamespace() != null) {
/* 214 */       xMLNode.addAttribute("namespace", null, null, paramMessage.getNamespace());
/*     */     }
/*     */     
/* 217 */     if (paramBoolean1) {
/* 218 */       xMLNode.addAttribute("encodingStyle", null, null, paramBoolean2 ? "http://www.w3.org/2003/05/soap-encoding" : "http://schemas.xmlsoap.org/soap/encoding/");
/*     */     }
/*     */ 
/*     */     
/* 222 */     Part[] arrayOfPart = Util.getHeaderParts(paramMessage);
/* 223 */     for (byte b = 0; b < arrayOfPart.length; b++) {
/* 224 */       Part part = arrayOfPart[b];
/*     */       
/* 226 */       XMLNode xMLNode1 = paramBoolean2 ? paramXMLNode.addChild("header", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/") : paramXMLNode.addChild("header", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*     */ 
/*     */ 
/*     */       
/* 230 */       xMLNode1.addAttribute("use", null, null, paramBoolean1 ? "encoded" : "literal");
/*     */ 
/*     */       
/* 233 */       xMLNode1.addAttribute("namespace", null, null, paramMessage.getNamespace());
/*     */ 
/*     */       
/* 236 */       if (paramBoolean1) {
/* 237 */         xMLNode1.addAttribute("encodingStyle", null, null, paramBoolean2 ? "http://www.w3.org/2003/05/soap-encoding" : "http://schemas.xmlsoap.org/soap/encoding/");
/*     */       }
/*     */ 
/*     */       
/* 241 */       xMLNode1.addAttribute("message", null, null, "tns:" + paramMessage.getName() + "Header");
/*     */ 
/*     */       
/* 244 */       xMLNode1.addAttribute("part", null, null, part.getName());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\BindingOperationWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */