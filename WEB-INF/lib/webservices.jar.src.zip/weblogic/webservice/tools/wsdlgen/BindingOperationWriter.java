package weblogic.webservice.tools.wsdlgen;

import java.util.Iterator;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.xml.xmlnode.XMLNode;

public class BindingOperationWriter implements WSDLConstants {
  private static Util util = new Util();
  
  public void write(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
    XMLNode xMLNode1 = paramXMLNode.addChild("operation", null, "http://schemas.xmlsoap.org/wsdl/");
    xMLNode1.addAttribute("name", null, null, paramOperation.getName());
    XMLNode xMLNode2 = paramBoolean ? xMLNode1.addChild("operation", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/") : xMLNode1.addChild("operation", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
    xMLNode2.addAttribute("soapAction", null, null, util.cleanSoapAction(paramOperation.getSoapAction()));
    xMLNode2.addAttribute("style", null, null, paramOperation.isRpcStyle() ? "rpc" : "document");
    writeReliabilityExtension(xMLNode1, paramOperation);
    writeConOpExtension(xMLNode1, paramOperation);
    writeInput(xMLNode1, paramOperation, paramBoolean);
    if (!paramOperation.isOneway())
      writeOutput(xMLNode1, paramOperation, paramBoolean); 
    writeFault(xMLNode1, paramOperation, paramBoolean);
  }
  
  private void writeReliabilityExtension(XMLNode paramXMLNode, Operation paramOperation) {
    if (paramOperation.getPersistDurationTime() != -1) {
      int i = paramOperation.getPersistDurationTime();
      XMLNode xMLNode = paramXMLNode.addChild("reliability", "wsr", "http://www.openuri.org/2002/10/soap/reliability/");
      xMLNode.addAttribute("persistDuration", null, null, String.valueOf(i));
    } 
  }
  
  private void writeConOpExtension(XMLNode paramXMLNode, Operation paramOperation) {
    if (paramOperation.getConversationPhase() != null) {
      String str = paramOperation.getConversationPhase();
      if ("CONTINUE".equals(str)) {
        XMLNode xMLNode = paramXMLNode.addChild("transition", "conv", "http://www.openuri.org/2002/04/wsdl/conversation/");
        xMLNode.addAttribute("phase", null, null, "continue");
      } else if ("START".equals(str)) {
        XMLNode xMLNode = paramXMLNode.addChild("transition", "conv", "http://www.openuri.org/2002/04/wsdl/conversation/");
        xMLNode.addAttribute("phase", null, null, "start");
      } else if ("FINISH".equals(str)) {
        XMLNode xMLNode = paramXMLNode.addChild("transition", "conv", "http://www.openuri.org/2002/04/wsdl/conversation/");
        xMLNode.addAttribute("phase", null, null, "finish");
      } 
    } 
  }
  
  private void writeFault(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
    for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
      Message message = (Message)iterator.next();
      XMLNode xMLNode1 = paramXMLNode.addChild("fault", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode1.addAttribute("name", null, null, message.getName());
      XMLNode xMLNode2 = paramBoolean ? xMLNode1.addChild("fault", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/") : xMLNode1.addChild("fault", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
      xMLNode2.addAttribute("name", null, null, message.getName());
      xMLNode2.addAttribute("use", null, null, paramOperation.isRpcStyle() ? "encoded" : "literal");
      if (message.getNamespace() != null)
        xMLNode2.addAttribute("namespace", null, null, message.getNamespace()); 
      if (paramOperation.isRpcStyle())
        xMLNode2.addAttribute("encodingStyle", null, null, paramBoolean ? "http://www.w3.org/2003/05/soap-encoding" : "http://schemas.xmlsoap.org/soap/encoding/"); 
    } 
  }
  
  private void writeInput(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
    XMLNode xMLNode = paramXMLNode.addChild("input", null, "http://schemas.xmlsoap.org/wsdl/");
    Message message = paramOperation.getInput();
    if (util.isMimeMessage(message)) {
      writeMimeParts(xMLNode, message, paramOperation.isRpcStyle(), paramBoolean);
    } else {
      writeSecRefExtension(xMLNode, message);
      writeConMsgExtension(xMLNode, paramOperation, paramBoolean);
      writeParts(xMLNode, message, paramOperation.isRpcStyle(), paramBoolean);
    } 
  }
  
  private void writeOutput(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
    XMLNode xMLNode = paramXMLNode.addChild("output", null, "http://schemas.xmlsoap.org/wsdl/");
    Message message = paramOperation.getOutput();
    if (util.isMimeMessage(message)) {
      writeMimeParts(xMLNode, message, paramOperation.isRpcStyle(), paramBoolean);
    } else {
      writeSecRefExtension(xMLNode, message);
      writeParts(xMLNode, message, paramOperation.isRpcStyle(), paramBoolean);
    } 
  }
  
  private void writeSecRefExtension(XMLNode paramXMLNode, Message paramMessage) {
    if (paramMessage.getSecuritySpecRef() == null)
      return; 
    XMLNode xMLNode = paramXMLNode.addChild("SecuritySpecRef", "spec", "http://www.openuri.org/2002/11/wsse/spec");
    xMLNode.addNamespace("spec", "http://www.openuri.org/2002/11/wsse/spec");
    xMLNode.addAttribute("RefId", null, null, paramMessage.getSecuritySpecRef());
  }
  
  private void writeConMsgExtension(XMLNode paramXMLNode, Operation paramOperation, boolean paramBoolean) {
    String str = paramOperation.getConversationPhase();
    if ("CONTINUE".equals(str) || "FINISH".equals(str)) {
      XMLNode xMLNode = null;
      if (paramBoolean) {
        xMLNode = paramXMLNode.addChild("header", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
      } else {
        xMLNode = paramXMLNode.addChild("header", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
      } 
      xMLNode.addNamespace("wsdl", "http://schemas.xmlsoap.org/wsdl/");
      xMLNode.addAttribute("required", "wsdl", null, "true");
      xMLNode.addAttribute("message", null, null, "tns:ContinueHeader_" + (paramOperation.isRpcStyle() ? "rpc" : "literal"));
      xMLNode.addAttribute("part", null, null, "ContinueHeader");
      xMLNode.addAttribute("use", null, null, paramOperation.isRpcStyle() ? "encoded" : "literal");
    } else if ("START".equals(str)) {
      XMLNode xMLNode = null;
      if (paramBoolean) {
        xMLNode = paramXMLNode.addChild("header", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
      } else {
        xMLNode = paramXMLNode.addChild("header", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
      } 
      xMLNode.addNamespace("wsdl", "http://schemas.xmlsoap.org/wsdl/");
      xMLNode.addAttribute("required", "wsdl", null, "true");
      xMLNode.addAttribute("message", null, null, "tns:StartHeader_" + (paramOperation.isRpcStyle() ? "rpc" : "literal"));
      xMLNode.addAttribute("part", null, null, "StartHeader");
      xMLNode.addAttribute("use", null, null, paramOperation.isRpcStyle() ? "encoded" : "literal");
    } 
  }
  
  private void writeMimeParts(XMLNode paramXMLNode, Message paramMessage, boolean paramBoolean1, boolean paramBoolean2) {
    XMLNode xMLNode1 = paramXMLNode.addChild("multipartRelated", "mime", "http://schemas.xmlsoap.org/wsdl/mime/");
    XMLNode xMLNode2 = xMLNode1.addChild("part", "mime", "http://schemas.xmlsoap.org/wsdl/mime/");
    writeParts(xMLNode2, paramMessage, paramBoolean1, paramBoolean2);
    Iterator iterator = util.getMimeParts(paramMessage);
    while (iterator.hasNext()) {
      Part part = (Part)iterator.next();
      XMLNode xMLNode = xMLNode1.addChild("part", "mime", "http://schemas.xmlsoap.org/wsdl/mime/");
      String[] arrayOfString = part.getContentType();
      if (arrayOfString == null || arrayOfString.length == 0)
        arrayOfString = new String[] { "text/plain" }; 
      for (byte b = 0; b < arrayOfString.length; b++) {
        XMLNode xMLNode3 = xMLNode.addChild("content", "mime", "http://schemas.xmlsoap.org/wsdl/mime/");
        xMLNode3.addAttribute("part", null, null, part.getName());
        xMLNode3.addAttribute("type", null, null, arrayOfString[b]);
      } 
    } 
  }
  
  private void writeParts(XMLNode paramXMLNode, Message paramMessage, boolean paramBoolean1, boolean paramBoolean2) {
    XMLNode xMLNode = paramBoolean2 ? paramXMLNode.addChild("body", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/") : paramXMLNode.addChild("body", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
    xMLNode.addAttribute("use", null, null, paramBoolean1 ? "encoded" : "literal");
    if (paramMessage.getNamespace() != null)
      xMLNode.addAttribute("namespace", null, null, paramMessage.getNamespace()); 
    if (paramBoolean1)
      xMLNode.addAttribute("encodingStyle", null, null, paramBoolean2 ? "http://www.w3.org/2003/05/soap-encoding" : "http://schemas.xmlsoap.org/soap/encoding/"); 
    Part[] arrayOfPart = Util.getHeaderParts(paramMessage);
    for (byte b = 0; b < arrayOfPart.length; b++) {
      Part part = arrayOfPart[b];
      XMLNode xMLNode1 = paramBoolean2 ? paramXMLNode.addChild("header", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/") : paramXMLNode.addChild("header", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
      xMLNode1.addAttribute("use", null, null, paramBoolean1 ? "encoded" : "literal");
      xMLNode1.addAttribute("namespace", null, null, paramMessage.getNamespace());
      if (paramBoolean1)
        xMLNode1.addAttribute("encodingStyle", null, null, paramBoolean2 ? "http://www.w3.org/2003/05/soap-encoding" : "http://schemas.xmlsoap.org/soap/encoding/"); 
      xMLNode1.addAttribute("message", null, null, "tns:" + paramMessage.getName() + "Header");
      xMLNode1.addAttribute("part", null, null, part.getName());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\BindingOperationWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */