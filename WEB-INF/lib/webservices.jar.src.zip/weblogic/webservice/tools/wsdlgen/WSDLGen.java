/*    */ package weblogic.webservice.tools.wsdlgen;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.Operation;
/*    */ import weblogic.webservice.Port;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSDLGen
/*    */ {
/*    */   private OutputStream out;
/*    */   private String location;
/* 26 */   private static final String charset = System.getProperty("weblogic.webservice.i18n.charset");
/*    */ 
/*    */ 
/*    */   
/* 30 */   public WSDLGen(PrintStream paramPrintStream) throws IOException { this.out = paramPrintStream; }
/*    */ 
/*    */ 
/*    */   
/* 34 */   public void visit(WebService paramWebService) throws IOException { writeWSDL(this.location, paramWebService, this.out); }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public void setDefaultEndpoint(String paramString) { this.location = paramString; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeWSDL(String paramString, WebService paramWebService, OutputStream paramOutputStream) throws IOException {
/* 44 */     DefinitionWriter definitionWriter = new DefinitionWriter();
/* 45 */     XMLNode xMLNode = definitionWriter.getWSDL(paramString, paramWebService);
/*    */     
/* 47 */     if (charset == null) {
/* 48 */       paramOutputStream.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".getBytes());
/* 49 */       paramOutputStream.write(xMLNode.toString().getBytes("UTF-8"));
/*    */     } else {
/* 51 */       paramOutputStream.write(("<?xml version=\"1.0\" encoding=\"" + charset + "\"?>\n").getBytes(charset));
/*    */ 
/*    */       
/* 54 */       paramOutputStream.write(xMLNode.toString().getBytes(charset));
/*    */     } 
/*    */   }
/*    */   
/*    */   private Port[] getPorts(WebService paramWebService) {
/* 59 */     ArrayList arrayList = new ArrayList();
/*    */     
/* 61 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext();) {
/* 62 */       arrayList.add(iterator.next());
/*    */     }
/*    */     
/* 65 */     return (Port[])arrayList.toArray(new Port[arrayList.size()]);
/*    */   }
/*    */ 
/*    */   
/*    */   private Operation[] getOperations(WebService paramWebService) {
/* 70 */     ArrayList arrayList = new ArrayList();
/*    */     
/* 72 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 73 */       Port port = (Port)iterator.next();
/*    */       
/* 75 */       for (Iterator iterator1 = port.getOperations(); iterator1.hasNext();) {
/* 76 */         arrayList.add(iterator1.next());
/*    */       }
/*    */     } 
/*    */     
/* 80 */     return (Operation[])arrayList.toArray(new Operation[arrayList.size()]);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\WSDLGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */