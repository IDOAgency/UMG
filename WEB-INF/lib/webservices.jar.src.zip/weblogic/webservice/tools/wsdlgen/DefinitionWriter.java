/*     */ package weblogic.webservice.tools.wsdlgen;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import weblogic.utils.AssertionError;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceFactory;
/*     */ import weblogic.webservice.binding.BindingInfo;
/*     */ import weblogic.webservice.binding.jms.JMSBindingInfo;
/*     */ import weblogic.xml.security.specs.SecurityDD;
/*     */ import weblogic.xml.security.specs.SecuritySpec;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefinitionWriter
/*     */   implements WSDLConstants
/*     */ {
/*  31 */   Util util = new Util();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLNode getWSDL(String paramString, WebService paramWebService) throws IOException {
/*  37 */     XMLNode xMLNode = new XMLNode();
/*     */     
/*  39 */     xMLNode.setName("definitions", null, "http://schemas.xmlsoap.org/wsdl/");
/*  40 */     xMLNode.addNamespace("", "http://schemas.xmlsoap.org/wsdl/");
/*  41 */     xMLNode.addNamespace("s", "http://www.w3.org/2001/XMLSchema");
/*     */ 
/*     */     
/*  44 */     xMLNode.addNamespace("http", "http://schemas.xmlsoap.org/wsdl/http/");
/*     */ 
/*     */     
/*  47 */     xMLNode.addNamespace("soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*  48 */     xMLNode.addNamespace("soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
/*     */     
/*  50 */     xMLNode.addNamespace("soapenc", "http://schemas.xmlsoap.org/soap/encoding/");
/*  51 */     xMLNode.addNamespace("soap12enc", "http://www.w3.org/2003/05/soap-encoding");
/*     */     
/*  53 */     xMLNode.addNamespace("mime", "http://schemas.xmlsoap.org/wsdl/mime/");
/*  54 */     xMLNode.addNamespace("conv", "http://www.openuri.org/2002/04/wsdl/conversation/");
/*  55 */     xMLNode.addNamespace("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
/*     */ 
/*     */     
/*  58 */     xMLNode.addNamespace("tns", paramWebService.getTargetNamespace());
/*     */     
/*  60 */     xMLNode.addAttribute("targetNamespace", null, null, paramWebService.getTargetNamespace());
/*     */ 
/*     */     
/*  63 */     if (paramWebService.getTypes() != null) {
/*  64 */       xMLNode.addChild(paramWebService.getTypes());
/*     */     }
/*     */     
/*  67 */     writeMessage(xMLNode, paramWebService);
/*  68 */     writePortType(xMLNode, paramWebService);
/*  69 */     writeBinding(xMLNode, paramWebService);
/*  70 */     writeService(paramString, xMLNode, paramWebService);
/*     */     
/*  72 */     return xMLNode;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeService(String paramString, XMLNode paramXMLNode, WebService paramWebService) {
/*  78 */     XMLNode xMLNode = paramXMLNode.addChild("service", null, "http://schemas.xmlsoap.org/wsdl/");
/*     */     
/*  80 */     xMLNode.addAttribute("name", null, null, paramWebService.getName());
/*     */     
/*  82 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/*  83 */       Port port = (Port)iterator.next();
/*     */       
/*  85 */       XMLNode xMLNode1 = xMLNode.addChild("port", null, "http://schemas.xmlsoap.org/wsdl/");
/*  86 */       xMLNode1.addAttribute("name", null, null, port.getName());
/*     */       
/*  88 */       xMLNode1.addAttribute("binding", null, null, "tns:" + port.getName());
/*     */       
/*  90 */       XMLNode xMLNode2 = null;
/*     */       
/*  92 */       if (port.getBindingInfo().isSoap12()) {
/*  93 */         xMLNode2 = xMLNode1.addChild("address", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
/*     */       } else {
/*  95 */         xMLNode2 = xMLNode1.addChild("address", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*     */       } 
/*     */       
/*  98 */       String str = paramString;
/*     */       
/* 100 */       if (isJMSBindingInfo(port.getBindingInfo())) {
/* 101 */         str = getJMSLocation(paramString, (JMSBindingInfo)port.getBindingInfo());
/*     */       }
/*     */ 
/*     */       
/* 105 */       xMLNode2.addAttribute("location", null, null, str);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getJMSLocation(String paramString, JMSBindingInfo paramJMSBindingInfo) {
/*     */     try {
/* 111 */       URL uRL = new URL(paramString);
/* 112 */       paramJMSBindingInfo.setHost(uRL.getHost());
/* 113 */       paramJMSBindingInfo.setPort(uRL.getPort());
/* 114 */       paramJMSBindingInfo.setServiceURI(uRL.getPath());
/* 115 */       return paramJMSBindingInfo.getAddress();
/* 116 */     } catch (MalformedURLException malformedURLException) {
/* 117 */       throw new AssertionError(malformedURLException);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeMessage(XMLNode paramXMLNode, WebService paramWebService) {
/* 122 */     MessageWriter messageWriter = new MessageWriter();
/*     */     
/* 124 */     for (Iterator iterator = getPortTypes(paramWebService); iterator.hasNext(); ) {
/* 125 */       Port port = (Port)iterator.next();
/*     */       
/* 127 */       for (Iterator iterator1 = port.getOrderedOperations(); iterator1.hasNext(); ) {
/* 128 */         Operation operation = (Operation)iterator1.next();
/* 129 */         messageWriter.write(paramXMLNode, operation);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writePortType(XMLNode paramXMLNode, WebService paramWebService) {
/* 136 */     OperationWriter operationWriter = new OperationWriter();
/*     */     
/* 138 */     for (Iterator iterator = getPortTypes(paramWebService); iterator.hasNext(); ) {
/* 139 */       Port port = (Port)iterator.next();
/* 140 */       XMLNode xMLNode = paramXMLNode.addChild("portType", null, "http://schemas.xmlsoap.org/wsdl/");
/* 141 */       xMLNode.addAttribute("name", null, null, port.getTypeName());
/*     */       
/* 143 */       for (Iterator iterator1 = port.getOrderedOperations(); iterator1.hasNext(); ) {
/* 144 */         Operation operation = (Operation)iterator1.next();
/* 145 */         operationWriter.write(xMLNode, operation);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Iterator getPortTypes(WebService paramWebService) {
/* 151 */     HashMap hashMap = new HashMap();
/*     */     
/* 153 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 154 */       Port port = (Port)iterator.next();
/* 155 */       hashMap.put(port.getTypeName(), port);
/*     */     } 
/*     */     
/* 158 */     return hashMap.values().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeBinding(XMLNode paramXMLNode, WebService paramWebService) {
/* 165 */     BindingOperationWriter bindingOperationWriter = new BindingOperationWriter();
/*     */     
/* 167 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 168 */       Port port = (Port)iterator.next();
/* 169 */       XMLNode xMLNode1 = paramXMLNode.addChild("binding", null, "http://schemas.xmlsoap.org/wsdl/");
/*     */       
/* 171 */       xMLNode1.addAttribute("name", null, null, port.getName());
/*     */       
/* 173 */       xMLNode1.addAttribute("type", null, null, "tns:" + port.getTypeName());
/*     */ 
/*     */       
/* 176 */       XMLNode xMLNode2 = null;
/*     */       
/* 178 */       if (port.getBindingInfo().isSoap12()) {
/* 179 */         xMLNode2 = xMLNode1.addChild("binding", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
/*     */       } else {
/* 181 */         xMLNode2 = xMLNode1.addChild("binding", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
/*     */       } 
/*     */       
/* 184 */       xMLNode2.addAttribute("style", null, null, port.isRpcStyle() ? "rpc" : "document");
/*     */ 
/*     */       
/* 187 */       if (isJMSBindingInfo(port.getBindingInfo())) {
/* 188 */         xMLNode2.addAttribute("transport", null, null, "http://www.openuri.org/2002/04/soap/jms/");
/*     */       } else {
/*     */         
/* 191 */         xMLNode2.addAttribute("transport", null, null, "http://schemas.xmlsoap.org/soap/http");
/*     */       } 
/*     */ 
/*     */       
/* 195 */       writeSecBindingExtension(xMLNode1, paramWebService);
/*     */       
/* 197 */       for (Iterator iterator1 = port.getOrderedOperations(); iterator1.hasNext(); ) {
/* 198 */         Operation operation = (Operation)iterator1.next();
/*     */         
/* 200 */         bindingOperationWriter.write(xMLNode1, operation, port.getBindingInfo().isSoap12());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSecBindingExtension(XMLNode paramXMLNode, WebService paramWebService) {
/* 209 */     SecurityDD securityDD = paramWebService.getSecurity();
/*     */     
/* 211 */     if (securityDD != null) {
/* 212 */       for (Iterator iterator = securityDD.getSecuritySpecs(); iterator.hasNext(); ) {
/* 213 */         SecuritySpec securitySpec = (SecuritySpec)iterator.next();
/* 214 */         paramXMLNode.addChild(securitySpec.getXMLNode());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 220 */   private boolean isJMSBindingInfo(BindingInfo paramBindingInfo) { return paramBindingInfo instanceof JMSBindingInfo; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public static void main(String[] paramArrayOfString) throws Exception { System.out.println((new DefinitionWriter()).getWSDL("foo.bar", WebServiceFactory.newInstance().createFromWSDL("http://www.ukindex.co.uk/cgi-bin/ukiws.dll/wsdl/IUKIService"))); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\DefinitionWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */