package weblogic.webservice.tools.wsdlgen;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import weblogic.utils.AssertionError;
import weblogic.webservice.Operation;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceFactory;
import weblogic.webservice.binding.BindingInfo;
import weblogic.webservice.binding.jms.JMSBindingInfo;
import weblogic.xml.security.specs.SecurityDD;
import weblogic.xml.security.specs.SecuritySpec;
import weblogic.xml.xmlnode.XMLNode;

public class DefinitionWriter implements WSDLConstants {
  Util util = new Util();
  
  public XMLNode getWSDL(String paramString, WebService paramWebService) throws IOException {
    XMLNode xMLNode = new XMLNode();
    xMLNode.setName("definitions", null, "http://schemas.xmlsoap.org/wsdl/");
    xMLNode.addNamespace("", "http://schemas.xmlsoap.org/wsdl/");
    xMLNode.addNamespace("s", "http://www.w3.org/2001/XMLSchema");
    xMLNode.addNamespace("http", "http://schemas.xmlsoap.org/wsdl/http/");
    xMLNode.addNamespace("soap", "http://schemas.xmlsoap.org/wsdl/soap/");
    xMLNode.addNamespace("soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
    xMLNode.addNamespace("soapenc", "http://schemas.xmlsoap.org/soap/encoding/");
    xMLNode.addNamespace("soap12enc", "http://www.w3.org/2003/05/soap-encoding");
    xMLNode.addNamespace("mime", "http://schemas.xmlsoap.org/wsdl/mime/");
    xMLNode.addNamespace("conv", "http://www.openuri.org/2002/04/wsdl/conversation/");
    xMLNode.addNamespace("wsr", "http://www.openuri.org/2002/10/soap/reliability/");
    xMLNode.addNamespace("tns", paramWebService.getTargetNamespace());
    xMLNode.addAttribute("targetNamespace", null, null, paramWebService.getTargetNamespace());
    if (paramWebService.getTypes() != null)
      xMLNode.addChild(paramWebService.getTypes()); 
    writeMessage(xMLNode, paramWebService);
    writePortType(xMLNode, paramWebService);
    writeBinding(xMLNode, paramWebService);
    writeService(paramString, xMLNode, paramWebService);
    return xMLNode;
  }
  
  private void writeService(String paramString, XMLNode paramXMLNode, WebService paramWebService) {
    XMLNode xMLNode = paramXMLNode.addChild("service", null, "http://schemas.xmlsoap.org/wsdl/");
    xMLNode.addAttribute("name", null, null, paramWebService.getName());
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      XMLNode xMLNode1 = xMLNode.addChild("port", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode1.addAttribute("name", null, null, port.getName());
      xMLNode1.addAttribute("binding", null, null, "tns:" + port.getName());
      XMLNode xMLNode2 = null;
      if (port.getBindingInfo().isSoap12()) {
        xMLNode2 = xMLNode1.addChild("address", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
      } else {
        xMLNode2 = xMLNode1.addChild("address", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
      } 
      String str = paramString;
      if (isJMSBindingInfo(port.getBindingInfo()))
        str = getJMSLocation(paramString, (JMSBindingInfo)port.getBindingInfo()); 
      xMLNode2.addAttribute("location", null, null, str);
    } 
  }
  
  private String getJMSLocation(String paramString, JMSBindingInfo paramJMSBindingInfo) {
    try {
      URL uRL = new URL(paramString);
      paramJMSBindingInfo.setHost(uRL.getHost());
      paramJMSBindingInfo.setPort(uRL.getPort());
      paramJMSBindingInfo.setServiceURI(uRL.getPath());
      return paramJMSBindingInfo.getAddress();
    } catch (MalformedURLException malformedURLException) {
      throw new AssertionError(malformedURLException);
    } 
  }
  
  private void writeMessage(XMLNode paramXMLNode, WebService paramWebService) {
    MessageWriter messageWriter = new MessageWriter();
    for (Iterator iterator = getPortTypes(paramWebService); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      for (Iterator iterator1 = port.getOrderedOperations(); iterator1.hasNext(); ) {
        Operation operation = (Operation)iterator1.next();
        messageWriter.write(paramXMLNode, operation);
      } 
    } 
  }
  
  private void writePortType(XMLNode paramXMLNode, WebService paramWebService) {
    OperationWriter operationWriter = new OperationWriter();
    for (Iterator iterator = getPortTypes(paramWebService); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      XMLNode xMLNode = paramXMLNode.addChild("portType", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode.addAttribute("name", null, null, port.getTypeName());
      for (Iterator iterator1 = port.getOrderedOperations(); iterator1.hasNext(); ) {
        Operation operation = (Operation)iterator1.next();
        operationWriter.write(xMLNode, operation);
      } 
    } 
  }
  
  private Iterator getPortTypes(WebService paramWebService) {
    HashMap hashMap = new HashMap();
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      hashMap.put(port.getTypeName(), port);
    } 
    return hashMap.values().iterator();
  }
  
  private void writeBinding(XMLNode paramXMLNode, WebService paramWebService) {
    BindingOperationWriter bindingOperationWriter = new BindingOperationWriter();
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      XMLNode xMLNode1 = paramXMLNode.addChild("binding", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode1.addAttribute("name", null, null, port.getName());
      xMLNode1.addAttribute("type", null, null, "tns:" + port.getTypeName());
      XMLNode xMLNode2 = null;
      if (port.getBindingInfo().isSoap12()) {
        xMLNode2 = xMLNode1.addChild("binding", "soap12", "http://schemas.xmlsoap.org/wsdl/soap12/");
      } else {
        xMLNode2 = xMLNode1.addChild("binding", "soap", "http://schemas.xmlsoap.org/wsdl/soap/");
      } 
      xMLNode2.addAttribute("style", null, null, port.isRpcStyle() ? "rpc" : "document");
      if (isJMSBindingInfo(port.getBindingInfo())) {
        xMLNode2.addAttribute("transport", null, null, "http://www.openuri.org/2002/04/soap/jms/");
      } else {
        xMLNode2.addAttribute("transport", null, null, "http://schemas.xmlsoap.org/soap/http");
      } 
      writeSecBindingExtension(xMLNode1, paramWebService);
      for (Iterator iterator1 = port.getOrderedOperations(); iterator1.hasNext(); ) {
        Operation operation = (Operation)iterator1.next();
        bindingOperationWriter.write(xMLNode1, operation, port.getBindingInfo().isSoap12());
      } 
    } 
  }
  
  private void writeSecBindingExtension(XMLNode paramXMLNode, WebService paramWebService) {
    SecurityDD securityDD = paramWebService.getSecurity();
    if (securityDD != null)
      for (Iterator iterator = securityDD.getSecuritySpecs(); iterator.hasNext(); ) {
        SecuritySpec securitySpec = (SecuritySpec)iterator.next();
        paramXMLNode.addChild(securitySpec.getXMLNode());
      }  
  }
  
  private boolean isJMSBindingInfo(BindingInfo paramBindingInfo) { return paramBindingInfo instanceof JMSBindingInfo; }
  
  public static void main(String[] paramArrayOfString) throws Exception { System.out.println((new DefinitionWriter()).getWSDL("foo.bar", WebServiceFactory.newInstance().createFromWSDL("http://www.ukindex.co.uk/cgi-bin/ukiws.dll/wsdl/IUKIService"))); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\DefinitionWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */