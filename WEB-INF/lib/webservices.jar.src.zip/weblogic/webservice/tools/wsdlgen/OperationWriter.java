package weblogic.webservice.tools.wsdlgen;

import java.util.Iterator;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.xml.xmlnode.XMLNode;

public class OperationWriter implements WSDLConstants {
  void write(XMLNode paramXMLNode, Operation paramOperation) {
    XMLNode xMLNode1 = paramXMLNode.addChild("operation", null, "http://schemas.xmlsoap.org/wsdl/");
    xMLNode1.addAttribute("name", null, null, paramOperation.getName());
    String[] arrayOfString = paramOperation.getParameterOrder();
    if (arrayOfString != null && arrayOfString.length != 0) {
      StringBuffer stringBuffer = new StringBuffer();
      for (byte b = 0; b < arrayOfString.length; b++) {
        stringBuffer.append(arrayOfString[b]);
        if (b < arrayOfString.length - 1)
          stringBuffer.append(" "); 
      } 
      xMLNode1.addAttribute("parameterOrder", null, null, stringBuffer.toString());
    } 
    XMLNode xMLNode2 = xMLNode1.addChild("input", null, "http://schemas.xmlsoap.org/wsdl/");
    xMLNode2.addAttribute("message", null, null, "tns:" + paramOperation.getInput().getName());
    if (!paramOperation.isOneway()) {
      XMLNode xMLNode = xMLNode1.addChild("output", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode.addAttribute("message", null, null, "tns:" + paramOperation.getOutput().getName());
    } 
    for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
      Message message = (Message)iterator.next();
      XMLNode xMLNode = xMLNode1.addChild("fault", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode.addAttribute("message", null, null, "tns:" + message.getName());
      xMLNode.addAttribute("name", null, null, message.getName());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\OperationWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */