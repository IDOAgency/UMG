/*    */ package weblogic.webservice.tools.wsdlgen;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.Message;
/*    */ import weblogic.webservice.Operation;
/*    */ import weblogic.xml.xmlnode.XMLNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OperationWriter
/*    */   implements WSDLConstants
/*    */ {
/*    */   void write(XMLNode paramXMLNode, Operation paramOperation) {
/* 17 */     XMLNode xMLNode1 = paramXMLNode.addChild("operation", null, "http://schemas.xmlsoap.org/wsdl/");
/*    */ 
/*    */     
/* 20 */     xMLNode1.addAttribute("name", null, null, paramOperation.getName());
/*    */     
/* 22 */     String[] arrayOfString = paramOperation.getParameterOrder();
/*    */     
/* 24 */     if (arrayOfString != null && arrayOfString.length != 0) {
/* 25 */       StringBuffer stringBuffer = new StringBuffer();
/*    */       
/* 27 */       for (byte b = 0; b < arrayOfString.length; b++) {
/* 28 */         stringBuffer.append(arrayOfString[b]);
/*    */         
/* 30 */         if (b < arrayOfString.length - 1) {
/* 31 */           stringBuffer.append(" ");
/*    */         }
/*    */       } 
/*    */       
/* 35 */       xMLNode1.addAttribute("parameterOrder", null, null, stringBuffer.toString());
/*    */     } 
/*    */ 
/*    */     
/* 39 */     XMLNode xMLNode2 = xMLNode1.addChild("input", null, "http://schemas.xmlsoap.org/wsdl/");
/*    */     
/* 41 */     xMLNode2.addAttribute("message", null, null, "tns:" + paramOperation.getInput().getName());
/*    */ 
/*    */     
/* 44 */     if (!paramOperation.isOneway()) {
/* 45 */       XMLNode xMLNode = xMLNode1.addChild("output", null, "http://schemas.xmlsoap.org/wsdl/");
/*    */       
/* 47 */       xMLNode.addAttribute("message", null, null, "tns:" + paramOperation.getOutput().getName());
/*    */     } 
/*    */ 
/*    */     
/* 51 */     for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
/* 52 */       Message message = (Message)iterator.next();
/*    */       
/* 54 */       XMLNode xMLNode = xMLNode1.addChild("fault", null, "http://schemas.xmlsoap.org/wsdl/");
/*    */       
/* 56 */       xMLNode.addAttribute("message", null, null, "tns:" + message.getName());
/* 57 */       xMLNode.addAttribute("name", null, null, message.getName());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\OperationWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */