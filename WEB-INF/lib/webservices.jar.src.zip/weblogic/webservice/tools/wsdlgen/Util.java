/*     */ package weblogic.webservice.tools.wsdlgen;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.PartFilter;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*  19 */   public String getEncodingStyle() { return StdNamespace.instance().soapEncoding(); }
/*     */ 
/*     */   
/*     */   public Iterator getMimeParts(Message paramMessage) {
/*  23 */     ArrayList arrayList = new ArrayList();
/*     */     
/*  25 */     for (Iterator iterator = paramMessage.getParts(); iterator.hasNext(); ) {
/*  26 */       Part part = (Part)iterator.next();
/*     */       
/*  28 */       if (part.isAttachment()) {
/*  29 */         arrayList.add(part);
/*     */       }
/*     */     } 
/*     */     
/*  33 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   public String getMimeContentTypes(Part paramPart) {
/*  37 */     String[] arrayOfString = paramPart.getContentType();
/*     */     
/*  39 */     if (arrayOfString == null || arrayOfString.length == 0) {
/*  40 */       arrayOfString = new String[] { "text/plain" };
/*     */     }
/*     */     
/*  43 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*  45 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  46 */       stringBuffer.append("    <mime:content part=\"");
/*  47 */       stringBuffer.append(paramPart.getName());
/*  48 */       stringBuffer.append("\" type=\"");
/*  49 */       stringBuffer.append(arrayOfString[b]);
/*  50 */       stringBuffer.append("\"/>\n");
/*     */     } 
/*     */     
/*  53 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public boolean isMimeMessage(Message paramMessage) {
/*  57 */     Iterator iterator = getMimeParts(paramMessage);
/*  58 */     return iterator.hasNext();
/*     */   }
/*     */   
/*     */   public String cleanSoapAction(String paramString) {
/*  62 */     if (paramString == null || "\"\"".equals(paramString)) {
/*  63 */       return "";
/*     */     }
/*  65 */     if (paramString.endsWith("\"") && paramString.startsWith("\"")) {
/*  66 */       return paramString.substring(1, paramString.length() - 1);
/*     */     }
/*  68 */     return paramString;
/*     */   }
/*     */   
/*     */   public String getParameterOrder(Operation paramOperation) {
/*  72 */     String[] arrayOfString = paramOperation.getParameterOrder();
/*     */     
/*  74 */     if (arrayOfString == null || arrayOfString.length == 0)
/*     */     {
/*  76 */       return "";
/*     */     }
/*     */     
/*  79 */     StringBuffer stringBuffer = new StringBuffer();
/*  80 */     stringBuffer.append("parameterOrder=\"");
/*     */     
/*  82 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  83 */       stringBuffer.append(arrayOfString[b]);
/*     */       
/*  85 */       if (b != arrayOfString.length - 1) {
/*  86 */         stringBuffer.append(" ");
/*     */       }
/*     */     } 
/*     */     
/*  90 */     stringBuffer.append("\"");
/*  91 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public static Part[] getHeaderParts(Message paramMessage) {
/*  95 */     return paramMessage.getParts(new PartFilter()
/*     */         {
/*  97 */           public boolean accept(Part param1Part) { return param1Part.isHeader(); }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static Part[] getBodyAndAttachmentParts(Message paramMessage) {
/* 103 */     return paramMessage.getParts(new PartFilter()
/*     */         {
/* 105 */           public boolean accept(Part param1Part) { return (param1Part.isBody() || param1Part.isAttachment()); }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static Part[] getBodyParts(Message paramMessage) {
/* 111 */     return paramMessage.getParts(new PartFilter()
/*     */         {
/* 113 */           public boolean accept(Part param1Part) { return param1Part.isBody(); }
/*     */         });
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */