package weblogic.webservice.tools.wsdlgen;

import java.util.ArrayList;
import java.util.Iterator;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.PartFilter;
import weblogic.xml.schema.binding.util.StdNamespace;

public class Util {
  public String getEncodingStyle() { return StdNamespace.instance().soapEncoding(); }
  
  public Iterator getMimeParts(Message paramMessage) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = paramMessage.getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.isAttachment())
        arrayList.add(part); 
    } 
    return arrayList.iterator();
  }
  
  public String getMimeContentTypes(Part paramPart) {
    String[] arrayOfString = paramPart.getContentType();
    if (arrayOfString == null || arrayOfString.length == 0)
      arrayOfString = new String[] { "text/plain" }; 
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < arrayOfString.length; b++) {
      stringBuffer.append("    <mime:content part=\"");
      stringBuffer.append(paramPart.getName());
      stringBuffer.append("\" type=\"");
      stringBuffer.append(arrayOfString[b]);
      stringBuffer.append("\"/>\n");
    } 
    return stringBuffer.toString();
  }
  
  public boolean isMimeMessage(Message paramMessage) {
    Iterator iterator = getMimeParts(paramMessage);
    return iterator.hasNext();
  }
  
  public String cleanSoapAction(String paramString) {
    if (paramString == null || "\"\"".equals(paramString))
      return ""; 
    if (paramString.endsWith("\"") && paramString.startsWith("\""))
      return paramString.substring(1, paramString.length() - 1); 
    return paramString;
  }
  
  public String getParameterOrder(Operation paramOperation) {
    String[] arrayOfString = paramOperation.getParameterOrder();
    if (arrayOfString == null || arrayOfString.length == 0)
      return ""; 
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("parameterOrder=\"");
    for (byte b = 0; b < arrayOfString.length; b++) {
      stringBuffer.append(arrayOfString[b]);
      if (b != arrayOfString.length - 1)
        stringBuffer.append(" "); 
    } 
    stringBuffer.append("\"");
    return stringBuffer.toString();
  }
  
  public static Part[] getHeaderParts(Message paramMessage) {
    return paramMessage.getParts(new PartFilter() {
          public boolean accept(Part param1Part) { return param1Part.isHeader(); }
        });
  }
  
  public static Part[] getBodyAndAttachmentParts(Message paramMessage) {
    return paramMessage.getParts(new PartFilter() {
          public boolean accept(Part param1Part) { return (param1Part.isBody() || param1Part.isAttachment()); }
        });
  }
  
  public static Part[] getBodyParts(Message paramMessage) {
    return paramMessage.getParts(new PartFilter() {
          public boolean accept(Part param1Part) { return param1Part.isBody(); }
        });
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\Util.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */