package weblogic.webservice.tools.wsdlgen;

import java.util.Iterator;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.PartFilter;
import weblogic.xml.xmlnode.XMLNode;

public class MessageWriter implements WSDLConstants {
  public void write(XMLNode paramXMLNode, Operation paramOperation) {
    writeInput(paramXMLNode, paramOperation);
    writeOutput(paramXMLNode, paramOperation);
    writeFault(paramXMLNode, paramOperation);
    writeConversation(paramXMLNode, paramOperation);
  }
  
  private void writeInput(XMLNode paramXMLNode, Operation paramOperation) {
    Message message = paramOperation.getInput();
    XMLNode xMLNode = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
    xMLNode.addAttribute("name", null, null, message.getName());
    if ("documentwrapped".equals(paramOperation.getStyle())) {
      writeWrapParts(xMLNode, paramOperation.getName(), message.getNamespace());
    } else {
      writeParts(xMLNode, Util.getBodyAndAttachmentParts(message), paramOperation.isRpcStyle());
    } 
    Part[] arrayOfPart = Util.getHeaderParts(message);
    if (arrayOfPart.length > 0) {
      XMLNode xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode1.addAttribute("name", null, null, message.getName() + "Header");
      writeParts(xMLNode1, arrayOfPart, paramOperation.isRpcStyle());
    } 
  }
  
  private void writeOutput(XMLNode paramXMLNode, Operation paramOperation) {
    Message message = paramOperation.getOutput();
    XMLNode xMLNode = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
    xMLNode.addAttribute("name", null, null, message.getName());
    if ("documentwrapped".equals(paramOperation.getStyle())) {
      writeWrapParts(xMLNode, paramOperation.getName() + "Response", message.getNamespace());
    } else {
      writeParts(xMLNode, Util.getBodyAndAttachmentParts(message), paramOperation.isRpcStyle());
    } 
    Part[] arrayOfPart = Util.getHeaderParts(message);
    if (arrayOfPart.length > 0) {
      XMLNode xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode1.addAttribute("name", null, null, message.getName() + "Header");
      writeParts(xMLNode1, arrayOfPart, paramOperation.isRpcStyle());
    } 
  }
  
  private void writeFault(XMLNode paramXMLNode, Operation paramOperation) {
    Iterator iterator;
    label14: for (iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
      Message message = (Message)iterator.next();
      Iterator iterator1 = paramXMLNode.getChildren("message", null);
      while (iterator1.hasNext()) {
        XMLNode xMLNode1 = (XMLNode)iterator1.next();
        if (xMLNode1.getAttribute("name", null).equals(message.getName()))
          continue label14; 
      } 
      XMLNode xMLNode = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
      xMLNode.addAttribute("name", null, null, message.getName());
      Part[] arrayOfPart = message.getParts(new PartFilter() {
            private final MessageWriter this$0;
            
            public boolean accept(Part param1Part) { return true; }
          });
      writeParts(xMLNode, arrayOfPart, paramOperation.isRpcStyle());
    } 
  }
  
  private void writeParts(XMLNode paramXMLNode, Part[] paramArrayOfPart, boolean paramBoolean) {
    for (byte b = 0; b < paramArrayOfPart.length; b++) {
      Part part = paramArrayOfPart[b];
      XMLNode xMLNode = paramXMLNode.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
      String str = part.getXMLType().getNamespaceURI();
      xMLNode.addAttribute("name", null, null, part.getName());
      if (str != null && !str.equals(""))
        xMLNode.addNamespace("partns", str); 
      if (paramBoolean) {
        if (str == null || str.equals("")) {
          xMLNode.addAttribute("xmlns", null, null, "");
          xMLNode.addAttribute("type", null, null, part.getXMLType().getLocalPart());
        } else {
          xMLNode.addAttribute("type", null, null, "partns:" + part.getXMLType().getLocalPart());
        } 
      } else if (str == null || str.equals("")) {
        xMLNode.addAttribute("xmlns", null, null, "");
        xMLNode.addAttribute("element", null, null, part.getXMLType().getLocalPart());
      } else {
        xMLNode.addAttribute("element", null, null, "partns:" + part.getXMLType().getLocalPart());
      } 
    } 
  }
  
  private void writeWrapParts(XMLNode paramXMLNode, String paramString1, String paramString2) {
    XMLNode xMLNode = paramXMLNode.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
    xMLNode.addAttribute("name", null, null, "parameters");
    xMLNode.addNamespace("partns", paramString2);
    xMLNode.addAttribute("element", null, null, "partns:" + paramString1);
  }
  
  private void writeConversation(XMLNode paramXMLNode, Operation paramOperation) {
    String str = paramOperation.getConversationPhase();
    if (str == null || str.equals("NONE"))
      return; 
    if (paramOperation.isRpcStyle()) {
      boolean bool = false;
      Iterator iterator = paramXMLNode.getChildren("message", null);
      while (iterator.hasNext()) {
        XMLNode xMLNode = (XMLNode)iterator.next();
        if (xMLNode.getAttribute("name", null).equals("StartHeader_rpc")) {
          bool = true;
          break;
        } 
      } 
      if (!bool) {
        XMLNode xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
        xMLNode1.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
        xMLNode1.addAttribute("name", null, null, "StartHeader_rpc");
        XMLNode xMLNode2 = xMLNode1.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
        xMLNode2.addAttribute("name", null, null, "StartHeader");
        xMLNode2.addAttribute("type", null, null, "conv:StartHeader");
        xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
        xMLNode1.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
        xMLNode1.addAttribute("name", null, null, "ContinueHeader_rpc");
        xMLNode2 = xMLNode1.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
        xMLNode2.addAttribute("name", null, null, "ContinueHeader");
        xMLNode2.addAttribute("type", null, null, "conv:ContinueHeader");
      } 
    } else {
      boolean bool = false;
      Iterator iterator = paramXMLNode.getChildren("message", null);
      while (iterator.hasNext()) {
        XMLNode xMLNode = (XMLNode)iterator.next();
        if (xMLNode.getAttribute("name", null).equals("StartHeader_literal")) {
          bool = true;
          break;
        } 
      } 
      if (!bool) {
        XMLNode xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
        xMLNode1.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
        xMLNode1.addAttribute("name", null, null, "StartHeader_literal");
        XMLNode xMLNode2 = xMLNode1.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
        xMLNode2.addAttribute("name", null, null, "StartHeader");
        xMLNode2.addAttribute("element", null, null, "conv:StartHeader");
        xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
        xMLNode1.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
        xMLNode1.addAttribute("name", null, null, "ContinueHeader_literal");
        xMLNode2 = xMLNode1.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
        xMLNode2.addAttribute("name", null, null, "ContinueHeader");
        xMLNode2.addAttribute("element", null, null, "conv:ContinueHeader");
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\MessageWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */