/*     */ package weblogic.webservice.tools.wsdlgen;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.PartFilter;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageWriter
/*     */   implements WSDLConstants
/*     */ {
/*     */   public void write(XMLNode paramXMLNode, Operation paramOperation) {
/*  20 */     writeInput(paramXMLNode, paramOperation);
/*  21 */     writeOutput(paramXMLNode, paramOperation);
/*  22 */     writeFault(paramXMLNode, paramOperation);
/*  23 */     writeConversation(paramXMLNode, paramOperation);
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeInput(XMLNode paramXMLNode, Operation paramOperation) {
/*  28 */     Message message = paramOperation.getInput();
/*  29 */     XMLNode xMLNode = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/*     */     
/*  31 */     xMLNode.addAttribute("name", null, null, message.getName());
/*     */     
/*  33 */     if ("documentwrapped".equals(paramOperation.getStyle())) {
/*  34 */       writeWrapParts(xMLNode, paramOperation.getName(), message.getNamespace());
/*     */     } else {
/*  36 */       writeParts(xMLNode, Util.getBodyAndAttachmentParts(message), paramOperation.isRpcStyle());
/*     */     } 
/*     */ 
/*     */     
/*  40 */     Part[] arrayOfPart = Util.getHeaderParts(message);
/*  41 */     if (arrayOfPart.length > 0) {
/*  42 */       XMLNode xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/*  43 */       xMLNode1.addAttribute("name", null, null, message.getName() + "Header");
/*  44 */       writeParts(xMLNode1, arrayOfPart, paramOperation.isRpcStyle());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeOutput(XMLNode paramXMLNode, Operation paramOperation) {
/*  50 */     Message message = paramOperation.getOutput();
/*  51 */     XMLNode xMLNode = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/*     */     
/*  53 */     xMLNode.addAttribute("name", null, null, message.getName());
/*     */     
/*  55 */     if ("documentwrapped".equals(paramOperation.getStyle())) {
/*  56 */       writeWrapParts(xMLNode, paramOperation.getName() + "Response", message.getNamespace());
/*     */     } else {
/*     */       
/*  59 */       writeParts(xMLNode, Util.getBodyAndAttachmentParts(message), paramOperation.isRpcStyle());
/*     */     } 
/*     */ 
/*     */     
/*  63 */     Part[] arrayOfPart = Util.getHeaderParts(message);
/*  64 */     if (arrayOfPart.length > 0) {
/*  65 */       XMLNode xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/*  66 */       xMLNode1.addAttribute("name", null, null, message.getName() + "Header");
/*  67 */       writeParts(xMLNode1, arrayOfPart, paramOperation.isRpcStyle());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void writeFault(XMLNode paramXMLNode, Operation paramOperation) {
/*     */     Iterator iterator;
/*  73 */     label14: for (iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
/*  74 */       Message message = (Message)iterator.next();
/*     */       
/*  76 */       Iterator iterator1 = paramXMLNode.getChildren("message", null);
/*  77 */       while (iterator1.hasNext()) {
/*  78 */         XMLNode xMLNode1 = (XMLNode)iterator1.next();
/*  79 */         if (xMLNode1.getAttribute("name", null).equals(message.getName())) {
/*     */           continue label14;
/*     */         }
/*     */       } 
/*     */       
/*  84 */       XMLNode xMLNode = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/*  85 */       xMLNode.addAttribute("name", null, null, message.getName());
/*     */       
/*  87 */       Part[] arrayOfPart = message.getParts(new PartFilter()
/*     */           {
/*  89 */             public boolean accept(Part param1Part) { return true; }
/*     */             
/*     */             private final MessageWriter this$0;
/*     */           });
/*  93 */       writeParts(xMLNode, arrayOfPart, paramOperation.isRpcStyle());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void writeParts(XMLNode paramXMLNode, Part[] paramArrayOfPart, boolean paramBoolean) {
/*  99 */     for (byte b = 0; b < paramArrayOfPart.length; b++) {
/* 100 */       Part part = paramArrayOfPart[b];
/* 101 */       XMLNode xMLNode = paramXMLNode.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
/*     */       
/* 103 */       String str = part.getXMLType().getNamespaceURI();
/*     */       
/* 105 */       xMLNode.addAttribute("name", null, null, part.getName());
/*     */       
/* 107 */       if (str != null && !str.equals("")) {
/* 108 */         xMLNode.addNamespace("partns", str);
/*     */       }
/*     */       
/* 111 */       if (paramBoolean) {
/* 112 */         if (str == null || str.equals("")) {
/* 113 */           xMLNode.addAttribute("xmlns", null, null, "");
/* 114 */           xMLNode.addAttribute("type", null, null, part.getXMLType().getLocalPart());
/*     */         } else {
/*     */           
/* 117 */           xMLNode.addAttribute("type", null, null, "partns:" + part.getXMLType().getLocalPart());
/*     */         }
/*     */       
/*     */       }
/* 121 */       else if (str == null || str.equals("")) {
/* 122 */         xMLNode.addAttribute("xmlns", null, null, "");
/* 123 */         xMLNode.addAttribute("element", null, null, part.getXMLType().getLocalPart());
/*     */       } else {
/*     */         
/* 126 */         xMLNode.addAttribute("element", null, null, "partns:" + part.getXMLType().getLocalPart());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeWrapParts(XMLNode paramXMLNode, String paramString1, String paramString2) {
/* 134 */     XMLNode xMLNode = paramXMLNode.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
/*     */     
/* 136 */     xMLNode.addAttribute("name", null, null, "parameters");
/* 137 */     xMLNode.addNamespace("partns", paramString2);
/* 138 */     xMLNode.addAttribute("element", null, null, "partns:" + paramString1);
/*     */   }
/*     */   
/*     */   private void writeConversation(XMLNode paramXMLNode, Operation paramOperation) {
/* 142 */     String str = paramOperation.getConversationPhase();
/* 143 */     if (str == null || str.equals("NONE"))
/*     */       return; 
/* 145 */     if (paramOperation.isRpcStyle()) {
/* 146 */       boolean bool = false;
/* 147 */       Iterator iterator = paramXMLNode.getChildren("message", null);
/* 148 */       while (iterator.hasNext()) {
/* 149 */         XMLNode xMLNode = (XMLNode)iterator.next();
/* 150 */         if (xMLNode.getAttribute("name", null).equals("StartHeader_rpc")) {
/* 151 */           bool = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 156 */       if (!bool) {
/* 157 */         XMLNode xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/* 158 */         xMLNode1.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
/* 159 */         xMLNode1.addAttribute("name", null, null, "StartHeader_rpc");
/* 160 */         XMLNode xMLNode2 = xMLNode1.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
/* 161 */         xMLNode2.addAttribute("name", null, null, "StartHeader");
/* 162 */         xMLNode2.addAttribute("type", null, null, "conv:StartHeader");
/*     */         
/* 164 */         xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/* 165 */         xMLNode1.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
/* 166 */         xMLNode1.addAttribute("name", null, null, "ContinueHeader_rpc");
/* 167 */         xMLNode2 = xMLNode1.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
/* 168 */         xMLNode2.addAttribute("name", null, null, "ContinueHeader");
/* 169 */         xMLNode2.addAttribute("type", null, null, "conv:ContinueHeader");
/*     */       } 
/*     */     } else {
/* 172 */       boolean bool = false;
/* 173 */       Iterator iterator = paramXMLNode.getChildren("message", null);
/* 174 */       while (iterator.hasNext()) {
/* 175 */         XMLNode xMLNode = (XMLNode)iterator.next();
/* 176 */         if (xMLNode.getAttribute("name", null).equals("StartHeader_literal")) {
/* 177 */           bool = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 182 */       if (!bool) {
/* 183 */         XMLNode xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/* 184 */         xMLNode1.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
/* 185 */         xMLNode1.addAttribute("name", null, null, "StartHeader_literal");
/* 186 */         XMLNode xMLNode2 = xMLNode1.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
/* 187 */         xMLNode2.addAttribute("name", null, null, "StartHeader");
/* 188 */         xMLNode2.addAttribute("element", null, null, "conv:StartHeader");
/*     */         
/* 190 */         xMLNode1 = paramXMLNode.addChild("message", null, "http://schemas.xmlsoap.org/wsdl/");
/* 191 */         xMLNode1.addNamespace("conv", "http://www.openuri.org/2002/04/soap/conversation/");
/* 192 */         xMLNode1.addAttribute("name", null, null, "ContinueHeader_literal");
/* 193 */         xMLNode2 = xMLNode1.addChild("part", null, "http://schemas.xmlsoap.org/wsdl/");
/* 194 */         xMLNode2.addAttribute("name", null, null, "ContinueHeader");
/* 195 */         xMLNode2.addAttribute("element", null, null, "conv:ContinueHeader");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\MessageWriter.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */