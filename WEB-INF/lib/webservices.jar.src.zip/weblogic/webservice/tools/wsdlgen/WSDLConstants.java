package weblogic.webservice.tools.wsdlgen;

public interface WSDLConstants {
  public static final String wsdlNS = "http://schemas.xmlsoap.org/wsdl/";
  
  public static final String soapNS = "http://schemas.xmlsoap.org/wsdl/soap/";
  
  public static final String soapencNS = "http://schemas.xmlsoap.org/soap/encoding/";
  
  public static final String soap12NS = "http://schemas.xmlsoap.org/wsdl/soap12/";
  
  public static final String soap12encNS = "http://www.w3.org/2003/05/soap-encoding";
  
  public static final String mimeNS = "http://schemas.xmlsoap.org/wsdl/mime/";
  
  public static final String schemaNS = "http://www.w3.org/2001/XMLSchema";
  
  public static final String convNS = "http://www.openuri.org/2002/04/wsdl/conversation/";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlgen\WSDLConstants.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */