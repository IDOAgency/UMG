/*    */ package weblogic.webservice.tools.ejbgen;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import weblogic.webservice.Port;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.tools.stubgen.StubGenHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassGen
/*    */ {
/* 21 */   private HashMap vars = new HashMap();
/*    */   
/* 23 */   private String targetDir = ".";
/*    */   private String packageName;
/*    */   
/*    */   public void setPackage(String paramString) {
/* 27 */     this.packageName = paramString;
/* 28 */     this.vars.put("packageName", paramString);
/*    */   }
/*    */ 
/*    */   
/* 32 */   public void setTargetDir(String paramString) { this.targetDir = paramString; }
/*    */ 
/*    */   
/*    */   public void visit(WebService paramWebService) throws IOException {
/* 36 */     this.vars.put("service", paramWebService);
/* 37 */     this.vars.put("port", getPort(paramWebService));
/* 38 */     this.vars.put("util", new StubGenHelper());
/*    */     
/* 40 */     writeWebServiceXML();
/* 41 */     writeService(paramWebService.getName());
/*    */   }
/*    */   
/*    */   private void writeWebServiceXML() {
/* 45 */     GenScript genScript = new GenScript("web-services.cg");
/* 46 */     setVars(genScript);
/* 47 */     PrintStream printStream = new PrintStream(new FileOutputStream(this.targetDir + File.separator + "web-services.xml"));
/*    */     
/* 49 */     genScript.setOutput(printStream);
/* 50 */     genScript.setVar("typeUtil", new TypeUtil());
/* 51 */     genScript.setVar("component", "java-class");
/* 52 */     genScript.gen();
/* 53 */     printStream.close();
/*    */   }
/*    */   
/*    */   private void writeService(String paramString) {
/* 57 */     GenScript genScript = new GenScript("ServiceClass.cg");
/* 58 */     setVars(genScript);
/* 59 */     PrintStream printStream = getPrintStream(paramString + ".java");
/* 60 */     genScript.setOutput(printStream);
/* 61 */     genScript.gen();
/* 62 */     printStream.close();
/*    */   }
/*    */ 
/*    */   
/*    */   private PrintStream getPrintStream(String paramString) throws IOException {
/* 67 */     File file = new File(this.targetDir + File.separator + this.packageName.replace('.', File.separatorChar) + File.separator + paramString);
/*    */ 
/*    */ 
/*    */     
/* 71 */     return new PrintStream(new FileOutputStream(file));
/*    */   }
/*    */   
/*    */   private void setVars(GenScript paramGenScript) {
/* 75 */     for (String str : this.vars.keySet()) {
/*    */       
/* 77 */       Object object = this.vars.get(str);
/* 78 */       paramGenScript.setVar(str, object);
/*    */     } 
/*    */   }
/*    */   
/*    */   private Port getPort(WebService paramWebService) throws IOException {
/* 83 */     Iterator iterator = paramWebService.getPorts();
/*    */     
/* 85 */     if (iterator.hasNext()) {
/* 86 */       return (Port)iterator.next();
/*    */     }
/*    */     
/* 89 */     throw new IOException("port not found");
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ejbgen\ClassGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */