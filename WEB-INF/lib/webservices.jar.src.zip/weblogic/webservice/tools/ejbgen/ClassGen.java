package weblogic.webservice.tools.ejbgen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.tools.stubgen.StubGenHelper;

public class ClassGen {
  private HashMap vars = new HashMap();
  
  private String targetDir = ".";
  
  private String packageName;
  
  public void setPackage(String paramString) {
    this.packageName = paramString;
    this.vars.put("packageName", paramString);
  }
  
  public void setTargetDir(String paramString) { this.targetDir = paramString; }
  
  public void visit(WebService paramWebService) throws IOException {
    this.vars.put("service", paramWebService);
    this.vars.put("port", getPort(paramWebService));
    this.vars.put("util", new StubGenHelper());
    writeWebServiceXML();
    writeService(paramWebService.getName());
  }
  
  private void writeWebServiceXML() {
    GenScript genScript = new GenScript("web-services.cg");
    setVars(genScript);
    PrintStream printStream = new PrintStream(new FileOutputStream(this.targetDir + File.separator + "web-services.xml"));
    genScript.setOutput(printStream);
    genScript.setVar("typeUtil", new TypeUtil());
    genScript.setVar("component", "java-class");
    genScript.gen();
    printStream.close();
  }
  
  private void writeService(String paramString) {
    GenScript genScript = new GenScript("ServiceClass.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream(paramString + ".java");
    genScript.setOutput(printStream);
    genScript.gen();
    printStream.close();
  }
  
  private PrintStream getPrintStream(String paramString) throws IOException {
    File file = new File(this.targetDir + File.separator + this.packageName.replace('.', File.separatorChar) + File.separator + paramString);
    return new PrintStream(new FileOutputStream(file));
  }
  
  private void setVars(GenScript paramGenScript) {
    for (String str : this.vars.keySet()) {
      Object object = this.vars.get(str);
      paramGenScript.setVar(str, object);
    } 
  }
  
  private Port getPort(WebService paramWebService) throws IOException {
    Iterator iterator = paramWebService.getPorts();
    if (iterator.hasNext())
      return (Port)iterator.next(); 
    throw new IOException("port not found");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ejbgen\ClassGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */