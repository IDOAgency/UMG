package weblogic.webservice.tools.ejbgen;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.tools.stubgen.StubGenHelper;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.util.StdNamespace;
import weblogic.xml.stream.XMLOutputStream;
import weblogic.xml.stream.XMLOutputStreamFactory;
import weblogic.xml.stream.XMLStreamException;
import weblogic.xml.xmlnode.XMLNode;

public class TypeUtil {
  private StubGenHelper stubGenHelper = new StubGenHelper();
  
  public String getSchema(XMLNode paramXMLNode) throws XMLStreamException {
    if (paramXMLNode == null)
      return "<types/>"; 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(byteArrayOutputStream);
    paramXMLNode.write(xMLOutputStream);
    xMLOutputStream.flush();
    return new String(byteArrayOutputStream.toByteArray());
  }
  
  public String getTypeMapping(TypeMappingRegistry paramTypeMappingRegistry) throws XMLStreamException {
    if (paramTypeMappingRegistry == null)
      return "<typemapping/>"; 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(byteArrayOutputStream);
    TypeMapping typeMapping = (TypeMapping)paramTypeMappingRegistry.getTypeMapping(StdNamespace.instance().soapEncoding());
    typeMapping.writeXML(xMLOutputStream);
    xMLOutputStream.flush();
    return new String(byteArrayOutputStream.toByteArray());
  }
  
  public String getArgStatement(Operation paramOperation) { return this.stubGenHelper.getArgStatement(paramOperation); }
  
  public String getStyle(Operation paramOperation, Part paramPart) {
    if (!paramOperation.isRpcStyle())
      return "in"; 
    if (paramPart.getMode() == Part.Mode.IN)
      return "in"; 
    if (paramPart.getMode() == Part.Mode.OUT)
      return "out"; 
    if (paramPart.getMode() == Part.Mode.INOUT)
      return "inout"; 
    return "unknown";
  }
  
  public String getLocation(Part paramPart) {
    if (paramPart.isBody())
      return "body"; 
    if (paramPart.isAttachment())
      return "attachment"; 
    return "header";
  }
  
  public Iterator getArgParts(Operation paramOperation) {
    ArrayList arrayList = new ArrayList();
    Iterator iterator;
    for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      arrayList.add(part);
    } 
    for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.OUT)
        arrayList.add(part); 
    } 
    return arrayList.iterator();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ejbgen\TypeUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */