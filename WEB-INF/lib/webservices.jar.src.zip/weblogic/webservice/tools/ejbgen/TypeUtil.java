/*     */ package weblogic.webservice.tools.ejbgen;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.tools.stubgen.StubGenHelper;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ import weblogic.xml.stream.XMLOutputStream;
/*     */ import weblogic.xml.stream.XMLOutputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeUtil
/*     */ {
/*  28 */   private StubGenHelper stubGenHelper = new StubGenHelper();
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchema(XMLNode paramXMLNode) throws XMLStreamException {
/*  33 */     if (paramXMLNode == null) {
/*  34 */       return "<types/>";
/*     */     }
/*     */     
/*  37 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*  39 */     XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(byteArrayOutputStream);
/*     */ 
/*     */     
/*  42 */     paramXMLNode.write(xMLOutputStream);
/*  43 */     xMLOutputStream.flush();
/*     */     
/*  45 */     return new String(byteArrayOutputStream.toByteArray());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeMapping(TypeMappingRegistry paramTypeMappingRegistry) throws XMLStreamException {
/*  51 */     if (paramTypeMappingRegistry == null) {
/*  52 */       return "<typemapping/>";
/*     */     }
/*     */     
/*  55 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*  57 */     XMLOutputStream xMLOutputStream = XMLOutputStreamFactory.newInstance().newDebugOutputStream(byteArrayOutputStream);
/*     */ 
/*     */     
/*  60 */     TypeMapping typeMapping = (TypeMapping)paramTypeMappingRegistry.getTypeMapping(StdNamespace.instance().soapEncoding());
/*     */ 
/*     */     
/*  63 */     typeMapping.writeXML(xMLOutputStream);
/*  64 */     xMLOutputStream.flush();
/*     */     
/*  66 */     return new String(byteArrayOutputStream.toByteArray());
/*     */   }
/*     */ 
/*     */   
/*  70 */   public String getArgStatement(Operation paramOperation) { return this.stubGenHelper.getArgStatement(paramOperation); }
/*     */ 
/*     */   
/*     */   public String getStyle(Operation paramOperation, Part paramPart) {
/*  74 */     if (!paramOperation.isRpcStyle()) {
/*  75 */       return "in";
/*     */     }
/*     */     
/*  78 */     if (paramPart.getMode() == Part.Mode.IN) {
/*  79 */       return "in";
/*     */     }
/*     */     
/*  82 */     if (paramPart.getMode() == Part.Mode.OUT) {
/*  83 */       return "out";
/*     */     }
/*     */     
/*  86 */     if (paramPart.getMode() == Part.Mode.INOUT) {
/*  87 */       return "inout";
/*     */     }
/*     */     
/*  90 */     return "unknown";
/*     */   }
/*     */   
/*     */   public String getLocation(Part paramPart) {
/*  94 */     if (paramPart.isBody())
/*  95 */       return "body"; 
/*  96 */     if (paramPart.isAttachment()) {
/*  97 */       return "attachment";
/*     */     }
/*  99 */     return "header";
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator getArgParts(Operation paramOperation) {
/* 104 */     ArrayList arrayList = new ArrayList();
/*     */     Iterator iterator;
/* 106 */     for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 107 */       Part part = (Part)iterator.next();
/* 108 */       arrayList.add(part);
/*     */     } 
/*     */     
/* 111 */     for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/* 112 */       Part part = (Part)iterator.next();
/*     */       
/* 114 */       if (part.getMode() == Part.Mode.OUT) {
/* 115 */         arrayList.add(part);
/*     */       }
/*     */     } 
/*     */     
/* 119 */     return arrayList.iterator();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ejbgen\TypeUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */