package weblogic.webservice.tools.ejbgen;

import java.io.IOException;
import weblogic.webservice.util.script.GenBase;

public class GenScript extends GenBase {
  public GenScript(String paramString) throws IOException { super(paramString, false); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ejbgen\GenScript.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */