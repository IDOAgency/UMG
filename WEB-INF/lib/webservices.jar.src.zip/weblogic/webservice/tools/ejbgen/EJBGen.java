package weblogic.webservice.tools.ejbgen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Iterator;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.tools.stubgen.StubGenHelper;

public class EJBGen {
  private HashMap vars = new HashMap();
  
  private String targetDir = ".";
  
  private String packageName;
  
  public void setPackage(String paramString) {
    this.packageName = paramString;
    this.vars.put("packageName", paramString);
  }
  
  public void setTargetDir(String paramString) { this.targetDir = paramString; }
  
  public void visit(WebService paramWebService) throws IOException {
    this.vars.put("service", paramWebService);
    this.vars.put("port", getPort(paramWebService));
    this.vars.put("util", new StubGenHelper());
    writeApplicationXML();
    writeBuildXML();
    writeEJBJarXML();
    writeWebServiceXML();
    writeWeblogicEJBJarXML();
    writeInterface(paramWebService.getName());
    writeHomeInterface(paramWebService.getName());
    writeServiceEJB(paramWebService.getName());
  }
  
  private void writeWeblogicEJBJarXML() {
    GenScript genScript = new GenScript("weblogic-ejb-jar.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream("weblogic-ejb-jar.xml");
    genScript.setOutput(printStream);
    genScript.gen();
    printStream.close();
  }
  
  private void writeWebServiceXML() {
    GenScript genScript = new GenScript("web-services.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream("web-services.xml");
    genScript.setOutput(printStream);
    genScript.setVar("typeUtil", new TypeUtil());
    genScript.setVar("component", "ejb");
    genScript.gen();
    printStream.close();
  }
  
  private void writeServiceEJB(String paramString) {
    GenScript genScript = new GenScript("ServiceEJB.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream(paramString + "EJB.java");
    genScript.setOutput(printStream);
    genScript.gen();
    printStream.close();
  }
  
  private void writeInterface(String paramString) {
    GenScript genScript = new GenScript("Interface.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream(paramString + ".java");
    genScript.setOutput(printStream);
    genScript.gen();
    printStream.close();
  }
  
  private void writeHomeInterface(String paramString) {
    GenScript genScript = new GenScript("HomeInterface.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream(paramString + "Home.java");
    genScript.setOutput(printStream);
    genScript.gen();
    printStream.close();
  }
  
  private void writeEJBJarXML() {
    GenScript genScript = new GenScript("ejb-jar.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream("ejb-jar.xml");
    genScript.setOutput(printStream);
    genScript.gen();
    printStream.close();
  }
  
  private void writeBuildXML() {
    GenScript genScript = new GenScript("build.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream("build.xml");
    genScript.setOutput(printStream);
    genScript.gen();
    printStream.close();
  }
  
  private void writeApplicationXML() {
    GenScript genScript = new GenScript("application.cg");
    setVars(genScript);
    PrintStream printStream = getPrintStream("application.xml");
    genScript.setOutput(printStream);
    genScript.gen();
    printStream.close();
  }
  
  private PrintStream getPrintStream(String paramString) throws IOException {
    File file = new File(this.targetDir + File.separator + this.packageName.replace('.', File.separatorChar) + File.separator + paramString);
    return new PrintStream(new FileOutputStream(file));
  }
  
  private void setVars(GenScript paramGenScript) {
    for (String str : this.vars.keySet()) {
      Object object = this.vars.get(str);
      paramGenScript.setVar(str, object);
    } 
  }
  
  private Port getPort(WebService paramWebService) throws IOException {
    Iterator iterator = paramWebService.getPorts();
    if (iterator.hasNext())
      return (Port)iterator.next(); 
    throw new IOException("port not found");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ejbgen\EJBGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */