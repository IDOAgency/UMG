/*     */ package weblogic.webservice.tools.ejbgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.tools.stubgen.StubGenHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EJBGen
/*     */ {
/*  21 */   private HashMap vars = new HashMap();
/*     */   
/*  23 */   private String targetDir = ".";
/*     */   private String packageName;
/*     */   
/*     */   public void setPackage(String paramString) {
/*  27 */     this.packageName = paramString;
/*  28 */     this.vars.put("packageName", paramString);
/*     */   }
/*     */ 
/*     */   
/*  32 */   public void setTargetDir(String paramString) { this.targetDir = paramString; }
/*     */ 
/*     */   
/*     */   public void visit(WebService paramWebService) throws IOException {
/*  36 */     this.vars.put("service", paramWebService);
/*  37 */     this.vars.put("port", getPort(paramWebService));
/*  38 */     this.vars.put("util", new StubGenHelper());
/*     */     
/*  40 */     writeApplicationXML();
/*  41 */     writeBuildXML();
/*  42 */     writeEJBJarXML();
/*  43 */     writeWebServiceXML();
/*  44 */     writeWeblogicEJBJarXML();
/*     */     
/*  46 */     writeInterface(paramWebService.getName());
/*  47 */     writeHomeInterface(paramWebService.getName());
/*  48 */     writeServiceEJB(paramWebService.getName());
/*     */   }
/*     */   
/*     */   private void writeWeblogicEJBJarXML() {
/*  52 */     GenScript genScript = new GenScript("weblogic-ejb-jar.cg");
/*  53 */     setVars(genScript);
/*  54 */     PrintStream printStream = getPrintStream("weblogic-ejb-jar.xml");
/*  55 */     genScript.setOutput(printStream);
/*  56 */     genScript.gen();
/*  57 */     printStream.close();
/*     */   }
/*     */   
/*     */   private void writeWebServiceXML() {
/*  61 */     GenScript genScript = new GenScript("web-services.cg");
/*  62 */     setVars(genScript);
/*  63 */     PrintStream printStream = getPrintStream("web-services.xml");
/*  64 */     genScript.setOutput(printStream);
/*  65 */     genScript.setVar("typeUtil", new TypeUtil());
/*  66 */     genScript.setVar("component", "ejb");
/*  67 */     genScript.gen();
/*  68 */     printStream.close();
/*     */   }
/*     */   
/*     */   private void writeServiceEJB(String paramString) {
/*  72 */     GenScript genScript = new GenScript("ServiceEJB.cg");
/*  73 */     setVars(genScript);
/*  74 */     PrintStream printStream = getPrintStream(paramString + "EJB.java");
/*  75 */     genScript.setOutput(printStream);
/*  76 */     genScript.gen();
/*  77 */     printStream.close();
/*     */   }
/*     */   
/*     */   private void writeInterface(String paramString) {
/*  81 */     GenScript genScript = new GenScript("Interface.cg");
/*  82 */     setVars(genScript);
/*  83 */     PrintStream printStream = getPrintStream(paramString + ".java");
/*  84 */     genScript.setOutput(printStream);
/*  85 */     genScript.gen();
/*  86 */     printStream.close();
/*     */   }
/*     */   
/*     */   private void writeHomeInterface(String paramString) {
/*  90 */     GenScript genScript = new GenScript("HomeInterface.cg");
/*  91 */     setVars(genScript);
/*  92 */     PrintStream printStream = getPrintStream(paramString + "Home.java");
/*  93 */     genScript.setOutput(printStream);
/*  94 */     genScript.gen();
/*  95 */     printStream.close();
/*     */   }
/*     */   
/*     */   private void writeEJBJarXML() {
/*  99 */     GenScript genScript = new GenScript("ejb-jar.cg");
/* 100 */     setVars(genScript);
/* 101 */     PrintStream printStream = getPrintStream("ejb-jar.xml");
/* 102 */     genScript.setOutput(printStream);
/* 103 */     genScript.gen();
/* 104 */     printStream.close();
/*     */   }
/*     */   
/*     */   private void writeBuildXML() {
/* 108 */     GenScript genScript = new GenScript("build.cg");
/* 109 */     setVars(genScript);
/* 110 */     PrintStream printStream = getPrintStream("build.xml");
/* 111 */     genScript.setOutput(printStream);
/* 112 */     genScript.gen();
/* 113 */     printStream.close();
/*     */   }
/*     */   
/*     */   private void writeApplicationXML() {
/* 117 */     GenScript genScript = new GenScript("application.cg");
/* 118 */     setVars(genScript);
/* 119 */     PrintStream printStream = getPrintStream("application.xml");
/* 120 */     genScript.setOutput(printStream);
/* 121 */     genScript.gen();
/* 122 */     printStream.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private PrintStream getPrintStream(String paramString) throws IOException {
/* 127 */     File file = new File(this.targetDir + File.separator + this.packageName.replace('.', File.separatorChar) + File.separator + paramString);
/*     */ 
/*     */ 
/*     */     
/* 131 */     return new PrintStream(new FileOutputStream(file));
/*     */   }
/*     */   
/*     */   private void setVars(GenScript paramGenScript) {
/* 135 */     for (String str : this.vars.keySet()) {
/*     */       
/* 137 */       Object object = this.vars.get(str);
/* 138 */       paramGenScript.setVar(str, object);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Port getPort(WebService paramWebService) throws IOException {
/* 143 */     Iterator iterator = paramWebService.getPorts();
/*     */     
/* 145 */     if (iterator.hasNext()) {
/* 146 */       return (Port)iterator.next();
/*     */     }
/*     */     
/* 149 */     throw new IOException("port not found");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\ejbgen\EJBGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */