/*    */ package weblogic.webservice.tools.stubgen;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import weblogic.webservice.Port;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.util.script.GenBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DemoClient
/*    */   extends GenBase
/*    */ {
/*    */   private String destDir;
/* 25 */   private Set generated = new HashSet();
/* 26 */   private String packageName = "examples.temp";
/* 27 */   private DemoClientUtil util = new DemoClientUtil();
/*    */   
/*    */   public DemoClient() throws IOException {
/* 30 */     super("DemoClient.cg", false);
/* 31 */     setOutput(System.out);
/* 32 */     setVar("packageName", this.packageName);
/*    */   }
/*    */   
/*    */   public void setPackage(String paramString) {
/* 36 */     this.packageName = paramString;
/* 37 */     setVar("packageName", paramString);
/*    */   }
/*    */ 
/*    */   
/* 41 */   public void setDestDir(String paramString) { this.destDir = paramString; }
/*    */ 
/*    */   
/*    */   public void visit(WebService paramWebService, Port paramPort) throws IOException {
/* 45 */     setVar("service", paramWebService);
/* 46 */     setVar("port", paramPort);
/* 47 */     setVar("util", this.util);
/*    */     
/* 49 */     PrintStream printStream = null;
/* 50 */     if (this.destDir != null) {
/* 51 */       String str1 = this.destDir + File.separator + this.packageName.replace('.', File.separatorChar);
/*    */ 
/*    */       
/* 54 */       (new File(str1)).mkdirs();
/*    */       
/* 56 */       File file = null;
/*    */       
/* 58 */       String str2 = this.util.getJAXRPCClassName(paramPort.getTypeName());
/*    */       
/* 60 */       file = new File(str1, str2 + "_DemoClient.java");
/*    */       
/* 62 */       this.generated.add(file.getAbsolutePath());
/*    */       
/* 64 */       printStream = new PrintStream(new FileOutputStream(file), true);
/* 65 */       setOutput(printStream);
/*    */     } 
/*    */     
/* 68 */     gen();
/*    */     
/* 70 */     if (printStream != null) {
/* 71 */       printStream.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 76 */   public Set getGenerated() { return this.generated; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\DemoClient.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */