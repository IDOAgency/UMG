package weblogic.webservice.tools.stubgen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.util.script.GenBase;

public class DemoClient extends GenBase {
  private String destDir;
  
  private Set generated = new HashSet();
  
  private String packageName = "examples.temp";
  
  private DemoClientUtil util = new DemoClientUtil();
  
  public DemoClient() throws IOException {
    super("DemoClient.cg", false);
    setOutput(System.out);
    setVar("packageName", this.packageName);
  }
  
  public void setPackage(String paramString) {
    this.packageName = paramString;
    setVar("packageName", paramString);
  }
  
  public void setDestDir(String paramString) { this.destDir = paramString; }
  
  public void visit(WebService paramWebService, Port paramPort) throws IOException {
    setVar("service", paramWebService);
    setVar("port", paramPort);
    setVar("util", this.util);
    PrintStream printStream = null;
    if (this.destDir != null) {
      String str1 = this.destDir + File.separator + this.packageName.replace('.', File.separatorChar);
      (new File(str1)).mkdirs();
      File file = null;
      String str2 = this.util.getJAXRPCClassName(paramPort.getTypeName());
      file = new File(str1, str2 + "_DemoClient.java");
      this.generated.add(file.getAbsolutePath());
      printStream = new PrintStream(new FileOutputStream(file), true);
      setOutput(printStream);
    } 
    gen();
    if (printStream != null)
      printStream.close(); 
  }
  
  public Set getGenerated() { return this.generated; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\DemoClient.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */