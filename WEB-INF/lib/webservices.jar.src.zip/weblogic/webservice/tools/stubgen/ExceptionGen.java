package weblogic.webservice.tools.stubgen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;
import weblogic.webservice.util.jspgen.JspGenBase;
import weblogic.xml.schema.binding.internal.NameUtil;

public abstract class ExceptionGen extends JspGenBase {
  private String destDir = ".";
  
  private Set generated = new HashSet();
  
  protected String packageName = "examples.temp";
  
  protected String exceptionName;
  
  protected String partName;
  
  protected String javaTypeName;
  
  public void setPackage(String paramString) { this.packageName = paramString; }
  
  public void setDestDir(String paramString) { this.destDir = paramString; }
  
  public void visit(String paramString1, Class paramClass, String paramString2) throws IOException {
    if (java.lang.Exception.class.isAssignableFrom(paramClass))
      return; 
    PrintStream printStream = null;
    this.partName = NameUtil.getJavaName(paramString2);
    this.javaTypeName = getTypeName(paramClass);
    this.exceptionName = NameUtil.getJAXRPCClassName(paramString1);
    if (this.destDir != null) {
      String str = this.destDir + File.separator + this.packageName.replace('.', File.separatorChar);
      (new File(str)).mkdirs();
      File file = new File(str, paramString1 + ".java");
      this.generated.add(file.getAbsolutePath());
      printStream = new PrintStream(new FileOutputStream(file), true);
      setOutput(printStream);
    } 
    generate();
    if (printStream != null)
      printStream.close(); 
  }
  
  public Set getGenerated() { return this.generated; }
  
  private String getTypeName(Class paramClass) {
    String str = "";
    while (paramClass.getComponentType() != null) {
      paramClass = paramClass.getComponentType();
      str = str + "[]";
    } 
    return paramClass.getName() + str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\ExceptionGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */