/*    */ package weblogic.webservice.tools.stubgen;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import weblogic.webservice.util.jspgen.JspGenBase;
/*    */ import weblogic.xml.schema.binding.internal.NameUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ExceptionGen
/*    */   extends JspGenBase
/*    */ {
/* 25 */   private String destDir = ".";
/* 26 */   private Set generated = new HashSet();
/* 27 */   protected String packageName = "examples.temp";
/*    */ 
/*    */   
/*    */   protected String exceptionName;
/*    */ 
/*    */   
/*    */   protected String partName;
/*    */ 
/*    */   
/*    */   protected String javaTypeName;
/*    */ 
/*    */   
/* 39 */   public void setPackage(String paramString) { this.packageName = paramString; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public void setDestDir(String paramString) { this.destDir = paramString; }
/*    */ 
/*    */   
/*    */   public void visit(String paramString1, Class paramClass, String paramString2) throws IOException {
/* 48 */     if (java.lang.Exception.class.isAssignableFrom(paramClass))
/*    */       return; 
/* 50 */     PrintStream printStream = null;
/* 51 */     this.partName = NameUtil.getJavaName(paramString2);
/* 52 */     this.javaTypeName = getTypeName(paramClass);
/* 53 */     this.exceptionName = NameUtil.getJAXRPCClassName(paramString1);
/*    */     
/* 55 */     if (this.destDir != null) {
/* 56 */       String str = this.destDir + File.separator + this.packageName.replace('.', File.separatorChar);
/*    */ 
/*    */       
/* 59 */       (new File(str)).mkdirs();
/*    */       
/* 61 */       File file = new File(str, paramString1 + ".java");
/*    */       
/* 63 */       this.generated.add(file.getAbsolutePath());
/*    */       
/* 65 */       printStream = new PrintStream(new FileOutputStream(file), true);
/* 66 */       setOutput(printStream);
/*    */     } 
/*    */     
/* 69 */     generate();
/*    */     
/* 71 */     if (printStream != null) {
/* 72 */       printStream.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 77 */   public Set getGenerated() { return this.generated; }
/*    */ 
/*    */   
/*    */   private String getTypeName(Class paramClass) {
/* 81 */     String str = "";
/*    */     
/* 83 */     while (paramClass.getComponentType() != null) {
/* 84 */       paramClass = paramClass.getComponentType();
/* 85 */       str = str + "[]";
/*    */     } 
/*    */     
/* 88 */     return paramClass.getName() + str;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\ExceptionGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */