/*     */ package weblogic.webservice.tools.stubgen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.core.PortMapper;
/*     */ import weblogic.webservice.util.jspgen.GenFactory;
/*     */ import weblogic.xml.schema.binding.internal.NameUtil;
/*     */ 
/*     */ public class ServiceGen
/*     */ {
/*     */   private String destDir;
/*     */   private Class[] portInterfaces;
/*     */   private boolean genDemo;
/*     */   private ServiceBase serviceStub;
/*     */   private ServiceBase serviceInterface;
/*     */   private StubGenHelper helper;
/*     */   private boolean generateAsyncMethods;
/*     */   private boolean onlyConvenienceMethod;
/*     */   private Set generated;
/*     */   
/*     */   public ServiceGen() throws IOException {
/*  34 */     this.genDemo = false;
/*     */ 
/*     */ 
/*     */     
/*  38 */     this.helper = new StubGenHelper();
/*     */     
/*  40 */     this.onlyConvenienceMethod = false;
/*     */     
/*  42 */     this.generated = new HashSet();
/*     */ 
/*     */ 
/*     */     
/*  46 */     this.serviceStub = (ServiceBase)GenFactory.create("weblogic.webservice.tools.stubgen.Service");
/*     */ 
/*     */     
/*  49 */     this.serviceInterface = (ServiceBase)GenFactory.create("weblogic.webservice.tools.stubgen.ServiceInterface");
/*     */ 
/*     */     
/*  52 */     this.serviceStub.location = "http://you.forgot.to/set/wsdl/location/";
/*     */     
/*  54 */     this.serviceInterface.location = "http://you.forgot.to/set/wsdl/location/";
/*     */ 
/*     */     
/*  57 */     this.serviceStub.setHelper(this.helper);
/*  58 */     this.serviceInterface.setHelper(this.helper);
/*     */   }
/*     */ 
/*     */   
/*  62 */   public void setDestDir(String paramString) { this.destDir = paramString; }
/*     */ 
/*     */ 
/*     */   
/*  66 */   public void setGenerateAsyncMethods(boolean paramBoolean) { this.generateAsyncMethods = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  70 */   public void setOnlyConvenienceMethod(boolean paramBoolean) { this.onlyConvenienceMethod = paramBoolean; }
/*     */ 
/*     */   
/*     */   public void setPackage(String paramString) {
/*  74 */     this.serviceStub.packageName = paramString;
/*  75 */     this.serviceInterface.packageName = paramString;
/*  76 */     this.helper.setPackageName(paramString);
/*     */   }
/*     */   
/*     */   public void setWSDLLocation(String paramString) {
/*  80 */     this.serviceStub.location = paramString;
/*  81 */     this.serviceInterface.location = paramString;
/*     */   }
/*     */ 
/*     */   
/*  85 */   public void setJ2MEClient(boolean paramBoolean) { this.helper.setJ2MEClient(paramBoolean); }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void setPortInterfaces(Class[] paramArrayOfClass) { this.portInterfaces = paramArrayOfClass; }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public void setUseLowerCaseMethodNames(boolean paramBoolean) { this.helper.setUseLowerCaseMethodNames(paramBoolean); }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void setUsePortNameAsMethodName(boolean paramBoolean) { this.helper.setUsePortNameAsMethodName(paramBoolean); }
/*     */ 
/*     */   
/*     */   public void visit(WebService paramWebService) throws IOException {
/* 101 */     this.serviceStub.service = paramWebService;
/* 102 */     this.serviceInterface.service = paramWebService;
/*     */     
/* 104 */     this.serviceStub.ports = getPorts(paramWebService);
/* 105 */     this.serviceInterface.ports = getPorts(paramWebService);
/*     */     
/* 107 */     validate(paramWebService);
/*     */     
/* 109 */     PrintStream printStream1 = null;
/* 110 */     PrintStream printStream2 = null;
/*     */     
/* 112 */     if (this.destDir != null) {
/*     */       
/* 114 */       String str1 = this.destDir + File.separator + this.serviceStub.packageName.replace('.', File.separatorChar);
/*     */ 
/*     */       
/* 117 */       (new File(str1)).mkdirs();
/*     */       
/* 119 */       String str2 = this.helper.getJAXRPCClassName(paramWebService.getName());
/*     */ 
/*     */       
/* 122 */       this.serviceStub.serviceName = str2;
/* 123 */       this.serviceInterface.serviceName = str2;
/*     */       
/* 125 */       File file = new File(str1, str2 + "_Impl.java");
/* 126 */       printStream1 = new PrintStream(new FileOutputStream(file), true);
/* 127 */       this.serviceStub.setOutput(printStream1);
/* 128 */       this.generated.add(file.getAbsolutePath());
/*     */       
/* 130 */       file = new File(str1, str2 + ".java");
/* 131 */       this.generated.add(file.getAbsolutePath());
/*     */       
/* 133 */       printStream2 = new PrintStream(new FileOutputStream(file), true);
/*     */ 
/*     */       
/* 136 */       this.serviceInterface.setOutput(printStream2);
/*     */     } 
/*     */     
/* 139 */     this.serviceStub.generate();
/* 140 */     this.serviceInterface.generate();
/*     */     
/* 142 */     if (printStream1 != null) {
/* 143 */       printStream1.close();
/*     */     }
/*     */     
/* 146 */     if (printStream2 != null) {
/* 147 */       printStream2.close();
/*     */     }
/*     */     
/* 150 */     generateException(paramWebService);
/*     */     
/* 152 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 153 */       Port port = (Port)iterator.next();
/*     */       
/* 155 */       Class clazz = getClassForPortType(port.getTypeName(), this.portInterfaces);
/*     */ 
/*     */       
/* 158 */       if (clazz != null) {
/* 159 */         (new PortMapper()).mapInterfaceToPort(clazz, port);
/*     */       }
/*     */       
/* 162 */       generateStub(paramWebService, port, true);
/* 163 */       generateStub(paramWebService, port, false);
/* 164 */       if (this.genDemo) generateDemoClient(paramWebService, port); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validate(WebService paramWebService) throws IOException {
/* 169 */     String str = NameUtil.getJAXRPCClassName(paramWebService.getName());
/*     */ 
/*     */     
/* 172 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/* 173 */       Port port = (Port)iterator.next();
/*     */       
/* 175 */       String str1 = NameUtil.getJAXRPCClassName(port.getTypeName());
/* 176 */       if (str.equals(str1)) {
/* 177 */         port.setTypeName(str1 + "_PortType");
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Class getClassForPortType(String paramString, Class[] paramArrayOfClass) {
/* 183 */     if (paramArrayOfClass == null) {
/* 184 */       return null;
/*     */     }
/*     */     
/* 187 */     for (byte b = 0; b < paramArrayOfClass.length; b++) {
/* 188 */       if (paramString.equals(getLastName(paramArrayOfClass[b].getName()))) {
/* 189 */         return paramArrayOfClass[b];
/*     */       }
/*     */     } 
/*     */     
/* 193 */     return null;
/*     */   }
/*     */   
/*     */   private String getLastName(String paramString) {
/* 197 */     int i = paramString.lastIndexOf(".");
/* 198 */     return (i != -1) ? paramString.substring(i + 1, paramString.length()) : paramString;
/*     */   }
/*     */   
/*     */   private void generateException(WebService paramWebService) throws IOException {
/* 202 */     HashMap hashMap = new HashMap();
/* 203 */     HashSet hashSet = new HashSet();
/*     */     Iterator iterator;
/* 205 */     for (iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
/*     */       
/* 207 */       Iterator iterator1 = ((Port)iterator.next()).getOperations();
/* 208 */       while (iterator1.hasNext()) {
/*     */         
/* 210 */         Operation operation = (Operation)iterator1.next();
/* 211 */         Iterator iterator2 = operation.getFaults();
/*     */         
/* 213 */         while (iterator2.hasNext()) {
/* 214 */           Message message = (Message)iterator2.next();
/* 215 */           if (hashSet.add(message.getName())) {
/* 216 */             Part part = (Part)message.getParts().next();
/* 217 */             hashMap.put(message.getName(), part);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 223 */     for (iterator = hashSet.iterator(); iterator.hasNext(); ) {
/*     */       
/* 225 */       ExceptionGen exceptionGen = (ExceptionGen)GenFactory.create("weblogic.webservice.tools.stubgen.Exception");
/*     */ 
/*     */       
/* 228 */       exceptionGen.setPackage(this.serviceStub.packageName);
/* 229 */       exceptionGen.setDestDir(this.destDir);
/* 230 */       String str = (String)iterator.next();
/* 231 */       Part part = (Part)hashMap.get(str);
/* 232 */       exceptionGen.visit(str, part.getJavaType(), part.getName());
/* 233 */       this.generated.addAll(exceptionGen.getGenerated());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void generateStub(WebService paramWebService, Port paramPort, boolean paramBoolean) throws IOException {
/* 240 */     String str = paramBoolean ? "weblogic.webservice.tools.stubgen.StubInterface" : "weblogic.webservice.tools.stubgen.Stub";
/*     */ 
/*     */ 
/*     */     
/* 244 */     StubGen stubGen = (StubGen)GenFactory.create(str);
/* 245 */     stubGen.writeInterface = paramBoolean;
/*     */     
/* 247 */     stubGen.setPackage(this.serviceStub.packageName);
/* 248 */     stubGen.setDestDir(this.destDir);
/* 249 */     stubGen.setHelper(this.helper);
/* 250 */     stubGen.generateAsyncMethods = this.generateAsyncMethods;
/* 251 */     stubGen.onlyConvenienceMethod = this.onlyConvenienceMethod;
/*     */     
/* 253 */     stubGen.visit(paramWebService, paramPort);
/* 254 */     this.generated.addAll(stubGen.getGenerated());
/*     */   }
/*     */   
/*     */   private void generateDemoClient(WebService paramWebService, Port paramPort) throws IOException {
/* 258 */     DemoClient demoClient = new DemoClient();
/* 259 */     demoClient.setPackage(this.serviceStub.packageName);
/* 260 */     demoClient.setDestDir(this.destDir);
/*     */ 
/*     */     
/* 263 */     demoClient.visit(paramWebService, paramPort);
/* 264 */     this.generated.addAll(demoClient.getGenerated());
/*     */   }
/*     */   
/*     */   private Port[] getPorts(WebService paramWebService) {
/* 268 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 270 */     for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext();) {
/* 271 */       arrayList.add(iterator.next());
/*     */     }
/*     */     
/* 274 */     return (Port[])arrayList.toArray(new Port[arrayList.size()]);
/*     */   }
/*     */ 
/*     */   
/* 278 */   public Set getGenerated() { return this.generated; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\ServiceGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */