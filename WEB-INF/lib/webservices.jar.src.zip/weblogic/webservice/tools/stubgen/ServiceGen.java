package weblogic.webservice.tools.stubgen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.core.PortMapper;
import weblogic.webservice.util.jspgen.GenFactory;
import weblogic.xml.schema.binding.internal.NameUtil;

public class ServiceGen {
  private String destDir;
  
  private Class[] portInterfaces;
  
  private boolean genDemo;
  
  private ServiceBase serviceStub;
  
  private ServiceBase serviceInterface;
  
  private StubGenHelper helper;
  
  private boolean generateAsyncMethods;
  
  private boolean onlyConvenienceMethod;
  
  private Set generated;
  
  public ServiceGen() throws IOException {
    this.genDemo = false;
    this.helper = new StubGenHelper();
    this.onlyConvenienceMethod = false;
    this.generated = new HashSet();
    this.serviceStub = (ServiceBase)GenFactory.create("weblogic.webservice.tools.stubgen.Service");
    this.serviceInterface = (ServiceBase)GenFactory.create("weblogic.webservice.tools.stubgen.ServiceInterface");
    this.serviceStub.location = "http://you.forgot.to/set/wsdl/location/";
    this.serviceInterface.location = "http://you.forgot.to/set/wsdl/location/";
    this.serviceStub.setHelper(this.helper);
    this.serviceInterface.setHelper(this.helper);
  }
  
  public void setDestDir(String paramString) { this.destDir = paramString; }
  
  public void setGenerateAsyncMethods(boolean paramBoolean) { this.generateAsyncMethods = paramBoolean; }
  
  public void setOnlyConvenienceMethod(boolean paramBoolean) { this.onlyConvenienceMethod = paramBoolean; }
  
  public void setPackage(String paramString) {
    this.serviceStub.packageName = paramString;
    this.serviceInterface.packageName = paramString;
    this.helper.setPackageName(paramString);
  }
  
  public void setWSDLLocation(String paramString) {
    this.serviceStub.location = paramString;
    this.serviceInterface.location = paramString;
  }
  
  public void setJ2MEClient(boolean paramBoolean) { this.helper.setJ2MEClient(paramBoolean); }
  
  public void setPortInterfaces(Class[] paramArrayOfClass) { this.portInterfaces = paramArrayOfClass; }
  
  public void setUseLowerCaseMethodNames(boolean paramBoolean) { this.helper.setUseLowerCaseMethodNames(paramBoolean); }
  
  public void setUsePortNameAsMethodName(boolean paramBoolean) { this.helper.setUsePortNameAsMethodName(paramBoolean); }
  
  public void visit(WebService paramWebService) throws IOException {
    this.serviceStub.service = paramWebService;
    this.serviceInterface.service = paramWebService;
    this.serviceStub.ports = getPorts(paramWebService);
    this.serviceInterface.ports = getPorts(paramWebService);
    validate(paramWebService);
    PrintStream printStream1 = null;
    PrintStream printStream2 = null;
    if (this.destDir != null) {
      String str1 = this.destDir + File.separator + this.serviceStub.packageName.replace('.', File.separatorChar);
      (new File(str1)).mkdirs();
      String str2 = this.helper.getJAXRPCClassName(paramWebService.getName());
      this.serviceStub.serviceName = str2;
      this.serviceInterface.serviceName = str2;
      File file = new File(str1, str2 + "_Impl.java");
      printStream1 = new PrintStream(new FileOutputStream(file), true);
      this.serviceStub.setOutput(printStream1);
      this.generated.add(file.getAbsolutePath());
      file = new File(str1, str2 + ".java");
      this.generated.add(file.getAbsolutePath());
      printStream2 = new PrintStream(new FileOutputStream(file), true);
      this.serviceInterface.setOutput(printStream2);
    } 
    this.serviceStub.generate();
    this.serviceInterface.generate();
    if (printStream1 != null)
      printStream1.close(); 
    if (printStream2 != null)
      printStream2.close(); 
    generateException(paramWebService);
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      Class clazz = getClassForPortType(port.getTypeName(), this.portInterfaces);
      if (clazz != null)
        (new PortMapper()).mapInterfaceToPort(clazz, port); 
      generateStub(paramWebService, port, true);
      generateStub(paramWebService, port, false);
      if (this.genDemo)
        generateDemoClient(paramWebService, port); 
    } 
  }
  
  private void validate(WebService paramWebService) throws IOException {
    String str = NameUtil.getJAXRPCClassName(paramWebService.getName());
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Port port = (Port)iterator.next();
      String str1 = NameUtil.getJAXRPCClassName(port.getTypeName());
      if (str.equals(str1))
        port.setTypeName(str1 + "_PortType"); 
    } 
  }
  
  private Class getClassForPortType(String paramString, Class[] paramArrayOfClass) {
    if (paramArrayOfClass == null)
      return null; 
    for (byte b = 0; b < paramArrayOfClass.length; b++) {
      if (paramString.equals(getLastName(paramArrayOfClass[b].getName())))
        return paramArrayOfClass[b]; 
    } 
    return null;
  }
  
  private String getLastName(String paramString) {
    int i = paramString.lastIndexOf(".");
    return (i != -1) ? paramString.substring(i + 1, paramString.length()) : paramString;
  }
  
  private void generateException(WebService paramWebService) throws IOException {
    HashMap hashMap = new HashMap();
    HashSet hashSet = new HashSet();
    Iterator iterator;
    for (iterator = paramWebService.getPorts(); iterator.hasNext(); ) {
      Iterator iterator1 = ((Port)iterator.next()).getOperations();
      while (iterator1.hasNext()) {
        Operation operation = (Operation)iterator1.next();
        Iterator iterator2 = operation.getFaults();
        while (iterator2.hasNext()) {
          Message message = (Message)iterator2.next();
          if (hashSet.add(message.getName())) {
            Part part = (Part)message.getParts().next();
            hashMap.put(message.getName(), part);
          } 
        } 
      } 
    } 
    for (iterator = hashSet.iterator(); iterator.hasNext(); ) {
      ExceptionGen exceptionGen = (ExceptionGen)GenFactory.create("weblogic.webservice.tools.stubgen.Exception");
      exceptionGen.setPackage(this.serviceStub.packageName);
      exceptionGen.setDestDir(this.destDir);
      String str = (String)iterator.next();
      Part part = (Part)hashMap.get(str);
      exceptionGen.visit(str, part.getJavaType(), part.getName());
      this.generated.addAll(exceptionGen.getGenerated());
    } 
  }
  
  private void generateStub(WebService paramWebService, Port paramPort, boolean paramBoolean) throws IOException {
    String str = paramBoolean ? "weblogic.webservice.tools.stubgen.StubInterface" : "weblogic.webservice.tools.stubgen.Stub";
    StubGen stubGen = (StubGen)GenFactory.create(str);
    stubGen.writeInterface = paramBoolean;
    stubGen.setPackage(this.serviceStub.packageName);
    stubGen.setDestDir(this.destDir);
    stubGen.setHelper(this.helper);
    stubGen.generateAsyncMethods = this.generateAsyncMethods;
    stubGen.onlyConvenienceMethod = this.onlyConvenienceMethod;
    stubGen.visit(paramWebService, paramPort);
    this.generated.addAll(stubGen.getGenerated());
  }
  
  private void generateDemoClient(WebService paramWebService, Port paramPort) throws IOException {
    DemoClient demoClient = new DemoClient();
    demoClient.setPackage(this.serviceStub.packageName);
    demoClient.setDestDir(this.destDir);
    demoClient.visit(paramWebService, paramPort);
    this.generated.addAll(demoClient.getGenerated());
  }
  
  private Port[] getPorts(WebService paramWebService) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = paramWebService.getPorts(); iterator.hasNext();)
      arrayList.add(iterator.next()); 
    return (Port[])arrayList.toArray(new Port[arrayList.size()]);
  }
  
  public Set getGenerated() { return this.generated; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\ServiceGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */