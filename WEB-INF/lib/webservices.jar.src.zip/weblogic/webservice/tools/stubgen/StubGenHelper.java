/*     */ package weblogic.webservice.tools.stubgen;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.Serializer;
/*     */ import javax.xml.rpc.encoding.SerializerFactory;
/*     */ import javax.xml.rpc.encoding.TypeMapping;
/*     */ import weblogic.webservice.Message;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ import weblogic.webservice.util.jspgen.ScriptException;
/*     */ import weblogic.xml.schema.binding.CodecPropertyInfo;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.internal.NameUtil;
/*     */ import weblogic.xml.schema.binding.util.runtime.PropertyInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StubGenHelper
/*     */ {
/*     */   private boolean usePortNameAsMethodName = false;
/*     */   private boolean isJ2MEClient = false;
/*     */   private boolean useLowerCaseMethodNames = false;
/*     */   private String packageName;
/*     */   
/*  45 */   public void setJ2MEClient(boolean paramBoolean) { this.isJ2MEClient = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  49 */   public void setUseLowerCaseMethodNames(boolean paramBoolean) { this.useLowerCaseMethodNames = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  53 */   public void setUsePortNameAsMethodName(boolean paramBoolean) { this.usePortNameAsMethodName = paramBoolean; }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public void setPackageName(String paramString) { this.packageName = paramString; }
/*     */ 
/*     */   
/*     */   public String getPortName(Port paramPort) {
/*  61 */     if (this.usePortNameAsMethodName) {
/*  62 */       return paramPort.getName().replace('.', '_');
/*     */     }
/*  64 */     return paramPort.getTypeName().replace('.', '_');
/*     */   }
/*     */ 
/*     */   
/*     */   public String getThrowJAXRPCException() {
/*  69 */     if (this.isJ2MEClient) {
/*  70 */       return "throw e;";
/*     */     }
/*  72 */     return "throw new java.rmi.RemoteException( e.getMessage(), e.getLinkedCause() );\n";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getThrowAllException() {
/*  78 */     if (this.isJ2MEClient) {
/*  79 */       return "throw new javax.xml.rpc.JAXRPCException(e);";
/*     */     }
/*  81 */     return "throw new java.rmi.RemoteException( e.getMessage(), e );";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getThrowCustomerException(Operation paramOperation) {
/*  87 */     StringBuffer stringBuffer = new StringBuffer();
/*  88 */     HashSet hashSet = new HashSet();
/*     */     
/*     */     Iterator iterator;
/*  91 */     label24: for (iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
/*  92 */       Message message = (Message)iterator.next();
/*  93 */       String str = getFaultName(message);
/*     */       
/*  95 */       if ("java.lang.Exception".equals(str) || "Exception".equals(str)) {
/*     */         continue;
/*     */       }
/*     */       
/*  99 */       Part part = (Part)message.getParts().next();
/*     */       
/* 101 */       for (Iterator iterator1 = hashSet.iterator(); iterator1.hasNext();) {
/* 102 */         if (((Class)iterator1.next()).isAssignableFrom(part.getJavaType())) {
/*     */           continue label24;
/*     */         }
/*     */       } 
/*     */       
/* 107 */       if (java.lang.Exception.class.isAssignableFrom(part.getJavaType())) {
/* 108 */         hashSet.add(part.getJavaType());
/*     */       }
/*     */       
/* 111 */       char c1 = '{';
/* 112 */       char c2 = '}';
/* 113 */       stringBuffer.append("\n    " + c2 + " catch (" + str + " e) ");
/* 114 */       stringBuffer.append("" + c1 + "\n");
/* 115 */       stringBuffer.append("      throw e;");
/*     */     } 
/*     */     
/* 118 */     if (stringBuffer.length() > 0) {
/* 119 */       stringBuffer.append("\n");
/*     */     }
/*     */     
/* 122 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public String getThrowSOAPFaultException(Operation paramOperation) {
/* 126 */     if (this.isJ2MEClient) {
/* 127 */       return "throw e;";
/*     */     }
/* 129 */     return "throw new java.rmi.RemoteException( \"SOAP Fault:\" + e + \"\\nDetail:\\n\"+e.getDetail(), e );\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public boolean isTrue(String paramString) { return "true".equals(paramString); }
/*     */ 
/*     */   
/*     */   public String throwException(Operation paramOperation) {
/* 139 */     StringBuffer stringBuffer = new StringBuffer();
/* 140 */     boolean bool = false;
/*     */     
/* 142 */     for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
/* 143 */       Message message = (Message)iterator.next();
/* 144 */       if ("java.lang.Exception".equals(getFaultName(message)) || "Exception".equals(getFaultName(message))) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 149 */       if (!bool) {
/* 150 */         bool = true;
/* 151 */         stringBuffer.append("throws " + getFaultName(message)); continue;
/*     */       } 
/* 153 */       stringBuffer.append(", " + getFaultName(message));
/*     */     } 
/*     */ 
/*     */     
/* 157 */     if (!this.isJ2MEClient) {
/* 158 */       if (bool) {
/* 159 */         stringBuffer.append(", java.rmi.RemoteException ");
/*     */       } else {
/* 161 */         stringBuffer.append("throws java.rmi.RemoteException ");
/*     */       } 
/*     */     }
/*     */     
/* 165 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   private String getFaultName(Message paramMessage) {
/* 169 */     Part part = (Part)paramMessage.getParts().next();
/*     */     
/* 171 */     String str = null;
/* 172 */     if (java.lang.Exception.class.isAssignableFrom(part.getJavaType())) {
/* 173 */       str = part.getJavaType().getName();
/*     */     } else {
/* 175 */       str = this.packageName + "." + NameUtil.getJAXRPCClassName(paramMessage.getName());
/*     */     } 
/*     */     
/* 178 */     return str;
/*     */   }
/*     */ 
/*     */   
/* 182 */   public String extendsRemote() { return this.isJ2MEClient ? "" : " extends java.rmi.Remote"; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String setConvenienceArgs(Part paramPart) throws ScriptException {
/* 188 */     Iterator iterator = getNameAndTypesFromPart(paramPart);
/*     */     
/* 190 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 192 */     while (iterator.hasNext()) {
/* 193 */       Object[] arrayOfObject = (Object[])iterator.next();
/* 194 */       stringBuffer.append("    ");
/* 195 */       stringBuffer.append("_input.set");
/* 196 */       stringBuffer.append(makeFirstCharBig((String)arrayOfObject[0]));
/* 197 */       stringBuffer.append("( ");
/* 198 */       stringBuffer.append((String)arrayOfObject[0]);
/* 199 */       stringBuffer.append(" );\n");
/*     */     } 
/*     */     
/* 202 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public String getHeaderConvenienceArgNames(Operation paramOperation) {
/* 206 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     Iterator iterator;
/* 208 */     for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 209 */       Part part = (Part)iterator.next();
/*     */       
/* 211 */       if (part.isHeader()) {
/* 212 */         if (stringBuffer.length() != 0) {
/* 213 */           stringBuffer.append(", ");
/*     */         }
/*     */         
/* 216 */         stringBuffer.append(getJavaName(part.getName()));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 221 */     for (iterator = getOutPartsWithoutInOuts(paramOperation); iterator.hasNext(); ) {
/* 222 */       Part part = (Part)iterator.next();
/*     */       
/* 224 */       if (part.isHeader()) {
/* 225 */         if (stringBuffer.length() != 0) {
/* 226 */           stringBuffer.append(", ");
/*     */         }
/*     */         
/* 229 */         stringBuffer.append(getJavaName(part.getName()));
/*     */       } 
/*     */     } 
/*     */     
/* 233 */     if (stringBuffer.length() > 0) {
/* 234 */       return ", " + stringBuffer.toString();
/*     */     }
/* 236 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getConvenienceArgs(Operation paramOperation) {
/* 242 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 244 */     processConvenienceArgsParts(stringBuffer, paramOperation, paramOperation.getInput().getParts());
/*     */ 
/*     */     
/* 247 */     processConvenienceArgsParts(stringBuffer, paramOperation, getOutPartsWithoutInOuts(paramOperation));
/*     */ 
/*     */     
/* 250 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processConvenienceArgsParts(StringBuffer paramStringBuffer, Operation paramOperation, Iterator paramIterator) throws ScriptException {
/* 256 */     while (paramIterator.hasNext()) {
/* 257 */       Part part = (Part)paramIterator.next();
/*     */       
/* 259 */       if (part.isBody()) {
/* 260 */         Iterator iterator = getNameAndTypesFromPart(part);
/*     */         
/* 262 */         while (iterator.hasNext()) {
/* 263 */           if (paramStringBuffer.length() != 0) {
/* 264 */             paramStringBuffer.append(", ");
/*     */           }
/* 266 */           Object[] arrayOfObject = (Object[])iterator.next();
/* 267 */           paramStringBuffer.append(getJavaTypeName((Class)arrayOfObject[1]));
/* 268 */           paramStringBuffer.append(" ");
/* 269 */           paramStringBuffer.append((String)arrayOfObject[0]);
/*     */         } 
/*     */         continue;
/*     */       } 
/* 273 */       if (paramStringBuffer.length() != 0) {
/* 274 */         paramStringBuffer.append(", ");
/*     */       }
/*     */       
/* 277 */       String str = null;
/* 278 */       if (useHolderClass(paramOperation, part)) {
/* 279 */         str = getJavaTypeHolderName(part);
/*     */       } else {
/* 281 */         str = getJavaTypeName(part.getJavaType());
/*     */       } 
/*     */       
/* 284 */       paramStringBuffer.append(str).append(" ");
/* 285 */       paramStringBuffer.append(getJavaName(part.getName()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAsyncConvenienceArgs(Operation paramOperation) {
/* 293 */     String str = getConvenienceArgs(paramOperation);
/*     */     
/* 295 */     if (str.trim().length() != 0) {
/* 296 */       str = str + ", ";
/*     */     }
/*     */     
/* 299 */     return str + "weblogic.webservice.async.AsyncInfo asyncInfo";
/*     */   }
/*     */   
/*     */   public String getAsyncArgStatement(Operation paramOperation) {
/* 303 */     String str = getArgStatement(paramOperation);
/*     */     
/* 305 */     if (str.trim().length() != 0) {
/* 306 */       str = str + ", ";
/*     */     }
/*     */     
/* 309 */     return str + "weblogic.webservice.async.AsyncInfo asyncInfo";
/*     */   }
/*     */   
/*     */   public String getArgStatement(Operation paramOperation) {
/* 313 */     if (paramOperation.getParameterOrder() == null || paramOperation.getParameterOrder().length == 0)
/*     */     {
/*     */       
/* 316 */       return getArgStatementWithOutParamOrder(paramOperation);
/*     */     }
/* 318 */     return getArgStatementWithParamOrder(paramOperation);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getArgStatementWithParamOrder(Operation paramOperation) {
/* 323 */     String[] arrayOfString = paramOperation.getParameterOrder();
/*     */     
/* 325 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 327 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 328 */       Part part = paramOperation.getInput().getPart(arrayOfString[b]);
/*     */       
/* 330 */       if (part == null) {
/* 331 */         part = paramOperation.getOutput().getPart(arrayOfString[b]);
/*     */       }
/*     */       
/* 334 */       if (part == null) {
/* 335 */         throw new JAXRPCException(arrayOfString[b] + ": in paramOrder is not " + "a part");
/*     */       }
/*     */ 
/*     */       
/* 339 */       if (part.getMode() != Part.Mode.RETURN) {
/*     */         String str;
/*     */ 
/*     */         
/* 343 */         if (b) {
/* 344 */           stringBuffer.append(", ");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 349 */         if (paramOperation.isRpcStyle() && (part.getMode() == Part.Mode.OUT || part.getMode() == Part.Mode.INOUT)) {
/*     */ 
/*     */           
/* 352 */           str = getJavaTypeHolderName(part);
/*     */         } else {
/* 354 */           str = getJavaTypeName(part.getJavaType());
/*     */         } 
/*     */         
/* 357 */         stringBuffer.append(str).append(" ");
/* 358 */         stringBuffer.append(getJavaName(part.getName()));
/*     */       } 
/*     */     } 
/* 361 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean useHolderClass(Operation paramOperation, Part paramPart) {
/* 366 */     if (paramPart.isHeader()) {
/* 367 */       if (paramPart.getMode() == Part.Mode.INOUT || paramPart.getMode() == Part.Mode.OUT)
/*     */       {
/* 369 */         return true;
/*     */       
/*     */       }
/*     */     }
/* 373 */     else if (paramOperation.isRpcStyle() && (
/* 374 */       paramPart.getMode() == Part.Mode.INOUT || paramPart.getMode() == Part.Mode.OUT)) {
/*     */       
/* 376 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 381 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getArgStatementWithOutParamOrder(Operation paramOperation) {
/* 397 */     StringBuffer stringBuffer = new StringBuffer();
/* 398 */     boolean bool = true;
/*     */     Iterator iterator;
/* 400 */     for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
/* 401 */       String str; Part part = (Part)iterator.next();
/*     */       
/* 403 */       if (bool) {
/* 404 */         bool = false;
/*     */       } else {
/* 406 */         stringBuffer.append(", ");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 412 */       if (useHolderClass(paramOperation, part)) {
/* 413 */         str = getJavaTypeHolderName(part);
/*     */       } else {
/* 415 */         str = getJavaTypeName(part.getJavaType());
/*     */       } 
/*     */       
/* 418 */       stringBuffer.append(str).append(" ");
/* 419 */       stringBuffer.append(getJavaName(part.getName()));
/*     */     } 
/*     */     
/* 422 */     for (iterator = getOutPartsWithoutInOuts(paramOperation); iterator.hasNext(); ) {
/* 423 */       Part part = (Part)iterator.next();
/*     */       
/* 425 */       if (bool) {
/* 426 */         bool = false;
/*     */       } else {
/* 428 */         stringBuffer.append(", ");
/*     */       } 
/*     */       
/* 431 */       String str = getJavaTypeHolderName(part);
/*     */       
/* 433 */       stringBuffer.append(str).append(" ");
/* 434 */       stringBuffer.append(getJavaName(part.getName()));
/*     */     } 
/*     */     
/* 437 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public Iterator getOutPartsWithoutInOuts(Operation paramOperation) {
/* 441 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 443 */     for (Iterator iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/* 444 */       Part part = (Part)iterator.next();
/*     */       
/* 446 */       if (part.getMode() == Part.Mode.OUT) {
/* 447 */         arrayList.add(part);
/*     */       }
/*     */     } 
/*     */     
/* 451 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   public boolean isOutputPart(String paramString, Operation paramOperation) {
/* 455 */     Part part = paramOperation.getOutput().getPart(paramString);
/* 456 */     return !(part == null);
/*     */   }
/*     */   
/*     */   public boolean isInputPart(String paramString, Operation paramOperation) {
/* 460 */     Part part = paramOperation.getInput().getPart(paramString);
/* 461 */     return !(part == null);
/*     */   }
/*     */   
/*     */   public Iterator getAllParamParts(Operation paramOperation) {
/* 465 */     ArrayList arrayList = new ArrayList();
/*     */     Iterator iterator;
/* 467 */     for (iterator = paramOperation.getInput().getParts(); iterator.hasNext();) {
/* 468 */       arrayList.add(iterator.next());
/*     */     }
/*     */     
/* 471 */     for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
/* 472 */       Part part = (Part)iterator.next();
/*     */       
/* 474 */       if (part.getMode() == Part.Mode.OUT) {
/* 475 */         arrayList.add(part);
/*     */       }
/*     */     } 
/*     */     
/* 479 */     return arrayList.iterator();
/*     */   }
/*     */ 
/*     */   
/* 483 */   public Part getReturnPart(Operation paramOperation) { return paramOperation.getReturnPart(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaTypeHolderName(Part paramPart) throws ScriptException {
/* 489 */     TypeMapping typeMapping = (TypeMapping)paramPart.getTypeMapping();
/*     */     
/*     */     try {
/* 492 */       Class clazz = typeMapping.getHolderClass(paramPart.getJavaType(), paramPart.getXMLType());
/*     */       
/* 494 */       return getJavaTypeName(clazz);
/* 495 */     } catch (IOException iOException) {
/* 496 */       throw new JAXRPCException("unable to find holder class", iOException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getTypeFromPart(Part paramPart) throws ScriptException {
/* 501 */     if (paramPart == null) {
/* 502 */       return "void";
/*     */     }
/*     */     
/* 505 */     return getJavaTypeName(paramPart.getJavaType());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getJavaTypeName(Class paramClass) {
/* 510 */     if (paramClass == null) {
/* 511 */       return "void";
/*     */     }
/*     */     
/* 514 */     byte b1 = 0;
/*     */     
/* 516 */     while (paramClass.isArray()) {
/* 517 */       b1++;
/* 518 */       paramClass = paramClass.getComponentType();
/*     */     } 
/*     */     
/* 521 */     String str = paramClass.getName();
/*     */     
/* 523 */     for (byte b2 = 0; b2 < b1; b2++) {
/* 524 */       str = str + "[]";
/*     */     }
/*     */     
/* 527 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWriteConvenienceMethod(Operation paramOperation) throws ScriptException {
/* 533 */     if (paramOperation.isRpcStyle()) {
/* 534 */       return false;
/*     */     }
/*     */     
/* 537 */     if (!onlyOneBodyPart(paramOperation.getInput())) {
/* 538 */       return false;
/*     */     }
/*     */     
/* 541 */     if (!onlyOneBodyPart(paramOperation.getOutput())) {
/* 542 */       return false;
/*     */     }
/*     */     
/* 545 */     if (!isSinglePropertyOutBean(paramOperation)) {
/* 546 */       return false;
/*     */     }
/*     */     
/* 549 */     if (!isSimpleBean(getBodyPart(paramOperation.getInput()))) {
/* 550 */       return false;
/*     */     }
/*     */     
/* 553 */     if (!isSimpleBean(getBodyPart(paramOperation.getOutput()))) {
/* 554 */       return false;
/*     */     }
/*     */     
/* 557 */     return true;
/*     */   }
/*     */ 
/*     */   
/* 561 */   public String getJAXRPCClassName(String paramString) { return NameUtil.getJAXRPCClassName(paramString); }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJAXRPCMethodName(String paramString) {
/* 566 */     if (!this.useLowerCaseMethodNames) {
/* 567 */       return paramString;
/*     */     }
/* 569 */     return NameUtil.getJAXRPCMethodName(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSimpleBean(Part paramPart) {
/* 574 */     if (paramPart == null) {
/* 575 */       return true;
/*     */     }
/*     */     
/* 578 */     Class clazz = paramPart.getJavaType();
/*     */     
/* 580 */     if (clazz.isArray() || clazz.isPrimitive() || clazz.isAssignableFrom(Number.class) || clazz == String.class || !canNewInstance(clazz))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 586 */       return false;
/*     */     }
/*     */     
/* 589 */     return true;
/*     */   }
/*     */   
/*     */   private boolean canNewInstance(Class paramClass) {
/*     */     try {
/* 594 */       paramClass.newInstance();
/* 595 */     } catch (java.lang.Exception exception) {
/* 596 */       return false;
/*     */     } 
/*     */     
/* 599 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Part getBodyPart(Message paramMessage) {
/* 606 */     Iterator iterator = paramMessage.getParts();
/* 607 */     Part part = null;
/*     */     
/* 609 */     while (iterator.hasNext()) {
/* 610 */       Part part1 = (Part)iterator.next();
/* 611 */       if (part1.isBody()) return part1; 
/* 612 */       if (part1.isAttachment())
/*     */       {
/* 614 */         part = part1;
/*     */       }
/*     */     } 
/*     */     
/* 618 */     return part;
/*     */   }
/*     */   
/*     */   private boolean onlyOneBodyPart(Message paramMessage) {
/* 622 */     Iterator iterator = paramMessage.getParts();
/* 623 */     boolean bool = false;
/*     */     
/* 625 */     while (iterator.hasNext()) {
/* 626 */       Part part = (Part)iterator.next();
/* 627 */       if (part.isBody()) {
/* 628 */         if (bool) {
/* 629 */           return false;
/*     */         }
/* 631 */         bool = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 636 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSinglePropertyOutBean(Operation paramOperation) throws ScriptException {
/* 642 */     Part part = getReturnPart(paramOperation);
/*     */     
/* 644 */     if (part == null) {
/* 645 */       return false;
/*     */     }
/*     */     
/* 648 */     String str = getReturnTypeFromBean(part.getJavaType());
/*     */     
/* 650 */     return !(str == null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getReturnTypeFromBean(Class paramClass) {
/* 656 */     Iterator iterator = getNameAndTypes(paramClass);
/*     */     
/* 658 */     if (iterator.hasNext()) {
/* 659 */       Object[] arrayOfObject = (Object[])iterator.next();
/*     */       
/* 661 */       if (iterator.hasNext()) {
/* 662 */         return null;
/*     */       }
/* 664 */       return getJavaTypeName((Class)arrayOfObject[1]);
/*     */     } 
/*     */ 
/*     */     
/* 668 */     return "void";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getNameAndTypesFromPart(Part paramPart) throws ScriptException {
/* 674 */     TypeMapping typeMapping = paramPart.getTypeMapping();
/* 675 */     SerializerFactory serializerFactory = typeMapping.getSerializer(paramPart.getJavaType(), paramPart.getXMLType());
/*     */ 
/*     */     
/* 678 */     Serializer serializer = serializerFactory.getSerializerAs("stream");
/*     */     
/* 680 */     if (serializer instanceof CodecPropertyInfo) {
/* 681 */       CodecPropertyInfo codecPropertyInfo = (CodecPropertyInfo)serializer;
/*     */       
/* 683 */       ArrayList arrayList = new ArrayList();
/*     */       
/* 685 */       for (byte b = 0; b < codecPropertyInfo.getPropertyCount(); b++) {
/* 686 */         PropertyInfo propertyInfo = codecPropertyInfo.getPropertyInfo(b);
/* 687 */         arrayList.add(new Object[] { propertyInfo.getJavaName(), propertyInfo.getJavaType() });
/*     */       } 
/*     */       
/* 690 */       return arrayList.iterator();
/*     */     } 
/* 692 */     return getNameAndTypes(paramPart.getJavaType());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Iterator getNameAndTypes(Class paramClass) throws ScriptException {
/*     */     BeanInfo beanInfo;
/*     */     try {
/* 700 */       beanInfo = Introspector.getBeanInfo(paramClass);
/* 701 */     } catch (IntrospectionException introspectionException) {
/* 702 */       throw new ScriptException("unable to interospect bean:" + introspectionException);
/*     */     } 
/*     */     
/* 705 */     PropertyDescriptor[] arrayOfPropertyDescriptor = beanInfo.getPropertyDescriptors();
/*     */     
/* 707 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 709 */     for (byte b = 0; b < arrayOfPropertyDescriptor.length; b++) {
/* 710 */       if (!"class".equals(arrayOfPropertyDescriptor[b].getName())) {
/*     */ 
/*     */ 
/*     */         
/* 714 */         Method method = arrayOfPropertyDescriptor[b].getReadMethod();
/*     */         
/* 716 */         arrayList.add(new Object[] { arrayOfPropertyDescriptor[b].getName(), method.getReturnType() });
/*     */       } 
/*     */     } 
/*     */     
/* 720 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   public String makeFirstCharBig(String paramString) {
/* 724 */     if (paramString.length() > 0) {
/* 725 */       char c = paramString.charAt(0);
/* 726 */       paramString = Character.toUpperCase(c) + paramString.substring(1, paramString.length());
/*     */     } 
/*     */     
/* 729 */     return paramString;
/*     */   }
/*     */   
/*     */   public String getReturnStatement(Part paramPart) throws ScriptException {
/*     */     String str2;
/* 734 */     if (paramPart == null) {
/* 735 */       return "";
/*     */     }
/*     */     
/* 738 */     String str1 = getTypeFromPart(paramPart);
/*     */     
/* 740 */     if ("void".equals(str1)) {
/* 741 */       return "";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 746 */     if (str1.equals("int")) {
/* 747 */       str2 = "((java.lang.Integer)_result).intValue();";
/* 748 */     } else if (str1.equals("float")) {
/* 749 */       str2 = "((java.lang.Float)_result).floatValue();";
/* 750 */     } else if (str1.equals("long")) {
/* 751 */       str2 = "((java.lang.Long)_result).longValue();";
/* 752 */     } else if (str1.equals("double")) {
/* 753 */       str2 = "((java.lang.Double)_result).doubleValue();";
/* 754 */     } else if (str1.equals("short")) {
/* 755 */       str2 = "((java.lang.Short)_result).shortValue();";
/* 756 */     } else if (str1.equals("boolean")) {
/* 757 */       str2 = "((java.lang.Boolean)_result).booleanValue();";
/* 758 */     } else if (str1.equals("char")) {
/* 759 */       str2 = "((java.lang.Character)_result).charValue();";
/* 760 */     } else if (str1.equals("byte")) {
/* 761 */       str2 = "((java.lang.Byte)_result).byteValue();";
/*     */     } else {
/* 763 */       str2 = "(" + str1 + ")_result;";
/*     */     } 
/*     */     
/* 766 */     return "return " + str2 + "\n";
/*     */   }
/*     */   
/*     */   public static String getJavaName(String paramString) {
/* 770 */     boolean bool = Character.isLowerCase(paramString.charAt(0));
/* 771 */     String str = NameUtil.getJavaName(paramString);
/*     */     
/* 773 */     if (bool) {
/* 774 */       return NameUtil.lowercaseFirstLetter(str);
/*     */     }
/* 776 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\StubGenHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */