package weblogic.webservice.tools.stubgen;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.Serializer;
import javax.xml.rpc.encoding.SerializerFactory;
import javax.xml.rpc.encoding.TypeMapping;
import weblogic.webservice.Message;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;
import weblogic.webservice.util.jspgen.ScriptException;
import weblogic.xml.schema.binding.CodecPropertyInfo;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.internal.NameUtil;
import weblogic.xml.schema.binding.util.runtime.PropertyInfo;

public class StubGenHelper {
  private boolean usePortNameAsMethodName = false;
  
  private boolean isJ2MEClient = false;
  
  private boolean useLowerCaseMethodNames = false;
  
  private String packageName;
  
  public void setJ2MEClient(boolean paramBoolean) { this.isJ2MEClient = paramBoolean; }
  
  public void setUseLowerCaseMethodNames(boolean paramBoolean) { this.useLowerCaseMethodNames = paramBoolean; }
  
  public void setUsePortNameAsMethodName(boolean paramBoolean) { this.usePortNameAsMethodName = paramBoolean; }
  
  public void setPackageName(String paramString) { this.packageName = paramString; }
  
  public String getPortName(Port paramPort) {
    if (this.usePortNameAsMethodName)
      return paramPort.getName().replace('.', '_'); 
    return paramPort.getTypeName().replace('.', '_');
  }
  
  public String getThrowJAXRPCException() {
    if (this.isJ2MEClient)
      return "throw e;"; 
    return "throw new java.rmi.RemoteException( e.getMessage(), e.getLinkedCause() );\n";
  }
  
  public String getThrowAllException() {
    if (this.isJ2MEClient)
      return "throw new javax.xml.rpc.JAXRPCException(e);"; 
    return "throw new java.rmi.RemoteException( e.getMessage(), e );";
  }
  
  public String getThrowCustomerException(Operation paramOperation) {
    StringBuffer stringBuffer = new StringBuffer();
    HashSet hashSet = new HashSet();
    Iterator iterator;
    label24: for (iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
      Message message = (Message)iterator.next();
      String str = getFaultName(message);
      if ("java.lang.Exception".equals(str) || "Exception".equals(str))
        continue; 
      Part part = (Part)message.getParts().next();
      for (Iterator iterator1 = hashSet.iterator(); iterator1.hasNext();) {
        if (((Class)iterator1.next()).isAssignableFrom(part.getJavaType()))
          continue label24; 
      } 
      if (java.lang.Exception.class.isAssignableFrom(part.getJavaType()))
        hashSet.add(part.getJavaType()); 
      char c1 = '{';
      char c2 = '}';
      stringBuffer.append("\n    " + c2 + " catch (" + str + " e) ");
      stringBuffer.append("" + c1 + "\n");
      stringBuffer.append("      throw e;");
    } 
    if (stringBuffer.length() > 0)
      stringBuffer.append("\n"); 
    return stringBuffer.toString();
  }
  
  public String getThrowSOAPFaultException(Operation paramOperation) {
    if (this.isJ2MEClient)
      return "throw e;"; 
    return "throw new java.rmi.RemoteException( \"SOAP Fault:\" + e + \"\\nDetail:\\n\"+e.getDetail(), e );\n";
  }
  
  public boolean isTrue(String paramString) { return "true".equals(paramString); }
  
  public String throwException(Operation paramOperation) {
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool = false;
    for (Iterator iterator = paramOperation.getFaults(); iterator.hasNext(); ) {
      Message message = (Message)iterator.next();
      if ("java.lang.Exception".equals(getFaultName(message)) || "Exception".equals(getFaultName(message)))
        continue; 
      if (!bool) {
        bool = true;
        stringBuffer.append("throws " + getFaultName(message));
        continue;
      } 
      stringBuffer.append(", " + getFaultName(message));
    } 
    if (!this.isJ2MEClient)
      if (bool) {
        stringBuffer.append(", java.rmi.RemoteException ");
      } else {
        stringBuffer.append("throws java.rmi.RemoteException ");
      }  
    return stringBuffer.toString();
  }
  
  private String getFaultName(Message paramMessage) {
    Part part = (Part)paramMessage.getParts().next();
    String str = null;
    if (java.lang.Exception.class.isAssignableFrom(part.getJavaType())) {
      str = part.getJavaType().getName();
    } else {
      str = this.packageName + "." + NameUtil.getJAXRPCClassName(paramMessage.getName());
    } 
    return str;
  }
  
  public String extendsRemote() { return this.isJ2MEClient ? "" : " extends java.rmi.Remote"; }
  
  public String setConvenienceArgs(Part paramPart) throws ScriptException {
    Iterator iterator = getNameAndTypesFromPart(paramPart);
    StringBuffer stringBuffer = new StringBuffer();
    while (iterator.hasNext()) {
      Object[] arrayOfObject = (Object[])iterator.next();
      stringBuffer.append("    ");
      stringBuffer.append("_input.set");
      stringBuffer.append(makeFirstCharBig((String)arrayOfObject[0]));
      stringBuffer.append("( ");
      stringBuffer.append((String)arrayOfObject[0]);
      stringBuffer.append(" );\n");
    } 
    return stringBuffer.toString();
  }
  
  public String getHeaderConvenienceArgNames(Operation paramOperation) {
    StringBuffer stringBuffer = new StringBuffer();
    Iterator iterator;
    for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.isHeader()) {
        if (stringBuffer.length() != 0)
          stringBuffer.append(", "); 
        stringBuffer.append(getJavaName(part.getName()));
      } 
    } 
    for (iterator = getOutPartsWithoutInOuts(paramOperation); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.isHeader()) {
        if (stringBuffer.length() != 0)
          stringBuffer.append(", "); 
        stringBuffer.append(getJavaName(part.getName()));
      } 
    } 
    if (stringBuffer.length() > 0)
      return ", " + stringBuffer.toString(); 
    return "";
  }
  
  public String getConvenienceArgs(Operation paramOperation) {
    StringBuffer stringBuffer = new StringBuffer();
    processConvenienceArgsParts(stringBuffer, paramOperation, paramOperation.getInput().getParts());
    processConvenienceArgsParts(stringBuffer, paramOperation, getOutPartsWithoutInOuts(paramOperation));
    return stringBuffer.toString();
  }
  
  private void processConvenienceArgsParts(StringBuffer paramStringBuffer, Operation paramOperation, Iterator paramIterator) throws ScriptException {
    while (paramIterator.hasNext()) {
      Part part = (Part)paramIterator.next();
      if (part.isBody()) {
        Iterator iterator = getNameAndTypesFromPart(part);
        while (iterator.hasNext()) {
          if (paramStringBuffer.length() != 0)
            paramStringBuffer.append(", "); 
          Object[] arrayOfObject = (Object[])iterator.next();
          paramStringBuffer.append(getJavaTypeName((Class)arrayOfObject[1]));
          paramStringBuffer.append(" ");
          paramStringBuffer.append((String)arrayOfObject[0]);
        } 
        continue;
      } 
      if (paramStringBuffer.length() != 0)
        paramStringBuffer.append(", "); 
      String str = null;
      if (useHolderClass(paramOperation, part)) {
        str = getJavaTypeHolderName(part);
      } else {
        str = getJavaTypeName(part.getJavaType());
      } 
      paramStringBuffer.append(str).append(" ");
      paramStringBuffer.append(getJavaName(part.getName()));
    } 
  }
  
  public String getAsyncConvenienceArgs(Operation paramOperation) {
    String str = getConvenienceArgs(paramOperation);
    if (str.trim().length() != 0)
      str = str + ", "; 
    return str + "weblogic.webservice.async.AsyncInfo asyncInfo";
  }
  
  public String getAsyncArgStatement(Operation paramOperation) {
    String str = getArgStatement(paramOperation);
    if (str.trim().length() != 0)
      str = str + ", "; 
    return str + "weblogic.webservice.async.AsyncInfo asyncInfo";
  }
  
  public String getArgStatement(Operation paramOperation) {
    if (paramOperation.getParameterOrder() == null || paramOperation.getParameterOrder().length == 0)
      return getArgStatementWithOutParamOrder(paramOperation); 
    return getArgStatementWithParamOrder(paramOperation);
  }
  
  public String getArgStatementWithParamOrder(Operation paramOperation) {
    String[] arrayOfString = paramOperation.getParameterOrder();
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < arrayOfString.length; b++) {
      Part part = paramOperation.getInput().getPart(arrayOfString[b]);
      if (part == null)
        part = paramOperation.getOutput().getPart(arrayOfString[b]); 
      if (part == null)
        throw new JAXRPCException(arrayOfString[b] + ": in paramOrder is not " + "a part"); 
      if (part.getMode() != Part.Mode.RETURN) {
        String str;
        if (b)
          stringBuffer.append(", "); 
        if (paramOperation.isRpcStyle() && (part.getMode() == Part.Mode.OUT || part.getMode() == Part.Mode.INOUT)) {
          str = getJavaTypeHolderName(part);
        } else {
          str = getJavaTypeName(part.getJavaType());
        } 
        stringBuffer.append(str).append(" ");
        stringBuffer.append(getJavaName(part.getName()));
      } 
    } 
    return stringBuffer.toString();
  }
  
  boolean useHolderClass(Operation paramOperation, Part paramPart) {
    if (paramPart.isHeader()) {
      if (paramPart.getMode() == Part.Mode.INOUT || paramPart.getMode() == Part.Mode.OUT)
        return true; 
    } else if (paramOperation.isRpcStyle() && (
      paramPart.getMode() == Part.Mode.INOUT || paramPart.getMode() == Part.Mode.OUT)) {
      return true;
    } 
    return false;
  }
  
  public String getArgStatementWithOutParamOrder(Operation paramOperation) {
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool = true;
    Iterator iterator;
    for (iterator = paramOperation.getInput().getParts(); iterator.hasNext(); ) {
      String str;
      Part part = (Part)iterator.next();
      if (bool) {
        bool = false;
      } else {
        stringBuffer.append(", ");
      } 
      if (useHolderClass(paramOperation, part)) {
        str = getJavaTypeHolderName(part);
      } else {
        str = getJavaTypeName(part.getJavaType());
      } 
      stringBuffer.append(str).append(" ");
      stringBuffer.append(getJavaName(part.getName()));
    } 
    for (iterator = getOutPartsWithoutInOuts(paramOperation); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (bool) {
        bool = false;
      } else {
        stringBuffer.append(", ");
      } 
      String str = getJavaTypeHolderName(part);
      stringBuffer.append(str).append(" ");
      stringBuffer.append(getJavaName(part.getName()));
    } 
    return stringBuffer.toString();
  }
  
  public Iterator getOutPartsWithoutInOuts(Operation paramOperation) {
    ArrayList arrayList = new ArrayList();
    for (Iterator iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.OUT)
        arrayList.add(part); 
    } 
    return arrayList.iterator();
  }
  
  public boolean isOutputPart(String paramString, Operation paramOperation) {
    Part part = paramOperation.getOutput().getPart(paramString);
    return !(part == null);
  }
  
  public boolean isInputPart(String paramString, Operation paramOperation) {
    Part part = paramOperation.getInput().getPart(paramString);
    return !(part == null);
  }
  
  public Iterator getAllParamParts(Operation paramOperation) {
    ArrayList arrayList = new ArrayList();
    Iterator iterator;
    for (iterator = paramOperation.getInput().getParts(); iterator.hasNext();)
      arrayList.add(iterator.next()); 
    for (iterator = paramOperation.getOutput().getParts(); iterator.hasNext(); ) {
      Part part = (Part)iterator.next();
      if (part.getMode() == Part.Mode.OUT)
        arrayList.add(part); 
    } 
    return arrayList.iterator();
  }
  
  public Part getReturnPart(Operation paramOperation) { return paramOperation.getReturnPart(); }
  
  public String getJavaTypeHolderName(Part paramPart) throws ScriptException {
    TypeMapping typeMapping = (TypeMapping)paramPart.getTypeMapping();
    try {
      Class clazz = typeMapping.getHolderClass(paramPart.getJavaType(), paramPart.getXMLType());
      return getJavaTypeName(clazz);
    } catch (IOException iOException) {
      throw new JAXRPCException("unable to find holder class", iOException);
    } 
  }
  
  public String getTypeFromPart(Part paramPart) throws ScriptException {
    if (paramPart == null)
      return "void"; 
    return getJavaTypeName(paramPart.getJavaType());
  }
  
  public String getJavaTypeName(Class paramClass) {
    if (paramClass == null)
      return "void"; 
    byte b1 = 0;
    while (paramClass.isArray()) {
      b1++;
      paramClass = paramClass.getComponentType();
    } 
    String str = paramClass.getName();
    for (byte b2 = 0; b2 < b1; b2++)
      str = str + "[]"; 
    return str;
  }
  
  public boolean canWriteConvenienceMethod(Operation paramOperation) throws ScriptException {
    if (paramOperation.isRpcStyle())
      return false; 
    if (!onlyOneBodyPart(paramOperation.getInput()))
      return false; 
    if (!onlyOneBodyPart(paramOperation.getOutput()))
      return false; 
    if (!isSinglePropertyOutBean(paramOperation))
      return false; 
    if (!isSimpleBean(getBodyPart(paramOperation.getInput())))
      return false; 
    if (!isSimpleBean(getBodyPart(paramOperation.getOutput())))
      return false; 
    return true;
  }
  
  public String getJAXRPCClassName(String paramString) { return NameUtil.getJAXRPCClassName(paramString); }
  
  public String getJAXRPCMethodName(String paramString) {
    if (!this.useLowerCaseMethodNames)
      return paramString; 
    return NameUtil.getJAXRPCMethodName(paramString);
  }
  
  private boolean isSimpleBean(Part paramPart) {
    if (paramPart == null)
      return true; 
    Class clazz = paramPart.getJavaType();
    if (clazz.isArray() || clazz.isPrimitive() || clazz.isAssignableFrom(Number.class) || clazz == String.class || !canNewInstance(clazz))
      return false; 
    return true;
  }
  
  private boolean canNewInstance(Class paramClass) {
    try {
      paramClass.newInstance();
    } catch (java.lang.Exception exception) {
      return false;
    } 
    return true;
  }
  
  public Part getBodyPart(Message paramMessage) {
    Iterator iterator = paramMessage.getParts();
    Part part = null;
    while (iterator.hasNext()) {
      Part part1 = (Part)iterator.next();
      if (part1.isBody())
        return part1; 
      if (part1.isAttachment())
        part = part1; 
    } 
    return part;
  }
  
  private boolean onlyOneBodyPart(Message paramMessage) {
    Iterator iterator = paramMessage.getParts();
    boolean bool = false;
    while (iterator.hasNext()) {
      Part part = (Part)iterator.next();
      if (part.isBody()) {
        if (bool)
          return false; 
        bool = true;
      } 
    } 
    return true;
  }
  
  public boolean isSinglePropertyOutBean(Operation paramOperation) throws ScriptException {
    Part part = getReturnPart(paramOperation);
    if (part == null)
      return false; 
    String str = getReturnTypeFromBean(part.getJavaType());
    return !(str == null);
  }
  
  public String getReturnTypeFromBean(Class paramClass) {
    Iterator iterator = getNameAndTypes(paramClass);
    if (iterator.hasNext()) {
      Object[] arrayOfObject = (Object[])iterator.next();
      if (iterator.hasNext())
        return null; 
      return getJavaTypeName((Class)arrayOfObject[1]);
    } 
    return "void";
  }
  
  public Iterator getNameAndTypesFromPart(Part paramPart) throws ScriptException {
    TypeMapping typeMapping = paramPart.getTypeMapping();
    SerializerFactory serializerFactory = typeMapping.getSerializer(paramPart.getJavaType(), paramPart.getXMLType());
    Serializer serializer = serializerFactory.getSerializerAs("stream");
    if (serializer instanceof CodecPropertyInfo) {
      CodecPropertyInfo codecPropertyInfo = (CodecPropertyInfo)serializer;
      ArrayList arrayList = new ArrayList();
      for (byte b = 0; b < codecPropertyInfo.getPropertyCount(); b++) {
        PropertyInfo propertyInfo = codecPropertyInfo.getPropertyInfo(b);
        arrayList.add(new Object[] { propertyInfo.getJavaName(), propertyInfo.getJavaType() });
      } 
      return arrayList.iterator();
    } 
    return getNameAndTypes(paramPart.getJavaType());
  }
  
  private Iterator getNameAndTypes(Class paramClass) throws ScriptException {
    BeanInfo beanInfo;
    try {
      beanInfo = Introspector.getBeanInfo(paramClass);
    } catch (IntrospectionException introspectionException) {
      throw new ScriptException("unable to interospect bean:" + introspectionException);
    } 
    PropertyDescriptor[] arrayOfPropertyDescriptor = beanInfo.getPropertyDescriptors();
    ArrayList arrayList = new ArrayList();
    for (byte b = 0; b < arrayOfPropertyDescriptor.length; b++) {
      if (!"class".equals(arrayOfPropertyDescriptor[b].getName())) {
        Method method = arrayOfPropertyDescriptor[b].getReadMethod();
        arrayList.add(new Object[] { arrayOfPropertyDescriptor[b].getName(), method.getReturnType() });
      } 
    } 
    return arrayList.iterator();
  }
  
  public String makeFirstCharBig(String paramString) {
    if (paramString.length() > 0) {
      char c = paramString.charAt(0);
      paramString = Character.toUpperCase(c) + paramString.substring(1, paramString.length());
    } 
    return paramString;
  }
  
  public String getReturnStatement(Part paramPart) throws ScriptException {
    String str2;
    if (paramPart == null)
      return ""; 
    String str1 = getTypeFromPart(paramPart);
    if ("void".equals(str1))
      return ""; 
    if (str1.equals("int")) {
      str2 = "((java.lang.Integer)_result).intValue();";
    } else if (str1.equals("float")) {
      str2 = "((java.lang.Float)_result).floatValue();";
    } else if (str1.equals("long")) {
      str2 = "((java.lang.Long)_result).longValue();";
    } else if (str1.equals("double")) {
      str2 = "((java.lang.Double)_result).doubleValue();";
    } else if (str1.equals("short")) {
      str2 = "((java.lang.Short)_result).shortValue();";
    } else if (str1.equals("boolean")) {
      str2 = "((java.lang.Boolean)_result).booleanValue();";
    } else if (str1.equals("char")) {
      str2 = "((java.lang.Character)_result).charValue();";
    } else if (str1.equals("byte")) {
      str2 = "((java.lang.Byte)_result).byteValue();";
    } else {
      str2 = "(" + str1 + ")_result;";
    } 
    return "return " + str2 + "\n";
  }
  
  public static String getJavaName(String paramString) {
    boolean bool = Character.isLowerCase(paramString.charAt(0));
    String str = NameUtil.getJavaName(paramString);
    if (bool)
      return NameUtil.lowercaseFirstLetter(str); 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\StubGenHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */