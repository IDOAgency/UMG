/*    */ package weblogic.webservice.tools.stubgen;
/*    */ 
/*    */ import weblogic.webservice.Port;
/*    */ import weblogic.webservice.WebService;
/*    */ import weblogic.webservice.util.jspgen.JspGenBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServiceBase
/*    */   extends JspGenBase
/*    */ {
/*    */   protected StubGenHelper helper;
/* 14 */   protected String packageName = "examples.temp";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   protected String location = "http://you.forgot.to/set/wsdl/location/";
/*    */   protected WebService service;
/*    */   protected Port[] ports;
/*    */   
/* 27 */   void setHelper(StubGenHelper paramStubGenHelper) { this.helper = paramStubGenHelper; }
/*    */   
/*    */   protected Port port;
/*    */   
/* 31 */   public void setPackage(String paramString) { this.packageName = paramString; }
/*    */   
/*    */   protected String serviceName;
/*    */   
/* 35 */   public void setWSDLLocation(String paramString) { this.location = paramString; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\ServiceBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */