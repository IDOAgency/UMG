package weblogic.webservice.tools.stubgen;

import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.util.jspgen.JspGenBase;

public abstract class ServiceBase extends JspGenBase {
  protected StubGenHelper helper;
  
  protected String packageName = "examples.temp";
  
  protected String location = "http://you.forgot.to/set/wsdl/location/";
  
  protected WebService service;
  
  protected Port[] ports;
  
  protected Port port;
  
  protected String serviceName;
  
  void setHelper(StubGenHelper paramStubGenHelper) { this.helper = paramStubGenHelper; }
  
  public void setPackage(String paramString) { this.packageName = paramString; }
  
  public void setWSDLLocation(String paramString) { this.location = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\ServiceBase.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */