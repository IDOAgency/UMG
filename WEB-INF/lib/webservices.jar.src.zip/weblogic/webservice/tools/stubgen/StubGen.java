package weblogic.webservice.tools.stubgen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;
import weblogic.webservice.Port;
import weblogic.webservice.WebService;
import weblogic.webservice.util.jspgen.JspGenBase;

public abstract class StubGen extends JspGenBase {
  private String destDir;
  
  private Set generated = new HashSet();
  
  protected String packageName = "examples.temp";
  
  protected boolean writeInterface = false;
  
  protected StubGenHelper helper;
  
  protected WebService service;
  
  protected Port port;
  
  protected boolean generateAsyncMethods = false;
  
  protected boolean onlyConvenienceMethod = false;
  
  void setHelper(StubGenHelper paramStubGenHelper) { this.helper = paramStubGenHelper; }
  
  public void setOnlyConvenienceMethod(boolean paramBoolean) { this.onlyConvenienceMethod = paramBoolean; }
  
  public void setPackage(String paramString) { this.packageName = paramString; }
  
  public void setDestDir(String paramString) { this.destDir = paramString; }
  
  protected String firstLetterCap(String paramString) { return Character.toUpperCase(paramString.charAt(0)) + paramString.substring(1, paramString.length()); }
  
  public void visit(WebService paramWebService, Port paramPort) throws IOException {
    this.service = paramWebService;
    this.port = paramPort;
    PrintStream printStream = null;
    if (this.destDir != null) {
      String str1 = this.destDir + File.separator + this.packageName.replace('.', File.separatorChar);
      (new File(str1)).mkdirs();
      File file = null;
      String str2 = this.helper.getJAXRPCClassName(paramPort.getTypeName());
      if (this.writeInterface) {
        file = new File(str1, str2 + ".java");
      } else {
        file = new File(str1, str2 + "_Stub.java");
      } 
      this.generated.add(file.getAbsolutePath());
      printStream = new PrintStream(new FileOutputStream(file), true);
      setOutput(printStream);
    } 
    generate();
    if (printStream != null)
      printStream.close(); 
  }
  
  public Set getGenerated() { return this.generated; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\StubGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */