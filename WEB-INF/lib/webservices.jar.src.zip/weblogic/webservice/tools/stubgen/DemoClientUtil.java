package weblogic.webservice.tools.stubgen;

import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Iterator;
import javax.xml.rpc.JAXRPCException;
import weblogic.webservice.Operation;
import weblogic.webservice.Part;
import weblogic.webservice.Port;

public class DemoClientUtil {
  private StubGenHelper stubGenHelper = new StubGenHelper();
  
  private static final HashMap buildin = new HashMap();
  
  static  {
    buildin.put(int.class, "100");
    buildin.put(float.class, "10.1f");
    buildin.put(long.class, "1000");
    buildin.put(double.class, "20.2");
    buildin.put(short.class, "(short)10");
    buildin.put(boolean.class, "true");
    buildin.put(byte.class, "(byte)1");
    buildin.put(Integer.class, "new Integer(100)");
    buildin.put(Float.class, "new Float(10.1f)");
    buildin.put(Double.class, "new Double(20.2 )");
    buildin.put(Long.class, "new Long(1000)");
    buildin.put(Short.class, " new Short(10)");
    buildin.put(Boolean.class, "new Boolean(true)");
    buildin.put(String.class, "\"sample string\"");
    buildin.put(Byte.class, "new Byte(1)");
    buildin.put(java.util.Date.class, "new Date()");
    buildin.put(java.math.BigDecimal.class, "new java.math.BigDecimal(10000)");
    buildin.put(java.math.BigInteger.class, "new java.math.BigInteger(\"10000\")");
    buildin.put(java.util.Calendar.class, "java.util.Calendar.getInstance()");
  }
  
  public String getPortName(String paramString, Port paramPort) { return this.stubGenHelper.getPortName(paramPort); }
  
  public String getJAXRPCClassName(String paramString) { return this.stubGenHelper.getJAXRPCClassName(paramString); }
  
  public String getJAXRPCMethodName(String paramString, boolean paramBoolean) {
    this.stubGenHelper.setUseLowerCaseMethodNames(paramBoolean);
    return this.stubGenHelper.getJAXRPCMethodName(paramString);
  }
  
  public String getCallingParameters(Operation paramOperation) {
    if (paramOperation.getParameterOrder() == null || paramOperation.getParameterOrder().length == 0)
      return getArgStatementWithOutParamOrder(paramOperation); 
    return getArgStatementWithParamOrder(paramOperation);
  }
  
  public String getArgStatementWithParamOrder(Operation paramOperation) {
    String[] arrayOfString = paramOperation.getParameterOrder();
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < arrayOfString.length; b++) {
      Part part = paramOperation.getInput().getPart(arrayOfString[b]);
      if (part == null)
        part = paramOperation.getOutput().getPart(arrayOfString[b]); 
      if (part == null)
        throw new JAXRPCException(arrayOfString[b] + ": in paramOrder is not " + "a part"); 
      if (part.getMode() != Part.Mode.RETURN) {
        if (b)
          stringBuffer.append(", "); 
        if (paramOperation.isRpcStyle() && (part.getMode() == Part.Mode.OUT || part.getMode() == Part.Mode.INOUT)) {
          stringBuffer.append("new " + this.stubGenHelper.getJavaTypeHolderName(part) + "()");
        } else {
          stringBuffer.append(getArgString(part));
        } 
      } 
    } 
    return stringBuffer.toString();
  }
  
  public String getArgStatementWithOutParamOrder(Operation paramOperation) {
    Iterator iterator1 = paramOperation.getInput().getParts();
    StringBuffer stringBuffer = new StringBuffer();
    boolean bool = true;
    Iterator iterator2;
    for (iterator2 = paramOperation.getInput().getParts(); iterator2.hasNext(); ) {
      if (!bool)
        stringBuffer.append(", "); 
      Part part = (Part)iterator2.next();
      if (this.stubGenHelper.useHolderClass(paramOperation, part)) {
        String str = this.stubGenHelper.getJavaTypeHolderName(part);
        stringBuffer.append("new " + str + "()");
      } else {
        stringBuffer.append(getArgString(part));
      } 
      bool = false;
    } 
    for (iterator2 = this.stubGenHelper.getOutPartsWithoutInOuts(paramOperation); iterator2.hasNext(); ) {
      if (!bool)
        stringBuffer.append(", "); 
      Part part = (Part)iterator2.next();
      String str = this.stubGenHelper.getJavaTypeHolderName(part);
      stringBuffer.append("new " + str + "()");
      bool = false;
    } 
    return stringBuffer.toString();
  }
  
  private String getArgString(Part paramPart) {
    Class clazz = paramPart.getJavaType();
    Object object = buildin.get(clazz);
    if (object != null)
      return object.toString(); 
    if (clazz.isArray())
      return getArrayString(clazz); 
    if (isInstantiable(clazz))
      return "new " + clazz.getName() + "()"; 
    return "null";
  }
  
  private String getArrayString(Class paramClass) {
    Class clazz = paramClass.getComponentType();
    String str = "[]";
    while (clazz.isArray()) {
      clazz = clazz.getComponentType();
      str = str + "[]";
    } 
    return "new " + clazz.getName() + str + "{}";
  }
  
  private boolean isInstantiable(Class paramClass) {
    if (paramClass.isInterface())
      return false; 
    if (Modifier.isAbstract(paramClass.getModifiers()))
      return false; 
    try {
      paramClass.getConstructor(new Class[0]);
    } catch (NoSuchMethodException noSuchMethodException) {
      return false;
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\DemoClientUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */