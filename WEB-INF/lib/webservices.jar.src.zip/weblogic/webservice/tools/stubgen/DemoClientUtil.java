/*     */ package weblogic.webservice.tools.stubgen;
/*     */ 
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import weblogic.webservice.Operation;
/*     */ import weblogic.webservice.Part;
/*     */ import weblogic.webservice.Port;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DemoClientUtil
/*     */ {
/*  23 */   private StubGenHelper stubGenHelper = new StubGenHelper();
/*     */   
/*  25 */   private static final HashMap buildin = new HashMap();
/*     */   
/*     */   static  {
/*  28 */     buildin.put(int.class, "100");
/*  29 */     buildin.put(float.class, "10.1f");
/*  30 */     buildin.put(long.class, "1000");
/*  31 */     buildin.put(double.class, "20.2");
/*  32 */     buildin.put(short.class, "(short)10");
/*  33 */     buildin.put(boolean.class, "true");
/*  34 */     buildin.put(byte.class, "(byte)1");
/*  35 */     buildin.put(Integer.class, "new Integer(100)");
/*  36 */     buildin.put(Float.class, "new Float(10.1f)");
/*  37 */     buildin.put(Double.class, "new Double(20.2 )");
/*  38 */     buildin.put(Long.class, "new Long(1000)");
/*  39 */     buildin.put(Short.class, " new Short(10)");
/*  40 */     buildin.put(Boolean.class, "new Boolean(true)");
/*  41 */     buildin.put(String.class, "\"sample string\"");
/*  42 */     buildin.put(Byte.class, "new Byte(1)");
/*  43 */     buildin.put(java.util.Date.class, "new Date()");
/*  44 */     buildin.put(java.math.BigDecimal.class, "new java.math.BigDecimal(10000)");
/*  45 */     buildin.put(java.math.BigInteger.class, "new java.math.BigInteger(\"10000\")");
/*  46 */     buildin.put(java.util.Calendar.class, "java.util.Calendar.getInstance()");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  51 */   public String getPortName(String paramString, Port paramPort) { return this.stubGenHelper.getPortName(paramPort); }
/*     */ 
/*     */ 
/*     */   
/*  55 */   public String getJAXRPCClassName(String paramString) { return this.stubGenHelper.getJAXRPCClassName(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJAXRPCMethodName(String paramString, boolean paramBoolean) {
/*  61 */     this.stubGenHelper.setUseLowerCaseMethodNames(paramBoolean);
/*  62 */     return this.stubGenHelper.getJAXRPCMethodName(paramString);
/*     */   }
/*     */   
/*     */   public String getCallingParameters(Operation paramOperation) {
/*  66 */     if (paramOperation.getParameterOrder() == null || paramOperation.getParameterOrder().length == 0)
/*     */     {
/*     */       
/*  69 */       return getArgStatementWithOutParamOrder(paramOperation);
/*     */     }
/*  71 */     return getArgStatementWithParamOrder(paramOperation);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getArgStatementWithParamOrder(Operation paramOperation) {
/*  76 */     String[] arrayOfString = paramOperation.getParameterOrder();
/*     */     
/*  78 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*  80 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  81 */       Part part = paramOperation.getInput().getPart(arrayOfString[b]);
/*     */       
/*  83 */       if (part == null) {
/*  84 */         part = paramOperation.getOutput().getPart(arrayOfString[b]);
/*     */       }
/*     */       
/*  87 */       if (part == null) {
/*  88 */         throw new JAXRPCException(arrayOfString[b] + ": in paramOrder is not " + "a part");
/*     */       }
/*     */ 
/*     */       
/*  92 */       if (part.getMode() != Part.Mode.RETURN) {
/*     */ 
/*     */ 
/*     */         
/*  96 */         if (b) {
/*  97 */           stringBuffer.append(", ");
/*     */         }
/*     */         
/* 100 */         if (paramOperation.isRpcStyle() && (part.getMode() == Part.Mode.OUT || part.getMode() == Part.Mode.INOUT)) {
/*     */ 
/*     */           
/* 103 */           stringBuffer.append("new " + this.stubGenHelper.getJavaTypeHolderName(part) + "()");
/*     */         } else {
/* 105 */           stringBuffer.append(getArgString(part));
/*     */         } 
/*     */       } 
/*     */     } 
/* 109 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public String getArgStatementWithOutParamOrder(Operation paramOperation) {
/* 113 */     Iterator iterator1 = paramOperation.getInput().getParts();
/* 114 */     StringBuffer stringBuffer = new StringBuffer();
/* 115 */     boolean bool = true;
/*     */     Iterator iterator2;
/* 117 */     for (iterator2 = paramOperation.getInput().getParts(); iterator2.hasNext(); ) {
/* 118 */       if (!bool) {
/* 119 */         stringBuffer.append(", ");
/*     */       }
/*     */       
/* 122 */       Part part = (Part)iterator2.next();
/*     */       
/* 124 */       if (this.stubGenHelper.useHolderClass(paramOperation, part)) {
/* 125 */         String str = this.stubGenHelper.getJavaTypeHolderName(part);
/* 126 */         stringBuffer.append("new " + str + "()");
/*     */       } else {
/* 128 */         stringBuffer.append(getArgString(part));
/*     */       } 
/*     */       
/* 131 */       bool = false;
/*     */     } 
/*     */     
/* 134 */     for (iterator2 = this.stubGenHelper.getOutPartsWithoutInOuts(paramOperation); iterator2.hasNext(); ) {
/* 135 */       if (!bool) {
/* 136 */         stringBuffer.append(", ");
/*     */       }
/*     */       
/* 139 */       Part part = (Part)iterator2.next();
/* 140 */       String str = this.stubGenHelper.getJavaTypeHolderName(part);
/* 141 */       stringBuffer.append("new " + str + "()");
/*     */       
/* 143 */       bool = false;
/*     */     } 
/*     */     
/* 146 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   private String getArgString(Part paramPart) {
/* 150 */     Class clazz = paramPart.getJavaType();
/* 151 */     Object object = buildin.get(clazz);
/* 152 */     if (object != null) {
/* 153 */       return object.toString();
/*     */     }
/* 155 */     if (clazz.isArray()) {
/* 156 */       return getArrayString(clazz);
/*     */     }
/* 158 */     if (isInstantiable(clazz)) {
/* 159 */       return "new " + clazz.getName() + "()";
/*     */     }
/* 161 */     return "null";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getArrayString(Class paramClass) {
/* 168 */     Class clazz = paramClass.getComponentType();
/* 169 */     String str = "[]";
/*     */     
/* 171 */     while (clazz.isArray()) {
/* 172 */       clazz = clazz.getComponentType();
/* 173 */       str = str + "[]";
/*     */     } 
/*     */     
/* 176 */     return "new " + clazz.getName() + str + "{}";
/*     */   }
/*     */   
/*     */   private boolean isInstantiable(Class paramClass) {
/* 180 */     if (paramClass.isInterface()) return false;
/*     */     
/* 182 */     if (Modifier.isAbstract(paramClass.getModifiers())) {
/* 183 */       return false;
/*     */     }
/*     */     
/*     */     try {
/* 187 */       paramClass.getConstructor(new Class[0]);
/* 188 */     } catch (NoSuchMethodException noSuchMethodException) {
/* 189 */       return false;
/*     */     } 
/*     */     
/* 192 */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\DemoClientUtil.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */