package weblogic.webservice.tools.stubgen;

import java.io.IOException;
import weblogic.webservice.util.script.GenBase;

public class GenHelper extends GenBase {
  public GenHelper(String paramString) throws IOException { super(paramString, false); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\GenHelper.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */