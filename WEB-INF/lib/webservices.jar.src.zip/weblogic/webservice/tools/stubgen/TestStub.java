package weblogic.webservice.tools.stubgen;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import weblogic.utils.compiler.Tool;
import weblogic.utils.compiler.ToolFailureException;
import weblogic.webservice.tools.pagegen.SampleInstance;

public class TestStub extends Tool {
  private boolean verbose;
  
  private boolean print;
  
  private SampleInstance sampleInstance = new SampleInstance();
  
  public TestStub(String[] paramArrayOfString) { super(paramArrayOfString); }
  
  public void prepare() { fillInOptions(); }
  
  private void fillInOptions() {
    this.opts.setUsageArgs("<options>");
    this.opts.addOption("service", "service", "service class name");
    this.opts.addFlag("verbose", "Run service in verbose mode");
    this.opts.addFlag("print", "print invocation results");
    this.opts.addOption("logfile", "logfile", "log file to write results");
  }
  
  public void runBody() { runTest(this.opts.getOption("service"), this.opts.getBooleanOption("verbose", false), this.opts.getBooleanOption("print", false), this.opts.getOption("logfile")); }
  
  protected void runTest(String paramString1, boolean paramBoolean1, boolean paramBoolean2, String paramString2) throws ToolFailureException {
    Object object;
    this.verbose = paramBoolean1;
    this.print = paramBoolean2;
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    PrintStream printStream = new PrintStream(byteArrayOutputStream);
    if (paramString2 != null)
      printStream.println("<html><body><pre>"); 
    try {
      object = Class.forName(paramString1).newInstance();
    } catch (java.lang.Exception exception) {
      printStream.println(exception);
      exception.printStackTrace(printStream);
      throw new ToolFailureException("failed to create service:" + exception);
    } 
    Iterator iterator = getPorts(object);
    if (!iterator.hasNext())
      throw new ToolFailureException("no port found in service: " + paramString1); 
    HashMap hashMap = null;
    while (iterator.hasNext()) {
      Object object1 = iterator.next();
      hashMap = invokeTests(object1, printStream);
      printStatus(hashMap, printStream);
    } 
    if (paramString2 != null)
      printStream.println("</pre></body></html>"); 
    printStream.flush();
    try {
      if (paramString2 != null) {
        paramString2 = paramString2 + (testOk(hashMap) ? "_success" : "_failed");
        paramString2 = paramString2 + ".html";
        FileOutputStream fileOutputStream = new FileOutputStream(paramString2);
        fileOutputStream.write(byteArrayOutputStream.toByteArray());
        fileOutputStream.close();
      } else {
        System.out.write(byteArrayOutputStream.toByteArray());
      } 
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
  
  private boolean testOk(HashMap paramHashMap) {
    for (Map.Entry entry : paramHashMap.entrySet()) {
      Result result = (Result)entry.getValue();
      if (!result.status)
        return false; 
    } 
    return true;
  }
  
  private Iterator getPorts(Object paramObject) {
    ArrayList arrayList = new ArrayList();
    try {
      Method[] arrayOfMethod = paramObject.getClass().getDeclaredMethods();
      for (byte b = 0; b < arrayOfMethod.length; b++) {
        if (arrayOfMethod[b].getName().startsWith("get") && arrayOfMethod[b].getParameterTypes().length == 0)
          arrayList.add(arrayOfMethod[b].invoke(paramObject, new Object[0])); 
      } 
    } catch (java.lang.Exception exception) {
      exception.printStackTrace();
    } 
    return arrayList.iterator();
  }
  
  private void printStatus(HashMap paramHashMap, PrintStream paramPrintStream) {
    for (Map.Entry entry : paramHashMap.entrySet()) {
      String str = (String)entry.getKey();
      Result result = (Result)entry.getValue();
      paramPrintStream.println(str + ":" + (result.status ? "OK" : "FAILED"));
    } 
  }
  
  private HashMap invokeTests(Object paramObject, PrintStream paramPrintStream) throws ToolFailureException {
    HashMap hashMap = new HashMap();
    Method[] arrayOfMethod = null;
    try {
      arrayOfMethod = getTestMethods(paramObject);
    } catch (java.lang.Exception exception) {
      exception.printStackTrace(paramPrintStream);
      throw new ToolFailureException("unable to get test methods");
    } 
    for (byte b = 0; b < arrayOfMethod.length; b++) {
      if (!arrayOfMethod[b].getName().startsWith("class$")) {
        Result result = new Result(null);
        hashMap.put(arrayOfMethod[b].getName(), result);
        try {
          if (this.print)
            paramPrintStream.println("invoking ... " + arrayOfMethod[b].getName()); 
          result.ret = arrayOfMethod[b].invoke(paramObject, getParams(arrayOfMethod[b]));
          result.status = true;
          if (this.print)
            paramPrintStream.println("result: " + result.ret); 
        } catch (java.lang.Exception exception) {
          result.error = exception;
          result.status = false;
          if (this.print)
            exception.printStackTrace(paramPrintStream); 
        } 
      } 
    } 
    return hashMap;
  }
  
  private Object[] getParams(Method paramMethod) throws java.lang.Exception {
    Class[] arrayOfClass = paramMethod.getParameterTypes();
    ArrayList arrayList = new ArrayList();
    for (byte b = 0; b < arrayOfClass.length; b++)
      arrayList.add(this.sampleInstance.getSampleInstance(arrayOfClass[b], new HashMap())); 
    return arrayList.toArray();
  }
  
  private Method[] getTestMethods(Object paramObject) {
    Method[] arrayOfMethod = paramObject.getClass().getDeclaredMethods();
    ArrayList arrayList = new ArrayList();
    for (byte b = 0; b < arrayOfMethod.length; b++) {
      if (!arrayOfMethod[b].getName().startsWith("_"))
        arrayList.add(arrayOfMethod[b]); 
    } 
    return (Method[])arrayList.toArray(new Method[arrayList.size()]);
  }
  
  private class Result {
    boolean status;
    
    Throwable error;
    
    Object ret;
    
    private final TestStub this$0;
    
    private Result() {}
  }
  
  public static void main(String[] paramArrayOfString) { (new TestStub(paramArrayOfString)).run(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\TestStub.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */