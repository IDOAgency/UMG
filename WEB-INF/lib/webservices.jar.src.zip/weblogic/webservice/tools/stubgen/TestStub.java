/*     */ package weblogic.webservice.tools.stubgen;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import weblogic.utils.compiler.Tool;
/*     */ import weblogic.utils.compiler.ToolFailureException;
/*     */ import weblogic.webservice.tools.pagegen.SampleInstance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestStub
/*     */   extends Tool
/*     */ {
/*     */   private boolean verbose;
/*     */   private boolean print;
/*  28 */   private SampleInstance sampleInstance = new SampleInstance();
/*     */ 
/*     */   
/*  31 */   public TestStub(String[] paramArrayOfString) { super(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */   
/*  35 */   public void prepare() { fillInOptions(); }
/*     */ 
/*     */   
/*     */   private void fillInOptions() {
/*  39 */     this.opts.setUsageArgs("<options>");
/*  40 */     this.opts.addOption("service", "service", "service class name");
/*  41 */     this.opts.addFlag("verbose", "Run service in verbose mode");
/*  42 */     this.opts.addFlag("print", "print invocation results");
/*  43 */     this.opts.addOption("logfile", "logfile", "log file to write results");
/*     */   }
/*     */ 
/*     */   
/*  47 */   public void runBody() { runTest(this.opts.getOption("service"), this.opts.getBooleanOption("verbose", false), this.opts.getBooleanOption("print", false), this.opts.getOption("logfile")); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void runTest(String paramString1, boolean paramBoolean1, boolean paramBoolean2, String paramString2) throws ToolFailureException {
/*     */     Object object;
/*  56 */     this.verbose = paramBoolean1;
/*  57 */     this.print = paramBoolean2;
/*     */ 
/*     */     
/*  60 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*  62 */     PrintStream printStream = new PrintStream(byteArrayOutputStream);
/*     */     
/*  64 */     if (paramString2 != null) {
/*  65 */       printStream.println("<html><body><pre>");
/*     */     }
/*     */     
/*     */     try {
/*  69 */       object = Class.forName(paramString1).newInstance();
/*  70 */     } catch (java.lang.Exception exception) {
/*  71 */       printStream.println(exception);
/*  72 */       exception.printStackTrace(printStream);
/*  73 */       throw new ToolFailureException("failed to create service:" + exception);
/*     */     } 
/*     */     
/*  76 */     Iterator iterator = getPorts(object);
/*     */     
/*  78 */     if (!iterator.hasNext()) {
/*  79 */       throw new ToolFailureException("no port found in service: " + paramString1);
/*     */     }
/*     */ 
/*     */     
/*  83 */     HashMap hashMap = null;
/*     */     
/*  85 */     while (iterator.hasNext()) {
/*  86 */       Object object1 = iterator.next();
/*  87 */       hashMap = invokeTests(object1, printStream);
/*  88 */       printStatus(hashMap, printStream);
/*     */     } 
/*     */     
/*  91 */     if (paramString2 != null) {
/*  92 */       printStream.println("</pre></body></html>");
/*     */     }
/*     */     
/*  95 */     printStream.flush();
/*     */     
/*     */     try {
/*  98 */       if (paramString2 != null) {
/*  99 */         paramString2 = paramString2 + (testOk(hashMap) ? "_success" : "_failed");
/* 100 */         paramString2 = paramString2 + ".html";
/* 101 */         FileOutputStream fileOutputStream = new FileOutputStream(paramString2);
/* 102 */         fileOutputStream.write(byteArrayOutputStream.toByteArray());
/* 103 */         fileOutputStream.close();
/*     */       } else {
/* 105 */         System.out.write(byteArrayOutputStream.toByteArray());
/*     */       } 
/* 107 */     } catch (IOException iOException) {
/* 108 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean testOk(HashMap paramHashMap) {
/* 113 */     for (Map.Entry entry : paramHashMap.entrySet()) {
/*     */       
/* 115 */       Result result = (Result)entry.getValue();
/* 116 */       if (!result.status) {
/* 117 */         return false;
/*     */       }
/*     */     } 
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   private Iterator getPorts(Object paramObject) {
/* 124 */     ArrayList arrayList = new ArrayList();
/*     */     
/*     */     try {
/* 127 */       Method[] arrayOfMethod = paramObject.getClass().getDeclaredMethods();
/* 128 */       for (byte b = 0; b < arrayOfMethod.length; b++) {
/*     */         
/* 130 */         if (arrayOfMethod[b].getName().startsWith("get") && arrayOfMethod[b].getParameterTypes().length == 0)
/*     */         {
/* 132 */           arrayList.add(arrayOfMethod[b].invoke(paramObject, new Object[0]));
/*     */         }
/*     */       } 
/* 135 */     } catch (java.lang.Exception exception) {
/* 136 */       exception.printStackTrace();
/*     */     } 
/*     */     
/* 139 */     return arrayList.iterator();
/*     */   }
/*     */   
/*     */   private void printStatus(HashMap paramHashMap, PrintStream paramPrintStream) {
/* 143 */     for (Map.Entry entry : paramHashMap.entrySet()) {
/*     */       
/* 145 */       String str = (String)entry.getKey();
/* 146 */       Result result = (Result)entry.getValue();
/* 147 */       paramPrintStream.println(str + ":" + (result.status ? "OK" : "FAILED"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap invokeTests(Object paramObject, PrintStream paramPrintStream) throws ToolFailureException {
/* 154 */     HashMap hashMap = new HashMap();
/* 155 */     Method[] arrayOfMethod = null;
/*     */     
/*     */     try {
/* 158 */       arrayOfMethod = getTestMethods(paramObject);
/* 159 */     } catch (java.lang.Exception exception) {
/* 160 */       exception.printStackTrace(paramPrintStream);
/* 161 */       throw new ToolFailureException("unable to get test methods");
/*     */     } 
/*     */ 
/*     */     
/* 165 */     for (byte b = 0; b < arrayOfMethod.length; b++) {
/* 166 */       if (!arrayOfMethod[b].getName().startsWith("class$")) {
/*     */ 
/*     */ 
/*     */         
/* 170 */         Result result = new Result(null);
/* 171 */         hashMap.put(arrayOfMethod[b].getName(), result);
/*     */ 
/*     */         
/*     */         try {
/* 175 */           if (this.print) {
/* 176 */             paramPrintStream.println("invoking ... " + arrayOfMethod[b].getName());
/*     */           }
/*     */           
/* 179 */           result.ret = arrayOfMethod[b].invoke(paramObject, getParams(arrayOfMethod[b]));
/* 180 */           result.status = true;
/*     */           
/* 182 */           if (this.print) {
/* 183 */             paramPrintStream.println("result: " + result.ret);
/*     */           }
/* 185 */         } catch (java.lang.Exception exception) {
/* 186 */           result.error = exception;
/* 187 */           result.status = false;
/*     */           
/* 189 */           if (this.print) {
/* 190 */             exception.printStackTrace(paramPrintStream);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 195 */     return hashMap;
/*     */   }
/*     */   
/*     */   private Object[] getParams(Method paramMethod) throws java.lang.Exception {
/* 199 */     Class[] arrayOfClass = paramMethod.getParameterTypes();
/*     */     
/* 201 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 203 */     for (byte b = 0; b < arrayOfClass.length; b++) {
/* 204 */       arrayList.add(this.sampleInstance.getSampleInstance(arrayOfClass[b], new HashMap()));
/*     */     }
/*     */     
/* 207 */     return arrayList.toArray();
/*     */   }
/*     */   
/*     */   private Method[] getTestMethods(Object paramObject) {
/* 211 */     Method[] arrayOfMethod = paramObject.getClass().getDeclaredMethods();
/*     */     
/* 213 */     ArrayList arrayList = new ArrayList();
/*     */     
/* 215 */     for (byte b = 0; b < arrayOfMethod.length; b++) {
/* 216 */       if (!arrayOfMethod[b].getName().startsWith("_")) {
/* 217 */         arrayList.add(arrayOfMethod[b]);
/*     */       }
/*     */     } 
/*     */     
/* 221 */     return (Method[])arrayList.toArray(new Method[arrayList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public static void main(String[] paramArrayOfString) { (new TestStub(paramArrayOfString)).run(); }
/*     */   
/*     */   private class Result {
/*     */     boolean status;
/*     */     Throwable error;
/*     */     Object ret;
/*     */     private final TestStub this$0;
/*     */     
/*     */     private Result() {}
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\stubgen\TestStub.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */