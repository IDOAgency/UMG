/*    */ package weblogic.webservice.tools.versioning;
/*    */ 
/*    */ import weblogic.utils.NestedException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VersioningException
/*    */   extends NestedException
/*    */ {
/* 12 */   public VersioningException(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */   
/* 16 */   public VersioningException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\versioning\VersioningException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */