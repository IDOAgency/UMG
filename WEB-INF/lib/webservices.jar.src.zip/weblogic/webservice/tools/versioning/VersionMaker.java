package weblogic.webservice.tools.versioning;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import weblogic.webservice.util.bytecode.ConstantPool;
import weblogic.webservice.util.bytecode.SClass;

public class VersionMaker {
  private static final String VERSION = "81";
  
  private static final boolean debug = false;
  
  private OutputStream getOutputFile(File paramFile, String paramString) throws IOException {
    if (paramString.startsWith("weblogic"))
      paramString = "weblogic81" + paramString.substring("weblogic".length(), paramString.length()); 
    int i = paramString.lastIndexOf("/");
    String str = (i == -1) ? paramString : paramString.substring(0, i);
    File file1 = new File(paramFile, str.replace('/', File.separatorChar));
    file1.mkdirs();
    File file2 = new File(paramFile, paramString.replace('/', File.separatorChar));
    return new FileOutputStream(file2);
  }
  
  private void changeConstantPool(ConstantPool paramConstantPool) {
    for (Iterator iterator = paramConstantPool.getConstants(); iterator.hasNext(); ) {
      Object object = iterator.next();
      if (object instanceof ConstantPool.ConstantUtf8Info) {
        ConstantPool.ConstantUtf8Info constantUtf8Info = (ConstantPool.ConstantUtf8Info)object;
        String str = constantUtf8Info.getString();
        if (str.startsWith("weblogic/"))
          str = "weblogic81" + str.substring("weblogic".length(), str.length()); 
        if (str.startsWith("weblogic."))
          str = "weblogic81" + str.substring("weblogic".length(), str.length()); 
        str = replace(str, "Lweblogic/", "Lweblogic81/");
        constantUtf8Info.setString(str);
      } 
    } 
  }
  
  private String replace(String paramString1, String paramString2, String paramString3) {
    StringBuffer stringBuffer = new StringBuffer();
    int i;
    while ((i = paramString1.indexOf(paramString2)) != -1) {
      String str = paramString1.substring(0, i);
      stringBuffer.append(str);
      stringBuffer.append(paramString3);
      paramString1 = paramString1.substring(i + paramString2.length(), paramString1.length());
    } 
    stringBuffer.append(paramString1);
    return stringBuffer.toString();
  }
  
  private void crunchFile(File paramFile, String paramString, InputStream paramInputStream) throws IOException {
    if (paramInputStream == null) {
      System.err.println("Warning: File " + paramString + " not found in classpath");
    } else if (paramString.endsWith(".class")) {
      SClass sClass = readSClass(paramInputStream);
      changeConstantPool(sClass.getConstantPool());
      OutputStream outputStream = getOutputFile(paramFile, paramString);
      DataOutputStream dataOutputStream;
      sClass.write(dataOutputStream = new DataOutputStream(outputStream));
      dataOutputStream.close();
      outputStream.close();
    } else {
      copyFile(paramFile, paramString, paramInputStream);
    } 
  }
  
  private void copyFile(File paramFile, String paramString, InputStream paramInputStream) throws IOException {
    OutputStream outputStream = getOutputFile(paramFile, paramString);
    String str = asString(paramInputStream);
    str = replace(str, "\"weblogic.", "\"weblogic81.");
    outputStream.write(str.getBytes());
    outputStream.close();
  }
  
  private String asString(InputStream paramInputStream) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i;
    while ((i = paramInputStream.read()) != -1)
      byteArrayOutputStream.write((char)i); 
    paramInputStream.close();
    String str = new String(byteArrayOutputStream.toByteArray());
    byteArrayOutputStream.close();
    return str;
  }
  
  private void printMessage(String paramString) {
    int i = paramString.length();
    String str = (i > 50) ? ("..." + paramString.substring(i - 50, i)) : paramString;
    System.out.println("Crunching.. " + str);
  }
  
  private SClass readSClass(InputStream paramInputStream) throws IOException {
    SClass sClass = new SClass();
    sClass.read(new DataInputStream(paramInputStream));
    paramInputStream.close();
    return sClass;
  }
  
  public static void main(String[] paramArrayOfString) {
    try {
      (new VersionMaker()).makeit(paramArrayOfString);
    } catch (Throwable throwable) {
      System.out.println(throwable);
      throwable.printStackTrace(System.out);
    } 
  }
  
  private void doJar(File paramFile, String paramString) throws IOException {
    JarFile jarFile = new JarFile(paramString);
    for (Enumeration enumeration = jarFile.entries(); enumeration.hasMoreElements(); ) {
      ZipEntry zipEntry = (ZipEntry)enumeration.nextElement();
      if (zipEntry.isDirectory())
        continue; 
      InputStream inputStream = jarFile.getInputStream(zipEntry);
      crunchFile(paramFile, zipEntry.getName(), inputStream);
      inputStream.close();
    } 
  }
  
  private void doFileList(File paramFile, String paramString) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(new FileReader(paramString));
    String str;
    while ((str = bufferedReader.readLine()) != null) {
      InputStream inputStream = VersionMaker.class.getClassLoader().getResourceAsStream(str);
      crunchFile(paramFile, str, inputStream);
      if (inputStream != null)
        inputStream.close(); 
    } 
  }
  
  public void makeit(String[] paramArrayOfString) {
    if (paramArrayOfString.length < 2) {
      System.out.println("VersionMaker target-dir [file-lists|jar-file]*");
      return;
    } 
    File file = new File(paramArrayOfString[0]);
    if (!file.exists())
      throw new IOException("unable to find target dir:" + paramArrayOfString[0]); 
    for (byte b = 1; b < paramArrayOfString.length; b++) {
      if (paramArrayOfString[b].endsWith(".jar")) {
        doJar(file, paramArrayOfString[b]);
      } else {
        doFileList(file, paramArrayOfString[b]);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\versioning\VersionMaker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */