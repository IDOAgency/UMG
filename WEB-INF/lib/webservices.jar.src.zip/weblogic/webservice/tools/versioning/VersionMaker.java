/*     */ package weblogic.webservice.tools.versioning;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.zip.ZipEntry;
/*     */ import weblogic.webservice.util.bytecode.ConstantPool;
/*     */ import weblogic.webservice.util.bytecode.SClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionMaker
/*     */ {
/*     */   private static final String VERSION = "81";
/*     */   private static final boolean debug = false;
/*     */   
/*     */   private OutputStream getOutputFile(File paramFile, String paramString) throws IOException {
/*  40 */     if (paramString.startsWith("weblogic"))
/*     */     {
/*  42 */       paramString = "weblogic81" + paramString.substring("weblogic".length(), paramString.length());
/*     */     }
/*     */ 
/*     */     
/*  46 */     int i = paramString.lastIndexOf("/");
/*  47 */     String str = (i == -1) ? paramString : paramString.substring(0, i);
/*     */     
/*  49 */     File file1 = new File(paramFile, str.replace('/', File.separatorChar));
/*     */ 
/*     */     
/*  52 */     file1.mkdirs();
/*     */     
/*  54 */     File file2 = new File(paramFile, paramString.replace('/', File.separatorChar));
/*     */ 
/*     */     
/*  57 */     return new FileOutputStream(file2);
/*     */   }
/*     */ 
/*     */   
/*     */   private void changeConstantPool(ConstantPool paramConstantPool) {
/*  62 */     for (Iterator iterator = paramConstantPool.getConstants(); iterator.hasNext(); ) {
/*  63 */       Object object = iterator.next();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  71 */       if (object instanceof ConstantPool.ConstantUtf8Info) {
/*  72 */         ConstantPool.ConstantUtf8Info constantUtf8Info = (ConstantPool.ConstantUtf8Info)object;
/*  73 */         String str = constantUtf8Info.getString();
/*     */         
/*  75 */         if (str.startsWith("weblogic/")) {
/*  76 */           str = "weblogic81" + str.substring("weblogic".length(), str.length());
/*     */         }
/*     */ 
/*     */         
/*  80 */         if (str.startsWith("weblogic.")) {
/*  81 */           str = "weblogic81" + str.substring("weblogic".length(), str.length());
/*     */         }
/*     */ 
/*     */         
/*  85 */         str = replace(str, "Lweblogic/", "Lweblogic81/");
/*     */         
/*  87 */         constantUtf8Info.setString(str);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String replace(String paramString1, String paramString2, String paramString3) {
/*  93 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/*     */     int i;
/*     */     
/*  97 */     while ((i = paramString1.indexOf(paramString2)) != -1) {
/*  98 */       String str = paramString1.substring(0, i);
/*  99 */       stringBuffer.append(str);
/* 100 */       stringBuffer.append(paramString3);
/* 101 */       paramString1 = paramString1.substring(i + paramString2.length(), paramString1.length());
/*     */     } 
/*     */     
/* 104 */     stringBuffer.append(paramString1);
/* 105 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void crunchFile(File paramFile, String paramString, InputStream paramInputStream) throws IOException {
/* 115 */     if (paramInputStream == null) {
/* 116 */       System.err.println("Warning: File " + paramString + " not found in classpath");
/*     */     }
/* 118 */     else if (paramString.endsWith(".class")) {
/* 119 */       SClass sClass = readSClass(paramInputStream);
/* 120 */       changeConstantPool(sClass.getConstantPool());
/*     */ 
/*     */       
/* 123 */       OutputStream outputStream = getOutputFile(paramFile, paramString); DataOutputStream dataOutputStream;
/* 124 */       sClass.write(dataOutputStream = new DataOutputStream(outputStream));
/* 125 */       dataOutputStream.close();
/* 126 */       outputStream.close();
/*     */     } else {
/* 128 */       copyFile(paramFile, paramString, paramInputStream);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyFile(File paramFile, String paramString, InputStream paramInputStream) throws IOException {
/* 136 */     OutputStream outputStream = getOutputFile(paramFile, paramString);
/*     */     
/* 138 */     String str = asString(paramInputStream);
/* 139 */     str = replace(str, "\"weblogic.", "\"weblogic81.");
/*     */     
/* 141 */     outputStream.write(str.getBytes());
/* 142 */     outputStream.close();
/*     */   }
/*     */   
/*     */   private String asString(InputStream paramInputStream) throws IOException {
/* 146 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*     */     int i;
/* 149 */     while ((i = paramInputStream.read()) != -1) {
/* 150 */       byteArrayOutputStream.write((char)i);
/*     */     }
/*     */     
/* 153 */     paramInputStream.close();
/* 154 */     String str = new String(byteArrayOutputStream.toByteArray());
/*     */     
/* 156 */     byteArrayOutputStream.close();
/* 157 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   private void printMessage(String paramString) {
/* 162 */     int i = paramString.length();
/*     */     
/* 164 */     String str = (i > 50) ? ("..." + paramString.substring(i - 50, i)) : paramString;
/*     */ 
/*     */     
/* 167 */     System.out.println("Crunching.. " + str);
/*     */   }
/*     */   
/*     */   private SClass readSClass(InputStream paramInputStream) throws IOException {
/* 171 */     SClass sClass = new SClass();
/* 172 */     sClass.read(new DataInputStream(paramInputStream));
/* 173 */     paramInputStream.close();
/* 174 */     return sClass;
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*     */     try {
/* 179 */       (new VersionMaker()).makeit(paramArrayOfString);
/* 180 */     } catch (Throwable throwable) {
/* 181 */       System.out.println(throwable);
/* 182 */       throwable.printStackTrace(System.out);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doJar(File paramFile, String paramString) throws IOException {
/* 188 */     JarFile jarFile = new JarFile(paramString);
/*     */     
/* 190 */     for (Enumeration enumeration = jarFile.entries(); enumeration.hasMoreElements(); ) {
/* 191 */       ZipEntry zipEntry = (ZipEntry)enumeration.nextElement();
/*     */       
/* 193 */       if (zipEntry.isDirectory()) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 198 */       InputStream inputStream = jarFile.getInputStream(zipEntry);
/* 199 */       crunchFile(paramFile, zipEntry.getName(), inputStream);
/* 200 */       inputStream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void doFileList(File paramFile, String paramString) throws IOException {
/* 206 */     BufferedReader bufferedReader = new BufferedReader(new FileReader(paramString));
/*     */     
/*     */     String str;
/*     */     
/* 210 */     while ((str = bufferedReader.readLine()) != null) {
/*     */       
/* 212 */       InputStream inputStream = VersionMaker.class.getClassLoader().getResourceAsStream(str);
/*     */ 
/*     */       
/* 215 */       crunchFile(paramFile, str, inputStream);
/* 216 */       if (inputStream != null) {
/* 217 */         inputStream.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void makeit(String[] paramArrayOfString) {
/* 224 */     if (paramArrayOfString.length < 2) {
/* 225 */       System.out.println("VersionMaker target-dir [file-lists|jar-file]*");
/*     */       
/*     */       return;
/*     */     } 
/* 229 */     File file = new File(paramArrayOfString[0]);
/*     */     
/* 231 */     if (!file.exists()) {
/* 232 */       throw new IOException("unable to find target dir:" + paramArrayOfString[0]);
/*     */     }
/*     */     
/* 235 */     for (byte b = 1; b < paramArrayOfString.length; b++) {
/*     */       
/* 237 */       if (paramArrayOfString[b].endsWith(".jar")) {
/* 238 */         doJar(file, paramArrayOfString[b]);
/*     */       } else {
/* 240 */         doFileList(file, paramArrayOfString[b]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\versioning\VersionMaker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */