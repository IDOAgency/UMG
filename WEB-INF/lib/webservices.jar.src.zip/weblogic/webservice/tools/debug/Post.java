package weblogic.webservice.tools.debug;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import weblogic.utils.compiler.Tool;
import weblogic.utils.compiler.ToolFailureException;

public class Post extends Tool {
  private static final String LINE = "____________________________________________________________________";
  
  public Post(String[] paramArrayOfString) throws IOException {
    super(paramArrayOfString);
    fillInOptions();
  }
  
  public void prepare() {}
  
  public void runBody() {
    String[] arrayOfString = this.opts.args();
    if (arrayOfString.length == 0)
      throw new ToolFailureException("request file not specified"); 
    if (arrayOfString.length > 1)
      throw new ToolFailureException("only one request file can be specified"); 
    String str = arrayOfString[0];
    try {
      StringBuffer stringBuffer1 = new StringBuffer();
      StringBuffer stringBuffer2 = new StringBuffer();
      StringBuffer stringBuffer3 = new StringBuffer();
      String str1 = parseFile(str, stringBuffer1, stringBuffer2, stringBuffer3);
      System.out.println("Invoking soap message on host: " + str1);
      Socket socket = createSocket(str1);
      OutputStream outputStream = socket.getOutputStream();
      InputStream inputStream = socket.getInputStream();
      sendRequest(outputStream, stringBuffer1.toString(), stringBuffer2.toString(), stringBuffer3.toString());
      readResponse(inputStream);
      socket.close();
    } catch (IOException iOException) {
      iOException.printStackTrace();
      throw new ToolFailureException("unable to invoke: " + iOException, iOException);
    } 
  }
  
  private void readResponse(InputStream paramInputStream) throws IOException {
    System.out.println("____________________________________________________________________");
    int i;
    while ((i = paramInputStream.read()) != -1)
      System.out.print((char)i); 
    paramInputStream.close();
    System.out.println("____________________________________________________________________");
  }
  
  private void sendRequest(OutputStream paramOutputStream, String paramString1, String paramString2, String paramString3) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    byteArrayOutputStream.write(paramString1.getBytes());
    byteArrayOutputStream.write("\r\n".getBytes());
    byteArrayOutputStream.write(paramString2.getBytes());
    byteArrayOutputStream.write(("Content-Length: " + paramString3.getBytes().length + "\r\n").getBytes());
    byteArrayOutputStream.write("\r\n".getBytes());
    byteArrayOutputStream.write(paramString3.getBytes());
    byteArrayOutputStream.flush();
    System.out.println("____________________________________________________________________");
    System.out.println(new String(byteArrayOutputStream.toByteArray()));
    System.out.println("____________________________________________________________________");
    paramOutputStream.write(byteArrayOutputStream.toByteArray());
    paramOutputStream.flush();
  }
  
  private Socket createSocket(String paramString) throws IOException {
    String str;
    byte b;
    int i = paramString.indexOf(":");
    if (i != -1) {
      str = paramString.substring(0, i);
      String str1 = paramString.substring(i + 1, paramString.length());
      b = Integer.parseInt(str1);
    } else {
      str = paramString;
      b = 80;
    } 
    return new Socket(str, b);
  }
  
  private String parseFile(String paramString, StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws IOException, ToolFailureException {
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(paramString)));
    String str1 = null;
    String str2 = bufferedReader.readLine();
    paramStringBuffer1.append(str2);
    while ((str2 = bufferedReader.readLine()) != null) {
      String str = getHostName(str2);
      if (str != null)
        str1 = str; 
      if (str2.length() == 0)
        break; 
      paramStringBuffer2.append(str2).append("\r\n");
    } 
    while ((str2 = bufferedReader.readLine()) != null)
      paramStringBuffer3.append(str2).append("\r\n"); 
    bufferedReader.close();
    if (str1 == null)
      throw new ToolFailureException("unable to find 'Host' http header in the request"); 
    return str1;
  }
  
  private String getHostName(String paramString) {
    int i = paramString.indexOf(":");
    String str = null;
    if (i != -1) {
      String str1 = paramString.substring(0, i).trim();
      String str2 = paramString.substring(i + 1, paramString.length()).trim();
      if ("HOST".equalsIgnoreCase(str1))
        return str2; 
    } 
    return str;
  }
  
  private void fillInOptions() { this.opts.setUsageArgs("file_name"); }
  
  public static void main(String[] paramArrayOfString) throws IOException { (new Post(paramArrayOfString)).run(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\debug\Post.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */