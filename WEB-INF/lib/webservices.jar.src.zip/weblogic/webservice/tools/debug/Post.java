/*     */ package weblogic.webservice.tools.debug;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.Socket;
/*     */ import weblogic.utils.compiler.Tool;
/*     */ import weblogic.utils.compiler.ToolFailureException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Post
/*     */   extends Tool
/*     */ {
/*     */   private static final String LINE = "____________________________________________________________________";
/*     */   
/*     */   public Post(String[] paramArrayOfString) throws IOException {
/*  37 */     super(paramArrayOfString);
/*  38 */     fillInOptions();
/*     */   }
/*     */ 
/*     */   
/*     */   public void prepare() {}
/*     */   
/*     */   public void runBody() {
/*  45 */     String[] arrayOfString = this.opts.args();
/*     */     
/*  47 */     if (arrayOfString.length == 0) {
/*  48 */       throw new ToolFailureException("request file not specified");
/*     */     }
/*     */     
/*  51 */     if (arrayOfString.length > 1) {
/*  52 */       throw new ToolFailureException("only one request file can be specified");
/*     */     }
/*     */ 
/*     */     
/*  56 */     String str = arrayOfString[0];
/*     */     
/*     */     try {
/*  59 */       StringBuffer stringBuffer1 = new StringBuffer();
/*  60 */       StringBuffer stringBuffer2 = new StringBuffer();
/*  61 */       StringBuffer stringBuffer3 = new StringBuffer();
/*     */       
/*  63 */       String str1 = parseFile(str, stringBuffer1, stringBuffer2, stringBuffer3);
/*  64 */       System.out.println("Invoking soap message on host: " + str1);
/*     */       
/*  66 */       Socket socket = createSocket(str1);
/*  67 */       OutputStream outputStream = socket.getOutputStream();
/*  68 */       InputStream inputStream = socket.getInputStream();
/*     */       
/*  70 */       sendRequest(outputStream, stringBuffer1.toString(), stringBuffer2.toString(), stringBuffer3.toString());
/*  71 */       readResponse(inputStream);
/*  72 */       socket.close();
/*  73 */     } catch (IOException iOException) {
/*  74 */       iOException.printStackTrace();
/*  75 */       throw new ToolFailureException("unable to invoke: " + iOException, iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readResponse(InputStream paramInputStream) throws IOException {
/*  81 */     System.out.println("____________________________________________________________________");
/*     */     
/*     */     int i;
/*     */     
/*  85 */     while ((i = paramInputStream.read()) != -1) {
/*  86 */       System.out.print((char)i);
/*     */     }
/*     */     
/*  89 */     paramInputStream.close();
/*     */     
/*  91 */     System.out.println("____________________________________________________________________");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendRequest(OutputStream paramOutputStream, String paramString1, String paramString2, String paramString3) throws IOException {
/*  97 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */     
/*  99 */     byteArrayOutputStream.write(paramString1.getBytes());
/* 100 */     byteArrayOutputStream.write("\r\n".getBytes());
/* 101 */     byteArrayOutputStream.write(paramString2.getBytes());
/*     */     
/* 103 */     byteArrayOutputStream.write(("Content-Length: " + paramString3.getBytes().length + "\r\n").getBytes());
/*     */ 
/*     */     
/* 106 */     byteArrayOutputStream.write("\r\n".getBytes());
/* 107 */     byteArrayOutputStream.write(paramString3.getBytes());
/* 108 */     byteArrayOutputStream.flush();
/*     */     
/* 110 */     System.out.println("____________________________________________________________________");
/* 111 */     System.out.println(new String(byteArrayOutputStream.toByteArray()));
/* 112 */     System.out.println("____________________________________________________________________");
/*     */     
/* 114 */     paramOutputStream.write(byteArrayOutputStream.toByteArray());
/* 115 */     paramOutputStream.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Socket createSocket(String paramString) throws IOException {
/*     */     String str;
/*     */     byte b;
/* 123 */     int i = paramString.indexOf(":");
/*     */     
/* 125 */     if (i != -1) {
/* 126 */       str = paramString.substring(0, i);
/* 127 */       String str1 = paramString.substring(i + 1, paramString.length());
/* 128 */       b = Integer.parseInt(str1);
/*     */     } else {
/* 130 */       str = paramString;
/* 131 */       b = 80;
/*     */     } 
/*     */     
/* 134 */     return new Socket(str, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parseFile(String paramString, StringBuffer paramStringBuffer1, StringBuffer paramStringBuffer2, StringBuffer paramStringBuffer3) throws IOException, ToolFailureException {
/* 141 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(paramString)));
/*     */ 
/*     */     
/* 144 */     String str1 = null;
/*     */     
/* 146 */     String str2 = bufferedReader.readLine();
/* 147 */     paramStringBuffer1.append(str2);
/*     */     
/* 149 */     while ((str2 = bufferedReader.readLine()) != null) {
/* 150 */       String str = getHostName(str2);
/*     */       
/* 152 */       if (str != null) {
/* 153 */         str1 = str;
/*     */       }
/*     */       
/* 156 */       if (str2.length() == 0) {
/*     */         break;
/*     */       }
/*     */       
/* 160 */       paramStringBuffer2.append(str2).append("\r\n");
/*     */     } 
/*     */     
/* 163 */     while ((str2 = bufferedReader.readLine()) != null) {
/* 164 */       paramStringBuffer3.append(str2).append("\r\n");
/*     */     }
/*     */     
/* 167 */     bufferedReader.close();
/*     */     
/* 169 */     if (str1 == null) {
/* 170 */       throw new ToolFailureException("unable to find 'Host' http header in the request");
/*     */     }
/*     */     
/* 173 */     return str1;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getHostName(String paramString) {
/* 178 */     int i = paramString.indexOf(":");
/*     */     
/* 180 */     String str = null;
/*     */     
/* 182 */     if (i != -1) {
/* 183 */       String str1 = paramString.substring(0, i).trim();
/* 184 */       String str2 = paramString.substring(i + 1, paramString.length()).trim();
/*     */       
/* 186 */       if ("HOST".equalsIgnoreCase(str1)) {
/* 187 */         return str2;
/*     */       }
/*     */     } 
/*     */     
/* 191 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 196 */   private void fillInOptions() { this.opts.setUsageArgs("file_name"); }
/*     */ 
/*     */ 
/*     */   
/* 200 */   public static void main(String[] paramArrayOfString) throws IOException { (new Post(paramArrayOfString)).run(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\debug\Post.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */