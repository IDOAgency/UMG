package weblogic.webservice.tools.debug;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.StringTokenizer;
import weblogic.utils.compiler.Tool;
import weblogic.utils.compiler.ToolFailureException;

public class ProxyServer extends Tool {
  private ServerSocket serverSocket;
  
  public ProxyServer(String[] paramArrayOfString) throws IOException {
    super(paramArrayOfString);
    fillInOptions();
  }
  
  public void prepare() {}
  
  public void runBody() {
    int i = this.opts.getIntegerOption("port", 9001);
    try {
      this.serverSocket = new ServerSocket(i);
      System.out.println("Listening on port " + i);
      acceptConnection();
    } catch (IOException iOException) {
      throw new ToolFailureException("got an IOException");
    } 
  }
  
  public void acceptConnection() {
    while (true) {
      final Socket socket = this.serverSocket.accept();
      System.out.println("Got a socket connection");
      try {
        (new Thread() {
            private final Socket val$socket;
            
            private final ProxyServer this$0;
            
            public void run() { ProxyServer.this.processConnection(socket); }
          }).run();
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
  }
  
  private StringBuffer readFromStream(StringBuffer paramStringBuffer, HashMap paramHashMap, InputStream paramInputStream) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    String str = bufferedReader.readLine();
    if (str == null)
      throw new IOException("not an http request"); 
    paramStringBuffer.append(str);
    while ((str = bufferedReader.readLine()) != null) {
      if (str.length() == 0)
        break; 
      addHeader(paramHashMap, str);
    } 
    boolean bool = isKeepAlive(paramHashMap);
    StringBuffer stringBuffer = new StringBuffer();
    if (!bool) {
      while ((str = bufferedReader.readLine()) != null)
        stringBuffer.append(str); 
    } else {
      int i = getContentLength(paramHashMap);
      for (byte b = 0; b < i; b++)
        stringBuffer.append((char)bufferedReader.read()); 
    } 
    return stringBuffer;
  }
  
  private boolean isKeepAlive(HashMap paramHashMap) {
    String str = (String)paramHashMap.get("Connection");
    if (str == null)
      str = (String)paramHashMap.get("Proxy-Connection"); 
    if (str != null && "Keep-Alive".equals(str))
      return true; 
    return false;
  }
  
  private int getContentLength(HashMap paramHashMap) {
    String str = (String)paramHashMap.get("Content-Length");
    if (str == null)
      return 0; 
    return Integer.parseInt(str);
  }
  
  private void addHeader(HashMap paramHashMap, String paramString) {
    String str2, str1;
    int i = paramString.indexOf(":");
    if (i != -1) {
      str1 = paramString.substring(0, i);
      str2 = paramString.substring(i + 1, paramString.length());
    } else {
      str1 = paramString;
      str2 = "";
    } 
    paramHashMap.put(str1.trim(), str2.trim());
  }
  
  private void processConnection(Socket paramSocket) {
    try {
      handleConnection(paramSocket);
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } finally {
      try {
        paramSocket.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      } 
    } 
  }
  
  public void handleConnection(Socket paramSocket) {
    InputStream inputStream1 = paramSocket.getInputStream();
    OutputStream outputStream1 = paramSocket.getOutputStream();
    HashMap hashMap = new HashMap();
    StringBuffer stringBuffer1 = new StringBuffer();
    StringBuffer stringBuffer2 = readFromStream(stringBuffer1, hashMap, inputStream1);
    dump(stringBuffer1.toString(), hashMap, stringBuffer2);
    Socket socket = createSocket(stringBuffer1.toString(), hashMap);
    InputStream inputStream2 = socket.getInputStream();
    OutputStream outputStream2 = socket.getOutputStream();
    writeToStream(stringBuffer1.toString(), hashMap, stringBuffer2, outputStream2);
    stringBuffer2 = readFromStream(stringBuffer1 = new StringBuffer(), hashMap = new HashMap(), inputStream2);
    dump(stringBuffer1.toString(), hashMap, stringBuffer2);
    writeToStream(stringBuffer1.toString(), hashMap, stringBuffer2, outputStream1);
  }
  
  private void writeToStream(String paramString, HashMap paramHashMap, StringBuffer paramStringBuffer, OutputStream paramOutputStream) throws IOException {
    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramOutputStream);
    bufferedOutputStream.write(paramString.getBytes());
    String str = "\r\n";
    bufferedOutputStream.write(str.getBytes());
    for (Object object1 : paramHashMap.keySet()) {
      Object object2 = paramHashMap.get(object1);
      str = object1 + ": " + object2 + "\r\n";
      bufferedOutputStream.write(str.getBytes());
    } 
    str = "\r\n";
    bufferedOutputStream.write(str.getBytes());
    bufferedOutputStream.write(paramStringBuffer.toString().getBytes());
    bufferedOutputStream.flush();
    paramOutputStream.flush();
  }
  
  private String[] split(String paramString) throws IOException {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString);
    String[] arrayOfString = new String[3];
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (!stringTokenizer.hasMoreTokens())
        throw new IOException("not a valid http request"); 
      arrayOfString[b] = stringTokenizer.nextToken();
    } 
    return arrayOfString;
  }
  
  private void dump(String paramString, HashMap paramHashMap, StringBuffer paramStringBuffer) {
    System.out.println("------------------------------------------");
    System.out.println("target:" + paramString);
    System.out.println("HTTP HEADERS:");
    System.out.println(paramHashMap);
    System.out.println("BODY:");
    System.out.println(paramStringBuffer);
    System.out.println("------------------------------------------");
  }
  
  private Socket createSocket(String paramString, HashMap paramHashMap) throws IOException {
    String[] arrayOfString = split(paramString);
    int i = 80;
    String str = "localhost";
    try {
      URL uRL = new URL(arrayOfString[1]);
      i = getPort(uRL.getPort());
      str = uRL.getHost();
    } catch (IOException iOException) {
      String str1 = (String)paramHashMap.get("Host");
      if (str1 == null)
        throw new IOException("unable to find host:" + paramString); 
      int j = str1.indexOf(":");
      if (j == -1) {
        str = str1;
      } else {
        str = str1.substring(0, j);
        i = Integer.parseInt(str1.substring(j + 1, str1.length()));
      } 
    } 
    return new Socket(str, i);
  }
  
  private int getPort(int paramInt) { return (paramInt < 1) ? 80 : paramInt; }
  
  private void fillInOptions() {
    this.opts.setUsageArgs("<options>");
    this.opts.addOption("port", "port", "proxy server port");
  }
  
  public static void main(String[] paramArrayOfString) throws IOException { (new ProxyServer(paramArrayOfString)).run(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\debug\ProxyServer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */