/*     */ package weblogic.webservice.tools.debug;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.StringTokenizer;
/*     */ import weblogic.utils.compiler.Tool;
/*     */ import weblogic.utils.compiler.ToolFailureException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyServer
/*     */   extends Tool
/*     */ {
/*     */   private ServerSocket serverSocket;
/*     */   
/*     */   public ProxyServer(String[] paramArrayOfString) throws IOException {
/*  35 */     super(paramArrayOfString);
/*  36 */     fillInOptions();
/*     */   }
/*     */ 
/*     */   
/*     */   public void prepare() {}
/*     */   
/*     */   public void runBody() {
/*  43 */     int i = this.opts.getIntegerOption("port", 9001);
/*     */     
/*     */     try {
/*  46 */       this.serverSocket = new ServerSocket(i);
/*  47 */       System.out.println("Listening on port " + i);
/*     */       
/*  49 */       acceptConnection();
/*  50 */     } catch (IOException iOException) {
/*  51 */       throw new ToolFailureException("got an IOException");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void acceptConnection() {
/*     */     while (true) {
/*  58 */       final Socket socket = this.serverSocket.accept();
/*     */       
/*  60 */       System.out.println("Got a socket connection");
/*     */       
/*     */       try {
/*  63 */         (new Thread() { private final Socket val$socket;
/*     */             
/*  65 */             public void run() { ProxyServer.this.processConnection(socket); }
/*     */             private final ProxyServer this$0; }
/*     */           ).run();
/*  68 */       } catch (Exception exception) {
/*  69 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private StringBuffer readFromStream(StringBuffer paramStringBuffer, HashMap paramHashMap, InputStream paramInputStream) throws IOException {
/*  77 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/*     */     
/*  79 */     String str = bufferedReader.readLine();
/*     */     
/*  81 */     if (str == null) {
/*  82 */       throw new IOException("not an http request");
/*     */     }
/*     */     
/*  85 */     paramStringBuffer.append(str);
/*     */     
/*  87 */     while ((str = bufferedReader.readLine()) != null) {
/*     */       
/*  89 */       if (str.length() == 0) {
/*     */         break;
/*     */       }
/*     */       
/*  93 */       addHeader(paramHashMap, str);
/*     */     } 
/*     */     
/*  96 */     boolean bool = isKeepAlive(paramHashMap);
/*     */     
/*  98 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 100 */     if (!bool) {
/* 101 */       while ((str = bufferedReader.readLine()) != null) {
/* 102 */         stringBuffer.append(str);
/*     */       }
/*     */     } else {
/* 105 */       int i = getContentLength(paramHashMap);
/*     */       
/* 107 */       for (byte b = 0; b < i; b++) {
/* 108 */         stringBuffer.append((char)bufferedReader.read());
/*     */       }
/*     */     } 
/*     */     
/* 112 */     return stringBuffer;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isKeepAlive(HashMap paramHashMap) {
/* 117 */     String str = (String)paramHashMap.get("Connection");
/*     */     
/* 119 */     if (str == null) {
/* 120 */       str = (String)paramHashMap.get("Proxy-Connection");
/*     */     }
/*     */     
/* 123 */     if (str != null && "Keep-Alive".equals(str)) {
/* 124 */       return true;
/*     */     }
/*     */     
/* 127 */     return false;
/*     */   }
/*     */   
/*     */   private int getContentLength(HashMap paramHashMap) {
/* 131 */     String str = (String)paramHashMap.get("Content-Length");
/* 132 */     if (str == null) {
/* 133 */       return 0;
/*     */     }
/* 135 */     return Integer.parseInt(str);
/*     */   }
/*     */   
/*     */   private void addHeader(HashMap paramHashMap, String paramString) {
/*     */     String str2, str1;
/* 140 */     int i = paramString.indexOf(":");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     if (i != -1) {
/* 146 */       str1 = paramString.substring(0, i);
/* 147 */       str2 = paramString.substring(i + 1, paramString.length());
/*     */     } else {
/* 149 */       str1 = paramString;
/* 150 */       str2 = "";
/*     */     } 
/*     */     
/* 153 */     paramHashMap.put(str1.trim(), str2.trim());
/*     */   }
/*     */   
/*     */   private void processConnection(Socket paramSocket) {
/*     */     try {
/* 158 */       handleConnection(paramSocket);
/* 159 */     } catch (IOException iOException) {
/* 160 */       iOException.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 163 */         paramSocket.close();
/* 164 */       } catch (IOException iOException) {
/* 165 */         iOException.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void handleConnection(Socket paramSocket) {
/* 171 */     InputStream inputStream1 = paramSocket.getInputStream();
/* 172 */     OutputStream outputStream1 = paramSocket.getOutputStream();
/*     */     
/* 174 */     HashMap hashMap = new HashMap();
/*     */     
/* 176 */     StringBuffer stringBuffer1 = new StringBuffer();
/* 177 */     StringBuffer stringBuffer2 = readFromStream(stringBuffer1, hashMap, inputStream1);
/*     */     
/* 179 */     dump(stringBuffer1.toString(), hashMap, stringBuffer2);
/*     */     
/* 181 */     Socket socket = createSocket(stringBuffer1.toString(), hashMap);
/* 182 */     InputStream inputStream2 = socket.getInputStream();
/* 183 */     OutputStream outputStream2 = socket.getOutputStream();
/*     */     
/* 185 */     writeToStream(stringBuffer1.toString(), hashMap, stringBuffer2, outputStream2);
/*     */     
/* 187 */     stringBuffer2 = readFromStream(stringBuffer1 = new StringBuffer(), hashMap = new HashMap(), inputStream2);
/*     */ 
/*     */     
/* 190 */     dump(stringBuffer1.toString(), hashMap, stringBuffer2);
/* 191 */     writeToStream(stringBuffer1.toString(), hashMap, stringBuffer2, outputStream1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeToStream(String paramString, HashMap paramHashMap, StringBuffer paramStringBuffer, OutputStream paramOutputStream) throws IOException {
/* 198 */     BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(paramOutputStream);
/* 199 */     bufferedOutputStream.write(paramString.getBytes());
/* 200 */     String str = "\r\n";
/* 201 */     bufferedOutputStream.write(str.getBytes());
/*     */     
/* 203 */     for (Object object1 : paramHashMap.keySet()) {
/*     */       
/* 205 */       Object object2 = paramHashMap.get(object1);
/* 206 */       str = object1 + ": " + object2 + "\r\n";
/* 207 */       bufferedOutputStream.write(str.getBytes());
/*     */     } 
/* 209 */     str = "\r\n";
/* 210 */     bufferedOutputStream.write(str.getBytes());
/*     */     
/* 212 */     bufferedOutputStream.write(paramStringBuffer.toString().getBytes());
/* 213 */     bufferedOutputStream.flush();
/* 214 */     paramOutputStream.flush();
/*     */   }
/*     */   
/*     */   private String[] split(String paramString) throws IOException {
/* 218 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString);
/* 219 */     String[] arrayOfString = new String[3];
/*     */     
/* 221 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 222 */       if (!stringTokenizer.hasMoreTokens()) {
/* 223 */         throw new IOException("not a valid http request");
/*     */       }
/* 225 */       arrayOfString[b] = stringTokenizer.nextToken();
/*     */     } 
/*     */     
/* 228 */     return arrayOfString;
/*     */   }
/*     */   
/*     */   private void dump(String paramString, HashMap paramHashMap, StringBuffer paramStringBuffer) {
/* 232 */     System.out.println("------------------------------------------");
/* 233 */     System.out.println("target:" + paramString);
/* 234 */     System.out.println("HTTP HEADERS:");
/* 235 */     System.out.println(paramHashMap);
/* 236 */     System.out.println("BODY:");
/* 237 */     System.out.println(paramStringBuffer);
/* 238 */     System.out.println("------------------------------------------");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Socket createSocket(String paramString, HashMap paramHashMap) throws IOException {
/* 244 */     String[] arrayOfString = split(paramString);
/*     */     
/* 246 */     int i = 80;
/* 247 */     String str = "localhost";
/*     */     
/*     */     try {
/* 250 */       URL uRL = new URL(arrayOfString[1]);
/* 251 */       i = getPort(uRL.getPort());
/* 252 */       str = uRL.getHost();
/* 253 */     } catch (IOException iOException) {
/*     */       
/* 255 */       String str1 = (String)paramHashMap.get("Host");
/*     */       
/* 257 */       if (str1 == null) {
/* 258 */         throw new IOException("unable to find host:" + paramString);
/*     */       }
/*     */       
/* 261 */       int j = str1.indexOf(":");
/*     */       
/* 263 */       if (j == -1) {
/* 264 */         str = str1;
/*     */       } else {
/* 266 */         str = str1.substring(0, j);
/* 267 */         i = Integer.parseInt(str1.substring(j + 1, str1.length()));
/*     */       } 
/*     */     } 
/*     */     
/* 271 */     return new Socket(str, i);
/*     */   }
/*     */ 
/*     */   
/* 275 */   private int getPort(int paramInt) { return (paramInt < 1) ? 80 : paramInt; }
/*     */ 
/*     */   
/*     */   private void fillInOptions() {
/* 279 */     this.opts.setUsageArgs("<options>");
/* 280 */     this.opts.addOption("port", "port", "proxy server port");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 285 */   public static void main(String[] paramArrayOfString) throws IOException { (new ProxyServer(paramArrayOfString)).run(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\debug\ProxyServer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */