package weblogic.webservice.tools.cchecker;

import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.webservice.dd.verify.VerifyException;

public interface checkDD {
  void checkDDParts(WebServicesMBean paramWebServicesMBean) throws VerifyException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkDD.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */