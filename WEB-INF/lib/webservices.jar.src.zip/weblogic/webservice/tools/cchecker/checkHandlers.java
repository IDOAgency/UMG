/*     */ package weblogic.webservice.tools.cchecker;
/*     */ 
/*     */ import weblogic.management.descriptors.webservice.HandlerChainMBean;
/*     */ import weblogic.management.descriptors.webservice.HandlerChainsMBean;
/*     */ import weblogic.management.descriptors.webservice.HandlerMBean;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.webservice.dd.verify.VerifyException;
/*     */ import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class checkHandlers
/*     */   extends checkKernel
/*     */ {
/*     */   private ClassLoader cl;
/*     */   private HandlerChainsMBean chainsMBean;
/*     */   private WebServiceComplianceTextFormatter fmt;
/*     */   private checkInform InformUser;
/*     */   
/*     */   public checkHandlers(HandlerChainsMBean paramHandlerChainsMBean, ClassLoader paramClassLoader) {
/*  24 */     this.fmt = new WebServiceComplianceTextFormatter();
/*     */ 
/*     */     
/*  27 */     this.InformUser = new checkInform();
/*     */ 
/*     */ 
/*     */     
/*  31 */     this.InformUser.debug("checkHandlers()");
/*     */     
/*  33 */     Debug.assertion((paramHandlerChainsMBean != null));
/*  34 */     Debug.assertion((paramClassLoader != null));
/*     */     
/*  36 */     this.chainsMBean = paramHandlerChainsMBean;
/*  37 */     this.cl = paramClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkChains() throws VerifyException {
/*  42 */     this.InformUser.debug("checkChains()");
/*     */     
/*  44 */     Debug.assertion((this.chainsMBean != null));
/*     */     
/*  46 */     HandlerChainMBean[] arrayOfHandlerChainMBean = this.chainsMBean.getHandlerChains();
/*     */     
/*  48 */     for (byte b = 0; b < arrayOfHandlerChainMBean.length; b++) {
/*     */       
/*  50 */       String str = arrayOfHandlerChainMBean[b].getHandlerChainName();
/*     */ 
/*     */       
/*  53 */       if (str == null || "".equals(str))
/*     */       {
/*  55 */         throw new VerifyException(this.fmt.noHandlerChainName());
/*     */       }
/*     */ 
/*     */       
/*  59 */       HandlerMBean[] arrayOfHandlerMBean = arrayOfHandlerChainMBean[b].getHandlers();
/*     */ 
/*     */       
/*  62 */       if (arrayOfHandlerMBean == null || arrayOfHandlerMBean.length == 0) {
/*  63 */         throw new VerifyException(this.fmt.noHandlersInChain(str));
/*     */       }
/*     */       
/*  66 */       for (byte b1 = 0; b1 < arrayOfHandlerMBean.length; b1++) {
/*  67 */         checkHandler(arrayOfHandlerMBean[b1], str);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkHandler(HandlerMBean paramHandlerMBean, String paramString) throws VerifyException {
/*  74 */     this.InformUser.debug("checkHandler() - " + paramString);
/*     */     
/*  76 */     String str = paramHandlerMBean.getClassName();
/*     */     
/*  78 */     if (str == null || "".equals(str)) {
/*  79 */       throw new VerifyException(this.fmt.noHandlerClassName(paramString));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  85 */       Class clazz = this.cl.loadClass(str);
/*     */ 
/*     */       
/*  88 */       if (!javax.xml.rpc.handler.Handler.class.isAssignableFrom(clazz)) {
/*  89 */         throw new VerifyException(this.fmt.doesntExtendHandler(paramString, str));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       if (!hasDefaultCtor(clazz)) {
/*  96 */         throw new VerifyException(this.fmt.handlerNeedsDefaultCtor(paramString, str));
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 101 */     catch (ClassNotFoundException classNotFoundException) {
/* 102 */       throw new VerifyException(this.fmt.cantLoadHandlerClass(paramString, str));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkHandlers.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */