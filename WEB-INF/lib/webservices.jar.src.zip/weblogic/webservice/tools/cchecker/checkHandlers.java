package weblogic.webservice.tools.cchecker;

import weblogic.management.descriptors.webservice.HandlerChainMBean;
import weblogic.management.descriptors.webservice.HandlerChainsMBean;
import weblogic.management.descriptors.webservice.HandlerMBean;
import weblogic.utils.Debug;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;

final class checkHandlers extends checkKernel {
  private ClassLoader cl;
  
  private HandlerChainsMBean chainsMBean;
  
  private WebServiceComplianceTextFormatter fmt;
  
  private checkInform InformUser;
  
  public checkHandlers(HandlerChainsMBean paramHandlerChainsMBean, ClassLoader paramClassLoader) {
    this.fmt = new WebServiceComplianceTextFormatter();
    this.InformUser = new checkInform();
    this.InformUser.debug("checkHandlers()");
    Debug.assertion((paramHandlerChainsMBean != null));
    Debug.assertion((paramClassLoader != null));
    this.chainsMBean = paramHandlerChainsMBean;
    this.cl = paramClassLoader;
  }
  
  public void checkChains() throws VerifyException {
    this.InformUser.debug("checkChains()");
    Debug.assertion((this.chainsMBean != null));
    HandlerChainMBean[] arrayOfHandlerChainMBean = this.chainsMBean.getHandlerChains();
    for (byte b = 0; b < arrayOfHandlerChainMBean.length; b++) {
      String str = arrayOfHandlerChainMBean[b].getHandlerChainName();
      if (str == null || "".equals(str))
        throw new VerifyException(this.fmt.noHandlerChainName()); 
      HandlerMBean[] arrayOfHandlerMBean = arrayOfHandlerChainMBean[b].getHandlers();
      if (arrayOfHandlerMBean == null || arrayOfHandlerMBean.length == 0)
        throw new VerifyException(this.fmt.noHandlersInChain(str)); 
      for (byte b1 = 0; b1 < arrayOfHandlerMBean.length; b1++)
        checkHandler(arrayOfHandlerMBean[b1], str); 
    } 
  }
  
  private void checkHandler(HandlerMBean paramHandlerMBean, String paramString) throws VerifyException {
    this.InformUser.debug("checkHandler() - " + paramString);
    String str = paramHandlerMBean.getClassName();
    if (str == null || "".equals(str))
      throw new VerifyException(this.fmt.noHandlerClassName(paramString)); 
    try {
      Class clazz = this.cl.loadClass(str);
      if (!javax.xml.rpc.handler.Handler.class.isAssignableFrom(clazz))
        throw new VerifyException(this.fmt.doesntExtendHandler(paramString, str)); 
      if (!hasDefaultCtor(clazz))
        throw new VerifyException(this.fmt.handlerNeedsDefaultCtor(paramString, str)); 
    } catch (ClassNotFoundException classNotFoundException) {
      throw new VerifyException(this.fmt.cantLoadHandlerClass(paramString, str));
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkHandlers.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */