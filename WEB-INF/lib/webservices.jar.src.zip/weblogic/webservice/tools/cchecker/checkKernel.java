package weblogic.webservice.tools.cchecker;

import weblogic.kernel.Kernel;

abstract class checkKernel {
  private boolean isServer = Kernel.isServer();
  
  protected boolean isServer() { return this.isServer; }
  
  protected boolean hasDefaultCtor(Class paramClass) {
    try {
      paramClass.getConstructor((Class[])null);
      return true;
    } catch (NoSuchMethodException noSuchMethodException) {
      return false;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkKernel.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */