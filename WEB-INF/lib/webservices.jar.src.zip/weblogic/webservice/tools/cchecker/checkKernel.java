/*    */ package weblogic.webservice.tools.cchecker;
/*    */ 
/*    */ import weblogic.kernel.Kernel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class checkKernel
/*    */ {
/* 13 */   private boolean isServer = Kernel.isServer();
/*    */ 
/*    */ 
/*    */   
/* 17 */   protected boolean isServer() { return this.isServer; }
/*    */ 
/*    */   
/*    */   protected boolean hasDefaultCtor(Class paramClass) {
/*    */     try {
/* 22 */       paramClass.getConstructor((Class[])null);
/*    */       
/* 24 */       return true;
/* 25 */     } catch (NoSuchMethodException noSuchMethodException) {
/* 26 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkKernel.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */