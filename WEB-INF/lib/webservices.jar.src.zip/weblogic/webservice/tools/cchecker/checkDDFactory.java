/*    */ package weblogic.webservice.tools.cchecker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class checkDDFactory
/*    */ {
/* 13 */   public static checkDD newCheckDD(ClassLoader paramClassLoader) { return new checkDDParts(paramClassLoader); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkDDFactory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */