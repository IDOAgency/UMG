/*    */ package weblogic.webservice.tools.cchecker;
/*    */ 
/*    */ import weblogic.management.descriptors.webservice.JavaClassMBean;
/*    */ import weblogic.webservice.dd.verify.VerifyException;
/*    */ import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class checkJavaElements
/*    */   extends checkKernel
/*    */ {
/*    */   private JavaClassMBean[] mbeans;
/*    */   private ClassLoader cl;
/*    */   private WebServiceComplianceTextFormatter fmt;
/*    */   private checkInform InformUser;
/*    */   
/*    */   public checkJavaElements(JavaClassMBean[] paramArrayOfJavaClassMBean, ClassLoader paramClassLoader) {
/* 19 */     this.fmt = new WebServiceComplianceTextFormatter();
/*    */ 
/*    */     
/* 22 */     this.InformUser = new checkInform();
/*    */ 
/*    */     
/* 25 */     this.InformUser.debug("checkJavaElements()");
/*    */     
/* 27 */     this.mbeans = paramArrayOfJavaClassMBean;
/* 28 */     this.cl = paramClassLoader;
/*    */   }
/*    */ 
/*    */   
/*    */   public void checkJavaClasses() throws VerifyException {
/* 33 */     this.InformUser.debug("checkJavaClasses()");
/*    */     
/* 35 */     for (byte b = 0; b < this.mbeans.length; b++) {
/*    */       
/* 37 */       String str = this.mbeans[b].getClassName();
/*    */ 
/*    */       
/*    */       try {
/* 41 */         this.InformUser.debug("checkJavaClasses() Loading: " + str);
/*    */         
/* 43 */         Class clazz = this.cl.loadClass(str);
/*    */         
/* 45 */         if (!hasDefaultCtor(clazz)) {
/* 46 */           this.InformUser.say(this.fmt.javaComponentNeedsDefaultCtor(this.mbeans[b].getComponentName(), str));
/*    */ 
/*    */           
/* 49 */           if (ComplianceChecker.stopOnError) {
/* 50 */             throw new VerifyException("ComplianceChecker - execution halted.");
/*    */           }
/*    */         }
/*    */       
/* 54 */       } catch (ClassNotFoundException classNotFoundException) {
/* 55 */         this.InformUser.say(this.fmt.javaComponentClassNotFound(this.mbeans[b].getComponentName(), str));
/*    */ 
/*    */         
/* 58 */         if (ComplianceChecker.stopOnError)
/* 59 */           throw new VerifyException("ComplianceChecker - execution halted."); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkJavaElements.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */