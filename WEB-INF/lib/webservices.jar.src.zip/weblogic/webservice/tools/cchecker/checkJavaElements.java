package weblogic.webservice.tools.cchecker;

import weblogic.management.descriptors.webservice.JavaClassMBean;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;

public final class checkJavaElements extends checkKernel {
  private JavaClassMBean[] mbeans;
  
  private ClassLoader cl;
  
  private WebServiceComplianceTextFormatter fmt;
  
  private checkInform InformUser;
  
  public checkJavaElements(JavaClassMBean[] paramArrayOfJavaClassMBean, ClassLoader paramClassLoader) {
    this.fmt = new WebServiceComplianceTextFormatter();
    this.InformUser = new checkInform();
    this.InformUser.debug("checkJavaElements()");
    this.mbeans = paramArrayOfJavaClassMBean;
    this.cl = paramClassLoader;
  }
  
  public void checkJavaClasses() throws VerifyException {
    this.InformUser.debug("checkJavaClasses()");
    for (byte b = 0; b < this.mbeans.length; b++) {
      String str = this.mbeans[b].getClassName();
      try {
        this.InformUser.debug("checkJavaClasses() Loading: " + str);
        Class clazz = this.cl.loadClass(str);
        if (!hasDefaultCtor(clazz)) {
          this.InformUser.say(this.fmt.javaComponentNeedsDefaultCtor(this.mbeans[b].getComponentName(), str));
          if (ComplianceChecker.stopOnError)
            throw new VerifyException("ComplianceChecker - execution halted."); 
        } 
      } catch (ClassNotFoundException classNotFoundException) {
        this.InformUser.say(this.fmt.javaComponentClassNotFound(this.mbeans[b].getComponentName(), str));
        if (ComplianceChecker.stopOnError)
          throw new VerifyException("ComplianceChecker - execution halted."); 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkJavaElements.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */