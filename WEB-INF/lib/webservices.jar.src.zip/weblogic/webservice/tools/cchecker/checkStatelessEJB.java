package weblogic.webservice.tools.cchecker;

import javax.naming.NamingException;
import weblogic.management.descriptors.webservice.StatelessEJBMBean;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;
import weblogic.webservice.util.EJBHelper;

public final class checkStatelessEJB extends checkKernel {
  private StatelessEJBMBean[] mbeans;
  
  private checkInform InformUser;
  
  private WebServiceComplianceTextFormatter fmt;
  
  public checkStatelessEJB(StatelessEJBMBean[] paramArrayOfStatelessEJBMBean) {
    this.InformUser = new checkInform();
    this.fmt = new WebServiceComplianceTextFormatter();
    this.InformUser.debug("checkStatelessEJB()");
    this.mbeans = paramArrayOfStatelessEJBMBean;
  }
  
  public void checkEJB() throws VerifyException {
    this.InformUser.debug("checkEJB()");
    for (byte b = 0; b < this.mbeans.length; b++) {
      if (this.mbeans[b].getEJBLink() == null && this.mbeans[b].getJNDIName() == null)
        throw new VerifyException(this.fmt.mustSpecifyJNDIOrEJBLink(this.mbeans[b].getComponentName())); 
      if (isServer()) {
        String str;
        boolean bool = true;
        if (this.mbeans[b].getEJBLink() != null) {
          bool = true;
          str = this.mbeans[b].getEJBLink().getPath();
        } else {
          bool = false;
          str = this.mbeans[b].getJNDIName().getPath();
        } 
        if (str == null)
          throw new VerifyException(this.fmt.mustSpecifyJNDIOrEJBLink(this.mbeans[b].getComponentName())); 
        try {
          Object object = EJBHelper.getEJBHome(this.mbeans[b]);
          object.getClass().getMethod("create", (Class[])null);
        } catch (NamingException namingException) {
          String str1 = WebServiceLogger.logComplianceCheckerNamingException();
          WebServiceLogger.logStackTrace(str1, namingException);
          if (bool)
            throw new VerifyException(this.fmt.couldntFindEJBLink(this.mbeans[b].getComponentName(), str, namingException)); 
          throw new VerifyException(this.fmt.couldntFindJNDIName(this.mbeans[b].getComponentName(), str, namingException));
        } catch (ClassCastException classCastException) {
          if (bool)
            throw new VerifyException(this.fmt.ejbLinkWasNotEJBHome(this.mbeans[b].getComponentName(), str)); 
          throw new VerifyException(this.fmt.jndiNameWasNotEJBHome(this.mbeans[b].getComponentName(), str));
        } catch (NoSuchMethodException noSuchMethodException) {
          if (bool)
            throw new VerifyException(this.fmt.ejbLinkWasNotStateless(this.mbeans[b].getComponentName(), str)); 
          throw new VerifyException(this.fmt.jndiNameWasNotStateless(this.mbeans[b].getComponentName(), str));
        } 
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkStatelessEJB.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */