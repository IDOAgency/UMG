/*     */ package weblogic.webservice.tools.cchecker;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import weblogic.management.descriptors.webservice.StatelessEJBMBean;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.dd.verify.VerifyException;
/*     */ import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;
/*     */ import weblogic.webservice.util.EJBHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class checkStatelessEJB
/*     */   extends checkKernel
/*     */ {
/*     */   private StatelessEJBMBean[] mbeans;
/*     */   private checkInform InformUser;
/*     */   private WebServiceComplianceTextFormatter fmt;
/*     */   
/*     */   public checkStatelessEJB(StatelessEJBMBean[] paramArrayOfStatelessEJBMBean) {
/*  21 */     this.InformUser = new checkInform();
/*     */     
/*  23 */     this.fmt = new WebServiceComplianceTextFormatter();
/*     */ 
/*     */ 
/*     */     
/*  27 */     this.InformUser.debug("checkStatelessEJB()");
/*     */     
/*  29 */     this.mbeans = paramArrayOfStatelessEJBMBean;
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkEJB() throws VerifyException {
/*  34 */     this.InformUser.debug("checkEJB()");
/*     */     
/*  36 */     for (byte b = 0; b < this.mbeans.length; b++) {
/*     */ 
/*     */       
/*  39 */       if (this.mbeans[b].getEJBLink() == null && this.mbeans[b].getJNDIName() == null) {
/*  40 */         throw new VerifyException(this.fmt.mustSpecifyJNDIOrEJBLink(this.mbeans[b].getComponentName()));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*  45 */       if (isServer()) {
/*     */         String str;
/*  47 */         boolean bool = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  53 */         if (this.mbeans[b].getEJBLink() != null) {
/*  54 */           bool = true;
/*  55 */           str = this.mbeans[b].getEJBLink().getPath();
/*     */         } else {
/*  57 */           bool = false;
/*  58 */           str = this.mbeans[b].getJNDIName().getPath();
/*     */         } 
/*     */ 
/*     */         
/*  62 */         if (str == null) {
/*  63 */           throw new VerifyException(this.fmt.mustSpecifyJNDIOrEJBLink(this.mbeans[b].getComponentName()));
/*     */         }
/*     */ 
/*     */         
/*     */         try {
/*  68 */           Object object = EJBHelper.getEJBHome(this.mbeans[b]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  75 */           object.getClass().getMethod("create", (Class[])null);
/*     */         
/*     */         }
/*  78 */         catch (NamingException namingException) {
/*     */           
/*  80 */           String str1 = WebServiceLogger.logComplianceCheckerNamingException();
/*  81 */           WebServiceLogger.logStackTrace(str1, namingException);
/*     */           
/*  83 */           if (bool) {
/*  84 */             throw new VerifyException(this.fmt.couldntFindEJBLink(this.mbeans[b].getComponentName(), str, namingException));
/*     */           }
/*     */           
/*  87 */           throw new VerifyException(this.fmt.couldntFindJNDIName(this.mbeans[b].getComponentName(), str, namingException));
/*     */         
/*     */         }
/*  90 */         catch (ClassCastException classCastException) {
/*     */           
/*  92 */           if (bool) {
/*  93 */             throw new VerifyException(this.fmt.ejbLinkWasNotEJBHome(this.mbeans[b].getComponentName(), str));
/*     */           }
/*     */           
/*  96 */           throw new VerifyException(this.fmt.jndiNameWasNotEJBHome(this.mbeans[b].getComponentName(), str));
/*     */         
/*     */         }
/*  99 */         catch (NoSuchMethodException noSuchMethodException) {
/*     */           
/* 101 */           if (bool) {
/* 102 */             throw new VerifyException(this.fmt.ejbLinkWasNotStateless(this.mbeans[b].getComponentName(), str));
/*     */           }
/*     */           
/* 105 */           throw new VerifyException(this.fmt.jndiNameWasNotStateless(this.mbeans[b].getComponentName(), str));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkStatelessEJB.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */