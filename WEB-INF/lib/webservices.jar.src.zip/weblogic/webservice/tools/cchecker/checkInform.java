/*    */ package weblogic.webservice.tools.cchecker;
/*    */ 
/*    */ import weblogic.utils.Debug;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class checkInform
/*    */ {
/*    */   public void say(String paramString) {
/* 19 */     if (ComplianceChecker.traceLevel != 0) {
/* 20 */       System.out.println(paramString);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void say(String paramString, int paramInt) {
/* 26 */     if (paramInt <= ComplianceChecker.traceLevel) {
/* 27 */       System.out.println(paramString);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void debug(String paramString) {
/* 33 */     if (ComplianceChecker.verbose)
/* 34 */       Debug.say(paramString); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkInform.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */