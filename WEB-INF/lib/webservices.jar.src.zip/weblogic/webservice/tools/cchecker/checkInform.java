package weblogic.webservice.tools.cchecker;

import weblogic.utils.Debug;

public final class checkInform {
  public void say(String paramString) {
    if (ComplianceChecker.traceLevel != 0)
      System.out.println(paramString); 
  }
  
  public void say(String paramString, int paramInt) {
    if (paramInt <= ComplianceChecker.traceLevel)
      System.out.println(paramString); 
  }
  
  public void debug(String paramString) {
    if (ComplianceChecker.verbose)
      Debug.say(paramString); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkInform.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */