package weblogic.webservice.tools.cchecker;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.jar.JarEntry;
import java.util.zip.ZipEntry;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.servlet.internal.WarClassFinder;
import weblogic.utils.PlatformConstants;
import weblogic.utils.classloaders.GenericClassLoader;
import weblogic.utils.compiler.Tool;
import weblogic.utils.compiler.ToolFailureException;
import weblogic.utils.jars.JarFileUtils;
import weblogic.utils.jars.VirtualJarFactory;
import weblogic.utils.jars.VirtualJarFile;
import weblogic.webservice.dd.DDLoader;
import weblogic.webservice.dd.DDProcessingException;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;

public final class ComplianceChecker extends Tool implements PlatformConstants {
  public static int traceLevel = 1;
  
  public static boolean verbose = false;
  
  public static boolean stopOnError = false;
  
  protected static final int traceQuiet = 0;
  
  protected static final int traceNormal = 1;
  
  protected static final int traceMore = 2;
  
  protected static final int traceAll = 3;
  
  private ClassLoader cl = null;
  
  private WebServicesMBean mbean = null;
  
  private String fName = null;
  
  private String f2Name = null;
  
  private Iterator jarEntries;
  
  private ZipEntry currentEntry = null;
  
  public File ccTmpDir;
  
  private WebServiceComplianceTextFormatter fmt = new WebServiceComplianceTextFormatter();
  
  private checkInform InformUser = new checkInform();
  
  public ComplianceChecker(String[] paramArrayOfString) { super(paramArrayOfString); }
  
  public void prepare() {
    this.opts.addFlag("stopOnError", "Halts the Compliance Checker on the first error.");
    this.opts.addOption("traceLevel", "1", "0=quiet, 1=Normal [Default], 2=Specific test executed, 3=All information");
    this.opts.addFlag("verbose", "Displays the Compliance Checker debug messages.");
    this.opts.markPrivate("verbose");
    this.opts.setUsageArgs(this.fmt.complianceCheckerHelp());
  }
  
  public void runBody() {
    checkToolInputs();
    String[] arrayOfString = this.opts.args();
    runAnt(arrayOfString[0]);
  }
  
  public void runAnt(String paramString) throws VerifyException, ToolFailureException, IOException, DDProcessingException { checkToolFile(paramString); }
  
  private void checkToolFile(String paramString) throws VerifyException, ToolFailureException, IOException, DDProcessingException {
    this.InformUser.debug("checkToolFile(" + paramString + ")");
    File file = new File(paramString);
    this.fName = file.getName();
    if (!file.exists())
      throw new ToolFailureException(this.fmt.noFileOrDirectorNamed(paramString)); 
    if (!file.canRead())
      throw new ToolFailureException(this.fmt.noReadPermission(paramString)); 
    DDLoader dDLoader = new DDLoader();
    if (file.isDirectory()) {
      this.InformUser.say("Processing directory as exploded webservice WAR or EAR: " + this.fName, 3);
      VirtualJarFile virtualJarFile = VirtualJarFactory.createVirtualJar(file);
      this.mbean = dDLoader.load(virtualJarFile);
      this.cl = new GenericClassLoader(new WarClassFinder(file.getAbsolutePath()));
      checkExecute();
    } else if (this.fName.endsWith(".xml") || this.fName.endsWith(".XML")) {
      this.InformUser.say("Processing the webservice deployment descriptor: " + this.fName, 3);
      fileInputStream = null;
      try {
        fileInputStream = new FileInputStream(file);
        this.mbean = dDLoader.load(fileInputStream);
        this.cl = getClass().getClassLoader();
      } finally {
        if (fileInputStream != null)
          try {
            fileInputStream.close();
          } catch (IOException iOException) {} 
      } 
      checkExecute();
    } else if (this.fName.endsWith(".war") || this.fName.endsWith(".WAR")) {
      this.InformUser.say("Processing the webservice WAR file: " + this.fName, 3);
      VirtualJarFile virtualJarFile = VirtualJarFactory.createVirtualJar(file);
      this.mbean = dDLoader.load(virtualJarFile);
      this.cl = new GenericClassLoader(new WarClassFinder(file.getAbsolutePath()));
      checkExecute();
      try {
        if (virtualJarFile != null)
          virtualJarFile.close(); 
      } catch (IOException iOException) {}
    } else if (this.fName.endsWith(".ear") || this.fName.endsWith(".EAR")) {
      this.InformUser.say("Processing the webservice EAR file: " + this.fName, 3);
      VirtualJarFile virtualJarFile = VirtualJarFactory.createVirtualJar(file);
      this.jarEntries = virtualJarFile.entries();
      boolean bool = false;
      String str = null;
      while (this.jarEntries.hasNext()) {
        this.currentEntry = (JarEntry)this.jarEntries.next();
        str = this.currentEntry.getName();
        this.InformUser.debug("EAR entry: " + str);
        if (str.endsWith(".war") || str.endsWith(".WAR")) {
          bool = true;
          JarFileUtils.extract(virtualJarFile, this.ccTmpDir);
          this.ccTmpDir;
          File file1 = new File(this.ccTmpDir.getAbsolutePath() + File.separatorChar + str);
          this.f2Name = file1.getName();
          this.InformUser.say("Opening WAR located: " + file1.getAbsolutePath(), 3);
          VirtualJarFile virtualJarFile1 = VirtualJarFactory.createVirtualJar(file1);
          this.mbean = dDLoader.load(virtualJarFile1);
          this.cl = new GenericClassLoader(new WarClassFinder(file1.getAbsolutePath()));
          checkExecute();
          this.mbean = null;
          this.cl = null;
          try {
            if (virtualJarFile1 != null)
              virtualJarFile1.close(); 
          } catch (IOException iOException) {}
        } 
      } 
      try {
        if (virtualJarFile != null)
          virtualJarFile.close(); 
      } catch (IOException iOException) {}
      if (!bool)
        throw new ToolFailureException(this.fmt.couldNotFindWARinEAR(this.fName)); 
    } else {
      throw new ToolFailureException(this.fmt.unrecognizedFileType(paramString));
    } 
  }
  
  public void runChecker(VirtualJarFile paramVirtualJarFile, GenericClassLoader paramGenericClassLoader, boolean paramBoolean) throws VerifyException, ToolFailureException, IOException, DDProcessingException {
    if (paramBoolean) {
      traceLevel = 3;
    } else {
      traceLevel = 0;
    } 
    DDLoader dDLoader = new DDLoader();
    this.mbean = dDLoader.load(paramVirtualJarFile);
    this.cl = paramGenericClassLoader;
    checkExecute();
  }
  
  public void checkExecute() {
    if (this.mbean == null)
      throw new ToolFailureException(this.fmt.noWebServiceMbean(this.fName)); 
    if (this.cl == null)
      throw new ToolFailureException(this.fmt.noWebServiceClassLoader(this.fName)); 
    this.InformUser.debug("Instantiating new checkDD");
    checkDD checkDD = checkDDFactory.newCheckDD(this.cl);
    this.InformUser.debug("Executing the checkDD in the WebserviceMbean");
    checkDD.checkDDParts(this.mbean);
    if (traceLevel > 0)
      this.InformUser.say(this.fmt.normalCompletion()); 
  }
  
  private void checkToolInputs() {
    if (this.opts.hasOption("verbose"))
      verbose = true; 
    this.InformUser.debug("checkToolInputs()");
    if (this.opts.args().length < 1 || this.opts.args().length > 2) {
      this.opts.usageError(this.fmt.noFilesGiven());
      this.InformUser.say(this.fmt.complianceCheckerHelp());
      throw new ToolFailureException(this.fmt.invalidArgsGiven());
    } 
    checkTraceLevel(this.opts.getOption("traceLevel"));
    if (this.opts.hasOption("stopOnError"))
      stopOnError = true; 
    String str = System.getProperty("java.io.tempdir");
    if (str == null) {
      String str1 = System.getProperty("os.name");
      if (str1 != null && str1.toLowerCase().indexOf("windows") > 0) {
        str = "C:\\TMP";
      } else {
        str = "/tmp";
      } 
    } 
    this.ccTmpDir = new File(str);
    this.ccTmpDir = new File(this.ccTmpDir, "_wl_ccheck_tmp");
    this.ccTmpDir.mkdirs();
  }
  
  public void checkTraceLevel(String paramString) throws VerifyException, ToolFailureException, IOException, DDProcessingException {
    if (paramString == null) {
      traceLevel = 1;
    } else if (paramString.equals("0")) {
      traceLevel = 0;
    } else if (paramString.equals("2")) {
      traceLevel = 2;
    } else if (paramString.equals("3")) {
      traceLevel = 3;
    } 
  }
  
  public static void main(String[] paramArrayOfString) { (new ComplianceChecker(paramArrayOfString)).run(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\ComplianceChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */