/*     */ package weblogic.webservice.tools.cchecker;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.zip.ZipEntry;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.servlet.internal.WarClassFinder;
/*     */ import weblogic.utils.PlatformConstants;
/*     */ import weblogic.utils.classloaders.GenericClassLoader;
/*     */ import weblogic.utils.compiler.Tool;
/*     */ import weblogic.utils.compiler.ToolFailureException;
/*     */ import weblogic.utils.jars.JarFileUtils;
/*     */ import weblogic.utils.jars.VirtualJarFactory;
/*     */ import weblogic.utils.jars.VirtualJarFile;
/*     */ import weblogic.webservice.dd.DDLoader;
/*     */ import weblogic.webservice.dd.DDProcessingException;
/*     */ import weblogic.webservice.dd.verify.VerifyException;
/*     */ import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ComplianceChecker
/*     */   extends Tool
/*     */   implements PlatformConstants
/*     */ {
/*  33 */   public static int traceLevel = 1;
/*     */   
/*     */   public static boolean verbose = false;
/*     */   public static boolean stopOnError = false;
/*     */   protected static final int traceQuiet = 0;
/*     */   protected static final int traceNormal = 1;
/*     */   protected static final int traceMore = 2;
/*     */   protected static final int traceAll = 3;
/*  41 */   private ClassLoader cl = null;
/*  42 */   private WebServicesMBean mbean = null;
/*  43 */   private String fName = null;
/*  44 */   private String f2Name = null;
/*     */   private Iterator jarEntries;
/*  46 */   private ZipEntry currentEntry = null;
/*     */   
/*     */   public File ccTmpDir;
/*  49 */   private WebServiceComplianceTextFormatter fmt = new WebServiceComplianceTextFormatter();
/*     */ 
/*     */   
/*  52 */   private checkInform InformUser = new checkInform();
/*     */ 
/*     */   
/*  55 */   public ComplianceChecker(String[] paramArrayOfString) { super(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void prepare() {
/*  60 */     this.opts.addFlag("stopOnError", "Halts the Compliance Checker on the first error.");
/*     */ 
/*     */     
/*  63 */     this.opts.addOption("traceLevel", "1", "0=quiet, 1=Normal [Default], 2=Specific test executed, 3=All information");
/*     */ 
/*     */     
/*  66 */     this.opts.addFlag("verbose", "Displays the Compliance Checker debug messages.");
/*     */     
/*  68 */     this.opts.markPrivate("verbose");
/*     */     
/*  70 */     this.opts.setUsageArgs(this.fmt.complianceCheckerHelp());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void runBody() {
/*  79 */     checkToolInputs();
/*     */     
/*  81 */     String[] arrayOfString = this.opts.args();
/*     */ 
/*     */     
/*  84 */     runAnt(arrayOfString[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public void runAnt(String paramString) throws VerifyException, ToolFailureException, IOException, DDProcessingException { checkToolFile(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkToolFile(String paramString) throws VerifyException, ToolFailureException, IOException, DDProcessingException {
/*  97 */     this.InformUser.debug("checkToolFile(" + paramString + ")");
/*     */     
/*  99 */     File file = new File(paramString);
/*     */     
/* 101 */     this.fName = file.getName();
/*     */     
/* 103 */     if (!file.exists())
/* 104 */       throw new ToolFailureException(this.fmt.noFileOrDirectorNamed(paramString)); 
/* 105 */     if (!file.canRead()) {
/* 106 */       throw new ToolFailureException(this.fmt.noReadPermission(paramString));
/*     */     }
/*     */     
/* 109 */     DDLoader dDLoader = new DDLoader();
/*     */     
/* 111 */     if (file.isDirectory()) {
/* 112 */       this.InformUser.say("Processing directory as exploded webservice WAR or EAR: " + this.fName, 3);
/*     */ 
/*     */       
/* 115 */       VirtualJarFile virtualJarFile = VirtualJarFactory.createVirtualJar(file);
/*     */       
/* 117 */       this.mbean = dDLoader.load(virtualJarFile);
/* 118 */       this.cl = new GenericClassLoader(new WarClassFinder(file.getAbsolutePath()));
/*     */       
/* 120 */       checkExecute();
/*     */     }
/* 122 */     else if (this.fName.endsWith(".xml") || this.fName.endsWith(".XML")) {
/* 123 */       this.InformUser.say("Processing the webservice deployment descriptor: " + this.fName, 3);
/*     */ 
/*     */       
/* 126 */       fileInputStream = null;
/*     */       
/*     */       try {
/* 129 */         fileInputStream = new FileInputStream(file);
/*     */         
/* 131 */         this.mbean = dDLoader.load(fileInputStream);
/* 132 */         this.cl = getClass().getClassLoader();
/*     */       } finally {
/*     */         
/* 135 */         if (fileInputStream != null) {
/*     */           try {
/* 137 */             fileInputStream.close();
/* 138 */           } catch (IOException iOException) {}
/*     */         }
/*     */       } 
/*     */       
/* 142 */       checkExecute();
/*     */     }
/* 144 */     else if (this.fName.endsWith(".war") || this.fName.endsWith(".WAR")) {
/* 145 */       this.InformUser.say("Processing the webservice WAR file: " + this.fName, 3);
/*     */ 
/*     */       
/* 148 */       VirtualJarFile virtualJarFile = VirtualJarFactory.createVirtualJar(file);
/*     */       
/* 150 */       this.mbean = dDLoader.load(virtualJarFile);
/* 151 */       this.cl = new GenericClassLoader(new WarClassFinder(file.getAbsolutePath()));
/* 152 */       checkExecute();
/*     */ 
/*     */       
/* 155 */       try { if (virtualJarFile != null) virtualJarFile.close();  } catch (IOException iOException) {}
/*     */     }
/* 157 */     else if (this.fName.endsWith(".ear") || this.fName.endsWith(".EAR")) {
/* 158 */       this.InformUser.say("Processing the webservice EAR file: " + this.fName, 3);
/*     */ 
/*     */       
/* 161 */       VirtualJarFile virtualJarFile = VirtualJarFactory.createVirtualJar(file);
/*     */       
/* 163 */       this.jarEntries = virtualJarFile.entries();
/*     */       
/* 165 */       boolean bool = false;
/* 166 */       String str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 175 */       while (this.jarEntries.hasNext()) {
/* 176 */         this.currentEntry = (JarEntry)this.jarEntries.next();
/* 177 */         str = this.currentEntry.getName();
/*     */         
/* 179 */         this.InformUser.debug("EAR entry: " + str);
/*     */         
/* 181 */         if (str.endsWith(".war") || str.endsWith(".WAR")) {
/* 182 */           bool = true;
/*     */           
/* 184 */           JarFileUtils.extract(virtualJarFile, this.ccTmpDir);
/*     */           
/* 186 */           this.ccTmpDir; File file1 = new File(this.ccTmpDir.getAbsolutePath() + File.separatorChar + str);
/*     */ 
/*     */           
/* 189 */           this.f2Name = file1.getName();
/*     */           
/* 191 */           this.InformUser.say("Opening WAR located: " + file1.getAbsolutePath(), 3);
/*     */ 
/*     */           
/* 194 */           VirtualJarFile virtualJarFile1 = VirtualJarFactory.createVirtualJar(file1);
/*     */           
/* 196 */           this.mbean = dDLoader.load(virtualJarFile1);
/* 197 */           this.cl = new GenericClassLoader(new WarClassFinder(file1.getAbsolutePath()));
/*     */           
/* 199 */           checkExecute();
/*     */           
/* 201 */           this.mbean = null;
/* 202 */           this.cl = null;
/*     */           
/* 204 */           try { if (virtualJarFile1 != null) virtualJarFile1.close();  } catch (IOException iOException) {}
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 210 */       try { if (virtualJarFile != null) virtualJarFile.close();  } catch (IOException iOException) {}
/*     */       
/* 212 */       if (!bool) {
/* 213 */         throw new ToolFailureException(this.fmt.couldNotFindWARinEAR(this.fName));
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 218 */       throw new ToolFailureException(this.fmt.unrecognizedFileType(paramString));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void runChecker(VirtualJarFile paramVirtualJarFile, GenericClassLoader paramGenericClassLoader, boolean paramBoolean) throws VerifyException, ToolFailureException, IOException, DDProcessingException {
/* 231 */     if (paramBoolean) {
/* 232 */       traceLevel = 3;
/*     */     } else {
/* 234 */       traceLevel = 0;
/*     */     } 
/* 236 */     DDLoader dDLoader = new DDLoader();
/* 237 */     this.mbean = dDLoader.load(paramVirtualJarFile);
/* 238 */     this.cl = paramGenericClassLoader;
/* 239 */     checkExecute();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkExecute() {
/* 246 */     if (this.mbean == null) {
/* 247 */       throw new ToolFailureException(this.fmt.noWebServiceMbean(this.fName));
/*     */     }
/*     */     
/* 250 */     if (this.cl == null) {
/* 251 */       throw new ToolFailureException(this.fmt.noWebServiceClassLoader(this.fName));
/*     */     }
/*     */ 
/*     */     
/* 255 */     this.InformUser.debug("Instantiating new checkDD");
/*     */     
/* 257 */     checkDD checkDD = checkDDFactory.newCheckDD(this.cl);
/*     */     
/* 259 */     this.InformUser.debug("Executing the checkDD in the WebserviceMbean");
/* 260 */     checkDD.checkDDParts(this.mbean);
/*     */ 
/*     */     
/* 263 */     if (traceLevel > 0) {
/* 264 */       this.InformUser.say(this.fmt.normalCompletion());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkToolInputs() {
/* 276 */     if (this.opts.hasOption("verbose")) {
/* 277 */       verbose = true;
/*     */     }
/*     */     
/* 280 */     this.InformUser.debug("checkToolInputs()");
/*     */ 
/*     */     
/* 283 */     if (this.opts.args().length < 1 || this.opts.args().length > 2) {
/* 284 */       this.opts.usageError(this.fmt.noFilesGiven());
/* 285 */       this.InformUser.say(this.fmt.complianceCheckerHelp());
/*     */       
/* 287 */       throw new ToolFailureException(this.fmt.invalidArgsGiven());
/*     */     } 
/*     */     
/* 290 */     checkTraceLevel(this.opts.getOption("traceLevel"));
/*     */     
/* 292 */     if (this.opts.hasOption("stopOnError")) {
/* 293 */       stopOnError = true;
/*     */     }
/*     */ 
/*     */     
/* 297 */     String str = System.getProperty("java.io.tempdir");
/*     */     
/* 299 */     if (str == null) {
/* 300 */       String str1 = System.getProperty("os.name");
/*     */       
/* 302 */       if (str1 != null && str1.toLowerCase().indexOf("windows") > 0) {
/* 303 */         str = "C:\\TMP";
/*     */       } else {
/* 305 */         str = "/tmp";
/*     */       } 
/*     */     } 
/*     */     
/* 309 */     this.ccTmpDir = new File(str);
/* 310 */     this.ccTmpDir = new File(this.ccTmpDir, "_wl_ccheck_tmp");
/*     */     
/* 312 */     this.ccTmpDir.mkdirs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkTraceLevel(String paramString) throws VerifyException, ToolFailureException, IOException, DDProcessingException {
/* 321 */     if (paramString == null) {
/* 322 */       traceLevel = 1;
/* 323 */     } else if (paramString.equals("0")) {
/* 324 */       traceLevel = 0;
/* 325 */     } else if (paramString.equals("2")) {
/* 326 */       traceLevel = 2;
/* 327 */     } else if (paramString.equals("3")) {
/* 328 */       traceLevel = 3;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 334 */   public static void main(String[] paramArrayOfString) { (new ComplianceChecker(paramArrayOfString)).run(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\ComplianceChecker.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */