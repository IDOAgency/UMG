package weblogic.webservice.tools.cchecker;

import weblogic.management.descriptors.webservice.ComponentsMBean;
import weblogic.management.descriptors.webservice.HandlerChainsMBean;
import weblogic.management.descriptors.webservice.JavaClassMBean;
import weblogic.management.descriptors.webservice.StatelessEJBMBean;
import weblogic.management.descriptors.webservice.WebServiceMBean;
import weblogic.management.descriptors.webservice.WebServicesMBean;
import weblogic.webservice.dd.verify.VerifyException;
import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;

public final class checkDDParts implements checkDD {
  private static final boolean debug = true;
  
  private static final boolean verbose = true;
  
  private ClassLoader cl;
  
  private WebServiceComplianceTextFormatter fmt;
  
  private checkInform InformUser;
  
  checkDDParts(ClassLoader paramClassLoader) {
    this.fmt = new WebServiceComplianceTextFormatter();
    this.InformUser = new checkInform();
    this.InformUser.debug("checkDDParts(ClassLoader)");
    this.cl = paramClassLoader;
  }
  
  public void checkDDParts(WebServicesMBean paramWebServicesMBean) throws VerifyException {
    this.InformUser.debug("checkDDParts(WebServiceMBean)");
    checkHandlerChains(paramWebServicesMBean);
    WebServiceMBean[] arrayOfWebServiceMBean = paramWebServicesMBean.getWebServices();
    if (arrayOfWebServiceMBean == null || arrayOfWebServiceMBean.length == 0)
      throw new VerifyException(this.fmt.noWebServices()); 
    for (byte b = 0; b < arrayOfWebServiceMBean.length; b++)
      checkWebService(arrayOfWebServiceMBean[b]); 
  }
  
  private void checkHandlerChains(WebServicesMBean paramWebServicesMBean) throws VerifyException {
    this.InformUser.say("checkHandlerChains()", 2);
    HandlerChainsMBean handlerChainsMBean = paramWebServicesMBean.getHandlerChains();
    if (handlerChainsMBean != null) {
      checkHandlers checkHandlers = new checkHandlers(handlerChainsMBean, this.cl);
      checkHandlers.checkChains();
    } else {
      this.InformUser.say("checkHandlerChains() = null", 3);
    } 
  }
  
  private void checkWebService(WebServiceMBean paramWebServiceMBean) throws VerifyException {
    this.InformUser.say("checkWebService()", 2);
    checkComponents(paramWebServiceMBean.getComponents());
  }
  
  private void checkComponents(ComponentsMBean paramComponentsMBean) throws VerifyException {
    this.InformUser.say("checkComponents()", 2);
    if (paramComponentsMBean == null) {
      this.InformUser.say("checkComponents() = null", 3);
      return;
    } 
    JavaClassMBean[] arrayOfJavaClassMBean = paramComponentsMBean.getJavaClassComponents();
    if (arrayOfJavaClassMBean != null && arrayOfJavaClassMBean.length > 0) {
      this.InformUser.debug("checkJavaElements() Java Classes");
      checkJavaElements checkJavaElements = new checkJavaElements(arrayOfJavaClassMBean, this.cl);
      checkJavaElements.checkJavaClasses();
    } else {
      this.InformUser.debug("checkComponents() no Java Classes");
    } 
    StatelessEJBMBean[] arrayOfStatelessEJBMBean = paramComponentsMBean.getStatelessEJBs();
    if (arrayOfStatelessEJBMBean != null && arrayOfStatelessEJBMBean.length > 0) {
      this.InformUser.debug("checkComponents() EJB Components");
      checkStatelessEJB checkStatelessEJB = new checkStatelessEJB(arrayOfStatelessEJBMBean);
      checkStatelessEJB.checkEJB();
    } else {
      this.InformUser.debug("checkComponents() no EJB Components");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkDDParts.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */