/*     */ package weblogic.webservice.tools.cchecker;
/*     */ 
/*     */ import weblogic.management.descriptors.webservice.ComponentsMBean;
/*     */ import weblogic.management.descriptors.webservice.HandlerChainsMBean;
/*     */ import weblogic.management.descriptors.webservice.JavaClassMBean;
/*     */ import weblogic.management.descriptors.webservice.StatelessEJBMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServiceMBean;
/*     */ import weblogic.management.descriptors.webservice.WebServicesMBean;
/*     */ import weblogic.webservice.dd.verify.VerifyException;
/*     */ import weblogic.webservice.dd.verify.WebServiceComplianceTextFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class checkDDParts
/*     */   implements checkDD
/*     */ {
/*     */   private static final boolean debug = true;
/*     */   private static final boolean verbose = true;
/*     */   private ClassLoader cl;
/*     */   private WebServiceComplianceTextFormatter fmt;
/*     */   private checkInform InformUser;
/*     */   
/*     */   checkDDParts(ClassLoader paramClassLoader) {
/*  36 */     this.fmt = new WebServiceComplianceTextFormatter();
/*     */ 
/*     */     
/*  39 */     this.InformUser = new checkInform();
/*     */ 
/*     */     
/*  42 */     this.InformUser.debug("checkDDParts(ClassLoader)");
/*     */     
/*  44 */     this.cl = paramClassLoader;
/*     */   }
/*     */ 
/*     */   
/*     */   public void checkDDParts(WebServicesMBean paramWebServicesMBean) throws VerifyException {
/*  49 */     this.InformUser.debug("checkDDParts(WebServiceMBean)");
/*     */     
/*  51 */     checkHandlerChains(paramWebServicesMBean);
/*     */     
/*  53 */     WebServiceMBean[] arrayOfWebServiceMBean = paramWebServicesMBean.getWebServices();
/*     */     
/*  55 */     if (arrayOfWebServiceMBean == null || arrayOfWebServiceMBean.length == 0) {
/*  56 */       throw new VerifyException(this.fmt.noWebServices());
/*     */     }
/*     */     
/*  59 */     for (byte b = 0; b < arrayOfWebServiceMBean.length; b++)
/*     */     {
/*  61 */       checkWebService(arrayOfWebServiceMBean[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkHandlerChains(WebServicesMBean paramWebServicesMBean) throws VerifyException {
/*  68 */     this.InformUser.say("checkHandlerChains()", 2);
/*     */     
/*  70 */     HandlerChainsMBean handlerChainsMBean = paramWebServicesMBean.getHandlerChains();
/*     */     
/*  72 */     if (handlerChainsMBean != null) {
/*  73 */       checkHandlers checkHandlers = new checkHandlers(handlerChainsMBean, this.cl);
/*     */ 
/*     */       
/*  76 */       checkHandlers.checkChains();
/*     */     } else {
/*  78 */       this.InformUser.say("checkHandlerChains() = null", 3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkWebService(WebServiceMBean paramWebServiceMBean) throws VerifyException {
/*  85 */     this.InformUser.say("checkWebService()", 2);
/*  86 */     checkComponents(paramWebServiceMBean.getComponents());
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkComponents(ComponentsMBean paramComponentsMBean) throws VerifyException {
/*  91 */     this.InformUser.say("checkComponents()", 2);
/*     */ 
/*     */     
/*  94 */     if (paramComponentsMBean == null) {
/*  95 */       this.InformUser.say("checkComponents() = null", 3);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 101 */     JavaClassMBean[] arrayOfJavaClassMBean = paramComponentsMBean.getJavaClassComponents();
/*     */     
/* 103 */     if (arrayOfJavaClassMBean != null && arrayOfJavaClassMBean.length > 0) {
/* 104 */       this.InformUser.debug("checkJavaElements() Java Classes");
/*     */       
/* 106 */       checkJavaElements checkJavaElements = new checkJavaElements(arrayOfJavaClassMBean, this.cl);
/*     */       
/* 108 */       checkJavaElements.checkJavaClasses();
/*     */     } else {
/* 110 */       this.InformUser.debug("checkComponents() no Java Classes");
/*     */     } 
/*     */ 
/*     */     
/* 114 */     StatelessEJBMBean[] arrayOfStatelessEJBMBean = paramComponentsMBean.getStatelessEJBs();
/*     */     
/* 116 */     if (arrayOfStatelessEJBMBean != null && arrayOfStatelessEJBMBean.length > 0) {
/* 117 */       this.InformUser.debug("checkComponents() EJB Components");
/*     */       
/* 119 */       checkStatelessEJB checkStatelessEJB = new checkStatelessEJB(arrayOfStatelessEJBMBean);
/*     */       
/* 121 */       checkStatelessEJB.checkEJB();
/*     */     } else {
/* 123 */       this.InformUser.debug("checkComponents() no EJB Components");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\cchecker\checkDDParts.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */