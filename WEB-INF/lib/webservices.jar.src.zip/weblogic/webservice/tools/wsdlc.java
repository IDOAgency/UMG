package weblogic.webservice.tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import weblogic.utils.Debug;
import weblogic.utils.compiler.Tool;
import weblogic.utils.compiler.ToolFailureException;
import weblogic.webservice.WebService;
import weblogic.webservice.WebServiceFactory;
import weblogic.webservice.WebServiceLogger;
import weblogic.webservice.core.encoding.DefaultRegistry;
import weblogic.webservice.tools.ejbgen.ClassGen;
import weblogic.webservice.tools.ejbgen.EJBGen;
import weblogic.webservice.tools.stubgen.ServiceGen;
import weblogic.webservice.tools.typegen.TypeGen;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.TypeMappingFactory;
import weblogic.xml.schema.binding.internal.NameUtil;
import weblogic.xml.schema.binding.util.StdNamespace;
import weblogic.xml.stream.XMLInputStream;
import weblogic.xml.stream.XMLInputStreamFactory;
import weblogic.xml.stream.XMLStreamException;

public class wsdlc extends Tool {
  public wsdlc(String[] paramArrayOfString) { super(paramArrayOfString); }
  
  public void prepare() { fillInOptions(); }
  
  public void runBody() {
    checkOptions();
    if (this.opts.getBooleanOption("wsdl2client", false)) {
      generateClient(this.opts.getOption("d"), this.opts.getOption("wsdl"), this.opts.getOption("package", "sample"), this.opts.getBooleanOption("generateTypes"), this.opts.getOption("typeMapping"), this.opts.getOption("serviceName"));
    } else if (this.opts.getBooleanOption("wsdl2ejb", false)) {
      generateEJB(this.opts.getOption("d"), this.opts.getOption("wsdl"), this.opts.getOption("package", "sample"), this.opts.getBooleanOption("generateTypes"), this.opts.getOption("typeMapping"), this.opts.getOption("serviceName"));
    } else if (this.opts.getBooleanOption("wsdl2class", false)) {
      generateClass(this.opts.getOption("d"), this.opts.getOption("wsdl"), this.opts.getOption("package", "sample"), this.opts.getBooleanOption("generateTypes"), this.opts.getOption("typeMapping"), this.opts.getOption("serviceName"));
    } 
  }
  
  private void fillInOptions() {
    this.opts.setUsageArgs("<options>");
    this.opts.addFlag("wsdl2client", "Generate client stub from wsdl");
    this.opts.addFlag("wsdl2ejb", "Generate EJB from wsdl");
    this.opts.addFlag("wsdl2class", "Generate service with a class file target component");
    this.opts.addFlag("generateTypes", "Generate data types");
    this.opts.addOption("typeMapping", "typeMapping", "file to load type mapping from ");
    this.opts.addOption("d", "directory", "target directory to generate files");
    this.opts.addOption("wsdl", "wsdlURL", "url of the wsdl file");
    this.opts.addOption("package", "package", "package generated files");
    this.opts.addOption("serviceName", "serviceName", "name of the service (specified when there are more than one service");
  }
  
  private void checkOptions() {
    if (this.opts.getOption("d") == null)
      throw new ToolFailureException("target directory not specified"); 
    if (this.opts.getOption("wsdl") == null)
      throw new ToolFailureException("wsdl url not specified"); 
  }
  
  public void generateWSDL(Class paramClass) {}
  
  public void generateWSDL(String paramString) {}
  
  public void generateClass(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5) throws ToolFailureException {
    try {
      TypeMappingRegistry typeMappingRegistry = getRegistry(paramString4);
      createTargetDir(paramString1, paramString3);
      TypeGen typeGen = new TypeGen();
      if (paramBoolean)
        typeGen.generate(paramString2, paramString1, paramString3, typeMappingRegistry, true); 
      WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
      WebService webService = webServiceFactory.createFromWSDL(paramString2, paramString5, typeMappingRegistry);
      ClassGen classGen = new ClassGen();
      classGen.setPackage(paramString3);
      classGen.setTargetDir(paramString1);
      classGen.visit(webService);
    } catch (BindingException bindingException) {
      String str = WebServiceLogger.logToolWsdlcClassBindingException();
      WebServiceLogger.logStackTrace(str, bindingException);
      throw new ToolFailureException("unable to generate impl class" + bindingException);
    } catch (JAXRPCException jAXRPCException) {
      String str = WebServiceLogger.logToolWsdlcClassJAXRPCException();
      WebServiceLogger.logStackTrace(str, jAXRPCException);
      throw new ToolFailureException("unable to generate impl class" + jAXRPCException);
    } catch (IOException iOException) {
      String str = WebServiceLogger.logToolWsdlcClassIOException();
      WebServiceLogger.logStackTrace(str, iOException);
      throw new ToolFailureException("unable to generate impl class" + iOException);
    } 
  }
  
  public void generateEJB(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5) throws ToolFailureException {
    Debug.say("WARNING: pls use wsdl2service");
    try {
      TypeMappingRegistry typeMappingRegistry = getRegistry(paramString4);
      createTargetDir(paramString1, paramString3);
      TypeGen typeGen = new TypeGen();
      if (paramBoolean)
        typeGen.generate(paramString2, paramString1, paramString3, typeMappingRegistry, true); 
      WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
      WebService webService = webServiceFactory.createFromWSDL(paramString2, paramString5, typeMappingRegistry);
      EJBGen eJBGen = new EJBGen();
      eJBGen.setPackage(paramString3);
      eJBGen.setTargetDir(paramString1);
      eJBGen.visit(webService);
    } catch (BindingException bindingException) {
      String str = WebServiceLogger.logToolWsdlcEJBBindingException();
      WebServiceLogger.logStackTrace(str, bindingException);
      throw new ToolFailureException("unable to generate ejb" + bindingException);
    } catch (JAXRPCException jAXRPCException) {
      String str = WebServiceLogger.logToolWsdlcEJBJAXRPCException();
      WebServiceLogger.logStackTrace(str, jAXRPCException);
      throw new ToolFailureException("unable to generate ejb" + jAXRPCException);
    } catch (IOException iOException) {
      String str = WebServiceLogger.logToolWsdlcEJBIOException();
      WebServiceLogger.logStackTrace(str, iOException);
      throw new ToolFailureException("unable to generate ejb" + iOException);
    } 
  }
  
  private String createTargetDir(String paramString1, String paramString2) throws IOException {
    paramString1 = paramString1 + File.separator + paramString2.replace('.', File.separatorChar) + File.separator;
    File file = new File(paramString1);
    if (!file.exists())
      file.mkdirs(); 
    return paramString1;
  }
  
  private TypeMappingRegistry getRegistry(String paramString) throws IOException {
    DefaultRegistry defaultRegistry = new DefaultRegistry();
    if (paramString != null)
      try {
        TypeMapping typeMapping = TypeMappingFactory.newInstance().createDefaultMapping();
        XMLInputStream xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(new FileInputStream(paramString));
        typeMapping.readXML(xMLInputStream);
        defaultRegistry.register(StdNamespace.instance().soapEncoding(), (TypeMapping)typeMapping);
      } catch (XMLStreamException xMLStreamException) {
        throw new IOException("Error parsing the XML file" + xMLStreamException);
      }  
    return defaultRegistry;
  }
  
  public void generateClient(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5) throws ToolFailureException {
    Debug.say("WARNING: pls use clientgen");
    try {
      String str = createTargetDir(paramString1, paramString3);
      TypeMappingRegistry typeMappingRegistry = getRegistry(paramString4);
      TypeGen typeGen = new TypeGen();
      if (paramBoolean)
        typeGen.generate(paramString2, paramString1, paramString3, typeMappingRegistry, false); 
      WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
      WebService webService = webServiceFactory.createFromWSDL(paramString2, paramString5, typeMappingRegistry);
      ServiceGen serviceGen = new ServiceGen();
      serviceGen.setPackage(paramString3);
      serviceGen.setDestDir(paramString1);
      serviceGen.setWSDLLocation(paramString2);
      serviceGen.visit(webService);
      if (paramBoolean || paramString4 != null)
        typeGen.writeMapping(NameUtil.getJAXRPCClassName(webService.getName()), str, typeMappingRegistry); 
    } catch (BindingException bindingException) {
      String str = WebServiceLogger.logToolWsdlcClientBindingException();
      WebServiceLogger.logStackTrace(str, bindingException);
      throw new ToolFailureException("unable to generate service", bindingException);
    } catch (JAXRPCException jAXRPCException) {
      String str = WebServiceLogger.logToolWsdlcClientJAXRPCException();
      WebServiceLogger.logStackTrace(str, jAXRPCException);
      throw new ToolFailureException("unable to generate service", jAXRPCException);
    } catch (IOException iOException) {
      String str = WebServiceLogger.logToolWsdlcClientIOException();
      WebServiceLogger.logStackTrace(str, iOException);
      throw new ToolFailureException("unable to generate service", iOException);
    } 
  }
  
  public static void main(String[] paramArrayOfString) { (new wsdlc(paramArrayOfString)).run(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlc.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */