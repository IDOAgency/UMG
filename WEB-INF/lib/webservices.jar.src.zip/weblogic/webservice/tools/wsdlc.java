/*     */ package weblogic.webservice.tools;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.TypeMapping;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import weblogic.utils.Debug;
/*     */ import weblogic.utils.compiler.Tool;
/*     */ import weblogic.utils.compiler.ToolFailureException;
/*     */ import weblogic.webservice.WebService;
/*     */ import weblogic.webservice.WebServiceFactory;
/*     */ import weblogic.webservice.WebServiceLogger;
/*     */ import weblogic.webservice.core.encoding.DefaultRegistry;
/*     */ import weblogic.webservice.tools.ejbgen.ClassGen;
/*     */ import weblogic.webservice.tools.ejbgen.EJBGen;
/*     */ import weblogic.webservice.tools.stubgen.ServiceGen;
/*     */ import weblogic.webservice.tools.typegen.TypeGen;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.TypeMappingFactory;
/*     */ import weblogic.xml.schema.binding.internal.NameUtil;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ import weblogic.xml.stream.XMLInputStream;
/*     */ import weblogic.xml.stream.XMLInputStreamFactory;
/*     */ import weblogic.xml.stream.XMLStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class wsdlc
/*     */   extends Tool
/*     */ {
/*  47 */   public wsdlc(String[] paramArrayOfString) { super(paramArrayOfString); }
/*     */ 
/*     */ 
/*     */   
/*  51 */   public void prepare() { fillInOptions(); }
/*     */ 
/*     */   
/*     */   public void runBody() {
/*  55 */     checkOptions();
/*     */     
/*  57 */     if (this.opts.getBooleanOption("wsdl2client", false)) {
/*  58 */       generateClient(this.opts.getOption("d"), this.opts.getOption("wsdl"), this.opts.getOption("package", "sample"), this.opts.getBooleanOption("generateTypes"), this.opts.getOption("typeMapping"), this.opts.getOption("serviceName"));
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  63 */     else if (this.opts.getBooleanOption("wsdl2ejb", false)) {
/*  64 */       generateEJB(this.opts.getOption("d"), this.opts.getOption("wsdl"), this.opts.getOption("package", "sample"), this.opts.getBooleanOption("generateTypes"), this.opts.getOption("typeMapping"), this.opts.getOption("serviceName"));
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  69 */     else if (this.opts.getBooleanOption("wsdl2class", false)) {
/*  70 */       generateClass(this.opts.getOption("d"), this.opts.getOption("wsdl"), this.opts.getOption("package", "sample"), this.opts.getBooleanOption("generateTypes"), this.opts.getOption("typeMapping"), this.opts.getOption("serviceName"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillInOptions() {
/*  83 */     this.opts.setUsageArgs("<options>");
/*  84 */     this.opts.addFlag("wsdl2client", "Generate client stub from wsdl");
/*  85 */     this.opts.addFlag("wsdl2ejb", "Generate EJB from wsdl");
/*     */     
/*  87 */     this.opts.addFlag("wsdl2class", "Generate service with a class file target component");
/*     */ 
/*     */     
/*  90 */     this.opts.addFlag("generateTypes", "Generate data types");
/*     */     
/*  92 */     this.opts.addOption("typeMapping", "typeMapping", "file to load type mapping from ");
/*     */ 
/*     */     
/*  95 */     this.opts.addOption("d", "directory", "target directory to generate files");
/*  96 */     this.opts.addOption("wsdl", "wsdlURL", "url of the wsdl file");
/*  97 */     this.opts.addOption("package", "package", "package generated files");
/*     */     
/*  99 */     this.opts.addOption("serviceName", "serviceName", "name of the service (specified when there are more than one service");
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkOptions() {
/* 104 */     if (this.opts.getOption("d") == null) {
/* 105 */       throw new ToolFailureException("target directory not specified");
/*     */     }
/*     */     
/* 108 */     if (this.opts.getOption("wsdl") == null) {
/* 109 */       throw new ToolFailureException("wsdl url not specified");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateWSDL(Class paramClass) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateWSDL(String paramString) {}
/*     */ 
/*     */   
/*     */   public void generateClass(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5) throws ToolFailureException {
/*     */     try {
/* 124 */       TypeMappingRegistry typeMappingRegistry = getRegistry(paramString4);
/* 125 */       createTargetDir(paramString1, paramString3);
/* 126 */       TypeGen typeGen = new TypeGen();
/*     */       
/* 128 */       if (paramBoolean) {
/* 129 */         typeGen.generate(paramString2, paramString1, paramString3, typeMappingRegistry, true);
/*     */       }
/*     */ 
/*     */       
/* 133 */       WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
/*     */       
/* 135 */       WebService webService = webServiceFactory.createFromWSDL(paramString2, paramString5, typeMappingRegistry);
/*     */ 
/*     */       
/* 138 */       ClassGen classGen = new ClassGen();
/* 139 */       classGen.setPackage(paramString3);
/* 140 */       classGen.setTargetDir(paramString1);
/* 141 */       classGen.visit(webService);
/* 142 */     } catch (BindingException bindingException) {
/* 143 */       String str = WebServiceLogger.logToolWsdlcClassBindingException();
/* 144 */       WebServiceLogger.logStackTrace(str, bindingException);
/* 145 */       throw new ToolFailureException("unable to generate impl class" + bindingException);
/* 146 */     } catch (JAXRPCException jAXRPCException) {
/* 147 */       String str = WebServiceLogger.logToolWsdlcClassJAXRPCException();
/* 148 */       WebServiceLogger.logStackTrace(str, jAXRPCException);
/* 149 */       throw new ToolFailureException("unable to generate impl class" + jAXRPCException);
/* 150 */     } catch (IOException iOException) {
/* 151 */       String str = WebServiceLogger.logToolWsdlcClassIOException();
/* 152 */       WebServiceLogger.logStackTrace(str, iOException);
/* 153 */       throw new ToolFailureException("unable to generate impl class" + iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateEJB(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5) throws ToolFailureException {
/* 161 */     Debug.say("WARNING: pls use wsdl2service");
/*     */     
/*     */     try {
/* 164 */       TypeMappingRegistry typeMappingRegistry = getRegistry(paramString4);
/* 165 */       createTargetDir(paramString1, paramString3);
/* 166 */       TypeGen typeGen = new TypeGen();
/*     */       
/* 168 */       if (paramBoolean) {
/* 169 */         typeGen.generate(paramString2, paramString1, paramString3, typeMappingRegistry, true);
/*     */       }
/*     */ 
/*     */       
/* 173 */       WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
/*     */       
/* 175 */       WebService webService = webServiceFactory.createFromWSDL(paramString2, paramString5, typeMappingRegistry);
/*     */ 
/*     */       
/* 178 */       EJBGen eJBGen = new EJBGen();
/* 179 */       eJBGen.setPackage(paramString3);
/* 180 */       eJBGen.setTargetDir(paramString1);
/* 181 */       eJBGen.visit(webService);
/* 182 */     } catch (BindingException bindingException) {
/* 183 */       String str = WebServiceLogger.logToolWsdlcEJBBindingException();
/* 184 */       WebServiceLogger.logStackTrace(str, bindingException);
/* 185 */       throw new ToolFailureException("unable to generate ejb" + bindingException);
/* 186 */     } catch (JAXRPCException jAXRPCException) {
/* 187 */       String str = WebServiceLogger.logToolWsdlcEJBJAXRPCException();
/* 188 */       WebServiceLogger.logStackTrace(str, jAXRPCException);
/* 189 */       throw new ToolFailureException("unable to generate ejb" + jAXRPCException);
/* 190 */     } catch (IOException iOException) {
/* 191 */       String str = WebServiceLogger.logToolWsdlcEJBIOException();
/* 192 */       WebServiceLogger.logStackTrace(str, iOException);
/* 193 */       throw new ToolFailureException("unable to generate ejb" + iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String createTargetDir(String paramString1, String paramString2) throws IOException {
/* 200 */     paramString1 = paramString1 + File.separator + paramString2.replace('.', File.separatorChar) + File.separator;
/*     */ 
/*     */     
/* 203 */     File file = new File(paramString1);
/*     */     
/* 205 */     if (!file.exists()) {
/* 206 */       file.mkdirs();
/*     */     }
/*     */     
/* 209 */     return paramString1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeMappingRegistry getRegistry(String paramString) throws IOException {
/* 215 */     DefaultRegistry defaultRegistry = new DefaultRegistry();
/*     */     
/* 217 */     if (paramString != null) {
/*     */       
/*     */       try {
/* 220 */         TypeMapping typeMapping = TypeMappingFactory.newInstance().createDefaultMapping();
/*     */ 
/*     */         
/* 223 */         XMLInputStream xMLInputStream = XMLInputStreamFactory.newInstance().newInputStream(new FileInputStream(paramString));
/*     */ 
/*     */ 
/*     */         
/* 227 */         typeMapping.readXML(xMLInputStream);
/*     */         
/* 229 */         defaultRegistry.register(StdNamespace.instance().soapEncoding(), (TypeMapping)typeMapping);
/*     */       
/*     */       }
/* 232 */       catch (XMLStreamException xMLStreamException) {
/* 233 */         throw new IOException("Error parsing the XML file" + xMLStreamException);
/*     */       } 
/*     */     }
/*     */     
/* 237 */     return defaultRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateClient(String paramString1, String paramString2, String paramString3, boolean paramBoolean, String paramString4, String paramString5) throws ToolFailureException {
/* 244 */     Debug.say("WARNING: pls use clientgen");
/*     */     
/*     */     try {
/* 247 */       String str = createTargetDir(paramString1, paramString3);
/*     */       
/* 249 */       TypeMappingRegistry typeMappingRegistry = getRegistry(paramString4);
/*     */       
/* 251 */       TypeGen typeGen = new TypeGen();
/*     */       
/* 253 */       if (paramBoolean) {
/* 254 */         typeGen.generate(paramString2, paramString1, paramString3, typeMappingRegistry, false);
/*     */       }
/*     */ 
/*     */       
/* 258 */       WebServiceFactory webServiceFactory = WebServiceFactory.newInstance();
/*     */       
/* 260 */       WebService webService = webServiceFactory.createFromWSDL(paramString2, paramString5, typeMappingRegistry);
/*     */ 
/*     */       
/* 263 */       ServiceGen serviceGen = new ServiceGen();
/* 264 */       serviceGen.setPackage(paramString3);
/* 265 */       serviceGen.setDestDir(paramString1);
/* 266 */       serviceGen.setWSDLLocation(paramString2);
/* 267 */       serviceGen.visit(webService);
/*     */       
/* 269 */       if (paramBoolean || paramString4 != null) {
/* 270 */         typeGen.writeMapping(NameUtil.getJAXRPCClassName(webService.getName()), str, typeMappingRegistry);
/*     */       
/*     */       }
/*     */     }
/* 274 */     catch (BindingException bindingException) {
/* 275 */       String str = WebServiceLogger.logToolWsdlcClientBindingException();
/* 276 */       WebServiceLogger.logStackTrace(str, bindingException);
/* 277 */       throw new ToolFailureException("unable to generate service", bindingException);
/* 278 */     } catch (JAXRPCException jAXRPCException) {
/* 279 */       String str = WebServiceLogger.logToolWsdlcClientJAXRPCException();
/* 280 */       WebServiceLogger.logStackTrace(str, jAXRPCException);
/* 281 */       throw new ToolFailureException("unable to generate service", jAXRPCException);
/* 282 */     } catch (IOException iOException) {
/* 283 */       String str = WebServiceLogger.logToolWsdlcClientIOException();
/* 284 */       WebServiceLogger.logStackTrace(str, iOException);
/* 285 */       throw new ToolFailureException("unable to generate service", iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 290 */   public static void main(String[] paramArrayOfString) { (new wsdlc(paramArrayOfString)).run(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\wsdlc.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */