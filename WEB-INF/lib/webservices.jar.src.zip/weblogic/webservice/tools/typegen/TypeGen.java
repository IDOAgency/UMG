package weblogic.webservice.tools.typegen;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.URL;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import weblogic.webservice.client.WLSSLAdapter;
import weblogic.webservice.wsdl.DefinitionFactory;
import weblogic.webservice.wsdl.WsdlConstants;
import weblogic.xml.schema.binding.BindingConfiguration;
import weblogic.xml.schema.binding.BindingException;
import weblogic.xml.schema.binding.TypeMapping;
import weblogic.xml.schema.binding.TypeMappingBuilder;
import weblogic.xml.schema.binding.TypeMappingBuilderFactory;
import weblogic.xml.schema.binding.internal.TypeMappingBase;
import weblogic.xml.schema.binding.util.StdNamespace;
import weblogic.xml.xmlnode.XMLNode;

public class TypeGen {
  WLSSLAdapter adapter = null;
  
  public void generate(String paramString1, String paramString2, String paramString3, TypeMappingRegistry paramTypeMappingRegistry, boolean paramBoolean) throws IOException, JAXRPCException, BindingException {
    DefinitionFactory definitionFactory = new DefinitionFactory(getSSLAdapter());
    XMLNode xMLNode1 = definitionFactory.createDefinition(paramString1);
    XMLNode xMLNode2 = xMLNode1.getChild("types", WsdlConstants.wsdlNS);
    if (xMLNode2 == null)
      return; 
    TypeMappingBuilder typeMappingBuilder = TypeMappingBuilderFactory.newInstance().createTypeMappingBuilder();
    TypeMapping typeMapping = (TypeMapping)paramTypeMappingRegistry.getTypeMapping(StdNamespace.instance().soapEncoding());
    if (typeMapping == null)
      throw new JAXRPCException("typeMapping is null"); 
    typeMappingBuilder.setTypeMapping(typeMapping);
    BindingConfiguration bindingConfiguration = typeMappingBuilder.getBindingConfiguration();
    bindingConfiguration.setBeanOutputDirectory(paramString2);
    if (paramBoolean)
      bindingConfiguration.setFixedPackage(paramString3); 
    typeMappingBuilder.processSchemas(xMLNode2.stream(), paramString1);
  }
  
  public void writeMapping(String paramString1, String paramString2, TypeMappingRegistry paramTypeMappingRegistry) throws IOException {
    TypeMapping typeMapping = (TypeMapping)paramTypeMappingRegistry.getTypeMapping(StdNamespace.instance().soapEncoding());
    File file = new File(paramString2 + File.separator + paramString1 + ".xml");
    FileOutputStream fileOutputStream = new FileOutputStream(file);
    ((TypeMappingBase)typeMapping).writeXML(new PrintStream(fileOutputStream));
    fileOutputStream.close();
  }
  
  private InputStream getWSDLStream(String paramString) throws IOException {
    URL uRL = new URL(paramString);
    if (getSSLAdapter() != null)
      return getSSLAdapter().openConnection(uRL).getInputStream(); 
    return uRL.openStream();
  }
  
  private WLSSLAdapter getSSLAdapter() {
    if (this.adapter == null) {
      this.adapter = new WLSSLAdapter();
      this.adapter.setStrictChecking(false);
      this.adapter.setVerbose(true);
    } 
    return this.adapter;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\typegen\TypeGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */