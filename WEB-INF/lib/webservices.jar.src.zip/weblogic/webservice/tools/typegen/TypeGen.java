/*     */ package weblogic.webservice.tools.typegen;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import weblogic.webservice.client.WLSSLAdapter;
/*     */ import weblogic.webservice.wsdl.DefinitionFactory;
/*     */ import weblogic.webservice.wsdl.WsdlConstants;
/*     */ import weblogic.xml.schema.binding.BindingConfiguration;
/*     */ import weblogic.xml.schema.binding.BindingException;
/*     */ import weblogic.xml.schema.binding.TypeMapping;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilder;
/*     */ import weblogic.xml.schema.binding.TypeMappingBuilderFactory;
/*     */ import weblogic.xml.schema.binding.internal.TypeMappingBase;
/*     */ import weblogic.xml.schema.binding.util.StdNamespace;
/*     */ import weblogic.xml.xmlnode.XMLNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeGen
/*     */ {
/*  38 */   WLSSLAdapter adapter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(String paramString1, String paramString2, String paramString3, TypeMappingRegistry paramTypeMappingRegistry, boolean paramBoolean) throws IOException, JAXRPCException, BindingException {
/*  45 */     DefinitionFactory definitionFactory = new DefinitionFactory(getSSLAdapter());
/*     */     
/*  47 */     XMLNode xMLNode1 = definitionFactory.createDefinition(paramString1);
/*     */     
/*  49 */     XMLNode xMLNode2 = xMLNode1.getChild("types", WsdlConstants.wsdlNS);
/*     */     
/*  51 */     if (xMLNode2 == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     TypeMappingBuilder typeMappingBuilder = TypeMappingBuilderFactory.newInstance().createTypeMappingBuilder();
/*     */ 
/*     */     
/*  61 */     TypeMapping typeMapping = (TypeMapping)paramTypeMappingRegistry.getTypeMapping(StdNamespace.instance().soapEncoding());
/*     */ 
/*     */     
/*  64 */     if (typeMapping == null) {
/*  65 */       throw new JAXRPCException("typeMapping is null");
/*     */     }
/*     */     
/*  68 */     typeMappingBuilder.setTypeMapping(typeMapping);
/*     */     
/*  70 */     BindingConfiguration bindingConfiguration = typeMappingBuilder.getBindingConfiguration();
/*  71 */     bindingConfiguration.setBeanOutputDirectory(paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     if (paramBoolean)
/*     */     {
/*  78 */       bindingConfiguration.setFixedPackage(paramString3);
/*     */     }
/*     */     
/*  81 */     typeMappingBuilder.processSchemas(xMLNode2.stream(), paramString1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeMapping(String paramString1, String paramString2, TypeMappingRegistry paramTypeMappingRegistry) throws IOException {
/*  90 */     TypeMapping typeMapping = (TypeMapping)paramTypeMappingRegistry.getTypeMapping(StdNamespace.instance().soapEncoding());
/*     */ 
/*     */     
/*  93 */     File file = new File(paramString2 + File.separator + paramString1 + ".xml");
/*     */ 
/*     */     
/*  96 */     FileOutputStream fileOutputStream = new FileOutputStream(file);
/*     */     
/*  98 */     ((TypeMappingBase)typeMapping).writeXML(new PrintStream(fileOutputStream));
/*  99 */     fileOutputStream.close();
/*     */   }
/*     */   
/*     */   private InputStream getWSDLStream(String paramString) throws IOException {
/* 103 */     URL uRL = new URL(paramString);
/*     */     
/* 105 */     if (getSSLAdapter() != null) {
/* 106 */       return getSSLAdapter().openConnection(uRL).getInputStream();
/*     */     }
/* 108 */     return uRL.openStream();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private WLSSLAdapter getSSLAdapter() {
/* 114 */     if (this.adapter == null) {
/* 115 */       this.adapter = new WLSSLAdapter();
/* 116 */       this.adapter.setStrictChecking(false);
/* 117 */       this.adapter.setVerbose(true);
/*     */     } 
/*     */     
/* 120 */     return this.adapter;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\tools\typegen\TypeGen.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */