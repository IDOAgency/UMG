package weblogic.webservice.extensions;

import javax.xml.rpc.Service;
import weblogic.webservice.context.WebServiceContext;

public interface WLService extends Service {
  WebServiceContext context();
  
  WebServiceContext joinContext();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\extensions\WLService.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */