package weblogic.webservice.extensions;

import java.util.Iterator;
import javax.xml.rpc.Call;
import javax.xml.rpc.ParameterMode;

public interface WLCall extends Call {
  Iterator getParameterNames();
  
  Class getParameterJavaType(String paramString);
  
  ParameterMode getParameterMode(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\extensions\WLCall.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */