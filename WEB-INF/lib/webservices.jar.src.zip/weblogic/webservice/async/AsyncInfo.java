/*    */ package weblogic.webservice.async;
/*    */ 
/*    */ import weblogic.webservice.WSServerService;
/*    */ import weblogic.webservice.saf.StoreForwardException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsyncInfo
/*    */ {
/*    */   private Object caller;
/*    */   private ResultListener resultListener;
/*    */   private boolean relDel = false;
/*    */   private boolean inOrderDel = false;
/*    */   
/* 30 */   public Object getCaller() { return this.caller; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   public void setCaller(Object paramObject) { this.caller = paramObject; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public ResultListener getResultListener() { return this.resultListener; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public void setResultListener(ResultListener paramResultListener) { this.resultListener = paramResultListener; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setReliableDelivery(boolean paramBoolean) throws StoreForwardException {
/* 66 */     WSServerService.getWSServerService().verifySAFConfiguration();
/* 67 */     this.relDel = paramBoolean;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   public boolean isReliableDelivery() { return this.relDel; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 85 */   public void setInOrderDelivery(boolean paramBoolean) throws StoreForwardException { this.inOrderDel = paramBoolean; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 94 */   public boolean isInOrderDelivery() { return this.inOrderDel; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\AsyncInfo.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */