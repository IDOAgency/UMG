package weblogic.webservice.async;

import weblogic.kernel.Kernel;
import weblogic.work.WorkAdapter;
import weblogic.work.WorkManagerFactory;

public class KernelFeederImpl implements KernelFeeder {
  public boolean isServer() { return Kernel.isServer(); }
  
  public void addTask(Runnable paramRunnable) { WorkManagerFactory.getInstance().getSystem().schedule(new ExecuteTask(paramRunnable)); }
  
  public static class ExecuteTask extends WorkAdapter {
    private Runnable task;
    
    public ExecuteTask(Runnable param1Runnable) { this.task = param1Runnable; }
    
    public void run() { this.task.run(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\KernelFeederImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */