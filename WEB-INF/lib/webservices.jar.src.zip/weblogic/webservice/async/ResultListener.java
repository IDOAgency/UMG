package weblogic.webservice.async;

public interface ResultListener {
  void onCompletion(InvokeCompletedEvent paramInvokeCompletedEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\ResultListener.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */