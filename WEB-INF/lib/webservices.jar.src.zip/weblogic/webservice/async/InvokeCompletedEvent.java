package weblogic.webservice.async;

import java.util.EventObject;

public class InvokeCompletedEvent extends EventObject {
  private FutureResult futureResult;
  
  public InvokeCompletedEvent(Object paramObject) { super(paramObject); }
  
  public FutureResult getFutureResult() { return this.futureResult; }
  
  public void setFutureResult(FutureResult paramFutureResult) { this.futureResult = paramFutureResult; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\InvokeCompletedEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */