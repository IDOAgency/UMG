package weblogic.webservice.async;

import java.util.ArrayList;

public class ThreadPool implements Runnable {
  private ArrayList tasks;
  
  protected static boolean DEBUG = false;
  
  private boolean isRunningOnServer;
  
  private KernelFeeder kernelFeeder;
  
  public ThreadPool(int paramInt) {
    this.tasks = new ArrayList();
    findRunningOnServer();
    if (!this.isRunningOnServer)
      startThreads(paramInt); 
  }
  
  private void startThreads(int paramInt) {
    for (byte b = 0; b < paramInt; b++) {
      Thread thread = new Thread(this, "Web Service Client Thread #" + b);
      thread.setDaemon(true);
      thread.start();
    } 
  }
  
  private void findRunningOnServer() {
    try {
      Class.forName("weblogic.kernel.Kernel");
      this.kernelFeeder = (KernelFeeder)Class.forName("weblogic.webservice.async.KernelFeederImpl").newInstance();
      this.isRunningOnServer = this.kernelFeeder.isServer();
    } catch (Throwable throwable) {
      this.isRunningOnServer = false;
      if (DEBUG)
        throwable.printStackTrace(); 
    } 
  }
  
  public void run() {
    while (true) {
      try {
        while (true) {
          Runnable runnable = getTask();
          runnable.run();
        } 
        break;
      } catch (Throwable throwable) {
        if (DEBUG)
          throwable.printStackTrace(System.out); 
      } 
    } 
  }
  
  private Runnable getTask() {
    synchronized (this.tasks) {
      while (true) {
        if (this.tasks.size() != 0)
          return (Runnable)this.tasks.remove(0); 
        if (this.tasks.size() == 0)
          try {
            this.tasks.wait();
          } catch (InterruptedException interruptedException) {
            if (DEBUG)
              interruptedException.printStackTrace(System.out); 
          }  
      } 
    } 
  }
  
  public void addTask(Runnable paramRunnable) {
    if (this.isRunningOnServer) {
      this.kernelFeeder.addTask(paramRunnable);
    } else {
      synchronized (this.tasks) {
        this.tasks.add(paramRunnable);
        this.tasks.notifyAll();
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\ThreadPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */