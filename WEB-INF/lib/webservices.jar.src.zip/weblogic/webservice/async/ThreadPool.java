/*    */ package weblogic.webservice.async;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadPool
/*    */   implements Runnable
/*    */ {
/*    */   private ArrayList tasks;
/*    */   protected static boolean DEBUG = false;
/*    */   private boolean isRunningOnServer;
/*    */   private KernelFeeder kernelFeeder;
/*    */   
/*    */   public ThreadPool(int paramInt) {
/* 18 */     this.tasks = new ArrayList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 26 */     findRunningOnServer();
/*    */     
/* 28 */     if (!this.isRunningOnServer) {
/* 29 */       startThreads(paramInt);
/*    */     }
/*    */   }
/*    */   
/*    */   private void startThreads(int paramInt) {
/* 34 */     for (byte b = 0; b < paramInt; b++) {
/* 35 */       Thread thread = new Thread(this, "Web Service Client Thread #" + b);
/* 36 */       thread.setDaemon(true);
/* 37 */       thread.start();
/*    */     } 
/*    */   }
/*    */   
/*    */   private void findRunningOnServer() {
/*    */     try {
/* 43 */       Class.forName("weblogic.kernel.Kernel");
/*    */       
/* 45 */       this.kernelFeeder = (KernelFeeder)Class.forName("weblogic.webservice.async.KernelFeederImpl").newInstance();
/*    */ 
/*    */       
/* 48 */       this.isRunningOnServer = this.kernelFeeder.isServer();
/* 49 */     } catch (Throwable throwable) {
/* 50 */       this.isRunningOnServer = false;
/*    */       
/* 52 */       if (DEBUG) {
/* 53 */         throwable.printStackTrace();
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   public void run() {
/*    */     while (true) {
/*    */       try {
/*    */         while (true)
/* 62 */         { Runnable runnable = getTask();
/* 63 */           runnable.run(); }  break;
/* 64 */       } catch (Throwable throwable) {
/* 65 */         if (DEBUG) throwable.printStackTrace(System.out); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private Runnable getTask() {
/* 71 */     synchronized (this.tasks) {
/*    */       
/*    */       while (true) {
/* 74 */         if (this.tasks.size() != 0) {
/* 75 */           return (Runnable)this.tasks.remove(0);
/*    */         }
/*    */         
/* 78 */         if (this.tasks.size() == 0) {
/*    */           try {
/* 80 */             this.tasks.wait();
/* 81 */           } catch (InterruptedException interruptedException) {
/* 82 */             if (DEBUG) interruptedException.printStackTrace(System.out);
/*    */           
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void addTask(Runnable paramRunnable) {
/* 91 */     if (this.isRunningOnServer) {
/* 92 */       this.kernelFeeder.addTask(paramRunnable);
/*    */     } else {
/* 94 */       synchronized (this.tasks) {
/* 95 */         this.tasks.add(paramRunnable);
/* 96 */         this.tasks.notifyAll();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\ThreadPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */