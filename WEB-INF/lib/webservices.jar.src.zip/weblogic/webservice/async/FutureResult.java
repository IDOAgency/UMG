package weblogic.webservice.async;

import java.rmi.RemoteException;

public interface FutureResult {
  boolean isCompleted();
  
  void waitFor(long paramLong);
  
  void abort();
  
  Object getResult() throws RemoteException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\FutureResult.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */