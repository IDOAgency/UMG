package weblogic.webservice.async;

import java.rmi.RemoteException;

public class FutureResultImpl implements FutureResult {
  private boolean completed;
  
  private Object result;
  
  private AsyncInfo asyncInfo;
  
  public void setAsyncInfo(AsyncInfo paramAsyncInfo) { this.asyncInfo = paramAsyncInfo; }
  
  public AsyncInfo getAsyncInfo() { return this.asyncInfo; }
  
  public boolean isCompleted() { return this.completed; }
  
  public void setCompleted() { this.completed = true; }
  
  public void waitFor(long paramLong) { throw new Error("NIY"); }
  
  public void abort() { throw new Error("NIY"); }
  
  public Object getResult() throws RemoteException {
    try {
      synchronized (this) {
        while (!this.completed)
          wait(); 
      } 
    } catch (InterruptedException interruptedException) {}
    if (this.result instanceof RemoteException)
      throw (RemoteException)this.result; 
    if (this.result instanceof Throwable) {
      Throwable throwable = (Throwable)this.result;
      throw new RemoteException(throwable.getMessage(), throwable);
    } 
    return this.result;
  }
  
  public void setError(Throwable paramThrowable) {
    this.result = paramThrowable;
    synchronized (this) {
      this.completed = true;
      notifyAll();
    } 
  }
  
  public void setResult(Object paramObject) {
    this.result = paramObject;
    synchronized (this) {
      this.completed = true;
      notifyAll();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\FutureResultImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */