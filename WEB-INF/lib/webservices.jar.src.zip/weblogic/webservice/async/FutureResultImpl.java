/*    */ package weblogic.webservice.async;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FutureResultImpl
/*    */   implements FutureResult
/*    */ {
/*    */   private boolean completed;
/*    */   private Object result;
/*    */   private AsyncInfo asyncInfo;
/*    */   
/* 20 */   public void setAsyncInfo(AsyncInfo paramAsyncInfo) { this.asyncInfo = paramAsyncInfo; }
/*    */ 
/*    */ 
/*    */   
/* 24 */   public AsyncInfo getAsyncInfo() { return this.asyncInfo; }
/*    */ 
/*    */ 
/*    */   
/* 28 */   public boolean isCompleted() { return this.completed; }
/*    */ 
/*    */ 
/*    */   
/* 32 */   public void setCompleted() { this.completed = true; }
/*    */ 
/*    */ 
/*    */   
/* 36 */   public void waitFor(long paramLong) { throw new Error("NIY"); }
/*    */ 
/*    */ 
/*    */   
/* 40 */   public void abort() { throw new Error("NIY"); }
/*    */ 
/*    */   
/*    */   public Object getResult() throws RemoteException {
/*    */     try {
/* 45 */       synchronized (this) {
/* 46 */         while (!this.completed) {
/* 47 */           wait();
/*    */         }
/*    */       } 
/* 50 */     } catch (InterruptedException interruptedException) {}
/*    */ 
/*    */     
/* 53 */     if (this.result instanceof RemoteException) {
/* 54 */       throw (RemoteException)this.result;
/*    */     }
/*    */     
/* 57 */     if (this.result instanceof Throwable) {
/* 58 */       Throwable throwable = (Throwable)this.result;
/* 59 */       throw new RemoteException(throwable.getMessage(), throwable);
/*    */     } 
/*    */     
/* 62 */     return this.result;
/*    */   }
/*    */   
/*    */   public void setError(Throwable paramThrowable) {
/* 66 */     this.result = paramThrowable;
/*    */     
/* 68 */     synchronized (this) {
/* 69 */       this.completed = true;
/* 70 */       notifyAll();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setResult(Object paramObject) {
/* 75 */     this.result = paramObject;
/*    */     
/* 77 */     synchronized (this) {
/* 78 */       this.completed = true;
/* 79 */       notifyAll();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\FutureResultImpl.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */