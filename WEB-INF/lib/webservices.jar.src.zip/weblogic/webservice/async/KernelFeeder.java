package weblogic.webservice.async;

public interface KernelFeeder {
  void addTask(Runnable paramRunnable);
  
  boolean isServer();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\KernelFeeder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */