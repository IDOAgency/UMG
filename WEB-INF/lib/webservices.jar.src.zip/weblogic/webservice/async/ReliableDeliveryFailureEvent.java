/*    */ package weblogic.webservice.async;
/*    */ 
/*    */ import weblogic.webservice.saf.StoreForwardException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReliableDeliveryFailureEvent
/*    */   extends InvokeCompletedEvent
/*    */ {
/*    */   private String message;
/*    */   private StoreForwardException exception;
/*    */   
/*    */   public ReliableDeliveryFailureEvent(StoreForwardException paramStoreForwardException) {
/* 24 */     super(paramStoreForwardException);
/* 25 */     this.exception = paramStoreForwardException;
/* 26 */     this.message = paramStoreForwardException.getMessage();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReliableDeliveryFailureEvent(String paramString) {
/* 33 */     super(paramString);
/* 34 */     this.message = paramString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public String getErrorMessage() { return this.message; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public StoreForwardException getException() { return this.exception; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\ReliableDeliveryFailureEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */