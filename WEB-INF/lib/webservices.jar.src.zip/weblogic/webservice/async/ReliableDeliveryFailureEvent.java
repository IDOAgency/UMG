package weblogic.webservice.async;

import weblogic.webservice.saf.StoreForwardException;

public class ReliableDeliveryFailureEvent extends InvokeCompletedEvent {
  private String message;
  
  private StoreForwardException exception;
  
  public ReliableDeliveryFailureEvent(StoreForwardException paramStoreForwardException) {
    super(paramStoreForwardException);
    this.exception = paramStoreForwardException;
    this.message = paramStoreForwardException.getMessage();
  }
  
  public ReliableDeliveryFailureEvent(String paramString) {
    super(paramString);
    this.message = paramString;
  }
  
  public String getErrorMessage() { return this.message; }
  
  public StoreForwardException getException() { return this.exception; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\async\ReliableDeliveryFailureEvent.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */