package weblogic.webservice;

import java.lang.reflect.Method;
import javax.xml.rpc.JAXRPCException;

public interface InvocationHandler {
  public static final int STATELESS_JAVA_TYPE = 1;
  
  public static final int STATEFUL_JAVA_TYPE = 2;
  
  public static final int JMS_TOPIC_SUBSCRIBER_TYPE = 4;
  
  public static final int JMS_QUEUE_RECEIVER_TYPE = 3;
  
  public static final int JMS_TOPIC_SENDER_TYPE = 5;
  
  public static final int JMS_QUEUE_SENDER_TYPE = 6;
  
  public static final int STATELESS_SESSION_EJB_TYPE = 7;
  
  Object invoke(String paramString, Object[] paramArrayOfObject, WLMessageContext paramWLMessageContext) throws JAXRPCException, TargetInvocationException;
  
  Method[] getAllMethods();
  
  void registerOperation(String paramString1, String paramString2, Class[] paramArrayOfClass) throws NoSuchMethodException;
  
  int getType();
  
  String getInfo();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogic\webservice\InvocationHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */