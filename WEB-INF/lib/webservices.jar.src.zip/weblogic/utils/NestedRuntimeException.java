/*     */ package weblogic.utils;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NestedRuntimeException
/*     */   extends RuntimeException
/*     */   implements NestedThrowable
/*     */ {
/*     */   private Throwable nested;
/*     */   
/*     */   public NestedRuntimeException() {}
/*     */   
/*  18 */   public NestedRuntimeException(String paramString) { super(paramString); }
/*     */ 
/*     */   
/*     */   public NestedRuntimeException(Throwable paramThrowable) {
/*  22 */     super(paramThrowable);
/*  23 */     this.nested = paramThrowable;
/*     */   }
/*     */   
/*     */   public NestedRuntimeException(String paramString, Throwable paramThrowable) {
/*  27 */     super(paramString, paramThrowable);
/*  28 */     this.nested = paramThrowable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   public Throwable getNestedException() { return getNested(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public Throwable getNested() { return this.nested; }
/*     */ 
/*     */ 
/*     */   
/*  53 */   public String superToString() { return super.toString(); }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public void superPrintStackTrace(PrintStream paramPrintStream) { super.printStackTrace(paramPrintStream); }
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void superPrintStackTrace(PrintWriter paramPrintWriter) { super.printStackTrace(paramPrintWriter); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public String toString() { return NestedThrowable.Util.toString(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public void printStackTrace(PrintStream paramPrintStream) { NestedThrowable.Util.printStackTrace(this, paramPrintStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public void printStackTrace(PrintWriter paramPrintWriter) { NestedThrowable.Util.printStackTrace(this, paramPrintWriter); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void printStackTrace() { printStackTrace(System.err); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\NestedRuntimeException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */