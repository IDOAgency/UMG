/*    */ package weblogic.utils.collections;
/*    */ 
/*    */ public class NumericValueHashtable
/*    */   extends NumericValueHashMap
/*    */ {
/*  6 */   public NumericValueHashtable(int paramInt, float paramFloat) { super(paramInt, paramFloat); }
/*    */ 
/*    */ 
/*    */   
/* 10 */   public NumericValueHashtable(int paramInt) { super(paramInt); }
/*    */ 
/*    */ 
/*    */   
/*    */   public NumericValueHashtable() {}
/*    */ 
/*    */ 
/*    */   
/* 18 */   public boolean containsValue(long paramLong) { return super.containsValue(paramLong); }
/*    */ 
/*    */ 
/*    */   
/* 22 */   public boolean containsKey(Object paramObject) { return super.containsKey(paramObject); }
/*    */ 
/*    */ 
/*    */   
/* 26 */   public long get(Object paramObject) { return super.get(paramObject, 0L); }
/*    */ 
/*    */ 
/*    */   
/* 30 */   public long get(Object paramObject, long paramLong) { return super.get(paramObject, paramLong); }
/*    */ 
/*    */ 
/*    */   
/* 34 */   protected void rehash() { super.rehash(); }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public long put(Object paramObject, long paramLong) { return super.put(paramObject, paramLong); }
/*    */ 
/*    */ 
/*    */   
/* 42 */   public long remove(Object paramObject) { return super.remove(paramObject); }
/*    */ 
/*    */ 
/*    */   
/* 46 */   public void clear() { super.clear(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\collections\NumericValueHashtable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */