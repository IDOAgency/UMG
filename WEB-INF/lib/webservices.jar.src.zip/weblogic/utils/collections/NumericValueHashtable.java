package weblogic.utils.collections;

public class NumericValueHashtable extends NumericValueHashMap {
  public NumericValueHashtable(int paramInt, float paramFloat) { super(paramInt, paramFloat); }
  
  public NumericValueHashtable(int paramInt) { super(paramInt); }
  
  public NumericValueHashtable() {}
  
  public boolean containsValue(long paramLong) { return super.containsValue(paramLong); }
  
  public boolean containsKey(Object paramObject) { return super.containsKey(paramObject); }
  
  public long get(Object paramObject) { return super.get(paramObject, 0L); }
  
  public long get(Object paramObject, long paramLong) { return super.get(paramObject, paramLong); }
  
  protected void rehash() { super.rehash(); }
  
  public long put(Object paramObject, long paramLong) { return super.put(paramObject, paramLong); }
  
  public long remove(Object paramObject) { return super.remove(paramObject); }
  
  public void clear() { super.clear(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\collections\NumericValueHashtable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */