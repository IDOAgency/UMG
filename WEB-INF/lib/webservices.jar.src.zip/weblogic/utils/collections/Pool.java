package weblogic.utils.collections;

import java.util.Collection;

public interface Pool extends Collection {
  boolean add(Object paramObject);
  
  Object remove();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\collections\Pool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */