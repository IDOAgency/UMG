package weblogic.utils.collections;

import java.util.AbstractCollection;
import java.util.Iterator;

public class StackPool extends AbstractCollection implements Pool {
  private final int capacity;
  
  private int pointer;
  
  private final Object[] values;
  
  public StackPool(int paramInt) {
    if (paramInt < 0)
      throw new IllegalArgumentException(); 
    this.capacity = paramInt;
    this.values = new Object[this.capacity];
    this.pointer = 0;
  }
  
  protected int getPointer() { return this.pointer; }
  
  protected void setPointer(int paramInt) { this.pointer = paramInt; }
  
  protected Object getValueAt(int paramInt) { return this.values[paramInt]; }
  
  protected Object decrementPointerAndGetValue() { return this.values[--this.pointer]; }
  
  protected void setValueAt(int paramInt, Object paramObject) { this.values[paramInt] = paramObject; }
  
  public int size() { return this.pointer; }
  
  public int capacity() { return this.capacity; }
  
  public Iterator iterator() { return new Object(this, new ArrayIterator(this.values)); }
  
  public boolean add(Object paramObject) {
    if (this.pointer == this.capacity)
      return false; 
    this.values[this.pointer++] = paramObject;
    return true;
  }
  
  public Object remove() {
    if (this.pointer > 0) {
      Object object = this.values[--this.pointer];
      this.values[this.pointer] = null;
      return object;
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\collections\StackPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */