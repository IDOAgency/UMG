/*    */ package weblogic.utils.collections;
/*    */ 
/*    */ import java.util.AbstractCollection;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class StackPool
/*    */   extends AbstractCollection
/*    */   implements Pool {
/*    */   private final int capacity;
/*    */   private int pointer;
/*    */   private final Object[] values;
/*    */   
/*    */   public StackPool(int paramInt) {
/* 14 */     if (paramInt < 0) throw new IllegalArgumentException(); 
/* 15 */     this.capacity = paramInt;
/* 16 */     this.values = new Object[this.capacity];
/* 17 */     this.pointer = 0;
/*    */   }
/*    */ 
/*    */   
/* 21 */   protected int getPointer() { return this.pointer; }
/*    */ 
/*    */ 
/*    */   
/* 25 */   protected void setPointer(int paramInt) { this.pointer = paramInt; }
/*    */ 
/*    */ 
/*    */   
/* 29 */   protected Object getValueAt(int paramInt) { return this.values[paramInt]; }
/*    */ 
/*    */ 
/*    */   
/* 33 */   protected Object decrementPointerAndGetValue() { return this.values[--this.pointer]; }
/*    */ 
/*    */ 
/*    */   
/* 37 */   protected void setValueAt(int paramInt, Object paramObject) { this.values[paramInt] = paramObject; }
/*    */ 
/*    */   
/* 40 */   public int size() { return this.pointer; }
/*    */   
/* 42 */   public int capacity() { return this.capacity; }
/*    */ 
/*    */   
/* 45 */   public Iterator iterator() { return new Object(this, new ArrayIterator(this.values)); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean add(Object paramObject) {
/* 51 */     if (this.pointer == this.capacity) return false; 
/* 52 */     this.values[this.pointer++] = paramObject;
/* 53 */     return true;
/*    */   }
/*    */   
/*    */   public Object remove() {
/* 57 */     if (this.pointer > 0) {
/* 58 */       Object object = this.values[--this.pointer];
/* 59 */       this.values[this.pointer] = null;
/* 60 */       return object;
/*    */     } 
/* 62 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\collections\StackPool.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */