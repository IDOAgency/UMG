/*    */ package weblogic.utils.collections;
/*    */ 
/*    */ import java.util.AbstractCollection;
/*    */ import java.util.EmptyStackException;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public final class Stack
/*    */   extends AbstractCollection
/*    */ {
/*    */   private Object[] values;
/*    */   private int pointer;
/*    */   
/* 13 */   public Stack() { this(15); }
/*    */ 
/*    */   
/*    */   public Stack(int paramInt) {
/* 17 */     if (paramInt < 0) throw new IllegalArgumentException(); 
/* 18 */     this.values = new Object[paramInt];
/* 19 */     this.pointer = 0;
/*    */   }
/*    */   
/*    */   private Stack(Object[] paramArrayOfObject, int paramInt) {
/* 23 */     this.values = paramArrayOfObject;
/* 24 */     this.pointer = paramInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void resize() {
/* 31 */     if (this.pointer == 0) {
/* 32 */       this.values = new Object[1];
/*    */       return;
/*    */     } 
/* 35 */     Object[] arrayOfObject = new Object[this.pointer * 2];
/* 36 */     System.arraycopy(this.values, 0, arrayOfObject, 0, this.pointer);
/* 37 */     this.values = arrayOfObject;
/*    */   }
/*    */   
/*    */   public boolean add(Object paramObject) {
/* 41 */     push(paramObject);
/* 42 */     return true;
/*    */   }
/*    */   
/*    */   public void clear() {
/* 46 */     Object[] arrayOfObject = this.values;
/* 47 */     while (this.pointer > 0) {
/* 48 */       arrayOfObject[--this.pointer] = null;
/*    */     }
/*    */   }
/*    */   
/* 52 */   public boolean isEmpty() { return (this.pointer == 0); }
/*    */   
/*    */   public Iterator iterator() {
/* 55 */     Object[] arrayOfObject = new Object[this.pointer];
/* 56 */     System.arraycopy(this.values, 0, arrayOfObject, 0, this.pointer);
/* 57 */     return new ArrayIterator(arrayOfObject);
/*    */   }
/*    */   
/*    */   public Object clone() {
/* 61 */     Object[] arrayOfObject = new Object[this.pointer];
/* 62 */     System.arraycopy(this.values, 0, arrayOfObject, 0, this.pointer);
/* 63 */     return new Stack(arrayOfObject, this.pointer);
/*    */   }
/*    */   
/* 66 */   public int size() { return this.pointer; }
/*    */   
/*    */   public void push(Object paramObject) {
/* 69 */     if (this.pointer == this.values.length) resize(); 
/* 70 */     this.values[this.pointer++] = paramObject;
/*    */   }
/*    */   
/*    */   public Object pop() {
/*    */     try {
/* 75 */       Object object = this.values[--this.pointer];
/* 76 */       this.values[this.pointer] = null;
/* 77 */       return object;
/* 78 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/*    */ 
/*    */       
/* 81 */       if (this.pointer < 0) this.pointer = 0; 
/* 82 */       throw new EmptyStackException();
/*    */     } 
/*    */   }
/*    */   
/*    */   public Object peek() {
/*    */     try {
/* 88 */       return this.values[this.pointer - 1];
/* 89 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/* 90 */       throw new EmptyStackException();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\collections\Stack.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */