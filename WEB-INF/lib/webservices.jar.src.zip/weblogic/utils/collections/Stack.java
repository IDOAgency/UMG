package weblogic.utils.collections;

import java.util.AbstractCollection;
import java.util.EmptyStackException;
import java.util.Iterator;

public final class Stack extends AbstractCollection {
  private Object[] values;
  
  private int pointer;
  
  public Stack() { this(15); }
  
  public Stack(int paramInt) {
    if (paramInt < 0)
      throw new IllegalArgumentException(); 
    this.values = new Object[paramInt];
    this.pointer = 0;
  }
  
  private Stack(Object[] paramArrayOfObject, int paramInt) {
    this.values = paramArrayOfObject;
    this.pointer = paramInt;
  }
  
  private void resize() {
    if (this.pointer == 0) {
      this.values = new Object[1];
      return;
    } 
    Object[] arrayOfObject = new Object[this.pointer * 2];
    System.arraycopy(this.values, 0, arrayOfObject, 0, this.pointer);
    this.values = arrayOfObject;
  }
  
  public boolean add(Object paramObject) {
    push(paramObject);
    return true;
  }
  
  public void clear() {
    Object[] arrayOfObject = this.values;
    while (this.pointer > 0)
      arrayOfObject[--this.pointer] = null; 
  }
  
  public boolean isEmpty() { return (this.pointer == 0); }
  
  public Iterator iterator() {
    Object[] arrayOfObject = new Object[this.pointer];
    System.arraycopy(this.values, 0, arrayOfObject, 0, this.pointer);
    return new ArrayIterator(arrayOfObject);
  }
  
  public Object clone() {
    Object[] arrayOfObject = new Object[this.pointer];
    System.arraycopy(this.values, 0, arrayOfObject, 0, this.pointer);
    return new Stack(arrayOfObject, this.pointer);
  }
  
  public int size() { return this.pointer; }
  
  public void push(Object paramObject) {
    if (this.pointer == this.values.length)
      resize(); 
    this.values[this.pointer++] = paramObject;
  }
  
  public Object pop() {
    try {
      Object object = this.values[--this.pointer];
      this.values[this.pointer] = null;
      return object;
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      if (this.pointer < 0)
        this.pointer = 0; 
      throw new EmptyStackException();
    } 
  }
  
  public Object peek() {
    try {
      return this.values[this.pointer - 1];
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      throw new EmptyStackException();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\collections\Stack.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */