package weblogic.utils;

import java.io.PrintStream;
import java.io.PrintWriter;

public interface NestedThrowable {
  Throwable getNested();
  
  String superToString();
  
  void superPrintStackTrace(PrintStream paramPrintStream);
  
  void superPrintStackTrace(PrintWriter paramPrintWriter);
  
  public static class NestedThrowable {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\NestedThrowable.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */