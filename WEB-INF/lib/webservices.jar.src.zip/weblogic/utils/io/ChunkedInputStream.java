package weblogic.utils.io;

import java.io.IOException;
import java.io.InputStream;
import weblogic.utils.Hex;

public class ChunkedInputStream extends InputStream {
  protected Chunk head;
  
  private Chunk markHead;
  
  protected int streamPos;
  
  private int markStreamPos;
  
  protected int chunkPos;
  
  private int markChunkPos;
  
  private InputStream is;
  
  protected ChunkedInputStream() {}
  
  public ChunkedInputStream(Chunk paramChunk, int paramInt, InputStream paramInputStream) throws IOException {
    this.is = paramInputStream;
    this.head = paramChunk;
    skip(paramInt);
  }
  
  public ChunkedInputStream(Chunk paramChunk, int paramInt) { init(paramChunk, paramInt); }
  
  public final Chunk getChunks() { return this.head; }
  
  public void init(Chunk paramChunk, int paramInt) {
    this.head = paramChunk;
    this.markHead = null;
    this.streamPos = 0;
    this.chunkPos = 0;
    this.markStreamPos = -1;
    this.markChunkPos = -1;
    this.is = null;
    try {
      skip(paramInt);
    } catch (IOException iOException) {
      throw new AssertionError(iOException);
    } 
  }
  
  public String dumpBuf() {
    StringBuffer stringBuffer = new StringBuffer(Hex.dump(this.head.buf, this.chunkPos, this.head.end - this.chunkPos));
    Chunk chunk = this.head.next;
    while (chunk != null) {
      stringBuffer.append("\n").append(Hex.dump(chunk.buf, 0, chunk.end));
      chunk = chunk.next;
    } 
    return stringBuffer.toString();
  }
  
  protected final void advanceList() {
    this.streamPos += this.head.end;
    this.chunkPos = 0;
    Chunk chunk = this.head.next;
    if (this.markHead == null)
      Chunk.releaseChunk(this.head); 
    this.head = chunk;
  }
  
  public int available() {
    int i = this.head.end - this.chunkPos;
    for (Chunk chunk = this.head; chunk.next != null; ) {
      chunk = chunk.next;
      i += chunk.end;
    } 
    return i;
  }
  
  public void close() {
    if (this.markHead != null)
      reset(); 
    for (; this.head != null; advanceList());
  }
  
  public final void mark(int paramInt) {
    this.markStreamPos = this.streamPos;
    this.markChunkPos = this.chunkPos;
    this.markHead = this.head;
  }
  
  public final boolean markSupported() { return (this.is == null); }
  
  public int read() {
    if (this.chunkPos == this.head.end)
      if (this.head.next != null) {
        advanceList();
      } else {
        if (this.is != null)
          return this.is.read(); 
        return -1;
      }  
    return this.head.buf[this.chunkPos++] & 0xFF;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
    int i = paramInt2;
    while (paramInt2 > 0) {
      if (this.chunkPos == this.head.end)
        if (this.head.next != null) {
          advanceList();
        } else {
          if (this.is != null)
            return i - paramInt2 + this.is.read(paramArrayOfByte, paramInt1, paramInt2); 
          if (paramInt2 == i)
            return -1; 
          return i - paramInt2;
        }  
      int j = Math.min(this.head.end - this.chunkPos, paramInt2);
      System.arraycopy(this.head.buf, this.chunkPos, paramArrayOfByte, paramInt1, j);
      this.chunkPos += j;
      paramInt1 += j;
      paramInt2 -= j;
    } 
    return i;
  }
  
  public final void reset() {
    this.streamPos = this.markStreamPos;
    this.chunkPos = this.markChunkPos;
    this.head = this.markHead;
    this.markChunkPos = -1;
    this.markHead = null;
    this.markStreamPos = -1;
  }
  
  public long skip(long paramLong) throws IOException {
    long l = paramLong;
    while (paramLong > 0L) {
      if (this.chunkPos == this.head.end)
        if (this.head.next != null) {
          advanceList();
        } else {
          if (this.is != null)
            return l - paramLong + this.is.skip(paramLong); 
          return l - paramLong;
        }  
      long l1 = Math.min((this.head.end - this.chunkPos), paramLong);
      this.chunkPos = (int)(this.chunkPos + l1);
      paramLong -= l1;
    } 
    return l;
  }
  
  public final int peek() { return peek(this.chunkPos); }
  
  public final int peek(int paramInt) {
    if (this.chunkPos + paramInt < this.head.end) {
      byte b = this.head.buf[this.chunkPos + paramInt];
      return b & 0xFF;
    } 
    int i = this.head.end - this.chunkPos;
    Chunk chunk = this.head.next;
    while (true) {
      if (chunk == null)
        return -1; 
      if (paramInt - i < chunk.end) {
        byte b = chunk.buf[paramInt - i];
        return b & 0xFF;
      } 
      i += chunk.end;
      chunk = chunk.next;
    } 
  }
  
  public final int pos() { return this.streamPos + this.chunkPos; }
  
  public String toString() { return super.toString() + " - currentPos: '" + pos() + ", chunkPos: '" + this.chunkPos + "', currentChunk: '" + this.head + "'"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\io\ChunkedInputStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */