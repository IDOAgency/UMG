/*     */ package weblogic.utils.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import weblogic.utils.Hex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkedInputStream
/*     */   extends InputStream
/*     */ {
/*     */   protected Chunk head;
/*     */   private Chunk markHead;
/*     */   protected int streamPos;
/*     */   private int markStreamPos;
/*     */   protected int chunkPos;
/*     */   private int markChunkPos;
/*     */   private InputStream is;
/*     */   
/*     */   protected ChunkedInputStream() {}
/*     */   
/*     */   public ChunkedInputStream(Chunk paramChunk, int paramInt, InputStream paramInputStream) throws IOException {
/*  46 */     this.is = paramInputStream;
/*  47 */     this.head = paramChunk;
/*  48 */     skip(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public ChunkedInputStream(Chunk paramChunk, int paramInt) { init(paramChunk, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public final Chunk getChunks() { return this.head; }
/*     */ 
/*     */   
/*     */   public void init(Chunk paramChunk, int paramInt) {
/*  68 */     this.head = paramChunk;
/*  69 */     this.markHead = null;
/*  70 */     this.streamPos = 0;
/*  71 */     this.chunkPos = 0;
/*  72 */     this.markStreamPos = -1;
/*  73 */     this.markChunkPos = -1;
/*  74 */     this.is = null;
/*     */     try {
/*  76 */       skip(paramInt);
/*  77 */     } catch (IOException iOException) {
/*  78 */       throw new AssertionError(iOException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String dumpBuf() {
/*  83 */     StringBuffer stringBuffer = new StringBuffer(Hex.dump(this.head.buf, this.chunkPos, this.head.end - this.chunkPos));
/*     */     
/*  85 */     Chunk chunk = this.head.next;
/*     */     
/*  87 */     while (chunk != null) {
/*  88 */       stringBuffer.append("\n").append(Hex.dump(chunk.buf, 0, chunk.end));
/*  89 */       chunk = chunk.next;
/*     */     } 
/*  91 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   protected final void advanceList() {
/*  95 */     this.streamPos += this.head.end;
/*  96 */     this.chunkPos = 0;
/*  97 */     Chunk chunk = this.head.next;
/*  98 */     if (this.markHead == null) Chunk.releaseChunk(this.head); 
/*  99 */     this.head = chunk;
/*     */   }
/*     */   
/*     */   public int available() {
/* 103 */     int i = this.head.end - this.chunkPos;
/* 104 */     for (Chunk chunk = this.head; chunk.next != null; ) {
/* 105 */       chunk = chunk.next;
/* 106 */       i += chunk.end;
/*     */     } 
/* 108 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 114 */     if (this.markHead != null) reset(); 
/* 115 */     for (; this.head != null; advanceList());
/*     */   }
/*     */   
/*     */   public final void mark(int paramInt) {
/* 119 */     this.markStreamPos = this.streamPos;
/* 120 */     this.markChunkPos = this.chunkPos;
/* 121 */     this.markHead = this.head;
/*     */   }
/*     */   
/* 124 */   public final boolean markSupported() { return (this.is == null); }
/*     */ 
/*     */   
/*     */   public int read() {
/* 128 */     if (this.chunkPos == this.head.end) {
/* 129 */       if (this.head.next != null) { advanceList(); }
/*     */       
/*     */       else
/*     */       
/* 133 */       { if (this.is != null) return this.is.read(); 
/* 134 */         return -1; }
/*     */     
/*     */     }
/* 137 */     return this.head.buf[this.chunkPos++] & 0xFF;
/*     */   }
/*     */   
/*     */   public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/* 141 */     int i = paramInt2;
/* 142 */     while (paramInt2 > 0) {
/*     */       
/* 144 */       if (this.chunkPos == this.head.end) {
/* 145 */         if (this.head.next != null)
/* 146 */         { advanceList(); }
/* 147 */         else { if (this.is != null)
/*     */           {
/*     */ 
/*     */             
/* 151 */             return i - paramInt2 + this.is.read(paramArrayOfByte, paramInt1, paramInt2);
/*     */           }
/* 153 */           if (paramInt2 == i) return -1; 
/* 154 */           return i - paramInt2; }
/*     */       
/*     */       }
/* 157 */       int j = Math.min(this.head.end - this.chunkPos, paramInt2);
/* 158 */       System.arraycopy(this.head.buf, this.chunkPos, paramArrayOfByte, paramInt1, j);
/* 159 */       this.chunkPos += j;
/* 160 */       paramInt1 += j;
/* 161 */       paramInt2 -= j;
/*     */     } 
/* 163 */     return i;
/*     */   }
/*     */   
/*     */   public final void reset() {
/* 167 */     this.streamPos = this.markStreamPos;
/* 168 */     this.chunkPos = this.markChunkPos;
/* 169 */     this.head = this.markHead;
/* 170 */     this.markChunkPos = -1;
/* 171 */     this.markHead = null;
/* 172 */     this.markStreamPos = -1;
/*     */   }
/*     */   
/*     */   public long skip(long paramLong) throws IOException {
/* 176 */     long l = paramLong;
/* 177 */     while (paramLong > 0L) {
/* 178 */       if (this.chunkPos == this.head.end) {
/* 179 */         if (this.head.next != null)
/* 180 */         { advanceList(); }
/* 181 */         else { if (this.is != null) {
/* 182 */             return l - paramLong + this.is.skip(paramLong);
/*     */           }
/* 184 */           return l - paramLong; }
/*     */       
/*     */       }
/* 187 */       long l1 = Math.min((this.head.end - this.chunkPos), paramLong);
/* 188 */       this.chunkPos = (int)(this.chunkPos + l1);
/* 189 */       paramLong -= l1;
/*     */     } 
/* 191 */     return l;
/*     */   }
/*     */   
/* 194 */   public final int peek() { return peek(this.chunkPos); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int peek(int paramInt) {
/* 206 */     if (this.chunkPos + paramInt < this.head.end) {
/* 207 */       byte b = this.head.buf[this.chunkPos + paramInt];
/* 208 */       return b & 0xFF;
/*     */     } 
/*     */ 
/*     */     
/* 212 */     int i = this.head.end - this.chunkPos;
/* 213 */     Chunk chunk = this.head.next;
/*     */     while (true) {
/* 215 */       if (chunk == null) return -1;
/*     */       
/* 217 */       if (paramInt - i < chunk.end) {
/* 218 */         byte b = chunk.buf[paramInt - i];
/* 219 */         return b & 0xFF;
/*     */       } 
/* 221 */       i += chunk.end;
/* 222 */       chunk = chunk.next;
/*     */     } 
/*     */   }
/*     */   
/* 226 */   public final int pos() { return this.streamPos + this.chunkPos; }
/*     */ 
/*     */   
/* 229 */   public String toString() { return super.toString() + " - currentPos: '" + pos() + ", chunkPos: '" + this.chunkPos + "', currentChunk: '" + this.head + "'"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\io\ChunkedInputStream.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */