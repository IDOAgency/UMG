/*     */ package weblogic.utils.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.ArrayList;
/*     */ import weblogic.utils.Hex;
/*     */ import weblogic.utils.collections.PartitionedStackPool;
/*     */ import weblogic.utils.collections.Pool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Chunk
/*     */ {
/*     */   private static final int DEFAULT_CHUNK_SIZE = 4080;
/*     */   private static final int DEFAULT_PARTITION_SIZE = 4;
/*     */   private static final int DEFAULT_CHUNK_POOL_SIZE = 2048;
/*  37 */   public static final int CHUNK_SIZE = getChunkSize();
/*     */   
/*  39 */   private static final Pool chunkPool = new PartitionedStackPool(getPoolSize(), getPartitionSize());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean memoryLow = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private static final ArrayList memoryManagedList = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] buf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int end;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Chunk next;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getChunkSize() {
/*  79 */     Integer integer = null;
/*     */     
/*     */     try {
/*  82 */       integer = Integer.getInteger("weblogic.Chunksize");
/*  83 */       if (integer == null) integer = Integer.getInteger("weblogic.utils.io.Chunk.ChunkSize"); 
/*  84 */     } catch (SecurityException securityException) {}
/*     */     
/*  86 */     if (integer == null) integer = new Integer(4080); 
/*  87 */     return integer.intValue();
/*     */   }
/*     */   
/*     */   private static int getPartitionSize() {
/*  91 */     Integer integer = null;
/*     */     try {
/*  93 */       integer = Integer.getInteger("weblogic.PartitionSize");
/*  94 */     } catch (SecurityException securityException) {}
/*     */ 
/*     */     
/*  97 */     if (integer == null) integer = new Integer(4); 
/*  98 */     return integer.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getPoolSize() {
/* 117 */     Integer integer = null;
/*     */ 
/*     */     
/*     */     try {
/* 121 */       integer = Integer.getInteger("weblogic.utils.io.chunkpoolsize");
/* 122 */       if (integer == null) integer = Integer.getInteger("weblogic.utils.io.Chunk.PoolSize"); 
/* 123 */     } catch (SecurityException securityException) {}
/*     */     
/* 125 */     if (integer == null) integer = new Integer(2048); 
/* 126 */     return integer.intValue();
/*     */   }
/*     */   
/*     */   public static Chunk getChunk() {
/* 130 */     Chunk chunk = (Chunk)chunkPool.remove();
/* 131 */     if (chunk == null) {
/*     */ 
/*     */       
/* 134 */       synchronized (memoryManagedList) {
/* 135 */         while (chunk == null && memoryManagedList.size() > 0) {
/* 136 */           SoftReference softReference = (SoftReference)memoryManagedList.remove(0);
/* 137 */           chunk = (Chunk)softReference.get();
/*     */         } 
/*     */       } 
/* 140 */       if (chunk == null) {
/* 141 */         chunk = new Chunk();
/*     */       }
/*     */     } 
/* 144 */     return chunk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void releaseChunk(Chunk paramChunk) {
/* 153 */     paramChunk.end = 0;
/* 154 */     paramChunk.next = null;
/* 155 */     if (!chunkPool.add(paramChunk) && !memoryLow)
/*     */     {
/*     */       
/* 158 */       synchronized (memoryManagedList) {
/* 159 */         memoryManagedList.add(new SoftReference(paramChunk));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void releaseChunks(Chunk paramChunk) {
/* 169 */     while (paramChunk != null) {
/* 170 */       Chunk chunk = paramChunk.next;
/* 171 */       releaseChunk(paramChunk);
/* 172 */       paramChunk = chunk;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void signalLowMemoryCondition() {
/* 177 */     synchronized (memoryManagedList) {
/* 178 */       memoryLow = true;
/* 179 */       memoryManagedList.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void clearLowMemoryCondition() {
/* 184 */     synchronized (memoryManagedList) {
/* 185 */       memoryLow = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int size(Chunk paramChunk) {
/* 190 */     int i = 0;
/* 191 */     while (paramChunk != null) {
/* 192 */       i += paramChunk.end;
/* 193 */       paramChunk = paramChunk.next;
/*     */     } 
/* 195 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chunk tail(Chunk paramChunk) {
/*     */     Chunk chunk;
/* 203 */     for (chunk = paramChunk; chunk.next != null; chunk = chunk.next);
/* 204 */     return chunk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chunk ensureCapacity(Chunk paramChunk) {
/* 212 */     if (CHUNK_SIZE == paramChunk.end) {
/* 213 */       paramChunk.next = getChunk();
/* 214 */       return paramChunk.next;
/*     */     } 
/* 216 */     return paramChunk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int chunkFully(Chunk paramChunk, InputStream paramInputStream) throws IOException {
/* 224 */     Chunk chunk = tail(paramChunk);
/* 225 */     int i = 0;
/*     */     while (true) {
/* 227 */       chunk = ensureCapacity(chunk);
/* 228 */       int j = paramInputStream.read(chunk.buf, chunk.end, CHUNK_SIZE - chunk.end);
/* 229 */       if (j == -1)
/* 230 */         break;  chunk.end += j;
/* 231 */       i += j;
/*     */     } 
/* 233 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int chunk(Chunk paramChunk, InputStream paramInputStream, int paramInt) throws IOException {
/* 243 */     Chunk chunk = tail(paramChunk);
/* 244 */     int i = paramInt;
/* 245 */     while (paramInt > 0) {
/* 246 */       chunk = ensureCapacity(chunk);
/* 247 */       int j = Math.min(paramInt, CHUNK_SIZE - chunk.end);
/* 248 */       int k = paramInputStream.read(chunk.buf, chunk.end, j);
/* 249 */       if (k == -1) return i - paramInt; 
/* 250 */       chunk.end += k;
/* 251 */       paramInt -= k;
/*     */     } 
/* 253 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Chunk split(Chunk paramChunk, int paramInt) {
/*     */     Chunk chunk;
/* 262 */     int i = 0;
/*     */     
/* 264 */     while (i < paramInt) {
/* 265 */       i += paramChunk.end;
/* 266 */       if (i < paramInt) {
/* 267 */         paramChunk = paramChunk.next;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 272 */     int j = i - paramInt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     if (j == 0) {
/* 279 */       chunk = paramChunk.next;
/*     */     } else {
/* 281 */       chunk = getChunk();
/* 282 */       System.arraycopy(paramChunk.buf, paramChunk.end - j, chunk.buf, 0, j);
/* 283 */       paramChunk.end -= j;
/* 284 */       chunk.end = j;
/* 285 */       chunk.next = paramChunk.next;
/*     */     } 
/*     */     
/* 288 */     paramChunk.next = null;
/* 289 */     return chunk;
/*     */   }
/*     */   
/*     */   private Chunk() {
/* 293 */     this.buf = new byte[CHUNK_SIZE];
/* 294 */     this.end = 0;
/* 295 */     this.next = null;
/*     */   }
/*     */   
/*     */   public Chunk(int paramInt) {
/* 299 */     this.buf = new byte[paramInt];
/* 300 */     this.end = 0;
/* 301 */     this.next = null;
/*     */   }
/*     */ 
/*     */   
/* 305 */   public String toString() { return super.toString() + " - end: '" + this.end + "', buf: '" + Hex.dump(this.buf) + "', next: '" + this.next + "'"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\io\Chunk.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */