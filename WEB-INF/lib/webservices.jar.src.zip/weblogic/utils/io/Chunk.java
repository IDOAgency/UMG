package weblogic.utils.io;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.util.ArrayList;
import weblogic.utils.Hex;
import weblogic.utils.collections.PartitionedStackPool;
import weblogic.utils.collections.Pool;

public final class Chunk {
  private static final int DEFAULT_CHUNK_SIZE = 4080;
  
  private static final int DEFAULT_PARTITION_SIZE = 4;
  
  private static final int DEFAULT_CHUNK_POOL_SIZE = 2048;
  
  public static final int CHUNK_SIZE = getChunkSize();
  
  private static final Pool chunkPool = new PartitionedStackPool(getPoolSize(), getPartitionSize());
  
  private static boolean memoryLow = false;
  
  private static final ArrayList memoryManagedList = new ArrayList();
  
  public final byte[] buf;
  
  public int end;
  
  public Chunk next;
  
  private static int getChunkSize() {
    Integer integer = null;
    try {
      integer = Integer.getInteger("weblogic.Chunksize");
      if (integer == null)
        integer = Integer.getInteger("weblogic.utils.io.Chunk.ChunkSize"); 
    } catch (SecurityException securityException) {}
    if (integer == null)
      integer = new Integer(4080); 
    return integer.intValue();
  }
  
  private static int getPartitionSize() {
    Integer integer = null;
    try {
      integer = Integer.getInteger("weblogic.PartitionSize");
    } catch (SecurityException securityException) {}
    if (integer == null)
      integer = new Integer(4); 
    return integer.intValue();
  }
  
  private static int getPoolSize() {
    Integer integer = null;
    try {
      integer = Integer.getInteger("weblogic.utils.io.chunkpoolsize");
      if (integer == null)
        integer = Integer.getInteger("weblogic.utils.io.Chunk.PoolSize"); 
    } catch (SecurityException securityException) {}
    if (integer == null)
      integer = new Integer(2048); 
    return integer.intValue();
  }
  
  public static Chunk getChunk() {
    Chunk chunk = (Chunk)chunkPool.remove();
    if (chunk == null) {
      synchronized (memoryManagedList) {
        while (chunk == null && memoryManagedList.size() > 0) {
          SoftReference softReference = (SoftReference)memoryManagedList.remove(0);
          chunk = (Chunk)softReference.get();
        } 
      } 
      if (chunk == null)
        chunk = new Chunk(); 
    } 
    return chunk;
  }
  
  public static void releaseChunk(Chunk paramChunk) {
    paramChunk.end = 0;
    paramChunk.next = null;
    if (!chunkPool.add(paramChunk) && !memoryLow)
      synchronized (memoryManagedList) {
        memoryManagedList.add(new SoftReference(paramChunk));
      }  
  }
  
  public static void releaseChunks(Chunk paramChunk) {
    while (paramChunk != null) {
      Chunk chunk = paramChunk.next;
      releaseChunk(paramChunk);
      paramChunk = chunk;
    } 
  }
  
  public static void signalLowMemoryCondition() {
    synchronized (memoryManagedList) {
      memoryLow = true;
      memoryManagedList.clear();
    } 
  }
  
  public static void clearLowMemoryCondition() {
    synchronized (memoryManagedList) {
      memoryLow = false;
    } 
  }
  
  public static int size(Chunk paramChunk) {
    int i = 0;
    while (paramChunk != null) {
      i += paramChunk.end;
      paramChunk = paramChunk.next;
    } 
    return i;
  }
  
  public static Chunk tail(Chunk paramChunk) {
    Chunk chunk;
    for (chunk = paramChunk; chunk.next != null; chunk = chunk.next);
    return chunk;
  }
  
  public static Chunk ensureCapacity(Chunk paramChunk) {
    if (CHUNK_SIZE == paramChunk.end) {
      paramChunk.next = getChunk();
      return paramChunk.next;
    } 
    return paramChunk;
  }
  
  public static int chunkFully(Chunk paramChunk, InputStream paramInputStream) throws IOException {
    Chunk chunk = tail(paramChunk);
    int i = 0;
    while (true) {
      chunk = ensureCapacity(chunk);
      int j = paramInputStream.read(chunk.buf, chunk.end, CHUNK_SIZE - chunk.end);
      if (j == -1)
        break; 
      chunk.end += j;
      i += j;
    } 
    return i;
  }
  
  public static int chunk(Chunk paramChunk, InputStream paramInputStream, int paramInt) throws IOException {
    Chunk chunk = tail(paramChunk);
    int i = paramInt;
    while (paramInt > 0) {
      chunk = ensureCapacity(chunk);
      int j = Math.min(paramInt, CHUNK_SIZE - chunk.end);
      int k = paramInputStream.read(chunk.buf, chunk.end, j);
      if (k == -1)
        return i - paramInt; 
      chunk.end += k;
      paramInt -= k;
    } 
    return i;
  }
  
  public static Chunk split(Chunk paramChunk, int paramInt) {
    Chunk chunk;
    int i = 0;
    while (i < paramInt) {
      i += paramChunk.end;
      if (i < paramInt)
        paramChunk = paramChunk.next; 
    } 
    int j = i - paramInt;
    if (j == 0) {
      chunk = paramChunk.next;
    } else {
      chunk = getChunk();
      System.arraycopy(paramChunk.buf, paramChunk.end - j, chunk.buf, 0, j);
      paramChunk.end -= j;
      chunk.end = j;
      chunk.next = paramChunk.next;
    } 
    paramChunk.next = null;
    return chunk;
  }
  
  private Chunk() {
    this.buf = new byte[CHUNK_SIZE];
    this.end = 0;
    this.next = null;
  }
  
  public Chunk(int paramInt) {
    this.buf = new byte[paramInt];
    this.end = 0;
    this.next = null;
  }
  
  public String toString() { return super.toString() + " - end: '" + this.end + "', buf: '" + Hex.dump(this.buf) + "', next: '" + this.next + "'"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\io\Chunk.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */