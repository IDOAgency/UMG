package weblogic.utils.encoders;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public abstract class CharacterEncoder {
  protected PrintStream pStream;
  
  abstract int bytesPerAtom();
  
  abstract int bytesPerLine();
  
  void encodeBufferPrefix(OutputStream paramOutputStream) throws IOException { this.pStream = new PrintStream(paramOutputStream); }
  
  void encodeBufferSuffix(OutputStream paramOutputStream) throws IOException {}
  
  void encodeLinePrefix(OutputStream paramOutputStream, int paramInt) throws IOException {}
  
  void encodeLineSuffix(OutputStream paramOutputStream) throws IOException { this.pStream.println(); }
  
  abstract void encodeAtom(OutputStream paramOutputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException;
  
  protected int readFully(InputStream paramInputStream, byte[] paramArrayOfByte) throws IOException {
    for (byte b = 0; b < paramArrayOfByte.length; b++) {
      int i = paramInputStream.read();
      if (i == -1)
        return b; 
      paramArrayOfByte[b] = (byte)i;
    } 
    return paramArrayOfByte.length;
  }
  
  public void encodeBuffer(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    int i;
    byte[] arrayOfByte = new byte[bytesPerLine()];
    encodeBufferPrefix(paramOutputStream);
    do {
      i = readFully(paramInputStream, arrayOfByte);
      if (i == -1)
        break; 
      encodeLinePrefix(paramOutputStream, i);
      for (int j = 0; j < i; j += bytesPerAtom()) {
        if (j + bytesPerAtom() <= i) {
          encodeAtom(paramOutputStream, arrayOfByte, j, bytesPerAtom());
        } else {
          encodeAtom(paramOutputStream, arrayOfByte, j, i - j);
        } 
      } 
      encodeLineSuffix(paramOutputStream);
    } while (i >= bytesPerLine());
    encodeBufferSuffix(paramOutputStream);
  }
  
  public void encodeBuffer(byte[] paramArrayOfByte, OutputStream paramOutputStream) throws IOException {
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    encodeBuffer(byteArrayInputStream, paramOutputStream);
  }
  
  public String encodeBuffer(byte[] paramArrayOfByte) {
    String str;
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
    try {
      encodeBuffer(byteArrayInputStream, byteArrayOutputStream);
    } catch (Exception null) {
      throw new Error("ChracterEncoder::encodeBuffer internal error");
    } 
    try {
      str = byteArrayOutputStream.toString("UTF8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw new Error("CharacterEncoder::encodeBuffer internal error(2)");
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\encoders\CharacterEncoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */