/*     */ package weblogic.utils.encoders;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CharacterEncoder
/*     */ {
/*     */   protected PrintStream pStream;
/*     */   
/*     */   abstract int bytesPerAtom();
/*     */   
/*     */   abstract int bytesPerLine();
/*     */   
/*  98 */   void encodeBufferPrefix(OutputStream paramOutputStream) throws IOException { this.pStream = new PrintStream(paramOutputStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void encodeBufferSuffix(OutputStream paramOutputStream) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void encodeLinePrefix(OutputStream paramOutputStream, int paramInt) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   void encodeLineSuffix(OutputStream paramOutputStream) throws IOException { this.pStream.println(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void encodeAtom(OutputStream paramOutputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int readFully(InputStream paramInputStream, byte[] paramArrayOfByte) throws IOException {
/* 129 */     for (byte b = 0; b < paramArrayOfByte.length; b++) {
/* 130 */       int i = paramInputStream.read();
/* 131 */       if (i == -1)
/* 132 */         return b; 
/* 133 */       paramArrayOfByte[b] = (byte)i;
/*     */     } 
/* 135 */     return paramArrayOfByte.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBuffer(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
/*     */     int i;
/* 147 */     byte[] arrayOfByte = new byte[bytesPerLine()];
/*     */     
/* 149 */     encodeBufferPrefix(paramOutputStream);
/*     */     
/*     */     do {
/* 152 */       i = readFully(paramInputStream, arrayOfByte);
/* 153 */       if (i == -1) {
/*     */         break;
/*     */       }
/* 156 */       encodeLinePrefix(paramOutputStream, i);
/* 157 */       for (int j = 0; j < i; j += bytesPerAtom()) {
/* 158 */         if (j + bytesPerAtom() <= i) {
/* 159 */           encodeAtom(paramOutputStream, arrayOfByte, j, bytesPerAtom());
/*     */         } else {
/* 161 */           encodeAtom(paramOutputStream, arrayOfByte, j, i - j);
/*     */         } 
/*     */       } 
/* 164 */       encodeLineSuffix(paramOutputStream);
/* 165 */     } while (i >= bytesPerLine());
/*     */ 
/*     */ 
/*     */     
/* 169 */     encodeBufferSuffix(paramOutputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void encodeBuffer(byte[] paramArrayOfByte, OutputStream paramOutputStream) throws IOException {
/* 177 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
/* 178 */     encodeBuffer(byteArrayInputStream, paramOutputStream);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encodeBuffer(byte[] paramArrayOfByte) {
/*     */     String str;
/* 186 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 187 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
/*     */     try {
/* 189 */       encodeBuffer(byteArrayInputStream, byteArrayOutputStream);
/* 190 */     } catch (Exception null) {
/*     */       
/* 192 */       throw new Error("ChracterEncoder::encodeBuffer internal error");
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 197 */       str = byteArrayOutputStream.toString("UTF8");
/* 198 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/* 200 */       throw new Error("CharacterEncoder::encodeBuffer internal error(2)");
/*     */     } 
/* 202 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\encoders\CharacterEncoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */