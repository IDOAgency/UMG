/*     */ package weblogic.utils.encoders;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64Encoder
/*     */   extends CharacterEncoder
/*     */ {
/*  54 */   int bytesPerAtom() { return 3; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   int bytesPerLine() { return 57; }
/*     */ 
/*     */   
/*     */   private static final char[] pem_array = { 
/*  67 */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void encodeAtom(OutputStream paramOutputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/*  89 */     if (paramInt2 == 1) {
/*  90 */       byte b = paramArrayOfByte[paramInt1];
/*  91 */       boolean bool1 = false;
/*  92 */       boolean bool2 = false;
/*  93 */       paramOutputStream.write(pem_array[b >>> 2 & 0x3F]);
/*  94 */       paramOutputStream.write(pem_array[(b << 4 & 0x30) + (bool1 >>> 4 & 0xF)]);
/*  95 */       paramOutputStream.write(61);
/*  96 */       paramOutputStream.write(61);
/*  97 */     } else if (paramInt2 == 2) {
/*  98 */       byte b1 = paramArrayOfByte[paramInt1];
/*  99 */       byte b2 = paramArrayOfByte[paramInt1 + 1];
/* 100 */       boolean bool = false;
/* 101 */       paramOutputStream.write(pem_array[b1 >>> 2 & 0x3F]);
/* 102 */       paramOutputStream.write(pem_array[(b1 << 4 & 0x30) + (b2 >>> 4 & 0xF)]);
/* 103 */       paramOutputStream.write(pem_array[(b2 << 2 & 0x3C) + (bool >>> 6 & 0x3)]);
/* 104 */       paramOutputStream.write(61);
/*     */     } else {
/* 106 */       byte b1 = paramArrayOfByte[paramInt1];
/* 107 */       byte b2 = paramArrayOfByte[paramInt1 + 1];
/* 108 */       byte b3 = paramArrayOfByte[paramInt1 + 2];
/* 109 */       paramOutputStream.write(pem_array[b1 >>> 2 & 0x3F]);
/* 110 */       paramOutputStream.write(pem_array[(b1 << 4 & 0x30) + (b2 >>> 4 & 0xF)]);
/* 111 */       paramOutputStream.write(pem_array[(b2 << 2 & 0x3C) + (b3 >>> 6 & 0x3)]);
/* 112 */       paramOutputStream.write(pem_array[b3 & 0x3F]);
/*     */     } 
/*     */   }
/*     */   
/*     */   void encodeLineSuffix(OutputStream paramOutputStream) throws IOException {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\encoders\BASE64Encoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */