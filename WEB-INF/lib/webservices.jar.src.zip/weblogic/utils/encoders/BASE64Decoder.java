/*     */ package weblogic.utils.encoders;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BASE64Decoder
/*     */   extends CharacterDecoder
/*     */ {
/*  68 */   int bytesPerAtom() { return 4; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   int bytesPerLine() { return 72; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final char[] pem_array = { 
/*  80 */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private static final byte[] pem_convert_array = new byte[256];
/*     */   static  {
/*     */     byte b;
/*  95 */     for (b = 0; b < 'ÿ'; b++) {
/*  96 */       pem_convert_array[b] = -1;
/*     */     }
/*  98 */     for (b = 0; b < pem_array.length; b++) {
/*  99 */       pem_convert_array[pem_array[b]] = (byte)b;
/*     */     }
/*     */   }
/*     */   
/* 103 */   byte[] decode_buffer = new byte[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decodeAtom(InputStream paramInputStream, OutputStream paramOutputStream, int paramInt) throws IOException {
/* 112 */     byte b1 = -1, b2 = -1, b3 = -1, b4 = -1;
/*     */     
/* 114 */     if (paramInt < 2) {
/* 115 */       throw new CEFormatException("BASE64Decoder: Not enough bytes for an atom.");
/*     */     }
/*     */     do {
/* 118 */       i = paramInputStream.read();
/* 119 */       if (i == -1) {
/* 120 */         throw new CEStreamExhausted();
/*     */       }
/* 122 */     } while (i == 10 || i == 13);
/* 123 */     this.decode_buffer[0] = (byte)i;
/*     */     
/* 125 */     int i = readFully(paramInputStream, this.decode_buffer, 1, paramInt - 1);
/* 126 */     if (i == -1) {
/* 127 */       throw new CEStreamExhausted();
/*     */     }
/*     */     
/* 130 */     if (paramInt > 3 && this.decode_buffer[3] == 61) {
/* 131 */       paramInt = 3;
/*     */     }
/* 133 */     if (paramInt > 2 && this.decode_buffer[2] == 61) {
/* 134 */       paramInt = 2;
/*     */     }
/* 136 */     switch (paramInt) {
/*     */       case 4:
/* 138 */         b4 = pem_convert_array[this.decode_buffer[3] & 0xFF];
/*     */       
/*     */       case 3:
/* 141 */         b3 = pem_convert_array[this.decode_buffer[2] & 0xFF];
/*     */       
/*     */       case 2:
/* 144 */         b2 = pem_convert_array[this.decode_buffer[1] & 0xFF];
/* 145 */         b1 = pem_convert_array[this.decode_buffer[0] & 0xFF];
/*     */         break;
/*     */     } 
/*     */     
/* 149 */     switch (paramInt) {
/*     */       case 2:
/* 151 */         paramOutputStream.write((byte)(b1 << 2 & 0xFC | b2 >>> 4 & 0x3));
/*     */         break;
/*     */       case 3:
/* 154 */         paramOutputStream.write((byte)(b1 << 2 & 0xFC | b2 >>> 4 & 0x3));
/* 155 */         paramOutputStream.write((byte)(b2 << 4 & 0xF0 | b3 >>> 2 & 0xF));
/*     */         break;
/*     */       case 4:
/* 158 */         paramOutputStream.write((byte)(b1 << 2 & 0xFC | b2 >>> 4 & 0x3));
/* 159 */         paramOutputStream.write((byte)(b2 << 4 & 0xF0 | b3 >>> 2 & 0xF));
/* 160 */         paramOutputStream.write((byte)(b3 << 6 & 0xC0 | b4 & 0x3F));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\encoders\BASE64Decoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */