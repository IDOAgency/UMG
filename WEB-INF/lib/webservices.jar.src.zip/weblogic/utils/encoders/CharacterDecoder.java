/*     */ package weblogic.utils.encoders;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CharacterDecoder
/*     */ {
/*     */   abstract int bytesPerAtom();
/*     */   
/*     */   abstract int bytesPerLine();
/*     */   
/*     */   void decodeBufferPrefix(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {}
/*     */   
/*     */   void decodeBufferSuffix(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {}
/*     */   
/* 111 */   int decodeLinePrefix(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException { return bytesPerLine(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decodeLineSuffix(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   void decodeAtom(InputStream paramInputStream, OutputStream paramOutputStream, int paramInt) throws IOException { throw new CEStreamExhausted(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int readFully(InputStream paramInputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2) throws IOException {
/* 137 */     for (int i = 0; i < paramInt2; i++) {
/* 138 */       int j = paramInputStream.read();
/* 139 */       if (j == -1)
/* 140 */         return !i ? -1 : i; 
/* 141 */       paramArrayOfByte[i + paramInt1] = (byte)j;
/*     */     } 
/* 143 */     return paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decodeBuffer(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
/* 155 */     int i = 0;
/*     */     
/* 157 */     decodeBufferPrefix(paramInputStream, paramOutputStream);
/*     */ 
/*     */     
/*     */     try {
/*     */       while (true)
/* 162 */       { int k = decodeLinePrefix(paramInputStream, paramOutputStream); int j;
/* 163 */         for (j = 0; j + bytesPerAtom() < k; j += bytesPerAtom()) {
/* 164 */           decodeAtom(paramInputStream, paramOutputStream, bytesPerAtom());
/* 165 */           i += bytesPerAtom();
/*     */         } 
/* 167 */         if (j + bytesPerAtom() == k) {
/* 168 */           decodeAtom(paramInputStream, paramOutputStream, bytesPerAtom());
/* 169 */           i += bytesPerAtom();
/*     */         } else {
/* 171 */           decodeAtom(paramInputStream, paramOutputStream, k - j);
/* 172 */           i += k - j;
/*     */         } 
/* 174 */         decodeLineSuffix(paramInputStream, paramOutputStream); } 
/* 175 */     } catch (CEStreamExhausted cEStreamExhausted) {
/*     */ 
/*     */ 
/*     */       
/* 179 */       decodeBufferSuffix(paramInputStream, paramOutputStream);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decodeBuffer(String paramString) throws IOException {
/* 188 */     byte[] arrayOfByte = new byte[paramString.length()];
/*     */ 
/*     */ 
/*     */     
/* 192 */     paramString.getBytes(0, paramString.length(), arrayOfByte, 0);
/* 193 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(arrayOfByte);
/* 194 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 195 */     decodeBuffer(byteArrayInputStream, byteArrayOutputStream);
/* 196 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decodeBuffer(InputStream paramInputStream) throws IOException {
/* 203 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 204 */     decodeBuffer(paramInputStream, byteArrayOutputStream);
/* 205 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\encoders\CharacterDecoder.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */