/*    */ package weblogic.utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssertionError
/*    */   extends NestedError
/*    */   implements PlatformConstants
/*    */ {
/*    */   private static final boolean debug = true;
/*    */   private static final boolean verbose = true;
/*    */   private static final boolean makeFatal = false;
/*    */   private static final String DEFAULT_MSG = "***** ASSERTION FAILED *****";
/*    */   
/*    */   public AssertionError() {
/* 36 */     super("***** ASSERTION FAILED *****");
/* 37 */     printStackTrace();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AssertionError(String paramString) {
/* 46 */     super("***** ASSERTION FAILED *****[ " + paramString + " ]");
/* 47 */     printStackTrace();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AssertionError(Throwable paramThrowable) {
/* 56 */     super("***** ASSERTION FAILED *****", paramThrowable);
/* 57 */     printStackTrace();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AssertionError(String paramString, Throwable paramThrowable) {
/* 66 */     super("***** ASSERTION FAILED *****[ " + paramString + " ]", paramThrowable);
/* 67 */     printStackTrace();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void exit() {
/* 73 */     System.err.println("Exiting because AssertionError.makeFatal == true.");
/* 74 */     System.exit(-1);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\AssertionError.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */