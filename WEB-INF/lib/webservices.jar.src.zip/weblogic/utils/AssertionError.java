package weblogic.utils;

public class AssertionError extends NestedError implements PlatformConstants {
  private static final boolean debug = true;
  
  private static final boolean verbose = true;
  
  private static final boolean makeFatal = false;
  
  private static final String DEFAULT_MSG = "***** ASSERTION FAILED *****";
  
  public AssertionError() {
    super("***** ASSERTION FAILED *****");
    printStackTrace();
  }
  
  public AssertionError(String paramString) {
    super("***** ASSERTION FAILED *****[ " + paramString + " ]");
    printStackTrace();
  }
  
  public AssertionError(Throwable paramThrowable) {
    super("***** ASSERTION FAILED *****", paramThrowable);
    printStackTrace();
  }
  
  public AssertionError(String paramString, Throwable paramThrowable) {
    super("***** ASSERTION FAILED *****[ " + paramString + " ]", paramThrowable);
    printStackTrace();
  }
  
  private void exit() {
    System.err.println("Exiting because AssertionError.makeFatal == true.");
    System.exit(-1);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\AssertionError.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */