package weblogic.utils;

import java.io.PrintStream;
import java.util.Date;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.logging.Logger;

public final class Debug {
  private static final boolean DEBUG = false;
  
  private static final Logger LOGGER = Logger.getLogger("weblogic.utils.Debug");
  
  private static final PrintStream out = System.out;
  
  public static boolean verboseMethods = false;
  
  public static boolean showLineNumbers = false;
  
  public static boolean addTimeStamp = false;
  
  private static final Hashtable categories;
  
  static  {
    try {
      verboseMethods = Boolean.getBoolean("debug.methodNames");
      showLineNumbers = Boolean.getBoolean("debug.lineNumbers");
      addTimeStamp = Boolean.getBoolean("debug.addTimeStamp");
    } catch (SecurityException securityException) {}
    categories = new Hashtable();
  }
  
  public static void assertion(boolean paramBoolean) {
    if (!paramBoolean)
      throw new java.lang.AssertionError("Assertion violated"); 
  }
  
  public static void assertion(boolean paramBoolean, String paramString) {
    if (!paramBoolean)
      throw new java.lang.AssertionError(paramString); 
  }
  
  public static void say(String paramString) { out.println((addTimeStamp ? ("" + new Date()) : "") + (new StackTrace()).location(0).tag(0) + paramString); }
  
  public static void timestamp(String paramString) { out.println("[" + System.currentTimeMillis() + "] " + paramString); }
  
  public static void here() { out.println("*** " + (new StackTrace()).location(0).dump() + " ***"); }
  
  public static void stackdump() { stackdump("Stack dump:"); }
  
  public static void stackdump(String paramString) { (new StackTrace()).dump(out, paramString); }
  
  public static void caller(int paramInt) {
    String str = null;
    try {
      str = (new StackTrace()).location(paramInt).caller();
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
    out.println("caller(" + paramInt + ") => " + str);
  }
  
  public static void begin(String paramString) {
    out.print(paramString + " ... ");
    out.flush();
  }
  
  public static void ok() { out.println("ok."); }
  
  public static DebugCategory getCategory(String paramString) {
    DebugCategory debugCategory = (DebugCategory)categories.get(paramString);
    if (debugCategory != null)
      return debugCategory; 
    debugCategory = new DebugCategory(paramString);
    categories.put(paramString, debugCategory);
    String str = null;
    try {
      if (System.getProperty(paramString) != null)
        debugCategory.setEnabled(true); 
      str = System.getProperty("weblogic.Debug");
    } catch (Exception exception) {}
    if (str != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(str, ",");
      while (stringTokenizer.hasMoreTokens()) {
        try {
          String str1 = stringTokenizer.nextToken().trim();
          int i = str1.indexOf("=");
          if (i != -1)
            str1 = str1.substring(0, i).trim(); 
          if (str1.equals(paramString) && 
            !debugCategory.isEnabled())
            debugCategory.setEnabled(true); 
        } catch (NoSuchElementException noSuchElementException) {
        
        } catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
      } 
    } 
    return debugCategory;
  }
  
  public static void attributeChangeNotification(String paramString, Object paramObject1, Object paramObject2) {
    DebugCategory debugCategory = getCategory(paramString);
    if (paramObject2 != null && 
      paramObject2 instanceof Boolean)
      debugCategory.setEnabled(((Boolean)paramObject2).booleanValue()); 
  }
  
  static final class Debug {}
  
  static final class Debug {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\Debug.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */