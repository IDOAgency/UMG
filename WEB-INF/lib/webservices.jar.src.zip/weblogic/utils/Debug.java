/*     */ package weblogic.utils;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Debug
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*  20 */   private static final Logger LOGGER = Logger.getLogger("weblogic.utils.Debug");
/*     */ 
/*     */   
/*  23 */   private static final PrintStream out = System.out;
/*     */ 
/*     */   
/*     */   public static boolean verboseMethods = false;
/*     */ 
/*     */   
/*     */   public static boolean showLineNumbers = false;
/*     */ 
/*     */   
/*     */   public static boolean addTimeStamp = false;
/*     */ 
/*     */   
/*     */   private static final Hashtable categories;
/*     */ 
/*     */ 
/*     */   
/*     */   static 
/*     */   {
/*     */     try {
/*  42 */       verboseMethods = Boolean.getBoolean("debug.methodNames");
/*  43 */       showLineNumbers = Boolean.getBoolean("debug.lineNumbers");
/*  44 */       addTimeStamp = Boolean.getBoolean("debug.addTimeStamp");
/*  45 */     } catch (SecurityException securityException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     categories = new Hashtable(); } public static void assertion(boolean paramBoolean) {
/*     */     if (!paramBoolean)
/*     */       throw new java.lang.AssertionError("Assertion violated"); 
/*     */   } public static void assertion(boolean paramBoolean, String paramString) {
/*     */     if (!paramBoolean)
/*     */       throw new java.lang.AssertionError(paramString); 
/*     */   } public static DebugCategory getCategory(String paramString) {
/* 159 */     DebugCategory debugCategory = (DebugCategory)categories.get(paramString);
/*     */     
/* 161 */     if (debugCategory != null) {
/* 162 */       return debugCategory;
/*     */     }
/*     */     
/* 165 */     debugCategory = new DebugCategory(paramString);
/* 166 */     categories.put(paramString, debugCategory);
/*     */ 
/*     */     
/* 169 */     String str = null;
/*     */ 
/*     */     
/*     */     try {
/* 173 */       if (System.getProperty(paramString) != null) debugCategory.setEnabled(true);
/*     */       
/* 175 */       str = System.getProperty("weblogic.Debug");
/* 176 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     if (str != null) {
/* 182 */       StringTokenizer stringTokenizer = new StringTokenizer(str, ",");
/* 183 */       while (stringTokenizer.hasMoreTokens()) {
/*     */         
/* 185 */         try { String str1 = stringTokenizer.nextToken().trim();
/*     */           
/* 187 */           int i = str1.indexOf("=");
/* 188 */           if (i != -1) {
/* 189 */             str1 = str1.substring(0, i).trim();
/*     */           }
/* 191 */           if (str1.equals(paramString) && 
/* 192 */             !debugCategory.isEnabled()) debugCategory.setEnabled(true);
/*     */            }
/*     */         
/* 195 */         catch (NoSuchElementException noSuchElementException) {  }
/* 196 */         catch (StringIndexOutOfBoundsException stringIndexOutOfBoundsException) {}
/*     */       } 
/*     */     } 
/*     */     
/* 200 */     return debugCategory;
/*     */   }
/*     */   public static void say(String paramString) { out.println((addTimeStamp ? ("" + new Date()) : "") + (new StackTrace()).location(0).tag(0) + paramString); }
/*     */   public static void timestamp(String paramString) { out.println("[" + System.currentTimeMillis() + "] " + paramString); }
/*     */   public static void here() { out.println("*** " + (new StackTrace()).location(0).dump() + " ***"); }
/*     */   public static void stackdump() { stackdump("Stack dump:"); }
/*     */   public static void stackdump(String paramString) { (new StackTrace()).dump(out, paramString); }
/*     */   public static void caller(int paramInt) {
/*     */     String str = null;
/*     */     try {
/*     */       str = (new StackTrace()).location(paramInt).caller();
/*     */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*     */     out.println("caller(" + paramInt + ") => " + str);
/*     */   }
/*     */   public static void begin(String paramString) {
/*     */     out.print(paramString + " ... ");
/*     */     out.flush();
/*     */   }
/*     */   
/*     */   public static void ok() { out.println("ok."); }
/*     */   
/*     */   public static void attributeChangeNotification(String paramString, Object paramObject1, Object paramObject2) {
/* 222 */     DebugCategory debugCategory = getCategory(paramString);
/* 223 */     if (paramObject2 != null && 
/* 224 */       paramObject2 instanceof Boolean)
/* 225 */       debugCategory.setEnabled(((Boolean)paramObject2).booleanValue()); 
/*     */   }
/*     */   
/*     */   static final class Debug {}
/*     */   
/*     */   static final class Debug {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\Debug.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */