package weblogic.utils;

public class UnsyncCircularQueue {
  private static final int DEFAULT_CAPACITY = 256;
  
  private static final int DEFAULT_MAX_CAPACITY = 65536;
  
  public static final int MAX_CAPACITY = 1073741824;
  
  private int size = 0;
  
  private int producerIndex = 0;
  
  private int consumerIndex = 0;
  
  private int capacity = 1;
  
  private int maxCapacity = 1;
  
  private int bitmask;
  
  private Object[] q;
  
  public UnsyncCircularQueue() { this(256); }
  
  public UnsyncCircularQueue(int paramInt) { this(paramInt, 65536); }
  
  public UnsyncCircularQueue(int paramInt1, int paramInt2) {
    if (paramInt1 > paramInt2)
      throw new IllegalArgumentException("Capacity greater than maximum"); 
    if (paramInt2 > 1073741824)
      throw new IllegalArgumentException("Capacity: '" + paramInt2 + "' greater than maximum: '" + 1073741824 + "'"); 
    for (this.capacity = 1; this.capacity < paramInt1; this.capacity <<= 1);
    for (this.maxCapacity = 1; this.maxCapacity < paramInt2; this.maxCapacity <<= 1);
    this.bitmask = this.capacity - 1;
    this.q = new Object[this.capacity];
  }
  
  private void expandQueue() {
    if (this.capacity == this.maxCapacity)
      throw new FullQueueException(this.maxCapacity, null); 
    int i = this.capacity;
    Object[] arrayOfObject = this.q;
    this.capacity += this.capacity;
    this.bitmask = this.capacity - 1;
    this.q = new Object[this.capacity];
    System.arraycopy(arrayOfObject, this.consumerIndex, this.q, 0, i - this.consumerIndex);
    if (this.consumerIndex != 0)
      System.arraycopy(arrayOfObject, 0, this.q, i - this.consumerIndex, this.consumerIndex); 
    this.consumerIndex = 0;
    this.producerIndex = this.size;
  }
  
  public final void put(Object paramObject) {
    if (this.size == this.capacity)
      expandQueue(); 
    this.size++;
    this.q[this.producerIndex] = paramObject;
    this.producerIndex = this.producerIndex + 1 & this.bitmask;
  }
  
  public final Object get() {
    if (this.size == 0)
      return null; 
    this.size--;
    Object object = this.q[this.consumerIndex];
    this.q[this.consumerIndex] = null;
    this.consumerIndex = this.consumerIndex + 1 & this.bitmask;
    return object;
  }
  
  public boolean empty() { return (this.size == 0); }
  
  public int size() { return this.size; }
  
  public int capacity() { return this.capacity; }
  
  public Object peek() {
    if (this.size == 0)
      return null; 
    return this.q[this.consumerIndex];
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer(super.toString() + " - capacity: '" + capacity() + "' size: '" + size() + "'");
    if (this.size > 0) {
      stringBuffer.append(" elements:");
      for (int i = 0; i < this.size; i++) {
        stringBuffer.append('\n');
        stringBuffer.append('\t');
        stringBuffer.append(this.q[this.consumerIndex + i & this.bitmask].toString());
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static class FullQueueException extends RuntimeException {
    private static final long serialVersionUID = 273708857498202064L;
    
    int capacity;
    
    private FullQueueException(int param1Int) { this.capacity = param1Int; }
    
    public String getMessage() { return "Queue exceed maximum capacity of: '" + this.capacity + "' elements"; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\UnsyncCircularQueue.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */