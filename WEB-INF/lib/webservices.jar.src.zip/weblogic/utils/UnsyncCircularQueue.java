/*     */ package weblogic.utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsyncCircularQueue
/*     */ {
/*     */   private static final int DEFAULT_CAPACITY = 256;
/*     */   private static final int DEFAULT_MAX_CAPACITY = 65536;
/*     */   public static final int MAX_CAPACITY = 1073741824;
/*  23 */   private int size = 0;
/*  24 */   private int producerIndex = 0;
/*  25 */   private int consumerIndex = 0;
/*  26 */   private int capacity = 1;
/*  27 */   private int maxCapacity = 1;
/*     */ 
/*     */   
/*     */   private int bitmask;
/*     */   
/*     */   private Object[] q;
/*     */ 
/*     */   
/*  35 */   public UnsyncCircularQueue() { this(256); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public UnsyncCircularQueue(int paramInt) { this(paramInt, 65536); }
/*     */ 
/*     */   
/*     */   public UnsyncCircularQueue(int paramInt1, int paramInt2) {
/*  49 */     if (paramInt1 > paramInt2) {
/*  50 */       throw new IllegalArgumentException("Capacity greater than maximum");
/*     */     }
/*     */     
/*  53 */     if (paramInt2 > 1073741824) {
/*  54 */       throw new IllegalArgumentException("Capacity: '" + paramInt2 + "' greater than maximum: '" + 1073741824 + "'");
/*     */     }
/*     */ 
/*     */     
/*  58 */     for (this.capacity = 1; this.capacity < paramInt1; this.capacity <<= 1);
/*  59 */     for (this.maxCapacity = 1; this.maxCapacity < paramInt2; this.maxCapacity <<= 1);
/*     */     
/*  61 */     this.bitmask = this.capacity - 1;
/*  62 */     this.q = new Object[this.capacity];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void expandQueue() {
/*  71 */     if (this.capacity == this.maxCapacity) {
/*  72 */       throw new FullQueueException(this.maxCapacity, null);
/*     */     }
/*     */     
/*  75 */     int i = this.capacity;
/*  76 */     Object[] arrayOfObject = this.q;
/*     */     
/*  78 */     this.capacity += this.capacity;
/*  79 */     this.bitmask = this.capacity - 1;
/*  80 */     this.q = new Object[this.capacity];
/*     */     
/*  82 */     System.arraycopy(arrayOfObject, this.consumerIndex, this.q, 0, i - this.consumerIndex);
/*     */     
/*  84 */     if (this.consumerIndex != 0) {
/*  85 */       System.arraycopy(arrayOfObject, 0, this.q, i - this.consumerIndex, this.consumerIndex);
/*     */     }
/*     */     
/*  88 */     this.consumerIndex = 0;
/*  89 */     this.producerIndex = this.size;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void put(Object paramObject) {
/*  94 */     if (this.size == this.capacity) expandQueue();
/*     */     
/*  96 */     this.size++;
/*  97 */     this.q[this.producerIndex] = paramObject;
/*     */     
/*  99 */     this.producerIndex = this.producerIndex + 1 & this.bitmask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object get() {
/* 106 */     if (this.size == 0) return null;
/*     */     
/* 108 */     this.size--;
/* 109 */     Object object = this.q[this.consumerIndex];
/* 110 */     this.q[this.consumerIndex] = null;
/*     */     
/* 112 */     this.consumerIndex = this.consumerIndex + 1 & this.bitmask;
/*     */     
/* 114 */     return object;
/*     */   }
/*     */   
/* 117 */   public boolean empty() { return (this.size == 0); }
/*     */   
/* 119 */   public int size() { return this.size; }
/*     */   
/* 121 */   public int capacity() { return this.capacity; }
/*     */   
/*     */   public Object peek() {
/* 124 */     if (this.size == 0) return null; 
/* 125 */     return this.q[this.consumerIndex];
/*     */   }
/*     */   
/*     */   public String toString() {
/* 129 */     StringBuffer stringBuffer = new StringBuffer(super.toString() + " - capacity: '" + capacity() + "' size: '" + size() + "'");
/*     */ 
/*     */     
/* 132 */     if (this.size > 0) {
/* 133 */       stringBuffer.append(" elements:");
/* 134 */       for (int i = 0; i < this.size; i++) {
/* 135 */         stringBuffer.append('\n');
/* 136 */         stringBuffer.append('\t');
/* 137 */         stringBuffer.append(this.q[this.consumerIndex + i & this.bitmask].toString());
/*     */       } 
/*     */     } 
/*     */     
/* 141 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public static class FullQueueException extends RuntimeException {
/*     */     private static final long serialVersionUID = 273708857498202064L;
/*     */     int capacity;
/*     */     
/* 148 */     private FullQueueException(int param1Int) { this.capacity = param1Int; }
/*     */ 
/*     */     
/* 151 */     public String getMessage() { return "Queue exceed maximum capacity of: '" + this.capacity + "' elements"; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\UnsyncCircularQueue.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */