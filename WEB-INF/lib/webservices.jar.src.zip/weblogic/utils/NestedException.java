/*     */ package weblogic.utils;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NestedException
/*     */   extends Exception
/*     */   implements NestedThrowable
/*     */ {
/*     */   protected Throwable nested;
/*     */   private static final long serialVersionUID = -439506221202060860L;
/*     */   
/*     */   public NestedException() {}
/*     */   
/*  20 */   public NestedException(String paramString) { super(paramString); }
/*     */ 
/*     */   
/*     */   public NestedException(Throwable paramThrowable) {
/*  24 */     super(paramThrowable);
/*  25 */     this.nested = paramThrowable;
/*     */   }
/*     */ 
/*     */   
/*     */   public NestedException(String paramString, Throwable paramThrowable) {
/*  30 */     super(paramString, paramThrowable);
/*  31 */     this.nested = paramThrowable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   public Throwable getNestedException() { return getNested(); }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*  45 */     String str = super.getMessage();
/*  46 */     if (str == null && 
/*  47 */       this.nested != null)
/*  48 */       str = this.nested.getMessage(); 
/*  49 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public Throwable getNested() { return this.nested; }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public String superToString() { return super.toString(); }
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void superPrintStackTrace(PrintStream paramPrintStream) { super.printStackTrace(paramPrintStream); }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void superPrintStackTrace(PrintWriter paramPrintWriter) { super.printStackTrace(paramPrintWriter); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public String toString() { return NestedThrowable.Util.toString(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public void printStackTrace(PrintStream paramPrintStream) { NestedThrowable.Util.printStackTrace(this, paramPrintStream); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void printStackTrace(PrintWriter paramPrintWriter) { NestedThrowable.Util.printStackTrace(this, paramPrintWriter); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public void printStackTrace() { printStackTrace(System.err); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\NestedException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */