package weblogic.utils;

import java.io.PrintStream;
import java.io.PrintWriter;

public class NestedException extends Exception implements NestedThrowable {
  protected Throwable nested;
  
  private static final long serialVersionUID = -439506221202060860L;
  
  public NestedException() {}
  
  public NestedException(String paramString) { super(paramString); }
  
  public NestedException(Throwable paramThrowable) {
    super(paramThrowable);
    this.nested = paramThrowable;
  }
  
  public NestedException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
    this.nested = paramThrowable;
  }
  
  public Throwable getNestedException() { return getNested(); }
  
  public String getMessage() {
    String str = super.getMessage();
    if (str == null && 
      this.nested != null)
      str = this.nested.getMessage(); 
    return str;
  }
  
  public Throwable getNested() { return this.nested; }
  
  public String superToString() { return super.toString(); }
  
  public void superPrintStackTrace(PrintStream paramPrintStream) { super.printStackTrace(paramPrintStream); }
  
  public void superPrintStackTrace(PrintWriter paramPrintWriter) { super.printStackTrace(paramPrintWriter); }
  
  public String toString() { return NestedThrowable.Util.toString(this); }
  
  public void printStackTrace(PrintStream paramPrintStream) { NestedThrowable.Util.printStackTrace(this, paramPrintStream); }
  
  public void printStackTrace(PrintWriter paramPrintWriter) { NestedThrowable.Util.printStackTrace(this, paramPrintWriter); }
  
  public void printStackTrace() { printStackTrace(System.err); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\NestedException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */