package weblogic.utils;

import java.io.Serializable;

public final class UnsyncStringBuffer implements Serializable {
  private char[] value;
  
  private int count;
  
  private boolean shared;
  
  static final long serialVersionUID = 3388685877147921107L;
  
  public UnsyncStringBuffer() { this(16); }
  
  public UnsyncStringBuffer(int paramInt) {
    this.value = new char[paramInt];
    this.shared = false;
  }
  
  public UnsyncStringBuffer(String paramString) {
    this(paramString.length() + 16);
    append(paramString);
  }
  
  public int length() { return this.count; }
  
  public int capacity() { return this.value.length; }
  
  private final void copyWhenShared() {
    if (this.shared) {
      char[] arrayOfChar = new char[this.value.length];
      System.arraycopy(this.value, 0, arrayOfChar, 0, this.count);
      this.value = arrayOfChar;
      this.shared = false;
    } 
  }
  
  public void ensureCapacity(int paramInt) {
    int i = this.value.length;
    if (paramInt > i) {
      int j = (i + 1) * 2;
      if (paramInt > j)
        j = paramInt; 
      char[] arrayOfChar = new char[j];
      System.arraycopy(this.value, 0, arrayOfChar, 0, this.count);
      this.value = arrayOfChar;
      this.shared = false;
    } 
  }
  
  public void setLength(int paramInt) {
    if (paramInt < 0)
      throw new StringIndexOutOfBoundsException(paramInt); 
    ensureCapacity(paramInt);
    if (this.count < paramInt) {
      copyWhenShared();
      for (; this.count < paramInt; this.count++)
        this.value[this.count] = Character.MIN_VALUE; 
    } 
    this.count = paramInt;
  }
  
  public char charAt(int paramInt) {
    if (paramInt < 0 || paramInt >= this.count)
      throw new StringIndexOutOfBoundsException(paramInt); 
    return this.value[paramInt];
  }
  
  public void getChars(int paramInt1, int paramInt2, char[] paramArrayOfChar, int paramInt3) {
    if (paramInt1 < 0 || paramInt1 >= this.count)
      throw new StringIndexOutOfBoundsException(paramInt1); 
    if (paramInt2 < 0 || paramInt2 > this.count)
      throw new StringIndexOutOfBoundsException(paramInt2); 
    if (paramInt1 < paramInt2)
      System.arraycopy(this.value, paramInt1, paramArrayOfChar, paramInt3, paramInt2 - paramInt1); 
  }
  
  public void setCharAt(int paramInt, char paramChar) {
    if (paramInt < 0 || paramInt >= this.count)
      throw new StringIndexOutOfBoundsException(paramInt); 
    copyWhenShared();
    this.value[paramInt] = paramChar;
  }
  
  public UnsyncStringBuffer append(Object paramObject) { return append(String.valueOf(paramObject)); }
  
  public UnsyncStringBuffer append(String paramString) {
    if (paramString == null)
      paramString = String.valueOf(paramString); 
    int i = paramString.length();
    ensureCapacity(this.count + i);
    copyWhenShared();
    paramString.getChars(0, i, this.value, this.count);
    this.count += i;
    return this;
  }
  
  public UnsyncStringBuffer append(char[] paramArrayOfChar) {
    int i = paramArrayOfChar.length;
    ensureCapacity(this.count + i);
    copyWhenShared();
    System.arraycopy(paramArrayOfChar, 0, this.value, this.count, i);
    this.count += i;
    return this;
  }
  
  public UnsyncStringBuffer append(char[] paramArrayOfChar, int paramInt1, int paramInt2) {
    ensureCapacity(this.count + paramInt2);
    copyWhenShared();
    System.arraycopy(paramArrayOfChar, paramInt1, this.value, this.count, paramInt2);
    this.count += paramInt2;
    return this;
  }
  
  public UnsyncStringBuffer append(boolean paramBoolean) { return append(String.valueOf(paramBoolean)); }
  
  public UnsyncStringBuffer append(char paramChar) {
    ensureCapacity(this.count + 1);
    copyWhenShared();
    this.value[this.count++] = paramChar;
    return this;
  }
  
  public UnsyncStringBuffer append(int paramInt) { return append(String.valueOf(paramInt)); }
  
  public UnsyncStringBuffer append(long paramLong) { return append(String.valueOf(paramLong)); }
  
  public UnsyncStringBuffer append(float paramFloat) { return append(String.valueOf(paramFloat)); }
  
  public UnsyncStringBuffer append(double paramDouble) { return append(String.valueOf(paramDouble)); }
  
  public UnsyncStringBuffer insert(int paramInt, Object paramObject) { return insert(paramInt, String.valueOf(paramObject)); }
  
  public UnsyncStringBuffer insert(int paramInt, String paramString) {
    if (paramInt < 0 || paramInt > this.count)
      throw new StringIndexOutOfBoundsException(); 
    int i = paramString.length();
    ensureCapacity(this.count + i);
    copyWhenShared();
    System.arraycopy(this.value, paramInt, this.value, paramInt + i, this.count - paramInt);
    paramString.getChars(0, i, this.value, paramInt);
    this.count += i;
    return this;
  }
  
  public UnsyncStringBuffer insert(int paramInt, char[] paramArrayOfChar) {
    if (paramInt < 0 || paramInt > this.count)
      throw new StringIndexOutOfBoundsException(); 
    int i = paramArrayOfChar.length;
    ensureCapacity(this.count + i);
    copyWhenShared();
    System.arraycopy(this.value, paramInt, this.value, paramInt + i, this.count - paramInt);
    System.arraycopy(paramArrayOfChar, 0, this.value, paramInt, i);
    this.count += i;
    return this;
  }
  
  public UnsyncStringBuffer insert(int paramInt, boolean paramBoolean) { return insert(paramInt, String.valueOf(paramBoolean)); }
  
  public UnsyncStringBuffer insert(int paramInt, char paramChar) {
    ensureCapacity(this.count + 1);
    copyWhenShared();
    System.arraycopy(this.value, paramInt, this.value, paramInt + 1, this.count - paramInt);
    this.value[paramInt] = paramChar;
    this.count++;
    return this;
  }
  
  public UnsyncStringBuffer insert(int paramInt1, int paramInt2) { return insert(paramInt1, String.valueOf(paramInt2)); }
  
  public UnsyncStringBuffer insert(int paramInt, long paramLong) { return insert(paramInt, String.valueOf(paramLong)); }
  
  public UnsyncStringBuffer insert(int paramInt, float paramFloat) { return insert(paramInt, String.valueOf(paramFloat)); }
  
  public UnsyncStringBuffer insert(int paramInt, double paramDouble) { return insert(paramInt, String.valueOf(paramDouble)); }
  
  public UnsyncStringBuffer reverse() {
    copyWhenShared();
    int i = this.count - 1;
    for (int j = i - 1 >> 1; j >= 0; j--) {
      char c = this.value[j];
      this.value[j] = this.value[i - j];
      this.value[i - j] = c;
    } 
    return this;
  }
  
  public String toString() {
    this.shared = true;
    return new String(this.value, 0, this.count);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\UnsyncStringBuffer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */