/*     */ package weblogic.utils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UnsyncStringBuffer
/*     */   implements Serializable
/*     */ {
/*     */   private char[] value;
/*     */   private int count;
/*     */   private boolean shared;
/*     */   static final long serialVersionUID = 3388685877147921107L;
/*     */   
/*  22 */   public UnsyncStringBuffer() { this(16); }
/*     */ 
/*     */   
/*     */   public UnsyncStringBuffer(int paramInt) {
/*  26 */     this.value = new char[paramInt];
/*  27 */     this.shared = false;
/*     */   }
/*     */   
/*     */   public UnsyncStringBuffer(String paramString) {
/*  31 */     this(paramString.length() + 16);
/*  32 */     append(paramString);
/*     */   }
/*     */ 
/*     */   
/*  36 */   public int length() { return this.count; }
/*     */ 
/*     */ 
/*     */   
/*  40 */   public int capacity() { return this.value.length; }
/*     */ 
/*     */   
/*     */   private final void copyWhenShared() {
/*  44 */     if (this.shared) {
/*  45 */       char[] arrayOfChar = new char[this.value.length];
/*  46 */       System.arraycopy(this.value, 0, arrayOfChar, 0, this.count);
/*  47 */       this.value = arrayOfChar;
/*  48 */       this.shared = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void ensureCapacity(int paramInt) {
/*  53 */     int i = this.value.length;
/*     */     
/*  55 */     if (paramInt > i) {
/*  56 */       int j = (i + 1) * 2;
/*  57 */       if (paramInt > j) {
/*  58 */         j = paramInt;
/*     */       }
/*     */       
/*  61 */       char[] arrayOfChar = new char[j];
/*  62 */       System.arraycopy(this.value, 0, arrayOfChar, 0, this.count);
/*  63 */       this.value = arrayOfChar;
/*  64 */       this.shared = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setLength(int paramInt) {
/*  69 */     if (paramInt < 0) {
/*  70 */       throw new StringIndexOutOfBoundsException(paramInt);
/*     */     }
/*  72 */     ensureCapacity(paramInt);
/*     */     
/*  74 */     if (this.count < paramInt) {
/*  75 */       copyWhenShared();
/*  76 */       for (; this.count < paramInt; this.count++) {
/*  77 */         this.value[this.count] = Character.MIN_VALUE;
/*     */       }
/*     */     } 
/*  80 */     this.count = paramInt;
/*     */   }
/*     */   
/*     */   public char charAt(int paramInt) {
/*  84 */     if (paramInt < 0 || paramInt >= this.count) {
/*  85 */       throw new StringIndexOutOfBoundsException(paramInt);
/*     */     }
/*  87 */     return this.value[paramInt];
/*     */   }
/*     */   
/*     */   public void getChars(int paramInt1, int paramInt2, char[] paramArrayOfChar, int paramInt3) {
/*  91 */     if (paramInt1 < 0 || paramInt1 >= this.count) {
/*  92 */       throw new StringIndexOutOfBoundsException(paramInt1);
/*     */     }
/*  94 */     if (paramInt2 < 0 || paramInt2 > this.count) {
/*  95 */       throw new StringIndexOutOfBoundsException(paramInt2);
/*     */     }
/*  97 */     if (paramInt1 < paramInt2) {
/*  98 */       System.arraycopy(this.value, paramInt1, paramArrayOfChar, paramInt3, paramInt2 - paramInt1);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCharAt(int paramInt, char paramChar) {
/* 103 */     if (paramInt < 0 || paramInt >= this.count) {
/* 104 */       throw new StringIndexOutOfBoundsException(paramInt);
/*     */     }
/* 106 */     copyWhenShared();
/* 107 */     this.value[paramInt] = paramChar;
/*     */   }
/*     */ 
/*     */   
/* 111 */   public UnsyncStringBuffer append(Object paramObject) { return append(String.valueOf(paramObject)); }
/*     */ 
/*     */   
/*     */   public UnsyncStringBuffer append(String paramString) {
/* 115 */     if (paramString == null) {
/* 116 */       paramString = String.valueOf(paramString);
/*     */     }
/*     */     
/* 119 */     int i = paramString.length();
/* 120 */     ensureCapacity(this.count + i);
/* 121 */     copyWhenShared();
/* 122 */     paramString.getChars(0, i, this.value, this.count);
/* 123 */     this.count += i;
/* 124 */     return this;
/*     */   }
/*     */   
/*     */   public UnsyncStringBuffer append(char[] paramArrayOfChar) {
/* 128 */     int i = paramArrayOfChar.length;
/* 129 */     ensureCapacity(this.count + i);
/* 130 */     copyWhenShared();
/* 131 */     System.arraycopy(paramArrayOfChar, 0, this.value, this.count, i);
/* 132 */     this.count += i;
/* 133 */     return this;
/*     */   }
/*     */   
/*     */   public UnsyncStringBuffer append(char[] paramArrayOfChar, int paramInt1, int paramInt2) {
/* 137 */     ensureCapacity(this.count + paramInt2);
/* 138 */     copyWhenShared();
/* 139 */     System.arraycopy(paramArrayOfChar, paramInt1, this.value, this.count, paramInt2);
/* 140 */     this.count += paramInt2;
/* 141 */     return this;
/*     */   }
/*     */ 
/*     */   
/* 145 */   public UnsyncStringBuffer append(boolean paramBoolean) { return append(String.valueOf(paramBoolean)); }
/*     */ 
/*     */   
/*     */   public UnsyncStringBuffer append(char paramChar) {
/* 149 */     ensureCapacity(this.count + 1);
/* 150 */     copyWhenShared();
/* 151 */     this.value[this.count++] = paramChar;
/* 152 */     return this;
/*     */   }
/*     */ 
/*     */   
/* 156 */   public UnsyncStringBuffer append(int paramInt) { return append(String.valueOf(paramInt)); }
/*     */ 
/*     */ 
/*     */   
/* 160 */   public UnsyncStringBuffer append(long paramLong) { return append(String.valueOf(paramLong)); }
/*     */ 
/*     */ 
/*     */   
/* 164 */   public UnsyncStringBuffer append(float paramFloat) { return append(String.valueOf(paramFloat)); }
/*     */ 
/*     */ 
/*     */   
/* 168 */   public UnsyncStringBuffer append(double paramDouble) { return append(String.valueOf(paramDouble)); }
/*     */ 
/*     */ 
/*     */   
/* 172 */   public UnsyncStringBuffer insert(int paramInt, Object paramObject) { return insert(paramInt, String.valueOf(paramObject)); }
/*     */ 
/*     */   
/*     */   public UnsyncStringBuffer insert(int paramInt, String paramString) {
/* 176 */     if (paramInt < 0 || paramInt > this.count) {
/* 177 */       throw new StringIndexOutOfBoundsException();
/*     */     }
/* 179 */     int i = paramString.length();
/* 180 */     ensureCapacity(this.count + i);
/* 181 */     copyWhenShared();
/* 182 */     System.arraycopy(this.value, paramInt, this.value, paramInt + i, this.count - paramInt);
/* 183 */     paramString.getChars(0, i, this.value, paramInt);
/* 184 */     this.count += i;
/* 185 */     return this;
/*     */   }
/*     */   
/*     */   public UnsyncStringBuffer insert(int paramInt, char[] paramArrayOfChar) {
/* 189 */     if (paramInt < 0 || paramInt > this.count) {
/* 190 */       throw new StringIndexOutOfBoundsException();
/*     */     }
/* 192 */     int i = paramArrayOfChar.length;
/* 193 */     ensureCapacity(this.count + i);
/* 194 */     copyWhenShared();
/* 195 */     System.arraycopy(this.value, paramInt, this.value, paramInt + i, this.count - paramInt);
/* 196 */     System.arraycopy(paramArrayOfChar, 0, this.value, paramInt, i);
/* 197 */     this.count += i;
/* 198 */     return this;
/*     */   }
/*     */ 
/*     */   
/* 202 */   public UnsyncStringBuffer insert(int paramInt, boolean paramBoolean) { return insert(paramInt, String.valueOf(paramBoolean)); }
/*     */ 
/*     */   
/*     */   public UnsyncStringBuffer insert(int paramInt, char paramChar) {
/* 206 */     ensureCapacity(this.count + 1);
/* 207 */     copyWhenShared();
/* 208 */     System.arraycopy(this.value, paramInt, this.value, paramInt + 1, this.count - paramInt);
/* 209 */     this.value[paramInt] = paramChar;
/* 210 */     this.count++;
/* 211 */     return this;
/*     */   }
/*     */ 
/*     */   
/* 215 */   public UnsyncStringBuffer insert(int paramInt1, int paramInt2) { return insert(paramInt1, String.valueOf(paramInt2)); }
/*     */ 
/*     */ 
/*     */   
/* 219 */   public UnsyncStringBuffer insert(int paramInt, long paramLong) { return insert(paramInt, String.valueOf(paramLong)); }
/*     */ 
/*     */ 
/*     */   
/* 223 */   public UnsyncStringBuffer insert(int paramInt, float paramFloat) { return insert(paramInt, String.valueOf(paramFloat)); }
/*     */ 
/*     */ 
/*     */   
/* 227 */   public UnsyncStringBuffer insert(int paramInt, double paramDouble) { return insert(paramInt, String.valueOf(paramDouble)); }
/*     */ 
/*     */   
/*     */   public UnsyncStringBuffer reverse() {
/* 231 */     copyWhenShared();
/* 232 */     int i = this.count - 1;
/* 233 */     for (int j = i - 1 >> 1; j >= 0; j--) {
/* 234 */       char c = this.value[j];
/* 235 */       this.value[j] = this.value[i - j];
/* 236 */       this.value[i - j] = c;
/*     */     } 
/* 238 */     return this;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 242 */     this.shared = true;
/* 243 */     return new String(this.value, 0, this.count);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\UnsyncStringBuffer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */