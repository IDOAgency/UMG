package weblogic.utils;

public interface PlatformConstants {
  public static final String EOL = System.getProperty("line.separator");
  
  public static final String FILE_SEP = System.getProperty("file.separator");
  
  public static final String PATH_SEP = System.getProperty("path.separator");
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\PlatformConstants.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */