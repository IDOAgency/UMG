/*    */ package weblogic.utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface PlatformConstants
/*    */ {
/* 16 */   public static final String EOL = System.getProperty("line.separator");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 22 */   public static final String FILE_SEP = System.getProperty("file.separator");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   public static final String PATH_SEP = System.getProperty("path.separator");
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\PlatformConstants.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */