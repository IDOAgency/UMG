package weblogic.utils;

public final class DebugCategory {
  private final String name;
  
  private boolean enabled;
  
  public DebugCategory(String paramString) {
    this.enabled = false;
    this.name = paramString;
  }
  
  public String getName() { return this.name; }
  
  public boolean isEnabled() { return this.enabled; }
  
  public void setEnabled(boolean paramBoolean) { this.enabled = paramBoolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\DebugCategory.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */