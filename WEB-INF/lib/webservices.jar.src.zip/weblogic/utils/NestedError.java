package weblogic.utils;

import java.io.PrintStream;
import java.io.PrintWriter;

public class NestedError extends Error implements NestedThrowable {
  private Throwable nested;
  
  public NestedError() {}
  
  public NestedError(String paramString) { super(paramString); }
  
  public NestedError(Throwable paramThrowable) {
    super(paramThrowable);
    this.nested = paramThrowable;
  }
  
  public NestedError(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
    this.nested = paramThrowable;
  }
  
  public Throwable getNestedError() { return getNested(); }
  
  public Throwable getNested() { return this.nested; }
  
  public String superToString() { return super.toString(); }
  
  public void superPrintStackTrace(PrintStream paramPrintStream) { super.printStackTrace(paramPrintStream); }
  
  public void superPrintStackTrace(PrintWriter paramPrintWriter) { super.printStackTrace(paramPrintWriter); }
  
  public String toString() { return NestedThrowable.Util.toString(this); }
  
  public void printStackTrace(PrintStream paramPrintStream) { NestedThrowable.Util.printStackTrace(this, paramPrintStream); }
  
  public void printStackTrace(PrintWriter paramPrintWriter) { NestedThrowable.Util.printStackTrace(this, paramPrintWriter); }
  
  public void printStackTrace() { printStackTrace(System.err); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\weblogi\\utils\NestedError.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.0.7
 */