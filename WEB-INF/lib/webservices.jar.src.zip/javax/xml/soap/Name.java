package javax.xml.soap;

public interface Name {
  String getLocalName();
  
  String getQualifiedName();
  
  String getPrefix();
  
  String getURI();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\Name.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */