package javax.xml.soap;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import javax.activation.DataHandler;

public abstract class SOAPMessage {
  public static final String CHARACTER_SET_ENCODING = "javax.xml.soap.character-set-encoding";
  
  public static final String WRITE_XML_DECLARATION = "javax.xml.soap.write-xml-declaration";
  
  public abstract void setContentDescription(String paramString);
  
  public abstract String getContentDescription();
  
  public abstract SOAPPart getSOAPPart();
  
  public abstract SOAPBody getSOAPBody() throws SOAPException;
  
  public abstract SOAPHeader getSOAPHeader() throws SOAPException;
  
  public abstract void removeAllAttachments();
  
  public abstract int countAttachments();
  
  public abstract Iterator getAttachments();
  
  public abstract Iterator getAttachments(MimeHeaders paramMimeHeaders);
  
  public abstract void addAttachmentPart(AttachmentPart paramAttachmentPart);
  
  public abstract AttachmentPart createAttachmentPart();
  
  public AttachmentPart createAttachmentPart(DataHandler paramDataHandler) {
    AttachmentPart attachmentPart = createAttachmentPart();
    attachmentPart.setDataHandler(paramDataHandler);
    return attachmentPart;
  }
  
  public abstract MimeHeaders getMimeHeaders();
  
  public AttachmentPart createAttachmentPart(Object paramObject, String paramString) {
    AttachmentPart attachmentPart = createAttachmentPart();
    attachmentPart.setContent(paramObject, paramString);
    return attachmentPart;
  }
  
  public abstract void saveChanges();
  
  public abstract boolean saveRequired();
  
  public abstract void writeTo(OutputStream paramOutputStream) throws SOAPException, IOException;
  
  public abstract void setProperty(String paramString, Object paramObject) throws SOAPException;
  
  public abstract Object getProperty(String paramString) throws SOAPException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\SOAPMessage.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */