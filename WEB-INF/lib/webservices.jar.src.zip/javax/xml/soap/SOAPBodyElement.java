package javax.xml.soap;

public interface SOAPBodyElement extends SOAPElement {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\SOAPBodyElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */