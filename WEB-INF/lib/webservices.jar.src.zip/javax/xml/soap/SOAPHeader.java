package javax.xml.soap;

import java.util.Iterator;

public interface SOAPHeader extends SOAPElement {
  SOAPHeaderElement addHeaderElement(Name paramName) throws SOAPException;
  
  Iterator examineMustUnderstandHeaderElements(String paramString);
  
  Iterator examineHeaderElements(String paramString);
  
  Iterator extractHeaderElements(String paramString);
  
  Iterator examineAllHeaderElements();
  
  Iterator extractAllHeaderElements();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\SOAPHeader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */