package javax.xml.soap;

import java.util.Locale;

public interface SOAPFault extends SOAPBodyElement {
  void setFaultCode(Name paramName) throws SOAPException;
  
  void setFaultCode(String paramString) throws SOAPException;
  
  Name getFaultCodeAsName();
  
  String getFaultCode();
  
  void setFaultActor(String paramString) throws SOAPException;
  
  String getFaultActor();
  
  void setFaultString(String paramString) throws SOAPException;
  
  void setFaultString(String paramString, Locale paramLocale) throws SOAPException;
  
  String getFaultString();
  
  Locale getFaultStringLocale();
  
  Detail getDetail();
  
  Detail addDetail();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\SOAPFault.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */