package javax.xml.soap;

public abstract class SOAPConnection {
  public abstract SOAPMessage call(SOAPMessage paramSOAPMessage, Object paramObject) throws SOAPException;
  
  public abstract void close();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\SOAPConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */