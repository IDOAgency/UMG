package javax.xml.soap;

import java.util.Iterator;

public interface Detail extends SOAPFaultElement {
  DetailEntry addDetailEntry(Name paramName) throws SOAPException;
  
  Iterator getDetailEntries();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\Detail.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */