package javax.xml.soap;

import java.util.Iterator;
import javax.activation.DataHandler;

public abstract class AttachmentPart {
  public abstract int getSize() throws SOAPException;
  
  public abstract void clearContent();
  
  public abstract Object getContent() throws SOAPException;
  
  public abstract void setContent(Object paramObject, String paramString);
  
  public abstract DataHandler getDataHandler() throws SOAPException;
  
  public abstract void setDataHandler(DataHandler paramDataHandler);
  
  public String getContentId() {
    String[] arrayOfString = getMimeHeader("Content-Id");
    return (arrayOfString != null && arrayOfString.length > 0) ? arrayOfString[0] : null;
  }
  
  public String getContentLocation() {
    String[] arrayOfString = getMimeHeader("Content-Location");
    return (arrayOfString != null && arrayOfString.length > 0) ? arrayOfString[0] : null;
  }
  
  public String getContentType() {
    String[] arrayOfString = getMimeHeader("Content-Type");
    return (arrayOfString != null && arrayOfString.length > 0) ? arrayOfString[0] : null;
  }
  
  public void setContentId(String paramString) { setMimeHeader("Content-Id", paramString); }
  
  public void setContentLocation(String paramString) { setMimeHeader("Content-Location", paramString); }
  
  public void setContentType(String paramString) { setMimeHeader("Content-Type", paramString); }
  
  public abstract void removeMimeHeader(String paramString);
  
  public abstract void removeAllMimeHeaders();
  
  public abstract String[] getMimeHeader(String paramString);
  
  public abstract void setMimeHeader(String paramString1, String paramString2);
  
  public abstract void addMimeHeader(String paramString1, String paramString2);
  
  public abstract Iterator getAllMimeHeaders();
  
  public abstract Iterator getMatchingMimeHeaders(String[] paramArrayOfString);
  
  public abstract Iterator getNonMatchingMimeHeaders(String[] paramArrayOfString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\AttachmentPart.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */