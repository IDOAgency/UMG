package javax.xml.soap;

public class MimeHeader {
  private String name;
  
  private String value;
  
  public MimeHeader(String paramString1, String paramString2) {
    this.name = paramString1;
    this.value = paramString2;
  }
  
  public String getName() { return this.name; }
  
  public String getValue() { return this.value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\MimeHeader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */