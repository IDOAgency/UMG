package javax.xml.soap;

import org.w3c.dom.Node;

public interface Node extends Node {
  String getValue();
  
  void setValue(String paramString);
  
  void setParentElement(SOAPElement paramSOAPElement) throws SOAPException;
  
  SOAPElement getParentElement();
  
  void detachNode();
  
  void recycleNode();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\Node.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */