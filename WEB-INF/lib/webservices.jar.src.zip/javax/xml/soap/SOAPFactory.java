package javax.xml.soap;

public abstract class SOAPFactory {
  private static final String SOAP_FACTORY_PROPERTY = "javax.xml.soap.SOAPFactory";
  
  private static final String DEFAULT_SOAP_FACTORY = "com.sun.xml.messaging.saaj.soap.ver1_1.SOAPFactory1_1Impl";
  
  public abstract SOAPElement createElement(Name paramName) throws SOAPException;
  
  public abstract SOAPElement createElement(String paramString) throws SOAPException;
  
  public abstract SOAPElement createElement(String paramString1, String paramString2, String paramString3) throws SOAPException;
  
  public abstract Detail createDetail() throws SOAPException;
  
  public abstract Name createName(String paramString1, String paramString2, String paramString3) throws SOAPException;
  
  public abstract Name createName(String paramString) throws SOAPException;
  
  public static SOAPFactory newInstance() throws SOAPException {
    try {
      return (SOAPFactory)FactoryFinder.find("javax.xml.soap.SOAPFactory", "com.sun.xml.messaging.saaj.soap.ver1_1.SOAPFactory1_1Impl");
    } catch (Exception exception) {
      throw new SOAPException("Unable to create SOAP Factory: " + exception.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\SOAPFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */