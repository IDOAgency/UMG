package javax.xml.soap;

import org.w3c.dom.Text;

public interface Text extends Node, Text {
  boolean isComment();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\soap\Text.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */