/*    */ package javax.xml.rpc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterMode
/*    */ {
/*    */   private final String mode;
/*    */   
/* 22 */   private ParameterMode(String mode) { this.mode = mode; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   public String toString() { return this.mode; }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public static final ParameterMode IN = new ParameterMode("IN");
/*    */ 
/*    */ 
/*    */   
/* 37 */   public static final ParameterMode OUT = new ParameterMode("OUT");
/*    */ 
/*    */ 
/*    */   
/* 41 */   public static final ParameterMode INOUT = new ParameterMode("INOUT");
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\ParameterMode.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */