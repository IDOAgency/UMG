package javax.xml.rpc;

public class ParameterMode {
  private final String mode;
  
  private ParameterMode(String mode) { this.mode = mode; }
  
  public String toString() { return this.mode; }
  
  public static final ParameterMode IN = new ParameterMode("IN");
  
  public static final ParameterMode OUT = new ParameterMode("OUT");
  
  public static final ParameterMode INOUT = new ParameterMode("INOUT");
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\ParameterMode.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */