package javax.xml.rpc;

public class ServiceException extends Exception {
  private Throwable cause;
  
  public ServiceException() { this.cause = null; }
  
  public ServiceException(String message) {
    super(message);
    this.cause = null;
  }
  
  public ServiceException(String message, Throwable cause) {
    super(message);
    this.cause = cause;
  }
  
  public ServiceException(Throwable cause) {
    super((cause == null) ? null : cause.toString());
    this.cause = cause;
  }
  
  public Throwable getLinkedCause() { return this.cause; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\ServiceException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */