package javax.xml.rpc.handler;

import java.util.Iterator;

public interface MessageContext {
  void setProperty(String paramString, Object paramObject);
  
  Object getProperty(String paramString);
  
  void removeProperty(String paramString);
  
  boolean containsProperty(String paramString);
  
  Iterator getPropertyNames();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\handler\MessageContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */