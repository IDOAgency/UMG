package javax.xml.rpc.handler;

import javax.xml.namespace.QName;

public interface Handler {
  boolean handleRequest(MessageContext paramMessageContext);
  
  boolean handleResponse(MessageContext paramMessageContext);
  
  boolean handleFault(MessageContext paramMessageContext);
  
  void init(HandlerInfo paramHandlerInfo);
  
  void destroy();
  
  QName[] getHeaders();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\handler\Handler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */