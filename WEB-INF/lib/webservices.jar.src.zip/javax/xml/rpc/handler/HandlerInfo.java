/*     */ package javax.xml.rpc.handler;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerInfo
/*     */   implements Serializable
/*     */ {
/*     */   private Class handlerClass;
/*     */   private Map config;
/*     */   private Vector headers;
/*     */   
/*     */   public HandlerInfo() {
/*  33 */     this.handlerClass = null;
/*  34 */     this.config = new HashMap();
/*  35 */     this.headers = new Vector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HandlerInfo(Class handlerClass, Map config, QName[] headers) {
/*  48 */     this.handlerClass = handlerClass;
/*  49 */     this.config = config;
/*  50 */     this.headers = new Vector();
/*  51 */     if (headers != null) {
/*  52 */       for (int i = 0; i < headers.length; i++) {
/*  53 */         this.headers.add(i, headers[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public void setHandlerClass(Class handlerClass) { this.handlerClass = handlerClass; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public Class getHandlerClass() { return this.handlerClass; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public void setHandlerConfig(Map config) { this.config = config; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public Map getHandlerConfig() { return this.config; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaders(QName[] headers) {
/*  99 */     this.headers.clear();
/* 100 */     if (headers != null) {
/* 101 */       for (int i = 0; i < headers.length; i++) {
/* 102 */         this.headers.add(i, headers[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName[] getHeaders() {
/* 114 */     if (this.headers.size() == 0) {
/* 115 */       return null;
/*     */     }
/* 117 */     QName[] qns = new QName[this.headers.size()];
/* 118 */     this.headers.copyInto(qns);
/* 119 */     return qns;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\handler\HandlerInfo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */