package javax.xml.rpc;

public class JAXRPCException extends RuntimeException {
  private Throwable cause;
  
  public JAXRPCException() { this.cause = null; }
  
  public JAXRPCException(String message) {
    super(message);
    this.cause = null;
  }
  
  public JAXRPCException(String message, Throwable cause) {
    super(message);
    this.cause = cause;
  }
  
  public JAXRPCException(Throwable cause) {
    super((cause == null) ? null : cause.toString());
    this.cause = cause;
  }
  
  public Throwable getLinkedCause() { return this.cause; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\JAXRPCException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */