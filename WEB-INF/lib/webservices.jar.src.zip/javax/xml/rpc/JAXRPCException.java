/*    */ package javax.xml.rpc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JAXRPCException
/*    */   extends RuntimeException
/*    */ {
/*    */   private Throwable cause;
/*    */   
/* 25 */   public JAXRPCException() { this.cause = null; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JAXRPCException(String message) {
/* 34 */     super(message);
/* 35 */     this.cause = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JAXRPCException(String message, Throwable cause) {
/* 47 */     super(message);
/* 48 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JAXRPCException(Throwable cause) {
/* 63 */     super((cause == null) ? null : cause.toString());
/* 64 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 73 */   public Throwable getLinkedCause() { return this.cause; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\JAXRPCException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */