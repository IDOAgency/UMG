/*     */ package javax.xml.rpc;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FactoryFinder
/*     */ {
/*     */   private static Object newInstance(String className, ClassLoader classLoader) throws ServiceException {
/*     */     try {
/*     */       Class clazz;
/*  37 */       if (classLoader == null) {
/*  38 */         clazz = Class.forName(className);
/*     */       } else {
/*  40 */         clazz = classLoader.loadClass(className);
/*     */       } 
/*  42 */       return clazz.newInstance();
/*     */     } catch (ClassNotFoundException x) {
/*  44 */       throw new ServiceException("Provider " + className + " not found", x);
/*     */     } catch (Exception x) {
/*     */       
/*  47 */       throw new ServiceException("Provider " + className + " could not be instantiated: " + x, x);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object find(String factoryId, String fallbackClassName) throws ServiceException {
/*     */     ClassLoader classLoader;
/*     */     try {
/*  77 */       classLoader = Thread.currentThread().getContextClassLoader();
/*     */     } catch (Exception x) {
/*  79 */       throw new ServiceException(x.toString(), x);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  84 */       String systemProp = System.getProperty(factoryId);
/*     */       
/*  86 */       if (systemProp != null) {
/*  87 */         return newInstance(systemProp, classLoader);
/*     */       }
/*  89 */     } catch (SecurityException se) {}
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  94 */       String javah = System.getProperty("java.home");
/*  95 */       String configFile = javah + File.separator + "lib" + File.separator + "jaxrpc.properties";
/*     */       
/*  97 */       File f = new File(configFile);
/*  98 */       if (f.exists()) {
/*  99 */         Properties props = new Properties();
/* 100 */         props.load(new FileInputStream(f));
/* 101 */         String factoryClassName = props.getProperty(factoryId);
/* 102 */         return newInstance(factoryClassName, classLoader);
/*     */       } 
/* 104 */     } catch (Exception ex) {}
/*     */ 
/*     */     
/* 107 */     String serviceId = "META-INF/services/" + factoryId;
/*     */     
/*     */     try {
/* 110 */       InputStream is = null;
/* 111 */       if (classLoader == null) {
/* 112 */         is = ClassLoader.getSystemResourceAsStream(serviceId);
/*     */       } else {
/* 114 */         is = classLoader.getResourceAsStream(serviceId);
/*     */       } 
/*     */       
/* 117 */       if (is != null) {
/* 118 */         BufferedReader rd = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/*     */ 
/*     */         
/* 121 */         String factoryClassName = rd.readLine();
/* 122 */         rd.close();
/*     */         
/* 124 */         if (factoryClassName != null && !"".equals(factoryClassName))
/*     */         {
/* 126 */           return newInstance(factoryClassName, classLoader);
/*     */         }
/*     */       } 
/* 129 */     } catch (Exception ex) {}
/*     */ 
/*     */     
/* 132 */     if (fallbackClassName == null) {
/* 133 */       throw new ServiceException("Provider for " + factoryId + " cannot be found", null);
/*     */     }
/*     */ 
/*     */     
/* 137 */     return newInstance(fallbackClassName, classLoader);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\FactoryFinder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */