package javax.xml.rpc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

class FactoryFinder {
  private static Object newInstance(String className, ClassLoader classLoader) throws ServiceException {
    try {
      Class clazz;
      if (classLoader == null) {
        clazz = Class.forName(className);
      } else {
        clazz = classLoader.loadClass(className);
      } 
      return clazz.newInstance();
    } catch (ClassNotFoundException x) {
      throw new ServiceException("Provider " + className + " not found", x);
    } catch (Exception x) {
      throw new ServiceException("Provider " + className + " could not be instantiated: " + x, x);
    } 
  }
  
  static Object find(String factoryId, String fallbackClassName) throws ServiceException {
    ClassLoader classLoader;
    try {
      classLoader = Thread.currentThread().getContextClassLoader();
    } catch (Exception x) {
      throw new ServiceException(x.toString(), x);
    } 
    try {
      String systemProp = System.getProperty(factoryId);
      if (systemProp != null)
        return newInstance(systemProp, classLoader); 
    } catch (SecurityException se) {}
    try {
      String javah = System.getProperty("java.home");
      String configFile = javah + File.separator + "lib" + File.separator + "jaxrpc.properties";
      File f = new File(configFile);
      if (f.exists()) {
        Properties props = new Properties();
        props.load(new FileInputStream(f));
        String factoryClassName = props.getProperty(factoryId);
        return newInstance(factoryClassName, classLoader);
      } 
    } catch (Exception ex) {}
    String serviceId = "META-INF/services/" + factoryId;
    try {
      InputStream is = null;
      if (classLoader == null) {
        is = ClassLoader.getSystemResourceAsStream(serviceId);
      } else {
        is = classLoader.getResourceAsStream(serviceId);
      } 
      if (is != null) {
        BufferedReader rd = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        String factoryClassName = rd.readLine();
        rd.close();
        if (factoryClassName != null && !"".equals(factoryClassName))
          return newInstance(factoryClassName, classLoader); 
      } 
    } catch (Exception ex) {}
    if (fallbackClassName == null)
      throw new ServiceException("Provider for " + factoryId + " cannot be found", null); 
    return newInstance(fallbackClassName, classLoader);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\FactoryFinder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */