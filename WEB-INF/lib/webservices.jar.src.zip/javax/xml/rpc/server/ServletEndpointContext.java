package javax.xml.rpc.server;

import java.security.Principal;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.xml.rpc.handler.MessageContext;

public interface ServletEndpointContext {
  MessageContext getMessageContext();
  
  Principal getUserPrincipal();
  
  HttpSession getHttpSession();
  
  ServletContext getServletContext();
  
  boolean isUserInRole(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\server\ServletEndpointContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */