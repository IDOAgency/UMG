package javax.xml.rpc.server;

import javax.xml.rpc.ServiceException;

public interface ServiceLifecycle {
  void init(Object paramObject) throws ServiceException;
  
  void destroy();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\server\ServiceLifecycle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */