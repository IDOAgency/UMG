package javax.xml.rpc.encoding;

import java.io.Serializable;
import java.util.Iterator;

public interface SerializerFactory extends Serializable {
  Serializer getSerializerAs(String paramString);
  
  Iterator getSupportedMechanismTypes();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\encoding\SerializerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */