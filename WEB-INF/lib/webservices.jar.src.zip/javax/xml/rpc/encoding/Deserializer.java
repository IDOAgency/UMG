package javax.xml.rpc.encoding;

import java.io.Serializable;

public interface Deserializer extends Serializable {
  String getMechanismType();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\encoding\Deserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */