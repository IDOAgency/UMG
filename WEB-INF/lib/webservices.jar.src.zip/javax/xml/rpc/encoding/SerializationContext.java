package javax.xml.rpc.encoding;

public interface SerializationContext {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\encoding\SerializationContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */