package javax.xml.rpc.encoding;

import java.io.Serializable;
import java.util.Iterator;

public interface DeserializerFactory extends Serializable {
  Deserializer getDeserializerAs(String paramString);
  
  Iterator getSupportedMechanismTypes();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\encoding\DeserializerFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */