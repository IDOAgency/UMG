package javax.xml.rpc.encoding;

import java.io.Serializable;

public interface TypeMappingRegistry extends Serializable {
  TypeMapping register(String paramString, TypeMapping paramTypeMapping);
  
  void registerDefault(TypeMapping paramTypeMapping);
  
  TypeMapping getDefaultTypeMapping();
  
  String[] getRegisteredEncodingStyleURIs();
  
  TypeMapping getTypeMapping(String paramString);
  
  TypeMapping createTypeMapping();
  
  TypeMapping unregisterTypeMapping(String paramString);
  
  boolean removeTypeMapping(TypeMapping paramTypeMapping);
  
  void clear();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\encoding\TypeMappingRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */