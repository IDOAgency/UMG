package javax.xml.rpc.holders;

public final class ByteArrayHolder implements Holder {
  public byte[] value;
  
  public ByteArrayHolder() {}
  
  public ByteArrayHolder(byte[] mybyteArray) { this.value = mybyteArray; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\ByteArrayHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */