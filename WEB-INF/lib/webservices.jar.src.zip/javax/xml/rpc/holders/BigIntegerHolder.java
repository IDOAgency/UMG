/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BigIntegerHolder
/*    */   implements Holder
/*    */ {
/*    */   public BigInteger value;
/*    */   
/*    */   public BigIntegerHolder() {}
/*    */   
/* 16 */   public BigIntegerHolder(BigInteger myBigInteger) { this.value = myBigInteger; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\BigIntegerHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */