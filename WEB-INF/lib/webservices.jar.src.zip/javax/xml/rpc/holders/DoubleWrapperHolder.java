package javax.xml.rpc.holders;

public final class DoubleWrapperHolder implements Holder {
  public Double value;
  
  public DoubleWrapperHolder() {}
  
  public DoubleWrapperHolder(Double mydouble) { this.value = mydouble; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\DoubleWrapperHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */