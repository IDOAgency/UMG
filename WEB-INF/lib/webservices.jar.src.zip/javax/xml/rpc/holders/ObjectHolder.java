/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObjectHolder
/*    */   implements Holder
/*    */ {
/*    */   public Object value;
/*    */   
/*    */   public ObjectHolder() {}
/*    */   
/* 16 */   public ObjectHolder(Object value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\ObjectHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */