/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ShortHolder
/*    */   implements Holder
/*    */ {
/*    */   public short value;
/*    */   
/*    */   public ShortHolder() {}
/*    */   
/* 16 */   public ShortHolder(short myshort) { this.value = myshort; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\ShortHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */