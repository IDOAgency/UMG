/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ByteHolder
/*    */   implements Holder
/*    */ {
/*    */   public byte value;
/*    */   
/*    */   public ByteHolder() {}
/*    */   
/* 16 */   public ByteHolder(byte mybyte) { this.value = mybyte; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\ByteHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */