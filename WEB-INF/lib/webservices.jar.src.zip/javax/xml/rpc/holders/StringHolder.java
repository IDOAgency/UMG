/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StringHolder
/*    */   implements Holder
/*    */ {
/*    */   public String value;
/*    */   
/*    */   public StringHolder() {}
/*    */   
/* 16 */   public StringHolder(String myString) { this.value = myString; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\StringHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */