/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LongWrapperHolder
/*    */   implements Holder
/*    */ {
/*    */   public Long value;
/*    */   
/*    */   public LongWrapperHolder() {}
/*    */   
/* 16 */   public LongWrapperHolder(Long mylong) { this.value = mylong; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\LongWrapperHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */