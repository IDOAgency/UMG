/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ByteWrapperHolder
/*    */   implements Holder
/*    */ {
/*    */   public Byte value;
/*    */   
/*    */   public ByteWrapperHolder() {}
/*    */   
/* 16 */   public ByteWrapperHolder(Byte mybyte) { this.value = mybyte; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\ByteWrapperHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */