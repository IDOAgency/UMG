package javax.xml.rpc.holders;

public final class DoubleHolder implements Holder {
  public double value;
  
  public DoubleHolder() {}
  
  public DoubleHolder(double mydouble) { this.value = mydouble; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\DoubleHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */