/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BooleanWrapperHolder
/*    */   implements Holder
/*    */ {
/*    */   public Boolean value;
/*    */   
/*    */   public BooleanWrapperHolder() {}
/*    */   
/* 16 */   public BooleanWrapperHolder(Boolean myboolean) { this.value = myboolean; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\BooleanWrapperHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */