package javax.xml.rpc.holders;

public final class ShortWrapperHolder implements Holder {
  public Short value;
  
  public ShortWrapperHolder() {}
  
  public ShortWrapperHolder(Short myshort) { this.value = myshort; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\ShortWrapperHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */