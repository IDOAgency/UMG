package javax.xml.rpc.holders;

public final class FloatHolder implements Holder {
  public float value;
  
  public FloatHolder() {}
  
  public FloatHolder(float myfloat) { this.value = myfloat; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\FloatHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */