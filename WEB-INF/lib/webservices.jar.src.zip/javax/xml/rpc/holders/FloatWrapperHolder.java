/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FloatWrapperHolder
/*    */   implements Holder
/*    */ {
/*    */   public Float value;
/*    */   
/*    */   public FloatWrapperHolder() {}
/*    */   
/* 16 */   public FloatWrapperHolder(Float myfloat) { this.value = myfloat; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\FloatWrapperHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */