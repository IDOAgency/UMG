/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class QNameHolder
/*    */   implements Holder
/*    */ {
/*    */   public QName value;
/*    */   
/*    */   public QNameHolder() {}
/*    */   
/* 16 */   public QNameHolder(QName myQName) { this.value = myQName; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\QNameHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */