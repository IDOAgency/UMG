/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IntHolder
/*    */   implements Holder
/*    */ {
/*    */   public int value;
/*    */   
/*    */   public IntHolder() {}
/*    */   
/* 16 */   public IntHolder(int myint) { this.value = myint; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\IntHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */