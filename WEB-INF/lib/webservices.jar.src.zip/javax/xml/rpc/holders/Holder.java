package javax.xml.rpc.holders;

public interface Holder {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\Holder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */