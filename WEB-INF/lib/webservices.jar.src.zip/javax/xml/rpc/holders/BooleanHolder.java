package javax.xml.rpc.holders;

public final class BooleanHolder implements Holder {
  public boolean value;
  
  public BooleanHolder() {}
  
  public BooleanHolder(boolean myboolean) { this.value = myboolean; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\BooleanHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */