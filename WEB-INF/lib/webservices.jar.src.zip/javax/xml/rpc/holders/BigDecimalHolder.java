package javax.xml.rpc.holders;

import java.math.BigDecimal;

public final class BigDecimalHolder implements Holder {
  public BigDecimal value;
  
  public BigDecimalHolder() {}
  
  public BigDecimalHolder(BigDecimal myBigDecimal) { this.value = myBigDecimal; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\holders\BigDecimalHolder.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */