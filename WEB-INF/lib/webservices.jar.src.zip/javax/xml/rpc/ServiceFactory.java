/*    */ package javax.xml.rpc;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.Properties;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServiceFactory
/*    */ {
/*    */   public static final String SERVICEFACTORY_PROPERTY = "javax.xml.rpc.ServiceFactory";
/*    */   private static final String DEFAULT_SERVICEFACTORY = "com.sun.xml.rpc.client.ServiceFactoryImpl";
/*    */   
/*    */   public static ServiceFactory newInstance() throws ServiceException {
/*    */     try {
/* 58 */       return (ServiceFactory)FactoryFinder.find("javax.xml.rpc.ServiceFactory", "com.sun.xml.rpc.client.ServiceFactoryImpl");
/*    */     }
/*    */     catch (ServiceException ex) {
/*    */       
/* 62 */       throw ex;
/*    */     } catch (Exception ex) {
/* 64 */       throw new ServiceException("Unable to create Service Factory: " + ex.getMessage());
/*    */     } 
/*    */   }
/*    */   
/*    */   public abstract Service createService(URL paramURL, QName paramQName) throws ServiceException;
/*    */   
/*    */   public abstract Service createService(QName paramQName) throws ServiceException;
/*    */   
/*    */   public abstract Service loadService(Class paramClass) throws ServiceException;
/*    */   
/*    */   public abstract Service loadService(URL paramURL, Class paramClass, Properties paramProperties) throws ServiceException;
/*    */   
/*    */   public abstract Service loadService(URL paramURL, QName paramQName, Properties paramProperties) throws ServiceException;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\webservices.jar!\javax\xml\rpc\ServiceFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */