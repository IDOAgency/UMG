package com.techempower;

public interface ConnectorFactory {
  void configure(EnhancedProperties paramEnhancedProperties, TechEmpowerApplication paramTechEmpowerApplication);
  
  DatabaseConnector getConnector(String paramString);
  
  DatabaseConnector getScrollingConnector(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\ConnectorFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */