package com.techempower;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;

public class UrlPunisher implements Runnable {
  protected String url;
  
  protected int id;
  
  protected boolean stillNeeded;
  
  protected static String correctResponse = null;
  
  protected static Random random = new Random();
  
  public UrlPunisher(String paramString, int paramInt) {
    this.id = 0;
    this.stillNeeded = true;
    this.url = paramString;
    this.id = paramInt;
  }
  
  public void run() {
    byte[] arrayOfByte = new byte[4000];
    while (isStillNeeded()) {
      String str = "";
      try {
        long l = System.currentTimeMillis();
        URL uRL = new URL(this.url);
        URLConnection uRLConnection = uRL.openConnection();
        uRLConnection.setUseCaches(false);
        uRLConnection.setDoInput(true);
        InputStream inputStream = uRLConnection.getInputStream();
        int i = 0;
        while (!i) {
          Thread.yield();
          i = inputStream.read(arrayOfByte, 0, 4000);
          if (i > 0) {
            String str1 = new String(arrayOfByte, 0, i);
            str = String.valueOf(str) + str1;
          } 
        } 
        if (correctResponse == null) {
          correctResponse = str;
        } else if (correctResponse.equals(str)) {
          long l1 = System.currentTimeMillis() - l;
        } 
        inputStream.close();
      } catch (MalformedURLException malformedURLException) {
      
      } catch (IOException iOException) {}
      try {
        Thread.sleep(random.nextInt(60000));
      } catch (InterruptedException interruptedException) {}
    } 
  }
  
  public boolean isStillNeeded() { return this.stillNeeded; }
  
  public void setStillNeeded(boolean paramBoolean) { this.stillNeeded = paramBoolean; }
  
  public static void main(String[] paramArrayOfString) {
    String str = "http://tiamat.techempower.com/tempest/?cmd=user-articles";
    if (paramArrayOfString.length == 1)
      str = paramArrayOfString[0]; 
    for (byte b = 0; b < 'È'; b++) {
      UrlPunisher urlPunisher = new UrlPunisher(str, b);
      Thread thread = new Thread(urlPunisher);
      thread.start();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\UrlPunisher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */