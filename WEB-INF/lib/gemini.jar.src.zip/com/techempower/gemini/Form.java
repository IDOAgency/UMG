package com.techempower.gemini;

import com.techempower.ComponentLog;
import java.util.Iterator;
import java.util.Vector;

public class Form {
  public static final String COMPONENT_CODE = "form";
  
  public static final String POST = "POST";
  
  public static final String GET = "GET";
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  protected Vector formElements;
  
  protected Vector formSubmissions;
  
  protected String formName;
  
  protected String formAction;
  
  protected String formMethod;
  
  public Form(GeminiApplication paramGeminiApplication) {
    this.formElements = new Vector();
    this.formSubmissions = new Vector();
    this.formName = "Form";
    this.formAction = "";
    this.formMethod = "POST";
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("form");
  }
  
  public Form(GeminiApplication paramGeminiApplication, String paramString1, String paramString2, String paramString3) {
    this.formElements = new Vector();
    this.formSubmissions = new Vector();
    this.formName = "Form";
    this.formAction = "";
    this.formMethod = "POST";
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("form");
    setName(paramString1);
    setAction(paramString2);
    setMethod(paramString3);
  }
  
  public FormValidation validate() {
    FormValidation formValidation = new FormValidation(this);
    formValidation.processForm();
    return formValidation;
  }
  
  public String toString() { return "Form [\"" + getName() + "\"; " + this.formElements.size() + " element(s)]"; }
  
  public String dumpContents() {
    StringBuffer stringBuffer = new StringBuffer(500);
    for (byte b = 0; b < this.formElements.size(); b++) {
      FormElement formElement = (FormElement)this.formElements.elementAt(b);
      stringBuffer.append(formElement.getDisplayName());
      stringBuffer.append(": ");
      if (formElement instanceof FormCheckBox) {
        FormCheckBox formCheckBox = (FormCheckBox)formElement;
        if (formCheckBox.isChecked()) {
          stringBuffer.append("checked");
        } else {
          stringBuffer.append("not checked");
        } 
      } else {
        stringBuffer.append(formElement.getStringValue());
      } 
      stringBuffer.append("\r\n");
    } 
    return stringBuffer.toString();
  }
  
  public String render() { return render(null); }
  
  public String render(FormValidation paramFormValidation) {
    StringBuffer stringBuffer = new StringBuffer(500);
    stringBuffer.append(renderStart());
    stringBuffer.append("<table border=\"1\" cellspacing=\"1\" cellpadding=\"1\">");
    for (byte b = 0; b < this.formElements.size(); b++) {
      FormElement formElement = (FormElement)this.formElements.elementAt(b);
      if (paramFormValidation != null && paramFormValidation.getErroredElements().contains(formElement)) {
        stringBuffer.append("<tr><td><b>");
        stringBuffer.append(formElement.getName());
        stringBuffer.append(":</b></td><td>");
        stringBuffer.append(formElement.render());
        stringBuffer.append("</td></tr>");
      } else {
        stringBuffer.append("<tr><td>");
        stringBuffer.append(formElement.getName());
        stringBuffer.append(":</td><td>");
        stringBuffer.append(formElement.render());
        stringBuffer.append("</td></tr>");
      } 
    } 
    stringBuffer.append("</table>");
    stringBuffer.append(renderEnd());
    return stringBuffer.toString();
  }
  
  public String renderStart() {
    StringBuffer stringBuffer = new StringBuffer(60);
    stringBuffer.append("<form name=\"");
    stringBuffer.append(this.formName);
    stringBuffer.append("\" action=\"");
    stringBuffer.append(this.formAction);
    stringBuffer.append("\" method=\"");
    stringBuffer.append(this.formMethod);
    stringBuffer.append("\">");
    return stringBuffer.toString();
  }
  
  public String renderEnd() { return "</form>"; }
  
  public void setName(String paramString) { this.formName = paramString; }
  
  public String getName() { return this.formName; }
  
  public GeminiApplication getApplication() { return this.application; }
  
  public void setAction(String paramString) { this.formAction = paramString; }
  
  public String getAction() { return this.formAction; }
  
  public void setMethod(String paramString) { this.formMethod = paramString; }
  
  public String getMethod() { return this.formMethod; }
  
  public Iterator getElements() { return this.formElements.iterator(); }
  
  public void addElementsFromForm(Form paramForm) {
    Iterator iterator = paramForm.getElements();
    while (iterator.hasNext()) {
      FormElement formElement = (FormElement)iterator.next();
      addElement(formElement);
    } 
  }
  
  public void addElement(FormElement paramFormElement) { this.formElements.addElement(paramFormElement); }
  
  public void addSubmissionElement(FormSubmissionElement paramFormSubmissionElement) {
    this.formSubmissions.addElement(paramFormSubmissionElement);
    this.formElements.addElement(paramFormSubmissionElement);
  }
  
  public void removeElement(String paramString) {
    FormElement formElement = getElement(paramString);
    removeElement(formElement);
  }
  
  public void removeElement(FormElement paramFormElement) {
    if (paramFormElement != null)
      this.formElements.remove(paramFormElement); 
  }
  
  public void removeSubmissionElement(FormSubmissionElement paramFormSubmissionElement) {
    if (paramFormSubmissionElement != null) {
      this.formSubmissions.remove(paramFormSubmissionElement);
      removeElement(paramFormSubmissionElement);
    } 
  }
  
  public FormElement getElement(int paramInt) {
    if (paramInt >= 0 && paramInt < this.formElements.size())
      return (FormElement)this.formElements.elementAt(paramInt); 
    return null;
  }
  
  public FormElement getElement(String paramString) {
    for (byte b = 0; b < this.formElements.size(); b++) {
      FormElement formElement = (FormElement)this.formElements.elementAt(b);
      if (formElement.getName().equalsIgnoreCase(paramString))
        return formElement; 
    } 
    return null;
  }
  
  public String getStringValue(String paramString) {
    FormElement formElement = getElement(paramString);
    if (formElement != null)
      return formElement.getStringValue(); 
    return null;
  }
  
  public int getIntegerValue(String paramString) {
    FormElement formElement = getElement(paramString);
    if (formElement != null)
      return formElement.getIntegerValue(); 
    return 0;
  }
  
  public String getRenderableValue(String paramString) {
    FormElement formElement = getElement(paramString);
    if (formElement != null)
      return formElement.getRenderableValue(); 
    return null;
  }
  
  public void setValues(Context paramContext) {
    for (byte b = 0; b < this.formElements.size(); b++) {
      FormElement formElement = (FormElement)this.formElements.elementAt(b);
      formElement.setValue(paramContext);
    } 
  }
  
  public boolean isUnchanged() {
    for (byte b = 0; b < this.formElements.size(); b++) {
      FormElement formElement = (FormElement)this.formElements.elementAt(b);
      if (!formElement.isUnchanged())
        return false; 
    } 
    return true;
  }
  
  public boolean isChanged() { return isUnchanged() ^ true; }
  
  public boolean isSubmitted() {
    for (byte b = 0; b < this.formSubmissions.size(); b++) {
      FormSubmissionElement formSubmissionElement = (FormSubmissionElement)this.formSubmissions.elementAt(b);
      if (formSubmissionElement.isSubmitted())
        return true; 
    } 
    return false;
  }
  
  public void revertCheckBoxes() {
    for (byte b = 0; b < this.formElements.size(); b++) {
      FormElement formElement = (FormElement)this.formElements.elementAt(b);
      if (formElement instanceof FormCheckBox)
        formElement.revert(); 
    } 
  }
  
  public Vector getChangedElements() {
    Vector vector = new Vector();
    for (byte b = 0; b < this.formElements.size(); b++) {
      FormElement formElement = (FormElement)this.formElements.elementAt(b);
      if (!formElement.isUnchanged())
        vector.addElement(formElement); 
    } 
    return vector;
  }
  
  public boolean isNew() { return isUnchanged(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\Form.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */