package com.techempower.gemini;

import com.techempower.ComponentLog;
import com.techempower.EnhancedProperties;
import com.techempower.Version;

public class BugTool implements GeminiConstants {
  public static final String COMPONENT_CODE = "bugt";
  
  public static final String DEFAULT_BUG_URL = "http://tiamat.techempower.com/bugtool/bugreport.asp?";
  
  public static final String DEFAULT_COMMENT_URL = "http://tiamat.techempower.com:8012/submit-comment.jsp?";
  
  public static final String DEFAULT_FIELD_VALUE = "unknown";
  
  protected boolean bugToolEnabled;
  
  protected boolean commentToolEnabled;
  
  protected String bugReportURL;
  
  protected String bugReportProgram;
  
  protected String bugReportSection;
  
  protected boolean bugToolAdminOnly;
  
  protected String commentURL;
  
  protected String commentVersion;
  
  protected ComponentLog log;
  
  public BugTool(GeminiApplication paramGeminiApplication) {
    this.bugToolEnabled = false;
    this.commentToolEnabled = false;
    this.bugReportURL = "http://tiamat.techempower.com/bugtool/bugreport.asp?";
    this.bugReportProgram = "unknown";
    this.bugReportSection = "unknown";
    this.bugToolAdminOnly = false;
    this.commentURL = "http://tiamat.techempower.com:8012/submit-comment.jsp?";
    this.commentVersion = "unknown";
    this.log = paramGeminiApplication.getLog("bugt");
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
    this.bugReportProgram = paramVersion.getProductName();
    this.bugReportSection = "v" + paramVersion.getVersionString();
    this.commentVersion = "v" + paramVersion.getVersionString();
    this.bugToolEnabled = paramEnhancedProperties.getYesNoProperty("BugToolEnabled", this.bugToolEnabled);
    this.bugReportURL = paramEnhancedProperties.getProperty("BugToolURLPrefix", this.bugReportURL);
    this.bugToolAdminOnly = paramEnhancedProperties.getYesNoProperty("BugToolAdminOnly", this.bugToolAdminOnly);
    this.commentToolEnabled = paramEnhancedProperties.getYesNoProperty("CommentToolEnabled", this.commentToolEnabled);
    this.commentURL = paramEnhancedProperties.getProperty("CommentToolURLPrefix", this.commentURL);
    if (this.bugToolEnabled) {
      if (this.bugToolAdminOnly) {
        this.log.debug("Bug tool enabled only for administrators.");
      } else {
        this.log.debug("Bug tool enabled.");
      } 
    } else {
      this.log.debug("Bug tool not enabled.");
    } 
    if (this.commentToolEnabled) {
      this.log.debug("Comment tool enabled.");
    } else {
      this.log.debug("Comment tool not enabled.");
    } 
  }
  
  public boolean isEnabled() { return isBugEnabled(); }
  
  public boolean isBugEnabled() { return this.bugToolEnabled; }
  
  public boolean isCommentEnabled() { return this.commentToolEnabled; }
  
  public String getBugReportLink(Context paramContext) {
    StringBuffer stringBuffer = new StringBuffer(getBugReportAnchor(paramContext, "<b>Report bug</b>"));
    String str = getCommentAnchor(paramContext, "<b>Submit comment</b>");
    if (str.length() > 0 && stringBuffer.length() > 0) {
      stringBuffer.append(" | ");
      stringBuffer.append(str);
    } 
    if (stringBuffer.length() > 0) {
      stringBuffer.insert(0, "<br><br><p><font face=\"Arial, Helvetica\" size=1>[ ");
      stringBuffer.append(" ]</font></p>");
    } 
    return stringBuffer.toString();
  }
  
  public String getBugReportAnchor(Context paramContext, String paramString) {
    StringBuffer stringBuffer = new StringBuffer(80);
    if (this.bugToolEnabled) {
      String str = paramContext.getReferencedJSP();
      stringBuffer.append("<a href=\"");
      stringBuffer.append(this.bugReportURL);
      stringBuffer.append("Program=");
      stringBuffer.append(this.bugReportProgram.replace(' ', '+'));
      stringBuffer.append("&Section=");
      stringBuffer.append(this.bugReportSection.replace(' ', '+'));
      stringBuffer.append("&Screen=");
      stringBuffer.append(str);
      stringBuffer.append("&UserName=");
      stringBuffer.append(paramContext.getClientIP());
      stringBuffer.append("\" target=\"bugreportwindow\">");
      stringBuffer.append(paramString);
      stringBuffer.append("</a>");
    } 
    return stringBuffer.toString();
  }
  
  public String getCommentAnchor(Context paramContext, String paramString) {
    StringBuffer stringBuffer = new StringBuffer(80);
    if (this.commentToolEnabled) {
      String str = paramContext.getReferencedJSP();
      stringBuffer.append("<a href=\"");
      stringBuffer.append(this.commentURL);
      stringBuffer.append("Screen=");
      stringBuffer.append(str);
      stringBuffer.append("&Version=");
      stringBuffer.append(this.commentVersion);
      stringBuffer.append("&Username=");
      stringBuffer.append(paramContext.getClientIP());
      stringBuffer.append("\" target=\"commentwindow\">");
      stringBuffer.append(paramString);
      stringBuffer.append("</a></b>");
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\BugTool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */