/*    */ package com.techempower.gemini;
/*    */ 
/*    */ import com.techempower.BasicHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeminiHelper
/*    */   extends BasicHelper
/*    */   implements GeminiConstants
/*    */ {
/*    */   public static int getBrowserType(Context paramContext) {
/* 62 */     String str = paramContext.getHeader("User-Agent");
/*    */     
/* 64 */     if (str != null) {
/*    */       
/* 66 */       str = str.toLowerCase();
/*    */       
/* 68 */       for (byte b = 0; b < GeminiConstants.BROWSER_TYPE_CHECK_ORDER.length; b++) {
/*    */         
/* 70 */         if (str.indexOf(GeminiConstants.BROWSER_USER_AGENT_IDS[GeminiConstants.BROWSER_TYPE_CHECK_ORDER[b]]) != -1)
/*    */         {
/* 72 */           return GeminiConstants.BROWSER_TYPE_CHECK_ORDER[b];
/*    */         }
/*    */       } 
/*    */     } 
/* 76 */     return -1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getBrowserTypeName(int paramInt) {
/* 88 */     if (paramInt >= 0 && paramInt < GeminiConstants.BROWSER_NAMES.length) {
/* 89 */       return GeminiConstants.BROWSER_NAMES[paramInt];
/*    */     }
/* 91 */     return new String("");
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\GeminiHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */