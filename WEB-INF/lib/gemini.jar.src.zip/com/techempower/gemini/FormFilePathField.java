package com.techempower.gemini;

public class FormFilePathField extends FormTextField {
  static char[] BAD_CHARS = { ':', '*', '?', '"', '<', '>', '|' };
  
  static int CONVENTIONAL_PATH_PREFIX_OFFSET = 3;
  
  static int UNC_PATH_PREFIX_OFFSET = 2;
  
  public FormFilePathField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2) { super(paramString1, paramString2, paramBoolean, paramInt1, paramInt2); }
  
  public FormFilePathField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt); }
  
  public FormFilePathField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, "", paramBoolean, paramInt); }
  
  public FormFilePathField(String paramString, int paramInt) { this(paramString, "", false, paramInt); }
  
  public FormFilePathField(String paramString) { this(paramString, "", false, 20); }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    if (this.value.trim().equalsIgnoreCase("")) {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
          "Please provide input in the field named " + getDisplayName() + ".", 
          "Please provide input in the file path.");
    } else if (this.value.length() > 4) {
      if (isUNCFilePath(this.value.trim())) {
        if (containsChar(this.value.trim(), BAD_CHARS, UNC_PATH_PREFIX_OFFSET))
          paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " contains one of the following invalid characters  : * ? \" < > |", 
              String.valueOf(getDisplayName()) + " may not contain of the following characters  : * ? \" < > |", 
              "Please remove any of these characters from your file path  : * ? \" < > |"); 
      } else if (isConventionalFilePath(this.value.trim())) {
        if (containsChar(this.value.trim(), BAD_CHARS, CONVENTIONAL_PATH_PREFIX_OFFSET))
          paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " contains one of the following invalid characters  : * ? \" < > |", 
              String.valueOf(getDisplayName()) + " may not contain of the following characters  : * ? \" < > |", 
              "Please remove any of these characters from your file path  : * ? \" < > |"); 
      } else {
        paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is not in a valid format.", 
            String.valueOf(getDisplayName()) + " contains an incorrectly formatted file path.", 
            "The path must be in the form \"C:\\temp\" or \"\\\\mycomputer\\documents\\\".");
      } 
    } else {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is too short to provide a meaningful file path.", 
          "Please provide a longer value in the field named " + getDisplayName(), 
          "Please provide a file path value at least four characters long.");
    } 
  }
  
  private boolean isConventionalFilePath(String paramString) {
    if (!Character.isLetter(paramString.charAt(0)))
      return false; 
    if (!paramString.startsWith(":\\", 1) && 
      !paramString.startsWith(":/", 1))
      return false; 
    return true;
  }
  
  private boolean isUNCFilePath(String paramString) {
    if (!paramString.startsWith("\\\\") && 
      !paramString.startsWith("//"))
      return false; 
    return true;
  }
  
  private boolean containsChar(String paramString, char[] paramArrayOfChar, int paramInt) {
    for (byte b = 0; b < paramArrayOfChar.length; b++) {
      if (paramString.indexOf(paramArrayOfChar[b], paramInt) != -1)
        return true; 
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormFilePathField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */