/*     */ package com.techempower.gemini;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormFilePathField
/*     */   extends FormTextField
/*     */ {
/*  37 */   static char[] BAD_CHARS = { ':', '*', '?', '"', '<', '>', '|' };
/*  38 */   static int CONVENTIONAL_PATH_PREFIX_OFFSET = 3;
/*  39 */   static int UNC_PATH_PREFIX_OFFSET = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public FormFilePathField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2) { super(paramString1, paramString2, paramBoolean, paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public FormFilePathField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public FormFilePathField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, "", paramBoolean, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public FormFilePathField(String paramString, int paramInt) { this(paramString, "", false, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public FormFilePathField(String paramString) { this(paramString, "", false, 20); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 105 */     if (this.value.trim().equalsIgnoreCase("")) {
/*     */       
/* 107 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
/* 108 */           "Please provide input in the field named " + getDisplayName() + ".", 
/* 109 */           "Please provide input in the file path.");
/*     */ 
/*     */     
/*     */     }
/* 113 */     else if (this.value.length() > 4) {
/*     */ 
/*     */ 
/*     */       
/* 117 */       if (isUNCFilePath(this.value.trim()))
/*     */       {
/*     */         
/* 120 */         if (containsChar(this.value.trim(), BAD_CHARS, UNC_PATH_PREFIX_OFFSET))
/*     */         {
/* 122 */           paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " contains one of the following invalid characters  : * ? \" < > |", 
/* 123 */               String.valueOf(getDisplayName()) + " may not contain of the following characters  : * ? \" < > |", 
/* 124 */               "Please remove any of these characters from your file path  : * ? \" < > |");
/*     */         }
/*     */       }
/* 127 */       else if (isConventionalFilePath(this.value.trim()))
/*     */       {
/*     */         
/* 130 */         if (containsChar(this.value.trim(), BAD_CHARS, CONVENTIONAL_PATH_PREFIX_OFFSET))
/*     */         {
/* 132 */           paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " contains one of the following invalid characters  : * ? \" < > |", 
/* 133 */               String.valueOf(getDisplayName()) + " may not contain of the following characters  : * ? \" < > |", 
/* 134 */               "Please remove any of these characters from your file path  : * ? \" < > |");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 139 */         paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is not in a valid format.", 
/* 140 */             String.valueOf(getDisplayName()) + " contains an incorrectly formatted file path.", 
/* 141 */             "The path must be in the form \"C:\\temp\" or \"\\\\mycomputer\\documents\\\".");
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 146 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is too short to provide a meaningful file path.", 
/* 147 */           "Please provide a longer value in the field named " + getDisplayName(), 
/* 148 */           "Please provide a file path value at least four characters long.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isConventionalFilePath(String paramString) {
/* 159 */     if (!Character.isLetter(paramString.charAt(0))) {
/* 160 */       return false;
/*     */     }
/*     */     
/* 163 */     if (!paramString.startsWith(":\\", 1) && 
/* 164 */       !paramString.startsWith(":/", 1))
/*     */     {
/* 166 */       return false;
/*     */     }
/* 168 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUNCFilePath(String paramString) {
/* 179 */     if (!paramString.startsWith("\\\\") && 
/* 180 */       !paramString.startsWith("//"))
/*     */     {
/* 182 */       return false;
/*     */     }
/* 184 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean containsChar(String paramString, char[] paramArrayOfChar, int paramInt) {
/* 189 */     for (byte b = 0; b < paramArrayOfChar.length; b++) {
/*     */       
/* 191 */       if (paramString.indexOf(paramArrayOfChar[b], paramInt) != -1)
/*     */       {
/* 193 */         return true;
/*     */       }
/*     */     } 
/* 196 */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormFilePathField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */