/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormValidation
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fval";
/*     */   protected ComponentLog log;
/*     */   protected boolean errors;
/*     */   protected Form form;
/*     */   protected Vector validations;
/*     */   protected Vector valErrors;
/*     */   protected Vector valElements;
/*     */   protected Vector valInstructions;
/*     */   protected Hashtable inlineInstructions;
/*     */   
/*     */   public FormValidation(Form paramForm) {
/*  47 */     this.errors = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.form = paramForm;
/*  66 */     this.log = paramForm.getApplication().getLog("fval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processForm() {
/*  75 */     this.validations = new Vector();
/*  76 */     this.valErrors = new Vector();
/*  77 */     this.valInstructions = new Vector();
/*  78 */     this.valElements = new Vector();
/*  79 */     this.inlineInstructions = new Hashtable();
/*     */ 
/*     */     
/*  82 */     this.errors = false;
/*     */ 
/*     */     
/*  85 */     Iterator iterator = this.form.getElements();
/*     */ 
/*     */ 
/*     */     
/*  89 */     while (iterator.hasNext()) {
/*     */       
/*  91 */       FormElement formElement = (FormElement)iterator.next();
/*  92 */       FormSingleValidation formSingleValidation = formElement.validate();
/*     */ 
/*     */       
/*  95 */       if (formSingleValidation != null && formSingleValidation.isError) {
/*     */         
/*  97 */         this.errors = true;
/*     */ 
/*     */         
/* 100 */         this.validations.addElement(formSingleValidation);
/* 101 */         if (formSingleValidation.error != null)
/* 102 */           this.valErrors.addElement(formSingleValidation.error); 
/* 103 */         if (formSingleValidation.element != null)
/* 104 */           this.valElements.addElement(formSingleValidation.element); 
/* 105 */         if (formSingleValidation.instruction != null)
/* 106 */           this.valInstructions.addElement(formSingleValidation.instruction); 
/* 107 */         if (formSingleValidation.inline != null) {
/* 108 */           this.inlineInstructions.put(formSingleValidation.element, formSingleValidation.inline);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public void reprocessForm() { processForm(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public Vector getValidations() { return this.validations; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public Vector getErrorStrings() { return this.valErrors; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public Vector getInstructions() { return this.valInstructions; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public Vector getErroredElements() { return this.valElements; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public Hashtable getInlineInstructions() { return this.inlineInstructions; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInlineInstructions(FormElement paramFormElement) {
/* 174 */     String str = (String)this.inlineInstructions.get(paramFormElement);
/*     */     
/* 176 */     if (str != null) {
/* 177 */       return str;
/*     */     }
/* 179 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public boolean isErrored(FormElement paramFormElement) { return getErroredElements().contains(paramFormElement); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   public boolean hasErrors() { return this.errors; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public boolean isGood() { return hasErrors() ^ true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public Form getForm() { return this.form; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormValidation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */