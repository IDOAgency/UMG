package com.techempower.gemini;

import com.techempower.BasicHelper;

public class FormTextArea extends FormElement {
  public static final int DEFAULT_ROWS = 10;
  
  public static final int DEFAULT_COLS = 50;
  
  public static final String DEFAULT_WRAP = "virtual";
  
  public static final String DEFAULT_VALUE = "";
  
  protected String value;
  
  protected String startingValue;
  
  protected int maxLength;
  
  protected int rows;
  
  protected int cols;
  
  protected String wrap;
  
  public FormTextArea(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2, String paramString3) {
    super(paramString1, paramString2, paramBoolean);
    setRows(paramInt1);
    setCols(paramInt2);
    setWrap(paramString3);
  }
  
  public FormTextArea(String paramString1, boolean paramBoolean, int paramInt1, int paramInt2, String paramString2) { this(paramString1, "", paramBoolean, paramInt1, paramInt2, paramString2); }
  
  public FormTextArea(String paramString1, int paramInt1, int paramInt2, String paramString2) { this(paramString1, "", false, paramInt1, paramInt2, paramString2); }
  
  public FormTextArea(String paramString, int paramInt1, int paramInt2) { this(paramString, "", false, paramInt1, paramInt2, "virtual"); }
  
  public FormTextArea(String paramString) { this(paramString, "", false, 10, 50, "virtual"); }
  
  public void setRows(int paramInt) { this.rows = paramInt; }
  
  public void setCols(int paramInt) { this.cols = paramInt; }
  
  public void setWrap(String paramString) { this.wrap = paramString; }
  
  public int getRows() { return this.rows; }
  
  public int getCols() { return this.cols; }
  
  public String getWrap() { return this.wrap; }
  
  public void setValue(String paramString) {
    if (!isReadOnly())
      this.value = paramString; 
  }
  
  public void setStartingValue(String paramString) { this.startingValue = paramString; }
  
  public String getStartingValue() { return this.startingValue; }
  
  public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.value)); }
  
  protected String getValue() { return this.value; }
  
  public String getStringValue() { return getValue(); }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public int getIntegerValue() { return 0; }
  
  public String render() {
    StringBuffer stringBuffer = new StringBuffer(60);
    stringBuffer.append("<textarea");
    stringBuffer.append(getClassName());
    stringBuffer.append(" name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" rows=\"");
    stringBuffer.append(getRows());
    stringBuffer.append("\" cols=\"");
    stringBuffer.append(getCols());
    stringBuffer.append('"');
    stringBuffer.append(getTabIndex());
    stringBuffer.append(getFormEvents());
    stringBuffer.append(" wrap=\"");
    stringBuffer.append(getWrap());
    stringBuffer.append('"');
    stringBuffer.append(getEnabledString());
    stringBuffer.append(getReadOnlyString());
    stringBuffer.append(getId());
    stringBuffer.append('>');
    stringBuffer.append(getRenderableValue());
    stringBuffer.append("</textarea>");
    return stringBuffer.toString();
  }
  
  public FormSingleValidation validate() {
    FormSingleValidation formSingleValidation = new FormSingleValidation(this);
    if (isRequired())
      requiredValidation(formSingleValidation); 
    customValidation(formSingleValidation);
    return formSingleValidation;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    if (getStringValue().length() == 0) {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
          "Please provide input in the field named " + getDisplayName() + ".", 
          "Please provide input in this field.");
    } else if (getStringValue().length() > getMaxLength()) {
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is too long.", 
          "The value in the field named " + getDisplayName() + " cannot be longer " + 
          "than " + getMaxLength() + " characters.", 
          "The value in this field cannot be longer then " + getMaxLength() + 
          " characters.");
    } 
  }
  
  public boolean isDefault() { return "".equals(getValue()); }
  
  public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
  
  public int getMaxLength() { return this.maxLength; }
  
  public void setMaxLength(int paramInt) { this.maxLength = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormTextArea.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */