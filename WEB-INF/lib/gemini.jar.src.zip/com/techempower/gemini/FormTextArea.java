/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormTextArea
/*     */   extends FormElement
/*     */ {
/*     */   public static final int DEFAULT_ROWS = 10;
/*     */   public static final int DEFAULT_COLS = 50;
/*     */   public static final String DEFAULT_WRAP = "virtual";
/*     */   public static final String DEFAULT_VALUE = "";
/*     */   protected String value;
/*     */   protected String startingValue;
/*     */   protected int maxLength;
/*     */   protected int rows;
/*     */   protected int cols;
/*     */   protected String wrap;
/*     */   
/*     */   public FormTextArea(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2, String paramString3) {
/*  69 */     super(paramString1, paramString2, paramBoolean);
/*  70 */     setRows(paramInt1);
/*  71 */     setCols(paramInt2);
/*  72 */     setWrap(paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public FormTextArea(String paramString1, boolean paramBoolean, int paramInt1, int paramInt2, String paramString2) { this(paramString1, "", paramBoolean, paramInt1, paramInt2, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public FormTextArea(String paramString1, int paramInt1, int paramInt2, String paramString2) { this(paramString1, "", false, paramInt1, paramInt2, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public FormTextArea(String paramString, int paramInt1, int paramInt2) { this(paramString, "", false, paramInt1, paramInt2, "virtual"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public FormTextArea(String paramString) { this(paramString, "", false, 10, 50, "virtual"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void setRows(int paramInt) { this.rows = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public void setCols(int paramInt) { this.cols = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void setWrap(String paramString) { this.wrap = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public int getRows() { return this.rows; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public int getCols() { return this.cols; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public String getWrap() { return this.wrap; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String paramString) {
/* 164 */     if (!isReadOnly()) {
/* 165 */       this.value = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public void setStartingValue(String paramString) { this.startingValue = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 185 */   public String getStartingValue() { return this.startingValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.value)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   protected String getValue() { return this.value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public String getStringValue() { return getValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public int getIntegerValue() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 252 */     StringBuffer stringBuffer = new StringBuffer(60);
/*     */     
/* 254 */     stringBuffer.append("<textarea");
/* 255 */     stringBuffer.append(getClassName());
/* 256 */     stringBuffer.append(" name=\"");
/* 257 */     stringBuffer.append(getName());
/* 258 */     stringBuffer.append("\" rows=\"");
/* 259 */     stringBuffer.append(getRows());
/* 260 */     stringBuffer.append("\" cols=\"");
/* 261 */     stringBuffer.append(getCols());
/* 262 */     stringBuffer.append('"');
/* 263 */     stringBuffer.append(getTabIndex());
/* 264 */     stringBuffer.append(getFormEvents());
/* 265 */     stringBuffer.append(" wrap=\"");
/* 266 */     stringBuffer.append(getWrap());
/* 267 */     stringBuffer.append('"');
/* 268 */     stringBuffer.append(getEnabledString());
/* 269 */     stringBuffer.append(getReadOnlyString());
/* 270 */     stringBuffer.append(getId());
/* 271 */     stringBuffer.append('>');
/* 272 */     stringBuffer.append(getRenderableValue());
/* 273 */     stringBuffer.append("</textarea>");
/*     */     
/* 275 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormSingleValidation validate() {
/* 290 */     FormSingleValidation formSingleValidation = new FormSingleValidation(this);
/*     */     
/* 292 */     if (isRequired())
/*     */     {
/*     */       
/* 295 */       requiredValidation(formSingleValidation);
/*     */     }
/*     */ 
/*     */     
/* 299 */     customValidation(formSingleValidation);
/*     */     
/* 301 */     return formSingleValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 313 */     if (getStringValue().length() == 0) {
/*     */       
/* 315 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is empty.", 
/* 316 */           "Please provide input in the field named " + getDisplayName() + ".", 
/* 317 */           "Please provide input in this field.");
/*     */     }
/* 319 */     else if (getStringValue().length() > getMaxLength()) {
/*     */       
/* 321 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is too long.", 
/* 322 */           "The value in the field named " + getDisplayName() + " cannot be longer " + 
/* 323 */           "than " + getMaxLength() + " characters.", 
/* 324 */           "The value in this field cannot be longer then " + getMaxLength() + 
/* 325 */           " characters.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 335 */   public boolean isDefault() { return "".equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 345 */   public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 353 */   public int getMaxLength() { return this.maxLength; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 361 */   public void setMaxLength(int paramInt) { this.maxLength = paramInt; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormTextArea.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */