/*    */ package com.techempower.gemini;
/*    */ 
/*    */ import com.techempower.DataEntity;
/*    */ import com.techempower.JdbcConnector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreditCard
/*    */   extends DataEntity
/*    */ {
/*    */   protected int creditCardID;
/*    */   protected int userID;
/*    */   protected short creditCardTypeID;
/*    */   protected String creditCardNumber;
/*    */   protected short creditCardExpirationMonth;
/*    */   protected short creditCardExpirationYear;
/*    */   
/*    */   public String toString() {
/* 43 */     return "creditCardID: " + this.creditCardID + "\n" + 
/* 44 */       "userID: " + this.userID + "\n" + 
/* 45 */       "creditCardTypeID: " + this.creditCardTypeID + "\n" + 
/* 46 */       "creditCardNumber: " + this.creditCardNumber + "\n" + 
/* 47 */       "creditCardExpirationMonth: " + this.creditCardExpirationMonth + "\n" + 
/* 48 */       "creditCardExpirationYear: " + this.creditCardExpirationYear;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] paramArrayOfString) {
/* 60 */     JdbcConnector jdbcConnector = null;
/*    */ 
/*    */     
/*    */     try {
/* 64 */       String str1 = "jdbc:JTurbo://";
/* 65 */       String str2 = "com.ashna.jturbo.driver.Driver";
/* 66 */       String str3 = "eharmony/eharmony/sql70=true";
/*    */       
/* 68 */       JdbcConnector.loadDriver(str2, str1, false, false);
/* 69 */       JdbcConnector.setDefaultJdbcURLPrefix(str1);
/* 70 */       jdbcConnector = new JdbcConnector(str3);
/* 71 */       jdbcConnector.setUsername("eharmony");
/* 72 */       jdbcConnector.setPassword("ehdev");
/* 73 */       jdbcConnector.setQuery("SELECT * FROM ehCreditCard WHERE CreditCardID = 610;");
/* 74 */       jdbcConnector.runQuery();
/*    */       
/* 76 */       CreditCard creditCard = new CreditCard();
/*    */       
/* 78 */       for (byte b = 0; b < 'ᎈ'; b++)
/* 79 */         creditCard.initializeByVariables(jdbcConnector); 
/* 80 */       System.out.println(creditCard.toString());
/*    */     }
/* 82 */     catch (Exception exception) {
/*    */       
/* 84 */       System.out.println("Exception:\n" + exception);
/*    */     }
/*    */     finally {
/*    */       
/* 88 */       if (jdbcConnector != null)
/* 89 */         jdbcConnector.close(); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\CreditCard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */