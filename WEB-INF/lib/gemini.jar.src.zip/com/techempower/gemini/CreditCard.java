package com.techempower.gemini;

import com.techempower.DataEntity;
import com.techempower.JdbcConnector;

public class CreditCard extends DataEntity {
  protected int creditCardID;
  
  protected int userID;
  
  protected short creditCardTypeID;
  
  protected String creditCardNumber;
  
  protected short creditCardExpirationMonth;
  
  protected short creditCardExpirationYear;
  
  public String toString() {
    return "creditCardID: " + this.creditCardID + "\n" + 
      "userID: " + this.userID + "\n" + 
      "creditCardTypeID: " + this.creditCardTypeID + "\n" + 
      "creditCardNumber: " + this.creditCardNumber + "\n" + 
      "creditCardExpirationMonth: " + this.creditCardExpirationMonth + "\n" + 
      "creditCardExpirationYear: " + this.creditCardExpirationYear;
  }
  
  public static void main(String[] paramArrayOfString) {
    JdbcConnector jdbcConnector = null;
    try {
      String str1 = "jdbc:JTurbo://";
      String str2 = "com.ashna.jturbo.driver.Driver";
      String str3 = "eharmony/eharmony/sql70=true";
      JdbcConnector.loadDriver(str2, str1, false, false);
      JdbcConnector.setDefaultJdbcURLPrefix(str1);
      jdbcConnector = new JdbcConnector(str3);
      jdbcConnector.setUsername("eharmony");
      jdbcConnector.setPassword("ehdev");
      jdbcConnector.setQuery("SELECT * FROM ehCreditCard WHERE CreditCardID = 610;");
      jdbcConnector.runQuery();
      CreditCard creditCard = new CreditCard();
      for (byte b = 0; b < 'ᎈ'; b++)
        creditCard.initializeByVariables(jdbcConnector); 
      System.out.println(creditCard.toString());
    } catch (Exception exception) {
      System.out.println("Exception:\n" + exception);
    } finally {
      if (jdbcConnector != null)
        jdbcConnector.close(); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\CreditCard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */