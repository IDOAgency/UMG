package com.techempower.gemini;

import com.techempower.BasicHelper;
import com.techempower.StringList;

public class FormMultiSelectBox extends FormElement {
  public static final String[] DEFAULT_VALUES = null;
  
  public boolean isDefault() { return null.equals(getValues()); }
  
  public static final String[] DEFAULT_SELECTION = null;
  
  protected boolean multipleSelect = true;
  
  protected String[] selections = null;
  
  protected String[] values = null;
  
  protected String[] valueIDs = null;
  
  protected String[] startingSelections = null;
  
  protected String onChangeAction = null;
  
  protected int size = 10;
  
  public FormMultiSelectBox(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean1, boolean paramBoolean2) {
    super(paramString);
    setOptions(paramArrayOfString2);
    setStartingValues(paramArrayOfString1);
    setValues(paramArrayOfString1);
    setMultiple(paramBoolean2);
    if (paramArrayOfString2 != null) {
      setSize(paramArrayOfString2.length);
      this.valueIDs = paramArrayOfString2;
    } 
  }
  
  public FormMultiSelectBox(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean) {
    super(paramString);
    setOptions(paramArrayOfString2);
    setStartingValues(paramArrayOfString1);
    setValues(paramArrayOfString1);
    if (paramArrayOfString2 != null) {
      setSize(paramArrayOfString2.length);
      this.valueIDs = paramArrayOfString2;
    } 
  }
  
  public FormMultiSelectBox(String paramString, String[] paramArrayOfString, boolean paramBoolean) { this(paramString, null, paramArrayOfString, paramBoolean); }
  
  public FormMultiSelectBox(String paramString, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2) { this(paramString, null, paramArrayOfString, paramBoolean1, paramBoolean2); }
  
  public FormMultiSelectBox(String paramString, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString1, String[] paramArrayOfString2) {
    this(paramString, null, paramArrayOfString1, paramBoolean1, paramBoolean2);
    this.valueIDs = paramArrayOfString2;
  }
  
  public boolean isMultiple() { return this.multipleSelect; }
  
  public int getSize() { return this.size; }
  
  public String getAction() { return this.onChangeAction; }
  
  protected String[] getValues() { return this.selections; }
  
  public String[] getStringValues() { return getValues(); }
  
  protected String getValue() {
    if (this.selections != null) {
      StringList stringList = new StringList(", ");
      for (byte b = 0; b < this.selections.length; b++)
        stringList.add(this.selections[b]); 
      return stringList.toString();
    } 
    return "";
  }
  
  public String getStringValue() { return getValue(); }
  
  public String[] getStringOptions() { return this.values; }
  
  public void setOptions(String[] paramArrayOfString) { this.values = paramArrayOfString; }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public FormSingleValidation validate() {
    FormSingleValidation formSingleValidation = new FormSingleValidation(this);
    if (isRequired())
      requiredValidation(formSingleValidation); 
    customValidation(formSingleValidation);
    return formSingleValidation;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    if (getStringValue().length() == 0)
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is unselected.", "Please provide input in the area named " + getDisplayName() + ".", "Please provide input in this field."); 
  }
  
  public void setValue(String paramString) { this.selections = new String[] { paramString }; }
  
  public void setValues(String[] paramArrayOfString) { this.selections = paramArrayOfString; }
  
  public void setValue(Context paramContext) { setValues(paramContext.getRequest().getParameterValues(getName())); }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public void setMultiple(boolean paramBoolean) { this.multipleSelect = paramBoolean; }
  
  public void setAction(String paramString) { this.onChangeAction = paramString; }
  
  public boolean isUnchanged() {
    byte b = 0;
    if (this.startingSelections != null && this.selections != null && this.startingSelections.length == this.selections.length)
      for (byte b1 = 0; b1 < this.startingSelections.length; b1++) {
        for (byte b2 = 0; b2 < this.selections.length; b2++) {
          if (this.startingSelections[b1].equals(this.selections[b2]))
            b++; 
        } 
      }  
    if ((this.startingSelections != null && b == this.startingSelections.length) || (this.startingSelections == null && this.selections == null))
      return true; 
    return false;
  }
  
  public String render() {
    String str = getAction();
    StringBuffer stringBuffer = new StringBuffer(150);
    stringBuffer.append("<select ");
    if (isMultiple())
      stringBuffer.append("multiple "); 
    stringBuffer.append("name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" size=\"");
    stringBuffer.append(this.size);
    stringBuffer.append("\" ");
    if (str != null) {
      stringBuffer.append(" onChange=\"");
      stringBuffer.append(str);
      stringBuffer.append("\" ");
    } 
    stringBuffer.append(' ');
    stringBuffer.append(getClassName());
    stringBuffer.append('>');
    if (this.values != null)
      for (byte b = 0; b < this.values.length; b++) {
        stringBuffer.append("<option name=\"");
        stringBuffer.append(this.values[b]);
        stringBuffer.append("\" value=\"");
        stringBuffer.append(String.valueOf(this.valueIDs[b]) + "\"");
        if (isStartingValue(this.values[b]))
          stringBuffer.append(" selected"); 
        stringBuffer.append('>');
        stringBuffer.append(this.values[b]);
        stringBuffer.append("</option>");
      }  
    stringBuffer.append("</select>");
    return stringBuffer.toString();
  }
  
  public void setStartingValue(String paramString) { this.startingSelections = new String[] { paramString }; }
  
  public void setStartingValues(String[] paramArrayOfString) { this.startingSelections = paramArrayOfString; }
  
  public String getStartingValue() { return this.startingSelections.toString(); }
  
  public String[] getStartingValues() { return this.startingSelections; }
  
  public boolean isStartingValue(String paramString) {
    if (this.startingSelections != null)
      for (byte b = 0; b < this.startingSelections.length; b++) {
        if (this.startingSelections[b].equals(paramString))
          return true; 
      }  
    return false;
  }
  
  public void setSize(int paramInt) { this.size = paramInt; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormMultiSelectBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */