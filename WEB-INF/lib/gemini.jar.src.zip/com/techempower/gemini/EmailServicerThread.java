package com.techempower.gemini;

import com.techempower.EndableThread;
import java.util.Vector;

class EmailServicerThread extends EndableThread {
  GeminiApplication application;
  
  Vector emailPackages = new Vector();
  
  EmailTransport emailTransport;
  
  public EmailServicerThread(int paramInt, GeminiApplication paramGeminiApplication) {
    super("Email servicer thread " + paramInt);
    this.application = paramGeminiApplication;
    this.emailTransport = paramGeminiApplication.getEmailTransport();
  }
  
  public void run() {
    while (isRunning() || this.emailPackages.size() > 0) {
      if (this.emailPackages.size() > 0) {
        EmailPackage emailPackage = (EmailPackage)this.emailPackages.elementAt(0);
        this.emailTransport.sendEmail(emailPackage);
        this.emailPackages.removeElementAt(0);
        setMinimumSleep();
      } else {
        incrementSleep();
      } 
      simpleSleep();
    } 
  }
  
  public boolean queueMail(EmailPackage paramEmailPackage) {
    if (this.emailTransport != null) {
      this.emailPackages.addElement(paramEmailPackage);
      return true;
    } 
    return false;
  }
  
  public int getBacklog() { return this.emailPackages.size(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\EmailServicerThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */