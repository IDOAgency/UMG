/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.LogWriter;
/*     */ import com.techempower.LogWriterCloser;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequestLog
/*     */   implements LogWriter
/*     */ {
/*     */   public static final String COMPONENT_CODE = "reqL";
/*     */   public static final String DEFAULT_REQUESTLOG_DIR = "logs";
/*     */   public static final String DEFAULT_SOFTWARE_NAME = "Servlet-dispatched web application";
/*     */   public static final String DEFAULT_VERSION = "1.0";
/*     */   public static final String DEFAULT_LOGFILE_EXT = ".log";
/*     */   public static final String DEFAULT_LOGFILE_PREFIX = "ex";
/*     */   public static final String FIELDS = "date time c-ip cs-method cs-uri-stem sc-status cs(User-Agent) cs(Referer) cs(Cookie)";
/*  66 */   protected static SimpleDateFormat filenameFormat = new SimpleDateFormat("yyMMdd");
/*  67 */   protected static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  68 */   protected static SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  69 */   protected static TimeZone gmtTimeZone = TimeZone.getTimeZone("GMT");
/*     */ 
/*     */   
/*     */   protected ComponentLog log;
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/*  77 */     filenameFormat.setTimeZone(gmtTimeZone);
/*  78 */     dateFormat.setTimeZone(gmtTimeZone);
/*  79 */     timeFormat.setTimeZone(gmtTimeZone);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   protected String softwareName = "Servlet-dispatched web application";
/*  88 */   protected String version = "1.0";
/*  89 */   protected String logDirectory = "logs" + File.separator;
/*  90 */   protected String logFilenamePre = "ex";
/*  91 */   protected String logFilenameSuf = ".log";
/*  92 */   protected String logFilename = null;
/*  93 */   protected int lastDay = 0;
/*  94 */   protected Calendar cal = Calendar.getInstance(gmtTimeZone);
/*     */   protected boolean enabled = false;
/*     */   protected boolean initialized = false;
/*  97 */   protected FileWriter fileWriter = null;
/*  98 */   protected Object lockObject = new Object();
/*  99 */   protected LogWriterCloser closer = LogWriterCloser.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestLog(String paramString1, String paramString2, String paramString3, ComponentLog paramComponentLog) {
/* 116 */     this.log = paramComponentLog;
/*     */ 
/*     */     
/* 119 */     setSoftwareName(paramString1);
/* 120 */     setVersion(paramString2);
/* 121 */     setLogDirectory(paramString3);
/*     */ 
/*     */ 
/*     */     
/* 125 */     this.closer.addLogWriter(this, String.valueOf(paramString1) + " request log");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public void setSoftwareName(String paramString) { this.softwareName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public void setVersion(String paramString) { this.version = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogDirectory(String paramString) {
/* 158 */     if (paramString.endsWith(File.separator)) {
/* 159 */       this.logDirectory = paramString;
/*     */     } else {
/* 161 */       this.logDirectory = String.valueOf(paramString) + File.separator;
/*     */     } 
/* 163 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public void setLogFilenamePrefix(String paramString) { this.logFilenamePre = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public String getLogFilenamePrefix() { return this.logFilenamePre; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public void setLogFilenameSuffix(String paramString) { this.logFilenameSuf = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public String getLogFilenameSuffix() { return this.logFilenameSuf; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enable() {
/* 205 */     this.enabled = true;
/* 206 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   public void disable() { this.enabled = false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(Context paramContext, String paramString) {
/* 229 */     if (this.enabled) {
/*     */ 
/*     */       
/* 232 */       this.cal = Calendar.getInstance(gmtTimeZone);
/*     */       
/* 234 */       if (needNewFile() || !this.initialized)
/*     */       {
/* 236 */         initialize();
/*     */       }
/*     */ 
/*     */       
/* 240 */       writeLogEntry(String.valueOf(this.logDirectory) + this.logFilename, constructLogItem(paramContext, paramString));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 249 */   public boolean isOpen() { return !(this.fileWriter == null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeFile() {
/* 259 */     synchronized (this.lockObject) {
/*     */ 
/*     */       
/*     */       try {
/* 263 */         if (this.fileWriter != null) {
/* 264 */           this.fileWriter.close();
/*     */         }
/* 266 */       } catch (IOException iOException) {
/*     */         
/* 268 */         this.log.debug("IOException while closing request log!");
/*     */       } 
/* 270 */       this.fileWriter = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeFile(String paramString) {
/* 279 */     this.log.debug(paramString);
/* 280 */     closeFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void openFile(String paramString) {
/*     */     try {
/* 295 */       this.fileWriter = new FileWriter(paramString, true);
/*     */     }
/* 297 */     catch (IOException iOException) {
/*     */       
/* 299 */       this.log.debug("IOException while opening request log!");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeLogEntry(String paramString1, String paramString2) {
/*     */     try {
/* 311 */       this.closer.access(this);
/*     */ 
/*     */       
/* 314 */       synchronized (this.lockObject)
/*     */       {
/* 316 */         if (this.fileWriter == null)
/* 317 */           openFile(paramString1); 
/* 318 */         this.fileWriter.write(paramString2);
/* 319 */         this.fileWriter.flush();
/*     */       }
/*     */     
/* 322 */     } catch (IOException iOException) {
/*     */       
/* 324 */       this.log.debug("Could not write to request log: " + iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String constructLogItem(Context paramContext, String paramString) {
/* 333 */     StringBuffer stringBuffer = new StringBuffer(100);
/*     */     
/* 335 */     stringBuffer.append(timeFormat.format(this.cal.getTime()));
/* 336 */     stringBuffer.append(' ');
/* 337 */     stringBuffer.append(paramContext.getClientIP());
/* 338 */     stringBuffer.append(' ');
/* 339 */     stringBuffer.append(paramContext.getRequestMethod());
/* 340 */     stringBuffer.append(' ');
/* 341 */     stringBuffer.append(paramString);
/* 342 */     stringBuffer.append(" 200 ");
/* 343 */     stringBuffer.append(getContextHeader(paramContext, "User-Agent"));
/* 344 */     stringBuffer.append(' ');
/* 345 */     stringBuffer.append(getContextHeader(paramContext, "Referer"));
/* 346 */     stringBuffer.append(' ');
/* 347 */     stringBuffer.append(paramContext.getCustomCookie());
/* 348 */     stringBuffer.append("\r\n");
/*     */     
/* 350 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getContextHeader(Context paramContext, String paramString) {
/* 359 */     String str = paramContext.getHeader(paramString);
/* 360 */     if (str == null) {
/* 361 */       str = "-";
/*     */     } else {
/* 363 */       str = str.replace(' ', '+');
/*     */     } 
/* 365 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean needNewFile() {
/* 374 */     int i = this.cal.get(5);
/*     */     
/* 376 */     if (i != this.lastDay) {
/*     */       
/* 378 */       this.lastDay = i;
/* 379 */       return true;
/*     */     } 
/*     */     
/* 382 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize() {
/* 391 */     this.initialized = true;
/*     */     
/* 393 */     String str = filenameFormat.format(this.cal.getTime());
/*     */ 
/*     */     
/* 396 */     this.logFilename = String.valueOf(this.logFilenamePre) + str + this.logFilenameSuf;
/*     */ 
/*     */     
/* 399 */     File file = new File(String.valueOf(this.logDirectory) + this.logFilename);
/* 400 */     this.log.log("Setting request log file to: " + this.logFilename);
/*     */     
/* 402 */     if (!file.exists()) {
/*     */       
/* 404 */       synchronized (this.lockObject)
/*     */       {
/*     */         
/* 407 */         closeFile();
/* 408 */         openFile(String.valueOf(this.logDirectory) + this.logFilename);
/*     */ 
/*     */         
/* 411 */         writeHeader(this.cal);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 416 */       this.log.log("Request log file already exists.  Appending.");
/*     */       
/* 418 */       synchronized (this.lockObject) {
/*     */ 
/*     */         
/* 421 */         closeFile();
/* 422 */         openFile(String.valueOf(this.logDirectory) + this.logFilename);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeHeader(Calendar paramCalendar) {
/*     */     try {
/* 436 */       synchronized (this.lockObject)
/*     */       {
/* 438 */         this.fileWriter.write("#Software: " + this.softwareName + "\r\n");
/* 439 */         this.fileWriter.write("#Version: " + this.version + "\r\n");
/* 440 */         this.fileWriter.write("#Date: " + dateFormat.format(paramCalendar.getTime()) + "\r\n");
/* 441 */         this.fileWriter.write("#Fields: date time c-ip cs-method cs-uri-stem sc-status cs(User-Agent) cs(Referer) cs(Cookie)\r\n");
/* 442 */         this.fileWriter.flush();
/*     */       }
/*     */     
/* 445 */     } catch (IOException iOException) {
/*     */       
/* 447 */       this.log.debug("Could not write request log header: " + iOException);
/*     */     } 
/*     */   }
/*     */   
/*     */   public RequestLog() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\RequestLog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */