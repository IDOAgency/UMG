package com.techempower.gemini;

public class FormPasswordField extends FormTextField {
  public FormPasswordField(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2) { super(paramString1, paramString2, paramBoolean, paramInt1, paramInt2); }
  
  public FormPasswordField(String paramString1, String paramString2, boolean paramBoolean, int paramInt) { this(paramString1, paramString2, paramBoolean, paramInt, paramInt); }
  
  public FormPasswordField(String paramString, boolean paramBoolean, int paramInt) { this(paramString, "", paramBoolean, paramInt); }
  
  public FormPasswordField(String paramString, int paramInt) { this(paramString, "", false, paramInt); }
  
  public FormPasswordField(String paramString) { this(paramString, "", false, 20); }
  
  public String render() {
    StringBuffer stringBuffer = new StringBuffer(60);
    stringBuffer.append("<input type=\"password\"");
    stringBuffer.append(getClassName());
    stringBuffer.append(" name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" value=\"");
    stringBuffer.append(getRenderableValue());
    stringBuffer.append("\" size=\"");
    stringBuffer.append(getLength());
    stringBuffer.append("\" maxlength=\"");
    stringBuffer.append(getMaxLength());
    stringBuffer.append("\"");
    stringBuffer.append(getTabIndex());
    stringBuffer.append(getFormEvents());
    stringBuffer.append(getEnabledString());
    stringBuffer.append(getReadOnlyString());
    stringBuffer.append(getId());
    stringBuffer.append('>');
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormPasswordField.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */