package com.techempower.gemini;

import com.techempower.ComponentLog;
import com.techempower.EnhancedProperties;
import com.techempower.Version;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

public class Configurator implements GeminiConstants {
  public static final String COMPONENT_CODE = "conf";
  
  public static final String CONFIGURATION_FILENAME_EXT = ".conf";
  
  protected boolean configured;
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  protected Configurator(GeminiApplication paramGeminiApplication) {
    this.configured = false;
    this.application = null;
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("conf");
  }
  
  public void configure() {
    Version version = this.application.getVersion();
    this.log.debug("Configuring " + version.getProductName() + " system.");
    try {
      String str = String.valueOf(version.getProductName()) + ".conf";
      InputStream inputStream = ClassLoader.getSystemResourceAsStream(str);
      if (inputStream == null)
        inputStream = new FileInputStream(str); 
      EnhancedProperties enhancedProperties = new EnhancedProperties(this.application);
      enhancedProperties.load(inputStream);
      inputStream.close();
      configureWithProps(enhancedProperties, version);
      this.configured = true;
      this.log.log("Configuration complete.");
    } catch (IOException iOException) {
      this.log.debug("Cannot read configuration file: " + iOException);
    } 
  }
  
  protected File findConfigurationFile(String paramString) {
    String str1 = String.valueOf(paramString) + ".conf";
    File file = new File(str1);
    if (file.exists())
      return file; 
    String str2 = System.getProperty("java.class.path");
    StringTokenizer stringTokenizer = new StringTokenizer(str2, ";");
    while (stringTokenizer.hasMoreTokens()) {
      String str = stringTokenizer.nextToken();
      if (!str.endsWith(".jar") && 
        !str.endsWith(".zip")) {
        if (!str.endsWith(File.separator))
          str = String.valueOf(str) + File.separator; 
        file = new File(String.valueOf(str) + str1);
        if (file.exists())
          return file; 
      } 
    } 
    return null;
  }
  
  public void configureIfNecessary() {
    if (!isConfigured())
      configure(); 
  }
  
  public boolean isConfigured() { return this.configured; }
  
  protected void configureWithProps(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
    this.application.getApplicationLog().configure(paramEnhancedProperties, paramVersion);
    this.application.getSessionManager().configure(paramEnhancedProperties);
    this.application.getBugTool().configure(paramEnhancedProperties, paramVersion);
    if (this.application.getEmailServicer() != null)
      this.application.getEmailServicer().configure(paramEnhancedProperties); 
    if (this.application.getEmailTransport() != null)
      this.application.getEmailTransport().configure(paramEnhancedProperties); 
    if (this.application.getEmailTemplater() != null)
      this.application.getEmailTemplater().configure(paramEnhancedProperties); 
    if (this.application.getFornaxSettings() != null)
      this.application.getFornaxSettings().configure(paramEnhancedProperties); 
    if (this.application.getSecurity() != null)
      this.application.getSecurity().configure(paramEnhancedProperties); 
    customConfiguration(paramEnhancedProperties, paramVersion);
  }
  
  protected void customConfiguration(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
    this.log.debug("Default custom configuration called.");
    this.application.getInfrastructure().configure(paramEnhancedProperties, paramVersion);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\Configurator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */