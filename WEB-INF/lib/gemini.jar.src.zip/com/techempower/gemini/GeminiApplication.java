/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.TechEmpowerApplication;
/*     */ import com.techempower.gemini.fornax.FornaxSettings;
/*     */ import com.techempower.gemini.pyxis.BasicSecurity;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeminiApplication
/*     */   extends TechEmpowerApplication
/*     */   implements GeminiConstants
/*     */ {
/*  89 */   protected BasicInfrastructure infrastructure = constructInfrastructure();
/*  90 */   protected Configurator configurator = constructConfigurator();
/*  91 */   protected Dispatcher dispatcher = constructDispatcher();
/*  92 */   protected SessionManager sessionManager = constructSessionManager();
/*  93 */   protected BugTool bugTool = constructBugTool();
/*  94 */   protected EmailServicer emailServicer = constructEmailServicer();
/*  95 */   protected EmailTemplater emailTemplater = constructEmailTemplater();
/*  96 */   protected EmailTransport emailTransport = constructEmailTransport();
/*  97 */   protected FornaxSettings fornaxSettings = constructFornaxSettings();
/*  98 */   protected BasicSecurity security = constructSecurity();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static GeminiApplication instance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   protected BasicInfrastructure constructInfrastructure() { return new BasicInfrastructure(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   protected Configurator constructConfigurator() { return new Configurator(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   protected Dispatcher constructDispatcher() { return new Dispatcher(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   protected SessionManager constructSessionManager() { return new SessionManager(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   protected BugTool constructBugTool() { return new BugTool(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   protected EmailServicer constructEmailServicer() { return new EmailServicer(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   protected EmailTransport constructEmailTransport() { return new EmailTransport(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   protected EmailTemplater constructEmailTemplater() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   protected FornaxSettings constructFornaxSettings() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   protected BasicSecurity constructSecurity() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 228 */   public BasicInfrastructure getInfrastructure() { return this.infrastructure; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   public Configurator getConfigurator() { return this.configurator; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public Dispatcher getDispatcher() { return this.dispatcher; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public EmailServicer getEmailServicer() { return this.emailServicer; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public EmailTransport getEmailTransport() { return this.emailTransport; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 268 */   public EmailTemplater getEmailTemplater() { return this.emailTemplater; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   public FornaxSettings getFornaxSettings() { return this.fornaxSettings; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 284 */   public BasicSecurity getSecurity() { return this.security; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 296 */   public Context getContext(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, ServletContext paramServletContext) { return new Context(paramHttpServletRequest, paramHttpServletResponse, paramServletContext, this.dispatcher); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 304 */   public BugTool getBugTool() { return this.bugTool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 312 */   public SessionManager getSessionManager() { return this.sessionManager; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   public final String getGeminiVersion() { return "1.14"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GeminiApplication getInstance() {
/* 332 */     if (instance == null)
/* 333 */       instance = new GeminiApplication(); 
/* 334 */     return instance;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\GeminiApplication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */