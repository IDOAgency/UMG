package com.techempower.gemini;

import com.techempower.BasicHelper;
import java.util.StringTokenizer;
import java.util.Vector;

public class FormRadioButtonGroup extends FormElement {
  public static final String[] DEFAULT_VALUES = new String[0];
  
  public static final String DEFAULT_SELECTION = "";
  
  protected String selection;
  
  protected Vector values;
  
  protected Vector labels;
  
  protected String startingSelection;
  
  protected boolean incrementTabIndex = true;
  
  protected boolean showLabels = true;
  
  public FormRadioButtonGroup(String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean) {
    super(paramString1, paramString2, paramBoolean);
    setLabelList(paramArrayOfString2);
    setValueList(paramArrayOfString1);
  }
  
  public FormRadioButtonGroup(String paramString1, String paramString2, String[] paramArrayOfString, boolean paramBoolean) {
    super(paramString1, paramString2, paramBoolean);
    setValueList(paramArrayOfString);
  }
  
  public FormRadioButtonGroup(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    super(paramString1, paramString2, paramBoolean);
    setValueList(paramString3);
  }
  
  public FormRadioButtonGroup(String paramString1, String paramString2, boolean paramBoolean) { this(paramString1, "", paramString2, paramBoolean); }
  
  public FormRadioButtonGroup(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean) { this(paramString, "", paramArrayOfString1, paramArrayOfString2, paramBoolean); }
  
  public FormRadioButtonGroup(String paramString, String[] paramArrayOfString, boolean paramBoolean) { this(paramString, "", paramArrayOfString, paramBoolean); }
  
  public FormRadioButtonGroup(String paramString1, String paramString2) { this(paramString1, "", paramString2, false); }
  
  public FormRadioButtonGroup(String paramString) { this(paramString, "", DEFAULT_VALUES, false); }
  
  public void setValue(String paramString) {
    if (!isReadOnly())
      this.selection = paramString; 
  }
  
  public void setValueList(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
    int i = stringTokenizer.countTokens();
    boolean bool = false;
    this.values = new Vector(i);
    while (stringTokenizer.hasMoreTokens())
      this.values.addElement(stringTokenizer.nextToken().trim()); 
  }
  
  public void setValueList(String[] paramArrayOfString) {
    this.values = new Vector(paramArrayOfString.length);
    for (byte b = 0; b < paramArrayOfString.length; b++)
      this.values.addElement(paramArrayOfString[b]); 
  }
  
  public void setLabelList(String[] paramArrayOfString) {
    if (paramArrayOfString != null) {
      this.labels = new Vector(paramArrayOfString.length);
      for (byte b = 0; b < paramArrayOfString.length; b++)
        this.labels.addElement(paramArrayOfString[b]); 
    } else {
      setShowLabels(false);
    } 
  }
  
  public void setStartingValue(String paramString) { this.startingSelection = paramString; }
  
  public String getStartingValue() { return this.startingSelection; }
  
  public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.selection)); }
  
  protected String getValue() { return this.selection; }
  
  public String getStringValue() { return getValue(); }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public int getIntegerValue() { return 0; }
  
  public String[] getValueList() {
    null = new String[this.values.size()];
    return (String[])this.values.toArray(null);
  }
  
  public Vector getValuesVector() { return this.values; }
  
  public String render() {
    StringBuffer stringBuffer = new StringBuffer(100);
    for (byte b = 0; b < this.values.size(); b++)
      stringBuffer.append(renderSingle(b)); 
    return stringBuffer.toString();
  }
  
  public String renderSingle(int paramInt) {
    if (paramInt >= 0 && 
      paramInt < this.values.size()) {
      String str = (String)this.values.elementAt(paramInt);
      StringBuffer stringBuffer = new StringBuffer(50);
      stringBuffer.append("<input type=\"radio\" name=\"");
      stringBuffer.append(getName());
      stringBuffer.append("\" value=\"");
      stringBuffer.append(str);
      stringBuffer.append('"');
      if (str.equals(getStringValue()))
        stringBuffer.append(" checked"); 
      stringBuffer.append(getElementTabIndexString(paramInt));
      stringBuffer.append(getFormEvents());
      stringBuffer.append(getEnabledString());
      stringBuffer.append(getId());
      stringBuffer.append('>');
      if (this.showLabels)
        if (this.labels != null) {
          String str1 = (String)this.labels.elementAt(paramInt);
          stringBuffer.append(str1);
        } else {
          stringBuffer.append(str);
        }  
      return stringBuffer.toString();
    } 
    return "";
  }
  
  public String renderSingle(String paramString) {
    for (byte b = 0; b < this.values.size(); b++) {
      String str = (String)this.values.elementAt(b);
      if (str.equals(paramString))
        return renderSingle(b); 
    } 
    return "";
  }
  
  public FormSingleValidation validate() {
    FormSingleValidation formSingleValidation = new FormSingleValidation(this);
    if (isRequired())
      requiredValidation(formSingleValidation); 
    customValidation(formSingleValidation);
    return formSingleValidation;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    if (getStringValue().length() == 0)
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is unselected.", 
          "Please provide input in the area named " + getDisplayName() + ".", 
          "Please provide input in this field."); 
  }
  
  public boolean isDefault() { return DEFAULT_VALUES.equals(getValue()); }
  
  public boolean isUnchanged() { return this.startingSelection.equals(getValue()); }
  
  public boolean isIncrementTabIndex() { return this.incrementTabIndex; }
  
  public void setShowLabels(boolean paramBoolean) { this.showLabels = paramBoolean; }
  
  public boolean setIncrementTabIndex(boolean paramBoolean) { return this.incrementTabIndex = paramBoolean; }
  
  private String getElementTabIndexString(int paramInt) {
    if (isIncrementTabIndex() && this.tabIndex >= 0)
      return " tabindex=\"" + (this.tabIndex + paramInt) + "\" "; 
    return "";
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormRadioButtonGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */