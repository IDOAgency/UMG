package com.techempower.gemini;

import com.techempower.ComponentLog;
import com.techempower.Version;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class InfrastructureServlet extends HttpServlet implements GeminiConstants {
  public static final String COMPONENT_CODE = "svlt";
  
  protected GeminiApplication application = getApplication();
  
  protected ComponentLog log = this.application.getLog("svlt");
  
  protected Version version = this.application.getVersion();
  
  public void init() {
    displayBanner();
    this.log.debug("Starting up.");
    configure();
  }
  
  public GeminiApplication getApplication() { return GeminiApplication.getInstance(); }
  
  public void configure() { this.application.getConfigurator().configureIfNecessary(); }
  
  public void destroy() { super.destroy(); }
  
  public void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    Context context = this.application.getContext(paramHttpServletRequest, paramHttpServletResponse, 
        getServletContext());
    handleRequest(context, true);
  }
  
  public void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse) throws ServletException, IOException {
    Context context = this.application.getContext(paramHttpServletRequest, paramHttpServletResponse, 
        getServletContext());
    handleRequest(context, false);
  }
  
  public void handleRequest(Context paramContext, boolean paramBoolean) {}
  
  public String getServletName() { return String.valueOf(this.version.getProductName()) + " Servlet version " + this.version.getVersionString(); }
  
  public String getServletInfo() {
    return String.valueOf(getServletName()) + 
      " - Copyright (c) " + this.version.getCopyrightYears() + 
      " " + this.version.getClientName() + 
      " - developed by " + this.version.getDeveloperName() + ".";
  }
  
  protected void displayBanner() { this.log.debug(getServletName()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\InfrastructureServlet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */