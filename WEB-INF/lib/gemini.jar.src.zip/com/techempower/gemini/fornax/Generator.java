/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Generator
/*     */   implements FornaxDBConstants, FornaxSQLStatements
/*     */ {
/*     */   boolean debug;
/*     */   FornaxSettings mSettings;
/*     */   protected Report mReport;
/*     */   
/*     */   public Generator(FornaxSettings paramFornaxSettings) {
/*  34 */     this.debug = true;
/*     */     
/*  36 */     this.mSettings = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  46 */     this.mSettings = paramFornaxSettings;
/*  47 */     this.mReport = (new ReportManager(this.mSettings)).getReport();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startGeneration() {
/*  74 */     Vector vector1 = new Vector();
/*  75 */     Vector vector2 = new Vector();
/*  76 */     Vector vector3 = new Vector();
/*  77 */     Vector vector4 = new Vector();
/*  78 */     DataObjectManager dataObjectManager = new DataObjectManager(this.mSettings);
/*  79 */     DBRecordManager dBRecordManager = new DBRecordManager();
/*     */ 
/*     */     
/*  82 */     GeneratorFileManager generatorFileManager = new GeneratorFileManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     vector1 = dataObjectManager.buildContentInfo();
/*  94 */     Hashtable hashtable1 = dataObjectManager.getGroupTable();
/*  95 */     Hashtable hashtable2 = dataObjectManager.getContentTypeTable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     this.mReport.startReport();
/*     */ 
/*     */ 
/*     */     
/* 107 */     for (byte b = 0; b < vector1.size(); b++) {
/*     */       
/* 109 */       ContentType contentType = (ContentType)vector1.elementAt(b);
/*     */ 
/*     */       
/* 112 */       if (this.mSettings.isMultiGroup())
/*     */       {
/*     */         
/* 115 */         this.mReport.startContentTypeReport(contentType);
/*     */       }
/*     */ 
/*     */       
/* 119 */       vector2 = contentType.getGroups();
/*     */ 
/*     */       
/* 122 */       for (byte b1 = 0; b1 < vector2.size(); b1++) {
/*     */         
/* 124 */         ContentTypeInstanceGroup contentTypeInstanceGroup = (ContentTypeInstanceGroup)vector2.elementAt(b1);
/*     */         
/* 126 */         vector4 = contentTypeInstanceGroup.getGroupVariants();
/*     */ 
/*     */         
/* 129 */         this.mReport.startContentTypeGroupReport(contentTypeInstanceGroup);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 138 */         this.mReport.startListPageReport();
/*     */ 
/*     */         
/* 141 */         this.mReport.addNewListPageLineReport();
/*     */ 
/*     */ 
/*     */         
/* 145 */         VariantGenerationManager variantGenerationManager = new VariantGenerationManager(null, hashtable2, this);
/*     */ 
/*     */         
/* 148 */         variantGenerationManager.setListPage(contentTypeInstanceGroup.getGroupListPage());
/*     */         
/* 150 */         if (contentTypeInstanceGroup.isListPageGenerated()) {
/*     */ 
/*     */ 
/*     */           
/* 154 */           if (this.debug)
/*     */           {
/* 156 */             System.out.println("  List page generation START ");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 161 */           variantGenerationManager.setInstances(contentTypeInstanceGroup.getGroupContentTypeInstances());
/*     */ 
/*     */           
/* 164 */           variantGenerationManager.loadTemplate(contentTypeInstanceGroup.getGroupListPage().getListPageTemplate(), true);
/*     */ 
/*     */           
/* 167 */           variantGenerationManager.generateListPage();
/*     */           
/* 169 */           if (this.debug)
/*     */           {
/* 171 */             System.out.println("  List Page generation END ");
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 178 */           variantGenerationManager.deleteListPage();
/* 179 */           this.mReport.updateLine("File not generated", " ");
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 188 */         this.mReport.startContentItemReport();
/*     */ 
/*     */ 
/*     */         
/* 192 */         for (byte b2 = 0; b2 < vector4.size(); b2++) {
/*     */           
/* 194 */           Variant variant = (Variant)vector4.elementAt(b2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 203 */           System.out.println("************   GENERATION START FOR GROUP [" + contentTypeInstanceGroup.getGroupName() + "]  *****************");
/*     */ 
/*     */ 
/*     */           
/* 207 */           if (this.debug)
/*     */           {
/* 209 */             System.out.println("  VariantID = [" + variant.getVariantID() + "]");
/*     */           }
/*     */ 
/*     */           
/* 213 */           this.mReport.addSpacerLine();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 220 */           if (this.debug)
/*     */           {
/* 222 */             System.out.println("  Generation of content pages START ");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 227 */           VariantGenerationManager variantGenerationManager1 = new VariantGenerationManager(variant, hashtable2, this);
/*     */ 
/*     */           
/* 230 */           variantGenerationManager1.setInstances(contentTypeInstanceGroup.getGroupContentTypeInstances());
/*     */ 
/*     */           
/* 233 */           variantGenerationManager1.setContentType(contentType);
/*     */ 
/*     */           
/* 236 */           variantGenerationManager1.setSingletonFlag(contentTypeInstanceGroup.isSingleton());
/*     */ 
/*     */           
/* 239 */           if (contentTypeInstanceGroup.isInstanceGenerationEnabled() && variant.isEnabledForGeneration()) {
/*     */ 
/*     */             
/* 242 */             variantGenerationManager1.loadTemplate(variant.getVariantTemplate(), false);
/*     */ 
/*     */             
/* 245 */             variantGenerationManager1.generate();
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 252 */             this.mReport.noInstanceFileGeneration();
/* 253 */             variantGenerationManager1.deleteInstanceFiles();
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 258 */           if (this.debug)
/*     */           {
/* 260 */             System.out.println("  Generation of content pages END  ");
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 267 */         this.mReport.addSpacerLine();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 276 */     this.mReport.addSpacerLine();
/* 277 */     this.mReport.endReport();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 287 */   public Report getReport() { return this.mReport; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   public String getReportString() { return this.mReport.getHTMLReportString(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\Generator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */