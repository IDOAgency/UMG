package com.techempower.gemini.fornax;

import com.techempower.gemini.GeminiConstants;

public interface FornaxConstants extends GeminiConstants {
  public static final String FORNAX_PREFIX = "Fornax.";
  
  public static final String FORNAX_CMD_PREFIX = "fornax-";
  
  public static final String SHORT_FORNAX_PREFIX = "fn";
  
  public static final String SORT_ASCENDING_INDICATOR = "icon-up.gif";
  
  public static final String SORT_DESCENDING_INDICATOR = "icon-down.gif";
  
  public static final String CURRENT_TIMESTAMP = "CURRENT_TIMESTAMP";
  
  public static final String TRUE = "T";
  
  public static final String FALSE = "F";
  
  public static final int NULL_ID_AS_INT = -1;
  
  public static final String NULL_ID_AS_STRING = "-1";
  
  public static final String NULL_DATETIME = "1900-01-01 00:00:00AM";
  
  public static final String NULL_STRING = "";
  
  public static final int DEFAULT_STARTING_PAGE_NUMBER = 1;
  
  public static final int DEFAULT_DATE_TIME_FIELD_LENGTH = 26;
  
  public static final int DEFAULT_INT_FIELD_LENGTH = 10;
  
  public static final int DEFAULT_INT_FIELD_LENGTH_ALT_IE = 15;
  
  public static final int DEFAULT_INT_FIELD_MAX_LENGTH = 15;
  
  public static final int DEFAULT_FLOAT_FIELD_LENGTH = 10;
  
  public static final int DEFAULT_FLOAT_FIELD_LENGTH_ALT_IE = 15;
  
  public static final int DEFAULT_FLOAT_FIELD_MAX_LENGTH = 25;
  
  public static final int DEFAULT_STRING_FIELD_LENGTH = 23;
  
  public static final int DEFAULT_STRING_FIELD_LENGTH_ALT_IE = 40;
  
  public static final int DEFAULT_TEXT_AREA_ROWS = 10;
  
  public static final int DEFAULT_TEXT_AREA_COLS = 28;
  
  public static final int DEFAULT_TEXT_AREA_COLS_ALT_IE = 55;
  
  public static final String DEFAULT_TEXT_AREA_WRAP_MODE = "virtual";
  
  public static final int MAX_TEXT_FIELD_CHARACTER_LENGTH = 50;
  
  public static final int MAX_FILEPATH_FIELD_CHARACTER_LENGTH = 500;
  
  public static final String DATETIME = "DATE";
  
  public static final String INTEGER = "INTEGER";
  
  public static final String FLOATINGPOINT = "FLOATINGPOINT";
  
  public static final String STRING = "STRING";
  
  public static final int VALUE_INSTANCES_LIST_UPDATE = 1;
  
  public static final int VALUE_INSTANCE_ADD = 0;
  
  public static final int VALUE_INSTANCE_COPY = 1;
  
  public static final int VALUE_INSTANCE_EDIT = 2;
  
  public static final int DEFAULT_EDIT_MODE = 0;
  
  public static final int VALUE_EDIT_ACTION_SAVE = 0;
  
  public static final int VALUE_EDIT_ACTION_ERROR = 1;
  
  public static final int DEFAULT_EDIT_ACTION = 0;
  
  public static final int PAGE_BACKWARD = -1;
  
  public static final int PAGE_PRESERVE = 0;
  
  public static final int PAGE_FORWARD = 1;
  
  public static final int FETCH_ALL_OBJECT_PAGES = 0;
  
  public static final int PAGE_FIRST = -1;
  
  public static final int PAGE_LAST = -2;
  
  public static final int SORT_ASCENDING = 0;
  
  public static final int SORT_DESCENDING = 1;
  
  public static final int CT_SORT_BY_ID = 0;
  
  public static final int CT_SORT_BY_NAME = 1;
  
  public static final int CT_SORT_BY_INSTANCES_COUNT = 2;
  
  public static final int CTI_SORT_BY_ID = 0;
  
  public static final int CTI_SORT_BY_NAME = 1;
  
  public static final int CTI_SORT_BY_DATE_LAST_MODIFIED = 2;
  
  public static final String FORM_SUBMIT_BUTTON = "submit-button";
  
  public static final String FORM_CANCEL_BUTTON = "cancel-button";
  
  public static final String FORM_INSTANCE_ID = "instance-id";
  
  public static final String FORM_INSTANCE_CONTENT_TYPE_ID = "instance-content-type-id";
  
  public static final String FORM_INSTANCE_NAME = "instance-name";
  
  public static final String FORM_INSTANCE_DESCRIPTION = "instance-description";
  
  public static final String FORM_INSTANCE_DISABLED = "instance-disabled";
  
  public static final String FORM_INSTANCE_QUEUED_FOR_DELETION = "instance-queued-for-deletion";
  
  public static final String FORM_GROUP_LISTPAGE_GENERATE = "listPage-generate";
  
  public static final String FORM_VARIANT_ENABLED = "variant-enabled";
  
  public static final String FORM_VARIANT_NUMERING_MODE = "variant-numbering-mode";
  
  public static final String FORM_FILE_PATH = "file-path";
  
  public static final String FORM_CONTENTTYPE_LISTPAGE_GENERATE = "content-type-listPage-generate";
  
  public static final String LISTPAGE_GENERATE_DROPDOWN_VALUES = "T, F";
  
  public static final String LISTPAGE_GENERATE_DROPDOWN_TEXT = "Yes, No";
  
  public static final String VARIANT_NUMBERINGMODE_DROPDOWN_VALUES = "S,I,N";
  
  public static final String VARIANT_NUMBERINGMODE_DROPDOWN_TEXT = "Sequential,By ID,None";
  
  public static final String CLASS_CONTENT_TEXT = "contentText";
  
  public static final String CLASS_CONTENT_TEXT_REQUIRED = "contentText";
  
  public static final String JAVA_PACKAGE_NAME = "com.techempower.gemini.fornax";
  
  public static final String CMD_LOGIN = "login";
  
  public static final String CMD_MAIN_MENU = "main-menu";
  
  public static final String CMD_CONTENT_MANAGEMENT_PREFIX = "content-";
  
  public static final String CMD_CONTENT_TYPES_MANAGE = "content-type-list";
  
  public static final String CMD_CONTENT_TYPE_INSTANCES_LIST = "content-type-instances-list";
  
  public static final String CMD_CONTENT_TYPE_INSTANCE_EDIT = "content-editor";
  
  public static final String CMD_GENERATION_MANAGEMENT_PREFIX = "generation-";
  
  public static final String CMD_GENERATION_MANAGE = "generation-management";
  
  public static final String CMD_GENERATION_RUN = "generation-run";
  
  public static final String PARM_LOGOUT = "logout";
  
  public static final String PARM_INSTANCES_LIST_MODE = "instances-list-mode";
  
  public static final String PARM_CONTENT_TYPE_ID = "content-type-id";
  
  public static final String PARM_CONTENT_TYPE_EDIT_MODE = "edit-mode";
  
  public static final String PARM_CONTENT_TYPE_EDIT_ACTION = "edit-action";
  
  public static final String PARM_CONTENT_TYPE_INSTANCE_ID = "instance-id";
  
  public static final String PARM_CURRENT_PAGE_NUMBER = "current-page";
  
  public static final String PARM_NUMBER_OF_PAGES = "number-of-pages";
  
  public static final String PARM_PAGING_MODE = "paging-mode";
  
  public static final String PARM_SORT_MODE = "sort-mode";
  
  public static final String PARM_SORT_DIRECTION = "sort-direction";
  
  public static final String JSP_LOGIN = "login.jsp";
  
  public static final String JSP_MAIN_MENU = "main-menu.jsp";
  
  public static final String JSP_CONTENT_TYPE_MANAGEMENT = "content-type-list.jsp";
  
  public static final String JSP_CONTENT_TYPE_INSTANCES_LIST = "content-type-instances-list.jsp";
  
  public static final String JSP_CONTENT_TYPE_INSTANCE_EDIT = "content-editor.jsp";
  
  public static final String JSP_GENERATION_MANAGEMENT = "generation-management.jsp";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */