package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.Context;
import com.techempower.gemini.Dispatcher;
import com.techempower.gemini.Form;
import com.techempower.gemini.FormSubmitButton;
import com.techempower.gemini.FormValidation;
import com.techempower.gemini.GeminiApplication;
import com.techempower.gemini.GeminiHelper;
import com.techempower.gemini.Handler;
import com.techempower.gemini.pyxis.BasicSecurity;
import com.techempower.gemini.pyxis.BasicUser;
import java.util.ArrayList;
import java.util.Vector;

public class FornaxNavigationHandler implements Handler, FornaxConstants {
  public static final String COMPONENT_CODE = "hLog";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected String navigationCommandPrefix;
  
  public FornaxNavigationHandler(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("hLog");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
    this.navigationCommandPrefix = new String(String.valueOf(paramGeminiApplication.getInfrastructure().getServletURL()) + "?" + "cmd" + "=" + "fornax-");
  }
  
  public String getDescription() { return "NavigationManagement"; }
  
  public boolean acceptRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
    BasicSecurity basicSecurity = this.fornaxSettings.getSecurity();
    if (basicSecurity != null && basicSecurity.isLoggedIn(paramContext)) {
      if (paramString.equalsIgnoreCase("fornax-login") || 
        paramString.equalsIgnoreCase("fornax-main-menu") || 
        paramString.equalsIgnoreCase("fornax-content-type-list") || 
        paramString.equalsIgnoreCase("fornax-content-type-instances-list") || 
        paramString.equalsIgnoreCase("fornax-content-editor") || 
        paramString.equalsIgnoreCase("fornax-generation-management"))
        return handleRequest(paramDispatcher, paramContext, paramString); 
      return false;
    } 
    return paramDispatcher.redispatch(paramContext, "fornax-login");
  }
  
  public boolean handleRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
    if (paramString.equalsIgnoreCase("fornax-login"))
      return paramContext.includeJSP("login.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix()); 
    if (paramString.equalsIgnoreCase("fornax-main-menu")) {
      buildMainMenuElements(paramContext);
      return paramContext.includeJSP("main-menu.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
    } 
    if (paramString.equalsIgnoreCase("fornax-content-type-list")) {
      buildContentTypesManagementElements(paramContext);
      return paramContext.includeJSP("content-type-list.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
    } 
    if (paramString.equalsIgnoreCase("fornax-content-type-instances-list")) {
      buildContentTypeInstancesListElements(paramContext);
      return paramContext.includeJSP("content-type-instances-list.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
    } 
    if (paramString.equalsIgnoreCase("fornax-content-editor")) {
      if (buildContentTypeInstanceEditElements(paramDispatcher, paramContext))
        return paramContext.includeJSP("content-editor.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix()); 
      paramContext.removeDelivery("Form");
      return paramDispatcher.redispatch(paramContext, "fornax-content-type-instances-list");
    } 
    if (paramString.equalsIgnoreCase("fornax-generation-management")) {
      if (buildGenerationManagementElements(paramContext))
        return paramContext.includeJSP("generation-management.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix()); 
      paramContext.removeDelivery("Form");
      return paramDispatcher.redispatch(paramContext, "fornax-generation-run");
    } 
    return false;
  }
  
  protected void buildMainMenuElements(Context paramContext) {
    BasicUser basicUser = this.fornaxSettings.getSecurity().getLogin(paramContext);
    String str = new String("");
    if (basicUser != null)
      str = String.valueOf(basicUser.getUserFirstname()) + " " + basicUser.getUserLastname(); 
    paramContext.putDelivery("LinkContentManagement", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list"));
    paramContext.putDelivery("LinkGenerationManagement", new String(String.valueOf(this.navigationCommandPrefix) + "generation-management"));
    paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
    paramContext.putDelivery("LoggedInUserName", str);
  }
  
  protected void buildContentTypesManagementElements(Context paramContext) {
    int i = paramContext.getIntRequestValue("sort-mode", 0);
    int j = paramContext.getIntRequestValue("sort-direction", 0);
    paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
    paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
    paramContext.putDelivery("LinkContentTypeInstancesList", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "="));
    paramContext.putDelivery("LinkSortByID", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list" + "&" + "sort-mode" + "=" + Character.MIN_VALUE + "&" + "sort-direction" + "="));
    paramContext.putDelivery("LinkSortByName", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list" + "&" + "sort-mode" + "=" + '\001' + "&" + "sort-direction" + "="));
    paramContext.putDelivery("LinkSortByInstancesCount", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list" + "&" + "sort-mode" + "=" + '\002' + "&" + "sort-direction" + "="));
    FornaxContentTypeManager fornaxContentTypeManager = new FornaxContentTypeManager(this.application);
    paramContext.putDelivery("ContentTypes", fornaxContentTypeManager.getContentTypes(0, i, j));
    paramContext.putDelivery("sort-mode", new Integer(i));
    paramContext.putDelivery("sort-direction", new Integer(j));
  }
  
  protected void buildContentTypeInstancesListElements(Context paramContext) {
    int i = paramContext.getIntRequestValue("content-type-id", -1);
    int j = paramContext.getIntRequestValue("instances-list-mode", -1);
    int k = paramContext.getIntRequestValue("paging-mode", 0);
    int m = paramContext.getIntRequestValue("current-page", 1) + k;
    int n = paramContext.getIntRequestValue("sort-mode", 0);
    int i1 = paramContext.getIntRequestValue("sort-direction", 0);
    FornaxContentTypeManager fornaxContentTypeManager = new FornaxContentTypeManager(this.application);
    FornaxContentTypeInstanceManager fornaxContentTypeInstanceManager = new FornaxContentTypeInstanceManager(this.application);
    int i2 = m;
    if (m == -1) {
      m = 1;
    } else if (m == -2) {
      fornaxContentTypeInstanceManager.getContentTypeInstances(i, m, n, i1);
      m = fornaxContentTypeInstanceManager.getPageCount();
    } 
    String str = "&content-type-id=" + i + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + n + "&" + "sort-direction" + "=" + i1;
    Form form = buildContentTypeInstancesListForm(paramContext, str);
    fornaxContentTypeInstanceManager.setForm(form);
    paramContext.putDelivery("ContentType", fornaxContentTypeManager.getContentType(i));
    Vector vector = fornaxContentTypeInstanceManager.getContentTypeInstances(i, i2, n, i1);
    paramContext.putDelivery("ContentTypeInstances", vector);
    paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
    paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
    paramContext.putDelivery("LinkContentManagement", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-list"));
    paramContext.putDelivery("LinkGenerationManagement", new String(String.valueOf(this.navigationCommandPrefix) + "generation-management"));
    paramContext.putDelivery("LinkContentTypeInstanceAdd", new String(String.valueOf(this.navigationCommandPrefix) + "content-editor" + "&" + "edit-mode" + "=" + Character.MIN_VALUE + "&" + "edit-action" + "=" + Character.MIN_VALUE + str + "&" + "instance-id" + "=" + "-1"));
    paramContext.putDelivery("LinkContentTypeInstanceCopy", new String(String.valueOf(this.navigationCommandPrefix) + "content-editor" + "&" + "edit-mode" + "=" + '\001' + "&" + "edit-action" + "=" + Character.MIN_VALUE + str + "&" + "instance-id" + "="));
    paramContext.putDelivery("LinkContentTypeInstanceEdit", new String(String.valueOf(this.navigationCommandPrefix) + "content-editor" + "&" + "edit-mode" + "=" + '\002' + "&" + "edit-action" + "=" + Character.MIN_VALUE + str + "&" + "instance-id" + "="));
    paramContext.putDelivery("LinkPageBackward", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + -1 + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + n + "&" + "sort-direction" + "=" + i1));
    paramContext.putDelivery("LinkPageForward", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + '\001' + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + n + "&" + "sort-direction" + "=" + i1));
    paramContext.putDelivery("LinkSortByID", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + Character.MIN_VALUE + "&" + "sort-direction" + "="));
    paramContext.putDelivery("LinkSortByName", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + '\001' + "&" + "sort-direction" + "="));
    paramContext.putDelivery("LinkSortByLastModifiedTimestamp", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + "&" + "content-type-id" + "=" + i + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + m + "&" + "sort-mode" + "=" + '\002' + "&" + "sort-direction" + "="));
    paramContext.putDelivery("current-page", new Integer(m));
    paramContext.putDelivery("number-of-pages", new Integer(fornaxContentTypeInstanceManager.getPageCount()));
    paramContext.putDelivery("sort-mode", new Integer(n));
    paramContext.putDelivery("sort-direction", new Integer(i1));
    form.setValues(paramContext);
    if (form.isSubmitted()) {
      if (j == 1) {
        this.log.debug("Updating form now....");
        fornaxContentTypeInstanceManager.updateInstanceStatusFlags(paramContext, form, vector);
      } else {
        this.log.debug("(2) reverting now...");
        form.revertCheckBoxes();
      } 
    } else {
      this.log.debug("(1) reverting now...");
      form.revertCheckBoxes();
    } 
    paramContext.putDelivery("Form", form);
  }
  
  protected Form buildContentTypeInstancesListForm(Context paramContext, String paramString) {
    String str = String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + paramString + "&" + "instances-list-mode" + "=" + '\001';
    Form form = new Form(this.application, 
        "ContentTypeInstancesListForm", 
        str, 
        "POST");
    form.addSubmissionElement(new FormSubmitButton("submit-button", "Save Status Changes"));
    return form;
  }
  
  protected boolean buildContentTypeInstanceEditElements(Dispatcher paramDispatcher, Context paramContext) {
    Form form;
    int i = paramContext.getIntRequestValue("edit-mode", 0);
    int j = paramContext.getIntRequestValue("edit-action", 0);
    int k = paramContext.getIntRequestValue("instance-id", -1);
    int m = k;
    boolean bool = false;
    if (i == 1) {
      m = -1;
      bool = true;
    } 
    int n = paramContext.getIntRequestValue("content-type-id", -1);
    int i1 = paramContext.getIntRequestValue("paging-mode", 0);
    int i2 = paramContext.getIntRequestValue("current-page", 1) + i1;
    int i3 = paramContext.getIntRequestValue("sort-mode", 0);
    int i4 = paramContext.getIntRequestValue("sort-direction", 0);
    String str1 = new String("&content-type-id=" + n + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + i2 + "&" + "sort-mode" + "=" + i3 + "&" + "sort-direction" + "=" + i4);
    String str2 = new String("&content-type-id=" + n + "&" + "paging-mode" + "=" + Character.MIN_VALUE + "&" + "current-page" + "=" + -2 + "&" + "sort-mode" + "=" + Character.MIN_VALUE + "&" + "sort-direction" + "=" + Character.MIN_VALUE);
    if (i == 2) {
      form = buildContentTypeInstanceEditElementsForm(paramContext, m, str1, i, j);
    } else {
      form = buildContentTypeInstanceEditElementsForm(paramContext, m, str2, i, j);
    } 
    FornaxContentTypeManager fornaxContentTypeManager = new FornaxContentTypeManager(this.application);
    FornaxContentTypeInstanceManager fornaxContentTypeInstanceManager = new FornaxContentTypeInstanceManager(this.application);
    fornaxContentTypeInstanceManager.setForm(form);
    this.log.debug("Browser currently detected as: " + GeminiHelper.getBrowserTypeName(GeminiHelper.getBrowserType(paramContext)));
    fornaxContentTypeInstanceManager.setBrowserType(GeminiHelper.getBrowserType(paramContext));
    paramContext.putDelivery("ContentType", fornaxContentTypeManager.getContentType(n));
    paramContext.putDelivery("ContentTypeInstance", fornaxContentTypeInstanceManager.getContentTypeInstance(k, n, bool));
    paramContext.putDelivery("ContentTypeInstanceFieldValues", fornaxContentTypeInstanceManager.getContentTypeInstanceFieldValues(k, n));
    paramContext.putDelivery("edit-mode", new Integer(i));
    paramContext.putDelivery("edit-action", new Integer(j));
    paramContext.putDelivery("content-type-id", new Integer(n));
    paramContext.putDelivery("instance-id", new Integer(k));
    paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
    paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
    paramContext.putDelivery("LinkContentTypeInstancesList", new String(String.valueOf(this.navigationCommandPrefix) + "content-type-instances-list" + str1));
    form.setValues(paramContext);
    if (form.isSubmitted()) {
      this.log.debug("submission detected");
      if (j == 0) {
        this.log.debug("Save in progress....");
        if (!form.isUnchanged()) {
          this.log.debug("Form has changes....");
          FormValidation formValidation = form.validate();
          if (formValidation.isGood()) {
            this.log.debug("Form contents are valid...");
            ArrayList arrayList = new ArrayList();
            if (fornaxContentTypeInstanceManager.updateContentTypeInstance(paramContext, form, i, arrayList)) {
              this.log.debug("Update completed successfullly");
            } else {
              this.log.debug("Update failed!!");
            } 
            for (byte b = 0; arrayList.size() < 0; b++)
              this.log.debug((String)arrayList.get(b)); 
            return false;
          } 
          this.log.debug("Form validation has errors");
          paramContext.putDelivery("FormValidation", formValidation);
        } 
      } else {
        this.log.debug("EDT: (2) reverting checkboxes");
        form.revertCheckBoxes();
      } 
    } else {
      this.log.debug("EDT: (1) reverting checkboxes");
      form.revertCheckBoxes();
    } 
    paramContext.putDelivery("Form", form);
    return true;
  }
  
  protected Form buildContentTypeInstanceEditElementsForm(Context paramContext, int paramInt1, String paramString, int paramInt2, int paramInt3) {
    String str = String.valueOf(this.navigationCommandPrefix) + "content-editor" + "&" + "edit-mode" + "=" + paramInt2 + "&" + "edit-action" + "=" + paramInt3 + paramString + "&" + "instance-id" + "=" + paramInt1;
    Form form = new Form(this.application, 
        "ContentTypeInstanceEditForm", 
        str, 
        "POST");
    if (paramInt2 == 0 || paramInt2 == 1) {
      form.addSubmissionElement(new FormSubmitButton("submit-button", "Create Content Item"));
    } else {
      form.addSubmissionElement(new FormSubmitButton("submit-button", "Save Changes"));
    } 
    return form;
  }
  
  protected boolean buildGenerationManagementElements(Context paramContext) {
    paramContext.putDelivery("LinkMainMenu", new String(String.valueOf(this.navigationCommandPrefix) + "main-menu"));
    paramContext.putDelivery("LinkLogout", new String(String.valueOf(this.navigationCommandPrefix) + "login" + "&" + "logout" + "=true"));
    paramContext.putDelivery("LinkRunGeneration", new String(String.valueOf(this.navigationCommandPrefix) + "generation-run"));
    String str = "";
    Form form = buildGenerationManagerForm(paramContext, str);
    FornaxGenerationManager fornaxGenerationManager = new FornaxGenerationManager(this.application);
    fornaxGenerationManager.constructGenerationManagementElements(paramContext, form);
    form.setValues(paramContext);
    if (form.isSubmitted()) {
      if (!form.isUnchanged()) {
        this.log.debug("Form has changes....");
        FormValidation formValidation = form.validate();
        if (formValidation.isGood()) {
          this.log.debug("Form contents are valid...");
          this.log.debug("Updating form now....");
          fornaxGenerationManager.updateGenerationManagementElements(paramContext, form);
          return false;
        } 
        this.log.debug("Form validation has errors");
        paramContext.putDelivery("FormValidation", formValidation);
      } else {
        this.log.debug("NO changes were made to the form, so its contents must be valid...");
        this.log.debug("Updating form now....");
        fornaxGenerationManager.updateGenerationManagementElements(paramContext, form);
        return false;
      } 
    } else {
      this.log.debug("(2) reverting now...");
      form.revertCheckBoxes();
    } 
    paramContext.putDelivery("Form", form);
    return true;
  }
  
  protected Form buildGenerationManagerForm(Context paramContext, String paramString) {
    String str = String.valueOf(this.navigationCommandPrefix) + "generation-management";
    Form form = new Form(this.application, 
        "GenerationForm", 
        str, 
        "POST");
    form.addSubmissionElement(new FormSubmitButton("submit-button", "Generate"));
    return form;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxNavigationHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */