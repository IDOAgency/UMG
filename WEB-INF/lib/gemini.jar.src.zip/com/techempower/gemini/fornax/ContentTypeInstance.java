package com.techempower.gemini.fornax;

import java.util.Hashtable;
import java.util.Vector;

public class ContentTypeInstance implements FornaxDBConstants {
  protected boolean debug;
  
  protected int mInstanceID;
  
  protected String mName;
  
  protected String mDescription;
  
  protected int mGroupID;
  
  protected String mGroupName;
  
  protected int mContentTypeID;
  
  protected String mContentTypeName;
  
  protected int mSequenceNO;
  
  protected boolean mIsDisabled;
  
  protected boolean mIsQueuedForDeletion;
  
  protected String mDateCreated;
  
  protected int mLastModifiedUserID;
  
  protected String mLastModifiedTimestamp;
  
  protected Vector mFields;
  
  public ContentTypeInstance(Hashtable paramHashtable) {
    this.debug = false;
    this.mFields = new Vector();
    this.mInstanceID = ((Integer)paramHashtable.get("instanceID")).intValue();
    this.mName = (String)paramHashtable.get("instanceName");
    this.mDescription = (String)paramHashtable.get("instanceDescription");
    this.mGroupID = ((Integer)paramHashtable.get("instanceGroupID")).intValue();
    this.mGroupName = (String)paramHashtable.get("instancesGroupName");
    this.mContentTypeID = ((Integer)paramHashtable.get("instanceContentTypeID")).intValue();
    this.mContentTypeName = (String)paramHashtable.get("ContentTypeName");
    this.mSequenceNO = ((Integer)paramHashtable.get("instanceSequenceNumber")).intValue();
    this.mIsDisabled = ((Boolean)paramHashtable.get("instanceIsDisabled")).booleanValue();
    this.mIsQueuedForDeletion = ((Boolean)paramHashtable.get("instanceIsQueuedForDeletion")).booleanValue();
    this.mDateCreated = (String)paramHashtable.get("instanceDateCreated");
    this.mLastModifiedUserID = ((Integer)paramHashtable.get("instanceLastModifiedByUserID")).intValue();
    this.mLastModifiedTimestamp = (String)paramHashtable.get("instanceLastModifiedTimeStamp");
    this.mFields = (Vector)paramHashtable.get("instanceFields");
  }
  
  public int getInstanceID() { return this.mInstanceID; }
  
  public String getName() { return this.mName; }
  
  public String getDescription() { return this.mDescription; }
  
  public int getGroupID() { return this.mGroupID; }
  
  public String getGroupName() { return this.mGroupName; }
  
  public String getContentTypeName() { return this.mContentTypeName; }
  
  public int getSequenceNO() { return this.mSequenceNO; }
  
  public boolean isDisabled() { return this.mIsDisabled; }
  
  public boolean isQueuedForDeletion() { return this.mIsQueuedForDeletion; }
  
  public String getDateCreated() { return this.mDateCreated; }
  
  public int getLastModifiedByUserID() { return this.mLastModifiedUserID; }
  
  public String getLastModifiedTimestamp() { return this.mLastModifiedTimestamp; }
  
  public String getFieldValueByName(String paramString) {
    String str = null;
    if (this.debug) {
      System.out.println("fieldname " + paramString);
      System.out.println(" there are this may fields = " + this.mFields.size());
    } 
    for (byte b = 0; b < this.mFields.size(); b++) {
      ContentTypeField contentTypeField = (ContentTypeField)this.mFields.elementAt(b);
      if (this.debug)
        System.out.println("the field name from the obj is = " + contentTypeField.getFieldName()); 
      if (contentTypeField.getFieldName().equalsIgnoreCase(paramString)) {
        if (this.debug)
          System.out.println("found the field ... and now trying to get the value . . ."); 
        if (this.mFields.elementAt(b) instanceof ContentTypeFieldDate) {
          ContentTypeFieldDate contentTypeFieldDate = (ContentTypeFieldDate)this.mFields.elementAt(b);
          str = contentTypeFieldDate.getFieldValue();
          break;
        } 
        if (this.mFields.elementAt(b) instanceof ContentTypeFieldInteger) {
          ContentTypeFieldInteger contentTypeFieldInteger = (ContentTypeFieldInteger)this.mFields.elementAt(b);
          str = contentTypeFieldInteger.getFieldValue();
          break;
        } 
        if (this.mFields.elementAt(b) instanceof ContentTypeFieldFloat) {
          ContentTypeFieldFloat contentTypeFieldFloat = (ContentTypeFieldFloat)this.mFields.elementAt(b);
          str = contentTypeFieldFloat.getFieldValue();
          break;
        } 
        if (this.mFields.elementAt(b) instanceof ContentTypeFieldString) {
          ContentTypeFieldString contentTypeFieldString = (ContentTypeFieldString)this.mFields.elementAt(b);
          str = contentTypeFieldString.getFieldValue();
        } 
        break;
      } 
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ContentTypeInstance.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */