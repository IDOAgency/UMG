/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariantType
/*    */   implements FornaxDBConstants
/*    */ {
/*    */   protected int mVariantTypeID;
/*    */   protected String mVariantTypeCode;
/*    */   protected String mVariantTypeDescription;
/*    */   
/*    */   public VariantType(Hashtable paramHashtable) {
/* 41 */     this.mVariantTypeID = ((Integer)paramHashtable.get("variantTypeID")).intValue();
/* 42 */     this.mVariantTypeCode = (String)paramHashtable.get("variantTypeCode");
/* 43 */     this.mVariantTypeDescription = (String)paramHashtable.get("variantTypeDescription");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public int getVariantTypeID() { return this.mVariantTypeID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public String getVariantTypeCode() { return this.mVariantTypeCode; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   public String getVariantTypeDescription() { return this.mVariantTypeDescription; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\VariantType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */