/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import com.techempower.JdbcConnector;
/*     */ import com.techempower.gemini.Context;
/*     */ import com.techempower.gemini.Form;
/*     */ import com.techempower.gemini.FormCheckBox;
/*     */ import com.techempower.gemini.FormComplexDateField;
/*     */ import com.techempower.gemini.FormFloatField;
/*     */ import com.techempower.gemini.FormHidden;
/*     */ import com.techempower.gemini.FormIntegerField;
/*     */ import com.techempower.gemini.FormTextArea;
/*     */ import com.techempower.gemini.FormTextField;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeInstanceManager
/*     */   implements FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fMng";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected Form form;
/*     */   protected final int PAGE_SIZE = 6;
/*     */   protected int browserType;
/*     */   protected Vector contentTypeInstances;
/*     */   
/*     */   public FornaxContentTypeInstanceManager(GeminiApplication paramGeminiApplication) {
/*  49 */     this.form = null;
/*     */     
/*  51 */     this.PAGE_SIZE = 6;
/*     */ 
/*     */     
/*  54 */     this.browserType = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     this.application = paramGeminiApplication;
/*  69 */     this.log = paramGeminiApplication.getLog("fMng");
/*  70 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public String getDescription() { return "Fornax ContentTypeInstance Manager"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxContentTypeInstance getContentTypeInstance(int paramInt1, int paramInt2, boolean paramBoolean) {
/*     */     FornaxContentTypeInstance fornaxContentTypeInstance;
/*  90 */     if (paramInt1 == -1) {
/*     */       
/*  92 */       fornaxContentTypeInstance = new FornaxContentTypeInstance();
/*  93 */       fornaxContentTypeInstance.setContentTypeID(paramInt2);
/*     */     }
/*     */     else {
/*     */       
/*  97 */       String str = 
/*     */ 
/*     */         
/* 100 */         "SELECT * FROM fnContentTypeInstance WHERE InstanceID = " + 
/* 101 */         paramInt1;
/*     */       
/* 103 */       Vector vector = 
/* 104 */         this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 105 */           "com.techempower.gemini.fornax.FornaxContentTypeInstance", 
/* 106 */           true, 
/* 107 */           this.fornaxSettings);
/*     */ 
/*     */       
/* 110 */       if (vector.size() == 1) {
/* 111 */         fornaxContentTypeInstance = (FornaxContentTypeInstance)vector.get(0);
/*     */ 
/*     */ 
/*     */         
/* 115 */         if (paramBoolean) {
/* 116 */           fornaxContentTypeInstance.setID(-1);
/* 117 */           fornaxContentTypeInstance.setIsDisabled("F");
/* 118 */           fornaxContentTypeInstance.setIsQueuedForDeletion("F");
/*     */           
/* 120 */           fornaxContentTypeInstance.setDateCreated(FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM"));
/* 121 */           fornaxContentTypeInstance.setLastModifiedByUserID(-1);
/* 122 */           fornaxContentTypeInstance.setLastModifiedTimestamp(FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM"));
/*     */         } 
/*     */       } else {
/*     */         
/* 126 */         fornaxContentTypeInstance = null;
/*     */       } 
/*     */     } 
/*     */     
/* 130 */     if (this.form != null && fornaxContentTypeInstance != null)
/*     */     {
/* 132 */       addContentTypeInstanceFullFormData(fornaxContentTypeInstance);
/*     */     }
/* 134 */     return fornaxContentTypeInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypeInstances(int paramInt) {
/* 144 */     this.contentTypeInstances = 
/* 145 */       getContentTypeInstances(paramInt, 1, 0, 0);
/*     */     
/* 147 */     return this.contentTypeInstances;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypeInstances(int paramInt1, int paramInt2, int paramInt3) {
/* 156 */     this.contentTypeInstances = 
/* 157 */       getContentTypeInstances(paramInt1, 1, paramInt2, paramInt3);
/*     */     
/* 159 */     return this.contentTypeInstances;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypeInstances(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*     */     Vector vector;
/* 168 */     this.log.debug("Requesting page: " + paramInt2);
/*     */     
/* 170 */     String str = 
/*     */ 
/*     */       
/* 173 */       "SELECT * FROM fnContentTypeInstance WHERE InstanceContentTypeID = " + 
/* 174 */       paramInt1;
/*     */ 
/*     */ 
/*     */     
/* 178 */     switch (paramInt3) {
/*     */       
/*     */       case 0:
/* 181 */         str = String.valueOf(str) + " ORDER BY InstanceID"; break;
/*     */       case 1:
/* 183 */         str = String.valueOf(str) + " ORDER BY InstanceName"; break;
/*     */       case 2:
/* 185 */         str = String.valueOf(str) + " ORDER BY InstanceLastModifiedTimestamp"; break;
/*     */       default:
/* 187 */         str = String.valueOf(str) + " ORDER BY InstanceID";
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 192 */     switch (paramInt4) {
/*     */       
/*     */       case 0:
/* 195 */         str = String.valueOf(str) + " ASC"; break;
/*     */       case 1:
/* 197 */         str = String.valueOf(str) + " DESC"; break;
/*     */       default:
/* 199 */         str = String.valueOf(str) + " ASC";
/*     */         break;
/*     */     } 
/*     */     
/* 203 */     this.contentTypeInstances = null;
/* 204 */     this.contentTypeInstances = 
/* 205 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 206 */         "com.techempower.gemini.fornax.FornaxContentTypeInstance", 
/* 207 */         true, 
/* 208 */         this.fornaxSettings);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (paramInt2 == 0) {
/*     */       
/* 226 */       vector = this.contentTypeInstances;
/*     */     }
/* 228 */     else if (paramInt2 == -1) {
/*     */       
/* 230 */       vector = 
/* 231 */         this.fornaxSettings.getFornaxHelper().getPageOfVectorObjects(this.contentTypeInstances, 1, 6);
/*     */     }
/* 233 */     else if (paramInt2 == -2) {
/*     */       
/* 235 */       vector = 
/* 236 */         this.fornaxSettings.getFornaxHelper().getPageOfVectorObjects(this.contentTypeInstances, getPageCount(), 6);
/*     */     }
/*     */     else {
/*     */       
/* 240 */       vector = 
/* 241 */         this.fornaxSettings.getFornaxHelper().getPageOfVectorObjects(this.contentTypeInstances, paramInt2, 6);
/*     */     } 
/*     */ 
/*     */     
/* 245 */     if (this.form != null)
/*     */     {
/*     */       
/* 248 */       for (byte b = 0; b < vector.size(); b++)
/*     */       {
/* 250 */         addContentTypeInstanceFormData((FornaxContentTypeInstance)vector.get(b));
/*     */       }
/*     */     }
/*     */     
/* 254 */     this.log.debug("Number of instances fetched (after): " + vector.size());
/*     */     
/* 256 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getContentTypeInstancesForGroup(int paramInt, String paramString) {
/* 266 */     String str = 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 271 */       " SELECT cti.* FROM fnMapContentTypeInstanceToInstancesGroup mp INNER JOIN fnContentTypeInstance cti ON cti.InstanceID = mp.InstanceID AND mp.InstancesGroupID = " + 
/* 272 */       paramInt + 
/* 273 */       " WHERE cti.InstanceIsQueuedForDeletion = '" + paramString + "'" + 
/* 274 */       " ORDER BY mp.InstanceSequenceNumber ASC";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 279 */     return this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 280 */         "com.techempower.gemini.fornax.FornaxContentTypeInstance", 
/* 281 */         true, 
/* 282 */         this.fornaxSettings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Vector getContentTypeInstanceFieldValues(int paramInt1, int paramInt2) {
/* 301 */     FornaxContentTypeInstanceFieldValueManager fornaxContentTypeInstanceFieldValueManager = 
/* 302 */       new FornaxContentTypeInstanceFieldValueManager(this.application);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 309 */     Vector vector = 
/* 310 */       fornaxContentTypeInstanceFieldValueManager.getContentTypeInstanceFieldValues(paramInt1, paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 315 */     if (this.form != null)
/*     */     {
/* 317 */       if (vector.size() > 0)
/*     */       {
/* 319 */         addContentTypeInstanceFieldValuesFormData(vector);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 327 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPageCount() {
/* 338 */     if (this.contentTypeInstances != null)
/*     */     {
/* 340 */       return (int)Math.ceil((this.contentTypeInstances.size() / 6.0F));
/*     */     }
/* 342 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 351 */   public void setForm(Form paramForm) { this.form = paramForm; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 363 */   public void setBrowserType(int paramInt) { this.browserType = paramInt; }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addContentTypeInstanceFormData(FornaxContentTypeInstance paramFornaxContentTypeInstance) {
/* 368 */     FormCheckBox formCheckBox1 = new FormCheckBox("instance-disabled-" + paramFornaxContentTypeInstance.getID());
/* 369 */     formCheckBox1.setValue(Integer.toString(paramFornaxContentTypeInstance.getID()));
/* 370 */     formCheckBox1.setStartingChecked(paramFornaxContentTypeInstance.isDisabled());
/* 371 */     formCheckBox1.setChecked(paramFornaxContentTypeInstance.isDisabled());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 376 */     FormCheckBox formCheckBox2 = new FormCheckBox("instance-queued-for-deletion-" + paramFornaxContentTypeInstance.getID());
/* 377 */     formCheckBox2.setValue(Integer.toString(paramFornaxContentTypeInstance.getID()));
/* 378 */     formCheckBox2.setStartingChecked(paramFornaxContentTypeInstance.isQueuedForDeletion());
/* 379 */     formCheckBox2.setChecked(paramFornaxContentTypeInstance.isQueuedForDeletion());
/*     */ 
/*     */ 
/*     */     
/* 383 */     this.form.addElement(formCheckBox1);
/* 384 */     this.form.addElement(formCheckBox2);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addContentTypeInstanceFullFormData(FornaxContentTypeInstance paramFornaxContentTypeInstance) {
/* 389 */     FormHidden formHidden1 = new FormHidden("instance-id", 
/* 390 */         Integer.toString(paramFornaxContentTypeInstance.getID()), 
/* 391 */         true);
/*     */     
/* 393 */     FormHidden formHidden2 = new FormHidden("instance-content-type-id", 
/* 394 */         Integer.toString(paramFornaxContentTypeInstance.getContentTypeID()), 
/* 395 */         true);
/*     */ 
/*     */ 
/*     */     
/* 399 */     byte b1 = 23;
/*     */     
/* 401 */     if (this.browserType == 0 || 
/* 402 */       this.browserType == 1) {
/* 403 */       b1 = 40;
/*     */     }
/* 405 */     FormTextField formTextField = new FormTextField("instance-name", 
/* 406 */         paramFornaxContentTypeInstance.getName(), 
/* 407 */         true, 
/* 408 */         b1, 
/* 409 */         50);
/*     */     
/* 411 */     formTextField.setClassName("contentText");
/* 412 */     formTextField.setDisplayName("\"Content Item Name\"");
/*     */ 
/*     */ 
/*     */     
/* 416 */     byte b2 = 28;
/*     */     
/* 418 */     if (this.browserType == 0 || 
/* 419 */       this.browserType == 1) {
/* 420 */       b2 = 55;
/*     */     }
/* 422 */     FormTextArea formTextArea = new FormTextArea("instance-description", 
/* 423 */         paramFornaxContentTypeInstance.getDescription(), 
/* 424 */         false, 
/* 425 */         10, 
/* 426 */         b2, 
/* 427 */         "virtual");
/*     */     
/* 429 */     formTextArea.setClassName("contentText");
/*     */ 
/*     */     
/* 432 */     FormCheckBox formCheckBox1 = new FormCheckBox("instance-disabled");
/*     */     
/* 434 */     formCheckBox1.setValue(Integer.toString(paramFornaxContentTypeInstance.getID()));
/* 435 */     formCheckBox1.setStartingChecked(paramFornaxContentTypeInstance.isDisabled());
/* 436 */     formCheckBox1.setChecked(paramFornaxContentTypeInstance.isDisabled());
/*     */     
/* 438 */     FormCheckBox formCheckBox2 = new FormCheckBox("instance-queued-for-deletion");
/*     */     
/* 440 */     formCheckBox2.setValue(Integer.toString(paramFornaxContentTypeInstance.getID()));
/* 441 */     formCheckBox2.setStartingChecked(paramFornaxContentTypeInstance.isQueuedForDeletion());
/* 442 */     formCheckBox2.setChecked(paramFornaxContentTypeInstance.isQueuedForDeletion());
/*     */     
/* 444 */     this.form.addElement(formHidden1);
/* 445 */     this.form.addElement(formHidden2);
/* 446 */     this.form.addElement(formTextField);
/* 447 */     this.form.addElement(formTextArea);
/* 448 */     this.form.addElement(formCheckBox1);
/* 449 */     this.form.addElement(formCheckBox2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addContentTypeInstanceFieldValuesFormData(Vector paramVector) {
/* 461 */     for (byte b = 0; b < paramVector.size(); b++) {
/*     */       
/* 463 */       FornaxContentTypeInstanceFieldValue fornaxContentTypeInstanceFieldValue = (FornaxContentTypeInstanceFieldValue)paramVector.get(b);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 468 */       String str = fornaxContentTypeInstanceFieldValue.getDataTypeName();
/*     */       
/* 470 */       if (str.equalsIgnoreCase("DATE")) {
/*     */         
/* 472 */         addDateTimeFieldFormElement(fornaxContentTypeInstanceFieldValue);
/*     */       }
/* 474 */       else if (str.equalsIgnoreCase("INTEGER")) {
/*     */         
/* 476 */         addIntegerFieldFormElement(fornaxContentTypeInstanceFieldValue);
/*     */       }
/* 478 */       else if (str.equalsIgnoreCase("FLOATINGPOINT")) {
/*     */         
/* 480 */         addFloatingPointFieldFormElement(fornaxContentTypeInstanceFieldValue);
/*     */       }
/* 482 */       else if (str.equalsIgnoreCase("STRING")) {
/*     */         
/* 484 */         addStringFieldFormElement(fornaxContentTypeInstanceFieldValue);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addDateTimeFieldFormElement(FornaxContentTypeInstanceFieldValue paramFornaxContentTypeInstanceFieldValue) {
/* 492 */     byte b = 23;
/*     */     
/* 494 */     if (this.browserType == 0 || 
/* 495 */       this.browserType == 1) {
/* 496 */       b = 40;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 510 */     FormComplexDateField formComplexDateField = new FormComplexDateField(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
/* 511 */         paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
/* 512 */         paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
/* 513 */         26);
/*     */ 
/*     */ 
/*     */     
/* 517 */     if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
/* 518 */       formComplexDateField.setClassName("contentText");
/*     */     } else {
/* 520 */       formComplexDateField.setClassName("contentText");
/*     */     } 
/* 522 */     formComplexDateField.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
/*     */     
/* 524 */     if (this.form != null) {
/* 525 */       this.form.addElement(formComplexDateField);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addIntegerFieldFormElement(FornaxContentTypeInstanceFieldValue paramFornaxContentTypeInstanceFieldValue) {
/* 531 */     byte b = 10;
/*     */     
/* 533 */     if (this.browserType == 0 || 
/* 534 */       this.browserType == 1) {
/* 535 */       b = 15;
/*     */     }
/* 537 */     FormIntegerField formIntegerField = new FormIntegerField(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
/* 538 */         paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
/* 539 */         paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
/* 540 */         (int)paramFornaxContentTypeInstanceFieldValue.getFieldNumericValueMin(), 
/* 541 */         (int)paramFornaxContentTypeInstanceFieldValue.getFieldNumericValueMax(), 
/* 542 */         b, 
/* 543 */         15);
/*     */ 
/*     */     
/* 546 */     if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
/* 547 */       formIntegerField.setClassName("contentText");
/*     */     } else {
/* 549 */       formIntegerField.setClassName("contentText");
/*     */     } 
/* 551 */     formIntegerField.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
/*     */     
/* 553 */     if (this.form != null) {
/* 554 */       this.form.addElement(formIntegerField);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addFloatingPointFieldFormElement(FornaxContentTypeInstanceFieldValue paramFornaxContentTypeInstanceFieldValue) {
/* 560 */     byte b = 10;
/*     */     
/* 562 */     if (this.browserType == 0 || 
/* 563 */       this.browserType == 1) {
/* 564 */       b = 15;
/*     */     }
/* 566 */     FormFloatField formFloatField = new FormFloatField(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
/* 567 */         paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
/* 568 */         paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
/* 569 */         paramFornaxContentTypeInstanceFieldValue.getFieldNumericValueMin(), 
/* 570 */         paramFornaxContentTypeInstanceFieldValue.getFieldNumericValueMax(), 
/* 571 */         b, 
/* 572 */         25);
/*     */ 
/*     */     
/* 575 */     if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
/* 576 */       formFloatField.setClassName("contentText");
/*     */     } else {
/* 578 */       formFloatField.setClassName("contentText");
/*     */     } 
/* 580 */     formFloatField.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
/*     */     
/* 582 */     if (this.form != null) {
/* 583 */       this.form.addElement(formFloatField);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addStringFieldFormElement(FornaxContentTypeInstanceFieldValue paramFornaxContentTypeInstanceFieldValue) {
/* 591 */     if (paramFornaxContentTypeInstanceFieldValue.getFieldStringMaxLength() <= 50) {
/*     */ 
/*     */       
/* 594 */       byte b = 23;
/*     */       
/* 596 */       if (this.browserType == 0 || 
/* 597 */         this.browserType == 1) {
/* 598 */         b = 40;
/*     */       }
/* 600 */       FormTextField formTextField = new FormTextField(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
/* 601 */           paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
/* 602 */           paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
/* 603 */           b, 
/* 604 */           paramFornaxContentTypeInstanceFieldValue.getFieldStringMaxLength());
/*     */ 
/*     */       
/* 607 */       if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
/* 608 */         formTextField.setClassName("contentText");
/*     */       } else {
/* 610 */         formTextField.setClassName("contentText");
/*     */       } 
/* 612 */       formTextField.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
/*     */       
/* 614 */       if (this.form != null) {
/* 615 */         this.form.addElement(formTextField);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 620 */       byte b = 28;
/*     */       
/* 622 */       if (this.browserType == 0 || 
/* 623 */         this.browserType == 1) {
/* 624 */         b = 55;
/*     */       }
/* 626 */       FormTextArea formTextArea = new FormTextArea(paramFornaxContentTypeInstanceFieldValue.getFieldName(), 
/* 627 */           paramFornaxContentTypeInstanceFieldValue.getFieldValue(), 
/* 628 */           paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired(), 
/* 629 */           10, 
/* 630 */           b, 
/* 631 */           "virtual");
/*     */       
/* 633 */       formTextArea.setMaxLength(paramFornaxContentTypeInstanceFieldValue.getFieldStringMaxLength());
/*     */ 
/*     */       
/* 636 */       if (paramFornaxContentTypeInstanceFieldValue.isFieldValueRequired()) {
/* 637 */         formTextArea.setClassName("contentText");
/*     */       } else {
/* 639 */         formTextArea.setClassName("contentText");
/*     */       } 
/* 641 */       formTextArea.setDisplayName("\"" + paramFornaxContentTypeInstanceFieldValue.getFieldName() + "\"");
/*     */       
/* 643 */       if (this.form != null) {
/* 644 */         this.form.addElement(formTextArea);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean updateContentTypeInstance(Context paramContext, Form paramForm, int paramInt, ArrayList paramArrayList) {
/* 668 */     int i = paramForm.getIntegerValue("instance-id");
/* 669 */     int j = paramForm.getIntegerValue("instance-content-type-id");
/*     */     
/* 671 */     this.log.debug("Preparing to update instanceID:" + i + ", and TypeID: " + j);
/*     */     
/* 673 */     if (paramInt != 2 || (paramInt == 2 && i > 0 && j > 0)) {
/*     */ 
/*     */       
/* 676 */       FornaxContentTypeInstance fornaxContentTypeInstance = getContentTypeInstance(i, j, false);
/*     */ 
/*     */       
/* 679 */       fornaxContentTypeInstance.setContentTypeID(paramForm.getIntegerValue("instance-content-type-id"));
/* 680 */       fornaxContentTypeInstance.setName(paramForm.getStringValue("instance-name"));
/* 681 */       fornaxContentTypeInstance.setDescription(paramForm.getStringValue("instance-description"));
/* 682 */       fornaxContentTypeInstance.setIsDisabled("F");
/* 683 */       fornaxContentTypeInstance.setIsQueuedForDeletion("F");
/*     */       
/*     */       FormCheckBox formCheckBox;
/*     */       
/* 687 */       if ((formCheckBox = (FormCheckBox)paramForm.getElement("instance-disabled")) != null)
/*     */       {
/* 689 */         if (formCheckBox.isChecked()) {
/* 690 */           fornaxContentTypeInstance.setIsDisabled("T");
/*     */         }
/*     */       }
/* 693 */       if ((formCheckBox = (FormCheckBox)paramForm.getElement("instance-queued-for-deletion")) != null)
/*     */       {
/* 695 */         if (formCheckBox.isChecked()) {
/* 696 */           fornaxContentTypeInstance.setIsQueuedForDeletion("T");
/*     */         }
/*     */       }
/* 699 */       if (this.fornaxSettings.getSecurity() != null) {
/* 700 */         fornaxContentTypeInstance.setLastModifiedByUserID(this.fornaxSettings.getSecurity().getLogin(paramContext).getUserID());
/*     */       } else {
/* 702 */         this.log.debug("no security context available at this time...");
/*     */       } 
/* 704 */       this.log.debug("running update....");
/*     */       
/* 706 */       int k = fornaxContentTypeInstance.runUpdate(this.fornaxSettings.getConnector(""), true);
/*     */       
/* 708 */       this.log.debug("return value retrieved as: " + k);
/*     */ 
/*     */       
/* 711 */       if (i == -1 && k == -1) {
/*     */         
/* 713 */         paramArrayList.add(new String(
/* 714 */               "cnTypeInstMgr::updateContentTypeInstance\nDB ERROR, The INSERT failed [ContentTypeID: " + 
/* 715 */               j + 
/* 716 */               ", InstanceID: " + i + 
/* 717 */               ", return value: " + k + "]"));
/*     */ 
/*     */         
/* 720 */         return false;
/*     */       } 
/*     */       
/* 723 */       if (i != -1 && k != 1) {
/*     */         
/* 725 */         paramArrayList.add(new String(
/* 726 */               "cnTypeInstMgr::updateContentTypeInstance\nDB ERROR, The UPDATE failed [ContentTypeID: " + 
/* 727 */               j + 
/* 728 */               ", InstanceID: " + i + 
/* 729 */               ", return value: " + k + "]"));
/*     */ 
/*     */         
/* 732 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 736 */       if (i == -1 && k != -1) {
/* 737 */         i = k;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 742 */       Vector vector = getContentTypeInstanceFieldValues(i, j);
/*     */ 
/*     */ 
/*     */       
/* 746 */       for (byte b = 0; b < vector.size(); b++) {
/*     */         
/* 748 */         FornaxContentTypeInstanceFieldValue fornaxContentTypeInstanceFieldValue = (FornaxContentTypeInstanceFieldValue)vector.get(b);
/* 749 */         String str = paramForm.getStringValue(fornaxContentTypeInstanceFieldValue.getFieldName());
/*     */         
/* 751 */         if (str != null) {
/* 752 */           fornaxContentTypeInstanceFieldValue.setFieldValue(str);
/* 753 */           int m = fornaxContentTypeInstanceFieldValue.runUpdate(this.fornaxSettings.getConnector(""));
/* 754 */           this.log.debug("return value for field update retrieved as: " + m);
/*     */ 
/*     */           
/* 757 */           if (m == -1)
/*     */           {
/* 759 */             paramArrayList.add(new String(
/* 760 */                   "cnTypeInstMgr::updateContentTypeInstance\nDB ERROR, The fieldValue INSERT?UPDATE failed [ContentTypeID: " + 
/* 761 */                   j + 
/* 762 */                   ", InstanceID: " + i + 
/* 763 */                   ", FieldName: " + fornaxContentTypeInstanceFieldValue.getFieldName() + 
/* 764 */                   ", return value: " + m + "]"));
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 776 */       if (!updateInstancesGroupMapping(j, i))
/*     */       {
/* 778 */         paramArrayList.add(new String(
/* 779 */               "cnTypeInstMgr::updateContentTypeInstance\nDB ERROR, An error occurred while updating the instance group mapping [ContentTypeID: " + 
/* 780 */               j + 
/* 781 */               ", InstanceID: " + i + 
/* 782 */               ", DefaultGroupID detected as: " + 
/* 783 */               getDefaultGroupID(j) + "]"));
/*     */       }
/*     */ 
/*     */       
/* 787 */       return !(k == -1);
/*     */     } 
/* 789 */     paramArrayList.add(new String(
/* 790 */           "cnTypeInstMgr::updateContentTypeInstance\nGENERAL ERROR, either the instance or content type id was invalid [ContentTypeID: " + 
/* 791 */           j + 
/* 792 */           ", InstanceID: " + i + "]"));
/*     */ 
/*     */     
/* 795 */     this.log.debug("Either the ContentTypeID or InstanceID was invalid.");
/*     */     
/* 797 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateInstanceStatusFlags(Context paramContext, Form paramForm, Vector paramVector) {
/* 812 */     boolean bool = false;
/*     */     
/* 814 */     for (byte b = 0; b < paramVector.size(); b++) {
/*     */       
/* 816 */       FornaxContentTypeInstance fornaxContentTypeInstance = (FornaxContentTypeInstance)paramVector.get(b);
/* 817 */       fornaxContentTypeInstance.setIsDisabled("F");
/* 818 */       fornaxContentTypeInstance.setIsQueuedForDeletion("F");
/*     */       FormCheckBox formCheckBox;
/* 820 */       if ((formCheckBox = (FormCheckBox)paramForm.getElement("instance-disabled-" + fornaxContentTypeInstance.getID())) != null) {
/*     */ 
/*     */         
/* 823 */         if (formCheckBox.isChecked()) {
/* 824 */           fornaxContentTypeInstance.setIsDisabled("T");
/*     */         }
/*     */         
/* 827 */         if (formCheckBox.getStartingChecked() != formCheckBox.isChecked()) {
/* 828 */           bool = true;
/*     */         }
/*     */       } 
/*     */       
/* 832 */       if ((formCheckBox = (FormCheckBox)paramForm.getElement("instance-queued-for-deletion-" + fornaxContentTypeInstance.getID())) != null) {
/*     */ 
/*     */         
/* 835 */         if (formCheckBox.isChecked()) {
/* 836 */           fornaxContentTypeInstance.setIsQueuedForDeletion("T");
/*     */         }
/*     */         
/* 839 */         if (formCheckBox.getStartingChecked() != formCheckBox.isChecked()) {
/* 840 */           bool = true;
/*     */         }
/*     */       } 
/*     */       
/* 844 */       if (bool) {
/*     */         
/* 846 */         this.log.debug("Status changes WERE made to instanceID: " + fornaxContentTypeInstance.getID());
/*     */         
/* 848 */         if (paramContext != null) {
/* 849 */           fornaxContentTypeInstance.setLastModifiedByUserID(this.fornaxSettings.getSecurity().getLogin(paramContext).getUserID());
/*     */         } else {
/* 851 */           this.log.debug("unabled to update last modified by user ID for instanceID: " + fornaxContentTypeInstance.getID());
/*     */         } 
/*     */       } 
/*     */       
/* 855 */       fornaxContentTypeInstance.runUpdate(this.fornaxSettings.getConnector(""), bool);
/*     */       
/* 857 */       if (bool)
/*     */       {
/* 859 */         resynchInstanceLastModifiedTimeStamp(fornaxContentTypeInstance);
/*     */       }
/*     */       
/* 862 */       bool = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultGroupID(int paramInt) {
/* 869 */     return FornaxContentTypeManager.getDefaultInstancesGroupID(paramInt, 
/* 870 */         this.fornaxSettings.getConnector(""));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean updateInstancesGroupMapping(int paramInt1, int paramInt2) {
/* 876 */     boolean bool = true;
/*     */ 
/*     */ 
/*     */     
/* 880 */     int i = getDefaultGroupID(paramInt1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 886 */     isInstanceMappedToGroup(i, 
/* 887 */         paramInt2, 
/* 888 */         this.fornaxSettings.getConnector(""));
/*     */ 
/*     */     
/* 891 */     String str = 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 897 */       "BEGIN TRAN; DECLARE @iNextSeqNo int; SELECT @iNextSeqNo = max(InstanceSequenceNumber) FROM fnMapContentTypeInstanceToInstancesGroup WHERE InstancesGroupID = " + 
/* 898 */       i + ";" + 
/*     */       
/* 900 */       " INSERT INTO fnMapContentTypeInstanceToInstancesGroup(InstanceID," + 
/* 901 */       " InstancesGroupID," + 
/* 902 */       " InstanceSequenceNumber)" + 
/* 903 */       " VALUES (" + paramInt2 + "," + i + ", @iNextSeqNo);" + 
/*     */       
/* 905 */       " SELECT count(InstanceID) as 'InstanceCount'" + 
/* 906 */       " FROM fnMapContentTypeInstanceToInstancesGroup" + 
/* 907 */       " WHERE InstanceID = " + paramInt2 + 
/* 908 */       " AND InstancesGroupID = " + i + ";" + 
/*     */       
/* 910 */       " COMMIT TRAN;";
/*     */     
/* 912 */     DatabaseConnector databaseConnector = 
/* 913 */       this.fornaxSettings.getConnector(str);
/*     */     
/* 915 */     databaseConnector.runQuery();
/*     */     
/* 917 */     int j = -1;
/*     */     
/* 919 */     if (databaseConnector.more()) {
/*     */       
/* 921 */       databaseConnector.first();
/* 922 */       if ((j = databaseConnector.getInt("InstanceCount", -1)) != 1)
/* 923 */         bool = false; 
/*     */     } 
/* 925 */     databaseConnector.close();
/*     */ 
/*     */ 
/*     */     
/* 929 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resynchInstanceLastModifiedTimeStamp(FornaxContentTypeInstance paramFornaxContentTypeInstance) {
/* 935 */     JdbcConnector jdbcConnector = (JdbcConnector)this.fornaxSettings.getConnector("select InstanceLastModifiedTimestamp from fnContentTypeInstance where InstanceID = " + paramFornaxContentTypeInstance.getID());
/* 936 */     jdbcConnector.runQuery();
/* 937 */     if (jdbcConnector.more()) {
/*     */       
/* 939 */       jdbcConnector.first();
/* 940 */       Calendar calendar = Calendar.getInstance();
/* 941 */       calendar.setTime(jdbcConnector.getDate("InstanceLastModifiedTimestamp"));
/* 942 */       paramFornaxContentTypeInstance.setLastModifiedTimestamp(calendar);
/*     */     } 
/* 944 */     jdbcConnector.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInstanceMappedToGroup(int paramInt1, int paramInt2, DatabaseConnector paramDatabaseConnector) {
/* 964 */     boolean bool = false;
/*     */     
/* 966 */     String str = 
/*     */ 
/*     */       
/* 969 */       "SELECT count(InstanceID) as 'InstanceCount' FROM fnMapContentTypeInstanceToInstancesGroup mp WHERE mp.InstancesGroupID = " + 
/* 970 */       paramInt1 + 
/* 971 */       " AND mp.InstanceID = " + paramInt2;
/*     */     
/* 973 */     paramDatabaseConnector.setQuery(str);
/* 974 */     paramDatabaseConnector.runQuery();
/*     */     
/* 976 */     if (paramDatabaseConnector.more()) {
/*     */       
/* 978 */       paramDatabaseConnector.first();
/* 979 */       if (paramDatabaseConnector.getInt("InstanceCount", -1) == 1)
/* 980 */         bool = true; 
/*     */     } 
/* 982 */     paramDatabaseConnector.close();
/*     */ 
/*     */ 
/*     */     
/* 986 */     return bool;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstanceManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */