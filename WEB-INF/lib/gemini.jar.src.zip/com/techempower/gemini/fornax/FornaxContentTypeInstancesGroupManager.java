package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.Context;
import com.techempower.gemini.Form;
import com.techempower.gemini.FormDropDownMenu;
import com.techempower.gemini.GeminiApplication;
import java.util.Vector;

public class FornaxContentTypeInstancesGroupManager implements FornaxConstants {
  public static final String COMPONENT_CODE = "fMng";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected Vector contentTypeInstancesGroups;
  
  public FornaxContentTypeInstancesGroupManager(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("fMng");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
  }
  
  public String getDescription() { return "Fornax Content Type Instances Group Manager"; }
  
  public FornaxContentTypeInstancesGroup getContentTypeInstancesGroup(int paramInt) {
    String str = 
      
      "SELECT InstancesGroup.*, InstancesGroupCount.InstancesGroupInstancesCount FROM (SELECT * FROM fnContentTypeInstancesGroup WHERE InstancesGroupID = " + 
      paramInt + 
      " )" + 
      " AS [InstancesGroup]" + 
      " INNER JOIN (SELECT ctg.InstancesGroupID, count(ctg.InstancesGroupID) as 'InstancesGroupInstancesCount'" + 
      " FROM fnContentTypeInstancesGroup ctg" + 
      " INNER JOIN fnMapContentTypeInstanceToInstancesGroup mp" + 
      " ON mp.InstancesGroupID = ctg.InstancesGroupID" + 
      " WHERE ctg.InstancesGroupID = " + paramInt + 
      " GROUP BY ctg.InstancesGroupID)" + 
      " AS [InstancesGroupCount]" + 
      " ON InstancesGroupCount.InstancesGroupID = InstancesGroup.InstancesGroupID";
    Vector vector = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentTypeInstancesGroup", 
        true, 
        this.fornaxSettings);
    if (vector.size() == 1)
      return (FornaxContentTypeInstancesGroup)vector.get(0); 
    return null;
  }
  
  public Vector getContentTypeInstancesGroups(int paramInt) {
    String str1 = "";
    if (!this.fornaxSettings.isMultiGroup())
      str1 = "top 1"; 
    String str2 = 
      
      "SELECT " + str1 + " InstancesGroup.*, InstancesGroupCount.InstancesGroupInstancesCount" + 
      
      " FROM (SELECT " + str1 + " *" + 
      " FROM fnContentTypeInstancesGroup" + 
      " WHERE InstancesGroupContentTypeID = " + paramInt + 
      " )" + 
      " AS [InstancesGroup]" + 
      " INNER JOIN (SELECT ctg.InstancesGroupID, count(ctg.InstancesGroupID) as 'InstancesGroupInstancesCount'" + 
      " FROM fnContentTypeInstancesGroup ctg" + 
      " INNER JOIN fnMapContentTypeInstanceToInstancesGroup mp" + 
      " ON mp.InstancesGroupID = ctg.InstancesGroupID" + 
      " WHERE ctg.InstancesGroupContentTypeID = " + paramInt + 
      " GROUP BY ctg.InstancesGroupID)" + 
      " AS [InstancesGroupCount]" + 
      " ON InstancesGroupCount.InstancesGroupID = InstancesGroup.InstancesGroupID";
    this.contentTypeInstancesGroups = null;
    this.contentTypeInstancesGroups = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str2, 
        "com.techempower.gemini.fornax.FornaxContentTypeInstancesGroup", 
        true, 
        this.fornaxSettings);
    return this.contentTypeInstancesGroups;
  }
  
  public void updateInstancesGroupsListPageFlag(Context paramContext, Form paramForm, Vector paramVector) {
    for (byte b = 0; b < paramVector.size(); b++) {
      FornaxContentTypeInstancesGroup fornaxContentTypeInstancesGroup = (FornaxContentTypeInstancesGroup)paramVector.elementAt(b);
      FormDropDownMenu formDropDownMenu = (FormDropDownMenu)paramForm.getElement("listPage-generate-" + Integer.toString(fornaxContentTypeInstancesGroup.getID()));
      if (formDropDownMenu != null) {
        fornaxContentTypeInstancesGroup.setIsListPageGenerated(formDropDownMenu.getStringValue());
        fornaxContentTypeInstancesGroup.runUpdate(this.fornaxSettings.getConnector(""));
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstancesGroupManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */