/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentTypeFieldFloat
/*    */   extends ContentTypeField
/*    */   implements FornaxDBConstants
/*    */ {
/*    */   protected int mValueID;
/*    */   protected int mInstanceID;
/*    */   protected String mFieldValue;
/*    */   
/*    */   public ContentTypeFieldFloat(Hashtable paramHashtable) {
/* 48 */     super(paramHashtable);
/*    */     
/* 50 */     this.mValueID = ((Integer)paramHashtable.get("floatingPointValueID")).intValue();
/* 51 */     this.mInstanceID = ((Integer)paramHashtable.get("floatingPointValueInstance")).intValue();
/* 52 */     this.mFieldValue = (String)paramHashtable.get("floatingPointValueData");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public int getValueID() { return this.mValueID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public int getInstanceID() { return this.mInstanceID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 80 */   public String getFieldValue() { return this.mFieldValue; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ContentTypeFieldFloat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */