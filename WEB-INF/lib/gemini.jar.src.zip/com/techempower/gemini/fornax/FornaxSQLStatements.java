package com.techempower.gemini.fornax;

public interface FornaxSQLStatements {
  public static final String GET_ALL_CONTENTTYPE_INFO_QUERY = "SELECT * from fnContentType ORDER BY ContentTypeID";
  
  public static final String GET_CONTENTTYPE_INFO_QUERY = "SELECT * from fnContentType WHERE ContentTypeID = @contentTypeID ";
  
  public static final String GET_ALL_CONTENTTYPEINSTANCESGROUP_INFO_QUERY = "SELECT * from fnContentTypeInstancesGroup ORDER BY InstancesGroupID";
  
  public static final String GET_INSTANCESGROUP_INFO_FOR_CONTENTTYPE_QUERY = "SELECT * from fnContentTypeInstancesGroup WHERE InstancesGroupContentTypeID = @contentTypeID  ORDER BY InstancesGroupID";
  
  public static final String GET_INSTANCESGROUP_INFO_FOR_CONTENTTYPE_TOP1_QUERY = "SELECT TOP 1 * from fnContentTypeInstancesGroup WHERE InstancesGroupContentTypeID = @contentTypeID  ORDER BY InstancesGroupID";
  
  public static final String GET_CONTENTTYPEINSTANCESGROUP_INFO_QUERY = "SELECT * from fnContentTypeInstancesGroup g INNER JOIN fnContentType c on g.InstancesGroupContentTypeID = c.ContentTypeID  WHERE g.InstancesGroupID = @groupID";
  
  public static final String GET_CONTENTTYPE_INFO_FOR_GROUP_QUERY = "SELECT ct.* from fnContentTypeInstancesGroup ctg INNER JOIN fnContentType ct on ctg.InstancesGroupContentTypeID = ct.ContentTypeID WHERE ctg.InstancesGroupContentTypeID = @contentTypeID";
  
  public static final String GET_LISTPAGE_INFO_QUERY = "SELECT * from fnListPage WHERE ListPageID = @listPageID";
  
  public static final String GET_CONTENTYPE_TEMPLATE_INFO_QUERY = "SELECT * from fnContentTypeTemplate  WHERE ContentTypeTemplateID = @templateID";
  
  public static final String GET_FILEPATH_INFO_QUERY = "SELECT * from fnFilePath where FilePathID = @filePathID";
  
  public static final String GET_DESTINATIONGENERATION_INFO_QUERY = "SELECT * from fnGenerationDestination WHERE GenerationDestinationID = @destinationID";
  
  public static final String GET_DATAFIELDS_FOR_CONTENTTYPE = "SELECT * from fnContentTypeField ctf INNER JOIN fnContentTypeFieldDataType cdt on ctf.FieldDataTypeID = cdt.DataTypeID WHERE ctf.FieldContentTypeID = @contentTypeID";
  
  public static final String GET_INSTANCES_FOR_CONTENTTYPE_GROUP = "SELECT ctg.InstancesGroupID, ctg.InstanceSequenceNumber, cti.* , ct.* , g.InstancesGroupName FROM fnMapContentTypeInstanceToInstancesGroup ctg INNER JOIN fnContentTypeInstance cti on ctg.InstanceID = cti.instanceID INNER JOIN fnContentType ct on cti.InstanceContentTypeID = ct.ContentTypeID INNER JOIN fnContentTypeInstancesGroup g on ctg.InstancesGroupID = g.InstancesGroupID WHERE ctg.InstancesGroupID = @groupID ORDER BY cti.InstanceIsQueuedForDeletion ASC, cti.InstanceIsDisabled ASC, ctg.InstanceSequenceNumber";
  
  public static final String GET_FIELD_VALUES_FOR_CONTENTTYPE_INSTANCE = "SELECT \t* FROM fnContentTypeInstanceFieldValue WHERE instanceID = @instanceID and  InstanceContentTypeID = @contentTypeID";
  
  public static final String GET_VARIANTS_INFO_FOR_CONTENTTYPE_GROUP = "SELECT * FROM fnContentTypeInstancesGroupVariant cg INNER JOIN fnVariantType v on v.VariantTypeID = cg.VariantTypeID WHERE cg.VariantInstancesGroupID = @groupID";
  
  public static final String GET_LISTPAGE_INFO_FOR_CONTENTTYPE_GROUP_QUERY = "SELECT * FROM fnContentTypeInstancesGroup ctg LEFT OUTER JOIN fnListPage lp on ctg.InstancesGroupListPageID = lp.ListPageID   WHERE ctg.InstancesGroupID = @groupID";
  
  public static final String DELETE_CONTENTTYPE_INSTANCE_QUERY = "DELETE FROM fnContentTypeInstance WHERE InstanceID = @instanceID";
  
  public static final String DELETE_CONTENTTYPE_INSTANCE_DATEFIELD_QUERY = "DELETE FROM fnContentTypeDateValue WHERE DateValueInstanceID = @instanceID";
  
  public static final String DELETE_CONTENTTYPE_INSTANCE_INTEGERFIELD_QUERY = "DELETE FROM fnContentTypeIntegerValue WHERE IntegerValueInstanceID = @instanceID";
  
  public static final String DELETE_CONTENTTYPE_INSTANCE_FLOATFIELD_QUERY = "DELETE FROM fnContentTypeFloatingPointValue WHERE FloatingPointValueInstanceID = @instanceID";
  
  public static final String DELETE_CONTENTTYPE_INSTANCE_STRINGFIELD_QUERY = "DELETE FROM fnContentTypeStringValue WHERE StringValueInstanceID = @instanceID";
  
  public static final String DELETE_CONTENTTYPE_INSTANCE_MAPPINGS_TO_GROUP_QUERY = "DELETE FROM fnMapContentTypeInstanceToInstancesGroup WHERE InstanceID = @instanceID";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxSQLStatements.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */