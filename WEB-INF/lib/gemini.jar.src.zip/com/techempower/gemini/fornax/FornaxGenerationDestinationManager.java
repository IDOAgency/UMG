/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxGenerationDestinationManager
/*     */   implements FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fMng";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected Vector generationDestinations;
/*     */   FornaxFilePathManager filePathManager;
/*     */   
/*     */   public FornaxGenerationDestinationManager(GeminiApplication paramGeminiApplication) {
/*  63 */     this.application = paramGeminiApplication;
/*  64 */     this.log = paramGeminiApplication.getLog("fMng");
/*  65 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*  66 */     this.filePathManager = new FornaxFilePathManager(this.application);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public String getDescription() { return "Fornax Generation Destination Manager"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxGenerationDestination getGenerationDestination(int paramInt) {
/*  84 */     String str = 
/*     */ 
/*     */       
/*  87 */       "SELECT * FROM fnGenerationDestination WHERE GenerationDestinationID = " + 
/*  88 */       paramInt;
/*     */     
/*  90 */     Vector vector = 
/*  91 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/*  92 */         "com.techempower.gemini.fornax.FornaxGenerationDestination", 
/*  93 */         true, 
/*  94 */         this.fornaxSettings);
/*     */ 
/*     */ 
/*     */     
/*  98 */     if (vector.size() == 1)
/*     */     {
/* 100 */       return (FornaxGenerationDestination)vector.get(0);
/*     */     }
/*     */ 
/*     */     
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getGenerationDestinations() {
/* 115 */     String str = 
/*     */ 
/*     */       
/* 118 */       "SELECT * FROM fnGenerationDestination ORDER BY GenerationDestinationID";
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.generationDestinations = null;
/* 123 */     this.generationDestinations = 
/* 124 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 125 */         "com.techempower.gemini.fornax.FornaxGenerationDestination", 
/* 126 */         true, 
/* 127 */         this.fornaxSettings);
/*     */     
/* 129 */     return this.generationDestinations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public FornaxFilePath getFilePath(int paramInt) { return this.filePathManager.getFilePath(paramInt); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxGenerationDestinationManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */