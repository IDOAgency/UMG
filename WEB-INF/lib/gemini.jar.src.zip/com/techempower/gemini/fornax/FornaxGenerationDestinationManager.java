package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.GeminiApplication;
import java.util.Vector;

public class FornaxGenerationDestinationManager implements FornaxConstants {
  public static final String COMPONENT_CODE = "fMng";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected Vector generationDestinations;
  
  FornaxFilePathManager filePathManager;
  
  public FornaxGenerationDestinationManager(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("fMng");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
    this.filePathManager = new FornaxFilePathManager(this.application);
  }
  
  public String getDescription() { return "Fornax Generation Destination Manager"; }
  
  public FornaxGenerationDestination getGenerationDestination(int paramInt) {
    String str = 
      
      "SELECT * FROM fnGenerationDestination WHERE GenerationDestinationID = " + 
      paramInt;
    Vector vector = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxGenerationDestination", 
        true, 
        this.fornaxSettings);
    if (vector.size() == 1)
      return (FornaxGenerationDestination)vector.get(0); 
    return null;
  }
  
  public Vector getGenerationDestinations() {
    String str = 
      
      "SELECT * FROM fnGenerationDestination ORDER BY GenerationDestinationID";
    this.generationDestinations = null;
    this.generationDestinations = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxGenerationDestination", 
        true, 
        this.fornaxSettings);
    return this.generationDestinations;
  }
  
  public FornaxFilePath getFilePath(int paramInt) { return this.filePathManager.getFilePath(paramInt); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxGenerationDestinationManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */