package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class Variant extends VariantType implements FornaxDBConstants {
  protected int mVariantID;
  
  protected int mVariantInstanceGroupID;
  
  protected Template mVariantTemplate;
  
  protected GenerationDestination mVariantGenerationDestination;
  
  protected boolean mVariantIsEnabled;
  
  protected String mVariantFileNamePrefix;
  
  protected String mVariantFileNameTitle;
  
  protected String mVariantFileNameSuffix;
  
  protected String mVariantFileNameExt;
  
  protected String mVariantFileNameNumberingMode;
  
  public Variant(Hashtable paramHashtable) {
    super(paramHashtable);
    this.mVariantID = ((Integer)paramHashtable.get("variantID")).intValue();
    this.mVariantInstanceGroupID = ((Integer)paramHashtable.get("variantInstancesGroupID")).intValue();
    this.mVariantIsEnabled = ((Boolean)paramHashtable.get("variantIsEnabledForGeneration")).booleanValue();
    this.mVariantFileNamePrefix = (String)paramHashtable.get("variantFileNamePrefix");
    this.mVariantFileNameTitle = (String)paramHashtable.get("variantFileNameTitle");
    this.mVariantFileNameSuffix = (String)paramHashtable.get("variantFileNameSuffix");
    this.mVariantFileNameExt = (String)paramHashtable.get("variantFileNameExtension");
    this.mVariantFileNameNumberingMode = (String)paramHashtable.get("variantFileNameNumberingMode");
    this.mVariantTemplate = (Template)paramHashtable.get("variantTemplate");
    this.mVariantGenerationDestination = (GenerationDestination)paramHashtable.get("variantGenerationDestination");
  }
  
  public int getVariantID() { return this.mVariantID; }
  
  public int getVariantInstanceGroupID() { return this.mVariantInstanceGroupID; }
  
  public Template getVariantTemplate() { return this.mVariantTemplate; }
  
  public boolean isEnabledForGeneration() { return this.mVariantIsEnabled; }
  
  public GenerationDestination getVariantGenerationDestination() { return this.mVariantGenerationDestination; }
  
  public String getVariantFileNamePrefix() { return this.mVariantFileNamePrefix; }
  
  public String getVariantFileNameTitle() { return this.mVariantFileNameTitle; }
  
  public String getVariantFileNameSuffix() { return this.mVariantFileNameSuffix; }
  
  public String getVariantFileNameExt() { return this.mVariantFileNameExt; }
  
  public String getVariantFileNameNumberingMode() { return this.mVariantFileNameNumberingMode; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\Variant.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */