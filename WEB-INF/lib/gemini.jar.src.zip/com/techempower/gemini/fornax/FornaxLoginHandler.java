/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.gemini.Context;
/*     */ import com.techempower.gemini.Dispatcher;
/*     */ import com.techempower.gemini.Form;
/*     */ import com.techempower.gemini.FormElement;
/*     */ import com.techempower.gemini.FormHidden;
/*     */ import com.techempower.gemini.FormPasswordField;
/*     */ import com.techempower.gemini.FormTextField;
/*     */ import com.techempower.gemini.FormValidation;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import com.techempower.gemini.Handler;
/*     */ import com.techempower.gemini.pyxis.BasicSecurity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxLoginHandler
/*     */   implements Handler, FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "hLog";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   
/*     */   public FornaxLoginHandler(GeminiApplication paramGeminiApplication) {
/*  57 */     this.application = paramGeminiApplication;
/*  58 */     this.log = paramGeminiApplication.getLog("hLog");
/*  59 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public String getDescription() { return "Login"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean acceptRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
/*  77 */     if (paramString.equalsIgnoreCase("fornax-login"))
/*     */     {
/*  79 */       return handleRequest(paramDispatcher, paramContext, paramString);
/*     */     }
/*     */     
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean handleRequest(Dispatcher paramDispatcher, Context paramContext, String paramString) {
/*  92 */     BasicSecurity basicSecurity = this.fornaxSettings.getSecurity();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     boolean bool = Boolean.valueOf(paramContext.getRequestValue("logout", "false")).booleanValue();
/*     */ 
/*     */     
/* 105 */     Form form = buildLoginForm(paramContext);
/* 106 */     paramContext.putDelivery("Form", form);
/*     */     
/* 108 */     if (bool) {
/*     */       
/* 110 */       basicSecurity.logout(paramContext);
/* 111 */       paramContext.putDelivery("Confirmation", "Thank you for using Fornax.<br>To login again, enter your user name and password below.");
/*     */     }
/* 113 */     else if (!form.isUnchanged()) {
/*     */       
/* 115 */       FormValidation formValidation = form.validate();
/*     */       
/* 117 */       FormElement formElement = form.getElement("username");
/* 118 */       String str = formElement.getStringValue();
/*     */ 
/*     */       
/* 121 */       if (formValidation.isGood()) {
/*     */         
/* 123 */         String str1 = form.getStringValue("password");
/*     */         
/* 125 */         boolean bool1 = basicSecurity.login(paramContext, str, str1);
/*     */         
/* 127 */         if (bool1)
/*     */         {
/* 129 */           return paramDispatcher.redispatch(paramContext, "fornax-main-menu");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 134 */         paramContext.putDelivery("Message", "Invalid login.  Please try again.");
/* 135 */         paramContext.putDelivery("FormValidation", formValidation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 200 */         paramContext.putDelivery("Message", "Please provide a user name and passwod in order to login.");
/* 201 */         paramContext.putDelivery("FormValidation", formValidation);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 206 */     return paramContext.includeJSP("login.jsp", String.valueOf(this.fornaxSettings.getURLDirectoryPrefix()) + this.fornaxSettings.getJspDirectory(), this.fornaxSettings.useURLDirectoryPrefix());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   protected boolean cookieLogon(Dispatcher paramDispatcher, Context paramContext, String paramString) { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Form buildLoginForm(Context paramContext) {
/* 253 */     Form form = new Form(this.application, "LoginForm", this.application.getInfrastructure().getServletURL(), "POST");
/* 254 */     form.addElement(new FormHidden("cmd", "fornax-login", true));
/* 255 */     form.addElement(new FormTextField("username", true, 30));
/* 256 */     form.addElement(new FormPasswordField("password", true, 30));
/*     */ 
/*     */     
/* 259 */     form.setValues(paramContext);
/*     */     
/* 261 */     return form;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxLoginHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */