/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ import com.techempower.DataEntity;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import java.util.Calendar;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeInstance
/*     */   extends DataEntity
/*     */   implements FornaxConstants, FornaxDBConstants
/*     */ {
/*     */   protected int instanceID;
/*     */   protected int instanceContentTypeID;
/*     */   protected String instanceName;
/*     */   protected String instanceDescription;
/*     */   protected boolean instanceIsDisabled;
/*     */   protected boolean instanceIsQueuedForDeletion;
/*     */   protected Calendar instanceDateCreated;
/*     */   protected int instanceLastModifiedByUserID;
/*     */   protected Calendar instanceLastModifiedTimestamp;
/*     */   
/*     */   public FornaxContentTypeInstance() {
/*  37 */     this.instanceID = -1;
/*  38 */     this.instanceContentTypeID = -1;
/*  39 */     this.instanceName = "";
/*  40 */     this.instanceDescription = "";
/*  41 */     this.instanceIsDisabled = false;
/*  42 */     this.instanceIsQueuedForDeletion = false;
/*  43 */     this.instanceDateCreated = null;
/*  44 */     this.instanceLastModifiedByUserID = -1;
/*  45 */     this.instanceLastModifiedTimestamp = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     this.instanceDateCreated = FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM");
/*  56 */     this.instanceLastModifiedTimestamp = FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializationComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomSetMethodBindings() {
/*  73 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  75 */     hashtable.put("InstanceID", "setID");
/*  76 */     hashtable.put("InstanceContentTypeID", "setContentTypeID");
/*  77 */     hashtable.put("InstanceName", "setName");
/*  78 */     hashtable.put("InstanceDescription", "setDescription");
/*  79 */     hashtable.put("InstanceIsDisabled", "setIsDisabled");
/*  80 */     hashtable.put("InstanceIsQueuedForDeletion", "setIsQueuedForDeletion");
/*  81 */     hashtable.put("InstanceDateCreated", "setDateCreated");
/*  82 */     hashtable.put("InstanceLastModifiedByUserID", "setLastModifiedByUserID");
/*  83 */     hashtable.put("InstanceLastModifiedTimestamp", "setLastModifiedTimestamp");
/*     */     
/*  85 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public int getIdentity() { return this.instanceID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public String getTableName() { return "fnContentTypeInstance"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public String getIdentityColumnName() { return "InstanceID"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public int getID() { return this.instanceID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public int getContentTypeID() { return this.instanceContentTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public String getName() { return this.instanceName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public String getDescription() { return this.instanceDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public boolean isDisabled() { return this.instanceIsDisabled; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsDisabledAsString() {
/* 166 */     if (this.instanceIsDisabled) {
/* 167 */       return "T";
/*     */     }
/* 169 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public boolean isQueuedForDeletion() { return this.instanceIsQueuedForDeletion; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsQueuedForDeletionAsString() {
/* 181 */     if (this.instanceIsQueuedForDeletion) {
/* 182 */       return "T";
/*     */     }
/* 184 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   public Calendar getDateCreated() { return this.instanceDateCreated; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateCreatedAsString() {
/* 196 */     Calendar calendar = FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM");
/*     */     
/* 198 */     if (this.instanceDateCreated.getTime().equals(calendar.getTime())) {
/* 199 */       return "---";
/*     */     }
/* 201 */     return BasicHelper.getCalendarAsString(this.instanceDateCreated, 3, 2, "/", "   ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 208 */   public int getLastModifiedByUserID() { return this.instanceLastModifiedByUserID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public Calendar getLastModifiedTimestamp() { return this.instanceLastModifiedTimestamp; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLastModifiedTimestampAsString() {
/* 220 */     Calendar calendar = FornaxHelper.getInitializedCalendar("1900-01-01 00:00:00AM");
/*     */     
/* 222 */     if (this.instanceLastModifiedTimestamp.getTime().equals(calendar.getTime())) {
/* 223 */       return "---";
/*     */     }
/* 225 */     return BasicHelper.getCalendarAsString(this.instanceLastModifiedTimestamp, 3, 2, "/", "   ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public void setID(int paramInt) { this.instanceID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public void setContentTypeID(int paramInt) { this.instanceContentTypeID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/* 263 */     if (paramString != null) {
/* 264 */       this.instanceName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String paramString) {
/* 275 */     if (paramString != null) {
/* 276 */       this.instanceDescription = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsDisabled(String paramString) {
/* 287 */     this.instanceIsDisabled = false;
/*     */     
/* 289 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 291 */       this.instanceIsDisabled = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsQueuedForDeletion(String paramString) {
/* 303 */     this.instanceIsQueuedForDeletion = false;
/*     */     
/* 305 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 307 */       this.instanceIsQueuedForDeletion = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 319 */   public void setDateCreated(Calendar paramCalendar) { this.instanceDateCreated = paramCalendar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 330 */   public void setLastModifiedByUserID(int paramInt) { this.instanceLastModifiedByUserID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 341 */   public void setLastModifiedTimestamp(Calendar paramCalendar) { this.instanceLastModifiedTimestamp = paramCalendar; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int runUpdate(DatabaseConnector paramDatabaseConnector, boolean paramBoolean) {
/* 353 */     String str1 = "IDENTITY_VALUE";
/* 354 */     String str2 = "ROWCOUNT_VALUE";
/*     */     
/* 356 */     boolean bool = false;
/*     */     
/* 358 */     String str3 = new String("");
/* 359 */     String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
/* 360 */     String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
/*     */ 
/*     */     
/* 363 */     if (this.instanceID == -1) {
/*     */       
/* 365 */       bool = true;
/*     */       
/* 367 */       str3 = String.valueOf(str3) + "INSERT INTO " + getTableName() + 
/* 368 */         "          ( " + "instanceContentTypeID" + ", " + 
/* 369 */         "instanceName" + ", " + 
/* 370 */         "instanceDescription" + ", " + 
/* 371 */         "instanceIsDisabled" + ", " + 
/* 372 */         "instanceIsQueuedForDeletion" + ", " + 
/* 373 */         "instanceDateCreated" + ", " + 
/* 374 */         "instanceLastModifiedByUserID" + ", " + 
/* 375 */         "instanceLastModifiedTimeStamp" + 
/* 376 */         "          ) " + 
/* 377 */         "   VALUES (" + getContentTypeID() + ", '" + 
/* 378 */         getName() + "', '" + 
/* 379 */         getDescription() + "', '" + 
/* 380 */         getIsDisabledAsString() + "', '" + 
/* 381 */         getIsQueuedForDeletionAsString() + "', " + 
/* 382 */         "CURRENT_TIMESTAMP" + ", " + 
/* 383 */         getLastModifiedByUserID() + ", " + 
/* 384 */         "CURRENT_TIMESTAMP" + 
/* 385 */         "          )";
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 390 */       str3 = String.valueOf(str3) + "UPDATE " + getTableName() + 
/* 391 */         "   SET " + "instanceName" + "='" + getName() + "'," + 
/* 392 */         "instanceDescription" + "='" + getDescription() + "'," + 
/* 393 */         "instanceIsDisabled" + "='" + getIsDisabledAsString() + "'," + 
/* 394 */         "instanceIsQueuedForDeletion" + "='" + getIsQueuedForDeletionAsString() + "'";
/*     */       
/* 396 */       if (paramBoolean)
/*     */       {
/* 398 */         str3 = String.valueOf(str3) + ",instanceLastModifiedByUserID=" + getLastModifiedByUserID() + "," + 
/* 399 */           "instanceLastModifiedTimeStamp" + "=" + "CURRENT_TIMESTAMP";
/*     */       }
/*     */       
/* 402 */       str3 = String.valueOf(str3) + " WHERE " + getIdentityColumnName() + "=" + getID();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     if (bool) {
/* 409 */       str3 = String.valueOf(str3) + "; " + str4;
/*     */     } else {
/* 411 */       str3 = String.valueOf(str3) + "; " + str5;
/*     */     } 
/*     */     
/* 414 */     str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
/*     */     
/* 416 */     System.out.println("Running sql stmt:\n" + str3);
/*     */ 
/*     */     
/* 419 */     paramDatabaseConnector.setQuery(str3);
/* 420 */     paramDatabaseConnector.runQuery();
/*     */ 
/*     */     
/* 423 */     if (paramDatabaseConnector.more()) {
/*     */       
/* 425 */       paramDatabaseConnector.first();
/*     */ 
/*     */ 
/*     */       
/* 429 */       if (bool) {
/* 430 */         int j = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1);
/*     */       }
/* 432 */       int i = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 445 */     paramDatabaseConnector.close();
/*     */     
/* 447 */     return -1;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstance.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */