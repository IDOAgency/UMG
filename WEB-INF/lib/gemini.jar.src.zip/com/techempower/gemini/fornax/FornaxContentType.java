/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.DataEntity;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentType
/*     */   extends DataEntity
/*     */   implements FornaxConstants, FornaxDBConstants
/*     */ {
/*  37 */   protected int contentTypeID = -1;
/*  38 */   protected int contentTypeListPageID = -1;
/*  39 */   protected String contentTypeName = "";
/*  40 */   protected String contentTypeDescription = "";
/*     */   protected boolean contentTypeIsSingleton = false;
/*     */   protected boolean contentTypeIsListPageGenerated = false;
/*  43 */   protected int contentTypeInstancesCount = 0;
/*  44 */   protected int contentTypeInstancesGroupsCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializationComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomSetMethodBindings() {
/*  64 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  66 */     hashtable.put("ContentTypeID", "setID");
/*  67 */     hashtable.put("ContentTypeListPageID", "setListPageID");
/*  68 */     hashtable.put("ContentTypeName", "setName");
/*  69 */     hashtable.put("ContentTypeDescription", "setDescription");
/*  70 */     hashtable.put("ContentTypeIsSingleton", "setIsSingleton");
/*  71 */     hashtable.put("ContentTypeIsListPageGenerated", "setIsListPageGenerated");
/*  72 */     hashtable.put("ContentTypeInstancesCount", "setInstancesCount");
/*  73 */     hashtable.put("ContentTypeInstancesGroupsCount", "setInstancesGroupsCount");
/*     */     
/*  75 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public int getIdentity() { return this.contentTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public String getTableName() { return "fnContentType"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public String getIdentityColumnName() { return "ContentTypeID"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public int getID() { return this.contentTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public int getListPageID() { return this.contentTypeListPageID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public String getName() { return this.contentTypeName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public String getDescription() { return this.contentTypeDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public boolean isSingleton() { return this.contentTypeIsSingleton; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsSingletonAsString() {
/* 157 */     if (this.contentTypeIsSingleton)
/*     */     {
/* 159 */       return "T";
/*     */     }
/*     */ 
/*     */     
/* 163 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public boolean isListPageGenerated() { return this.contentTypeIsListPageGenerated; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIsListPageGeneratedAsString() {
/* 178 */     if (this.contentTypeIsListPageGenerated)
/*     */     {
/* 180 */       return "T";
/*     */     }
/*     */ 
/*     */     
/* 184 */     return "F";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public int getInstancesCount() { return this.contentTypeInstancesCount; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public int getInstancesGroupsCount() { return this.contentTypeInstancesGroupsCount; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   public void setID(int paramInt) { this.contentTypeID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public void setListPageID(int paramInt) { this.contentTypeListPageID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/* 237 */     if (paramString != null) {
/* 238 */       this.contentTypeName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String paramString) {
/* 249 */     if (paramString != null) {
/* 250 */       this.contentTypeDescription = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsSingleton(String paramString) {
/* 261 */     this.contentTypeIsSingleton = false;
/*     */     
/* 263 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 265 */       this.contentTypeIsSingleton = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsListPageGenerated(String paramString) {
/* 277 */     this.contentTypeIsListPageGenerated = false;
/*     */     
/* 279 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 281 */       this.contentTypeIsListPageGenerated = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 293 */   public void setInstancesCount(int paramInt) { this.contentTypeInstancesCount = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 304 */   public void setInstancesGroupsCount(int paramInt) { this.contentTypeInstancesGroupsCount = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int runUpdate(DatabaseConnector paramDatabaseConnector) {
/* 312 */     String str1 = "IDENTITY_VALUE";
/* 313 */     String str2 = "ROWCOUNT_VALUE";
/*     */     
/* 315 */     boolean bool = false;
/*     */     
/* 317 */     String str3 = new String("");
/* 318 */     String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
/* 319 */     String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
/*     */ 
/*     */     
/* 322 */     if (this.contentTypeID == -1) {
/*     */       
/* 324 */       bool = true;
/*     */       
/* 326 */       str3 = String.valueOf(str3) + "INSERT INTO " + getTableName() + 
/* 327 */         "          ( " + "contentTypeListPageID" + ", " + 
/* 328 */         "contentTypeName" + ", " + 
/* 329 */         "contentTypeDescription" + ", " + 
/* 330 */         "contentTypeIsSingleton" + ", " + 
/* 331 */         "contentTypeIsListPageGenerated" + 
/* 332 */         "          ) " + 
/* 333 */         "   VALUES (" + getListPageID() + ", " + 
/* 334 */         getName() + ", '" + 
/* 335 */         getDescription() + "', '" + 
/* 336 */         getIsSingletonAsString() + "', '" + 
/* 337 */         getIsListPageGeneratedAsString() + "'" + 
/* 338 */         "          )";
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 343 */       str3 = String.valueOf(str3) + "UPDATE " + getTableName() + 
/* 344 */         "   SET " + "contentTypeListPageID" + "=" + getListPageID() + ", " + 
/* 345 */         "contentTypeName" + "='" + getName() + "', " + 
/* 346 */         "contentTypeDescription" + "='" + getDescription() + "'," + 
/* 347 */         "contentTypeIsSingleton" + "='" + getIsSingletonAsString() + "'," + 
/* 348 */         "contentTypeIsListPageGenerated" + "='" + getIsListPageGeneratedAsString() + "'";
/*     */ 
/*     */       
/* 351 */       str3 = String.valueOf(str3) + " WHERE " + getIdentityColumnName() + "=" + getID();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     if (bool) {
/* 358 */       str3 = String.valueOf(str3) + "; " + str4;
/*     */     } else {
/* 360 */       str3 = String.valueOf(str3) + "; " + str5;
/*     */     } 
/*     */     
/* 363 */     str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
/*     */     
/* 365 */     System.out.println("Running sql stmt:\n" + str3);
/*     */ 
/*     */     
/* 368 */     paramDatabaseConnector.setQuery(str3);
/* 369 */     paramDatabaseConnector.runQuery();
/*     */ 
/*     */     
/* 372 */     if (paramDatabaseConnector.more()) {
/*     */       
/* 374 */       paramDatabaseConnector.first();
/*     */ 
/*     */ 
/*     */       
/* 378 */       if (bool) {
/* 379 */         int j = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1);
/*     */       }
/* 381 */       int i = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     paramDatabaseConnector.close();
/*     */     
/* 396 */     return -1;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */