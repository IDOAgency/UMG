package com.techempower.gemini.fornax;

import com.techempower.DataEntity;
import com.techempower.DatabaseConnector;
import java.util.Hashtable;

public class FornaxContentType extends DataEntity implements FornaxConstants, FornaxDBConstants {
  protected int contentTypeID = -1;
  
  protected int contentTypeListPageID = -1;
  
  protected String contentTypeName = "";
  
  protected String contentTypeDescription = "";
  
  protected boolean contentTypeIsSingleton = false;
  
  protected boolean contentTypeIsListPageGenerated = false;
  
  protected int contentTypeInstancesCount = 0;
  
  protected int contentTypeInstancesGroupsCount = 0;
  
  public void initializationComplete() {}
  
  public Hashtable getCustomSetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("ContentTypeID", "setID");
    hashtable.put("ContentTypeListPageID", "setListPageID");
    hashtable.put("ContentTypeName", "setName");
    hashtable.put("ContentTypeDescription", "setDescription");
    hashtable.put("ContentTypeIsSingleton", "setIsSingleton");
    hashtable.put("ContentTypeIsListPageGenerated", "setIsListPageGenerated");
    hashtable.put("ContentTypeInstancesCount", "setInstancesCount");
    hashtable.put("ContentTypeInstancesGroupsCount", "setInstancesGroupsCount");
    return hashtable;
  }
  
  public int getIdentity() { return this.contentTypeID; }
  
  public String getTableName() { return "fnContentType"; }
  
  public String getIdentityColumnName() { return "ContentTypeID"; }
  
  public int getID() { return this.contentTypeID; }
  
  public int getListPageID() { return this.contentTypeListPageID; }
  
  public String getName() { return this.contentTypeName; }
  
  public String getDescription() { return this.contentTypeDescription; }
  
  public boolean isSingleton() { return this.contentTypeIsSingleton; }
  
  public String getIsSingletonAsString() {
    if (this.contentTypeIsSingleton)
      return "T"; 
    return "F";
  }
  
  public boolean isListPageGenerated() { return this.contentTypeIsListPageGenerated; }
  
  public String getIsListPageGeneratedAsString() {
    if (this.contentTypeIsListPageGenerated)
      return "T"; 
    return "F";
  }
  
  public int getInstancesCount() { return this.contentTypeInstancesCount; }
  
  public int getInstancesGroupsCount() { return this.contentTypeInstancesGroupsCount; }
  
  public void setID(int paramInt) { this.contentTypeID = paramInt; }
  
  public void setListPageID(int paramInt) { this.contentTypeListPageID = paramInt; }
  
  public void setName(String paramString) {
    if (paramString != null)
      this.contentTypeName = paramString; 
  }
  
  public void setDescription(String paramString) {
    if (paramString != null)
      this.contentTypeDescription = paramString; 
  }
  
  public void setIsSingleton(String paramString) {
    this.contentTypeIsSingleton = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.contentTypeIsSingleton = true; 
  }
  
  public void setIsListPageGenerated(String paramString) {
    this.contentTypeIsListPageGenerated = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.contentTypeIsListPageGenerated = true; 
  }
  
  public void setInstancesCount(int paramInt) { this.contentTypeInstancesCount = paramInt; }
  
  public void setInstancesGroupsCount(int paramInt) { this.contentTypeInstancesGroupsCount = paramInt; }
  
  public int runUpdate(DatabaseConnector paramDatabaseConnector) {
    String str1 = "IDENTITY_VALUE";
    String str2 = "ROWCOUNT_VALUE";
    boolean bool = false;
    String str3 = new String("");
    String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
    String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
    if (this.contentTypeID == -1) {
      bool = true;
      str3 = String.valueOf(str3) + "INSERT INTO " + getTableName() + 
        "          ( " + "contentTypeListPageID" + ", " + 
        "contentTypeName" + ", " + 
        "contentTypeDescription" + ", " + 
        "contentTypeIsSingleton" + ", " + 
        "contentTypeIsListPageGenerated" + 
        "          ) " + 
        "   VALUES (" + getListPageID() + ", " + 
        getName() + ", '" + 
        getDescription() + "', '" + 
        getIsSingletonAsString() + "', '" + 
        getIsListPageGeneratedAsString() + "'" + 
        "          )";
    } else {
      str3 = String.valueOf(str3) + "UPDATE " + getTableName() + 
        "   SET " + "contentTypeListPageID" + "=" + getListPageID() + ", " + 
        "contentTypeName" + "='" + getName() + "', " + 
        "contentTypeDescription" + "='" + getDescription() + "'," + 
        "contentTypeIsSingleton" + "='" + getIsSingletonAsString() + "'," + 
        "contentTypeIsListPageGenerated" + "='" + getIsListPageGeneratedAsString() + "'";
      str3 = String.valueOf(str3) + " WHERE " + getIdentityColumnName() + "=" + getID();
    } 
    if (bool) {
      str3 = String.valueOf(str3) + "; " + str4;
    } else {
      str3 = String.valueOf(str3) + "; " + str5;
    } 
    str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
    System.out.println("Running sql stmt:\n" + str3);
    paramDatabaseConnector.setQuery(str3);
    paramDatabaseConnector.runQuery();
    if (paramDatabaseConnector.more()) {
      paramDatabaseConnector.first();
      if (bool)
        int j = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1); 
      int i = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
    } 
    paramDatabaseConnector.close();
    return -1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */