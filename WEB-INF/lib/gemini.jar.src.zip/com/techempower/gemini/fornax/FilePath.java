/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilePath
/*    */   implements FornaxDBConstants
/*    */ {
/*    */   protected int mFilePathID;
/*    */   protected String mFilePathName;
/*    */   protected boolean mFilePathIsRelative;
/*    */   
/*    */   public FilePath(Hashtable paramHashtable) {
/* 41 */     this.mFilePathID = ((Integer)paramHashtable.get("filePathID")).intValue();
/* 42 */     this.mFilePathName = (String)paramHashtable.get("filePathName");
/* 43 */     this.mFilePathIsRelative = ((Boolean)paramHashtable.get("filePathIsRelative")).booleanValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public int getFilePathID() { return this.mFilePathID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public String getFilePathName() { return this.mFilePathName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   public String getFormattedFilePathName() { return FornaxHelper.formatFilePath(this.mFilePathName); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 78 */   public boolean isFilePathRelative() { return this.mFilePathIsRelative; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FilePath.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */