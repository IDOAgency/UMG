package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class FilePath implements FornaxDBConstants {
  protected int mFilePathID;
  
  protected String mFilePathName;
  
  protected boolean mFilePathIsRelative;
  
  public FilePath(Hashtable paramHashtable) {
    this.mFilePathID = ((Integer)paramHashtable.get("filePathID")).intValue();
    this.mFilePathName = (String)paramHashtable.get("filePathName");
    this.mFilePathIsRelative = ((Boolean)paramHashtable.get("filePathIsRelative")).booleanValue();
  }
  
  public int getFilePathID() { return this.mFilePathID; }
  
  public String getFilePathName() { return this.mFilePathName; }
  
  public String getFormattedFilePathName() { return FornaxHelper.formatFilePath(this.mFilePathName); }
  
  public boolean isFilePathRelative() { return this.mFilePathIsRelative; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FilePath.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */