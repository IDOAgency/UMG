package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class Template implements FornaxDBConstants {
  protected int mTemplateID;
  
  protected FilePath mTemplateFilePath;
  
  protected String mTemplateFileName;
  
  protected String mTemplateFileDescription;
  
  public Template(Hashtable paramHashtable) {
    this.mTemplateID = ((Integer)paramHashtable.get("contentTypeTemplateID")).intValue();
    this.mTemplateFilePath = (FilePath)paramHashtable.get("contentTypeTemplateFilePath");
    this.mTemplateFileName = (String)paramHashtable.get("contentTypeTemplateFileName");
    this.mTemplateFileDescription = (String)paramHashtable.get("contentTypeTemplateFileDescription");
  }
  
  public int getTemplateID() { return this.mTemplateID; }
  
  public FilePath getFilePath() { return this.mTemplateFilePath; }
  
  public String getTemplateFileName() { return this.mTemplateFileName; }
  
  public String getTemplateFileDescription() { return this.mTemplateFileDescription; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\Template.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */