/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Template
/*    */   implements FornaxDBConstants
/*    */ {
/*    */   protected int mTemplateID;
/*    */   protected FilePath mTemplateFilePath;
/*    */   protected String mTemplateFileName;
/*    */   protected String mTemplateFileDescription;
/*    */   
/*    */   public Template(Hashtable paramHashtable) {
/* 43 */     this.mTemplateID = ((Integer)paramHashtable.get("contentTypeTemplateID")).intValue();
/* 44 */     this.mTemplateFilePath = (FilePath)paramHashtable.get("contentTypeTemplateFilePath");
/* 45 */     this.mTemplateFileName = (String)paramHashtable.get("contentTypeTemplateFileName");
/* 46 */     this.mTemplateFileDescription = (String)paramHashtable.get("contentTypeTemplateFileDescription");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public int getTemplateID() { return this.mTemplateID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public FilePath getFilePath() { return this.mTemplateFilePath; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   public String getTemplateFileName() { return this.mTemplateFileName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 81 */   public String getTemplateFileDescription() { return this.mTemplateFileDescription; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\Template.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */