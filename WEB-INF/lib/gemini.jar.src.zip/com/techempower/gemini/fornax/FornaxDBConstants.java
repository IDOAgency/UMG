package com.techempower.gemini.fornax;

public interface FornaxDBConstants {
  public static final String GROUP_ID = "InstancesGroupID";
  
  public static final String GROUP_NAME = "InstancesGroupName";
  
  public static final String GROUP_DESC = "InstancesGroupDescription";
  
  public static final String GROUP_IS_SINGLETON = "InstancesGroupIsSingleton";
  
  public static final String GROUP_IS_LISTPAGE_GENERATED = "InstancesGroupIsListPageGenerated";
  
  public static final String GROUP_LISTPAGE_ID = "InstancesGroupListPageID";
  
  public static final String GROUP_CONTENTTYPE_ID = "InstancesGroupContentTypeID";
  
  public static final String GROUP_CONTENTTYPE_NAME = "contentTypeName";
  
  public static final String GROUP_IS_INSTANCE_GENERATION_ENABLED = "InstancesGroupIsInstanceGenerationEnabled";
  
  public static final String GROUP_LISTPAGE = "groupListPage";
  
  public static final String GROUP_CONTENTTYPE = "groupContentType";
  
  public static final String GROUP_INSTANCES = "groupInstances";
  
  public static final String GROUP_VARIANTS = "groupVariants";
  
  public static final String CONTENTTYPE_ID = "contentTypeID";
  
  public static final String CONTENTTYPE_NAME = "contentTypeName";
  
  public static final String CONTENTTYPE_DESC = "contentTypeDescription";
  
  public static final String CONTENTTYPE_IS_SINGLETON = "contentTypeIsSingleton";
  
  public static final String CONTENTTYPE_IS_LISTPAGE_GENERATED = "contentTypeIsListPageGenerated";
  
  public static final String CONTENTTYPE_LISTPAGE_ID = "contentTypeListPageID";
  
  public static final String CONTENTTYPE_LISTPAGE = "contentTypeListPage";
  
  public static final String CONTENTTYPE_FIELDS = "contentTypeFields";
  
  public static final String CONTENTTYPE_GROUPS = "contentTypeGroups";
  
  public static final String FIELD_ID = "instanceFieldID";
  
  public static final String FIELD_CONTENTTYPE_ID = "instanceContentTypeID";
  
  public static final String FIELD_NAME = "instanceFieldName";
  
  public static final String FIELD_DESC = "instanceFieldDescription";
  
  public static final String FIELD_DATATYPE_ID = "instanceDataTypeID";
  
  public static final String FIELD_DATATYPE_NAME = "instanceDataTypeName";
  
  public static final String FIELD_DATATYPE_DESC = "instanceDataTypeDescription";
  
  public static final String INSTANCE_ID = "instanceID";
  
  public static final String INSTANCE_NAME = "instanceName";
  
  public static final String INSTANCE_DESC = "instanceDescription";
  
  public static final String INSTANCE_GROUP_ID = "instanceGroupID";
  
  public static final String INSTANCE_GROUP_NAME = "instancesGroupName";
  
  public static final String INSTANCE_CONTENTTYPE_ID = "instanceContentTypeID";
  
  public static final String INSTANCE_CONTENTTYPE_NAME = "ContentTypeName";
  
  public static final String INSTANCE_SEQUENCE_NO = "instanceSequenceNumber";
  
  public static final String INSTANCE_IS_DISABLED = "instanceIsDisabled";
  
  public static final String INSTANCE_IS_QUEUED_FOR_DELETE = "instanceIsQueuedForDeletion";
  
  public static final String INSTANCE_DATE_CREATED = "instanceDateCreated";
  
  public static final String INSTANCE_LAST_MODIFIED_USER_ID = "instanceLastModifiedByUserID";
  
  public static final String INSTANCE_LAST_MODIFIED_TIMESTAMP = "instanceLastModifiedTimeStamp";
  
  public static final String INSTANCE_FIELDS = "instanceFields";
  
  public static final String FIELD_VALUE_ID = "valueID";
  
  public static final String FIELD_VALUE_INSTANCE_ID = "valueInstance";
  
  public static final String FIELD_VALUE = "instanceFieldValue";
  
  public static final int FIELD_VALUE_ID_DEFAULT = -1;
  
  public static final String FIELD_DATEVALUE_ID = "dateValueID";
  
  public static final String FIELD_DATEVALUE_INSTANCE_ID = "dateValueInstance";
  
  public static final String FIELD_DATEVALUE = "dateValueData";
  
  public static final String FIELD_DATEVALUE_DEFAULT = "01/01/1900 12:00 AM PDT";
  
  public static final String FIELD_INTEGERVALUE_ID = "intergerValueID";
  
  public static final String FIELD_INTEGERVALUE_INSTANCE_ID = "integerValueInstance";
  
  public static final String FIELD_INTEGERVALUE = "integerValueData";
  
  public static final String FIELD_INTEGERVALUE_DEFAULT = "0";
  
  public static final String FIELD_FLOATVALUE_ID = "floatingPointValueID";
  
  public static final String FIELD_FLOATVALUE_INSTANCE_ID = "floatingPointValueInstance";
  
  public static final String FIELD_FLOATVALUE = "floatingPointValueData";
  
  public static final String FIELD_FLOATVALUE_DEFAULT = "0";
  
  public static final String FIELD_STRINGVALUE_ID = "stringPointValueID";
  
  public static final String FIELD_STRINGVALUE_INSTANCE_ID = "stringPointValueInstance";
  
  public static final String FIELD_STRINGVALUE = "stringPointValueData";
  
  public static final String FIELD_STRINGVALUE_DEFAULT = "";
  
  public static final String VARIANT_TYPE_ID = "variantTypeID";
  
  public static final String VARIANT_TYPE_CODE = "variantTypeCode";
  
  public static final String VARIANT_TYPE_DESC = "variantTypeDescription";
  
  public static final String VARIANT_ID = "variantID";
  
  public static final String VARIANT_INSTANCE_GROUP_ID = "variantInstancesGroupID";
  
  public static final String VARIANT_ISENABLED = "variantIsEnabledForGeneration";
  
  public static final String VARIANT_FILENAME_PREFIX = "variantFileNamePrefix";
  
  public static final String VARIANT_FILENAME_TITLE = "variantFileNameTitle";
  
  public static final String VARIANT_FILENAME_SUFFIX = "variantFileNameSuffix";
  
  public static final String VARIANT_FILENAME_EXT = "variantFileNameExtension";
  
  public static final String VARIANT_FILENAME_NUMBERING_MODE = "variantFileNameNumberingMode";
  
  public static final String VARIANT_TEMPLATE_ID = "variantTemplateID";
  
  public static final String VARIANT_GENERATIONDESTINATION_ID = "variantGenerationDestinationID";
  
  public static final String VARIANT_TEMPLATE = "variantTemplate";
  
  public static final String VARIANT_GENERATIONDESTINATION = "variantGenerationDestination";
  
  public static final String LISTPAGE_ID = "listPageID";
  
  public static final String LISTPAGE_FILENAME_PREFIX = "listPageFileNamePrefix";
  
  public static final String LISTPAGE_FILENAME_TITLE = "listPageFileNameTitle";
  
  public static final String LISTPAGE_FILENAME_SUFFIX = "listPageFileNameSuffix";
  
  public static final String LISTPAGE_FILENAME_EXT = "listPageFileNameExtension";
  
  public static final String LISTPAGE_TEMPLATE_ID = "listPageTemplateID";
  
  public static final String LISTPAGE_GENERATIONDESTINATION_ID = "listPageGenerationDestinationID";
  
  public static final String LISTPAGE_TEMPLATE = "listPageTemplate";
  
  public static final String LISTPAGE_GENERATIONDESTINATION = "listPageGenerationDestination";
  
  public static final String TEMPLATE_ID = "contentTypeTemplateID";
  
  public static final String TEMPLATE_FILENAME = "contentTypeTemplateFileName";
  
  public static final String TEMPLATE_FILEDESC = "contentTypeTemplateFileDescription";
  
  public static final String TEMPLATE_FILEPATH_ID = "contentTypeTemplateFilePathID";
  
  public static final String TEMPLATE_FILEPATH = "contentTypeTemplateFilePath";
  
  public static final String GENERATIONDESITNATION_ID = "generationDestinationID";
  
  public static final String GENERATIONDESITNATION_FILEPATH_ID = "generationDestinationFilePathID";
  
  public static final String GENERATIONDESITNATION_NAME = "generationDestinationName";
  
  public static final String GENERATIONDESITNATION_DESC = "generationDestinationDesc";
  
  public static final String GENERATIONDESITNATION_SERVER_NETWORK_NAME = "generationDestinationServerNetworkName";
  
  public static final String GENERATIONDESITNATION_SERVER_DNS_NAME = "generationDestinationServerDNSName";
  
  public static final String GENERATIONDESITNATION_SERVER_IP_ADDRESS = "generationDestinationServerIPAddress";
  
  public static final String GENERATIONDESITNATION_LOGON_USERNAME = "generationDestinationLogonUserName";
  
  public static final String GENERATIONDESITNATION_LOGON_PASSWORD = "generationDestinationLogonPassword";
  
  public static final String GENERATIONDESITNATION_FILEPATH = "generationDestinationFilePath";
  
  public static final String FILEPATH_ID = "filePathID";
  
  public static final String FILEPATH_NAME = "filePathName";
  
  public static final String FILEPATH_IS_RELATIVE = "filePathIsRelative";
  
  public static final String DATATYPE_DATE = "DATE";
  
  public static final String DATATYPE_INTEGER = "INTEGER";
  
  public static final String DATATYPE_FLOATINGPOINT = "FLOATINGPOINT";
  
  public static final String DATATYPE_STRING = "STRING";
  
  public static final String NUMBERING_MODE_SEQ = "S";
  
  public static final String NUMBERING_MODE_ID = "I";
  
  public static final String NUMBERING_MODE_NONE = "N";
  
  public static final String TEMPLATE_TAG_DELTA = "delta=";
  
  public static final String TEMPLATE_TAG_CONTENTTYPE = "type=";
  
  public static final String TEMPLATE_TAG_GROUP = "typegroup=";
  
  public static final String TEMPLATE_TAG_VARIANT = "variant=";
  
  public static final String TEMPLATE_TAG_FIELD = "field=";
  
  public static final String TEMPLATE_TAG_BEFORE = "before=";
  
  public static final String TEMPLATE_TAG_AFTER = "after=";
  
  public static final String TEMPLATE_TAG_START = "[[";
  
  public static final String TEMPLATE_TAG_END = "]]";
  
  public static final String TEMPLATE_TAG_ENDLOOP = "[[content-endloop]]";
  
  public static final String END_LINE = "\n";
  
  public static final String NONE = "[none]";
  
  public static final boolean MULTIPLEGROUPS = false;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxDBConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */