package com.techempower.gemini.fornax;

import com.techempower.DataEntity;
import com.techempower.DatabaseConnector;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Hashtable;

public class FornaxContentTypeInstanceFieldValue extends DataEntity implements FornaxConstants, FornaxDBConstants {
  protected int instanceID = -1;
  
  protected int instanceContentTypeID = -1;
  
  protected int instanceFieldID = -1;
  
  protected int instanceDataTypeID = -1;
  
  protected int instanceFieldSequenceNumber = -1;
  
  protected String instanceFieldValue = "";
  
  protected String instanceFieldName = "";
  
  protected String instanceFieldDescription = "";
  
  protected String instanceDataTypeName = "";
  
  protected String instanceDataTypeDescription = "";
  
  protected boolean instanceFieldValueIsRequired = true;
  
  protected int instanceFieldStringMaxLength = -1;
  
  protected float instanceFieldNumericValueMin = 0.0F;
  
  protected float instanceFieldNumericValueMax = 0.0F;
  
  protected final String valuesTablePrefix = "fnContentType";
  
  protected final String valuesTableSuffix = "Value";
  
  protected final String valuesColumnSuffix = "ValueData";
  
  public void initializationComplete() {}
  
  public Hashtable getCustomSetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("InstanceID", "setID");
    hashtable.put("InstanceContentTypeID", "setContentTypeID");
    hashtable.put("InstanceFieldID", "setFieldID");
    hashtable.put("InstanceDataTypeID", "setDataTypeID");
    hashtable.put("InstanceFieldSequenceNumber", "setFieldSequenceNumber");
    hashtable.put("InstanceFieldValue", "setFieldValue");
    hashtable.put("InstanceFieldName", "setFieldName");
    hashtable.put("InstanceFieldDescription", "setFieldDescription");
    hashtable.put("InstanceFieldValueIsRequired", "setFieldValueIsRequired");
    hashtable.put("InstanceFieldStringMaxLength", "setFieldStringMaxLength");
    hashtable.put("InstanceFieldNumericValueMin", "setFieldNumericValueMin");
    hashtable.put("InstanceFieldNumericValueMax", "setFieldNumericValueMax");
    hashtable.put("InstanceDataTypeName", "setDataTypeName");
    hashtable.put("InstanceDataTypeDescription", "setDataTypeDescription");
    return hashtable;
  }
  
  public int getIdentity() { return this.instanceID; }
  
  public String getTableName() { return "fnContentTypeInstanceFieldValue"; }
  
  public String getIdentityColumnName() { return "InstanceID"; }
  
  public int getID() { return this.instanceID; }
  
  public int getContentTypeID() { return this.instanceContentTypeID; }
  
  public int getFieldID() { return this.instanceFieldID; }
  
  public int getDataTypeID() { return this.instanceDataTypeID; }
  
  public int getFieldSequenceNumber() { return this.instanceFieldSequenceNumber; }
  
  public String getFieldValue() {
    String str = this.instanceFieldValue;
    if (str != null)
      if (this.instanceDataTypeName.equals("DATE")) {
        Calendar calendar = FornaxHelper.getInitializedCalendar(str);
        str = DateFormat.getDateInstance(2).format(calendar.getTime()).replace('.', '/');
      }  
    return str;
  }
  
  public String getFieldName() { return this.instanceFieldName; }
  
  public String getFieldDescription() { return this.instanceFieldDescription; }
  
  public boolean isFieldValueRequired() { return this.instanceFieldValueIsRequired; }
  
  public int getFieldStringMaxLength() { return this.instanceFieldStringMaxLength; }
  
  public float getFieldNumericValueMin() { return this.instanceFieldNumericValueMin; }
  
  public float getFieldNumericValueMax() { return this.instanceFieldNumericValueMax; }
  
  public String getDataTypeName() { return this.instanceDataTypeName; }
  
  public String getDataTypeDescription() { return this.instanceDataTypeDescription; }
  
  public void setID(int paramInt) { this.instanceID = paramInt; }
  
  public void setContentTypeID(int paramInt) { this.instanceContentTypeID = paramInt; }
  
  public void setFieldID(int paramInt) { this.instanceFieldID = paramInt; }
  
  public void setDataTypeID(int paramInt) { this.instanceDataTypeID = paramInt; }
  
  public void setFieldSequenceNumber(int paramInt) { this.instanceFieldSequenceNumber = paramInt; }
  
  public void setFieldValue(String paramString) {
    if (paramString != null)
      this.instanceFieldValue = paramString; 
  }
  
  public void setFieldName(String paramString) {
    if (paramString != null)
      this.instanceFieldName = paramString; 
  }
  
  public void setFieldValueIsRequired(String paramString) {
    this.instanceFieldValueIsRequired = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.instanceFieldValueIsRequired = true; 
  }
  
  public void setFieldStringMaxLength(int paramInt) { this.instanceFieldStringMaxLength = paramInt; }
  
  public void setFieldNumericValueMin(float paramFloat) { this.instanceFieldNumericValueMin = paramFloat; }
  
  public void setFieldNumericValueMax(float paramFloat) { this.instanceFieldNumericValueMax = paramFloat; }
  
  public void setFieldDescription(String paramString) {
    if (paramString != null)
      this.instanceFieldDescription = paramString; 
  }
  
  public void setDataTypeName(String paramString) {
    if (paramString != null)
      this.instanceDataTypeName = paramString; 
  }
  
  public void setDataTypeDescription(String paramString) {
    if (paramString != null)
      this.instanceDataTypeDescription = paramString; 
  }
  
  public int runUpdate(DatabaseConnector paramDatabaseConnector) {
    String str1 = "IDENTITY_VALUE";
    String str2 = "ROWCOUNT_VALUE";
    String str3 = new String("");
    String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
    String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
    boolean bool = false;
    int i = getID();
    int j = getFieldID();
    String str6 = getDataTypeName();
    String str7 = "fnContentType" + str6 + "Value";
    String str8 = String.valueOf(str6) + "ValueData";
    String str9 = new String("");
    String str10 = new String("");
    if (str6.equalsIgnoreCase("DATE") || 
      str6.equalsIgnoreCase("STRING")) {
      str9 = "'";
      str10 = "'";
    } 
    String str11 = "SELECT count(*) as 'RowCount' FROM " + 
      str7 + 
      " WHERE " + str6 + "ValueInstanceID = " + i + 
      " AND " + str6 + "ValueFieldID = " + j;
    paramDatabaseConnector.setQuery(str11);
    paramDatabaseConnector.runQuery();
    if (paramDatabaseConnector.more()) {
      paramDatabaseConnector.first();
      if (paramDatabaseConnector.getInt("RowCount", -1) == 1)
        bool = true; 
    } 
    paramDatabaseConnector.close();
    if (bool) {
      str3 = 
        "UPDATE " + str7 + 
        " SET " + str8 + " = " + str9 + getFieldValue() + str10 + 
        " WHERE " + str6 + "ValueInstanceID = " + i + 
        " AND " + str6 + "ValueFieldID = " + j;
    } else {
      str3 = 
        "INSERT INTO " + str7 + "(" + str6 + "ValueInstanceID, " + 
        str6 + "ValueFieldID, " + 
        str6 + "ValueData)" + 
        " VALUES (" + i + ", " + 
        j + ", " + 
        str9 + getFieldValue() + str10 + ")";
    } 
    if (!bool) {
      str3 = String.valueOf(str3) + "; " + str4;
    } else {
      str3 = String.valueOf(str3) + "; " + str5;
    } 
    str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
    System.out.println("Running sql stmt:\n" + str3);
    paramDatabaseConnector.setQuery(str3);
    paramDatabaseConnector.runQuery();
    if (paramDatabaseConnector.more()) {
      paramDatabaseConnector.first();
      if (!bool)
        int m = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1); 
      int k = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
    } 
    paramDatabaseConnector.close();
    return -1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstanceFieldValue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */