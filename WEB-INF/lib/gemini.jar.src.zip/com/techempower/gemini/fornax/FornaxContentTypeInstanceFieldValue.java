/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.DataEntity;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeInstanceFieldValue
/*     */   extends DataEntity
/*     */   implements FornaxConstants, FornaxDBConstants
/*     */ {
/*  39 */   protected int instanceID = -1;
/*  40 */   protected int instanceContentTypeID = -1;
/*  41 */   protected int instanceFieldID = -1;
/*  42 */   protected int instanceDataTypeID = -1;
/*     */   
/*  44 */   protected int instanceFieldSequenceNumber = -1;
/*     */   
/*  46 */   protected String instanceFieldValue = "";
/*  47 */   protected String instanceFieldName = "";
/*  48 */   protected String instanceFieldDescription = "";
/*  49 */   protected String instanceDataTypeName = "";
/*  50 */   protected String instanceDataTypeDescription = "";
/*     */   
/*     */   protected boolean instanceFieldValueIsRequired = true;
/*  53 */   protected int instanceFieldStringMaxLength = -1;
/*  54 */   protected float instanceFieldNumericValueMin = 0.0F;
/*  55 */   protected float instanceFieldNumericValueMax = 0.0F;
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected final String valuesTablePrefix = "fnContentType";
/*  60 */   protected final String valuesTableSuffix = "Value";
/*  61 */   protected final String valuesColumnSuffix = "ValueData";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializationComplete() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getCustomSetMethodBindings() {
/*  81 */     Hashtable hashtable = new Hashtable();
/*     */     
/*  83 */     hashtable.put("InstanceID", "setID");
/*  84 */     hashtable.put("InstanceContentTypeID", "setContentTypeID");
/*  85 */     hashtable.put("InstanceFieldID", "setFieldID");
/*  86 */     hashtable.put("InstanceDataTypeID", "setDataTypeID");
/*  87 */     hashtable.put("InstanceFieldSequenceNumber", "setFieldSequenceNumber");
/*  88 */     hashtable.put("InstanceFieldValue", "setFieldValue");
/*  89 */     hashtable.put("InstanceFieldName", "setFieldName");
/*  90 */     hashtable.put("InstanceFieldDescription", "setFieldDescription");
/*  91 */     hashtable.put("InstanceFieldValueIsRequired", "setFieldValueIsRequired");
/*  92 */     hashtable.put("InstanceFieldStringMaxLength", "setFieldStringMaxLength");
/*  93 */     hashtable.put("InstanceFieldNumericValueMin", "setFieldNumericValueMin");
/*  94 */     hashtable.put("InstanceFieldNumericValueMax", "setFieldNumericValueMax");
/*  95 */     hashtable.put("InstanceDataTypeName", "setDataTypeName");
/*  96 */     hashtable.put("InstanceDataTypeDescription", "setDataTypeDescription");
/*     */     
/*  98 */     return hashtable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   public int getIdentity() { return this.instanceID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public String getTableName() { return "fnContentTypeInstanceFieldValue"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public String getIdentityColumnName() { return "InstanceID"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public int getID() { return this.instanceID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public int getContentTypeID() { return this.instanceContentTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public int getFieldID() { return this.instanceFieldID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   public int getDataTypeID() { return this.instanceDataTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public int getFieldSequenceNumber() { return this.instanceFieldSequenceNumber; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFieldValue() {
/* 179 */     String str = this.instanceFieldValue;
/*     */     
/* 181 */     if (str != null)
/*     */     {
/* 183 */       if (this.instanceDataTypeName.equals("DATE")) {
/*     */         
/* 185 */         Calendar calendar = FornaxHelper.getInitializedCalendar(str);
/* 186 */         str = DateFormat.getDateInstance(2).format(calendar.getTime()).replace('.', '/');
/*     */       } 
/*     */     }
/* 189 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public String getFieldName() { return this.instanceFieldName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   public String getFieldDescription() { return this.instanceFieldDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public boolean isFieldValueRequired() { return this.instanceFieldValueIsRequired; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 213 */   public int getFieldStringMaxLength() { return this.instanceFieldStringMaxLength; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   public float getFieldNumericValueMin() { return this.instanceFieldNumericValueMin; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public float getFieldNumericValueMax() { return this.instanceFieldNumericValueMax; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public String getDataTypeName() { return this.instanceDataTypeName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public String getDataTypeDescription() { return this.instanceDataTypeDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   public void setID(int paramInt) { this.instanceID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public void setContentTypeID(int paramInt) { this.instanceContentTypeID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   public void setFieldID(int paramInt) { this.instanceFieldID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   public void setDataTypeID(int paramInt) { this.instanceDataTypeID = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 296 */   public void setFieldSequenceNumber(int paramInt) { this.instanceFieldSequenceNumber = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldValue(String paramString) {
/* 307 */     if (paramString != null) {
/* 308 */       this.instanceFieldValue = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldName(String paramString) {
/* 319 */     if (paramString != null) {
/* 320 */       this.instanceFieldName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldValueIsRequired(String paramString) {
/* 331 */     this.instanceFieldValueIsRequired = false;
/*     */     
/* 333 */     if (paramString.trim().equalsIgnoreCase("T"))
/*     */     {
/* 335 */       this.instanceFieldValueIsRequired = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 347 */   public void setFieldStringMaxLength(int paramInt) { this.instanceFieldStringMaxLength = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 358 */   public void setFieldNumericValueMin(float paramFloat) { this.instanceFieldNumericValueMin = paramFloat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 369 */   public void setFieldNumericValueMax(float paramFloat) { this.instanceFieldNumericValueMax = paramFloat; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFieldDescription(String paramString) {
/* 380 */     if (paramString != null) {
/* 381 */       this.instanceFieldDescription = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataTypeName(String paramString) {
/* 392 */     if (paramString != null) {
/* 393 */       this.instanceDataTypeName = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataTypeDescription(String paramString) {
/* 404 */     if (paramString != null) {
/* 405 */       this.instanceDataTypeDescription = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int runUpdate(DatabaseConnector paramDatabaseConnector) {
/* 417 */     String str1 = "IDENTITY_VALUE";
/* 418 */     String str2 = "ROWCOUNT_VALUE";
/*     */     
/* 420 */     String str3 = new String("");
/* 421 */     String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
/* 422 */     String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
/*     */     
/* 424 */     boolean bool = false;
/*     */     
/* 426 */     int i = getID();
/* 427 */     int j = getFieldID();
/*     */     
/* 429 */     String str6 = getDataTypeName();
/*     */     
/* 431 */     String str7 = "fnContentType" + str6 + "Value";
/* 432 */     String str8 = String.valueOf(str6) + "ValueData";
/*     */     
/* 434 */     String str9 = new String("");
/* 435 */     String str10 = new String("");
/*     */     
/* 437 */     if (str6.equalsIgnoreCase("DATE") || 
/* 438 */       str6.equalsIgnoreCase("STRING")) {
/*     */       
/* 440 */       str9 = "'";
/* 441 */       str10 = "'";
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 446 */     String str11 = "SELECT count(*) as 'RowCount' FROM " + 
/* 447 */       str7 + 
/* 448 */       " WHERE " + str6 + "ValueInstanceID = " + i + 
/* 449 */       " AND " + str6 + "ValueFieldID = " + j;
/*     */     
/* 451 */     paramDatabaseConnector.setQuery(str11);
/* 452 */     paramDatabaseConnector.runQuery();
/*     */     
/* 454 */     if (paramDatabaseConnector.more()) {
/*     */       
/* 456 */       paramDatabaseConnector.first();
/* 457 */       if (paramDatabaseConnector.getInt("RowCount", -1) == 1)
/* 458 */         bool = true; 
/*     */     } 
/* 460 */     paramDatabaseConnector.close();
/*     */     
/* 462 */     if (bool) {
/*     */       
/* 464 */       str3 = 
/* 465 */         "UPDATE " + str7 + 
/* 466 */         " SET " + str8 + " = " + str9 + getFieldValue() + str10 + 
/* 467 */         " WHERE " + str6 + "ValueInstanceID = " + i + 
/* 468 */         " AND " + str6 + "ValueFieldID = " + j;
/*     */     }
/*     */     else {
/*     */       
/* 472 */       str3 = 
/* 473 */         "INSERT INTO " + str7 + "(" + str6 + "ValueInstanceID, " + 
/* 474 */         str6 + "ValueFieldID, " + 
/* 475 */         str6 + "ValueData)" + 
/* 476 */         " VALUES (" + i + ", " + 
/* 477 */         j + ", " + 
/* 478 */         str9 + getFieldValue() + str10 + ")";
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 484 */     if (!bool) {
/* 485 */       str3 = String.valueOf(str3) + "; " + str4;
/*     */     } else {
/* 487 */       str3 = String.valueOf(str3) + "; " + str5;
/*     */     } 
/*     */     
/* 490 */     str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
/*     */     
/* 492 */     System.out.println("Running sql stmt:\n" + str3);
/*     */ 
/*     */     
/* 495 */     paramDatabaseConnector.setQuery(str3);
/* 496 */     paramDatabaseConnector.runQuery();
/*     */ 
/*     */     
/* 499 */     if (paramDatabaseConnector.more()) {
/*     */       
/* 501 */       paramDatabaseConnector.first();
/*     */ 
/*     */ 
/*     */       
/* 505 */       if (!bool) {
/* 506 */         int m = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1);
/*     */       }
/* 508 */       int k = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 521 */     paramDatabaseConnector.close();
/*     */     
/* 523 */     return -1;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstanceFieldValue.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */