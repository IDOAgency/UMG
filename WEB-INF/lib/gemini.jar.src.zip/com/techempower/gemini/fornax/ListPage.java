/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListPage
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected int mListPageID;
/*     */   protected Template mListPageTemplate;
/*     */   protected GenerationDestination mListPageGenerationDestination;
/*     */   protected String mListPageFileNamePrefix;
/*     */   protected String mListPageFileNameTitle;
/*     */   protected String mListPageFileNameSuffix;
/*     */   protected String mListPageFileNameExt;
/*     */   
/*     */   public ListPage(Hashtable paramHashtable) {
/*  47 */     this.mListPageID = ((Integer)paramHashtable.get("listPageID")).intValue();
/*  48 */     this.mListPageTemplate = (Template)paramHashtable.get("listPageTemplate");
/*  49 */     this.mListPageGenerationDestination = (GenerationDestination)paramHashtable.get("listPageGenerationDestination");
/*  50 */     this.mListPageFileNamePrefix = (String)paramHashtable.get("listPageFileNamePrefix");
/*  51 */     this.mListPageFileNameTitle = (String)paramHashtable.get("listPageFileNameTitle");
/*  52 */     this.mListPageFileNameSuffix = (String)paramHashtable.get("listPageFileNameSuffix");
/*  53 */     this.mListPageFileNameExt = (String)paramHashtable.get("listPageFileNameExtension");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public int getListPageID() { return this.mListPageID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public Template getListPageTemplate() { return this.mListPageTemplate; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public GenerationDestination getListPageGenerationDestination() { return this.mListPageGenerationDestination; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public String getListPageFileNamePrefix() { return this.mListPageFileNamePrefix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public String getListPageFileNameTitle() { return this.mListPageFileNameTitle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public String getListPageFileNameSuffix() { return this.mListPageFileNameSuffix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public String getListPageFileNameExt() { return this.mListPageFileNameExt; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ListPage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */