/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateTagContentItem
/*     */   extends TemplateTag
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected boolean debug = false;
/*     */   protected String mDelta;
/*     */   protected String mField;
/*     */   protected String mBeforeHTML;
/*     */   protected String mAfterHTML;
/*     */   protected Hashtable mContentTypeTable;
/*     */   
/*     */   public TemplateTagContentItem(Hashtable paramHashtable1, Hashtable paramHashtable2) {
/*  55 */     super(paramHashtable1, false);
/*  56 */     this.mDelta = (String)paramHashtable1.get("delta=");
/*  57 */     this.mField = (String)paramHashtable1.get("field=");
/*  58 */     this.mBeforeHTML = (String)paramHashtable1.get("before=");
/*  59 */     this.mAfterHTML = (String)paramHashtable1.get("after=");
/*  60 */     this.mContentTypeTable = paramHashtable2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public String getDelta() { return this.mDelta; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public String getField() { return this.mField; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public String getBeforeHTML() { return this.mBeforeHTML; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public String getAfterHTML() { return this.mAfterHTML; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render(Hashtable paramHashtable) {
/* 105 */     String str1 = null;
/* 106 */     String str2 = "";
/* 107 */     ReserveWordTemplateFieldManager reserveWordTemplateFieldManager = new ReserveWordTemplateFieldManager();
/*     */ 
/*     */ 
/*     */     
/* 111 */     ContentTypeInstance contentTypeInstance = (ContentTypeInstance)paramHashtable.get("instance");
/* 112 */     ContentTypeInstanceGroup contentTypeInstanceGroup = (ContentTypeInstanceGroup)paramHashtable.get("group");
/* 113 */     Variant variant = (Variant)paramHashtable.get("groupVariant");
/* 114 */     Generator generator = (Generator)paramHashtable.get("generator");
/* 115 */     ContentType contentType = (ContentType)paramHashtable.get("contenttype");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     if (contentType == null) {
/*     */       
/* 123 */       contentType = (ContentType)this.mContentTypeTable.get(this.mContentType.toUpperCase());
/*     */ 
/*     */       
/* 126 */       if (contentType != null)
/*     */       {
/* 128 */         contentTypeInstanceGroup = contentType.getGroupByName(this.mContentTypeGroup);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (this.mDelta.trim() != "")
/*     */     {
/* 138 */       if (contentTypeInstanceGroup != null) {
/*     */         
/* 140 */         DeltaTemplateFieldManager deltaTemplateFieldManager = new DeltaTemplateFieldManager(contentTypeInstanceGroup, contentTypeInstance);
/* 141 */         ContentTypeInstance contentTypeInstance1 = deltaTemplateFieldManager.getDeltaInstance(this.mDelta);
/* 142 */         if (contentTypeInstance1 != null)
/*     */         {
/* 144 */           contentTypeInstance = contentTypeInstance1;
/*     */         }
/*     */         else
/*     */         {
/* 148 */           generator.getReport().updateLine("", "Delta field will be skipped.");
/* 149 */           contentTypeInstanceGroup = null;
/*     */           
/* 151 */           str1 = null;
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 160 */         generator.getReport().updateLine("", "Error : Group does not match content type.");
/* 161 */         contentTypeInstanceGroup = null;
/*     */         
/* 163 */         str1 = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     if (reserveWordTemplateFieldManager.isReserveWord(this.mField)) {
/*     */ 
/*     */       
/* 174 */       if (contentTypeInstanceGroup != null)
/*     */       {
/*     */         
/* 177 */         reserveWordTemplateFieldManager.setInstance(contentTypeInstance);
/* 178 */         reserveWordTemplateFieldManager.setContentType(contentType);
/*     */ 
/*     */ 
/*     */         
/* 182 */         Variant variant1 = contentTypeInstanceGroup.getVariantByVariantTypeCode(this.mVariant);
/*     */         
/* 184 */         if (variant1 != null) {
/*     */           
/* 186 */           reserveWordTemplateFieldManager.setVariant(variant1);
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 192 */           if (this.mVariant != null) {
/* 193 */             generator.getReport().updateLine("", "Syntax Error : Variant [" + this.mVariant + "] not valid. ");
/*     */           }
/*     */           
/* 196 */           if (variant != null) {
/* 197 */             reserveWordTemplateFieldManager.setVariant(variant);
/*     */           } else {
/*     */             
/* 200 */             generator.getReport().updateLine("", "Syntax Error : Variant [" + variant + "] not valid. ");
/* 201 */             this.mField = "";
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 206 */         str1 = reserveWordTemplateFieldManager.render(this.mField);
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */         
/* 212 */         generator.getReport().updateLine("", "Error : Could not render field due to invalid type [" + this.mContentType + "] OR typegroup[" + this.mContentTypeGroup + "].");
/*     */         
/* 214 */         str1 = null;
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 223 */     else if (contentTypeInstance != null) {
/* 224 */       str1 = contentTypeInstance.getFieldValueByName(this.mField);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     if (str1 == null) {
/*     */ 
/*     */       
/* 234 */       generator.getReport().updateLine("", "Syntax Error : Field [" + this.mField + "] not valid. ");
/*     */       
/* 236 */       System.out.println("  Could not find field data " + this.mField + " for InstanceID[" + contentTypeInstance.getInstanceID() + "]");
/* 237 */       str2 = "";
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 242 */       str2 = String.valueOf(this.mBeforeHTML) + str1 + this.mAfterHTML;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     if (this.debug)
/*     */     {
/* 251 */       System.out.println("Rendered field " + this.mField + " to = " + str1);
/*     */     }
/*     */     
/* 254 */     return str2;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\TemplateTagContentItem.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */