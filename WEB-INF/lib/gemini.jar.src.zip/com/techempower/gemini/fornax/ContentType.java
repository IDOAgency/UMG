/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentType
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected int mContentTypeID;
/*     */   protected String mContentTypeName;
/*     */   protected String mContentTypeDescription;
/*     */   protected ListPage mContentTypeListPage;
/*     */   protected boolean mIsSingleton;
/*     */   protected boolean mIsListPageGenerated;
/*     */   protected Vector mFields;
/*     */   protected Vector mGroups;
/*     */   
/*     */   public ContentType(Hashtable paramHashtable) {
/*  41 */     this.mFields = new Vector();
/*  42 */     this.mGroups = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     this.mContentTypeID = ((Integer)paramHashtable.get("contentTypeID")).intValue();
/*  50 */     this.mContentTypeName = (String)paramHashtable.get("contentTypeName");
/*  51 */     this.mContentTypeDescription = (String)paramHashtable.get("contentTypeDescription");
/*  52 */     this.mContentTypeListPage = (ListPage)paramHashtable.get("contentTypeListPage");
/*  53 */     this.mIsSingleton = ((Boolean)paramHashtable.get("contentTypeIsSingleton")).booleanValue();
/*  54 */     this.mIsListPageGenerated = ((Boolean)paramHashtable.get("contentTypeIsListPageGenerated")).booleanValue();
/*  55 */     this.mFields = (Vector)paramHashtable.get("contentTypeFields");
/*  56 */     this.mGroups = (Vector)paramHashtable.get("contentTypeGroups");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public int getContentTypeID() { return this.mContentTypeID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public String getContentTypeName() { return this.mContentTypeName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public String getContentTypeDescription() { return this.mContentTypeDescription; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public ListPage getContentTypeListPage() { return this.mContentTypeListPage; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public boolean getIsSingleton() { return this.mIsSingleton; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public Vector getContentTypeFields() { return this.mFields; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public Vector getGroups() { return this.mGroups; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public boolean isListPageGenerated() { return this.mIsListPageGenerated; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentTypeInstanceGroup getGroupByName(String paramString) {
/* 137 */     ContentTypeInstanceGroup contentTypeInstanceGroup = null;
/*     */     
/* 139 */     for (byte b = 0; b < this.mGroups.size(); b++) {
/*     */       
/* 141 */       contentTypeInstanceGroup = (ContentTypeInstanceGroup)this.mGroups.elementAt(b);
/*     */       
/* 143 */       if (contentTypeInstanceGroup.getGroupName().equalsIgnoreCase(paramString)) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 149 */       contentTypeInstanceGroup = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 154 */     return contentTypeInstanceGroup;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ContentType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */