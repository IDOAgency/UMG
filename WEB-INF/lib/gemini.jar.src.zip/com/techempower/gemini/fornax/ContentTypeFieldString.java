/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentTypeFieldString
/*    */   extends ContentTypeField
/*    */   implements FornaxDBConstants
/*    */ {
/*    */   protected int mValueID;
/*    */   protected int mInstanceID;
/*    */   protected String mFieldValue;
/*    */   
/*    */   public ContentTypeFieldString(Hashtable paramHashtable) {
/* 47 */     super(paramHashtable);
/*    */     
/* 49 */     this.mValueID = ((Integer)paramHashtable.get("stringPointValueID")).intValue();
/* 50 */     this.mInstanceID = ((Integer)paramHashtable.get("stringPointValueInstance")).intValue();
/* 51 */     this.mFieldValue = (String)paramHashtable.get("stringPointValueData");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 60 */   public int getValueID() { return this.mValueID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   public int getInstanceID() { return this.mInstanceID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 78 */   public String getFieldValue() { return this.mFieldValue; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ContentTypeFieldString.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */