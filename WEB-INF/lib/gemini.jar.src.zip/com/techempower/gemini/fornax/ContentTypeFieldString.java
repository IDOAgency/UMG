package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class ContentTypeFieldString extends ContentTypeField implements FornaxDBConstants {
  protected int mValueID;
  
  protected int mInstanceID;
  
  protected String mFieldValue;
  
  public ContentTypeFieldString(Hashtable paramHashtable) {
    super(paramHashtable);
    this.mValueID = ((Integer)paramHashtable.get("stringPointValueID")).intValue();
    this.mInstanceID = ((Integer)paramHashtable.get("stringPointValueInstance")).intValue();
    this.mFieldValue = (String)paramHashtable.get("stringPointValueData");
  }
  
  public int getValueID() { return this.mValueID; }
  
  public int getInstanceID() { return this.mInstanceID; }
  
  public String getFieldValue() { return this.mFieldValue; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ContentTypeFieldString.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */