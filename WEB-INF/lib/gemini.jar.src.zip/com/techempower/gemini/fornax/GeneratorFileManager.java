package com.techempower.gemini.fornax;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class GeneratorFileManager implements FornaxDBConstants {
  protected static final String DEFAULT_GENERATION_FILEMODE = "rw";
  
  protected static final String DEFAULT_ACCESS_FILEMODE = "r";
  
  protected String generatedFileName;
  
  protected String generationFileMode;
  
  protected Generator mGenerator;
  
  public void setGenerator(Generator paramGenerator) { this.mGenerator = paramGenerator; }
  
  public void deleteContentTypeInstanceFile(ContentTypeInstance paramContentTypeInstance, Variant paramVariant) {
    String str = getFileName(paramContentTypeInstance, paramVariant, true);
    System.out.println("  ***   Deleting INSTANCE file START  ***  instanceID[" + paramContentTypeInstance.getInstanceID() + "]");
    deleteFile(str);
    System.out.println("  ****  Deleting INSTANCE file END    *** ");
    this.mGenerator.getReport().updateLine(str, "DELETED FILE");
  }
  
  public void deleteListPageFile(ListPage paramListPage) {
    String str = getListPageFileName(paramListPage);
    System.out.println("  ***   Deleting LIST PAGE file START  ***  " + str);
    deleteFile(str);
    System.out.println("  ****  Deleting LIST PAGE file END    *** ");
  }
  
  public void deleteFile(String paramString) {
    System.out.println("        Deleting File Name : " + paramString);
    File file = new File(paramString);
    try {
      file.delete();
    } catch (Exception exception) {
      System.out.println("ERROR : File " + paramString + "can not be deleted.");
    } 
  }
  
  public void generateContentFiles(ContentTypeInstance paramContentTypeInstance, Variant paramVariant, String paramString) {
    String str = getFileName(paramContentTypeInstance, paramVariant, true);
    deleteFile(str);
    FileWriter fileWriter = createNewFile(str);
    System.out.println("  ***   Generating INSTANCE file to disk START . . . *** ");
    System.out.println("        File Name : " + str);
    if (fileWriter != null)
      try {
        fileWriter.write(paramString);
        fileWriter.flush();
        fileWriter.close();
      } catch (Exception exception) {
        this.mGenerator.getReport().updateLine(str, "Error writing to file. " + exception.toString());
        System.out.println("Exception Error : Error writing to file. ");
      }  
    System.out.println("  ***   Generating INSTANCE file to disk DONE   ***");
    this.mGenerator.getReport().updateLine(str, "Generation Successful");
  }
  
  public void generateListPageFile(ListPage paramListPage, String paramString) {
    String str = getListPageFileName(paramListPage);
    deleteFile(str);
    FileWriter fileWriter = createNewFile(str);
    System.out.println("  ***   Generating LIST PAGE file to disk START . . . *** ");
    System.out.println("        File Name : " + str);
    if (fileWriter != null)
      try {
        fileWriter.write(paramString);
        fileWriter.flush();
        fileWriter.close();
      } catch (Exception exception) {
        System.out.println("Exception Error : Error writing to List Page. ");
      }  
    System.out.println("  ***   Generating LIST PAGE file to disk DONE *** ");
    this.mGenerator.getReport().updateLine(str, "Generation Successful! ");
  }
  
  public BufferedReader getTemplateFile(Template paramTemplate) {
    BufferedReader bufferedReader = null;
    FilePath filePath = paramTemplate.getFilePath();
    String str = "";
    if (filePath != null) {
      if (!filePath.isFilePathRelative())
        str = String.valueOf(filePath.getFormattedFilePathName()) + paramTemplate.getTemplateFileName(); 
      try {
        bufferedReader = new BufferedReader(new FileReader(str));
      } catch (Exception exception) {
        System.out.println("template file not found");
      } 
    } 
    return bufferedReader;
  }
  
  public FileWriter createNewFile(String paramString) {
    FileWriter fileWriter = null;
    try {
      fileWriter = new FileWriter(paramString, false);
    } catch (Exception exception) {
      System.out.println("Expeption Error : Can not create a new file " + paramString);
    } 
    return fileWriter;
  }
  
  public String getFileName(ContentTypeInstance paramContentTypeInstance, Variant paramVariant, boolean paramBoolean) {
    String str = "";
    GenerationDestination generationDestination = paramVariant.getVariantGenerationDestination();
    FilePath filePath = generationDestination.getFilePath();
    if (filePath != null)
      if (paramBoolean)
        str = filePath.getFormattedFilePathName();  
    str = String.valueOf(str) + paramVariant.getVariantFileNamePrefix() + paramVariant.getVariantFileNameTitle() + 
      paramVariant.getVariantFileNameSuffix();
    if (paramVariant.getVariantFileNameNumberingMode().equalsIgnoreCase("S")) {
      str = String.valueOf(str) + (new Integer(paramContentTypeInstance.getSequenceNO())).toString() + "." + paramVariant.getVariantFileNameExt();
    } else if (paramVariant.getVariantFileNameNumberingMode().equalsIgnoreCase("I")) {
      str = String.valueOf(str) + (new Integer(paramContentTypeInstance.getInstanceID())).toString() + "." + paramVariant.getVariantFileNameExt();
    } else {
      str = String.valueOf(str) + "." + paramVariant.getVariantFileNameExt();
    } 
    return str;
  }
  
  public String getListPageFileName(ListPage paramListPage) {
    null = "";
    GenerationDestination generationDestination = paramListPage.getListPageGenerationDestination();
    FilePath filePath = generationDestination.getFilePath();
    if (filePath != null)
      null = filePath.getFormattedFilePathName(); 
    return String.valueOf(null) + paramListPage.getListPageFileNamePrefix() + paramListPage.getListPageFileNameTitle() + 
      paramListPage.getListPageFileNameSuffix() + "." + paramListPage.getListPageFileNameExt();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\GeneratorFileManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */