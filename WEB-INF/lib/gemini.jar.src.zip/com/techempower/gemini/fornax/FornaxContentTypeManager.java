package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.DatabaseConnector;
import com.techempower.gemini.Context;
import com.techempower.gemini.Form;
import com.techempower.gemini.FormDropDownMenu;
import com.techempower.gemini.FormHidden;
import com.techempower.gemini.GeminiApplication;
import java.util.Vector;

public class FornaxContentTypeManager implements FornaxConstants {
  public static final String COMPONENT_CODE = "fMng";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected final int PAGE_SIZE = 6;
  
  protected Vector contentTypes;
  
  public FornaxContentTypeManager(GeminiApplication paramGeminiApplication) {
    this.PAGE_SIZE = 6;
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("fMng");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
  }
  
  public String getDescription() { return "Fornax Content Type Manager"; }
  
  public FornaxContentType getContentType(int paramInt) {
    String str = 
      
      "SELECT ContentType.*, ContentTypeInstancesCount.ContentTypeInstancesCount, ContentTypeInstancesGroupsCount.ContentTypeInstancesGroupsCount FROM (SELECT * FROM fnContentType WHERE ContentTypeID = " + 
      paramInt + 
      " )" + 
      " AS [ContentType]" + 
      " INNER JOIN (SELECT ct.ContentTypeID, count(ct.ContentTypeID) as 'ContentTypeInstancesCount'" + 
      " FROM fnContentType ct" + 
      " INNER JOIN fnContentTypeInstance ci" + 
      " ON ci.InstanceContentTypeID = ct.ContentTypeID" + 
      " WHERE ct.ContentTypeID = " + paramInt + 
      " GROUP BY ct.ContentTypeID)" + 
      " AS [ContentTypeInstancesCount]" + 
      " ON ContentType.ContentTypeID = ContentTypeInstancesCount.ContentTypeID" + 
      " INNER JOIN (SELECT ct.ContentTypeID, count(ct.ContentTypeID) as 'ContentTypeInstancesGroupsCount'" + 
      " FROM fnContentType ct" + 
      " INNER JOIN fnContentTypeInstancesGroup ctg" + 
      " ON ctg.InstancesGroupContentTypeID = ct.ContentTypeID" + 
      " WHERE ct.ContentTypeID = " + paramInt + 
      " GROUP BY ct.ContentTypeID)" + 
      " AS [ContentTypeInstancesGroupsCount]" + 
      " ON ContentType.ContentTypeID = ContentTypeInstancesGroupsCount.ContentTypeID";
    Vector vector = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentType", 
        true, 
        this.fornaxSettings);
    if (vector.size() == 1)
      return (FornaxContentType)vector.get(0); 
    return null;
  }
  
  public Vector getContentTypes() {
    this.contentTypes = 
      getContentTypes(1, 0, 0);
    return this.contentTypes;
  }
  
  public Vector getContentTypes(int paramInt1, int paramInt2) {
    this.contentTypes = 
      getContentTypes(1, paramInt1, paramInt2);
    return this.contentTypes;
  }
  
  public Vector getContentTypes(int paramInt1, int paramInt2, int paramInt3) {
    String str = 
      
      "SELECT ContentType.*, ContentTypeInstancesCount.ContentTypeInstancesCount, ContentTypeInstancesGroupsCount.ContentTypeInstancesGroupsCount FROM (SELECT * FROM fnContentType ) AS [ContentType] INNER JOIN (SELECT ct.ContentTypeID, count(ct.ContentTypeID) as 'ContentTypeInstancesCount' FROM fnContentType ct INNER JOIN fnContentTypeInstance ci ON ci.InstanceContentTypeID = ct.ContentTypeID GROUP BY ct.ContentTypeID) AS [ContentTypeInstancesCount] ON ContentType.ContentTypeID = ContentTypeInstancesCount.ContentTypeID INNER JOIN (SELECT ct.ContentTypeID, count(ct.ContentTypeID) as 'ContentTypeInstancesGroupsCount' FROM fnContentType ct INNER JOIN fnContentTypeInstancesGroup ctg ON ctg.InstancesGroupContentTypeID = ct.ContentTypeID GROUP BY ct.ContentTypeID) AS [ContentTypeInstancesGroupsCount] ON ContentType.ContentTypeID = ContentTypeInstancesGroupsCount.ContentTypeID";
    switch (paramInt2) {
      case 0:
        str = String.valueOf(str) + " ORDER BY ContentType.ContentTypeID";
        break;
      case 1:
        str = String.valueOf(str) + " ORDER BY ContentType.ContentTypeName";
        break;
      case 2:
        str = String.valueOf(str) + " ORDER BY ContentTypeInstancesCount.ContentTypeInstancesCount";
        break;
      default:
        str = String.valueOf(str) + " ORDER BY ContentType.ContentTypeID";
        break;
    } 
    switch (paramInt3) {
      case 0:
        str = String.valueOf(str) + " ASC";
        break;
      case 1:
        str = String.valueOf(str) + " DESC";
        break;
      default:
        str = String.valueOf(str) + " ASC";
        break;
    } 
    this.contentTypes = null;
    this.contentTypes = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentType", 
        true, 
        this.fornaxSettings);
    if (paramInt1 != 0) {
      Vector vector = 
        this.fornaxSettings.getFornaxHelper().getPageOfVectorObjects(this.contentTypes, paramInt1, 6);
      this.log.debug("returning partial page...");
      return vector;
    } 
    this.log.debug("returning full page...");
    if (this.contentTypes == null)
      this.log.debug("vector is NULL"); 
    return this.contentTypes;
  }
  
  public int getPageCount() {
    if (this.contentTypes != null)
      return (int)Math.ceil((this.contentTypes.size() / 6.0F)); 
    return 0;
  }
  
  public void updateContentTypeListPageFlag(Context paramContext, Form paramForm, Vector paramVector) {
    String str = "F";
    for (byte b = 0; b < paramVector.size(); b++) {
      FornaxContentType fornaxContentType = (FornaxContentType)paramVector.elementAt(b);
      if (this.fornaxSettings.isMultiGroup()) {
        FormDropDownMenu formDropDownMenu = (FormDropDownMenu)paramForm.getElement("content-type-listPage-generate-" + Integer.toString(fornaxContentType.getID()));
        if (formDropDownMenu != null)
          str = formDropDownMenu.getStringValue(); 
      } else {
        FormHidden formHidden = (FormHidden)paramForm.getElement("content-type-listPage-generate-" + Integer.toString(fornaxContentType.getID()));
        if (formHidden != null)
          str = formHidden.getStringValue(); 
      } 
      fornaxContentType.setIsListPageGenerated(str);
      fornaxContentType.runUpdate(this.fornaxSettings.getConnector(""));
    } 
  }
  
  public static int getDefaultInstancesGroupID(int paramInt, DatabaseConnector paramDatabaseConnector) {
    int i = -1;
    String str = 
      
      "SELECT ctig.InstancesGroupID FROM fnContentType ct INNER JOIN fnContentTypeInstancesGroup ctig ON ct.ContentTypeID = ctig.InstancesGroupContentTypeID WHERE lower(ct.ContentTypeName) = lower(ctig.InstancesGroupName) AND ct.ContentTypeID = " + 
      paramInt;
    paramDatabaseConnector.setQuery(str);
    paramDatabaseConnector.runQuery();
    if (paramDatabaseConnector.more()) {
      paramDatabaseConnector.first();
      i = paramDatabaseConnector.getInt("InstancesGroupID", -1);
    } 
    paramDatabaseConnector.close();
    return i;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */