package com.techempower.gemini.fornax;

import java.util.Hashtable;
import java.util.Vector;

public class TemplateTagContentLoop extends TemplateTag implements FornaxDBConstants {
  protected boolean debug = false;
  
  protected Vector mContentItems = new Vector();
  
  protected Hashtable mContentTypeTable = new Hashtable();
  
  public TemplateTagContentLoop(Hashtable paramHashtable1, Hashtable paramHashtable2) {
    super(paramHashtable1, true);
    this.mContentTypeTable = paramHashtable2;
  }
  
  public void setContentItems(Vector paramVector) { this.mContentItems = paramVector; }
  
  public Vector getContentItems() { return this.mContentItems; }
  
  public String render(Variant paramVariant, Generator paramGenerator) {
    String str = "";
    Hashtable hashtable = new Hashtable();
    if (this.debug)
      System.out.println("looking for group = " + this.mContentTypeGroup.toUpperCase()); 
    ContentType contentType = (ContentType)this.mContentTypeTable.get(this.mContentType.toUpperCase());
    if (contentType != null) {
      ContentTypeInstanceGroup contentTypeInstanceGroup = contentType.getGroupByName(this.mContentTypeGroup);
      if (contentTypeInstanceGroup != null) {
        Vector vector = contentTypeInstanceGroup.getGroupContentTypeInstances();
        for (byte b = 0; b < vector.size(); b++) {
          ContentTypeInstance contentTypeInstance = (ContentTypeInstance)vector.elementAt(b);
          if (!contentTypeInstance.isQueuedForDeletion() && !contentTypeInstance.isDisabled())
            for (byte b1 = 0; b1 < this.mContentItems.size(); b1++) {
              TemplateTagContentItem templateTagContentItem = (TemplateTagContentItem)this.mContentItems.elementAt(b1);
              if (contentTypeInstance != null)
                hashtable.put("instance", contentTypeInstance); 
              if (contentTypeInstanceGroup != null)
                hashtable.put("group", contentTypeInstanceGroup); 
              if (paramVariant != null)
                hashtable.put("groupVariant", paramVariant); 
              if (paramGenerator != null)
                hashtable.put("generator", paramGenerator); 
              if (contentType != null)
                hashtable.put("contentType", contentType); 
              str = String.valueOf(str) + templateTagContentItem.render(hashtable);
              if (this.debug)
                System.out.println("tagLoopItemValue= " + str); 
            }  
        } 
      } else {
        paramGenerator.getReport().updateLine("", "Content Type does not match the group specified. Check Template File Tags.");
      } 
    } else {
      paramGenerator.getReport().updateLine("", "Could not find content type " + this.mContentType);
      System.out.println("ERROR : Content Type is null");
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\TemplateTagContentLoop.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */