/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateTagContentLoop
/*     */   extends TemplateTag
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected boolean debug = false;
/*  43 */   protected Vector mContentItems = new Vector();
/*     */   
/*  45 */   protected Hashtable mContentTypeTable = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TemplateTagContentLoop(Hashtable paramHashtable1, Hashtable paramHashtable2) {
/*  52 */     super(paramHashtable1, true);
/*     */     
/*  54 */     this.mContentTypeTable = paramHashtable2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public void setContentItems(Vector paramVector) { this.mContentItems = paramVector; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public Vector getContentItems() { return this.mContentItems; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render(Variant paramVariant, Generator paramGenerator) {
/*  83 */     String str = "";
/*  84 */     Hashtable hashtable = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     if (this.debug)
/*     */     {
/*  92 */       System.out.println("looking for group = " + this.mContentTypeGroup.toUpperCase());
/*     */     }
/*     */ 
/*     */     
/*  96 */     ContentType contentType = (ContentType)this.mContentTypeTable.get(this.mContentType.toUpperCase());
/*     */     
/*  98 */     if (contentType != null) {
/*     */ 
/*     */ 
/*     */       
/* 102 */       ContentTypeInstanceGroup contentTypeInstanceGroup = contentType.getGroupByName(this.mContentTypeGroup);
/*     */       
/* 104 */       if (contentTypeInstanceGroup != null)
/*     */       {
/*     */         
/* 107 */         Vector vector = contentTypeInstanceGroup.getGroupContentTypeInstances();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 116 */         for (byte b = 0; b < vector.size(); b++)
/*     */         {
/* 118 */           ContentTypeInstance contentTypeInstance = (ContentTypeInstance)vector.elementAt(b);
/*     */           
/* 120 */           if (!contentTypeInstance.isQueuedForDeletion() && !contentTypeInstance.isDisabled())
/*     */           {
/*     */             
/* 123 */             for (byte b1 = 0; b1 < this.mContentItems.size(); b1++)
/*     */             {
/* 125 */               TemplateTagContentItem templateTagContentItem = (TemplateTagContentItem)this.mContentItems.elementAt(b1);
/*     */ 
/*     */               
/* 128 */               if (contentTypeInstance != null)
/* 129 */                 hashtable.put("instance", contentTypeInstance); 
/* 130 */               if (contentTypeInstanceGroup != null)
/* 131 */                 hashtable.put("group", contentTypeInstanceGroup); 
/* 132 */               if (paramVariant != null)
/* 133 */                 hashtable.put("groupVariant", paramVariant); 
/* 134 */               if (paramGenerator != null)
/* 135 */                 hashtable.put("generator", paramGenerator); 
/* 136 */               if (contentType != null) {
/* 137 */                 hashtable.put("contentType", contentType);
/*     */               }
/* 139 */               str = String.valueOf(str) + templateTagContentItem.render(hashtable);
/*     */ 
/*     */               
/* 142 */               if (this.debug)
/*     */               {
/* 144 */                 System.out.println("tagLoopItemValue= " + str);
/*     */               
/*     */               }
/*     */             
/*     */             }
/*     */           
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 156 */         paramGenerator.getReport().updateLine("", "Content Type does not match the group specified. Check Template File Tags.");
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 164 */       paramGenerator.getReport().updateLine("", "Could not find content type " + this.mContentType);
/* 165 */       System.out.println("ERROR : Content Type is null");
/*     */     } 
/*     */ 
/*     */     
/* 169 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\TemplateTagContentLoop.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */