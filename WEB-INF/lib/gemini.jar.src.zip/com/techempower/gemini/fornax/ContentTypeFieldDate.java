/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentTypeFieldDate
/*    */   extends ContentTypeField
/*    */   implements FornaxDBConstants
/*    */ {
/*    */   protected int mValueID;
/*    */   protected int mInstanceID;
/*    */   protected String mFieldValue;
/*    */   
/*    */   public ContentTypeFieldDate(Hashtable paramHashtable) {
/* 51 */     super(paramHashtable);
/*    */     
/* 53 */     this.mValueID = ((Integer)paramHashtable.get("dateValueID")).intValue();
/* 54 */     this.mInstanceID = ((Integer)paramHashtable.get("dateValueInstance")).intValue();
/* 55 */     this.mFieldValue = (String)paramHashtable.get("dateValueData");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public int getValueID() { return this.mValueID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 73 */   public int getInstanceID() { return this.mInstanceID; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public String getFieldValue() { return this.mFieldValue; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ContentTypeFieldDate.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */