/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import com.techempower.DatabaseConnector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DBRecordManager
/*    */   implements FornaxDBConstants, FornaxSQLStatements
/*    */ {
/*    */   protected boolean debug = true;
/*    */   
/*    */   public void deleteContentTypeInstance(int paramInt) {
/* 48 */     Integer integer = new Integer(paramInt);
/*    */     
/* 50 */     System.out.println("  ***   Deleting Record from database START  *** ");
/*    */ 
/*    */     
/* 53 */     String str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeDateValue WHERE DateValueInstanceID = @instanceID", "@instanceID", integer.toString());
/* 54 */     if (this.debug)
/* 55 */       System.out.println(str); 
/* 56 */     DatabaseConnector databaseConnector = FornaxDBConnector.getConnector(str);
/* 57 */     databaseConnector.runQuery();
/*    */ 
/*    */     
/* 60 */     str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeIntegerValue WHERE IntegerValueInstanceID = @instanceID", "@instanceID", integer.toString());
/* 61 */     databaseConnector.setQuery(str);
/* 62 */     databaseConnector.runQuery();
/*    */ 
/*    */     
/* 65 */     str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeFloatingPointValue WHERE FloatingPointValueInstanceID = @instanceID", "@instanceID", integer.toString());
/* 66 */     databaseConnector.setQuery(str);
/* 67 */     databaseConnector.runQuery();
/*    */ 
/*    */     
/* 70 */     str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeStringValue WHERE StringValueInstanceID = @instanceID", "@instanceID", integer.toString());
/* 71 */     databaseConnector.setQuery(str);
/* 72 */     databaseConnector.runQuery();
/*    */ 
/*    */     
/* 75 */     str = FornaxHelper.replaceParameters("DELETE FROM fnMapContentTypeInstanceToInstancesGroup WHERE InstanceID = @instanceID", "@instanceID", integer.toString());
/* 76 */     databaseConnector.setQuery(str);
/* 77 */     databaseConnector.runQuery();
/*    */ 
/*    */ 
/*    */     
/* 81 */     str = FornaxHelper.replaceParameters("DELETE FROM fnContentTypeInstance WHERE InstanceID = @instanceID", "@instanceID", integer.toString());
/* 82 */     databaseConnector.setQuery(str);
/* 83 */     databaseConnector.runQuery();
/*    */     
/* 85 */     System.out.println("        InstanceID[" + paramInt + "]");
/* 86 */     System.out.println("  ***   Deleting Record from database END  *** ");
/*    */     
/* 88 */     databaseConnector.close();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\DBRecordManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */