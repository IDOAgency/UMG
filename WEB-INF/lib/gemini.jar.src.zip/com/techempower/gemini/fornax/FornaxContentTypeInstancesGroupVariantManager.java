/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.gemini.Context;
/*     */ import com.techempower.gemini.Form;
/*     */ import com.techempower.gemini.FormCheckBox;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxContentTypeInstancesGroupVariantManager
/*     */   implements FornaxConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "fMng";
/*     */   public GeminiApplication application;
/*     */   public ComponentLog log;
/*     */   public FornaxSettings fornaxSettings;
/*     */   protected Vector contentTypeInstancesGroupVariants;
/*     */   FornaxGenerationDestinationManager generationDestinationManager;
/*     */   
/*     */   public FornaxContentTypeInstancesGroupVariantManager(GeminiApplication paramGeminiApplication) {
/*  63 */     this.application = paramGeminiApplication;
/*  64 */     this.log = paramGeminiApplication.getLog("fMng");
/*  65 */     this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
/*  66 */     this.generationDestinationManager = new FornaxGenerationDestinationManager(this.application);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public String getDescription() { return "Fornax ContentType Instances Group Variant Manager"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxContentTypeInstancesGroupVariant getInstancesGroupVariant(int paramInt) {
/*  84 */     String str = 
/*     */ 
/*     */       
/*  87 */       "SELECT * FROM fnContentTypeInstancesGroupVariant WHERE VariantID = " + 
/*  88 */       paramInt;
/*     */     
/*  90 */     Vector vector = 
/*  91 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/*  92 */         "com.techempower.gemini.fornax.FornaxContentTypeInstancesGroupVariant", 
/*  93 */         true, 
/*  94 */         this.fornaxSettings);
/*     */     
/*  96 */     if (vector.size() == 1)
/*     */     {
/*  98 */       return (FornaxContentTypeInstancesGroupVariant)vector.get(0);
/*     */     }
/*     */ 
/*     */     
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getInstancesGroupVariants(int paramInt) {
/* 113 */     String str = 
/*     */ 
/*     */       
/* 116 */       "SELECT * FROM fnContentTypeInstancesGroupVariant WHERE VariantInstancesGroupID = " + 
/* 117 */       paramInt;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.contentTypeInstancesGroupVariants = null;
/* 123 */     this.contentTypeInstancesGroupVariants = 
/* 124 */       this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
/* 125 */         "com.techempower.gemini.fornax.FornaxContentTypeInstancesGroupVariant", 
/* 126 */         true, 
/* 127 */         this.fornaxSettings);
/*     */ 
/*     */ 
/*     */     
/* 131 */     return this.contentTypeInstancesGroupVariants;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   FornaxGenerationDestination getGenerationDestination(int paramInt) { return this.generationDestinationManager.getGenerationDestination(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateVariantInfo(Context paramContext, Form paramForm, Vector paramVector) {
/* 148 */     boolean bool = false;
/*     */     
/* 150 */     for (byte b = 0; b < paramVector.size(); b++) {
/*     */       
/* 152 */       FornaxContentTypeInstancesGroupVariant fornaxContentTypeInstancesGroupVariant = (FornaxContentTypeInstancesGroupVariant)paramVector.elementAt(b);
/*     */ 
/*     */ 
/*     */       
/* 156 */       FormCheckBox formCheckBox = (FormCheckBox)paramForm.getElement("variant-enabled-" + Integer.toString(fornaxContentTypeInstancesGroupVariant.getID()));
/*     */       
/* 158 */       if (formCheckBox != null) {
/*     */         
/* 160 */         if (formCheckBox.isChecked()) {
/*     */           
/* 162 */           fornaxContentTypeInstancesGroupVariant.setIsEnabledForGeneration("T");
/*     */         }
/*     */         else {
/*     */           
/* 166 */           fornaxContentTypeInstancesGroupVariant.setIsEnabledForGeneration("F");
/*     */         } 
/*     */         
/* 169 */         bool = true;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       if (bool)
/*     */       {
/* 184 */         fornaxContentTypeInstancesGroupVariant.runUpdate(this.fornaxSettings.getConnector(""));
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstancesGroupVariantManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */