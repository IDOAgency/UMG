package com.techempower.gemini.fornax;

import com.techempower.ComponentLog;
import com.techempower.gemini.Context;
import com.techempower.gemini.Form;
import com.techempower.gemini.FormCheckBox;
import com.techempower.gemini.GeminiApplication;
import java.util.Vector;

public class FornaxContentTypeInstancesGroupVariantManager implements FornaxConstants {
  public static final String COMPONENT_CODE = "fMng";
  
  public GeminiApplication application;
  
  public ComponentLog log;
  
  public FornaxSettings fornaxSettings;
  
  protected Vector contentTypeInstancesGroupVariants;
  
  FornaxGenerationDestinationManager generationDestinationManager;
  
  public FornaxContentTypeInstancesGroupVariantManager(GeminiApplication paramGeminiApplication) {
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("fMng");
    this.fornaxSettings = paramGeminiApplication.getFornaxSettings();
    this.generationDestinationManager = new FornaxGenerationDestinationManager(this.application);
  }
  
  public String getDescription() { return "Fornax ContentType Instances Group Variant Manager"; }
  
  public FornaxContentTypeInstancesGroupVariant getInstancesGroupVariant(int paramInt) {
    String str = 
      
      "SELECT * FROM fnContentTypeInstancesGroupVariant WHERE VariantID = " + 
      paramInt;
    Vector vector = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentTypeInstancesGroupVariant", 
        true, 
        this.fornaxSettings);
    if (vector.size() == 1)
      return (FornaxContentTypeInstancesGroupVariant)vector.get(0); 
    return null;
  }
  
  public Vector getInstancesGroupVariants(int paramInt) {
    String str = 
      
      "SELECT * FROM fnContentTypeInstancesGroupVariant WHERE VariantInstancesGroupID = " + 
      paramInt;
    this.contentTypeInstancesGroupVariants = null;
    this.contentTypeInstancesGroupVariants = 
      this.fornaxSettings.getFornaxHelper().buildCacheVector(str, 
        "com.techempower.gemini.fornax.FornaxContentTypeInstancesGroupVariant", 
        true, 
        this.fornaxSettings);
    return this.contentTypeInstancesGroupVariants;
  }
  
  FornaxGenerationDestination getGenerationDestination(int paramInt) { return this.generationDestinationManager.getGenerationDestination(paramInt); }
  
  public void updateVariantInfo(Context paramContext, Form paramForm, Vector paramVector) {
    boolean bool = false;
    for (byte b = 0; b < paramVector.size(); b++) {
      FornaxContentTypeInstancesGroupVariant fornaxContentTypeInstancesGroupVariant = (FornaxContentTypeInstancesGroupVariant)paramVector.elementAt(b);
      FormCheckBox formCheckBox = (FormCheckBox)paramForm.getElement("variant-enabled-" + Integer.toString(fornaxContentTypeInstancesGroupVariant.getID()));
      if (formCheckBox != null) {
        if (formCheckBox.isChecked()) {
          fornaxContentTypeInstancesGroupVariant.setIsEnabledForGeneration("T");
        } else {
          fornaxContentTypeInstancesGroupVariant.setIsEnabledForGeneration("F");
        } 
        bool = true;
      } 
      if (bool)
        fornaxContentTypeInstancesGroupVariant.runUpdate(this.fornaxSettings.getConnector("")); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstancesGroupVariantManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */