/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ import com.techempower.DataEntity;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import java.util.Calendar;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxHelper
/*     */   extends BasicHelper
/*     */   implements FornaxConstants
/*     */ {
/*     */   protected FornaxSettings fornaxSettings;
/*     */   
/*  55 */   public FornaxHelper(FornaxSettings paramFornaxSettings) { this.fornaxSettings = paramFornaxSettings; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector getDataEntities(Class paramClass, DatabaseConnector paramDatabaseConnector, boolean paramBoolean) {
/*  73 */     Vector vector = new Vector();
/*     */ 
/*     */     
/*  76 */     while (paramDatabaseConnector.more()) {
/*     */ 
/*     */       
/*     */       try {
/*  80 */         DataEntity dataEntity = (DataEntity)paramClass.newInstance();
/*     */         
/*  82 */         if (paramBoolean) {
/*  83 */           dataEntity.initializeByMethods(paramDatabaseConnector);
/*     */         } else {
/*  85 */           dataEntity.initializeByVariables(paramDatabaseConnector);
/*     */         } 
/*     */         
/*  88 */         vector.addElement(dataEntity);
/*     */       }
/*  90 */       catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  95 */       paramDatabaseConnector.next();
/*     */     } 
/*     */     
/*  98 */     paramDatabaseConnector.close();
/*     */     
/* 100 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector buildCacheVector(String paramString1, String paramString2, boolean paramBoolean, FornaxSettings paramFornaxSettings) {
/* 113 */     DatabaseConnector databaseConnector = paramFornaxSettings.getConnector(paramString1);
/*     */     
/* 115 */     null = new Vector();
/*     */ 
/*     */     
/*     */     try {
/* 119 */       databaseConnector.runQuery();
/* 120 */       return getDataEntities(Class.forName(paramString2), databaseConnector, paramBoolean);
/*     */ 
/*     */     
/*     */     }
/* 124 */     catch (Exception exception) {
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 130 */       databaseConnector.close();
/*     */     } 
/*     */ 
/*     */     
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void installHandlers(GeminiApplication paramGeminiApplication) {
/* 146 */     paramGeminiApplication.getDispatcher().getDispatchHandlers().addElement(new FornaxLoginHandler(paramGeminiApplication));
/* 147 */     paramGeminiApplication.getDispatcher().getDispatchHandlers().addElement(new FornaxNavigationHandler(paramGeminiApplication));
/* 148 */     paramGeminiApplication.getDispatcher().getDispatchHandlers().addElement(new FornaxGenerationHandler(paramGeminiApplication));
/*     */     
/* 150 */     paramGeminiApplication.getApplicationLog().log("FRNX: Handlers successfully installed.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replaceParameters(String paramString1, String paramString2, String paramString3) {
/* 168 */     while (paramString1.indexOf(paramString2) > -1) {
/*     */       
/* 170 */       StringBuffer stringBuffer = new StringBuffer(paramString1);
/* 171 */       int i = paramString1.indexOf(paramString2);
/* 172 */       int j = paramString1.indexOf(paramString2) + paramString2.length();
/* 173 */       paramString1 = stringBuffer.replace(i, j, paramString3).toString();
/*     */     } 
/* 175 */     return paramString1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector getPageOfVectorObjects(Vector paramVector, int paramInt1, int paramInt2) {
/* 187 */     if (paramVector != null) {
/*     */       
/* 189 */       int i = paramVector.size();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 194 */       int j = (paramInt1 - 1) * paramInt2;
/* 195 */       int k = paramInt1 * paramInt2 - 1;
/*     */ 
/*     */       
/* 198 */       if (j < 0) {
/* 199 */         j = 0;
/*     */       }
/*     */       
/* 202 */       if (k > i - 1) {
/* 203 */         k = i - 1;
/*     */       }
/*     */       
/* 206 */       Vector vector = new Vector();
/*     */       
/* 208 */       for (int m = j; m <= k; m++)
/*     */       {
/* 210 */         vector.add(paramVector.get(m));
/*     */       }
/* 212 */       return vector;
/*     */     } 
/* 214 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar getInitializedCalendar(String paramString) {
/* 220 */     Calendar calendar = null;
/*     */     
/*     */     try {
/* 223 */       calendar = BasicHelper.parseComplexDate(paramString);
/* 224 */     } catch (Exception exception) {
/* 225 */       System.out.println("Exception raised: " + exception.toString());
/*     */     } 
/*     */     
/* 228 */     if (calendar != null) {
/*     */       
/* 230 */       calendar.set(14, 0);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 235 */       calendar = Calendar.getInstance();
/* 236 */       calendar.clear();
/*     */       
/* 238 */       calendar.set(1900, 0, 1, 0, 0, 0);
/* 239 */       calendar.set(14, 0);
/*     */     } 
/* 241 */     return calendar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatFilePath(String paramString) {
/* 252 */     String str = "";
/*     */ 
/*     */     
/* 255 */     if (paramString.startsWith("\\\\"))
/*     */     {
/* 257 */       str = "\\\\\\\\";
/*     */     }
/*     */ 
/*     */     
/* 261 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "\\");
/*     */ 
/*     */     
/* 264 */     while (stringTokenizer.hasMoreTokens())
/*     */     {
/* 266 */       str = String.valueOf(str) + stringTokenizer.nextToken() + "\\\\";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 271 */     return str;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */