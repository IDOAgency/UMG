package com.techempower.gemini.fornax;

import java.util.Hashtable;

public class ContentTypeFieldInteger extends ContentTypeField implements FornaxDBConstants {
  protected int mValueID;
  
  protected int mInstanceID;
  
  protected String mFieldValue;
  
  public ContentTypeFieldInteger(Hashtable paramHashtable) {
    super(paramHashtable);
    this.mValueID = ((Integer)paramHashtable.get("intergerValueID")).intValue();
    this.mInstanceID = ((Integer)paramHashtable.get("integerValueInstance")).intValue();
    this.mFieldValue = (String)paramHashtable.get("integerValueData");
  }
  
  public int getValueID() { return this.mValueID; }
  
  public int getInstanceID() { return this.mInstanceID; }
  
  public String getFieldValue() { return this.mFieldValue; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ContentTypeFieldInteger.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */