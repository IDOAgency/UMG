package com.techempower.gemini.fornax;

public class ReserveWordTemplateFieldManager {
  protected boolean debug = false;
  
  protected static final String SELF_ID = "_self_id";
  
  protected static final String SELF_URLREF = "_self_urlref";
  
  protected static final String SELF_FILENAME = "_self_filename";
  
  protected static final String SELF_TYPENAME = "_self_typename";
  
  protected static final String SELF_GROUPNAME = "_self_groupname";
  
  protected static final String SELF_VARIANTNAME = "_self_variantname";
  
  protected ContentTypeInstance mInstance;
  
  protected Variant mVariant;
  
  protected ContentType mContentType;
  
  public void setInstance(ContentTypeInstance paramContentTypeInstance) { this.mInstance = paramContentTypeInstance; }
  
  public void setContentType(ContentType paramContentType) { this.mContentType = paramContentType; }
  
  public void setVariant(Variant paramVariant) { this.mVariant = paramVariant; }
  
  public boolean isReserveWord(String paramString) {
    if (paramString.equalsIgnoreCase("_self_id"))
      return true; 
    if (paramString.equalsIgnoreCase("_self_urlref"))
      return true; 
    if (paramString.equalsIgnoreCase("_self_filename"))
      return true; 
    if (paramString.equalsIgnoreCase("_self_typename"))
      return true; 
    if (paramString.equalsIgnoreCase("_self_groupname"))
      return true; 
    if (paramString.equalsIgnoreCase("_self_variantname"))
      return true; 
    return false;
  }
  
  public String render(String paramString) {
    String str = null;
    if (paramString.equalsIgnoreCase("_self_id")) {
      str = (new Integer(this.mInstance.getInstanceID())).toString();
    } else if (paramString.equalsIgnoreCase("_self_urlref")) {
      GeneratorFileManager generatorFileManager = new GeneratorFileManager();
      str = generatorFileManager.getFileName(this.mInstance, this.mVariant, true);
    } else if (paramString.equalsIgnoreCase("_self_filename")) {
      GeneratorFileManager generatorFileManager = new GeneratorFileManager();
      str = generatorFileManager.getFileName(this.mInstance, this.mVariant, false);
    } else if (paramString.equalsIgnoreCase("_self_typename")) {
      str = this.mInstance.getContentTypeName();
    } else if (paramString.equalsIgnoreCase("_self_groupname")) {
      str = this.mInstance.getGroupName();
    } else if (paramString.equalsIgnoreCase("_self_variantname")) {
      str = this.mVariant.getVariantTypeCode();
    } 
    if (this.debug)
      System.out.println("ReserveWord rendering = " + str); 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\ReserveWordTemplateFieldManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */