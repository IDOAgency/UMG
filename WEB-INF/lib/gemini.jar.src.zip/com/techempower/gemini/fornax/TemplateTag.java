/*    */ package com.techempower.gemini.fornax;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class TemplateTag
/*    */   implements FornaxDBConstants
/*    */ {
/*    */   protected String mContentType;
/*    */   protected String mContentTypeGroup;
/*    */   protected String mVariant;
/*    */   protected boolean mIsLoop;
/*    */   
/*    */   public TemplateTag(Hashtable paramHashtable, boolean paramBoolean) {
/* 49 */     this.mContentType = (String)paramHashtable.get("type=");
/* 50 */     this.mContentTypeGroup = (String)paramHashtable.get("typegroup=");
/* 51 */     this.mVariant = (String)paramHashtable.get("variant=");
/* 52 */     this.mIsLoop = paramBoolean;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public String getContentType() { return this.mContentType; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   public String getContentTypeGroup() { return this.mContentTypeGroup; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 78 */   public String getVariant() { return this.mVariant; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 87 */   public boolean isLoop() { return this.mIsLoop; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\TemplateTag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */