package com.techempower.gemini.fornax;

import com.techempower.DataEntity;
import java.util.Hashtable;

public class FornaxVariantType extends DataEntity implements FornaxConstants {
  protected int variantTypeID = -1;
  
  protected String variantTypeCode = "";
  
  protected String variantTypeDescription = "";
  
  public void initializationComplete() {}
  
  public Hashtable getCustomSetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("VariantTypeID", "setID");
    hashtable.put("VariantTypeCode", "setCode");
    hashtable.put("VariantTypeDescription", "setDescription");
    return hashtable;
  }
  
  public int getIdentity() { return this.variantTypeID; }
  
  public String getTableName() { return "fnVariantType"; }
  
  public String getIdentityColumnName() { return "VariantTypeID"; }
  
  public int getID() { return this.variantTypeID; }
  
  public String getCode() { return this.variantTypeCode; }
  
  public String getDescription() { return this.variantTypeDescription; }
  
  public void setID(int paramInt) { this.variantTypeID = paramInt; }
  
  public void setCode(String paramString) {
    if (paramString != null)
      this.variantTypeCode = paramString; 
  }
  
  public void setDescription(String paramString) {
    if (paramString != null)
      this.variantTypeDescription = paramString; 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxVariantType.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */