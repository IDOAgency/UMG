package com.techempower.gemini.fornax;

import com.techempower.BasicConnectorFactory;
import com.techempower.DatabaseConnector;
import com.techempower.EnhancedProperties;
import com.techempower.gemini.BasicServiceSettings;
import com.techempower.gemini.GeminiApplication;
import com.techempower.gemini.pyxis.BasicSecurity;
import com.techempower.gemini.pyxis.BasicUser;

public class FornaxSettings extends BasicServiceSettings implements FornaxConstants {
  protected FornaxHelper fornaxHelper;
  
  protected String htmlPath = new String("/jsp");
  
  protected String imagePath = new String("/resources/images");
  
  protected String javascriptPath = new String("/resources/js");
  
  protected String jspPath = new String("/jsp");
  
  protected String stylePath = new String("/resources/css/styles.css");
  
  protected boolean multiGroup = false;
  
  protected String generationLogDir = new String("/reports/");
  
  protected int randomPasswordLength = 8;
  
  protected String usersTable = new String("FornaxUsers");
  
  public FornaxSettings(GeminiApplication paramGeminiApplication) {
    super(paramGeminiApplication);
    this.fornaxHelper = new FornaxHelper(this);
    this.securityManager = new BasicSecurity(paramGeminiApplication);
  }
  
  public void customConfigure(EnhancedProperties paramEnhancedProperties) {
    this.application.getApplicationLog().debug("Configuring Fornax...");
    this.htmlPath = paramEnhancedProperties.getProperty("Fornax.HTMLDirectory", this.htmlPath);
    this.jspPath = paramEnhancedProperties.getProperty("Fornax.JSPDirectory", this.jspPath);
    this.imagePath = paramEnhancedProperties.getProperty("Fornax.ImageDirectory", this.imagePath);
    this.javascriptPath = paramEnhancedProperties.getProperty("Fornax.JavaScriptDirectory", this.javascriptPath);
    this.stylePath = paramEnhancedProperties.getProperty("Fornax.StyleSheet", this.stylePath);
    this.urlDirectoryPrefix = paramEnhancedProperties.getProperty("Fornax.urlDirectoryPrefix", this.urlDirectoryPrefix);
    this.useURLDirectoryPrefix = paramEnhancedProperties.getYesNoProperty("Fornax.useURLDirectoryPrefix", this.useURLDirectoryPrefix);
    this.randomPasswordLength = paramEnhancedProperties.getIntegerProperty("Fornax.RandomPasswordLength", this.randomPasswordLength);
    this.usersTable = paramEnhancedProperties.getProperty("Fornax.UsersTable", this.usersTable);
    this.multiGroup = paramEnhancedProperties.getYesNoProperty("Fornax.MultiGroupMode", this.multiGroup);
    this.generationLogDir = paramEnhancedProperties.getProperty("Fornax.GenerationLogDir", this.generationLogDir);
    this.connectorFactory = new BasicConnectorFactory("Fornax.");
    this.connectorFactory.configure(paramEnhancedProperties, this.application);
    this.securityManager.configure(paramEnhancedProperties);
    this.application.getApplicationLog().debug("Fornax configuration complete.");
  }
  
  public DatabaseConnector getConnector(String paramString) {
    if (this.connectorFactory != null)
      return this.connectorFactory.getConnector(paramString); 
    return null;
  }
  
  public FornaxHelper getFornaxHelper() { return this.fornaxHelper; }
  
  public String getHtmlDirectory() { return this.htmlPath; }
  
  public String getImageDirectory() { return this.imagePath; }
  
  public String getJavaScriptDirectory() { return this.javascriptPath; }
  
  public String getJspDirectory() { return this.jspPath; }
  
  public String getUserName(int paramInt) {
    String str = new String("");
    BasicUser basicUser = getSecurity().getUser(paramInt);
    if (basicUser != null) {
      str = String.valueOf(basicUser.getUserFirstname()) + " " + basicUser.getUserLastname();
    } else {
      str = null;
    } 
    return str;
  }
  
  public String getStyleSheet() { return this.stylePath; }
  
  public String getStyleLink() { return "<link rel=\"STYLESHEET\" type=\"text/css\" href=\"" + getStyleSheet() + "\">"; }
  
  public int getRandomPasswordLength() { return this.randomPasswordLength; }
  
  public String getUsersTable() { return this.usersTable; }
  
  public boolean isMultiGroup() { return this.multiGroup; }
  
  public String getGenerationLogDir() { return this.generationLogDir; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxSettings.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */