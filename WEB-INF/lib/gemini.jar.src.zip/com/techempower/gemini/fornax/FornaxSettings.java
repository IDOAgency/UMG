/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import com.techempower.BasicConnectorFactory;
/*     */ import com.techempower.DatabaseConnector;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import com.techempower.gemini.BasicServiceSettings;
/*     */ import com.techempower.gemini.GeminiApplication;
/*     */ import com.techempower.gemini.pyxis.BasicSecurity;
/*     */ import com.techempower.gemini.pyxis.BasicUser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FornaxSettings
/*     */   extends BasicServiceSettings
/*     */   implements FornaxConstants
/*     */ {
/*     */   protected FornaxHelper fornaxHelper;
/*  40 */   protected String htmlPath = new String("/jsp");
/*  41 */   protected String imagePath = new String("/resources/images");
/*  42 */   protected String javascriptPath = new String("/resources/js");
/*  43 */   protected String jspPath = new String("/jsp");
/*  44 */   protected String stylePath = new String("/resources/css/styles.css");
/*     */   protected boolean multiGroup = false;
/*  46 */   protected String generationLogDir = new String("/reports/");
/*     */ 
/*     */ 
/*     */   
/*  50 */   protected int randomPasswordLength = 8;
/*  51 */   protected String usersTable = new String("FornaxUsers");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FornaxSettings(GeminiApplication paramGeminiApplication) {
/*  62 */     super(paramGeminiApplication);
/*  63 */     this.fornaxHelper = new FornaxHelper(this);
/*  64 */     this.securityManager = new BasicSecurity(paramGeminiApplication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void customConfigure(EnhancedProperties paramEnhancedProperties) {
/*  72 */     this.application.getApplicationLog().debug("Configuring Fornax...");
/*     */     
/*  74 */     this.htmlPath = paramEnhancedProperties.getProperty("Fornax.HTMLDirectory", this.htmlPath);
/*  75 */     this.jspPath = paramEnhancedProperties.getProperty("Fornax.JSPDirectory", this.jspPath);
/*  76 */     this.imagePath = paramEnhancedProperties.getProperty("Fornax.ImageDirectory", this.imagePath);
/*  77 */     this.javascriptPath = paramEnhancedProperties.getProperty("Fornax.JavaScriptDirectory", this.javascriptPath);
/*  78 */     this.stylePath = paramEnhancedProperties.getProperty("Fornax.StyleSheet", this.stylePath);
/*     */     
/*  80 */     this.urlDirectoryPrefix = paramEnhancedProperties.getProperty("Fornax.urlDirectoryPrefix", this.urlDirectoryPrefix);
/*  81 */     this.useURLDirectoryPrefix = paramEnhancedProperties.getYesNoProperty("Fornax.useURLDirectoryPrefix", this.useURLDirectoryPrefix);
/*     */     
/*  83 */     this.randomPasswordLength = paramEnhancedProperties.getIntegerProperty("Fornax.RandomPasswordLength", this.randomPasswordLength);
/*  84 */     this.usersTable = paramEnhancedProperties.getProperty("Fornax.UsersTable", this.usersTable);
/*     */     
/*  86 */     this.multiGroup = paramEnhancedProperties.getYesNoProperty("Fornax.MultiGroupMode", this.multiGroup);
/*  87 */     this.generationLogDir = paramEnhancedProperties.getProperty("Fornax.GenerationLogDir", this.generationLogDir);
/*     */     
/*  89 */     this.connectorFactory = new BasicConnectorFactory("Fornax.");
/*  90 */     this.connectorFactory.configure(paramEnhancedProperties, this.application);
/*     */ 
/*     */     
/*  93 */     this.securityManager.configure(paramEnhancedProperties);
/*     */     
/*  95 */     this.application.getApplicationLog().debug("Fornax configuration complete.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseConnector getConnector(String paramString) {
/* 103 */     if (this.connectorFactory != null) {
/* 104 */       return this.connectorFactory.getConnector(paramString);
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public FornaxHelper getFornaxHelper() { return this.fornaxHelper; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public String getHtmlDirectory() { return this.htmlPath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public String getImageDirectory() { return this.imagePath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public String getJavaScriptDirectory() { return this.javascriptPath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public String getJspDirectory() { return this.jspPath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserName(int paramInt) {
/* 158 */     String str = new String("");
/*     */     
/* 160 */     BasicUser basicUser = getSecurity().getUser(paramInt);
/*     */     
/* 162 */     if (basicUser != null) {
/* 163 */       str = String.valueOf(basicUser.getUserFirstname()) + " " + basicUser.getUserLastname();
/*     */     } else {
/* 165 */       str = null;
/*     */     } 
/* 167 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public String getStyleSheet() { return this.stylePath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public String getStyleLink() { return "<link rel=\"STYLESHEET\" type=\"text/css\" href=\"" + getStyleSheet() + "\">"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public int getRandomPasswordLength() { return this.randomPasswordLength; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   public String getUsersTable() { return this.usersTable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   public boolean isMultiGroup() { return this.multiGroup; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   public String getGenerationLogDir() { return this.generationLogDir; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxSettings.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */