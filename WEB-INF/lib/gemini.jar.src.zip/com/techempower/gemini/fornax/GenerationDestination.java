/*     */ package com.techempower.gemini.fornax;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenerationDestination
/*     */   implements FornaxDBConstants
/*     */ {
/*     */   protected int mGenerationDestinationID;
/*     */   protected FilePath mGenerationDestinationFilePath;
/*     */   protected String mGenerationDestinationName;
/*     */   protected String mGenerationDestinationDesc;
/*     */   protected String mGenerationDestinationServerNetworkName;
/*     */   protected String mGenerationDestinationServerDNSName;
/*     */   protected String mGenerationDestinationServerIPAddress;
/*     */   protected String mGenerationDestinationLogonUserName;
/*     */   protected String mGenerationDestinationLogonPassword;
/*     */   
/*     */   public GenerationDestination(Hashtable paramHashtable) {
/*  48 */     this.mGenerationDestinationID = ((Integer)paramHashtable.get("generationDestinationID")).intValue();
/*  49 */     this.mGenerationDestinationFilePath = (FilePath)paramHashtable.get("generationDestinationFilePath");
/*  50 */     this.mGenerationDestinationName = (String)paramHashtable.get("generationDestinationName");
/*  51 */     this.mGenerationDestinationDesc = (String)paramHashtable.get("generationDestinationDesc");
/*  52 */     this.mGenerationDestinationServerNetworkName = (String)paramHashtable.get("generationDestinationServerNetworkName");
/*  53 */     this.mGenerationDestinationServerDNSName = (String)paramHashtable.get("generationDestinationServerDNSName");
/*  54 */     this.mGenerationDestinationServerIPAddress = (String)paramHashtable.get("generationDestinationServerIPAddress");
/*  55 */     this.mGenerationDestinationLogonUserName = (String)paramHashtable.get("generationDestinationLogonUserName");
/*  56 */     this.mGenerationDestinationLogonPassword = (String)paramHashtable.get("generationDestinationLogonPassword");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public int getGenerationDestinationID() { return this.mGenerationDestinationID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public FilePath getFilePath() { return this.mGenerationDestinationFilePath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public String getGenerationDestinationName() { return this.mGenerationDestinationName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public String getGenerationDestinationDesc() { return this.mGenerationDestinationDesc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public String getServerNetworkName() { return this.mGenerationDestinationServerNetworkName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public String getServerDNSkName() { return this.mGenerationDestinationServerDNSName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public String getServerIPAddress() { return this.mGenerationDestinationServerIPAddress; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public String getLogonUserName() { return this.mGenerationDestinationLogonUserName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public String getLogonPassword() { return this.mGenerationDestinationLogonPassword; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\GenerationDestination.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */