package com.techempower.gemini.fornax;

import com.techempower.DataEntity;
import com.techempower.DatabaseConnector;
import java.util.Hashtable;

public class FornaxContentTypeInstancesGroupVariant extends DataEntity implements FornaxConstants, FornaxDBConstants {
  protected int variantID = -1;
  
  protected int variantVariantTypeID = -1;
  
  protected int variantInstancesGroupID = -1;
  
  protected int variantTemplateID = -1;
  
  protected int variantGenerationDestinationID = -1;
  
  protected boolean variantIsEnabledForGeneration = false;
  
  protected String variantFileNamePrefix = "";
  
  protected String variantFileNameTitle = "";
  
  protected String variantFileNameSuffix = "";
  
  protected String variantFileNameExtension = "";
  
  protected String variantFileNameNumberingMode = "";
  
  public void initializationComplete() {}
  
  public Hashtable getCustomSetMethodBindings() {
    Hashtable hashtable = new Hashtable();
    hashtable.put("VariantID", "setID");
    hashtable.put("VariantTypeID", "setVariantTypeID");
    hashtable.put("VariantInstancesGroupID", "setInstancesGroupID");
    hashtable.put("VariantTemplateID", "setTemplateID");
    hashtable.put("VariantGenerationDestinationID", "setGenerationDestinationID");
    hashtable.put("VariantIsEnabledForGeneration", "setIsEnabledForGeneration");
    hashtable.put("VariantFileNamePrefix", "setFileNamePrefix");
    hashtable.put("VariantFileNameTitle", "setFileNameTitle");
    hashtable.put("VariantFileNameSuffix", "setFileNameSuffix");
    hashtable.put("VariantFileNameExtension", "setFileNameExtension");
    hashtable.put("VariantFileNameNumberingMode", "setFileNameNumberingMode");
    return hashtable;
  }
  
  public int getIdentity() { return this.variantID; }
  
  public String getTableName() { return "fnContentTypeInstancesGroupVariant"; }
  
  public String getIdentityColumnName() { return "VariantID"; }
  
  public int getID() { return this.variantID; }
  
  public int getVariantTypeID() { return this.variantVariantTypeID; }
  
  public int getInstancesGroupID() { return this.variantInstancesGroupID; }
  
  public int getTemplateID() { return this.variantTemplateID; }
  
  public int getGenerationDestinationID() { return this.variantGenerationDestinationID; }
  
  public boolean isEnabledForGeneration() { return this.variantIsEnabledForGeneration; }
  
  public String getIsEnabledForGenerationAsString() {
    if (this.variantIsEnabledForGeneration)
      return "T"; 
    return "F";
  }
  
  public String getFileNamePrefix() { return this.variantFileNamePrefix; }
  
  public String getFileNameTitle() { return this.variantFileNameTitle; }
  
  public String getFileNameSuffix() { return this.variantFileNameSuffix; }
  
  public String getFileNameExtension() { return this.variantFileNameExtension; }
  
  public String getFileNameNumberingMode() { return this.variantFileNameNumberingMode; }
  
  public void setID(int paramInt) { this.variantID = paramInt; }
  
  public void setVariantTypeID(int paramInt) { this.variantVariantTypeID = paramInt; }
  
  public void setInstancesGroupID(int paramInt) { this.variantInstancesGroupID = paramInt; }
  
  public void setTemplateID(int paramInt) { this.variantTemplateID = paramInt; }
  
  public void setGenerationDestinationID(int paramInt) { this.variantGenerationDestinationID = paramInt; }
  
  public void setIsEnabledForGeneration(String paramString) {
    this.variantIsEnabledForGeneration = false;
    if (paramString.trim().equalsIgnoreCase("T"))
      this.variantIsEnabledForGeneration = true; 
  }
  
  public void setFileNamePrefix(String paramString) {
    if (paramString != null)
      this.variantFileNamePrefix = paramString; 
  }
  
  public void setFileNameTitle(String paramString) {
    if (paramString != null)
      this.variantFileNameTitle = paramString; 
  }
  
  public void setFileNameSuffix(String paramString) {
    if (paramString != null)
      this.variantFileNameSuffix = paramString; 
  }
  
  public void setFileNameExtension(String paramString) {
    if (paramString != null)
      this.variantFileNameExtension = paramString; 
  }
  
  public void setFileNameNumberingMode(String paramString) {
    if (paramString != null)
      this.variantFileNameNumberingMode = paramString; 
  }
  
  public int runUpdate(DatabaseConnector paramDatabaseConnector) {
    String str1 = "IDENTITY_VALUE";
    String str2 = "ROWCOUNT_VALUE";
    boolean bool = false;
    String str3 = new String("");
    String str4 = new String("select @@identity as 'IDENTITY_VALUE'");
    String str5 = new String("select @@rowcount as 'ROWCOUNT_VALUE'");
    if (this.variantID == -1) {
      bool = true;
      str3 = String.valueOf(str3) + "INSERT INTO " + getTableName() + 
        "          ( " + "variantTypeID" + ", " + 
        "variantInstancesGroupID" + ", " + 
        "variantTemplateID" + ", " + 
        "variantGenerationDestinationID" + ", " + 
        "variantIsEnabledForGeneration" + ", " + 
        "variantFileNamePrefix" + ", " + 
        "variantFileNameTitle" + ", " + 
        "variantFileNameSuffix" + ", " + 
        "variantFileNameExtension" + ", " + 
        "variantFileNameNumberingMode" + 
        "          ) " + 
        "   VALUES (" + getVariantTypeID() + ", " + 
        getInstancesGroupID() + ", " + 
        getTemplateID() + ", " + 
        getGenerationDestinationID() + ",' " + 
        getIsEnabledForGenerationAsString() + "', '" + 
        getFileNamePrefix() + "', '" + 
        getFileNameTitle() + "', '" + 
        getFileNameSuffix() + "', '" + 
        getFileNameExtension() + "', '" + 
        getFileNameNumberingMode() + "'" + 
        "          )";
    } else {
      str3 = String.valueOf(str3) + "UPDATE " + getTableName() + 
        "   SET " + "variantTypeID" + "=" + getVariantTypeID() + ", " + 
        "variantInstancesGroupID" + "=" + getInstancesGroupID() + ", " + 
        "variantTemplateID" + "=" + getTemplateID() + "," + 
        "variantGenerationDestinationID" + "=" + getGenerationDestinationID() + "," + 
        "variantIsEnabledForGeneration" + "='" + getIsEnabledForGenerationAsString() + "'," + 
        "variantFileNamePrefix" + "='" + getFileNamePrefix() + "'," + 
        "variantFileNameTitle" + "='" + getFileNameTitle() + "'," + 
        "variantFileNameSuffix" + "='" + getFileNameSuffix() + "'," + 
        "variantFileNameExtension" + "='" + getFileNameExtension() + "'," + 
        "variantFileNameNumberingMode" + "='" + getFileNameNumberingMode() + "'";
      str3 = String.valueOf(str3) + " WHERE " + getIdentityColumnName() + "=" + getID();
    } 
    if (bool) {
      str3 = String.valueOf(str3) + "; " + str4;
    } else {
      str3 = String.valueOf(str3) + "; " + str5;
    } 
    str3 = "BEGIN TRAN; " + str3 + "; " + "COMMIT TRAN";
    System.out.println("Running sql stmt:\n" + str3);
    paramDatabaseConnector.setQuery(str3);
    paramDatabaseConnector.runQuery();
    if (paramDatabaseConnector.more()) {
      paramDatabaseConnector.first();
      if (bool)
        int j = paramDatabaseConnector.getInt("IDENTITY_VALUE", -1); 
      int i = paramDatabaseConnector.getInt("ROWCOUNT_VALUE", -1);
    } 
    paramDatabaseConnector.close();
    return -1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\fornax\FornaxContentTypeInstancesGroupVariant.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */