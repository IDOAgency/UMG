/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FormElement
/*     */ {
/*     */   public static final String COMPONENT_CODE = "felt";
/*  46 */   protected static String defaultValue = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   protected String name = "";
/*  53 */   protected String displayName = null;
/*     */   
/*     */   protected boolean required = false;
/*     */   protected boolean readOnly = false;
/*  57 */   protected int tabIndex = -1;
/*  58 */   protected Vector formEvents = null;
/*     */   protected boolean enabled = true;
/*  60 */   protected String id = "";
/*  61 */   protected String className = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormElement(String paramString1, String paramString2, boolean paramBoolean) {
/*  73 */     if (paramString2 == null) {
/*  74 */       paramString2 = "";
/*     */     }
/*  76 */     setName(paramString1);
/*  77 */     setStartingValue(paramString2);
/*  78 */     setValue(paramString2);
/*  79 */     setRequired(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public FormElement(String paramString, boolean paramBoolean) { this(paramString, "", paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public FormElement(String paramString) { this(paramString, "", false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public void setName(String paramString) { this.name = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public void setDisplayName(String paramString) { this.displayName = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDisplayName() {
/* 130 */     if (this.displayName != null) {
/* 131 */       return this.displayName;
/*     */     }
/* 133 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public void setClassName(String paramString) { this.className = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 149 */     if (this.className != null && this.className.length() > 0) {
/* 150 */       return " class=\"" + this.className + '"';
/*     */     }
/* 152 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public void setId(String paramString) { this.id = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 168 */     if (this.id != null && this.id.length() > 0) {
/* 169 */       return " id=\"" + this.id + '"';
/*     */     }
/* 171 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public void setRequired(boolean paramBoolean) { this.required = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public boolean isRequired() { return this.required; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public void setReadOnly(boolean paramBoolean) { this.readOnly = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public boolean isReadOnly() { return this.readOnly; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getReadOnlyString() {
/* 213 */     if (this.readOnly) {
/* 214 */       return " readonly";
/*     */     }
/* 216 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void revert() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   public int getIntegerValue() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 315 */   public String toString() { return render(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void customValidation(FormSingleValidation paramFormSingleValidation) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 361 */   public void setTabIndex(int paramInt) { this.tabIndex = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTabIndex() {
/* 369 */     if (this.tabIndex >= 0) {
/* 370 */       return " tabindex=\"" + this.tabIndex + "\" ";
/*     */     }
/* 372 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFormEvent(String paramString1, String paramString2) {
/* 385 */     String str = "";
/*     */     
/* 387 */     if (this.formEvents == null) {
/* 388 */       this.formEvents = new Vector();
/*     */     }
/*     */     
/*     */     try {
/* 392 */       StringBuffer stringBuffer = new StringBuffer(50);
/* 393 */       stringBuffer.append(' ');
/* 394 */       stringBuffer.append(paramString1);
/* 395 */       stringBuffer.append("=\"");
/* 396 */       stringBuffer.append(paramString2);
/* 397 */       stringBuffer.append('"');
/*     */       
/* 399 */       this.formEvents.add(stringBuffer.toString());
/*     */     }
/* 401 */     catch (NullPointerException nullPointerException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormEvents() {
/* 413 */     if (this.formEvents != null && 
/* 414 */       this.formEvents.size() > 0) {
/*     */       
/* 416 */       StringBuffer stringBuffer = new StringBuffer(50);
/*     */       
/* 418 */       for (byte b = 0; b < this.formEvents.size(); b++)
/*     */       {
/* 420 */         stringBuffer.append(this.formEvents.get(b));
/*     */       }
/*     */       
/* 423 */       return stringBuffer.toString();
/*     */     } 
/*     */ 
/*     */     
/* 427 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 436 */   public boolean isEnabled() { return this.enabled; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEnabledString() {
/* 444 */     if (isEnabled()) {
/* 445 */       return "";
/*     */     }
/* 447 */     return " disabled";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 455 */   public void setEnabled(boolean paramBoolean) { this.enabled = paramBoolean; }
/*     */   
/*     */   public abstract String getEscapedValue();
/*     */   
/*     */   public abstract String getRenderableValue();
/*     */   
/*     */   public abstract String getStartingValue();
/*     */   
/*     */   public abstract String getStringValue();
/*     */   
/*     */   public abstract boolean isDefault();
/*     */   
/*     */   public abstract boolean isUnchanged();
/*     */   
/*     */   public abstract String render();
/*     */   
/*     */   public abstract void setStartingValue(String paramString);
/*     */   
/*     */   public abstract void setValue(Context paramContext);
/*     */   
/*     */   public abstract void setValue(String paramString);
/*     */   
/*     */   public abstract FormSingleValidation validate();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */