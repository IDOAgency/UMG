package com.techempower.gemini;

import java.util.Vector;

public abstract class FormElement {
  public static final String COMPONENT_CODE = "felt";
  
  protected static String defaultValue = "";
  
  protected String name = "";
  
  protected String displayName = null;
  
  protected boolean required = false;
  
  protected boolean readOnly = false;
  
  protected int tabIndex = -1;
  
  protected Vector formEvents = null;
  
  protected boolean enabled = true;
  
  protected String id = "";
  
  protected String className = "";
  
  public FormElement(String paramString1, String paramString2, boolean paramBoolean) {
    if (paramString2 == null)
      paramString2 = ""; 
    setName(paramString1);
    setStartingValue(paramString2);
    setValue(paramString2);
    setRequired(paramBoolean);
  }
  
  public FormElement(String paramString, boolean paramBoolean) { this(paramString, "", paramBoolean); }
  
  public FormElement(String paramString) { this(paramString, "", false); }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setDisplayName(String paramString) { this.displayName = paramString; }
  
  public String getDisplayName() {
    if (this.displayName != null)
      return this.displayName; 
    return getName();
  }
  
  public void setClassName(String paramString) { this.className = paramString; }
  
  public String getClassName() {
    if (this.className != null && this.className.length() > 0)
      return " class=\"" + this.className + '"'; 
    return "";
  }
  
  public void setId(String paramString) { this.id = paramString; }
  
  public String getId() {
    if (this.id != null && this.id.length() > 0)
      return " id=\"" + this.id + '"'; 
    return "";
  }
  
  public void setRequired(boolean paramBoolean) { this.required = paramBoolean; }
  
  public boolean isRequired() { return this.required; }
  
  public void setReadOnly(boolean paramBoolean) { this.readOnly = paramBoolean; }
  
  public boolean isReadOnly() { return this.readOnly; }
  
  public String getReadOnlyString() {
    if (this.readOnly)
      return " readonly"; 
    return "";
  }
  
  public void revert() {}
  
  public int getIntegerValue() { return 0; }
  
  public String toString() { return render(); }
  
  protected void customValidation(FormSingleValidation paramFormSingleValidation) {}
  
  public void setTabIndex(int paramInt) { this.tabIndex = paramInt; }
  
  public String getTabIndex() {
    if (this.tabIndex >= 0)
      return " tabindex=\"" + this.tabIndex + "\" "; 
    return "";
  }
  
  public void addFormEvent(String paramString1, String paramString2) {
    String str = "";
    if (this.formEvents == null)
      this.formEvents = new Vector(); 
    try {
      StringBuffer stringBuffer = new StringBuffer(50);
      stringBuffer.append(' ');
      stringBuffer.append(paramString1);
      stringBuffer.append("=\"");
      stringBuffer.append(paramString2);
      stringBuffer.append('"');
      this.formEvents.add(stringBuffer.toString());
    } catch (NullPointerException nullPointerException) {}
  }
  
  public String getFormEvents() {
    if (this.formEvents != null && 
      this.formEvents.size() > 0) {
      StringBuffer stringBuffer = new StringBuffer(50);
      for (byte b = 0; b < this.formEvents.size(); b++)
        stringBuffer.append(this.formEvents.get(b)); 
      return stringBuffer.toString();
    } 
    return "";
  }
  
  public boolean isEnabled() { return this.enabled; }
  
  public String getEnabledString() {
    if (isEnabled())
      return ""; 
    return " disabled";
  }
  
  public void setEnabled(boolean paramBoolean) { this.enabled = paramBoolean; }
  
  public abstract String getEscapedValue();
  
  public abstract String getRenderableValue();
  
  public abstract String getStartingValue();
  
  public abstract String getStringValue();
  
  public abstract boolean isDefault();
  
  public abstract boolean isUnchanged();
  
  public abstract String render();
  
  public abstract void setStartingValue(String paramString);
  
  public abstract void setValue(Context paramContext);
  
  public abstract void setValue(String paramString);
  
  public abstract FormSingleValidation validate();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormElement.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */