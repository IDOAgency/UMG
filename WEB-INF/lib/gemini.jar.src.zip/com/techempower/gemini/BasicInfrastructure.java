/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import com.techempower.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicInfrastructure
/*     */   implements GeminiConstants
/*     */ {
/*     */   public static final String COMPONENT_CODE = "infr";
/*     */   public static final String DEFAULT_URL_PREFIX = "";
/*     */   public static final String DEFAULT_HTML_DIR = "/";
/*     */   public static final String DEFAULT_JSP_DIR = "/jsp/";
/*     */   public static final String DEFAULT_IMAGES_DIR = "/images/";
/*     */   public static final String DEFAULT_SERVLET_NAME = "/core/dis";
/*     */   protected RequestLog requestLog;
/*     */   protected String standardDomain;
/*     */   protected String secureDomain;
/*     */   protected String htmlFileDirectory;
/*     */   protected String jspFileDirectory;
/*     */   protected String imageFileDirectory;
/*     */   protected String servletName;
/*     */   protected String urlDirectoryPrefix;
/*     */   protected boolean allowDirectJSPs;
/*     */   protected boolean useURLDirectoryPrefix;
/*     */   protected GeminiApplication application;
/*     */   protected ComponentLog log;
/*     */   
/*     */   public BasicInfrastructure(GeminiApplication paramGeminiApplication) {
/*  49 */     this.requestLog = null;
/*  50 */     this.standardDomain = "";
/*  51 */     this.secureDomain = "";
/*  52 */     this.htmlFileDirectory = "/";
/*  53 */     this.jspFileDirectory = "/jsp/";
/*  54 */     this.imageFileDirectory = "/images/";
/*  55 */     this.servletName = "/core/dis";
/*  56 */     this.urlDirectoryPrefix = "";
/*  57 */     this.allowDirectJSPs = false;
/*  58 */     this.useURLDirectoryPrefix = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     this.application = paramGeminiApplication;
/*     */ 
/*     */     
/*  76 */     this.log = paramGeminiApplication.getLog("infr");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
/*  85 */     this.standardDomain = paramEnhancedProperties.getProperty("StandardDomain", this.standardDomain);
/*  86 */     this.secureDomain = paramEnhancedProperties.getProperty("SecureDomain", this.secureDomain);
/*  87 */     this.htmlFileDirectory = paramEnhancedProperties.getProperty("HTMLDirectory", this.htmlFileDirectory);
/*  88 */     this.jspFileDirectory = paramEnhancedProperties.getProperty("JSPDirectory", this.jspFileDirectory);
/*  89 */     this.imageFileDirectory = paramEnhancedProperties.getProperty("ImageDirectory", this.imageFileDirectory);
/*  90 */     this.servletName = paramEnhancedProperties.getProperty("ServletURL", this.servletName);
/*  91 */     this.allowDirectJSPs = paramEnhancedProperties.getYesNoProperty("AllowDirectJSPs", false);
/*     */ 
/*     */     
/*  94 */     this.requestLog = new RequestLog(
/*  95 */         paramVersion.getProductName(), paramVersion.getVersionString(), 
/*  96 */         paramEnhancedProperties.getProperty("RequestLogDir", "request-logs"), 
/*  97 */         this.application.getLog("reqL"));
/*     */ 
/*     */ 
/*     */     
/* 101 */     boolean bool = paramEnhancedProperties.getYesNoProperty("RequestLogEnabled", false);
/* 102 */     if (bool) {
/*     */       
/* 104 */       this.log.debug("Request logging enabled.");
/* 105 */       this.requestLog.enable();
/*     */     }
/*     */     else {
/*     */       
/* 109 */       this.log.debug("Request logging disabled.");
/* 110 */       this.requestLog.disable();
/*     */     } 
/*     */ 
/*     */     
/* 114 */     this.requestLog.setLogFilenameSuffix(paramEnhancedProperties.getProperty("RequestLogSuffix", this.requestLog.getLogFilenameSuffix()));
/*     */ 
/*     */     
/* 117 */     customConfigure(paramEnhancedProperties, paramVersion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void customConfigure(EnhancedProperties paramEnhancedProperties, Version paramVersion) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public RequestLog getRequestLog() { return this.requestLog; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public String getStandardDomain() { return this.standardDomain; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public String getSecureDomain() { return this.secureDomain; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public String getJspDirectory() { return this.jspFileDirectory; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public String getHtmlDirectory() { return this.htmlFileDirectory; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public String getImageDirectory() { return this.imageFileDirectory; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public String getServletName() { return this.servletName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public String getServletURL() { return getServletName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public String getServletCmdURL(String paramString) { return String.valueOf(this.servletName) + '?' + "cmd" + '=' + paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 213 */   public String getServletCmdAnchor(String paramString) { return "<a href=\"" + getServletCmdURL(paramString) + "\">"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   public String getStandardServletCmdURL(String paramString) { return String.valueOf(getStandardDomain()) + getServletCmdURL(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public String getSecureServletCmdURL(String paramString) { return String.valueOf(getSecureDomain()) + getServletCmdURL(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   public String getURLDirectoryPrefix() { return this.urlDirectoryPrefix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public boolean canInvokeJSPsDirectly() { return this.allowDirectJSPs; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   public boolean useURLDirectoryPrefix() { return this.useURLDirectoryPrefix; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\BasicInfrastructure.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */