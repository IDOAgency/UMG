package com.techempower.gemini;

import com.techempower.ComponentLog;
import com.techempower.EnhancedProperties;
import com.techempower.Version;

public class BasicInfrastructure implements GeminiConstants {
  public static final String COMPONENT_CODE = "infr";
  
  public static final String DEFAULT_URL_PREFIX = "";
  
  public static final String DEFAULT_HTML_DIR = "/";
  
  public static final String DEFAULT_JSP_DIR = "/jsp/";
  
  public static final String DEFAULT_IMAGES_DIR = "/images/";
  
  public static final String DEFAULT_SERVLET_NAME = "/core/dis";
  
  protected RequestLog requestLog;
  
  protected String standardDomain;
  
  protected String secureDomain;
  
  protected String htmlFileDirectory;
  
  protected String jspFileDirectory;
  
  protected String imageFileDirectory;
  
  protected String servletName;
  
  protected String urlDirectoryPrefix;
  
  protected boolean allowDirectJSPs;
  
  protected boolean useURLDirectoryPrefix;
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  public BasicInfrastructure(GeminiApplication paramGeminiApplication) {
    this.requestLog = null;
    this.standardDomain = "";
    this.secureDomain = "";
    this.htmlFileDirectory = "/";
    this.jspFileDirectory = "/jsp/";
    this.imageFileDirectory = "/images/";
    this.servletName = "/core/dis";
    this.urlDirectoryPrefix = "";
    this.allowDirectJSPs = false;
    this.useURLDirectoryPrefix = false;
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("infr");
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
    this.standardDomain = paramEnhancedProperties.getProperty("StandardDomain", this.standardDomain);
    this.secureDomain = paramEnhancedProperties.getProperty("SecureDomain", this.secureDomain);
    this.htmlFileDirectory = paramEnhancedProperties.getProperty("HTMLDirectory", this.htmlFileDirectory);
    this.jspFileDirectory = paramEnhancedProperties.getProperty("JSPDirectory", this.jspFileDirectory);
    this.imageFileDirectory = paramEnhancedProperties.getProperty("ImageDirectory", this.imageFileDirectory);
    this.servletName = paramEnhancedProperties.getProperty("ServletURL", this.servletName);
    this.allowDirectJSPs = paramEnhancedProperties.getYesNoProperty("AllowDirectJSPs", false);
    this.requestLog = new RequestLog(
        paramVersion.getProductName(), paramVersion.getVersionString(), 
        paramEnhancedProperties.getProperty("RequestLogDir", "request-logs"), 
        this.application.getLog("reqL"));
    boolean bool = paramEnhancedProperties.getYesNoProperty("RequestLogEnabled", false);
    if (bool) {
      this.log.debug("Request logging enabled.");
      this.requestLog.enable();
    } else {
      this.log.debug("Request logging disabled.");
      this.requestLog.disable();
    } 
    this.requestLog.setLogFilenameSuffix(paramEnhancedProperties.getProperty("RequestLogSuffix", this.requestLog.getLogFilenameSuffix()));
    customConfigure(paramEnhancedProperties, paramVersion);
  }
  
  public void customConfigure(EnhancedProperties paramEnhancedProperties, Version paramVersion) {}
  
  public RequestLog getRequestLog() { return this.requestLog; }
  
  public String getStandardDomain() { return this.standardDomain; }
  
  public String getSecureDomain() { return this.secureDomain; }
  
  public String getJspDirectory() { return this.jspFileDirectory; }
  
  public String getHtmlDirectory() { return this.htmlFileDirectory; }
  
  public String getImageDirectory() { return this.imageFileDirectory; }
  
  public String getServletName() { return this.servletName; }
  
  public String getServletURL() { return getServletName(); }
  
  public String getServletCmdURL(String paramString) { return String.valueOf(this.servletName) + '?' + "cmd" + '=' + paramString; }
  
  public String getServletCmdAnchor(String paramString) { return "<a href=\"" + getServletCmdURL(paramString) + "\">"; }
  
  public String getStandardServletCmdURL(String paramString) { return String.valueOf(getStandardDomain()) + getServletCmdURL(paramString); }
  
  public String getSecureServletCmdURL(String paramString) { return String.valueOf(getSecureDomain()) + getServletCmdURL(paramString); }
  
  public String getURLDirectoryPrefix() { return this.urlDirectoryPrefix; }
  
  public boolean canInvokeJSPsDirectly() { return this.allowDirectJSPs; }
  
  public boolean useURLDirectoryPrefix() { return this.useURLDirectoryPrefix; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\BasicInfrastructure.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */