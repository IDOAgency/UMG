package com.techempower.gemini.pyxis;

public class PyxisUsersGroup extends PyxisStandardGroup {
  public PyxisUsersGroup(PyxisSettings paramPyxisSettings) { super(paramPyxisSettings); }
  
  public int getGroupID() { return 1; }
  
  public String getName() { return "Users"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\pyxis\PyxisUsersGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */