package com.techempower.gemini.pyxis;

import com.techempower.BoxedInt;
import com.techempower.DataEntity;
import java.util.ArrayList;

public class BasicUser extends DataEntity implements PyxisConstants {
  protected int userID;
  
  protected String userUsername;
  
  private String userPassword;
  
  protected String userFirstname;
  
  protected String userLastname;
  
  private int[] userGroups;
  
  private boolean memberAdministrators;
  
  private boolean memberUsers;
  
  private boolean memberGuests;
  
  protected PyxisSettings settings;
  
  public BasicUser(PyxisSettings paramPyxisSettings) {
    this.userID = 0;
    this.userUsername = "";
    this.userPassword = "";
    this.userFirstname = "";
    this.userLastname = "";
    this.userGroups = new int[0];
    this.memberAdministrators = false;
    this.memberUsers = false;
    this.memberGuests = false;
    this.settings = paramPyxisSettings;
  }
  
  public void setUserGroups(int[] paramArrayOfInt) {
    this.userGroups = paramArrayOfInt;
    evaluateGroups();
  }
  
  public void setUserGroups(ArrayList paramArrayList) {
    this.userGroups = new int[paramArrayList.size()];
    for (byte b = 0; b < paramArrayList.size(); b++) {
      BoxedInt boxedInt = (BoxedInt)paramArrayList.get(b);
      this.userGroups[b] = boxedInt.get();
    } 
    evaluateGroups();
  }
  
  public void setUserID(int paramInt) { this.userID = paramInt; }
  
  public void setUserUsername(String paramString) { this.userUsername = paramString; }
  
  public void setUserPassword(String paramString) { this.userPassword = paramString; }
  
  public void setUserFirstname(String paramString) { this.userFirstname = paramString; }
  
  public void setUserLastname(String paramString) { this.userLastname = paramString; }
  
  public int getUserID() { return this.userID; }
  
  public String getUserUsername() { return this.userUsername; }
  
  public final String getUserPassword() { return this.userPassword; }
  
  public String getUserFirstname() { return this.userFirstname; }
  
  public String getUserLastname() { return this.userLastname; }
  
  public final boolean isAdministrator() { return this.memberAdministrators; }
  
  public final boolean isUser() { return this.memberUsers; }
  
  public final boolean isGuest() { return this.memberGuests; }
  
  public final boolean isMember(int paramInt) {
    for (byte b = 0; b < this.userGroups.length; b++) {
      if (this.userGroups[b] == paramInt)
        return true; 
    } 
    return false;
  }
  
  protected void evaluateGroups() {
    this.memberAdministrators = false;
    this.memberUsers = false;
    this.memberGuests = false;
    for (byte b = 0; b < this.userGroups.length; b++) {
      if (this.userGroups[b] == 1000) {
        this.memberAdministrators = true;
      } else if (this.userGroups[b] == 1) {
        this.memberUsers = true;
      } else if (this.userGroups[b] == 0) {
        this.memberGuests = true;
      } 
    } 
  }
  
  public int getIdentity() { return this.userID; }
  
  public String getTableName() { return this.settings.getUsersTable(); }
  
  public String getIdentityColumnName() { return "UserID"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\pyxis\BasicUser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */