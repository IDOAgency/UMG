package com.techempower.gemini.pyxis;

import com.techempower.gemini.GeminiConstants;

public interface PyxisConstants extends GeminiConstants {
  public static final String PYXIS_PREFIX = "Pyxis.";
  
  public static final String SHORT_PYXIS_PREFIX = "px";
  
  public static final String SESSION_USER = "Pyxis.User";
  
  public static final String USERS_IDENTITY = "UserID";
  
  public static final String USERS_USERNAME = "UserUsername";
  
  public static final String USERS_PASSWORD = "UserPassword";
  
  public static final String GROUPS_IDENTITY = "GroupID";
  
  public static final String GROUPS_NAME = "GroupName";
  
  public static final String GROUPS_DESCRIPTION = "GroupDescription";
  
  public static final int GROUP_ADMINISTRATORS = 1000;
  
  public static final int GROUP_GUESTS = 0;
  
  public static final int GROUP_USERS = 1;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\pyxis\PyxisConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */