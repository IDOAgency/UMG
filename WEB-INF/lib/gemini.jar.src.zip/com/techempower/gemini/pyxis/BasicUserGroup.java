package com.techempower.gemini.pyxis;

import com.techempower.DataEntity;

public class BasicUserGroup extends DataEntity implements PyxisConstants {
  protected int groupID;
  
  protected String name;
  
  protected String description;
  
  protected PyxisSettings settings;
  
  public BasicUserGroup(PyxisSettings paramPyxisSettings) { this.settings = paramPyxisSettings; }
  
  public void setGroupID(int paramInt) { this.groupID = paramInt; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public void setDescription(String paramString) { this.description = paramString; }
  
  public int getGroupID() { return this.groupID; }
  
  public String getName() { return this.name; }
  
  public String getDescription() { return this.description; }
  
  public int getIdentity() { return this.groupID; }
  
  public String getTableName() { return this.settings.getGroupsTable(); }
  
  public String getIdentityColumnName() { return "GroupID"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\pyxis\BasicUserGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */