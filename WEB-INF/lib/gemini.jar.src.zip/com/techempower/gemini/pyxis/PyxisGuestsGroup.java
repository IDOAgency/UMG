package com.techempower.gemini.pyxis;

public class PyxisGuestsGroup extends PyxisStandardGroup {
  public PyxisGuestsGroup(PyxisSettings paramPyxisSettings) { super(paramPyxisSettings); }
  
  public int getGroupID() { return 0; }
  
  public String getName() { return "Guests"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\pyxis\PyxisGuestsGroup.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */