package com.techempower.gemini.pyxis;

public class BasicWebUser extends BasicUser {
  protected String userEmail = "";
  
  protected String userPasswordHint = "";
  
  public BasicWebUser(PyxisSettings paramPyxisSettings) { super(paramPyxisSettings); }
  
  public void setUserEmail(String paramString) { this.userEmail = paramString; }
  
  public void setUserPasswordHint(String paramString) { this.userPasswordHint = paramString; }
  
  public String getUserEmail() { return this.userEmail; }
  
  public String getUserPasswordHint() { return this.userPasswordHint; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\pyxis\BasicWebUser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */