/*     */ package com.techempower.gemini;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormSingleValidation
/*     */ {
/*  36 */   public FormElement element = null;
/*     */   public boolean isError = false;
/*  38 */   public String error = null;
/*  39 */   public String instruction = null;
/*  40 */   public String inline = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormSingleValidation(FormElement paramFormElement, boolean paramBoolean, String paramString1, String paramString2, String paramString3) {
/*  60 */     this.element = paramFormElement;
/*  61 */     this.instruction = paramString2;
/*  62 */     this.isError = paramBoolean;
/*  63 */     this.error = paramString1;
/*  64 */     this.inline = paramString3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public FormSingleValidation(FormElement paramFormElement, boolean paramBoolean, String paramString1, String paramString2) { this(paramFormElement, paramBoolean, paramString1, paramString2, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public FormSingleValidation(FormElement paramFormElement) { this.element = paramFormElement; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setError(String paramString1, String paramString2, String paramString3) {
/*  95 */     this.isError = true;
/*  96 */     this.error = paramString1;
/*  97 */     this.instruction = paramString2;
/*  98 */     this.inline = paramString3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void setError(String paramString1, String paramString2) { setError(paramString1, paramString2, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSet() {
/* 118 */     return !(!this.isError || (
/* 119 */       this.error == null && 
/* 120 */       this.instruction == null && 
/* 121 */       this.inline == null));
/*     */   }
/*     */   
/*     */   public FormSingleValidation() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormSingleValidation.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */