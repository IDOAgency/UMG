package com.techempower.gemini;

import com.techempower.BasicHelper;

public class FormHidden extends FormElement {
  public static final String DEFAULT_VALUE = "";
  
  protected String value;
  
  protected String startingValue;
  
  public FormHidden(String paramString1, String paramString2, boolean paramBoolean) {
    super(paramString1, paramString2, false);
    setReadOnly(paramBoolean);
  }
  
  public FormHidden(String paramString1, String paramString2) { this(paramString1, paramString2, false); }
  
  public FormHidden(String paramString) { this(paramString, ""); }
  
  public void setValue(String paramString) {
    if (!isReadOnly())
      this.value = paramString; 
  }
  
  public void setStartingValue(String paramString) { this.startingValue = paramString; }
  
  public String getStartingValue() { return this.startingValue; }
  
  public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.value)); }
  
  protected String getValue() { return this.value; }
  
  public String getStringValue() { return getValue(); }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public int getIntegerValue() {
    try {
      return Integer.parseInt(getValue());
    } catch (NumberFormatException numberFormatException) {
      return 0;
    } 
  }
  
  public String render() {
    StringBuffer stringBuffer = new StringBuffer(60);
    stringBuffer.append("<input type=\"hidden\" name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" value=\"");
    stringBuffer.append(getRenderableValue());
    stringBuffer.append("\">");
    return stringBuffer.toString();
  }
  
  public FormSingleValidation validate() {
    FormSingleValidation formSingleValidation = new FormSingleValidation(this);
    if (isRequired())
      requiredValidation(formSingleValidation); 
    customValidation(formSingleValidation);
    return formSingleValidation;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {}
  
  public boolean isDefault() { return "".equals(getValue()); }
  
  public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormHidden.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */