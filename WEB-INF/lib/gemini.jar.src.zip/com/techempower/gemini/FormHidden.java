/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormHidden
/*     */   extends FormElement
/*     */ {
/*     */   public static final String DEFAULT_VALUE = "";
/*     */   protected String value;
/*     */   protected String startingValue;
/*     */   
/*     */   public FormHidden(String paramString1, String paramString2, boolean paramBoolean) {
/*  57 */     super(paramString1, paramString2, false);
/*  58 */     setReadOnly(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public FormHidden(String paramString1, String paramString2) { this(paramString1, paramString2, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public FormHidden(String paramString) { this(paramString, ""); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String paramString) {
/*  86 */     if (!isReadOnly()) {
/*  87 */       this.value = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public void setStartingValue(String paramString) { this.startingValue = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public String getStartingValue() { return this.startingValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.value)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   protected String getValue() { return this.value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public String getStringValue() { return getValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerValue() {
/*     */     try {
/* 168 */       return Integer.parseInt(getValue());
/*     */     
/*     */     }
/* 171 */     catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 185 */     StringBuffer stringBuffer = new StringBuffer(60);
/* 186 */     stringBuffer.append("<input type=\"hidden\" name=\"");
/* 187 */     stringBuffer.append(getName());
/* 188 */     stringBuffer.append("\" value=\"");
/* 189 */     stringBuffer.append(getRenderableValue());
/* 190 */     stringBuffer.append("\">");
/*     */     
/* 192 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormSingleValidation validate() {
/* 205 */     FormSingleValidation formSingleValidation = new FormSingleValidation(this);
/*     */     
/* 207 */     if (isRequired())
/*     */     {
/*     */       
/* 210 */       requiredValidation(formSingleValidation);
/*     */     }
/*     */ 
/*     */     
/* 214 */     customValidation(formSingleValidation);
/*     */     
/* 216 */     return formSingleValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public boolean isDefault() { return "".equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 247 */   public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormHidden.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */