/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.gemini.pyxis.BasicSecurity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormAddRemoveMultiSelectBox
/*     */   extends FormMultiSelectBox
/*     */ {
/*  40 */   protected int[] selectionIDs = null;
/*  41 */   protected int[] valueIDs = null;
/*     */   
/*  43 */   protected String form1Name = "f" + BasicSecurity.randomPassword(5) + "f";
/*  44 */   protected String form2Name = "f" + BasicSecurity.randomPassword(5) + "f";
/*  45 */   protected String fmsbName = "s" + BasicSecurity.randomPassword(5) + "s";
/*  46 */   protected String divForm1Name = "d" + BasicSecurity.randomPassword(5) + "d";
/*  47 */   protected String divForm2Name = "d" + BasicSecurity.randomPassword(5) + "d";
/*  48 */   protected String divForm1Class = "c" + BasicSecurity.randomPassword(5) + "c";
/*  49 */   protected String divForm2Class = "c" + BasicSecurity.randomPassword(5) + "c";
/*     */   
/*  51 */   protected int divTop = 0;
/*  52 */   protected int divLeft = 0;
/*  53 */   protected int div1Top = 0;
/*  54 */   protected int div1Left = 0;
/*  55 */   protected int div2Top = 0;
/*  56 */   protected int div2Left = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormAddRemoveMultiSelectBox(String paramString, String[] paramArrayOfString1, int[] paramArrayOfInt1, String[] paramArrayOfString2, int[] paramArrayOfInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  71 */     super(paramString, paramArrayOfString1, paramArrayOfString2, paramBoolean1, paramBoolean2);
/*  72 */     this.div1Top = paramInt1;
/*  73 */     this.div1Left = paramInt2;
/*  74 */     this.div2Top = paramInt3;
/*  75 */     this.div2Left = paramInt4;
/*  76 */     this.fmsbName = String.valueOf(paramString) + "2";
/*  77 */     this.selectionIDs = paramArrayOfInt1;
/*  78 */     this.valueIDs = paramArrayOfInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormAddRemoveMultiSelectBox(String paramString, String[] paramArrayOfString1, int[] paramArrayOfInt1, String[] paramArrayOfString2, int[] paramArrayOfInt2, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  93 */     super(paramString, paramArrayOfString1, paramArrayOfString2, paramBoolean);
/*  94 */     this.div1Top = paramInt1;
/*  95 */     this.div1Left = paramInt2;
/*  96 */     this.div2Top = paramInt3;
/*  97 */     this.div2Left = paramInt4;
/*  98 */     this.fmsbName = String.valueOf(paramString) + "2";
/*  99 */     this.selectionIDs = paramArrayOfInt1;
/* 100 */     this.valueIDs = paramArrayOfInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public FormAddRemoveMultiSelectBox(String paramString, String[] paramArrayOfString, int[] paramArrayOfInt, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this(paramString, null, null, paramArrayOfString, paramArrayOfInt, paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public FormAddRemoveMultiSelectBox(String paramString, String[] paramArrayOfString, int[] paramArrayOfInt, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this(paramString, null, null, paramArrayOfString, paramArrayOfInt, paramBoolean1, paramBoolean2, paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getStyleSheet(String paramString, int paramInt1, int paramInt2) {
/* 164 */     StringBuffer stringBuffer = new StringBuffer();
/* 165 */     stringBuffer.append("\n");
/* 166 */     stringBuffer.append("<style type=\"text/css\">\n");
/* 167 */     stringBuffer.append("." + paramString + "\n{\n");
/* 168 */     stringBuffer.append("position : absolute;\n");
/* 169 */     stringBuffer.append("top : " + paramInt1 + ";\n");
/* 170 */     stringBuffer.append("left : " + paramInt2 + ";\n");
/* 171 */     stringBuffer.append("z-index : 1;\n}\n");
/* 172 */     stringBuffer.append("</style>\n");
/* 173 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getJavaScriptHeader() {
/* 181 */     StringBuffer stringBuffer = new StringBuffer();
/* 182 */     stringBuffer.append("\n");
/* 183 */     stringBuffer.append("<script language=\"JavaScript\">\n");
/* 184 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   protected String getJavaScriptEnd() { return "\n</script>\n"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 200 */     String str1 = "";
/* 201 */     String str2 = isMultiple() ? " multiple " : " ";
/*     */     
/* 203 */     String str3 = " ";
/* 204 */     if (getAction() != null)
/*     */     {
/* 206 */       str3 = " onChange=\"" + getAction() + "\" ";
/*     */     }
/*     */     
/* 209 */     StringBuffer stringBuffer = new StringBuffer();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 214 */     stringBuffer.append(getStyleSheet(this.divForm1Class, this.div1Top, this.div1Left));
/* 215 */     stringBuffer.append(getStyleSheet(this.divForm2Class, this.div2Top, this.div2Left));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     stringBuffer.append(getJavaScriptHeader());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     stringBuffer.append("var " + this.fmsbName + " = new MultiSelectBox()" + ";\n");
/* 226 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".name = \"" + this.fmsbName + "\";\n");
/* 227 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".divName = \"" + this.divForm1Name + "\";\n");
/* 228 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".divText = '" + "<div class=\"" + this.divForm1Class + "\" id=\"" + this.divForm1Name + "\" name=\"" + this.divForm1Name + "\">" + "';\n");
/* 229 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".formName = \"" + this.form1Name + "\";\n");
/* 230 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".formText = '" + "<form name=\"" + this.form1Name + "\">" + "';\n");
/* 231 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".selectText = '" + "<select" + str2 + "name=\"" + this.fmsbName + "\" size=\"" + this.size + "\"" + str3 + " " + getClassName() + ">" + "';\n");
/* 232 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".top = \"" + this.div1Top + "\";\n");
/* 233 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".left = \"" + this.div1Left + "\";\n");
/* 234 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".values = new Array();\n");
/* 235 */     stringBuffer.append(String.valueOf(this.fmsbName) + ".valueIDs = new Array();\n");
/* 236 */     if (this.values != null)
/*     */     {
/* 238 */       for (byte b = 0; b < this.values.length; b++) {
/*     */         
/* 240 */         stringBuffer.append(String.valueOf(this.fmsbName) + ".values[" + b + "] = \"" + this.values[b] + "\";\n");
/* 241 */         stringBuffer.append(String.valueOf(this.fmsbName) + ".valueIDs[" + b + "] = \"" + this.valueIDs[b] + "\";\n");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     stringBuffer.append("var " + getName() + " = new MultiSelectBox()" + ";\n");
/* 249 */     stringBuffer.append(String.valueOf(getName()) + ".name = \"" + getName() + "\";\n");
/* 250 */     stringBuffer.append(String.valueOf(getName()) + ".divName = \"" + this.divForm2Name + "\";\n");
/* 251 */     stringBuffer.append(String.valueOf(getName()) + ".divText = '" + "<div class=\"" + this.divForm2Class + "\" id=\"" + this.divForm2Name + "\" name=\"" + this.divForm2Name + "\">" + "';\n");
/* 252 */     stringBuffer.append(String.valueOf(getName()) + ".formName = \"" + this.form2Name + "\";\n");
/* 253 */     stringBuffer.append(String.valueOf(getName()) + ".formText = '" + "<form name=\"" + this.form2Name + "\">" + "';\n");
/* 254 */     stringBuffer.append(String.valueOf(getName()) + ".selectText = '" + "<select" + str2 + "name=\"" + getName() + "\" size=\"" + this.size + "\"" + str3 + " " + getClassName() + ">" + "';\n");
/* 255 */     stringBuffer.append(String.valueOf(getName()) + ".top = \"" + this.div2Top + "\";\n");
/* 256 */     stringBuffer.append(String.valueOf(getName()) + ".left = \"" + this.div2Left + "\";\n");
/* 257 */     stringBuffer.append(String.valueOf(getName()) + ".values = new Array();\n");
/* 258 */     stringBuffer.append(String.valueOf(getName()) + ".valueIDs = new Array();\n");
/* 259 */     if (this.selections != null)
/*     */     {
/* 261 */       for (byte b = 0; b < this.selections.length; b++) {
/*     */         
/* 263 */         stringBuffer.append(String.valueOf(getName()) + ".values[" + b + "] = \"" + this.selections[b] + "\";\n");
/* 264 */         stringBuffer.append(String.valueOf(getName()) + ".valueIDs[" + b + "] = \"" + this.selectionIDs[b] + "\";\n");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 271 */     stringBuffer.append(getJavaScriptEnd());
/* 272 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormAddRemoveMultiSelectBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */