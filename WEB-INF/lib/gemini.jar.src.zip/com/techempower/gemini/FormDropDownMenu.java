/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormDropDownMenu
/*     */   extends FormElement
/*     */ {
/*     */   public static final String DEFAULT_VALUES = "";
/*     */   public static final String DEFAULT_SELECTION = "";
/*     */   protected String selection;
/*     */   protected Vector values;
/*     */   protected Vector menuText;
/*     */   protected String startingSelection;
/*     */   protected String onChangeAction;
/*     */   
/*     */   public FormDropDownMenu(String paramString1, String paramString2, String[] paramArrayOfString1, String[] paramArrayOfString2, boolean paramBoolean) {
/*  77 */     super(paramString1, paramString2, paramBoolean);
/*  78 */     setMenuTextList(paramArrayOfString2);
/*  79 */     setValueList(paramArrayOfString1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormDropDownMenu(String paramString1, String paramString2, Integer[] paramArrayOfInteger, String[] paramArrayOfString, boolean paramBoolean) {
/*  95 */     super(paramString1, paramString2, paramBoolean);
/*  96 */     setMenuTextList(paramArrayOfString);
/*  97 */     setValueList(paramArrayOfInteger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormDropDownMenu(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean) {
/* 114 */     super(paramString1, paramString2, paramBoolean);
/* 115 */     setMenuTextList(paramString4);
/* 116 */     setValueList(paramString3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public FormDropDownMenu(String paramString1, String paramString2, String[] paramArrayOfString, boolean paramBoolean) { this(paramString1, paramString2, paramArrayOfString, paramArrayOfString, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public FormDropDownMenu(String paramString1, String paramString2, String paramString3, boolean paramBoolean) { this(paramString1, paramString2, paramString3, paramString3, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public FormDropDownMenu(String paramString1, String paramString2, boolean paramBoolean) { this(paramString1, "", paramString2, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public FormDropDownMenu(String paramString, String[] paramArrayOfString, boolean paramBoolean) { this(paramString, "", paramArrayOfString, paramBoolean); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public FormDropDownMenu(String paramString1, String paramString2) { this(paramString1, "", paramString2, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public FormDropDownMenu(String paramString) { this(paramString, "", "", false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String paramString) {
/* 190 */     if (!isReadOnly()) {
/* 191 */       this.selection = paramString;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueList(String paramString) {
/* 199 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
/*     */     
/* 201 */     int i = stringTokenizer.countTokens();
/* 202 */     boolean bool = false;
/* 203 */     this.values = new Vector(i);
/*     */     
/* 205 */     while (stringTokenizer.hasMoreTokens())
/*     */     {
/* 207 */       this.values.addElement(stringTokenizer.nextToken().trim());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueList(String[] paramArrayOfString) {
/* 216 */     this.values = new Vector(paramArrayOfString.length);
/* 217 */     for (byte b = 0; b < paramArrayOfString.length; b++)
/*     */     {
/* 219 */       this.values.addElement(paramArrayOfString[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueList(Integer[] paramArrayOfInteger) {
/* 229 */     this.values = new Vector(paramArrayOfInteger.length);
/* 230 */     for (byte b = 0; b < paramArrayOfInteger.length; b++)
/*     */     {
/* 232 */       this.values.addElement(paramArrayOfInteger[b].toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendOption(String paramString1, String paramString2) {
/* 245 */     this.values.addElement(paramString1);
/* 246 */     if (paramString2 != null) {
/* 247 */       this.menuText.addElement(paramString2);
/*     */     } else {
/* 249 */       this.menuText.addElement(paramString1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public void setStartingValue(String paramString) { this.startingSelection = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public String getStartingValue() { return this.startingSelection; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), this.selection)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   protected String getValue() { return this.selection; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 298 */   public String getAction() { return this.onChangeAction; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 306 */   public String getStringValue() { return getValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIntegerValue() {
/*     */     try {
/* 317 */       return Integer.parseInt(getValue());
/*     */     }
/* 319 */     catch (NumberFormatException numberFormatException) {
/*     */       
/* 321 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 332 */   public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 343 */   public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getValueList() {
/* 351 */     null = new String[this.values.size()];
/* 352 */     return (String[])this.values.toArray(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 361 */   public Vector getValuesVector() { return this.values; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String render() {
/* 369 */     String str = " ";
/* 370 */     if (getAction() != null)
/*     */     {
/* 372 */       str = " onChange=\"" + getAction() + "\" ";
/*     */     }
/*     */     
/* 375 */     StringBuffer stringBuffer = new StringBuffer(100);
/*     */     
/* 377 */     stringBuffer.append("<select name=\"");
/* 378 */     stringBuffer.append(getName());
/* 379 */     stringBuffer.append('"');
/* 380 */     stringBuffer.append(getTabIndex());
/* 381 */     stringBuffer.append(getFormEvents());
/* 382 */     stringBuffer.append(getEnabledString());
/* 383 */     stringBuffer.append(getId());
/* 384 */     stringBuffer.append(getClassName());
/* 385 */     stringBuffer.append(str);
/* 386 */     stringBuffer.append('>');
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 391 */     for (byte b = 0; b < this.values.size(); b++) {
/*     */       
/* 393 */       String str1 = (String)this.values.elementAt(b);
/*     */       
/* 395 */       stringBuffer.append("<option value=\"");
/* 396 */       stringBuffer.append(str1);
/* 397 */       stringBuffer.append('"');
/*     */       
/* 399 */       if (str1.equals(getStringValue()))
/*     */       {
/* 401 */         stringBuffer.append(" selected");
/*     */       }
/*     */       
/* 404 */       stringBuffer.append('>');
/* 405 */       stringBuffer.append(this.menuText.elementAt(b));
/*     */     } 
/*     */     
/* 408 */     stringBuffer.append("</select>");
/*     */     
/* 410 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormSingleValidation validate() {
/* 418 */     FormSingleValidation formSingleValidation = new FormSingleValidation(this);
/*     */     
/* 420 */     if (isRequired())
/*     */     {
/*     */       
/* 423 */       requiredValidation(formSingleValidation);
/*     */     }
/*     */ 
/*     */     
/* 427 */     customValidation(formSingleValidation);
/*     */     
/* 429 */     return formSingleValidation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
/* 441 */     if (getStringValue().length() == 0)
/*     */     {
/* 443 */       paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is unselected.", 
/* 444 */           "Please select a value from the dropdown menu named " + getDisplayName() + ".", 
/* 445 */           "This dropdown requires a value to be selected");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 455 */   public boolean isDefault() { return "".equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 465 */   public boolean isUnchanged() { return this.startingSelection.equals(getValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMenuTextList(String paramString) {
/* 473 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ",");
/*     */     
/* 475 */     int i = stringTokenizer.countTokens();
/* 476 */     boolean bool = false;
/* 477 */     this.menuText = new Vector(i);
/*     */     
/* 479 */     while (stringTokenizer.hasMoreTokens())
/*     */     {
/* 481 */       this.menuText.addElement(stringTokenizer.nextToken().trim());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMenuTextList(String[] paramArrayOfString) {
/* 490 */     this.menuText = new Vector(paramArrayOfString.length);
/* 491 */     for (byte b = 0; b < paramArrayOfString.length; b++)
/*     */     {
/* 493 */       this.menuText.addElement(paramArrayOfString[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getMenuTextList() {
/* 505 */     null = new String[this.menuText.size()];
/* 506 */     return (String[])this.menuText.toArray(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 518 */   public void setAction(String paramString) { this.onChangeAction = paramString; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormDropDownMenu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */