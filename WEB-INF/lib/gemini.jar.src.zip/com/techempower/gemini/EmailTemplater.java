package com.techempower.gemini;

import com.techempower.BasicHelper;
import com.techempower.ComponentLog;
import com.techempower.EnhancedProperties;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Hashtable;

public class EmailTemplater {
  public static final String COMPONENT_CODE = "emtm";
  
  protected Hashtable emails;
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  public EmailTemplater(GeminiApplication paramGeminiApplication) {
    this.emails = new Hashtable();
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("emtm");
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties) {}
  
  public EmailPackage getEmail(String paramString1, Hashtable paramHashtable, String paramString2, String paramString3) {
    EmailPackage emailPackage = (EmailPackage)this.emails.get(paramString1);
    if (emailPackage != null && emailPackage.getBody() != null) {
      String str = BasicHelper.macroExpand(paramHashtable, emailPackage.getBody());
      return new EmailPackage(emailPackage.getSubject(), str, 
          paramString3, paramString2);
    } 
    return null;
  }
  
  protected int addEmail(EnhancedProperties paramEnhancedProperties, String paramString) {
    String str = paramEnhancedProperties.getProperty(paramString);
    return addEmail(str, paramString);
  }
  
  protected int addEmail(String paramString1, String paramString2) {
    if (paramString1 != null)
      try {
        FileReader fileReader = new FileReader(paramString1);
        LineNumberReader lineNumberReader = new LineNumberReader(fileReader);
        String str = lineNumberReader.readLine();
        if (str != null)
          if (str.toUpperCase().startsWith("SUBJECT: ")) {
            String str1 = str.substring(9);
            StringBuffer stringBuffer = new StringBuffer(100);
            str = lineNumberReader.readLine();
            if (str.length() == 0)
              str = lineNumberReader.readLine(); 
            while (str != null) {
              stringBuffer.append(str);
              stringBuffer.append("\r\n");
              str = lineNumberReader.readLine();
            } 
            this.emails.put(paramString2, new EmailPackage(str1, stringBuffer.toString()));
          }  
        lineNumberReader.close();
        fileReader.close();
        return 1;
      } catch (IOException iOException) {
        this.log.log("Cannot read email contents for " + paramString2 + ": " + iOException);
      }  
    return 0;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\EmailTemplater.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */