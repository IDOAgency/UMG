/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import com.techempower.BasicHelper;
/*     */ import com.techempower.ComponentLog;
/*     */ import com.techempower.EnhancedProperties;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.LineNumberReader;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmailTemplater
/*     */ {
/*     */   public static final String COMPONENT_CODE = "emtm";
/*     */   protected Hashtable emails;
/*     */   protected GeminiApplication application;
/*     */   protected ComponentLog log;
/*     */   
/*     */   public EmailTemplater(GeminiApplication paramGeminiApplication) {
/*  44 */     this.emails = new Hashtable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.application = paramGeminiApplication;
/*  58 */     this.log = paramGeminiApplication.getLog("emtm");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EmailPackage getEmail(String paramString1, Hashtable paramHashtable, String paramString2, String paramString3) {
/*  87 */     EmailPackage emailPackage = (EmailPackage)this.emails.get(paramString1);
/*     */ 
/*     */     
/*  90 */     if (emailPackage != null && emailPackage.getBody() != null) {
/*     */ 
/*     */       
/*  93 */       String str = BasicHelper.macroExpand(paramHashtable, emailPackage.getBody());
/*     */       
/*  95 */       return new EmailPackage(emailPackage.getSubject(), str, 
/*  96 */           paramString3, paramString2);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int addEmail(EnhancedProperties paramEnhancedProperties, String paramString) {
/* 111 */     String str = paramEnhancedProperties.getProperty(paramString);
/*     */     
/* 113 */     return addEmail(str, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int addEmail(String paramString1, String paramString2) {
/* 126 */     if (paramString1 != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 131 */         FileReader fileReader = new FileReader(paramString1);
/* 132 */         LineNumberReader lineNumberReader = new LineNumberReader(fileReader);
/*     */         
/* 134 */         String str = lineNumberReader.readLine();
/*     */         
/* 136 */         if (str != null)
/*     */         {
/*     */           
/* 139 */           if (str.toUpperCase().startsWith("SUBJECT: ")) {
/*     */             
/* 141 */             String str1 = str.substring(9);
/* 142 */             StringBuffer stringBuffer = new StringBuffer(100);
/*     */ 
/*     */             
/* 145 */             str = lineNumberReader.readLine();
/*     */             
/* 147 */             if (str.length() == 0)
/*     */             {
/*     */               
/* 150 */               str = lineNumberReader.readLine();
/*     */             }
/*     */ 
/*     */             
/* 154 */             while (str != null) {
/*     */               
/* 156 */               stringBuffer.append(str);
/* 157 */               stringBuffer.append("\r\n");
/*     */ 
/*     */               
/* 160 */               str = lineNumberReader.readLine();
/*     */             } 
/*     */ 
/*     */             
/* 164 */             this.emails.put(paramString2, new EmailPackage(str1, stringBuffer.toString()));
/*     */           } 
/*     */         }
/*     */         
/* 168 */         lineNumberReader.close();
/* 169 */         fileReader.close();
/*     */         
/* 171 */         return 1;
/*     */       }
/* 173 */       catch (IOException iOException) {
/*     */         
/* 175 */         this.log.log("Cannot read email contents for " + paramString2 + ": " + iOException);
/*     */       } 
/*     */     }
/*     */     
/* 179 */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\EmailTemplater.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */