package com.techempower.gemini;

import java.util.Hashtable;

public class EmailPackage {
  protected String recipientAddress;
  
  protected String mailServer;
  
  protected String messageBody;
  
  protected String authorAddress;
  
  protected String subject;
  
  protected Hashtable custom;
  
  protected boolean sent;
  
  protected boolean successful;
  
  public EmailPackage(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.recipientAddress = null;
    this.mailServer = null;
    this.messageBody = null;
    this.authorAddress = null;
    this.subject = null;
    this.custom = null;
    this.sent = false;
    this.successful = false;
    setBody(paramString2);
    setSubject(paramString1);
    setRecipient(paramString3);
    setAuthor(paramString4);
  }
  
  public EmailPackage(String paramString1, String paramString2) {
    this.recipientAddress = null;
    this.mailServer = null;
    this.messageBody = null;
    this.authorAddress = null;
    this.subject = null;
    this.custom = null;
    this.sent = false;
    this.successful = false;
    setBody(paramString2);
    setSubject(paramString1);
  }
  
  public EmailPackage(String paramString) {
    this.recipientAddress = null;
    this.mailServer = null;
    this.messageBody = null;
    this.authorAddress = null;
    this.subject = null;
    this.custom = null;
    this.sent = false;
    this.successful = false;
    setRecipient(paramString);
  }
  
  public void setCustomAttribute(String paramString1, String paramString2) {
    if (this.custom == null)
      this.custom = new Hashtable(); 
    this.custom.put(paramString1, paramString2);
  }
  
  public String getCustomAttribute(String paramString) {
    if (this.custom != null) {
      String str = (String)this.custom.get(paramString);
      if (str != null)
        return str; 
    } 
    return "";
  }
  
  public void setSent(boolean paramBoolean) { this.sent = paramBoolean; }
  
  public void setSuccessful(boolean paramBoolean) { this.successful = paramBoolean; }
  
  public boolean wasSent() { return this.sent; }
  
  public boolean wasSuccessful() { return this.successful; }
  
  public void setRecipient(String paramString) { this.recipientAddress = paramString; }
  
  public String getRecipient() { return this.recipientAddress; }
  
  public void setAuthor(String paramString) { this.authorAddress = paramString; }
  
  public String getAuthor() { return this.authorAddress; }
  
  public void setSubject(String paramString) { this.subject = paramString; }
  
  public String getSubject() { return this.subject; }
  
  public void setBody(String paramString) { this.messageBody = paramString; }
  
  public String getBody() { return this.messageBody; }
  
  public void setMailServer(String paramString) { this.mailServer = paramString; }
  
  public String getMailServer() { return this.mailServer; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\EmailPackage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */