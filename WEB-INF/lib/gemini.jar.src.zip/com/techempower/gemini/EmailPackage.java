/*     */ package com.techempower.gemini;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmailPackage
/*     */ {
/*     */   protected String recipientAddress;
/*     */   protected String mailServer;
/*     */   protected String messageBody;
/*     */   protected String authorAddress;
/*     */   protected String subject;
/*     */   protected Hashtable custom;
/*     */   protected boolean sent;
/*     */   protected boolean successful;
/*     */   
/*     */   public EmailPackage(String paramString1, String paramString2, String paramString3, String paramString4) {
/*  58 */     this.recipientAddress = null;
/*  59 */     this.mailServer = null;
/*  60 */     this.messageBody = null;
/*  61 */     this.authorAddress = null;
/*  62 */     this.subject = null;
/*  63 */     this.custom = null;
/*  64 */     this.sent = false;
/*  65 */     this.successful = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     setBody(paramString2);
/*  77 */     setSubject(paramString1);
/*  78 */     setRecipient(paramString3);
/*  79 */     setAuthor(paramString4); } public EmailPackage(String paramString1, String paramString2) { this.recipientAddress = null;
/*     */     this.mailServer = null;
/*     */     this.messageBody = null;
/*     */     this.authorAddress = null;
/*     */     this.subject = null;
/*     */     this.custom = null;
/*     */     this.sent = false;
/*     */     this.successful = false;
/*  87 */     setBody(paramString2);
/*  88 */     setSubject(paramString1); } public EmailPackage(String paramString) { this.recipientAddress = null;
/*     */     this.mailServer = null;
/*     */     this.messageBody = null;
/*     */     this.authorAddress = null;
/*     */     this.subject = null;
/*     */     this.custom = null;
/*     */     this.sent = false;
/*     */     this.successful = false;
/*  96 */     setRecipient(paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCustomAttribute(String paramString1, String paramString2) {
/* 107 */     if (this.custom == null)
/* 108 */       this.custom = new Hashtable(); 
/* 109 */     this.custom.put(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCustomAttribute(String paramString) {
/* 118 */     if (this.custom != null) {
/*     */       
/* 120 */       String str = (String)this.custom.get(paramString);
/* 121 */       if (str != null) {
/* 122 */         return str;
/*     */       }
/*     */     } 
/* 125 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public void setSent(boolean paramBoolean) { this.sent = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public void setSuccessful(boolean paramBoolean) { this.successful = paramBoolean; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public boolean wasSent() { return this.sent; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public boolean wasSuccessful() { return this.successful; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public void setRecipient(String paramString) { this.recipientAddress = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public String getRecipient() { return this.recipientAddress; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   public void setAuthor(String paramString) { this.authorAddress = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public String getAuthor() { return this.authorAddress; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   public void setSubject(String paramString) { this.subject = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public String getSubject() { return this.subject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 213 */   public void setBody(String paramString) { this.messageBody = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   public String getBody() { return this.messageBody; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   public void setMailServer(String paramString) { this.mailServer = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   public String getMailServer() { return this.mailServer; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\EmailPackage.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */