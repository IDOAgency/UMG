package com.techempower.gemini;

import com.techempower.BasicHelper;

public class FormCheckBox extends FormElement {
  public static final String DEFAULT_VALUE = "y";
  
  public static final String DEFAULT_TEXT = "";
  
  protected String value;
  
  protected String text;
  
  protected boolean startingChecked = false;
  
  protected boolean checked = false;
  
  public FormCheckBox(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2) {
    super(paramString1, paramString2, paramBoolean1);
    setText(paramString3);
    setStartingChecked(paramBoolean2);
    setChecked(paramBoolean2);
  }
  
  public FormCheckBox(String paramString1, String paramString2, String paramString3, boolean paramBoolean) { this(paramString1, paramString2, paramString3, paramBoolean, false); }
  
  public FormCheckBox(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) { this(paramString1, "y", paramString2, paramBoolean1, paramBoolean2); }
  
  public FormCheckBox(String paramString1, String paramString2, boolean paramBoolean) { this(paramString1, "y", paramString2, paramBoolean, false); }
  
  public FormCheckBox(String paramString, boolean paramBoolean) { this(paramString, "y", "", paramBoolean); }
  
  public FormCheckBox(String paramString) { this(paramString, "y", "", false); }
  
  public void setChecked(boolean paramBoolean) { this.checked = paramBoolean; }
  
  public boolean isChecked() { return this.checked; }
  
  public void setValue(String paramString) {
    if (!isReadOnly()) {
      if (this.value == null)
        this.value = paramString; 
      setChecked(!(paramString == null || paramString.length() <= 0));
    } 
  }
  
  public void setStartingValue(String paramString) {}
  
  public String getStartingValue() { return null; }
  
  public void setStartingChecked(boolean paramBoolean) { this.startingChecked = paramBoolean; }
  
  public boolean getStartingChecked() { return this.startingChecked; }
  
  public void revert() { setChecked(getStartingChecked()); }
  
  public void setValue(Context paramContext) { setValue(paramContext.getRequestValue(getName(), "")); }
  
  public String getText() {
    if (this.text == null)
      return ""; 
    return this.text;
  }
  
  public void setText(String paramString) { this.text = paramString; }
  
  protected String getValue() { return this.value; }
  
  public String getStringValue() { return getValue(); }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public int getIntegerValue() {
    try {
      return Integer.parseInt(getValue());
    } catch (NumberFormatException numberFormatException) {
      return 0;
    } 
  }
  
  public String render() {
    StringBuffer stringBuffer = new StringBuffer(60);
    stringBuffer.append("<input type=\"checkbox\" name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" value=\"");
    stringBuffer.append(getValue());
    stringBuffer.append('"');
    if (isChecked())
      stringBuffer.append(" checked"); 
    stringBuffer.append(getTabIndex());
    stringBuffer.append(getFormEvents());
    stringBuffer.append(getEnabledString());
    stringBuffer.append(getId());
    stringBuffer.append('>');
    stringBuffer.append(getText());
    return stringBuffer.toString();
  }
  
  public FormSingleValidation validate() {
    FormSingleValidation formSingleValidation = new FormSingleValidation(this);
    if (isRequired())
      requiredValidation(formSingleValidation); 
    customValidation(formSingleValidation);
    return formSingleValidation;
  }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {
    if (getStringValue().length() == 0)
      paramFormSingleValidation.setError(String.valueOf(getDisplayName()) + " is unchecked.", 
          "Please check the checkbox named " + getDisplayName() + ".", 
          "This checkbox field must be checked."); 
  }
  
  public boolean isDefault() { return "y".equals(getValue()); }
  
  public boolean isUnchanged() { return !(getStartingChecked() != isChecked()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormCheckBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */