package com.techempower.gemini;

import com.techempower.BasicHelper;

public class FormSubmitButton extends FormSubmissionElement {
  public static final String DEFAULT_VALUE = "Submit";
  
  protected String value;
  
  protected String startingValue;
  
  protected boolean submitted = false;
  
  public FormSubmitButton(String paramString1, String paramString2, boolean paramBoolean) {
    super(paramString1, paramString2, paramBoolean);
    setReadOnly(true);
  }
  
  public FormSubmitButton(String paramString1, String paramString2) { this(paramString1, paramString2, false); }
  
  public void setValue(String paramString) {
    if (!isReadOnly())
      this.value = paramString; 
  }
  
  public void setValue(Context paramContext) {
    String str = paramContext.getRequestValue(getName(), "");
    this.submitted = !(str.length() <= 0);
  }
  
  public void setStartingValue(String paramString) { this.startingValue = paramString; }
  
  public String getStartingValue() { return this.startingValue; }
  
  protected String getValue() { return this.value; }
  
  public String getStringValue() { return getValue(); }
  
  public String getRenderableValue() { return BasicHelper.escapeDoubleQuotesForHtml(getValue()); }
  
  public String getEscapedValue() { return BasicHelper.escapeSingleQuotes(getValue()); }
  
  public int getIntegerValue() { return 0; }
  
  public String render() {
    StringBuffer stringBuffer = new StringBuffer(60);
    stringBuffer.append("<input type=\"submit\" name=\"");
    stringBuffer.append(getName());
    stringBuffer.append("\" value=\"");
    stringBuffer.append(getRenderableValue());
    stringBuffer.append('"');
    stringBuffer.append(getTabIndex());
    stringBuffer.append(getFormEvents());
    stringBuffer.append(getEnabledString());
    stringBuffer.append(getReadOnlyString());
    stringBuffer.append(getId());
    stringBuffer.append('>');
    return stringBuffer.toString();
  }
  
  public FormSingleValidation validate() { return null; }
  
  protected void requiredValidation(FormSingleValidation paramFormSingleValidation) {}
  
  public boolean isDefault() { return "Submit".equals(getValue()); }
  
  public boolean isUnchanged() { return this.startingValue.equals(getValue()); }
  
  public boolean isSubmitted() { return this.submitted; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\FormSubmitButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */