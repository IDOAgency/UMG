package com.techempower.gemini;

import com.techempower.ComponentLog;
import com.techempower.EnhancedProperties;

public class EmailServicer {
  public static final String COMPONENT_CODE = "emsv";
  
  public static final int DEFAULT_SERVICER_THREADS = 5;
  
  protected GeminiApplication application;
  
  protected ComponentLog log;
  
  protected int threadCount;
  
  protected EmailServicerThread[] threads;
  
  protected boolean initialConf;
  
  public EmailServicer(GeminiApplication paramGeminiApplication) {
    this.threadCount = 5;
    this.initialConf = false;
    this.application = paramGeminiApplication;
    this.log = paramGeminiApplication.getLog("emsv");
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties) {
    this.threadCount = paramEnhancedProperties.getIntegerProperty("EmailerThreads", this.threadCount);
    if (!this.initialConf || this.threads.length != this.threadCount) {
      this.initialConf = true;
      EmailServicerThread[] arrayOfEmailServicerThread = new EmailServicerThread[this.threadCount];
      for (byte b = 0; b < arrayOfEmailServicerThread.length; b++) {
        if (this.threads != null && 
          b < this.threads.length && 
          this.threads[b] != null) {
          arrayOfEmailServicerThread[b] = this.threads[b];
        } else {
          arrayOfEmailServicerThread[b] = new EmailServicerThread(b, this.application);
          arrayOfEmailServicerThread[b].start();
        } 
      } 
      if (this.threads != null)
        for (int i = arrayOfEmailServicerThread.length; i < this.threads.length; i++)
          this.threads[i].setKeepRunning(false);  
      this.threads = arrayOfEmailServicerThread;
      this.log.log(String.valueOf(this.threadCount) + " threads created for outgoing e-mail delivery.");
    } 
  }
  
  public int getThreads() { return this.threadCount; }
  
  public int getBusyThreads() {
    byte b1 = 0;
    for (byte b2 = 0; b2 < this.threads.length; b2++) {
      if (this.threads[b2].getBacklog() > 0)
        b1++; 
    } 
    return b1;
  }
  
  public int getBacklog() {
    int i = 0;
    for (byte b = 0; b < this.threads.length; b++)
      i += this.threads[b].getBacklog(); 
    return i;
  }
  
  public void sendMail(EmailPackage paramEmailPackage) {
    try {
      byte b1 = 0;
      int i = this.threads[b1].getBacklog();
      for (byte b2 = 1; b2 < this.threads.length; b2++) {
        if (this.threads[b2].getBacklog() < i) {
          b1 = b2;
          i = this.threads[b1].getBacklog();
        } 
      } 
      if (this.threads[b1].queueMail(paramEmailPackage) == false)
        this.log.debug("Could not queue mail."); 
    } catch (Exception exception) {
      this.log.debug("Exception while queuing mail: " + exception);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\EmailServicer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */