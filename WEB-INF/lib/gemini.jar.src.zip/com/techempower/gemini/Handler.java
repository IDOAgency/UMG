package com.techempower.gemini;

public interface Handler extends GeminiConstants {
  boolean acceptRequest(Dispatcher paramDispatcher, Context paramContext, String paramString);
  
  String getDescription();
  
  boolean handleRequest(Dispatcher paramDispatcher, Context paramContext, String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\gemini\Handler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */