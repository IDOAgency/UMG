/*     */ package com.techempower;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlTable
/*     */   implements SqlReservedWords
/*     */ {
/*     */   protected String tableName;
/*     */   protected String username;
/*     */   protected Vector columnSelections;
/*     */   protected Vector orderByColumns;
/*     */   protected String fullName;
/*     */   
/*  41 */   public SqlTable(String paramString) { this(paramString, null, null); }
/*     */ 
/*     */ 
/*     */   
/*  45 */   public SqlTable(String paramString1, String paramString2) { this(paramString1, paramString2, null); }
/*     */ 
/*     */   
/*     */   public SqlTable(String paramString1, String paramString2, Vector paramVector) {
/*  49 */     this.tableName = paramString1;
/*  50 */     this.username = paramString2;
/*  51 */     this.columnSelections = paramVector;
/*     */ 
/*     */     
/*  54 */     this.fullName = "";
/*  55 */     if (paramString2 != null && paramString2.length() > 0)
/*     */     {
/*  57 */       this.fullName = String.valueOf(this.fullName) + paramString2 + ".";
/*     */     }
/*     */     
/*  60 */     if (paramString1 == null) {
/*  61 */       paramString1 = "";
/*     */     }
/*  63 */     this.fullName = String.valueOf(this.fullName) + paramString1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public String getFullName() { return this.fullName; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public String getTableName() { return this.tableName; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public String getUsername() { return this.username; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnSelection(String paramString) {
/*  87 */     if (this.columnSelections == null) {
/*  88 */       this.columnSelections = new Vector(1);
/*     */     }
/*  90 */     if (!this.columnSelections.contains(paramString))
/*     */     {
/*  92 */       this.columnSelections.addElement(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addColumnSelections(Vector paramVector) {
/*  98 */     for (byte b = 0; paramVector != null && b < paramVector.size(); b++)
/*     */     {
/* 100 */       addColumnSelection((String)paramVector.elementAt(b));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 106 */   public Vector getColumnSelections() { return this.columnSelections; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOrderByColumn(String paramString) {
/* 111 */     if (this.orderByColumns == null) {
/* 112 */       this.orderByColumns = new Vector(1);
/*     */     }
/* 114 */     this.orderByColumns.addElement(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSelectionClause() {
/* 122 */     String str = "";
/*     */     
/* 124 */     for (byte b = 0; this.columnSelections != null && b < this.columnSelections.size(); b++) {
/*     */       
/* 126 */       String str1 = (String)this.columnSelections.elementAt(b);
/*     */       
/* 128 */       if (str.length() > 0)
/*     */       {
/* 130 */         str = String.valueOf(str) + ", ";
/*     */       }
/*     */       
/* 133 */       str = String.valueOf(str) + getFullName() + "." + str1;
/*     */     } 
/*     */     
/* 136 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOrderByClause() {
/* 144 */     String str = "";
/*     */     
/* 146 */     for (byte b = 0; this.orderByColumns != null && b < this.orderByColumns.size(); b++) {
/*     */       
/* 148 */       String str1 = (String)this.orderByColumns.elementAt(b);
/*     */       
/* 150 */       if (str.length() > 0)
/*     */       {
/* 152 */         str = String.valueOf(str) + ", ";
/*     */       }
/*     */       
/* 155 */       str = String.valueOf(str) + getFullName() + "." + str1;
/*     */     } 
/*     */     
/* 158 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 166 */     if (paramObject instanceof SqlTable) {
/*     */       
/* 168 */       SqlTable sqlTable = (SqlTable)paramObject;
/*     */       
/* 170 */       return stringsMatchIgnoreCase(getFullName(), sqlTable.getFullName());
/*     */     } 
/*     */     
/* 173 */     return super.equals(paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean stringsMatchIgnoreCase(String paramString1, String paramString2) {
/* 186 */     if (paramString1 == null && paramString2 == null)
/* 187 */       return true; 
/* 188 */     if (paramString1 == null || paramString2 == null) {
/* 189 */       return false;
/*     */     }
/*     */     
/* 192 */     return paramString1.equalsIgnoreCase(paramString2);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\SqlTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */