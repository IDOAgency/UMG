/*    */ package com.techempower;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventRunnerThread
/*    */   extends Thread
/*    */ {
/*    */   protected ScheduledEvent event;
/*    */   protected Scheduler scheduler;
/*    */   
/*    */   public EventRunnerThread(ScheduledEvent paramScheduledEvent, Scheduler paramScheduler) {
/* 47 */     super("Event Runner Thread");
/*    */     
/* 49 */     setPriority(1);
/*    */     
/* 51 */     this.event = paramScheduledEvent;
/* 52 */     this.scheduler = paramScheduler;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 60 */     this.event.execute(this.scheduler);
/* 61 */     this.event.setExecuting(false);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\EventRunnerThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */