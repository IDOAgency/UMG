package com.techempower;

public class EventRunnerThread extends Thread {
  protected ScheduledEvent event;
  
  protected Scheduler scheduler;
  
  public EventRunnerThread(ScheduledEvent paramScheduledEvent, Scheduler paramScheduler) {
    super("Event Runner Thread");
    setPriority(1);
    this.event = paramScheduledEvent;
    this.scheduler = paramScheduler;
  }
  
  public void run() {
    this.event.execute(this.scheduler);
    this.event.setExecuting(false);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\EventRunnerThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */