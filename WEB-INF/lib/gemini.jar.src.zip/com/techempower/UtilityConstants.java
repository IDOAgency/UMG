package com.techempower;

public interface UtilityConstants {
  public static final String[] DAYS_OF_WEEK = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", 
      "Saturday" };
  
  public static final String[] DAYS_ABBREVIATED = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
  
  public static final String[] MONTH_NAMES = { 
      "January", "February", "March", "April", "May", "June", "July", 
      "August", "September", "October", 
      "November", "December" };
  
  public static final String[] MONTH_NAMES_ABBREVIATED = { 
      "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", 
      "Nov", "Dec" };
  
  public static final int[] MONTH_DAYS = { 
      31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 
      30, 31 };
  
  public static final String[] PERMITTED_DATE_FORMATS = { 
      "MM-dd-yyyy hh:mm:ss.SSS", 
      "MM-dd-yyyy hh:mm:ss.SSS a", 
      "MM-dd-yyyy hh:mm:ss.SSSa", 
      "MM-dd-yyyy hh:mm:ss a", 
      "MM-dd-yyyy hh:mm:ssa", 
      "MM-dd-yyyy hh:mm a", 
      "MM-dd-yyyy hh:mma", 
      "MM-dd-yyyy", 
      
      "MM/dd/yyyy hh:mm:ss.SSS", 
      "MM/dd/yyyy hh:mm:ss.SSS a", 
      "MM/dd/yyyy hh:mm:ss.SSSa", 
      "MM/dd/yyyy hh:mm:ss a", 
      "MM/dd/yyyy hh:mm:ssa", 
      "MM/dd/yyyy hh:mm a", 
      "MM/dd/yyyy hh:mma", 
      "MM/dd/yyyy", 
      
      "MMM d yyyy hh:mm:ss.SSS", 
      "MMM d yyyy hh:mm:ss.SSS a", 
      "MMM d yyyy hh:mm:ss.SSSa", 
      "MMM d yyyy hh:mm:ss a", 
      "MMM d yyyy hh:mm:ssa", 
      "MMM d yyyy hh:mm a", 
      "MMM d yyyy hh:mma", 
      "MMM d yyyy", 
      
      "MMM. d yyyy hh:mm:ss.SSS", 
      "MMM. d yyyy hh:mm:ss.SSS a", 
      "MMM. d yyyy hh:mm:ss.SSSa", 
      "MMM. d yyyy hh:mm:ss a", 
      "MMM. d yyyy hh:mm:ssa", 
      "MMM. d yyyy hh:mm a", 
      "MMM. d yyyy hh:mma", 
      "MMM. d yyyy", 
      
      "MMM. d, yyyy hh:mm:ss.SSS", 
      "MMM. d, yyyy hh:mm:ss.SSS a", 
      "MMM. d, yyyy hh:mm:ss.SSSa", 
      "MMM. d, yyyy hh:mm:ss a", 
      "MMM. d, yyyy hh:mm:ssa", 
      "MMM. d, yyyy hh:mm a", 
      "MMM. d, yyyy hh:mma", 
      "MMM. d, yyyy", 
      "MMM d, yyyy hh:mm:ss.SSS", 
      "MMM d, yyyy hh:mm:ss.SSS a", 
      "MMM d, yyyy hh:mm:ss.SSSa", 
      "MMM d, yyyy hh:mm:ss a", 
      "MMM d, yyyy hh:mm:ssa", 
      "MMM d, yyyy hh:mm a", 
      "MMM d, yyyy hh:mma", 
      "MMM d, yyyy" };
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\UtilityConstants.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */