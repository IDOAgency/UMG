package com.techempower;

import java.lang.reflect.Field;

class DataFieldToVariableMap extends DataFieldToObjectEntityMap {
  public Field variable;
  
  public DataFieldToVariableMap(Field paramField, String paramString, int paramInt) {
    this.variable = paramField;
    this.fieldName = paramString;
    this.fieldType = paramInt;
  }
  
  public DataFieldToVariableMap() {}
  
  public String toString() { return "DFTVM [" + this.fieldName + "; " + this.fieldType + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\DataFieldToVariableMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */