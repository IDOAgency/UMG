package com.techempower;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class JdbcConnector implements DatabaseConnector {
  public static final String COMPONENT_CODE = "jdbc";
  
  public static final boolean DEBUG_ALSO_CONSOLE = true;
  
  public static final int DEBUG_HIGH = 3;
  
  public static final int DEBUG_MEDIUM = 2;
  
  public static final int DEBUG_LOW = 1;
  
  public static final long EXCESSIVE_FILE_SIZE = 2000000L;
  
  public static final String DEFAULT_DEBUG_FILE = "c:\\temp\\JdbcConnector-debug.txt";
  
  public static final String NULL_VALUE_REPLACE = "[none]";
  
  protected static final String DEFAULT_DRIVER_NAME = "sun.jdbc.odbc.JdbcOdbcDriver";
  
  protected static final String DEFAULT_JDBC_PREFIX = "jdbc:odbc:";
  
  protected static int debugLevel = 3;
  
  protected static Vector loadedDrivers = new Vector();
  
  protected static String defJdbcURLPrefix = "jdbc:odbc:";
  
  protected static Object lockObject = new Object();
  
  protected static boolean initialized = false;
  
  protected static long queryNumber = 0L;
  
  protected static String debugFilename = "c:\\temp\\JdbcConnector-debug.txt";
  
  protected static Hashtable dbConnections = new Hashtable();
  
  protected static DateFormat dateFormat = DateFormat.getDateTimeInstance(2, 2);
  
  private String username;
  
  private String password;
  
  protected int updateRowCount;
  
  protected String jdbcURLPrefix;
  
  protected JdbcDriver driverInUse;
  
  protected boolean forceNewConnection;
  
  protected Connection forcedConnection;
  
  protected Statement statement;
  
  protected ResultSet resultSet;
  
  protected boolean nextThrewException;
  
  protected boolean readOnly;
  
  protected boolean forwardOnly;
  
  protected String query;
  
  protected String connectString;
  
  protected int rowCount;
  
  protected int rowNumber;
  
  public JdbcConnector(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2) {
    this.username = null;
    this.password = null;
    this.updateRowCount = -1;
    this.jdbcURLPrefix = defJdbcURLPrefix;
    this.driverInUse = null;
    this.forceNewConnection = false;
    this.forcedConnection = null;
    this.statement = null;
    this.resultSet = null;
    this.nextThrewException = true;
    this.readOnly = true;
    this.forwardOnly = false;
    this.query = null;
    this.connectString = null;
    this.rowCount = -1;
    this.rowNumber = 0;
    debugFile("Constructor starting.");
    debugFile("Database connect string: " + paramString2);
    debugFile("JDBC prefix: " + paramString1);
    debugFile("Query: " + paramString3);
    setReadOnly(paramBoolean1);
    setForwardOnly(paramBoolean2);
    setJdbcURLPrefix(paramString1);
    this.connectString = paramString2;
    this.query = paramString3;
    if (!initialized)
      synchronized (lockObject) {
        loadDriver("sun.jdbc.odbc.JdbcOdbcDriver", "jdbc:odbc:", false, false);
      }  
    debugFile("Constructor finished.");
  }
  
  public JdbcConnector(String paramString1, String paramString2, String paramString3) { this(paramString1, paramString2, paramString3, true, false); }
  
  public JdbcConnector(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) { this(defJdbcURLPrefix, paramString1, paramString2, paramBoolean1, paramBoolean2); }
  
  public JdbcConnector(String paramString1, String paramString2) { this(defJdbcURLPrefix, paramString1, paramString2, true, false); }
  
  public JdbcConnector(String paramString) { this(defJdbcURLPrefix, paramString, "", true, false); }
  
  public void finalize() { close(); }
  
  public void setUsername(String paramString) { this.username = paramString; }
  
  public void setPassword(String paramString) { this.password = paramString; }
  
  public void setQuery(String paramString) {
    debugFile("setQuery: " + paramString);
    close();
    this.query = paramString;
    this.nextThrewException = true;
    if (!this.driverInUse.supportsGetRow)
      this.rowNumber = 0; 
  }
  
  public String getQuery() { return this.query; }
  
  public void setReadOnly(boolean paramBoolean) { this.readOnly = paramBoolean; }
  
  public boolean getReadOnly() { return this.readOnly; }
  
  public void setForceNewConnection(boolean paramBoolean) { this.forceNewConnection = paramBoolean; }
  
  public boolean getForceNewConnection() { return this.forceNewConnection; }
  
  public void setForwardOnly(boolean paramBoolean) { this.forwardOnly = paramBoolean; }
  
  public boolean getForwardOnly() { return this.forwardOnly; }
  
  public void first() {
    if (this.forwardOnly) {
      debugFile("call to first on a forward-only query.");
      return;
    } 
    try {
      this.nextThrewException = this.resultSet.first() ^ true;
      if (!this.driverInUse.supportsGetRow)
        this.rowNumber = 1; 
    } catch (Exception exception) {
      debugFile("Exception on first(): " + exception, 2);
      this.nextThrewException = true;
    } 
  }
  
  public void next() {
    try {
      this.nextThrewException = this.resultSet.next() ^ true;
      if (!this.driverInUse.supportsGetRow)
        this.rowNumber++; 
    } catch (Exception exception) {
      this.nextThrewException = true;
    } 
  }
  
  public boolean more() { return this.nextThrewException ^ true; }
  
  public void moveAbsolute(int paramInt) {
    if (this.forwardOnly) {
      debugFile("call to moveAbsolute on a forward-only query.");
      return;
    } 
    try {
      if (this.driverInUse.supportsAbsolute) {
        this.resultSet.absolute(paramInt + 1);
        if (!this.driverInUse.supportsGetRow)
          this.rowNumber = paramInt + 1; 
      } else {
        first();
        while (getRowNumber() < paramInt + 1 && more())
          next(); 
      } 
    } catch (Exception exception) {
      debugFile("Exception while moving to absolute position " + paramInt + ": " + exception, 2);
    } 
  }
  
  public int getRowNumber() {
    try {
      if (this.driverInUse.supportsGetRow)
        return this.resultSet.getRow(); 
      return this.rowNumber;
    } catch (Exception exception) {
      debugFile("Exception while getting row number: " + exception, 2);
      return 0;
    } 
  }
  
  public String[] getFieldNames() {
    try {
      ResultSetMetaData resultSetMetaData = this.resultSet.getMetaData();
      int i = resultSetMetaData.getColumnCount();
      String[] arrayOfString = new String[i];
      for (byte b = 1; b < i + 1; b++)
        arrayOfString[b - true] = resultSetMetaData.getColumnName(b); 
      return arrayOfString;
    } catch (Exception exception) {
      debugFile("Exception while gathering field names: " + exception, 2);
      return new String[0];
    } 
  }
  
  public int[] getFieldTypes() {
    try {
      ResultSetMetaData resultSetMetaData = this.resultSet.getMetaData();
      int i = resultSetMetaData.getColumnCount();
      int[] arrayOfInt = new int[i];
      for (byte b = 1; b < i + 1; b++)
        arrayOfInt[b - true] = resultSetMetaData.getColumnType(b); 
      return arrayOfInt;
    } catch (Exception exception) {
      debugFile("Exception while gathering field names: " + exception, 2);
      return new int[0];
    } 
  }
  
  public String getFieldByName(String paramString) {
    try {
      return this.resultSet.getString(paramString);
    } catch (Exception exception) {
      debugFile("Exception while retrieving field " + paramString + ": " + exception, 2);
      return null;
    } 
  }
  
  public String getField(String paramString) {
    String str = getFieldByName(paramString);
    if (str != null)
      return str; 
    return "[none]";
  }
  
  public String getField(String paramString1, String paramString2) {
    String str = getFieldByName(paramString1);
    if (str != null)
      return str; 
    return paramString2;
  }
  
  public int getIntegerFieldByName(String paramString) {
    try {
      return this.resultSet.getInt(paramString);
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public int getIntegerField(String paramString) { return getIntegerFieldByName(paramString); }
  
  public int getInt(String paramString) { return getIntegerFieldByName(paramString); }
  
  public int getInt(String paramString, int paramInt) {
    try {
      return this.resultSet.getInt(paramString);
    } catch (Exception exception) {
      return paramInt;
    } 
  }
  
  public Date getDate(String paramString) {
    try {
      return this.resultSet.getDate(paramString);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public boolean getBoolean(String paramString) {
    try {
      return this.resultSet.getBoolean(paramString);
    } catch (Exception exception) {
      return false;
    } 
  }
  
  public float getFloat(String paramString) {
    try {
      return this.resultSet.getFloat(paramString);
    } catch (Exception exception) {
      return 0.0F;
    } 
  }
  
  public double getDouble(String paramString) {
    try {
      return this.resultSet.getDouble(paramString);
    } catch (Exception exception) {
      return 0.0D;
    } 
  }
  
  public byte getByte(String paramString) {
    try {
      return this.resultSet.getByte(paramString);
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public short getShort(String paramString) {
    try {
      return this.resultSet.getShort(paramString);
    } catch (Exception exception) {
      return 0;
    } 
  }
  
  public long getLong(String paramString) {
    try {
      return this.resultSet.getLong(paramString);
    } catch (Exception exception) {
      return 0L;
    } 
  }
  
  public int getRowCount() {
    if (this.resultSet != null) {
      if (this.rowCount > -1)
        return this.rowCount; 
      this.rowCount = 0;
      first();
      while (more()) {
        this.rowCount++;
        next();
      } 
      first();
      return this.rowCount;
    } 
    return 0;
  }
  
  public void close() {
    if (this.resultSet != null) {
      try {
        this.resultSet.close();
      } catch (Exception exception) {
        debugFile("Exception while closing result set: " + exception, 2);
      } 
      this.resultSet = null;
    } 
    if (this.statement != null) {
      try {
        this.statement.close();
      } catch (Exception exception) {
        debugFile("Exception while closing statement: " + exception, 2);
      } 
      this.statement = null;
    } 
    if (this.forcedConnection != null) {
      try {
        this.forcedConnection.close();
      } catch (Exception exception) {
        debugFile("Exception while closing forced connection: " + exception, 2);
      } 
      this.forcedConnection = null;
    } 
  }
  
  public void runQuery() { runQuery(false); }
  
  public int runUpdateQuery() {
    close();
    queryNumber++;
    this.rowCount = -1;
    JdbcConnectionProfile jdbcConnectionProfile = getDbConnection(this.connectString, this.username, this.password);
    if (jdbcConnectionProfile != null) {
      if (this.forceNewConnection)
        this.forcedConnection = jdbcConnectionProfile.connection; 
      jdbcConnectionProfile.incrementLoad();
      debugFile("Creating the statement.");
      try {
        this.statement = jdbcConnectionProfile.connection.createStatement();
        debugFile("Statement created.");
        this.updateRowCount = doUpdate(this.statement);
        jdbcConnectionProfile.close();
      } catch (SQLException sQLException) {
        debugFile("SQL Exception while creating statement or running query: " + sQLException, 2);
        return -1;
      } 
      jdbcConnectionProfile.decrementLoad();
    } else {
      debugFile("No valid connection available, aborting query.", 3);
    } 
    debugFile("Returning from runQuery.");
    return this.updateRowCount;
  }
  
  protected int doUpdate(Statement paramStatement) {
    try {
      paramStatement.execute(this.query);
      return paramStatement.getUpdateCount();
    } catch (SQLException sQLException) {
      debugFile("SQLException in doUpdate: " + sQLException);
      return -1;
    } 
  }
  
  public void runQuerySafe() { runQuery(true); }
  
  public void runQuery(boolean paramBoolean) {
    close();
    queryNumber++;
    this.rowCount = -1;
    JdbcConnectionProfile jdbcConnectionProfile = getDbConnection(this.connectString, this.username, this.password);
    if (jdbcConnectionProfile != null) {
      if (this.forceNewConnection)
        this.forcedConnection = jdbcConnectionProfile.connection; 
      jdbcConnectionProfile.incrementLoad();
      if (paramBoolean) {
        try {
          generateStatement(jdbcConnectionProfile);
        } catch (SQLException sQLException) {
          debugFile("SQL Exception while creating statement: " + sQLException, 3);
          jdbcConnectionProfile.close();
          throw new JdbcConnectorError("Creation of statement failed.", sQLException);
        } 
        try {
          generateResults(this.statement);
        } catch (SQLException sQLException) {
          jdbcConnectionProfile.decrementLoad();
          debugFile("SQL Exception while running query: " + sQLException, 3);
          throw new JdbcConnectorError("runQuery failed.", sQLException);
        } 
      } else {
        boolean bool = false;
        try {
          generateStatement(jdbcConnectionProfile);
        } catch (SQLException sQLException) {
          jdbcConnectionProfile.close();
          debugFile("SQL Exception while creating statement: " + sQLException, 3);
          bool = true;
        } 
        if (!bool)
          try {
            generateResults(this.statement);
          } catch (SQLException sQLException) {
            jdbcConnectionProfile.decrementLoad();
            if (sQLException.toString().indexOf("onnection reset by peer") >= 0) {
              jdbcConnectionProfile.close();
              debugFile("SQL Exception while running query: " + sQLException, 3);
            } else {
              debugFile("SQL Exception while running query: " + sQLException, 2);
            } 
          }  
      } 
    } else {
      debugFile("No valid connection available, aborting query.", 3);
    } 
    debugFile("Returning from runQuery.");
  }
  
  public void setJdbcURLPrefix(String paramString) {
    this.jdbcURLPrefix = paramString;
    this.driverInUse = null;
    for (byte b = 0; b < loadedDrivers.size(); b++) {
      JdbcDriver jdbcDriver = (JdbcDriver)loadedDrivers.elementAt(b);
      String str = jdbcDriver.urlPrefix;
      if (str.equals(this.jdbcURLPrefix)) {
        this.driverInUse = jdbcDriver;
        break;
      } 
    } 
    if (this.driverInUse == null)
      debugFile("No suitable driver found for prefix: " + this.jdbcURLPrefix + "!"); 
  }
  
  public String getJdbcURLPrefix() { return this.jdbcURLPrefix; }
  
  protected void generateStatement(JdbcConnectionProfile paramJdbcConnectionProfile) throws SQLException {
    try {
      debugFile("Creating the statement.");
      if (this.driverInUse.jdbc1) {
        this.statement = paramJdbcConnectionProfile.connection.createStatement();
        debugFile("Statement created.");
      } else {
        char c1 = 'Ϭ';
        char c2 = 'ϯ';
        if (this.forwardOnly)
          c1 = 'ϫ'; 
        if (!this.readOnly)
          c2 = 'ϰ'; 
        this.statement = paramJdbcConnectionProfile.connection.createStatement(c1, 
            c2);
      } 
    } catch (SQLException sQLException) {
      this.nextThrewException = true;
      this.resultSet = null;
      throw sQLException;
    } 
  }
  
  protected void generateResults(Statement paramStatement) throws SQLException {
    try {
      this.resultSet = paramStatement.executeQuery(this.query);
      debugFile("Results generated.");
      next();
    } catch (SQLException sQLException) {
      this.nextThrewException = true;
      this.resultSet = null;
      throw sQLException;
    } 
  }
  
  protected JdbcConnectionProfile getDbConnection(String paramString1, String paramString2, String paramString3) {
    JdbcConnectionProfile jdbcConnectionProfile = null;
    if (this.forceNewConnection) {
      jdbcConnectionProfile = new JdbcConnectionProfile(this);
      jdbcConnectionProfile.establishDbConnection(paramString1, paramString2, paramString3);
    } else {
      String str = String.valueOf(paramString2) + "/" + paramString3 + "/" + paramString1;
      JdbcConnectionManager jdbcConnectionManager = (JdbcConnectionManager)dbConnections.get(str);
      synchronized (lockObject) {
        if (jdbcConnectionManager == null) {
          jdbcConnectionManager = new JdbcConnectionManager(this);
          dbConnections.put(str, jdbcConnectionManager);
        } 
        if (jdbcConnectionManager.size() < this.driverInUse.pooling) {
          JdbcConnectionProfile jdbcConnectionProfile1 = new JdbcConnectionProfile(this);
          jdbcConnectionProfile1.establishDbConnection(paramString1, paramString2, paramString3);
          if (jdbcConnectionProfile1.getConnection() != null) {
            jdbcConnectionProfile = jdbcConnectionProfile1;
            jdbcConnectionManager.add(jdbcConnectionProfile1);
          } 
        } else {
          jdbcConnectionProfile = jdbcConnectionManager.getLowestLoad();
          if (jdbcConnectionProfile != null && jdbcConnectionProfile.isClosed()) {
            jdbcConnectionProfile.establishDbConnection(paramString1, paramString2, paramString3);
            if (jdbcConnectionProfile.getConnection() == null)
              jdbcConnectionProfile = null; 
          } 
        } 
      } 
    } 
    return jdbcConnectionProfile;
  }
  
  protected Connection establishDbConnection(String paramString1, String paramString2, String paramString3) {
    try {
      String str = String.valueOf(this.jdbcURLPrefix) + paramString1;
      debugFile("establishDbConnection(" + str + ", " + paramString2 + ", " + paramString3 + ")");
      return DriverManager.getConnection(str, paramString2, paramString3);
    } catch (SQLException sQLException) {
      debugFile("SQL Exception while connecting: " + sQLException, 3);
      return null;
    } 
  }
  
  public static void loadDriver(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt) {
    for (byte b = 0; b < loadedDrivers.size(); b++) {
      JdbcDriver jdbcDriver = (JdbcDriver)loadedDrivers.elementAt(b);
      if (jdbcDriver.className.equals(paramString1))
        return; 
    } 
    debugFile("Loading JDBC driver: " + paramString1);
    try {
      Class.forName(paramString1);
      JdbcDriver jdbcDriver = new JdbcDriver(paramString1, paramString2, paramBoolean1, 
          paramBoolean2, paramBoolean3, paramInt);
      loadedDrivers.addElement(jdbcDriver);
    } catch (ClassNotFoundException classNotFoundException) {
      debugFile("ClassNotFound: " + classNotFoundException, 3);
    } 
    initialized = true;
  }
  
  public static void loadDriver(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) { loadDriver(paramString1, paramString2, paramBoolean1, paramBoolean2, paramBoolean3, 1); }
  
  public static void loadDriver(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) { loadDriver(paramString1, paramString2, paramBoolean1, paramBoolean2, false, 1); }
  
  public static long getQueryNumber() { return queryNumber; }
  
  public static void setDebugLevel(int paramInt) {
    if (debugLevel >= 1 && debugLevel <= 3)
      debugLevel = paramInt; 
  }
  
  public static void setDebugFilename(String paramString) { debugFilename = paramString; }
  
  public static void setDefaultJdbcURLPrefix(String paramString) { defJdbcURLPrefix = paramString; }
  
  public static String getDefaultJdbcURLPrefix() { return defJdbcURLPrefix; }
  
  public static void debugFile(String paramString) { debugFile(paramString, 1); }
  
  public static void debugFile(String paramString, int paramInt) {
    if (debugLevel <= paramInt)
      if (debugFilename != null)
        try {
          if (queryNumber % 500L == 0L) {
            File file = new File(debugFilename);
            if (file.exists())
              if (file.length() > 2000000L)
                file.delete();  
          } 
          String str1 = "H";
          if (paramInt == 2) {
            str1 = "M";
          } else if (paramInt == 1) {
            str1 = "L";
          } 
          Date date = new Date();
          String str2 = 
            "jdbc: " + str1 + " [" + dateFormat.format(date) + "] " + paramString;
          FileWriter fileWriter = new FileWriter(debugFilename, true);
          fileWriter.write(String.valueOf(str2) + "\r\n");
          fileWriter.flush();
          fileWriter.close();
          System.out.println(str2);
        } catch (IOException iOException) {}  
  }
  
  class JdbcConnectionManager extends Vector {
    private final JdbcConnector this$0;
    
    JdbcConnectionManager(JdbcConnector this$0) {
      this.this$0 = this$0;
    }
    
    public JdbcConnector.JdbcConnectionProfile add(JdbcConnector.JdbcConnectionProfile param1JdbcConnectionProfile) {
      addElement(param1JdbcConnectionProfile);
      param1JdbcConnectionProfile.setManager(this);
      return param1JdbcConnectionProfile;
    }
    
    public JdbcConnector.JdbcConnectionProfile getLowestLoad() {
      Enumeration enumeration = elements();
      JdbcConnector.JdbcConnectionProfile jdbcConnectionProfile = null;
      while (enumeration.hasMoreElements()) {
        JdbcConnector.JdbcConnectionProfile jdbcConnectionProfile1 = (JdbcConnector.JdbcConnectionProfile)enumeration.nextElement();
        if (jdbcConnectionProfile == null || jdbcConnectionProfile1.getLoad() < jdbcConnectionProfile.getLoad())
          jdbcConnectionProfile = jdbcConnectionProfile1; 
      } 
      return jdbcConnectionProfile;
    }
    
    public void dropProfile() {
      if (size() > 0)
        remove(0); 
    }
  }
  
  class JdbcConnectionProfile {
    private final JdbcConnector this$0;
    
    protected Object lockObject;
    
    public int load;
    
    private String connectString;
    
    private String username;
    
    private String password;
    
    protected JdbcConnector.JdbcConnectionManager manager;
    
    public Connection connection;
    
    JdbcConnectionProfile(JdbcConnector this$0) {
      this.this$0 = this$0;
      this.lockObject = new Object();
      this.load = 0;
    }
    
    protected void establishDbConnection(String param1String1, String param1String2, String param1String3) {
      close();
      synchronized (this.lockObject) {
        if (this.connection == null) {
          this.username = param1String2;
          this.password = param1String3;
          this.connectString = param1String1;
          String str = String.valueOf(this.this$0.jdbcURLPrefix) + param1String1;
          try {
            JdbcConnector.debugFile("establishDbConnection(" + str + ", " + param1String2 + 
                ", " + param1String3 + ")");
            this.connection = DriverManager.getConnection(str, param1String2, param1String3);
          } catch (SQLException sQLException) {
            JdbcConnector.debugFile("SQL Exception while connecting: " + sQLException, 3);
            this.connection = null;
          } 
          this.load = 0;
        } 
      } 
    }
    
    public Connection getConnection() {
      if (this.connection == null && this.connectString != null)
        establishDbConnection(this.connectString, this.username, this.password); 
      return this.connection;
    }
    
    public void setManager(JdbcConnector.JdbcConnectionManager param1JdbcConnectionManager) { this.manager = param1JdbcConnectionManager; }
    
    public boolean isClosed() {
      try {
        if (this.connection != null)
          return this.connection.isClosed(); 
      } catch (SQLException sQLException) {
        JdbcConnector.debugFile("SQLException while determining connection's closed status: " + sQLException);
      } 
      return true;
    }
    
    public void close() {
      if (this.connection != null) {
        try {
          this.connection.close();
        } catch (SQLException sQLException) {
          JdbcConnector.debugFile("SQLException while closing connection: " + sQLException);
        } 
        this.connection = null;
      } 
    }
    
    public int incrementLoad() { return ++this.load; }
    
    public int decrementLoad() {
      this.load--;
      if (this.load < 0)
        this.load = 0; 
      return this.load;
    }
    
    public int getLoad() { return this.load; }
  }
  
  static class JdbcDriver {
    public String className;
    
    public String urlPrefix;
    
    public boolean supportsAbsolute;
    
    public boolean supportsGetRow;
    
    public boolean jdbc1;
    
    public int pooling;
    
    public JdbcDriver(String param1String1, String param1String2, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, int param1Int) {
      this.className = param1String1;
      this.urlPrefix = param1String2;
      this.supportsAbsolute = param1Boolean1;
      this.supportsGetRow = param1Boolean2;
      this.jdbc1 = param1Boolean3;
      this.pooling = param1Int;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\JdbcConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */