package com.techempower;

import java.util.Properties;

public class EnhancedProperties extends Properties {
  protected TechEmpowerApplication application;
  
  public EnhancedProperties(TechEmpowerApplication paramTechEmpowerApplication) { setApplication(paramTechEmpowerApplication); }
  
  public EnhancedProperties() {}
  
  public void setApplication(TechEmpowerApplication paramTechEmpowerApplication) { this.application = paramTechEmpowerApplication; }
  
  public TechEmpowerApplication getApplication() { return this.application; }
  
  public long getLongProperty(String paramString) { return getLongProperty(paramString, 0L); }
  
  public long getLongProperty(String paramString, long paramLong) {
    long l = paramLong;
    try {
      l = Long.parseLong(getProperty(paramString));
    } catch (Exception exception) {}
    return l;
  }
  
  public int getIntegerProperty(String paramString) { return getIntegerProperty(paramString, 0); }
  
  public int getIntegerProperty(String paramString, int paramInt) {
    int i = paramInt;
    try {
      i = Integer.parseInt(getProperty(paramString));
    } catch (Exception exception) {}
    return i;
  }
  
  public double getDoubleProperty(String paramString) { return getDoubleProperty(paramString, 0.0D); }
  
  public double getDoubleProperty(String paramString, double paramDouble) {
    double d = paramDouble;
    try {
      d = Double.parseDouble(getProperty(paramString));
    } catch (Exception exception) {}
    return d;
  }
  
  public float getFloatProperty(String paramString) { return getFloatProperty(paramString, 0.0F); }
  
  public float getFloatProperty(String paramString, float paramFloat) {
    float f = paramFloat;
    try {
      f = Float.parseFloat(getProperty(paramString));
    } catch (Exception exception) {}
    return f;
  }
  
  public boolean getYesNoProperty(String paramString) { return getYesNoProperty(paramString, false); }
  
  public boolean getYesNoProperty(String paramString, boolean paramBoolean) {
    boolean bool = paramBoolean;
    String str = getProperty(paramString);
    if (str != null)
      if (str.equalsIgnoreCase("Yes")) {
        bool = true;
      } else if (str.equalsIgnoreCase("No")) {
        bool = false;
      }  
    return bool;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\EnhancedProperties.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */