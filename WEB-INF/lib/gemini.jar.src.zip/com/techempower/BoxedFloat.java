package com.techempower;

public final class BoxedFloat {
  private float floatValue;
  
  public BoxedFloat(float paramFloat) { this.floatValue = paramFloat; }
  
  public float get() { return this.floatValue; }
  
  public void set(float paramFloat) { this.floatValue = paramFloat; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\BoxedFloat.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */