package com.techempower;

import java.io.IOException;

public class ConsoleThreadKiller extends Thread {
  public static final String COMPONENT_CODE = "ctkl";
  
  protected ThreadGroup threadGroup;
  
  protected byte[] buffer = new byte[1024];
  
  protected Thread[] list = null;
  
  protected ComponentLog log;
  
  public ConsoleThreadKiller(TechEmpowerApplication paramTechEmpowerApplication) {
    super("ConsoleThreadKiller");
    setDaemon(true);
    this.log = paramTechEmpowerApplication.getLog("ctkl");
  }
  
  public ConsoleThreadKiller() { this(null); }
  
  public void run() {
    this.threadGroup = getThreadGroup();
    while (this.threadGroup.getParent() != null)
      this.threadGroup = this.threadGroup.getParent(); 
    setPriority(10);
    while (true) {
      try {
        if (System.in.available() > 0) {
          int i = System.in.read(this.buffer);
          String str = new String(this.buffer, 0, i - 2);
          processCommand(str);
        } 
      } catch (IOException iOException) {}
      try {
        Thread.yield();
        Thread.sleep(200L);
      } catch (InterruptedException interruptedException) {}
    } 
  }
  
  public void processCommand(String paramString) {
    if (paramString.startsWith("l")) {
      this.log.debug("Thread list:");
      updateActiveThreads();
      listThreads();
    } else if (paramString.startsWith("k")) {
      try {
        String str = paramString.substring(1);
        int i = Integer.parseInt(str);
        Thread thread = this.list[i];
        if (thread == this) {
          this.log.debug("Cannot kill the thread-killer!");
        } else if (thread != null) {
          this.log.debug("Stopping thread: " + thread);
          thread.stop();
          this.log.debug("Thread stopped.");
          updateActiveThreads();
          listThreads();
        } else {
          this.log.debug("Not a valid thread number.");
        } 
      } catch (Exception exception) {
        this.log.debug("Not a valid thread number or could not stop thread.");
        this.log.debug("Exception: " + exception);
      } 
    } else if (paramString.startsWith("f")) {
      this.log.debug("Thread list flushed.");
      this.list = null;
    } 
  }
  
  public void updateActiveThreads() {
    int i = this.threadGroup.activeCount();
    this.list = new Thread[i];
    this.threadGroup.enumerate(this.list, true);
  }
  
  public void listThreads() {
    for (byte b = 0; b < this.list.length; b++) {
      if (this.list[b] != null)
        this.log.debug("thd. " + b + ": " + this.list[b]); 
    } 
  }
  
  public String toString() { return "ConsoleThreadKiller"; }
  
  public static void main(String[] paramArrayOfString) {
    ConsoleThreadKiller consoleThreadKiller = new ConsoleThreadKiller();
    consoleThreadKiller.start();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\ConsoleThreadKiller.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */