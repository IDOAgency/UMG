package com.techempower;

import java.sql.Date;

public interface DatabaseConnector {
  void close();
  
  void first();
  
  boolean getBoolean(String paramString);
  
  byte getByte(String paramString);
  
  Date getDate(String paramString);
  
  double getDouble(String paramString);
  
  String getField(String paramString);
  
  String getFieldByName(String paramString);
  
  String[] getFieldNames();
  
  int[] getFieldTypes();
  
  float getFloat(String paramString);
  
  boolean getForwardOnly();
  
  int getInt(String paramString);
  
  int getInt(String paramString, int paramInt);
  
  int getIntegerField(String paramString);
  
  int getIntegerFieldByName(String paramString);
  
  long getLong(String paramString);
  
  String getQuery();
  
  boolean getReadOnly();
  
  int getRowCount();
  
  int getRowNumber();
  
  short getShort(String paramString);
  
  boolean more();
  
  void moveAbsolute(int paramInt);
  
  void next();
  
  void runQuery();
  
  int runUpdateQuery();
  
  void setForwardOnly(boolean paramBoolean);
  
  void setPassword(String paramString);
  
  void setQuery(String paramString);
  
  void setReadOnly(boolean paramBoolean);
  
  void setUsername(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\DatabaseConnector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */