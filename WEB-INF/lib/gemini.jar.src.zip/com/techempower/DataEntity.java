package com.techempower;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public abstract class DataEntity {
  public static final int IDENTITY_NOT_RETURNED = -1;
  
  public static final int CANNOT_RUN_QUERY = -2;
  
  public static final String IDENTITY_RESULT_NAME = "Identity";
  
  public static final int ALT_SQL_TYPE_NCHAR = -8;
  
  public static final int ALT_SQL_TYPE_NVARCHAR = -9;
  
  public static final int KNOWN_SQL_TYPE_THRESHOLD = -10;
  
  protected boolean newDataEntity = true;
  
  public void initializeByMethods(DatabaseConnector paramDatabaseConnector) {
    try {
      Vector vector = getMethodMappingCache(paramDatabaseConnector);
      for (byte b = 0; b < vector.size(); b++) {
        DataFieldToMethodMap dataFieldToMethodMap = (DataFieldToMethodMap)vector.elementAt(b);
        invokeMemberSetMethod(dataFieldToMethodMap.method, paramDatabaseConnector, dataFieldToMethodMap.fieldName, 
            dataFieldToMethodMap.fieldType);
      } 
      customInitialization(paramDatabaseConnector);
      setNew(false);
      initializationComplete();
    } catch (Exception exception) {}
  }
  
  public void initializeByVariables(DatabaseConnector paramDatabaseConnector) {
    try {
      Vector vector = getFieldMappingCache(paramDatabaseConnector);
      for (byte b = 0; b < vector.size(); b++) {
        DataFieldToVariableMap dataFieldToVariableMap = (DataFieldToVariableMap)vector.elementAt(b);
        setMemberVariable(dataFieldToVariableMap.variable, paramDatabaseConnector, dataFieldToVariableMap.fieldName, 
            dataFieldToVariableMap.fieldType);
      } 
      customInitialization(paramDatabaseConnector);
      setNew(false);
      initializationComplete();
    } catch (Exception exception) {
      System.out.println("DataEntity.initializeByVariables, exception: " + exception);
    } 
  }
  
  public boolean isNew() { return this.newDataEntity; }
  
  public void setNew(boolean paramBoolean) { this.newDataEntity = paramBoolean; }
  
  public int getIdentity() { return 0; }
  
  public String getTableName() { return null; }
  
  public String getIdentityColumnName() { return null; }
  
  public boolean useMethodsForUpdate() { return false; }
  
  public Hashtable getCustomMethodBindings() { return getCustomSetMethodBindings(); }
  
  public Hashtable getCustomSetMethodBindings() { return null; }
  
  public Hashtable getCustomGetMethodBindings() { return null; }
  
  public Hashtable getCustomVariableBindings() { return null; }
  
  public String getUpdateSpName() { return null; }
  
  public int updateDatabase(DatabaseConnector paramDatabaseConnector) {
    Vector vector;
    String str1 = getUpdateSpName();
    String str2 = getTableName();
    String str3 = getIdentityColumnName();
    int i = getIdentity();
    if (useMethodsForUpdate()) {
      vector = getGetMethodMappingCache();
    } else {
      vector = getFieldMappingCache(null);
    } 
    if (vector != null) {
      StringBuffer stringBuffer = new StringBuffer();
      if (str1 != null) {
        stringBuffer.append(str1);
        stringBuffer.append(' ');
        StringList stringList = new StringList(", ");
        for (byte b = 0; b < vector.size(); b++) {
          DataFieldToObjectEntityMap dataFieldToObjectEntityMap = (DataFieldToObjectEntityMap)vector.elementAt(b);
          try {
            Object object;
            if (useMethodsForUpdate()) {
              object = invokeMemberGetMethod(((DataFieldToMethodMap)dataFieldToObjectEntityMap).method);
            } else {
              object = ((DataFieldToVariableMap)dataFieldToObjectEntityMap).variable.get(this);
            } 
            if (object instanceof String) {
              stringList.add(BasicHelper.prepareString((String)object));
            } else {
              stringList.add(object.toString());
            } 
          } catch (IllegalAccessException illegalAccessException) {}
        } 
        stringBuffer.append(stringList.toString());
      } else if (str2 != null && i == 0) {
        stringBuffer.append("INSERT INTO ");
        stringBuffer.append(str2);
        StringList stringList1 = new StringList(", ");
        StringList stringList2 = new StringList(", ");
        for (byte b = 0; b < vector.size(); b++) {
          DataFieldToObjectEntityMap dataFieldToObjectEntityMap = (DataFieldToObjectEntityMap)vector.elementAt(b);
          if (!dataFieldToObjectEntityMap.fieldName.equals(str3))
            try {
              Object object;
              if (useMethodsForUpdate()) {
                object = invokeMemberGetMethod(((DataFieldToMethodMap)dataFieldToObjectEntityMap).method);
              } else {
                object = ((DataFieldToVariableMap)dataFieldToObjectEntityMap).variable.get(this);
              } 
              if (object != null) {
                stringList1.add(dataFieldToObjectEntityMap.fieldName);
                if (object instanceof String) {
                  stringList2.add(BasicHelper.prepareString((String)object));
                } else if (object instanceof java.sql.Date) {
                  stringList2.add("'" + object.toString() + "'");
                } else if (object instanceof Date) {
                  Date date = (Date)object;
                  Timestamp timestamp = new Timestamp(date.getTime());
                  stringList2.add("'" + timestamp.toString() + "'");
                } else {
                  stringList2.add(object.toString());
                } 
              } 
            } catch (IllegalAccessException illegalAccessException) {} 
        } 
        stringBuffer.append(" (");
        stringBuffer.append(stringList1);
        stringBuffer.append(") VALUES (");
        stringBuffer.append(stringList2);
        stringBuffer.append(");");
      } else if (str3 != null && str2 != null && i > 0) {
        stringBuffer.append("UPDATE ");
        stringBuffer.append(str2);
        StringList stringList = new StringList(", ");
        for (byte b = 0; b < vector.size(); b++) {
          DataFieldToObjectEntityMap dataFieldToObjectEntityMap = (DataFieldToObjectEntityMap)vector.elementAt(b);
          if (!dataFieldToObjectEntityMap.fieldName.equals(str3))
            try {
              Object object;
              if (useMethodsForUpdate()) {
                object = invokeMemberGetMethod(((DataFieldToMethodMap)dataFieldToObjectEntityMap).method);
              } else {
                object = ((DataFieldToVariableMap)dataFieldToObjectEntityMap).variable.get(this);
              } 
              if (object != null)
                if (object instanceof String) {
                  stringList.add(String.valueOf(dataFieldToObjectEntityMap.fieldName) + " = " + BasicHelper.prepareString((String)object));
                } else if (object instanceof java.sql.Date) {
                  stringList.add(String.valueOf(dataFieldToObjectEntityMap.fieldName) + " = '" + object.toString() + "'");
                } else if (object instanceof Date) {
                  Date date = (Date)object;
                  Timestamp timestamp = new Timestamp(date.getTime());
                  stringList.add(String.valueOf(dataFieldToObjectEntityMap.fieldName) + " = '" + timestamp.toString() + "'");
                } else {
                  stringList.add(String.valueOf(dataFieldToObjectEntityMap.fieldName) + " = " + object.toString());
                }  
            } catch (IllegalAccessException illegalAccessException) {} 
        } 
        stringBuffer.append(" SET ");
        stringBuffer.append(stringList);
        stringBuffer.append(" WHERE (");
        stringBuffer.append(str3);
        stringBuffer.append(" = ");
        stringBuffer.append(i);
        stringBuffer.append(");");
      } else {
        System.out.println("DataEntity: Stored proc. and table names are null.  Cannot update.");
      } 
      if (stringBuffer.length() > 0) {
        paramDatabaseConnector.setQuery(stringBuffer.toString());
        if (debugQueries())
          System.out.println("DataEntity updateDatabase query:\n" + stringBuffer); 
        paramDatabaseConnector.runQuery();
        if (paramDatabaseConnector.more()) {
          int j = paramDatabaseConnector.getInt("Identity");
          paramDatabaseConnector.close();
          if (j > 0)
            return j; 
        } else {
          paramDatabaseConnector.close();
        } 
        return -1;
      } 
    } else {
      System.out.println("DataEntity: Field cache not ready for this class.  Cannot update.");
    } 
    return -2;
  }
  
  protected boolean caseSensitiveBinding() { return false; }
  
  protected void customInitialization(DatabaseConnector paramDatabaseConnector) {}
  
  protected void initializationComplete() {}
  
  protected Vector getFieldMappingCache(DatabaseConnector paramDatabaseConnector) {
    Vector vector = DataMappingCache.getFieldMappings(getClass());
    if (vector == null && paramDatabaseConnector != null) {
      buildFieldCache(paramDatabaseConnector);
      vector = DataMappingCache.getFieldMappings(getClass());
    } 
    return vector;
  }
  
  protected Vector getMethodMappingCache(DatabaseConnector paramDatabaseConnector) {
    Vector vector = DataMappingCache.getSetMethodMappings(getClass());
    if (vector == null && paramDatabaseConnector != null) {
      buildMethodCache(paramDatabaseConnector);
      vector = DataMappingCache.getSetMethodMappings(getClass());
    } 
    return vector;
  }
  
  protected Vector getGetMethodMappingCache() { return DataMappingCache.getGetMethodMappings(getClass()); }
  
  protected void buildMethodCache(DatabaseConnector paramDatabaseConnector) {
    Vector vector1 = new Vector();
    Vector vector2 = new Vector();
    String[] arrayOfString = paramDatabaseConnector.getFieldNames();
    int[] arrayOfInt = paramDatabaseConnector.getFieldTypes();
    Method[] arrayOfMethod = getClass().getMethods();
    for (byte b = 0; b < arrayOfMethod.length; b++) {
      for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
        boolean bool;
        if (caseSensitiveBinding()) {
          bool = arrayOfMethod[b].getName().equals("set" + arrayOfString[b1]);
        } else {
          bool = arrayOfMethod[b].getName().equalsIgnoreCase("set" + arrayOfString[b1]);
        } 
        if (bool)
          vector1.addElement(new DataFieldToMethodMap(arrayOfMethod[b], 
                arrayOfString[b1], arrayOfInt[b1])); 
        if (caseSensitiveBinding()) {
          bool = arrayOfMethod[b].getName().equals("get" + arrayOfString[b1]);
        } else {
          bool = arrayOfMethod[b].getName().equalsIgnoreCase("get" + arrayOfString[b1]);
        } 
        if (!bool)
          if (caseSensitiveBinding()) {
            bool = arrayOfMethod[b].getName().equals("is" + arrayOfString[b1]);
          } else {
            bool = arrayOfMethod[b].getName().equalsIgnoreCase("is" + arrayOfString[b1]);
          }  
        if (bool)
          vector2.addElement(new DataFieldToMethodMap(arrayOfMethod[b], 
                arrayOfString[b1], arrayOfInt[b1])); 
      } 
    } 
    processCustomBindingsMap(vector1, arrayOfString, arrayOfInt, arrayOfMethod, 
        getCustomMethodBindings());
    processCustomBindingsMap(vector2, arrayOfString, arrayOfInt, arrayOfMethod, 
        getCustomGetMethodBindings());
    DataMappingCache.putSetMethodMappings(getClass(), vector1);
    DataMappingCache.putGetMethodMappings(getClass(), vector2);
  }
  
  protected void processCustomBindingsMap(Vector paramVector, String[] paramArrayOfString, int[] paramArrayOfInt, Method[] paramArrayOfMethod, Hashtable paramHashtable) {
    if (paramHashtable != null) {
      Enumeration enumeration = paramHashtable.keys();
      while (enumeration.hasMoreElements()) {
        int i = 0;
        String str2 = (String)enumeration.nextElement();
        String str1 = (String)paramHashtable.get(str2);
        for (byte b = 0; b < paramArrayOfString.length; b++) {
          if (paramArrayOfString[b].equals(str2)) {
            i = paramArrayOfInt[b];
            break;
          } 
        } 
        if (i > -10)
          for (byte b1 = 0; b1 < paramArrayOfMethod.length; b1++) {
            if (paramArrayOfMethod[b1].getName().equals(str1)) {
              paramVector.addElement(new DataFieldToMethodMap(paramArrayOfMethod[b1], 
                    str2, i));
              break;
            } 
          }  
      } 
    } 
  }
  
  protected void buildFieldCache(DatabaseConnector paramDatabaseConnector) {
    Vector vector1 = new Vector();
    String[] arrayOfString = paramDatabaseConnector.getFieldNames();
    int[] arrayOfInt = paramDatabaseConnector.getFieldTypes();
    Vector vector2 = new Vector();
    Class clazz = getClass();
    while (clazz != null) {
      Field[] arrayOfField = clazz.getDeclaredFields();
      for (byte b1 = 0; b1 < arrayOfField.length; b1++)
        vector2.addElement(arrayOfField[b1]); 
      clazz = clazz.getSuperclass();
    } 
    for (byte b = 0; b < vector2.size(); b++) {
      Field field = (Field)vector2.elementAt(b);
      for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
        boolean bool;
        if (caseSensitiveBinding()) {
          bool = field.getName().equals(arrayOfString[b1]);
        } else {
          bool = field.getName().equalsIgnoreCase(arrayOfString[b1]);
        } 
        if (bool)
          vector1.addElement(new DataFieldToVariableMap(field, 
                arrayOfString[b1], arrayOfInt[b1])); 
      } 
    } 
    Hashtable hashtable = getCustomVariableBindings();
    if (hashtable != null) {
      Enumeration enumeration = hashtable.keys();
      while (enumeration.hasMoreElements()) {
        int i = 0;
        String str1 = (String)enumeration.nextElement();
        String str2 = (String)hashtable.get(str1);
        for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
          if (arrayOfString[b1].equals(str1)) {
            i = arrayOfInt[b1];
            break;
          } 
        } 
        if (i > -10)
          for (byte b2 = 0; b2 < vector2.size(); b2++) {
            Field field = (Field)vector2.elementAt(b2);
            if (field.getName().equals(str2)) {
              vector1.addElement(new DataFieldToVariableMap(field, 
                    str1, i));
              break;
            } 
          }  
      } 
    } 
    DataMappingCache.putFieldMappings(getClass(), vector1);
  }
  
  protected void invokeMemberSetMethod(Method paramMethod, DatabaseConnector paramDatabaseConnector, String paramString, int paramInt) {
    try {
      if (paramInt == 4) {
        paramMethod.invoke(this, new Object[] { new Integer(paramDatabaseConnector.getInt(paramString)) });
      } else if (paramInt == -6) {
        paramMethod.invoke(this, new Object[] { new Byte(paramDatabaseConnector.getByte(paramString)) });
      } else if (paramInt == 5) {
        paramMethod.invoke(this, new Object[] { new Short(paramDatabaseConnector.getShort(paramString)) });
      } else if (paramInt == -5) {
        paramMethod.invoke(this, new Object[] { new Long(paramDatabaseConnector.getLong(paramString)) });
      } else if (paramInt == 8) {
        paramMethod.invoke(this, new Object[] { new Double(paramDatabaseConnector.getDouble(paramString)) });
      } else if (paramInt == 6) {
        paramMethod.invoke(this, new Object[] { new Float(paramDatabaseConnector.getFloat(paramString)) });
      } else if (paramInt == 2) {
        paramMethod.invoke(this, new Object[] { new Float(paramDatabaseConnector.getFloat(paramString)) });
      } else if (paramInt == -7) {
        paramMethod.invoke(this, new Object[] { new Boolean(paramDatabaseConnector.getBoolean(paramString)) });
      } else if (paramInt == 12 || 
        paramInt == 1 || 
        paramInt == -8 || 
        paramInt == -9) {
        paramMethod.invoke(this, new Object[] { paramDatabaseConnector.getFieldByName(paramString) });
      } else if (paramInt == 91 || 
        paramInt == 93) {
        Class[] arrayOfClass = paramMethod.getParameterTypes();
        if (arrayOfClass.length == 1) {
          if (arrayOfClass[0].getName().indexOf("java.util.Calendar") > -1) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(paramDatabaseConnector.getDate(paramString));
            paramMethod.invoke(this, new Object[] { calendar });
          } else {
            paramMethod.invoke(this, new Object[] { paramDatabaseConnector.getDate(paramString) });
          } 
        } else {
          System.out.println("DataEntity: method " + paramMethod.getName() + " does not take 1 parameter.");
        } 
      } 
    } catch (InvocationTargetException invocationTargetException) {
      System.out.println("InvocationTargetException: " + invocationTargetException);
    } catch (IllegalAccessException illegalAccessException) {
      System.out.println("IllegalAccessException: " + illegalAccessException);
    } 
  }
  
  protected Object invokeMemberGetMethod(Method paramMethod) {
    try {
      return paramMethod.invoke(this, new Object[0]);
    } catch (InvocationTargetException invocationTargetException) {
      System.out.println("InvocationTargetException: " + invocationTargetException);
    } catch (IllegalAccessException illegalAccessException) {
      System.out.println("IllegalAccessException: " + illegalAccessException);
    } 
    return null;
  }
  
  protected void setMemberVariable(Field paramField, DatabaseConnector paramDatabaseConnector, String paramString, int paramInt) {
    try {
      if (paramInt == 4) {
        paramField.set(this, new Integer(paramDatabaseConnector.getInt(paramString)));
      } else if (paramInt == -6) {
        paramField.set(this, new Byte(paramDatabaseConnector.getByte(paramString)));
      } else if (paramInt == 5) {
        paramField.set(this, new Short(paramDatabaseConnector.getShort(paramString)));
      } else if (paramInt == -5) {
        paramField.set(this, new Long(paramDatabaseConnector.getLong(paramString)));
      } else if (paramInt == 8) {
        paramField.set(this, new Double(paramDatabaseConnector.getDouble(paramString)));
      } else if (paramInt == 6) {
        paramField.set(this, new Float(paramDatabaseConnector.getFloat(paramString)));
      } else if (paramInt == 2) {
        paramField.set(this, new Float(paramDatabaseConnector.getFloat(paramString)));
      } else if (paramInt == -7) {
        paramField.set(this, new Boolean(paramDatabaseConnector.getBoolean(paramString)));
      } else if (paramInt == 12 || 
        paramInt == 1 || 
        paramInt == -8 || 
        paramInt == -9) {
        paramField.set(this, paramDatabaseConnector.getFieldByName(paramString));
      } else if (paramInt == 91 || 
        paramInt == 93) {
        if (paramField.getType().getName().indexOf("java.util.Calendar") > -1) {
          Calendar calendar = Calendar.getInstance();
          calendar.setTime(paramDatabaseConnector.getDate(paramString));
          paramField.set(this, calendar);
        } else {
          paramField.set(this, paramDatabaseConnector.getDate(paramString));
        } 
      } 
    } catch (IllegalAccessException illegalAccessException) {
      System.out.println("IllegalAccessException: " + illegalAccessException);
    } 
  }
  
  public boolean debugQueries() { return false; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\DataEntity.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */