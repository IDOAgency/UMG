/*     */ package com.techempower;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SchedulerThread
/*     */   extends EndableThread
/*     */ {
/*     */   public static final String COMPONENT_CODE = "sthr";
/*     */   protected Scheduler scheduler;
/*     */   protected ComponentLog log;
/*     */   
/*     */   public SchedulerThread(Scheduler paramScheduler) {
/*  50 */     super("SchedulerThread");
/*     */     
/*  52 */     this.scheduler = paramScheduler;
/*  53 */     this.log = paramScheduler.getApplication().getLog("sthr");
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  58 */       setPriority(1);
/*     */     }
/*  60 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  72 */     this.log.debug("Scheduler thread started.");
/*     */ 
/*     */     
/*  75 */     while (isRunning()) {
/*     */       
/*  77 */       this.scheduler.checkSchedule();
/*     */ 
/*     */ 
/*     */       
/*  81 */       simpleSleep(this.scheduler.getSleepTime());
/*     */     } 
/*     */     
/*  84 */     this.log.debug("Scheduler thread stopped.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeepRunning(boolean paramBoolean) {
/*  92 */     super.setKeepRunning(paramBoolean);
/*     */     
/*  94 */     if (!isRunning()) {
/*  95 */       this.log.debug("Stop request received.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public String toString() { return "SchedulerThread " + this.scheduler; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\SchedulerThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */