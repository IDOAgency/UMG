package com.techempower;

public class SchedulerThread extends EndableThread {
  public static final String COMPONENT_CODE = "sthr";
  
  protected Scheduler scheduler;
  
  protected ComponentLog log;
  
  public SchedulerThread(Scheduler paramScheduler) {
    super("SchedulerThread");
    this.scheduler = paramScheduler;
    this.log = paramScheduler.getApplication().getLog("sthr");
    try {
      setPriority(1);
    } catch (Exception exception) {}
  }
  
  public void run() {
    this.log.debug("Scheduler thread started.");
    while (isRunning()) {
      this.scheduler.checkSchedule();
      simpleSleep(this.scheduler.getSleepTime());
    } 
    this.log.debug("Scheduler thread stopped.");
  }
  
  public void setKeepRunning(boolean paramBoolean) {
    super.setKeepRunning(paramBoolean);
    if (!isRunning())
      this.log.debug("Stop request received."); 
  }
  
  public String toString() { return "SchedulerThread " + this.scheduler; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\SchedulerThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */