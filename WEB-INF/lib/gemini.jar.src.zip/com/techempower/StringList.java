package com.techempower;

public class StringList {
  protected String separator = ",";
  
  protected StringBuffer value = new StringBuffer();
  
  public StringList() {}
  
  public StringList(String paramString) { this.separator = paramString; }
  
  public void add(String paramString) {
    if (this.value.length() > 0)
      this.value.append(this.separator); 
    this.value.append(paramString);
  }
  
  public String toString() { return this.value.toString(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\StringList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */