package com.techempower;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class BasicHelper {
  public static ArrayList DEFAULT_DATE_FORMATTERS = new ArrayList();
  
  static  {
    byte b = 0;
    for (; b < UtilityConstants.PERMITTED_DATE_FORMATS.length; 
      b++) {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
          UtilityConstants.PERMITTED_DATE_FORMATS[b]);
      simpleDateFormat.setLenient(false);
      DEFAULT_DATE_FORMATTERS.add(b, simpleDateFormat);
    } 
  }
  
  public static String pluralize(int paramInt) {
    if (paramInt != 1)
      return "s"; 
    return "";
  }
  
  public static String zeroPad(int paramInt1, int paramInt2) {
    StringBuffer stringBuffer = new StringBuffer(paramInt2);
    stringBuffer.append(paramInt1);
    while (stringBuffer.length() < paramInt2)
      stringBuffer.insert(0, '0'); 
    return stringBuffer.toString();
  }
  
  public static boolean isAllNumeric(String paramString) {
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c < '0' || c > '9')
        return false; 
    } 
    return true;
  }
  
  public static String truncateString(String paramString, int paramInt) {
    if (paramString.length() > paramInt)
      return paramString.substring(0, paramInt); 
    return paramString;
  }
  
  public static String ellipseTruncateString(String paramString, int paramInt) {
    if (paramInt > 3)
      paramInt -= 3; 
    if (paramString.length() > paramInt)
      return String.valueOf(paramString.substring(0, paramInt)) + "..."; 
    return paramString;
  }
  
  public static boolean validateEmailAddress(String paramString) {
    if (paramString != null) {
      int i = paramString.indexOf('@');
      int j = paramString.indexOf('.', i);
      if (i > 0 && j > i + 1 && 
        j < paramString.length() - 1)
        return true; 
    } 
    return false;
  }
  
  public static String stripNonAlphanumeric(String paramString) {
    StringBuffer stringBuffer = new StringBuffer(paramString.length());
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if ((c >= 'a' && c <= 'z') || (
        c >= 'A' && c <= 'Z') || (
        c >= '0' && c <= '9'))
        stringBuffer.append(c); 
    } 
    return stringBuffer.toString();
  }
  
  public static String macroExpand(Hashtable paramHashtable, String paramString) {
    String str = new String(paramString);
    Enumeration enumeration = paramHashtable.keys();
    while (enumeration.hasMoreElements()) {
      String str1 = (String)enumeration.nextElement();
      String str2 = (String)paramHashtable.get(str1);
      int i = 0;
      int j = str.indexOf(str1, i);
      while (j > -1) {
        str = String.valueOf(str.substring(0, j)) + 
          str2 + 
          str.substring(j + str1.length());
        i = j + str2.length();
        j = str.indexOf(str1, i);
      } 
    } 
    return str;
  }
  
  public static String escapeSingleQuotes(String paramString) {
    if (paramString != null) {
      StringBuffer stringBuffer = new StringBuffer(paramString.length());
      int i = 0;
      int j = paramString.indexOf("'", i);
      while (j > -1) {
        stringBuffer.append(paramString.substring(i, j));
        stringBuffer.append("''");
        i = j + 1;
        j = paramString.indexOf("'", i);
      } 
      stringBuffer.append(paramString.substring(i));
      return stringBuffer.toString();
    } 
    return "";
  }
  
  public static String prepareString(String paramString) { return String.valueOf('\'') + escapeSingleQuotes(paramString) + '\''; }
  
  public static String escapeDoubleQuotesForHtml(String paramString) {
    StringBuffer stringBuffer = new StringBuffer(paramString.length());
    if (paramString != null) {
      int i = 0;
      int j = paramString.indexOf("\"", i);
      while (j > -1) {
        stringBuffer.append(paramString.substring(i, j));
        stringBuffer.append("&quot;");
        i = j + 1;
        j = paramString.indexOf("\"", i);
      } 
      stringBuffer.append(paramString.substring(i));
    } 
    return stringBuffer.toString();
  }
  
  public static String formatUrl(String paramString) {
    if (paramString != null) {
      if (paramString.length() > 0) {
        String str = paramString;
        if (!str.startsWith("http://"))
          str = "http://" + str; 
        if (str.substring(7).indexOf('/') == -1)
          str = String.valueOf(str) + "/"; 
        return str;
      } 
      return paramString;
    } 
    return "";
  }
  
  public static boolean isValidDate(String paramString) { return isValidDate(paramString, DEFAULT_DATE_FORMATTERS); }
  
  public static boolean isValidDate(String paramString, ArrayList paramArrayList) { return isValidDate(paramString, paramArrayList, null); }
  
  public static boolean isValidDate(String paramString, ArrayList paramArrayList, BoxedInt paramBoxedInt) {
    if (paramString == null)
      return false; 
    if (paramArrayList == null || paramArrayList.size() <= 0)
      paramArrayList = DEFAULT_DATE_FORMATTERS; 
    for (byte b = 0; b < paramArrayList.size(); b++) {
      SimpleDateFormat simpleDateFormat = (SimpleDateFormat)paramArrayList.get(b);
      if (simpleDateFormat.parse(paramString, new ParsePosition(false)) != null) {
        if (paramBoxedInt != null)
          paramBoxedInt.set(b); 
        return true;
      } 
    } 
    if (paramBoxedInt != null)
      paramBoxedInt.set(-1); 
    return false;
  }
  
  public static String getCalendarAsString(Calendar paramCalendar, int paramInt1, int paramInt2) { return getCalendarAsString(paramCalendar, paramInt1, paramInt2, "", ""); }
  
  public static String getCalendarAsString(Calendar paramCalendar, int paramInt1, int paramInt2, String paramString1, String paramString2) {
    String str = new String("");
    if (paramString2.equalsIgnoreCase("")) {
      str = DateFormat.getDateTimeInstance(paramInt1, 
          paramInt2).format(paramCalendar.getTime());
    } else {
      str = String.valueOf(DateFormat.getDateInstance(paramInt1).format(paramCalendar.getTime())) + 
        paramString2 + 
        DateFormat.getTimeInstance(paramInt2).format(paramCalendar.getTime());
    } 
    if (!paramString1.equalsIgnoreCase(""))
      replaceSubstrings(str, ".", paramString1); 
    return str;
  }
  
  public static Calendar parseComplexDate(String paramString) { return parseComplexDate(paramString, DEFAULT_DATE_FORMATTERS); }
  
  public static Calendar parseComplexDate(String paramString, ArrayList paramArrayList) { return parseComplexDate(paramString, paramArrayList, null); }
  
  public static Calendar parseComplexDate(String paramString, ArrayList paramArrayList, BoxedInt paramBoxedInt) {
    if (paramString == null)
      return null; 
    if (paramArrayList == null || paramArrayList.size() <= 0)
      paramArrayList = DEFAULT_DATE_FORMATTERS; 
    Calendar calendar = null;
    BoxedInt boxedInt = new BoxedInt(-1);
    if (isValidDate(paramString, paramArrayList, boxedInt)) {
      calendar = Calendar.getInstance();
      calendar.clear();
      calendar.setTime(((SimpleDateFormat)paramArrayList
          .get(boxedInt.get())).parse(paramString, new ParsePosition(0)));
    } 
    if (paramBoxedInt != null)
      paramBoxedInt.set(boxedInt.get()); 
    return calendar;
  }
  
  public static Calendar parseDate(String paramString) {
    if (paramString != null)
      try {
        StringTokenizer stringTokenizer = new StringTokenizer(paramString, "-/.");
        String str1 = stringTokenizer.nextToken();
        String str2 = stringTokenizer.nextToken();
        String str3 = stringTokenizer.nextToken();
        int i = Integer.parseInt(str1) - 1;
        int j = Integer.parseInt(str2);
        int k = Integer.parseInt(str3);
        if (k < 100)
          if (k > 50) {
            k += 1900;
          } else {
            k += 2000;
          }  
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(k, i, j);
        return calendar;
      } catch (Exception exception) {} 
    return null;
  }
  
  public static String replaceSubstrings(String paramString1, String paramString2, String paramString3) { return replaceSubstrings(paramString1, paramString2, paramString3, true); }
  
  public static String replaceSubstrings(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
    StringBuffer stringBuffer = new StringBuffer("");
    if (paramString1 != null && paramString1.length() > 0)
      if (paramString2 != null && paramString2.length() > 0 && 
        paramString3 != null && !paramString2.equals(paramString3)) {
        int i = 0;
        int j = 0;
        while (i + paramString2.length() <= paramString1.length()) {
          if (paramString1.regionMatches(paramBoolean, i, paramString2, 0, paramString2.length())) {
            String str = paramString1.substring(j, i);
            stringBuffer.append(str);
            stringBuffer.append(paramString3);
            j += str.length() + paramString2.length();
            i += paramString2.length();
            continue;
          } 
          i++;
        } 
        if (j < paramString1.length())
          stringBuffer.append(paramString1.substring(j)); 
      }  
    return stringBuffer.toString();
  }
  
  public static String convertStackTraceToString(Throwable paramThrowable) {
    String str = "";
    if (paramThrowable != null) {
      StringWriter stringWriter = new StringWriter();
      PrintWriter printWriter = new PrintWriter(stringWriter);
      paramThrowable.printStackTrace(printWriter);
      str = stringWriter.toString();
    } 
    return str;
  }
  
  public static void main(String[] paramArrayOfString) {
    String str = null;
    try {
      throw new NullPointerException("Test exception");
    } catch (Exception exception) {
      str = convertStackTraceToString(exception);
      System.out.println("Converted string:\n" + str);
      return;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\BasicHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */