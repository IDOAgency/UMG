/*     */ package com.techempower;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicHelper
/*     */ {
/*  38 */   public static ArrayList DEFAULT_DATE_FORMATTERS = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/*  50 */     byte b = 0;
/*  51 */     for (; b < UtilityConstants.PERMITTED_DATE_FORMATS.length; 
/*  52 */       b++) {
/*     */       
/*  54 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
/*  55 */           UtilityConstants.PERMITTED_DATE_FORMATS[b]);
/*     */ 
/*     */       
/*  58 */       simpleDateFormat.setLenient(false);
/*  59 */       DEFAULT_DATE_FORMATTERS.add(b, simpleDateFormat);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String pluralize(int paramInt) {
/*  75 */     if (paramInt != 1) {
/*  76 */       return "s";
/*     */     }
/*  78 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String zeroPad(int paramInt1, int paramInt2) {
/*  92 */     StringBuffer stringBuffer = new StringBuffer(paramInt2);
/*     */     
/*  94 */     stringBuffer.append(paramInt1);
/*     */     
/*  96 */     while (stringBuffer.length() < paramInt2) {
/*  97 */       stringBuffer.insert(0, '0');
/*     */     }
/*  99 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAllNumeric(String paramString) {
/* 113 */     for (byte b = 0; b < paramString.length(); b++) {
/*     */       
/* 115 */       char c = paramString.charAt(b);
/* 116 */       if (c < '0' || c > '9') {
/* 117 */         return false;
/*     */       }
/*     */     } 
/* 120 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String truncateString(String paramString, int paramInt) {
/* 129 */     if (paramString.length() > paramInt) {
/* 130 */       return paramString.substring(0, paramInt);
/*     */     }
/* 132 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String ellipseTruncateString(String paramString, int paramInt) {
/* 141 */     if (paramInt > 3) {
/* 142 */       paramInt -= 3;
/*     */     }
/* 144 */     if (paramString.length() > paramInt) {
/* 145 */       return String.valueOf(paramString.substring(0, paramInt)) + "...";
/*     */     }
/* 147 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean validateEmailAddress(String paramString) {
/* 162 */     if (paramString != null) {
/*     */       
/* 164 */       int i = paramString.indexOf('@');
/* 165 */       int j = paramString.indexOf('.', i);
/*     */ 
/*     */ 
/*     */       
/* 169 */       if (i > 0 && j > i + 1 && 
/* 170 */         j < paramString.length() - 1)
/*     */       {
/* 172 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 176 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stripNonAlphanumeric(String paramString) {
/* 189 */     StringBuffer stringBuffer = new StringBuffer(paramString.length());
/*     */ 
/*     */ 
/*     */     
/* 193 */     for (byte b = 0; b < paramString.length(); b++) {
/*     */       
/* 195 */       char c = paramString.charAt(b);
/*     */ 
/*     */       
/* 198 */       if ((c >= 'a' && c <= 'z') || (
/* 199 */         c >= 'A' && c <= 'Z') || (
/* 200 */         c >= '0' && c <= '9'))
/*     */       {
/*     */         
/* 203 */         stringBuffer.append(c);
/*     */       }
/*     */     } 
/*     */     
/* 207 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String macroExpand(Hashtable paramHashtable, String paramString) {
/* 224 */     String str = new String(paramString);
/*     */     
/* 226 */     Enumeration enumeration = paramHashtable.keys();
/*     */ 
/*     */     
/* 229 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 231 */       String str1 = (String)enumeration.nextElement();
/* 232 */       String str2 = (String)paramHashtable.get(str1);
/*     */       
/* 234 */       int i = 0;
/*     */ 
/*     */       
/* 237 */       int j = str.indexOf(str1, i);
/* 238 */       while (j > -1) {
/*     */ 
/*     */         
/* 241 */         str = String.valueOf(str.substring(0, j)) + 
/* 242 */           str2 + 
/* 243 */           str.substring(j + str1.length());
/* 244 */         i = j + str2.length();
/*     */         
/* 246 */         j = str.indexOf(str1, i);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 251 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeSingleQuotes(String paramString) {
/* 268 */     if (paramString != null) {
/*     */       
/* 270 */       StringBuffer stringBuffer = new StringBuffer(paramString.length());
/* 271 */       int i = 0;
/* 272 */       int j = paramString.indexOf("'", i);
/*     */ 
/*     */       
/* 275 */       while (j > -1) {
/*     */         
/* 277 */         stringBuffer.append(paramString.substring(i, j));
/* 278 */         stringBuffer.append("''");
/* 279 */         i = j + 1;
/* 280 */         j = paramString.indexOf("'", i);
/*     */       } 
/* 282 */       stringBuffer.append(paramString.substring(i));
/*     */       
/* 284 */       return stringBuffer.toString();
/*     */     } 
/*     */     
/* 287 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   public static String prepareString(String paramString) { return String.valueOf('\'') + escapeSingleQuotes(paramString) + '\''; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String escapeDoubleQuotesForHtml(String paramString) {
/* 311 */     StringBuffer stringBuffer = new StringBuffer(paramString.length());
/*     */     
/* 313 */     if (paramString != null) {
/*     */       
/* 315 */       int i = 0;
/* 316 */       int j = paramString.indexOf("\"", i);
/* 317 */       while (j > -1) {
/*     */         
/* 319 */         stringBuffer.append(paramString.substring(i, j));
/* 320 */         stringBuffer.append("&quot;");
/* 321 */         i = j + 1;
/* 322 */         j = paramString.indexOf("\"", i);
/*     */       } 
/* 324 */       stringBuffer.append(paramString.substring(i));
/*     */     } 
/*     */     
/* 327 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatUrl(String paramString) {
/* 340 */     if (paramString != null) {
/*     */       
/* 342 */       if (paramString.length() > 0) {
/*     */         
/* 344 */         String str = paramString;
/*     */ 
/*     */         
/* 347 */         if (!str.startsWith("http://"))
/*     */         {
/* 349 */           str = "http://" + str;
/*     */         }
/*     */ 
/*     */         
/* 353 */         if (str.substring(7).indexOf('/') == -1)
/*     */         {
/* 355 */           str = String.valueOf(str) + "/";
/*     */         }
/*     */         
/* 358 */         return str;
/*     */       } 
/*     */ 
/*     */       
/* 362 */       return paramString;
/*     */     } 
/*     */ 
/*     */     
/* 366 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 400 */   public static boolean isValidDate(String paramString) { return isValidDate(paramString, DEFAULT_DATE_FORMATTERS); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 408 */   public static boolean isValidDate(String paramString, ArrayList paramArrayList) { return isValidDate(paramString, paramArrayList, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValidDate(String paramString, ArrayList paramArrayList, BoxedInt paramBoxedInt) {
/* 418 */     if (paramString == null) {
/* 419 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 423 */     if (paramArrayList == null || paramArrayList.size() <= 0) {
/* 424 */       paramArrayList = DEFAULT_DATE_FORMATTERS;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 432 */     for (byte b = 0; b < paramArrayList.size(); b++) {
/*     */       
/* 434 */       SimpleDateFormat simpleDateFormat = (SimpleDateFormat)paramArrayList.get(b);
/*     */       
/* 436 */       if (simpleDateFormat.parse(paramString, new ParsePosition(false)) != null) {
/*     */         
/* 438 */         if (paramBoxedInt != null)
/*     */         {
/* 440 */           paramBoxedInt.set(b);
/*     */         }
/* 442 */         return true;
/*     */       } 
/*     */     } 
/* 445 */     if (paramBoxedInt != null) {
/* 446 */       paramBoxedInt.set(-1);
/*     */     }
/* 448 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 472 */   public static String getCalendarAsString(Calendar paramCalendar, int paramInt1, int paramInt2) { return getCalendarAsString(paramCalendar, paramInt1, paramInt2, "", ""); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCalendarAsString(Calendar paramCalendar, int paramInt1, int paramInt2, String paramString1, String paramString2) {
/* 482 */     String str = new String("");
/*     */     
/* 484 */     if (paramString2.equalsIgnoreCase("")) {
/*     */       
/* 486 */       str = DateFormat.getDateTimeInstance(paramInt1, 
/* 487 */           paramInt2).format(paramCalendar.getTime());
/*     */     }
/*     */     else {
/*     */       
/* 491 */       str = String.valueOf(DateFormat.getDateInstance(paramInt1).format(paramCalendar.getTime())) + 
/* 492 */         paramString2 + 
/* 493 */         DateFormat.getTimeInstance(paramInt2).format(paramCalendar.getTime());
/*     */     } 
/*     */     
/* 496 */     if (!paramString1.equalsIgnoreCase(""))
/*     */     {
/* 498 */       replaceSubstrings(str, ".", paramString1);
/*     */     }
/*     */     
/* 501 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 532 */   public static Calendar parseComplexDate(String paramString) { return parseComplexDate(paramString, DEFAULT_DATE_FORMATTERS); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 540 */   public static Calendar parseComplexDate(String paramString, ArrayList paramArrayList) { return parseComplexDate(paramString, paramArrayList, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parseComplexDate(String paramString, ArrayList paramArrayList, BoxedInt paramBoxedInt) {
/* 550 */     if (paramString == null) {
/* 551 */       return null;
/*     */     }
/*     */     
/* 554 */     if (paramArrayList == null || paramArrayList.size() <= 0) {
/* 555 */       paramArrayList = DEFAULT_DATE_FORMATTERS;
/*     */     }
/*     */     
/* 558 */     Calendar calendar = null;
/* 559 */     BoxedInt boxedInt = new BoxedInt(-1);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 564 */     if (isValidDate(paramString, paramArrayList, boxedInt)) {
/*     */       
/* 566 */       calendar = Calendar.getInstance();
/* 567 */       calendar.clear();
/* 568 */       calendar.setTime(((SimpleDateFormat)paramArrayList
/* 569 */           .get(boxedInt.get())).parse(paramString, new ParsePosition(0)));
/*     */     } 
/*     */     
/* 572 */     if (paramBoxedInt != null) {
/* 573 */       paramBoxedInt.set(boxedInt.get());
/*     */     }
/* 575 */     return calendar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Calendar parseDate(String paramString) {
/* 594 */     if (paramString != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 599 */         StringTokenizer stringTokenizer = new StringTokenizer(paramString, "-/.");
/* 600 */         String str1 = stringTokenizer.nextToken();
/* 601 */         String str2 = stringTokenizer.nextToken();
/* 602 */         String str3 = stringTokenizer.nextToken();
/*     */         
/* 604 */         int i = Integer.parseInt(str1) - 1;
/* 605 */         int j = Integer.parseInt(str2);
/* 606 */         int k = Integer.parseInt(str3);
/*     */ 
/*     */         
/* 609 */         if (k < 100)
/*     */         {
/* 611 */           if (k > 50) {
/* 612 */             k += 1900;
/*     */           } else {
/* 614 */             k += 2000;
/*     */           } 
/*     */         }
/* 617 */         Calendar calendar = Calendar.getInstance();
/* 618 */         calendar.clear();
/* 619 */         calendar.set(k, i, j);
/*     */         
/* 621 */         return calendar;
/*     */       }
/* 623 */       catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 629 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 644 */   public static String replaceSubstrings(String paramString1, String paramString2, String paramString3) { return replaceSubstrings(paramString1, paramString2, paramString3, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String replaceSubstrings(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
/* 653 */     StringBuffer stringBuffer = new StringBuffer("");
/*     */     
/* 655 */     if (paramString1 != null && paramString1.length() > 0)
/*     */     {
/* 657 */       if (paramString2 != null && paramString2.length() > 0 && 
/* 658 */         paramString3 != null && !paramString2.equals(paramString3)) {
/*     */         
/* 660 */         int i = 0;
/* 661 */         int j = 0;
/*     */         
/* 663 */         while (i + paramString2.length() <= paramString1.length()) {
/*     */           
/* 665 */           if (paramString1.regionMatches(paramBoolean, i, paramString2, 0, paramString2.length())) {
/*     */             
/* 667 */             String str = paramString1.substring(j, i);
/*     */             
/* 669 */             stringBuffer.append(str);
/* 670 */             stringBuffer.append(paramString3);
/*     */             
/* 672 */             j += str.length() + paramString2.length();
/* 673 */             i += paramString2.length();
/*     */             continue;
/*     */           } 
/* 676 */           i++;
/*     */         } 
/*     */         
/* 679 */         if (j < paramString1.length())
/*     */         {
/* 681 */           stringBuffer.append(paramString1.substring(j));
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 687 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String convertStackTraceToString(Throwable paramThrowable) {
/* 698 */     String str = "";
/*     */     
/* 700 */     if (paramThrowable != null) {
/*     */       
/* 702 */       StringWriter stringWriter = new StringWriter();
/* 703 */       PrintWriter printWriter = new PrintWriter(stringWriter);
/*     */       
/* 705 */       paramThrowable.printStackTrace(printWriter);
/*     */       
/* 707 */       str = stringWriter.toString();
/*     */     } 
/*     */     
/* 710 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/* 722 */     String str = null;
/*     */     
/*     */     try {
/* 725 */       throw new NullPointerException("Test exception");
/*     */     }
/* 727 */     catch (Exception exception) {
/*     */       
/* 729 */       str = convertStackTraceToString(exception);
/*     */ 
/*     */       
/* 732 */       System.out.println("Converted string:\n" + str);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\BasicHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */