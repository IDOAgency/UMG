/*    */ package com.techempower;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdbcConnectorError
/*    */   extends Error
/*    */ {
/* 31 */   protected Exception rootCause = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JdbcConnectorError(String paramString, Exception paramException) {
/* 38 */     super(paramString);
/* 39 */     this.rootCause = paramException;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 44 */   public JdbcConnectorError(String paramString) { super(paramString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public Exception getRootCause() { return this.rootCause; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\JdbcConnectorError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */