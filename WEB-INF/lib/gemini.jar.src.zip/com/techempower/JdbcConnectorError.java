package com.techempower;

public class JdbcConnectorError extends Error {
  protected Exception rootCause = null;
  
  public JdbcConnectorError(String paramString, Exception paramException) {
    super(paramString);
    this.rootCause = paramException;
  }
  
  public JdbcConnectorError(String paramString) { super(paramString); }
  
  public Exception getRootCause() { return this.rootCause; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\JdbcConnectorError.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */