package com.techempower;

public class BasicConnectorFactory implements ConnectorFactory {
  public static final String COMPONENT_CODE = "cnfc";
  
  protected String propertyPrefix;
  
  protected String dbConnect;
  
  protected String dbLoginName;
  
  protected String dbLoginPass;
  
  protected String driverUrlPrefix;
  
  protected String driverClass;
  
  protected boolean driverJdbc1;
  
  protected boolean driverSupGetRow;
  
  protected boolean driverSupAbs;
  
  protected int driverPooling;
  
  protected ComponentLog log;
  
  public BasicConnectorFactory(String paramString) {
    this.propertyPrefix = "";
    this.dbConnect = "";
    this.dbLoginName = "";
    this.dbLoginPass = "";
    this.driverUrlPrefix = "";
    this.driverClass = "";
    this.driverJdbc1 = false;
    this.driverSupGetRow = false;
    this.driverSupAbs = false;
    this.driverPooling = 1;
    this.propertyPrefix = paramString;
  }
  
  public BasicConnectorFactory() { this("db."); }
  
  public void configure(EnhancedProperties paramEnhancedProperties, TechEmpowerApplication paramTechEmpowerApplication) {
    this.log = paramTechEmpowerApplication.getLog("cnfc");
    this.dbConnect = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "ConnectString", this.dbConnect);
    this.dbLoginName = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "LoginName", this.dbLoginName);
    this.dbLoginPass = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "LoginPass", this.dbLoginPass);
    this.driverUrlPrefix = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "Driver.UrlPrefix", this.driverUrlPrefix);
    this.driverClass = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "Driver.Class", this.driverClass);
    this.driverPooling = paramEnhancedProperties.getIntegerProperty(String.valueOf(this.propertyPrefix) + "Driver.Pooling", this.driverPooling);
    this.driverJdbc1 = paramEnhancedProperties.getYesNoProperty(String.valueOf(this.propertyPrefix) + "Driver.Jdbc1", this.driverJdbc1);
    this.driverSupGetRow = paramEnhancedProperties.getYesNoProperty(String.valueOf(this.propertyPrefix) + "Driver.SupportsGetRow", this.driverSupGetRow);
    this.driverSupAbs = paramEnhancedProperties.getYesNoProperty(String.valueOf(this.propertyPrefix) + "Driver.SupportsAbsolute", this.driverSupAbs);
    JdbcConnector.loadDriver(this.driverClass, this.driverUrlPrefix, this.driverSupAbs, 
        this.driverSupGetRow, this.driverJdbc1, this.driverPooling);
  }
  
  public DatabaseConnector getConnector(String paramString) {
    JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
    jdbcConnector.setUsername(this.dbLoginName);
    jdbcConnector.setPassword(this.dbLoginPass);
    jdbcConnector.setForwardOnly(true);
    return jdbcConnector;
  }
  
  public JdbcConnector getUniqueConnector(String paramString) {
    JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
    jdbcConnector.setUsername(this.dbLoginName);
    jdbcConnector.setPassword(this.dbLoginPass);
    jdbcConnector.setForceNewConnection(true);
    jdbcConnector.setForwardOnly(false);
    return jdbcConnector;
  }
  
  public DatabaseConnector getScrollingConnector(String paramString) {
    JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
    jdbcConnector.setUsername(this.dbLoginName);
    jdbcConnector.setPassword(this.dbLoginPass);
    jdbcConnector.setForwardOnly(false);
    return jdbcConnector;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\BasicConnectorFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */