/*     */ package com.techempower;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicConnectorFactory
/*     */   implements ConnectorFactory
/*     */ {
/*     */   public static final String COMPONENT_CODE = "cnfc";
/*     */   protected String propertyPrefix;
/*     */   protected String dbConnect;
/*     */   protected String dbLoginName;
/*     */   protected String dbLoginPass;
/*     */   protected String driverUrlPrefix;
/*     */   protected String driverClass;
/*     */   protected boolean driverJdbc1;
/*     */   protected boolean driverSupGetRow;
/*     */   protected boolean driverSupAbs;
/*     */   protected int driverPooling;
/*     */   protected ComponentLog log;
/*     */   
/*     */   public BasicConnectorFactory(String paramString) {
/*  58 */     this.propertyPrefix = "";
/*  59 */     this.dbConnect = "";
/*  60 */     this.dbLoginName = "";
/*  61 */     this.dbLoginPass = "";
/*  62 */     this.driverUrlPrefix = "";
/*  63 */     this.driverClass = "";
/*  64 */     this.driverJdbc1 = false;
/*  65 */     this.driverSupGetRow = false;
/*  66 */     this.driverSupAbs = false;
/*  67 */     this.driverPooling = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.propertyPrefix = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public BasicConnectorFactory() { this("db."); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties, TechEmpowerApplication paramTechEmpowerApplication) {
/* 102 */     this.log = paramTechEmpowerApplication.getLog("cnfc");
/*     */     
/* 104 */     this.dbConnect = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "ConnectString", this.dbConnect);
/* 105 */     this.dbLoginName = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "LoginName", this.dbLoginName);
/* 106 */     this.dbLoginPass = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "LoginPass", this.dbLoginPass);
/* 107 */     this.driverUrlPrefix = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "Driver.UrlPrefix", this.driverUrlPrefix);
/* 108 */     this.driverClass = paramEnhancedProperties.getProperty(String.valueOf(this.propertyPrefix) + "Driver.Class", this.driverClass);
/* 109 */     this.driverPooling = paramEnhancedProperties.getIntegerProperty(String.valueOf(this.propertyPrefix) + "Driver.Pooling", this.driverPooling);
/* 110 */     this.driverJdbc1 = paramEnhancedProperties.getYesNoProperty(String.valueOf(this.propertyPrefix) + "Driver.Jdbc1", this.driverJdbc1);
/* 111 */     this.driverSupGetRow = paramEnhancedProperties.getYesNoProperty(String.valueOf(this.propertyPrefix) + "Driver.SupportsGetRow", this.driverSupGetRow);
/* 112 */     this.driverSupAbs = paramEnhancedProperties.getYesNoProperty(String.valueOf(this.propertyPrefix) + "Driver.SupportsAbsolute", this.driverSupAbs);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     JdbcConnector.loadDriver(this.driverClass, this.driverUrlPrefix, this.driverSupAbs, 
/* 118 */         this.driverSupGetRow, this.driverJdbc1, this.driverPooling);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseConnector getConnector(String paramString) {
/* 128 */     JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
/* 129 */     jdbcConnector.setUsername(this.dbLoginName);
/* 130 */     jdbcConnector.setPassword(this.dbLoginPass);
/* 131 */     jdbcConnector.setForwardOnly(true);
/*     */     
/* 133 */     return jdbcConnector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcConnector getUniqueConnector(String paramString) {
/* 149 */     JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
/* 150 */     jdbcConnector.setUsername(this.dbLoginName);
/* 151 */     jdbcConnector.setPassword(this.dbLoginPass);
/* 152 */     jdbcConnector.setForceNewConnection(true);
/* 153 */     jdbcConnector.setForwardOnly(false);
/*     */     
/* 155 */     return jdbcConnector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatabaseConnector getScrollingConnector(String paramString) {
/* 165 */     JdbcConnector jdbcConnector = new JdbcConnector(this.driverUrlPrefix, this.dbConnect, paramString);
/* 166 */     jdbcConnector.setUsername(this.dbLoginName);
/* 167 */     jdbcConnector.setPassword(this.dbLoginPass);
/* 168 */     jdbcConnector.setForwardOnly(false);
/*     */     
/* 170 */     return jdbcConnector;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\BasicConnectorFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */