/*     */ package com.techempower;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EndableThread
/*     */   extends Thread
/*     */ {
/*     */   public static final int DEFAULT_MAXIMUM_SLEEP = 10000;
/*     */   public static final int DEFAULT_MINIMUM_SLEEP = 500;
/*     */   public static final int DEFAULT_SLEEP_ADJUSTMENT = 500;
/*     */   public static final int DEFAULT_SLEEP_PERIOD = 1000;
/*     */   protected boolean running = true;
/*  52 */   protected int maxSleep = 10000;
/*  53 */   protected int minSleep = 500;
/*  54 */   protected int sleepAdjustment = 500;
/*  55 */   protected int sleepPeriod = 1000;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EndableThread(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  73 */     super(paramString);
/*     */     
/*  75 */     this.sleepPeriod = paramInt1;
/*  76 */     this.maxSleep = paramInt2;
/*  77 */     this.minSleep = paramInt3;
/*  78 */     this.sleepAdjustment = paramInt4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EndableThread(String paramString, int paramInt) {
/*  89 */     this(paramString, paramInt, 10000, 
/*  90 */         500, 500);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public EndableThread(String paramString) { this(paramString, 1000); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public EndableThread() { this("Endable thread"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeepRunning(boolean paramBoolean) {
/* 117 */     this.running = paramBoolean;
/* 118 */     interrupt();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public boolean isRunning() { return this.running; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public void simpleSleep() { simpleSleep(this.sleepPeriod); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void simpleSleep(int paramInt) {
/*     */     try {
/* 149 */       Thread.sleep(paramInt);
/*     */     }
/* 151 */     catch (InterruptedException interruptedException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementSleep() {
/* 162 */     if (this.sleepPeriod < this.maxSleep) {
/*     */       
/* 164 */       this.sleepPeriod += this.sleepAdjustment;
/* 165 */       if (this.sleepPeriod > this.maxSleep) {
/* 166 */         this.sleepPeriod = this.maxSleep;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decrementSleep() {
/* 175 */     if (this.sleepPeriod > this.minSleep) {
/*     */       
/* 177 */       this.sleepPeriod -= this.sleepAdjustment;
/* 178 */       if (this.sleepPeriod < this.minSleep) {
/* 179 */         this.sleepPeriod = this.minSleep;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public void setMinimumSleep() { this.sleepPeriod = this.minSleep; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public void setMaximumSleep() { this.sleepPeriod = this.maxSleep; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\EndableThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */