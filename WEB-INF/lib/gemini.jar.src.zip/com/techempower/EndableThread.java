package com.techempower;

public class EndableThread extends Thread {
  public static final int DEFAULT_MAXIMUM_SLEEP = 10000;
  
  public static final int DEFAULT_MINIMUM_SLEEP = 500;
  
  public static final int DEFAULT_SLEEP_ADJUSTMENT = 500;
  
  public static final int DEFAULT_SLEEP_PERIOD = 1000;
  
  protected boolean running = true;
  
  protected int maxSleep = 10000;
  
  protected int minSleep = 500;
  
  protected int sleepAdjustment = 500;
  
  protected int sleepPeriod = 1000;
  
  public EndableThread(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramString);
    this.sleepPeriod = paramInt1;
    this.maxSleep = paramInt2;
    this.minSleep = paramInt3;
    this.sleepAdjustment = paramInt4;
  }
  
  public EndableThread(String paramString, int paramInt) {
    this(paramString, paramInt, 10000, 
        500, 500);
  }
  
  public EndableThread(String paramString) { this(paramString, 1000); }
  
  public EndableThread() { this("Endable thread"); }
  
  public void setKeepRunning(boolean paramBoolean) {
    this.running = paramBoolean;
    interrupt();
  }
  
  public boolean isRunning() { return this.running; }
  
  public void simpleSleep() { simpleSleep(this.sleepPeriod); }
  
  public void simpleSleep(int paramInt) {
    try {
      Thread.sleep(paramInt);
    } catch (InterruptedException interruptedException) {}
  }
  
  public void incrementSleep() {
    if (this.sleepPeriod < this.maxSleep) {
      this.sleepPeriod += this.sleepAdjustment;
      if (this.sleepPeriod > this.maxSleep)
        this.sleepPeriod = this.maxSleep; 
    } 
  }
  
  public void decrementSleep() {
    if (this.sleepPeriod > this.minSleep) {
      this.sleepPeriod -= this.sleepAdjustment;
      if (this.sleepPeriod < this.minSleep)
        this.sleepPeriod = this.minSleep; 
    } 
  }
  
  public void setMinimumSleep() { this.sleepPeriod = this.minSleep; }
  
  public void setMaximumSleep() { this.sleepPeriod = this.maxSleep; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\EndableThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */