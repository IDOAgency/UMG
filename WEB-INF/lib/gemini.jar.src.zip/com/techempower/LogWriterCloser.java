/*     */ package com.techempower;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogWriterCloser
/*     */   extends Thread
/*     */ {
/*     */   protected static final int DEFAULT_SLEEP_MILLIS = 5000;
/*     */   protected static final long DEFAULT_LAST_ACCESS_THRESHOLD = 120000L;
/*  41 */   protected static LogWriterCloser instance = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   protected Vector logWriters = new Vector();
/*  48 */   protected int sleepMillis = 5000;
/*  49 */   protected long threshold = 120000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogWriterCloser() {
/*  63 */     super("Log writer closer");
/*  64 */     setDaemon(true);
/*  65 */     setPriority(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLogWriter(LogWriter paramLogWriter, String paramString) {
/*  74 */     LogWriterDescriptor logWriterDescriptor = new LogWriterDescriptor(this, paramLogWriter, 
/*  75 */         paramString);
/*  76 */     this.logWriters.addElement(logWriterDescriptor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLogWriter(LogWriter paramLogWriter) {
/*  84 */     Enumeration enumeration = this.logWriters.elements();
/*     */ 
/*     */ 
/*     */     
/*  88 */     while (enumeration.hasMoreElements()) {
/*     */       
/*  90 */       LogWriterDescriptor logWriterDescriptor = (LogWriterDescriptor)enumeration.nextElement();
/*  91 */       if (logWriterDescriptor.logWriter == paramLogWriter) {
/*  92 */         this.logWriters.removeElement(logWriterDescriptor);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public void setSleepPeriod(int paramInt) { this.sleepMillis = paramInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public void setIdleThreshold(long paramLong) { this.threshold = paramLong; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     while (true) {
/*     */       try {
/* 131 */         Thread.sleep(this.sleepMillis);
/*     */       }
/* 133 */       catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 138 */       long l = System.currentTimeMillis();
/*     */ 
/*     */       
/* 141 */       for (byte b = 0; b < this.logWriters.size(); b++) {
/*     */         
/* 143 */         LogWriterDescriptor logWriterDescriptor = (LogWriterDescriptor)this.logWriters.elementAt(b);
/*     */ 
/*     */ 
/*     */         
/* 147 */         if (logWriterDescriptor.logWriter.isOpen() && 
/* 148 */           l > logWriterDescriptor.lastAccess + this.threshold)
/*     */         {
/* 150 */           logWriterDescriptor.logWriter.closeFile(String.valueOf(logWriterDescriptor.description) + " inactive; closing file.");
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void access(LogWriter paramLogWriter) {
/* 166 */     for (byte b = 0; b < this.logWriters.size(); b++) {
/*     */       
/* 168 */       LogWriterDescriptor logWriterDescriptor = (LogWriterDescriptor)this.logWriters.elementAt(b);
/*     */ 
/*     */       
/* 171 */       if (paramLogWriter == logWriterDescriptor.logWriter) {
/*     */         
/* 173 */         logWriterDescriptor.lastAccess = System.currentTimeMillis();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 184 */   public String toString() { return "LogWriterCloser [" + this.logWriters.size() + " LogWriters being watched]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LogWriterCloser getInstance() {
/* 198 */     if (instance == null) {
/*     */       
/* 200 */       instance = new LogWriterCloser();
/* 201 */       instance.start();
/*     */     } 
/*     */ 
/*     */     
/* 205 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class LogWriterDescriptor
/*     */   {
/*     */     private final LogWriterCloser this$0;
/*     */ 
/*     */     
/*     */     public LogWriter logWriter;
/*     */ 
/*     */     
/*     */     public long lastAccess;
/*     */ 
/*     */     
/*     */     public String description;
/*     */ 
/*     */     
/*     */     public LogWriterDescriptor(LogWriterCloser this$0, LogWriter param1LogWriter, String param1String) {
/* 225 */       this.this$0 = this$0;
/*     */       
/* 227 */       this.logWriter = param1LogWriter;
/* 228 */       this.description = param1String;
/* 229 */       this.lastAccess = System.currentTimeMillis();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\LogWriterCloser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */