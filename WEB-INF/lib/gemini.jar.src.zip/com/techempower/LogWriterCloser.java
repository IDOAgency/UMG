package com.techempower;

import java.util.Enumeration;
import java.util.Vector;

public class LogWriterCloser extends Thread {
  protected static final int DEFAULT_SLEEP_MILLIS = 5000;
  
  protected static final long DEFAULT_LAST_ACCESS_THRESHOLD = 120000L;
  
  protected static LogWriterCloser instance = null;
  
  protected Vector logWriters = new Vector();
  
  protected int sleepMillis = 5000;
  
  protected long threshold = 120000L;
  
  public LogWriterCloser() {
    super("Log writer closer");
    setDaemon(true);
    setPriority(1);
  }
  
  public void addLogWriter(LogWriter paramLogWriter, String paramString) {
    LogWriterDescriptor logWriterDescriptor = new LogWriterDescriptor(this, paramLogWriter, 
        paramString);
    this.logWriters.addElement(logWriterDescriptor);
  }
  
  public void removeLogWriter(LogWriter paramLogWriter) {
    Enumeration enumeration = this.logWriters.elements();
    while (enumeration.hasMoreElements()) {
      LogWriterDescriptor logWriterDescriptor = (LogWriterDescriptor)enumeration.nextElement();
      if (logWriterDescriptor.logWriter == paramLogWriter)
        this.logWriters.removeElement(logWriterDescriptor); 
    } 
  }
  
  public void setSleepPeriod(int paramInt) { this.sleepMillis = paramInt; }
  
  public void setIdleThreshold(long paramLong) { this.threshold = paramLong; }
  
  public void run() {
    while (true) {
      try {
        Thread.sleep(this.sleepMillis);
      } catch (InterruptedException interruptedException) {}
      long l = System.currentTimeMillis();
      for (byte b = 0; b < this.logWriters.size(); b++) {
        LogWriterDescriptor logWriterDescriptor = (LogWriterDescriptor)this.logWriters.elementAt(b);
        if (logWriterDescriptor.logWriter.isOpen() && 
          l > logWriterDescriptor.lastAccess + this.threshold)
          logWriterDescriptor.logWriter.closeFile(String.valueOf(logWriterDescriptor.description) + " inactive; closing file."); 
      } 
    } 
  }
  
  public void access(LogWriter paramLogWriter) {
    for (byte b = 0; b < this.logWriters.size(); b++) {
      LogWriterDescriptor logWriterDescriptor = (LogWriterDescriptor)this.logWriters.elementAt(b);
      if (paramLogWriter == logWriterDescriptor.logWriter) {
        logWriterDescriptor.lastAccess = System.currentTimeMillis();
        break;
      } 
    } 
  }
  
  public String toString() { return "LogWriterCloser [" + this.logWriters.size() + " LogWriters being watched]"; }
  
  public static LogWriterCloser getInstance() {
    if (instance == null) {
      instance = new LogWriterCloser();
      instance.start();
    } 
    return instance;
  }
  
  class LogWriterDescriptor {
    private final LogWriterCloser this$0;
    
    public LogWriter logWriter;
    
    public long lastAccess;
    
    public String description;
    
    public LogWriterDescriptor(LogWriterCloser this$0, LogWriter param1LogWriter, String param1String) {
      this.this$0 = this$0;
      this.logWriter = param1LogWriter;
      this.description = param1String;
      this.lastAccess = System.currentTimeMillis();
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\LogWriterCloser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */