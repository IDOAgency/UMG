/*     */ package com.techempower;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlJoin
/*     */   implements SqlReservedWords
/*     */ {
/*     */   protected SqlTable srcTable;
/*     */   protected String[] srcColumns;
/*     */   protected SqlTable destTable;
/*     */   protected String[] destColumns;
/*     */   protected int joinType;
/*     */   protected int queryMode;
/*     */   
/*     */   public SqlJoin(SqlTable paramSqlTable1, String[] paramArrayOfString1, SqlTable paramSqlTable2, String[] paramArrayOfString2, int paramInt1, int paramInt2) {
/*  45 */     this.srcTable = paramSqlTable1;
/*  46 */     this.srcColumns = paramArrayOfString1;
/*     */     
/*  48 */     this.destTable = paramSqlTable2;
/*  49 */     this.destColumns = paramArrayOfString2;
/*     */     
/*  51 */     this.joinType = paramInt1;
/*  52 */     this.queryMode = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public SqlTable getSrcTable() { return this.srcTable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public SqlTable getDestTable() { return this.destTable; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public int getJoinType() { return this.joinType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJoinCondition() {
/*  85 */     String str = "";
/*     */     
/*  87 */     if (this.srcTable != null && this.destTable != null && 
/*  88 */       this.srcColumns != null && this.destColumns != null && 
/*  89 */       this.srcColumns.length == this.destColumns.length)
/*     */     {
/*  91 */       for (byte b = 0; b < this.srcColumns.length; b++) {
/*     */         
/*  93 */         if (str.length() > 0)
/*     */         {
/*  95 */           str = String.valueOf(str) + " AND ";
/*     */         }
/*     */         
/*  98 */         str = String.valueOf(str) + this.srcTable.getFullName() + "." + this.srcColumns[b] + getJoinOperator(true) + 
/*  99 */           " " + "=" + " " + 
/* 100 */           this.destTable.getFullName() + "." + this.destColumns[b] + getJoinOperator(false);
/*     */       } 
/*     */     }
/*     */     
/* 104 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getJoinOperator(boolean paramBoolean) {
/* 113 */     if (this.queryMode == 0) {
/*     */       
/* 115 */       if (this.joinType == 1 && !paramBoolean)
/*     */       {
/* 117 */         return "(+)";
/*     */       }
/* 119 */       if (this.joinType == 2 && paramBoolean)
/*     */       {
/* 121 */         return "(+)";
/*     */       }
/*     */     } 
/*     */     
/* 125 */     return "";
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\SqlJoin.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */