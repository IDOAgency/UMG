package com.techempower;

class DataFieldToObjectEntityMap {
  public String fieldName;
  
  public int fieldType;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\DataFieldToObjectEntityMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */