package com.techempower;

public interface SqlReservedWords {
  public static final String SELECT = "SELECT";
  
  public static final String FROM = "FROM";
  
  public static final String WHERE = "WHERE";
  
  public static final String ORDER_BY = "ORDER BY";
  
  public static final String AND = "AND";
  
  public static final String OR = "OR";
  
  public static final String INNER_JOIN_KEYWORD = "INNER JOIN";
  
  public static final String RIGHT_JOIN_KEYWORD = "RIGHT JOIN";
  
  public static final String LEFT_JOIN_KEYWORD = "LEFT JOIN";
  
  public static final String ON = "ON";
  
  public static final String OUTER_JOIN_OPERATOR = "(+)";
  
  public static final String DISTINCT = "DISTINCT";
  
  public static final String DISTINCT_ROW = "DISTINCTROW";
  
  public static final String EQUALS = "=";
  
  public static final String NAME_SEPARATOR = ".";
  
  public static final String SELECTION_SEPARATOR = ",";
  
  public static final String LEFT_PAREN = "(";
  
  public static final String RIGHT_PAREN = ")";
  
  public static final String SPACE = " ";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\SqlReservedWords.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */