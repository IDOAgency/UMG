package com.techempower;

public final class BoxedDouble {
  private double doubleValue;
  
  public BoxedDouble(double paramDouble) { this.doubleValue = paramDouble; }
  
  public double get() { return this.doubleValue; }
  
  public void set(double paramDouble) { this.doubleValue = paramDouble; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\BoxedDouble.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */