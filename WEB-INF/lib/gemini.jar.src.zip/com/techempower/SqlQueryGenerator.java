/*     */ package com.techempower;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlQueryGenerator
/*     */   implements SqlReservedWords
/*     */ {
/*     */   public static final int ENTRY_LEVEL_SQL_92 = 0;
/*     */   public static final int INTERMEDIATE_LEVEL_SQL_92 = 1;
/*     */   public static final int INNER_JOIN = 0;
/*     */   public static final int LEFT_JOIN = 1;
/*     */   public static final int RIGHT_JOIN = 2;
/*     */   protected int queryMode;
/*     */   protected Vector tables;
/*     */   protected Vector joins;
/*     */   protected Vector orderBys;
/*     */   protected String whereAppendage;
/*     */   protected boolean orderBySet;
/*     */   protected String orderBySetting;
/*     */   protected String generatedClause;
/*     */   protected String distinctKeyword;
/*     */   
/*     */   public SqlQueryGenerator(int paramInt) {
/*  76 */     this.queryMode = 0;
/*     */     
/*  78 */     this.tables = new Vector();
/*  79 */     this.joins = new Vector();
/*  80 */     this.orderBys = new Vector();
/*     */     
/*  82 */     this.whereAppendage = "";
/*     */     
/*  84 */     this.orderBySet = false;
/*  85 */     this.orderBySetting = "";
/*     */     
/*  87 */     this.generatedClause = "";
/*     */     
/*  89 */     this.distinctKeyword = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     this.queryMode = paramInt;
/*     */ 
/*     */     
/*  99 */     if (paramInt < 0 || 
/* 100 */       paramInt > 1)
/*     */     {
/* 102 */       paramInt = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 115 */     this.tables.removeAllElements();
/* 116 */     this.joins.removeAllElements();
/* 117 */     this.orderBys.removeAllElements();
/*     */     
/* 119 */     this.whereAppendage = "";
/*     */     
/* 121 */     this.orderBySet = false;
/* 122 */     this.orderBySetting = "";
/*     */     
/* 124 */     this.generatedClause = "";
/*     */     
/* 126 */     this.distinctKeyword = "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public void setDistinctKeyword(String paramString) { this.distinctKeyword = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public SqlTable addTable(String paramString1, String paramString2) { return addTable(paramString1, null, new String[] { paramString2 }); }
/*     */ 
/*     */ 
/*     */   
/* 146 */   public SqlTable addTable(String paramString, String[] paramArrayOfString) { return addTable(new SqlTable(paramString, null, toVector(paramArrayOfString))); }
/*     */ 
/*     */ 
/*     */   
/* 150 */   public SqlTable addTable(String paramString1, String paramString2, String paramString3) { return addTable(paramString1, paramString2, new String[] { paramString3 }); }
/*     */ 
/*     */ 
/*     */   
/* 154 */   public SqlTable addTable(String paramString1, String paramString2, String[] paramArrayOfString) { return addTable(new SqlTable(paramString1, paramString2, toVector(paramArrayOfString))); }
/*     */ 
/*     */   
/*     */   public SqlTable addTable(SqlTable paramSqlTable) {
/* 158 */     int i = this.tables.indexOf(paramSqlTable);
/*     */ 
/*     */     
/* 161 */     if (i > -1) {
/*     */       
/* 163 */       SqlTable sqlTable = (SqlTable)this.tables.elementAt(i);
/* 164 */       sqlTable.addColumnSelections(paramSqlTable.getColumnSelections());
/*     */       
/* 166 */       paramSqlTable = sqlTable;
/*     */     }
/*     */     else {
/*     */       
/* 170 */       this.tables.addElement(paramSqlTable);
/*     */     } 
/* 172 */     return paramSqlTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlTable getTableByTableName(String paramString) {
/* 180 */     SqlTable sqlTable = null;
/*     */     
/* 182 */     for (byte b = 0; paramString != null && this.tables != null && b < this.tables.size(); b++) {
/*     */       
/* 184 */       SqlTable sqlTable1 = (SqlTable)this.tables.elementAt(b);
/*     */       
/* 186 */       if (sqlTable1.getTableName().equalsIgnoreCase(paramString)) {
/*     */         
/* 188 */         sqlTable = sqlTable1;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 193 */     return sqlTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public SqlJoin addJoin(String paramString1, String paramString2, String paramString3, int paramInt) { return addJoin(paramString1, paramString2, new String[] { paramString3 }, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   public SqlJoin addJoin(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt) { return addJoin(paramString1, new String[] { paramString2 }, paramString3, new String[] { paramString4 }, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   public SqlJoin addJoin(String paramString1, String paramString2, String[] paramArrayOfString, int paramInt) { return addJoin(paramString1, paramArrayOfString, paramString2, paramArrayOfString, paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SqlJoin addJoin(String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, int paramInt) {
/* 227 */     SqlTable sqlTable1 = getTableByTableName(paramString1);
/* 228 */     SqlTable sqlTable2 = getTableByTableName(paramString2);
/*     */     
/* 230 */     if (sqlTable1 == null)
/*     */     {
/* 232 */       sqlTable1 = addTable(paramString1, new String[0]);
/*     */     }
/*     */     
/* 235 */     if (sqlTable2 == null)
/*     */     {
/* 237 */       sqlTable2 = addTable(paramString2, new String[0]);
/*     */     }
/*     */     
/* 240 */     if (sqlTable1 != null && sqlTable2 != null) {
/*     */       
/* 242 */       SqlJoin sqlJoin = new SqlJoin(sqlTable1, 
/* 243 */           paramArrayOfString1, 
/* 244 */           sqlTable2, 
/* 245 */           paramArrayOfString2, 
/* 246 */           paramInt, 
/* 247 */           this.queryMode);
/* 248 */       this.joins.addElement(sqlJoin);
/*     */       
/* 250 */       return sqlJoin;
/*     */     } 
/* 252 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendToWhere(String paramString) {
/* 262 */     if (paramString != null && paramString.length() > 0) {
/*     */ 
/*     */       
/* 265 */       if (paramString.startsWith("AND")) {
/* 266 */         paramString = paramString.substring("AND".length());
/*     */       }
/* 268 */       if (paramString.length() > 0)
/*     */       {
/* 270 */         if (this.whereAppendage.length() == 0) {
/*     */ 
/*     */           
/* 273 */           this.whereAppendage = paramString;
/*     */         }
/*     */         else {
/*     */           
/* 277 */           this.whereAppendage = String.valueOf(this.whereAppendage) + " AND (" + paramString + ")";
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOrderBy(String paramString1, String paramString2) {
/* 288 */     if (paramString2 != null) {
/*     */       
/* 290 */       SqlTable sqlTable = getTableByTableName(paramString1);
/*     */       
/* 292 */       if (sqlTable != null) {
/*     */         
/* 294 */         SqlTable sqlTable1 = new SqlTable(sqlTable.getTableName(), sqlTable.getUsername());
/* 295 */         sqlTable1.addOrderByColumn(paramString2);
/*     */         
/* 297 */         this.orderBys.addElement(sqlTable1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrderBy(String paramString) {
/* 307 */     if (paramString != null && paramString.length() > 0) {
/*     */       
/* 309 */       this.orderBySetting = paramString;
/* 310 */       this.orderBySet = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   public String getQuery() { return getQuery(false); }
/*     */ 
/*     */   
/*     */   public String getQuery(boolean paramBoolean) {
/* 324 */     if (this.generatedClause == null || this.generatedClause.length() == 0) {
/* 325 */       this.generatedClause = String.valueOf(getSelectClause()) + getFromClause() + getWhereClause() + getOrderByClause();
/* 326 */     } else if (paramBoolean) {
/* 327 */       this.generatedClause = String.valueOf(getSelectClause()) + getFromClause() + getWhereClause() + getOrderByClause();
/*     */     } 
/* 329 */     return this.generatedClause;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getSelectClause() {
/* 346 */     String str = "";
/*     */     
/* 348 */     for (byte b = 0; b < this.tables.size(); b++) {
/*     */       
/* 350 */       SqlTable sqlTable = (SqlTable)this.tables.elementAt(b);
/* 351 */       String str1 = sqlTable.getSelectionClause();
/*     */       
/* 353 */       if (str1.length() > 0) {
/*     */         
/* 355 */         if (str.length() > 0) {
/* 356 */           str = String.valueOf(str) + ", ";
/*     */         }
/* 358 */         str = String.valueOf(str) + str1;
/*     */       } 
/*     */     } 
/*     */     
/* 362 */     if (str.length() > 0) {
/*     */ 
/*     */       
/* 365 */       if (this.distinctKeyword.length() > 0) {
/* 366 */         str = String.valueOf(this.distinctKeyword) + " " + str;
/*     */       }
/*     */       
/* 369 */       str = "SELECT " + str;
/*     */     } 
/*     */     
/* 372 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getFromClause() {
/* 380 */     String str = "";
/*     */     
/* 382 */     if (this.queryMode == 0) {
/*     */       
/* 384 */       for (byte b = 0; b < this.tables.size(); b++) {
/*     */         
/* 386 */         SqlTable sqlTable = (SqlTable)this.tables.elementAt(b);
/* 387 */         String str1 = sqlTable.getFullName();
/*     */         
/* 389 */         if (str1.length() > 0)
/*     */         {
/* 391 */           if (str.length() > 0) {
/* 392 */             str = String.valueOf(str) + ", ";
/*     */           }
/* 394 */           str = String.valueOf(str) + str1;
/*     */         }
/*     */       
/*     */       } 
/* 398 */     } else if (this.queryMode == 1) {
/*     */       
/* 400 */       String str1 = "";
/*     */ 
/*     */       
/* 403 */       if (this.joins.isEmpty()) {
/*     */         
/* 405 */         for (byte b = 0; b < this.tables.size(); b++)
/*     */         {
/* 407 */           SqlTable sqlTable = (SqlTable)this.tables.elementAt(b);
/* 408 */           String str2 = sqlTable.getFullName();
/*     */           
/* 410 */           if (str2.length() > 0)
/*     */           {
/* 412 */             if (str1.length() > 0) {
/* 413 */               str1 = String.valueOf(str1) + ", ";
/*     */             }
/* 415 */             str1 = String.valueOf(str1) + str2;
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 422 */         Vector vector = new Vector(this.joins.size() * 2);
/*     */         
/* 424 */         for (byte b = 0; b < this.joins.size(); b++) {
/*     */           
/* 426 */           SqlJoin sqlJoin = (SqlJoin)this.joins.elementAt(b);
/*     */ 
/*     */           
/* 429 */           if (b == 0) {
/*     */             
/* 431 */             vector.addElement(sqlJoin.getSrcTable());
/* 432 */             vector.addElement(sqlJoin.getDestTable());
/*     */             
/* 434 */             str1 = String.valueOf(str1) + sqlJoin.getSrcTable().getFullName() + " " + getJoinKeyword(sqlJoin.getJoinType()) + " " + 
/* 435 */               sqlJoin.getDestTable().getFullName() + 
/* 436 */               " " + "ON" + " " + sqlJoin.getJoinCondition();
/*     */           }
/*     */           else {
/*     */             
/* 440 */             boolean bool = true;
/*     */             
/* 442 */             SqlTable sqlTable = sqlJoin.getDestTable();
/*     */             
/* 444 */             int i = vector.indexOf(sqlTable);
/*     */             
/* 446 */             if (i > -1) {
/*     */ 
/*     */               
/* 449 */               sqlTable = sqlJoin.getSrcTable();
/*     */ 
/*     */               
/* 452 */               i = vector.indexOf(sqlTable);
/*     */ 
/*     */               
/* 455 */               if (i > -1) {
/*     */                 
/* 457 */                 sqlTable = sqlJoin.getDestTable();
/* 458 */                 bool = false;
/*     */               } 
/*     */             } 
/*     */             
/* 462 */             if (bool) {
/* 463 */               vector.addElement(sqlTable);
/*     */             }
/* 465 */             str1 = "(" + str1 + ")" + " " + getJoinKeyword(sqlJoin.getJoinType()) + " " + 
/* 466 */               sqlTable.getFullName() + 
/* 467 */               " " + "ON" + " " + sqlJoin.getJoinCondition();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 472 */       str = String.valueOf(str) + str1;
/*     */     } 
/*     */     
/* 475 */     if (str.length() > 0) {
/* 476 */       str = " FROM " + str;
/*     */     }
/* 478 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getWhereClause() {
/* 486 */     String str = "";
/*     */     
/* 488 */     if (this.queryMode == 0) {
/*     */       
/* 490 */       String str1 = "";
/*     */       
/* 492 */       for (byte b = 0; b < this.joins.size(); b++) {
/*     */         
/* 494 */         SqlJoin sqlJoin = (SqlJoin)this.joins.elementAt(b);
/* 495 */         String str2 = sqlJoin.getJoinCondition();
/*     */         
/* 497 */         if (str2.length() > 0) {
/*     */           
/* 499 */           if (str1.length() > 0) {
/* 500 */             str1 = String.valueOf(str1) + " AND ";
/*     */           }
/* 502 */           str1 = String.valueOf(str1) + str2;
/*     */         } 
/*     */       } 
/*     */       
/* 506 */       if (str1.length() > 0)
/*     */       {
/* 508 */         str = String.valueOf(str) + "(" + str1 + ")";
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 515 */     if (this.whereAppendage.length() > 0) {
/*     */       
/* 517 */       String str1 = "(" + this.whereAppendage + ")";
/*     */       
/* 519 */       if (str.length() > 0)
/*     */       {
/* 521 */         str1 = " AND " + str1;
/*     */       }
/*     */       
/* 524 */       str = String.valueOf(str) + str1;
/*     */     } 
/*     */     
/* 527 */     if (str.length() > 0) {
/* 528 */       str = " WHERE " + str;
/*     */     }
/* 530 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getOrderByClause() {
/* 538 */     String str = "";
/*     */     
/* 540 */     if (this.orderBySet) {
/*     */       
/* 542 */       if (this.orderBySetting.startsWith("ORDER BY")) {
/* 543 */         str = this.orderBySetting;
/*     */       } else {
/* 545 */         str = String.valueOf(str) + this.orderBySetting;
/*     */       } 
/*     */     } else {
/*     */       
/* 549 */       for (byte b = 0; b < this.orderBys.size(); b++) {
/*     */         
/* 551 */         SqlTable sqlTable = (SqlTable)this.orderBys.elementAt(b);
/* 552 */         String str1 = sqlTable.getOrderByClause();
/*     */         
/* 554 */         if (str1.length() > 0) {
/*     */           
/* 556 */           if (str.length() > 0) {
/* 557 */             str = String.valueOf(str) + ", ";
/*     */           }
/* 559 */           str = String.valueOf(str) + str1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 564 */     if (str.length() > 0) {
/* 565 */       str = " ORDER BY " + str;
/*     */     }
/* 567 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJoinKeyword(int paramInt) {
/* 576 */     if (paramInt == 0)
/*     */     {
/* 578 */       return "INNER JOIN";
/*     */     }
/* 580 */     if (paramInt == 1)
/*     */     {
/* 582 */       return "LEFT JOIN";
/*     */     }
/* 584 */     if (paramInt == 2)
/*     */     {
/* 586 */       return "RIGHT JOIN";
/*     */     }
/*     */     
/* 589 */     return "INNER JOIN";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector toVector(Object[] paramArrayOfObject) {
/*     */     Vector vector;
/* 599 */     if (paramArrayOfObject == null) {
/* 600 */       vector = new Vector(0);
/*     */     } else {
/*     */       
/* 603 */       vector = new Vector(paramArrayOfObject.length);
/*     */       
/* 605 */       for (byte b = 0; b < paramArrayOfObject.length; b++)
/*     */       {
/* 607 */         vector.addElement(paramArrayOfObject[b]);
/*     */       }
/*     */     } 
/*     */     
/* 611 */     return vector;
/*     */   }
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\SqlQueryGenerator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */