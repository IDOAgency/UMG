package com.techempower;

import java.util.Vector;

public class SqlQueryGenerator implements SqlReservedWords {
  public static final int ENTRY_LEVEL_SQL_92 = 0;
  
  public static final int INTERMEDIATE_LEVEL_SQL_92 = 1;
  
  public static final int INNER_JOIN = 0;
  
  public static final int LEFT_JOIN = 1;
  
  public static final int RIGHT_JOIN = 2;
  
  protected int queryMode;
  
  protected Vector tables;
  
  protected Vector joins;
  
  protected Vector orderBys;
  
  protected String whereAppendage;
  
  protected boolean orderBySet;
  
  protected String orderBySetting;
  
  protected String generatedClause;
  
  protected String distinctKeyword;
  
  public SqlQueryGenerator(int paramInt) {
    this.queryMode = 0;
    this.tables = new Vector();
    this.joins = new Vector();
    this.orderBys = new Vector();
    this.whereAppendage = "";
    this.orderBySet = false;
    this.orderBySetting = "";
    this.generatedClause = "";
    this.distinctKeyword = "";
    this.queryMode = paramInt;
    if (paramInt < 0 || 
      paramInt > 1)
      paramInt = 0; 
  }
  
  public void clear() {
    this.tables.removeAllElements();
    this.joins.removeAllElements();
    this.orderBys.removeAllElements();
    this.whereAppendage = "";
    this.orderBySet = false;
    this.orderBySetting = "";
    this.generatedClause = "";
    this.distinctKeyword = "";
  }
  
  public void setDistinctKeyword(String paramString) { this.distinctKeyword = paramString; }
  
  public SqlTable addTable(String paramString1, String paramString2) { return addTable(paramString1, null, new String[] { paramString2 }); }
  
  public SqlTable addTable(String paramString, String[] paramArrayOfString) { return addTable(new SqlTable(paramString, null, toVector(paramArrayOfString))); }
  
  public SqlTable addTable(String paramString1, String paramString2, String paramString3) { return addTable(paramString1, paramString2, new String[] { paramString3 }); }
  
  public SqlTable addTable(String paramString1, String paramString2, String[] paramArrayOfString) { return addTable(new SqlTable(paramString1, paramString2, toVector(paramArrayOfString))); }
  
  public SqlTable addTable(SqlTable paramSqlTable) {
    int i = this.tables.indexOf(paramSqlTable);
    if (i > -1) {
      SqlTable sqlTable = (SqlTable)this.tables.elementAt(i);
      sqlTable.addColumnSelections(paramSqlTable.getColumnSelections());
      paramSqlTable = sqlTable;
    } else {
      this.tables.addElement(paramSqlTable);
    } 
    return paramSqlTable;
  }
  
  public SqlTable getTableByTableName(String paramString) {
    SqlTable sqlTable = null;
    for (byte b = 0; paramString != null && this.tables != null && b < this.tables.size(); b++) {
      SqlTable sqlTable1 = (SqlTable)this.tables.elementAt(b);
      if (sqlTable1.getTableName().equalsIgnoreCase(paramString)) {
        sqlTable = sqlTable1;
        break;
      } 
    } 
    return sqlTable;
  }
  
  public SqlJoin addJoin(String paramString1, String paramString2, String paramString3, int paramInt) { return addJoin(paramString1, paramString2, new String[] { paramString3 }, paramInt); }
  
  public SqlJoin addJoin(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt) { return addJoin(paramString1, new String[] { paramString2 }, paramString3, new String[] { paramString4 }, paramInt); }
  
  public SqlJoin addJoin(String paramString1, String paramString2, String[] paramArrayOfString, int paramInt) { return addJoin(paramString1, paramArrayOfString, paramString2, paramArrayOfString, paramInt); }
  
  public SqlJoin addJoin(String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, int paramInt) {
    SqlTable sqlTable1 = getTableByTableName(paramString1);
    SqlTable sqlTable2 = getTableByTableName(paramString2);
    if (sqlTable1 == null)
      sqlTable1 = addTable(paramString1, new String[0]); 
    if (sqlTable2 == null)
      sqlTable2 = addTable(paramString2, new String[0]); 
    if (sqlTable1 != null && sqlTable2 != null) {
      SqlJoin sqlJoin = new SqlJoin(sqlTable1, 
          paramArrayOfString1, 
          sqlTable2, 
          paramArrayOfString2, 
          paramInt, 
          this.queryMode);
      this.joins.addElement(sqlJoin);
      return sqlJoin;
    } 
    return null;
  }
  
  public void appendToWhere(String paramString) {
    if (paramString != null && paramString.length() > 0) {
      if (paramString.startsWith("AND"))
        paramString = paramString.substring("AND".length()); 
      if (paramString.length() > 0)
        if (this.whereAppendage.length() == 0) {
          this.whereAppendage = paramString;
        } else {
          this.whereAppendage = String.valueOf(this.whereAppendage) + " AND (" + paramString + ")";
        }  
    } 
  }
  
  public void addOrderBy(String paramString1, String paramString2) {
    if (paramString2 != null) {
      SqlTable sqlTable = getTableByTableName(paramString1);
      if (sqlTable != null) {
        SqlTable sqlTable1 = new SqlTable(sqlTable.getTableName(), sqlTable.getUsername());
        sqlTable1.addOrderByColumn(paramString2);
        this.orderBys.addElement(sqlTable1);
      } 
    } 
  }
  
  public void setOrderBy(String paramString) {
    if (paramString != null && paramString.length() > 0) {
      this.orderBySetting = paramString;
      this.orderBySet = true;
    } 
  }
  
  public String getQuery() { return getQuery(false); }
  
  public String getQuery(boolean paramBoolean) {
    if (this.generatedClause == null || this.generatedClause.length() == 0) {
      this.generatedClause = String.valueOf(getSelectClause()) + getFromClause() + getWhereClause() + getOrderByClause();
    } else if (paramBoolean) {
      this.generatedClause = String.valueOf(getSelectClause()) + getFromClause() + getWhereClause() + getOrderByClause();
    } 
    return this.generatedClause;
  }
  
  protected String getSelectClause() {
    String str = "";
    for (byte b = 0; b < this.tables.size(); b++) {
      SqlTable sqlTable = (SqlTable)this.tables.elementAt(b);
      String str1 = sqlTable.getSelectionClause();
      if (str1.length() > 0) {
        if (str.length() > 0)
          str = String.valueOf(str) + ", "; 
        str = String.valueOf(str) + str1;
      } 
    } 
    if (str.length() > 0) {
      if (this.distinctKeyword.length() > 0)
        str = String.valueOf(this.distinctKeyword) + " " + str; 
      str = "SELECT " + str;
    } 
    return str;
  }
  
  protected String getFromClause() {
    String str = "";
    if (this.queryMode == 0) {
      for (byte b = 0; b < this.tables.size(); b++) {
        SqlTable sqlTable = (SqlTable)this.tables.elementAt(b);
        String str1 = sqlTable.getFullName();
        if (str1.length() > 0) {
          if (str.length() > 0)
            str = String.valueOf(str) + ", "; 
          str = String.valueOf(str) + str1;
        } 
      } 
    } else if (this.queryMode == 1) {
      String str1 = "";
      if (this.joins.isEmpty()) {
        for (byte b = 0; b < this.tables.size(); b++) {
          SqlTable sqlTable = (SqlTable)this.tables.elementAt(b);
          String str2 = sqlTable.getFullName();
          if (str2.length() > 0) {
            if (str1.length() > 0)
              str1 = String.valueOf(str1) + ", "; 
            str1 = String.valueOf(str1) + str2;
          } 
        } 
      } else {
        Vector vector = new Vector(this.joins.size() * 2);
        for (byte b = 0; b < this.joins.size(); b++) {
          SqlJoin sqlJoin = (SqlJoin)this.joins.elementAt(b);
          if (b == 0) {
            vector.addElement(sqlJoin.getSrcTable());
            vector.addElement(sqlJoin.getDestTable());
            str1 = String.valueOf(str1) + sqlJoin.getSrcTable().getFullName() + " " + getJoinKeyword(sqlJoin.getJoinType()) + " " + 
              sqlJoin.getDestTable().getFullName() + 
              " " + "ON" + " " + sqlJoin.getJoinCondition();
          } else {
            boolean bool = true;
            SqlTable sqlTable = sqlJoin.getDestTable();
            int i = vector.indexOf(sqlTable);
            if (i > -1) {
              sqlTable = sqlJoin.getSrcTable();
              i = vector.indexOf(sqlTable);
              if (i > -1) {
                sqlTable = sqlJoin.getDestTable();
                bool = false;
              } 
            } 
            if (bool)
              vector.addElement(sqlTable); 
            str1 = "(" + str1 + ")" + " " + getJoinKeyword(sqlJoin.getJoinType()) + " " + 
              sqlTable.getFullName() + 
              " " + "ON" + " " + sqlJoin.getJoinCondition();
          } 
        } 
      } 
      str = String.valueOf(str) + str1;
    } 
    if (str.length() > 0)
      str = " FROM " + str; 
    return str;
  }
  
  protected String getWhereClause() {
    String str = "";
    if (this.queryMode == 0) {
      String str1 = "";
      for (byte b = 0; b < this.joins.size(); b++) {
        SqlJoin sqlJoin = (SqlJoin)this.joins.elementAt(b);
        String str2 = sqlJoin.getJoinCondition();
        if (str2.length() > 0) {
          if (str1.length() > 0)
            str1 = String.valueOf(str1) + " AND "; 
          str1 = String.valueOf(str1) + str2;
        } 
      } 
      if (str1.length() > 0)
        str = String.valueOf(str) + "(" + str1 + ")"; 
    } 
    if (this.whereAppendage.length() > 0) {
      String str1 = "(" + this.whereAppendage + ")";
      if (str.length() > 0)
        str1 = " AND " + str1; 
      str = String.valueOf(str) + str1;
    } 
    if (str.length() > 0)
      str = " WHERE " + str; 
    return str;
  }
  
  protected String getOrderByClause() {
    String str = "";
    if (this.orderBySet) {
      if (this.orderBySetting.startsWith("ORDER BY")) {
        str = this.orderBySetting;
      } else {
        str = String.valueOf(str) + this.orderBySetting;
      } 
    } else {
      for (byte b = 0; b < this.orderBys.size(); b++) {
        SqlTable sqlTable = (SqlTable)this.orderBys.elementAt(b);
        String str1 = sqlTable.getOrderByClause();
        if (str1.length() > 0) {
          if (str.length() > 0)
            str = String.valueOf(str) + ", "; 
          str = String.valueOf(str) + str1;
        } 
      } 
    } 
    if (str.length() > 0)
      str = " ORDER BY " + str; 
    return str;
  }
  
  public static String getJoinKeyword(int paramInt) {
    if (paramInt == 0)
      return "INNER JOIN"; 
    if (paramInt == 1)
      return "LEFT JOIN"; 
    if (paramInt == 2)
      return "RIGHT JOIN"; 
    return "INNER JOIN";
  }
  
  public static Vector toVector(Object[] paramArrayOfObject) {
    Vector vector;
    if (paramArrayOfObject == null) {
      vector = new Vector(0);
    } else {
      vector = new Vector(paramArrayOfObject.length);
      for (byte b = 0; b < paramArrayOfObject.length; b++)
        vector.addElement(paramArrayOfObject[b]); 
    } 
    return vector;
  }
  
  public static void main(String[] paramArrayOfString) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\SqlQueryGenerator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */