package com.techempower;

public class TechEmpowerApplication {
  protected Version version = constructVersion();
  
  protected Log log = constructLog();
  
  protected Version constructVersion() { return Version.getInstance(); }
  
  protected Log constructLog() { return new Log(this); }
  
  public Version getVersion() { return this.version; }
  
  public ComponentLog getLog(String paramString) { return new ComponentLog(this.log, paramString); }
  
  public Log getApplicationLog() { return this.log; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\TechEmpowerApplication.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */