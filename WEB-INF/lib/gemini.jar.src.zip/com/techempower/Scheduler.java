package com.techempower;

import java.util.Enumeration;
import java.util.Vector;

public class Scheduler {
  public static final String COMPONENT_CODE = "schd";
  
  public static final int DEFAULT_SLEEP_TIME = 5000;
  
  protected TechEmpowerApplication application;
  
  protected ComponentLog log;
  
  protected Vector scheduledEvents;
  
  protected SchedulerThread schedulerThread;
  
  protected int sleepTime;
  
  protected boolean daemonMode;
  
  public Scheduler(TechEmpowerApplication paramTechEmpowerApplication) { this(paramTechEmpowerApplication, false); }
  
  public Scheduler(TechEmpowerApplication paramTechEmpowerApplication, boolean paramBoolean) {
    this.scheduledEvents = new Vector();
    this.sleepTime = 5000;
    this.daemonMode = false;
    this.application = paramTechEmpowerApplication;
    this.log = paramTechEmpowerApplication.getLog("schd");
    this.daemonMode = paramBoolean;
  }
  
  public void scheduleEvent(ScheduledEvent paramScheduledEvent, SimpleDate paramSimpleDate) {
    paramScheduledEvent.setScheduledTime(paramSimpleDate);
    if (this.scheduledEvents.contains(paramScheduledEvent)) {
      this.log.debug(String.valueOf(String.valueOf(paramScheduledEvent)) + " rescheduled.");
    } else {
      this.scheduledEvents.addElement(paramScheduledEvent);
      this.log.debug(String.valueOf(String.valueOf(paramScheduledEvent)) + " scheduled.");
    } 
  }
  
  public void scheduleEvent(ScheduledEvent paramScheduledEvent) { scheduleEvent(paramScheduledEvent, new SimpleDate(paramScheduledEvent.getDefaultScheduledTime())); }
  
  public void removeEvent(ScheduledEvent paramScheduledEvent) { this.scheduledEvents.removeElement(paramScheduledEvent); }
  
  public boolean isRunning() { return !(this.schedulerThread == null); }
  
  public void stop() {
    if (this.schedulerThread != null)
      this.schedulerThread.setKeepRunning(false); 
    this.schedulerThread = null;
  }
  
  public void start() {
    if (this.schedulerThread == null) {
      this.schedulerThread = new SchedulerThread(this);
      this.schedulerThread.setDaemon(this.daemonMode);
      this.schedulerThread.start();
    } 
  }
  
  public int getSleepTime() { return this.sleepTime; }
  
  public TechEmpowerApplication getApplication() { return this.application; }
  
  public void setSleepTime(int paramInt) {
    if (paramInt > 0 && paramInt <= 600) {
      this.sleepTime = paramInt * 1000;
      this.log.debug("Sleep time set to " + paramInt + " second" + BasicHelper.pluralize(paramInt) + ".");
    } 
  }
  
  public void checkSchedule() {
    long l = (new SimpleDate()).getAsLong();
    Enumeration enumeration = this.scheduledEvents.elements();
    while (enumeration.hasMoreElements()) {
      ScheduledEvent scheduledEvent = (ScheduledEvent)enumeration.nextElement();
      if (!scheduledEvent.isExecuting() && scheduledEvent.getScheduledTime() <= l) {
        scheduledEvent.setExecuting(true);
        if (scheduledEvent.requiresOwnThread()) {
          this.log.log("Execute on new thread " + scheduledEvent);
          EventRunnerThread eventRunnerThread = new EventRunnerThread(scheduledEvent, this);
          eventRunnerThread.start();
          continue;
        } 
        this.log.log("Executing " + scheduledEvent);
        scheduledEvent.execute(this);
        scheduledEvent.setExecuting(false);
      } 
    } 
  }
  
  public String toString() { return "[Scheduler: " + this.scheduledEvents.size() + " event(s)]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\Scheduler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */