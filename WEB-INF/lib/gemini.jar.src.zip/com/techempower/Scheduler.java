/*     */ package com.techempower;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Scheduler
/*     */ {
/*     */   public static final String COMPONENT_CODE = "schd";
/*     */   public static final int DEFAULT_SLEEP_TIME = 5000;
/*     */   protected TechEmpowerApplication application;
/*     */   protected ComponentLog log;
/*     */   protected Vector scheduledEvents;
/*     */   protected SchedulerThread schedulerThread;
/*     */   protected int sleepTime;
/*     */   protected boolean daemonMode;
/*     */   
/*  71 */   public Scheduler(TechEmpowerApplication paramTechEmpowerApplication) { this(paramTechEmpowerApplication, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Scheduler(TechEmpowerApplication paramTechEmpowerApplication, boolean paramBoolean) {
/*     */     this.scheduledEvents = new Vector();
/*     */     this.sleepTime = 5000;
/*     */     this.daemonMode = false;
/*  82 */     this.application = paramTechEmpowerApplication;
/*  83 */     this.log = paramTechEmpowerApplication.getLog("schd");
/*  84 */     this.daemonMode = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scheduleEvent(ScheduledEvent paramScheduledEvent, SimpleDate paramSimpleDate) {
/*  94 */     paramScheduledEvent.setScheduledTime(paramSimpleDate);
/*  95 */     if (this.scheduledEvents.contains(paramScheduledEvent)) {
/*     */ 
/*     */       
/*  98 */       this.log.debug(String.valueOf(String.valueOf(paramScheduledEvent)) + " rescheduled.");
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 104 */       this.scheduledEvents.addElement(paramScheduledEvent);
/*     */       
/* 106 */       this.log.debug(String.valueOf(String.valueOf(paramScheduledEvent)) + " scheduled.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void scheduleEvent(ScheduledEvent paramScheduledEvent) { scheduleEvent(paramScheduledEvent, new SimpleDate(paramScheduledEvent.getDefaultScheduledTime())); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void removeEvent(ScheduledEvent paramScheduledEvent) { this.scheduledEvents.removeElement(paramScheduledEvent); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public boolean isRunning() { return !(this.schedulerThread == null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 142 */     if (this.schedulerThread != null)
/* 143 */       this.schedulerThread.setKeepRunning(false); 
/* 144 */     this.schedulerThread = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 153 */     if (this.schedulerThread == null) {
/*     */       
/* 155 */       this.schedulerThread = new SchedulerThread(this);
/* 156 */       this.schedulerThread.setDaemon(this.daemonMode);
/* 157 */       this.schedulerThread.start();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public int getSleepTime() { return this.sleepTime; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public TechEmpowerApplication getApplication() { return this.application; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSleepTime(int paramInt) {
/* 183 */     if (paramInt > 0 && paramInt <= 600) {
/*     */       
/* 185 */       this.sleepTime = paramInt * 1000;
/* 186 */       this.log.debug("Sleep time set to " + paramInt + " second" + BasicHelper.pluralize(paramInt) + ".");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkSchedule() {
/* 196 */     long l = (new SimpleDate()).getAsLong();
/*     */ 
/*     */ 
/*     */     
/* 200 */     Enumeration enumeration = this.scheduledEvents.elements();
/*     */ 
/*     */     
/* 203 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 205 */       ScheduledEvent scheduledEvent = (ScheduledEvent)enumeration.nextElement();
/*     */ 
/*     */ 
/*     */       
/* 209 */       if (!scheduledEvent.isExecuting() && scheduledEvent.getScheduledTime() <= l) {
/*     */         
/* 211 */         scheduledEvent.setExecuting(true);
/* 212 */         if (scheduledEvent.requiresOwnThread()) {
/*     */ 
/*     */           
/* 215 */           this.log.log("Execute on new thread " + scheduledEvent);
/* 216 */           EventRunnerThread eventRunnerThread = new EventRunnerThread(scheduledEvent, this);
/* 217 */           eventRunnerThread.start();
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 222 */         this.log.log("Executing " + scheduledEvent);
/* 223 */         scheduledEvent.execute(this);
/* 224 */         scheduledEvent.setExecuting(false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   public String toString() { return "[Scheduler: " + this.scheduledEvents.size() + " event(s)]"; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\Scheduler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */