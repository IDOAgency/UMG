package com.techempower;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;

public class Log implements UtilityConstants, LogWriter {
  public static final String DEFAULT_LOGFILE_DIR = "logs";
  
  public static final String DEFAULT_LOGFILE_EXT = ".log";
  
  public static final String DEFAULT_LOGFILE = "log.log";
  
  public static final boolean DEFAULT_DEBUG_ENABLED = true;
  
  public static final boolean DEFAULT_LOG_ALL_TO_FILE = false;
  
  public static final String DEFAULT_COMPONENT_CODE = "none";
  
  public static final String COMPONENT_CODE = "logf";
  
  protected TechEmpowerApplication application;
  
  protected boolean debugEnabled;
  
  protected boolean logAllToFile;
  
  protected String logFilename;
  
  protected String logDirectory;
  
  protected int lastDay;
  
  protected Calendar cal;
  
  protected Version version;
  
  protected FileWriter fileWriter;
  
  protected Object lockObject;
  
  protected LogWriterCloser closer;
  
  public Log(TechEmpowerApplication paramTechEmpowerApplication) {
    this.debugEnabled = true;
    this.logAllToFile = false;
    this.logFilename = "log.log";
    this.logDirectory = "logs" + File.separator;
    this.lastDay = 0;
    this.cal = Calendar.getInstance();
    this.version = new Version();
    this.fileWriter = null;
    this.lockObject = new Object();
    this.closer = LogWriterCloser.getInstance();
    this.version = paramTechEmpowerApplication.getVersion();
    this.closer.addLogWriter(this, String.valueOf(this.version.getProductName()) + " system log");
  }
  
  public void log(String paramString) { log("none", paramString); }
  
  public void debug(String paramString) {
    if (this.logAllToFile) {
      log("none", paramString);
    } else {
      debugToConsole("none", paramString);
    } 
  }
  
  public void assert(boolean paramBoolean, String paramString) { assert("none", paramBoolean, paramString); }
  
  public void closeFile() {
    synchronized (this.lockObject) {
      try {
        if (this.fileWriter != null)
          this.fileWriter.close(); 
      } catch (IOException iOException) {
        debug("logf", "IOException while closing log file!");
      } 
      this.fileWriter = null;
    } 
  }
  
  public void closeFile(String paramString) {
    log("logf", paramString);
    closeFile();
  }
  
  public boolean isOpen() { return !(this.fileWriter == null); }
  
  public void setLogfileDirectory(String paramString) {
    if (paramString.endsWith(File.separator)) {
      this.logDirectory = paramString;
    } else {
      this.logDirectory = String.valueOf(paramString) + File.separator;
    } 
  }
  
  public void configure(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
    setLogfileDirectory(paramEnhancedProperties.getProperty("LogDirectory", this.logDirectory));
    this.logAllToFile = paramEnhancedProperties.getYesNoProperty("LogEverythingToFile", this.logAllToFile);
    log("logf", "Log successfully configured.");
  }
  
  public void log(String paramString1, String paramString2) {
    this.cal = Calendar.getInstance();
    if (needNewFile()) {
      synchronized (this.lockObject) {
        this.logFilename = generateFilename();
        closeFile();
      } 
      debug("logf", "New log file: " + this.logFilename);
    } 
    StringBuffer stringBuffer = new StringBuffer(80);
    stringBuffer.append(this.version.getProductCode());
    stringBuffer.append(' ');
    stringBuffer.append(generateTimestamp());
    stringBuffer.append(' ');
    stringBuffer.append(paramString1);
    stringBuffer.append(": ");
    stringBuffer.append(paramString2);
    stringBuffer.append("\r\n");
    writeLogEntry(String.valueOf(this.logDirectory) + this.logFilename, stringBuffer.toString());
    debugToConsole(paramString1, paramString2);
  }
  
  public void debug(String paramString1, String paramString2) {
    if (this.logAllToFile) {
      log(paramString1, paramString2);
    } else {
      debugToConsole(paramString1, paramString2);
    } 
  }
  
  public void assert(String paramString1, boolean paramBoolean, String paramString2) {
    if (!paramBoolean)
      debug(paramString1, paramString2); 
  }
  
  public String generateFilename() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(zeroPad(this.cal.get(1), 4));
    stringBuffer.append('-');
    stringBuffer.append(zeroPad(this.cal.get(2) + 1, 2));
    stringBuffer.append('-');
    stringBuffer.append(zeroPad(this.cal.get(5), 2));
    stringBuffer.append(".log");
    return stringBuffer.toString();
  }
  
  public String generateTimestamp() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(zeroPad(this.cal.get(5), 2));
    stringBuffer.append(UtilityConstants.MONTH_NAMES_ABBREVIATED[this.cal.get(2)]);
    stringBuffer.append(zeroPad(this.cal.get(1), 2));
    stringBuffer.append(' ');
    stringBuffer.append(zeroPad(this.cal.get(11), 2));
    stringBuffer.append(':');
    stringBuffer.append(zeroPad(this.cal.get(12), 2));
    stringBuffer.append(':');
    stringBuffer.append(zeroPad(this.cal.get(13), 2));
    return stringBuffer.toString();
  }
  
  public String generateBriefTimestamp() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(zeroPad(this.cal.get(11), 2));
    stringBuffer.append(':');
    stringBuffer.append(zeroPad(this.cal.get(12), 2));
    stringBuffer.append(':');
    stringBuffer.append(zeroPad(this.cal.get(13), 2));
    return stringBuffer.toString();
  }
  
  protected void debugToConsole(String paramString1, String paramString2) {
    this.cal = Calendar.getInstance();
    if (this.debugEnabled) {
      StringBuffer stringBuffer = new StringBuffer(80);
      stringBuffer.append(this.version.getProductCode());
      stringBuffer.append(' ');
      stringBuffer.append(generateBriefTimestamp());
      stringBuffer.append(' ');
      stringBuffer.append(paramString1);
      stringBuffer.append(": ");
      stringBuffer.append(paramString2);
      System.out.println(stringBuffer.toString());
    } 
  }
  
  protected boolean needNewFile() {
    int i = this.cal.get(5);
    if (i != this.lastDay) {
      this.lastDay = i;
      return true;
    } 
    return false;
  }
  
  protected void writeLogEntry(String paramString1, String paramString2) {
    try {
      this.closer.access(this);
      synchronized (this.lockObject) {
        if (this.fileWriter == null)
          openFile(paramString1); 
        if (this.fileWriter != null) {
          this.fileWriter.write(paramString2);
          this.fileWriter.flush();
        } else {
          debug("logf", "Log file not open; cannot write to log.");
        } 
      } 
    } catch (IOException iOException) {
      debug("logf", "Cannot write to log: " + iOException);
    } 
  }
  
  protected void openFile(String paramString) {
    try {
      this.fileWriter = new FileWriter(paramString, true);
    } catch (IOException iOException) {
      debug("logf", "Cannot open log: " + paramString);
    } 
  }
  
  public static String zeroPad(int paramInt1, int paramInt2) {
    StringBuffer stringBuffer = new StringBuffer(paramInt2);
    stringBuffer.append(paramInt1);
    while (stringBuffer.length() < paramInt2)
      stringBuffer.insert(0, "0"); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\Log.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */