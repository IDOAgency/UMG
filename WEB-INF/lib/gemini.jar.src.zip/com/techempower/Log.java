/*     */ package com.techempower;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Log
/*     */   implements UtilityConstants, LogWriter
/*     */ {
/*     */   public static final String DEFAULT_LOGFILE_DIR = "logs";
/*     */   public static final String DEFAULT_LOGFILE_EXT = ".log";
/*     */   public static final String DEFAULT_LOGFILE = "log.log";
/*     */   public static final boolean DEFAULT_DEBUG_ENABLED = true;
/*     */   public static final boolean DEFAULT_LOG_ALL_TO_FILE = false;
/*     */   public static final String DEFAULT_COMPONENT_CODE = "none";
/*     */   public static final String COMPONENT_CODE = "logf";
/*     */   protected TechEmpowerApplication application;
/*     */   protected boolean debugEnabled;
/*     */   protected boolean logAllToFile;
/*     */   protected String logFilename;
/*     */   protected String logDirectory;
/*     */   protected int lastDay;
/*     */   protected Calendar cal;
/*     */   protected Version version;
/*     */   protected FileWriter fileWriter;
/*     */   protected Object lockObject;
/*     */   protected LogWriterCloser closer;
/*     */   
/*     */   public Log(TechEmpowerApplication paramTechEmpowerApplication) {
/*  70 */     this.debugEnabled = true;
/*  71 */     this.logAllToFile = false;
/*  72 */     this.logFilename = "log.log";
/*  73 */     this.logDirectory = "logs" + File.separator;
/*  74 */     this.lastDay = 0;
/*  75 */     this.cal = Calendar.getInstance();
/*  76 */     this.version = new Version();
/*  77 */     this.fileWriter = null;
/*  78 */     this.lockObject = new Object();
/*  79 */     this.closer = LogWriterCloser.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     this.version = paramTechEmpowerApplication.getVersion();
/*  99 */     this.closer.addLogWriter(this, String.valueOf(this.version.getProductName()) + " system log");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void log(String paramString) { log("none", paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(String paramString) {
/* 121 */     if (this.logAllToFile) {
/* 122 */       log("none", paramString);
/*     */     } else {
/* 124 */       debugToConsole("none", paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public void assert(boolean paramBoolean, String paramString) { assert("none", paramBoolean, paramString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeFile() {
/* 146 */     synchronized (this.lockObject) {
/*     */ 
/*     */       
/*     */       try {
/* 150 */         if (this.fileWriter != null) {
/* 151 */           this.fileWriter.close();
/*     */         }
/* 153 */       } catch (IOException iOException) {
/*     */         
/* 155 */         debug("logf", "IOException while closing log file!");
/*     */       } 
/* 157 */       this.fileWriter = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeFile(String paramString) {
/* 167 */     log("logf", paramString);
/* 168 */     closeFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public boolean isOpen() { return !(this.fileWriter == null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogfileDirectory(String paramString) {
/* 186 */     if (paramString.endsWith(File.separator)) {
/* 187 */       this.logDirectory = paramString;
/*     */     } else {
/* 189 */       this.logDirectory = String.valueOf(paramString) + File.separator;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configure(EnhancedProperties paramEnhancedProperties, Version paramVersion) {
/* 198 */     setLogfileDirectory(paramEnhancedProperties.getProperty("LogDirectory", this.logDirectory));
/* 199 */     this.logAllToFile = paramEnhancedProperties.getYesNoProperty("LogEverythingToFile", this.logAllToFile);
/*     */ 
/*     */     
/* 202 */     log("logf", "Log successfully configured.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(String paramString1, String paramString2) {
/* 214 */     this.cal = Calendar.getInstance();
/*     */ 
/*     */     
/* 217 */     if (needNewFile()) {
/*     */       
/* 219 */       synchronized (this.lockObject) {
/*     */         
/* 221 */         this.logFilename = generateFilename();
/* 222 */         closeFile();
/*     */       } 
/*     */       
/* 225 */       debug("logf", "New log file: " + this.logFilename);
/*     */     } 
/*     */ 
/*     */     
/* 229 */     StringBuffer stringBuffer = new StringBuffer(80);
/* 230 */     stringBuffer.append(this.version.getProductCode());
/* 231 */     stringBuffer.append(' ');
/* 232 */     stringBuffer.append(generateTimestamp());
/* 233 */     stringBuffer.append(' ');
/* 234 */     stringBuffer.append(paramString1);
/* 235 */     stringBuffer.append(": ");
/* 236 */     stringBuffer.append(paramString2);
/* 237 */     stringBuffer.append("\r\n");
/*     */ 
/*     */     
/* 240 */     writeLogEntry(String.valueOf(this.logDirectory) + this.logFilename, stringBuffer.toString());
/*     */ 
/*     */     
/* 243 */     debugToConsole(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(String paramString1, String paramString2) {
/* 255 */     if (this.logAllToFile) {
/* 256 */       log(paramString1, paramString2);
/*     */     } else {
/* 258 */       debugToConsole(paramString1, paramString2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assert(String paramString1, boolean paramBoolean, String paramString2) {
/* 272 */     if (!paramBoolean) {
/* 273 */       debug(paramString1, paramString2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateFilename() {
/* 281 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 283 */     stringBuffer.append(zeroPad(this.cal.get(1), 4));
/* 284 */     stringBuffer.append('-');
/* 285 */     stringBuffer.append(zeroPad(this.cal.get(2) + 1, 2));
/* 286 */     stringBuffer.append('-');
/* 287 */     stringBuffer.append(zeroPad(this.cal.get(5), 2));
/* 288 */     stringBuffer.append(".log");
/*     */     
/* 290 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateTimestamp() {
/* 298 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 300 */     stringBuffer.append(zeroPad(this.cal.get(5), 2));
/* 301 */     stringBuffer.append(UtilityConstants.MONTH_NAMES_ABBREVIATED[this.cal.get(2)]);
/* 302 */     stringBuffer.append(zeroPad(this.cal.get(1), 2));
/* 303 */     stringBuffer.append(' ');
/* 304 */     stringBuffer.append(zeroPad(this.cal.get(11), 2));
/* 305 */     stringBuffer.append(':');
/* 306 */     stringBuffer.append(zeroPad(this.cal.get(12), 2));
/* 307 */     stringBuffer.append(':');
/* 308 */     stringBuffer.append(zeroPad(this.cal.get(13), 2));
/*     */     
/* 310 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String generateBriefTimestamp() {
/* 318 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 320 */     stringBuffer.append(zeroPad(this.cal.get(11), 2));
/* 321 */     stringBuffer.append(':');
/* 322 */     stringBuffer.append(zeroPad(this.cal.get(12), 2));
/* 323 */     stringBuffer.append(':');
/* 324 */     stringBuffer.append(zeroPad(this.cal.get(13), 2));
/*     */     
/* 326 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void debugToConsole(String paramString1, String paramString2) {
/* 342 */     this.cal = Calendar.getInstance();
/*     */     
/* 344 */     if (this.debugEnabled) {
/*     */       
/* 346 */       StringBuffer stringBuffer = new StringBuffer(80);
/* 347 */       stringBuffer.append(this.version.getProductCode());
/* 348 */       stringBuffer.append(' ');
/* 349 */       stringBuffer.append(generateBriefTimestamp());
/* 350 */       stringBuffer.append(' ');
/* 351 */       stringBuffer.append(paramString1);
/* 352 */       stringBuffer.append(": ");
/* 353 */       stringBuffer.append(paramString2);
/*     */       
/* 355 */       System.out.println(stringBuffer.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean needNewFile() {
/* 364 */     int i = this.cal.get(5);
/*     */     
/* 366 */     if (i != this.lastDay) {
/*     */       
/* 368 */       this.lastDay = i;
/* 369 */       return true;
/*     */     } 
/*     */     
/* 372 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeLogEntry(String paramString1, String paramString2) {
/*     */     try {
/* 383 */       this.closer.access(this);
/*     */ 
/*     */       
/* 386 */       synchronized (this.lockObject) {
/*     */         
/* 388 */         if (this.fileWriter == null) {
/* 389 */           openFile(paramString1);
/*     */         }
/* 391 */         if (this.fileWriter != null)
/*     */         {
/* 393 */           this.fileWriter.write(paramString2);
/* 394 */           this.fileWriter.flush();
/*     */         }
/*     */         else
/*     */         {
/* 398 */           debug("logf", "Log file not open; cannot write to log.");
/*     */         }
/*     */       
/*     */       } 
/* 402 */     } catch (IOException iOException) {
/*     */       
/* 404 */       debug("logf", "Cannot write to log: " + iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void openFile(String paramString) {
/*     */     try {
/* 416 */       this.fileWriter = new FileWriter(paramString, true);
/*     */     }
/* 418 */     catch (IOException iOException) {
/*     */       
/* 420 */       debug("logf", "Cannot open log: " + paramString);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String zeroPad(int paramInt1, int paramInt2) {
/* 433 */     StringBuffer stringBuffer = new StringBuffer(paramInt2);
/* 434 */     stringBuffer.append(paramInt1);
/* 435 */     while (stringBuffer.length() < paramInt2) {
/* 436 */       stringBuffer.insert(0, "0");
/*     */     }
/* 438 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\gemini.jar!\com\techempower\Log.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */