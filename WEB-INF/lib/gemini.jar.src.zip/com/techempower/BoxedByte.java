package com.techempower;

public final class BoxedByte {
  private byte byteValue;
  
  public BoxedByte(byte paramByte) { this.byteValue = paramByte; }
  
  public byte get() { return this.byteValue; }
  
  public void set(byte paramByte) { this.byteValue = paramByte; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\gemini.jar!\com\techempower\BoxedByte.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */