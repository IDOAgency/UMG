package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.Binding;
import javax.wsdl.BindingFault;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Definition;
import javax.wsdl.Fault;
import javax.wsdl.Import;
import javax.wsdl.Input;
import javax.wsdl.Message;
import javax.wsdl.Operation;
import javax.wsdl.Output;
import javax.wsdl.Part;
import javax.wsdl.Port;
import javax.wsdl.PortType;
import javax.wsdl.Service;
import javax.wsdl.Types;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.xml.namespace.QName;

public class DefinitionImpl extends AbstractWSDLElement implements Definition {
  protected String documentBaseURI = null;
  
  protected QName name = null;
  
  protected String targetNamespace = null;
  
  protected Map namespaces = new HashMap();
  
  protected Map imports = new HashMap();
  
  protected Types types = null;
  
  protected Map messages = new HashMap();
  
  protected Map bindings = new HashMap();
  
  protected Map portTypes = new HashMap();
  
  protected Map services = new HashMap();
  
  protected List nativeAttributeNames = Arrays.asList(Constants.DEFINITION_ATTR_NAMES);
  
  protected ExtensionRegistry extReg = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setDocumentBaseURI(String paramString) { this.documentBaseURI = paramString; }
  
  public String getDocumentBaseURI() { return this.documentBaseURI; }
  
  public void setQName(QName paramQName) { this.name = paramQName; }
  
  public QName getQName() { return this.name; }
  
  public void setTargetNamespace(String paramString) { this.targetNamespace = paramString; }
  
  public String getTargetNamespace() { return this.targetNamespace; }
  
  public void addNamespace(String paramString1, String paramString2) {
    if (paramString1 == null)
      paramString1 = ""; 
    if (paramString2 != null) {
      this.namespaces.put(paramString1, paramString2);
    } else {
      this.namespaces.remove(paramString1);
    } 
  }
  
  public String getNamespace(String paramString) {
    if (paramString == null)
      paramString = ""; 
    return (String)this.namespaces.get(paramString);
  }
  
  public String removeNamespace(String paramString) {
    if (paramString == null)
      paramString = ""; 
    return (String)this.namespaces.remove(paramString);
  }
  
  public String getPrefix(String paramString) {
    if (paramString == null)
      return null; 
    for (Map.Entry entry : this.namespaces.entrySet()) {
      String str1 = (String)entry.getKey();
      String str2 = (String)entry.getValue();
      if (paramString.equals(str2))
        return str1; 
    } 
    return null;
  }
  
  public Map getNamespaces() { return this.namespaces; }
  
  public void setTypes(Types paramTypes) { this.types = paramTypes; }
  
  public Types getTypes() { return this.types; }
  
  public void addImport(Import paramImport) {
    String str = paramImport.getNamespaceURI();
    List list = (List)this.imports.get(str);
    if (list == null) {
      list = new Vector();
      this.imports.put(str, list);
    } 
    list.add(paramImport);
  }
  
  public Import removeImport(Import paramImport) {
    String str = paramImport.getNamespaceURI();
    List list = (List)this.imports.get(str);
    Import import = null;
    if (list != null && list.remove(paramImport))
      import = paramImport; 
    return import;
  }
  
  public List getImports(String paramString) { return (List)this.imports.get(paramString); }
  
  public Map getImports() { return this.imports; }
  
  public void addMessage(Message paramMessage) { this.messages.put(paramMessage.getQName(), paramMessage); }
  
  public Message getMessage(QName paramQName) {
    Message message = (Message)this.messages.get(paramQName);
    if (message == null && paramQName != null)
      message = (Message)getFromImports("message", paramQName); 
    return message;
  }
  
  public Message removeMessage(QName paramQName) { return (Message)this.messages.remove(paramQName); }
  
  public Map getMessages() { return this.messages; }
  
  public void addBinding(Binding paramBinding) { this.bindings.put(paramBinding.getQName(), paramBinding); }
  
  public Binding getBinding(QName paramQName) {
    Binding binding = (Binding)this.bindings.get(paramQName);
    if (binding == null && paramQName != null)
      binding = (Binding)getFromImports("binding", paramQName); 
    return binding;
  }
  
  public Binding removeBinding(QName paramQName) { return (Binding)this.bindings.remove(paramQName); }
  
  public Map getBindings() { return this.bindings; }
  
  public void addPortType(PortType paramPortType) { this.portTypes.put(paramPortType.getQName(), paramPortType); }
  
  public PortType getPortType(QName paramQName) {
    PortType portType = (PortType)this.portTypes.get(paramQName);
    if (portType == null && paramQName != null)
      portType = (PortType)getFromImports("portType", paramQName); 
    return portType;
  }
  
  public PortType removePortType(QName paramQName) { return (PortType)this.portTypes.remove(paramQName); }
  
  public Map getPortTypes() { return this.portTypes; }
  
  public void addService(Service paramService) { this.services.put(paramService.getQName(), paramService); }
  
  public Service getService(QName paramQName) {
    Service service = (Service)this.services.get(paramQName);
    if (service == null && paramQName != null)
      service = (Service)getFromImports("service", paramQName); 
    return service;
  }
  
  public Service removeService(QName paramQName) { return (Service)this.services.remove(paramQName); }
  
  public Map getServices() { return this.services; }
  
  public Binding createBinding() { return new BindingImpl(); }
  
  public BindingFault createBindingFault() { return new BindingFaultImpl(); }
  
  public BindingInput createBindingInput() { return new BindingInputImpl(); }
  
  public BindingOperation createBindingOperation() { return new BindingOperationImpl(); }
  
  public BindingOutput createBindingOutput() { return new BindingOutputImpl(); }
  
  public Fault createFault() { return new FaultImpl(); }
  
  public Import createImport() { return new ImportImpl(); }
  
  public Input createInput() { return new InputImpl(); }
  
  public Message createMessage() { return new MessageImpl(); }
  
  public Operation createOperation() { return new OperationImpl(); }
  
  public Output createOutput() { return new OutputImpl(); }
  
  public Part createPart() { return new PartImpl(); }
  
  public Port createPort() { return new PortImpl(); }
  
  public PortType createPortType() { return new PortTypeImpl(); }
  
  public Service createService() { return new ServiceImpl(); }
  
  public Types createTypes() { return new TypesImpl(); }
  
  public void setExtensionRegistry(ExtensionRegistry paramExtensionRegistry) { this.extReg = paramExtensionRegistry; }
  
  public ExtensionRegistry getExtensionRegistry() { return this.extReg; }
  
  private Object getFromImports(String paramString, QName paramQName) {
    PortType portType = null;
    List list = getImports(paramQName.getNamespaceURI());
    if (list != null)
      for (Import import : list) {
        if (import != null) {
          Definition definition = import.getDefinition();
          if (definition != null) {
            if (paramString == "service") {
              portType = definition.getService(paramQName);
            } else if (paramString == "message") {
              portType = definition.getMessage(paramQName);
            } else if (paramString == "binding") {
              portType = definition.getBinding(paramQName);
            } else if (paramString == "portType") {
              portType = definition.getPortType(paramQName);
            } 
            if (portType != null)
              return portType; 
          } 
        } 
      }  
    return portType;
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Definition: name=" + this.name + " targetNamespace=" + this.targetNamespace);
    if (this.imports != null) {
      Iterator iterator = this.imports.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    if (this.types != null)
      stringBuffer.append("\n" + this.types); 
    if (this.messages != null) {
      Iterator iterator = this.messages.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    if (this.portTypes != null) {
      Iterator iterator = this.portTypes.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    if (this.bindings != null) {
      Iterator iterator = this.bindings.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    if (this.services != null) {
      Iterator iterator = this.services.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
  
  public Map getAllBindings() {
    HashMap hashMap = new HashMap(getBindings());
    Map map = getImports();
    for (Vector vector : map.values()) {
      for (Import import : vector) {
        Definition definition = import.getDefinition();
        if (definition != null)
          hashMap.putAll(definition.getAllBindings()); 
      } 
    } 
    return hashMap;
  }
  
  public Map getAllPortTypes() {
    HashMap hashMap = new HashMap(getPortTypes());
    Map map = getImports();
    for (Vector vector : map.values()) {
      for (Import import : vector) {
        Definition definition = import.getDefinition();
        if (definition != null)
          hashMap.putAll(definition.getAllPortTypes()); 
      } 
    } 
    return hashMap;
  }
  
  public Map getAllServices() {
    HashMap hashMap = new HashMap(getServices());
    Map map = getImports();
    for (Vector vector : map.values()) {
      for (Import import : vector) {
        Definition definition = import.getDefinition();
        if (definition != null)
          hashMap.putAll(definition.getAllServices()); 
      } 
    } 
    return hashMap;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\DefinitionImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */