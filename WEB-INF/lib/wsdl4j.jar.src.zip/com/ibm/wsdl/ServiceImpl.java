package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.wsdl.Port;
import javax.wsdl.Service;
import javax.xml.namespace.QName;

public class ServiceImpl extends AbstractWSDLElement implements Service {
  protected QName name = null;
  
  protected Map ports = new HashMap();
  
  protected List nativeAttributeNames = Arrays.asList(Constants.SERVICE_ATTR_NAMES);
  
  public static final long serialVersionUID = 1L;
  
  public void setQName(QName paramQName) { this.name = paramQName; }
  
  public QName getQName() { return this.name; }
  
  public void addPort(Port paramPort) { this.ports.put(paramPort.getName(), paramPort); }
  
  public Port getPort(String paramString) { return (Port)this.ports.get(paramString); }
  
  public Port removePort(String paramString) { return (Port)this.ports.remove(paramString); }
  
  public Map getPorts() { return this.ports; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Service: name=" + this.name);
    if (this.ports != null) {
      Iterator iterator = this.ports.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\ServiceImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */