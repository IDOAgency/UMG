package com.ibm.wsdl;

import java.util.Arrays;
import java.util.List;
import javax.wsdl.Message;
import javax.wsdl.Output;

public class OutputImpl extends AbstractWSDLElement implements Output {
  protected String name = null;
  
  protected Message message = null;
  
  protected List nativeAttributeNames = Arrays.asList(Constants.OUTPUT_ATTR_NAMES);
  
  public static final long serialVersionUID = 1L;
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setMessage(Message paramMessage) { this.message = paramMessage; }
  
  public Message getMessage() { return this.message; }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Output: name=" + this.name);
    if (this.message != null)
      stringBuffer.append("\n" + this.message); 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\OutputImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */