package com.ibm.wsdl;

import java.util.Arrays;
import java.util.List;
import javax.wsdl.Types;

public class TypesImpl extends AbstractWSDLElement implements Types {
  protected List nativeAttributeNames = Arrays.asList(Constants.TYPES_ATTR_NAMES);
  
  public static final long serialVersionUID = 1L;
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Types:");
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\TypesImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */