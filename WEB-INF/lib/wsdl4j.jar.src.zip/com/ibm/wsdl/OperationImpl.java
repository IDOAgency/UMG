package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.wsdl.Fault;
import javax.wsdl.Input;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.Output;

public class OperationImpl extends AbstractWSDLElement implements Operation {
  protected String name = null;
  
  protected Input input = null;
  
  protected Output output = null;
  
  protected Map faults = new HashMap();
  
  protected OperationType style = null;
  
  protected List parameterOrder = null;
  
  protected List nativeAttributeNames = Arrays.asList(Constants.OPERATION_ATTR_NAMES);
  
  protected boolean isUndefined = true;
  
  public static final long serialVersionUID = 1L;
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setInput(Input paramInput) { this.input = paramInput; }
  
  public Input getInput() { return this.input; }
  
  public void setOutput(Output paramOutput) { this.output = paramOutput; }
  
  public Output getOutput() { return this.output; }
  
  public void addFault(Fault paramFault) { this.faults.put(paramFault.getName(), paramFault); }
  
  public Fault getFault(String paramString) { return (Fault)this.faults.get(paramString); }
  
  public Fault removeFault(String paramString) { return (Fault)this.faults.remove(paramString); }
  
  public Map getFaults() { return this.faults; }
  
  public void setStyle(OperationType paramOperationType) { this.style = paramOperationType; }
  
  public OperationType getStyle() { return this.style; }
  
  public void setParameterOrdering(List paramList) { this.parameterOrder = paramList; }
  
  public List getParameterOrdering() { return this.parameterOrder; }
  
  public void setUndefined(boolean paramBoolean) { this.isUndefined = paramBoolean; }
  
  public boolean isUndefined() { return this.isUndefined; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Operation: name=" + this.name);
    if (this.parameterOrder != null)
      stringBuffer.append("\nparameterOrder=" + this.parameterOrder); 
    if (this.style != null)
      stringBuffer.append("\nstyle=" + this.style); 
    if (this.input != null)
      stringBuffer.append("\n" + this.input); 
    if (this.output != null)
      stringBuffer.append("\n" + this.output); 
    if (this.faults != null) {
      Iterator iterator = this.faults.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\OperationImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */