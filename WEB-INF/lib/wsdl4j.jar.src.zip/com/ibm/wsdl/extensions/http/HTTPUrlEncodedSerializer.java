package com.ibm.wsdl.extensions.http;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.http.HTTPUrlEncoded;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class HTTPUrlEncodedSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    HTTPUrlEncoded hTTPUrlEncoded = (HTTPUrlEncoded)paramExtensibilityElement;
    if (hTTPUrlEncoded != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/http/", "urlEncoded", paramDefinition);
      paramPrintWriter.print("        <" + str);
      Boolean bool = hTTPUrlEncoded.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println("/>");
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    HTTPUrlEncoded hTTPUrlEncoded = (HTTPUrlEncoded)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str != null)
      hTTPUrlEncoded.setRequired(new Boolean(str)); 
    return hTTPUrlEncoded;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\http\HTTPUrlEncodedSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */