package com.ibm.wsdl.extensions.http;

import javax.wsdl.extensions.http.HTTPBinding;
import javax.xml.namespace.QName;

public class HTTPBindingImpl implements HTTPBinding {
  protected QName elementType = HTTPConstants.Q_ELEM_HTTP_BINDING;
  
  protected Boolean required = null;
  
  protected String verb = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setVerb(String paramString) { this.verb = paramString; }
  
  public String getVerb() { return this.verb; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("HTTPBinding (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.verb != null)
      stringBuffer.append("\nverb=" + this.verb); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\http\HTTPBindingImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */