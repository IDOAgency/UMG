package com.ibm.wsdl.extensions.mime;

import javax.wsdl.extensions.mime.MIMEMimeXml;
import javax.xml.namespace.QName;

public class MIMEMimeXmlImpl implements MIMEMimeXml {
  protected QName elementType = MIMEConstants.Q_ELEM_MIME_MIME_XML;
  
  protected Boolean required = null;
  
  protected String part = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setPart(String paramString) { this.part = paramString; }
  
  public String getPart() { return this.part; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("MIMEMimeXml (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.part != null)
      stringBuffer.append("\npart=" + this.part); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\mime\MIMEMimeXmlImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */