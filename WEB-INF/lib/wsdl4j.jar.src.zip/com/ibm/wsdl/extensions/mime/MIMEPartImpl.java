package com.ibm.wsdl.extensions.mime;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.mime.MIMEPart;
import javax.xml.namespace.QName;

public class MIMEPartImpl implements MIMEPart {
  protected QName elementType = MIMEConstants.Q_ELEM_MIME_PART;
  
  protected Boolean required = null;
  
  protected List extElements = new Vector();
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement) { this.extElements.add(paramExtensibilityElement); }
  
  public ExtensibilityElement removeExtensibilityElement(ExtensibilityElement paramExtensibilityElement) { return this.extElements.remove(paramExtensibilityElement) ? paramExtensibilityElement : null; }
  
  public List getExtensibilityElements() { return this.extElements; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("MIMEPart (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.extElements != null) {
      Iterator iterator = this.extElements.iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\mime\MIMEPartImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */