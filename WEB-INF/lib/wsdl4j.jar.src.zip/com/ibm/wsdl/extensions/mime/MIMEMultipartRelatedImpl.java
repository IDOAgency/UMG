package com.ibm.wsdl.extensions.mime;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.extensions.mime.MIMEMultipartRelated;
import javax.wsdl.extensions.mime.MIMEPart;
import javax.xml.namespace.QName;

public class MIMEMultipartRelatedImpl implements MIMEMultipartRelated {
  protected QName elementType = MIMEConstants.Q_ELEM_MIME_MULTIPART_RELATED;
  
  protected Boolean required = null;
  
  protected List mimeParts = new Vector();
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void addMIMEPart(MIMEPart paramMIMEPart) { this.mimeParts.add(paramMIMEPart); }
  
  public MIMEPart removeMIMEPart(MIMEPart paramMIMEPart) { return this.mimeParts.remove(paramMIMEPart) ? paramMIMEPart : null; }
  
  public List getMIMEParts() { return this.mimeParts; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("MIMEMultipartRelated (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.mimeParts != null) {
      Iterator iterator = this.mimeParts.iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\mime\MIMEMultipartRelatedImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */