package com.ibm.wsdl.extensions.mime;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import com.ibm.wsdl.util.xml.XPathUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.List;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.mime.MIMEMultipartRelated;
import javax.wsdl.extensions.mime.MIMEPart;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class MIMEMultipartRelatedSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    MIMEMultipartRelated mIMEMultipartRelated = (MIMEMultipartRelated)paramExtensibilityElement;
    if (mIMEMultipartRelated != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/mime/", "multipartRelated", paramDefinition);
      if (paramClass != null && MIMEPart.class.isAssignableFrom(paramClass))
        paramPrintWriter.print("    "); 
      paramPrintWriter.print("        <" + str);
      Boolean bool = mIMEMultipartRelated.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println('>');
      printMIMEParts(mIMEMultipartRelated.getMIMEParts(), paramPrintWriter, paramDefinition, paramExtensionRegistry);
      if (paramClass != null && MIMEPart.class.isAssignableFrom(paramClass))
        paramPrintWriter.print("    "); 
      paramPrintWriter.println("        </" + str + '>');
    } 
  }
  
  private void printMIMEParts(List paramList, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    if (paramList != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/mime/", "part", paramDefinition);
      for (MIMEPart mIMEPart : paramList) {
        if (mIMEPart != null) {
          paramPrintWriter.print("          <" + str);
          Boolean bool = mIMEPart.getRequired();
          if (bool != null)
            DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
          paramPrintWriter.println('>');
          List list = mIMEPart.getExtensibilityElements();
          if (list != null)
            for (ExtensibilityElement extensibilityElement : list) {
              QName qName = extensibilityElement.getElementType();
              ExtensionSerializer extensionSerializer = paramExtensionRegistry.querySerializer(MIMEPart.class, qName);
              extensionSerializer.marshall(MIMEPart.class, qName, extensibilityElement, paramPrintWriter, paramDefinition, paramExtensionRegistry);
            }  
          paramPrintWriter.println("          </" + str + '>');
        } 
      } 
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    MIMEMultipartRelated mIMEMultipartRelated = (MIMEMultipartRelated)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(MIMEConstants.Q_ELEM_MIME_PART, element)) {
        mIMEMultipartRelated.addMIMEPart(parseMIMEPart(MIMEMultipartRelated.class, MIMEConstants.Q_ELEM_MIME_PART, element, paramDefinition, paramExtensionRegistry));
      } else {
        DOMUtils.throwWSDLException(element);
      } 
    } 
    if (str != null)
      mIMEMultipartRelated.setRequired(new Boolean(str)); 
    return mIMEMultipartRelated;
  }
  
  private MIMEPart parseMIMEPart(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    MIMEPart mIMEPart = (MIMEPart)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str != null)
      mIMEPart.setRequired(new Boolean(str)); 
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      try {
        QName qName = QNameUtils.newQName(element);
        ExtensionDeserializer extensionDeserializer = paramExtensionRegistry.queryDeserializer(MIMEPart.class, qName);
        ExtensibilityElement extensibilityElement = extensionDeserializer.unmarshall(MIMEPart.class, qName, element, paramDefinition, paramExtensionRegistry);
        mIMEPart.addExtensibilityElement(extensibilityElement);
      } catch (WSDLException wSDLException) {
        if (wSDLException.getLocation() == null)
          wSDLException.setLocation(XPathUtils.getXPathExprFromNode(element)); 
        throw wSDLException;
      } 
    } 
    return mIMEPart;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\mime\MIMEMultipartRelatedSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */