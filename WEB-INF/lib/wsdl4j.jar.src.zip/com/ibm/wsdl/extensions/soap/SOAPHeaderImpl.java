package com.ibm.wsdl.extensions.soap;

import java.util.List;
import java.util.Vector;
import javax.wsdl.extensions.soap.SOAPHeader;
import javax.wsdl.extensions.soap.SOAPHeaderFault;
import javax.xml.namespace.QName;

public class SOAPHeaderImpl implements SOAPHeader {
  protected QName elementType = SOAPConstants.Q_ELEM_SOAP_HEADER;
  
  protected Boolean required = null;
  
  protected QName message = null;
  
  protected String part = null;
  
  protected String use = null;
  
  protected List encodingStyles = null;
  
  protected String namespaceURI = null;
  
  protected List soapHeaderFaults = new Vector();
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setMessage(QName paramQName) { this.message = paramQName; }
  
  public QName getMessage() { return this.message; }
  
  public void setPart(String paramString) { this.part = paramString; }
  
  public String getPart() { return this.part; }
  
  public void setUse(String paramString) { this.use = paramString; }
  
  public String getUse() { return this.use; }
  
  public void setEncodingStyles(List paramList) { this.encodingStyles = paramList; }
  
  public List getEncodingStyles() { return this.encodingStyles; }
  
  public void setNamespaceURI(String paramString) { this.namespaceURI = paramString; }
  
  public String getNamespaceURI() { return this.namespaceURI; }
  
  public void addSOAPHeaderFault(SOAPHeaderFault paramSOAPHeaderFault) { this.soapHeaderFaults.add(paramSOAPHeaderFault); }
  
  public SOAPHeaderFault removeSOAPHeaderFault(SOAPHeaderFault paramSOAPHeaderFault) { return this.soapHeaderFaults.remove(paramSOAPHeaderFault) ? paramSOAPHeaderFault : null; }
  
  public List getSOAPHeaderFaults() { return this.soapHeaderFaults; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SOAPHeader (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.message != null)
      stringBuffer.append("\nmessage=" + this.message); 
    if (this.part != null)
      stringBuffer.append("\npart=" + this.part); 
    if (this.use != null)
      stringBuffer.append("\nuse=" + this.use); 
    if (this.encodingStyles != null)
      stringBuffer.append("\nencodingStyles=" + this.encodingStyles); 
    if (this.namespaceURI != null)
      stringBuffer.append("\nnamespaceURI=" + this.namespaceURI); 
    if (this.soapHeaderFaults != null)
      stringBuffer.append("\nsoapHeaderFaults=" + this.soapHeaderFaults); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap\SOAPHeaderImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */