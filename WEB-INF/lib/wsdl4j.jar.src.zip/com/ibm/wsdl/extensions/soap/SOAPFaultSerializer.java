package com.ibm.wsdl.extensions.soap;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap.SOAPFault;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAPFaultSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAPFault sOAPFault = (SOAPFault)paramExtensibilityElement;
    if (sOAPFault != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap/", "fault", paramDefinition);
      paramPrintWriter.print("        <" + str);
      DOMUtils.printAttribute("name", sOAPFault.getName(), paramPrintWriter);
      DOMUtils.printAttribute("use", sOAPFault.getUse(), paramPrintWriter);
      DOMUtils.printAttribute("encodingStyle", StringUtils.getNMTokens(sOAPFault.getEncodingStyles()), paramPrintWriter);
      DOMUtils.printAttribute("namespace", sOAPFault.getNamespaceURI(), paramPrintWriter);
      Boolean bool = sOAPFault.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println("/>");
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAPFault sOAPFault = (SOAPFault)paramExtensionRegistry.createExtension(paramClass, paramQName);
    QName qName = DOMUtils.getQualifiedAttributeValue(paramElement, "message", "header", false, paramDefinition);
    String str1 = DOMUtils.getAttribute(paramElement, "name");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      sOAPFault.setName(str1); 
    if (str2 != null)
      sOAPFault.setUse(str2); 
    if (str3 != null)
      sOAPFault.setEncodingStyles(StringUtils.parseNMTokens(str3)); 
    if (str4 != null)
      sOAPFault.setNamespaceURI(str4); 
    if (str5 != null)
      sOAPFault.setRequired(new Boolean(str5)); 
    return sOAPFault;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap\SOAPFaultSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */