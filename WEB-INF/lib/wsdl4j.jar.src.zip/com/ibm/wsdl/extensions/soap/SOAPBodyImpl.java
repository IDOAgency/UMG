package com.ibm.wsdl.extensions.soap;

import java.util.List;
import javax.wsdl.extensions.soap.SOAPBody;
import javax.xml.namespace.QName;

public class SOAPBodyImpl implements SOAPBody {
  protected QName elementType = SOAPConstants.Q_ELEM_SOAP_BODY;
  
  protected Boolean required = null;
  
  protected List parts = null;
  
  protected String use = null;
  
  protected List encodingStyles = null;
  
  protected String namespaceURI = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setParts(List paramList) { this.parts = paramList; }
  
  public List getParts() { return this.parts; }
  
  public void setUse(String paramString) { this.use = paramString; }
  
  public String getUse() { return this.use; }
  
  public void setEncodingStyles(List paramList) { this.encodingStyles = paramList; }
  
  public List getEncodingStyles() { return this.encodingStyles; }
  
  public void setNamespaceURI(String paramString) { this.namespaceURI = paramString; }
  
  public String getNamespaceURI() { return this.namespaceURI; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SOAPBody (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.parts != null)
      stringBuffer.append("\nparts=" + this.parts); 
    if (this.use != null)
      stringBuffer.append("\nuse=" + this.use); 
    if (this.encodingStyles != null)
      stringBuffer.append("\nencodingStyles=" + this.encodingStyles); 
    if (this.namespaceURI != null)
      stringBuffer.append("\nnamespaceURI=" + this.namespaceURI); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap\SOAPBodyImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */