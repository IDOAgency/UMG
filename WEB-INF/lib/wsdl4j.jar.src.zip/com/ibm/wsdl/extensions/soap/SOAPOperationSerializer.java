package com.ibm.wsdl.extensions.soap;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap.SOAPOperation;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAPOperationSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAPOperation sOAPOperation = (SOAPOperation)paramExtensibilityElement;
    if (sOAPOperation != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap/", "operation", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("soapAction", sOAPOperation.getSoapActionURI(), paramPrintWriter);
      DOMUtils.printAttribute("style", sOAPOperation.getStyle(), paramPrintWriter);
      Boolean bool = sOAPOperation.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println("/>");
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAPOperation sOAPOperation = (SOAPOperation)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str1 = DOMUtils.getAttribute(paramElement, "soapAction");
    String str2 = DOMUtils.getAttribute(paramElement, "style");
    String str3 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      sOAPOperation.setSoapActionURI(str1); 
    if (str2 != null)
      sOAPOperation.setStyle(str2); 
    if (str3 != null)
      sOAPOperation.setRequired(new Boolean(str3)); 
    return sOAPOperation;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap\SOAPOperationSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */