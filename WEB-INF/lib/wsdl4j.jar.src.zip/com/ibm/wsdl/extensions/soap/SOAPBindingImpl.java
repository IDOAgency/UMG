package com.ibm.wsdl.extensions.soap;

import javax.wsdl.extensions.soap.SOAPBinding;
import javax.xml.namespace.QName;

public class SOAPBindingImpl implements SOAPBinding {
  protected QName elementType = SOAPConstants.Q_ELEM_SOAP_BINDING;
  
  protected Boolean required = null;
  
  protected String style = null;
  
  protected String transportURI = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setStyle(String paramString) { this.style = paramString; }
  
  public String getStyle() { return this.style; }
  
  public void setTransportURI(String paramString) { this.transportURI = paramString; }
  
  public String getTransportURI() { return this.transportURI; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SOAPBinding (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.transportURI != null)
      stringBuffer.append("\ntransportURI=" + this.transportURI); 
    if (this.style != null)
      stringBuffer.append("\nstyle=" + this.style); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap\SOAPBindingImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */