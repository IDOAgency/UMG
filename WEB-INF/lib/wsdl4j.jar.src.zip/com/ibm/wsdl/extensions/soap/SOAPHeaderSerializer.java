package com.ibm.wsdl.extensions.soap;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.List;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap.SOAPHeader;
import javax.wsdl.extensions.soap.SOAPHeaderFault;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAPHeaderSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAPHeader sOAPHeader = (SOAPHeader)paramExtensibilityElement;
    if (sOAPHeader != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap/", "header", paramDefinition);
      paramPrintWriter.print("        <" + str);
      DOMUtils.printQualifiedAttribute("message", sOAPHeader.getMessage(), paramDefinition, paramPrintWriter);
      DOMUtils.printAttribute("part", sOAPHeader.getPart(), paramPrintWriter);
      DOMUtils.printAttribute("use", sOAPHeader.getUse(), paramPrintWriter);
      DOMUtils.printAttribute("encodingStyle", StringUtils.getNMTokens(sOAPHeader.getEncodingStyles()), paramPrintWriter);
      DOMUtils.printAttribute("namespace", sOAPHeader.getNamespaceURI(), paramPrintWriter);
      Boolean bool = sOAPHeader.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println('>');
      printSoapHeaderFaults(sOAPHeader.getSOAPHeaderFaults(), paramDefinition, paramPrintWriter);
      paramPrintWriter.println("        </" + str + '>');
    } 
  }
  
  private static void printSoapHeaderFaults(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramList != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap/", "headerfault", paramDefinition);
      for (SOAPHeaderFault sOAPHeaderFault : paramList) {
        if (sOAPHeaderFault != null) {
          paramPrintWriter.print("          <" + str);
          DOMUtils.printQualifiedAttribute("message", sOAPHeaderFault.getMessage(), paramDefinition, paramPrintWriter);
          DOMUtils.printAttribute("part", sOAPHeaderFault.getPart(), paramPrintWriter);
          DOMUtils.printAttribute("use", sOAPHeaderFault.getUse(), paramPrintWriter);
          DOMUtils.printAttribute("encodingStyle", StringUtils.getNMTokens(sOAPHeaderFault.getEncodingStyles()), paramPrintWriter);
          DOMUtils.printAttribute("namespace", sOAPHeaderFault.getNamespaceURI(), paramPrintWriter);
          Boolean bool = sOAPHeaderFault.getRequired();
          if (bool != null)
            DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
          paramPrintWriter.println("/>");
        } 
      } 
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAPHeader sOAPHeader = (SOAPHeader)paramExtensionRegistry.createExtension(paramClass, paramQName);
    QName qName = DOMUtils.getQualifiedAttributeValue(paramElement, "message", "header", false, paramDefinition);
    String str1 = DOMUtils.getAttribute(paramElement, "part");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (qName != null)
      sOAPHeader.setMessage(qName); 
    if (str1 != null)
      sOAPHeader.setPart(str1); 
    if (str2 != null)
      sOAPHeader.setUse(str2); 
    if (str3 != null)
      sOAPHeader.setEncodingStyles(StringUtils.parseNMTokens(str3)); 
    if (str4 != null)
      sOAPHeader.setNamespaceURI(str4); 
    if (str5 != null)
      sOAPHeader.setRequired(new Boolean(str5)); 
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(SOAPConstants.Q_ELEM_SOAP_HEADER_FAULT, element)) {
        sOAPHeader.addSOAPHeaderFault(parseSoapHeaderFault(SOAPHeader.class, SOAPConstants.Q_ELEM_SOAP_HEADER_FAULT, element, paramExtensionRegistry, paramDefinition));
      } else {
        DOMUtils.throwWSDLException(element);
      } 
    } 
    return sOAPHeader;
  }
  
  private static SOAPHeaderFault parseSoapHeaderFault(Class paramClass, QName paramQName, Element paramElement, ExtensionRegistry paramExtensionRegistry, Definition paramDefinition) throws WSDLException {
    SOAPHeaderFault sOAPHeaderFault = (SOAPHeaderFault)paramExtensionRegistry.createExtension(paramClass, paramQName);
    QName qName = DOMUtils.getQualifiedAttributeValue(paramElement, "message", "header", false, paramDefinition);
    String str1 = DOMUtils.getAttribute(paramElement, "part");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (qName != null)
      sOAPHeaderFault.setMessage(qName); 
    if (str1 != null)
      sOAPHeaderFault.setPart(str1); 
    if (str2 != null)
      sOAPHeaderFault.setUse(str2); 
    if (str3 != null)
      sOAPHeaderFault.setEncodingStyles(StringUtils.parseNMTokens(str3)); 
    if (str4 != null)
      sOAPHeaderFault.setNamespaceURI(str4); 
    if (str5 != null)
      sOAPHeaderFault.setRequired(new Boolean(str5)); 
    return sOAPHeaderFault;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap\SOAPHeaderSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */