package com.ibm.wsdl.extensions.schema;

import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaImport;
import javax.wsdl.extensions.schema.SchemaReference;
import javax.wsdl.xml.WSDLLocator;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SchemaDeserializer implements ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  private final Map allReferencedSchemas = new Hashtable();
  
  private static ThreadLocal wsdlLocator = new ThreadLocal();
  
  public static void setLocator(WSDLLocator paramWSDLLocator) { wsdlLocator.set(paramWSDLLocator); }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    Schema schema = (Schema)paramExtensionRegistry.createExtension(paramClass, paramQName);
    schema.setElementType(paramQName);
    schema.setElement(paramElement);
    schema.setDocumentBaseURI(paramDefinition.getDocumentBaseURI());
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      QName qName = QNameUtils.newQName(element);
      SchemaReference schemaReference = null;
      String str = null;
      if (SchemaConstants.XSD_IMPORT_QNAME_LIST.contains(qName)) {
        SchemaImport schemaImport = schema.createImport();
        schemaImport.setId(DOMUtils.getAttribute(element, "id"));
        schemaImport.setNamespaceURI(DOMUtils.getAttribute(element, "namespace"));
        str = DOMUtils.getAttribute(element, "schemaLocation");
        schemaImport.setSchemaLocationURI(str);
        schema.addImport(schemaImport);
      } else if (SchemaConstants.XSD_INCLUDE_QNAME_LIST.contains(qName)) {
        schemaReference = schema.createInclude();
        schemaReference.setId(DOMUtils.getAttribute(element, "id"));
        str = DOMUtils.getAttribute(element, "schemaLocation");
        schemaReference.setSchemaLocationURI(str);
        schema.addInclude(schemaReference);
      } else if (SchemaConstants.XSD_REDEFINE_QNAME_LIST.contains(qName)) {
        schemaReference = schema.createRedefine();
        schemaReference.setId(DOMUtils.getAttribute(element, "id"));
        str = DOMUtils.getAttribute(element, "schemaLocation");
        schemaReference.setSchemaLocationURI(str);
        schema.addRedefine(schemaReference);
      } 
    } 
    return schema;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\schema\SchemaDeserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */