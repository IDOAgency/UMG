package com.ibm.wsdl.extensions.schema;

import javax.wsdl.extensions.schema.SchemaImport;

public class SchemaImportImpl extends SchemaReferenceImpl implements SchemaImport {
  public static final long serialVersionUID = 1L;
  
  private String namespace = null;
  
  public String getNamespaceURI() { return this.namespace; }
  
  public void setNamespaceURI(String paramString) { this.namespace = paramString; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\schema\SchemaImportImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */