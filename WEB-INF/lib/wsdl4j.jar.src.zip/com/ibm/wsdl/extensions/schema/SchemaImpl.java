package com.ibm.wsdl.extensions.schema;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaImport;
import javax.wsdl.extensions.schema.SchemaReference;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SchemaImpl implements Schema {
  protected QName elementType = null;
  
  protected Boolean required = null;
  
  protected Element element = null;
  
  public static final long serialVersionUID = 1L;
  
  private Map imports = new HashMap();
  
  private List includes = new Vector();
  
  private List redefines = new Vector();
  
  private String documentBaseURI = null;
  
  public Map getImports() { return this.imports; }
  
  public SchemaImport createImport() { return new SchemaImportImpl(); }
  
  public void addImport(SchemaImport paramSchemaImport) {
    String str = paramSchemaImport.getNamespaceURI();
    List list = (List)this.imports.get(str);
    if (list == null) {
      list = new Vector();
      this.imports.put(str, list);
    } 
    list.add(paramSchemaImport);
  }
  
  public List getIncludes() { return this.includes; }
  
  public SchemaReference createInclude() { return new SchemaReferenceImpl(); }
  
  public void addInclude(SchemaReference paramSchemaReference) { this.includes.add(paramSchemaReference); }
  
  public List getRedefines() { return this.redefines; }
  
  public SchemaReference createRedefine() { return new SchemaReferenceImpl(); }
  
  public void addRedefine(SchemaReference paramSchemaReference) { this.redefines.add(paramSchemaReference); }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SchemaExtensibilityElement (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.element != null)
      stringBuffer.append("\nelement=" + this.element); 
    return stringBuffer.toString();
  }
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setElement(Element paramElement) { this.element = paramElement; }
  
  public Element getElement() { return this.element; }
  
  public void setDocumentBaseURI(String paramString) { this.documentBaseURI = paramString; }
  
  public String getDocumentBaseURI() { return this.documentBaseURI; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\schema\SchemaImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */