package com.ibm.wsdl.extensions.schema;

import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaReference;

public class SchemaReferenceImpl implements SchemaReference {
  public static final long serialVersionUID = 1L;
  
  private String id = null;
  
  private String schemaLocation = null;
  
  private Schema referencedSchema = null;
  
  public String getId() { return this.id; }
  
  public void setId(String paramString) { this.id = paramString; }
  
  public String getSchemaLocationURI() { return this.schemaLocation; }
  
  public void setSchemaLocationURI(String paramString) { this.schemaLocation = paramString; }
  
  public Schema getReferencedSchema() { return this.referencedSchema; }
  
  public void setReferencedSchema(Schema paramSchema) { this.referencedSchema = paramSchema; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\schema\SchemaReferenceImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */