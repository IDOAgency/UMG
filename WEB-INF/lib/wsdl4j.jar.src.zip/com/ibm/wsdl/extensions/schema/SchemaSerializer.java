package com.ibm.wsdl.extensions.schema;

import com.ibm.wsdl.util.xml.DOM2Writer;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.schema.Schema;
import javax.xml.namespace.QName;

public class SchemaSerializer implements ExtensionSerializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    Schema schema = (Schema)paramExtensibilityElement;
    paramPrintWriter.print("    ");
    DOM2Writer.serializeAsXML(schema.getElement(), paramDefinition.getNamespaces(), paramPrintWriter);
    paramPrintWriter.println();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\schema\SchemaSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */