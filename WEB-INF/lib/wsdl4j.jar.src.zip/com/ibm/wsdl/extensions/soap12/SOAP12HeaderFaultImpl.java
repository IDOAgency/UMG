package com.ibm.wsdl.extensions.soap12;

import javax.wsdl.extensions.soap12.SOAP12HeaderFault;
import javax.xml.namespace.QName;

public class SOAP12HeaderFaultImpl implements SOAP12HeaderFault {
  protected QName elementType = SOAP12Constants.Q_ELEM_SOAP_HEADER_FAULT;
  
  protected Boolean required = null;
  
  protected QName message = null;
  
  protected String part = null;
  
  protected String use = null;
  
  protected String encodingStyle = null;
  
  protected String namespaceURI = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setMessage(QName paramQName) { this.message = paramQName; }
  
  public QName getMessage() { return this.message; }
  
  public void setPart(String paramString) { this.part = paramString; }
  
  public String getPart() { return this.part; }
  
  public void setUse(String paramString) { this.use = paramString; }
  
  public String getUse() { return this.use; }
  
  public void setEncodingStyle(String paramString) { this.encodingStyle = paramString; }
  
  public String getEncodingStyle() { return this.encodingStyle; }
  
  public void setNamespaceURI(String paramString) { this.namespaceURI = paramString; }
  
  public String getNamespaceURI() { return this.namespaceURI; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SOAPHeaderFault (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.message != null)
      stringBuffer.append("\nmessage=" + this.message); 
    if (this.part != null)
      stringBuffer.append("\npart=" + this.part); 
    if (this.use != null)
      stringBuffer.append("\nuse=" + this.use); 
    if (this.encodingStyle != null)
      stringBuffer.append("\nencodingStyles=" + this.encodingStyle); 
    if (this.namespaceURI != null)
      stringBuffer.append("\nnamespaceURI=" + this.namespaceURI); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12HeaderFaultImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */