package com.ibm.wsdl.extensions.soap12;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.List;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap12.SOAP12Header;
import javax.wsdl.extensions.soap12.SOAP12HeaderFault;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAP12HeaderSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Header sOAP12Header = (SOAP12Header)paramExtensibilityElement;
    if (sOAP12Header != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap12/", "header", paramDefinition);
      paramPrintWriter.print("        <" + str);
      DOMUtils.printQualifiedAttribute("message", sOAP12Header.getMessage(), paramDefinition, paramPrintWriter);
      DOMUtils.printAttribute("part", sOAP12Header.getPart(), paramPrintWriter);
      DOMUtils.printAttribute("use", sOAP12Header.getUse(), paramPrintWriter);
      DOMUtils.printAttribute("encodingStyle", sOAP12Header.getEncodingStyle(), paramPrintWriter);
      DOMUtils.printAttribute("namespace", sOAP12Header.getNamespaceURI(), paramPrintWriter);
      Boolean bool = sOAP12Header.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println('>');
      printSoapHeaderFaults(sOAP12Header.getSOAP12HeaderFaults(), paramDefinition, paramPrintWriter);
      paramPrintWriter.println("        </" + str + '>');
    } 
  }
  
  private static void printSoapHeaderFaults(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramList != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap12/", "headerfault", paramDefinition);
      for (SOAP12HeaderFault sOAP12HeaderFault : paramList) {
        if (sOAP12HeaderFault != null) {
          paramPrintWriter.print("          <" + str);
          DOMUtils.printQualifiedAttribute("message", sOAP12HeaderFault.getMessage(), paramDefinition, paramPrintWriter);
          DOMUtils.printAttribute("part", sOAP12HeaderFault.getPart(), paramPrintWriter);
          DOMUtils.printAttribute("use", sOAP12HeaderFault.getUse(), paramPrintWriter);
          DOMUtils.printAttribute("encodingStyle", sOAP12HeaderFault.getEncodingStyle(), paramPrintWriter);
          DOMUtils.printAttribute("namespace", sOAP12HeaderFault.getNamespaceURI(), paramPrintWriter);
          Boolean bool = sOAP12HeaderFault.getRequired();
          if (bool != null)
            DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
          paramPrintWriter.println("/>");
        } 
      } 
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Header sOAP12Header = (SOAP12Header)paramExtensionRegistry.createExtension(paramClass, paramQName);
    QName qName = DOMUtils.getQualifiedAttributeValue(paramElement, "message", "header", false, paramDefinition);
    String str1 = DOMUtils.getAttribute(paramElement, "part");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (qName != null)
      sOAP12Header.setMessage(qName); 
    if (str1 != null)
      sOAP12Header.setPart(str1); 
    if (str2 != null)
      sOAP12Header.setUse(str2); 
    if (str3 != null)
      sOAP12Header.setEncodingStyle(str3); 
    if (str4 != null)
      sOAP12Header.setNamespaceURI(str4); 
    if (str5 != null)
      sOAP12Header.setRequired(new Boolean(str5)); 
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(SOAP12Constants.Q_ELEM_SOAP_HEADER_FAULT, element)) {
        sOAP12Header.addSOAP12HeaderFault(parseSoapHeaderFault(SOAP12Header.class, SOAP12Constants.Q_ELEM_SOAP_HEADER_FAULT, element, paramExtensionRegistry, paramDefinition));
      } else {
        DOMUtils.throwWSDLException(element);
      } 
    } 
    return sOAP12Header;
  }
  
  private static SOAP12HeaderFault parseSoapHeaderFault(Class paramClass, QName paramQName, Element paramElement, ExtensionRegistry paramExtensionRegistry, Definition paramDefinition) throws WSDLException {
    SOAP12HeaderFault sOAP12HeaderFault = (SOAP12HeaderFault)paramExtensionRegistry.createExtension(paramClass, paramQName);
    QName qName = DOMUtils.getQualifiedAttributeValue(paramElement, "message", "header", false, paramDefinition);
    String str1 = DOMUtils.getAttribute(paramElement, "part");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (qName != null)
      sOAP12HeaderFault.setMessage(qName); 
    if (str1 != null)
      sOAP12HeaderFault.setPart(str1); 
    if (str2 != null)
      sOAP12HeaderFault.setUse(str2); 
    if (str3 != null)
      sOAP12HeaderFault.setEncodingStyle(str3); 
    if (str4 != null)
      sOAP12HeaderFault.setNamespaceURI(str4); 
    if (str5 != null)
      sOAP12HeaderFault.setRequired(new Boolean(str5)); 
    return sOAP12HeaderFault;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12HeaderSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */