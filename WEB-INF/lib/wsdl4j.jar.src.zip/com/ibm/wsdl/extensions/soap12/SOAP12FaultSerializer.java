package com.ibm.wsdl.extensions.soap12;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap12.SOAP12Fault;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAP12FaultSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Fault sOAP12Fault = (SOAP12Fault)paramExtensibilityElement;
    if (sOAP12Fault != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap12/", "fault", paramDefinition);
      paramPrintWriter.print("        <" + str);
      DOMUtils.printAttribute("name", sOAP12Fault.getName(), paramPrintWriter);
      DOMUtils.printAttribute("use", sOAP12Fault.getUse(), paramPrintWriter);
      DOMUtils.printAttribute("encodingStyle", sOAP12Fault.getEncodingStyle(), paramPrintWriter);
      DOMUtils.printAttribute("namespace", sOAP12Fault.getNamespaceURI(), paramPrintWriter);
      Boolean bool = sOAP12Fault.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println("/>");
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Fault sOAP12Fault = (SOAP12Fault)paramExtensionRegistry.createExtension(paramClass, paramQName);
    QName qName = DOMUtils.getQualifiedAttributeValue(paramElement, "message", "header", false, paramDefinition);
    String str1 = DOMUtils.getAttribute(paramElement, "name");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      sOAP12Fault.setName(str1); 
    if (str2 != null)
      sOAP12Fault.setUse(str2); 
    if (str3 != null)
      sOAP12Fault.setEncodingStyle(str3); 
    if (str4 != null)
      sOAP12Fault.setNamespaceURI(str4); 
    if (str5 != null)
      sOAP12Fault.setRequired(new Boolean(str5)); 
    return sOAP12Fault;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12FaultSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */