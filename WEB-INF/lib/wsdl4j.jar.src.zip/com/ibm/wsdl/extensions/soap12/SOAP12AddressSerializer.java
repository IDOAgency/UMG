package com.ibm.wsdl.extensions.soap12;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap12.SOAP12Address;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAP12AddressSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Address sOAP12Address = (SOAP12Address)paramExtensibilityElement;
    if (sOAP12Address != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap12/", "address", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("location", sOAP12Address.getLocationURI(), paramPrintWriter);
      Boolean bool = sOAP12Address.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println("/>");
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Address sOAP12Address = (SOAP12Address)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str1 = DOMUtils.getAttribute(paramElement, "location");
    String str2 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      sOAP12Address.setLocationURI(str1); 
    if (str2 != null)
      sOAP12Address.setRequired(new Boolean(str2)); 
    return sOAP12Address;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12AddressSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */