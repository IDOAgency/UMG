package com.ibm.wsdl.extensions.soap12;

import javax.wsdl.extensions.soap12.SOAP12Operation;
import javax.xml.namespace.QName;

public class SOAP12OperationImpl implements SOAP12Operation {
  protected QName elementType = SOAP12Constants.Q_ELEM_SOAP_OPERATION;
  
  protected Boolean required = null;
  
  protected String soapActionURI = null;
  
  protected Boolean soapActionRequired = null;
  
  protected String style = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setSoapActionURI(String paramString) { this.soapActionURI = paramString; }
  
  public String getSoapActionURI() { return this.soapActionURI; }
  
  public void setSoapActionRequired(Boolean paramBoolean) { this.soapActionRequired = paramBoolean; }
  
  public Boolean getSoapActionRequired() { return this.soapActionRequired; }
  
  public void setStyle(String paramString) { this.style = paramString; }
  
  public String getStyle() { return this.style; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SOAPOperation (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.soapActionURI != null)
      stringBuffer.append("\nsoapActionURI=" + this.soapActionURI); 
    if (this.soapActionRequired != null)
      stringBuffer.append("\nsoapActionRequired=" + this.soapActionRequired); 
    if (this.style != null)
      stringBuffer.append("\nstyle=" + this.style); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12OperationImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */