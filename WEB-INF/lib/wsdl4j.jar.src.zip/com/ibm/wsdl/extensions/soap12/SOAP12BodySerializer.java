package com.ibm.wsdl.extensions.soap12;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap12.SOAP12Body;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAP12BodySerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Body sOAP12Body = (SOAP12Body)paramExtensibilityElement;
    if (sOAP12Body != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap12/", "body", paramDefinition);
      if (paramClass != null && javax.wsdl.extensions.mime.MIMEPart.class.isAssignableFrom(paramClass))
        paramPrintWriter.print("    "); 
      paramPrintWriter.print("        <" + str);
      DOMUtils.printAttribute("parts", StringUtils.getNMTokens(sOAP12Body.getParts()), paramPrintWriter);
      DOMUtils.printAttribute("use", sOAP12Body.getUse(), paramPrintWriter);
      DOMUtils.printAttribute("encodingStyle", sOAP12Body.getEncodingStyle(), paramPrintWriter);
      DOMUtils.printAttribute("namespace", sOAP12Body.getNamespaceURI(), paramPrintWriter);
      Boolean bool = sOAP12Body.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println("/>");
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Body sOAP12Body = (SOAP12Body)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str1 = DOMUtils.getAttribute(paramElement, "parts");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      sOAP12Body.setParts(StringUtils.parseNMTokens(str1)); 
    if (str2 != null)
      sOAP12Body.setUse(str2); 
    if (str3 != null)
      sOAP12Body.setEncodingStyle(str3); 
    if (str4 != null)
      sOAP12Body.setNamespaceURI(str4); 
    if (str5 != null)
      sOAP12Body.setRequired(new Boolean(str5)); 
    return sOAP12Body;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12BodySerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */