package com.ibm.wsdl.extensions.soap12;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap12.SOAP12Operation;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAP12OperationSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Operation sOAP12Operation = (SOAP12Operation)paramExtensibilityElement;
    if (sOAP12Operation != null) {
      String str1 = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap12/", "operation", paramDefinition);
      paramPrintWriter.print("      <" + str1);
      Boolean bool1 = sOAP12Operation.getSoapActionRequired();
      String str2 = (bool1 == null) ? null : bool1.toString();
      DOMUtils.printAttribute("soapAction", sOAP12Operation.getSoapActionURI(), paramPrintWriter);
      DOMUtils.printAttribute("soapActionRequired", str2, paramPrintWriter);
      DOMUtils.printAttribute("style", sOAP12Operation.getStyle(), paramPrintWriter);
      Boolean bool2 = sOAP12Operation.getRequired();
      if (bool2 != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool2.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println("/>");
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Operation sOAP12Operation = (SOAP12Operation)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str1 = DOMUtils.getAttribute(paramElement, "soapAction");
    String str2 = DOMUtils.getAttribute(paramElement, "soapActionRequired");
    String str3 = DOMUtils.getAttribute(paramElement, "style");
    String str4 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      sOAP12Operation.setSoapActionURI(str1); 
    if (str2 != null) {
      Boolean bool = new Boolean(str2);
      sOAP12Operation.setSoapActionRequired(bool);
    } 
    if (str3 != null)
      sOAP12Operation.setStyle(str3); 
    if (str4 != null)
      sOAP12Operation.setRequired(new Boolean(str4)); 
    return sOAP12Operation;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12OperationSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */