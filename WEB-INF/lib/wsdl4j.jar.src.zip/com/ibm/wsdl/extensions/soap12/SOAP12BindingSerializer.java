package com.ibm.wsdl.extensions.soap12;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap12.SOAP12Binding;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAP12BindingSerializer implements ExtensionSerializer, ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Binding sOAP12Binding = (SOAP12Binding)paramExtensibilityElement;
    if (sOAP12Binding != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap12/", "binding", paramDefinition);
      paramPrintWriter.print("    <" + str);
      DOMUtils.printAttribute("style", sOAP12Binding.getStyle(), paramPrintWriter);
      DOMUtils.printAttribute("transport", sOAP12Binding.getTransportURI(), paramPrintWriter);
      Boolean bool = sOAP12Binding.getRequired();
      if (bool != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, bool.toString(), paramDefinition, paramPrintWriter); 
      paramPrintWriter.println("/>");
    } 
  }
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    SOAP12Binding sOAP12Binding = (SOAP12Binding)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str1 = DOMUtils.getAttribute(paramElement, "transport");
    String str2 = DOMUtils.getAttribute(paramElement, "style");
    String str3 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      sOAP12Binding.setTransportURI(str1); 
    if (str2 != null)
      sOAP12Binding.setStyle(str2); 
    if (str3 != null)
      sOAP12Binding.setRequired(new Boolean(str3)); 
    return sOAP12Binding;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12BindingSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */