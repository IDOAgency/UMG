package com.ibm.wsdl.extensions.soap12;

import javax.wsdl.extensions.soap12.SOAP12Fault;
import javax.xml.namespace.QName;

public class SOAP12FaultImpl implements SOAP12Fault {
  protected QName elementType = SOAP12Constants.Q_ELEM_SOAP_FAULT;
  
  protected Boolean required = null;
  
  protected String name = null;
  
  protected String use = null;
  
  protected String encodingStyle = null;
  
  protected String namespaceURI = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setUse(String paramString) { this.use = paramString; }
  
  public String getUse() { return this.use; }
  
  public void setEncodingStyle(String paramString) { this.encodingStyle = paramString; }
  
  public String getEncodingStyle() { return this.encodingStyle; }
  
  public void setNamespaceURI(String paramString) { this.namespaceURI = paramString; }
  
  public String getNamespaceURI() { return this.namespaceURI; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("SOAPFault (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.name != null)
      stringBuffer.append("\nname=" + this.name); 
    if (this.use != null)
      stringBuffer.append("\nuse=" + this.use); 
    if (this.encodingStyle != null)
      stringBuffer.append("\nencodingStyle=" + this.encodingStyle); 
    if (this.namespaceURI != null)
      stringBuffer.append("\nnamespaceURI=" + this.namespaceURI); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\extensions\soap12\SOAP12FaultImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */