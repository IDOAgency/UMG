package com.ibm.wsdl;

import java.util.Arrays;
import java.util.List;
import javax.wsdl.Input;
import javax.wsdl.Message;

public class InputImpl extends AbstractWSDLElement implements Input {
  protected String name = null;
  
  protected Message message = null;
  
  protected List nativeAttributeNames = Arrays.asList(Constants.INPUT_ATTR_NAMES);
  
  public static final long serialVersionUID = 1L;
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setMessage(Message paramMessage) { this.message = paramMessage; }
  
  public Message getMessage() { return this.message; }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Input: name=" + this.name);
    if (this.message != null)
      stringBuffer.append("\n" + this.message); 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\InputImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */