package com.ibm.wsdl.factory;

import com.ibm.wsdl.DefinitionImpl;
import com.ibm.wsdl.extensions.PopulatedExtensionRegistry;
import com.ibm.wsdl.xml.WSDLReaderImpl;
import com.ibm.wsdl.xml.WSDLWriterImpl;
import javax.wsdl.Definition;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLReader;
import javax.wsdl.xml.WSDLWriter;

public class WSDLFactoryImpl extends WSDLFactory {
  public Definition newDefinition() {
    DefinitionImpl definitionImpl = new DefinitionImpl();
    ExtensionRegistry extensionRegistry = newPopulatedExtensionRegistry();
    definitionImpl.setExtensionRegistry(extensionRegistry);
    return definitionImpl;
  }
  
  public WSDLReader newWSDLReader() { return new WSDLReaderImpl(); }
  
  public WSDLWriter newWSDLWriter() { return new WSDLWriterImpl(); }
  
  public ExtensionRegistry newPopulatedExtensionRegistry() { return new PopulatedExtensionRegistry(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\factory\WSDLFactoryImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */