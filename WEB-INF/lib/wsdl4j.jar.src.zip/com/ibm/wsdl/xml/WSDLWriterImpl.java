package com.ibm.wsdl.xml;

import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOM2Writer;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.wsdl.Binding;
import javax.wsdl.BindingFault;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Definition;
import javax.wsdl.Fault;
import javax.wsdl.Import;
import javax.wsdl.Input;
import javax.wsdl.Message;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.Output;
import javax.wsdl.Part;
import javax.wsdl.Port;
import javax.wsdl.PortType;
import javax.wsdl.Service;
import javax.wsdl.Types;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.AttributeExtensible;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLReader;
import javax.wsdl.xml.WSDLWriter;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

public class WSDLWriterImpl implements WSDLWriter {
  public void setFeature(String paramString, boolean paramBoolean) throws IllegalArgumentException {
    if (paramString == null)
      throw new IllegalArgumentException("Feature name must not be null."); 
    throw new IllegalArgumentException("Feature name '" + paramString + "' not recognized.");
  }
  
  public boolean getFeature(String paramString) throws IllegalArgumentException {
    if (paramString == null)
      throw new IllegalArgumentException("Feature name must not be null."); 
    throw new IllegalArgumentException("Feature name '" + paramString + "' not recognized.");
  }
  
  protected void printDefinition(Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramDefinition == null)
      return; 
    if (paramDefinition.getPrefix("http://schemas.xmlsoap.org/wsdl/") == null) {
      String str = "wsdl";
      byte b = 0;
      while (paramDefinition.getNamespace(str) != null)
        str = "wsdl" + b++; 
      paramDefinition.addNamespace(str, "http://schemas.xmlsoap.org/wsdl/");
    } 
    String str1 = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "definitions", paramDefinition);
    paramPrintWriter.print('<' + str1);
    QName qName = paramDefinition.getQName();
    String str2 = paramDefinition.getTargetNamespace();
    Map map = paramDefinition.getNamespaces();
    if (qName != null)
      DOMUtils.printAttribute("name", qName.getLocalPart(), paramPrintWriter); 
    DOMUtils.printAttribute("targetNamespace", str2, paramPrintWriter);
    printExtensibilityAttributes(Definition.class, paramDefinition, paramDefinition, paramPrintWriter);
    printNamespaceDeclarations(map, paramPrintWriter);
    paramPrintWriter.println('>');
    printDocumentation(paramDefinition.getDocumentationElement(), paramDefinition, paramPrintWriter);
    printImports(paramDefinition.getImports(), paramDefinition, paramPrintWriter);
    printTypes(paramDefinition.getTypes(), paramDefinition, paramPrintWriter);
    printMessages(paramDefinition.getMessages(), paramDefinition, paramPrintWriter);
    printPortTypes(paramDefinition.getPortTypes(), paramDefinition, paramPrintWriter);
    printBindings(paramDefinition.getBindings(), paramDefinition, paramPrintWriter);
    printServices(paramDefinition.getServices(), paramDefinition, paramPrintWriter);
    List list = paramDefinition.getExtensibilityElements();
    printExtensibilityElements(Definition.class, list, paramDefinition, paramPrintWriter);
    paramPrintWriter.println("</" + str1 + '>');
    paramPrintWriter.flush();
  }
  
  protected void printServices(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "service", paramDefinition);
      for (Service service : paramMap.values()) {
        paramPrintWriter.print("  <" + str);
        QName qName = service.getQName();
        if (qName != null)
          DOMUtils.printAttribute("name", qName.getLocalPart(), paramPrintWriter); 
        printExtensibilityAttributes(Service.class, service, paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(service.getDocumentationElement(), paramDefinition, paramPrintWriter);
        printPorts(service.getPorts(), paramDefinition, paramPrintWriter);
        List list = service.getExtensibilityElements();
        printExtensibilityElements(Service.class, list, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("  </" + str + '>');
      } 
    } 
  }
  
  protected void printPorts(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "port", paramDefinition);
      for (Port port : paramMap.values()) {
        paramPrintWriter.print("    <" + str);
        DOMUtils.printAttribute("name", port.getName(), paramPrintWriter);
        Binding binding = port.getBinding();
        if (binding != null)
          DOMUtils.printQualifiedAttribute("binding", binding.getQName(), paramDefinition, paramPrintWriter); 
        printExtensibilityAttributes(Port.class, port, paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(port.getDocumentationElement(), paramDefinition, paramPrintWriter);
        List list = port.getExtensibilityElements();
        printExtensibilityElements(Port.class, list, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("    </" + str + '>');
      } 
    } 
  }
  
  protected void printBindings(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "binding", paramDefinition);
      for (Binding binding : paramMap.values()) {
        if (!binding.isUndefined()) {
          paramPrintWriter.print("  <" + str);
          QName qName = binding.getQName();
          if (qName != null)
            DOMUtils.printAttribute("name", qName.getLocalPart(), paramPrintWriter); 
          PortType portType = binding.getPortType();
          if (portType != null)
            DOMUtils.printQualifiedAttribute("type", portType.getQName(), paramDefinition, paramPrintWriter); 
          paramPrintWriter.println('>');
          printDocumentation(binding.getDocumentationElement(), paramDefinition, paramPrintWriter);
          List list = binding.getExtensibilityElements();
          printExtensibilityElements(Binding.class, list, paramDefinition, paramPrintWriter);
          printBindingOperations(binding.getBindingOperations(), paramDefinition, paramPrintWriter);
          paramPrintWriter.println("  </" + str + '>');
        } 
      } 
    } 
  }
  
  protected void printBindingOperations(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramList != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "operation", paramDefinition);
      for (BindingOperation bindingOperation : paramList) {
        paramPrintWriter.print("    <" + str);
        DOMUtils.printAttribute("name", bindingOperation.getName(), paramPrintWriter);
        printExtensibilityAttributes(BindingOperation.class, bindingOperation, paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(bindingOperation.getDocumentationElement(), paramDefinition, paramPrintWriter);
        List list = bindingOperation.getExtensibilityElements();
        printExtensibilityElements(BindingOperation.class, list, paramDefinition, paramPrintWriter);
        printBindingInput(bindingOperation.getBindingInput(), paramDefinition, paramPrintWriter);
        printBindingOutput(bindingOperation.getBindingOutput(), paramDefinition, paramPrintWriter);
        printBindingFaults(bindingOperation.getBindingFaults(), paramDefinition, paramPrintWriter);
        paramPrintWriter.println("    </" + str + '>');
      } 
    } 
  }
  
  protected void printBindingInput(BindingInput paramBindingInput, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramBindingInput != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "input", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("name", paramBindingInput.getName(), paramPrintWriter);
      printExtensibilityAttributes(BindingInput.class, paramBindingInput, paramDefinition, paramPrintWriter);
      paramPrintWriter.println('>');
      printDocumentation(paramBindingInput.getDocumentationElement(), paramDefinition, paramPrintWriter);
      List list = paramBindingInput.getExtensibilityElements();
      printExtensibilityElements(BindingInput.class, list, paramDefinition, paramPrintWriter);
      paramPrintWriter.println("      </" + str + '>');
    } 
  }
  
  protected void printBindingOutput(BindingOutput paramBindingOutput, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramBindingOutput != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "output", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("name", paramBindingOutput.getName(), paramPrintWriter);
      paramPrintWriter.println('>');
      printDocumentation(paramBindingOutput.getDocumentationElement(), paramDefinition, paramPrintWriter);
      List list = paramBindingOutput.getExtensibilityElements();
      printExtensibilityElements(BindingOutput.class, list, paramDefinition, paramPrintWriter);
      paramPrintWriter.println("      </" + str + '>');
    } 
  }
  
  protected void printBindingFaults(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "fault", paramDefinition);
      for (BindingFault bindingFault : paramMap.values()) {
        paramPrintWriter.print("      <" + str);
        DOMUtils.printAttribute("name", bindingFault.getName(), paramPrintWriter);
        printExtensibilityAttributes(BindingFault.class, bindingFault, paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(bindingFault.getDocumentationElement(), paramDefinition, paramPrintWriter);
        List list = bindingFault.getExtensibilityElements();
        printExtensibilityElements(BindingFault.class, list, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("      </" + str + '>');
      } 
    } 
  }
  
  protected void printPortTypes(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "portType", paramDefinition);
      for (PortType portType : paramMap.values()) {
        if (!portType.isUndefined()) {
          paramPrintWriter.print("  <" + str);
          QName qName = portType.getQName();
          if (qName != null)
            DOMUtils.printAttribute("name", qName.getLocalPart(), paramPrintWriter); 
          printExtensibilityAttributes(PortType.class, portType, paramDefinition, paramPrintWriter);
          paramPrintWriter.println('>');
          printDocumentation(portType.getDocumentationElement(), paramDefinition, paramPrintWriter);
          printOperations(portType.getOperations(), paramDefinition, paramPrintWriter);
          List list = portType.getExtensibilityElements();
          printExtensibilityElements(PortType.class, list, paramDefinition, paramPrintWriter);
          paramPrintWriter.println("  </" + str + '>');
        } 
      } 
    } 
  }
  
  protected void printOperations(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramList != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "operation", paramDefinition);
      for (Operation operation : paramList) {
        if (!operation.isUndefined()) {
          paramPrintWriter.print("    <" + str);
          DOMUtils.printAttribute("name", operation.getName(), paramPrintWriter);
          DOMUtils.printAttribute("parameterOrder", StringUtils.getNMTokens(operation.getParameterOrdering()), paramPrintWriter);
          printExtensibilityAttributes(Operation.class, operation, paramDefinition, paramPrintWriter);
          paramPrintWriter.println('>');
          printDocumentation(operation.getDocumentationElement(), paramDefinition, paramPrintWriter);
          OperationType operationType = operation.getStyle();
          if (operationType == OperationType.ONE_WAY) {
            printInput(operation.getInput(), paramDefinition, paramPrintWriter);
          } else if (operationType == OperationType.SOLICIT_RESPONSE) {
            printOutput(operation.getOutput(), paramDefinition, paramPrintWriter);
            printInput(operation.getInput(), paramDefinition, paramPrintWriter);
          } else if (operationType == OperationType.NOTIFICATION) {
            printOutput(operation.getOutput(), paramDefinition, paramPrintWriter);
          } else {
            printInput(operation.getInput(), paramDefinition, paramPrintWriter);
            printOutput(operation.getOutput(), paramDefinition, paramPrintWriter);
          } 
          printFaults(operation.getFaults(), paramDefinition, paramPrintWriter);
          List list = operation.getExtensibilityElements();
          printExtensibilityElements(Operation.class, list, paramDefinition, paramPrintWriter);
          paramPrintWriter.println("    </" + str + '>');
        } 
      } 
    } 
  }
  
  protected void printInput(Input paramInput, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramInput != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "input", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("name", paramInput.getName(), paramPrintWriter);
      Message message = paramInput.getMessage();
      if (message != null)
        DOMUtils.printQualifiedAttribute("message", message.getQName(), paramDefinition, paramPrintWriter); 
      printExtensibilityAttributes(Input.class, paramInput, paramDefinition, paramPrintWriter);
      paramPrintWriter.println('>');
      printDocumentation(paramInput.getDocumentationElement(), paramDefinition, paramPrintWriter);
      List list = paramInput.getExtensibilityElements();
      printExtensibilityElements(Input.class, list, paramDefinition, paramPrintWriter);
      paramPrintWriter.println("    </" + str + '>');
    } 
  }
  
  protected void printOutput(Output paramOutput, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramOutput != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "output", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("name", paramOutput.getName(), paramPrintWriter);
      Message message = paramOutput.getMessage();
      if (message != null)
        DOMUtils.printQualifiedAttribute("message", message.getQName(), paramDefinition, paramPrintWriter); 
      printExtensibilityAttributes(Output.class, paramOutput, paramDefinition, paramPrintWriter);
      paramPrintWriter.println('>');
      printDocumentation(paramOutput.getDocumentationElement(), paramDefinition, paramPrintWriter);
      List list = paramOutput.getExtensibilityElements();
      printExtensibilityElements(Output.class, list, paramDefinition, paramPrintWriter);
      paramPrintWriter.println("    </" + str + '>');
    } 
  }
  
  protected void printFaults(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "fault", paramDefinition);
      for (Fault fault : paramMap.values()) {
        paramPrintWriter.print("      <" + str);
        DOMUtils.printAttribute("name", fault.getName(), paramPrintWriter);
        Message message = fault.getMessage();
        if (message != null)
          DOMUtils.printQualifiedAttribute("message", message.getQName(), paramDefinition, paramPrintWriter); 
        printExtensibilityAttributes(Fault.class, fault, paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(fault.getDocumentationElement(), paramDefinition, paramPrintWriter);
        List list = fault.getExtensibilityElements();
        printExtensibilityElements(Fault.class, list, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("    </" + str + '>');
      } 
    } 
  }
  
  protected void printMessages(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "message", paramDefinition);
      for (Message message : paramMap.values()) {
        if (!message.isUndefined()) {
          paramPrintWriter.print("  <" + str);
          QName qName = message.getQName();
          if (qName != null)
            DOMUtils.printAttribute("name", qName.getLocalPart(), paramPrintWriter); 
          printExtensibilityAttributes(Message.class, message, paramDefinition, paramPrintWriter);
          paramPrintWriter.println('>');
          printDocumentation(message.getDocumentationElement(), paramDefinition, paramPrintWriter);
          printParts(message.getOrderedParts(null), paramDefinition, paramPrintWriter);
          List list = message.getExtensibilityElements();
          printExtensibilityElements(Message.class, list, paramDefinition, paramPrintWriter);
          paramPrintWriter.println("  </" + str + '>');
        } 
      } 
    } 
  }
  
  protected void printParts(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramList != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "part", paramDefinition);
      for (Part part : paramList) {
        paramPrintWriter.print("    <" + str);
        DOMUtils.printAttribute("name", part.getName(), paramPrintWriter);
        DOMUtils.printQualifiedAttribute("element", part.getElementName(), paramDefinition, paramPrintWriter);
        DOMUtils.printQualifiedAttribute("type", part.getTypeName(), paramDefinition, paramPrintWriter);
        printExtensibilityAttributes(Part.class, part, paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(part.getDocumentationElement(), paramDefinition, paramPrintWriter);
        List list = part.getExtensibilityElements();
        printExtensibilityElements(Part.class, list, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("    </" + str + '>');
      } 
    } 
  }
  
  protected void printExtensibilityAttributes(Class paramClass, AttributeExtensible paramAttributeExtensible, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    Map map = paramAttributeExtensible.getExtensionAttributes();
    for (QName qName1 : map.keySet()) {
      Object object = map.get(qName1);
      String str = null;
      QName qName2 = null;
      if (object instanceof String) {
        str = (String)object;
      } else if (object instanceof QName) {
        qName2 = (QName)object;
      } else if (object instanceof List) {
        List list = (List)object;
        int i = list.size();
        if (i > 0) {
          Object object1 = list.get(0);
          if (object1 instanceof String) {
            str = StringUtils.getNMTokens(list);
          } else if (object1 instanceof QName) {
            StringBuffer stringBuffer = new StringBuffer();
            for (byte b = 0; b < i; b++) {
              QName qName = (QName)list.get(b);
              stringBuffer.append(((b > 0) ? " " : "") + DOMUtils.getQualifiedValue(qName.getNamespaceURI(), qName.getLocalPart(), paramDefinition));
            } 
            str = stringBuffer.toString();
          } else {
            throw new WSDLException("CONFIGURATION_ERROR", "Unknown type of extension attribute '" + qName1 + "': " + object1.getClass().getName());
          } 
        } else {
          str = "";
        } 
      } else {
        throw new WSDLException("CONFIGURATION_ERROR", "Unknown type of extension attribute '" + qName1 + "': " + object.getClass().getName());
      } 
      if (qName2 != null) {
        DOMUtils.printQualifiedAttribute(qName1, qName2, paramDefinition, paramPrintWriter);
        continue;
      } 
      DOMUtils.printQualifiedAttribute(qName1, str, paramDefinition, paramPrintWriter);
    } 
  }
  
  protected void printDocumentation(Element paramElement, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramElement != null) {
      DOM2Writer.serializeAsXML(paramElement, paramDefinition.getNamespaces(), paramPrintWriter);
      paramPrintWriter.println();
    } 
  }
  
  protected void printTypes(Types paramTypes, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramTypes != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "types", paramDefinition);
      paramPrintWriter.print("  <" + str);
      printExtensibilityAttributes(Types.class, paramTypes, paramDefinition, paramPrintWriter);
      paramPrintWriter.println('>');
      printDocumentation(paramTypes.getDocumentationElement(), paramDefinition, paramPrintWriter);
      List list = paramTypes.getExtensibilityElements();
      printExtensibilityElements(Types.class, list, paramDefinition, paramPrintWriter);
      paramPrintWriter.println("  </" + str + '>');
    } 
  }
  
  protected void printImports(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "import", paramDefinition);
      for (List list : paramMap.values()) {
        for (Import import : list) {
          paramPrintWriter.print("  <" + str);
          DOMUtils.printAttribute("namespace", import.getNamespaceURI(), paramPrintWriter);
          DOMUtils.printAttribute("location", import.getLocationURI(), paramPrintWriter);
          printExtensibilityAttributes(Import.class, import, paramDefinition, paramPrintWriter);
          paramPrintWriter.println('>');
          printDocumentation(import.getDocumentationElement(), paramDefinition, paramPrintWriter);
          List list1 = import.getExtensibilityElements();
          printExtensibilityElements(Import.class, list1, paramDefinition, paramPrintWriter);
          paramPrintWriter.println("    </" + str + '>');
        } 
      } 
    } 
  }
  
  protected void printNamespaceDeclarations(Map paramMap, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramMap != null) {
      Set set = paramMap.keySet();
      for (String str : set) {
        if (str == null)
          str = ""; 
        DOMUtils.printAttribute("xmlns" + (!str.equals("") ? (":" + str) : ""), (String)paramMap.get(str), paramPrintWriter);
      } 
    } 
  }
  
  protected void printExtensibilityElements(Class paramClass, List paramList, Definition paramDefinition, PrintWriter paramPrintWriter) throws WSDLException {
    if (paramList != null)
      for (ExtensibilityElement extensibilityElement : paramList) {
        QName qName = extensibilityElement.getElementType();
        ExtensionRegistry extensionRegistry = paramDefinition.getExtensionRegistry();
        if (extensionRegistry == null)
          throw new WSDLException("CONFIGURATION_ERROR", "No ExtensionRegistry set for this Definition, so unable to serialize a '" + qName + "' element in the context of a '" + paramClass.getName() + "'."); 
        ExtensionSerializer extensionSerializer = extensionRegistry.querySerializer(paramClass, qName);
        extensionSerializer.marshall(paramClass, qName, extensibilityElement, paramPrintWriter, paramDefinition, extensionRegistry);
      }  
  }
  
  private static Document getDocument(InputSource paramInputSource, String paramString) throws WSDLException {
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    documentBuilderFactory.setNamespaceAware(true);
    documentBuilderFactory.setValidating(false);
    try {
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      return documentBuilder.parse(paramInputSource);
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (Exception exception) {
      throw new WSDLException("PARSER_ERROR", "Problem parsing '" + paramString + "'.", exception);
    } 
  }
  
  public Document getDocument(Definition paramDefinition) throws WSDLException {
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    writeWSDL(paramDefinition, printWriter);
    StringReader stringReader = new StringReader(stringWriter.toString());
    InputSource inputSource = new InputSource(stringReader);
    return getDocument(inputSource, "- WSDL Document -");
  }
  
  public void writeWSDL(Definition paramDefinition, Writer paramWriter) throws WSDLException {
    PrintWriter printWriter = new PrintWriter(paramWriter);
    String str1 = (paramWriter instanceof OutputStreamWriter) ? ((OutputStreamWriter)paramWriter).getEncoding() : null;
    String str2 = DOM2Writer.java2XMLEncoding(str1);
    if (str2 == null)
      throw new WSDLException("CONFIGURATION_ERROR", "Unsupported Java encoding for writing wsdl file: '" + str1 + "'."); 
    printWriter.println("<?xml version=\"1.0\" encoding=\"" + str2 + "\"?>");
    printDefinition(paramDefinition, printWriter);
  }
  
  public void writeWSDL(Definition paramDefinition, OutputStream paramOutputStream) throws WSDLException {
    OutputStreamWriter outputStreamWriter = null;
    try {
      outputStreamWriter = new OutputStreamWriter(paramOutputStream, "UTF8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      unsupportedEncodingException.printStackTrace();
      outputStreamWriter = new OutputStreamWriter(paramOutputStream);
    } 
    writeWSDL(paramDefinition, outputStreamWriter);
  }
  
  public static void main(String[] paramArrayOfString) throws WSDLException {
    if (paramArrayOfString.length == 1) {
      WSDLFactory wSDLFactory = WSDLFactory.newInstance();
      WSDLReader wSDLReader = wSDLFactory.newWSDLReader();
      WSDLWriter wSDLWriter = wSDLFactory.newWSDLWriter();
      wSDLWriter.writeWSDL(wSDLReader.readWSDL(null, paramArrayOfString[0]), System.out);
    } else {
      System.err.println("Usage:");
      System.err.println();
      System.err.println("  java " + WSDLWriterImpl.class.getName() + " filename|URL");
      System.err.println();
      System.err.println("This test driver simply reads a WSDL document into a model (using a WSDLReader), and then serializes it back to standard out. In effect, it performs a round-trip test on the specified WSDL document.");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\xml\WSDLWriterImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */