package com.ibm.wsdl.xml;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.extensions.schema.SchemaConstants;
import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import com.ibm.wsdl.util.xml.XPathUtils;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.Binding;
import javax.wsdl.BindingFault;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Definition;
import javax.wsdl.Fault;
import javax.wsdl.Import;
import javax.wsdl.Input;
import javax.wsdl.Message;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.Output;
import javax.wsdl.Part;
import javax.wsdl.Port;
import javax.wsdl.PortType;
import javax.wsdl.Service;
import javax.wsdl.Types;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.AttributeExtensible;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaReference;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLLocator;
import javax.wsdl.xml.WSDLReader;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.xml.sax.InputSource;

public class WSDLReaderImpl implements WSDLReader {
  private static final List STYLE_ONE_WAY = Arrays.asList(new String[] { "input" });
  
  private static final List STYLE_REQUEST_RESPONSE = Arrays.asList(new String[] { "input", "output" });
  
  private static final List STYLE_SOLICIT_RESPONSE = Arrays.asList(new String[] { "output", "input" });
  
  private static final List STYLE_NOTIFICATION = Arrays.asList(new String[] { "output" });
  
  protected boolean verbose = true;
  
  protected boolean importDocuments = true;
  
  protected ExtensionRegistry extReg = null;
  
  protected String factoryImplName = null;
  
  protected WSDLLocator loc = null;
  
  protected WSDLFactory factory = null;
  
  protected Map allSchemas = new Hashtable();
  
  public void setFeature(String paramString, boolean paramBoolean) throws IllegalArgumentException {
    if (paramString == null)
      throw new IllegalArgumentException("Feature name must not be null."); 
    if (paramString.equals("javax.wsdl.verbose")) {
      this.verbose = paramBoolean;
    } else if (paramString.equals("javax.wsdl.importDocuments")) {
      this.importDocuments = paramBoolean;
    } else {
      throw new IllegalArgumentException("Feature name '" + paramString + "' not recognized.");
    } 
  }
  
  public boolean getFeature(String paramString) throws IllegalArgumentException {
    if (paramString == null)
      throw new IllegalArgumentException("Feature name must not be null."); 
    if (paramString.equals("javax.wsdl.verbose"))
      return this.verbose; 
    if (paramString.equals("javax.wsdl.importDocuments"))
      return this.importDocuments; 
    throw new IllegalArgumentException("Feature name '" + paramString + "' not recognized.");
  }
  
  public void setExtensionRegistry(ExtensionRegistry paramExtensionRegistry) { this.extReg = paramExtensionRegistry; }
  
  public ExtensionRegistry getExtensionRegistry() { return this.extReg; }
  
  protected WSDLFactory getWSDLFactory() throws WSDLException {
    if (this.factory == null)
      this.factory = (this.factoryImplName != null) ? WSDLFactory.newInstance(this.factoryImplName) : WSDLFactory.newInstance(); 
    return this.factory;
  }
  
  public void setFactoryImplName(String paramString) throws UnsupportedOperationException {
    if ((this.factoryImplName == null && paramString != null) || (this.factoryImplName != null && !this.factoryImplName.equals(paramString))) {
      this.factory = null;
      this.factoryImplName = paramString;
    } 
  }
  
  public String getFactoryImplName() { return this.factoryImplName; }
  
  protected Definition parseDefinitions(String paramString, Element paramElement, Map paramMap) throws WSDLException {
    checkElementName(paramElement, Constants.Q_ELEM_DEFINITIONS);
    WSDLFactory wSDLFactory = getWSDLFactory();
    Definition definition = wSDLFactory.newDefinition();
    if (this.extReg != null)
      definition.setExtensionRegistry(this.extReg); 
    String str1 = DOMUtils.getAttribute(paramElement, "name");
    String str2 = DOMUtils.getAttribute(paramElement, "targetNamespace");
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    if (paramMap == null)
      paramMap = new Hashtable(); 
    if (paramString != null) {
      definition.setDocumentBaseURI(paramString);
      paramMap.put(paramString, definition);
    } 
    if (str1 != null)
      definition.setQName(new QName(str2, str1)); 
    if (str2 != null)
      definition.setTargetNamespace(str2); 
    int i = namedNodeMap.getLength();
    for (byte b = 0; b < i; b++) {
      Attr attr = (Attr)namedNodeMap.item(b);
      String str3 = attr.getNamespaceURI();
      String str4 = attr.getLocalName();
      String str5 = attr.getValue();
      if (str3 != null && str3.equals("http://www.w3.org/2000/xmlns/"))
        if (str4 != null && !str4.equals("xmlns")) {
          definition.addNamespace(str4, str5);
        } else {
          definition.addNamespace(null, str5);
        }  
    } 
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_IMPORT, element)) {
        definition.addImport(parseImport(element, definition, paramMap));
      } else if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        definition.setDocumentationElement(element);
      } else if (QNameUtils.matches(Constants.Q_ELEM_TYPES, element)) {
        definition.setTypes(parseTypes(element, definition));
      } else if (QNameUtils.matches(Constants.Q_ELEM_MESSAGE, element)) {
        definition.addMessage(parseMessage(element, definition));
      } else if (QNameUtils.matches(Constants.Q_ELEM_PORT_TYPE, element)) {
        definition.addPortType(parsePortType(element, definition));
      } else if (QNameUtils.matches(Constants.Q_ELEM_BINDING, element)) {
        definition.addBinding(parseBinding(element, definition));
      } else if (QNameUtils.matches(Constants.Q_ELEM_SERVICE, element)) {
        definition.addService(parseService(element, definition));
      } else {
        definition.addExtensibilityElement(parseExtensibilityElement(Definition.class, element, definition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Definition.class, definition, definition);
    return definition;
  }
  
  protected Import parseImport(Element paramElement, Definition paramDefinition, Map paramMap) throws WSDLException {
    Import import = paramDefinition.createImport();
    try {
      String str1 = DOMUtils.getAttribute(paramElement, "namespace");
      String str2 = DOMUtils.getAttribute(paramElement, "location");
      String str3 = null;
      if (str1 != null)
        import.setNamespaceURI(str1); 
      if (str2 != null) {
        import.setLocationURI(str2);
        if (this.importDocuments)
          try {
            str3 = paramDefinition.getDocumentBaseURI();
            Definition definition = null;
            InputStream inputStream = null;
            InputSource inputSource = null;
            URL uRL = null;
            if (this.loc != null) {
              inputSource = this.loc.getImportInputSource(str3, str2);
              String str = this.loc.getLatestImportURI();
              definition = (Definition)paramMap.get(str);
              inputSource.setSystemId(str);
            } else {
              URL uRL1 = (str3 != null) ? StringUtils.getURL(null, str3) : null;
              uRL = StringUtils.getURL(uRL1, str2);
              definition = (Definition)paramMap.get(uRL.toString());
              if (definition == null) {
                inputStream = StringUtils.getContentAsInputStream(uRL);
                if (inputStream != null) {
                  inputSource = new InputSource(inputStream);
                  inputSource.setSystemId(uRL.toString());
                } 
              } 
            } 
            if (definition == null) {
              if (inputSource == null)
                throw new WSDLException("OTHER_ERROR", "Unable to locate imported document at '" + str2 + "'" + ((str3 == null) ? "." : (", relative to '" + str3 + "'."))); 
              Document document = getDocument(inputSource, inputSource.getSystemId());
              if (inputStream != null)
                inputStream.close(); 
              Element element1 = document.getDocumentElement();
              if (QNameUtils.matches(Constants.Q_ELEM_DEFINITIONS, element1)) {
                if (this.verbose)
                  System.out.println("Retrieving document at '" + str2 + "'" + ((str3 == null) ? "." : (", relative to '" + str3 + "'."))); 
                String str = (this.loc != null) ? this.loc.getLatestImportURI() : ((uRL != null) ? uRL.toString() : str2);
                definition = readWSDL(str, element1, paramMap);
              } else {
                QName qName = QNameUtils.newQName(element1);
                if (SchemaConstants.XSD_QNAME_LIST.contains(qName)) {
                  if (this.verbose)
                    System.out.println("Retrieving schema wsdl:imported from '" + str2 + "'" + ((str3 == null) ? "." : (", relative to '" + str3 + "'."))); 
                  WSDLFactory wSDLFactory = getWSDLFactory();
                  definition = wSDLFactory.newDefinition();
                  if (this.extReg != null)
                    definition.setExtensionRegistry(this.extReg); 
                  String str = (this.loc != null) ? this.loc.getLatestImportURI() : ((uRL != null) ? uRL.toString() : str2);
                  definition.setDocumentBaseURI(str);
                  Types types = definition.createTypes();
                  types.addExtensibilityElement(parseSchema(Types.class, element1, definition));
                  definition.setTypes(types);
                } 
              } 
            } 
            if (definition != null)
              import.setDefinition(definition); 
          } catch (WSDLException wSDLException) {
            throw wSDLException;
          } catch (RuntimeException runtimeException) {
            throw runtimeException;
          } catch (Exception exception) {
            throw new WSDLException("OTHER_ERROR", "Unable to resolve imported document at '" + str2 + ((str3 == null) ? "'." : ("', relative to '" + str3 + "'")), exception);
          }  
      } 
    } catch (WSDLException wSDLException) {
      if (wSDLException.getLocation() == null) {
        wSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
      } else {
        String str = XPathUtils.getXPathExprFromNode(paramElement) + wSDLException.getLocation();
        wSDLException.setLocation(str);
      } 
      throw wSDLException;
    } 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        import.setDocumentationElement(element);
      } else {
        import.addExtensibilityElement(parseExtensibilityElement(Import.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Import.class, import, paramDefinition);
    return import;
  }
  
  protected Types parseTypes(Element paramElement, Definition paramDefinition) throws WSDLException {
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    Types types = paramDefinition.createTypes();
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      QName qName = QNameUtils.newQName(element);
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        types.setDocumentationElement(element);
      } else if (SchemaConstants.XSD_QNAME_LIST.contains(qName)) {
        types.addExtensibilityElement(parseSchema(Types.class, element, paramDefinition));
      } else {
        types.addExtensibilityElement(parseExtensibilityElement(Types.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Types.class, types, paramDefinition);
    return types;
  }
  
  protected ExtensibilityElement parseSchema(Class paramClass, Element paramElement, Definition paramDefinition) throws WSDLException {
    Object object = null;
    ExtensionRegistry extensionRegistry = null;
    try {
      extensionRegistry = paramDefinition.getExtensionRegistry();
      if (extensionRegistry == null)
        throw new WSDLException("CONFIGURATION_ERROR", "No ExtensionRegistry set for this Definition, so unable to deserialize a '" + object + "' element in the " + "context of a '" + paramClass.getName() + "'."); 
      return parseSchema(paramClass, paramElement, paramDefinition, extensionRegistry);
    } catch (WSDLException wSDLException) {
      if (wSDLException.getLocation() == null)
        wSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement)); 
      throw wSDLException;
    } 
  }
  
  protected ExtensibilityElement parseSchema(Class paramClass, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    Schema schema = null;
    SchemaReference schemaReference = null;
    try {
      QName qName = QNameUtils.newQName(paramElement);
      ExtensionDeserializer extensionDeserializer = paramExtensionRegistry.queryDeserializer(paramClass, qName);
      ExtensibilityElement extensibilityElement = extensionDeserializer.unmarshall(paramClass, qName, paramElement, paramDefinition, paramExtensionRegistry);
      if (extensibilityElement instanceof Schema) {
        schema = (Schema)extensibilityElement;
      } else {
        return extensibilityElement;
      } 
      if (schema.getDocumentBaseURI() != null)
        this.allSchemas.put(schema.getDocumentBaseURI(), schema); 
      ArrayList arrayList = new ArrayList();
      Collection collection = schema.getImports().values();
      Iterator iterator = collection.iterator();
      while (iterator.hasNext())
        arrayList.addAll((Collection)iterator.next()); 
      arrayList.addAll(schema.getIncludes());
      arrayList.addAll(schema.getRedefines());
      ListIterator listIterator = arrayList.listIterator();
      while (listIterator.hasNext()) {
        try {
          schemaReference = (SchemaReference)listIterator.next();
          if (schemaReference.getSchemaLocationURI() == null)
            continue; 
          if (this.verbose)
            System.out.println("Retrieving schema at '" + schemaReference.getSchemaLocationURI() + ((schema.getDocumentBaseURI() == null) ? "'." : ("', relative to '" + schema.getDocumentBaseURI() + "'."))); 
          InputStream inputStream = null;
          InputSource inputSource = null;
          Schema schema1 = null;
          String str = null;
          if (this.loc != null) {
            inputSource = this.loc.getImportInputSource(schema.getDocumentBaseURI(), schemaReference.getSchemaLocationURI());
            if (inputSource == null)
              throw new WSDLException("OTHER_ERROR", "Unable to locate with a locator the schema referenced at '" + schemaReference.getSchemaLocationURI() + "' relative to document base '" + schema.getDocumentBaseURI() + "'"); 
            str = this.loc.getLatestImportURI();
            schema1 = (Schema)this.allSchemas.get(str);
          } else {
            String str1 = schema.getDocumentBaseURI();
            URL uRL1 = (str1 != null) ? StringUtils.getURL(null, str1) : null;
            URL uRL2 = StringUtils.getURL(uRL1, schemaReference.getSchemaLocationURI());
            str = uRL2.toExternalForm();
            schema1 = (Schema)this.allSchemas.get(str);
            if (schema1 == null) {
              inputStream = StringUtils.getContentAsInputStream(uRL2);
              if (inputStream != null)
                inputSource = new InputSource(inputStream); 
              if (inputSource == null)
                throw new WSDLException("OTHER_ERROR", "Unable to locate with a url the document referenced at '" + schemaReference.getSchemaLocationURI() + "'" + ((str1 == null) ? "." : (", relative to '" + str1 + "'."))); 
            } 
          } 
          if (schema1 == null) {
            inputSource.setSystemId(str);
            Document document = getDocument(inputSource, str);
            if (inputStream != null)
              inputStream.close(); 
            Element element = document.getDocumentElement();
            QName qName1 = QNameUtils.newQName(element);
            if (SchemaConstants.XSD_QNAME_LIST.contains(qName1)) {
              WSDLFactory wSDLFactory = getWSDLFactory();
              Definition definition = wSDLFactory.newDefinition();
              definition.setDocumentBaseURI(str);
              schema1 = (Schema)parseSchema(paramClass, element, definition, paramExtensionRegistry);
            } 
          } 
          schemaReference.setReferencedSchema(schema1);
        } catch (WSDLException wSDLException) {
          throw wSDLException;
        } catch (RuntimeException runtimeException) {
          throw runtimeException;
        } catch (Exception exception) {
          throw new WSDLException("OTHER_ERROR", "An error occurred trying to resolve schema referenced at '" + schemaReference.getSchemaLocationURI() + "'" + ((schema.getDocumentBaseURI() == null) ? "." : (", relative to '" + schema.getDocumentBaseURI() + "'.")), exception);
        } 
      } 
      return schema;
    } catch (WSDLException wSDLException) {
      if (wSDLException.getLocation() == null) {
        wSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
      } else {
        String str = XPathUtils.getXPathExprFromNode(paramElement) + wSDLException.getLocation();
        wSDLException.setLocation(str);
      } 
      throw wSDLException;
    } 
  }
  
  protected Binding parseBinding(Element paramElement, Definition paramDefinition) throws WSDLException {
    Binding binding = null;
    List list = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", list);
    QName qName = getQualifiedAttributeValue(paramElement, "type", "binding", paramDefinition, list);
    PortType portType = null;
    if (str != null) {
      QName qName1 = new QName(paramDefinition.getTargetNamespace(), str);
      binding = paramDefinition.getBinding(qName1);
      if (binding == null) {
        binding = paramDefinition.createBinding();
        binding.setQName(qName1);
      } 
    } else {
      binding = paramDefinition.createBinding();
    } 
    binding.setUndefined(false);
    if (qName != null) {
      portType = paramDefinition.getPortType(qName);
      if (portType == null) {
        portType = paramDefinition.createPortType();
        portType.setQName(qName);
        paramDefinition.addPortType(portType);
      } 
      binding.setPortType(portType);
    } 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        binding.setDocumentationElement(element);
      } else if (QNameUtils.matches(Constants.Q_ELEM_OPERATION, element)) {
        binding.addBindingOperation(parseBindingOperation(element, portType, paramDefinition));
      } else {
        binding.addExtensibilityElement(parseExtensibilityElement(Binding.class, element, paramDefinition));
      } 
    } 
    return binding;
  }
  
  protected BindingOperation parseBindingOperation(Element paramElement, PortType paramPortType, Definition paramDefinition) throws WSDLException {
    BindingOperation bindingOperation = paramDefinition.createBindingOperation();
    List list = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", list);
    if (str != null)
      bindingOperation.setName(str); 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        bindingOperation.setDocumentationElement(element);
      } else if (QNameUtils.matches(Constants.Q_ELEM_INPUT, element)) {
        bindingOperation.setBindingInput(parseBindingInput(element, paramDefinition));
      } else if (QNameUtils.matches(Constants.Q_ELEM_OUTPUT, element)) {
        bindingOperation.setBindingOutput(parseBindingOutput(element, paramDefinition));
      } else if (QNameUtils.matches(Constants.Q_ELEM_FAULT, element)) {
        bindingOperation.addBindingFault(parseBindingFault(element, paramDefinition));
      } else {
        bindingOperation.addExtensibilityElement(parseExtensibilityElement(BindingOperation.class, element, paramDefinition));
      } 
    } 
    if (paramPortType != null) {
      BindingInput bindingInput = bindingOperation.getBindingInput();
      BindingOutput bindingOutput = bindingOperation.getBindingOutput();
      String str1 = (bindingInput != null) ? ((bindingInput.getName() != null) ? bindingInput.getName() : ":none") : null;
      String str2 = (bindingOutput != null) ? ((bindingOutput.getName() != null) ? bindingOutput.getName() : ":none") : null;
      Operation operation = paramPortType.getOperation(str, str1, str2);
      if (operation == null)
        if (":none".equals(str1) && ":none".equals(str2)) {
          operation = paramPortType.getOperation(str, null, null);
        } else if (":none".equals(str1)) {
          operation = paramPortType.getOperation(str, null, str2);
        } else if (":none".equals(str2)) {
          operation = paramPortType.getOperation(str, str1, null);
        }  
      if (operation == null) {
        Input input = paramDefinition.createInput();
        Output output = paramDefinition.createOutput();
        operation = paramDefinition.createOperation();
        operation.setName(str);
        input.setName(str1);
        output.setName(str2);
        operation.setInput(input);
        operation.setOutput(output);
        paramPortType.addOperation(operation);
      } 
      bindingOperation.setOperation(operation);
    } 
    parseExtensibilityAttributes(paramElement, BindingOperation.class, bindingOperation, paramDefinition);
    return bindingOperation;
  }
  
  protected BindingInput parseBindingInput(Element paramElement, Definition paramDefinition) throws WSDLException {
    BindingInput bindingInput = paramDefinition.createBindingInput();
    List list = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", list);
    if (str != null)
      bindingInput.setName(str); 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        bindingInput.setDocumentationElement(element);
      } else {
        bindingInput.addExtensibilityElement(parseExtensibilityElement(BindingInput.class, element, paramDefinition));
      } 
    } 
    return bindingInput;
  }
  
  protected BindingOutput parseBindingOutput(Element paramElement, Definition paramDefinition) throws WSDLException {
    BindingOutput bindingOutput = paramDefinition.createBindingOutput();
    List list = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", list);
    if (str != null)
      bindingOutput.setName(str); 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        bindingOutput.setDocumentationElement(element);
      } else {
        bindingOutput.addExtensibilityElement(parseExtensibilityElement(BindingOutput.class, element, paramDefinition));
      } 
    } 
    return bindingOutput;
  }
  
  protected BindingFault parseBindingFault(Element paramElement, Definition paramDefinition) throws WSDLException {
    BindingFault bindingFault = paramDefinition.createBindingFault();
    List list = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", list);
    if (str != null)
      bindingFault.setName(str); 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        bindingFault.setDocumentationElement(element);
      } else {
        bindingFault.addExtensibilityElement(parseExtensibilityElement(BindingFault.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, BindingFault.class, bindingFault, paramDefinition);
    return bindingFault;
  }
  
  protected Message parseMessage(Element paramElement, Definition paramDefinition) throws WSDLException {
    Message message = null;
    List list = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", list);
    if (str != null) {
      QName qName = new QName(paramDefinition.getTargetNamespace(), str);
      message = paramDefinition.getMessage(qName);
      if (message == null) {
        message = paramDefinition.createMessage();
        message.setQName(qName);
      } 
    } else {
      message = paramDefinition.createMessage();
    } 
    message.setUndefined(false);
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        message.setDocumentationElement(element);
      } else if (QNameUtils.matches(Constants.Q_ELEM_PART, element)) {
        message.addPart(parsePart(element, paramDefinition));
      } else {
        message.addExtensibilityElement(parseExtensibilityElement(Message.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Message.class, message, paramDefinition);
    return message;
  }
  
  protected Part parsePart(Element paramElement, Definition paramDefinition) throws WSDLException {
    Part part = paramDefinition.createPart();
    String str = DOMUtils.getAttribute(paramElement, "name");
    QName qName1 = getQualifiedAttributeValue(paramElement, "element", "message", paramDefinition);
    QName qName2 = getQualifiedAttributeValue(paramElement, "type", "message", paramDefinition);
    if (str != null)
      part.setName(str); 
    if (qName1 != null)
      part.setElementName(qName1); 
    if (qName2 != null)
      part.setTypeName(qName2); 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        part.setDocumentationElement(element);
      } else {
        part.addExtensibilityElement(parseExtensibilityElement(Part.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Part.class, part, paramDefinition);
    return part;
  }
  
  protected void parseExtensibilityAttributes(Element paramElement, Class paramClass, AttributeExtensible paramAttributeExtensible, Definition paramDefinition) throws WSDLException {
    List list = paramAttributeExtensible.getNativeAttributeNames();
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    int i = namedNodeMap.getLength();
    for (byte b = 0; b < i; b++) {
      Attr attr = (Attr)namedNodeMap.item(b);
      String str1 = attr.getLocalName();
      String str2 = attr.getNamespaceURI();
      String str3 = attr.getPrefix();
      QName qName = new QName(str2, str1);
      if (str2 != null && !str2.equals("http://schemas.xmlsoap.org/wsdl/")) {
        if (!str2.equals("http://www.w3.org/2000/xmlns/")) {
          DOMUtils.registerUniquePrefix(str3, str2, paramDefinition);
          String str = attr.getValue();
          int j = -1;
          ExtensionRegistry extensionRegistry = paramDefinition.getExtensionRegistry();
          if (extensionRegistry != null)
            j = extensionRegistry.queryExtensionAttributeType(paramClass, qName); 
          Object object = parseExtensibilityAttribute(paramElement, j, str, paramDefinition);
          paramAttributeExtensible.setExtensionAttribute(qName, object);
        } 
      } else if (!list.contains(str1)) {
        WSDLException wSDLException = new WSDLException("INVALID_WSDL", "Encountered illegal extension attribute '" + qName + "'. Extension " + "attributes must be in " + "a namespace other than " + "WSDL's.");
        wSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
        throw wSDLException;
      } 
    } 
  }
  
  protected Object parseExtensibilityAttribute(Element paramElement, int paramInt, String paramString, Definition paramDefinition) throws WSDLException {
    if (paramInt == 1)
      return DOMUtils.getQName(paramString, paramElement, paramDefinition); 
    if (paramInt == 2)
      return StringUtils.parseNMTokens(paramString); 
    if (paramInt == 3) {
      List list = StringUtils.parseNMTokens(paramString);
      int i = list.size();
      Vector vector = new Vector(i);
      for (byte b = 0; b < i; b++) {
        String str = (String)list.get(b);
        QName qName1 = DOMUtils.getQName(str, paramElement, paramDefinition);
        vector.add(qName1);
      } 
      return vector;
    } 
    if (paramInt == 0)
      return paramString; 
    QName qName = null;
    try {
      qName = DOMUtils.getQName(paramString, paramElement, paramDefinition);
    } catch (WSDLException wSDLException) {
      qName = new QName(paramString);
    } 
    return qName;
  }
  
  protected PortType parsePortType(Element paramElement, Definition paramDefinition) throws WSDLException {
    PortType portType = null;
    String str = DOMUtils.getAttribute(paramElement, "name");
    if (str != null) {
      QName qName = new QName(paramDefinition.getTargetNamespace(), str);
      portType = paramDefinition.getPortType(qName);
      if (portType == null) {
        portType = paramDefinition.createPortType();
        portType.setQName(qName);
      } 
    } else {
      portType = paramDefinition.createPortType();
    } 
    portType.setUndefined(false);
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        portType.setDocumentationElement(element);
      } else if (QNameUtils.matches(Constants.Q_ELEM_OPERATION, element)) {
        Operation operation = parseOperation(element, portType, paramDefinition);
        if (operation != null)
          portType.addOperation(operation); 
      } else {
        portType.addExtensibilityElement(parseExtensibilityElement(PortType.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, PortType.class, portType, paramDefinition);
    return portType;
  }
  
  protected Operation parseOperation(Element paramElement, PortType paramPortType, Definition paramDefinition) throws WSDLException {
    Operation operation = null;
    List list = DOMUtils.getAttributes(paramElement);
    String str1 = DOMUtils.getAttribute(paramElement, "name", list);
    String str2 = DOMUtils.getAttribute(paramElement, "parameterOrder", list);
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    Element element1 = DOMUtils.getFirstChildElement(paramElement);
    Vector vector1 = new Vector();
    Element element2 = null;
    Input input = null;
    Output output = null;
    Vector vector2 = new Vector();
    Vector vector3 = new Vector();
    boolean bool = true;
    while (element1 != null) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element1)) {
        element2 = element1;
      } else if (QNameUtils.matches(Constants.Q_ELEM_INPUT, element1)) {
        input = parseInput(element1, paramDefinition);
        vector1.add("input");
      } else if (QNameUtils.matches(Constants.Q_ELEM_OUTPUT, element1)) {
        output = parseOutput(element1, paramDefinition);
        vector1.add("output");
      } else if (QNameUtils.matches(Constants.Q_ELEM_FAULT, element1)) {
        vector2.add(parseFault(element1, paramDefinition));
      } else {
        vector3.add(parseExtensibilityElement(Operation.class, element1, paramDefinition));
      } 
      element1 = DOMUtils.getNextSiblingElement(element1);
    } 
    if (str1 != null) {
      String str3 = (input != null) ? ((input.getName() != null) ? input.getName() : ":none") : null;
      String str4 = (output != null) ? ((output.getName() != null) ? output.getName() : ":none") : null;
      operation = paramPortType.getOperation(str1, str3, str4);
      if (operation != null && !operation.isUndefined())
        operation = null; 
      if (operation != null && str3 == null) {
        Input input1 = operation.getInput();
        if (input1 != null && input1.getName() != null)
          operation = null; 
      } 
      if (operation != null && str4 == null) {
        Output output1 = operation.getOutput();
        if (output1 != null && output1.getName() != null)
          operation = null; 
      } 
      if (operation == null) {
        operation = paramDefinition.createOperation();
        operation.setName(str1);
        bool = false;
      } 
    } else {
      operation = paramDefinition.createOperation();
      bool = false;
    } 
    operation.setUndefined(false);
    if (str2 != null)
      operation.setParameterOrdering(StringUtils.parseNMTokens(str2)); 
    if (element2 != null)
      operation.setDocumentationElement(element2); 
    if (input != null)
      operation.setInput(input); 
    if (output != null)
      operation.setOutput(output); 
    if (vector2.size() > 0) {
      Iterator iterator = vector2.iterator();
      while (iterator.hasNext())
        operation.addFault((Fault)iterator.next()); 
    } 
    if (vector3.size() > 0) {
      Iterator iterator = vector3.iterator();
      while (iterator.hasNext())
        operation.addExtensibilityElement((ExtensibilityElement)iterator.next()); 
    } 
    OperationType operationType = null;
    if (vector1.equals(STYLE_ONE_WAY)) {
      operationType = OperationType.ONE_WAY;
    } else if (vector1.equals(STYLE_REQUEST_RESPONSE)) {
      operationType = OperationType.REQUEST_RESPONSE;
    } else if (vector1.equals(STYLE_SOLICIT_RESPONSE)) {
      operationType = OperationType.SOLICIT_RESPONSE;
    } else if (vector1.equals(STYLE_NOTIFICATION)) {
      operationType = OperationType.NOTIFICATION;
    } 
    if (operationType != null)
      operation.setStyle(operationType); 
    if (bool)
      operation = null; 
    parseExtensibilityAttributes(paramElement, Operation.class, operation, paramDefinition);
    return operation;
  }
  
  protected Service parseService(Element paramElement, Definition paramDefinition) throws WSDLException {
    Service service = paramDefinition.createService();
    List list = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", list);
    if (str != null)
      service.setQName(new QName(paramDefinition.getTargetNamespace(), str)); 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        service.setDocumentationElement(element);
      } else if (QNameUtils.matches(Constants.Q_ELEM_PORT, element)) {
        service.addPort(parsePort(element, paramDefinition));
      } else {
        service.addExtensibilityElement(parseExtensibilityElement(Service.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Service.class, service, paramDefinition);
    return service;
  }
  
  protected Port parsePort(Element paramElement, Definition paramDefinition) throws WSDLException {
    Port port = paramDefinition.createPort();
    List list = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", list);
    QName qName = getQualifiedAttributeValue(paramElement, "binding", "port", paramDefinition, list);
    if (str != null)
      port.setName(str); 
    if (qName != null) {
      Binding binding = paramDefinition.getBinding(qName);
      if (binding == null) {
        binding = paramDefinition.createBinding();
        binding.setQName(qName);
        paramDefinition.addBinding(binding);
      } 
      port.setBinding(binding);
    } 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        port.setDocumentationElement(element);
      } else {
        port.addExtensibilityElement(parseExtensibilityElement(Port.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Port.class, port, paramDefinition);
    return port;
  }
  
  protected ExtensibilityElement parseExtensibilityElement(Class paramClass, Element paramElement, Definition paramDefinition) throws WSDLException {
    QName qName = QNameUtils.newQName(paramElement);
    String str = paramElement.getNamespaceURI();
    try {
      if (str == null || str.equals("http://schemas.xmlsoap.org/wsdl/"))
        throw new WSDLException("INVALID_WSDL", "Encountered illegal extension element '" + qName + "' in the context of a '" + paramClass.getName() + "'. Extension elements must be in " + "a namespace other than WSDL's."); 
      ExtensionRegistry extensionRegistry = paramDefinition.getExtensionRegistry();
      if (extensionRegistry == null)
        throw new WSDLException("CONFIGURATION_ERROR", "No ExtensionRegistry set for this Definition, so unable to deserialize a '" + qName + "' element in the " + "context of a '" + paramClass.getName() + "'."); 
      ExtensionDeserializer extensionDeserializer = extensionRegistry.queryDeserializer(paramClass, qName);
      return extensionDeserializer.unmarshall(paramClass, qName, paramElement, paramDefinition, extensionRegistry);
    } catch (WSDLException wSDLException) {
      if (wSDLException.getLocation() == null)
        wSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement)); 
      throw wSDLException;
    } 
  }
  
  protected Input parseInput(Element paramElement, Definition paramDefinition) throws WSDLException {
    Input input = paramDefinition.createInput();
    String str = DOMUtils.getAttribute(paramElement, "name");
    QName qName = getQualifiedAttributeValue(paramElement, "message", "input", paramDefinition);
    if (str != null)
      input.setName(str); 
    if (qName != null) {
      Message message = paramDefinition.getMessage(qName);
      if (message == null) {
        message = paramDefinition.createMessage();
        message.setQName(qName);
        paramDefinition.addMessage(message);
      } 
      input.setMessage(message);
    } 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        input.setDocumentationElement(element);
      } else {
        input.addExtensibilityElement(parseExtensibilityElement(Input.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Input.class, input, paramDefinition);
    return input;
  }
  
  protected Output parseOutput(Element paramElement, Definition paramDefinition) throws WSDLException {
    Output output = paramDefinition.createOutput();
    String str = DOMUtils.getAttribute(paramElement, "name");
    QName qName = getQualifiedAttributeValue(paramElement, "message", "output", paramDefinition);
    if (str != null)
      output.setName(str); 
    if (qName != null) {
      Message message = paramDefinition.getMessage(qName);
      if (message == null) {
        message = paramDefinition.createMessage();
        message.setQName(qName);
        paramDefinition.addMessage(message);
      } 
      output.setMessage(message);
    } 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        output.setDocumentationElement(element);
      } else {
        output.addExtensibilityElement(parseExtensibilityElement(Output.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Output.class, output, paramDefinition);
    return output;
  }
  
  protected Fault parseFault(Element paramElement, Definition paramDefinition) throws WSDLException {
    Fault fault = paramDefinition.createFault();
    String str = DOMUtils.getAttribute(paramElement, "name");
    QName qName = getQualifiedAttributeValue(paramElement, "message", "fault", paramDefinition);
    if (str != null)
      fault.setName(str); 
    if (qName != null) {
      Message message = paramDefinition.getMessage(qName);
      if (message == null) {
        message = paramDefinition.createMessage();
        message.setQName(qName);
        paramDefinition.addMessage(message);
      } 
      fault.setMessage(message);
    } 
    NamedNodeMap namedNodeMap = paramElement.getAttributes();
    registerNSDeclarations(namedNodeMap, paramDefinition);
    for (Element element = DOMUtils.getFirstChildElement(paramElement); element != null; element = DOMUtils.getNextSiblingElement(element)) {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, element)) {
        fault.setDocumentationElement(element);
      } else {
        fault.addExtensibilityElement(parseExtensibilityElement(Fault.class, element, paramDefinition));
      } 
    } 
    parseExtensibilityAttributes(paramElement, Fault.class, fault, paramDefinition);
    return fault;
  }
  
  private static QName getQualifiedAttributeValue(Element paramElement, String paramString1, String paramString2, Definition paramDefinition) throws WSDLException {
    try {
      return DOMUtils.getQualifiedAttributeValue(paramElement, paramString1, paramString2, false, paramDefinition);
    } catch (WSDLException wSDLException) {
      if (wSDLException.getFaultCode().equals("NO_PREFIX_SPECIFIED")) {
        String str = DOMUtils.getAttribute(paramElement, paramString1);
        return new QName(str);
      } 
      throw wSDLException;
    } 
  }
  
  private static QName getQualifiedAttributeValue(Element paramElement, String paramString1, String paramString2, Definition paramDefinition, List paramList) throws WSDLException {
    try {
      return DOMUtils.getQualifiedAttributeValue(paramElement, paramString1, paramString2, false, paramDefinition, paramList);
    } catch (WSDLException wSDLException) {
      if (wSDLException.getFaultCode().equals("NO_PREFIX_SPECIFIED")) {
        String str = DOMUtils.getAttribute(paramElement, paramString1, paramList);
        return new QName(str);
      } 
      throw wSDLException;
    } 
  }
  
  private static void checkElementName(Element paramElement, QName paramQName) throws WSDLException {
    if (!QNameUtils.matches(paramQName, paramElement)) {
      WSDLException wSDLException = new WSDLException("INVALID_WSDL", "Expected element '" + paramQName + "'.");
      wSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
      throw wSDLException;
    } 
  }
  
  private static Document getDocument(InputSource paramInputSource, String paramString) throws WSDLException {
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    documentBuilderFactory.setNamespaceAware(true);
    documentBuilderFactory.setValidating(false);
    try {
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      return documentBuilder.parse(paramInputSource);
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (Exception exception) {
      throw new WSDLException("PARSER_ERROR", "Problem parsing '" + paramString + "'.", exception);
    } 
  }
  
  private static void registerNSDeclarations(NamedNodeMap paramNamedNodeMap, Definition paramDefinition) {
    int i = paramNamedNodeMap.getLength();
    for (byte b = 0; b < i; b++) {
      Attr attr = (Attr)paramNamedNodeMap.item(b);
      String str1 = attr.getNamespaceURI();
      String str2 = attr.getLocalName();
      String str3 = attr.getValue();
      if (str1 != null && str1.equals("http://www.w3.org/2000/xmlns/"))
        if (str2 != null && !str2.equals("xmlns")) {
          DOMUtils.registerUniquePrefix(str2, str3, paramDefinition);
        } else {
          DOMUtils.registerUniquePrefix(null, str3, paramDefinition);
        }  
    } 
  }
  
  public Definition readWSDL(String paramString) throws WSDLException { return readWSDL(null, paramString); }
  
  public Definition readWSDL(String paramString1, String paramString2) throws WSDLException {
    try {
      if (this.verbose)
        System.out.println("Retrieving document at '" + paramString2 + "'" + ((paramString1 == null) ? "." : (", relative to '" + paramString1 + "'."))); 
      URL uRL1 = (paramString1 != null) ? StringUtils.getURL(null, paramString1) : null;
      URL uRL2 = StringUtils.getURL(uRL1, paramString2);
      InputStream inputStream = StringUtils.getContentAsInputStream(uRL2);
      InputSource inputSource = new InputSource(inputStream);
      inputSource.setSystemId(uRL2.toString());
      Document document = getDocument(inputSource, uRL2.toString());
      inputStream.close();
      return readWSDL(uRL2.toString(), document);
    } catch (WSDLException wSDLException) {
      throw wSDLException;
    } catch (RuntimeException runtimeException) {
      throw runtimeException;
    } catch (Exception exception) {
      throw new WSDLException("OTHER_ERROR", "Unable to resolve imported document at '" + paramString2 + ((paramString1 == null) ? "'." : ("', relative to '" + paramString1 + "'.")), exception);
    } 
  }
  
  public Definition readWSDL(String paramString, Element paramElement) throws WSDLException { return readWSDL(paramString, paramElement, null); }
  
  public Definition readWSDL(WSDLLocator paramWSDLLocator, Element paramElement) throws WSDLException {
    try {
      this.loc = paramWSDLLocator;
      return readWSDL(paramWSDLLocator.getBaseURI(), paramElement, null);
    } finally {
      paramWSDLLocator.close();
      this.loc = null;
    } 
  }
  
  protected Definition readWSDL(String paramString, Element paramElement, Map paramMap) throws WSDLException { return parseDefinitions(paramString, paramElement, paramMap); }
  
  public Definition readWSDL(String paramString, Document paramDocument) throws WSDLException { return readWSDL(paramString, paramDocument.getDocumentElement()); }
  
  public Definition readWSDL(String paramString, InputSource paramInputSource) throws WSDLException {
    String str = (paramInputSource.getSystemId() != null) ? paramInputSource.getSystemId() : "- WSDL Document -";
    return readWSDL(paramString, getDocument(paramInputSource, str));
  }
  
  public Definition readWSDL(WSDLLocator paramWSDLLocator) throws WSDLException {
    InputSource inputSource = paramWSDLLocator.getBaseInputSource();
    String str = paramWSDLLocator.getBaseURI();
    if (inputSource == null)
      throw new WSDLException("OTHER_ERROR", "Unable to locate document at '" + str + "'."); 
    inputSource.setSystemId(str);
    this.loc = paramWSDLLocator;
    if (this.verbose)
      System.out.println("Retrieving document at '" + str + "'."); 
    try {
      return readWSDL(str, inputSource);
    } finally {
      this.loc.close();
      this.loc = null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\xml\WSDLReaderImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */