package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.wsdl.BindingFault;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Operation;

public class BindingOperationImpl extends AbstractWSDLElement implements BindingOperation {
  protected String name = null;
  
  protected Operation operation = null;
  
  protected BindingInput bindingInput = null;
  
  protected BindingOutput bindingOutput = null;
  
  protected Map bindingFaults = new HashMap();
  
  protected List nativeAttributeNames = Arrays.asList(Constants.BINDING_OPERATION_ATTR_NAMES);
  
  public static final long serialVersionUID = 1L;
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setOperation(Operation paramOperation) { this.operation = paramOperation; }
  
  public Operation getOperation() { return this.operation; }
  
  public void setBindingInput(BindingInput paramBindingInput) { this.bindingInput = paramBindingInput; }
  
  public BindingInput getBindingInput() { return this.bindingInput; }
  
  public void setBindingOutput(BindingOutput paramBindingOutput) { this.bindingOutput = paramBindingOutput; }
  
  public BindingOutput getBindingOutput() { return this.bindingOutput; }
  
  public void addBindingFault(BindingFault paramBindingFault) { this.bindingFaults.put(paramBindingFault.getName(), paramBindingFault); }
  
  public BindingFault getBindingFault(String paramString) { return (BindingFault)this.bindingFaults.get(paramString); }
  
  public BindingFault removeBindingFault(String paramString) { return (BindingFault)this.bindingFaults.remove(paramString); }
  
  public Map getBindingFaults() { return this.bindingFaults; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("BindingOperation: name=" + this.name);
    if (this.bindingInput != null)
      stringBuffer.append("\n" + this.bindingInput); 
    if (this.bindingOutput != null)
      stringBuffer.append("\n" + this.bindingOutput); 
    if (this.bindingFaults != null) {
      Iterator iterator = this.bindingFaults.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\BindingOperationImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */