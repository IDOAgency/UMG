package com.ibm.wsdl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.WSDLElement;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public abstract class AbstractWSDLElement implements WSDLElement {
  protected Element docEl;
  
  protected List extElements = new Vector();
  
  protected Map extensionAttributes = new HashMap();
  
  public void setDocumentationElement(Element paramElement) { this.docEl = paramElement; }
  
  public Element getDocumentationElement() { return this.docEl; }
  
  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement) { this.extElements.add(paramExtensibilityElement); }
  
  public ExtensibilityElement removeExtensibilityElement(ExtensibilityElement paramExtensibilityElement) { return this.extElements.remove(paramExtensibilityElement) ? paramExtensibilityElement : null; }
  
  public List getExtensibilityElements() { return this.extElements; }
  
  public void setExtensionAttribute(QName paramQName, Object paramObject) {
    if (paramObject != null) {
      this.extensionAttributes.put(paramQName, paramObject);
    } else {
      this.extensionAttributes.remove(paramQName);
    } 
  }
  
  public Object getExtensionAttribute(QName paramQName) { return this.extensionAttributes.get(paramQName); }
  
  public Map getExtensionAttributes() { return this.extensionAttributes; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    if (this.extElements.size() > 0) {
      Iterator iterator = this.extElements.iterator();
      if (iterator.hasNext()) {
        stringBuffer.append(iterator.next());
        while (iterator.hasNext()) {
          stringBuffer.append("\n");
          stringBuffer.append(iterator.next());
        } 
      } 
    } 
    if (this.extensionAttributes.size() > 0) {
      Iterator iterator = this.extensionAttributes.keySet().iterator();
      if (iterator.hasNext()) {
        QName qName = (QName)iterator.next();
        stringBuffer.append("extension attribute: ");
        stringBuffer.append(qName);
        stringBuffer.append("=");
        stringBuffer.append(this.extensionAttributes.get(qName));
        while (iterator.hasNext()) {
          qName = (QName)iterator.next();
          stringBuffer.append("\n");
          stringBuffer.append("extension attribute: ");
          stringBuffer.append(qName);
          stringBuffer.append("=");
          stringBuffer.append(this.extensionAttributes.get(qName));
        } 
      } 
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\AbstractWSDLElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */