package com.ibm.wsdl;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.Input;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.Output;
import javax.wsdl.PortType;
import javax.xml.namespace.QName;

public class PortTypeImpl extends AbstractWSDLElement implements PortType {
  protected QName name = null;
  
  protected List operations = new Vector();
  
  protected List nativeAttributeNames = Arrays.asList(Constants.PORT_TYPE_ATTR_NAMES);
  
  protected boolean isUndefined = true;
  
  public static final long serialVersionUID = 1L;
  
  public void setQName(QName paramQName) { this.name = paramQName; }
  
  public QName getQName() { return this.name; }
  
  public void addOperation(Operation paramOperation) { this.operations.add(paramOperation); }
  
  public Operation getOperation(String paramString1, String paramString2, String paramString3) {
    boolean bool = false;
    Operation operation = null;
    for (Operation operation1 : this.operations) {
      String str = operation1.getName();
      if (paramString1 != null && str != null) {
        if (!paramString1.equals(str))
          operation1 = null; 
      } else if (paramString1 != null || str != null) {
        operation1 = null;
      } 
      if (operation1 != null && paramString2 != null) {
        OperationType operationType = operation1.getStyle();
        String str1 = str;
        if (operationType == OperationType.REQUEST_RESPONSE) {
          str1 = str + "Request";
        } else if (operationType == OperationType.SOLICIT_RESPONSE) {
          str1 = str + "Solicit";
        } 
        boolean bool1 = paramString2.equals(str1);
        Input input = operation1.getInput();
        if (input != null) {
          String str2 = input.getName();
          if (str2 == null) {
            if (!bool1 && !paramString2.equals(":none"))
              operation1 = null; 
          } else if (!str2.equals(paramString2)) {
            operation1 = null;
          } 
        } else {
          operation1 = null;
        } 
      } 
      if (operation1 != null && paramString3 != null) {
        OperationType operationType = operation1.getStyle();
        String str1 = str;
        if (operationType == OperationType.REQUEST_RESPONSE || operationType == OperationType.SOLICIT_RESPONSE)
          str1 = str + "Response"; 
        boolean bool1 = paramString3.equals(str1);
        Output output = operation1.getOutput();
        if (output != null) {
          String str2 = output.getName();
          if (str2 == null) {
            if (!bool1 && !paramString3.equals(":none"))
              operation1 = null; 
          } else if (!str2.equals(paramString3)) {
            operation1 = null;
          } 
        } else {
          operation1 = null;
        } 
      } 
      if (operation1 != null) {
        if (bool)
          throw new IllegalArgumentException("Duplicate operation with name=" + paramString1 + ((paramString2 != null) ? (", inputName=" + paramString2) : "") + ((paramString3 != null) ? (", outputName=" + paramString3) : "") + ", found in portType '" + getQName() + "'."); 
        bool = true;
        operation = operation1;
      } 
    } 
    return operation;
  }
  
  public List getOperations() { return this.operations; }
  
  public Operation removeOperation(String paramString1, String paramString2, String paramString3) {
    Operation operation = getOperation(paramString1, paramString2, paramString3);
    return this.operations.remove(operation) ? operation : null;
  }
  
  public void setUndefined(boolean paramBoolean) { this.isUndefined = paramBoolean; }
  
  public boolean isUndefined() { return this.isUndefined; }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("PortType: name=" + this.name);
    if (this.operations != null) {
      Iterator iterator = this.operations.iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\PortTypeImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */