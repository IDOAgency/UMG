package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.Message;
import javax.wsdl.Part;
import javax.xml.namespace.QName;

public class MessageImpl extends AbstractWSDLElement implements Message {
  protected Map parts = new HashMap();
  
  protected List additionOrderOfParts = new Vector();
  
  protected QName name = null;
  
  protected List nativeAttributeNames = Arrays.asList(Constants.MESSAGE_ATTR_NAMES);
  
  protected boolean isUndefined = true;
  
  public static final long serialVersionUID = 1L;
  
  public void setQName(QName paramQName) { this.name = paramQName; }
  
  public QName getQName() { return this.name; }
  
  public void addPart(Part paramPart) {
    String str = paramPart.getName();
    this.parts.put(str, paramPart);
    this.additionOrderOfParts.add(str);
  }
  
  public Part getPart(String paramString) { return (Part)this.parts.get(paramString); }
  
  public Part removePart(String paramString) { return (Part)this.parts.remove(paramString); }
  
  public Map getParts() { return this.parts; }
  
  public List getOrderedParts(List paramList) {
    Vector vector = new Vector();
    if (paramList == null)
      paramList = this.additionOrderOfParts; 
    for (String str : paramList) {
      Part part = getPart(str);
      if (part != null)
        vector.add(part); 
    } 
    return vector;
  }
  
  public void setUndefined(boolean paramBoolean) { this.isUndefined = paramBoolean; }
  
  public boolean isUndefined() { return this.isUndefined; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Message: name=" + this.name);
    if (this.parts != null) {
      Iterator iterator = this.parts.values().iterator();
      while (iterator.hasNext())
        stringBuffer.append("\n" + iterator.next()); 
    } 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\MessageImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */