package com.ibm.wsdl;

import java.util.Arrays;
import java.util.List;
import javax.wsdl.Definition;
import javax.wsdl.Import;

public class ImportImpl extends AbstractWSDLElement implements Import {
  protected String namespaceURI = null;
  
  protected String locationURI = null;
  
  protected Definition definition = null;
  
  protected List nativeAttributeNames = Arrays.asList(Constants.IMPORT_ATTR_NAMES);
  
  public static final long serialVersionUID = 1L;
  
  public void setNamespaceURI(String paramString) { this.namespaceURI = paramString; }
  
  public String getNamespaceURI() { return this.namespaceURI; }
  
  public void setLocationURI(String paramString) { this.locationURI = paramString; }
  
  public String getLocationURI() { return this.locationURI; }
  
  public void setDefinition(Definition paramDefinition) { this.definition = paramDefinition; }
  
  public Definition getDefinition() { return this.definition; }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Import:");
    if (this.namespaceURI != null)
      stringBuffer.append("\nnamespaceURI=" + this.namespaceURI); 
    if (this.locationURI != null)
      stringBuffer.append("\nlocationURI=" + this.locationURI); 
    if (this.definition != null) {
      stringBuffer.append("\ndefinition=" + this.definition.getDocumentBaseURI());
      stringBuffer.append("\ndefinition namespaceURI=" + this.definition.getTargetNamespace());
    } 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\ImportImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */