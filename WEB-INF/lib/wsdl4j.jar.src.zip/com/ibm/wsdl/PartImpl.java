package com.ibm.wsdl;

import java.util.Arrays;
import java.util.List;
import javax.wsdl.Part;
import javax.xml.namespace.QName;

public class PartImpl extends AbstractWSDLElement implements Part {
  protected String name = null;
  
  protected QName elementName = null;
  
  protected QName typeName = null;
  
  protected List nativeAttributeNames = Arrays.asList(Constants.PART_ATTR_NAMES);
  
  public static final long serialVersionUID = 1L;
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setElementName(QName paramQName) { this.elementName = paramQName; }
  
  public QName getElementName() { return this.elementName; }
  
  public void setTypeName(QName paramQName) { this.typeName = paramQName; }
  
  public QName getTypeName() { return this.typeName; }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Part: name=" + this.name);
    if (this.elementName != null)
      stringBuffer.append("\nelementName=" + this.elementName); 
    if (this.typeName != null)
      stringBuffer.append("\ntypeName=" + this.typeName); 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\PartImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */