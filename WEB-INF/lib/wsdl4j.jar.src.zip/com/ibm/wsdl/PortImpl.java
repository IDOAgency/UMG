package com.ibm.wsdl;

import java.util.Arrays;
import java.util.List;
import javax.wsdl.Binding;
import javax.wsdl.Port;

public class PortImpl extends AbstractWSDLElement implements Port {
  protected String name = null;
  
  protected Binding binding = null;
  
  protected List nativeAttributeNames = Arrays.asList(Constants.PORT_ATTR_NAMES);
  
  public static final long serialVersionUID = 1L;
  
  public void setName(String paramString) { this.name = paramString; }
  
  public String getName() { return this.name; }
  
  public void setBinding(Binding paramBinding) { this.binding = paramBinding; }
  
  public Binding getBinding() { return this.binding; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Port: name=" + this.name);
    if (this.binding != null)
      stringBuffer.append("\n" + this.binding); 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\PortImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */