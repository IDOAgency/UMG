package com.ibm.wsdl;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.Binding;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.PortType;
import javax.xml.namespace.QName;

public class BindingImpl extends AbstractWSDLElement implements Binding {
  protected QName name = null;
  
  protected PortType portType = null;
  
  protected List bindingOperations = new Vector();
  
  protected List nativeAttributeNames = Arrays.asList(Constants.BINDING_ATTR_NAMES);
  
  protected boolean isUndefined = true;
  
  public static final long serialVersionUID = 1L;
  
  public void setQName(QName paramQName) { this.name = paramQName; }
  
  public QName getQName() { return this.name; }
  
  public void setPortType(PortType paramPortType) { this.portType = paramPortType; }
  
  public PortType getPortType() { return this.portType; }
  
  public void addBindingOperation(BindingOperation paramBindingOperation) { this.bindingOperations.add(paramBindingOperation); }
  
  public BindingOperation getBindingOperation(String paramString1, String paramString2, String paramString3) {
    boolean bool = false;
    BindingOperation bindingOperation = null;
    for (BindingOperation bindingOperation1 : this.bindingOperations) {
      String str = bindingOperation1.getName();
      if (paramString1 != null && str != null) {
        if (!paramString1.equals(str))
          bindingOperation1 = null; 
      } else if (paramString1 != null || str != null) {
        bindingOperation1 = null;
      } 
      if (bindingOperation1 != null && paramString2 != null) {
        PortType portType1 = getPortType();
        OperationType operationType = null;
        if (portType1 != null) {
          Operation operation = portType1.getOperation(paramString1, paramString2, paramString3);
          if (operation != null)
            operationType = operation.getStyle(); 
        } 
        String str1 = str;
        if (operationType == OperationType.REQUEST_RESPONSE) {
          str1 = str + "Request";
        } else if (operationType == OperationType.SOLICIT_RESPONSE) {
          str1 = str + "Solicit";
        } 
        boolean bool1 = paramString2.equals(str1);
        BindingInput bindingInput = bindingOperation1.getBindingInput();
        if (bindingInput != null) {
          String str2 = bindingInput.getName();
          if (str2 == null) {
            if (!bool1 && !paramString2.equals(":none"))
              bindingOperation1 = null; 
          } else if (!str2.equals(paramString2)) {
            bindingOperation1 = null;
          } 
        } else {
          bindingOperation1 = null;
        } 
      } 
      if (bindingOperation1 != null && paramString3 != null) {
        PortType portType1 = getPortType();
        OperationType operationType = null;
        if (portType1 != null) {
          Operation operation = portType1.getOperation(paramString1, paramString2, paramString3);
          if (operation != null)
            operationType = operation.getStyle(); 
        } 
        String str1 = str;
        if (operationType == OperationType.REQUEST_RESPONSE || operationType == OperationType.SOLICIT_RESPONSE)
          str1 = str + "Response"; 
        boolean bool1 = paramString3.equals(str1);
        BindingOutput bindingOutput = bindingOperation1.getBindingOutput();
        if (bindingOutput != null) {
          String str2 = bindingOutput.getName();
          if (str2 == null) {
            if (!bool1 && !paramString3.equals(":none"))
              bindingOperation1 = null; 
          } else if (!str2.equals(paramString3)) {
            bindingOperation1 = null;
          } 
        } else {
          bindingOperation1 = null;
        } 
      } 
      if (bindingOperation1 != null) {
        if (bool)
          throw new IllegalArgumentException("Duplicate operation with name=" + paramString1 + ((paramString2 != null) ? (", inputName=" + paramString2) : "") + ((paramString3 != null) ? (", outputName=" + paramString3) : "") + ", found in binding '" + getQName() + "'."); 
        bool = true;
        bindingOperation = bindingOperation1;
      } 
    } 
    return bindingOperation;
  }
  
  public List getBindingOperations() { return this.bindingOperations; }
  
  public BindingOperation removeBindingOperation(String paramString1, String paramString2, String paramString3) {
    BindingOperation bindingOperation = getBindingOperation(paramString1, paramString2, paramString3);
    return this.bindingOperations.remove(bindingOperation) ? bindingOperation : null;
  }
  
  public void setUndefined(boolean paramBoolean) { this.isUndefined = paramBoolean; }
  
  public boolean isUndefined() { return this.isUndefined; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Binding: name=");
    stringBuffer.append(this.name);
    if (this.portType != null) {
      stringBuffer.append("\n");
      stringBuffer.append(this.portType);
    } 
    if (this.bindingOperations != null) {
      Iterator iterator = this.bindingOperations.iterator();
      while (iterator.hasNext()) {
        stringBuffer.append("\n");
        stringBuffer.append(iterator.next());
      } 
    } 
    String str = super.toString();
    if (!str.equals("")) {
      stringBuffer.append("\n");
      stringBuffer.append(str);
    } 
    return stringBuffer.toString();
  }
  
  public List getNativeAttributeNames() { return this.nativeAttributeNames; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsdl\BindingImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */