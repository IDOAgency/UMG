package com.ibm.wsdl.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;

public class IOUtils {
  static boolean debug = false;
  
  public static String getStringFromReader(Reader paramReader) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(paramReader);
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    String str;
    while ((str = bufferedReader.readLine()) != null)
      printWriter.println(str); 
    printWriter.flush();
    return stringWriter.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsd\\util\IOUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */