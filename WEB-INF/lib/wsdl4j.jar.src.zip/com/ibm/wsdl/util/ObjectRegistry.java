package com.ibm.wsdl.util;

import java.util.Hashtable;
import java.util.Map;

public class ObjectRegistry {
  Hashtable reg = new Hashtable();
  
  ObjectRegistry parent = null;
  
  public ObjectRegistry() {}
  
  public ObjectRegistry(Map paramMap) {
    if (paramMap != null)
      for (String str : paramMap.keySet())
        register(str, paramMap.get(str));  
  }
  
  public ObjectRegistry(ObjectRegistry paramObjectRegistry) { this.parent = paramObjectRegistry; }
  
  public void register(String paramString, Object paramObject) { this.reg.put(paramString, paramObject); }
  
  public void unregister(String paramString) { this.reg.remove(paramString); }
  
  public Object lookup(String paramString) throws IllegalArgumentException {
    Object object = this.reg.get(paramString);
    if (object == null && this.parent != null)
      object = this.parent.lookup(paramString); 
    if (object == null)
      throw new IllegalArgumentException("object '" + paramString + "' not in registry"); 
    return object;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsd\\util\ObjectRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */