package com.ibm.wsdl.util.xml;

import javax.xml.namespace.QName;
import org.w3c.dom.Node;

public class QNameUtils {
  public static boolean matches(QName paramQName, Node paramNode) { return (paramNode != null && paramQName.equals(newQName(paramNode))); }
  
  public static QName newQName(Node paramNode) { return (paramNode != null) ? new QName(paramNode.getNamespaceURI(), paramNode.getLocalName()) : new QName(null, null); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsd\\util\xml\QNameUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */