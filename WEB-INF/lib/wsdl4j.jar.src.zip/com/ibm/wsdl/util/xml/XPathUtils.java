package com.ibm.wsdl.util.xml;

import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

public class XPathUtils {
  private static Node getPreviousTypedNode(Node paramNode, short paramShort) {
    for (paramNode = paramNode.getPreviousSibling(); paramNode != null && paramNode.getNodeType() != paramShort; paramNode = paramNode.getPreviousSibling());
    return paramNode;
  }
  
  private static Node getNextTypedNode(Node paramNode, short paramShort) {
    for (paramNode = paramNode.getNextSibling(); paramNode != null && paramNode.getNodeType() != paramShort; paramNode = paramNode.getNextSibling());
    return paramNode;
  }
  
  private static String getValue(Node paramNode, short paramShort) {
    switch (paramShort) {
      case 1:
        return ((Element)paramNode).getTagName();
      case 3:
        return ((Text)paramNode).getData();
      case 7:
        return ((ProcessingInstruction)paramNode).getData();
    } 
    return "";
  }
  
  private static short getNodeType(Node paramNode) { return (paramNode != null) ? paramNode.getNodeType() : -1; }
  
  private static String getXPathFromVector(Vector paramVector) {
    StringBuffer stringBuffer = new StringBuffer();
    int i = paramVector.size();
    for (byte b = 0; b < i; b++) {
      String str2;
      Node node = (Node)paramVector.elementAt(b);
      short s = getNodeType(node);
      String str1 = getValue(node, s);
      byte b1 = 1;
      for (node = getPreviousTypedNode(node, s); node != null; node = getPreviousTypedNode(node, s)) {
        if (s == 1) {
          if (getValue(node, s).equals(str1))
            b1++; 
        } else {
          b1++;
        } 
      } 
      boolean bool = (b1 > 1) ? 1 : 0;
      if (!bool) {
        node = (Node)paramVector.elementAt(b);
        node = getNextTypedNode(node, s);
        while (!bool && node != null) {
          if (s == 1) {
            if (getValue(node, s).equals(str1)) {
              bool = true;
              continue;
            } 
            node = getNextTypedNode(node, s);
            continue;
          } 
          bool = true;
        } 
      } 
      switch (s) {
        case 3:
          str2 = "text()";
          break;
        case 7:
          str2 = "processing-instruction()";
          break;
        default:
          str2 = str1;
          break;
      } 
      if (str2 != null && str2.length() > 0)
        stringBuffer.append('/' + str2); 
      if (bool)
        stringBuffer.append("[" + b1 + "]"); 
    } 
    return stringBuffer.toString();
  }
  
  private static Vector getVectorPathFromNode(Node paramNode) {
    Vector vector = new Vector();
    while (paramNode != null) {
      vector.insertElementAt(paramNode, 0);
      paramNode = paramNode.getParentNode();
    } 
    return vector;
  }
  
  public static String getXPathExprFromNode(Node paramNode) throws IllegalArgumentException {
    short s = getNodeType(paramNode);
    switch (s) {
      case 1:
      case 3:
      case 7:
        return getXPathFromVector(getVectorPathFromNode(paramNode));
      case 9:
        return "/";
    } 
    throw new IllegalArgumentException("Only works for element, text, document, and PI nodes.");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsd\\util\xml\XPathUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */