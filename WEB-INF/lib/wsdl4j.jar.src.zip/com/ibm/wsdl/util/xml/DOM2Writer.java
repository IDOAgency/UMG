package com.ibm.wsdl.util.xml;

import com.ibm.wsdl.util.ObjectRegistry;
import com.ibm.wsdl.util.StringUtils;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DOM2Writer {
  private static String NS_URI_XMLNS = "http://www.w3.org/2000/xmlns/";
  
  private static String NS_URI_XML = "http://www.w3.org/XML/1998/namespace";
  
  private static Map xmlEncodingMap = new HashMap();
  
  public static String nodeToString(Node paramNode) { return nodeToString(paramNode, new HashMap()); }
  
  public static String nodeToString(Node paramNode, Map paramMap) {
    StringWriter stringWriter = new StringWriter();
    serializeAsXML(paramNode, paramMap, stringWriter);
    return stringWriter.toString();
  }
  
  public static void serializeElementAsDocument(Element paramElement, Writer paramWriter) { serializeElementAsDocument(paramElement, new HashMap(), paramWriter); }
  
  public static void serializeElementAsDocument(Element paramElement, Map paramMap, Writer paramWriter) {
    PrintWriter printWriter = new PrintWriter(paramWriter);
    String str1 = (paramWriter instanceof OutputStreamWriter) ? ((OutputStreamWriter)paramWriter).getEncoding() : null;
    String str2 = java2XMLEncoding(str1);
    if (str2 != null) {
      printWriter.println("<?xml version=\"1.0\" encoding=\"" + str2 + "\"?>");
    } else {
      printWriter.println("<?xml version=\"1.0\"?>");
    } 
    serializeAsXML(paramElement, paramMap, paramWriter);
  }
  
  public static void serializeAsXML(Node paramNode, Writer paramWriter) { serializeAsXML(paramNode, new HashMap(), paramWriter); }
  
  public static void serializeAsXML(Node paramNode, Map paramMap, Writer paramWriter) {
    ObjectRegistry objectRegistry = new ObjectRegistry(paramMap);
    objectRegistry.register("xml", NS_URI_XML);
    PrintWriter printWriter = new PrintWriter(paramWriter);
    String str = (paramWriter instanceof OutputStreamWriter) ? ((OutputStreamWriter)paramWriter).getEncoding() : null;
    print(paramNode, objectRegistry, printWriter, java2XMLEncoding(str));
  }
  
  private static void print(Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter, String paramString) {
    NodeList nodeList2;
    byte b;
    int i;
    NamedNodeMap namedNodeMap;
    String str2;
    NodeList nodeList1;
    String str1;
    if (paramNode == null)
      return; 
    boolean bool = false;
    short s = paramNode.getNodeType();
    switch (s) {
      case 9:
        if (paramString != null) {
          paramPrintWriter.println("<?xml version=\"1.0\" encoding=\"" + paramString + "\"?>");
        } else {
          paramPrintWriter.println("<?xml version=\"1.0\"?>");
        } 
        nodeList1 = paramNode.getChildNodes();
        if (nodeList1 != null) {
          int j = nodeList1.getLength();
          for (byte b1 = 0; b1 < j; b1++)
            print(nodeList1.item(b1), paramObjectRegistry, paramPrintWriter, paramString); 
        } 
        break;
      case 1:
        paramObjectRegistry = new ObjectRegistry(paramObjectRegistry);
        paramPrintWriter.print('<' + paramNode.getNodeName());
        str1 = paramNode.getPrefix();
        str2 = paramNode.getNamespaceURI();
        if (str1 != null && str2 != null) {
          boolean bool1 = false;
          try {
            String str = (String)paramObjectRegistry.lookup(str1);
            if (str2.equals(str))
              bool1 = true; 
          } catch (IllegalArgumentException illegalArgumentException) {}
          if (!bool1)
            printNamespaceDecl(paramNode, paramObjectRegistry, paramPrintWriter); 
        } 
        namedNodeMap = paramNode.getAttributes();
        i = (namedNodeMap != null) ? namedNodeMap.getLength() : 0;
        for (b = 0; b < i; b++) {
          Attr attr = (Attr)namedNodeMap.item(b);
          paramPrintWriter.print(' ' + attr.getNodeName() + "=\"" + normalize(attr.getValue()) + '"');
          String str3 = attr.getPrefix();
          String str4 = attr.getNamespaceURI();
          if (str3 != null && str4 != null) {
            boolean bool1 = false;
            try {
              String str = (String)paramObjectRegistry.lookup(str3);
              if (str4.equals(str))
                bool1 = true; 
            } catch (IllegalArgumentException illegalArgumentException) {}
            if (!bool1)
              printNamespaceDecl(attr, paramObjectRegistry, paramPrintWriter); 
          } 
        } 
        nodeList2 = paramNode.getChildNodes();
        if (nodeList2 != null) {
          int j = nodeList2.getLength();
          bool = (j > 0) ? 1 : 0;
          if (bool)
            paramPrintWriter.print('>'); 
          for (byte b1 = 0; b1 < j; b1++)
            print(nodeList2.item(b1), paramObjectRegistry, paramPrintWriter, paramString); 
        } else {
          bool = false;
        } 
        if (!bool)
          paramPrintWriter.print("/>"); 
        break;
      case 5:
        paramPrintWriter.print('&');
        paramPrintWriter.print(paramNode.getNodeName());
        paramPrintWriter.print(';');
        break;
      case 4:
        paramPrintWriter.print("<![CDATA[");
        paramPrintWriter.print(paramNode.getNodeValue());
        paramPrintWriter.print("]]>");
        break;
      case 3:
        paramPrintWriter.print(normalize(paramNode.getNodeValue()));
        break;
      case 8:
        paramPrintWriter.print("<!--");
        paramPrintWriter.print(paramNode.getNodeValue());
        paramPrintWriter.print("-->");
        break;
      case 7:
        paramPrintWriter.print("<?");
        paramPrintWriter.print(paramNode.getNodeName());
        str1 = paramNode.getNodeValue();
        if (str1 != null && str1.length() > 0) {
          paramPrintWriter.print(' ');
          paramPrintWriter.print(str1);
        } 
        paramPrintWriter.println("?>");
        break;
    } 
    if (s == 1 && bool == true) {
      paramPrintWriter.print("</");
      paramPrintWriter.print(paramNode.getNodeName());
      paramPrintWriter.print('>');
      bool = false;
    } 
  }
  
  public static String java2XMLEncoding(String paramString) { return (String)xmlEncodingMap.get(paramString); }
  
  private static void printNamespaceDecl(Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter) {
    switch (paramNode.getNodeType()) {
      case 2:
        printNamespaceDecl(((Attr)paramNode).getOwnerElement(), paramNode, paramObjectRegistry, paramPrintWriter);
        break;
      case 1:
        printNamespaceDecl((Element)paramNode, paramNode, paramObjectRegistry, paramPrintWriter);
        break;
    } 
  }
  
  private static void printNamespaceDecl(Element paramElement, Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter) {
    String str1 = paramNode.getNamespaceURI();
    String str2 = paramNode.getPrefix();
    if (!str1.equals(NS_URI_XMLNS) || !str2.equals("xmlns")) {
      if (DOMUtils.getAttributeNS(paramElement, NS_URI_XMLNS, str2) == null)
        paramPrintWriter.print(" xmlns:" + str2 + "=\"" + str1 + '"'); 
    } else {
      str2 = paramNode.getLocalName();
      str1 = paramNode.getNodeValue();
    } 
    paramObjectRegistry.register(str2, str1);
  }
  
  private static String normalize(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    int i = (paramString != null) ? paramString.length() : 0;
    for (byte b = 0; b < i; b++) {
      char c = paramString.charAt(b);
      switch (c) {
        case '<':
          stringBuffer.append("&lt;");
          break;
        case '>':
          stringBuffer.append("&gt;");
          break;
        case '&':
          stringBuffer.append("&amp;");
          break;
        case '"':
          stringBuffer.append("&quot;");
          break;
        case '\n':
          if (b > 0) {
            char c1 = stringBuffer.charAt(stringBuffer.length() - 1);
            if (c1 != '\r') {
              stringBuffer.append(StringUtils.lineSeparator);
              break;
            } 
            stringBuffer.append('\n');
            break;
          } 
          stringBuffer.append(StringUtils.lineSeparator);
          break;
        default:
          stringBuffer.append(c);
          break;
      } 
    } 
    return stringBuffer.toString();
  }
  
  static  {
    xmlEncodingMap.put(null, "UTF-8");
    xmlEncodingMap.put(System.getProperty("file.encoding"), "UTF-8");
    xmlEncodingMap.put("UTF8", "UTF-8");
    xmlEncodingMap.put("UTF-16", "UTF-16");
    xmlEncodingMap.put("UnicodeBig", "UTF-16");
    xmlEncodingMap.put("UnicodeLittle", "UTF-16");
    xmlEncodingMap.put("ASCII", "US-ASCII");
    xmlEncodingMap.put("ISO8859_1", "ISO-8859-1");
    xmlEncodingMap.put("ISO8859_2", "ISO-8859-2");
    xmlEncodingMap.put("ISO8859_3", "ISO-8859-3");
    xmlEncodingMap.put("ISO8859_4", "ISO-8859-4");
    xmlEncodingMap.put("ISO8859_5", "ISO-8859-5");
    xmlEncodingMap.put("ISO8859_6", "ISO-8859-6");
    xmlEncodingMap.put("ISO8859_7", "ISO-8859-7");
    xmlEncodingMap.put("ISO8859_8", "ISO-8859-8");
    xmlEncodingMap.put("ISO8859_9", "ISO-8859-9");
    xmlEncodingMap.put("ISO8859_13", "ISO-8859-13");
    xmlEncodingMap.put("ISO8859_15_FDIS", "ISO-8859-15");
    xmlEncodingMap.put("GBK", "GBK");
    xmlEncodingMap.put("Big5", "Big5");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsd\\util\xml\DOM2Writer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */