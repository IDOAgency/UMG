package com.ibm.wsdl.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

public class StringUtils {
  public static final String lineSeparator = System.getProperty("line.separator", "\n");
  
  public static final String lineSeparatorStr = cleanString(lineSeparator);
  
  public static String cleanString(String paramString) {
    if (paramString == null)
      return null; 
    char[] arrayOfChar = paramString.toCharArray();
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < arrayOfChar.length; b++) {
      switch (arrayOfChar[b]) {
        case '"':
          stringBuffer.append("\\\"");
          break;
        case '\\':
          stringBuffer.append("\\\\");
          break;
        case '\n':
          stringBuffer.append("\\n");
          break;
        case '\r':
          stringBuffer.append("\\r");
          break;
        default:
          stringBuffer.append(arrayOfChar[b]);
          break;
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static String getClassName(Class paramClass) {
    String str = paramClass.getName();
    return paramClass.isArray() ? parseDescriptor(str) : str;
  }
  
  private static String parseDescriptor(String paramString) {
    char[] arrayOfChar = paramString.toCharArray();
    byte b = 0;
    int i;
    for (i = 0; arrayOfChar[i] == '['; i++)
      b++; 
    StringBuffer stringBuffer = new StringBuffer();
    switch (arrayOfChar[i++]) {
      case 'B':
        stringBuffer.append("byte");
        break;
      case 'C':
        stringBuffer.append("char");
        break;
      case 'D':
        stringBuffer.append("double");
        break;
      case 'F':
        stringBuffer.append("float");
        break;
      case 'I':
        stringBuffer.append("int");
        break;
      case 'J':
        stringBuffer.append("long");
        break;
      case 'S':
        stringBuffer.append("short");
        break;
      case 'Z':
        stringBuffer.append("boolean");
        break;
      case 'L':
        stringBuffer.append(arrayOfChar, i, arrayOfChar.length - i - 1);
        break;
    } 
    for (i = 0; i < b; i++)
      stringBuffer.append("[]"); 
    return stringBuffer.toString();
  }
  
  public static URL getURL(URL paramURL, String paramString) throws MalformedURLException {
    try {
      return new URL(paramURL, paramString);
    } catch (MalformedURLException malformedURLException) {
      File file = new File(paramString);
      if (paramURL == null || (paramURL != null && file.isAbsolute()))
        return file.toURL(); 
      throw malformedURLException;
    } 
  }
  
  public static InputStream getContentAsInputStream(URL paramURL) throws SecurityException, IllegalArgumentException, IOException {
    if (paramURL == null)
      throw new IllegalArgumentException("URL cannot be null."); 
    try {
      InputStream inputStream = paramURL.openStream();
      if (inputStream == null)
        throw new IllegalArgumentException("No content."); 
      return inputStream;
    } catch (SecurityException securityException) {
      throw new SecurityException("Your JVM's SecurityManager has disallowed this.");
    } catch (FileNotFoundException fileNotFoundException) {
      throw new FileNotFoundException("This file was not found: " + paramURL);
    } 
  }
  
  public static List parseNMTokens(String paramString) {
    StringTokenizer stringTokenizer = new StringTokenizer(paramString, " ");
    Vector vector = new Vector();
    while (stringTokenizer.hasMoreTokens())
      vector.add(stringTokenizer.nextToken()); 
    return vector;
  }
  
  public static String getNMTokens(List paramList) {
    if (paramList != null) {
      StringBuffer stringBuffer = new StringBuffer();
      int i = paramList.size();
      for (byte b = 0; b < i; b++) {
        String str = (String)paramList.get(b);
        stringBuffer.append(((b > 0) ? " " : "") + str);
      } 
      return stringBuffer.toString();
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\com\ibm\wsd\\util\StringUtils.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */