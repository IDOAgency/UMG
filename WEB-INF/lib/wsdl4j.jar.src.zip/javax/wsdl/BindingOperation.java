package javax.wsdl;

import java.util.Map;

public interface BindingOperation extends WSDLElement {
  void setName(String paramString);
  
  String getName();
  
  void setOperation(Operation paramOperation);
  
  Operation getOperation();
  
  void setBindingInput(BindingInput paramBindingInput);
  
  BindingInput getBindingInput();
  
  void setBindingOutput(BindingOutput paramBindingOutput);
  
  BindingOutput getBindingOutput();
  
  void addBindingFault(BindingFault paramBindingFault);
  
  BindingFault removeBindingFault(String paramString);
  
  BindingFault getBindingFault(String paramString);
  
  Map getBindingFaults();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\BindingOperation.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */