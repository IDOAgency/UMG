package javax.wsdl;

import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;

public interface Message extends WSDLElement {
  void setQName(QName paramQName);
  
  QName getQName();
  
  void addPart(Part paramPart);
  
  Part getPart(String paramString);
  
  Part removePart(String paramString);
  
  Map getParts();
  
  List getOrderedParts(List paramList);
  
  void setUndefined(boolean paramBoolean);
  
  boolean isUndefined();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Message.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */