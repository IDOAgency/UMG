package javax.wsdl;

public class WSDLException extends Exception {
  public static final long serialVersionUID = 1L;
  
  public static final String INVALID_WSDL = "INVALID_WSDL";
  
  public static final String PARSER_ERROR = "PARSER_ERROR";
  
  public static final String OTHER_ERROR = "OTHER_ERROR";
  
  public static final String CONFIGURATION_ERROR = "CONFIGURATION_ERROR";
  
  public static final String UNBOUND_PREFIX = "UNBOUND_PREFIX";
  
  public static final String NO_PREFIX_SPECIFIED = "NO_PREFIX_SPECIFIED";
  
  private String faultCode = null;
  
  private Throwable targetThrowable = null;
  
  private String location = null;
  
  public WSDLException(String paramString1, String paramString2, Throwable paramThrowable) {
    super(paramString2, paramThrowable);
    setFaultCode(paramString1);
  }
  
  public WSDLException(String paramString1, String paramString2) { this(paramString1, paramString2, null); }
  
  public void setFaultCode(String paramString) { this.faultCode = paramString; }
  
  public String getFaultCode() { return this.faultCode; }
  
  public void setTargetException(Throwable paramThrowable) { this.targetThrowable = paramThrowable; }
  
  public Throwable getTargetException() { return (this.targetThrowable == null) ? getCause() : this.targetThrowable; }
  
  public void setLocation(String paramString) { this.location = paramString; }
  
  public String getLocation() { return this.location; }
  
  public String getMessage() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("WSDLException");
    if (this.location != null)
      try {
        stringBuffer.append(" (at " + this.location + ")");
      } catch (IllegalArgumentException illegalArgumentException) {} 
    if (this.faultCode != null)
      stringBuffer.append(": faultCode=" + this.faultCode); 
    String str1 = super.getMessage();
    String str2 = null;
    String str3 = null;
    if (getTargetException() != null) {
      str2 = getTargetException().getMessage();
      str3 = getTargetException().getClass().getName();
    } 
    if (str1 != null && (str2 == null || !str1.equals(str2)))
      stringBuffer.append(": " + str1); 
    if (str3 != null)
      stringBuffer.append(": " + str3); 
    if (str2 != null)
      stringBuffer.append(": " + str2); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\WSDLException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */