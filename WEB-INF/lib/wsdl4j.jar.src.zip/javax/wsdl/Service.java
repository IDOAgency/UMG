package javax.wsdl;

import java.util.Map;
import javax.xml.namespace.QName;

public interface Service extends WSDLElement {
  void setQName(QName paramQName);
  
  QName getQName();
  
  void addPort(Port paramPort);
  
  Port getPort(String paramString);
  
  Port removePort(String paramString);
  
  Map getPorts();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Service.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */