package javax.wsdl;

import java.util.List;
import javax.xml.namespace.QName;

public interface PortType extends WSDLElement {
  void setQName(QName paramQName);
  
  QName getQName();
  
  void addOperation(Operation paramOperation);
  
  Operation getOperation(String paramString1, String paramString2, String paramString3);
  
  List getOperations();
  
  Operation removeOperation(String paramString1, String paramString2, String paramString3);
  
  void setUndefined(boolean paramBoolean);
  
  boolean isUndefined();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\PortType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */