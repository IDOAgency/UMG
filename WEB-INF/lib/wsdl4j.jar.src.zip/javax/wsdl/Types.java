package javax.wsdl;

public interface Types extends WSDLElement {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Types.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */