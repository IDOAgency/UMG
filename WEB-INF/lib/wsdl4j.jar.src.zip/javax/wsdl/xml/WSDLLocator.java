package javax.wsdl.xml;

import org.xml.sax.InputSource;

public interface WSDLLocator {
  InputSource getBaseInputSource();
  
  InputSource getImportInputSource(String paramString1, String paramString2);
  
  String getBaseURI();
  
  String getLatestImportURI();
  
  void close();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\xml\WSDLLocator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */