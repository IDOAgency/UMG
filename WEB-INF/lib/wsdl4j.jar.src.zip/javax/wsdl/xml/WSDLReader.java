package javax.wsdl.xml;

import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensionRegistry;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

public interface WSDLReader {
  void setFeature(String paramString, boolean paramBoolean) throws IllegalArgumentException;
  
  boolean getFeature(String paramString) throws IllegalArgumentException;
  
  void setExtensionRegistry(ExtensionRegistry paramExtensionRegistry);
  
  ExtensionRegistry getExtensionRegistry();
  
  void setFactoryImplName(String paramString) throws UnsupportedOperationException;
  
  String getFactoryImplName();
  
  Definition readWSDL(String paramString) throws WSDLException;
  
  Definition readWSDL(String paramString1, String paramString2) throws WSDLException;
  
  Definition readWSDL(String paramString, Element paramElement) throws WSDLException;
  
  Definition readWSDL(WSDLLocator paramWSDLLocator, Element paramElement) throws WSDLException;
  
  Definition readWSDL(String paramString, Document paramDocument) throws WSDLException;
  
  Definition readWSDL(String paramString, InputSource paramInputSource) throws WSDLException;
  
  Definition readWSDL(WSDLLocator paramWSDLLocator) throws WSDLException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\xml\WSDLReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */