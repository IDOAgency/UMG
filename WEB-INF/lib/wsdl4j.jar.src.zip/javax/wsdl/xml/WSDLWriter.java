package javax.wsdl.xml;

import java.io.OutputStream;
import java.io.Writer;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import org.w3c.dom.Document;

public interface WSDLWriter {
  void setFeature(String paramString, boolean paramBoolean) throws IllegalArgumentException;
  
  boolean getFeature(String paramString) throws IllegalArgumentException;
  
  Document getDocument(Definition paramDefinition) throws WSDLException;
  
  void writeWSDL(Definition paramDefinition, Writer paramWriter) throws WSDLException;
  
  void writeWSDL(Definition paramDefinition, OutputStream paramOutputStream) throws WSDLException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\xml\WSDLWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */