package javax.wsdl.extensions.soap;

import java.io.Serializable;
import javax.wsdl.extensions.ExtensibilityElement;

public interface SOAPBinding extends ExtensibilityElement, Serializable {
  void setStyle(String paramString);
  
  String getStyle();
  
  void setTransportURI(String paramString);
  
  String getTransportURI();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\soap\SOAPBinding.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */