package javax.wsdl.extensions.soap;

import java.io.Serializable;
import java.util.List;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.xml.namespace.QName;

public interface SOAPHeader extends ExtensibilityElement, Serializable {
  void setMessage(QName paramQName);
  
  QName getMessage();
  
  void setPart(String paramString);
  
  String getPart();
  
  void setUse(String paramString);
  
  String getUse();
  
  void setEncodingStyles(List paramList);
  
  List getEncodingStyles();
  
  void setNamespaceURI(String paramString);
  
  String getNamespaceURI();
  
  void addSOAPHeaderFault(SOAPHeaderFault paramSOAPHeaderFault);
  
  SOAPHeaderFault removeSOAPHeaderFault(SOAPHeaderFault paramSOAPHeaderFault);
  
  List getSOAPHeaderFaults();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\soap\SOAPHeader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */