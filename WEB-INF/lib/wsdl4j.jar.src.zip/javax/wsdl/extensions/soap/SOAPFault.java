package javax.wsdl.extensions.soap;

import java.io.Serializable;
import java.util.List;
import javax.wsdl.extensions.ExtensibilityElement;

public interface SOAPFault extends ExtensibilityElement, Serializable {
  void setName(String paramString);
  
  String getName();
  
  void setUse(String paramString);
  
  String getUse();
  
  void setEncodingStyles(List paramList);
  
  List getEncodingStyles();
  
  void setNamespaceURI(String paramString);
  
  String getNamespaceURI();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\soap\SOAPFault.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */