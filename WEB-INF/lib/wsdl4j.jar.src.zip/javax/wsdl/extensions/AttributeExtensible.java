package javax.wsdl.extensions;

import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;

public interface AttributeExtensible {
  public static final int NO_DECLARED_TYPE = -1;
  
  public static final int STRING_TYPE = 0;
  
  public static final int QNAME_TYPE = 1;
  
  public static final int LIST_OF_STRINGS_TYPE = 2;
  
  public static final int LIST_OF_QNAMES_TYPE = 3;
  
  void setExtensionAttribute(QName paramQName, Object paramObject);
  
  Object getExtensionAttribute(QName paramQName);
  
  Map getExtensionAttributes();
  
  List getNativeAttributeNames();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\AttributeExtensible.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */