package javax.wsdl.extensions;

import javax.xml.namespace.QName;

public interface ExtensibilityElement {
  void setElementType(QName paramQName);
  
  QName getElementType();
  
  void setRequired(Boolean paramBoolean);
  
  Boolean getRequired();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\ExtensibilityElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */