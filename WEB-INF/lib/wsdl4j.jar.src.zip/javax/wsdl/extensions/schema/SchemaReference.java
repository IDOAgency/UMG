package javax.wsdl.extensions.schema;

import java.io.Serializable;

public interface SchemaReference extends Serializable {
  String getId();
  
  void setId(String paramString);
  
  String getSchemaLocationURI();
  
  void setSchemaLocationURI(String paramString);
  
  Schema getReferencedSchema();
  
  void setReferencedSchema(Schema paramSchema);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\schema\SchemaReference.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */