package javax.wsdl.extensions.schema;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.wsdl.extensions.ExtensibilityElement;
import org.w3c.dom.Element;

public interface Schema extends ExtensibilityElement, Serializable {
  Map getImports();
  
  SchemaImport createImport();
  
  void addImport(SchemaImport paramSchemaImport);
  
  List getIncludes();
  
  SchemaReference createInclude();
  
  void addInclude(SchemaReference paramSchemaReference);
  
  List getRedefines();
  
  SchemaReference createRedefine();
  
  void addRedefine(SchemaReference paramSchemaReference);
  
  void setElement(Element paramElement);
  
  Element getElement();
  
  void setDocumentBaseURI(String paramString);
  
  String getDocumentBaseURI();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\schema\Schema.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */