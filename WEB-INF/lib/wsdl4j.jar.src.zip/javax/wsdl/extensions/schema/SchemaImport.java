package javax.wsdl.extensions.schema;

public interface SchemaImport extends SchemaReference {
  String getNamespaceURI();
  
  void setNamespaceURI(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\schema\SchemaImport.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */