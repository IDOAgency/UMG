package javax.wsdl.extensions;

import java.io.Serializable;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class UnknownExtensibilityElement implements ExtensibilityElement, Serializable {
  protected QName elementType = null;
  
  protected Boolean required = null;
  
  protected Element element = null;
  
  public static final long serialVersionUID = 1L;
  
  public void setElementType(QName paramQName) { this.elementType = paramQName; }
  
  public QName getElementType() { return this.elementType; }
  
  public void setRequired(Boolean paramBoolean) { this.required = paramBoolean; }
  
  public Boolean getRequired() { return this.required; }
  
  public void setElement(Element paramElement) { this.element = paramElement; }
  
  public Element getElement() { return this.element; }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("UnknownExtensibilityElement (" + this.elementType + "):");
    stringBuffer.append("\nrequired=" + this.required);
    if (this.element != null)
      stringBuffer.append("\nelement=" + this.element); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\UnknownExtensibilityElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */