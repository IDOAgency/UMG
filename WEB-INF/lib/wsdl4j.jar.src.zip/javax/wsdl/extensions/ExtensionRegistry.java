package javax.wsdl.extensions;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import javax.wsdl.WSDLException;
import javax.xml.namespace.QName;

public class ExtensionRegistry implements Serializable {
  public static final long serialVersionUID = 1L;
  
  protected Map serializerReg = new Hashtable();
  
  protected Map deserializerReg = new Hashtable();
  
  protected Map extensionTypeReg = new Hashtable();
  
  protected ExtensionSerializer defaultSer = null;
  
  protected ExtensionDeserializer defaultDeser = null;
  
  protected Map extensionAttributeTypeReg = new Hashtable();
  
  public ExtensionRegistry() {
    setDefaultSerializer(new UnknownExtensionSerializer());
    setDefaultDeserializer(new UnknownExtensionDeserializer());
  }
  
  public void setDefaultSerializer(ExtensionSerializer paramExtensionSerializer) { this.defaultSer = paramExtensionSerializer; }
  
  public ExtensionSerializer getDefaultSerializer() { return this.defaultSer; }
  
  public void setDefaultDeserializer(ExtensionDeserializer paramExtensionDeserializer) { this.defaultDeser = paramExtensionDeserializer; }
  
  public ExtensionDeserializer getDefaultDeserializer() { return this.defaultDeser; }
  
  public void registerSerializer(Class paramClass, QName paramQName, ExtensionSerializer paramExtensionSerializer) {
    Map map = (Map)this.serializerReg.get(paramClass);
    if (map == null) {
      map = new Hashtable();
      this.serializerReg.put(paramClass, map);
    } 
    map.put(paramQName, paramExtensionSerializer);
  }
  
  public void registerDeserializer(Class paramClass, QName paramQName, ExtensionDeserializer paramExtensionDeserializer) {
    Map map = (Map)this.deserializerReg.get(paramClass);
    if (map == null) {
      map = new Hashtable();
      this.deserializerReg.put(paramClass, map);
    } 
    map.put(paramQName, paramExtensionDeserializer);
  }
  
  public ExtensionSerializer querySerializer(Class paramClass, QName paramQName) throws WSDLException {
    Map map = (Map)this.serializerReg.get(paramClass);
    ExtensionSerializer extensionSerializer = null;
    if (map != null)
      extensionSerializer = (ExtensionSerializer)map.get(paramQName); 
    if (extensionSerializer == null)
      extensionSerializer = this.defaultSer; 
    if (extensionSerializer == null)
      throw new WSDLException("CONFIGURATION_ERROR", "No ExtensionSerializer found to serialize a '" + paramQName + "' element in the context of a '" + paramClass.getName() + "'."); 
    return extensionSerializer;
  }
  
  public ExtensionDeserializer queryDeserializer(Class paramClass, QName paramQName) throws WSDLException {
    Map map = (Map)this.deserializerReg.get(paramClass);
    ExtensionDeserializer extensionDeserializer = null;
    if (map != null)
      extensionDeserializer = (ExtensionDeserializer)map.get(paramQName); 
    if (extensionDeserializer == null)
      extensionDeserializer = this.defaultDeser; 
    if (extensionDeserializer == null)
      throw new WSDLException("CONFIGURATION_ERROR", "No ExtensionDeserializer found to deserialize a '" + paramQName + "' element in the context of a '" + paramClass.getName() + "'."); 
    return extensionDeserializer;
  }
  
  public Set getAllowableExtensions(Class paramClass) {
    Map map = (Map)this.deserializerReg.get(paramClass);
    return (map != null) ? map.keySet() : null;
  }
  
  public void mapExtensionTypes(Class paramClass1, QName paramQName, Class paramClass2) {
    Map map = (Map)this.extensionTypeReg.get(paramClass1);
    if (map == null) {
      map = new Hashtable();
      this.extensionTypeReg.put(paramClass1, map);
    } 
    map.put(paramQName, paramClass2);
  }
  
  public ExtensibilityElement createExtension(Class paramClass, QName paramQName) throws WSDLException {
    Map map = (Map)this.extensionTypeReg.get(paramClass);
    Class clazz = null;
    if (map != null)
      clazz = (Class)map.get(paramQName); 
    if (clazz == null)
      throw new WSDLException("CONFIGURATION_ERROR", "No Java extensionType found to represent a '" + paramQName + "' element in the context of a '" + paramClass.getName() + "'."); 
    if (!ExtensibilityElement.class.isAssignableFrom(clazz))
      throw new WSDLException("CONFIGURATION_ERROR", "The Java extensionType '" + clazz.getName() + "' does " + "not implement the ExtensibilityElement " + "interface."); 
    try {
      ExtensibilityElement extensibilityElement = (ExtensibilityElement)clazz.newInstance();
      if (extensibilityElement.getElementType() == null)
        extensibilityElement.setElementType(paramQName); 
      return extensibilityElement;
    } catch (Exception exception) {
      throw new WSDLException("CONFIGURATION_ERROR", "Problem instantiating Java extensionType '" + clazz.getName() + "'.", exception);
    } 
  }
  
  public void registerExtensionAttributeType(Class paramClass, QName paramQName, int paramInt) {
    Map map = (Map)this.extensionAttributeTypeReg.get(paramClass);
    if (map == null) {
      map = new Hashtable();
      this.extensionAttributeTypeReg.put(paramClass, map);
    } 
    map.put(paramQName, new Integer(paramInt));
  }
  
  public int queryExtensionAttributeType(Class paramClass, QName paramQName) {
    Map map = (Map)this.extensionAttributeTypeReg.get(paramClass);
    Integer integer = null;
    if (map != null)
      integer = (Integer)map.get(paramQName); 
    return (integer != null) ? integer.intValue() : -1;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\ExtensionRegistry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */