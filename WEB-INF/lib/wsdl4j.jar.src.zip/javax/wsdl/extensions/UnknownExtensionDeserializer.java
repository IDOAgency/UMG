package javax.wsdl.extensions;

import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class UnknownExtensionDeserializer implements ExtensionDeserializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    UnknownExtensibilityElement unknownExtensibilityElement = new UnknownExtensibilityElement();
    String str = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    unknownExtensibilityElement.setElementType(paramQName);
    if (str != null)
      unknownExtensibilityElement.setRequired(new Boolean(str)); 
    unknownExtensibilityElement.setElement(paramElement);
    return unknownExtensibilityElement;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\UnknownExtensionDeserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */