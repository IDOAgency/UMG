package javax.wsdl.extensions.soap12;

import java.io.Serializable;
import javax.wsdl.extensions.ExtensibilityElement;

public interface SOAP12Operation extends ExtensibilityElement, Serializable {
  void setSoapActionURI(String paramString);
  
  String getSoapActionURI();
  
  void setSoapActionRequired(Boolean paramBoolean);
  
  Boolean getSoapActionRequired();
  
  void setStyle(String paramString);
  
  String getStyle();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\soap12\SOAP12Operation.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */