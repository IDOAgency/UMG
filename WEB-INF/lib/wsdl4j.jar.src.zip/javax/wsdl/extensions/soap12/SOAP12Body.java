package javax.wsdl.extensions.soap12;

import java.io.Serializable;
import java.util.List;
import javax.wsdl.extensions.ExtensibilityElement;

public interface SOAP12Body extends ExtensibilityElement, Serializable {
  void setParts(List paramList);
  
  List getParts();
  
  void setUse(String paramString);
  
  String getUse();
  
  void setEncodingStyle(String paramString);
  
  String getEncodingStyle();
  
  void setNamespaceURI(String paramString);
  
  String getNamespaceURI();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\soap12\SOAP12Body.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */