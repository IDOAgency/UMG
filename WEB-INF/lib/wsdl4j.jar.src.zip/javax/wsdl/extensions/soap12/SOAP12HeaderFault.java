package javax.wsdl.extensions.soap12;

import java.io.Serializable;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.xml.namespace.QName;

public interface SOAP12HeaderFault extends ExtensibilityElement, Serializable {
  void setMessage(QName paramQName);
  
  QName getMessage();
  
  void setPart(String paramString);
  
  String getPart();
  
  void setUse(String paramString);
  
  String getUse();
  
  void setEncodingStyle(String paramString);
  
  String getEncodingStyle();
  
  void setNamespaceURI(String paramString);
  
  String getNamespaceURI();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\soap12\SOAP12HeaderFault.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */