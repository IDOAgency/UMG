package javax.wsdl.extensions.mime;

import java.io.Serializable;
import javax.wsdl.extensions.ExtensibilityElement;

public interface MIMEContent extends ExtensibilityElement, Serializable {
  void setPart(String paramString);
  
  String getPart();
  
  void setType(String paramString);
  
  String getType();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\mime\MIMEContent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */