package javax.wsdl.extensions.mime;

import java.io.Serializable;
import javax.wsdl.extensions.ElementExtensible;
import javax.wsdl.extensions.ExtensibilityElement;

public interface MIMEPart extends ElementExtensible, ExtensibilityElement, Serializable {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\mime\MIMEPart.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */