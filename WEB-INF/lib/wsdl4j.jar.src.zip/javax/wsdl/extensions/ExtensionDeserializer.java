package javax.wsdl.extensions;

import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public interface ExtensionDeserializer {
  ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\ExtensionDeserializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */