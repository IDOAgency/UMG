package javax.wsdl.extensions;

import java.util.List;

public interface ElementExtensible {
  void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement);
  
  ExtensibilityElement removeExtensibilityElement(ExtensibilityElement paramExtensibilityElement);
  
  List getExtensibilityElements();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\ElementExtensible.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */