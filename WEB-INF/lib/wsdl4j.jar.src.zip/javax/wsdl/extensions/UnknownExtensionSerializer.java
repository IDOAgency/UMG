package javax.wsdl.extensions;

import com.ibm.wsdl.util.xml.DOM2Writer;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.xml.namespace.QName;

public class UnknownExtensionSerializer implements ExtensionSerializer, Serializable {
  public static final long serialVersionUID = 1L;
  
  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry) throws WSDLException {
    UnknownExtensibilityElement unknownExtensibilityElement = (UnknownExtensibilityElement)paramExtensibilityElement;
    paramPrintWriter.print("    ");
    DOM2Writer.serializeAsXML(unknownExtensibilityElement.getElement(), paramDefinition.getNamespaces(), paramPrintWriter);
    paramPrintWriter.println();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\extensions\UnknownExtensionSerializer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */