package javax.wsdl.factory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Properties;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.xml.WSDLReader;
import javax.wsdl.xml.WSDLWriter;

public abstract class WSDLFactory {
  private static final String PROPERTY_NAME = "javax.wsdl.factory.WSDLFactory";
  
  private static final String PROPERTY_FILE_NAME = "wsdl.properties";
  
  private static final String META_INF_SERVICES_PROPERTY_FILE_NAME = "javax.wsdl.factory.WSDLFactory";
  
  private static final String DEFAULT_FACTORY_IMPL_NAME = "com.ibm.wsdl.factory.WSDLFactoryImpl";
  
  private static String fullPropertyFileName = null;
  
  private static String metaInfServicesFullPropertyFileName = null;
  
  static Class class$javax$wsdl$factory$WSDLFactory;
  
  public static WSDLFactory newInstance() throws WSDLException {
    String str = findFactoryImplName();
    return newInstance(str);
  }
  
  public static WSDLFactory newInstance(String paramString) throws WSDLException {
    if (paramString != null)
      try {
        Class clazz = Class.forName(paramString);
        return (WSDLFactory)clazz.newInstance();
      } catch (Exception exception) {
        throw new WSDLException("CONFIGURATION_ERROR", "Problem instantiating factory implementation.", exception);
      }  
    throw new WSDLException("CONFIGURATION_ERROR", "Unable to find name of factory implementation.");
  }
  
  public static WSDLFactory newInstance(String paramString, ClassLoader paramClassLoader) throws WSDLException {
    if (paramString != null)
      try {
        Class clazz = paramClassLoader.loadClass(paramString);
        return (WSDLFactory)clazz.newInstance();
      } catch (Exception exception) {
        throw new WSDLException("CONFIGURATION_ERROR", "Problem instantiating factory implementation.", exception);
      }  
    throw new WSDLException("CONFIGURATION_ERROR", "Unable to find name of factory implementation.");
  }
  
  public abstract Definition newDefinition();
  
  public abstract WSDLReader newWSDLReader();
  
  public abstract WSDLWriter newWSDLWriter();
  
  public abstract ExtensionRegistry newPopulatedExtensionRegistry();
  
  private static String findFactoryImplName() {
    String str1 = null;
    String str2 = getMetaInfFullPropertyFileName();
    if (str2 != null)
      try {
        InputStream inputStream = (InputStream)AccessController.doPrivileged(new PrivilegedAction(str2) {
              private final String val$metaInfServicesPropFileName;
              
              public Object run() { return ((WSDLFactory.class$javax$wsdl$factory$WSDLFactory == null) ? (WSDLFactory.class$javax$wsdl$factory$WSDLFactory = WSDLFactory.class$("javax.wsdl.factory.WSDLFactory")) : WSDLFactory.class$javax$wsdl$factory$WSDLFactory).getResourceAsStream(this.val$metaInfServicesPropFileName); }
            });
        if (inputStream != null) {
          InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
          BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
          str1 = bufferedReader.readLine();
          bufferedReader.close();
          inputStreamReader.close();
          inputStream.close();
        } 
        if (str1 != null)
          return str1; 
      } catch (IOException iOException) {} 
    try {
      str1 = System.getProperty("javax.wsdl.factory.WSDLFactory");
      if (str1 != null)
        return str1; 
    } catch (SecurityException securityException) {}
    String str3 = getFullPropertyFileName();
    if (str3 != null)
      try {
        Properties properties = new Properties();
        File file = new File(str3);
        FileInputStream fileInputStream = new FileInputStream(file);
        properties.load(fileInputStream);
        fileInputStream.close();
        str1 = properties.getProperty("javax.wsdl.factory.WSDLFactory");
        if (str1 != null)
          return str1; 
      } catch (IOException iOException) {} 
    return "com.ibm.wsdl.factory.WSDLFactoryImpl";
  }
  
  private static String getFullPropertyFileName() {
    if (fullPropertyFileName == null)
      try {
        String str = System.getProperty("java.home");
        fullPropertyFileName = str + File.separator + "lib" + File.separator + "wsdl.properties";
      } catch (SecurityException securityException) {} 
    return fullPropertyFileName;
  }
  
  private static String getMetaInfFullPropertyFileName() {
    if (metaInfServicesFullPropertyFileName == null) {
      String str = "/META-INF/services/";
      metaInfServicesFullPropertyFileName = str + "javax.wsdl.factory.WSDLFactory";
    } 
    return metaInfServicesFullPropertyFileName;
  }
  
  static Class class$(String paramString) {
    try {
      return Class.forName(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new NoClassDefFoundError(classNotFoundException.getMessage());
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\factory\WSDLFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */