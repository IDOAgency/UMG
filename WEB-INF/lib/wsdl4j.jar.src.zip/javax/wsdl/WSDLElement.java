package javax.wsdl;

import java.io.Serializable;
import javax.wsdl.extensions.AttributeExtensible;
import javax.wsdl.extensions.ElementExtensible;
import org.w3c.dom.Element;

public interface WSDLElement extends Serializable, AttributeExtensible, ElementExtensible {
  void setDocumentationElement(Element paramElement);
  
  Element getDocumentationElement();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\WSDLElement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */