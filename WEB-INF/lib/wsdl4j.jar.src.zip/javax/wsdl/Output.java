package javax.wsdl;

public interface Output extends WSDLElement {
  void setName(String paramString);
  
  String getName();
  
  void setMessage(Message paramMessage);
  
  Message getMessage();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Output.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */