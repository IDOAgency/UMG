package javax.wsdl;

import javax.xml.namespace.QName;

public interface Part extends WSDLElement {
  void setName(String paramString);
  
  String getName();
  
  void setElementName(QName paramQName);
  
  QName getElementName();
  
  void setTypeName(QName paramQName);
  
  QName getTypeName();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Part.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */