package javax.wsdl;

public interface Port extends WSDLElement {
  void setName(String paramString);
  
  String getName();
  
  void setBinding(Binding paramBinding);
  
  Binding getBinding();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Port.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */