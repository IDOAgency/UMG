package javax.wsdl;

import java.util.List;
import java.util.Map;

public interface Operation extends WSDLElement {
  void setName(String paramString);
  
  String getName();
  
  void setInput(Input paramInput);
  
  Input getInput();
  
  void setOutput(Output paramOutput);
  
  Output getOutput();
  
  void addFault(Fault paramFault);
  
  Fault getFault(String paramString);
  
  Fault removeFault(String paramString);
  
  Map getFaults();
  
  void setStyle(OperationType paramOperationType);
  
  OperationType getStyle();
  
  void setParameterOrdering(List paramList);
  
  List getParameterOrdering();
  
  void setUndefined(boolean paramBoolean);
  
  boolean isUndefined();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Operation.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */