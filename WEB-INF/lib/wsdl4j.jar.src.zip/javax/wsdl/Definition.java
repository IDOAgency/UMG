package javax.wsdl;

import java.util.List;
import java.util.Map;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.xml.namespace.QName;

public interface Definition extends WSDLElement {
  void setDocumentBaseURI(String paramString);
  
  String getDocumentBaseURI();
  
  void setQName(QName paramQName);
  
  QName getQName();
  
  void setTargetNamespace(String paramString);
  
  String getTargetNamespace();
  
  void addNamespace(String paramString1, String paramString2);
  
  String getNamespace(String paramString);
  
  String removeNamespace(String paramString);
  
  String getPrefix(String paramString);
  
  Map getNamespaces();
  
  void setTypes(Types paramTypes);
  
  Types getTypes();
  
  void addImport(Import paramImport);
  
  Import removeImport(Import paramImport);
  
  List getImports(String paramString);
  
  Map getImports();
  
  void addMessage(Message paramMessage);
  
  Message getMessage(QName paramQName);
  
  Message removeMessage(QName paramQName);
  
  Map getMessages();
  
  void addBinding(Binding paramBinding);
  
  Binding getBinding(QName paramQName);
  
  Binding removeBinding(QName paramQName);
  
  Map getBindings();
  
  Map getAllBindings();
  
  void addPortType(PortType paramPortType);
  
  PortType getPortType(QName paramQName);
  
  PortType removePortType(QName paramQName);
  
  Map getPortTypes();
  
  Map getAllPortTypes();
  
  void addService(Service paramService);
  
  Service getService(QName paramQName);
  
  Service removeService(QName paramQName);
  
  Map getServices();
  
  Map getAllServices();
  
  Binding createBinding();
  
  BindingFault createBindingFault();
  
  BindingInput createBindingInput();
  
  BindingOperation createBindingOperation();
  
  BindingOutput createBindingOutput();
  
  Fault createFault();
  
  Import createImport();
  
  Input createInput();
  
  Message createMessage();
  
  Operation createOperation();
  
  Output createOutput();
  
  Part createPart();
  
  Port createPort();
  
  PortType createPortType();
  
  Service createService();
  
  Types createTypes();
  
  ExtensionRegistry getExtensionRegistry();
  
  void setExtensionRegistry(ExtensionRegistry paramExtensionRegistry);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Definition.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */