package javax.wsdl;

public interface Import extends WSDLElement {
  void setNamespaceURI(String paramString);
  
  String getNamespaceURI();
  
  void setLocationURI(String paramString);
  
  String getLocationURI();
  
  void setDefinition(Definition paramDefinition);
  
  Definition getDefinition();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\Import.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */