package javax.wsdl;

import java.io.ObjectStreamException;
import java.io.Serializable;

public class OperationType implements Serializable {
  private final String id;
  
  private final int intId;
  
  private static int counter = 0;
  
  public static final long serialVersionUID = 1L;
  
  public static OperationType ONE_WAY = new OperationType("ONE_WAY");
  
  public static OperationType REQUEST_RESPONSE = new OperationType("REQUEST_RESPONSE");
  
  public static OperationType SOLICIT_RESPONSE = new OperationType("SOLICIT_RESPONSE");
  
  public static OperationType NOTIFICATION = new OperationType("NOTIFICATION");
  
  private static final OperationType[] INSTANCES = { ONE_WAY, REQUEST_RESPONSE, SOLICIT_RESPONSE, NOTIFICATION };
  
  private OperationType(String paramString) {
    this.id = paramString;
    this.intId = counter++;
  }
  
  private String getId() { return this.id; }
  
  public boolean equals(OperationType paramOperationType) { return (paramOperationType != null && this.id.equals(paramOperationType.getId())); }
  
  public String toString() { return this.id + "," + this.intId; }
  
  private Object readResolve() throws ObjectStreamException { return INSTANCES[this.intId]; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\wsdl4j.jar!\javax\wsdl\OperationType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.0.7
 */