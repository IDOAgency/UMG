/*    */ package org.apache.axis.handlers;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.xml.rpc.handler.HandlerChain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HandlerInfoChainFactory
/*    */   implements Serializable
/*    */ {
/* 27 */   protected List handlerInfos = new ArrayList();
/* 28 */   protected String[] _roles = null;
/*    */ 
/*    */   
/*    */   public HandlerInfoChainFactory() {}
/*    */ 
/*    */   
/* 34 */   public HandlerInfoChainFactory(List handlerInfos) { this.handlerInfos = handlerInfos; }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public List getHandlerInfos() { return this.handlerInfos; }
/*    */ 
/*    */   
/*    */   public HandlerChain createHandlerChain() {
/* 42 */     HandlerChain hc = new HandlerChainImpl(this.handlerInfos);
/* 43 */     hc.setRoles(getRoles());
/* 44 */     return hc;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 49 */   public String[] getRoles() { return this._roles; }
/*    */ 
/*    */ 
/*    */   
/* 53 */   public void setRoles(String[] roles) { this._roles = roles; }
/*    */   
/*    */   public void init(Map map) {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\HandlerInfoChainFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */