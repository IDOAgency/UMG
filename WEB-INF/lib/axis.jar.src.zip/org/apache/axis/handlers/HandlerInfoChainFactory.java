package org.apache.axis.handlers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.xml.rpc.handler.HandlerChain;

public class HandlerInfoChainFactory implements Serializable {
  protected List handlerInfos = new ArrayList();
  
  protected String[] _roles = null;
  
  public HandlerInfoChainFactory() {}
  
  public HandlerInfoChainFactory(List handlerInfos) { this.handlerInfos = handlerInfos; }
  
  public List getHandlerInfos() { return this.handlerInfos; }
  
  public HandlerChain createHandlerChain() {
    HandlerChain hc = new HandlerChainImpl(this.handlerInfos);
    hc.setRoles(getRoles());
    return hc;
  }
  
  public String[] getRoles() { return this._roles; }
  
  public void setRoles(String[] roles) { this._roles = roles; }
  
  public void init(Map map) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\HandlerInfoChainFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */