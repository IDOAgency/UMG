package org.apache.axis.handlers;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.security.AuthenticatedUser;
import org.apache.axis.security.SecurityProvider;
import org.apache.axis.security.simple.SimpleSecurityProvider;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class SimpleAuthenticationHandler extends BasicHandler {
  protected static Log log = LogFactory.getLog(SimpleAuthenticationHandler.class.getName());
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug("Enter: SimpleAuthenticationHandler::invoke"); 
    SimpleSecurityProvider simpleSecurityProvider = (SecurityProvider)msgContext.getProperty("securityProvider");
    if (simpleSecurityProvider == null) {
      simpleSecurityProvider = new SimpleSecurityProvider();
      msgContext.setProperty("securityProvider", simpleSecurityProvider);
    } 
    if (simpleSecurityProvider != null) {
      String userID = msgContext.getUsername();
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("user00", userID)); 
      if (userID == null || userID.equals(""))
        throw new AxisFault("Server.Unauthenticated", Messages.getMessage("cantAuth00", userID), null, null); 
      String passwd = msgContext.getPassword();
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("password00", passwd)); 
      AuthenticatedUser authUser = simpleSecurityProvider.authenticate(msgContext);
      if (authUser == null)
        throw new AxisFault("Server.Unauthenticated", Messages.getMessage("cantAuth01", userID), null, null); 
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("auth00", userID)); 
      msgContext.setProperty("authenticatedUser", authUser);
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: SimpleAuthenticationHandler::invoke"); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\SimpleAuthenticationHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */