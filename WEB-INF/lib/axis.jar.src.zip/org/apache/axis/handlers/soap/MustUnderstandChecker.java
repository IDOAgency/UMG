package org.apache.axis.handlers.soap;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Vector;
import javax.xml.namespace.QName;
import org.apache.axis.AxisFault;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.handlers.BasicHandler;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class MustUnderstandChecker extends BasicHandler {
  private static Log log = LogFactory.getLog(MustUnderstandChecker.class.getName());
  
  private SOAPService service;
  
  public MustUnderstandChecker(SOAPService service) {
    this.service = null;
    this.service = service;
  }
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("semanticCheck00")); 
    Message msg = msgContext.getCurrentMessage();
    if (msg == null)
      return; 
    SOAPEnvelope env = msg.getSOAPEnvelope();
    Vector headers = null;
    if (this.service != null) {
      ArrayList acts = this.service.getActors();
      headers = env.getHeadersByActor(acts);
    } else {
      headers = env.getHeaders();
    } 
    Vector misunderstoodHeaders = null;
    Enumeration enumeration = headers.elements();
    while (enumeration.hasMoreElements()) {
      SOAPHeaderElement header = (SOAPHeaderElement)enumeration.nextElement();
      if (msgContext != null && msgContext.getOperation() != null) {
        OperationDesc oper = msgContext.getOperation();
        if (oper.getParamByQName(header.getQName()) != null)
          continue; 
      } 
      if (header.getMustUnderstand() && !header.isProcessed()) {
        if (misunderstoodHeaders == null)
          misunderstoodHeaders = new Vector(); 
        misunderstoodHeaders.addElement(header);
      } 
    } 
    SOAPConstants soapConstants = msgContext.getSOAPConstants();
    if (misunderstoodHeaders != null) {
      AxisFault fault = new AxisFault(soapConstants.getMustunderstandFaultQName(), null, null, null, null, null);
      StringBuffer whatWasMissUnderstood = new StringBuffer(256);
      enumeration = misunderstoodHeaders.elements();
      while (enumeration.hasMoreElements()) {
        SOAPHeaderElement badHeader = (SOAPHeaderElement)enumeration.nextElement();
        QName badQName = new QName(badHeader.getNamespaceURI(), badHeader.getName());
        if (whatWasMissUnderstood.length() != 0)
          whatWasMissUnderstood.append(", "); 
        whatWasMissUnderstood.append(badQName.toString());
        if (soapConstants == SOAPConstants.SOAP12_CONSTANTS) {
          SOAPHeaderElement newHeader = new SOAPHeaderElement("http://www.w3.org/2003/05/soap-envelope", "NotUnderstood");
          newHeader.addAttribute(null, "qname", badQName);
          fault.addHeader(newHeader);
        } 
      } 
      fault.setFaultString(Messages.getMessage("noUnderstand00", whatWasMissUnderstood.toString()));
      throw fault;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\soap\MustUnderstandChecker.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */