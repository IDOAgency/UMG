package org.apache.axis.handlers;

import java.util.StringTokenizer;
import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.security.AuthenticatedUser;
import org.apache.axis.security.SecurityProvider;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class SimpleAuthorizationHandler extends BasicHandler {
  protected static Log log = LogFactory.getLog(SimpleAuthorizationHandler.class.getName());
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug("Enter: SimpleAuthorizationHandler::invoke"); 
    boolean allowByDefault = JavaUtils.isTrueExplicitly(getOption("allowByDefault"));
    AuthenticatedUser user = (AuthenticatedUser)msgContext.getProperty("authenticatedUser");
    if (user == null)
      throw new AxisFault("Server.NoUser", Messages.getMessage("needUser00"), null, null); 
    String userID = user.getName();
    SOAPService sOAPService = msgContext.getService();
    if (sOAPService == null)
      throw new AxisFault(Messages.getMessage("needService00")); 
    String serviceName = sOAPService.getName();
    String allowedRoles = (String)sOAPService.getOption("allowedRoles");
    if (allowedRoles == null) {
      if (allowByDefault) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("noRoles00")); 
      } else {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("noRoles01")); 
        throw new AxisFault("Server.Unauthorized", Messages.getMessage("notAuth00", userID, serviceName), null, null);
      } 
      if (log.isDebugEnabled())
        log.debug("Exit: SimpleAuthorizationHandler::invoke"); 
      return;
    } 
    SecurityProvider provider = (SecurityProvider)msgContext.getProperty("securityProvider");
    if (provider == null)
      throw new AxisFault(Messages.getMessage("noSecurity00")); 
    StringTokenizer st = new StringTokenizer(allowedRoles, ",");
    while (st.hasMoreTokens()) {
      String thisRole = st.nextToken();
      if (provider.userMatches(user, thisRole)) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("auth01", userID, serviceName)); 
        if (log.isDebugEnabled())
          log.debug("Exit: SimpleAuthorizationHandler::invoke"); 
        return;
      } 
    } 
    throw new AxisFault("Server.Unauthorized", Messages.getMessage("cantAuth02", userID, serviceName), null, null);
  }
  
  public void onFault(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled()) {
      log.debug("Enter: SimpleAuthorizationHandler::onFault");
      log.debug("Exit: SimpleAuthorizationHandler::onFault");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\SimpleAuthorizationHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */