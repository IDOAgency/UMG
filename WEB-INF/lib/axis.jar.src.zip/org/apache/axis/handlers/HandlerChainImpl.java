package org.apache.axis.handlers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.handler.Handler;
import javax.xml.rpc.handler.HandlerChain;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.rpc.soap.SOAPFaultException;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class HandlerChainImpl extends ArrayList implements HandlerChain {
  protected static Log log = LogFactory.getLog(HandlerChainImpl.class.getName());
  
  public static final String JAXRPC_METHOD_INFO = "jaxrpc.method.info";
  
  private String[] _roles;
  
  private int falseIndex = -1;
  
  public String[] getRoles() { return this._roles; }
  
  public void setRoles(String[] roles) {
    if (roles != null)
      this._roles = (String[])roles.clone(); 
  }
  
  public void init(Map map) {}
  
  protected List handlerInfos = new ArrayList();
  
  public HandlerChainImpl(List handlerInfos) {
    this.handlerInfos = handlerInfos;
    for (int i = 0; i < handlerInfos.size(); i++)
      add(newHandler(getHandlerInfo(i))); 
  }
  
  public void addNewHandler(String className, Map config) {
    try {
      HandlerInfo handlerInfo = new HandlerInfo(ClassUtils.forName(className), config, null);
      this.handlerInfos.add(handlerInfo);
      add(newHandler(handlerInfo));
    } catch (Exception ex) {
      String messageText = Messages.getMessage("NoJAXRPCHandler00", className);
      throw new JAXRPCException(messageText, ex);
    } 
  }
  
  public boolean handleFault(MessageContext _context) {
    context = (SOAPMessageContext)_context;
    preInvoke(context);
    try {
      int endIdx = size() - 1;
      if (this.falseIndex != -1)
        endIdx = this.falseIndex; 
      for (i = endIdx; i >= 0; i--) {
        if (!getHandlerInstance(i).handleFault(context))
          return false; 
      } 
      return true;
    } finally {
      postInvoke(context);
    } 
  }
  
  public ArrayList getMessageInfo(SOAPMessage message) {
    ArrayList list = new ArrayList();
    try {
      if (message == null || message.getSOAPPart() == null)
        return list; 
      SOAPEnvelope env = message.getSOAPPart().getEnvelope();
      SOAPBody body = env.getBody();
      Iterator it = body.getChildElements();
      SOAPElement operation = (SOAPElement)it.next();
      list.add(operation.getElementName().toString());
      for (Iterator i = operation.getChildElements(); i.hasNext(); ) {
        SOAPElement elt = (SOAPElement)i.next();
        list.add(elt.getElementName().toString());
      } 
    } catch (Exception e) {
      log.debug("Exception in getMessageInfo : ", e);
    } 
    return list;
  }
  
  public boolean handleRequest(MessageContext _context) {
    MessageContext actx = (MessageContext)_context;
    actx.setRoles(getRoles());
    context = (SOAPMessageContext)_context;
    preInvoke(context);
    try {
      for (i = 0; i < size(); i++) {
        Handler currentHandler = getHandlerInstance(i);
        try {
          if (!currentHandler.handleRequest(context)) {
            this.falseIndex = i;
            return false;
          } 
        } catch (SOAPFaultException sfe) {
          this.falseIndex = i;
          throw sfe;
        } 
      } 
      return true;
    } finally {
      postInvoke(context);
    } 
  }
  
  public boolean handleResponse(MessageContext context) {
    scontext = (SOAPMessageContext)context;
    preInvoke(scontext);
    try {
      int endIdx = size() - 1;
      if (this.falseIndex != -1)
        endIdx = this.falseIndex; 
      for (i = endIdx; i >= 0; i--) {
        if (!getHandlerInstance(i).handleResponse(context))
          return false; 
      } 
      return true;
    } finally {
      postInvoke(scontext);
    } 
  }
  
  private void preInvoke(SOAPMessageContext msgContext) {
    try {
      SOAPMessage message = msgContext.getMessage();
      if (message != null && message.getSOAPPart() != null)
        message.getSOAPPart().getEnvelope(); 
      msgContext.setProperty("axis.form.optimization", Boolean.FALSE);
      msgContext.setProperty("jaxrpc.method.info", getMessageInfo(message));
    } catch (Exception e) {
      log.debug("Exception in preInvoke : ", e);
      throw new RuntimeException("Exception in preInvoke : " + e.toString());
    } 
  }
  
  private void postInvoke(SOAPMessageContext msgContext) {
    Boolean propFormOptimization = (Boolean)msgContext.getProperty("axis.form.optimization");
    if (propFormOptimization != null && !propFormOptimization.booleanValue()) {
      msgContext.setProperty("axis.form.optimization", Boolean.TRUE);
      SOAPMessage message = msgContext.getMessage();
      ArrayList oldList = (ArrayList)msgContext.getProperty("jaxrpc.method.info");
      if (oldList != null && 
        !Arrays.equals(oldList.toArray(), getMessageInfo(message).toArray()))
        throw new RuntimeException(Messages.getMessage("invocationArgumentsModified00")); 
      try {
        if (message != null)
          message.saveChanges(); 
      } catch (SOAPException e) {
        log.debug("Exception in postInvoke : ", e);
        throw new RuntimeException("Exception in postInvoke : " + e.toString());
      } 
    } 
  }
  
  public void destroy() {
    int endIdx = size() - 1;
    if (this.falseIndex != -1)
      endIdx = this.falseIndex; 
    for (int i = endIdx; i >= 0; i--)
      getHandlerInstance(i).destroy(); 
    this.falseIndex = -1;
    clear();
  }
  
  private Handler getHandlerInstance(int index) { return (Handler)get(index); }
  
  private HandlerInfo getHandlerInfo(int index) { return (HandlerInfo)this.handlerInfos.get(index); }
  
  private Handler newHandler(HandlerInfo handlerInfo) {
    try {
      Handler handler = (Handler)handlerInfo.getHandlerClass().newInstance();
      handler.init(handlerInfo);
      return handler;
    } catch (Exception ex) {
      String messageText = Messages.getMessage("NoJAXRPCHandler00", handlerInfo.getHandlerClass().toString());
      throw new JAXRPCException(messageText, ex);
    } 
  }
  
  public HandlerChainImpl() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\HandlerChainImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */