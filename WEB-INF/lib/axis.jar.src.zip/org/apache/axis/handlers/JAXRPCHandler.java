package org.apache.axis.handlers;

import java.util.Map;
import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class JAXRPCHandler extends BasicHandler {
  protected static Log log = LogFactory.getLog(JAXRPCHandler.class.getName());
  
  protected HandlerChainImpl impl = new HandlerChainImpl();
  
  public void init() {
    super.init();
    String className = (String)getOption("className");
    if (className != null)
      addNewHandler(className, getOptions()); 
  }
  
  public void addNewHandler(String className, Map options) { this.impl.addNewHandler(className, options); }
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    log.debug("Enter: JAXRPCHandler::enter invoke");
    if (!msgContext.getPastPivot()) {
      this.impl.handleRequest(msgContext);
    } else {
      this.impl.handleResponse(msgContext);
    } 
    log.debug("Enter: JAXRPCHandler::exit invoke");
  }
  
  public void onFault(MessageContext msgContext) throws AxisFault { this.impl.handleFault(msgContext); }
  
  public void cleanup() { this.impl.destroy(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\JAXRPCHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */