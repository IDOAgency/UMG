/*    */ package org.apache.axis.handlers;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.apache.axis.AxisFault;
/*    */ import org.apache.axis.MessageContext;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JAXRPCHandler
/*    */   extends BasicHandler
/*    */ {
/* 31 */   protected static Log log = LogFactory.getLog(JAXRPCHandler.class.getName());
/*    */ 
/*    */   
/* 34 */   protected HandlerChainImpl impl = new HandlerChainImpl();
/*    */   
/*    */   public void init() {
/* 37 */     super.init();
/* 38 */     String className = (String)getOption("className");
/* 39 */     if (className != null) {
/* 40 */       addNewHandler(className, getOptions());
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 45 */   public void addNewHandler(String className, Map options) { this.impl.addNewHandler(className, options); }
/*    */ 
/*    */   
/*    */   public void invoke(MessageContext msgContext) throws AxisFault {
/* 49 */     log.debug("Enter: JAXRPCHandler::enter invoke");
/* 50 */     if (!msgContext.getPastPivot()) {
/* 51 */       this.impl.handleRequest(msgContext);
/*    */     } else {
/* 53 */       this.impl.handleResponse(msgContext);
/*    */     } 
/* 55 */     log.debug("Enter: JAXRPCHandler::exit invoke");
/*    */   }
/*    */ 
/*    */   
/* 59 */   public void onFault(MessageContext msgContext) throws AxisFault { this.impl.handleFault(msgContext); }
/*    */ 
/*    */ 
/*    */   
/* 63 */   public void cleanup() { this.impl.destroy(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\JAXRPCHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */