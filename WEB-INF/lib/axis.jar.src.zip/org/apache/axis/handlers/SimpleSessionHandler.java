package org.apache.axis.handlers;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.xml.namespace.QName;
import javax.xml.rpc.server.ServiceLifecycle;
import org.apache.axis.AxisEngine;
import org.apache.axis.AxisFault;
import org.apache.axis.Constants;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.axis.session.SimpleSession;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.SessionUtils;
import org.apache.commons.logging.Log;

public class SimpleSessionHandler extends BasicHandler {
  protected static Log log = LogFactory.getLog(SimpleSessionHandler.class.getName());
  
  public static final String SESSION_ID = "SimpleSession.id";
  
  public static final String SESSION_NS = "http://xml.apache.org/axis/session";
  
  public static final String SESSION_LOCALPART = "sessionID";
  
  public static final QName sessionHeaderName = new QName("http://xml.apache.org/axis/session", "sessionID");
  
  private Hashtable activeSessions = new Hashtable();
  
  private long reapPeriodicity = 30L;
  
  private long lastReapTime = 0L;
  
  private int defaultSessionTimeout = 60;
  
  public void invoke(MessageContext context) throws AxisFault {
    long curTime = System.currentTimeMillis();
    boolean reap = false;
    synchronized (this) {
      if (curTime > this.lastReapTime + this.reapPeriodicity * 1000L) {
        reap = true;
        this.lastReapTime = curTime;
      } 
    } 
    if (reap) {
      Set entries = this.activeSessions.entrySet();
      Set victims = new HashSet();
      Iterator i;
      for (i = entries.iterator(); i.hasNext(); ) {
        Map.Entry entry = (Map.Entry)i.next();
        Object key = entry.getKey();
        SimpleSession session = (SimpleSession)entry.getValue();
        if (curTime - session.getLastAccessTime() > (session.getTimeout() * 1000)) {
          log.debug(Messages.getMessage("timeout00", key.toString()));
          victims.add(key);
        } 
      } 
      for (i = victims.iterator(); i.hasNext(); ) {
        Object key = i.next();
        SimpleSession session = (SimpleSession)this.activeSessions.get(key);
        this.activeSessions.remove(key);
        Enumeration keys = session.getKeys();
        while (keys != null && keys.hasMoreElements()) {
          String keystr = (String)keys.nextElement();
          Object obj = session.get(keystr);
          if (obj != null && obj instanceof ServiceLifecycle)
            ((ServiceLifecycle)obj).destroy(); 
        } 
      } 
    } 
    if (context.isClient()) {
      doClient(context);
    } else {
      doServer(context);
    } 
  }
  
  public void doClient(MessageContext context) throws AxisFault {
    if (context.getPastPivot()) {
      Message msg = context.getResponseMessage();
      if (msg == null)
        return; 
      SOAPEnvelope env = msg.getSOAPEnvelope();
      SOAPHeaderElement header = env.getHeaderByName("http://xml.apache.org/axis/session", "sessionID");
      if (header == null)
        return; 
      try {
        Long id = (Long)header.getValueAsType(Constants.XSD_LONG);
        AxisEngine engine = context.getAxisEngine();
        engine.setOption("SimpleSession.id", id);
        header.setProcessed(true);
      } catch (Exception e) {
        throw AxisFault.makeFault(e);
      } 
    } else {
      AxisEngine engine = context.getAxisEngine();
      Long id = (Long)engine.getOption("SimpleSession.id");
      if (id == null)
        return; 
      Message msg = context.getRequestMessage();
      if (msg == null)
        throw new AxisFault(Messages.getMessage("noRequest00")); 
      SOAPEnvelope env = msg.getSOAPEnvelope();
      SOAPHeaderElement header = new SOAPHeaderElement("http://xml.apache.org/axis/session", "sessionID", id);
      env.addHeader(header);
    } 
  }
  
  public void doServer(MessageContext context) throws AxisFault {
    if (context.getPastPivot()) {
      Long id = (Long)context.getProperty("SimpleSession.id");
      if (id == null)
        return; 
      Message msg = context.getResponseMessage();
      if (msg == null)
        return; 
      SOAPEnvelope env = msg.getSOAPEnvelope();
      SOAPHeaderElement header = new SOAPHeaderElement("http://xml.apache.org/axis/session", "sessionID", id);
      env.addHeader(header);
    } else {
      Long id;
      Message msg = context.getRequestMessage();
      if (msg == null)
        throw new AxisFault(Messages.getMessage("noRequest00")); 
      SOAPEnvelope env = msg.getSOAPEnvelope();
      SOAPHeaderElement header = env.getHeaderByName("http://xml.apache.org/axis/session", "sessionID");
      if (header != null) {
        try {
          id = (Long)header.getValueAsType(Constants.XSD_LONG);
        } catch (Exception e) {
          throw AxisFault.makeFault(e);
        } 
      } else {
        id = getNewSession();
      } 
      SimpleSession session = (SimpleSession)this.activeSessions.get(id);
      if (session == null) {
        id = getNewSession();
        session = (SimpleSession)this.activeSessions.get(id);
      } 
      session.touch();
      context.setSession(session);
      context.setProperty("SimpleSession.id", id);
    } 
  }
  
  private Long getNewSession() {
    Long id = SessionUtils.generateSession();
    SimpleSession session = new SimpleSession();
    session.setTimeout(this.defaultSessionTimeout);
    this.activeSessions.put(id, session);
    return id;
  }
  
  public void setReapPeriodicity(long reapTime) { this.reapPeriodicity = reapTime; }
  
  public void setDefaultSessionTimeout(int defaultSessionTimeout) { this.defaultSessionTimeout = defaultSessionTimeout; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\SimpleSessionHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */