/*    */ package org.apache.axis.handlers;
/*    */ 
/*    */ import org.apache.axis.MessageContext;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogMessage
/*    */   extends BasicHandler
/*    */ {
/* 30 */   protected static Log log = LogFactory.getLog(LogMessage.class.getName());
/*    */ 
/*    */ 
/*    */   
/*    */   public void invoke(MessageContext context) {
/* 35 */     String msg = (String)getOption("message");
/* 36 */     if (msg != null)
/* 37 */       log.info(msg); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\LogMessage.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */