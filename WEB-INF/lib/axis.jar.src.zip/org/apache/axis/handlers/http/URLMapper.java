package org.apache.axis.handlers.http;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.handlers.BasicHandler;
import org.apache.axis.transport.http.HTTPConstants;
import org.apache.commons.logging.Log;

public class URLMapper extends BasicHandler {
  protected static Log log = LogFactory.getLog(URLMapper.class.getName());
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    log.debug("Enter: URLMapper::invoke");
    if (msgContext.getService() == null) {
      String path = (String)msgContext.getProperty(HTTPConstants.MC_HTTP_SERVLETPATHINFO);
      if (path != null && path.length() >= 1) {
        if (path.startsWith("/"))
          path = path.substring(1); 
        msgContext.setTargetService(path);
      } 
    } 
    log.debug("Exit: URLMapper::invoke");
  }
  
  public void generateWSDL(MessageContext msgContext) throws AxisFault { invoke(msgContext); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\http\URLMapper.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */