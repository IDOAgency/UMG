package org.apache.axis.handlers.http;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.handlers.BasicHandler;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class HTTPActionHandler extends BasicHandler {
  protected static Log log = LogFactory.getLog(HTTPActionHandler.class.getName());
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    log.debug("Enter: HTTPActionHandler::invoke");
    if (msgContext.getService() == null) {
      String action = msgContext.getSOAPActionURI();
      log.debug("  HTTP SOAPAction: " + action);
      if (action == null)
        throw new AxisFault("Server.NoHTTPSOAPAction", Messages.getMessage("noSOAPAction00"), null, null); 
      action = action.trim();
      if (action.length() > 0 && action.charAt(0) == '"')
        if (action.equals("\"\"")) {
          action = "";
        } else {
          action = action.substring(1, action.length() - 1);
        }  
      if (action.length() > 0)
        msgContext.setTargetService(action); 
    } 
    log.debug("Exit: HTTPActionHandler::invoke");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\http\HTTPActionHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */