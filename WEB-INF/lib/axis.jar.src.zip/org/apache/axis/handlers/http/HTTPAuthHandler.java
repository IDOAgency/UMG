package org.apache.axis.handlers.http;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.Base64;
import org.apache.axis.handlers.BasicHandler;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class HTTPAuthHandler extends BasicHandler {
  protected static Log log = LogFactory.getLog(HTTPAuthHandler.class.getName());
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    log.debug("Enter: HTTPAuthHandler::invoke");
    String tmp = (String)msgContext.getProperty("Authorization");
    if (tmp != null)
      tmp = tmp.trim(); 
    if (tmp != null && tmp.startsWith("Basic ")) {
      String user = null;
      tmp = new String(Base64.decode(tmp.substring(6)));
      int i = tmp.indexOf(':');
      if (i == -1) {
        user = tmp;
      } else {
        user = tmp.substring(0, i);
      } 
      msgContext.setUsername(user);
      log.debug(Messages.getMessage("httpUser00", user));
      if (i != -1) {
        String pwd = tmp.substring(i + 1);
        if (pwd != null && pwd.equals(""))
          pwd = null; 
        if (pwd != null) {
          msgContext.setPassword(pwd);
          log.debug(Messages.getMessage("httpPassword00", pwd));
        } 
      } 
    } 
    log.debug("Exit: HTTPAuthHandler::invoke");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\handlers\http\HTTPAuthHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */