package org.apache.axis.deployment.wsdd;

import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;
import javax.xml.namespace.QName;
import org.apache.axis.ConfigurationException;
import org.apache.axis.MessageContext;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.utils.Messages;
import org.w3c.dom.Element;
import org.xml.sax.helpers.AttributesImpl;

public class WSDDUndeployment extends WSDDElement implements WSDDTypeMappingContainer {
  private Vector handlers = new Vector();
  
  private Vector chains = new Vector();
  
  private Vector services = new Vector();
  
  private Vector transports = new Vector();
  
  private Vector typeMappings = new Vector();
  
  public void addHandler(QName handler) { this.handlers.add(handler); }
  
  public void addChain(QName chain) { this.chains.add(chain); }
  
  public void addTransport(QName transport) { this.transports.add(transport); }
  
  public void addService(QName service) { this.services.add(service); }
  
  public void deployTypeMapping(WSDDTypeMapping typeMapping) throws WSDDException { this.typeMappings.add(typeMapping); }
  
  public WSDDUndeployment() {}
  
  private QName getQName(Element el) throws WSDDException {
    String attr = el.getAttribute("name");
    if (attr == null || "".equals(attr))
      throw new WSDDException(Messages.getMessage("badNameAttr00")); 
    return new QName("", attr);
  }
  
  public WSDDUndeployment(Element e) throws WSDDException {
    super(e);
    Element[] elements = getChildElements(e, "handler");
    int i;
    for (i = 0; i < elements.length; i++)
      addHandler(getQName(elements[i])); 
    elements = getChildElements(e, "chain");
    for (i = 0; i < elements.length; i++)
      addChain(getQName(elements[i])); 
    elements = getChildElements(e, "transport");
    for (i = 0; i < elements.length; i++)
      addTransport(getQName(elements[i])); 
    elements = getChildElements(e, "service");
    for (i = 0; i < elements.length; i++)
      addService(getQName(elements[i])); 
  }
  
  protected QName getElementName() { return QNAME_UNDEPLOY; }
  
  public void undeployFromRegistry(WSDDDeployment registry) throws ConfigurationException {
    for (int n = 0; n < this.handlers.size(); n++) {
      QName qname = (QName)this.handlers.get(n);
      registry.undeployHandler(qname);
    } 
    for (int n = 0; n < this.chains.size(); n++) {
      QName qname = (QName)this.chains.get(n);
      registry.undeployHandler(qname);
    } 
    for (int n = 0; n < this.transports.size(); n++) {
      QName qname = (QName)this.transports.get(n);
      registry.undeployTransport(qname);
    } 
    for (int n = 0; n < this.services.size(); n++) {
      QName qname = (QName)this.services.get(n);
      try {
        String sname = qname.getLocalPart();
        MessageContext messageContext = MessageContext.getCurrentContext();
        if (messageContext != null) {
          SOAPService service = messageContext.getAxisEngine().getService(sname);
          if (service != null)
            service.clearSessions(); 
        } 
      } catch (Exception exp) {
        throw new ConfigurationException(exp);
      } 
      registry.undeployService(qname);
    } 
  }
  
  private void writeElement(SerializationContext context, QName elementQName, QName qname) throws IOException {
    AttributesImpl attrs = new AttributesImpl();
    attrs.addAttribute("", "name", "name", "CDATA", context.qName2String(qname));
    context.startElement(elementQName, attrs);
    context.endElement();
  }
  
  public void writeToContext(SerializationContext context) throws IOException {
    context.registerPrefixForURI("", "http://xml.apache.org/axis/wsdd/");
    context.startElement(WSDDConstants.QNAME_UNDEPLOY, null);
    Iterator i = this.handlers.iterator();
    while (i.hasNext()) {
      QName qname = (QName)i.next();
      writeElement(context, QNAME_HANDLER, qname);
    } 
    i = this.chains.iterator();
    while (i.hasNext()) {
      QName qname = (QName)i.next();
      writeElement(context, QNAME_CHAIN, qname);
    } 
    i = this.services.iterator();
    while (i.hasNext()) {
      QName qname = (QName)i.next();
      writeElement(context, QNAME_SERVICE, qname);
    } 
    i = this.transports.iterator();
    while (i.hasNext()) {
      QName qname = (QName)i.next();
      writeElement(context, QNAME_TRANSPORT, qname);
    } 
    i = this.typeMappings.iterator();
    while (i.hasNext()) {
      WSDDTypeMapping mapping = (WSDDTypeMapping)i.next();
      mapping.writeToContext(context);
    } 
    context.endElement();
  }
  
  public WSDDTypeMapping[] getTypeMappings() {
    WSDDTypeMapping[] t = new WSDDTypeMapping[this.typeMappings.size()];
    this.typeMappings.toArray(t);
    return t;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDUndeployment.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */