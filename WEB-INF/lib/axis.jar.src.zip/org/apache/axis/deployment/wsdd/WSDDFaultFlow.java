package org.apache.axis.deployment.wsdd;

import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class WSDDFaultFlow extends WSDDChain {
  public WSDDFaultFlow() {}
  
  public WSDDFaultFlow(Element e) throws WSDDException { super(e); }
  
  protected QName getElementName() { return WSDDConstants.QNAME_FAULTFLOW; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDFaultFlow.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */