package org.apache.axis.deployment.wsdd;

import java.util.Hashtable;
import javax.xml.namespace.QName;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.deployment.wsdd.providers.WSDDBsfProvider;
import org.apache.axis.deployment.wsdd.providers.WSDDComProvider;
import org.apache.axis.deployment.wsdd.providers.WSDDHandlerProvider;
import org.apache.axis.deployment.wsdd.providers.WSDDJavaCORBAProvider;
import org.apache.axis.deployment.wsdd.providers.WSDDJavaEJBProvider;
import org.apache.axis.deployment.wsdd.providers.WSDDJavaMsgProvider;
import org.apache.axis.deployment.wsdd.providers.WSDDJavaRMIProvider;
import org.apache.axis.deployment.wsdd.providers.WSDDJavaRPCProvider;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.discovery.ResourceNameIterator;
import org.apache.commons.discovery.resource.ClassLoaders;
import org.apache.commons.discovery.resource.names.DiscoverServiceNames;
import org.apache.commons.logging.Log;

public abstract class WSDDProvider {
  protected static Log log = LogFactory.getLog(WSDDProvider.class.getName());
  
  private static final String PLUGABLE_PROVIDER_FILENAME = "org.apache.axis.deployment.wsdd.Provider";
  
  private static Hashtable providers = new Hashtable();
  
  static  {
    providers.put(WSDDConstants.QNAME_JAVARPC_PROVIDER, new WSDDJavaRPCProvider());
    providers.put(WSDDConstants.QNAME_JAVAMSG_PROVIDER, new WSDDJavaMsgProvider());
    providers.put(WSDDConstants.QNAME_HANDLER_PROVIDER, new WSDDHandlerProvider());
    providers.put(WSDDConstants.QNAME_EJB_PROVIDER, new WSDDJavaEJBProvider());
    providers.put(WSDDConstants.QNAME_COM_PROVIDER, new WSDDComProvider());
    providers.put(WSDDConstants.QNAME_BSF_PROVIDER, new WSDDBsfProvider());
    providers.put(WSDDConstants.QNAME_CORBA_PROVIDER, new WSDDJavaCORBAProvider());
    providers.put(WSDDConstants.QNAME_RMI_PROVIDER, new WSDDJavaRMIProvider());
    try {
      loadPluggableProviders();
    } catch (Throwable t) {
      String msg = t + JavaUtils.LS + JavaUtils.stackToString(t);
      log.info(Messages.getMessage("exception01", msg));
    } 
  }
  
  private static void loadPluggableProviders() {
    clzLoader = WSDDProvider.class.getClassLoader();
    ClassLoaders loaders = new ClassLoaders();
    loaders.put(clzLoader);
    DiscoverServiceNames dsn = new DiscoverServiceNames(loaders);
    ResourceNameIterator iter = dsn.findResourceNames("org.apache.axis.deployment.wsdd.Provider");
    while (iter.hasNext()) {
      String className = iter.nextResourceName();
      try {
        Object o = Class.forName(className).newInstance();
        if (o instanceof WSDDProvider) {
          WSDDProvider provider = (WSDDProvider)o;
          String providerName = provider.getName();
          QName q = new QName("http://xml.apache.org/axis/wsdd/providers/java", providerName);
          providers.put(q, provider);
        } 
      } catch (Exception e) {
        String msg = e + JavaUtils.LS + JavaUtils.stackToString(e);
        log.info(Messages.getMessage("exception01", msg));
      } 
    } 
  }
  
  public static void registerProvider(QName uri, WSDDProvider prov) { providers.put(uri, prov); }
  
  public WSDDOperation[] getOperations() { return null; }
  
  public WSDDOperation getOperation(String name) { return null; }
  
  public static Handler getInstance(QName providerType, WSDDService service, EngineConfiguration registry) throws Exception {
    if (providerType == null)
      throw new WSDDException(Messages.getMessage("nullProvider00")); 
    WSDDProvider provider = (WSDDProvider)providers.get(providerType);
    if (provider == null)
      throw new WSDDException(Messages.getMessage("noMatchingProvider00", providerType.toString())); 
    return provider.newProviderInstance(service, registry);
  }
  
  public abstract Handler newProviderInstance(WSDDService paramWSDDService, EngineConfiguration paramEngineConfiguration) throws Exception;
  
  public abstract String getName();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */