package org.apache.axis.deployment.wsdd.providers;

import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.deployment.wsdd.WSDDProvider;
import org.apache.axis.deployment.wsdd.WSDDService;
import org.apache.axis.providers.java.RMIProvider;

public class WSDDJavaRMIProvider extends WSDDProvider {
  public String getName() { return "RMI"; }
  
  public Handler newProviderInstance(WSDDService service, EngineConfiguration registry) throws Exception { return new RMIProvider(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\providers\WSDDJavaRMIProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */