package org.apache.axis.deployment.wsdd;

import java.io.IOException;
import javax.xml.namespace.QName;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.ParameterDesc;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.XMLUtils;
import org.w3c.dom.Element;
import org.xml.sax.helpers.AttributesImpl;

public class WSDDParameter extends WSDDElement {
  OperationDesc parent;
  
  ParameterDesc parameter = new ParameterDesc();
  
  public WSDDParameter(Element e, OperationDesc parent) throws WSDDException {
    super(e);
    this.parent = parent;
    String nameStr = e.getAttribute("qname");
    if (nameStr != null && !nameStr.equals("")) {
      this.parameter.setQName(XMLUtils.getQNameFromString(nameStr, e));
    } else {
      nameStr = e.getAttribute("name");
      if (nameStr != null && !nameStr.equals(""))
        this.parameter.setQName(new QName(null, nameStr)); 
    } 
    String modeStr = e.getAttribute("mode");
    if (modeStr != null && !modeStr.equals(""))
      this.parameter.setMode(ParameterDesc.modeFromString(modeStr)); 
    String inHStr = e.getAttribute("inHeader");
    if (inHStr != null)
      this.parameter.setInHeader(JavaUtils.isTrueExplicitly(inHStr)); 
    String outHStr = e.getAttribute("outHeader");
    if (outHStr != null)
      this.parameter.setOutHeader(JavaUtils.isTrueExplicitly(outHStr)); 
    String typeStr = e.getAttribute("type");
    if (typeStr != null && !typeStr.equals(""))
      this.parameter.setTypeQName(XMLUtils.getQNameFromString(typeStr, e)); 
    String itemQNameStr = e.getAttribute("itemQName");
    if (itemQNameStr != null && !itemQNameStr.equals(""))
      this.parameter.setItemQName(XMLUtils.getQNameFromString(itemQNameStr, e)); 
    String itemTypeStr = e.getAttribute("itemType");
    if (itemTypeStr != null && !itemTypeStr.equals(""))
      this.parameter.setItemType(XMLUtils.getQNameFromString(itemTypeStr, e)); 
    Element docElem = getChildElement(e, "documentation");
    if (docElem != null) {
      WSDDDocumentation documentation = new WSDDDocumentation(docElem);
      this.parameter.setDocumentation(documentation.getValue());
    } 
  }
  
  public WSDDParameter() {}
  
  public WSDDParameter(ParameterDesc parameter) { this.parameter = parameter; }
  
  public void writeToContext(SerializationContext context) throws IOException {
    AttributesImpl attrs = new AttributesImpl();
    QName qname = this.parameter.getQName();
    if (qname != null)
      if (qname.getNamespaceURI() != null && !qname.getNamespaceURI().equals("")) {
        attrs.addAttribute("", "qname", "qname", "CDATA", context.qName2String(this.parameter.getQName()));
      } else {
        attrs.addAttribute("", "name", "name", "CDATA", this.parameter.getQName().getLocalPart());
      }  
    byte mode = this.parameter.getMode();
    if (mode != 1) {
      String modeStr = ParameterDesc.getModeAsString(mode);
      attrs.addAttribute("", "mode", "mode", "CDATA", modeStr);
    } 
    if (this.parameter.isInHeader())
      attrs.addAttribute("", "inHeader", "inHeader", "CDATA", "true"); 
    if (this.parameter.isOutHeader())
      attrs.addAttribute("", "outHeader", "outHeader", "CDATA", "true"); 
    QName typeQName = this.parameter.getTypeQName();
    if (typeQName != null)
      attrs.addAttribute("", "type", "type", "CDATA", context.qName2String(typeQName)); 
    QName itemQName = this.parameter.getItemQName();
    if (itemQName != null)
      attrs.addAttribute("", "itemQName", "itemQName", "CDATA", context.qName2String(itemQName)); 
    QName itemType = this.parameter.getItemType();
    if (itemType != null)
      attrs.addAttribute("", "itemType", "itemType", "CDATA", context.qName2String(itemType)); 
    context.startElement(getElementName(), attrs);
    if (this.parameter.getDocumentation() != null) {
      WSDDDocumentation documentation = new WSDDDocumentation(this.parameter.getDocumentation());
      documentation.writeToContext(context);
    } 
    context.endElement();
  }
  
  public ParameterDesc getParameter() { return this.parameter; }
  
  public void setParameter(ParameterDesc parameter) { this.parameter = parameter; }
  
  protected QName getElementName() { return WSDDConstants.QNAME_PARAM; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDParameter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */