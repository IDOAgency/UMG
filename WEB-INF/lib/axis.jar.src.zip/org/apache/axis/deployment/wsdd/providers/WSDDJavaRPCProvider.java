package org.apache.axis.deployment.wsdd.providers;

import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.deployment.wsdd.WSDDProvider;
import org.apache.axis.deployment.wsdd.WSDDService;
import org.apache.axis.providers.java.RPCProvider;

public class WSDDJavaRPCProvider extends WSDDProvider {
  public String getName() { return "RPC"; }
  
  public Handler newProviderInstance(WSDDService service, EngineConfiguration registry) throws Exception { return new RPCProvider(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\providers\WSDDJavaRPCProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */