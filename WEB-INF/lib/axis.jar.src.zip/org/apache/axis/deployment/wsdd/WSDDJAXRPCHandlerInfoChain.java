package org.apache.axis.deployment.wsdd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.namespace.QName;
import javax.xml.rpc.handler.HandlerInfo;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.handlers.HandlerInfoChainFactory;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.w3c.dom.Element;
import org.xml.sax.helpers.AttributesImpl;

public class WSDDJAXRPCHandlerInfoChain extends WSDDHandler {
  protected static Log log = LogFactory.getLog(WSDDJAXRPCHandlerInfoChain.class.getName());
  
  private ArrayList _hiList;
  
  private HandlerInfoChainFactory _hiChainFactory;
  
  private String[] _roles;
  
  public WSDDJAXRPCHandlerInfoChain() {}
  
  public WSDDJAXRPCHandlerInfoChain(Element e) throws WSDDException {
    super(e);
    ArrayList infoList = new ArrayList();
    this._hiList = new ArrayList();
    Element[] elements = getChildElements(e, "handlerInfo");
    if (elements.length != 0)
      for (int i = 0; i < elements.length; i++) {
        WSDDJAXRPCHandlerInfo handlerInfo = new WSDDJAXRPCHandlerInfo(elements[i]);
        this._hiList.add(handlerInfo);
        String handlerClassName = handlerInfo.getHandlerClassName();
        Class handlerClass = null;
        try {
          handlerClass = ClassUtils.forName(handlerClassName);
        } catch (ClassNotFoundException cnf) {
          log.error(Messages.getMessage("handlerInfoChainNoClass00", handlerClassName), cnf);
        } 
        Map handlerMap = handlerInfo.getHandlerMap();
        QName[] headers = handlerInfo.getHeaders();
        if (handlerClass != null) {
          HandlerInfo hi = new HandlerInfo(handlerClass, handlerMap, headers);
          infoList.add(hi);
        } 
      }  
    this._hiChainFactory = new HandlerInfoChainFactory(infoList);
    elements = getChildElements(e, "role");
    if (elements.length != 0) {
      ArrayList roleList = new ArrayList();
      for (int i = 0; i < elements.length; i++) {
        String role = elements[i].getAttribute("soapActorName");
        roleList.add(role);
      } 
      this._roles = new String[roleList.size()];
      this._roles = (String[])roleList.toArray(this._roles);
      this._hiChainFactory.setRoles(this._roles);
    } 
  }
  
  public HandlerInfoChainFactory getHandlerChainFactory() { return this._hiChainFactory; }
  
  public void setHandlerChainFactory(HandlerInfoChainFactory handlerInfoChainFactory) { this._hiChainFactory = handlerInfoChainFactory; }
  
  protected QName getElementName() { return WSDDConstants.QNAME_JAXRPC_HANDLERINFOCHAIN; }
  
  public void writeToContext(SerializationContext context) throws IOException {
    context.startElement(QNAME_JAXRPC_HANDLERINFOCHAIN, null);
    List his = this._hiList;
    Iterator iter = his.iterator();
    while (iter.hasNext()) {
      WSDDJAXRPCHandlerInfo hi = (WSDDJAXRPCHandlerInfo)iter.next();
      hi.writeToContext(context);
    } 
    if (this._roles != null)
      for (int i = 0; i < this._roles.length; i++) {
        AttributesImpl attrs1 = new AttributesImpl();
        attrs1.addAttribute("", "soapActorName", "soapActorName", "CDATA", this._roles[i]);
        context.startElement(QNAME_JAXRPC_ROLE, attrs1);
        context.endElement();
      }  
    context.endElement();
  }
  
  public ArrayList getHandlerInfoList() { return this._hiList; }
  
  public void setHandlerInfoList(ArrayList hiList) { this._hiList = hiList; }
  
  public String[] getRoles() { return this._roles; }
  
  public void setRoles(String[] roles) { this._roles = roles; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDJAXRPCHandlerInfoChain.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */