package org.apache.axis.deployment.wsdd;

import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class WSDDRequestFlow extends WSDDChain {
  public WSDDRequestFlow() {}
  
  public WSDDRequestFlow(Element e) throws WSDDException { super(e); }
  
  protected QName getElementName() { return WSDDConstants.QNAME_REQFLOW; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDRequestFlow.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */