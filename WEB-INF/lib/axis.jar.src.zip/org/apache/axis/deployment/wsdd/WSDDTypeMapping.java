/*     */ package org.apache.axis.deployment.wsdd;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.Constants;
/*     */ import org.apache.axis.encoding.SerializationContext;
/*     */ import org.apache.axis.utils.ClassUtils;
/*     */ import org.apache.axis.utils.JavaUtils;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.axis.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSDDTypeMapping
/*     */   extends WSDDElement
/*     */ {
/*  38 */   protected QName qname = null;
/*  39 */   protected String serializer = null;
/*  40 */   protected String deserializer = null;
/*  41 */   protected QName typeQName = null;
/*  42 */   protected String ref = null;
/*  43 */   protected String encodingStyle = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WSDDTypeMapping() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WSDDTypeMapping(Element e) throws WSDDException {
/*  61 */     this.serializer = e.getAttribute("serializer");
/*  62 */     this.deserializer = e.getAttribute("deserializer");
/*  63 */     Attr attrNode = e.getAttributeNode("encodingStyle");
/*     */     
/*  65 */     if (attrNode == null) {
/*  66 */       this.encodingStyle = Constants.URI_DEFAULT_SOAP_ENC;
/*     */     } else {
/*  68 */       this.encodingStyle = attrNode.getValue();
/*     */     } 
/*     */     
/*  71 */     String qnameStr = e.getAttribute("qname");
/*  72 */     this.qname = XMLUtils.getQNameFromString(qnameStr, e);
/*     */ 
/*     */ 
/*     */     
/*  76 */     String typeStr = e.getAttribute("type");
/*  77 */     this.typeQName = XMLUtils.getQNameFromString(typeStr, e);
/*  78 */     if (typeStr == null || typeStr.equals("")) {
/*  79 */       typeStr = e.getAttribute("languageSpecificType");
/*  80 */       this.typeQName = XMLUtils.getQNameFromString(typeStr, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeToContext(SerializationContext context) throws IOException {
/*  89 */     AttributesImpl attrs = new AttributesImpl();
/*  90 */     attrs.addAttribute("", "encodingStyle", "encodingStyle", "CDATA", this.encodingStyle);
/*  91 */     attrs.addAttribute("", "serializer", "serializer", "CDATA", this.serializer);
/*  92 */     attrs.addAttribute("", "deserializer", "deserializer", "CDATA", this.deserializer);
/*     */     
/*  94 */     String typeStr = context.qName2String(this.typeQName);
/*     */     
/*  96 */     attrs.addAttribute("", "type", "type", "CDATA", typeStr);
/*     */ 
/*     */     
/*  99 */     String qnameStr = context.attributeQName2String(this.qname);
/* 100 */     attrs.addAttribute("", "qname", "qname", "CDATA", qnameStr);
/*     */     
/* 102 */     context.startElement(QNAME_TYPEMAPPING, attrs);
/* 103 */     context.endElement();
/*     */   }
/*     */ 
/*     */   
/* 107 */   protected QName getElementName() { return QNAME_TYPEMAPPING; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public String getRef() { return this.ref; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void setRef(String ref) { this.ref = ref; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public String getEncodingStyle() { return this.encodingStyle; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public void setEncodingStyle(String es) { this.encodingStyle = es; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public QName getQName() { return this.qname; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public void setQName(QName name) { this.qname = name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getLanguageSpecificType() throws ClassNotFoundException {
/* 172 */     if (this.typeQName != null) {
/* 173 */       if (!"http://xml.apache.org/axis/wsdd/providers/java".equals(this.typeQName.getNamespaceURI())) {
/* 174 */         throw new ClassNotFoundException(Messages.getMessage("badTypeNamespace00", this.typeQName.getNamespaceURI(), "http://xml.apache.org/axis/wsdd/providers/java"));
/*     */       }
/*     */ 
/*     */       
/* 178 */       String loadName = JavaUtils.getLoadableClassName(this.typeQName.getLocalPart());
/* 179 */       if (JavaUtils.getWrapper(loadName) != null) {
/* 180 */         return JavaUtils.getPrimitiveClassFromName(loadName);
/*     */       }
/*     */       
/* 183 */       return ClassUtils.forName(loadName);
/*     */     } 
/*     */     
/* 186 */     throw new ClassNotFoundException(Messages.getMessage("noTypeQName00"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLanguageSpecificType(Class javaType) {
/* 195 */     String type = javaType.getName();
/* 196 */     this.typeQName = new QName("http://xml.apache.org/axis/wsdd/providers/java", type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public void setLanguageSpecificType(String javaType) { this.typeQName = new QName("http://xml.apache.org/axis/wsdd/providers/java", javaType); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   public Class getSerializer() throws ClassNotFoundException { return ClassUtils.forName(this.serializer); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public String getSerializerName() { return this.serializer; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   public void setSerializer(Class ser) { this.serializer = ser.getName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 243 */   public void setSerializer(String ser) { this.serializer = ser; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public Class getDeserializer() throws ClassNotFoundException { return ClassUtils.forName(this.deserializer); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   public String getDeserializerName() { return this.deserializer; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 272 */   public void setDeserializer(Class deser) { this.deserializer = deser.getName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public void setDeserializer(String deser) { this.deserializer = deser; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDTypeMapping.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */