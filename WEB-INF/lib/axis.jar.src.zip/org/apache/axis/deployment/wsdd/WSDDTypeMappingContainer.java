package org.apache.axis.deployment.wsdd;

public interface WSDDTypeMappingContainer {
  void deployTypeMapping(WSDDTypeMapping paramWSDDTypeMapping) throws WSDDException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDTypeMappingContainer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */