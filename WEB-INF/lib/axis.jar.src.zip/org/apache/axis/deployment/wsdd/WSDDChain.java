package org.apache.axis.deployment.wsdd;

import java.io.IOException;
import java.util.Vector;
import javax.xml.namespace.QName;
import org.apache.axis.ConfigurationException;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.SimpleChain;
import org.apache.axis.encoding.SerializationContext;
import org.w3c.dom.Element;
import org.xml.sax.helpers.AttributesImpl;

public class WSDDChain extends WSDDHandler {
  private Vector handlers = new Vector();
  
  public WSDDChain() {}
  
  public WSDDChain(Element e) throws WSDDException {
    super(e);
    if (this.type != null)
      return; 
    Element[] elements = getChildElements(e, "handler");
    if (elements.length != 0)
      for (int i = 0; i < elements.length; i++) {
        WSDDHandler handler = new WSDDHandler(elements[i]);
        addHandler(handler);
      }  
    elements = getChildElements(e, "chain");
    if (elements.length != 0)
      for (int i = 0; i < elements.length; i++) {
        WSDDChain chain = new WSDDChain(elements[i]);
        addHandler(chain);
      }  
  }
  
  protected QName getElementName() { return WSDDConstants.QNAME_CHAIN; }
  
  public void addHandler(WSDDHandler handler) { this.handlers.add(handler); }
  
  public Vector getHandlers() { return this.handlers; }
  
  public void removeHandler(WSDDHandler victim) { this.handlers.remove(victim); }
  
  public Handler makeNewInstance(EngineConfiguration registry) throws ConfigurationException {
    SimpleChain simpleChain = new SimpleChain();
    for (int n = 0; n < this.handlers.size(); n++) {
      WSDDHandler handler = (WSDDHandler)this.handlers.get(n);
      Handler h = handler.getInstance(registry);
      if (h != null) {
        simpleChain.addHandler(h);
      } else {
        throw new ConfigurationException("Can't find handler name:'" + handler.getQName() + "' type:'" + handler.getType() + "' in the registry");
      } 
    } 
    return simpleChain;
  }
  
  public void writeToContext(SerializationContext context) throws IOException {
    AttributesImpl attrs = new AttributesImpl();
    QName name = getQName();
    if (name != null)
      attrs.addAttribute("", "name", "name", "CDATA", context.qName2String(name)); 
    if (getType() != null)
      attrs.addAttribute("", "type", "type", "CDATA", context.qName2String(getType())); 
    context.startElement(getElementName(), attrs);
    for (int n = 0; n < this.handlers.size(); n++) {
      WSDDHandler handler = (WSDDHandler)this.handlers.get(n);
      handler.writeToContext(context);
    } 
    context.endElement();
  }
  
  public void deployToRegistry(WSDDDeployment registry) {
    if (getQName() != null)
      registry.addHandler(this); 
    for (int n = 0; n < this.handlers.size(); n++) {
      WSDDHandler handler = (WSDDHandler)this.handlers.get(n);
      if (handler.getQName() != null)
        handler.deployToRegistry(registry); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDChain.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */