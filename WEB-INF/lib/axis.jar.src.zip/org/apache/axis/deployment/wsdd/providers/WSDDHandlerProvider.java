package org.apache.axis.deployment.wsdd.providers;

import org.apache.axis.ConfigurationException;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.deployment.wsdd.WSDDProvider;
import org.apache.axis.deployment.wsdd.WSDDService;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;

public class WSDDHandlerProvider extends WSDDProvider {
  public String getName() { return "Handler"; }
  
  public Handler newProviderInstance(WSDDService service, EngineConfiguration registry) throws Exception {
    String providerClass = service.getParameter("handlerClass");
    if (providerClass == null)
      throw new ConfigurationException(Messages.getMessage("noHandlerClass00")); 
    Class _class = ClassUtils.forName(providerClass);
    if (!Handler.class.isAssignableFrom(_class))
      throw new ConfigurationException(Messages.getMessage("badHandlerClass00", _class.getName())); 
    return (Handler)_class.newInstance();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\providers\WSDDHandlerProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */