package org.apache.axis.deployment.wsdd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.namespace.QName;
import org.apache.axis.description.FaultDesc;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.ParameterDesc;
import org.apache.axis.description.ServiceDesc;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.XMLUtils;
import org.w3c.dom.Element;
import org.xml.sax.helpers.AttributesImpl;

public class WSDDOperation extends WSDDElement {
  OperationDesc desc;
  
  public WSDDOperation(OperationDesc desc) {
    this.desc = new OperationDesc();
    this.desc = desc;
  }
  
  public WSDDOperation(Element e, ServiceDesc parent) throws WSDDException {
    super(e);
    this.desc = new OperationDesc();
    this.desc.setParent(parent);
    this.desc.setName(e.getAttribute("name"));
    String qNameStr = e.getAttribute("qname");
    if (qNameStr != null && !qNameStr.equals(""))
      this.desc.setElementQName(XMLUtils.getQNameFromString(qNameStr, e)); 
    String retQNameStr = e.getAttribute("returnQName");
    if (retQNameStr != null && !retQNameStr.equals(""))
      this.desc.setReturnQName(XMLUtils.getQNameFromString(retQNameStr, e)); 
    String retTypeStr = e.getAttribute("returnType");
    if (retTypeStr != null && !retTypeStr.equals(""))
      this.desc.setReturnType(XMLUtils.getQNameFromString(retTypeStr, e)); 
    String retHStr = e.getAttribute("returnHeader");
    if (retHStr != null)
      this.desc.setReturnHeader(JavaUtils.isTrueExplicitly(retHStr)); 
    String retItemQName = e.getAttribute("returnItemQName");
    if (retItemQName != null && !retItemQName.equals("")) {
      ParameterDesc param = this.desc.getReturnParamDesc();
      param.setItemQName(XMLUtils.getQNameFromString(retItemQName, e));
    } 
    String retItemType = e.getAttribute("returnItemType");
    if (retItemType != null && !retItemType.equals("")) {
      ParameterDesc param = this.desc.getReturnParamDesc();
      param.setItemType(XMLUtils.getQNameFromString(retItemType, e));
    } 
    String soapAction = e.getAttribute("soapAction");
    if (soapAction != null)
      this.desc.setSoapAction(soapAction); 
    String mepString = e.getAttribute("mep");
    if (mepString != null)
      this.desc.setMep(mepString); 
    Element[] parameters = getChildElements(e, "parameter");
    for (int i = 0; i < parameters.length; i++) {
      Element paramEl = parameters[i];
      WSDDParameter parameter = new WSDDParameter(paramEl, this.desc);
      this.desc.addParameter(parameter.getParameter());
    } 
    Element[] faultElems = getChildElements(e, "fault");
    for (int i = 0; i < faultElems.length; i++) {
      Element faultElem = faultElems[i];
      WSDDFault fault = new WSDDFault(faultElem);
      this.desc.addFault(fault.getFaultDesc());
    } 
    Element docElem = getChildElement(e, "documentation");
    if (docElem != null) {
      WSDDDocumentation documentation = new WSDDDocumentation(docElem);
      this.desc.setDocumentation(documentation.getValue());
    } 
  }
  
  public void writeToContext(SerializationContext context) throws IOException {
    AttributesImpl attrs = new AttributesImpl();
    if (this.desc.getReturnQName() != null)
      attrs.addAttribute("", "returnQName", "returnQName", "CDATA", context.qName2String(this.desc.getReturnQName())); 
    if (this.desc.getReturnType() != null)
      attrs.addAttribute("", "returnType", "returnType", "CDATA", context.qName2String(this.desc.getReturnType())); 
    if (this.desc.isReturnHeader())
      attrs.addAttribute("", "returnHeader", "returnHeader", "CDATA", "true"); 
    if (this.desc.getName() != null)
      attrs.addAttribute("", "name", "name", "CDATA", this.desc.getName()); 
    if (this.desc.getElementQName() != null)
      attrs.addAttribute("", "qname", "qname", "CDATA", context.qName2String(this.desc.getElementQName())); 
    QName retItemQName = this.desc.getReturnParamDesc().getItemQName();
    if (retItemQName != null)
      attrs.addAttribute("", "returnItemQName", "returnItemQName", "CDATA", context.qName2String(retItemQName)); 
    if (this.desc.getSoapAction() != null)
      attrs.addAttribute("", "soapAction", "soapAction", "CDATA", this.desc.getSoapAction()); 
    context.startElement(getElementName(), attrs);
    if (this.desc.getDocumentation() != null) {
      WSDDDocumentation documentation = new WSDDDocumentation(this.desc.getDocumentation());
      documentation.writeToContext(context);
    } 
    ArrayList params = this.desc.getParameters();
    for (Iterator i = params.iterator(); i.hasNext(); ) {
      ParameterDesc parameterDesc = (ParameterDesc)i.next();
      WSDDParameter p = new WSDDParameter(parameterDesc);
      p.writeToContext(context);
    } 
    ArrayList faults = this.desc.getFaults();
    if (faults != null)
      for (Iterator i = faults.iterator(); i.hasNext(); ) {
        FaultDesc faultDesc = (FaultDesc)i.next();
        WSDDFault f = new WSDDFault(faultDesc);
        f.writeToContext(context);
      }  
    context.endElement();
  }
  
  protected QName getElementName() { return QNAME_OPERATION; }
  
  public OperationDesc getOperationDesc() { return this.desc; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDOperation.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */