package org.apache.axis.deployment.wsdd;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.axis.ConfigurationException;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.XMLUtils;
import org.w3c.dom.Element;

public class WSDDGlobalConfiguration extends WSDDDeployableItem {
  private WSDDRequestFlow requestFlow;
  
  private WSDDResponseFlow responseFlow;
  
  private ArrayList roles = new ArrayList();
  
  public WSDDGlobalConfiguration() {}
  
  public WSDDGlobalConfiguration(Element e) throws WSDDException {
    super(e);
    Element reqEl = getChildElement(e, "requestFlow");
    if (reqEl != null && reqEl.getElementsByTagName("*").getLength() > 0)
      this.requestFlow = new WSDDRequestFlow(reqEl); 
    Element respEl = getChildElement(e, "responseFlow");
    if (respEl != null && respEl.getElementsByTagName("*").getLength() > 0)
      this.responseFlow = new WSDDResponseFlow(respEl); 
    Element[] roleElements = getChildElements(e, "role");
    for (int i = 0; i < roleElements.length; i++) {
      String role = XMLUtils.getChildCharacterData(roleElements[i]);
      this.roles.add(role);
    } 
  }
  
  protected QName getElementName() { return WSDDConstants.QNAME_GLOBAL; }
  
  public WSDDRequestFlow getRequestFlow() { return this.requestFlow; }
  
  public void setRequestFlow(WSDDRequestFlow reqFlow) { this.requestFlow = reqFlow; }
  
  public WSDDResponseFlow getResponseFlow() { return this.responseFlow; }
  
  public void setResponseFlow(WSDDResponseFlow responseFlow) { this.responseFlow = responseFlow; }
  
  public WSDDFaultFlow[] getFaultFlows() { return null; }
  
  public WSDDFaultFlow getFaultFlow(QName name) {
    WSDDFaultFlow[] t = getFaultFlows();
    for (int n = 0; n < t.length; n++) {
      if (t[n].getQName().equals(name))
        return t[n]; 
    } 
    return null;
  }
  
  public QName getType() { return null; }
  
  public void setType(String type) throws WSDDException { throw new WSDDException(Messages.getMessage("noTypeOnGlobalConfig00")); }
  
  public Handler makeNewInstance(EngineConfiguration registry) { return null; }
  
  public void writeToContext(SerializationContext context) throws IOException {
    context.startElement(QNAME_GLOBAL, null);
    writeParamsToContext(context);
    if (this.requestFlow != null)
      this.requestFlow.writeToContext(context); 
    if (this.responseFlow != null)
      this.responseFlow.writeToContext(context); 
    context.endElement();
  }
  
  public void deployToRegistry(WSDDDeployment registry) throws ConfigurationException {
    if (this.requestFlow != null)
      this.requestFlow.deployToRegistry(registry); 
    if (this.responseFlow != null)
      this.responseFlow.deployToRegistry(registry); 
  }
  
  public List getRoles() { return (List)this.roles.clone(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDGlobalConfiguration.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */