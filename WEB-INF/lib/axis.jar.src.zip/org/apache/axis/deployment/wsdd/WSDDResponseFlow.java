package org.apache.axis.deployment.wsdd;

import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class WSDDResponseFlow extends WSDDChain {
  public WSDDResponseFlow() {}
  
  public WSDDResponseFlow(Element e) throws WSDDException { super(e); }
  
  protected QName getElementName() { return WSDDConstants.QNAME_RESPFLOW; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDResponseFlow.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */