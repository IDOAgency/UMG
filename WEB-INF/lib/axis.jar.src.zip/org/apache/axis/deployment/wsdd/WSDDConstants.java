/*     */ package org.apache.axis.deployment.wsdd;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WSDDConstants
/*     */ {
/*     */   public static final String BEAN_SERIALIZER_FACTORY = "org.apache.axis.encoding.ser.BeanSerializerFactory";
/*     */   public static final String BEAN_DESERIALIZER_FACTORY = "org.apache.axis.encoding.ser.BeanDeserializerFactory";
/*     */   public static final String ARRAY_SERIALIZER_FACTORY = "org.apache.axis.encoding.ser.ArraySerializerFactory";
/*     */   public static final String ARRAY_DESERIALIZER_FACTORY = "org.apache.axis.encoding.ser.ArrayDeserializerFactory";
/*     */   public static final String URI_WSDD = "http://xml.apache.org/axis/wsdd/";
/*     */   public static final String URI_WSDD_JAVA = "http://xml.apache.org/axis/wsdd/providers/java";
/*     */   public static final String URI_WSDD_HANDLER = "http://xml.apache.org/axis/wsdd/providers/handler";
/*     */   public static final String URI_WSDD_WSDD_COM = "http://xml.apache.org/axis/wsdd/providers/com";
/*     */   public static final String URI_WSDD_WSDD_BSF = "http://xml.apache.org/axis/wsdd/providers/bsf";
/*     */   public static final String NS_PREFIX_WSDD = "";
/*     */   public static final String NS_PREFIX_WSDD_JAVA = "java";
/*     */   public static final String PROVIDER_RPC = "RPC";
/*     */   public static final String PROVIDER_MSG = "MSG";
/*     */   public static final String PROVIDER_HANDLER = "Handler";
/*     */   public static final String PROVIDER_EJB = "EJB";
/*     */   public static final String PROVIDER_COM = "COM";
/*     */   public static final String PROVIDER_BSF = "BSF";
/*     */   public static final String PROVIDER_CORBA = "CORBA";
/*     */   public static final String PROVIDER_RMI = "RMI";
/*  75 */   public static final QName QNAME_JAVARPC_PROVIDER = new QName("http://xml.apache.org/axis/wsdd/providers/java", "RPC");
/*  76 */   public static final QName QNAME_JAVAMSG_PROVIDER = new QName("http://xml.apache.org/axis/wsdd/providers/java", "MSG");
/*  77 */   public static final QName QNAME_HANDLER_PROVIDER = new QName("", "Handler");
/*  78 */   public static final QName QNAME_EJB_PROVIDER = new QName("http://xml.apache.org/axis/wsdd/providers/java", "EJB");
/*  79 */   public static final QName QNAME_COM_PROVIDER = new QName("http://xml.apache.org/axis/wsdd/providers/java", "COM");
/*  80 */   public static final QName QNAME_BSF_PROVIDER = new QName("http://xml.apache.org/axis/wsdd/providers/java", "BSF");
/*  81 */   public static final QName QNAME_CORBA_PROVIDER = new QName("http://xml.apache.org/axis/wsdd/providers/java", "CORBA");
/*  82 */   public static final QName QNAME_RMI_PROVIDER = new QName("http://xml.apache.org/axis/wsdd/providers/java", "RMI");
/*     */   
/*     */   public static final String ELEM_WSDD_PARAM = "parameter";
/*     */   
/*     */   public static final String ELEM_WSDD_DOC = "documentation";
/*     */   public static final String ELEM_WSDD_DEPLOY = "deployment";
/*     */   public static final String ELEM_WSDD_UNDEPLOY = "undeployment";
/*     */   public static final String ELEM_WSDD_REQFLOW = "requestFlow";
/*     */   public static final String ELEM_WSDD_RESPFLOW = "responseFlow";
/*     */   public static final String ELEM_WSDD_FAULTFLOW = "faultFlow";
/*     */   public static final String ELEM_WSDD_HANDLER = "handler";
/*     */   public static final String ELEM_WSDD_CHAIN = "chain";
/*     */   public static final String ELEM_WSDD_SERVICE = "service";
/*     */   public static final String ELEM_WSDD_TRANSPORT = "transport";
/*     */   public static final String ELEM_WSDD_GLOBAL = "globalConfiguration";
/*     */   public static final String ELEM_WSDD_TYPEMAPPING = "typeMapping";
/*     */   public static final String ELEM_WSDD_BEANMAPPING = "beanMapping";
/*     */   public static final String ELEM_WSDD_ARRAYMAPPING = "arrayMapping";
/*     */   public static final String ELEM_WSDD_OPERATION = "operation";
/*     */   public static final String ELEM_WSDD_ELEMENTMAPPING = "elementMapping";
/*     */   public static final String ELEM_WSDD_WSDLFILE = "wsdlFile";
/*     */   public static final String ELEM_WSDD_NAMESPACE = "namespace";
/*     */   public static final String ELEM_WSDD_ENDPOINTURL = "endpointURL";
/*     */   public static final String ELEM_WSDD_JAXRPC_HANDLERINFO = "handlerInfo";
/*     */   public static final String ELEM_WSDD_JAXRPC_CHAIN = "handlerInfoChain";
/*     */   public static final String ELEM_WSDD_JAXRPC_ROLE = "role";
/*     */   public static final String ELEM_WSDD_JAXRPC_HEADER = "header";
/*     */   public static final String ELEM_WSDD_FAULT = "fault";
/*     */   public static final String ELEM_WSDD_ROLE = "role";
/* 111 */   public static final QName QNAME_PARAM = new QName("http://xml.apache.org/axis/wsdd/", "parameter");
/* 112 */   public static final QName QNAME_DOC = new QName("http://xml.apache.org/axis/wsdd/", "documentation");
/* 113 */   public static final QName QNAME_DEPLOY = new QName("http://xml.apache.org/axis/wsdd/", "deployment");
/* 114 */   public static final QName QNAME_UNDEPLOY = new QName("http://xml.apache.org/axis/wsdd/", "undeployment");
/* 115 */   public static final QName QNAME_REQFLOW = new QName("http://xml.apache.org/axis/wsdd/", "requestFlow");
/* 116 */   public static final QName QNAME_RESPFLOW = new QName("http://xml.apache.org/axis/wsdd/", "responseFlow");
/* 117 */   public static final QName QNAME_FAULTFLOW = new QName("http://xml.apache.org/axis/wsdd/", "faultFlow");
/* 118 */   public static final QName QNAME_HANDLER = new QName("http://xml.apache.org/axis/wsdd/", "handler");
/* 119 */   public static final QName QNAME_CHAIN = new QName("http://xml.apache.org/axis/wsdd/", "chain");
/* 120 */   public static final QName QNAME_SERVICE = new QName("http://xml.apache.org/axis/wsdd/", "service");
/* 121 */   public static final QName QNAME_TRANSPORT = new QName("http://xml.apache.org/axis/wsdd/", "transport");
/* 122 */   public static final QName QNAME_GLOBAL = new QName("http://xml.apache.org/axis/wsdd/", "globalConfiguration");
/* 123 */   public static final QName QNAME_TYPEMAPPING = new QName("http://xml.apache.org/axis/wsdd/", "typeMapping");
/* 124 */   public static final QName QNAME_BEANMAPPING = new QName("http://xml.apache.org/axis/wsdd/", "beanMapping");
/* 125 */   public static final QName QNAME_ARRAYMAPPING = new QName("http://xml.apache.org/axis/wsdd/", "arrayMapping");
/* 126 */   public static final QName QNAME_OPERATION = new QName("http://xml.apache.org/axis/wsdd/", "operation");
/* 127 */   public static final QName QNAME_ELEMENTMAPPING = new QName("http://xml.apache.org/axis/wsdd/", "elementMapping");
/* 128 */   public static final QName QNAME_WSDLFILE = new QName("http://xml.apache.org/axis/wsdd/", "wsdlFile");
/* 129 */   public static final QName QNAME_NAMESPACE = new QName("http://xml.apache.org/axis/wsdd/", "namespace");
/* 130 */   public static final QName QNAME_ENDPOINTURL = new QName("http://xml.apache.org/axis/wsdd/", "endpointURL");
/* 131 */   public static final QName QNAME_JAXRPC_HANDLERINFO = new QName("http://xml.apache.org/axis/wsdd/", "handlerInfo");
/* 132 */   public static final QName QNAME_JAXRPC_HANDLERINFOCHAIN = new QName("http://xml.apache.org/axis/wsdd/", "handlerInfoChain");
/* 133 */   public static final QName QNAME_JAXRPC_HEADER = new QName("http://xml.apache.org/axis/wsdd/", "header");
/* 134 */   public static final QName QNAME_JAXRPC_ROLE = new QName("http://xml.apache.org/axis/wsdd/", "role");
/* 135 */   public static final QName QNAME_FAULT = new QName("http://xml.apache.org/axis/wsdd/", "fault");
/*     */   public static final String ATTR_LANG_SPEC_TYPE = "languageSpecificType";
/*     */   public static final String ATTR_QNAME = "qname";
/*     */   public static final String ATTR_NAME = "name";
/*     */   public static final String ATTR_TYPE = "type";
/*     */   public static final String ATTR_VALUE = "value";
/*     */   public static final String ATTR_LOCKED = "locked";
/*     */   public static final String ATTR_RETQNAME = "returnQName";
/*     */   public static final String ATTR_RETTYPE = "returnType";
/*     */   public static final String ATTR_RETITEMQNAME = "returnItemQName";
/*     */   public static final String ATTR_RETITEMTYPE = "returnItemType";
/*     */   public static final String ATTR_ITEMQNAME = "itemQName";
/*     */   public static final String ATTR_ITEMTYPE = "itemType";
/*     */   public static final String ATTR_MODE = "mode";
/*     */   public static final String ATTR_INHEADER = "inHeader";
/*     */   public static final String ATTR_OUTHEADER = "outHeader";
/*     */   public static final String ATTR_RETHEADER = "returnHeader";
/*     */   public static final String ATTR_STYLE = "style";
/*     */   public static final String ATTR_USE = "use";
/*     */   public static final String ATTR_STREAMING = "streaming";
/*     */   public static final String ATTR_ATTACHMENT_FORMAT = "attachment";
/*     */   public static final String ATTR_PROVIDER = "provider";
/*     */   public static final String ATTR_PIVOT = "pivot";
/*     */   public static final String ATTR_SERIALIZER = "serializer";
/*     */   public static final String ATTR_DESERIALIZER = "deserializer";
/*     */   public static final String ATTR_ENCSTYLE = "encodingStyle";
/*     */   public static final String ATTR_SOAPACTORNAME = "soapActorName";
/*     */   public static final String ATTR_CLASSNAME = "classname";
/*     */   public static final String ATTR_CLASS = "class";
/*     */   public static final String ATTR_SOAPACTION = "soapAction";
/*     */   public static final String ATTR_SOAP12ACTION = "action";
/*     */   public static final String ATTR_MEP = "mep";
/*     */   public static final String ATTR_INNER_TYPE = "innerType";
/*     */   public static final String ATTR_INNER_NAME = "innerName";
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDConstants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */