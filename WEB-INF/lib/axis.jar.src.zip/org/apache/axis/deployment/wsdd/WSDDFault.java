/*    */ package org.apache.axis.deployment.wsdd;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.description.FaultDesc;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.utils.XMLUtils;
/*    */ import org.w3c.dom.Element;
/*    */ import org.xml.sax.helpers.AttributesImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSDDFault
/*    */   extends WSDDElement
/*    */ {
/*    */   FaultDesc desc;
/*    */   
/* 35 */   public WSDDFault(FaultDesc desc) { this.desc = desc; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WSDDFault(Element e) throws WSDDException {
/* 44 */     super(e);
/*    */     
/* 46 */     this.desc = new FaultDesc();
/*    */     
/* 48 */     String nameStr = e.getAttribute("name");
/* 49 */     if (nameStr != null && !nameStr.equals("")) {
/* 50 */       this.desc.setName(nameStr);
/*    */     }
/* 52 */     String qNameStr = e.getAttribute("qname");
/* 53 */     if (qNameStr != null && !qNameStr.equals("")) {
/* 54 */       this.desc.setQName(XMLUtils.getQNameFromString(qNameStr, e));
/*    */     }
/* 56 */     String classNameStr = e.getAttribute("class");
/* 57 */     if (classNameStr != null && !classNameStr.equals("")) {
/* 58 */       this.desc.setClassName(classNameStr);
/*    */     }
/* 60 */     String xmlTypeStr = e.getAttribute("type");
/* 61 */     if (xmlTypeStr != null && !xmlTypeStr.equals("")) {
/* 62 */       this.desc.setXmlType(XMLUtils.getQNameFromString(xmlTypeStr, e));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   protected QName getElementName() { return QNAME_FAULT; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeToContext(SerializationContext context) throws IOException {
/* 77 */     AttributesImpl attrs = new AttributesImpl();
/*    */     
/* 79 */     attrs.addAttribute("", "qname", "qname", "CDATA", context.qName2String(this.desc.getQName()));
/*    */ 
/*    */ 
/*    */     
/* 83 */     attrs.addAttribute("", "class", "class", "CDATA", this.desc.getClassName());
/*    */ 
/*    */     
/* 86 */     attrs.addAttribute("", "type", "type", "CDATA", context.qName2String(this.desc.getXmlType()));
/*    */ 
/*    */ 
/*    */     
/* 90 */     context.startElement(getElementName(), attrs);
/* 91 */     context.endElement();
/*    */   }
/*    */ 
/*    */   
/* 95 */   public FaultDesc getFaultDesc() { return this.desc; }
/*    */ 
/*    */ 
/*    */   
/* 99 */   public void setFaultDesc(FaultDesc desc) { this.desc = desc; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDFault.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */