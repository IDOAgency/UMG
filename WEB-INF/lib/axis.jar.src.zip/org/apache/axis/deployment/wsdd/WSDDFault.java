package org.apache.axis.deployment.wsdd;

import java.io.IOException;
import javax.xml.namespace.QName;
import org.apache.axis.description.FaultDesc;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.XMLUtils;
import org.w3c.dom.Element;
import org.xml.sax.helpers.AttributesImpl;

public class WSDDFault extends WSDDElement {
  FaultDesc desc;
  
  public WSDDFault(FaultDesc desc) { this.desc = desc; }
  
  public WSDDFault(Element e) throws WSDDException {
    super(e);
    this.desc = new FaultDesc();
    String nameStr = e.getAttribute("name");
    if (nameStr != null && !nameStr.equals(""))
      this.desc.setName(nameStr); 
    String qNameStr = e.getAttribute("qname");
    if (qNameStr != null && !qNameStr.equals(""))
      this.desc.setQName(XMLUtils.getQNameFromString(qNameStr, e)); 
    String classNameStr = e.getAttribute("class");
    if (classNameStr != null && !classNameStr.equals(""))
      this.desc.setClassName(classNameStr); 
    String xmlTypeStr = e.getAttribute("type");
    if (xmlTypeStr != null && !xmlTypeStr.equals(""))
      this.desc.setXmlType(XMLUtils.getQNameFromString(xmlTypeStr, e)); 
  }
  
  protected QName getElementName() { return QNAME_FAULT; }
  
  public void writeToContext(SerializationContext context) throws IOException {
    AttributesImpl attrs = new AttributesImpl();
    attrs.addAttribute("", "qname", "qname", "CDATA", context.qName2String(this.desc.getQName()));
    attrs.addAttribute("", "class", "class", "CDATA", this.desc.getClassName());
    attrs.addAttribute("", "type", "type", "CDATA", context.qName2String(this.desc.getXmlType()));
    context.startElement(getElementName(), attrs);
    context.endElement();
  }
  
  public FaultDesc getFaultDesc() { return this.desc; }
  
  public void setFaultDesc(FaultDesc desc) { this.desc = desc; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDFault.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */