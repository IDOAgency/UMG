/*    */ package org.apache.axis.deployment.wsdd.providers;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.axis.EngineConfiguration;
/*    */ import org.apache.axis.Handler;
/*    */ import org.apache.axis.deployment.wsdd.WSDDProvider;
/*    */ import org.apache.axis.deployment.wsdd.WSDDService;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.providers.BSFProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSDDBsfProvider
/*    */   extends WSDDProvider
/*    */ {
/* 36 */   public String getName() { return "BSF"; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Handler newProviderInstance(WSDDService service, EngineConfiguration registry) throws Exception {
/* 43 */     BSFProvider bSFProvider = new BSFProvider();
/*    */     
/* 45 */     String option = service.getParameter("language");
/*    */     
/* 47 */     if (!option.equals("")) {
/* 48 */       bSFProvider.setOption("language", option);
/*    */     }
/*    */     
/* 51 */     option = service.getParameter("src");
/*    */     
/* 53 */     if (!option.equals("")) {
/* 54 */       bSFProvider.setOption("src", option);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 60 */     if (!option.equals("")) {
/* 61 */       bSFProvider.setOption("script", option);
/*    */     }
/*    */     
/* 64 */     return bSFProvider;
/*    */   }
/*    */   
/*    */   public void writeToContext(SerializationContext context) throws IOException {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\providers\WSDDBsfProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */