package org.apache.axis.deployment.wsdd.providers;

import java.io.IOException;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.deployment.wsdd.WSDDProvider;
import org.apache.axis.deployment.wsdd.WSDDService;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.providers.BSFProvider;

public class WSDDBsfProvider extends WSDDProvider {
  public String getName() { return "BSF"; }
  
  public Handler newProviderInstance(WSDDService service, EngineConfiguration registry) throws Exception {
    BSFProvider bSFProvider = new BSFProvider();
    String option = service.getParameter("language");
    if (!option.equals(""))
      bSFProvider.setOption("language", option); 
    option = service.getParameter("src");
    if (!option.equals(""))
      bSFProvider.setOption("src", option); 
    if (!option.equals(""))
      bSFProvider.setOption("script", option); 
    return bSFProvider;
  }
  
  public void writeToContext(SerializationContext context) throws IOException {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\providers\WSDDBsfProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */