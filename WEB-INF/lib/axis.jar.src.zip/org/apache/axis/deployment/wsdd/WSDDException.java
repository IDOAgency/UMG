/*    */ package org.apache.axis.deployment.wsdd;
/*    */ 
/*    */ import org.apache.axis.ConfigurationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSDDException
/*    */   extends ConfigurationException
/*    */ {
/* 33 */   public WSDDException(String msg) { super(msg); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public WSDDException(Exception e) { super(e); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */