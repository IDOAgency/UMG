package org.apache.axis.deployment.wsdd;

import java.io.IOException;
import javax.xml.namespace.QName;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.Messages;
import org.w3c.dom.Element;
import org.xml.sax.helpers.AttributesImpl;

public class WSDDHandler extends WSDDDeployableItem {
  public WSDDHandler() {}
  
  public WSDDHandler(Element e) throws WSDDException {
    super(e);
    if (this.type == null && getClass() == WSDDHandler.class)
      throw new WSDDException(Messages.getMessage("noTypeAttr00")); 
  }
  
  protected QName getElementName() { return QNAME_HANDLER; }
  
  public void writeToContext(SerializationContext context) throws IOException {
    AttributesImpl attrs = new AttributesImpl();
    QName name = getQName();
    if (name != null)
      attrs.addAttribute("", "name", "name", "CDATA", context.qName2String(name)); 
    attrs.addAttribute("", "type", "type", "CDATA", context.qName2String(getType()));
    context.startElement(WSDDConstants.QNAME_HANDLER, attrs);
    writeParamsToContext(context);
    context.endElement();
  }
  
  public void deployToRegistry(WSDDDeployment deployment) { deployment.addHandler(this); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */