package org.apache.axis.deployment.wsdd;

public class WSDDNonFatalException extends WSDDException {
  public WSDDNonFatalException(String msg) { super(msg); }
  
  public WSDDNonFatalException(Exception e) { super(e); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\deployment\wsdd\WSDDNonFatalException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */