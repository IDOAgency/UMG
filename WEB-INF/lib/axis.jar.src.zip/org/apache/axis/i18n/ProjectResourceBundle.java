package org.apache.axis.i18n;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class ProjectResourceBundle extends ResourceBundle {
  protected static Log log = LogFactory.getLog(ProjectResourceBundle.class.getName());
  
  private static final Hashtable bundleCache = new Hashtable();
  
  private static final Locale defaultLocale = Locale.getDefault();
  
  private final ResourceBundle resourceBundle;
  
  private final String resourceName;
  
  protected Object handleGetObject(String key) throws MissingResourceException {
    Object obj;
    if (log.isDebugEnabled())
      log.debug(toString() + "::handleGetObject(" + key + ")"); 
    try {
      obj = this.resourceBundle.getObject(key);
    } catch (MissingResourceException e) {
      obj = null;
    } 
    return obj;
  }
  
  public Enumeration getKeys() {
    Enumeration myKeys = this.resourceBundle.getKeys();
    if (this.parent == null)
      return myKeys; 
    HashSet set = new HashSet();
    while (myKeys.hasMoreElements())
      set.add(myKeys.nextElement()); 
    Enumeration pKeys = this.parent.getKeys();
    while (pKeys.hasMoreElements())
      set.add(pKeys.nextElement()); 
    return new Enumeration(this, set) {
        private Iterator it;
        
        private final HashSet val$set;
        
        private final ProjectResourceBundle this$0;
        
        public boolean hasMoreElements() { return this.it.hasNext(); }
        
        public Object nextElement() { return this.it.next(); }
      };
  }
  
  public static ProjectResourceBundle getBundle(String projectName, String packageName, String resourceName) throws MissingResourceException { return getBundle(projectName, packageName, resourceName, null, null, null); }
  
  public static ProjectResourceBundle getBundle(String projectName, Class caller, String resourceName, Locale locale) throws MissingResourceException { return getBundle(projectName, caller, resourceName, locale, null); }
  
  public static ProjectResourceBundle getBundle(String projectName, String packageName, String resourceName, Locale locale, ClassLoader loader) throws MissingResourceException { return getBundle(projectName, packageName, resourceName, locale, loader, null); }
  
  public static ProjectResourceBundle getBundle(String projectName, Class caller, String resourceName, Locale locale, ResourceBundle extendsBundle) throws MissingResourceException { return getBundle(projectName, getPackage(caller.getClass().getName()), resourceName, locale, caller.getClass().getClassLoader(), extendsBundle); }
  
  public static ProjectResourceBundle getBundle(String projectName, String packageName, String resourceName, Locale locale, ClassLoader loader, ResourceBundle extendsBundle) throws MissingResourceException {
    if (log.isDebugEnabled())
      log.debug("getBundle(" + projectName + "," + packageName + "," + resourceName + "," + String.valueOf(locale) + ",...)"); 
    Context context = new Context(null);
    context.setLocale(locale);
    context.setLoader(loader);
    context.setProjectName(projectName);
    context.setResourceName(resourceName);
    context.setParentBundle(extendsBundle);
    packageName = context.validate(packageName);
    ProjectResourceBundle bundle = null;
    try {
      bundle = getBundle(context, packageName);
    } catch (RuntimeException e) {
      log.debug("Exception: ", e);
      throw e;
    } 
    if (bundle == null)
      throw new MissingResourceException("Cannot find resource '" + packageName + '.' + resourceName + "'", resourceName, ""); 
    return bundle;
  }
  
  private static ProjectResourceBundle getBundle(Context context, String packageName) throws MissingResourceException {
    String cacheKey = context.getCacheKey(packageName);
    ProjectResourceBundle prb = (ProjectResourceBundle)bundleCache.get(cacheKey);
    if (prb == null) {
      String name = packageName + '.' + context.getResourceName();
      ResourceBundle rb = context.loadBundle(packageName);
      ResourceBundle parent = context.getParentBundle(packageName);
      if (rb != null) {
        prb = new ProjectResourceBundle(name, rb);
        prb.setParent(parent);
        if (log.isDebugEnabled())
          log.debug("Created " + prb + ", linked to parent " + String.valueOf(parent)); 
      } else if (parent != null) {
        if (parent instanceof ProjectResourceBundle) {
          prb = (ProjectResourceBundle)parent;
        } else {
          prb = new ProjectResourceBundle(name, parent);
        } 
        if (log.isDebugEnabled())
          log.debug("Root package not found, cross link to " + parent); 
      } 
      if (prb != null)
        bundleCache.put(cacheKey, prb); 
    } 
    return prb;
  }
  
  private static final String getPackage(String name) { return name.substring(0, name.lastIndexOf('.')).intern(); }
  
  private ProjectResourceBundle(String name, ResourceBundle bundle) throws MissingResourceException {
    this.resourceBundle = bundle;
    this.resourceName = name;
  }
  
  public String getResourceName() { return this.resourceName; }
  
  public static void clearCache() { bundleCache.clear(); }
  
  public String toString() { return this.resourceName; }
  
  private static class Context {
    private Locale _locale;
    
    private ClassLoader _loader;
    
    private String _projectName;
    
    private String _resourceName;
    
    private ResourceBundle _parent;
    
    private Context() {}
    
    void setLocale(Locale l) { this._locale = (l == null) ? defaultLocale : l; }
    
    void setLoader(ClassLoader l) {
      this._loader = (l != null) ? l : getClass().getClassLoader();
      if (this._loader == null)
        this._loader = ClassLoader.getSystemClassLoader(); 
    }
    
    void setProjectName(String name) { this._projectName = name.intern(); }
    
    void setResourceName(String name) { this._resourceName = name.intern(); }
    
    void setParentBundle(ResourceBundle b) { this._parent = b; }
    
    Locale getLocale() { return this._locale; }
    
    ClassLoader getLoader() { return this._loader; }
    
    String getProjectName() { return this._projectName; }
    
    String getResourceName() { return this._resourceName; }
    
    ResourceBundle getParentBundle() { return this._parent; }
    
    String getCacheKey(String packageName) {
      String loaderName = (this._loader == null) ? "" : (":" + this._loader.hashCode());
      return packageName + "." + this._resourceName + ":" + this._locale + ":" + defaultLocale + loaderName;
    }
    
    ResourceBundle loadBundle(String packageName) {
      try {
        return ResourceBundle.getBundle(packageName + '.' + this._resourceName, this._locale, this._loader);
      } catch (MissingResourceException e) {
        ProjectResourceBundle.log.debug("loadBundle: Ignoring MissingResourceException: " + e.getMessage());
        return null;
      } 
    }
    
    ResourceBundle getParentBundle(String packageName) {
      ResourceBundle p;
      if (packageName != this._projectName) {
        p = ProjectResourceBundle.getBundle(this, ProjectResourceBundle.getPackage(packageName));
      } else {
        p = this._parent;
        this._parent = null;
      } 
      return p;
    }
    
    String validate(String packageName) {
      if (this._projectName == null || this._projectName.length() == 0) {
        ProjectResourceBundle.log.debug("Project name not specified");
        throw new MissingResourceException("Project name not specified", "", "");
      } 
      if (packageName == null || packageName.length() == 0) {
        ProjectResourceBundle.log.debug("Package name not specified");
        throw new MissingResourceException("Package not specified", packageName, "");
      } 
      packageName = packageName.intern();
      if (packageName != this._projectName && !packageName.startsWith(this._projectName + '.')) {
        ProjectResourceBundle.log.debug("Project not a prefix of Package");
        throw new MissingResourceException("Project '" + this._projectName + "' must be a prefix of Package '" + packageName + "'", packageName + '.' + this._resourceName, "");
      } 
      return packageName;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\i18n\ProjectResourceBundle.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */