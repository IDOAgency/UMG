package org.apache.axis.i18n;

import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Properties;

public class RB {
  static Hashtable propertyCache = new Hashtable();
  
  public static final String BASE_NAME = "resource";
  
  public static final String PROPERTY_EXT = ".properties";
  
  protected String basePropertyFileName;
  
  protected Properties resourceProperties;
  
  public RB(String name) throws MissingResourceException { this(null, name, null); }
  
  public RB(Object caller, String name) throws MissingResourceException { this(caller, name, null); }
  
  public RB(Object caller, String name, Locale locale) throws MissingResourceException {
    ClassLoader cl = null;
    if (caller != null) {
      Class c;
      if (caller instanceof Class) {
        c = (Class)caller;
      } else {
        c = caller.getClass();
      } 
      cl = c.getClassLoader();
      if (name.indexOf("/") == -1) {
        String fullName = c.getName();
        int pos = fullName.lastIndexOf(".");
        if (pos > 0)
          name = fullName.substring(0, pos + 1).replace('.', '/') + name; 
      } 
    } else if (name.indexOf("/") == -1) {
      name = "org/apache/axis/default-resource";
    } 
    Locale defaultLocale = Locale.getDefault();
    if (locale != null && 
      locale.equals(defaultLocale))
      locale = null; 
    loadProperties(name, cl, locale, defaultLocale);
  }
  
  public String getString(String key) throws MissingResourceException { return getString(key, (Object[])null); }
  
  public String getString(String key, Object arg0) throws MissingResourceException {
    Object[] o = new Object[1];
    o[0] = arg0;
    return getString(key, o);
  }
  
  public String getString(String key, Object arg0, Object arg1) throws MissingResourceException {
    Object[] o = new Object[2];
    o[0] = arg0;
    o[1] = arg1;
    return getString(key, o);
  }
  
  public String getString(String key, Object arg0, Object arg1, Object arg2) throws MissingResourceException {
    Object[] o = new Object[3];
    o[0] = arg0;
    o[1] = arg1;
    o[2] = arg2;
    return getString(key, o);
  }
  
  public String getString(String key, Object[] array) throws MissingResourceException {
    msg = null;
    if (this.resourceProperties != null)
      msg = this.resourceProperties.getProperty(key); 
    if (msg == null)
      throw new MissingResourceException("Cannot find resource key \"" + key + "\" in base name " + this.basePropertyFileName, this.basePropertyFileName, key); 
    return MessageFormat.format(msg, array);
  }
  
  protected void loadProperties(String basename, ClassLoader loader, Locale locale, Locale defaultLocale) throws MissingResourceException {
    String loaderName = "";
    if (loader != null)
      loaderName = ":" + loader.hashCode(); 
    String cacheKey = basename + ":" + locale + ":" + defaultLocale + loaderName;
    Properties p = (Properties)propertyCache.get(cacheKey);
    this.basePropertyFileName = basename + ".properties";
    if (p == null) {
      if (locale != null)
        p = loadProperties(basename, loader, locale, p); 
      if (defaultLocale != null)
        p = loadProperties(basename, loader, defaultLocale, p); 
      p = merge(p, loadProperties(this.basePropertyFileName, loader));
      if (p == null)
        throw new MissingResourceException("Cannot find resource for base name " + this.basePropertyFileName, this.basePropertyFileName, ""); 
      propertyCache.put(cacheKey, p);
    } 
    this.resourceProperties = p;
  }
  
  protected Properties loadProperties(String basename, ClassLoader loader, Locale locale, Properties props) {
    String language = locale.getLanguage();
    String country = locale.getCountry();
    String variant = locale.getVariant();
    if (variant != null && 
      variant.trim().length() == 0)
      variant = null; 
    if (language != null) {
      if (country != null) {
        if (variant != null)
          props = merge(props, loadProperties(basename + "_" + language + "_" + country + "_" + variant + ".properties", loader)); 
        props = merge(props, loadProperties(basename + "_" + language + "_" + country + ".properties", loader));
      } 
      props = merge(props, loadProperties(basename + "_" + language + ".properties", loader));
    } 
    return props;
  }
  
  protected Properties loadProperties(String resname, ClassLoader loader) {
    Properties props = null;
    InputStream in = null;
    try {
      if (loader != null)
        in = loader.getResourceAsStream(resname); 
      if (in == null)
        in = ClassLoader.getSystemResourceAsStream(resname); 
      if (in != null) {
        props = new Properties();
        try {
          props.load(in);
        } catch (IOException ex) {
          props = null;
        } 
      } 
    } finally {
      if (in != null)
        try {
          in.close();
        } catch (Exception ex) {} 
    } 
    return props;
  }
  
  protected Properties merge(Properties p1, Properties p2) {
    if (p1 == null && p2 == null)
      return null; 
    if (p1 == null)
      return p2; 
    if (p2 == null)
      return p1; 
    Enumeration enumeration = p2.keys();
    while (enumeration.hasMoreElements()) {
      String key = (String)enumeration.nextElement();
      if (p1.getProperty(key) == null)
        p1.put(key, p2.getProperty(key)); 
    } 
    return p1;
  }
  
  public Properties getProperties() { return this.resourceProperties; }
  
  public static String getString(Object caller, String key) throws MissingResourceException { return getMessage(caller, "resource", null, key, null); }
  
  public static String getString(Object caller, String key, Object arg0) throws MissingResourceException {
    Object[] o = new Object[1];
    o[0] = arg0;
    return getMessage(caller, "resource", null, key, o);
  }
  
  public static String getString(Object caller, String key, Object arg0, Object arg1) throws MissingResourceException {
    Object[] o = new Object[2];
    o[0] = arg0;
    o[1] = arg1;
    return getMessage(caller, "resource", null, key, o);
  }
  
  public static String getString(Object caller, String key, Object arg0, Object arg1, Object arg2) throws MissingResourceException {
    Object[] o = new Object[3];
    o[0] = arg0;
    o[1] = arg1;
    o[2] = arg2;
    return getMessage(caller, "resource", null, key, o);
  }
  
  public static String getString(Object caller, String key, Object arg0, Object arg1, Object arg2, Object arg3) throws MissingResourceException {
    Object[] o = new Object[4];
    o[0] = arg0;
    o[1] = arg1;
    o[2] = arg2;
    o[3] = arg3;
    return getMessage(caller, "resource", null, key, o);
  }
  
  public static String getString(Object caller, String key, Object arg0, Object arg1, Object arg2, Object arg3, Object arg4) throws MissingResourceException {
    Object[] o = new Object[5];
    o[0] = arg0;
    o[1] = arg1;
    o[2] = arg2;
    o[3] = arg3;
    o[4] = arg4;
    return getMessage(caller, "resource", null, key, o);
  }
  
  public static String getString(Object caller, String key, Object[] args) throws MissingResourceException { return getMessage(caller, "resource", null, key, args); }
  
  public static String getString(Object caller, Locale locale, String key) throws MissingResourceException { return getMessage(caller, "resource", locale, key, null); }
  
  public static String getString(Object caller, Locale locale, String key, Object arg0) throws MissingResourceException {
    Object[] o = new Object[1];
    o[0] = arg0;
    return getMessage(caller, "resource", locale, key, o);
  }
  
  public static String getString(Object caller, Locale locale, String key, Object arg0, Object arg1) throws MissingResourceException {
    Object[] o = new Object[2];
    o[0] = arg0;
    o[1] = arg1;
    return getMessage(caller, "resource", locale, key, o);
  }
  
  public static String getString(Object caller, Locale locale, String key, Object arg0, Object arg1, Object arg2) throws MissingResourceException {
    Object[] o = new Object[3];
    o[0] = arg0;
    o[1] = arg1;
    o[2] = arg2;
    return getMessage(caller, "resource", locale, key, o);
  }
  
  public static String getString(Object caller, Locale locale, String key, Object arg0, Object arg1, Object arg2, Object arg3) throws MissingResourceException {
    Object[] o = new Object[4];
    o[0] = arg0;
    o[1] = arg1;
    o[2] = arg2;
    o[3] = arg3;
    return getMessage(caller, "resource", locale, key, o);
  }
  
  public static String getString(Object caller, Locale locale, String key, Object arg0, Object arg1, Object arg2, Object arg3, Object arg4) throws MissingResourceException {
    Object[] o = new Object[5];
    o[0] = arg0;
    o[1] = arg1;
    o[2] = arg2;
    o[3] = arg3;
    o[4] = arg4;
    return getMessage(caller, "resource", locale, key, o);
  }
  
  public static String getString(Object caller, Locale locale, String key, Object[] args) throws MissingResourceException { return getMessage(caller, "resource", locale, key, args); }
  
  public static String getMessage(Object caller, String basename, Locale locale, String key, Object[] args) throws MissingResourceException {
    String msg = null;
    MissingResourceException firstEx = null;
    String fullName = null;
    Class curClass = null;
    boolean didNull = false;
    if (caller != null)
      if (caller instanceof Class) {
        curClass = (Class)caller;
      } else {
        curClass = caller.getClass();
      }  
    while (msg == null) {
      if (curClass != null) {
        String pkgName = curClass.getName();
        int pos = pkgName.lastIndexOf(".");
        if (pos > 0) {
          fullName = pkgName.substring(0, pos + 1).replace('.', '/') + basename;
        } else {
          fullName = basename;
        } 
      } else {
        fullName = basename;
      } 
      try {
        RB rb = new RB(caller, fullName, locale);
        msg = rb.getString(key, args);
      } catch (MissingResourceException ex) {
        if (curClass == null)
          throw ex; 
        if (firstEx == null)
          firstEx = ex; 
        curClass = curClass.getSuperclass();
        if (curClass == null) {
          if (didNull)
            throw firstEx; 
          didNull = true;
          caller = null;
          continue;
        } 
        String cname = curClass.getName();
        if (cname.startsWith("java.") || cname.startsWith("javax.")) {
          if (didNull)
            throw firstEx; 
          didNull = true;
          caller = null;
          curClass = null;
        } 
      } 
    } 
    return msg;
  }
  
  public static void clearCache() { propertyCache.clear(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\i18n\RB.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */