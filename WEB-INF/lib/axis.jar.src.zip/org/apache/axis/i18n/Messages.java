/*     */ package org.apache.axis.i18n;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Messages
/*     */ {
/*  42 */   private static final Class thisClass = Messages.class;
/*     */   
/*  44 */   private static final String projectName = MessagesConstants.projectName;
/*     */   
/*  46 */   private static final String resourceName = MessagesConstants.resourceName;
/*  47 */   private static final Locale locale = MessagesConstants.locale;
/*     */   
/*  49 */   private static final String packageName = getPackage(thisClass.getName());
/*  50 */   private static final ClassLoader classLoader = thisClass.getClassLoader();
/*     */   
/*  52 */   private static final ResourceBundle parent = (MessagesConstants.rootPackageName == packageName) ? null : MessagesConstants.rootBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private static final MessageBundle messageBundle = new MessageBundle(projectName, packageName, resourceName, locale, classLoader, parent);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static String getMessage(String key) throws MissingResourceException { return messageBundle.getMessage(key); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public static String getMessage(String key, String arg0) throws MissingResourceException { return messageBundle.getMessage(key, arg0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public static String getMessage(String key, String arg0, String arg1) throws MissingResourceException { return messageBundle.getMessage(key, arg0, arg1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public static String getMessage(String key, String arg0, String arg1, String arg2) throws MissingResourceException { return messageBundle.getMessage(key, arg0, arg1, arg2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public static String getMessage(String key, String arg0, String arg1, String arg2, String arg3) throws MissingResourceException { return messageBundle.getMessage(key, arg0, arg1, arg2, arg3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   public static String getMessage(String key, String arg0, String arg1, String arg2, String arg3, String arg4) throws MissingResourceException { return messageBundle.getMessage(key, arg0, arg1, arg2, arg3, arg4); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public static String getMessage(String key, String[] args) throws MissingResourceException { return messageBundle.getMessage(key, args); }
/*     */ 
/*     */ 
/*     */   
/* 158 */   public static ResourceBundle getResourceBundle() { return messageBundle.getResourceBundle(); }
/*     */ 
/*     */ 
/*     */   
/* 162 */   public static MessageBundle getMessageBundle() { return messageBundle; }
/*     */ 
/*     */ 
/*     */   
/* 166 */   private static final String getPackage(String name) throws MissingResourceException { return name.substring(0, name.lastIndexOf('.')).intern(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\i18n\Messages.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */