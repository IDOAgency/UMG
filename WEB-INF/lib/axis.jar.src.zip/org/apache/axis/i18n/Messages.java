package org.apache.axis.i18n;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class Messages {
  private static final Class thisClass = Messages.class;
  
  private static final String projectName = MessagesConstants.projectName;
  
  private static final String resourceName = MessagesConstants.resourceName;
  
  private static final Locale locale = MessagesConstants.locale;
  
  private static final String packageName = getPackage(thisClass.getName());
  
  private static final ClassLoader classLoader = thisClass.getClassLoader();
  
  private static final ResourceBundle parent = (MessagesConstants.rootPackageName == packageName) ? null : MessagesConstants.rootBundle;
  
  private static final MessageBundle messageBundle = new MessageBundle(projectName, packageName, resourceName, locale, classLoader, parent);
  
  public static String getMessage(String key) throws MissingResourceException { return messageBundle.getMessage(key); }
  
  public static String getMessage(String key, String arg0) throws MissingResourceException { return messageBundle.getMessage(key, arg0); }
  
  public static String getMessage(String key, String arg0, String arg1) throws MissingResourceException { return messageBundle.getMessage(key, arg0, arg1); }
  
  public static String getMessage(String key, String arg0, String arg1, String arg2) throws MissingResourceException { return messageBundle.getMessage(key, arg0, arg1, arg2); }
  
  public static String getMessage(String key, String arg0, String arg1, String arg2, String arg3) throws MissingResourceException { return messageBundle.getMessage(key, arg0, arg1, arg2, arg3); }
  
  public static String getMessage(String key, String arg0, String arg1, String arg2, String arg3, String arg4) throws MissingResourceException { return messageBundle.getMessage(key, arg0, arg1, arg2, arg3, arg4); }
  
  public static String getMessage(String key, String[] args) throws MissingResourceException { return messageBundle.getMessage(key, args); }
  
  public static ResourceBundle getResourceBundle() { return messageBundle.getResourceBundle(); }
  
  public static MessageBundle getMessageBundle() { return messageBundle; }
  
  private static final String getPackage(String name) throws MissingResourceException { return name.substring(0, name.lastIndexOf('.')).intern(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\i18n\Messages.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */