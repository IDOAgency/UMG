/*    */ package org.apache.axis.i18n;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessagesConstants
/*    */ {
/* 26 */   public static final String projectName = "org.apache.axis".intern();
/* 27 */   public static final String resourceName = "resource".intern();
/* 28 */   public static final Locale locale = null;
/*    */   
/* 30 */   public static final String rootPackageName = "org.apache.axis.i18n".intern();
/*    */   
/* 32 */   public static final ResourceBundle rootBundle = ProjectResourceBundle.getBundle(projectName, rootPackageName, resourceName, locale, MessagesConstants.class.getClassLoader(), null);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\i18n\MessagesConstants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */