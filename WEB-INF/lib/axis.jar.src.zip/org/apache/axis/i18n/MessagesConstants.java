package org.apache.axis.i18n;

import java.util.Locale;
import java.util.ResourceBundle;

public class MessagesConstants {
  public static final String projectName = "org.apache.axis".intern();
  
  public static final String resourceName = "resource".intern();
  
  public static final Locale locale = null;
  
  public static final String rootPackageName = "org.apache.axis.i18n".intern();
  
  public static final ResourceBundle rootBundle = ProjectResourceBundle.getBundle(projectName, rootPackageName, resourceName, locale, MessagesConstants.class.getClassLoader(), null);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\i18n\MessagesConstants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */