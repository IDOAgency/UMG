/*     */ package org.apache.axis.i18n;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageBundle
/*     */ {
/*     */   private boolean loaded;
/*     */   private ProjectResourceBundle _resourceBundle;
/*     */   private final String projectName;
/*     */   private final String packageName;
/*     */   private final String resourceName;
/*     */   private final Locale locale;
/*     */   private final ClassLoader classLoader;
/*     */   private final ResourceBundle parent;
/*     */   
/*     */   public final ProjectResourceBundle getResourceBundle() {
/*  47 */     if (!this.loaded) {
/*  48 */       this._resourceBundle = ProjectResourceBundle.getBundle(this.projectName, this.packageName, this.resourceName, this.locale, this.classLoader, this.parent);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  54 */       this.loaded = true;
/*     */     } 
/*  56 */     return this._resourceBundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageBundle(String projectName, String packageName, String resourceName, Locale locale, ClassLoader classLoader, ResourceBundle parent) throws MissingResourceException {
/*     */     this.loaded = false;
/*     */     this._resourceBundle = null;
/*  70 */     this.projectName = projectName;
/*  71 */     this.packageName = packageName;
/*  72 */     this.resourceName = resourceName;
/*  73 */     this.locale = locale;
/*  74 */     this.classLoader = classLoader;
/*  75 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public String getMessage(String key) throws MissingResourceException { return getMessage(key, (String[])null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public String getMessage(String key, String arg0) throws MissingResourceException { return getMessage(key, new String[] { arg0 }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public String getMessage(String key, String arg0, String arg1) throws MissingResourceException { return getMessage(key, new String[] { arg0, arg1 }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public String getMessage(String key, String arg0, String arg1, String arg2) throws MissingResourceException { return getMessage(key, new String[] { arg0, arg1, arg2 }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public String getMessage(String key, String arg0, String arg1, String arg2, String arg3) throws MissingResourceException { return getMessage(key, new String[] { arg0, arg1, arg2, arg3 }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public String getMessage(String key, String arg0, String arg1, String arg2, String arg3, String arg4) throws MissingResourceException { return getMessage(key, new String[] { arg0, arg1, arg2, arg3, arg4 }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage(String key, String[] array) throws MissingResourceException {
/* 191 */     String msg = null;
/* 192 */     if (getResourceBundle() != null) {
/* 193 */       msg = getResourceBundle().getString(key);
/*     */     }
/*     */     
/* 196 */     if (msg == null) {
/* 197 */       throw new MissingResourceException("Cannot find resource key \"" + key + "\" in base name " + getResourceBundle().getResourceName(), getResourceBundle().getResourceName(), key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     return MessageFormat.format(msg, array);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\i18n\MessageBundle.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */