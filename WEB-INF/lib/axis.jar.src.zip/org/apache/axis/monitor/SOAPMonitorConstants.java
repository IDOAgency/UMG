package org.apache.axis.monitor;

public class SOAPMonitorConstants {
  public static final int SOAP_MONITOR_REQUEST = 0;
  
  public static final int SOAP_MONITOR_RESPONSE = 1;
  
  public static final String SOAP_MONITOR_PORT = "SOAPMonitorPort";
  
  public static final String SOAP_MONITOR_ID = "SOAPMonitorId";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\monitor\SOAPMonitorConstants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */