package org.apache.axis.components.threadpool;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.i18n.Messages;
import org.apache.commons.logging.Log;

public class ThreadPool {
  protected static Log log = LogFactory.getLog(ThreadPool.class.getName());
  
  public static final int DEFAULT_MAX_THREADS = 100;
  
  protected Map threads = new Hashtable();
  
  protected long threadcount;
  
  public boolean _shutdown;
  
  private int maxPoolSize = 100;
  
  public ThreadPool(int maxPoolSize) { this.maxPoolSize = maxPoolSize; }
  
  public void cleanup() {
    if (log.isDebugEnabled())
      log.debug("Enter: ThreadPool::cleanup"); 
    if (!isShutdown()) {
      safeShutdown();
      awaitShutdown();
    } 
    synchronized (this) {
      this.threads.clear();
      this._shutdown = false;
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: ThreadPool::cleanup"); 
  }
  
  public boolean isShutdown() {
    synchronized (this) {
      return (this._shutdown && this.threadcount == 0L);
    } 
  }
  
  public boolean isShuttingDown() {
    synchronized (this) {
      return this._shutdown;
    } 
  }
  
  public long getWorkerCount() {
    synchronized (this) {
      return this.threadcount;
    } 
  }
  
  public void addWorker(Runnable worker) {
    if (log.isDebugEnabled())
      log.debug("Enter: ThreadPool::addWorker"); 
    if (this._shutdown || this.threadcount == this.maxPoolSize)
      throw new IllegalStateException(Messages.getMessage("illegalStateException00")); 
    Thread thread = new Thread(worker);
    this.threads.put(worker, thread);
    this.threadcount++;
    thread.start();
    if (log.isDebugEnabled())
      log.debug("Exit: ThreadPool::addWorker"); 
  }
  
  public void interruptAll() {
    if (log.isDebugEnabled())
      log.debug("Enter: ThreadPool::interruptAll"); 
    synchronized (this.threads) {
      for (Iterator i = this.threads.values().iterator(); i.hasNext(); ) {
        Thread t = (Thread)i.next();
        t.interrupt();
      } 
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: ThreadPool::interruptAll"); 
  }
  
  public void shutdown() {
    if (log.isDebugEnabled())
      log.debug("Enter: ThreadPool::shutdown"); 
    synchronized (this) {
      this._shutdown = true;
    } 
    interruptAll();
    if (log.isDebugEnabled())
      log.debug("Exit: ThreadPool::shutdown"); 
  }
  
  public void safeShutdown() {
    if (log.isDebugEnabled())
      log.debug("Enter: ThreadPool::safeShutdown"); 
    synchronized (this) {
      this._shutdown = true;
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: ThreadPool::safeShutdown"); 
  }
  
  public void awaitShutdown() {
    if (log.isDebugEnabled())
      log.debug("Enter: ThreadPool::awaitShutdown"); 
    if (!this._shutdown)
      throw new IllegalStateException(Messages.getMessage("illegalStateException00")); 
    while (this.threadcount > 0L)
      wait(); 
    if (log.isDebugEnabled())
      log.debug("Exit: ThreadPool::awaitShutdown"); 
  }
  
  public boolean awaitShutdown(long timeout) throws InterruptedException {
    if (log.isDebugEnabled())
      log.debug("Enter: ThreadPool::awaitShutdown"); 
    if (!this._shutdown)
      throw new IllegalStateException(Messages.getMessage("illegalStateException00")); 
    if (this.threadcount == 0L) {
      if (log.isDebugEnabled())
        log.debug("Exit: ThreadPool::awaitShutdown"); 
      return true;
    } 
    long waittime = timeout;
    if (waittime <= 0L) {
      if (log.isDebugEnabled())
        log.debug("Exit: ThreadPool::awaitShutdown"); 
      return false;
    } 
    do {
      wait(waittime);
      if (this.threadcount == 0L) {
        if (log.isDebugEnabled())
          log.debug("Exit: ThreadPool::awaitShutdown"); 
        return true;
      } 
      waittime = timeout - System.currentTimeMillis();
    } while (waittime > 0L);
    if (log.isDebugEnabled())
      log.debug("Exit: ThreadPool::awaitShutdown"); 
    return false;
  }
  
  public void workerDone(Runnable worker, boolean restart) {
    if (log.isDebugEnabled())
      log.debug("Enter: ThreadPool::workerDone"); 
    synchronized (this) {
      this.threads.remove(worker);
      if (--this.threadcount == 0L && this._shutdown)
        notifyAll(); 
      if (!this._shutdown && restart)
        addWorker(worker); 
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: ThreadPool::workerDone"); 
  }
  
  public ThreadPool() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\threadpool\ThreadPool.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */