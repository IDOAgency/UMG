/*    */ package org.apache.axis.components.encoding;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EncodedByteArray
/*    */ {
/*    */   private byte[] array;
/*    */   private int pointer;
/*    */   private final double PADDING = 1.5D;
/*    */   
/*    */   public EncodedByteArray(byte[] bytes, int startPos, int length) {
/* 32 */     this.array = null;
/*    */ 
/*    */     
/* 35 */     this.PADDING = 1.5D;
/*    */ 
/*    */ 
/*    */     
/* 39 */     this.array = new byte[(int)(bytes.length * 1.5D)];
/* 40 */     System.arraycopy(bytes, startPos, this.array, 0, length);
/* 41 */     this.pointer = length;
/*    */   } public EncodedByteArray(int size) {
/*    */     this.array = null;
/*    */     this.PADDING = 1.5D;
/* 45 */     this.array = new byte[size];
/*    */   }
/*    */   
/*    */   public void append(int aByte) {
/* 49 */     if (this.pointer + 1 >= this.array.length) {
/* 50 */       byte[] newArray = new byte[(int)(this.array.length * 1.5D)];
/* 51 */       System.arraycopy(this.array, 0, newArray, 0, this.pointer);
/* 52 */       this.array = newArray;
/*    */     } 
/* 54 */     this.array[this.pointer] = (byte)aByte;
/* 55 */     this.pointer++;
/*    */   }
/*    */   
/*    */   public void append(byte[] byteArray) {
/* 59 */     if (this.pointer + byteArray.length >= this.array.length) {
/* 60 */       byte[] newArray = new byte[(int)(this.array.length * 1.5D) + byteArray.length];
/* 61 */       System.arraycopy(this.array, 0, newArray, 0, this.pointer);
/* 62 */       this.array = newArray;
/*    */     } 
/*    */     
/* 65 */     System.arraycopy(byteArray, 0, this.array, this.pointer, byteArray.length);
/* 66 */     this.pointer += byteArray.length;
/*    */   }
/*    */   
/*    */   public void append(byte[] byteArray, int pos, int length) {
/* 70 */     if (this.pointer + length >= this.array.length) {
/* 71 */       byte[] newArray = new byte[(int)(this.array.length * 1.5D) + byteArray.length];
/* 72 */       System.arraycopy(this.array, 0, newArray, 0, this.pointer);
/* 73 */       this.array = newArray;
/*    */     } 
/* 75 */     System.arraycopy(byteArray, pos, this.array, this.pointer, length);
/* 76 */     this.pointer += length;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 84 */   public String toString() { return new String(this.array, 0, this.pointer); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 94 */   public String toString(String charsetName) throws UnsupportedEncodingException { return new String(this.array, 0, this.pointer, charsetName); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\encoding\EncodedByteArray.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */