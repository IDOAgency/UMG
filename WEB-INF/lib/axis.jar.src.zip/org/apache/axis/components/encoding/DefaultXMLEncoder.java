package org.apache.axis.components.encoding;

public class DefaultXMLEncoder extends UTF8Encoder {
  private String encoding;
  
  public DefaultXMLEncoder(String encoding) {
    this.encoding = null;
    this.encoding = encoding;
  }
  
  public String getEncoding() { return this.encoding; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\encoding\DefaultXMLEncoder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */