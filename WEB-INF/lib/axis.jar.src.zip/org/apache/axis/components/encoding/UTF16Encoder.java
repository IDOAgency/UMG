/*    */ package org.apache.axis.components.encoding;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.apache.axis.i18n.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UTF16Encoder
/*    */   extends AbstractXMLEncoder
/*    */ {
/* 36 */   public String getEncoding() { return "UTF-16"; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeEncoded(Writer writer, String xmlString) throws IOException {
/* 47 */     if (xmlString == null) {
/*    */       return;
/*    */     }
/* 50 */     int length = xmlString.length();
/*    */     
/* 52 */     for (int i = 0; i < length; i++) {
/* 53 */       char character = xmlString.charAt(i);
/* 54 */       switch (character) {
/*    */ 
/*    */         
/*    */         case '&':
/* 58 */           writer.write("&amp;");
/*    */           break;
/*    */         case '"':
/* 61 */           writer.write("&quot;");
/*    */           break;
/*    */         case '<':
/* 64 */           writer.write("&lt;");
/*    */           break;
/*    */         case '>':
/* 67 */           writer.write("&gt;");
/*    */           break;
/*    */         case '\n':
/* 70 */           writer.write("\n");
/*    */           break;
/*    */         case '\r':
/* 73 */           writer.write("\r");
/*    */           break;
/*    */         case '\t':
/* 76 */           writer.write("\t");
/*    */           break;
/*    */         default:
/* 79 */           if (character < ' ') {
/* 80 */             throw new IllegalArgumentException(Messages.getMessage("invalidXmlCharacter00", Integer.toHexString(character), xmlString.substring(0, i)));
/*    */           }
/*    */ 
/*    */           
/* 84 */           if (character > Character.MAX_VALUE) {
/* 85 */             writer.write('ퟀ' + (character >> '\n'));
/* 86 */             writer.write(0xDC00 | character & 0x3FF); break;
/*    */           } 
/* 88 */           writer.write(character);
/*    */           break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\encoding\UTF16Encoder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */