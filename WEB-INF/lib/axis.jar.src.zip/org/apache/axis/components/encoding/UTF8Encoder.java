/*    */ package org.apache.axis.components.encoding;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Writer;
/*    */ import org.apache.axis.i18n.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UTF8Encoder
/*    */   extends AbstractXMLEncoder
/*    */ {
/* 37 */   public String getEncoding() { return "UTF-8"; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeEncoded(Writer writer, String xmlString) throws IOException {
/* 48 */     if (xmlString == null) {
/*    */       return;
/*    */     }
/* 51 */     int length = xmlString.length();
/*    */     
/* 53 */     for (int i = 0; i < length; i++) {
/* 54 */       char character = xmlString.charAt(i);
/* 55 */       switch (character) {
/*    */ 
/*    */         
/*    */         case '&':
/* 59 */           writer.write("&amp;");
/*    */           break;
/*    */         case '"':
/* 62 */           writer.write("&quot;");
/*    */           break;
/*    */         case '<':
/* 65 */           writer.write("&lt;");
/*    */           break;
/*    */         case '>':
/* 68 */           writer.write("&gt;");
/*    */           break;
/*    */         case '\n':
/* 71 */           writer.write("\n");
/*    */           break;
/*    */         case '\r':
/* 74 */           writer.write("\r");
/*    */           break;
/*    */         case '\t':
/* 77 */           writer.write("\t");
/*    */           break;
/*    */         default:
/* 80 */           if (character < ' ') {
/* 81 */             throw new IllegalArgumentException(Messages.getMessage("invalidXmlCharacter00", Integer.toHexString(character), xmlString.substring(0, i)));
/*    */           }
/*    */ 
/*    */           
/* 85 */           if (character > '') {
/* 86 */             writer.write("&#x");
/* 87 */             writer.write(Integer.toHexString(character).toUpperCase());
/* 88 */             writer.write(";"); break;
/*    */           } 
/* 90 */           writer.write(character);
/*    */           break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\encoding\UTF8Encoder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */