package org.apache.axis.components.encoding;

import java.io.IOException;
import java.io.Writer;

public interface XMLEncoder {
  String getEncoding();
  
  String encode(String paramString);
  
  void writeEncoded(Writer paramWriter, String paramString) throws IOException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\encoding\XMLEncoder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */