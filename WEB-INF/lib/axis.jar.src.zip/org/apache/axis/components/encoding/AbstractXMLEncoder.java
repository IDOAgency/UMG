package org.apache.axis.components.encoding;

import org.apache.axis.utils.Messages;

public abstract class AbstractXMLEncoder implements XMLEncoder {
  protected static final String AMP = "&amp;";
  
  protected static final String QUOTE = "&quot;";
  
  protected static final String LESS = "&lt;";
  
  protected static final String GREATER = "&gt;";
  
  protected static final String LF = "\n";
  
  protected static final String CR = "\r";
  
  protected static final String TAB = "\t";
  
  public abstract String getEncoding();
  
  public String encode(String xmlString) {
    if (xmlString == null)
      return ""; 
    char[] characters = xmlString.toCharArray();
    StringBuffer out = null;
    for (int i = 0; i < characters.length; i++) {
      char character = characters[i];
      switch (character) {
        case '&':
          if (out == null)
            out = getInitialByteArray(xmlString, i); 
          out.append("&amp;");
          break;
        case '"':
          if (out == null)
            out = getInitialByteArray(xmlString, i); 
          out.append("&quot;");
          break;
        case '<':
          if (out == null)
            out = getInitialByteArray(xmlString, i); 
          out.append("&lt;");
          break;
        case '>':
          if (out == null)
            out = getInitialByteArray(xmlString, i); 
          out.append("&gt;");
          break;
        case '\n':
          if (out == null)
            out = getInitialByteArray(xmlString, i); 
          out.append("\n");
          break;
        case '\r':
          if (out == null)
            out = getInitialByteArray(xmlString, i); 
          out.append("\r");
          break;
        case '\t':
          if (out == null)
            out = getInitialByteArray(xmlString, i); 
          out.append("\t");
          break;
        default:
          if (character < ' ')
            throw new IllegalArgumentException(Messages.getMessage("invalidXmlCharacter00", Integer.toHexString(character), xmlString.substring(0, i))); 
          if (out != null)
            out.append(character); 
          break;
      } 
    } 
    if (out == null)
      return xmlString; 
    return out.toString();
  }
  
  protected StringBuffer getInitialByteArray(String aXmlString, int pos) { return new StringBuffer(aXmlString.substring(0, pos)); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\encoding\AbstractXMLEncoder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */