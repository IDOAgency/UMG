/*    */ package org.apache.axis.components.script;
/*    */ 
/*    */ import org.apache.axis.AxisProperties;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptFactory
/*    */ {
/* 29 */   protected static Log log = LogFactory.getLog(ScriptFactory.class.getName());
/*    */ 
/*    */   
/*    */   static  {
/* 33 */     AxisProperties.setClassOverrideProperty(Script.class, "axis.Script");
/*    */     
/* 35 */     AxisProperties.setClassDefaults(Script.class, new String[] { "org.apache.axis.components.script.BSF" });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Script getScript() {
/* 45 */     script = (Script)AxisProperties.newInstance(Script.class);
/* 46 */     log.debug("axis.Script: " + script.getClass().getName());
/* 47 */     return script;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\script\ScriptFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */