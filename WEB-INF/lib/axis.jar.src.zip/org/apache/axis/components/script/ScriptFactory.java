package org.apache.axis.components.script;

import org.apache.axis.AxisProperties;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class ScriptFactory {
  protected static Log log = LogFactory.getLog(ScriptFactory.class.getName());
  
  static  {
    AxisProperties.setClassOverrideProperty(Script.class, "axis.Script");
    AxisProperties.setClassDefaults(Script.class, new String[] { "org.apache.axis.components.script.BSF" });
  }
  
  public static Script getScript() {
    script = (Script)AxisProperties.newInstance(Script.class);
    log.debug("axis.Script: " + script.getClass().getName());
    return script;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\script\ScriptFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */