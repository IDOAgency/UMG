package org.apache.axis.components.script;

import org.apache.bsf.BSFEngine;
import org.apache.bsf.BSFManager;

public class BSF implements Script {
  public Object run(String language, String name, String scriptStr, String methodName, Object[] argValues) throws Exception {
    BSFManager manager = new BSFManager();
    BSFEngine engine = manager.loadScriptingEngine(language);
    manager.exec(language, "service script for '" + name + "'", 0, 0, scriptStr);
    return engine.call(null, methodName, argValues);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\script\BSF.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */