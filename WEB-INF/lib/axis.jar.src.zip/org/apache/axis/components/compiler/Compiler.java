package org.apache.axis.components.compiler;

import java.io.IOException;
import java.util.List;

public interface Compiler {
  void addFile(String paramString);
  
  void setSource(String paramString);
  
  void setDestination(String paramString);
  
  void setClasspath(String paramString);
  
  void setEncoding(String paramString);
  
  boolean compile() throws IOException;
  
  List getErrors() throws IOException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\compiler\Compiler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */