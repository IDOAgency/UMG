package org.apache.axis.components.compiler;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class Javac extends AbstractCompiler {
  protected static Log log = LogFactory.getLog(Javac.class.getName());
  
  public static final String CLASSIC_CLASS = "sun.tools.javac.Main";
  
  public static final String MODERN_CLASS = "com.sun.tools.javac.main.Main";
  
  private boolean modern = false;
  
  static Class array$Ljava$lang$String;
  
  public Javac() {
    ClassLoader cl = getClassLoader();
    try {
      ClassUtils.forName("com.sun.tools.javac.main.Main", true, cl);
      this.modern = true;
    } catch (ClassNotFoundException e) {
      log.debug(Messages.getMessage("noModernCompiler"));
      try {
        ClassUtils.forName("sun.tools.javac.Main", true, cl);
        this.modern = false;
      } catch (Exception ex) {
        log.error(Messages.getMessage("noCompiler00"), ex);
        throw new RuntimeException(Messages.getMessage("noCompiler00"));
      } 
    } 
    log.debug(Messages.getMessage("compilerClass", this.modern ? "com.sun.tools.javac.main.Main" : "sun.tools.javac.Main"));
  }
  
  private ClassLoader getClassLoader() {
    ClassLoader cl = Thread.currentThread().getContextClassLoader();
    URL toolsURL = null;
    String tools = System.getProperty("java.home");
    if (tools != null) {
      File f = new File(tools + "/../lib/tools.jar");
      if (f.exists())
        try {
          toolsURL = f.toURL();
          cl = new URLClassLoader(new URL[] { toolsURL }, cl);
        } catch (MalformedURLException e) {} 
    } 
    return cl;
  }
  
  public boolean compile() throws IOException {
    ByteArrayOutputStream err = new ByteArrayOutputStream();
    boolean result = false;
    try {
      Object compiler;
      Class c = ClassUtils.forName(this.modern ? "com.sun.tools.javac.main.Main" : "sun.tools.javac.Main", true, getClassLoader());
      if (this.modern) {
        PrintWriter pw = new PrintWriter(new OutputStreamWriter(err));
        Constructor cons = c.getConstructor(new Class[] { String.class, PrintWriter.class });
        compiler = cons.newInstance(new Object[] { "javac", pw });
      } else {
        Constructor cons = c.getConstructor(new Class[] { java.io.OutputStream.class, String.class });
        compiler = cons.newInstance(new Object[] { err, "javac" });
      } 
      Method compile = c.getMethod("compile", new Class[] { (array$Ljava$lang$String == null) ? (array$Ljava$lang$String = class$("[Ljava.lang.String;")) : array$Ljava$lang$String });
      if (this.modern) {
        int compilationResult = ((Integer)compile.invoke(compiler, new Object[] { toStringArray(fillArguments(new ArrayList())) })).intValue();
        result = (compilationResult == 0);
        log.debug("Compilation Returned: " + Integer.toString(compilationResult));
      } else {
        Boolean ok = (Boolean)compile.invoke(compiler, new Object[] { toStringArray(fillArguments(new ArrayList())) });
        result = ok.booleanValue();
      } 
    } catch (Exception cnfe) {
      log.error(Messages.getMessage("noCompiler00"), cnfe);
      throw new RuntimeException(Messages.getMessage("noCompiler00"));
    } 
    this.errors = new ByteArrayInputStream(err.toByteArray());
    return result;
  }
  
  protected List parseStream(BufferedReader input) throws IOException {
    if (this.modern)
      return parseModernStream(input); 
    return parseClassicStream(input);
  }
  
  protected List parseModernStream(BufferedReader input) throws IOException {
    List errors = new ArrayList();
    String line = null;
    StringBuffer buffer = null;
    while (true) {
      buffer = new StringBuffer();
      do {
        if ((line = input.readLine()) == null) {
          if (buffer.length() > 0)
            errors.add(new CompilerError("\n" + buffer.toString())); 
          return errors;
        } 
        log.debug(line);
        buffer.append(line);
        buffer.append('\n');
      } while (!line.endsWith("^"));
      errors.add(parseModernError(buffer.toString()));
    } 
  }
  
  private CompilerError parseModernError(String error) {
    StringTokenizer tokens = new StringTokenizer(error, ":");
    try {
      String file = tokens.nextToken();
      if (file.length() == 1)
        file = file + ":" + tokens.nextToken(); 
      int line = Integer.parseInt(tokens.nextToken());
      String message = tokens.nextToken("\n").substring(1);
      String context = tokens.nextToken("\n");
      String pointer = tokens.nextToken("\n");
      int startcolumn = pointer.indexOf("^");
      int endcolumn = context.indexOf(" ", startcolumn);
      if (endcolumn == -1)
        endcolumn = context.length(); 
      return new CompilerError(file, false, line, startcolumn, line, endcolumn, message);
    } catch (NoSuchElementException nse) {
      return new CompilerError(Messages.getMessage("noMoreTokens", error));
    } catch (Exception nse) {
      return new CompilerError(Messages.getMessage("cantParse", error));
    } 
  }
  
  protected List parseClassicStream(BufferedReader input) throws IOException {
    List errors = null;
    String line = null;
    StringBuffer buffer = null;
    while (true) {
      buffer = new StringBuffer();
      for (int i = 0; i < 3; i++) {
        if ((line = input.readLine()) == null)
          return errors; 
        log.debug(line);
        buffer.append(line);
        buffer.append('\n');
      } 
      if (errors == null)
        errors = new ArrayList(); 
      errors.add(parseClassicError(buffer.toString()));
    } 
  }
  
  private CompilerError parseClassicError(String error) {
    StringTokenizer tokens = new StringTokenizer(error, ":");
    try {
      String file = tokens.nextToken();
      if (file.length() == 1)
        file = file + ":" + tokens.nextToken(); 
      int line = Integer.parseInt(tokens.nextToken());
      String last = tokens.nextToken();
      while (tokens.hasMoreElements())
        last = last + tokens.nextToken(); 
      tokens = new StringTokenizer(last.trim(), "\n");
      String message = tokens.nextToken();
      String context = tokens.nextToken();
      String pointer = tokens.nextToken();
      int startcolumn = pointer.indexOf("^");
      int endcolumn = context.indexOf(" ", startcolumn);
      if (endcolumn == -1)
        endcolumn = context.length(); 
      return new CompilerError(this.srcDir + File.separator + file, true, line, startcolumn, line, endcolumn, message);
    } catch (NoSuchElementException nse) {
      return new CompilerError(Messages.getMessage("noMoreTokens", error));
    } catch (Exception nse) {
      return new CompilerError(Messages.getMessage("cantParse", error));
    } 
  }
  
  public String toString() { return Messages.getMessage("sunJavac"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\compiler\Javac.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */