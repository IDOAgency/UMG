/*     */ package org.apache.axis.components.compiler;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCompiler
/*     */   implements Compiler
/*     */ {
/*  37 */   protected ArrayList fileList = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String srcDir;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String destDir;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String classpath;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   protected String encoding = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream errors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public void addFile(String file) { this.fileList.add(file); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public void setSource(String srcDir) { this.srcDir = srcDir; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public void setDestination(String destDir) { this.destDir = destDir; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public void setClasspath(String classpath) { this.classpath = classpath; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void setEncoding(String encoding) { this.encoding = encoding; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   public List getErrors() throws IOException { return parseStream(new BufferedReader(new InputStreamReader(this.errors))); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract List parseStream(BufferedReader paramBufferedReader) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List fillArguments(List arguments) {
/* 142 */     arguments.add("-d");
/* 143 */     arguments.add(this.destDir);
/*     */ 
/*     */     
/* 146 */     arguments.add("-classpath");
/* 147 */     arguments.add(this.classpath);
/*     */ 
/*     */     
/* 150 */     if (this.srcDir != null) {
/* 151 */       arguments.add("-sourcepath");
/* 152 */       arguments.add(this.srcDir);
/*     */     } 
/*     */ 
/*     */     
/* 156 */     arguments.add("-O");
/*     */ 
/*     */     
/* 159 */     arguments.add("-g");
/*     */ 
/*     */     
/* 162 */     if (this.encoding != null) {
/* 163 */       arguments.add("-encoding");
/* 164 */       arguments.add(this.encoding);
/*     */     } 
/*     */     
/* 167 */     return arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] toStringArray(List arguments) {
/* 178 */     String[] args = new String[arguments.size() + this.fileList.size()];
/*     */     int i;
/* 180 */     for (i = 0; i < arguments.size(); i++) {
/* 181 */       args[i] = (String)arguments.get(i);
/*     */     }
/*     */     
/* 184 */     for (int j = 0; j < this.fileList.size(); i++, j++) {
/* 185 */       args[i] = (String)this.fileList.get(j);
/*     */     }
/* 187 */     return args;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\compiler\AbstractCompiler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */