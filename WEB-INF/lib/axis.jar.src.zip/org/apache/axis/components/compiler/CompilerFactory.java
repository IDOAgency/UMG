package org.apache.axis.components.compiler;

import org.apache.axis.AxisProperties;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class CompilerFactory {
  protected static Log log = LogFactory.getLog(CompilerFactory.class.getName());
  
  static  {
    AxisProperties.setClassOverrideProperty(Compiler.class, "axis.Compiler");
    AxisProperties.setClassDefault(Compiler.class, "org.apache.axis.components.compiler.Javac");
  }
  
  public static Compiler getCompiler() {
    compiler = (Compiler)AxisProperties.newInstance(Compiler.class);
    if (compiler == null) {
      log.debug(Messages.getMessage("defaultCompiler"));
      compiler = new Javac();
    } 
    log.debug("axis.Compiler:" + compiler.getClass().getName());
    return compiler;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\compiler\CompilerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */