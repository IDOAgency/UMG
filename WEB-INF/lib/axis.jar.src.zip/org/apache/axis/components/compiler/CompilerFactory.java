/*    */ package org.apache.axis.components.compiler;
/*    */ 
/*    */ import org.apache.axis.AxisProperties;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.axis.utils.Messages;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompilerFactory
/*    */ {
/* 32 */   protected static Log log = LogFactory.getLog(CompilerFactory.class.getName());
/*    */ 
/*    */   
/*    */   static  {
/* 36 */     AxisProperties.setClassOverrideProperty(Compiler.class, "axis.Compiler");
/*    */     
/* 38 */     AxisProperties.setClassDefault(Compiler.class, "org.apache.axis.components.compiler.Javac");
/*    */   }
/*    */ 
/*    */   
/*    */   public static Compiler getCompiler() {
/* 43 */     compiler = (Compiler)AxisProperties.newInstance(Compiler.class);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 48 */     if (compiler == null) {
/* 49 */       log.debug(Messages.getMessage("defaultCompiler"));
/* 50 */       compiler = new Javac();
/*    */     } 
/*    */     
/* 53 */     log.debug("axis.Compiler:" + compiler.getClass().getName());
/*    */     
/* 55 */     return compiler;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\compiler\CompilerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */