package org.apache.axis.components.compiler;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class Jikes extends AbstractCompiler {
  protected static Log log = LogFactory.getLog(Jikes.class.getName());
  
  static final int OUTPUT_BUFFER_SIZE = 1024;
  
  static final int BUFFER_SIZE = 512;
  
  private class StreamPumper extends Thread {
    private BufferedInputStream stream;
    
    private boolean endOfStream;
    
    private boolean stopSignal;
    
    private int SLEEP_TIME;
    
    private OutputStream out;
    
    private final Jikes this$0;
    
    public StreamPumper(Jikes this$0, BufferedInputStream is, OutputStream out) {
      this.this$0 = this$0;
      this.endOfStream = false;
      this.stopSignal = false;
      this.SLEEP_TIME = 5;
      this.stream = is;
      this.out = out;
    }
    
    public void pumpStream() {
      byte[] buf = new byte[512];
      if (!this.endOfStream) {
        int bytesRead = this.stream.read(buf, 0, 512);
        if (bytesRead > 0) {
          this.out.write(buf, 0, bytesRead);
        } else if (bytesRead == -1) {
          this.endOfStream = true;
        } 
      } 
    }
    
    public void run() {
      try {
        while (!this.endOfStream) {
          pumpStream();
          sleep(this.SLEEP_TIME);
        } 
      } catch (Exception e) {}
    }
  }
  
  protected String[] toStringArray(List arguments) {
    int i;
    for (i = 0; i < arguments.size(); i++) {
      String arg = (String)arguments.get(i);
      if (arg.equals("-sourcepath")) {
        arguments.remove(i);
        arguments.remove(i);
        break;
      } 
    } 
    String[] args = new String[arguments.size() + this.fileList.size()];
    for (i = 0; i < arguments.size(); i++)
      args[i] = (String)arguments.get(i); 
    for (int j = 0; j < this.fileList.size(); i++, j++)
      args[i] = (String)this.fileList.get(j); 
    return args;
  }
  
  public boolean compile() throws IOException {
    int exitValue;
    List args = new ArrayList();
    args.add("jikes");
    args.add("+E");
    args.add("-nowarn");
    ByteArrayOutputStream tmpErr = new ByteArrayOutputStream(1024);
    try {
      Process p = Runtime.getRuntime().exec(toStringArray(fillArguments(args)));
      BufferedInputStream compilerErr = new BufferedInputStream(p.getErrorStream());
      StreamPumper errPumper = new StreamPumper(this, compilerErr, tmpErr);
      errPumper.start();
      p.waitFor();
      exitValue = p.exitValue();
      errPumper.join();
      compilerErr.close();
      p.destroy();
      tmpErr.close();
      this.errors = new ByteArrayInputStream(tmpErr.toByteArray());
    } catch (InterruptedException somethingHappened) {
      log.debug("Jikes.compile():SomethingHappened", somethingHappened);
      return false;
    } 
    return (exitValue == 0 && tmpErr.size() == 0);
  }
  
  protected List parseStream(BufferedReader input) throws IOException {
    List errors = null;
    String line = null;
    StringBuffer buffer = null;
    while (true) {
      buffer = new StringBuffer();
      if (line == null)
        line = input.readLine(); 
      if (line == null)
        return errors; 
      log.debug(line);
      buffer.append(line);
      while (true) {
        line = input.readLine();
        if (line == null)
          break; 
        if (line.length() > 0 && line.charAt(0) != ' ')
          break; 
        log.debug(line);
        buffer.append('\n');
        buffer.append(line);
      } 
      if (errors == null)
        errors = new ArrayList(); 
      errors.add(parseError(buffer.toString()));
    } 
  }
  
  private CompilerError parseError(String error) {
    StringTokenizer tokens = new StringTokenizer(error, ":");
    String file = tokens.nextToken();
    if (file.length() == 1)
      file = file + ":" + tokens.nextToken(); 
    StringBuffer message = new StringBuffer();
    String type = "";
    int startline = 0;
    int startcolumn = 0;
    int endline = 0;
    int endcolumn = 0;
    try {
      startline = Integer.parseInt(tokens.nextToken());
      startcolumn = Integer.parseInt(tokens.nextToken());
      endline = Integer.parseInt(tokens.nextToken());
      endcolumn = Integer.parseInt(tokens.nextToken());
    } catch (Exception e) {
      message.append(Messages.getMessage("compilerFail00"));
      type = "error";
      log.error(Messages.getMessage("compilerFail00"), e);
    } 
    if ("".equals(message)) {
      type = tokens.nextToken().trim().toLowerCase();
      message.append(tokens.nextToken("\n").substring(1).trim());
      while (tokens.hasMoreTokens())
        message.append("\n").append(tokens.nextToken()); 
    } 
    return new CompilerError(file, type.equals("error"), startline, startcolumn, endline, endcolumn, message.toString());
  }
  
  public String toString() { return Messages.getMessage("ibmJikes"); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\compiler\Jikes.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */