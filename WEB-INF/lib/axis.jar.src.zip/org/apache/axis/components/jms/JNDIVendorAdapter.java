package org.apache.axis.components.jms;

import java.util.HashMap;
import java.util.Hashtable;
import javax.jms.ConnectionFactory;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Topic;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.apache.axis.transport.jms.JMSURLHelper;

public class JNDIVendorAdapter extends JMSVendorAdapter {
  public static final String CONTEXT_FACTORY = "java.naming.factory.initial";
  
  public static final String PROVIDER_URL = "java.naming.provider.url";
  
  public static final String _CONNECTION_FACTORY_JNDI_NAME = "ConnectionFactoryJNDIName";
  
  public static final String CONNECTION_FACTORY_JNDI_NAME = "transport.jms.ConnectionFactoryJNDIName";
  
  private Context context;
  
  public QueueConnectionFactory getQueueConnectionFactory(HashMap cfConfig) throws Exception { return (QueueConnectionFactory)getConnectionFactory(cfConfig); }
  
  public TopicConnectionFactory getTopicConnectionFactory(HashMap cfConfig) throws Exception { return (TopicConnectionFactory)getConnectionFactory(cfConfig); }
  
  private ConnectionFactory getConnectionFactory(HashMap cfProps) throws Exception {
    if (cfProps == null)
      throw new IllegalArgumentException("noCFProps"); 
    String jndiName = (String)cfProps.get("transport.jms.ConnectionFactoryJNDIName");
    if (jndiName == null || jndiName.trim().length() == 0)
      throw new IllegalArgumentException("noCFName"); 
    Hashtable environment = new Hashtable(cfProps);
    String ctxFactory = (String)cfProps.get("java.naming.factory.initial");
    if (ctxFactory != null)
      environment.put("java.naming.factory.initial", ctxFactory); 
    String providerURL = (String)cfProps.get("java.naming.provider.url");
    if (providerURL != null)
      environment.put("java.naming.provider.url", providerURL); 
    this.context = new InitialContext(environment);
    return (ConnectionFactory)this.context.lookup(jndiName);
  }
  
  public void addVendorConnectionFactoryProperties(JMSURLHelper jmsurl, HashMap cfConfig) {
    String cfJNDIName = jmsurl.getPropertyValue("ConnectionFactoryJNDIName");
    if (cfJNDIName != null)
      cfConfig.put("transport.jms.ConnectionFactoryJNDIName", cfJNDIName); 
    String ctxFactory = jmsurl.getPropertyValue("java.naming.factory.initial");
    if (ctxFactory != null)
      cfConfig.put("java.naming.factory.initial", ctxFactory); 
    String providerURL = jmsurl.getPropertyValue("java.naming.provider.url");
    if (providerURL != null)
      cfConfig.put("java.naming.provider.url", providerURL); 
  }
  
  public boolean isMatchingConnectionFactory(ConnectionFactory cf, JMSURLHelper originalJMSURL, HashMap cfProps) {
    JMSURLHelper jmsurl = (JMSURLHelper)cfProps.get("transport.jms.EndpointAddress");
    String cfJndiName = jmsurl.getPropertyValue("ConnectionFactoryJNDIName");
    String originalCfJndiName = originalJMSURL.getPropertyValue("ConnectionFactoryJNDIName");
    if (cfJndiName.equalsIgnoreCase(originalCfJndiName))
      return true; 
    return false;
  }
  
  public Queue getQueue(QueueSession session, String name) throws Exception { return (Queue)this.context.lookup(name); }
  
  public Topic getTopic(TopicSession session, String name) throws Exception { return (Topic)this.context.lookup(name); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\jms\JNDIVendorAdapter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */