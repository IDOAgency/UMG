package org.apache.axis.components.jms;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Topic;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import org.apache.axis.MessageContext;
import org.apache.axis.client.Call;
import org.apache.axis.transport.jms.JMSURLHelper;

public abstract class JMSVendorAdapter {
  public static final int SEND_ACTION = 0;
  
  public static final int CONNECT_ACTION = 1;
  
  public static final int SUBSCRIBE_ACTION = 2;
  
  public static final int RECEIVE_ACTION = 3;
  
  public static final int ON_EXCEPTION_ACTION = 4;
  
  public abstract QueueConnectionFactory getQueueConnectionFactory(HashMap paramHashMap) throws Exception;
  
  public abstract TopicConnectionFactory getTopicConnectionFactory(HashMap paramHashMap) throws Exception;
  
  public abstract void addVendorConnectionFactoryProperties(JMSURLHelper paramJMSURLHelper, HashMap paramHashMap);
  
  public abstract boolean isMatchingConnectionFactory(ConnectionFactory paramConnectionFactory, JMSURLHelper paramJMSURLHelper, HashMap paramHashMap);
  
  public String getVendorId() {
    String name = getClass().getName();
    if (name.endsWith("VendorAdapter")) {
      int index = name.lastIndexOf("VendorAdapter");
      name = name.substring(0, index);
    } 
    int index = name.lastIndexOf(".");
    if (index > 0)
      name = name.substring(index + 1); 
    return name;
  }
  
  public HashMap getJMSConnectorProperties(JMSURLHelper jmsurl) {
    HashMap connectorProps = new HashMap();
    connectorProps.put("transport.jms.EndpointAddress", jmsurl);
    String clientID = jmsurl.getPropertyValue("clientID");
    if (clientID != null)
      connectorProps.put("transport.jms.clientID", clientID); 
    String connectRetryInterval = jmsurl.getPropertyValue("connectRetryInterval");
    if (connectRetryInterval != null)
      connectorProps.put("transport.jms.connectRetryInterval", connectRetryInterval); 
    String interactRetryInterval = jmsurl.getPropertyValue("interactRetryInterval");
    if (interactRetryInterval != null)
      connectorProps.put("transport.jms.interactRetryInterval", interactRetryInterval); 
    String domain = jmsurl.getPropertyValue("domain");
    if (domain != null)
      connectorProps.put("transport.jms.domain", domain); 
    String numRetries = jmsurl.getPropertyValue("numRetries");
    if (numRetries != null)
      connectorProps.put("transport.jms.numRetries", numRetries); 
    String numSessions = jmsurl.getPropertyValue("numSessions");
    if (numSessions != null)
      connectorProps.put("transport.jms.numSessions", numSessions); 
    String timeoutTime = jmsurl.getPropertyValue("timeoutTime");
    if (timeoutTime != null)
      connectorProps.put("transport.jms.timeoutTime", timeoutTime); 
    return connectorProps;
  }
  
  public HashMap getJMSConnectionFactoryProperties(JMSURLHelper jmsurl) {
    HashMap cfProps = new HashMap();
    cfProps.put("transport.jms.EndpointAddress", jmsurl);
    String domain = jmsurl.getPropertyValue("domain");
    if (domain != null)
      cfProps.put("transport.jms.domain", domain); 
    addVendorConnectionFactoryProperties(jmsurl, cfProps);
    return cfProps;
  }
  
  public Queue getQueue(QueueSession session, String name) throws Exception { return session.createQueue(name); }
  
  public Topic getTopic(TopicSession session, String name) throws Exception { return session.createTopic(name); }
  
  public boolean isRecoverable(Throwable thrown, int action) {
    if (thrown instanceof RuntimeException || thrown instanceof Error || thrown instanceof javax.jms.JMSSecurityException || thrown instanceof javax.jms.InvalidDestinationException)
      return false; 
    if (action == 4)
      return false; 
    return true;
  }
  
  public void setProperties(Message message, HashMap props) throws JMSException {
    Iterator iter = props.keySet().iterator();
    while (iter.hasNext()) {
      String key = (String)iter.next();
      String value = (String)props.get(key);
      message.setStringProperty(key, value);
    } 
  }
  
  public void setupMessageContext(MessageContext context, Call call, JMSURLHelper jmsurl) {
    Object tmp = null;
    String jmsurlDestination = null;
    if (jmsurl != null)
      jmsurlDestination = jmsurl.getDestination(); 
    if (jmsurlDestination != null) {
      context.setProperty("transport.jms.Destination", jmsurlDestination);
    } else {
      tmp = call.getProperty("transport.jms.Destination");
      if (tmp != null && tmp instanceof String) {
        context.setProperty("transport.jms.Destination", tmp);
      } else {
        context.removeProperty("transport.jms.Destination");
      } 
    } 
    String delivMode = null;
    if (jmsurl != null)
      delivMode = jmsurl.getPropertyValue("deliveryMode"); 
    if (delivMode != null) {
      int mode = 1;
      if (delivMode.equalsIgnoreCase("Persistent")) {
        mode = 2;
      } else if (delivMode.equalsIgnoreCase("Nonpersistent")) {
        mode = 1;
      } 
      context.setProperty("transport.jms.deliveryMode", new Integer(mode));
    } else {
      tmp = call.getProperty("transport.jms.deliveryMode");
      if (tmp != null && tmp instanceof Integer) {
        context.setProperty("transport.jms.deliveryMode", tmp);
      } else {
        context.removeProperty("transport.jms.deliveryMode");
      } 
    } 
    String prio = null;
    if (jmsurl != null)
      prio = jmsurl.getPropertyValue("priority"); 
    if (prio != null) {
      context.setProperty("transport.jms.priority", Integer.valueOf(prio));
    } else {
      tmp = call.getProperty("transport.jms.priority");
      if (tmp != null && tmp instanceof Integer) {
        context.setProperty("transport.jms.priority", tmp);
      } else {
        context.removeProperty("transport.jms.priority");
      } 
    } 
    String ttl = null;
    if (jmsurl != null)
      ttl = jmsurl.getPropertyValue("ttl"); 
    if (ttl != null) {
      context.setProperty("transport.jms.ttl", Long.valueOf(ttl));
    } else {
      tmp = call.getProperty("transport.jms.ttl");
      if (tmp != null && tmp instanceof Long) {
        context.setProperty("transport.jms.ttl", tmp);
      } else {
        context.removeProperty("transport.jms.ttl");
      } 
    } 
    String wait = null;
    if (jmsurl != null)
      wait = jmsurl.getPropertyValue("waitForResponse"); 
    if (wait != null) {
      context.setProperty("transport.jms.waitForResponse", Boolean.valueOf(wait));
    } else {
      tmp = call.getProperty("transport.jms.waitForResponse");
      if (tmp != null && tmp instanceof Boolean) {
        context.setProperty("transport.jms.waitForResponse", tmp);
      } else {
        context.removeProperty("transport.jms.waitForResponse");
      } 
    } 
    setupApplicationProperties(context, call, jmsurl);
  }
  
  public void setupApplicationProperties(MessageContext context, Call call, JMSURLHelper jmsurl) {
    Map appProps = new HashMap();
    if (jmsurl != null && jmsurl.getApplicationProperties() != null) {
      Iterator itr = jmsurl.getApplicationProperties().iterator();
      while (itr.hasNext()) {
        String name = (String)itr.next();
        appProps.put(name, jmsurl.getPropertyValue(name));
      } 
    } 
    Map ctxProps = (Map)context.getProperty("transport.jms.msgProps");
    if (ctxProps != null)
      appProps.putAll(ctxProps); 
    Map callProps = (Map)call.getProperty("transport.jms.msgProps");
    if (callProps != null)
      appProps.putAll(callProps); 
    context.setProperty("transport.jms.msgProps", appProps);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\jms\JMSVendorAdapter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */