package org.apache.axis.components.net;

public interface CommonsHTTPClientProperties {
  int getMaximumTotalConnections();
  
  int getMaximumConnectionsPerHost();
  
  int getConnectionPoolTimeout();
  
  int getDefaultConnectionTimeout();
  
  int getDefaultSoTimeout();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\CommonsHTTPClientProperties.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */