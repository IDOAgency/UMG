package org.apache.axis.components.net;

import java.net.Socket;

public interface SocketFactory {
  Socket create(String paramString, int paramInt, StringBuffer paramStringBuffer, BooleanHolder paramBooleanHolder) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\SocketFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */