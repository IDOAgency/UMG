/*     */ package org.apache.axis.components.net;
/*     */ 
/*     */ import com.sun.net.ssl.SSLContext;
/*     */ import com.sun.net.ssl.TrustManager;
/*     */ import com.sun.net.ssl.X509TrustManager;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SunFakeTrustSocketFactory
/*     */   extends SunJSSESocketFactory
/*     */ {
/*  34 */   protected static Log log = LogFactory.getLog(SunFakeTrustSocketFactory.class.getName());
/*     */ 
/*     */ 
/*     */   
/*     */   static Class class$org$apache$axis$components$net$SunFakeTrustSocketFactory$FakeX509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   public SunFakeTrustSocketFactory(Hashtable attributes) { super(attributes); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SSLContext getContext() throws Exception {
/*     */     try {
/*  56 */       SSLContext sc = SSLContext.getInstance("SSL");
/*     */       
/*  58 */       sc.init(null, new TrustManager[] { new FakeX509TrustManager() }, new SecureRandom());
/*     */ 
/*     */       
/*  61 */       if (log.isDebugEnabled()) {
/*  62 */         log.debug(Messages.getMessage("ftsf00"));
/*     */       }
/*  64 */       return sc;
/*  65 */     } catch (Exception exc) {
/*  66 */       log.error(Messages.getMessage("ftsf01"), exc);
/*  67 */       throw new Exception(Messages.getMessage("ftsf02"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FakeX509TrustManager
/*     */     implements X509TrustManager
/*     */   {
/*  77 */     protected static Log log = LogFactory.getLog(((SunFakeTrustSocketFactory.class$org$apache$axis$components$net$SunFakeTrustSocketFactory$FakeX509TrustManager == null) ? (SunFakeTrustSocketFactory.class$org$apache$axis$components$net$SunFakeTrustSocketFactory$FakeX509TrustManager = SunFakeTrustSocketFactory.class$("org.apache.axis.components.net.SunFakeTrustSocketFactory$FakeX509TrustManager")) : SunFakeTrustSocketFactory.class$org$apache$axis$components$net$SunFakeTrustSocketFactory$FakeX509TrustManager).getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isClientTrusted(X509Certificate[] chain) {
/*  90 */       if (log.isDebugEnabled()) {
/*  91 */         log.debug(Messages.getMessage("ftsf03"));
/*     */       }
/*  93 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isServerTrusted(X509Certificate[] chain) {
/* 106 */       if (log.isDebugEnabled()) {
/* 107 */         log.debug(Messages.getMessage("ftsf04"));
/*     */       }
/* 109 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public X509Certificate[] getAcceptedIssuers() {
/* 119 */       if (log.isDebugEnabled()) {
/* 120 */         log.debug(Messages.getMessage("ftsf05"));
/*     */       }
/* 122 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\SunFakeTrustSocketFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */