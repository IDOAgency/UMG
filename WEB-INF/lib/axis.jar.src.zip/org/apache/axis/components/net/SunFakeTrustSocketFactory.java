package org.apache.axis.components.net;

import com.sun.net.ssl.SSLContext;
import com.sun.net.ssl.TrustManager;
import com.sun.net.ssl.X509TrustManager;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Hashtable;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class SunFakeTrustSocketFactory extends SunJSSESocketFactory {
  protected static Log log = LogFactory.getLog(SunFakeTrustSocketFactory.class.getName());
  
  static Class class$org$apache$axis$components$net$SunFakeTrustSocketFactory$FakeX509TrustManager;
  
  public SunFakeTrustSocketFactory(Hashtable attributes) { super(attributes); }
  
  protected SSLContext getContext() throws Exception {
    try {
      SSLContext sc = SSLContext.getInstance("SSL");
      sc.init(null, new TrustManager[] { new FakeX509TrustManager() }, new SecureRandom());
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("ftsf00")); 
      return sc;
    } catch (Exception exc) {
      log.error(Messages.getMessage("ftsf01"), exc);
      throw new Exception(Messages.getMessage("ftsf02"));
    } 
  }
  
  public static class FakeX509TrustManager implements X509TrustManager {
    protected static Log log = LogFactory.getLog(((SunFakeTrustSocketFactory.class$org$apache$axis$components$net$SunFakeTrustSocketFactory$FakeX509TrustManager == null) ? (SunFakeTrustSocketFactory.class$org$apache$axis$components$net$SunFakeTrustSocketFactory$FakeX509TrustManager = SunFakeTrustSocketFactory.class$("org.apache.axis.components.net.SunFakeTrustSocketFactory$FakeX509TrustManager")) : SunFakeTrustSocketFactory.class$org$apache$axis$components$net$SunFakeTrustSocketFactory$FakeX509TrustManager).getName());
    
    public boolean isClientTrusted(X509Certificate[] chain) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("ftsf03")); 
      return true;
    }
    
    public boolean isServerTrusted(X509Certificate[] chain) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("ftsf04")); 
      return true;
    }
    
    public X509Certificate[] getAcceptedIssuers() {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("ftsf05")); 
      return null;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\SunFakeTrustSocketFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */