package org.apache.axis.components.net;

import org.apache.axis.AxisProperties;

public class DefaultHTTPSTransportClientProperties extends DefaultHTTPTransportClientProperties {
  public String getProxyHost() {
    if (this.proxyHost == null) {
      this.proxyHost = AxisProperties.getProperty("https.proxyHost");
      super.getProxyHost();
    } 
    return this.proxyHost;
  }
  
  public String getNonProxyHosts() {
    if (this.nonProxyHosts == null) {
      this.nonProxyHosts = AxisProperties.getProperty("https.nonProxyHosts");
      super.getNonProxyHosts();
    } 
    return this.nonProxyHosts;
  }
  
  public String getProxyPort() {
    if (this.proxyPort == null) {
      this.proxyPort = AxisProperties.getProperty("https.proxyPort");
      super.getProxyPort();
    } 
    return this.proxyPort;
  }
  
  public String getProxyUser() {
    if (this.proxyUser == null) {
      this.proxyUser = AxisProperties.getProperty("https.proxyUser");
      super.getProxyUser();
    } 
    return this.proxyUser;
  }
  
  public String getProxyPassword() {
    if (this.proxyPassword == null) {
      this.proxyPassword = AxisProperties.getProperty("https.proxyPassword");
      super.getProxyPassword();
    } 
    return this.proxyPassword;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\DefaultHTTPSTransportClientProperties.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */