package org.apache.axis.components.net;

import org.apache.axis.AxisProperties;

public class DefaultHTTPTransportClientProperties implements TransportClientProperties {
  private static final String emptyString = "";
  
  protected String proxyHost = null;
  
  protected String nonProxyHosts = null;
  
  protected String proxyPort = null;
  
  protected String proxyUser = null;
  
  protected String proxyPassword = null;
  
  public String getProxyHost() {
    if (this.proxyHost == null) {
      this.proxyHost = AxisProperties.getProperty("http.proxyHost");
      if (this.proxyHost == null)
        this.proxyHost = ""; 
    } 
    return this.proxyHost;
  }
  
  public String getNonProxyHosts() {
    if (this.nonProxyHosts == null) {
      this.nonProxyHosts = AxisProperties.getProperty("http.nonProxyHosts");
      if (this.nonProxyHosts == null)
        this.nonProxyHosts = ""; 
    } 
    return this.nonProxyHosts;
  }
  
  public String getProxyPort() {
    if (this.proxyPort == null) {
      this.proxyPort = AxisProperties.getProperty("http.proxyPort");
      if (this.proxyPort == null)
        this.proxyPort = ""; 
    } 
    return this.proxyPort;
  }
  
  public String getProxyUser() {
    if (this.proxyUser == null) {
      this.proxyUser = AxisProperties.getProperty("http.proxyUser");
      if (this.proxyUser == null)
        this.proxyUser = ""; 
    } 
    return this.proxyUser;
  }
  
  public String getProxyPassword() {
    if (this.proxyPassword == null) {
      this.proxyPassword = AxisProperties.getProperty("http.proxyPassword");
      if (this.proxyPassword == null)
        this.proxyPassword = ""; 
    } 
    return this.proxyPassword;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\DefaultHTTPTransportClientProperties.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */