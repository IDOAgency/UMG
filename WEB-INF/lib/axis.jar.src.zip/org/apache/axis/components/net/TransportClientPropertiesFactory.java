package org.apache.axis.components.net;

import java.util.HashMap;
import org.apache.axis.AxisProperties;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class TransportClientPropertiesFactory {
  protected static Log log = LogFactory.getLog(SocketFactoryFactory.class.getName());
  
  private static HashMap cache = new HashMap();
  
  private static HashMap defaults = new HashMap();
  
  static  {
    defaults.put("http", DefaultHTTPTransportClientProperties.class);
    defaults.put("https", DefaultHTTPSTransportClientProperties.class);
  }
  
  public static TransportClientProperties create(String protocol) {
    TransportClientProperties tcp = (TransportClientProperties)cache.get(protocol);
    if (tcp == null) {
      tcp = (TransportClientProperties)AxisProperties.newInstance(TransportClientProperties.class, (Class)defaults.get(protocol));
      if (tcp != null)
        cache.put(protocol, tcp); 
    } 
    return tcp;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\TransportClientPropertiesFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */