/*    */ package org.apache.axis.components.net;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import org.apache.axis.AxisProperties;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TransportClientPropertiesFactory
/*    */ {
/* 29 */   protected static Log log = LogFactory.getLog(SocketFactoryFactory.class.getName());
/*    */ 
/*    */   
/* 32 */   private static HashMap cache = new HashMap();
/* 33 */   private static HashMap defaults = new HashMap();
/*    */   
/*    */   static  {
/* 36 */     defaults.put("http", DefaultHTTPTransportClientProperties.class);
/* 37 */     defaults.put("https", DefaultHTTPSTransportClientProperties.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public static TransportClientProperties create(String protocol) {
/* 42 */     TransportClientProperties tcp = (TransportClientProperties)cache.get(protocol);
/*    */ 
/*    */     
/* 45 */     if (tcp == null) {
/* 46 */       tcp = (TransportClientProperties)AxisProperties.newInstance(TransportClientProperties.class, (Class)defaults.get(protocol));
/*    */ 
/*    */ 
/*    */       
/* 50 */       if (tcp != null) {
/* 51 */         cache.put(protocol, tcp);
/*    */       }
/*    */     } 
/*    */     
/* 55 */     return tcp;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\TransportClientPropertiesFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */