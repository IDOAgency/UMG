package org.apache.axis.components.net;

public class BooleanHolder {
  public boolean value;
  
  public BooleanHolder(boolean value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\BooleanHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */