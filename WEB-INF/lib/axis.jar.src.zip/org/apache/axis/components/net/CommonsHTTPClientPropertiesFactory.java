/*    */ package org.apache.axis.components.net;
/*    */ 
/*    */ import org.apache.axis.AxisProperties;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonsHTTPClientPropertiesFactory
/*    */ {
/* 26 */   protected static Log log = LogFactory.getLog(CommonsHTTPClientPropertiesFactory.class.getName());
/*    */   
/*    */   private static CommonsHTTPClientProperties properties;
/*    */ 
/*    */   
/*    */   public static CommonsHTTPClientProperties create() {
/* 32 */     if (properties == null) {
/* 33 */       properties = (CommonsHTTPClientProperties)AxisProperties.newInstance(CommonsHTTPClientProperties.class, DefaultCommonsHTTPClientProperties.class);
/*    */     }
/*    */ 
/*    */     
/* 37 */     return properties;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\CommonsHTTPClientPropertiesFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */