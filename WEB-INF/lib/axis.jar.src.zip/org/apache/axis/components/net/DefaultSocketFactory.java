package org.apache.axis.components.net;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.Socket;
import java.util.Hashtable;
import java.util.StringTokenizer;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.Base64;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class DefaultSocketFactory implements SocketFactory {
  protected static Log log = LogFactory.getLog(DefaultSocketFactory.class.getName());
  
  public static String CONNECT_TIMEOUT = "axis.client.connect.timeout";
  
  protected Hashtable attributes;
  
  private static boolean plain;
  
  private static Class inetClass;
  
  private static Constructor inetConstructor;
  
  private static Constructor socketConstructor;
  
  private static Method connect;
  
  static  {
    try {
      inetClass = Class.forName("java.net.InetSocketAddress");
      plain = false;
      inetConstructor = inetClass.getConstructor(new Class[] { String.class, int.class });
      socketConstructor = Socket.class.getConstructor(new Class[0]);
      connect = Socket.class.getMethod("connect", new Class[] { inetClass.getSuperclass(), int.class });
    } catch (Exception e) {
      plain = true;
    } 
  }
  
  public DefaultSocketFactory(Hashtable attributes) {
    this.attributes = null;
    this.attributes = attributes;
  }
  
  public Socket create(String host, int port, StringBuffer otherHeaders, BooleanHolder useFullURL) throws Exception {
    int timeout = 0;
    if (this.attributes != null) {
      String value = (String)this.attributes.get(CONNECT_TIMEOUT);
      timeout = (value != null) ? Integer.parseInt(value) : 0;
    } 
    TransportClientProperties tcp = TransportClientPropertiesFactory.create("http");
    Socket sock = null;
    boolean hostInNonProxyList = isHostInNonProxyList(host, tcp.getNonProxyHosts());
    if (tcp.getProxyUser().length() != 0) {
      StringBuffer tmpBuf = new StringBuffer();
      tmpBuf.append(tcp.getProxyUser()).append(":").append(tcp.getProxyPassword());
      otherHeaders.append("Proxy-Authorization").append(": Basic ").append(Base64.encode(tmpBuf.toString().getBytes())).append("\r\n");
    } 
    if (port == -1)
      port = 80; 
    if (tcp.getProxyHost().length() == 0 || tcp.getProxyPort().length() == 0 || hostInNonProxyList) {
      sock = create(host, port, timeout);
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("createdHTTP00")); 
    } else {
      sock = create(tcp.getProxyHost(), (new Integer(tcp.getProxyPort())).intValue(), timeout);
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("createdHTTP01", tcp.getProxyHost(), tcp.getProxyPort())); 
      useFullURL.value = true;
    } 
    return sock;
  }
  
  private static Socket create(String host, int port, int timeout) throws Exception {
    Socket sock = null;
    if (plain || timeout == 0) {
      sock = new Socket(host, port);
    } else {
      Object address = inetConstructor.newInstance(new Object[] { host, new Integer(port) });
      sock = (Socket)socketConstructor.newInstance(new Object[0]);
      connect.invoke(sock, new Object[] { address, new Integer(timeout) });
    } 
    return sock;
  }
  
  protected boolean isHostInNonProxyList(String host, String nonProxyHosts) {
    if (nonProxyHosts == null || host == null)
      return false; 
    StringTokenizer tokenizer = new StringTokenizer(nonProxyHosts, "|\"");
    while (tokenizer.hasMoreTokens()) {
      String pattern = tokenizer.nextToken();
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("match00", new String[] { "HTTPSender", host, pattern })); 
      if (match(pattern, host, false))
        return true; 
    } 
    return false;
  }
  
  protected static boolean match(String pattern, String str, boolean isCaseSensitive) {
    char[] patArr = pattern.toCharArray();
    char[] strArr = str.toCharArray();
    int patIdxStart = 0;
    int patIdxEnd = patArr.length - 1;
    int strIdxStart = 0;
    int strIdxEnd = strArr.length - 1;
    boolean containsStar = false;
    for (int i = 0; i < patArr.length; i++) {
      if (patArr[i] == '*') {
        containsStar = true;
        break;
      } 
    } 
    if (!containsStar) {
      if (patIdxEnd != strIdxEnd)
        return false; 
      for (int i = 0; i <= patIdxEnd; i++) {
        char ch = patArr[i];
        if (isCaseSensitive && ch != strArr[i])
          return false; 
        if (!isCaseSensitive && Character.toUpperCase(ch) != Character.toUpperCase(strArr[i]))
          return false; 
      } 
      return true;
    } 
    if (patIdxEnd == 0)
      return true; 
    char ch;
    while ((ch = patArr[patIdxStart]) != '*' && strIdxStart <= strIdxEnd) {
      if (isCaseSensitive && ch != strArr[strIdxStart])
        return false; 
      if (!isCaseSensitive && Character.toUpperCase(ch) != Character.toUpperCase(strArr[strIdxStart]))
        return false; 
      patIdxStart++;
      strIdxStart++;
    } 
    if (strIdxStart > strIdxEnd) {
      for (int i = patIdxStart; i <= patIdxEnd; i++) {
        if (patArr[i] != '*')
          return false; 
      } 
      return true;
    } 
    while ((ch = patArr[patIdxEnd]) != '*' && strIdxStart <= strIdxEnd) {
      if (isCaseSensitive && ch != strArr[strIdxEnd])
        return false; 
      if (!isCaseSensitive && Character.toUpperCase(ch) != Character.toUpperCase(strArr[strIdxEnd]))
        return false; 
      patIdxEnd--;
      strIdxEnd--;
    } 
    if (strIdxStart > strIdxEnd) {
      for (int i = patIdxStart; i <= patIdxEnd; i++) {
        if (patArr[i] != '*')
          return false; 
      } 
      return true;
    } 
    while (patIdxStart != patIdxEnd && strIdxStart <= strIdxEnd) {
      int patIdxTmp = -1;
      for (int i = patIdxStart + 1; i <= patIdxEnd; i++) {
        if (patArr[i] == '*') {
          patIdxTmp = i;
          break;
        } 
      } 
      if (patIdxTmp == patIdxStart + 1) {
        patIdxStart++;
        continue;
      } 
      int patLength = patIdxTmp - patIdxStart - 1;
      int strLength = strIdxEnd - strIdxStart + 1;
      int foundIdx = -1;
      int i;
      label113: for (i = 0; i <= strLength - patLength; ) {
        for (int j = 0; j < patLength; j++) {
          ch = patArr[patIdxStart + j + 1];
          if (isCaseSensitive && ch != strArr[strIdxStart + i + j])
            continue label113; 
          if (!isCaseSensitive && Character.toUpperCase(ch) != Character.toUpperCase(strArr[strIdxStart + i + j])) {
            i++;
            continue;
          } 
        } 
        foundIdx = strIdxStart + i;
      } 
      if (foundIdx == -1)
        return false; 
      patIdxStart = patIdxTmp;
      strIdxStart = foundIdx + patLength;
    } 
    for (int i = patIdxStart; i <= patIdxEnd; i++) {
      if (patArr[i] != '*')
        return false; 
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\DefaultSocketFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */