package org.apache.axis.components.net;

import java.util.Hashtable;
import org.apache.axis.AxisProperties;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class SocketFactoryFactory {
  protected static Log log = LogFactory.getLog(SocketFactoryFactory.class.getName());
  
  private static Hashtable factories = new Hashtable();
  
  private static final Class[] classes = { Hashtable.class };
  
  static  {
    AxisProperties.setClassOverrideProperty(SocketFactory.class, "axis.socketFactory");
    AxisProperties.setClassDefault(SocketFactory.class, "org.apache.axis.components.net.DefaultSocketFactory");
    AxisProperties.setClassOverrideProperty(SecureSocketFactory.class, "axis.socketSecureFactory");
    AxisProperties.setClassDefault(SecureSocketFactory.class, "org.apache.axis.components.net.JSSESocketFactory");
  }
  
  public static SocketFactory getFactory(String protocol, Hashtable attributes) {
    SocketFactory theFactory = (SocketFactory)factories.get(protocol);
    if (theFactory == null) {
      Object[] objects = { attributes };
      if (protocol.equalsIgnoreCase("http")) {
        theFactory = (SocketFactory)AxisProperties.newInstance(SocketFactory.class, classes, objects);
      } else if (protocol.equalsIgnoreCase("https")) {
        theFactory = (SecureSocketFactory)AxisProperties.newInstance(SecureSocketFactory.class, classes, objects);
      } 
      if (theFactory != null)
        factories.put(protocol, theFactory); 
    } 
    return theFactory;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\net\SocketFactoryFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */