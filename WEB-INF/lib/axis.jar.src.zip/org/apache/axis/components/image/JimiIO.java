package org.apache.axis.components.image;

import com.sun.jimi.core.Jimi;
import java.awt.Image;
import java.io.InputStream;
import java.io.OutputStream;

public class JimiIO implements ImageIO {
  public void saveImage(String id, Image image, OutputStream os) throws Exception { Jimi.putImage(id, image, os); }
  
  public Image loadImage(InputStream in) throws Exception { return Jimi.getImage(in); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\image\JimiIO.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */