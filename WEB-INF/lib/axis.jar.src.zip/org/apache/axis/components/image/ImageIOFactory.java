package org.apache.axis.components.image;

import org.apache.axis.AxisProperties;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.ClassUtils;
import org.apache.commons.logging.Log;

public class ImageIOFactory {
  protected static Log log = LogFactory.getLog(ImageIOFactory.class.getName());
  
  static  {
    AxisProperties.setClassOverrideProperty(ImageIO.class, "axis.ImageIO");
    AxisProperties.setClassDefaults(ImageIO.class, new String[] { "org.apache.axis.components.image.MerlinIO", "org.apache.axis.components.image.JimiIO", "org.apache.axis.components.image.JDK13IO" });
  }
  
  public static ImageIO getImageIO() {
    imageIO = (ImageIO)AxisProperties.newInstance(ImageIO.class);
    if (imageIO == null)
      try {
        Class cls = ClassUtils.forName("org.apache.axis.components.image.JDK13IO");
        imageIO = (ImageIO)cls.newInstance();
      } catch (Exception e) {
        log.debug("ImageIOFactory: No matching ImageIO found", e);
      }  
    log.debug("axis.ImageIO: " + imageIO.getClass().getName());
    return imageIO;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\image\ImageIOFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */