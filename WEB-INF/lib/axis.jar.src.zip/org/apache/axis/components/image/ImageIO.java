package org.apache.axis.components.image;

import java.awt.Image;
import java.io.InputStream;
import java.io.OutputStream;

public interface ImageIO {
  void saveImage(String paramString, Image paramImage, OutputStream paramOutputStream) throws Exception;
  
  Image loadImage(InputStream paramInputStream) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\image\ImageIO.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */