package org.apache.axis.components.uuid;

import java.security.SecureRandom;
import java.util.Random;

public class FastUUIDGen implements UUIDGen {
  private static Random secureRandom;
  
  private static String nodeStr;
  
  private static int clockSequence;
  
  private long lastTime = 0L;
  
  static  {
    try {
      secureRandom = SecureRandom.getInstance("SHA1PRNG", "SUN");
    } catch (Exception e) {
      secureRandom = new Random();
    } 
    nodeStr = getNodeHexValue();
    clockSequence = getClockSequence();
  }
  
  private static String getNodeHexValue() {
    node = 0L;
    long nodeValue = 0L;
    while ((node = getBitsValue(nodeValue, 47, 47)) == 0L)
      nodeValue = secureRandom.nextLong(); 
    node |= 0x800000000000L;
    return leftZeroPadString(Long.toHexString(node), 12);
  }
  
  private static int getClockSequence() { return secureRandom.nextInt(16384); }
  
  public String nextUUID() {
    long time = System.currentTimeMillis();
    long timestamp = time * 10000L;
    timestamp += 122192927672762368L;
    timestamp += 327237632L;
    synchronized (this) {
      if (time - this.lastTime <= 0L)
        clockSequence = clockSequence + 1 & 0x3FFF; 
      this.lastTime = time;
    } 
    long timeLow = getBitsValue(timestamp, 32, 32);
    long timeMid = getBitsValue(timestamp, 48, 16);
    long timeHi = getBitsValue(timestamp, 64, 16) | 0x1000L;
    long clockSeqLow = getBitsValue(clockSequence, 8, 8);
    long clockSeqHi = getBitsValue(clockSequence, 16, 8) | 0x80L;
    String timeLowStr = leftZeroPadString(Long.toHexString(timeLow), 8);
    String timeMidStr = leftZeroPadString(Long.toHexString(timeMid), 4);
    String timeHiStr = leftZeroPadString(Long.toHexString(timeHi), 4);
    String clockSeqHiStr = leftZeroPadString(Long.toHexString(clockSeqHi), 2);
    String clockSeqLowStr = leftZeroPadString(Long.toHexString(clockSeqLow), 2);
    StringBuffer result = new StringBuffer(36);
    result.append(timeLowStr).append("-");
    result.append(timeMidStr).append("-");
    result.append(timeHiStr).append("-");
    result.append(clockSeqHiStr).append(clockSeqLowStr);
    result.append("-").append(nodeStr);
    return result.toString();
  }
  
  private static long getBitsValue(long value, int startBit, int bitLen) { return value << 64 - startBit >>> 64 - bitLen; }
  
  private static final String leftZeroPadString(String bitString, int len) {
    if (bitString.length() < len) {
      int nbExtraZeros = len - bitString.length();
      StringBuffer extraZeros = new StringBuffer();
      for (int i = 0; i < nbExtraZeros; i++)
        extraZeros.append("0"); 
      extraZeros.append(bitString);
      bitString = extraZeros.toString();
    } 
    return bitString;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\component\\uuid\FastUUIDGen.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */