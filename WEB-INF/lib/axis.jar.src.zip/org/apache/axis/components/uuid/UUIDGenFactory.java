/*    */ package org.apache.axis.components.uuid;
/*    */ 
/*    */ import org.apache.axis.AxisProperties;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class UUIDGenFactory
/*    */ {
/* 41 */   protected static Log log = LogFactory.getLog(UUIDGenFactory.class.getName());
/*    */   
/*    */   static  {
/* 44 */     AxisProperties.setClassOverrideProperty(UUIDGen.class, "axis.UUIDGenerator");
/* 45 */     AxisProperties.setClassDefault(UUIDGen.class, "org.apache.axis.components.uuid.FastUUIDGen");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static UUIDGen getUUIDGen() {
/* 52 */     uuidgen = (UUIDGen)AxisProperties.newInstance(UUIDGen.class);
/* 53 */     log.debug("axis.UUIDGenerator:" + uuidgen.getClass().getName());
/* 54 */     return uuidgen;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\component\\uuid\UUIDGenFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */