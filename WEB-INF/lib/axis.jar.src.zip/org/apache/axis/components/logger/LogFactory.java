package org.apache.axis.components.logger;

import java.security.AccessController;
import java.security.PrivilegedAction;
import org.apache.commons.discovery.tools.DiscoverSingleton;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LogFactory {
  private static final LogFactory logFactory = getLogFactory();
  
  static Class class$org$apache$commons$logging$LogFactory;
  
  public static Log getLog(String name) { return LogFactory.getLog(name); }
  
  private static final LogFactory getLogFactory() {
    return (LogFactory)AccessController.doPrivileged(new PrivilegedAction() {
          public Object run() { return DiscoverSingleton.find((LogFactory.class$org$apache$commons$logging$LogFactory == null) ? (LogFactory.class$org$apache$commons$logging$LogFactory = LogFactory.class$("org.apache.commons.logging.LogFactory")) : LogFactory.class$org$apache$commons$logging$LogFactory, "commons-logging.properties", "org.apache.commons.logging.impl.LogFactoryImpl"); }
        });
  }
  
  static Class class$(String x0) { try {
      return Class.forName(x0);
    } catch (ClassNotFoundException x1) {
      throw new NoClassDefFoundError(x1.getMessage());
    }  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\components\logger\LogFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */