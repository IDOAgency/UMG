/*    */ package org.apache.axis.soap;
/*    */ 
/*    */ import javax.xml.soap.SOAPConnection;
/*    */ import javax.xml.soap.SOAPConnectionFactory;
/*    */ import javax.xml.soap.SOAPException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPConnectionFactoryImpl
/*    */   extends SOAPConnectionFactory
/*    */ {
/* 34 */   public SOAPConnection createConnection() throws SOAPException { return new SOAPConnectionImpl(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\soap\SOAPConnectionFactoryImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */