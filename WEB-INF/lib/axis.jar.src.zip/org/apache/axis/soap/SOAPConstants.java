package org.apache.axis.soap;

import java.io.Serializable;
import javax.xml.namespace.QName;

public interface SOAPConstants extends Serializable {
  public static final SOAP11Constants SOAP11_CONSTANTS = new SOAP11Constants();
  
  public static final SOAP12Constants SOAP12_CONSTANTS = new SOAP12Constants();
  
  String getEnvelopeURI();
  
  String getEncodingURI();
  
  QName getFaultQName();
  
  QName getHeaderQName();
  
  QName getBodyQName();
  
  QName getRoleAttributeQName();
  
  String getContentType();
  
  String getNextRoleURI();
  
  String getAttrHref();
  
  String getAttrItemType();
  
  QName getVerMismatchFaultCodeQName();
  
  QName getMustunderstandFaultQName();
  
  QName getArrayType();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\soap\SOAPConstants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */