/*     */ package org.apache.axis.soap;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAP12Constants
/*     */   implements SOAPConstants
/*     */ {
/*  29 */   private static QName headerQName = new QName("http://www.w3.org/2003/05/soap-envelope", "Header");
/*     */   
/*  31 */   private static QName bodyQName = new QName("http://www.w3.org/2003/05/soap-envelope", "Body");
/*     */   
/*  33 */   private static QName faultQName = new QName("http://www.w3.org/2003/05/soap-envelope", "Fault");
/*     */   
/*  35 */   private static QName roleQName = new QName("http://www.w3.org/2003/05/soap-envelope", "role");
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PROP_WEBMETHOD = "soap12.webmethod";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public String getEnvelopeURI() { return "http://www.w3.org/2003/05/soap-envelope"; }
/*     */ 
/*     */ 
/*     */   
/*  48 */   public String getEncodingURI() { return "http://www.w3.org/2003/05/soap-encoding"; }
/*     */ 
/*     */ 
/*     */   
/*  52 */   public QName getHeaderQName() { return headerQName; }
/*     */ 
/*     */ 
/*     */   
/*  56 */   public QName getBodyQName() { return bodyQName; }
/*     */ 
/*     */ 
/*     */   
/*  60 */   public QName getFaultQName() { return faultQName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public QName getRoleAttributeQName() { return roleQName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public String getContentType() { return "application/soap+xml"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public String getNextRoleURI() { return "http://www.w3.org/2003/05/soap-envelope/role/next"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public String getAttrHref() { return "ref"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public String getAttrItemType() { return "itemType"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public QName getVerMismatchFaultCodeQName() { return Constants.FAULT_SOAP12_VERSIONMISMATCH; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public QName getMustunderstandFaultQName() { return Constants.FAULT_SOAP12_MUSTUNDERSTAND; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public QName getArrayType() { return Constants.SOAP_ARRAY12; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\soap\SOAP12Constants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */