package org.apache.axis.soap;

import java.net.MalformedURLException;
import java.util.Iterator;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import org.apache.axis.AxisFault;
import org.apache.axis.Message;
import org.apache.axis.attachments.Attachments;
import org.apache.axis.client.Call;
import org.apache.axis.utils.Messages;

public class SOAPConnectionImpl extends SOAPConnection {
  private boolean closed = false;
  
  private Integer timeout = null;
  
  public Integer getTimeout() { return this.timeout; }
  
  public void setTimeout(Integer timeout) { this.timeout = timeout; }
  
  public SOAPMessage call(SOAPMessage request, Object endpoint) throws SOAPException {
    if (this.closed)
      throw new SOAPException(Messages.getMessage("connectionClosed00")); 
    try {
      Call call = new Call(endpoint.toString());
      ((Message)request).setMessageContext(call.getMessageContext());
      Attachments attachments = ((Message)request).getAttachmentsImpl();
      if (attachments != null) {
        Iterator iterator = attachments.getAttachments().iterator();
        while (iterator.hasNext()) {
          Object attachment = iterator.next();
          call.addAttachmentPart(attachment);
        } 
      } 
      String soapActionURI = checkForSOAPActionHeader(request);
      if (soapActionURI != null)
        call.setSOAPActionURI(soapActionURI); 
      call.setTimeout(this.timeout);
      call.setReturnClass(SOAPMessage.class);
      call.setProperty("call.CheckMustUnderstand", Boolean.FALSE);
      call.invoke((Message)request);
      return call.getResponseMessage();
    } catch (MalformedURLException mue) {
      throw new SOAPException(mue);
    } catch (AxisFault af) {
      return new Message(af);
    } 
  }
  
  private String checkForSOAPActionHeader(SOAPMessage request) {
    MimeHeaders hdrs = request.getMimeHeaders();
    if (hdrs != null) {
      String[] saHdrs = hdrs.getHeader("SOAPAction");
      if (saHdrs != null && saHdrs.length > 0)
        return saHdrs[0]; 
    } 
    return null;
  }
  
  public void close() {
    if (this.closed)
      throw new SOAPException(Messages.getMessage("connectionClosed00")); 
    this.closed = true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\soap\SOAPConnectionImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */