/*     */ package org.apache.axis.soap;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAP11Constants
/*     */   implements SOAPConstants
/*     */ {
/*  29 */   private static QName headerQName = new QName("http://schemas.xmlsoap.org/soap/envelope/", "Header");
/*     */   
/*  31 */   private static QName bodyQName = new QName("http://schemas.xmlsoap.org/soap/envelope/", "Body");
/*     */   
/*  33 */   private static QName faultQName = new QName("http://schemas.xmlsoap.org/soap/envelope/", "Fault");
/*     */   
/*  35 */   private static QName roleQName = new QName("http://schemas.xmlsoap.org/soap/envelope/", "actor");
/*     */ 
/*     */ 
/*     */   
/*  39 */   public String getEnvelopeURI() { return "http://schemas.xmlsoap.org/soap/envelope/"; }
/*     */ 
/*     */ 
/*     */   
/*  43 */   public String getEncodingURI() { return "http://schemas.xmlsoap.org/soap/encoding/"; }
/*     */ 
/*     */ 
/*     */   
/*  47 */   public QName getHeaderQName() { return headerQName; }
/*     */ 
/*     */ 
/*     */   
/*  51 */   public QName getBodyQName() { return bodyQName; }
/*     */ 
/*     */ 
/*     */   
/*  55 */   public QName getFaultQName() { return faultQName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public QName getRoleAttributeQName() { return roleQName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public String getContentType() { return "text/xml"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public String getNextRoleURI() { return "http://schemas.xmlsoap.org/soap/actor/next"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public String getAttrHref() { return "href"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public String getAttrItemType() { return "arrayType"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public QName getVerMismatchFaultCodeQName() { return Constants.FAULT_VERSIONMISMATCH; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public QName getMustunderstandFaultQName() { return Constants.FAULT_MUSTUNDERSTAND; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public QName getArrayType() { return Constants.SOAP_ARRAY; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\soap\SOAP11Constants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */