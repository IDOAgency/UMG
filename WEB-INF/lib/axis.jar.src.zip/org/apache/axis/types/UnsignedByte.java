/*    */ package org.apache.axis.types;
/*    */ 
/*    */ import org.apache.axis.utils.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnsignedByte
/*    */   extends UnsignedShort
/*    */ {
/*    */   public UnsignedByte() {}
/*    */   
/* 39 */   public UnsignedByte(long sValue) throws NumberFormatException { setValue(sValue); }
/*    */ 
/*    */ 
/*    */   
/* 43 */   public UnsignedByte(String sValue) throws NumberFormatException { setValue(Long.parseLong(sValue)); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(long sValue) throws NumberFormatException {
/* 53 */     if (!isValid(sValue)) {
/* 54 */       throw new NumberFormatException(Messages.getMessage("badUnsignedByte00") + String.valueOf(sValue) + "]");
/*    */     }
/*    */     
/* 57 */     this.lValue = new Long(sValue);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isValid(long sValue) {
/* 66 */     if (sValue < 0L || sValue > 255L) {
/* 67 */       return false;
/*    */     }
/* 69 */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\UnsignedByte.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */