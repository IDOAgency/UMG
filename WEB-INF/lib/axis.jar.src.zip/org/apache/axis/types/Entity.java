/*    */ package org.apache.axis.types;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Entity
/*    */   extends NCName
/*    */ {
/*    */   public Entity() {}
/*    */   
/* 35 */   public Entity(String stValue) throws IllegalArgumentException { super(stValue); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Entity.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */