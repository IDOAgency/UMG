package org.apache.axis.types;

public class Entity extends NCName {
  public Entity() {}
  
  public Entity(String stValue) throws IllegalArgumentException { super(stValue); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Entity.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */