/*     */ package org.apache.axis.types;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.Serializable;
/*     */ import org.apache.axis.utils.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HexBinary
/*     */   implements Serializable
/*     */ {
/*  29 */   byte[] m_value = null;
/*     */ 
/*     */   
/*     */   public HexBinary() {}
/*     */ 
/*     */   
/*  35 */   public HexBinary(String string) { this.m_value = decode(string); }
/*     */ 
/*     */ 
/*     */   
/*  39 */   public HexBinary(byte[] bytes) { this.m_value = bytes; }
/*     */ 
/*     */ 
/*     */   
/*  43 */   public byte[] getBytes() { return this.m_value; }
/*     */ 
/*     */ 
/*     */   
/*  47 */   public String toString() { return encode(this.m_value); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public int hashCode() { return super.hashCode(); }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  57 */     String s1 = object.toString();
/*  58 */     String s2 = toString();
/*  59 */     return s1.equals(s2);
/*     */   }
/*     */   
/*  62 */   public static final String ERROR_ODD_NUMBER_OF_DIGITS = Messages.getMessage("oddDigits00");
/*     */   
/*  64 */   public static final String ERROR_BAD_CHARACTER_IN_HEX_STRING = Messages.getMessage("badChars01");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int[] DEC = { 
/*  70 */       -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] decode(String digits) {
/* 101 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 102 */     for (int i = 0; i < digits.length(); i += 2) {
/* 103 */       char c1 = digits.charAt(i);
/* 104 */       if (i + 1 >= digits.length()) {
/* 105 */         throw new IllegalArgumentException(ERROR_ODD_NUMBER_OF_DIGITS);
/*     */       }
/* 107 */       char c2 = digits.charAt(i + 1);
/* 108 */       byte b = 0;
/* 109 */       if (c1 >= '0' && c1 <= '9') {
/* 110 */         b = (byte)(b + (c1 - '0') * '\020');
/* 111 */       } else if (c1 >= 'a' && c1 <= 'f') {
/* 112 */         b = (byte)(b + (c1 - 'a' + '\n') * '\020');
/* 113 */       } else if (c1 >= 'A' && c1 <= 'F') {
/* 114 */         b = (byte)(b + (c1 - 'A' + '\n') * '\020');
/*     */       } else {
/* 116 */         throw new IllegalArgumentException(ERROR_BAD_CHARACTER_IN_HEX_STRING);
/*     */       } 
/* 118 */       if (c2 >= '0' && c2 <= '9') {
/* 119 */         b = (byte)(b + c2 - '0');
/* 120 */       } else if (c2 >= 'a' && c2 <= 'f') {
/* 121 */         b = (byte)(b + c2 - 'a' + '\n');
/* 122 */       } else if (c2 >= 'A' && c2 <= 'F') {
/* 123 */         b = (byte)(b + c2 - 'A' + '\n');
/*     */       } else {
/* 125 */         throw new IllegalArgumentException(ERROR_BAD_CHARACTER_IN_HEX_STRING);
/*     */       } 
/* 127 */       baos.write(b);
/*     */     } 
/* 129 */     return baos.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(byte[] bytes) {
/* 142 */     StringBuffer sb = new StringBuffer(bytes.length * 2);
/* 143 */     for (int i = 0; i < bytes.length; i++) {
/* 144 */       sb.append(convertDigit(bytes[i] >> 4));
/* 145 */       sb.append(convertDigit(bytes[i] & 0xF));
/*     */     } 
/* 147 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int convert2Int(byte[] hex) {
/* 166 */     if (hex.length < 4) return 0; 
/* 167 */     if (DEC[hex[0]] < 0)
/* 168 */       throw new IllegalArgumentException(ERROR_BAD_CHARACTER_IN_HEX_STRING); 
/* 169 */     len = DEC[hex[0]];
/* 170 */     len <<= 4;
/* 171 */     if (DEC[hex[1]] < 0)
/* 172 */       throw new IllegalArgumentException(ERROR_BAD_CHARACTER_IN_HEX_STRING); 
/* 173 */     len += DEC[hex[1]];
/* 174 */     len <<= 4;
/* 175 */     if (DEC[hex[2]] < 0)
/* 176 */       throw new IllegalArgumentException(ERROR_BAD_CHARACTER_IN_HEX_STRING); 
/* 177 */     len += DEC[hex[2]];
/* 178 */     len <<= 4;
/* 179 */     if (DEC[hex[3]] < 0)
/* 180 */       throw new IllegalArgumentException(ERROR_BAD_CHARACTER_IN_HEX_STRING); 
/* 181 */     return DEC[hex[3]];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char convertDigit(int value) {
/* 193 */     value &= 0xF;
/* 194 */     if (value >= 10) {
/* 195 */       return (char)(value - 10 + 97);
/*     */     }
/* 197 */     return (char)(value + 48);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\HexBinary.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */