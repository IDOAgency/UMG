package org.apache.axis.types;

import java.util.StringTokenizer;

public class Entities extends NCName {
  private Entity[] entities;
  
  public Entities() {}
  
  public Entities(String stValue) throws IllegalArgumentException {
    StringTokenizer tokenizer = new StringTokenizer(stValue);
    int count = tokenizer.countTokens();
    this.entities = new Entity[count];
    for (int i = 0; i < count; i++)
      this.entities[i] = new Entity(tokenizer.nextToken()); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Entities.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */