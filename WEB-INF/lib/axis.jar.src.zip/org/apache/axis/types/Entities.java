/*    */ package org.apache.axis.types;
/*    */ 
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Entities
/*    */   extends NCName
/*    */ {
/*    */   private Entity[] entities;
/*    */   
/*    */   public Entities() {}
/*    */   
/*    */   public Entities(String stValue) throws IllegalArgumentException {
/* 37 */     StringTokenizer tokenizer = new StringTokenizer(stValue);
/* 38 */     int count = tokenizer.countTokens();
/* 39 */     this.entities = new Entity[count];
/* 40 */     for (int i = 0; i < count; i++)
/* 41 */       this.entities[i] = new Entity(tokenizer.nextToken()); 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Entities.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */