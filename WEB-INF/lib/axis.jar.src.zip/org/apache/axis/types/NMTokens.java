package org.apache.axis.types;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

public class NMTokens extends NCName {
  private NMToken[] tokens;
  
  public NMTokens() {}
  
  public NMTokens(String stValue) throws IllegalArgumentException { setValue(stValue); }
  
  public void setValue(String stValue) throws IllegalArgumentException {
    StringTokenizer tokenizer = new StringTokenizer(stValue);
    int count = tokenizer.countTokens();
    this.tokens = new NMToken[count];
    for (int i = 0; i < count; i++)
      this.tokens[i] = new NMToken(tokenizer.nextToken()); 
  }
  
  public String toString() {
    StringBuffer buf = new StringBuffer();
    for (int i = 0; i < this.tokens.length; i++) {
      NMToken token = this.tokens[i];
      if (i > 0)
        buf.append(" "); 
      buf.append(token.toString());
    } 
    return buf.toString();
  }
  
  public boolean equals(Object object) {
    if (object == this)
      return true; 
    if (object instanceof NMTokens) {
      NMTokens that = (NMTokens)object;
      if (this.tokens.length == that.tokens.length) {
        Set ourSet = new HashSet(Arrays.asList(this.tokens));
        Set theirSet = new HashSet(Arrays.asList(that.tokens));
        return ourSet.equals(theirSet);
      } 
      return false;
    } 
    return false;
  }
  
  public int hashCode() {
    int hash = 0;
    for (int i = 0; i < this.tokens.length; i++)
      hash += this.tokens[i].hashCode(); 
    return hash;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\NMTokens.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */