package org.apache.axis.types;

import java.io.Serializable;
import java.text.NumberFormat;
import org.apache.axis.utils.Messages;

public class Year implements Serializable {
  int year;
  
  String timezone;
  
  public Year(int year) throws NumberFormatException {
    this.timezone = null;
    setValue(year);
  }
  
  public Year(int year, String timezone) throws NumberFormatException {
    this.timezone = null;
    setValue(year, timezone);
  }
  
  public Year(String source) throws NumberFormatException {
    this.timezone = null;
    int negative = 0;
    if (source.charAt(0) == '-')
      negative = 1; 
    if (source.length() < 4 + negative)
      throw new NumberFormatException(Messages.getMessage("badYear00")); 
    int pos = 4 + negative;
    while (pos < source.length() && Character.isDigit(source.charAt(pos)))
      pos++; 
    setValue(Integer.parseInt(source.substring(0, pos)), source.substring(pos));
  }
  
  public int getYear() { return this.year; }
  
  public void setYear(int year) throws NumberFormatException {
    if (year == 0)
      throw new NumberFormatException(Messages.getMessage("badYear00")); 
    this.year = year;
  }
  
  public String getTimezone() { return this.timezone; }
  
  public void setTimezone(String timezone) throws NumberFormatException {
    if (timezone != null && timezone.length() > 0) {
      if (timezone.charAt(0) == '+' || timezone.charAt(0) == '-') {
        if (timezone.length() != 6 || !Character.isDigit(timezone.charAt(1)) || !Character.isDigit(timezone.charAt(2)) || timezone.charAt(3) != ':' || !Character.isDigit(timezone.charAt(4)) || !Character.isDigit(timezone.charAt(5)))
          throw new NumberFormatException(Messages.getMessage("badTimezone00")); 
      } else if (!timezone.equals("Z")) {
        throw new NumberFormatException(Messages.getMessage("badTimezone00"));
      } 
      this.timezone = timezone;
    } 
  }
  
  public void setValue(int year, String timezone) throws NumberFormatException {
    setYear(year);
    setTimezone(timezone);
  }
  
  public void setValue(int year) throws NumberFormatException { setYear(year); }
  
  public String toString() {
    NumberFormat nf = NumberFormat.getInstance();
    nf.setGroupingUsed(false);
    nf.setMinimumIntegerDigits(4);
    String s = nf.format(this.year);
    if (this.timezone != null)
      s = s + this.timezone; 
    return s;
  }
  
  public boolean equals(Object obj) {
    if (!(obj instanceof Year))
      return false; 
    Year other = (Year)obj;
    if (obj == null)
      return false; 
    if (this == obj)
      return true; 
    boolean equals = (this.year == other.year);
    if (this.timezone != null)
      equals = (equals && this.timezone.equals(other.timezone)); 
    return equals;
  }
  
  public int hashCode() { return (null == this.timezone) ? this.year : (this.year ^ this.timezone.hashCode()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Year.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */