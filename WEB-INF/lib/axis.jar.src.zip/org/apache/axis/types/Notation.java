/*     */ package org.apache.axis.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.axis.Constants;
/*     */ import org.apache.axis.description.AttributeDesc;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Notation
/*     */   implements Serializable
/*     */ {
/*     */   NCName name;
/*     */   URI publicURI;
/*     */   URI systemURI;
/*     */   
/*     */   public Notation() {}
/*     */   
/*     */   public Notation(NCName name, URI publicURI, URI systemURI) {
/*  40 */     this.name = name;
/*  41 */     this.publicURI = publicURI;
/*  42 */     this.systemURI = systemURI;
/*     */   }
/*     */ 
/*     */   
/*  46 */   public NCName getName() { return this.name; }
/*     */ 
/*     */ 
/*     */   
/*  50 */   public void setName(NCName name) { this.name = name; }
/*     */ 
/*     */ 
/*     */   
/*  54 */   public URI getPublic() { return this.publicURI; }
/*     */ 
/*     */ 
/*     */   
/*  58 */   public void setPublic(URI publicURI) { this.publicURI = publicURI; }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public URI getSystem() { return this.systemURI; }
/*     */ 
/*     */ 
/*     */   
/*  66 */   public void setSystem(URI systemURI) { this.systemURI = systemURI; }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  70 */     if (obj == null || !(obj instanceof Notation))
/*  71 */       return false; 
/*  72 */     Notation other = (Notation)obj;
/*  73 */     if (this.name == null) {
/*  74 */       if (other.getName() != null) {
/*  75 */         return false;
/*     */       }
/*  77 */     } else if (!this.name.equals(other.getName())) {
/*  78 */       return false;
/*     */     } 
/*  80 */     if (this.publicURI == null) {
/*  81 */       if (other.getPublic() != null) {
/*  82 */         return false;
/*     */       }
/*  84 */     } else if (!this.publicURI.equals(other.getPublic())) {
/*  85 */       return false;
/*     */     } 
/*  87 */     if (this.systemURI == null) {
/*  88 */       if (other.getSystem() != null) {
/*  89 */         return false;
/*     */       }
/*  91 */     } else if (!this.systemURI.equals(other.getSystem())) {
/*  92 */       return false;
/*     */     } 
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 106 */     int hash = 0;
/* 107 */     if (null != this.name) {
/* 108 */       hash += this.name.hashCode();
/*     */     }
/* 110 */     if (null != this.publicURI) {
/* 111 */       hash += this.publicURI.hashCode();
/*     */     }
/* 113 */     if (null != this.systemURI) {
/* 114 */       hash += this.systemURI.hashCode();
/*     */     }
/* 116 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   private static TypeDesc typeDesc = new TypeDesc(Notation.class);
/*     */ 
/*     */   
/*     */   static  {
/* 128 */     AttributeDesc attributeDesc = new AttributeDesc();
/* 129 */     attributeDesc.setFieldName("name");
/* 130 */     attributeDesc.setXmlName(Constants.XSD_NCNAME);
/* 131 */     typeDesc.addFieldDesc(attributeDesc);
/*     */ 
/*     */     
/* 134 */     attributeDesc = new AttributeDesc();
/* 135 */     attributeDesc.setFieldName("public");
/* 136 */     attributeDesc.setXmlName(Constants.XSD_ANYURI);
/* 137 */     typeDesc.addFieldDesc(attributeDesc);
/*     */ 
/*     */     
/* 140 */     ElementDesc element = null;
/* 141 */     element = new ElementDesc();
/* 142 */     element.setFieldName("system");
/* 143 */     element.setXmlName(Constants.XSD_ANYURI);
/*     */ 
/*     */     
/* 146 */     element.setNillable(true);
/* 147 */     typeDesc.addFieldDesc(attributeDesc);
/*     */   }
/*     */ 
/*     */   
/* 151 */   public static TypeDesc getTypeDesc() { return typeDesc; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Notation.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */