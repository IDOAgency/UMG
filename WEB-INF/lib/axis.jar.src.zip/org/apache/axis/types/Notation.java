package org.apache.axis.types;

import java.io.Serializable;
import org.apache.axis.Constants;
import org.apache.axis.description.AttributeDesc;
import org.apache.axis.description.ElementDesc;
import org.apache.axis.description.TypeDesc;

public class Notation implements Serializable {
  NCName name;
  
  URI publicURI;
  
  URI systemURI;
  
  public Notation() {}
  
  public Notation(NCName name, URI publicURI, URI systemURI) {
    this.name = name;
    this.publicURI = publicURI;
    this.systemURI = systemURI;
  }
  
  public NCName getName() { return this.name; }
  
  public void setName(NCName name) { this.name = name; }
  
  public URI getPublic() { return this.publicURI; }
  
  public void setPublic(URI publicURI) { this.publicURI = publicURI; }
  
  public URI getSystem() { return this.systemURI; }
  
  public void setSystem(URI systemURI) { this.systemURI = systemURI; }
  
  public boolean equals(Object obj) {
    if (obj == null || !(obj instanceof Notation))
      return false; 
    Notation other = (Notation)obj;
    if (this.name == null) {
      if (other.getName() != null)
        return false; 
    } else if (!this.name.equals(other.getName())) {
      return false;
    } 
    if (this.publicURI == null) {
      if (other.getPublic() != null)
        return false; 
    } else if (!this.publicURI.equals(other.getPublic())) {
      return false;
    } 
    if (this.systemURI == null) {
      if (other.getSystem() != null)
        return false; 
    } else if (!this.systemURI.equals(other.getSystem())) {
      return false;
    } 
    return true;
  }
  
  public int hashCode() {
    int hash = 0;
    if (null != this.name)
      hash += this.name.hashCode(); 
    if (null != this.publicURI)
      hash += this.publicURI.hashCode(); 
    if (null != this.systemURI)
      hash += this.systemURI.hashCode(); 
    return hash;
  }
  
  private static TypeDesc typeDesc = new TypeDesc(Notation.class);
  
  static  {
    AttributeDesc attributeDesc = new AttributeDesc();
    attributeDesc.setFieldName("name");
    attributeDesc.setXmlName(Constants.XSD_NCNAME);
    typeDesc.addFieldDesc(attributeDesc);
    attributeDesc = new AttributeDesc();
    attributeDesc.setFieldName("public");
    attributeDesc.setXmlName(Constants.XSD_ANYURI);
    typeDesc.addFieldDesc(attributeDesc);
    ElementDesc element = null;
    element = new ElementDesc();
    element.setFieldName("system");
    element.setXmlName(Constants.XSD_ANYURI);
    element.setNillable(true);
    typeDesc.addFieldDesc(attributeDesc);
  }
  
  public static TypeDesc getTypeDesc() { return typeDesc; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Notation.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */