/*     */ package org.apache.axis.types;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import org.apache.axis.utils.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnsignedLong
/*     */   extends Number
/*     */   implements Comparable
/*     */ {
/*  31 */   protected BigInteger lValue = BigInteger.ZERO;
/*  32 */   private static BigInteger MAX = new BigInteger("18446744073709551615");
/*     */ 
/*     */   
/*     */   public UnsignedLong() {}
/*     */ 
/*     */   
/*  38 */   public UnsignedLong(double value) throws NumberFormatException { setValue(new BigInteger(Double.toString(value))); }
/*     */ 
/*     */ 
/*     */   
/*  42 */   public UnsignedLong(BigInteger value) throws NumberFormatException { setValue(value); }
/*     */ 
/*     */ 
/*     */   
/*  46 */   public UnsignedLong(long lValue) throws NumberFormatException { setValue(BigInteger.valueOf(lValue)); }
/*     */ 
/*     */ 
/*     */   
/*  50 */   public UnsignedLong(String stValue) throws NumberFormatException { setValue(new BigInteger(stValue)); }
/*     */ 
/*     */   
/*     */   private void setValue(BigInteger val) throws NumberFormatException {
/*  54 */     if (!isValid(val)) {
/*  55 */       throw new NumberFormatException(Messages.getMessage("badUnsignedLong00") + String.valueOf(val) + "]");
/*     */     }
/*     */ 
/*     */     
/*  59 */     this.lValue = val;
/*     */   }
/*     */   
/*     */   public static boolean isValid(BigInteger value) {
/*  63 */     if (value.compareTo(BigInteger.ZERO) == -1 || value.compareTo(MAX) == 1)
/*     */     {
/*  65 */       return false;
/*     */     }
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */   
/*  71 */   public String toString() { return this.lValue.toString(); }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  75 */     if (this.lValue != null) {
/*  76 */       return this.lValue.hashCode();
/*     */     }
/*  78 */     return 0;
/*     */   }
/*     */   
/*  81 */   private Object __equalsCalc = null;
/*     */   
/*     */   public boolean equals(Object obj) {
/*  84 */     if (!(obj instanceof UnsignedLong)) return false; 
/*  85 */     UnsignedLong other = (UnsignedLong)obj;
/*  86 */     if (obj == null) return false; 
/*  87 */     if (this == obj) return true; 
/*  88 */     if (this.__equalsCalc != null) {
/*  89 */       return (this.__equalsCalc == obj);
/*     */     }
/*  91 */     this.__equalsCalc = obj;
/*     */     
/*  93 */     boolean _equals = ((this.lValue == null && other.lValue == null) || (this.lValue != null && this.lValue.equals(other.lValue)));
/*     */ 
/*     */ 
/*     */     
/*  97 */     this.__equalsCalc = null;
/*  98 */     return _equals;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Object obj) {
/* 103 */     if (this.lValue != null)
/* 104 */       return this.lValue.compareTo(obj); 
/* 105 */     if (equals(obj) == true) {
/* 106 */       return 0;
/*     */     }
/* 108 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public byte byteValue() { return this.lValue.byteValue(); }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public short shortValue() { return this.lValue.shortValue(); }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public int intValue() { return this.lValue.intValue(); }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public long longValue() { return this.lValue.longValue(); }
/*     */ 
/*     */ 
/*     */   
/* 129 */   public double doubleValue() { return this.lValue.doubleValue(); }
/*     */ 
/*     */ 
/*     */   
/* 133 */   public float floatValue() { return this.lValue.floatValue(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\UnsignedLong.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */