package org.apache.axis.types;

import java.math.BigInteger;
import org.apache.axis.utils.Messages;

public class UnsignedLong extends Number implements Comparable {
  protected BigInteger lValue = BigInteger.ZERO;
  
  private static BigInteger MAX = new BigInteger("18446744073709551615");
  
  public UnsignedLong() {}
  
  public UnsignedLong(double value) throws NumberFormatException { setValue(new BigInteger(Double.toString(value))); }
  
  public UnsignedLong(BigInteger value) throws NumberFormatException { setValue(value); }
  
  public UnsignedLong(long lValue) throws NumberFormatException { setValue(BigInteger.valueOf(lValue)); }
  
  public UnsignedLong(String stValue) throws NumberFormatException { setValue(new BigInteger(stValue)); }
  
  private void setValue(BigInteger val) throws NumberFormatException {
    if (!isValid(val))
      throw new NumberFormatException(Messages.getMessage("badUnsignedLong00") + String.valueOf(val) + "]"); 
    this.lValue = val;
  }
  
  public static boolean isValid(BigInteger value) {
    if (value.compareTo(BigInteger.ZERO) == -1 || value.compareTo(MAX) == 1)
      return false; 
    return true;
  }
  
  public String toString() { return this.lValue.toString(); }
  
  public int hashCode() {
    if (this.lValue != null)
      return this.lValue.hashCode(); 
    return 0;
  }
  
  private Object __equalsCalc = null;
  
  public boolean equals(Object obj) {
    if (!(obj instanceof UnsignedLong))
      return false; 
    UnsignedLong other = (UnsignedLong)obj;
    if (obj == null)
      return false; 
    if (this == obj)
      return true; 
    if (this.__equalsCalc != null)
      return (this.__equalsCalc == obj); 
    this.__equalsCalc = obj;
    boolean _equals = ((this.lValue == null && other.lValue == null) || (this.lValue != null && this.lValue.equals(other.lValue)));
    this.__equalsCalc = null;
    return _equals;
  }
  
  public int compareTo(Object obj) {
    if (this.lValue != null)
      return this.lValue.compareTo(obj); 
    if (equals(obj) == true)
      return 0; 
    return 1;
  }
  
  public byte byteValue() { return this.lValue.byteValue(); }
  
  public short shortValue() { return this.lValue.shortValue(); }
  
  public int intValue() { return this.lValue.intValue(); }
  
  public long longValue() { return this.lValue.longValue(); }
  
  public double doubleValue() { return this.lValue.doubleValue(); }
  
  public float floatValue() { return this.lValue.floatValue(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\UnsignedLong.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */