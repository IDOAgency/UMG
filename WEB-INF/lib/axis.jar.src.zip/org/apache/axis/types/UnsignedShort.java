package org.apache.axis.types;

import org.apache.axis.utils.Messages;

public class UnsignedShort extends UnsignedInt {
  public UnsignedShort() {}
  
  public UnsignedShort(long sValue) throws NumberFormatException { setValue(sValue); }
  
  public UnsignedShort(String sValue) throws NumberFormatException { setValue(Long.parseLong(sValue)); }
  
  public void setValue(long sValue) throws NumberFormatException {
    if (!isValid(sValue))
      throw new NumberFormatException(Messages.getMessage("badUnsignedShort00") + String.valueOf(sValue) + "]"); 
    this.lValue = new Long(sValue);
  }
  
  public static boolean isValid(long sValue) {
    if (sValue < 0L || sValue > 65535L)
      return false; 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\UnsignedShort.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */