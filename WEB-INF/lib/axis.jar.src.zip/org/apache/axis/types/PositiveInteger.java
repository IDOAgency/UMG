/*    */ package org.apache.axis.types;
/*    */ 
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ import java.math.BigInteger;
/*    */ import java.util.Random;
/*    */ import org.apache.axis.utils.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PositiveInteger
/*    */   extends NonNegativeInteger
/*    */ {
/*    */   private BigInteger iMinInclusive;
/*    */   
/*    */   public PositiveInteger(byte[] val) {
/* 37 */     super(val);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     this.iMinInclusive = new BigInteger("1"); checkValidity(); } public PositiveInteger(int signum, byte[] magnitude) { super(signum, magnitude); this.iMinInclusive = new BigInteger("1"); checkValidity(); } public PositiveInteger(int bitLength, int certainty, Random rnd) { super(bitLength, certainty, rnd); this.iMinInclusive = new BigInteger("1"); checkValidity(); } public PositiveInteger(int numBits, Random rnd) { super(numBits, rnd); this.iMinInclusive = new BigInteger("1"); checkValidity(); } public PositiveInteger(String val) { super(val); this.iMinInclusive = new BigInteger("1"); checkValidity(); } public PositiveInteger(String val, int radix) { super(val, radix); this.iMinInclusive = new BigInteger("1");
/*    */     checkValidity(); } private void checkValidity() {
/* 71 */     if (compareTo(this.iMinInclusive) < 0) {
/* 72 */       throw new NumberFormatException(Messages.getMessage("badposInt00") + ":  " + this);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 84 */   public Object writeReplace() throws ObjectStreamException { return new BigIntegerRep(toByteArray()); }
/*    */   
/*    */   protected static class BigIntegerRep
/*    */     implements Serializable {
/*    */     private byte[] array;
/*    */     
/* 90 */     protected BigIntegerRep(byte[] array) { this.array = array; }
/*    */ 
/*    */     
/* 93 */     protected Object readResolve() throws ObjectStreamException { return new PositiveInteger(this.array); }
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\PositiveInteger.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */