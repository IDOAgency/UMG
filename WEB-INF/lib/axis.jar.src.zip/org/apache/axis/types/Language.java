/*    */ package org.apache.axis.types;
/*    */ 
/*    */ import org.apache.axis.utils.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Language
/*    */   extends Token
/*    */ {
/*    */   public Language() {}
/*    */   
/*    */   public Language(String stValue) throws IllegalArgumentException {
/*    */     try {
/* 44 */       setValue(stValue);
/*    */     }
/* 46 */     catch (IllegalArgumentException e) {
/*    */       
/* 48 */       throw new IllegalArgumentException(Messages.getMessage("badLanguage00") + "data=[" + stValue + "]");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public static boolean isValid(String stValue) { return true; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Language.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */