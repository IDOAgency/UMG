package org.apache.axis.types;

import org.apache.axis.utils.Messages;

public class Language extends Token {
  public Language() {}
  
  public Language(String stValue) throws IllegalArgumentException {
    try {
      setValue(stValue);
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException(Messages.getMessage("badLanguage00") + "data=[" + stValue + "]");
    } 
  }
  
  public static boolean isValid(String stValue) { return true; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Language.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */