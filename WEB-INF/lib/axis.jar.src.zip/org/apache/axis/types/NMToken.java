package org.apache.axis.types;

import org.apache.axis.utils.Messages;
import org.apache.axis.utils.XMLChar;

public class NMToken extends Token {
  public NMToken() {}
  
  public NMToken(String stValue) throws IllegalArgumentException {
    try {
      setValue(stValue);
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException(Messages.getMessage("badNmtoken00") + "data=[" + stValue + "]");
    } 
  }
  
  public static boolean isValid(String stValue) {
    for (int scan = 0; scan < stValue.length(); scan++) {
      if (!XMLChar.isName(stValue.charAt(scan)))
        return false; 
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\NMToken.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */