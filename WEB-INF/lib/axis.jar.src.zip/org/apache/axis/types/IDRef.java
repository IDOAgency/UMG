/*    */ package org.apache.axis.types;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IDRef
/*    */   extends NCName
/*    */ {
/*    */   public IDRef() {}
/*    */   
/* 35 */   public IDRef(String stValue) throws IllegalArgumentException { super(stValue); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\IDRef.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */