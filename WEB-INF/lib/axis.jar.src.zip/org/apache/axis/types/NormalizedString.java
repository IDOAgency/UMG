package org.apache.axis.types;

import java.io.Serializable;
import org.apache.axis.utils.Messages;

public class NormalizedString implements Serializable {
  String m_value = null;
  
  public NormalizedString() {}
  
  public NormalizedString(String stValue) throws IllegalArgumentException { setValue(stValue); }
  
  public void setValue(String stValue) throws IllegalArgumentException {
    if (!isValid(stValue))
      throw new IllegalArgumentException(Messages.getMessage("badNormalizedString00") + " data=[" + stValue + "]"); 
    this.m_value = stValue;
  }
  
  public String toString() { return this.m_value; }
  
  public int hashCode() { return this.m_value.hashCode(); }
  
  public static boolean isValid(String stValue) {
    for (int scan = 0; scan < stValue.length(); scan++) {
      char cDigit = stValue.charAt(scan);
      switch (cDigit) {
        case '\t':
        case '\n':
        case '\r':
          return false;
      } 
    } 
    return true;
  }
  
  public boolean equals(Object object) {
    String s1 = object.toString();
    return s1.equals(this.m_value);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\NormalizedString.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */