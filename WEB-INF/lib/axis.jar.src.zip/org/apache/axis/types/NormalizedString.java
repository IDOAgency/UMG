/*     */ package org.apache.axis.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.apache.axis.utils.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NormalizedString
/*     */   implements Serializable
/*     */ {
/*  30 */   String m_value = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NormalizedString() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   public NormalizedString(String stValue) throws IllegalArgumentException { setValue(stValue); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String stValue) throws IllegalArgumentException {
/*  53 */     if (!isValid(stValue)) {
/*  54 */       throw new IllegalArgumentException(Messages.getMessage("badNormalizedString00") + " data=[" + stValue + "]");
/*     */     }
/*     */     
/*  57 */     this.m_value = stValue;
/*     */   }
/*     */ 
/*     */   
/*  61 */   public String toString() { return this.m_value; }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public int hashCode() { return this.m_value.hashCode(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isValid(String stValue) {
/*  84 */     for (int scan = 0; scan < stValue.length(); scan++) {
/*  85 */       char cDigit = stValue.charAt(scan);
/*  86 */       switch (cDigit) {
/*     */         case '\t':
/*     */         case '\n':
/*     */         case '\r':
/*  90 */           return false;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/*  95 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(Object object) {
/*  99 */     String s1 = object.toString();
/* 100 */     return s1.equals(this.m_value);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\NormalizedString.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */