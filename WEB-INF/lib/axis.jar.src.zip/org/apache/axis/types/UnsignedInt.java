package org.apache.axis.types;

import org.apache.axis.utils.Messages;

public class UnsignedInt extends Number implements Comparable {
  protected Long lValue = new Long(0L);
  
  public UnsignedInt() {}
  
  public UnsignedInt(long iValue) throws NumberFormatException { setValue(iValue); }
  
  public UnsignedInt(String stValue) throws NumberFormatException { setValue(Long.parseLong(stValue)); }
  
  public void setValue(long iValue) throws NumberFormatException {
    if (!isValid(iValue))
      throw new NumberFormatException(Messages.getMessage("badUnsignedInt00") + String.valueOf(iValue) + "]"); 
    this.lValue = new Long(iValue);
  }
  
  public String toString() {
    if (this.lValue != null)
      return this.lValue.toString(); 
    return null;
  }
  
  public int hashCode() {
    if (this.lValue != null)
      return this.lValue.hashCode(); 
    return 0;
  }
  
  public static boolean isValid(long iValue) {
    if (iValue < 0L || iValue > 4294967295L)
      return false; 
    return true;
  }
  
  private Object __equalsCalc = null;
  
  public boolean equals(Object obj) {
    if (!(obj instanceof UnsignedInt))
      return false; 
    UnsignedInt other = (UnsignedInt)obj;
    if (obj == null)
      return false; 
    if (this == obj)
      return true; 
    if (this.__equalsCalc != null)
      return (this.__equalsCalc == obj); 
    this.__equalsCalc = obj;
    boolean _equals = ((this.lValue == null && other.lValue == null) || (this.lValue != null && this.lValue.equals(other.lValue)));
    this.__equalsCalc = null;
    return _equals;
  }
  
  public int compareTo(Object obj) {
    if (this.lValue != null)
      return this.lValue.compareTo(obj); 
    if (equals(obj) == true)
      return 0; 
    return 1;
  }
  
  public byte byteValue() { return this.lValue.byteValue(); }
  
  public short shortValue() { return this.lValue.shortValue(); }
  
  public int intValue() { return this.lValue.intValue(); }
  
  public long longValue() { return this.lValue.longValue(); }
  
  public double doubleValue() { return this.lValue.doubleValue(); }
  
  public float floatValue() { return this.lValue.floatValue(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\UnsignedInt.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */