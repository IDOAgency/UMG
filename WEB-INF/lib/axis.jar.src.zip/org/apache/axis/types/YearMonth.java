package org.apache.axis.types;

import java.io.Serializable;
import java.text.NumberFormat;
import org.apache.axis.utils.Messages;

public class YearMonth implements Serializable {
  int year;
  
  int month;
  
  String timezone;
  
  public YearMonth(int year, int month) throws NumberFormatException {
    this.timezone = null;
    setValue(year, month);
  }
  
  public YearMonth(int year, int month, String timezone) throws NumberFormatException {
    this.timezone = null;
    setValue(year, month, timezone);
  }
  
  public YearMonth(String source) throws NumberFormatException {
    this.timezone = null;
    int negative = 0;
    if (source.charAt(0) == '-')
      negative = 1; 
    if (source.length() < 7 + negative)
      throw new NumberFormatException(Messages.getMessage("badYearMonth00")); 
    int pos = source.substring(negative).indexOf('-');
    if (pos < 0)
      throw new NumberFormatException(Messages.getMessage("badYearMonth00")); 
    if (negative > 0)
      pos++; 
    setValue(Integer.parseInt(source.substring(0, pos)), Integer.parseInt(source.substring(pos + 1, pos + 3)), source.substring(pos + 3));
  }
  
  public int getYear() { return this.year; }
  
  public void setYear(int year) {
    if (year == 0)
      throw new NumberFormatException(Messages.getMessage("badYearMonth00")); 
    this.year = year;
  }
  
  public int getMonth() { return this.month; }
  
  public void setMonth(int month) {
    if (month < 1 || month > 12)
      throw new NumberFormatException(Messages.getMessage("badYearMonth00")); 
    this.month = month;
  }
  
  public String getTimezone() { return this.timezone; }
  
  public void setTimezone(String timezone) throws NumberFormatException {
    if (timezone != null && timezone.length() > 0) {
      if (timezone.charAt(0) == '+' || timezone.charAt(0) == '-') {
        if (timezone.length() != 6 || !Character.isDigit(timezone.charAt(1)) || !Character.isDigit(timezone.charAt(2)) || timezone.charAt(3) != ':' || !Character.isDigit(timezone.charAt(4)) || !Character.isDigit(timezone.charAt(5)))
          throw new NumberFormatException(Messages.getMessage("badTimezone00")); 
      } else if (!timezone.equals("Z")) {
        throw new NumberFormatException(Messages.getMessage("badTimezone00"));
      } 
      this.timezone = timezone;
    } 
  }
  
  public void setValue(int year, int month, String timezone) throws NumberFormatException {
    setYear(year);
    setMonth(month);
    setTimezone(timezone);
  }
  
  public void setValue(int year, int month) throws NumberFormatException {
    setYear(year);
    setMonth(month);
  }
  
  public String toString() {
    NumberFormat nf = NumberFormat.getInstance();
    nf.setGroupingUsed(false);
    nf.setMinimumIntegerDigits(4);
    String s = nf.format(this.year) + "-";
    nf.setMinimumIntegerDigits(2);
    s = s + nf.format(this.month);
    if (this.timezone != null)
      s = s + this.timezone; 
    return s;
  }
  
  public boolean equals(Object obj) {
    if (!(obj instanceof YearMonth))
      return false; 
    YearMonth other = (YearMonth)obj;
    if (obj == null)
      return false; 
    if (this == obj)
      return true; 
    boolean equals = (this.year == other.year && this.month == other.month);
    if (this.timezone != null)
      equals = (equals && this.timezone.equals(other.timezone)); 
    return equals;
  }
  
  public int hashCode() { return (null == this.timezone) ? (this.month + this.year) : (this.month + this.year ^ this.timezone.hashCode()); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\YearMonth.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */