/*    */ package org.apache.axis.types;
/*    */ 
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ import java.math.BigInteger;
/*    */ import java.util.Random;
/*    */ import org.apache.axis.utils.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonPositiveInteger
/*    */   extends BigInteger
/*    */ {
/*    */   private BigInteger zero;
/*    */   
/*    */   public NonPositiveInteger(byte[] val) {
/* 38 */     super(val);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     this.zero = new BigInteger("0"); checkValidity(); } public NonPositiveInteger(int signum, byte[] magnitude) { super(signum, magnitude); this.zero = new BigInteger("0"); checkValidity(); } public NonPositiveInteger(int bitLength, int certainty, Random rnd) { super(bitLength, certainty, rnd); this.zero = new BigInteger("0"); checkValidity(); } public NonPositiveInteger(int numBits, Random rnd) { super(numBits, rnd); this.zero = new BigInteger("0"); checkValidity(); } public NonPositiveInteger(String val) { super(val); this.zero = new BigInteger("0"); checkValidity(); } public NonPositiveInteger(String val, int radix) { super(val, radix); this.zero = new BigInteger("0");
/*    */     checkValidity(); } private void checkValidity() {
/* 72 */     if (compareTo(this.zero) > 0) {
/* 73 */       throw new NumberFormatException(Messages.getMessage("badNonPosInt00") + ":  " + this);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 85 */   public Object writeReplace() throws ObjectStreamException { return new BigIntegerRep(toByteArray()); }
/*    */   
/*    */   protected static class BigIntegerRep
/*    */     implements Serializable {
/*    */     private byte[] array;
/*    */     
/* 91 */     protected BigIntegerRep(byte[] array) { this.array = array; }
/*    */ 
/*    */     
/* 94 */     protected Object readResolve() throws ObjectStreamException { return new NonPositiveInteger(this.array); }
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\NonPositiveInteger.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */