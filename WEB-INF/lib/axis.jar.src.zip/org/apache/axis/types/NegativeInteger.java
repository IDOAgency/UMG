package org.apache.axis.types;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Random;
import org.apache.axis.utils.Messages;

public class NegativeInteger extends NonPositiveInteger {
  private BigInteger zero;
  
  public NegativeInteger(byte[] val) {
    super(val);
    this.zero = new BigInteger("0");
    checkValidity();
  }
  
  public NegativeInteger(int signum, byte[] magnitude) {
    super(signum, magnitude);
    this.zero = new BigInteger("0");
    checkValidity();
  }
  
  public NegativeInteger(int bitLength, int certainty, Random rnd) {
    super(bitLength, certainty, rnd);
    this.zero = new BigInteger("0");
    checkValidity();
  }
  
  public NegativeInteger(int numBits, Random rnd) {
    super(numBits, rnd);
    this.zero = new BigInteger("0");
    checkValidity();
  }
  
  public NegativeInteger(String val) {
    super(val);
    this.zero = new BigInteger("0");
    checkValidity();
  }
  
  public NegativeInteger(String val, int radix) {
    super(val, radix);
    this.zero = new BigInteger("0");
    checkValidity();
  }
  
  private void checkValidity() {
    if (compareTo(this.zero) >= 0)
      throw new NumberFormatException(Messages.getMessage("badnegInt00") + ":  " + this); 
  }
  
  public Object writeReplace() throws ObjectStreamException { return new BigIntegerRep(toByteArray()); }
  
  protected static class BigIntegerRep implements Serializable {
    private byte[] array;
    
    protected BigIntegerRep(byte[] array) { this.array = array; }
    
    protected Object readResolve() throws ObjectStreamException { return new NegativeInteger(this.array); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\NegativeInteger.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */