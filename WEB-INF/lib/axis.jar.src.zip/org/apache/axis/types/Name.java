package org.apache.axis.types;

import org.apache.axis.utils.Messages;
import org.apache.axis.utils.XMLChar;

public class Name extends Token {
  public Name() {}
  
  public Name(String stValue) throws IllegalArgumentException {
    try {
      setValue(stValue);
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException(Messages.getMessage("badNameType00") + "data=[" + stValue + "]");
    } 
  }
  
  public void setValue(String stValue) throws IllegalArgumentException {
    if (!isValid(stValue))
      throw new IllegalArgumentException(Messages.getMessage("badNameType00") + " data=[" + stValue + "]"); 
    this.m_value = stValue;
  }
  
  public static boolean isValid(String stValue) {
    boolean bValid = true;
    for (int scan = 0; scan < stValue.length(); scan++) {
      if (scan == 0) {
        bValid = XMLChar.isNameStart(stValue.charAt(scan));
      } else {
        bValid = XMLChar.isName(stValue.charAt(scan));
      } 
      if (!bValid)
        break; 
    } 
    return bValid;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Name.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */