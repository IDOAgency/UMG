/*    */ package org.apache.axis.types;
/*    */ 
/*    */ import org.apache.axis.utils.Messages;
/*    */ import org.apache.axis.utils.XMLChar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Name
/*    */   extends Token
/*    */ {
/*    */   public Name() {}
/*    */   
/*    */   public Name(String stValue) throws IllegalArgumentException {
/*    */     try {
/* 43 */       setValue(stValue);
/*    */     }
/* 45 */     catch (IllegalArgumentException e) {
/*    */       
/* 47 */       throw new IllegalArgumentException(Messages.getMessage("badNameType00") + "data=[" + stValue + "]");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(String stValue) throws IllegalArgumentException {
/* 60 */     if (!isValid(stValue)) {
/* 61 */       throw new IllegalArgumentException(Messages.getMessage("badNameType00") + " data=[" + stValue + "]");
/*    */     }
/*    */     
/* 64 */     this.m_value = stValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isValid(String stValue) {
/* 75 */     boolean bValid = true;
/*    */     
/* 77 */     for (int scan = 0; scan < stValue.length(); scan++) {
/* 78 */       if (scan == 0) {
/* 79 */         bValid = XMLChar.isNameStart(stValue.charAt(scan));
/*    */       } else {
/* 81 */         bValid = XMLChar.isName(stValue.charAt(scan));
/* 82 */       }  if (!bValid) {
/*    */         break;
/*    */       }
/*    */     } 
/* 86 */     return bValid;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Name.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */