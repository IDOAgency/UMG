package org.apache.axis.types;

import org.apache.axis.utils.Messages;

public class Id extends NCName {
  public Id() {}
  
  public Id(String stValue) throws IllegalArgumentException {
    try {
      setValue(stValue);
    } catch (IllegalArgumentException e) {
      throw new IllegalArgumentException(Messages.getMessage("badIdType00") + "data=[" + stValue + "]");
    } 
  }
  
  public void setValue(String stValue) throws IllegalArgumentException {
    if (!isValid(stValue))
      throw new IllegalArgumentException(Messages.getMessage("badIdType00") + " data=[" + stValue + "]"); 
    this.m_value = stValue;
  }
  
  public static boolean isValid(String stValue) { return NCName.isValid(stValue); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Id.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */