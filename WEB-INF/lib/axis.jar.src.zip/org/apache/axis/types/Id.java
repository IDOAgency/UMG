/*    */ package org.apache.axis.types;
/*    */ 
/*    */ import org.apache.axis.utils.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Id
/*    */   extends NCName
/*    */ {
/*    */   public Id() {}
/*    */   
/*    */   public Id(String stValue) throws IllegalArgumentException {
/*    */     try {
/* 39 */       setValue(stValue);
/*    */     }
/* 41 */     catch (IllegalArgumentException e) {
/*    */       
/* 43 */       throw new IllegalArgumentException(Messages.getMessage("badIdType00") + "data=[" + stValue + "]");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(String stValue) throws IllegalArgumentException {
/* 56 */     if (!isValid(stValue)) {
/* 57 */       throw new IllegalArgumentException(Messages.getMessage("badIdType00") + " data=[" + stValue + "]");
/*    */     }
/*    */     
/* 60 */     this.m_value = stValue;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   public static boolean isValid(String stValue) { return NCName.isValid(stValue); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Id.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */