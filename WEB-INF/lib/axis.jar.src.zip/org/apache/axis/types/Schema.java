package org.apache.axis.types;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.Arrays;
import javax.xml.namespace.QName;
import org.apache.axis.description.AttributeDesc;
import org.apache.axis.description.TypeDesc;
import org.apache.axis.encoding.Deserializer;
import org.apache.axis.encoding.Serializer;
import org.apache.axis.encoding.ser.BeanDeserializer;
import org.apache.axis.encoding.ser.BeanSerializer;
import org.apache.axis.message.MessageElement;

public class Schema implements Serializable {
  private MessageElement[] _any;
  
  private URI targetNamespace;
  
  private NormalizedString version;
  
  private Id id;
  
  public MessageElement[] get_any() { return this._any; }
  
  public void set_any(MessageElement[] _any) { this._any = _any; }
  
  public URI getTargetNamespace() { return this.targetNamespace; }
  
  public void setTargetNamespace(URI targetNamespace) { this.targetNamespace = targetNamespace; }
  
  public NormalizedString getVersion() { return this.version; }
  
  public void setVersion(NormalizedString version) { this.version = version; }
  
  public Id getId() { return this.id; }
  
  public void setId(Id id) { this.id = id; }
  
  private Object __equalsCalc = null;
  
  public boolean equals(Object obj) {
    if (!(obj instanceof Schema))
      return false; 
    Schema other = (Schema)obj;
    if (obj == null)
      return false; 
    if (this == obj)
      return true; 
    if (this.__equalsCalc != null)
      return (this.__equalsCalc == obj); 
    this.__equalsCalc = obj;
    boolean _equals = (((this._any == null && other.get_any() == null) || (this._any != null && Arrays.equals(this._any, other.get_any()))) && ((this.targetNamespace == null && other.getTargetNamespace() == null) || (this.targetNamespace != null && this.targetNamespace.equals(other.getTargetNamespace()))) && ((this.version == null && other.getVersion() == null) || (this.version != null && this.version.equals(other.getVersion()))) && ((this.id == null && other.getId() == null) || (this.id != null && this.id.equals(other.getId()))));
    this.__equalsCalc = null;
    return _equals;
  }
  
  private boolean __hashCodeCalc = false;
  
  public int hashCode() {
    if (this.__hashCodeCalc)
      return 0; 
    this.__hashCodeCalc = true;
    int _hashCode = 1;
    if (get_any() != null) {
      int i = 0;
      for (; i < Array.getLength(get_any()); 
        i++) {
        Object obj = Array.get(get_any(), i);
        if (obj != null && !obj.getClass().isArray())
          _hashCode += obj.hashCode(); 
      } 
    } 
    if (getTargetNamespace() != null)
      _hashCode += getTargetNamespace().hashCode(); 
    if (getVersion() != null)
      _hashCode += getVersion().hashCode(); 
    if (getId() != null)
      _hashCode += getId().hashCode(); 
    this.__hashCodeCalc = false;
    return _hashCode;
  }
  
  private static TypeDesc typeDesc = new TypeDesc(Schema.class);
  
  static  {
    AttributeDesc attributeDesc = new AttributeDesc();
    attributeDesc.setFieldName("targetNamespace");
    attributeDesc.setXmlName(new QName("", "targetNamespace"));
    attributeDesc.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "anyURI"));
    typeDesc.addFieldDesc(attributeDesc);
    attributeDesc = new AttributeDesc();
    attributeDesc.setFieldName("version");
    attributeDesc.setXmlName(new QName("", "version"));
    attributeDesc.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "normalizedString"));
    typeDesc.addFieldDesc(attributeDesc);
    attributeDesc = new AttributeDesc();
    attributeDesc.setFieldName("id");
    attributeDesc.setXmlName(new QName("", "id"));
    attributeDesc.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "ID"));
    typeDesc.addFieldDesc(attributeDesc);
  }
  
  public static TypeDesc getTypeDesc() { return typeDesc; }
  
  public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) { return new BeanSerializer(_javaType, _xmlType, typeDesc); }
  
  public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) { return new BeanDeserializer(_javaType, _xmlType, typeDesc); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Schema.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */