/*     */ package org.apache.axis.types;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.AttributeDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ import org.apache.axis.message.MessageElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Schema
/*     */   implements Serializable
/*     */ {
/*     */   private MessageElement[] _any;
/*     */   private URI targetNamespace;
/*     */   private NormalizedString version;
/*     */   private Id id;
/*     */   
/*  34 */   public MessageElement[] get_any() { return this._any; }
/*     */ 
/*     */ 
/*     */   
/*  38 */   public void set_any(MessageElement[] _any) { this._any = _any; }
/*     */ 
/*     */ 
/*     */   
/*  42 */   public URI getTargetNamespace() { return this.targetNamespace; }
/*     */ 
/*     */ 
/*     */   
/*  46 */   public void setTargetNamespace(URI targetNamespace) { this.targetNamespace = targetNamespace; }
/*     */ 
/*     */ 
/*     */   
/*  50 */   public NormalizedString getVersion() { return this.version; }
/*     */ 
/*     */ 
/*     */   
/*  54 */   public void setVersion(NormalizedString version) { this.version = version; }
/*     */ 
/*     */ 
/*     */   
/*  58 */   public Id getId() { return this.id; }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public void setId(Id id) { this.id = id; }
/*     */ 
/*     */   
/*  65 */   private Object __equalsCalc = null;
/*     */   
/*     */   public boolean equals(Object obj) {
/*  68 */     if (!(obj instanceof Schema)) return false; 
/*  69 */     Schema other = (Schema)obj;
/*  70 */     if (obj == null) return false; 
/*  71 */     if (this == obj) return true; 
/*  72 */     if (this.__equalsCalc != null) {
/*  73 */       return (this.__equalsCalc == obj);
/*     */     }
/*  75 */     this.__equalsCalc = obj;
/*     */     
/*  77 */     boolean _equals = (((this._any == null && other.get_any() == null) || (this._any != null && Arrays.equals(this._any, other.get_any()))) && ((this.targetNamespace == null && other.getTargetNamespace() == null) || (this.targetNamespace != null && this.targetNamespace.equals(other.getTargetNamespace()))) && ((this.version == null && other.getVersion() == null) || (this.version != null && this.version.equals(other.getVersion()))) && ((this.id == null && other.getId() == null) || (this.id != null && this.id.equals(other.getId()))));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     this.__equalsCalc = null;
/*  91 */     return _equals;
/*     */   }
/*     */   
/*     */   private boolean __hashCodeCalc = false;
/*     */   
/*     */   public int hashCode() {
/*  97 */     if (this.__hashCodeCalc) {
/*  98 */       return 0;
/*     */     }
/* 100 */     this.__hashCodeCalc = true;
/* 101 */     int _hashCode = 1;
/* 102 */     if (get_any() != null) {
/* 103 */       int i = 0;
/* 104 */       for (; i < Array.getLength(get_any()); 
/* 105 */         i++) {
/* 106 */         Object obj = Array.get(get_any(), i);
/* 107 */         if (obj != null && !obj.getClass().isArray())
/*     */         {
/* 109 */           _hashCode += obj.hashCode();
/*     */         }
/*     */       } 
/*     */     } 
/* 113 */     if (getTargetNamespace() != null) {
/* 114 */       _hashCode += getTargetNamespace().hashCode();
/*     */     }
/* 116 */     if (getVersion() != null) {
/* 117 */       _hashCode += getVersion().hashCode();
/*     */     }
/* 119 */     if (getId() != null) {
/* 120 */       _hashCode += getId().hashCode();
/*     */     }
/* 122 */     this.__hashCodeCalc = false;
/* 123 */     return _hashCode;
/*     */   }
/*     */ 
/*     */   
/* 127 */   private static TypeDesc typeDesc = new TypeDesc(Schema.class);
/*     */ 
/*     */   
/*     */   static  {
/* 131 */     AttributeDesc attributeDesc = new AttributeDesc();
/* 132 */     attributeDesc.setFieldName("targetNamespace");
/* 133 */     attributeDesc.setXmlName(new QName("", "targetNamespace"));
/* 134 */     attributeDesc.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "anyURI"));
/* 135 */     typeDesc.addFieldDesc(attributeDesc);
/* 136 */     attributeDesc = new AttributeDesc();
/* 137 */     attributeDesc.setFieldName("version");
/* 138 */     attributeDesc.setXmlName(new QName("", "version"));
/* 139 */     attributeDesc.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "normalizedString"));
/* 140 */     typeDesc.addFieldDesc(attributeDesc);
/* 141 */     attributeDesc = new AttributeDesc();
/* 142 */     attributeDesc.setFieldName("id");
/* 143 */     attributeDesc.setXmlName(new QName("", "id"));
/* 144 */     attributeDesc.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "ID"));
/* 145 */     typeDesc.addFieldDesc(attributeDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public static TypeDesc getTypeDesc() { return typeDesc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType) { return new BeanSerializer(_javaType, _xmlType, typeDesc); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType) { return new BeanDeserializer(_javaType, _xmlType, typeDesc); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\types\Schema.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */