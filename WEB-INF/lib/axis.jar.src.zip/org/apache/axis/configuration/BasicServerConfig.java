/*    */ package org.apache.axis.configuration;
/*    */ 
/*    */ import org.apache.axis.SimpleTargetedChain;
/*    */ import org.apache.axis.transport.local.LocalResponder;
/*    */ import org.apache.axis.transport.local.LocalSender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicServerConfig
/*    */   extends SimpleProvider
/*    */ {
/*    */   public BasicServerConfig() {
/* 34 */     LocalResponder localResponder = new LocalResponder();
/* 35 */     SimpleTargetedChain transport = new SimpleTargetedChain(null, null, localResponder);
/* 36 */     deployTransport("local", transport);
/* 37 */     deployTransport("java", new SimpleTargetedChain(new LocalSender()));
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\BasicServerConfig.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */