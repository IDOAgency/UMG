package org.apache.axis.configuration;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.apache.axis.AxisProperties;
import org.apache.axis.EngineConfigurationFactory;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.discovery.ResourceClassIterator;
import org.apache.commons.discovery.tools.ClassUtils;
import org.apache.commons.logging.Log;

public class EngineConfigurationFactoryFinder {
  protected static Log log = LogFactory.getLog(EngineConfigurationFactoryFinder.class.getName());
  
  private static final Class mySpi = EngineConfigurationFactory.class;
  
  private static final Class[] newFactoryParamTypes = { Object.class };
  
  private static final String requiredMethod = "public static EngineConfigurationFactory newFactory(Object)";
  
  static  {
    AxisProperties.setClassOverrideProperty(EngineConfigurationFactory.class, "axis.EngineConfigFactory");
    AxisProperties.setClassDefaults(EngineConfigurationFactory.class, new String[] { "org.apache.axis.configuration.EngineConfigurationFactoryServlet", "org.apache.axis.configuration.EngineConfigurationFactoryDefault" });
  }
  
  public static EngineConfigurationFactory newFactory(Object obj) {
    Object[] params = { obj };
    return (EngineConfigurationFactory)AccessController.doPrivileged(new PrivilegedAction(params) {
          private final Object[] val$params;
          
          public Object run() {
            ResourceClassIterator services = AxisProperties.getResourceClassIterator(mySpi);
            EngineConfigurationFactory factory = null;
            while (factory == null && services.hasNext()) {
              try {
                Class service = services.nextResourceClass().loadClass();
                if (service != null)
                  factory = EngineConfigurationFactoryFinder.newFactory(service, newFactoryParamTypes, this.val$params); 
              } catch (Exception e) {}
            } 
            if (factory != null) {
              if (EngineConfigurationFactoryFinder.log.isDebugEnabled())
                EngineConfigurationFactoryFinder.log.debug(Messages.getMessage("engineFactory", factory.getClass().getName())); 
            } else {
              EngineConfigurationFactoryFinder.log.error(Messages.getMessage("engineConfigFactoryMissing"));
            } 
            return factory;
          }
        });
  }
  
  public static EngineConfigurationFactory newFactory() { return newFactory(null); }
  
  private static EngineConfigurationFactory newFactory(Class service, Class[] paramTypes, Object[] param) {
    try {
      Method method = ClassUtils.findPublicStaticMethod(service, EngineConfigurationFactory.class, "newFactory", paramTypes);
      if (method == null) {
        log.warn(Messages.getMessage("engineConfigMissingNewFactory", service.getName(), "public static EngineConfigurationFactory newFactory(Object)"));
      } else {
        try {
          return (EngineConfigurationFactory)method.invoke(null, param);
        } catch (InvocationTargetException e) {
          if (e.getTargetException() instanceof NoClassDefFoundError) {
            log.debug(Messages.getMessage("engineConfigLoadFactory", service.getName()));
          } else {
            log.warn(Messages.getMessage("engineConfigInvokeNewFactory", service.getName(), "public static EngineConfigurationFactory newFactory(Object)"), e);
          } 
        } catch (Exception e) {
          log.warn(Messages.getMessage("engineConfigInvokeNewFactory", service.getName(), "public static EngineConfigurationFactory newFactory(Object)"), e);
        } 
      } 
    } catch (NoClassDefFoundError e) {
      log.debug(Messages.getMessage("engineConfigLoadFactory", service.getName()));
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\EngineConfigurationFactoryFinder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */