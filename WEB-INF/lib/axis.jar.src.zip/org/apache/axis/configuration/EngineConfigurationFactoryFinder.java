/*     */ package org.apache.axis.configuration;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import org.apache.axis.AxisProperties;
/*     */ import org.apache.axis.EngineConfigurationFactory;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.commons.discovery.ResourceClassIterator;
/*     */ import org.apache.commons.discovery.tools.ClassUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EngineConfigurationFactoryFinder
/*     */ {
/*  48 */   protected static Log log = LogFactory.getLog(EngineConfigurationFactoryFinder.class.getName());
/*     */ 
/*     */   
/*  51 */   private static final Class mySpi = EngineConfigurationFactory.class;
/*     */   
/*  53 */   private static final Class[] newFactoryParamTypes = { Object.class };
/*     */ 
/*     */   
/*     */   private static final String requiredMethod = "public static EngineConfigurationFactory newFactory(Object)";
/*     */ 
/*     */   
/*     */   static  {
/*  60 */     AxisProperties.setClassOverrideProperty(EngineConfigurationFactory.class, "axis.EngineConfigFactory");
/*     */ 
/*     */ 
/*     */     
/*  64 */     AxisProperties.setClassDefaults(EngineConfigurationFactory.class, new String[] { "org.apache.axis.configuration.EngineConfigurationFactoryServlet", "org.apache.axis.configuration.EngineConfigurationFactoryDefault" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EngineConfigurationFactory newFactory(Object obj) {
/* 108 */     Object[] params = { obj };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     return (EngineConfigurationFactory)AccessController.doPrivileged(new PrivilegedAction(params)
/*     */         {
/*     */           public Object run() {
/* 116 */             ResourceClassIterator services = AxisProperties.getResourceClassIterator(mySpi);
/*     */             
/* 118 */             EngineConfigurationFactory factory = null;
/*     */             
/* 120 */             while (factory == null && services.hasNext()) {
/*     */               try {
/* 122 */                 Class service = services.nextResourceClass().loadClass();
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 127 */                 if (service != null) {
/* 128 */                   factory = EngineConfigurationFactoryFinder.newFactory(service, newFactoryParamTypes, this.val$params);
/*     */                 }
/* 130 */               } catch (Exception e) {}
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 139 */             if (factory != null) {
/* 140 */               if (EngineConfigurationFactoryFinder.log.isDebugEnabled()) {
/* 141 */                 EngineConfigurationFactoryFinder.log.debug(Messages.getMessage("engineFactory", factory.getClass().getName()));
/*     */               }
/*     */             } else {
/* 144 */               EngineConfigurationFactoryFinder.log.error(Messages.getMessage("engineConfigFactoryMissing"));
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 154 */             return factory;
/*     */           }
/*     */           private final Object[] val$params;
/*     */         });
/*     */   }
/*     */   
/* 160 */   public static EngineConfigurationFactory newFactory() { return newFactory(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static EngineConfigurationFactory newFactory(Class service, Class[] paramTypes, Object[] param) {
/*     */     try {
/* 178 */       Method method = ClassUtils.findPublicStaticMethod(service, EngineConfigurationFactory.class, "newFactory", paramTypes);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 183 */       if (method == null) {
/* 184 */         log.warn(Messages.getMessage("engineConfigMissingNewFactory", service.getName(), "public static EngineConfigurationFactory newFactory(Object)"));
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 189 */           return (EngineConfigurationFactory)method.invoke(null, param);
/* 190 */         } catch (InvocationTargetException e) {
/* 191 */           if (e.getTargetException() instanceof NoClassDefFoundError) {
/* 192 */             log.debug(Messages.getMessage("engineConfigLoadFactory", service.getName()));
/*     */           } else {
/*     */             
/* 195 */             log.warn(Messages.getMessage("engineConfigInvokeNewFactory", service.getName(), "public static EngineConfigurationFactory newFactory(Object)"), e);
/*     */           }
/*     */         
/*     */         }
/* 199 */         catch (Exception e) {
/* 200 */           log.warn(Messages.getMessage("engineConfigInvokeNewFactory", service.getName(), "public static EngineConfigurationFactory newFactory(Object)"), e);
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 205 */     } catch (NoClassDefFoundError e) {
/* 206 */       log.debug(Messages.getMessage("engineConfigLoadFactory", service.getName()));
/*     */     } 
/*     */ 
/*     */     
/* 210 */     return null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\EngineConfigurationFactoryFinder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */