package org.apache.axis.configuration;

import org.apache.axis.SimpleTargetedChain;
import org.apache.axis.transport.http.HTTPSender;
import org.apache.axis.transport.java.JavaSender;
import org.apache.axis.transport.local.LocalSender;

public class BasicClientConfig extends SimpleProvider {
  public BasicClientConfig() {
    deployTransport("java", new SimpleTargetedChain(new JavaSender()));
    deployTransport("local", new SimpleTargetedChain(new LocalSender()));
    deployTransport("http", new SimpleTargetedChain(new HTTPSender()));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\BasicClientConfig.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */