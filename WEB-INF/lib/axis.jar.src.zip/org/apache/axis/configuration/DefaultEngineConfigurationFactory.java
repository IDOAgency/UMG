package org.apache.axis.configuration;

import org.apache.axis.EngineConfiguration;
import org.apache.axis.EngineConfigurationFactory;

public class DefaultEngineConfigurationFactory implements EngineConfigurationFactory {
  protected final EngineConfigurationFactory factory;
  
  protected DefaultEngineConfigurationFactory(EngineConfigurationFactory factory) { this.factory = factory; }
  
  public DefaultEngineConfigurationFactory() { this(EngineConfigurationFactoryFinder.newFactory()); }
  
  public EngineConfiguration getClientEngineConfig() { return (this.factory == null) ? null : this.factory.getClientEngineConfig(); }
  
  public EngineConfiguration getServerEngineConfig() { return (this.factory == null) ? null : this.factory.getServerEngineConfig(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\DefaultEngineConfigurationFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */