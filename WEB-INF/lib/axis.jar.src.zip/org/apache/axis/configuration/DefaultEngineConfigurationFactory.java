/*    */ package org.apache.axis.configuration;
/*    */ 
/*    */ import org.apache.axis.EngineConfiguration;
/*    */ import org.apache.axis.EngineConfigurationFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultEngineConfigurationFactory
/*    */   implements EngineConfigurationFactory
/*    */ {
/*    */   protected final EngineConfigurationFactory factory;
/*    */   
/* 38 */   protected DefaultEngineConfigurationFactory(EngineConfigurationFactory factory) { this.factory = factory; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   public DefaultEngineConfigurationFactory() { this(EngineConfigurationFactoryFinder.newFactory()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public EngineConfiguration getClientEngineConfig() { return (this.factory == null) ? null : this.factory.getClientEngineConfig(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public EngineConfiguration getServerEngineConfig() { return (this.factory == null) ? null : this.factory.getServerEngineConfig(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\DefaultEngineConfigurationFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */