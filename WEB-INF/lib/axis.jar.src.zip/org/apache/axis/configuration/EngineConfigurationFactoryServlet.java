package org.apache.axis.configuration;

import java.io.File;
import java.io.InputStream;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import org.apache.axis.AxisProperties;
import org.apache.axis.ConfigurationException;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.EngineConfigurationFactory;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class EngineConfigurationFactoryServlet extends EngineConfigurationFactoryDefault {
  protected static Log log = LogFactory.getLog(EngineConfigurationFactoryServlet.class.getName());
  
  private ServletConfig cfg;
  
  public static EngineConfigurationFactory newFactory(Object param) { return (param instanceof ServletConfig) ? new EngineConfigurationFactoryServlet((ServletConfig)param) : null; }
  
  protected EngineConfigurationFactoryServlet(ServletConfig conf) { this.cfg = conf; }
  
  public EngineConfiguration getServerEngineConfig() { return getServerEngineConfig(this.cfg); }
  
  private static EngineConfiguration getServerEngineConfig(ServletConfig cfg) {
    ServletContext ctx = cfg.getServletContext();
    String configFile = cfg.getInitParameter("axis.ServerConfigFile");
    if (configFile == null)
      configFile = AxisProperties.getProperty("axis.ServerConfigFile"); 
    if (configFile == null)
      configFile = "server-config.wsdd"; 
    String appWebInfPath = "/WEB-INF";
    FileProvider config = null;
    String realWebInfPath = ctx.getRealPath(appWebInfPath);
    if (realWebInfPath == null || !(new File(realWebInfPath, configFile)).exists()) {
      String name = appWebInfPath + "/" + configFile;
      InputStream is = ctx.getResourceAsStream(name);
      if (is != null)
        config = new FileProvider(is); 
      if (config == null)
        log.error(Messages.getMessage("servletEngineWebInfError03", name)); 
    } 
    if (config == null && realWebInfPath != null)
      try {
        config = new FileProvider(realWebInfPath, configFile);
      } catch (ConfigurationException e) {
        log.error(Messages.getMessage("servletEngineWebInfError00"), e);
      }  
    if (config == null) {
      log.warn(Messages.getMessage("servletEngineWebInfWarn00"));
      try {
        InputStream is = ClassUtils.getResourceAsStream(org.apache.axis.server.AxisServer.class, "server-config.wsdd");
        config = new FileProvider(is);
      } catch (Exception e) {
        log.error(Messages.getMessage("servletEngineWebInfError02"), e);
      } 
    } 
    return config;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\EngineConfigurationFactoryServlet.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */