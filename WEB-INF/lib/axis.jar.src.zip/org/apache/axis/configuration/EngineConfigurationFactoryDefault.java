package org.apache.axis.configuration;

import org.apache.axis.AxisProperties;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.EngineConfigurationFactory;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class EngineConfigurationFactoryDefault implements EngineConfigurationFactory {
  protected static Log log = LogFactory.getLog(EngineConfigurationFactoryDefault.class.getName());
  
  public static final String OPTION_CLIENT_CONFIG_FILE = "axis.ClientConfigFile";
  
  public static final String OPTION_SERVER_CONFIG_FILE = "axis.ServerConfigFile";
  
  protected static final String CLIENT_CONFIG_FILE = "client-config.wsdd";
  
  protected static final String SERVER_CONFIG_FILE = "server-config.wsdd";
  
  public static EngineConfigurationFactory newFactory(Object param) {
    if (param != null)
      return null; 
    return new EngineConfigurationFactoryDefault();
  }
  
  protected String clientConfigFile = AxisProperties.getProperty("axis.ClientConfigFile", "client-config.wsdd");
  
  protected String serverConfigFile = AxisProperties.getProperty("axis.ServerConfigFile", "server-config.wsdd");
  
  public EngineConfiguration getClientEngineConfig() { return new FileProvider(this.clientConfigFile); }
  
  public EngineConfiguration getServerEngineConfig() { return new FileProvider(this.serverConfigFile); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\EngineConfigurationFactoryDefault.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */