/*     */ package org.apache.axis.configuration;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.AxisEngine;
/*     */ import org.apache.axis.ConfigurationException;
/*     */ import org.apache.axis.Handler;
/*     */ import org.apache.axis.WSDDEngineConfiguration;
/*     */ import org.apache.axis.deployment.wsdd.WSDDDeployment;
/*     */ import org.apache.axis.deployment.wsdd.WSDDDocument;
/*     */ import org.apache.axis.deployment.wsdd.WSDDGlobalConfiguration;
/*     */ import org.apache.axis.encoding.TypeMappingRegistry;
/*     */ import org.apache.axis.handlers.soap.SOAPService;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.axis.utils.XMLUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirProvider
/*     */   implements WSDDEngineConfiguration
/*     */ {
/*  49 */   protected static Log log = LogFactory.getLog(DirProvider.class.getName());
/*     */ 
/*     */   
/*  52 */   private WSDDDeployment deployment = null;
/*     */   
/*     */   private String configFile;
/*     */   
/*     */   private File dir;
/*     */   
/*     */   private static final String SERVER_CONFIG_FILE = "server-config.wsdd";
/*     */ 
/*     */   
/*  61 */   public DirProvider(String basepath) throws ConfigurationException { this(basepath, "server-config.wsdd"); }
/*     */ 
/*     */ 
/*     */   
/*     */   public DirProvider(String basepath, String configFile) throws ConfigurationException {
/*  66 */     File dir = new File(basepath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (!dir.exists() || !dir.isDirectory() || !dir.canRead()) {
/*  73 */       throw new ConfigurationException(Messages.getMessage("invalidConfigFilePath", basepath));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.dir = dir;
/*  79 */     this.configFile = configFile;
/*     */   }
/*     */ 
/*     */   
/*  83 */   public WSDDDeployment getDeployment() { return this.deployment; }
/*     */   
/*     */   private static class DirFilter implements FileFilter {
/*     */     private DirFilter() {}
/*     */     
/*  88 */     public boolean accept(File path) { return path.isDirectory(); }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureEngine(AxisEngine engine) throws ConfigurationException {
/*  94 */     this.deployment = new WSDDDeployment();
/*  95 */     WSDDGlobalConfiguration config = new WSDDGlobalConfiguration();
/*  96 */     config.setOptionsHashtable(new Hashtable());
/*  97 */     this.deployment.setGlobalConfiguration(config);
/*  98 */     File[] dirs = this.dir.listFiles(new DirFilter(null));
/*  99 */     for (int i = 0; i < dirs.length; i++) {
/* 100 */       processWSDD(dirs[i]);
/*     */     }
/* 102 */     this.deployment.configureEngine(engine);
/* 103 */     engine.refreshGlobalOptions();
/*     */   }
/*     */ 
/*     */   
/*     */   private void processWSDD(File dir) throws ConfigurationException {
/* 108 */     File file = new File(dir, this.configFile);
/* 109 */     if (!file.exists()) {
/*     */       return;
/*     */     }
/* 112 */     log.debug("Loading service configuration from file: " + file);
/* 113 */     InputStream in = null;
/*     */     try {
/* 115 */       in = new FileInputStream(file);
/* 116 */       WSDDDocument doc = new WSDDDocument(XMLUtils.newDocument(in));
/* 117 */       doc.deploy(this.deployment);
/* 118 */     } catch (Exception e) {
/* 119 */       throw new ConfigurationException(e);
/*     */     } finally {
/* 121 */       if (in != null) {
/*     */         try {
/* 123 */           in.close();
/* 124 */         } catch (IOException e) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEngineConfig(AxisEngine engine) throws ConfigurationException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public Handler getHandler(QName qname) throws ConfigurationException { return this.deployment.getHandler(qname); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPService getService(QName qname) throws ConfigurationException {
/* 156 */     SOAPService service = this.deployment.getService(qname);
/* 157 */     if (service == null) {
/* 158 */       throw new ConfigurationException(Messages.getMessage("noService10", qname.toString()));
/*     */     }
/*     */     
/* 161 */     return service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public SOAPService getServiceByNamespaceURI(String namespace) throws ConfigurationException { return this.deployment.getServiceByNamespaceURI(namespace); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public Handler getTransport(QName qname) throws ConfigurationException { return this.deployment.getTransport(qname); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public TypeMappingRegistry getTypeMappingRegistry() throws ConfigurationException { return this.deployment.getTypeMappingRegistry(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public Handler getGlobalRequest() throws ConfigurationException { return this.deployment.getGlobalRequest(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   public Handler getGlobalResponse() throws ConfigurationException { return this.deployment.getGlobalResponse(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Hashtable getGlobalOptions() throws ConfigurationException {
/* 208 */     WSDDGlobalConfiguration globalConfig = this.deployment.getGlobalConfiguration();
/*     */ 
/*     */     
/* 211 */     if (globalConfig != null) {
/* 212 */       return globalConfig.getParametersTable();
/*     */     }
/* 214 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   public Iterator getDeployedServices() throws ConfigurationException { return this.deployment.getDeployedServices(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public List getRoles() { return this.deployment.getRoles(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\DirProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */