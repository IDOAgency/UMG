package org.apache.axis.configuration;

import java.io.ByteArrayInputStream;
import org.apache.axis.AxisEngine;
import org.apache.axis.ConfigurationException;

public class XMLStringProvider extends FileProvider {
  String xmlConfiguration;
  
  public XMLStringProvider(String xmlConfiguration) {
    super(new ByteArrayInputStream(xmlConfiguration.getBytes()));
    this.xmlConfiguration = xmlConfiguration;
  }
  
  public void writeEngineConfig(AxisEngine engine) throws ConfigurationException {}
  
  public void configureEngine(AxisEngine engine) throws ConfigurationException {
    setInputStream(new ByteArrayInputStream(this.xmlConfiguration.getBytes()));
    super.configureEngine(engine);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\configuration\XMLStringProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */