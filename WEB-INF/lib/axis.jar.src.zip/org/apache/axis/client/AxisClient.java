package org.apache.axis.client;

import java.util.List;
import javax.xml.namespace.QName;
import javax.xml.rpc.handler.HandlerChain;
import javax.xml.rpc.handler.HandlerRegistry;
import org.apache.axis.AxisEngine;
import org.apache.axis.AxisFault;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.configuration.EngineConfigurationFactoryFinder;
import org.apache.axis.handlers.HandlerInfoChainFactory;
import org.apache.axis.handlers.soap.MustUnderstandChecker;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class AxisClient extends AxisEngine {
  protected static Log log = LogFactory.getLog(AxisClient.class.getName());
  
  MustUnderstandChecker checker = new MustUnderstandChecker(null);
  
  public AxisClient(EngineConfiguration config) { super(config); }
  
  public AxisClient() { this(EngineConfigurationFactoryFinder.newFactory().getClientEngineConfig()); }
  
  public AxisEngine getClientEngine() { return this; }
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug("Enter: AxisClient::invoke"); 
    String hName = null;
    Handler h = null;
    HandlerChain handlerImpl = null;
    MessageContext previousContext = getCurrentMessageContext();
    try {
      setCurrentMessageContext(msgContext);
      hName = msgContext.getStrProp("engine.handler");
      if (log.isDebugEnabled())
        log.debug("EngineHandler: " + hName); 
      if (hName != null) {
        h = getHandler(hName);
        if (h != null) {
          h.invoke(msgContext);
        } else {
          throw new AxisFault("Client.error", Messages.getMessage("noHandler00", hName), null, null);
        } 
      } else {
        SOAPService service = null;
        msgContext.setPastPivot(false);
        service = msgContext.getService();
        if (service != null) {
          h = service.getRequestHandler();
          if (h != null)
            h.invoke(msgContext); 
        } 
        if ((h = getGlobalRequest()) != null)
          h.invoke(msgContext); 
        handlerImpl = getJAXRPChandlerChain(msgContext);
        if (handlerImpl != null)
          try {
            if (!handlerImpl.handleRequest(msgContext))
              msgContext.setPastPivot(true); 
          } catch (RuntimeException re) {
            handlerImpl.destroy();
            throw re;
          }  
        if (!msgContext.getPastPivot()) {
          hName = msgContext.getTransportName();
          if (hName != null && (h = getTransport(hName)) != null) {
            try {
              h.invoke(msgContext);
            } catch (AxisFault e) {
              throw e;
            } 
          } else {
            throw new AxisFault(Messages.getMessage("noTransport00", hName));
          } 
        } 
        msgContext.setPastPivot(true);
        if (!msgContext.isPropertyTrue("axis.one.way")) {
          if (handlerImpl != null && !msgContext.isPropertyTrue("axis.one.way"))
            try {
              handlerImpl.handleResponse(msgContext);
            } catch (RuntimeException ex) {
              handlerImpl.destroy();
              throw ex;
            }  
          if ((h = getGlobalResponse()) != null)
            h.invoke(msgContext); 
          if (service != null) {
            h = service.getResponseHandler();
            if (h != null)
              h.invoke(msgContext); 
          } 
          if (msgContext.isPropertyTrue("call.CheckMustUnderstand", true))
            this.checker.invoke(msgContext); 
        } 
      } 
    } catch (Exception e) {
      if (e instanceof AxisFault)
        throw (AxisFault)e; 
      log.debug(Messages.getMessage("exception00"), e);
      throw AxisFault.makeFault(e);
    } finally {
      if (handlerImpl != null)
        handlerImpl.destroy(); 
      setCurrentMessageContext(previousContext);
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: AxisClient::invoke"); 
  }
  
  protected HandlerChain getJAXRPChandlerChain(MessageContext context) {
    List chain = null;
    HandlerInfoChainFactory hiChainFactory = null;
    boolean clientSpecified = false;
    Service service = (Service)context.getProperty("wsdl.service");
    if (service == null)
      return null; 
    QName portName = (QName)context.getProperty("wsdl.portName");
    if (portName == null)
      return null; 
    HandlerRegistry registry = service.getHandlerRegistry();
    if (registry != null) {
      chain = registry.getHandlerChain(portName);
      if (chain != null && !chain.isEmpty()) {
        hiChainFactory = new HandlerInfoChainFactory(chain);
        clientSpecified = true;
      } 
    } 
    if (!clientSpecified) {
      SOAPService soapService = context.getService();
      if (soapService != null)
        hiChainFactory = (HandlerInfoChainFactory)soapService.getOption("handlerInfoChain"); 
    } 
    if (hiChainFactory == null)
      return null; 
    return hiChainFactory.createHandlerChain();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\AxisClient.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */