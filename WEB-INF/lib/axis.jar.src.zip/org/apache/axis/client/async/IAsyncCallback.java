package org.apache.axis.client.async;

public interface IAsyncCallback {
  void onCompletion(IAsyncResult paramIAsyncResult);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\async\IAsyncCallback.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */