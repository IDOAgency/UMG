package org.apache.axis.client.async;

import javax.xml.namespace.QName;
import org.apache.axis.client.Call;

public class AsyncCall {
  private Call call;
  
  private IAsyncCallback callback;
  
  public AsyncCall(Call call) { this(call, null); }
  
  public AsyncCall(Call call, IAsyncCallback callback) {
    this.call = null;
    this.callback = null;
    this.call = call;
    this.callback = callback;
  }
  
  public IAsyncCallback getCallback() { return this.callback; }
  
  public void setCallback(IAsyncCallback callback) { this.callback = callback; }
  
  public IAsyncResult invoke(Object[] inputParams) { return new AsyncResult(this, null, inputParams); }
  
  public IAsyncResult invoke(QName qName, Object[] inputParams) { return new AsyncResult(this, qName, inputParams); }
  
  public Call getCall() { return this.call; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\async\AsyncCall.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */