/*     */ package org.apache.axis.client.async;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.client.Call;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncCall
/*     */ {
/*     */   private Call call;
/*     */   private IAsyncCallback callback;
/*     */   
/*  46 */   public AsyncCall(Call call) { this(call, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsyncCall(Call call, IAsyncCallback callback) {
/*     */     this.call = null;
/*     */     this.callback = null;
/*  56 */     this.call = call;
/*  57 */     this.callback = callback;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public IAsyncCallback getCallback() { return this.callback; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public void setCallback(IAsyncCallback callback) { this.callback = callback; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public IAsyncResult invoke(Object[] inputParams) { return new AsyncResult(this, null, inputParams); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public IAsyncResult invoke(QName qName, Object[] inputParams) { return new AsyncResult(this, qName, inputParams); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public Call getCall() { return this.call; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\async\AsyncCall.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */