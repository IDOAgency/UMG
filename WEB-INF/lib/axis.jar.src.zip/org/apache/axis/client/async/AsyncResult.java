/*     */ package org.apache.axis.client.async;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncResult
/*     */   implements IAsyncResult, Runnable
/*     */ {
/*     */   private Thread thread;
/*     */   private Object response;
/*     */   private Throwable exception;
/*     */   private AsyncCall ac;
/*     */   private QName opName;
/*     */   private Object[] params;
/*     */   private Status status;
/*     */   
/*     */   public AsyncResult(AsyncCall ac, QName opName, Object[] params) {
/*  31 */     this.thread = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  36 */     this.response = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  41 */     this.exception = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  46 */     this.ac = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     this.opName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  56 */     this.params = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     this.status = Status.NONE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     this.ac = ac;
/*  72 */     this.opName = opName;
/*  73 */     this.params = params;
/*     */     
/*  75 */     if (opName == null) {
/*  76 */       this.opName = ac.getCall().getOperationName();
/*     */     }
/*     */     
/*  79 */     this.thread = new Thread(this);
/*  80 */     this.thread.setDaemon(true);
/*  81 */     this.thread.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void abort() {
/*  88 */     this.thread.interrupt();
/*  89 */     this.status = Status.INTERRUPTED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public Status getStatus() { return this.status; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void waitFor(long timeout) throws InterruptedException { this.thread.wait(timeout); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public Object getResponse() { return this.response; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public Throwable getException() { return this.exception; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 134 */       this.response = this.ac.getCall().invoke(this.opName, this.params);
/* 135 */       this.status = Status.COMPLETED;
/* 136 */     } catch (Throwable e) {
/* 137 */       this.exception = e;
/* 138 */       this.status = Status.EXCEPTION;
/*     */     } finally {
/* 140 */       IAsyncCallback callback = this.ac.getCallback();
/* 141 */       if (callback != null)
/* 142 */         callback.onCompletion(this); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\async\AsyncResult.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */