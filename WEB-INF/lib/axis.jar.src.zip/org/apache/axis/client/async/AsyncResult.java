package org.apache.axis.client.async;

import javax.xml.namespace.QName;

public class AsyncResult implements IAsyncResult, Runnable {
  private Thread thread;
  
  private Object response;
  
  private Throwable exception;
  
  private AsyncCall ac;
  
  private QName opName;
  
  private Object[] params;
  
  private Status status;
  
  public AsyncResult(AsyncCall ac, QName opName, Object[] params) {
    this.thread = null;
    this.response = null;
    this.exception = null;
    this.ac = null;
    this.opName = null;
    this.params = null;
    this.status = Status.NONE;
    this.ac = ac;
    this.opName = opName;
    this.params = params;
    if (opName == null)
      this.opName = ac.getCall().getOperationName(); 
    this.thread = new Thread(this);
    this.thread.setDaemon(true);
    this.thread.start();
  }
  
  public void abort() {
    this.thread.interrupt();
    this.status = Status.INTERRUPTED;
  }
  
  public Status getStatus() { return this.status; }
  
  public void waitFor(long timeout) throws InterruptedException { this.thread.wait(timeout); }
  
  public Object getResponse() { return this.response; }
  
  public Throwable getException() { return this.exception; }
  
  public void run() {
    try {
      this.response = this.ac.getCall().invoke(this.opName, this.params);
      this.status = Status.COMPLETED;
    } catch (Throwable e) {
      this.exception = e;
      this.status = Status.EXCEPTION;
    } finally {
      IAsyncCallback callback = this.ac.getCallback();
      if (callback != null)
        callback.onCompletion(this); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\async\AsyncResult.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */