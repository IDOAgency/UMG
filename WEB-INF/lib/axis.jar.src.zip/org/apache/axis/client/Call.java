/*      */ package org.apache.axis.client;
/*      */ 
/*      */ import java.io.StringWriter;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.rmi.RemoteException;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import javax.wsdl.Binding;
/*      */ import javax.wsdl.BindingInput;
/*      */ import javax.wsdl.BindingOperation;
/*      */ import javax.wsdl.Operation;
/*      */ import javax.wsdl.Part;
/*      */ import javax.wsdl.Port;
/*      */ import javax.wsdl.PortType;
/*      */ import javax.wsdl.Service;
/*      */ import javax.wsdl.extensions.mime.MIMEMultipartRelated;
/*      */ import javax.wsdl.extensions.mime.MIMEPart;
/*      */ import javax.wsdl.extensions.soap.SOAPAddress;
/*      */ import javax.wsdl.extensions.soap.SOAPBody;
/*      */ import javax.wsdl.extensions.soap.SOAPOperation;
/*      */ import javax.xml.namespace.QName;
/*      */ import javax.xml.rpc.Call;
/*      */ import javax.xml.rpc.JAXRPCException;
/*      */ import javax.xml.rpc.ParameterMode;
/*      */ import javax.xml.soap.SOAPException;
/*      */ import org.apache.axis.AxisEngine;
/*      */ import org.apache.axis.AxisFault;
/*      */ import org.apache.axis.AxisProperties;
/*      */ import org.apache.axis.Handler;
/*      */ import org.apache.axis.InternalException;
/*      */ import org.apache.axis.Message;
/*      */ import org.apache.axis.MessageContext;
/*      */ import org.apache.axis.SOAPPart;
/*      */ import org.apache.axis.attachments.Attachments;
/*      */ import org.apache.axis.components.logger.LogFactory;
/*      */ import org.apache.axis.constants.Style;
/*      */ import org.apache.axis.constants.Use;
/*      */ import org.apache.axis.description.FaultDesc;
/*      */ import org.apache.axis.description.OperationDesc;
/*      */ import org.apache.axis.description.ParameterDesc;
/*      */ import org.apache.axis.encoding.DeserializerFactory;
/*      */ import org.apache.axis.encoding.SerializationContext;
/*      */ import org.apache.axis.encoding.SerializerFactory;
/*      */ import org.apache.axis.encoding.TypeMapping;
/*      */ import org.apache.axis.encoding.TypeMappingRegistry;
/*      */ import org.apache.axis.encoding.XMLType;
/*      */ import org.apache.axis.encoding.ser.BaseDeserializerFactory;
/*      */ import org.apache.axis.encoding.ser.BaseSerializerFactory;
/*      */ import org.apache.axis.handlers.soap.SOAPService;
/*      */ import org.apache.axis.message.RPCElement;
/*      */ import org.apache.axis.message.RPCHeaderParam;
/*      */ import org.apache.axis.message.RPCParam;
/*      */ import org.apache.axis.message.SOAPBodyElement;
/*      */ import org.apache.axis.message.SOAPEnvelope;
/*      */ import org.apache.axis.message.SOAPFault;
/*      */ import org.apache.axis.message.SOAPHeaderElement;
/*      */ import org.apache.axis.soap.SOAPConstants;
/*      */ import org.apache.axis.utils.ClassUtils;
/*      */ import org.apache.axis.utils.JavaUtils;
/*      */ import org.apache.axis.utils.LockableHashtable;
/*      */ import org.apache.axis.utils.Messages;
/*      */ import org.apache.axis.wsdl.symbolTable.BindingEntry;
/*      */ import org.apache.axis.wsdl.symbolTable.FaultInfo;
/*      */ import org.apache.axis.wsdl.symbolTable.Parameter;
/*      */ import org.apache.axis.wsdl.symbolTable.Parameters;
/*      */ import org.apache.axis.wsdl.symbolTable.SymbolTable;
/*      */ import org.apache.axis.wsdl.toJava.Utils;
/*      */ import org.apache.commons.logging.Log;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Call
/*      */   implements Call
/*      */ {
/*  124 */   protected static Log log = LogFactory.getLog(Call.class.getName());
/*      */   
/*  126 */   private static Log tlog = LogFactory.getLog("org.apache.axis.TIME");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  132 */   protected static Log entLog = LogFactory.getLog("org.apache.axis.enterprise");
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean parmAndRetReq;
/*      */ 
/*      */ 
/*      */   
/*      */   private Service service;
/*      */ 
/*      */ 
/*      */   
/*      */   private QName portName;
/*      */ 
/*      */ 
/*      */   
/*      */   private QName portTypeName;
/*      */ 
/*      */ 
/*      */   
/*      */   private QName operationName;
/*      */ 
/*      */ 
/*      */   
/*      */   private MessageContext msgContext;
/*      */ 
/*      */ 
/*      */   
/*      */   private LockableHashtable myProperties;
/*      */ 
/*      */ 
/*      */   
/*      */   private String username;
/*      */ 
/*      */ 
/*      */   
/*      */   private String password;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean maintainSession;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useSOAPAction;
/*      */ 
/*      */ 
/*      */   
/*      */   private String SOAPActionURI;
/*      */ 
/*      */ 
/*      */   
/*      */   private Integer timeout;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useStreaming;
/*      */ 
/*      */ 
/*      */   
/*      */   private OperationDesc operation;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean operationSetManually;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean invokeOneWay;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isMsg;
/*      */ 
/*      */ 
/*      */   
/*      */   private Transport transport;
/*      */ 
/*      */ 
/*      */   
/*      */   private String transportName;
/*      */ 
/*      */ 
/*      */   
/*      */   private HashMap outParams;
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList outParamsList;
/*      */ 
/*      */ 
/*      */   
/*      */   private Vector myHeaders;
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SEND_TYPE_ATTR = "sendXsiTypes";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String TRANSPORT_NAME = "transport_name";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CHARACTER_SET_ENCODING = "javax.xml.soap.character-set-encoding";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String TRANSPORT_PROPERTY = "java.protocol.handler.pkgs";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String WSDL_SERVICE = "wsdl.service";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String WSDL_PORT_NAME = "wsdl.portName";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String JAXRPC_SERVICE = "wsdl.service";
/*      */ 
/*      */   
/*      */   public static final String JAXRPC_PORTTYPE_NAME = "wsdl.portName";
/*      */ 
/*      */   
/*      */   public static final String FAULT_ON_NO_RESPONSE = "call.FaultOnNoResponse";
/*      */ 
/*      */   
/*      */   public static final String CHECK_MUST_UNDERSTAND = "call.CheckMustUnderstand";
/*      */ 
/*      */   
/*      */   public static final String ATTACHMENT_ENCAPSULATION_FORMAT = "attachment_encapsulation_format";
/*      */ 
/*      */   
/*      */   public static final String ATTACHMENT_ENCAPSULATION_FORMAT_MIME = "axis.attachment.style.mime";
/*      */ 
/*      */   
/*      */   public static final String ATTACHMENT_ENCAPSULATION_FORMAT_DIME = "axis.attachment.style.dime";
/*      */ 
/*      */   
/*      */   public static final String ATTACHMENT_ENCAPSULATION_FORMAT_MTOM = "axis.attachment.style.mtom";
/*      */ 
/*      */   
/*      */   public static final String CONNECTION_TIMEOUT_PROPERTY = "axis.connection.timeout";
/*      */ 
/*      */   
/*      */   public static final String STREAMING_PROPERTY = "axis.streaming";
/*      */ 
/*      */   
/*      */   protected static final String ONE_WAY = "axis.one.way";
/*      */ 
/*      */   
/*  285 */   private static Hashtable transports = new Hashtable();
/*      */   
/*  287 */   static ParameterMode[] modes = { null, ParameterMode.IN, ParameterMode.OUT, ParameterMode.INOUT }; private boolean encodingStyleExplicitlySet; private boolean useExplicitlySet; private SOAPService myService; protected Vector attachmentParts; private boolean isNeverInvoked; private static ArrayList propertyNames; private static ArrayList transportPackages; public Call(Service service) { this.parmAndRetReq = true; this.service = null; this.portName = null; this.portTypeName = null; this.operationName = null; this.msgContext = null; this.myProperties = new LockableHashtable(); this.username = null; this.password = null; this.maintainSession = false; this.useSOAPAction = false; this.SOAPActionURI = null; this.timeout = null; this.useStreaming = false; this.operation = null; this.operationSetManually = false; this.invokeOneWay = false; this.isMsg = false; this.transport = null; this.transportName = null; this.outParams = null; this.outParamsList = null; this.myHeaders = null; this.encodingStyleExplicitlySet = false; this.useExplicitlySet = false; this.myService = null; this.attachmentParts = new Vector(); this.isNeverInvoked = true; this.service = service; AxisEngine engine = service.getEngine(); this.msgContext = new MessageContext(engine); this.myProperties.setParent(engine.getOptions()); this.maintainSession = service.getMaintainSession(); } public Call(String url) throws MalformedURLException { this(new Service()); setTargetEndpointAddress(new URL(url)); } public Call(URL url) { this(new Service()); setTargetEndpointAddress(url); } public void setProperty(String name, Object value) { if (name == null || value == null)
/*      */       throw new JAXRPCException(Messages.getMessage((name == null) ? "badProp03" : "badProp04"));  if (name.equals("javax.xml.rpc.security.auth.username")) { verifyStringProperty(name, value); setUsername((String)value); } else if (name.equals("javax.xml.rpc.security.auth.password")) { verifyStringProperty(name, value); setPassword((String)value); } else if (name.equals("javax.xml.rpc.session.maintain")) { verifyBooleanProperty(name, value); setMaintainSession(((Boolean)value).booleanValue()); } else if (name.equals("javax.xml.rpc.soap.operation.style")) { verifyStringProperty(name, value); setOperationStyle((String)value); if (getOperationStyle() == Style.DOCUMENT || getOperationStyle() == Style.WRAPPED) { setOperationUse("literal"); } else if (getOperationStyle() == Style.RPC) { setOperationUse("encoded"); }  } else if (name.equals("javax.xml.rpc.soap.http.soapaction.use")) { verifyBooleanProperty(name, value); setUseSOAPAction(((Boolean)value).booleanValue()); } else if (name.equals("javax.xml.rpc.soap.http.soapaction.uri")) { verifyStringProperty(name, value); setSOAPActionURI((String)value); } else if (name.equals("javax.xml.rpc.encodingstyle.namespace.uri")) { verifyStringProperty(name, value); setEncodingStyle((String)value); } else if (name.equals("javax.xml.rpc.service.endpoint.address")) { verifyStringProperty(name, value); setTargetEndpointAddress((String)value); } else if (name.equals("transport_name")) { verifyStringProperty(name, value); this.transportName = (String)value; if (this.transport != null)
/*      */         this.transport.setTransportName((String)value);  }
/*      */     else if (name.equals("attachment_encapsulation_format")) { verifyStringProperty(name, value); if (!value.equals("axis.attachment.style.mime") && !value.equals("axis.attachment.style.mtom") && !value.equals("axis.attachment.style.dime"))
/*      */         throw new JAXRPCException(Messages.getMessage("badattachmenttypeerr", new String[] { (String)value, "axis.attachment.style.mime axis.attachment.style.mtom axis.attachment.style.dime" }));  }
/*      */     else if (name.equals("axis.connection.timeout")) { verifyIntegerProperty(name, value); setTimeout((Integer)value); }
/*      */     else if (name.equals("axis.streaming")) { verifyBooleanProperty(name, value); setStreaming(((Boolean)value).booleanValue()); }
/*      */     else if (name.equals("javax.xml.soap.character-set-encoding")) { verifyStringProperty(name, value); }
/*      */     else if (name.startsWith("java.") || name.startsWith("javax.")) { throw new JAXRPCException(Messages.getMessage("badProp05", name)); }
/*      */      this.myProperties.put(name, value); } private void verifyStringProperty(String name, Object value) { if (!(value instanceof String))
/*      */       throw new JAXRPCException(Messages.getMessage("badProp00", new String[] { name, "java.lang.String", value.getClass().getName() }));  } private void verifyBooleanProperty(String name, Object value) { if (!(value instanceof Boolean))
/*      */       throw new JAXRPCException(Messages.getMessage("badProp00", new String[] { name, "java.lang.Boolean", value.getClass().getName() }));  } private void verifyIntegerProperty(String name, Object value) { if (!(value instanceof Integer))
/*      */       throw new JAXRPCException(Messages.getMessage("badProp00", new String[] { name, "java.lang.Integer", value.getClass().getName() }));  } public Object getProperty(String name) { if (name == null || !isPropertySupported(name))
/*      */       throw new JAXRPCException((name == null) ? Messages.getMessage("badProp03") : Messages.getMessage("badProp05", name));  return this.myProperties.get(name); } public void removeProperty(String name) throws MalformedURLException { if (name == null || !isPropertySupported(name))
/*      */       throw new JAXRPCException((name == null) ? Messages.getMessage("badProp03") : Messages.getMessage("badProp05", name));  this.myProperties.remove(name); }
/*      */   public Iterator getPropertyNames() { return propertyNames.iterator(); }
/*      */   public boolean isPropertySupported(String name) { return (propertyNames.contains(name) || (!name.startsWith("java.") && !name.startsWith("javax."))); }
/*      */   public void setUsername(String username) throws MalformedURLException { this.username = username; }
/*      */   public String getUsername() { return this.username; }
/*      */   public void setPassword(String password) throws MalformedURLException { this.password = password; }
/*      */   public String getPassword() { return this.password; }
/*      */   public void setMaintainSession(boolean yesno) { this.maintainSession = yesno; }
/*      */   public boolean getMaintainSession() { return this.maintainSession; }
/*      */   public void setOperationStyle(String operationStyle) throws MalformedURLException { Style style = Style.getStyle(operationStyle, Style.DEFAULT); setOperationStyle(style); }
/*  311 */   static  { initialize();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  560 */     propertyNames = new ArrayList();
/*      */     
/*  562 */     propertyNames.add("javax.xml.rpc.security.auth.username");
/*  563 */     propertyNames.add("javax.xml.rpc.security.auth.password");
/*  564 */     propertyNames.add("javax.xml.rpc.session.maintain");
/*  565 */     propertyNames.add("javax.xml.rpc.soap.operation.style");
/*  566 */     propertyNames.add("javax.xml.rpc.soap.http.soapaction.use");
/*  567 */     propertyNames.add("javax.xml.rpc.soap.http.soapaction.uri");
/*  568 */     propertyNames.add("javax.xml.rpc.encodingstyle.namespace.uri");
/*  569 */     propertyNames.add("javax.xml.rpc.service.endpoint.address");
/*  570 */     propertyNames.add("transport_name");
/*  571 */     propertyNames.add("attachment_encapsulation_format");
/*  572 */     propertyNames.add("axis.connection.timeout");
/*  573 */     propertyNames.add("javax.xml.soap.character-set-encoding");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1975 */     transportPackages = null; } public void setOperationStyle(Style operationStyle) { if (this.operation == null) this.operation = new OperationDesc();  this.operation.setStyle(operationStyle); if (!this.useExplicitlySet && operationStyle != Style.RPC) this.operation.setUse(Use.LITERAL);  if (!this.encodingStyleExplicitlySet) { String encStyle = ""; if (operationStyle == Style.RPC) encStyle = this.msgContext.getSOAPConstants().getEncodingURI();  this.msgContext.setEncodingStyle(encStyle); }  } public Style getOperationStyle() { if (this.operation != null)
/*      */       return this.operation.getStyle();  return Style.DEFAULT; } public void setOperationUse(String operationUse) throws MalformedURLException { Use use = Use.getUse(operationUse, Use.DEFAULT); setOperationUse(use); } public void setOperationUse(Use operationUse) { this.useExplicitlySet = true; if (this.operation == null)
/*      */       this.operation = new OperationDesc();  this.operation.setUse(operationUse); if (!this.encodingStyleExplicitlySet) { String encStyle = ""; if (operationUse == Use.ENCODED)
/*      */         encStyle = this.msgContext.getSOAPConstants().getEncodingURI();  this.msgContext.setEncodingStyle(encStyle); }  } public Use getOperationUse() { if (this.operation != null)
/*      */       return this.operation.getUse();  return Use.DEFAULT; } public void setUseSOAPAction(boolean useSOAPAction) { this.useSOAPAction = useSOAPAction; } public boolean useSOAPAction() { return this.useSOAPAction; } public void setSOAPActionURI(String SOAPActionURI) throws MalformedURLException { this.useSOAPAction = true; this.SOAPActionURI = SOAPActionURI; }
/*      */   public String getSOAPActionURI() { return this.SOAPActionURI; }
/*      */   public void setEncodingStyle(String namespaceURI) throws MalformedURLException { this.encodingStyleExplicitlySet = true; this.msgContext.setEncodingStyle(namespaceURI); }
/*      */   public String getEncodingStyle() { return this.msgContext.getEncodingStyle(); }
/*      */   public void setTargetEndpointAddress(String address) throws MalformedURLException { URL urlAddress; try { urlAddress = new URL(address); } catch (MalformedURLException mue) { throw new JAXRPCException(mue); }  setTargetEndpointAddress(urlAddress); }
/*      */   public void setTargetEndpointAddress(URL address) { try { if (address == null) { setTransport(null); return; }  String protocol = address.getProtocol(); if (this.transport != null) { String oldAddr = this.transport.getUrl(); if (oldAddr != null && !oldAddr.equals("")) { URL tmpURL = new URL(oldAddr); String oldProto = tmpURL.getProtocol(); if (protocol.equals(oldProto)) { this.transport.setUrl(address.toString()); return; }  }  }  Transport transport = this.service.getTransportForURL(address); if (transport != null) { setTransport(transport); } else { transport = getTransportForProtocol(protocol); if (transport == null)
/*      */           throw new AxisFault("Call.setTargetEndpointAddress", Messages.getMessage("noTransport01", protocol), null, null);  transport.setUrl(address.toString()); setTransport(transport); this.service.registerTransportForURL(address, transport); }  } catch (Exception exp) { log.error(Messages.getMessage("exception00"), exp); }  }
/*      */   public String getTargetEndpointAddress() { try { if (this.transport == null)
/*      */         return null;  return this.transport.getUrl(); } catch (Exception exp) { return null; }  }
/*      */   public Integer getTimeout() { return this.timeout; }
/*      */   public void setTimeout(Integer timeout) { this.timeout = timeout; }
/*      */   public boolean getStreaming() { return this.useStreaming; }
/* 1991 */   public static void addTransportPackage(String packageName) throws MalformedURLException { if (transportPackages == null) {
/* 1992 */       transportPackages = new ArrayList();
/* 1993 */       String currentPackages = AxisProperties.getProperty("java.protocol.handler.pkgs");
/*      */       
/* 1995 */       if (currentPackages != null) {
/* 1996 */         StringTokenizer tok = new StringTokenizer(currentPackages, "|");
/*      */         
/* 1998 */         while (tok.hasMoreTokens()) {
/* 1999 */           transportPackages.add(tok.nextToken());
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2004 */     if (transportPackages.contains(packageName)) {
/*      */       return;
/*      */     }
/*      */     
/* 2008 */     transportPackages.add(packageName);
/*      */     
/* 2010 */     StringBuffer currentPackages = new StringBuffer();
/* 2011 */     for (Iterator i = transportPackages.iterator(); i.hasNext(); ) {
/* 2012 */       String thisPackage = (String)i.next();
/* 2013 */       currentPackages.append(thisPackage);
/* 2014 */       currentPackages.append('|');
/*      */     } 
/*      */     
/* 2017 */     String transportProperty = currentPackages.toString();
/* 2018 */     AccessController.doPrivileged(new PrivilegedAction(transportProperty) { private final String val$transportProperty;
/*      */           
/*      */           public Object run() { try {
/* 2021 */               System.setProperty("java.protocol.handler.pkgs", this.val$transportProperty);
/* 2022 */             } catch (SecurityException se) {}
/*      */             
/* 2024 */             return null; } }); } public void setStreaming(boolean useStreaming) { this.useStreaming = useStreaming; } public boolean isParameterAndReturnSpecRequired(QName operationName) { return this.parmAndRetReq; } public void addParameter(QName paramName, QName xmlType, ParameterMode parameterMode) { Class javaType = null; TypeMapping tm = getTypeMapping(); if (tm != null) javaType = tm.getClassForQName(xmlType);  addParameter(paramName, xmlType, javaType, parameterMode); } public void addParameter(QName paramName, QName xmlType, Class javaType, ParameterMode parameterMode) { if (this.operationSetManually) throw new RuntimeException(Messages.getMessage("operationAlreadySet"));  if (this.operation == null) this.operation = new OperationDesc();  ParameterDesc param = new ParameterDesc(); byte mode = 1; if (parameterMode == ParameterMode.INOUT) { mode = 3; param.setIsReturn(true); } else if (parameterMode == ParameterMode.OUT) { mode = 2; param.setIsReturn(true); }  param.setMode(mode); param.setQName(new QName(paramName.getNamespaceURI(), Utils.getLastLocalPart(paramName.getLocalPart()))); param.setTypeQName(xmlType); param.setJavaType(javaType); this.operation.addParameter(param); this.parmAndRetReq = true; } public void addParameter(String paramName, QName xmlType, ParameterMode parameterMode) { Class javaType = null; TypeMapping tm = getTypeMapping(); if (tm != null) javaType = tm.getClassForQName(xmlType);  addParameter(new QName("", paramName), xmlType, javaType, parameterMode); }
/*      */   public void addParameter(String paramName, QName xmlType, Class javaType, ParameterMode parameterMode) { addParameter(new QName("", paramName), xmlType, javaType, parameterMode); }
/*      */   public void addParameterAsHeader(QName paramName, QName xmlType, ParameterMode parameterMode, ParameterMode headerMode) { Class javaType = null; TypeMapping tm = getTypeMapping(); if (tm != null) javaType = tm.getClassForQName(xmlType);  addParameterAsHeader(paramName, xmlType, javaType, parameterMode, headerMode); }
/*      */   public void addParameterAsHeader(QName paramName, QName xmlType, Class javaType, ParameterMode parameterMode, ParameterMode headerMode) { if (this.operationSetManually) throw new RuntimeException(Messages.getMessage("operationAlreadySet"));  if (this.operation == null) this.operation = new OperationDesc();  ParameterDesc param = new ParameterDesc(); param.setQName(new QName(paramName.getNamespaceURI(), Utils.getLastLocalPart(paramName.getLocalPart()))); param.setTypeQName(xmlType); param.setJavaType(javaType); if (parameterMode == ParameterMode.IN) { param.setMode((byte)1); } else if (parameterMode == ParameterMode.INOUT) { param.setMode((byte)3); } else if (parameterMode == ParameterMode.OUT) { param.setMode((byte)2); }  if (headerMode == ParameterMode.IN) { param.setInHeader(true); } else if (headerMode == ParameterMode.INOUT) { param.setInHeader(true); param.setOutHeader(true); } else if (headerMode == ParameterMode.OUT) { param.setOutHeader(true); }  this.operation.addParameter(param); this.parmAndRetReq = true; }
/*      */   public QName getParameterTypeByName(String paramName) { QName paramQName = new QName("", paramName); return getParameterTypeByQName(paramQName); }
/*      */   public QName getParameterTypeByQName(QName paramQName) { ParameterDesc param = this.operation.getParamByQName(paramQName); if (param != null) return param.getTypeQName();  return null; }
/*      */   public void setReturnType(QName type) { if (this.operationSetManually) throw new RuntimeException(Messages.getMessage("operationAlreadySet"));  if (this.operation == null) this.operation = new OperationDesc();  this.operation.setReturnType(type); TypeMapping tm = getTypeMapping(); this.operation.setReturnClass(tm.getClassForQName(type)); this.parmAndRetReq = true; }
/*      */   public void setReturnType(QName xmlType, Class javaType) { setReturnType(xmlType); this.operation.setReturnClass(javaType); }
/*      */   public void setReturnTypeAsHeader(QName xmlType) { setReturnType(xmlType); this.operation.setReturnHeader(true); }
/*      */   public void setReturnTypeAsHeader(QName xmlType, Class javaType) { setReturnType(xmlType, javaType); this.operation.setReturnHeader(true); }
/*      */   public QName getReturnType() { if (this.operation != null) return this.operation.getReturnType();  return null; }
/*      */   public void setReturnQName(QName qname) { if (this.operationSetManually) throw new RuntimeException(Messages.getMessage("operationAlreadySet"));  if (this.operation == null) this.operation = new OperationDesc();  this.operation.setReturnQName(qname); }
/*      */   public void setReturnClass(Class cls) { if (this.operationSetManually) throw new RuntimeException(Messages.getMessage("operationAlreadySet"));  if (this.operation == null) this.operation = new OperationDesc();  this.operation.setReturnClass(cls); TypeMapping tm = getTypeMapping(); this.operation.setReturnType(tm.getTypeQName(cls)); this.parmAndRetReq = true; }
/*      */   public void removeAllParameters() { this.operation = new OperationDesc(); this.operationSetManually = false; this.parmAndRetReq = true; }
/* 2038 */   private Object[] getParamList(Object[] params) { int numParams = 0;
/*      */ 
/*      */ 
/*      */     
/* 2042 */     if (log.isDebugEnabled()) {
/* 2043 */       log.debug("operation=" + this.operation);
/* 2044 */       if (this.operation != null) {
/* 2045 */         log.debug("operation.getNumParams()=" + this.operation.getNumParams());
/*      */       }
/*      */     } 
/*      */     
/* 2049 */     if (this.operation == null || this.operation.getNumParams() == 0) {
/* 2050 */       return params;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2056 */     numParams = this.operation.getNumInParams();
/*      */     
/* 2058 */     if (params == null || numParams != params.length) {
/* 2059 */       throw new JAXRPCException(Messages.getMessage("parmMismatch00", (params == null) ? "no params" : ("" + params.length), "" + numParams));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2068 */     log.debug("getParamList number of params: " + params.length);
/*      */ 
/*      */ 
/*      */     
/* 2072 */     Vector result = new Vector();
/* 2073 */     int j = 0;
/* 2074 */     ArrayList parameters = this.operation.getParameters();
/*      */     
/* 2076 */     for (int i = 0; i < parameters.size(); i++) {
/* 2077 */       ParameterDesc param = (ParameterDesc)parameters.get(i);
/* 2078 */       if (param.getMode() != 2) {
/* 2079 */         QName paramQName = param.getQName();
/*      */ 
/*      */         
/* 2082 */         RPCParam rpcParam = null;
/* 2083 */         Object p = params[j++];
/* 2084 */         if (p instanceof RPCParam) {
/* 2085 */           rpcParam = (RPCParam)p;
/*      */         } else {
/* 2087 */           rpcParam = new RPCParam(paramQName.getNamespaceURI(), paramQName.getLocalPart(), p);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2094 */         rpcParam.setParamDesc(param);
/*      */ 
/*      */ 
/*      */         
/* 2098 */         if (param.isInHeader()) {
/* 2099 */           addHeader(new RPCHeaderParam(rpcParam));
/*      */         } else {
/* 2101 */           result.add(rpcParam);
/*      */         } 
/*      */       } 
/*      */     } 
/* 2105 */     return result.toArray(); }
/*      */   public QName getOperationName() { return this.operationName; } public void setOperationName(QName opName) { this.operationName = opName; } public void setOperationName(String opName) throws MalformedURLException { this.operationName = new QName(opName); } public void setOperation(String opName) throws MalformedURLException { if (this.service == null) throw new JAXRPCException(Messages.getMessage("noService04"));  setOperationName(opName); setEncodingStyle(null); setReturnType(null); removeAllParameters(); Service wsdlService = this.service.getWSDLService(); if (wsdlService == null) return;  Port port = wsdlService.getPort(this.portName.getLocalPart()); if (port == null) throw new JAXRPCException(Messages.getMessage("noPort00", "" + this.portName));  Binding binding = port.getBinding(); PortType portType = binding.getPortType(); if (portType == null) throw new JAXRPCException(Messages.getMessage("noPortType00", "" + this.portName));  setPortTypeName(portType.getQName()); List operations = portType.getOperations(); if (operations == null) throw new JAXRPCException(Messages.getMessage("noOperation01", opName));  Operation op = null; for (int i = 0; i < operations.size(); i++, op = null) { op = (Operation)operations.get(i); if (opName.equals(op.getName())) break;  }  if (op == null)
/*      */       throw new JAXRPCException(Messages.getMessage("noOperation01", opName));  List list = port.getExtensibilityElements(); String opStyle = null; BindingOperation bop = binding.getBindingOperation(opName, null, null); if (bop == null)
/*      */       throw new JAXRPCException(Messages.getMessage("noOperation02", opName));  list = bop.getExtensibilityElements(); for (int i = 0; list != null && i < list.size(); i++) { Object obj = list.get(i); if (obj instanceof SOAPOperation) { SOAPOperation sop = (SOAPOperation)obj; opStyle = ((SOAPOperation)obj).getStyle(); String action = sop.getSoapActionURI(); if (action != null) { setUseSOAPAction(true); setSOAPActionURI(action); break; }  setUseSOAPAction(false); setSOAPActionURI(null); break; }  }  BindingInput bIn = bop.getBindingInput(); if (bIn != null) { list = bIn.getExtensibilityElements(); for (int i = 0; list != null && i < list.size(); i++) { Object obj = list.get(i); if (obj instanceof MIMEMultipartRelated) { MIMEMultipartRelated mpr = (MIMEMultipartRelated)obj; Object part = null; List l = mpr.getMIMEParts(); for (int j = 0; l != null && j < l.size() && part == null; j++) { MIMEPart mp = (MIMEPart)l.get(j); List ll = mp.getExtensibilityElements(); for (int k = 0; ll != null && k < ll.size() && part == null; k++) { part = ll.get(k); if (!(part instanceof SOAPBody))
/*      */                 part = null;  }  }  if (null != part)
/*      */             obj = part;  }  if (obj instanceof SOAPBody) { SOAPBody sBody = (SOAPBody)obj; list = sBody.getEncodingStyles(); if (list != null && list.size() > 0)
/*      */             setEncodingStyle((String)list.get(0));  String ns = sBody.getNamespaceURI(); if (ns != null && !ns.equals(""))
/*      */             setOperationName(new QName(ns, opName));  break; }  }  }  Service service = getService(); SymbolTable symbolTable = service.getWSDLParser().getSymbolTable(); BindingEntry bEntry = symbolTable.getBindingEntry(binding.getQName()); Parameters parameters = bEntry.getParameters(bop.getOperation()); for (int j = 0; j < parameters.list.size(); j++) { Parameter p = (Parameter)parameters.list.get(j); QName paramType = Utils.getXSIType(p); ParameterMode mode = modes[p.getMode()]; if (p.isInHeader() || p.isOutHeader()) { addParameterAsHeader(p.getQName(), paramType, mode, mode); } else { addParameter(p.getQName(), paramType, mode); }  }  Map faultMap = bEntry.getFaults(); ArrayList faults = (ArrayList)faultMap.get(bop); if (faults == null)
/*      */       return;  for (Iterator faultIt = faults.iterator(); faultIt.hasNext(); ) { FaultInfo info = (FaultInfo)faultIt.next(); QName qname = info.getQName(); info.getMessage(); if (qname == null)
/*      */         continue;  QName xmlType = info.getXMLType(); Class clazz = getTypeMapping().getClassForQName(xmlType); if (clazz != null) { addFault(qname, clazz, xmlType, true); continue; }  log.debug(Messages.getMessage("clientNoTypemapping", xmlType.toString())); }  if (parameters.returnParam != null) { QName returnType = Utils.getXSIType(parameters.returnParam); QName returnQName = parameters.returnParam.getQName(); String javaType = null; if (parameters.returnParam.getMIMEInfo() != null) { javaType = "javax.activation.DataHandler"; } else { javaType = parameters.returnParam.getType().getName(); }  if (javaType == null) { javaType = ""; } else { javaType = javaType + ".class"; }  setReturnType(returnType); try { Class clazz = ClassUtils.forName(javaType); setReturnClass(clazz); } catch (ClassNotFoundException swallowedException) { log.debug(Messages.getMessage("clientNoReturnClass", javaType)); }  setReturnQName(returnQName); } else { setReturnType(XMLType.AXIS_VOID); }  boolean hasMIME = Utils.hasMIME(bEntry, bop); Use use = bEntry.getInputBodyType(bop.getOperation()); setOperationUse(use); if (use == Use.LITERAL) { setEncodingStyle(null); setProperty("sendXsiTypes", Boolean.FALSE); }  if (hasMIME || use == Use.LITERAL)
/*      */       setProperty("sendMultiRefs", Boolean.FALSE);  Style style = Style.getStyle(opStyle, bEntry.getBindingStyle()); if (style == Style.DOCUMENT && symbolTable.isWrapped())
/*      */       style = Style.WRAPPED;  setOperationStyle(style); if (style == Style.WRAPPED) { Map partsMap = bop.getOperation().getInput().getMessage().getParts(); Part p = (Part)partsMap.values().iterator().next(); QName q = p.getElementName(); setOperationName(q); } else { QName elementQName = Utils.getOperationQName(bop, bEntry, symbolTable); if (elementQName != null)
/* 2117 */         setOperationName(elementQName);  }  this.parmAndRetReq = false; } public void setTransport(Transport trans) { this.transport = trans;
/* 2118 */     if (log.isDebugEnabled())
/* 2119 */       log.debug(Messages.getMessage("transport00", "" + this.transport));  }
/*      */   public void setOperation(QName portName, String opName) { setOperation(portName, new QName(opName)); }
/*      */   public void setOperation(QName portName, QName opName) { if (this.service == null) throw new JAXRPCException(Messages.getMessage("noService04"));  setPortName(portName); setOperationName(opName); setReturnType(null); removeAllParameters(); Service wsdlService = this.service.getWSDLService(); if (wsdlService == null) return;  setTargetEndpointAddress((URL)null); Port port = wsdlService.getPort(portName.getLocalPart()); if (port == null) throw new JAXRPCException(Messages.getMessage("noPort00", "" + portName));  List list = port.getExtensibilityElements(); for (int i = 0; list != null && i < list.size(); i++) { Object obj = list.get(i); if (obj instanceof SOAPAddress) try { SOAPAddress addr = (SOAPAddress)obj; URL url = new URL(addr.getLocationURI()); setTargetEndpointAddress(url); } catch (Exception exp) { throw new JAXRPCException(Messages.getMessage("cantSetURI00", "" + exp)); }   }  setOperation(opName.getLocalPart()); }
/*      */   public QName getPortName() { return this.portName; }
/*      */   public void setPortName(QName portName) { this.portName = portName; }
/*      */   public QName getPortTypeName() { return (this.portTypeName == null) ? new QName("") : this.portTypeName; }
/*      */   public void setPortTypeName(QName portType) { this.portTypeName = portType; }
/*      */   public void setSOAPVersion(SOAPConstants soapConstants) { this.msgContext.setSOAPConstants(soapConstants); }
/*      */   public Object invoke(QName operationName, Object[] params) throws RemoteException { QName origOpName = this.operationName; this.operationName = operationName; try { return invoke(params); } catch (AxisFault af) { this.operationName = origOpName; if (af.detail != null && af.detail instanceof RemoteException) throw (RemoteException)af.detail;  throw af; } catch (RemoteException re) { this.operationName = origOpName; throw re; } catch (RuntimeException re) { this.operationName = origOpName; throw re; } catch (Error e) { this.operationName = origOpName; throw e; }  } public Object invoke(Object[] params) throws RemoteException { long t0 = 0L, t1 = 0L; if (tlog.isDebugEnabled()) t0 = System.currentTimeMillis();  SOAPEnvelope env = null; int i; for (i = 0; params != null && i < params.length && params[i] instanceof SOAPBodyElement; i++); if (params != null && params.length > 0 && i == params.length) { this.isMsg = true; env = new SOAPEnvelope(this.msgContext.getSOAPConstants(), this.msgContext.getSchemaVersion()); for (i = 0; i < params.length; i++) env.addBodyElement((SOAPBodyElement)params[i]);  Message msg = new Message(env); setRequestMessage(msg); invoke(); msg = this.msgContext.getResponseMessage(); if (msg == null) { if (this.msgContext.isPropertyTrue("call.FaultOnNoResponse", false)) throw new AxisFault(Messages.getMessage("nullResponse00"));  return null; }  env = msg.getSOAPEnvelope(); return env.getBodyElements(); }  if (this.operationName == null) throw new AxisFault(Messages.getMessage("noOperation00"));  try { Object res = invoke(this.operationName.getNamespaceURI(), this.operationName.getLocalPart(), params); if (tlog.isDebugEnabled()) { t1 = System.currentTimeMillis(); tlog.debug("axis.Call.invoke: " + (t1 - t0) + " " + this.operationName); }  return res; } catch (AxisFault af) { if (af.detail != null && af.detail instanceof RemoteException)
/*      */         throw (RemoteException)af.detail;  throw af; } catch (Exception exp) { entLog.debug(Messages.getMessage("toAxisFault00"), exp); throw AxisFault.makeFault(exp); }  } public void invokeOneWay(Object[] params) { try { this.invokeOneWay = true; invoke(params); } catch (Exception exp) { throw new JAXRPCException(exp.toString()); } finally { this.invokeOneWay = false; }  } public SOAPEnvelope invoke(Message msg) throws AxisFault { try { setRequestMessage(msg); invoke(); msg = this.msgContext.getResponseMessage(); if (msg == null) { if (this.msgContext.isPropertyTrue("call.FaultOnNoResponse", false))
/*      */           throw new AxisFault(Messages.getMessage("nullResponse00"));  return null; }  res = null; return msg.getSOAPEnvelope(); } catch (Exception exp) { if (exp instanceof AxisFault)
/*      */         throw (AxisFault)exp;  entLog.debug(Messages.getMessage("toAxisFault00"), exp); throw new AxisFault(Messages.getMessage("errorInvoking00", "\n" + exp)); }  } public SOAPEnvelope invoke(SOAPEnvelope env) throws AxisFault { try { Message msg = new Message(env); if (getProperty("javax.xml.soap.character-set-encoding") != null) { msg.setProperty("javax.xml.soap.character-set-encoding", getProperty("javax.xml.soap.character-set-encoding")); } else if (this.msgContext.getProperty("javax.xml.soap.character-set-encoding") != null) { msg.setProperty("javax.xml.soap.character-set-encoding", this.msgContext.getProperty("javax.xml.soap.character-set-encoding")); }  setRequestMessage(msg); invoke(); msg = this.msgContext.getResponseMessage(); if (msg == null) { if (this.msgContext.isPropertyTrue("call.FaultOnNoResponse", false))
/*      */           throw new AxisFault(Messages.getMessage("nullResponse00"));  return null; }  return msg.getSOAPEnvelope(); } catch (Exception exp) { if (exp instanceof AxisFault)
/* 2132 */         throw (AxisFault)exp;  entLog.debug(Messages.getMessage("toAxisFault00"), exp); throw AxisFault.makeFault(exp); }  } public static void setTransportForProtocol(String protocol, Class transportClass) { if (Transport.class.isAssignableFrom(transportClass)) { transports.put(protocol, transportClass); } else { throw new InternalException(transportClass.toString()); }  } public static void initialize() { addTransportPackage("org.apache.axis.transport"); setTransportForProtocol("java", org.apache.axis.transport.java.JavaTransport.class); setTransportForProtocol("local", org.apache.axis.transport.local.LocalTransport.class); setTransportForProtocol("http", org.apache.axis.transport.http.HTTPTransport.class); setTransportForProtocol("https", org.apache.axis.transport.http.HTTPTransport.class); } public Transport getTransportForProtocol(String protocol) { Class transportClass = (Class)transports.get(protocol);
/* 2133 */     Transport ret = null;
/* 2134 */     if (transportClass != null) {
/*      */       
/* 2136 */       try { ret = (Transport)transportClass.newInstance(); }
/* 2137 */       catch (InstantiationException e) {  }
/* 2138 */       catch (IllegalAccessException e) {}
/*      */     }
/*      */     
/* 2141 */     return ret; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRequestMessage(Message msg) {
/* 2156 */     String attachformat = (String)getProperty("attachment_encapsulation_format");
/*      */ 
/*      */     
/* 2159 */     if (null != attachformat) {
/* 2160 */       Attachments attachments = msg.getAttachmentsImpl();
/* 2161 */       if (null != attachments) {
/* 2162 */         if ("axis.attachment.style.mime".equals(attachformat)) {
/* 2163 */           attachments.setSendType(2);
/* 2164 */         } else if ("axis.attachment.style.mtom".equals(attachformat)) {
/* 2165 */           attachments.setSendType(4);
/* 2166 */         } else if ("axis.attachment.style.dime".equals(attachformat)) {
/* 2167 */           attachments.setSendType(3);
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 2172 */     if (null != this.attachmentParts && !this.attachmentParts.isEmpty()) {
/*      */       try {
/* 2174 */         Attachments attachments = msg.getAttachmentsImpl();
/* 2175 */         if (null == attachments) {
/* 2176 */           throw new RuntimeException(Messages.getMessage("noAttachments"));
/*      */         }
/*      */ 
/*      */         
/* 2180 */         attachments.setAttachmentParts(this.attachmentParts);
/* 2181 */       } catch (AxisFault ex) {
/* 2182 */         log.info(Messages.getMessage("axisFault00"), ex);
/* 2183 */         throw new RuntimeException(ex.getMessage());
/*      */       } 
/*      */     }
/*      */     
/* 2187 */     this.msgContext.setRequestMessage(msg);
/* 2188 */     this.attachmentParts.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2201 */   public Message getResponseMessage() { return this.msgContext.getResponseMessage(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2212 */   public MessageContext getMessageContext() { return this.msgContext; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addHeader(SOAPHeaderElement header) {
/* 2225 */     if (this.myHeaders == null) {
/* 2226 */       this.myHeaders = new Vector();
/*      */     }
/* 2228 */     this.myHeaders.add(header);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2238 */   public void clearHeaders() { this.myHeaders = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeMapping getTypeMapping() {
/* 2244 */     TypeMappingRegistry tmr = this.msgContext.getTypeMappingRegistry();
/*      */ 
/*      */     
/* 2247 */     return tmr.getOrMakeTypeMapping(getEncodingStyle());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2262 */   public void registerTypeMapping(Class javaType, QName xmlType, SerializerFactory sf, DeserializerFactory df) { registerTypeMapping(javaType, xmlType, sf, df, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerTypeMapping(Class javaType, QName xmlType, SerializerFactory sf, DeserializerFactory df, boolean force) {
/* 2279 */     TypeMapping tm = getTypeMapping();
/* 2280 */     if (!force && tm.isRegistered(javaType, xmlType)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 2285 */     tm.register(javaType, xmlType, sf, df);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2297 */   public void registerTypeMapping(Class javaType, QName xmlType, Class sfClass, Class dfClass) { registerTypeMapping(javaType, xmlType, sfClass, dfClass, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerTypeMapping(Class javaType, QName xmlType, Class sfClass, Class dfClass, boolean force) {
/* 2315 */     SerializerFactory sf = BaseSerializerFactory.createFactory(sfClass, javaType, xmlType);
/*      */     
/* 2317 */     DeserializerFactory df = BaseDeserializerFactory.createFactory(dfClass, javaType, xmlType);
/*      */ 
/*      */ 
/*      */     
/* 2321 */     if (sf != null || df != null) {
/* 2322 */       registerTypeMapping(javaType, xmlType, sf, df, force);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object invoke(String namespace, String method, Object[] args) throws AxisFault {
/* 2350 */     if (log.isDebugEnabled()) {
/* 2351 */       log.debug("Enter: Call::invoke(ns, meth, args)");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2359 */     if (getReturnType() != null && args != null && args.length != 0 && this.operation.getNumParams() == 0)
/*      */     {
/* 2361 */       throw new AxisFault(Messages.getMessage("mustSpecifyParms"));
/*      */     }
/*      */     
/* 2364 */     RPCElement body = new RPCElement(namespace, method, getParamList(args));
/*      */     
/* 2366 */     Object ret = invoke(body);
/*      */     
/* 2368 */     if (log.isDebugEnabled()) {
/* 2369 */       log.debug("Exit: Call::invoke(ns, meth, args)");
/*      */     }
/*      */     
/* 2372 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2391 */   public Object invoke(String method, Object[] args) throws AxisFault { return invoke("", method, args); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object invoke(RPCElement body) throws AxisFault {
/* 2404 */     if (log.isDebugEnabled()) {
/* 2405 */       log.debug("Enter: Call::invoke(RPCElement)");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2413 */     if (!this.invokeOneWay && this.operation != null && this.operation.getNumParams() > 0 && getReturnType() == null)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 2418 */       log.error(Messages.getMessage("mustSpecifyReturnType"));
/*      */     }
/*      */     
/* 2421 */     SOAPEnvelope reqEnv = new SOAPEnvelope(this.msgContext.getSOAPConstants(), this.msgContext.getSchemaVersion());
/*      */ 
/*      */     
/* 2424 */     SOAPEnvelope resEnv = null;
/* 2425 */     Message reqMsg = new Message(reqEnv);
/* 2426 */     Message resMsg = null;
/* 2427 */     Vector resArgs = null;
/* 2428 */     Object result = null;
/*      */ 
/*      */     
/* 2431 */     this.outParams = new HashMap();
/* 2432 */     this.outParamsList = new ArrayList();
/*      */ 
/*      */     
/*      */     try {
/* 2436 */       body.setEncodingStyle(getEncodingStyle());
/*      */       
/* 2438 */       setRequestMessage(reqMsg);
/*      */       
/* 2440 */       reqEnv.addBodyElement(body);
/* 2441 */       reqEnv.setMessageType("request");
/*      */       
/* 2443 */       invoke();
/* 2444 */     } catch (Exception e) {
/* 2445 */       entLog.debug(Messages.getMessage("toAxisFault00"), e);
/* 2446 */       throw AxisFault.makeFault(e);
/*      */     } 
/*      */     
/* 2449 */     resMsg = this.msgContext.getResponseMessage();
/*      */     
/* 2451 */     if (resMsg == null) {
/* 2452 */       if (this.msgContext.isPropertyTrue("call.FaultOnNoResponse", false)) {
/* 2453 */         throw new AxisFault(Messages.getMessage("nullResponse00"));
/*      */       }
/* 2455 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 2459 */     resEnv = resMsg.getSOAPEnvelope();
/* 2460 */     SOAPBodyElement bodyEl = resEnv.getFirstBody();
/* 2461 */     if (bodyEl == null) {
/* 2462 */       return null;
/*      */     }
/*      */     
/* 2465 */     if (bodyEl instanceof RPCElement) {
/*      */       try {
/* 2467 */         resArgs = ((RPCElement)bodyEl).getParams();
/* 2468 */       } catch (Exception e) {
/* 2469 */         log.error(Messages.getMessage("exception00"), e);
/* 2470 */         throw AxisFault.makeFault(e);
/*      */       } 
/*      */       
/* 2473 */       if (resArgs != null && resArgs.size() > 0) {
/*      */ 
/*      */ 
/*      */         
/* 2477 */         int outParamStart = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2502 */         boolean findReturnParam = false;
/* 2503 */         QName returnParamQName = null;
/* 2504 */         if (this.operation != null) {
/* 2505 */           returnParamQName = this.operation.getReturnQName();
/*      */         }
/*      */         
/* 2508 */         if (!XMLType.AXIS_VOID.equals(getReturnType())) {
/* 2509 */           if (returnParamQName == null) {
/*      */             
/* 2511 */             RPCParam param = (RPCParam)resArgs.get(0);
/* 2512 */             result = param.getObjectValue();
/* 2513 */             outParamStart = 1;
/*      */           }
/*      */           else {
/*      */             
/* 2517 */             findReturnParam = true;
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2528 */         for (int i = outParamStart; i < resArgs.size(); i++) {
/* 2529 */           RPCParam param = (RPCParam)resArgs.get(i);
/*      */           
/* 2531 */           Class javaType = getJavaTypeForQName(param.getQName());
/* 2532 */           Object value = param.getObjectValue();
/*      */ 
/*      */           
/* 2535 */           if (javaType != null && value != null && !javaType.isAssignableFrom(value.getClass()))
/*      */           {
/* 2537 */             value = JavaUtils.convert(value, javaType);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 2542 */           if (findReturnParam && returnParamQName.equals(param.getQName())) {
/*      */ 
/*      */             
/* 2545 */             result = value;
/* 2546 */             findReturnParam = false;
/*      */           } else {
/* 2548 */             this.outParams.put(param.getQName(), value);
/* 2549 */             this.outParamsList.add(value);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2560 */         if (findReturnParam) {
/* 2561 */           Iterator it = this.outParams.keySet().iterator();
/* 2562 */           while (findReturnParam && it.hasNext()) {
/* 2563 */             QName qname = (QName)it.next();
/* 2564 */             ParameterDesc paramDesc = this.operation.getOutputParamByQName(qname);
/*      */             
/* 2566 */             if (paramDesc == null) {
/*      */               
/* 2568 */               findReturnParam = false;
/* 2569 */               result = this.outParams.remove(qname);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2576 */         if (findReturnParam) {
/* 2577 */           String returnParamName = returnParamQName.toString();
/* 2578 */           throw new AxisFault(Messages.getMessage("noReturnParam", returnParamName));
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/* 2585 */         result = bodyEl.getValueAsType(getReturnType());
/* 2586 */       } catch (Exception e) {
/*      */         
/* 2588 */         result = bodyEl;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2593 */     if (log.isDebugEnabled()) {
/* 2594 */       log.debug("Exit: Call::invoke(RPCElement)");
/*      */     }
/*      */ 
/*      */     
/* 2598 */     if (this.operation != null && this.operation.getReturnClass() != null) {
/* 2599 */       result = JavaUtils.convert(result, this.operation.getReturnClass());
/*      */     }
/*      */     
/* 2602 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Class getJavaTypeForQName(QName name) {
/* 2612 */     if (this.operation == null) {
/* 2613 */       return null;
/*      */     }
/* 2615 */     ParameterDesc param = this.operation.getOutputParamByQName(name);
/* 2616 */     return (param == null) ? null : param.getJavaType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2625 */   public void setOption(String name, Object value) { this.service.getEngine().setOption(name, value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void invoke() {
/* 2637 */     if (log.isDebugEnabled()) {
/* 2638 */       log.debug("Enter: Call::invoke()");
/*      */     }
/*      */     
/* 2641 */     this.isNeverInvoked = false;
/*      */     
/* 2643 */     Message reqMsg = null;
/* 2644 */     SOAPEnvelope reqEnv = null;
/*      */     
/* 2646 */     this.msgContext.reset();
/* 2647 */     this.msgContext.setResponseMessage(null);
/* 2648 */     this.msgContext.setProperty("call_object", this);
/* 2649 */     this.msgContext.setProperty("wsdl.service", this.service);
/* 2650 */     this.msgContext.setProperty("wsdl.portName", getPortName());
/* 2651 */     if (this.isMsg) {
/* 2652 */       this.msgContext.setProperty("isMsg", "true");
/*      */     }
/*      */     
/* 2655 */     if (this.username != null) {
/* 2656 */       this.msgContext.setUsername(this.username);
/*      */     }
/* 2658 */     if (this.password != null) {
/* 2659 */       this.msgContext.setPassword(this.password);
/*      */     }
/* 2661 */     this.msgContext.setMaintainSession(this.maintainSession);
/*      */     
/* 2663 */     if (this.operation != null) {
/* 2664 */       this.msgContext.setOperation(this.operation);
/* 2665 */       this.operation.setStyle(getOperationStyle());
/* 2666 */       this.operation.setUse(getOperationUse());
/*      */     } 
/*      */     
/* 2669 */     if (this.useSOAPAction) {
/* 2670 */       this.msgContext.setUseSOAPAction(true);
/*      */     }
/* 2672 */     if (this.SOAPActionURI != null) {
/* 2673 */       this.msgContext.setSOAPActionURI(this.SOAPActionURI);
/*      */     } else {
/* 2675 */       this.msgContext.setSOAPActionURI(null);
/*      */     } 
/* 2677 */     if (this.timeout != null) {
/* 2678 */       this.msgContext.setTimeout(this.timeout.intValue());
/*      */     }
/* 2680 */     this.msgContext.setHighFidelity(!this.useStreaming);
/*      */ 
/*      */     
/* 2683 */     if (this.myService != null) {
/*      */       
/* 2685 */       this.msgContext.setService(this.myService);
/*      */     }
/* 2687 */     else if (this.portName != null) {
/*      */ 
/*      */       
/* 2690 */       this.msgContext.setTargetService(this.portName.getLocalPart());
/*      */     } else {
/*      */       
/* 2693 */       reqMsg = this.msgContext.getRequestMessage();
/*      */       
/* 2695 */       boolean isStream = ((SOAPPart)reqMsg.getSOAPPart()).isBodyStream();
/*      */       
/* 2697 */       if (reqMsg != null && !isStream) {
/* 2698 */         reqEnv = reqMsg.getSOAPEnvelope();
/*      */         
/* 2700 */         SOAPBodyElement body = reqEnv.getFirstBody();
/*      */         
/* 2702 */         if (body != null) {
/* 2703 */           if (body.getNamespaceURI() == null) {
/* 2704 */             throw new AxisFault("Call.invoke", Messages.getMessage("cantInvoke00", body.getName()), null, null);
/*      */           }
/*      */ 
/*      */           
/* 2708 */           this.msgContext.setTargetService(body.getNamespaceURI());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2714 */     if (log.isDebugEnabled()) {
/* 2715 */       log.debug(Messages.getMessage("targetService", this.msgContext.getTargetService()));
/*      */     }
/*      */ 
/*      */     
/* 2719 */     Message requestMessage = this.msgContext.getRequestMessage();
/* 2720 */     if (requestMessage != null) {
/*      */       try {
/* 2722 */         this.msgContext.setProperty("javax.xml.soap.character-set-encoding", requestMessage.getProperty("javax.xml.soap.character-set-encoding"));
/* 2723 */       } catch (SOAPException e) {}
/*      */ 
/*      */       
/* 2726 */       if (this.myHeaders != null) {
/* 2727 */         reqEnv = requestMessage.getSOAPEnvelope();
/*      */ 
/*      */         
/* 2730 */         for (int i = 0; this.myHeaders != null && i < this.myHeaders.size(); i++) {
/* 2731 */           reqEnv.addHeader((SOAPHeaderElement)this.myHeaders.get(i));
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2737 */     if (this.transport != null) {
/* 2738 */       this.transport.setupMessageContext(this.msgContext, this, this.service.getEngine());
/*      */     } else {
/*      */       
/* 2741 */       this.msgContext.setTransportName(this.transportName);
/*      */     } 
/*      */     
/* 2744 */     SOAPService svc = this.msgContext.getService();
/* 2745 */     if (svc != null) {
/* 2746 */       svc.setPropertyParent(this.myProperties);
/*      */     } else {
/* 2748 */       this.msgContext.setPropertyParent(this.myProperties);
/*      */     } 
/*      */ 
/*      */     
/* 2752 */     if (log.isDebugEnabled()) {
/* 2753 */       writer = new StringWriter();
/*      */       try {
/* 2755 */         SerializationContext ctx = new SerializationContext(writer, this.msgContext);
/*      */         
/* 2757 */         requestMessage.getSOAPEnvelope().output(ctx);
/* 2758 */         writer.close();
/* 2759 */       } catch (Exception e) {
/* 2760 */         throw AxisFault.makeFault(e);
/*      */       } finally {
/* 2762 */         log.debug(writer.getBuffer().toString());
/*      */       } 
/*      */     } 
/*      */     
/* 2766 */     if (!this.invokeOneWay) {
/* 2767 */       invokeEngine(this.msgContext);
/*      */     } else {
/* 2769 */       invokeEngineOneWay(this.msgContext);
/*      */     } 
/*      */     
/* 2772 */     if (log.isDebugEnabled()) {
/* 2773 */       log.debug("Exit: Call::invoke()");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invokeEngine(MessageContext msgContext) throws AxisFault {
/* 2784 */     this.service.getEngine().invoke(msgContext);
/*      */     
/* 2786 */     if (this.transport != null) {
/* 2787 */       this.transport.processReturnedMessageContext(msgContext);
/*      */     }
/*      */     
/* 2790 */     Message resMsg = msgContext.getResponseMessage();
/*      */     
/* 2792 */     if (resMsg == null) {
/* 2793 */       if (msgContext.isPropertyTrue("call.FaultOnNoResponse", false)) {
/* 2794 */         throw new AxisFault(Messages.getMessage("nullResponse00"));
/*      */       }
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 2802 */     resMsg.setMessageType("response");
/*      */     
/* 2804 */     SOAPEnvelope resEnv = resMsg.getSOAPEnvelope();
/*      */     
/* 2806 */     SOAPBodyElement respBody = resEnv.getFirstBody();
/* 2807 */     if (respBody instanceof SOAPFault)
/*      */     {
/* 2809 */       if (this.operation == null || this.operation.getReturnClass() == null || this.operation.getReturnClass() != javax.xml.soap.SOAPMessage.class)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2816 */         throw ((SOAPFault)respBody).getFault();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invokeEngineOneWay(MessageContext msgContext) throws AxisFault {
/* 2828 */     Runnable runnable = new Runnable(this, msgContext) { private final MessageContext val$msgContext; private final Call this$0;
/*      */         public void run() {
/* 2830 */           this.val$msgContext.setProperty("axis.one.way", Boolean.TRUE);
/*      */           try {
/* 2832 */             this.this$0.service.getEngine().invoke(this.val$msgContext);
/* 2833 */           } catch (AxisFault af) {
/*      */             
/* 2835 */             Call.log.debug(Messages.getMessage("exceptionPrinting"), af);
/*      */           } 
/* 2837 */           this.val$msgContext.removeProperty("axis.one.way");
/*      */         } }
/*      */       ;
/*      */     
/* 2841 */     Thread thread = new Thread(runnable);
/*      */     
/* 2843 */     thread.start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getOutputParams() {
/* 2856 */     if (this.isNeverInvoked) {
/* 2857 */       throw new JAXRPCException(Messages.getMessage("outputParamsUnavailable"));
/*      */     }
/*      */     
/* 2860 */     return this.outParams;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List getOutputValues() {
/* 2875 */     if (this.isNeverInvoked) {
/* 2876 */       throw new JAXRPCException(Messages.getMessage("outputParamsUnavailable"));
/*      */     }
/*      */     
/* 2879 */     return this.outParamsList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2891 */   public Service getService() { return this.service; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSOAPService(SOAPService service) {
/* 2902 */     this.myService = service;
/* 2903 */     if (service != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2910 */       service.setEngine(this.service.getAxisClient());
/* 2911 */       service.setPropertyParent(this.myProperties);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2924 */   public void setClientHandlers(Handler reqHandler, Handler respHandler) { setSOAPService(new SOAPService(reqHandler, null, respHandler)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2938 */   public void addAttachmentPart(Object attachment) { this.attachmentParts.add(attachment); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addFault(QName qname, Class cls, QName xmlType, boolean isComplex) {
/* 2953 */     if (this.operationSetManually) {
/* 2954 */       throw new RuntimeException(Messages.getMessage("operationAlreadySet"));
/*      */     }
/*      */ 
/*      */     
/* 2958 */     if (this.operation == null) {
/* 2959 */       this.operation = new OperationDesc();
/*      */     }
/*      */     
/* 2962 */     FaultDesc fault = new FaultDesc();
/* 2963 */     fault.setQName(qname);
/* 2964 */     fault.setClassName(cls.getName());
/* 2965 */     fault.setXmlType(xmlType);
/* 2966 */     fault.setComplex(isComplex);
/* 2967 */     this.operation.addFault(fault);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOperation(OperationDesc operation) {
/* 2978 */     this.operation = operation;
/* 2979 */     this.operationSetManually = true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2984 */   public OperationDesc getOperation() { return this.operation; }
/*      */ 
/*      */   
/*      */   public void clearOperation() {
/* 2988 */     this.operation = null;
/* 2989 */     this.operationSetManually = false;
/*      */   }
/*      */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\Call.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */