/*     */ package org.apache.axis.client;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.Service;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import javax.xml.rpc.Stub;
/*     */ import org.apache.axis.message.SOAPHeaderElement;
/*     */ import org.apache.axis.utils.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Stub
/*     */   implements Stub
/*     */ {
/*  39 */   protected Service service = null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean maintainSessionSet = false;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean maintainSession = false;
/*     */ 
/*     */   
/*  50 */   protected Properties cachedProperties = new Properties();
/*  51 */   protected String cachedUsername = null;
/*  52 */   protected String cachedPassword = null;
/*  53 */   protected URL cachedEndpoint = null;
/*  54 */   protected Integer cachedTimeout = null;
/*  55 */   protected QName cachedPortName = null;
/*     */ 
/*     */   
/*  58 */   private Vector headers = new Vector();
/*     */ 
/*     */   
/*  61 */   private Vector attachments = new Vector();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean firstCall = true;
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected Call _call = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean firstCall() {
/*  75 */     boolean ret = this.firstCall;
/*  76 */     this.firstCall = false;
/*  77 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void _setProperty(String name, Object value) {
/*  95 */     if (name == null || value == null) {
/*  96 */       throw new JAXRPCException(Messages.getMessage((name == null) ? "badProp03" : "badProp04"));
/*     */     }
/*     */ 
/*     */     
/* 100 */     if (name.equals("javax.xml.rpc.security.auth.username")) {
/* 101 */       if (!(value instanceof String)) {
/* 102 */         throw new JAXRPCException(Messages.getMessage("badProp00", new String[] { name, "java.lang.String", value.getClass().getName() }));
/*     */       }
/*     */ 
/*     */       
/* 106 */       this.cachedUsername = (String)value;
/*     */     }
/* 108 */     else if (name.equals("javax.xml.rpc.security.auth.password")) {
/* 109 */       if (!(value instanceof String)) {
/* 110 */         throw new JAXRPCException(Messages.getMessage("badProp00", new String[] { name, "java.lang.String", value.getClass().getName() }));
/*     */       }
/*     */ 
/*     */       
/* 114 */       this.cachedPassword = (String)value;
/*     */     }
/* 116 */     else if (name.equals("javax.xml.rpc.service.endpoint.address")) {
/* 117 */       if (!(value instanceof String)) {
/* 118 */         throw new JAXRPCException(Messages.getMessage("badProp00", new String[] { name, "java.lang.String", value.getClass().getName() }));
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 123 */         this.cachedEndpoint = new URL((String)value);
/*     */       }
/* 125 */       catch (MalformedURLException mue) {
/* 126 */         throw new JAXRPCException(mue.getMessage());
/*     */       }
/*     */     
/* 129 */     } else if (name.equals("javax.xml.rpc.session.maintain")) {
/* 130 */       if (!(value instanceof Boolean)) {
/* 131 */         throw new JAXRPCException(Messages.getMessage("badProp00", new String[] { name, "java.lang.Boolean", value.getClass().getName() }));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 137 */       this.maintainSessionSet = true;
/* 138 */       this.maintainSession = ((Boolean)value).booleanValue();
/*     */     } else {
/* 140 */       if (name.startsWith("java.") || name.startsWith("javax.")) {
/* 141 */         throw new JAXRPCException(Messages.getMessage("badProp05", name));
/*     */       }
/*     */ 
/*     */       
/* 145 */       this.cachedProperties.put(name, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object _getProperty(String name) {
/* 157 */     if (name == null) {
/* 158 */       throw new JAXRPCException(Messages.getMessage("badProp05", name));
/*     */     }
/*     */ 
/*     */     
/* 162 */     if (name.equals("javax.xml.rpc.security.auth.username")) {
/* 163 */       return this.cachedUsername;
/*     */     }
/* 165 */     if (name.equals("javax.xml.rpc.security.auth.password")) {
/* 166 */       return this.cachedPassword;
/*     */     }
/* 168 */     if (name.equals("javax.xml.rpc.service.endpoint.address")) {
/* 169 */       return this.cachedEndpoint.toString();
/*     */     }
/* 171 */     if (name.equals("javax.xml.rpc.session.maintain")) {
/* 172 */       return this.maintainSessionSet ? (this.maintainSession ? Boolean.TRUE : Boolean.FALSE) : null;
/*     */     }
/* 174 */     if (name.startsWith("java.") || name.startsWith("javax.")) {
/* 175 */       throw new JAXRPCException(Messages.getMessage("badProp05", name));
/*     */     }
/*     */ 
/*     */     
/* 179 */     return this.cachedProperties.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public Object removeProperty(String name) { return this.cachedProperties.remove(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public Iterator _getPropertyNames() { return this.cachedProperties.keySet().iterator(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public void setUsername(String username) { this.cachedUsername = username; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   public String getUsername() { return this.cachedUsername; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   public void setPassword(String password) { this.cachedPassword = password; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public String getPassword() { return this.cachedPassword; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public int getTimeout() { return (this.cachedTimeout == null) ? 0 : this.cachedTimeout.intValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   public void setTimeout(int timeout) { this.cachedTimeout = new Integer(timeout); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 247 */   public QName getPortName() { return this.cachedPortName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public void setPortName(QName portName) { this.cachedPortName = portName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public void setPortName(String portName) { setPortName(new QName(portName)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaintainSession(boolean session) {
/* 268 */     this.maintainSessionSet = true;
/* 269 */     this.maintainSession = session;
/* 270 */     this.cachedProperties.put("javax.xml.rpc.session.maintain", session ? Boolean.TRUE : Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public void setHeader(String namespace, String partName, Object headerValue) { this.headers.add(new SOAPHeaderElement(namespace, partName, headerValue)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 288 */   public void setHeader(SOAPHeaderElement header) { this.headers.add(header); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void extractAttachments(Call call) {
/* 296 */     this.attachments.clear();
/* 297 */     if (call.getResponseMessage() != null) {
/* 298 */       Iterator iterator = call.getResponseMessage().getAttachments();
/* 299 */       while (iterator.hasNext()) {
/* 300 */         this.attachments.add(iterator.next());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 310 */   public void addAttachment(Object handler) { this.attachments.add(handler); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPHeaderElement getHeader(String namespace, String partName) {
/* 317 */     for (int i = 0; i < this.headers.size(); i++) {
/* 318 */       SOAPHeaderElement header = (SOAPHeaderElement)this.headers.get(i);
/* 319 */       if (header.getNamespaceURI().equals(namespace) && header.getName().equals(partName))
/*     */       {
/* 321 */         return header; } 
/*     */     } 
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPHeaderElement getResponseHeader(String namespace, String partName) {
/*     */     try {
/* 332 */       if (this._call == null)
/* 333 */         return null; 
/* 334 */       return this._call.getResponseMessage().getSOAPEnvelope().getHeaderByName(namespace, partName);
/*     */     }
/* 336 */     catch (Exception e) {
/*     */       
/* 338 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPHeaderElement[] getHeaders() {
/* 346 */     SOAPHeaderElement[] array = new SOAPHeaderElement[this.headers.size()];
/* 347 */     this.headers.copyInto(array);
/* 348 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPHeaderElement[] getResponseHeaders() {
/* 355 */     SOAPHeaderElement[] array = new SOAPHeaderElement[0];
/*     */     
/*     */     try {
/* 358 */       if (this._call == null)
/* 359 */         return array; 
/* 360 */       Vector h = this._call.getResponseMessage().getSOAPEnvelope().getHeaders();
/* 361 */       array = new SOAPHeaderElement[h.size()];
/* 362 */       h.copyInto(array);
/* 363 */       return array;
/*     */     }
/* 365 */     catch (Exception e) {
/*     */       
/* 367 */       return array;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getAttachments() {
/* 378 */     Object[] array = new Object[this.attachments.size()];
/* 379 */     this.attachments.copyInto(array);
/* 380 */     this.attachments.clear();
/* 381 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 388 */   public void clearHeaders() { this.headers.clear(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 395 */   public void clearAttachments() { this.attachments.clear(); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRequestHeaders(Call call) {
/* 400 */     SOAPHeaderElement[] headers = getHeaders();
/* 401 */     for (int i = 0; i < headers.length; i++) {
/* 402 */       call.addHeader(headers[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setAttachments(Call call) {
/* 414 */     Object[] attachments = getAttachments();
/* 415 */     for (int i = 0; i < attachments.length; i++) {
/* 416 */       call.addAttachmentPart(attachments[i]);
/*     */     }
/* 418 */     clearAttachments();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 427 */   public Service _getService() { return this.service; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call _createCall() throws ServiceException {
/* 435 */     this._call = (Call)this.service.createCall();
/*     */ 
/*     */ 
/*     */     
/* 439 */     return this._call;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 446 */   public Call _getCall() throws ServiceException { return this._call; }
/*     */   
/*     */   protected void getResponseHeaders(Call call) {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\Stub.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */