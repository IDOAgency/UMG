/*    */ package org.apache.axis.client;
/*    */ 
/*    */ import org.apache.axis.AxisEngine;
/*    */ import org.apache.axis.AxisFault;
/*    */ import org.apache.axis.MessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Transport
/*    */ {
/* 28 */   public String transportName = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   public String url = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setupMessageContext(MessageContext context, Call message, AxisEngine engine) throws AxisFault {
/* 40 */     if (this.url != null) {
/* 41 */       context.setProperty("transport.url", this.url);
/*    */     }
/* 43 */     if (this.transportName != null) {
/* 44 */       context.setTransportName(this.transportName);
/*    */     }
/* 46 */     setupMessageContextImpl(context, message, engine);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setupMessageContextImpl(MessageContext context, Call message, AxisEngine engine) throws AxisFault {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void processReturnedMessageContext(MessageContext context) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public void setTransportName(String name) { this.transportName = name; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 79 */   public String getTransportName() { return this.transportName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 86 */   public String getUrl() { return this.url; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 93 */   public void setUrl(String url) { this.url = url; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\Transport.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */