/*     */ package org.apache.axis.client;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.rmi.Remote;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Vector;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.Referenceable;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.wsdl.Binding;
/*     */ import javax.wsdl.Operation;
/*     */ import javax.wsdl.Port;
/*     */ import javax.wsdl.PortType;
/*     */ import javax.wsdl.Service;
/*     */ import javax.wsdl.extensions.soap.SOAPAddress;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.Call;
/*     */ import javax.xml.rpc.Service;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import javax.xml.rpc.Stub;
/*     */ import javax.xml.rpc.encoding.TypeMappingRegistry;
/*     */ import javax.xml.rpc.handler.HandlerRegistry;
/*     */ import org.apache.axis.AxisEngine;
/*     */ import org.apache.axis.EngineConfiguration;
/*     */ import org.apache.axis.configuration.EngineConfigurationFactoryFinder;
/*     */ import org.apache.axis.encoding.TypeMappingRegistryImpl;
/*     */ import org.apache.axis.utils.ClassUtils;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.axis.utils.WSDLUtils;
/*     */ import org.apache.axis.utils.XMLUtils;
/*     */ import org.apache.axis.wsdl.gen.Parser;
/*     */ import org.apache.axis.wsdl.symbolTable.BindingEntry;
/*     */ import org.apache.axis.wsdl.symbolTable.ServiceEntry;
/*     */ import org.apache.axis.wsdl.symbolTable.SymbolTable;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Service
/*     */   implements Service, Serializable, Referenceable
/*     */ {
/*     */   private AxisEngine engine;
/*     */   private EngineConfiguration config;
/*     */   private QName serviceName;
/*     */   private String wsdlLocation;
/*     */   private Service wsdlService;
/*     */   private boolean maintainSession;
/*     */   private HandlerRegistryImpl registry;
/*     */   private Parser wsdlParser;
/*  83 */   private static Map cachedWSDL = new WeakHashMap();
/*     */ 
/*     */   
/*     */   private static boolean cachingWSDL = true;
/*     */ 
/*     */   
/*     */   protected Call _call;
/*     */ 
/*     */   
/*     */   private Hashtable transportImpls;
/*     */ 
/*     */ 
/*     */   
/*  96 */   protected Service getWSDLService() { return this.wsdlService; }
/*     */ 
/*     */ 
/*     */   
/* 100 */   public Parser getWSDLParser() { return this.wsdlParser; }
/*     */ 
/*     */ 
/*     */   
/* 104 */   protected AxisClient getAxisClient() { return new AxisClient(getEngineConfiguration()); } public Service() { this.engine = null; this.config = null;
/*     */     this.serviceName = null;
/*     */     this.wsdlLocation = null;
/*     */     this.wsdlService = null;
/*     */     this.maintainSession = false;
/*     */     this.registry = new HandlerRegistryImpl();
/*     */     this.wsdlParser = null;
/*     */     this._call = null;
/*     */     this.transportImpls = new Hashtable();
/* 113 */     this.engine = getAxisClient(); } public Service(QName serviceName) { this.engine = null; this.config = null;
/*     */     this.serviceName = null;
/*     */     this.wsdlLocation = null;
/*     */     this.wsdlService = null;
/*     */     this.maintainSession = false;
/*     */     this.registry = new HandlerRegistryImpl();
/*     */     this.wsdlParser = null;
/*     */     this._call = null;
/*     */     this.transportImpls = new Hashtable();
/* 122 */     this.serviceName = serviceName;
/* 123 */     this.engine = getAxisClient(); } public Service(EngineConfiguration engineConfiguration, AxisClient axisClient) { this.engine = null;
/*     */     this.config = null;
/*     */     this.serviceName = null;
/*     */     this.wsdlLocation = null;
/*     */     this.wsdlService = null;
/*     */     this.maintainSession = false;
/*     */     this.registry = new HandlerRegistryImpl();
/*     */     this.wsdlParser = null;
/*     */     this._call = null;
/*     */     this.transportImpls = new Hashtable();
/* 133 */     this.config = engineConfiguration;
/* 134 */     this.engine = axisClient; } public Service(EngineConfiguration config) { this.engine = null; this.config = null;
/*     */     this.serviceName = null;
/*     */     this.wsdlLocation = null;
/*     */     this.wsdlService = null;
/*     */     this.maintainSession = false;
/*     */     this.registry = new HandlerRegistryImpl();
/*     */     this.wsdlParser = null;
/*     */     this._call = null;
/*     */     this.transportImpls = new Hashtable();
/* 143 */     this.config = config;
/* 144 */     this.engine = getAxisClient(); }
/*     */   
/*     */   public Service(URL wsdlDoc, QName serviceName) throws ServiceException { this.engine = null;
/*     */     this.config = null;
/*     */     this.serviceName = null;
/*     */     this.wsdlLocation = null;
/*     */     this.wsdlService = null;
/*     */     this.maintainSession = false;
/*     */     this.registry = new HandlerRegistryImpl();
/*     */     this.wsdlParser = null;
/*     */     this._call = null;
/*     */     this.transportImpls = new Hashtable();
/* 156 */     this.serviceName = serviceName;
/* 157 */     this.engine = getAxisClient();
/* 158 */     this.wsdlLocation = wsdlDoc.toString();
/* 159 */     Parser parser = null;
/*     */     
/* 161 */     if (cachingWSDL && (parser = (Parser)cachedWSDL.get(this.wsdlLocation.toString())) != null) {
/*     */       
/* 163 */       initService(parser, serviceName);
/*     */     } else {
/* 165 */       initService(wsdlDoc.toString(), serviceName);
/*     */     }  } public Service(Parser parser, QName serviceName) throws ServiceException {
/*     */     this.engine = null;
/*     */     this.config = null;
/*     */     this.serviceName = null;
/*     */     this.wsdlLocation = null;
/*     */     this.wsdlService = null;
/*     */     this.maintainSession = false;
/*     */     this.registry = new HandlerRegistryImpl();
/*     */     this.wsdlParser = null;
/*     */     this._call = null;
/*     */     this.transportImpls = new Hashtable();
/* 177 */     this.serviceName = serviceName;
/* 178 */     this.engine = getAxisClient();
/* 179 */     initService(parser, serviceName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Service(String wsdlLocation, QName serviceName) throws ServiceException {
/*     */     this.engine = null;
/*     */     this.config = null;
/*     */     this.serviceName = null;
/*     */     this.wsdlLocation = null;
/*     */     this.wsdlService = null;
/*     */     this.maintainSession = false;
/*     */     this.registry = new HandlerRegistryImpl();
/*     */     this.wsdlParser = null;
/*     */     this._call = null;
/*     */     this.transportImpls = new Hashtable();
/* 195 */     this.serviceName = serviceName;
/* 196 */     this.wsdlLocation = wsdlLocation;
/* 197 */     this.engine = getAxisClient();
/*     */     
/* 199 */     Parser parser = null;
/* 200 */     if (cachingWSDL && (parser = (Parser)cachedWSDL.get(wsdlLocation)) != null) {
/*     */       
/* 202 */       initService(parser, serviceName);
/*     */     } else {
/* 204 */       initService(wsdlLocation, serviceName);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Service(InputStream wsdlInputStream, QName serviceName) throws ServiceException {
/*     */     this.engine = null;
/*     */     this.config = null;
/*     */     this.serviceName = null;
/*     */     this.wsdlLocation = null;
/*     */     this.wsdlService = null;
/*     */     this.maintainSession = false;
/*     */     this.registry = new HandlerRegistryImpl();
/*     */     this.wsdlParser = null;
/*     */     this._call = null;
/*     */     this.transportImpls = new Hashtable();
/* 220 */     this.engine = getAxisClient();
/* 221 */     Document doc = null;
/*     */     try {
/* 223 */       doc = XMLUtils.newDocument(wsdlInputStream);
/* 224 */     } catch (Exception exp) {
/* 225 */       throw new ServiceException(Messages.getMessage("wsdlError00", "", "\n" + exp));
/*     */     } 
/*     */     
/* 228 */     initService(null, doc, serviceName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initService(String url, QName serviceName) throws ServiceException {
/*     */     try {
/* 242 */       Parser parser = new Parser();
/* 243 */       parser.run(url);
/*     */       
/* 245 */       if (cachingWSDL && this.wsdlLocation != null) {
/* 246 */         cachedWSDL.put(url, parser);
/*     */       }
/* 248 */       initService(parser, serviceName);
/* 249 */     } catch (Exception exp) {
/* 250 */       throw new ServiceException(Messages.getMessage("wsdlError00", "", "\n" + exp), exp);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initService(String context, Document doc, QName serviceName) throws ServiceException {
/*     */     try {
/* 268 */       Parser parser = new Parser();
/* 269 */       parser.run(context, doc);
/*     */       
/* 271 */       initService(parser, serviceName);
/* 272 */     } catch (Exception exp) {
/* 273 */       throw new ServiceException(Messages.getMessage("wsdlError00", "", "\n" + exp));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initService(Parser parser, QName serviceName) throws ServiceException {
/*     */     try {
/* 288 */       this.wsdlParser = parser;
/* 289 */       ServiceEntry serviceEntry = parser.getSymbolTable().getServiceEntry(serviceName);
/* 290 */       if (serviceEntry != null)
/* 291 */         this.wsdlService = serviceEntry.getService(); 
/* 292 */       if (this.wsdlService == null) {
/* 293 */         throw new ServiceException(Messages.getMessage("noService00", "" + serviceName));
/*     */       }
/* 295 */     } catch (Exception exp) {
/* 296 */       throw new ServiceException(Messages.getMessage("wsdlError00", "", "\n" + exp));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Remote getPort(QName portName, Class proxyInterface) throws ServiceException {
/* 314 */     if (this.wsdlService == null) {
/* 315 */       throw new ServiceException(Messages.getMessage("wsdlMissing00"));
/*     */     }
/* 317 */     Port port = this.wsdlService.getPort(portName.getLocalPart());
/* 318 */     if (port == null) {
/* 319 */       throw new ServiceException(Messages.getMessage("noPort00", "" + portName));
/*     */     }
/*     */ 
/*     */     
/* 323 */     Remote stub = getGeneratedStub(portName, proxyInterface);
/* 324 */     return (stub != null) ? stub : getPort(null, portName, proxyInterface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Remote getGeneratedStub(QName portName, Class proxyInterface) throws ServiceException {
/*     */     try {
/* 338 */       String pkg = proxyInterface.getName();
/* 339 */       pkg = pkg.substring(0, pkg.lastIndexOf('.'));
/* 340 */       Port port = this.wsdlService.getPort(portName.getLocalPart());
/* 341 */       String binding = port.getBinding().getQName().getLocalPart();
/* 342 */       Class stubClass = ClassUtils.forName(pkg + "." + binding + "Stub");
/*     */       
/* 344 */       if (proxyInterface.isAssignableFrom(stubClass)) {
/* 345 */         Class[] formalArgs = { Service.class };
/* 346 */         Object[] actualArgs = { this };
/* 347 */         Constructor ctor = stubClass.getConstructor(formalArgs);
/* 348 */         Stub stub = (Stub)ctor.newInstance(actualArgs);
/* 349 */         stub._setProperty("javax.xml.rpc.service.endpoint.address", WSDLUtils.getAddressFromPort(port));
/*     */ 
/*     */         
/* 352 */         stub.setPortName(portName);
/* 353 */         return (Remote)stub;
/*     */       } 
/* 355 */       return null;
/*     */     }
/* 357 */     catch (Throwable t) {
/* 358 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Remote getPort(Class proxyInterface) throws ServiceException {
/* 371 */     if (this.wsdlService == null) {
/* 372 */       throw new ServiceException(Messages.getMessage("wsdlMissing00"));
/*     */     }
/* 374 */     Map ports = this.wsdlService.getPorts();
/* 375 */     if (ports == null || ports.size() <= 0) {
/* 376 */       throw new ServiceException(Messages.getMessage("noPort00", ""));
/*     */     }
/*     */     
/* 379 */     String clazzName = proxyInterface.getName();
/* 380 */     if (clazzName.lastIndexOf('.') != -1) {
/* 381 */       clazzName = clazzName.substring(clazzName.lastIndexOf('.') + 1);
/*     */     }
/*     */ 
/*     */     
/* 385 */     Port port = (Port)ports.get(clazzName);
/* 386 */     if (port == null)
/*     */     {
/* 388 */       port = (Port)ports.values().iterator().next();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 393 */     Remote stub = getGeneratedStub(new QName(port.getName()), proxyInterface);
/* 394 */     return (stub != null) ? stub : getPort(null, new QName(port.getName()), proxyInterface);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 411 */   public Remote getPort(String endpoint, Class proxyInterface) throws ServiceException { return getPort(endpoint, null, proxyInterface); }
/*     */ 
/*     */ 
/*     */   
/*     */   private Remote getPort(String endpoint, QName portName, Class proxyInterface) throws ServiceException {
/* 416 */     if (!proxyInterface.isInterface()) {
/* 417 */       throw new ServiceException(Messages.getMessage("mustBeIface00"));
/*     */     }
/*     */     
/* 420 */     if (!Remote.class.isAssignableFrom(proxyInterface)) {
/* 421 */       throw new ServiceException(Messages.getMessage("mustExtendRemote00"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 426 */     if (this.wsdlParser != null) {
/* 427 */       Port port = this.wsdlService.getPort(portName.getLocalPart());
/* 428 */       if (port == null) {
/* 429 */         throw new ServiceException(Messages.getMessage("noPort00", "" + proxyInterface.getName()));
/*     */       }
/* 431 */       Binding binding = port.getBinding();
/* 432 */       SymbolTable symbolTable = this.wsdlParser.getSymbolTable();
/* 433 */       BindingEntry bEntry = symbolTable.getBindingEntry(binding.getQName());
/* 434 */       if (bEntry.getParameters().size() != proxyInterface.getMethods().length) {
/* 435 */         throw new ServiceException(Messages.getMessage("incompatibleSEI00", "" + proxyInterface.getName()));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 441 */       Call call = null;
/* 442 */       if (portName == null) {
/* 443 */         call = (Call)createCall();
/* 444 */         if (endpoint != null) {
/* 445 */           call.setTargetEndpointAddress(new URL(endpoint));
/*     */         }
/*     */       } else {
/* 448 */         call = (Call)createCall(portName);
/*     */       } 
/* 450 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */       
/* 452 */       Stub stub = (Stub)Proxy.newProxyInstance(classLoader, new Class[] { proxyInterface, Stub.class }, new AxisClientProxy(call, portName));
/*     */ 
/*     */       
/* 455 */       if (stub instanceof Stub) {
/* 456 */         ((Stub)stub).setPortName(portName);
/*     */       }
/* 458 */       return (Remote)stub;
/* 459 */     } catch (Exception e) {
/* 460 */       throw new ServiceException(Messages.getMessage("wsdlError00", "", "\n" + e));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call createCall(QName portName) throws ServiceException {
/* 475 */     Call call = (Call)createCall();
/* 476 */     call.setPortName(portName);
/*     */ 
/*     */ 
/*     */     
/* 480 */     if (this.wsdlParser == null) {
/* 481 */       return call;
/*     */     }
/* 483 */     Port port = this.wsdlService.getPort(portName.getLocalPart());
/* 484 */     if (port == null) {
/* 485 */       throw new ServiceException(Messages.getMessage("noPort00", "" + portName));
/*     */     }
/* 487 */     Binding binding = port.getBinding();
/* 488 */     PortType portType = binding.getPortType();
/* 489 */     if (portType == null) {
/* 490 */       throw new ServiceException(Messages.getMessage("noPortType00", "" + portName));
/*     */     }
/*     */ 
/*     */     
/* 494 */     List list = port.getExtensibilityElements();
/* 495 */     for (int i = 0; list != null && i < list.size(); i++) {
/* 496 */       Object obj = list.get(i);
/* 497 */       if (obj instanceof SOAPAddress) {
/*     */         try {
/* 499 */           SOAPAddress addr = (SOAPAddress)obj;
/* 500 */           URL url = new URL(addr.getLocationURI());
/* 501 */           call.setTargetEndpointAddress(url);
/* 502 */         } catch (Exception exp) {
/* 503 */           throw new ServiceException(Messages.getMessage("cantSetURI00", "" + exp));
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 509 */     return call;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call createCall(QName portName, String operationName) throws ServiceException {
/* 526 */     Call call = (Call)createCall();
/* 527 */     call.setOperation(portName, operationName);
/* 528 */     return call;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call createCall(QName portName, QName operationName) throws ServiceException {
/* 545 */     Call call = (Call)createCall();
/* 546 */     call.setOperation(portName, operationName);
/* 547 */     return call;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call createCall() throws ServiceException {
/* 559 */     this._call = new Call(this);
/* 560 */     return this._call;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call[] getCalls(QName portName) throws ServiceException {
/* 577 */     if (portName == null) {
/* 578 */       throw new ServiceException(Messages.getMessage("badPort00"));
/*     */     }
/* 580 */     if (this.wsdlService == null) {
/* 581 */       throw new ServiceException(Messages.getMessage("wsdlMissing00"));
/*     */     }
/* 583 */     Port port = this.wsdlService.getPort(portName.getLocalPart());
/* 584 */     if (port == null) {
/* 585 */       throw new ServiceException(Messages.getMessage("noPort00", "" + portName));
/*     */     }
/* 587 */     Binding binding = port.getBinding();
/* 588 */     SymbolTable symbolTable = this.wsdlParser.getSymbolTable();
/* 589 */     BindingEntry bEntry = symbolTable.getBindingEntry(binding.getQName());
/*     */     
/* 591 */     Iterator i = bEntry.getParameters().keySet().iterator();
/*     */     
/* 593 */     Vector calls = new Vector();
/* 594 */     while (i.hasNext()) {
/* 595 */       Operation operation = (Operation)i.next();
/* 596 */       Call call = createCall(QName.valueOf(port.getName()), QName.valueOf(operation.getName()));
/*     */       
/* 598 */       calls.add(call);
/*     */     } 
/* 600 */     Call[] array = new Call[calls.size()];
/* 601 */     calls.toArray(array);
/* 602 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 619 */   public HandlerRegistry getHandlerRegistry() { return this.registry; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getWSDLDocumentLocation() {
/*     */     try {
/* 630 */       return new URL(this.wsdlLocation);
/* 631 */     } catch (MalformedURLException e) {
/* 632 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getServiceName() {
/* 642 */     if (this.serviceName != null) return this.serviceName; 
/* 643 */     if (this.wsdlService == null) return null; 
/* 644 */     QName qn = this.wsdlService.getQName();
/* 645 */     return new QName(qn.getNamespaceURI(), qn.getLocalPart());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getPorts() throws ServiceException {
/* 659 */     if (this.wsdlService == null) {
/* 660 */       throw new ServiceException(Messages.getMessage("wsdlMissing00"));
/*     */     }
/* 662 */     if (this.wsdlService.getPorts() == null)
/*     */     {
/* 664 */       return (new Vector()).iterator();
/*     */     }
/*     */     
/* 667 */     Map portmap = this.wsdlService.getPorts();
/* 668 */     List portlist = new ArrayList(portmap.size());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 674 */     Iterator portiterator = portmap.values().iterator();
/* 675 */     while (portiterator.hasNext()) {
/* 676 */       Port port = (Port)portiterator.next();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 682 */       portlist.add(new QName(this.wsdlService.getQName().getNamespaceURI(), port.getName()));
/*     */     } 
/*     */ 
/*     */     
/* 686 */     return portlist.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeMappingRegistry(TypeMappingRegistry registry) throws ServiceException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 705 */   public TypeMappingRegistry getTypeMappingRegistry() { return this.engine.getTypeMappingRegistry(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() {
/* 714 */     String classname = getClass().getName();
/* 715 */     Reference reference = new Reference(classname, "org.apache.axis.client.ServiceFactory", null);
/*     */     
/* 717 */     StringRefAddr addr = null;
/* 718 */     if (!classname.equals("org.apache.axis.client.Service")) {
/*     */ 
/*     */       
/* 721 */       addr = new StringRefAddr("service classname", classname);
/*     */       
/* 723 */       reference.add(addr);
/*     */     } else {
/* 725 */       if (this.wsdlLocation != null) {
/* 726 */         addr = new StringRefAddr("WSDL location", this.wsdlLocation.toString());
/*     */         
/* 728 */         reference.add(addr);
/*     */       } 
/* 730 */       QName serviceName = getServiceName();
/* 731 */       if (serviceName != null) {
/* 732 */         addr = new StringRefAddr("service namespace", serviceName.getNamespaceURI());
/*     */         
/* 734 */         reference.add(addr);
/* 735 */         addr = new StringRefAddr("service local part", serviceName.getLocalPart());
/*     */         
/* 737 */         reference.add(addr);
/*     */       } 
/*     */     } 
/* 740 */     if (this.maintainSession) {
/* 741 */       addr = new StringRefAddr("maintain session", "true");
/* 742 */       reference.add(addr);
/*     */     } 
/* 744 */     return reference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 756 */   public void setEngine(AxisEngine engine) { this.engine = engine; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 768 */   public AxisEngine getEngine() { return this.engine; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 805 */   public void setEngineConfiguration(EngineConfiguration config) { this.config = config; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EngineConfiguration getEngineConfiguration() {
/* 812 */     if (this.config == null) {
/* 813 */       this.config = EngineConfigurationFactoryFinder.newFactory().getClientEngineConfig();
/*     */     }
/* 815 */     return this.config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 830 */   public void setMaintainSession(boolean yesno) { this.maintainSession = yesno; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 837 */   public boolean getMaintainSession() { return this.maintainSession; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 848 */   public Call getCall() throws ServiceException { return this._call; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 855 */   public boolean getCacheWSDL() { return cachingWSDL; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 863 */   public void setCacheWSDL(boolean flag) { cachingWSDL = flag; }
/*     */   
/*     */   protected static class HandlerRegistryImpl
/*     */     implements HandlerRegistry {
/* 867 */     Map map = new HashMap();
/*     */ 
/*     */     
/*     */     public List getHandlerChain(QName portName) {
/* 871 */       String key = portName.getLocalPart();
/* 872 */       List list = (List)this.map.get(key);
/* 873 */       if (list == null) {
/* 874 */         list = new ArrayList();
/* 875 */         setHandlerChain(portName, list);
/*     */       } 
/* 877 */       return list;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 882 */     public void setHandlerChain(QName portName, List chain) { this.map.put(portName.getLocalPart(), chain); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 890 */   void registerTransportForURL(URL url, Transport transport) { this.transportImpls.put(url.toString(), transport); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 897 */   Transport getTransportForURL(URL url) { return (Transport)this.transportImpls.get(url.toString()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 905 */   public void setTypeMappingVersion(String version) { ((TypeMappingRegistryImpl)getTypeMappingRegistry()).doRegisterFromVersion(version); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\Service.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */