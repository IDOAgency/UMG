package org.apache.axis.client;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.xml.rpc.ServiceException;
import org.apache.axis.AxisFault;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.deployment.wsdd.WSDDConstants;
import org.apache.axis.message.SOAPBodyElement;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.Options;
import org.apache.axis.utils.StringUtils;
import org.apache.commons.logging.Log;

public class AdminClient {
  protected static Log log = LogFactory.getLog(AdminClient.class.getName());
  
  private static ThreadLocal defaultConfiguration = new ThreadLocal();
  
  protected Call call;
  
  public static void setDefaultConfiguration(EngineConfiguration config) { defaultConfiguration.set(config); }
  
  private static String getUsageInfo() {
    lSep = System.getProperty("line.separator");
    StringBuffer msg = new StringBuffer();
    msg.append(Messages.getMessage("acUsage00")).append(lSep);
    msg.append(Messages.getMessage("acUsage01")).append(lSep);
    msg.append(Messages.getMessage("acUsage02")).append(lSep);
    msg.append(Messages.getMessage("acUsage03")).append(lSep);
    msg.append(Messages.getMessage("acUsage04")).append(lSep);
    msg.append(Messages.getMessage("acUsage05")).append(lSep);
    msg.append(Messages.getMessage("acUsage06")).append(lSep);
    msg.append(Messages.getMessage("acUsage07")).append(lSep);
    msg.append(Messages.getMessage("acUsage08")).append(lSep);
    msg.append(Messages.getMessage("acUsage09")).append(lSep);
    msg.append(Messages.getMessage("acUsage10")).append(lSep);
    msg.append(Messages.getMessage("acUsage11")).append(lSep);
    msg.append(Messages.getMessage("acUsage12")).append(lSep);
    msg.append(Messages.getMessage("acUsage13")).append(lSep);
    msg.append(Messages.getMessage("acUsage14")).append(lSep);
    msg.append(Messages.getMessage("acUsage15")).append(lSep);
    msg.append(Messages.getMessage("acUsage16")).append(lSep);
    msg.append(Messages.getMessage("acUsage17")).append(lSep);
    msg.append(Messages.getMessage("acUsage18")).append(lSep);
    msg.append(Messages.getMessage("acUsage19")).append(lSep);
    msg.append(Messages.getMessage("acUsage20")).append(lSep);
    msg.append(Messages.getMessage("acUsage21")).append(lSep);
    msg.append(Messages.getMessage("acUsage22")).append(lSep);
    msg.append(Messages.getMessage("acUsage23")).append(lSep);
    msg.append(Messages.getMessage("acUsage24")).append(lSep);
    msg.append(Messages.getMessage("acUsage25")).append(lSep);
    msg.append(Messages.getMessage("acUsage26")).append(lSep);
    return msg.toString();
  }
  
  public AdminClient() {
    try {
      initAdminClient();
    } catch (ServiceException e) {
      System.err.println(Messages.getMessage("couldntCall00") + ": " + e);
      this.call = null;
    } 
  }
  
  public AdminClient(boolean ignored) throws ServiceException { initAdminClient(); }
  
  private void initAdminClient() {
    Service service;
    EngineConfiguration config = (EngineConfiguration)defaultConfiguration.get();
    if (config != null) {
      service = new Service(config);
    } else {
      service = new Service();
    } 
    this.call = (Call)service.createCall();
  }
  
  public Call getCall() { return this.call; }
  
  public String list(Options opts) throws Exception {
    processOpts(opts);
    return list();
  }
  
  public String list() {
    log.debug(Messages.getMessage("doList00"));
    String str = "<m:list xmlns:m=\"http://xml.apache.org/axis/wsdd/\"/>";
    ByteArrayInputStream input = new ByteArrayInputStream(str.getBytes());
    return process(input);
  }
  
  public String quit(Options opts) throws Exception {
    processOpts(opts);
    return quit();
  }
  
  protected static final String ROOT_UNDEPLOY = WSDDConstants.QNAME_UNDEPLOY.getLocalPart();
  
  public String quit() {
    log.debug(Messages.getMessage("doQuit00"));
    String str = "<m:quit xmlns:m=\"http://xml.apache.org/axis/wsdd/\"/>";
    ByteArrayInputStream input = new ByteArrayInputStream(str.getBytes());
    return process(input);
  }
  
  public String undeployHandler(String handlerName) throws Exception {
    log.debug(Messages.getMessage("doQuit00"));
    String str = "<m:" + ROOT_UNDEPLOY + " xmlns:m=\"" + "http://xml.apache.org/axis/wsdd/" + "\">" + "<handler name=\"" + handlerName + "\"/>" + "</m:" + ROOT_UNDEPLOY + ">";
    ByteArrayInputStream input = new ByteArrayInputStream(str.getBytes());
    return process(input);
  }
  
  public String undeployService(String serviceName) throws Exception {
    log.debug(Messages.getMessage("doQuit00"));
    String str = "<m:" + ROOT_UNDEPLOY + " xmlns:m=\"" + "http://xml.apache.org/axis/wsdd/" + "\">" + "<service name=\"" + serviceName + "\"/>" + "</m:" + ROOT_UNDEPLOY + ">";
    ByteArrayInputStream input = new ByteArrayInputStream(str.getBytes());
    return process(input);
  }
  
  public String process(String[] args) throws Exception {
    StringBuffer sb = new StringBuffer();
    Options opts = new Options(args);
    opts.setDefaultURL("http://localhost:8080/axis/services/AdminService");
    if (opts.isFlagSet('d') > 0);
    args = opts.getRemainingArgs();
    if (args == null || opts.isFlagSet('?') > 0) {
      System.out.println(Messages.getMessage("usage00", "AdminClient [Options] [list | <deployment-descriptor-files>]"));
      System.out.println("");
      System.out.println(getUsageInfo());
      return null;
    } 
    for (int i = 0; i < args.length; i++) {
      InputStream input = null;
      if (args[i].equals("list")) {
        sb.append(list(opts));
      } else if (args[i].equals("quit")) {
        sb.append(quit(opts));
      } else if (args[i].equals("passwd")) {
        System.out.println(Messages.getMessage("changePwd00"));
        if (args[i + true] == null) {
          System.err.println(Messages.getMessage("needPwd00"));
          return null;
        } 
        String str = "<m:passwd xmlns:m=\"http://xml.apache.org/axis/wsdd/\">";
        str = str + args[i + 1];
        str = str + "</m:passwd>";
        input = new ByteArrayInputStream(str.getBytes());
        i++;
        sb.append(process(opts, input));
      } else if (args[i].indexOf(File.pathSeparatorChar) == -1) {
        System.out.println(Messages.getMessage("processFile00", args[i]));
        sb.append(process(opts, args[i]));
      } else {
        StringTokenizer tokenizer = null;
        tokenizer = new StringTokenizer(args[i], File.pathSeparator);
        while (tokenizer.hasMoreTokens()) {
          String file = tokenizer.nextToken();
          System.out.println(Messages.getMessage("processFile00", file));
          sb.append(process(opts, file));
          if (tokenizer.hasMoreTokens())
            sb.append("\n"); 
        } 
      } 
    } 
    return sb.toString();
  }
  
  public void processOpts(Options opts) throws Exception {
    if (this.call == null)
      throw new Exception(Messages.getMessage("nullCall00")); 
    URL address = new URL(opts.getURL());
    setTargetEndpointAddress(address);
    setLogin(opts.getUser(), opts.getPassword());
    String tName = opts.isValueSet('t');
    setTransport(tName);
  }
  
  public void setLogin(String user, String password) {
    this.call.setUsername(user);
    this.call.setPassword(password);
  }
  
  public void setTargetEndpointAddress(URL address) { this.call.setTargetEndpointAddress(address); }
  
  public void setTransport(String transportName) {
    if (transportName != null && !transportName.equals(""))
      this.call.setProperty("transport_name", transportName); 
  }
  
  public String process(InputStream input) throws Exception { return process(null, input); }
  
  public String process(URL xmlURL) throws Exception { return process(null, xmlURL.openStream()); }
  
  public String process(String xmlFile) throws Exception {
    FileInputStream in = new FileInputStream(xmlFile);
    return process(null, in);
  }
  
  public String process(Options opts, String xmlFile) throws Exception {
    processOpts(opts);
    return process(xmlFile);
  }
  
  public String process(Options opts, InputStream input) throws Exception {
    try {
      if (this.call == null)
        throw new Exception(Messages.getMessage("nullCall00")); 
      if (opts != null)
        processOpts(opts); 
      this.call.setUseSOAPAction(true);
      this.call.setSOAPActionURI("urn:AdminService");
      Vector result = null;
      Object[] params = { new SOAPBodyElement(input) };
      result = (Vector)this.call.invoke(params);
      if (result == null || result.isEmpty())
        throw new AxisFault(Messages.getMessage("nullResponse00")); 
      SOAPBodyElement body = (SOAPBodyElement)result.elementAt(0);
      return body.toString();
    } finally {
      input.close();
    } 
  }
  
  public static void main(String[] args) {
    try {
      AdminClient admin = new AdminClient();
      String result = admin.process(args);
      if (result != null) {
        System.out.println(StringUtils.unescapeNumericChar(result));
      } else {
        System.exit(1);
      } 
    } catch (AxisFault ae) {
      System.err.println(Messages.getMessage("exception00") + " " + ae.dumpToString());
      System.exit(1);
    } catch (Exception e) {
      System.err.println(Messages.getMessage("exception00") + " " + e.getMessage());
      System.exit(1);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\AdminClient.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */