package org.apache.axis.client;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.JarURLConnection;
import java.net.URL;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;

public class HappyClient {
  PrintStream out;
  
  public HappyClient(PrintStream out) { this.out = out; }
  
  Class classExists(String classname) {
    try {
      return Class.forName(classname);
    } catch (ClassNotFoundException e) {
      return null;
    } 
  }
  
  boolean resourceExists(String resource) {
    InputStream instream = ClassUtils.getResourceAsStream(getClass(), resource);
    boolean found = (instream != null);
    if (instream != null)
      try {
        instream.close();
      } catch (IOException e) {} 
    return found;
  }
  
  int probeClass(String category, String classname, String jarFile, String description, String errorText, String homePage) throws IOException {
    String url = "";
    if (homePage != null)
      url = Messages.getMessage("happyClientHomepage", homePage); 
    String errorLine = "";
    if (errorText != null)
      errorLine = Messages.getMessage(errorText); 
    try {
      String text;
      Class clazz = classExists(classname);
      if (clazz == null) {
        String text = Messages.getMessage("happyClientMissingClass", category, classname, jarFile);
        this.out.println(text);
        this.out.println(url);
        return 1;
      } 
      String location = getLocation(clazz);
      if (location == null) {
        text = Messages.getMessage("happyClientFoundDescriptionClass", description, classname);
      } else {
        text = Messages.getMessage("happyClientFoundDescriptionClassLocation", description, classname, location);
      } 
      this.out.println(text);
      return 0;
    } catch (NoClassDefFoundError ncdfe) {
      this.out.println(Messages.getMessage("happyClientNoDependency", category, classname, jarFile));
      this.out.println(errorLine);
      this.out.println(url);
      this.out.println(ncdfe.getMessage());
      return 1;
    } 
  }
  
  String getLocation(Class clazz) {
    try {
      URL url = clazz.getProtectionDomain().getCodeSource().getLocation();
      String location = url.toString();
      if (location.startsWith("jar")) {
        url = ((JarURLConnection)url.openConnection()).getJarFileURL();
        location = url.toString();
      } 
      if (location.startsWith("file")) {
        File file = new File(url.getFile());
        return file.getAbsolutePath();
      } 
      return url.toString();
    } catch (Throwable t) {
      return Messages.getMessage("happyClientUnknownLocation");
    } 
  }
  
  int needClass(String classname, String jarFile, String description, String errorText, String homePage) throws IOException { return probeClass(Messages.getMessage("happyClientError"), classname, jarFile, description, errorText, homePage); }
  
  int wantClass(String classname, String jarFile, String description, String errorText, String homePage) throws IOException { return probeClass(Messages.getMessage("happyClientWarning"), classname, jarFile, description, errorText, homePage); }
  
  int wantResource(String resource, String errorText) throws Exception {
    if (!resourceExists(resource)) {
      this.out.println(Messages.getMessage("happyClientNoResource", resource));
      this.out.println(errorText);
      return 0;
    } 
    this.out.println(Messages.getMessage("happyClientFoundResource", resource));
    return 1;
  }
  
  private String getParserName() {
    SAXParser saxParser = getSAXParser();
    if (saxParser == null)
      return Messages.getMessage("happyClientNoParser"); 
    return saxParser.getClass().getName();
  }
  
  private SAXParser getSAXParser() {
    SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
    if (saxParserFactory == null)
      return null; 
    SAXParser saxParser = null;
    try {
      saxParser = saxParserFactory.newSAXParser();
    } catch (Exception e) {}
    return saxParser;
  }
  
  private String getParserLocation() {
    SAXParser saxParser = getSAXParser();
    if (saxParser == null)
      return null; 
    return getLocation(saxParser.getClass());
  }
  
  public int getJavaVersionNumber() {
    int javaVersionNumber = 10;
    try {
      Class.forName("java.lang.Void");
      javaVersionNumber++;
      Class.forName("java.lang.ThreadLocal");
      javaVersionNumber++;
      Class.forName("java.lang.StrictMath");
      javaVersionNumber++;
      Class.forName("java.lang.CharSequence");
      javaVersionNumber++;
    } catch (Throwable t) {}
    return javaVersionNumber;
  }
  
  private void title(String title) {
    this.out.println();
    String message = Messages.getMessage(title);
    this.out.println(message);
    for (int i = 0; i < message.length(); i++)
      this.out.print("="); 
    this.out.println();
  }
  
  public boolean verifyClientIsHappy(boolean warningsAsErrors) throws IOException {
    boolean bool;
    int needed = 0, wanted = 0;
    this.out.println();
    title("happyClientTitle");
    title("happyClientNeeded");
    needed = needClass("javax.xml.soap.SOAPMessage", "saaj.jar", "SAAJ", "happyClientNoAxis", "http://xml.apache.org/axis/");
    needed += needClass("javax.xml.rpc.Service", "jaxrpc.jar", "JAX-RPC", "happyClientNoAxis", "http://xml.apache.org/axis/");
    needed += needClass("org.apache.commons.discovery.Resource", "commons-discovery.jar", "Jakarta-Commons Discovery", "happyClientNoAxis", "http://jakarta.apache.org/commons/discovery.html");
    needed += needClass("org.apache.commons.logging.Log", "commons-logging.jar", "Jakarta-Commons Logging", "happyClientNoAxis", "http://jakarta.apache.org/commons/logging.html");
    needed += needClass("org.apache.log4j.Layout", "log4j-1.2.4.jar", "Log4j", "happyClientNoLog4J", "http://jakarta.apache.org/log4j");
    needed += needClass("com.ibm.wsdl.factory.WSDLFactoryImpl", "wsdl4j.jar", "WSDL4Java", "happyClientNoAxis", null);
    needed += needClass("javax.xml.parsers.SAXParserFactory", "xerces.jar", "JAXP", "happyClientNoAxis", "http://xml.apache.org/xerces-j/");
    title("happyClientOptional");
    wanted += wantClass("javax.mail.internet.MimeMessage", "mail.jar", "Mail", "happyClientNoAttachments", "http://java.sun.com/products/javamail/");
    wanted += wantClass("javax.activation.DataHandler", "activation.jar", "Activation", "happyClientNoAttachments", "http://java.sun.com/products/javabeans/glasgow/jaf.html");
    wanted += wantClass("org.apache.xml.security.Init", "xmlsec.jar", "XML Security", "happyClientNoSecurity", "http://xml.apache.org/security/");
    wanted += wantClass("javax.net.ssl.SSLSocketFactory", Messages.getMessage("happyClientJSSEsources"), "Java Secure Socket Extension", "happyClientNoHTTPS", "http://java.sun.com/products/jsse/");
    int warningMessages = 0;
    String xmlParser = getParserName();
    String xmlParserLocation = getParserLocation();
    this.out.println(Messages.getMessage("happyClientXMLinfo", xmlParser, xmlParserLocation));
    if (xmlParser.indexOf("xerces") <= 0) {
      warningMessages++;
      this.out.println();
      this.out.println(Messages.getMessage("happyClientRecommendXerces"));
    } 
    if (getJavaVersionNumber() < 13) {
      warningMessages++;
      this.out.println();
      this.out.println(Messages.getMessage("happyClientUnsupportedJVM"));
    } 
    title("happyClientSummary");
    if (needed == 0) {
      this.out.println(Messages.getMessage("happyClientCorePresent"));
      bool = true;
    } else {
      bool = false;
      this.out.println(Messages.getMessage("happyClientCoreMissing", Integer.toString(needed)));
    } 
    if (wanted > 0) {
      this.out.println();
      this.out.println(Messages.getMessage("happyClientOptionalMissing", Integer.toString(wanted)));
      this.out.println(Messages.getMessage("happyClientOptionalOK"));
      if (warningsAsErrors)
        bool = false; 
    } else {
      this.out.println(Messages.getMessage("happyClientOptionalPresent"));
    } 
    if (warningMessages > 0) {
      this.out.println(Messages.getMessage("happyClientWarningMessageCount", Integer.toString(warningMessages)));
      if (warningsAsErrors)
        bool = false; 
    } 
    return bool;
  }
  
  public static void main(String[] args) {
    boolean isHappy = isClientHappy(args);
    System.exit(isHappy ? 0 : -1);
  }
  
  private static boolean isClientHappy(String[] args) {
    boolean isHappy;
    HappyClient happy = new HappyClient(System.out);
    int missing = 0;
    try {
      isHappy = happy.verifyClientIsHappy(false);
      for (int i = 0; i < args.length; i++)
        missing += happy.probeClass("argument", args[i], null, null, null, null); 
      if (missing > 0)
        isHappy = false; 
    } catch (IOException e) {
      e.printStackTrace();
      isHappy = false;
    } 
    return isHappy;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\client\HappyClient.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */