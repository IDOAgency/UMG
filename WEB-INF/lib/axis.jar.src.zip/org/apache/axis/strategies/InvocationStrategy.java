/*    */ package org.apache.axis.strategies;
/*    */ 
/*    */ import org.apache.axis.AxisFault;
/*    */ import org.apache.axis.Handler;
/*    */ import org.apache.axis.HandlerIterationStrategy;
/*    */ import org.apache.axis.MessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvocationStrategy
/*    */   implements HandlerIterationStrategy
/*    */ {
/* 32 */   public void visit(Handler handler, MessageContext msgContext) throws AxisFault { handler.invoke(msgContext); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\strategies\InvocationStrategy.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */