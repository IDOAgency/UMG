package org.apache.axis.enum;

import org.apache.axis.constants.Style;

public class Style extends Style {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\enum\Style.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */