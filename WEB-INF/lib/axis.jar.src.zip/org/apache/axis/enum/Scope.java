package org.apache.axis.enum;

import org.apache.axis.constants.Scope;

public class Scope extends Scope {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\enum\Scope.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */