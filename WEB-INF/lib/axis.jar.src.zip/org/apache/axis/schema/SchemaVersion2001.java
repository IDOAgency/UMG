package org.apache.axis.schema;

import javax.xml.namespace.QName;
import org.apache.axis.Constants;
import org.apache.axis.encoding.TypeMappingImpl;
import org.apache.axis.encoding.ser.CalendarDeserializerFactory;
import org.apache.axis.encoding.ser.CalendarSerializerFactory;

public class SchemaVersion2001 implements SchemaVersion {
  public static QName QNAME_NIL = new QName("http://www.w3.org/2001/XMLSchema-instance", "nil");
  
  public QName getNilQName() { return QNAME_NIL; }
  
  public String getXsiURI() { return "http://www.w3.org/2001/XMLSchema-instance"; }
  
  public String getXsdURI() { return "http://www.w3.org/2001/XMLSchema"; }
  
  public void registerSchemaSpecificTypes(TypeMappingImpl tm) {
    tm.register(java.util.Date.class, Constants.XSD_DATETIME, new CalendarSerializerFactory(java.util.Date.class, Constants.XSD_DATETIME), new CalendarDeserializerFactory(java.util.Date.class, Constants.XSD_DATETIME));
    tm.register(java.util.Calendar.class, Constants.XSD_DATETIME, new CalendarSerializerFactory(java.util.Calendar.class, Constants.XSD_DATETIME), new CalendarDeserializerFactory(java.util.Calendar.class, Constants.XSD_DATETIME));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\schema\SchemaVersion2001.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */