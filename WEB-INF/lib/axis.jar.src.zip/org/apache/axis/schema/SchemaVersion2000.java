/*    */ package org.apache.axis.schema;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.TypeMappingImpl;
/*    */ import org.apache.axis.encoding.ser.CalendarDeserializerFactory;
/*    */ import org.apache.axis.encoding.ser.CalendarSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SchemaVersion2000
/*    */   implements SchemaVersion
/*    */ {
/* 32 */   public static QName QNAME_NIL = new QName("http://www.w3.org/2000/10/XMLSchema-instance", "null");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   public QName getNilQName() { return QNAME_NIL; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public String getXsiURI() { return "http://www.w3.org/2000/10/XMLSchema-instance"; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 63 */   public String getXsdURI() { return "http://www.w3.org/2000/10/XMLSchema"; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public void registerSchemaSpecificTypes(TypeMappingImpl tm) { tm.register(java.util.Calendar.class, Constants.XSD_TIMEINSTANT2000, new CalendarSerializerFactory(java.util.Calendar.class, Constants.XSD_TIMEINSTANT2000), new CalendarDeserializerFactory(java.util.Calendar.class, Constants.XSD_TIMEINSTANT2000)); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\schema\SchemaVersion2000.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */