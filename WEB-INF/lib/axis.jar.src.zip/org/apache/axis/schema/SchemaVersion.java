/*    */ package org.apache.axis.schema;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.TypeMappingImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SchemaVersion
/*    */   extends Serializable
/*    */ {
/* 31 */   public static final SchemaVersion SCHEMA_1999 = new SchemaVersion1999();
/* 32 */   public static final SchemaVersion SCHEMA_2000 = new SchemaVersion2000();
/* 33 */   public static final SchemaVersion SCHEMA_2001 = new SchemaVersion2001();
/*    */   
/*    */   QName getNilQName();
/*    */   
/*    */   String getXsiURI();
/*    */   
/*    */   String getXsdURI();
/*    */   
/*    */   void registerSchemaSpecificTypes(TypeMappingImpl paramTypeMappingImpl);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\schema\SchemaVersion.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */