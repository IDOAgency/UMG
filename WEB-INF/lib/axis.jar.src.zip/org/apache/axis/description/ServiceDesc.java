package org.apache.axis.description;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.axis.constants.Style;
import org.apache.axis.constants.Use;
import org.apache.axis.encoding.TypeMapping;
import org.apache.axis.encoding.TypeMappingRegistry;

public interface ServiceDesc extends Serializable {
  Style getStyle();
  
  void setStyle(Style paramStyle);
  
  Use getUse();
  
  void setUse(Use paramUse);
  
  String getWSDLFile();
  
  void setWSDLFile(String paramString);
  
  List getAllowedMethods();
  
  void setAllowedMethods(List paramList);
  
  TypeMapping getTypeMapping();
  
  void setTypeMapping(TypeMapping paramTypeMapping);
  
  String getName();
  
  void setName(String paramString);
  
  String getDocumentation();
  
  void setDocumentation(String paramString);
  
  void removeOperationDesc(OperationDesc paramOperationDesc);
  
  void addOperationDesc(OperationDesc paramOperationDesc);
  
  ArrayList getOperations();
  
  OperationDesc[] getOperationsByName(String paramString);
  
  OperationDesc getOperationByName(String paramString);
  
  OperationDesc getOperationByElementQName(QName paramQName);
  
  OperationDesc[] getOperationsByQName(QName paramQName);
  
  void setNamespaceMappings(List paramList);
  
  String getDefaultNamespace();
  
  void setDefaultNamespace(String paramString);
  
  void setProperty(String paramString, Object paramObject);
  
  Object getProperty(String paramString);
  
  String getEndpointURL();
  
  void setEndpointURL(String paramString);
  
  TypeMappingRegistry getTypeMappingRegistry();
  
  void setTypeMappingRegistry(TypeMappingRegistry paramTypeMappingRegistry);
  
  boolean isInitialized();
  
  boolean isWrapped();
  
  List getDisallowedMethods();
  
  void setDisallowedMethods(List paramList);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\description\ServiceDesc.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */