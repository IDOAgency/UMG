/*     */ package org.apache.axis.description;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.axis.wsdl.symbolTable.TypeEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterDesc
/*     */   implements Serializable
/*     */ {
/*     */   public static final byte IN = 1;
/*     */   public static final byte OUT = 2;
/*     */   public static final byte INOUT = 3;
/*     */   private QName name;
/*     */   public TypeEntry typeEntry;
/*  47 */   private byte mode = 1;
/*     */   
/*     */   private QName typeQName;
/*     */   
/*  51 */   private Class javaType = null;
/*     */   
/*  53 */   private int order = -1;
/*     */   
/*     */   private boolean isReturn = false;
/*     */   
/*  57 */   private String mimeType = null;
/*     */ 
/*     */   
/*     */   private QName itemQName;
/*     */ 
/*     */   
/*     */   private QName itemType;
/*     */   
/*     */   private boolean inHeader = false;
/*     */   
/*     */   private boolean outHeader = false;
/*     */   
/*  69 */   private String documentation = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean omittable = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean nillable = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterDesc(ParameterDesc copy) {
/*  86 */     this.name = copy.name;
/*  87 */     this.typeEntry = copy.typeEntry;
/*  88 */     this.mode = copy.mode;
/*  89 */     this.typeQName = copy.typeQName;
/*  90 */     this.javaType = copy.javaType;
/*  91 */     this.order = copy.order;
/*  92 */     this.isReturn = copy.isReturn;
/*  93 */     this.mimeType = copy.mimeType;
/*  94 */     this.inHeader = copy.inHeader;
/*  95 */     this.outHeader = copy.outHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterDesc(QName name, byte mode, QName typeQName) {
/* 106 */     this.name = name;
/* 107 */     this.mode = mode;
/* 108 */     this.typeQName = typeQName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParameterDesc(QName name, byte mode, QName typeQName, Class javaType, boolean inHeader, boolean outHeader) {
/* 123 */     this(name, mode, typeQName);
/* 124 */     this.javaType = javaType;
/* 125 */     this.inHeader = inHeader;
/* 126 */     this.outHeader = outHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public ParameterDesc(QName name, byte mode, QName typeQName, Class javaType) { this(name, mode, typeQName, javaType, false, false); }
/*     */ 
/*     */ 
/*     */   
/* 141 */   public String toString() { return toString(""); }
/*     */   
/*     */   public String toString(String indent) {
/* 144 */     text = "";
/* 145 */     text = text + indent + "name:       " + this.name + "\n";
/* 146 */     text = text + indent + "typeEntry:  " + this.typeEntry + "\n";
/* 147 */     text = text + indent + "mode:       " + ((this.mode == 1) ? "IN" : ((this.mode == 3) ? "INOUT" : "OUT")) + "\n";
/*     */ 
/*     */     
/* 150 */     text = text + indent + "position:   " + this.order + "\n";
/* 151 */     text = text + indent + "isReturn:   " + this.isReturn + "\n";
/* 152 */     text = text + indent + "typeQName:  " + this.typeQName + "\n";
/* 153 */     text = text + indent + "javaType:   " + this.javaType + "\n";
/* 154 */     text = text + indent + "inHeader:   " + this.inHeader + "\n";
/* 155 */     return text + indent + "outHeader:  " + this.outHeader + "\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte modeFromString(String modeStr) {
/* 165 */     byte ret = 1;
/* 166 */     if (modeStr == null)
/* 167 */       return 1; 
/* 168 */     if (modeStr.equalsIgnoreCase("out")) {
/* 169 */       ret = 2;
/* 170 */     } else if (modeStr.equalsIgnoreCase("inout")) {
/* 171 */       ret = 3;
/*     */     } 
/* 173 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getModeAsString(byte mode) {
/* 178 */     if (mode == 3)
/* 179 */       return "inout"; 
/* 180 */     if (mode == 2)
/* 181 */       return "out"; 
/* 182 */     if (mode == 1) {
/* 183 */       return "in";
/*     */     }
/*     */     
/* 186 */     throw new IllegalArgumentException(Messages.getMessage("badParameterMode", Byte.toString(mode)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 191 */   public QName getQName() { return this.name; }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 195 */     if (this.name == null) {
/* 196 */       return null;
/*     */     }
/*     */     
/* 199 */     return this.name.getLocalPart();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 204 */   public void setName(String name) { this.name = new QName("", name); }
/*     */ 
/*     */ 
/*     */   
/* 208 */   public void setQName(QName name) { this.name = name; }
/*     */ 
/*     */ 
/*     */   
/* 212 */   public QName getTypeQName() { return this.typeQName; }
/*     */ 
/*     */ 
/*     */   
/* 216 */   public void setTypeQName(QName typeQName) { this.typeQName = typeQName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public Class getJavaType() { return this.javaType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaType(Class javaType) {
/* 233 */     if (javaType != null && (((
/* 234 */       this.mode == 1 || this.isReturn) && javax.xml.rpc.holders.Holder.class.isAssignableFrom(javaType)) || (this.mode != 1 && !this.isReturn && !javax.xml.rpc.holders.Holder.class.isAssignableFrom(javaType))))
/*     */     {
/*     */ 
/*     */       
/* 238 */       throw new IllegalArgumentException(Messages.getMessage("setJavaTypeErr00", javaType.getName(), getModeAsString(this.mode)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     this.javaType = javaType;
/*     */   }
/*     */ 
/*     */   
/* 249 */   public byte getMode() { return this.mode; }
/*     */ 
/*     */ 
/*     */   
/* 253 */   public void setMode(byte mode) { this.mode = mode; }
/*     */ 
/*     */ 
/*     */   
/* 257 */   public int getOrder() { return this.order; }
/*     */ 
/*     */ 
/*     */   
/* 261 */   public void setOrder(int order) { this.order = order; }
/*     */ 
/*     */ 
/*     */   
/* 265 */   public void setInHeader(boolean value) { this.inHeader = value; }
/*     */ 
/*     */ 
/*     */   
/* 269 */   public boolean isInHeader() { return this.inHeader; }
/*     */ 
/*     */ 
/*     */   
/* 273 */   public void setOutHeader(boolean value) { this.outHeader = value; }
/*     */ 
/*     */ 
/*     */   
/* 277 */   public boolean isOutHeader() { return this.outHeader; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   public boolean getIsReturn() { return this.isReturn; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   public void setIsReturn(boolean value) { this.isReturn = value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 299 */   public String getDocumentation() { return this.documentation; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 306 */   public void setDocumentation(String documentation) { this.documentation = documentation; }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 311 */     if (this.name == null) {
/* 312 */       out.writeBoolean(false);
/*     */     } else {
/* 314 */       out.writeBoolean(true);
/* 315 */       out.writeObject(this.name.getNamespaceURI());
/* 316 */       out.writeObject(this.name.getLocalPart());
/*     */     } 
/* 318 */     if (this.typeQName == null) {
/* 319 */       out.writeBoolean(false);
/*     */     } else {
/* 321 */       out.writeBoolean(true);
/* 322 */       out.writeObject(this.typeQName.getNamespaceURI());
/* 323 */       out.writeObject(this.typeQName.getLocalPart());
/*     */     } 
/* 325 */     out.defaultWriteObject();
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 330 */     if (in.readBoolean()) {
/* 331 */       this.name = new QName((String)in.readObject(), (String)in.readObject());
/*     */     } else {
/*     */       
/* 334 */       this.name = null;
/*     */     } 
/* 336 */     if (in.readBoolean()) {
/* 337 */       this.typeQName = new QName((String)in.readObject(), (String)in.readObject());
/*     */     } else {
/*     */       
/* 340 */       this.typeQName = null;
/*     */     } 
/* 342 */     in.defaultReadObject();
/*     */   }
/*     */ 
/*     */   
/* 346 */   public QName getItemQName() { return this.itemQName; }
/*     */ 
/*     */ 
/*     */   
/* 350 */   public void setItemQName(QName itemQName) { this.itemQName = itemQName; }
/*     */ 
/*     */ 
/*     */   
/* 354 */   public QName getItemType() { return this.itemType; }
/*     */ 
/*     */ 
/*     */   
/* 358 */   public void setItemType(QName itemType) { this.itemType = itemType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 367 */   public boolean isOmittable() { return this.omittable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 376 */   public void setOmittable(boolean omittable) { this.omittable = omittable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 384 */   public boolean isNillable() { return this.nillable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 392 */   public void setNillable(boolean nillable) { this.nillable = nillable; }
/*     */   
/*     */   public ParameterDesc() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\description\ParameterDesc.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */