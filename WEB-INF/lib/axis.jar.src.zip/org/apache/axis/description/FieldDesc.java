/*     */ package org.apache.axis.description;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldDesc
/*     */   implements Serializable
/*     */ {
/*     */   private String fieldName;
/*     */   private QName xmlName;
/*     */   private QName xmlType;
/*     */   private Class javaType;
/*     */   private boolean _isElement;
/*     */   private boolean minOccursIs0;
/*     */   
/*     */   protected FieldDesc(boolean isElement) {
/*  40 */     this._isElement = true;
/*     */ 
/*     */     
/*  43 */     this.minOccursIs0 = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     this._isElement = isElement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public String getFieldName() { return this.fieldName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void setFieldName(String fieldName) { this.fieldName = fieldName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public QName getXmlName() { return this.xmlName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public void setXmlName(QName xmlName) { this.xmlName = xmlName; }
/*     */ 
/*     */ 
/*     */   
/*  83 */   public Class getJavaType() { return this.javaType; }
/*     */ 
/*     */ 
/*     */   
/*  87 */   public void setJavaType(Class javaType) { this.javaType = javaType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public QName getXmlType() { return this.xmlType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void setXmlType(QName xmlType) { this.xmlType = xmlType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public boolean isElement() { return this._isElement; }
/*     */ 
/*     */ 
/*     */   
/* 114 */   public boolean isIndexed() { return false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public boolean isMinOccursZero() { return this.minOccursIs0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public void setMinOccursIs0(boolean minOccursIs0) { this.minOccursIs0 = minOccursIs0; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\description\FieldDesc.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */