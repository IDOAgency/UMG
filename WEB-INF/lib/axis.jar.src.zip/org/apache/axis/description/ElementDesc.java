/*     */ package org.apache.axis.description;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementDesc
/*     */   extends FieldDesc
/*     */   implements Serializable
/*     */ {
/*  30 */   private int minOccurs = 1;
/*     */   
/*  32 */   private int maxOccurs = 1;
/*     */ 
/*     */   
/*     */   private boolean nillable = false;
/*     */ 
/*     */   
/*     */   private boolean unbounded = false;
/*     */ 
/*     */   
/*     */   private QName arrayType;
/*     */   
/*     */   private QName itemQName;
/*     */ 
/*     */   
/*  46 */   public ElementDesc() { super(true); }
/*     */ 
/*     */ 
/*     */   
/*  50 */   public boolean isMinOccursZero() { return (this.minOccurs == 0); }
/*     */ 
/*     */ 
/*     */   
/*  54 */   public int getMinOccurs() { return this.minOccurs; }
/*     */ 
/*     */ 
/*     */   
/*  58 */   public void setMinOccurs(int minOccurs) { this.minOccurs = minOccurs; }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public int getMaxOccurs() { return this.maxOccurs; }
/*     */ 
/*     */ 
/*     */   
/*  66 */   public void setMaxOccurs(int maxOccurs) { this.maxOccurs = maxOccurs; }
/*     */ 
/*     */ 
/*     */   
/*  70 */   public void setMaxOccursUnbounded(boolean ubnd) { this.unbounded = ubnd; }
/*     */ 
/*     */ 
/*     */   
/*  74 */   public boolean isMaxOccursUnbounded() { return this.unbounded; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public boolean isNillable() { return this.nillable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public void setNillable(boolean nillable) { this.nillable = nillable; }
/*     */ 
/*     */ 
/*     */   
/*  96 */   public QName getArrayType() { return this.arrayType; }
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void setArrayType(QName arrayType) { this.arrayType = arrayType; }
/*     */ 
/*     */ 
/*     */   
/* 104 */   public QName getItemQName() { return this.itemQName; }
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void setItemQName(QName itemQName) { this.itemQName = itemQName; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\description\ElementDesc.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */