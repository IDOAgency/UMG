package org.apache.axis.description;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import javax.wsdl.OperationType;
import javax.xml.namespace.QName;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.constants.Style;
import org.apache.axis.constants.Use;
import org.apache.commons.logging.Log;

public class OperationDesc implements Serializable {
  public static final int MSG_METHOD_BODYARRAY = 1;
  
  public static final int MSG_METHOD_SOAPENVELOPE = 2;
  
  public static final int MSG_METHOD_ELEMENTARRAY = 3;
  
  public static final int MSG_METHOD_DOCUMENT = 4;
  
  public static final int MSG_METHOD_NONCONFORMING = -4;
  
  public static Map mepStrings = new HashMap();
  
  protected static Log log;
  
  private ServiceDesc parent;
  
  private ArrayList parameters;
  
  private String name;
  
  private QName elementQName;
  
  private Method method;
  
  private Style style;
  
  private Use use;
  
  private int numInParams;
  
  private int numOutParams;
  
  private String soapAction;
  
  private ArrayList faults;
  
  private ParameterDesc returnDesc;
  
  private int messageOperationStyle;
  
  private String documentation;
  
  private OperationType mep;
  
  static  {
    mepStrings.put("request-response", OperationType.REQUEST_RESPONSE);
    mepStrings.put("oneway", OperationType.ONE_WAY);
    mepStrings.put("solicit-response", OperationType.SOLICIT_RESPONSE);
    mepStrings.put("notification", OperationType.NOTIFICATION);
    log = LogFactory.getLog(OperationDesc.class.getName());
  }
  
  public OperationDesc() {
    this.parameters = new ArrayList();
    this.style = null;
    this.use = null;
    this.numInParams = 0;
    this.numOutParams = 0;
    this.soapAction = null;
    this.faults = null;
    this.returnDesc = new ParameterDesc();
    this.messageOperationStyle = -1;
    this.documentation = null;
    this.mep = OperationType.REQUEST_RESPONSE;
    this.returnDesc.setMode((byte)2);
    this.returnDesc.setIsReturn(true);
  }
  
  public OperationDesc(String name, ParameterDesc[] parameters, QName returnQName) {
    this.parameters = new ArrayList();
    this.style = null;
    this.use = null;
    this.numInParams = 0;
    this.numOutParams = 0;
    this.soapAction = null;
    this.faults = null;
    this.returnDesc = new ParameterDesc();
    this.messageOperationStyle = -1;
    this.documentation = null;
    this.mep = OperationType.REQUEST_RESPONSE;
    this.name = name;
    this.returnDesc.setQName(returnQName);
    this.returnDesc.setMode((byte)2);
    this.returnDesc.setIsReturn(true);
    for (int i = 0; i < parameters.length; i++)
      addParameter(parameters[i]); 
  }
  
  public String getName() { return this.name; }
  
  public void setName(String name) { this.name = name; }
  
  public String getDocumentation() { return this.documentation; }
  
  public void setDocumentation(String documentation) { this.documentation = documentation; }
  
  public QName getReturnQName() { return this.returnDesc.getQName(); }
  
  public void setReturnQName(QName returnQName) { this.returnDesc.setQName(returnQName); }
  
  public QName getReturnType() { return this.returnDesc.getTypeQName(); }
  
  public void setReturnType(QName returnType) {
    log.debug("@" + Integer.toHexString(hashCode()) + "setReturnType(" + returnType + ")");
    this.returnDesc.setTypeQName(returnType);
  }
  
  public Class getReturnClass() { return this.returnDesc.getJavaType(); }
  
  public void setReturnClass(Class returnClass) { this.returnDesc.setJavaType(returnClass); }
  
  public QName getElementQName() { return this.elementQName; }
  
  public void setElementQName(QName elementQName) { this.elementQName = elementQName; }
  
  public ServiceDesc getParent() { return this.parent; }
  
  public void setParent(ServiceDesc parent) { this.parent = parent; }
  
  public String getSoapAction() { return this.soapAction; }
  
  public void setSoapAction(String soapAction) { this.soapAction = soapAction; }
  
  public void setStyle(Style style) { this.style = style; }
  
  public Style getStyle() {
    if (this.style == null) {
      if (this.parent != null)
        return this.parent.getStyle(); 
      return Style.DEFAULT;
    } 
    return this.style;
  }
  
  public void setUse(Use use) { this.use = use; }
  
  public Use getUse() {
    if (this.use == null) {
      if (this.parent != null)
        return this.parent.getUse(); 
      return Use.DEFAULT;
    } 
    return this.use;
  }
  
  public void addParameter(ParameterDesc param) {
    param.setOrder(getNumParams());
    this.parameters.add(param);
    if (param.getMode() == 1 || param.getMode() == 3)
      this.numInParams++; 
    if (param.getMode() == 2 || param.getMode() == 3)
      this.numOutParams++; 
    log.debug("@" + Integer.toHexString(hashCode()) + " added parameter >" + param + "@" + Integer.toHexString(param.hashCode()) + "<total parameters:" + getNumParams());
  }
  
  public void addParameter(QName paramName, QName xmlType, Class javaType, byte parameterMode, boolean inHeader, boolean outHeader) {
    ParameterDesc param = new ParameterDesc(paramName, parameterMode, xmlType, javaType, inHeader, outHeader);
    addParameter(param);
  }
  
  public ParameterDesc getParameter(int i) {
    if (this.parameters.size() <= i)
      return null; 
    return (ParameterDesc)this.parameters.get(i);
  }
  
  public ArrayList getParameters() { return this.parameters; }
  
  public void setParameters(ArrayList newParameters) {
    this.parameters = new ArrayList();
    this.numInParams = 0;
    this.numOutParams = 0;
    ListIterator li = newParameters.listIterator();
    while (li.hasNext())
      addParameter((ParameterDesc)li.next()); 
  }
  
  public int getNumInParams() { return this.numInParams; }
  
  public int getNumOutParams() { return this.numOutParams; }
  
  public int getNumParams() { return this.parameters.size(); }
  
  public Method getMethod() { return this.method; }
  
  public void setMethod(Method method) { this.method = method; }
  
  public boolean isReturnHeader() { return this.returnDesc.isOutHeader(); }
  
  public void setReturnHeader(boolean value) { this.returnDesc.setOutHeader(value); }
  
  public ParameterDesc getParamByQName(QName qname) {
    for (Iterator i = this.parameters.iterator(); i.hasNext(); ) {
      ParameterDesc param = (ParameterDesc)i.next();
      if (param.getQName().equals(qname))
        return param; 
    } 
    return null;
  }
  
  public ParameterDesc getInputParamByQName(QName qname) {
    ParameterDesc param = null;
    param = getParamByQName(qname);
    if (param == null || param.getMode() == 2)
      param = null; 
    return param;
  }
  
  public ParameterDesc getOutputParamByQName(QName qname) {
    ParameterDesc param = null;
    for (Iterator i = this.parameters.iterator(); i.hasNext(); ) {
      ParameterDesc pnext = (ParameterDesc)i.next();
      if (pnext.getQName().equals(qname) && pnext.getMode() != 1) {
        param = pnext;
        break;
      } 
    } 
    if (param == null)
      if (null == this.returnDesc.getQName()) {
        param = new ParameterDesc(this.returnDesc);
        param.setQName(qname);
      } else if (qname.equals(this.returnDesc.getQName())) {
        param = this.returnDesc;
      }  
    return param;
  }
  
  public ArrayList getAllInParams() {
    ArrayList result = new ArrayList();
    for (Iterator i = this.parameters.iterator(); i.hasNext(); ) {
      ParameterDesc desc = (ParameterDesc)i.next();
      if (desc.getMode() != 2)
        result.add(desc); 
    } 
    return result;
  }
  
  public ArrayList getAllOutParams() {
    ArrayList result = new ArrayList();
    for (Iterator i = this.parameters.iterator(); i.hasNext(); ) {
      ParameterDesc desc = (ParameterDesc)i.next();
      if (desc.getMode() != 1)
        result.add(desc); 
    } 
    return result;
  }
  
  public ArrayList getOutParams() {
    ArrayList result = new ArrayList();
    for (Iterator i = this.parameters.iterator(); i.hasNext(); ) {
      ParameterDesc desc = (ParameterDesc)i.next();
      if (desc.getMode() == 2)
        result.add(desc); 
    } 
    return result;
  }
  
  public void addFault(FaultDesc fault) {
    if (this.faults == null)
      this.faults = new ArrayList(); 
    this.faults.add(fault);
  }
  
  public ArrayList getFaults() { return this.faults; }
  
  public FaultDesc getFaultByClass(Class cls) {
    if (this.faults == null || cls == null)
      return null; 
    while (cls != null) {
      for (Iterator iterator = this.faults.iterator(); iterator.hasNext(); ) {
        FaultDesc desc = (FaultDesc)iterator.next();
        if (cls.getName().equals(desc.getClassName()))
          return desc; 
      } 
      cls = cls.getSuperclass();
      if (cls != null && (cls.getName().startsWith("java.") || cls.getName().startsWith("javax.")))
        cls = null; 
    } 
    return null;
  }
  
  public FaultDesc getFaultByClass(Class cls, boolean checkParents) {
    if (checkParents)
      return getFaultByClass(cls); 
    if (this.faults == null || cls == null)
      return null; 
    for (Iterator iterator = this.faults.iterator(); iterator.hasNext(); ) {
      FaultDesc desc = (FaultDesc)iterator.next();
      if (cls.getName().equals(desc.getClassName()))
        return desc; 
    } 
    return null;
  }
  
  public FaultDesc getFaultByQName(QName qname) {
    if (this.faults != null)
      for (Iterator iterator = this.faults.iterator(); iterator.hasNext(); ) {
        FaultDesc desc = (FaultDesc)iterator.next();
        if (qname.equals(desc.getQName()))
          return desc; 
      }  
    return null;
  }
  
  public FaultDesc getFaultByXmlType(QName xmlType) {
    if (this.faults != null)
      for (Iterator iterator = this.faults.iterator(); iterator.hasNext(); ) {
        FaultDesc desc = (FaultDesc)iterator.next();
        if (xmlType.equals(desc.getXmlType()))
          return desc; 
      }  
    return null;
  }
  
  public ParameterDesc getReturnParamDesc() { return this.returnDesc; }
  
  public String toString() { return toString(""); }
  
  public String toString(String indent) {
    String text = "";
    text = text + indent + "name:        " + getName() + "\n";
    text = text + indent + "returnQName: " + getReturnQName() + "\n";
    text = text + indent + "returnType:  " + getReturnType() + "\n";
    text = text + indent + "returnClass: " + getReturnClass() + "\n";
    text = text + indent + "elementQName:" + getElementQName() + "\n";
    text = text + indent + "soapAction:  " + getSoapAction() + "\n";
    text = text + indent + "style:       " + getStyle().getName() + "\n";
    text = text + indent + "use:         " + getUse().getName() + "\n";
    text = text + indent + "numInParams: " + getNumInParams() + "\n";
    text = text + indent + "method:" + getMethod() + "\n";
    for (int i = 0; i < this.parameters.size(); i++) {
      text = text + indent + " ParameterDesc[" + i + "]:\n";
      text = text + indent + ((ParameterDesc)this.parameters.get(i)).toString("  ") + "\n";
    } 
    if (this.faults != null)
      for (int i = 0; i < this.faults.size(); i++) {
        text = text + indent + " FaultDesc[" + i + "]:\n";
        text = text + indent + ((FaultDesc)this.faults.get(i)).toString("  ") + "\n";
      }  
    return text;
  }
  
  public int getMessageOperationStyle() { return this.messageOperationStyle; }
  
  public void setMessageOperationStyle(int messageOperationStyle) { this.messageOperationStyle = messageOperationStyle; }
  
  public OperationType getMep() { return this.mep; }
  
  public void setMep(OperationType mep) { this.mep = mep; }
  
  public void setMep(String mepString) {
    OperationType newMep = (OperationType)mepStrings.get(mepString);
    if (newMep != null)
      this.mep = newMep; 
  }
  
  private void writeObject(ObjectOutputStream out) throws IOException {
    out.defaultWriteObject();
    if (this.method != null) {
      out.writeObject(this.method.getDeclaringClass());
      out.writeObject(this.method.getName());
      out.writeObject(this.method.getParameterTypes());
    } else {
      out.writeObject(null);
    } 
  }
  
  private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
    in.defaultReadObject();
    Class clazz = (Class)in.readObject();
    if (clazz != null) {
      String methodName = (String)in.readObject();
      Class[] parameterTypes = (Class[])in.readObject();
      try {
        this.method = clazz.getMethod(methodName, parameterTypes);
      } catch (NoSuchMethodException e) {
        throw new IOException("Unable to deserialize the operation's method: " + methodName);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\description\OperationDesc.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */