/*    */ package org.apache.axis.description;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributeDesc
/*    */   extends FieldDesc
/*    */   implements Serializable
/*    */ {
/* 29 */   public AttributeDesc() { super(false); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   public void setAttributeName(String name) { setXmlName(new QName("", name)); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\description\AttributeDesc.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */