/*     */ package org.apache.axis.description;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FaultDesc
/*     */   implements Serializable
/*     */ {
/*     */   private String name;
/*     */   private QName qname;
/*     */   private ArrayList parameters;
/*     */   private String className;
/*     */   private QName xmlType;
/*     */   private boolean complex;
/*     */   
/*     */   public FaultDesc() {}
/*     */   
/*     */   public FaultDesc(QName qname, String className, QName xmlType, boolean complex) {
/*  48 */     this.qname = qname;
/*  49 */     this.className = className;
/*  50 */     this.xmlType = xmlType;
/*  51 */     this.complex = complex;
/*     */   }
/*     */ 
/*     */   
/*  55 */   public QName getQName() { return this.qname; }
/*     */ 
/*     */ 
/*     */   
/*  59 */   public void setQName(QName name) { this.qname = name; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void setName(String name) { this.name = name; }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public ArrayList getParameters() { return this.parameters; }
/*     */ 
/*     */ 
/*     */   
/*  77 */   public void setParameters(ArrayList parameters) { this.parameters = parameters; }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public String getClassName() { return this.className; }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void setClassName(String className) { this.className = className; }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public boolean isComplex() { return this.complex; }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public void setComplex(boolean complex) { this.complex = complex; }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public QName getXmlType() { return this.xmlType; }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void setXmlType(QName xmlType) { this.xmlType = xmlType; }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public String toString() { return toString(""); }
/*     */   
/*     */   public String toString(String indent) {
/* 108 */     String text = "";
/* 109 */     text = text + indent + "name: " + getName() + "\n";
/* 110 */     text = text + indent + "qname: " + getQName() + "\n";
/* 111 */     text = text + indent + "type: " + getXmlType() + "\n";
/* 112 */     text = text + indent + "Class: " + getClassName() + "\n";
/* 113 */     for (int i = 0; this.parameters != null && i < this.parameters.size(); i++) {
/* 114 */       text = text + indent + " ParameterDesc[" + i + "]:\n";
/* 115 */       text = text + indent + ((ParameterDesc)this.parameters.get(i)).toString("  ") + "\n";
/*     */     } 
/* 117 */     return text;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\description\FaultDesc.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */