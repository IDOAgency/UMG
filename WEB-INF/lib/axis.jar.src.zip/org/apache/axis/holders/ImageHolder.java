/*    */ package org.apache.axis.holders;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import javax.xml.rpc.holders.Holder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ImageHolder
/*    */   implements Holder
/*    */ {
/*    */   public Image value;
/*    */   
/*    */   public ImageHolder() {}
/*    */   
/* 42 */   public ImageHolder(Image value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\ImageHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */