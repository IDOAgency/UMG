package org.apache.axis.holders;

import javax.xml.rpc.holders.Holder;
import org.apache.axis.attachments.OctetStream;

public final class OctetStreamHolder implements Holder {
  public OctetStream value;
  
  public OctetStreamHolder() {}
  
  public OctetStreamHolder(OctetStream value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\OctetStreamHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */