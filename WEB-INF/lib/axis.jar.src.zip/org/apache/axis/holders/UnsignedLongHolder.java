/*    */ package org.apache.axis.holders;
/*    */ 
/*    */ import javax.xml.rpc.holders.Holder;
/*    */ import org.apache.axis.types.UnsignedLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class UnsignedLongHolder
/*    */   implements Holder
/*    */ {
/*    */   public UnsignedLong value;
/*    */   
/*    */   public UnsignedLongHolder() {}
/*    */   
/* 44 */   public UnsignedLongHolder(UnsignedLong value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\UnsignedLongHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */