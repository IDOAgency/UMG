package org.apache.axis.holders;

import javax.xml.rpc.holders.Holder;
import org.apache.axis.types.NormalizedString;

public final class NormalizedStringHolder implements Holder {
  public NormalizedString value;
  
  public NormalizedStringHolder() {}
  
  public NormalizedStringHolder(NormalizedString value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\NormalizedStringHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */