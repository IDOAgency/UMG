/*    */ package org.apache.axis.holders;
/*    */ 
/*    */ import javax.activation.DataHandler;
/*    */ import javax.xml.rpc.holders.Holder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DataHandlerHolder
/*    */   implements Holder
/*    */ {
/*    */   public DataHandler value;
/*    */   
/*    */   public DataHandlerHolder() {}
/*    */   
/* 42 */   public DataHandlerHolder(DataHandler value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\DataHandlerHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */