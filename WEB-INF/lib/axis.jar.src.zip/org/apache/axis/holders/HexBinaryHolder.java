package org.apache.axis.holders;

import javax.xml.rpc.holders.Holder;
import org.apache.axis.types.HexBinary;

public final class HexBinaryHolder implements Holder {
  public HexBinary value;
  
  public HexBinaryHolder() {}
  
  public HexBinaryHolder(HexBinary value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\HexBinaryHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */