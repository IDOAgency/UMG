package org.apache.axis.holders;

import javax.xml.rpc.holders.Holder;
import org.apache.axis.types.UnsignedByte;

public final class UnsignedByteHolder implements Holder {
  public UnsignedByte value;
  
  public UnsignedByteHolder() {}
  
  public UnsignedByteHolder(UnsignedByte value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\UnsignedByteHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */