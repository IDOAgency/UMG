/*    */ package org.apache.axis.holders;
/*    */ 
/*    */ import javax.xml.rpc.holders.Holder;
/*    */ import org.apache.axis.types.Duration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DurationHolder
/*    */   implements Holder
/*    */ {
/*    */   public Duration value;
/*    */   
/*    */   public DurationHolder() {}
/*    */   
/* 44 */   public DurationHolder(Duration value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\DurationHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */