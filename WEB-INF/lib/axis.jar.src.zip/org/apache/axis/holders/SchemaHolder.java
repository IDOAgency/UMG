package org.apache.axis.holders;

import javax.xml.rpc.holders.Holder;
import org.apache.axis.types.Schema;

public final class SchemaHolder implements Holder {
  public Schema value;
  
  public SchemaHolder() {}
  
  public SchemaHolder(Schema value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\SchemaHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */