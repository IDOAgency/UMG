/*    */ package org.apache.axis.holders;
/*    */ 
/*    */ import javax.xml.rpc.holders.Holder;
/*    */ import org.apache.axis.types.MonthDay;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MonthDayHolder
/*    */   implements Holder
/*    */ {
/*    */   public MonthDay value;
/*    */   
/*    */   public MonthDayHolder() {}
/*    */   
/* 44 */   public MonthDayHolder(MonthDay value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\MonthDayHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */