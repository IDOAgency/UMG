/*    */ package org.apache.axis.holders;
/*    */ 
/*    */ import javax.xml.rpc.holders.Holder;
/*    */ import org.apache.axis.types.NonNegativeInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NonNegativeIntegerHolder
/*    */   implements Holder
/*    */ {
/*    */   public NonNegativeInteger value;
/*    */   
/*    */   public NonNegativeIntegerHolder() {}
/*    */   
/* 44 */   public NonNegativeIntegerHolder(NonNegativeInteger value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\NonNegativeIntegerHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */