package org.apache.axis.holders;

import javax.xml.rpc.holders.Holder;
import org.apache.axis.types.URI;

public final class URIHolder implements Holder {
  public URI value;
  
  public URIHolder() {}
  
  public URIHolder(URI value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\URIHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */