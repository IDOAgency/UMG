package org.apache.axis.holders;

import javax.xml.rpc.holders.Holder;
import org.apache.axis.types.Day;

public final class DayHolder implements Holder {
  public Day value;
  
  public DayHolder() {}
  
  public DayHolder(Day value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\holders\DayHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */