package org.apache.axis.encoding;

import javax.xml.rpc.encoding.SerializerFactory;

public interface SerializerFactory extends SerializerFactory {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\SerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */