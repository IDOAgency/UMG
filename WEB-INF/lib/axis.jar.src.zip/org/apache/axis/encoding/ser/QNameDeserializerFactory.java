package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;

public class QNameDeserializerFactory extends BaseDeserializerFactory {
  public QNameDeserializerFactory(Class javaType, QName xmlType) { super(QNameDeserializer.class, xmlType, javaType); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\QNameDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */