package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;
import org.apache.axis.types.Time;

public class TimeDeserializer extends SimpleDeserializer {
  public TimeDeserializer(Class javaType, QName xmlType) { super(javaType, xmlType); }
  
  public Object makeValue(String source) {
    Time t = new Time(source);
    return t.getAsCalendar();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\TimeDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */