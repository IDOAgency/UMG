/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.activation.DataHandler;
/*    */ import javax.mail.internet.MimeMultipart;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.attachments.MimeMultipartDataSource;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MimeMultipartDataHandlerSerializer
/*    */   extends JAFDataHandlerSerializer
/*    */ {
/* 36 */   protected static Log log = LogFactory.getLog(MimeMultipartDataHandlerSerializer.class.getName());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException {
/* 46 */     if (value != null) {
/* 47 */       DataHandler dh = new DataHandler(new MimeMultipartDataSource("Multipart", (MimeMultipart)value));
/* 48 */       super.serialize(name, attributes, dh, context);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\MimeMultipartDataHandlerSerializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */