/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import java.io.IOException;
/*    */ import javax.activation.DataHandler;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.attachments.ImageDataSource;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageDataHandlerSerializer
/*    */   extends JAFDataHandlerSerializer
/*    */ {
/* 36 */   protected static Log log = LogFactory.getLog(ImageDataHandlerSerializer.class.getName());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException {
/* 46 */     DataHandler dh = new DataHandler(new ImageDataSource("source", (Image)value));
/*    */     
/* 48 */     super.serialize(name, attributes, dh, context);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\ImageDataHandlerSerializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */