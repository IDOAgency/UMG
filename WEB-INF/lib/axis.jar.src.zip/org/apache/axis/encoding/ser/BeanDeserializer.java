package org.apache.axis.encoding.ser;

import java.io.CharArrayWriter;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.util.Map;
import javax.xml.namespace.QName;
import org.apache.axis.Constants;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.description.ElementDesc;
import org.apache.axis.description.FieldDesc;
import org.apache.axis.description.TypeDesc;
import org.apache.axis.encoding.ConstructorTarget;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.Deserializer;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.encoding.Target;
import org.apache.axis.encoding.TypeMapping;
import org.apache.axis.message.MessageElement;
import org.apache.axis.message.SOAPHandler;
import org.apache.axis.message.Text;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.BeanPropertyDescriptor;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class BeanDeserializer extends DeserializerImpl implements Serializable {
  protected static Log log = LogFactory.getLog(BeanDeserializer.class.getName());
  
  private final CharArrayWriter val;
  
  QName xmlType;
  
  Class javaType;
  
  protected Map propertyMap;
  
  protected QName prevQName;
  
  protected Constructor constructorToUse;
  
  protected Target constructorTarget;
  
  protected TypeDesc typeDesc;
  
  protected int collectionIndex;
  
  protected SimpleDeserializer cacheStringDSer;
  
  protected QName cacheXMLType;
  
  public BeanDeserializer(Class javaType, QName xmlType) { this(javaType, xmlType, TypeDesc.getTypeDescForClass(javaType)); }
  
  public BeanDeserializer(Class javaType, QName xmlType, TypeDesc typeDesc) { this(javaType, xmlType, typeDesc, BeanDeserializerFactory.getProperties(javaType, typeDesc)); }
  
  public BeanDeserializer(Class javaType, QName xmlType, TypeDesc typeDesc, Map propertyMap) {
    this.val = new CharArrayWriter();
    this.propertyMap = null;
    this.constructorToUse = null;
    this.constructorTarget = null;
    this.typeDesc = null;
    this.collectionIndex = -1;
    this.cacheStringDSer = null;
    this.cacheXMLType = null;
    this.xmlType = xmlType;
    this.javaType = javaType;
    this.typeDesc = typeDesc;
    this.propertyMap = propertyMap;
    try {
      this.value = javaType.newInstance();
    } catch (Exception e) {}
  }
  
  public void startElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (this.value == null)
      try {
        this.value = this.javaType.newInstance();
      } catch (Exception e) {
        Constructor[] constructors = this.javaType.getConstructors();
        if (constructors.length > 0)
          this.constructorToUse = constructors[0]; 
        if (this.constructorToUse == null)
          throw new SAXException(Messages.getMessage("cantCreateBean00", this.javaType.getName(), e.toString())); 
      }  
    super.startElement(namespace, localName, prefix, attributes, context);
  }
  
  public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    handleMixedContent();
    BeanPropertyDescriptor propDesc = null;
    FieldDesc fieldDesc = null;
    SOAPConstants soapConstants = context.getSOAPConstants();
    String encodingStyle = context.getEncodingStyle();
    boolean isEncoded = Constants.isSOAP_ENC(encodingStyle);
    QName elemQName = new QName(namespace, localName);
    if (this.prevQName == null || !this.prevQName.equals(elemQName))
      this.collectionIndex = -1; 
    boolean isArray = false;
    QName itemQName = null;
    if (this.typeDesc != null) {
      String fieldName = this.typeDesc.getFieldNameForElement(elemQName, isEncoded);
      propDesc = (BeanPropertyDescriptor)this.propertyMap.get(fieldName);
      fieldDesc = this.typeDesc.getFieldByName(fieldName);
      if (fieldDesc != null) {
        ElementDesc element = (ElementDesc)fieldDesc;
        isArray = element.isMaxOccursUnbounded();
        itemQName = element.getItemQName();
      } 
    } 
    if (propDesc == null)
      propDesc = (BeanPropertyDescriptor)this.propertyMap.get(localName); 
    if (propDesc == null || (this.prevQName != null && this.prevQName.equals(elemQName) && !propDesc.isIndexed() && !isArray && getAnyPropertyDesc() != null)) {
      this.prevQName = elemQName;
      propDesc = getAnyPropertyDesc();
      if (propDesc != null)
        try {
          MessageElement[] curElements = (MessageElement[])propDesc.get(this.value);
          int length = 0;
          if (curElements != null)
            length = curElements.length; 
          MessageElement[] newElements = new MessageElement[length + 1];
          if (curElements != null)
            System.arraycopy(curElements, 0, newElements, 0, length); 
          MessageElement thisEl = context.getCurElement();
          newElements[length] = thisEl;
          propDesc.set(this.value, newElements);
          if (!localName.equals(thisEl.getName()))
            return new SOAPHandler(newElements, length); 
          return new SOAPHandler();
        } catch (Exception e) {
          throw new SAXException(e);
        }  
    } 
    if (propDesc == null)
      throw new SAXException(Messages.getMessage("badElem00", this.javaType.getName(), localName)); 
    this.prevQName = elemQName;
    QName childXMLType = context.getTypeFromAttributes(namespace, localName, attributes);
    String href = attributes.getValue(soapConstants.getAttrHref());
    Class fieldType = propDesc.getType();
    if (childXMLType == null && fieldDesc != null && href == null) {
      childXMLType = fieldDesc.getXmlType();
      if (itemQName != null) {
        childXMLType = Constants.SOAP_ARRAY;
        fieldType = propDesc.getActualType();
      } else {
        childXMLType = fieldDesc.getXmlType();
      } 
    } 
    Deserializer dSer = getDeserializer(childXMLType, fieldType, href, context);
    if (dSer == null)
      dSer = context.getDeserializerForClass(propDesc.getType()); 
    if (context.isNil(attributes)) {
      if (propDesc != null && (propDesc.isIndexed() || isArray) && (
        dSer == null || !(dSer instanceof ArrayDeserializer))) {
        this.collectionIndex++;
        dSer.registerValueTarget(new BeanPropertyTarget(this.value, propDesc, this.collectionIndex));
        addChildDeserializer(dSer);
        return (SOAPHandler)dSer;
      } 
      return null;
    } 
    if (dSer == null)
      throw new SAXException(Messages.getMessage("noDeser00", childXMLType.toString())); 
    if (this.constructorToUse != null) {
      if (this.constructorTarget == null)
        this.constructorTarget = new ConstructorTarget(this.constructorToUse, this); 
      dSer.registerValueTarget(this.constructorTarget);
    } else if (propDesc.isWriteable()) {
      if ((itemQName != null || propDesc.isIndexed() || isArray) && !(dSer instanceof ArrayDeserializer)) {
        this.collectionIndex++;
        dSer.registerValueTarget(new BeanPropertyTarget(this.value, propDesc, this.collectionIndex));
      } else {
        this.collectionIndex = -1;
        dSer.registerValueTarget(new BeanPropertyTarget(this.value, propDesc));
      } 
    } 
    addChildDeserializer(dSer);
    return (SOAPHandler)dSer;
  }
  
  public BeanPropertyDescriptor getAnyPropertyDesc() {
    if (this.typeDesc == null)
      return null; 
    return this.typeDesc.getAnyDesc();
  }
  
  public void onStartElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (this.value == null && this.constructorToUse == null)
      try {
        this.value = this.javaType.newInstance();
      } catch (Exception e) {
        throw new SAXException(Messages.getMessage("cantCreateBean00", this.javaType.getName(), e.toString()));
      }  
    if (this.typeDesc == null)
      return; 
    for (int i = 0; i < attributes.getLength(); i++) {
      QName attrQName = new QName(attributes.getURI(i), attributes.getLocalName(i));
      String fieldName = this.typeDesc.getFieldNameForAttribute(attrQName);
      if (fieldName == null)
        continue; 
      FieldDesc fieldDesc = this.typeDesc.getFieldByName(fieldName);
      BeanPropertyDescriptor bpd = (BeanPropertyDescriptor)this.propertyMap.get(fieldName);
      if (bpd != null) {
        if (this.constructorToUse == null)
          if (!bpd.isWriteable() || bpd.isIndexed())
            continue;  
        Deserializer dSer = getDeserializer(fieldDesc.getXmlType(), bpd.getType(), null, context);
        if (dSer == null) {
          dSer = context.getDeserializerForClass(bpd.getType());
          if (dSer instanceof ArrayDeserializer) {
            SimpleListDeserializerFactory factory = new SimpleListDeserializerFactory(bpd.getType(), fieldDesc.getXmlType());
            dSer = (Deserializer)factory.getDeserializerAs(dSer.getMechanismType());
          } 
        } 
        if (dSer == null)
          throw new SAXException(Messages.getMessage("unregistered00", bpd.getType().toString())); 
        if (!(dSer instanceof SimpleDeserializer))
          throw new SAXException(Messages.getMessage("AttrNotSimpleType00", bpd.getName(), bpd.getType().toString())); 
        try {
          dSer.onStartElement(namespace, localName, prefix, attributes, context);
          Object val = ((SimpleDeserializer)dSer).makeValue(attributes.getValue(i));
          if (this.constructorToUse == null) {
            bpd.set(this.value, val);
          } else {
            if (this.constructorTarget == null)
              this.constructorTarget = new ConstructorTarget(this.constructorToUse, this); 
            this.constructorTarget.set(val);
          } 
        } catch (Exception e) {
          throw new SAXException(e);
        } 
      } 
      continue;
    } 
  }
  
  protected Deserializer getDeserializer(QName xmlType, Class javaType, String href, DeserializationContext context) {
    if (javaType.isArray())
      context.setDestinationClass(javaType); 
    if (this.cacheStringDSer != null && 
      String.class.equals(javaType) && href == null && ((this.cacheXMLType == null && xmlType == null) || (this.cacheXMLType != null && this.cacheXMLType.equals(xmlType)))) {
      this.cacheStringDSer.reset();
      return this.cacheStringDSer;
    } 
    DeserializerImpl deserializerImpl = null;
    if (xmlType != null && href == null) {
      deserializerImpl = context.getDeserializerForType(xmlType);
    } else {
      TypeMapping tm = context.getTypeMapping();
      QName defaultXMLType = tm.getTypeQName(javaType);
      if (href == null) {
        deserializerImpl = context.getDeserializer(javaType, defaultXMLType);
      } else {
        deserializerImpl = new DeserializerImpl();
        context.setDestinationClass(javaType);
        deserializerImpl.setDefaultType(defaultXMLType);
      } 
    } 
    if (javaType.equals(String.class) && deserializerImpl instanceof SimpleDeserializer) {
      this.cacheStringDSer = (SimpleDeserializer)deserializerImpl;
      this.cacheXMLType = xmlType;
    } 
    return deserializerImpl;
  }
  
  public void characters(char[] chars, int start, int end) throws SAXException { this.val.write(chars, start, end); }
  
  public void onEndElement(String namespace, String localName, DeserializationContext context) throws SAXException { handleMixedContent(); }
  
  protected void handleMixedContent() throws SAXException {
    BeanPropertyDescriptor propDesc = getAnyPropertyDesc();
    if (propDesc == null || this.val.size() == 0)
      return; 
    String textValue = this.val.toString().trim();
    this.val.reset();
    if (textValue.length() == 0)
      return; 
    try {
      MessageElement[] curElements = (MessageElement[])propDesc.get(this.value);
      int length = 0;
      if (curElements != null)
        length = curElements.length; 
      MessageElement[] newElements = new MessageElement[length + 1];
      if (curElements != null)
        System.arraycopy(curElements, 0, newElements, 0, length); 
      MessageElement thisEl = new MessageElement(new Text(textValue));
      newElements[length] = thisEl;
      propDesc.set(this.value, newElements);
    } catch (Exception e) {
      throw new SAXException(e);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\BeanDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */