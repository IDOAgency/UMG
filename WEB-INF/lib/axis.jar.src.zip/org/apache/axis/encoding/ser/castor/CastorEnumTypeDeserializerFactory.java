/*    */ package org.apache.axis.encoding.ser.castor;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.DeserializerFactory;
/*    */ import org.apache.axis.encoding.ser.BaseDeserializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CastorEnumTypeDeserializerFactory
/*    */   extends BaseDeserializerFactory
/*    */ {
/* 32 */   public CastorEnumTypeDeserializerFactory(Class javaType, QName xmlType) { super(CastorEnumTypeDeserializer.class, xmlType, javaType); }
/*    */ 
/*    */   
/* 35 */   public static DeserializerFactory create(Class javaType, QName xmlType) { return new CastorEnumTypeDeserializerFactory(javaType, xmlType); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\castor\CastorEnumTypeDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */