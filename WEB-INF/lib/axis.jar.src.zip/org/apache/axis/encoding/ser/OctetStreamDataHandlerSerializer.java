package org.apache.axis.encoding.ser;

import java.io.IOException;
import javax.activation.DataHandler;
import javax.xml.namespace.QName;
import org.apache.axis.attachments.OctetStream;
import org.apache.axis.attachments.OctetStreamDataSource;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.SerializationContext;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;

public class OctetStreamDataHandlerSerializer extends JAFDataHandlerSerializer {
  protected static Log log = LogFactory.getLog(OctetStreamDataHandlerSerializer.class.getName());
  
  public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException {
    DataHandler dh = new DataHandler(new OctetStreamDataSource("source", (OctetStream)value));
    super.serialize(name, attributes, dh, context);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\OctetStreamDataHandlerSerializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */