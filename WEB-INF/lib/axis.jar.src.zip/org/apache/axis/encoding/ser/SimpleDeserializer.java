package org.apache.axis.encoding.ser;

import java.io.CharArrayWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.xml.namespace.QName;
import org.apache.axis.description.TypeDesc;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.Deserializer;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.encoding.TypeMapping;
import org.apache.axis.message.SOAPHandler;
import org.apache.axis.types.URI;
import org.apache.axis.utils.BeanPropertyDescriptor;
import org.apache.axis.utils.BeanUtils;
import org.apache.axis.utils.Messages;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class SimpleDeserializer extends DeserializerImpl {
  private static final Class[] STRING_STRING_CLASS = { String.class, String.class };
  
  public static final Class[] STRING_CLASS = { String.class };
  
  private final CharArrayWriter val;
  
  private Constructor constructor;
  
  private Map propertyMap;
  
  private HashMap attributeMap;
  
  public QName xmlType;
  
  public Class javaType;
  
  private TypeDesc typeDesc;
  
  protected DeserializationContext context;
  
  protected SimpleDeserializer cacheStringDSer;
  
  protected QName cacheXMLType;
  
  public SimpleDeserializer(Class javaType, QName xmlType) {
    this.val = new CharArrayWriter();
    this.constructor = null;
    this.propertyMap = null;
    this.attributeMap = null;
    this.typeDesc = null;
    this.context = null;
    this.cacheStringDSer = null;
    this.cacheXMLType = null;
    this.xmlType = xmlType;
    this.javaType = javaType;
    init();
  }
  
  public SimpleDeserializer(Class javaType, QName xmlType, TypeDesc typeDesc) {
    this.val = new CharArrayWriter();
    this.constructor = null;
    this.propertyMap = null;
    this.attributeMap = null;
    this.typeDesc = null;
    this.context = null;
    this.cacheStringDSer = null;
    this.cacheXMLType = null;
    this.xmlType = xmlType;
    this.javaType = javaType;
    this.typeDesc = typeDesc;
    init();
  }
  
  private void init() {
    if (org.apache.axis.encoding.SimpleType.class.isAssignableFrom(this.javaType))
      if (this.typeDesc == null)
        this.typeDesc = TypeDesc.getTypeDescForClass(this.javaType);  
    if (this.typeDesc != null) {
      this.propertyMap = this.typeDesc.getPropertyDescriptorMap();
    } else {
      BeanPropertyDescriptor[] pd = BeanUtils.getPd(this.javaType, null);
      this.propertyMap = new HashMap();
      for (int i = 0; i < pd.length; i++) {
        BeanPropertyDescriptor descriptor = pd[i];
        this.propertyMap.put(descriptor.getName(), descriptor);
      } 
    } 
  }
  
  public void reset() {
    this.val.reset();
    this.attributeMap = null;
    this.isNil = false;
    this.isEnded = false;
  }
  
  public void setConstructor(Constructor c) { this.constructor = c; }
  
  public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException { throw new SAXException(Messages.getMessage("cantHandle00", "SimpleDeserializer")); }
  
  public void characters(char[] chars, int start, int end) throws SAXException { this.val.write(chars, start, end); }
  
  public void onEndElement(String namespace, String localName, DeserializationContext context) throws SAXException {
    if (this.isNil) {
      this.value = null;
      return;
    } 
    try {
      this.value = makeValue(this.val.toString());
    } catch (InvocationTargetException ite) {
      Throwable realException = ite.getTargetException();
      if (realException instanceof Exception)
        throw new SAXException((Exception)realException); 
      throw new SAXException(ite.getMessage());
    } catch (Exception e) {
      throw new SAXException(e);
    } 
    setSimpleTypeAttributes();
  }
  
  public Object makeValue(String source) throws Exception {
    if (this.javaType == String.class)
      return source; 
    source = source.trim();
    if (source.length() == 0 && this.typeDesc == null)
      return null; 
    if (this.constructor == null) {
      Object value = makeBasicValue(source);
      if (value != null)
        return value; 
    } 
    Object[] args = null;
    boolean isQNameSubclass = QName.class.isAssignableFrom(this.javaType);
    if (isQNameSubclass) {
      int colon = source.lastIndexOf(":");
      String namespace = (colon < 0) ? "" : this.context.getNamespaceURI(source.substring(0, colon));
      String localPart = (colon < 0) ? source : source.substring(colon + 1);
      args = new Object[] { namespace, localPart };
    } 
    if (this.constructor == null)
      try {
        if (isQNameSubclass) {
          this.constructor = this.javaType.getDeclaredConstructor(STRING_STRING_CLASS);
        } else {
          this.constructor = this.javaType.getDeclaredConstructor(STRING_CLASS);
        } 
      } catch (Exception e) {
        return null;
      }  
    if (this.constructor.getParameterTypes().length == 0)
      try {
        Object obj = this.constructor.newInstance(new Object[0]);
        obj.getClass().getMethod("set_value", new Class[] { String.class }).invoke(obj, new Object[] { source });
        return obj;
      } catch (Exception e) {} 
    if (args == null)
      args = new Object[] { source }; 
    return this.constructor.newInstance(args);
  }
  
  private Object makeBasicValue(String source) throws Exception {
    if (this.javaType == boolean.class || this.javaType == Boolean.class) {
      switch (source.charAt(0)) {
        case '0':
        case 'F':
        case 'f':
          return Boolean.FALSE;
        case '1':
        case 'T':
        case 't':
          return Boolean.TRUE;
      } 
      throw new NumberFormatException(Messages.getMessage("badBool00"));
    } 
    if (this.javaType == float.class || this.javaType == Float.class) {
      if (source.equals("NaN"))
        return new Float(NaNF); 
      if (source.equals("INF"))
        return new Float(Float.POSITIVE_INFINITY); 
      if (source.equals("-INF"))
        return new Float(Float.NEGATIVE_INFINITY); 
      return new Float(source);
    } 
    if (this.javaType == double.class || this.javaType == Double.class) {
      if (source.equals("NaN"))
        return new Double(NaND); 
      if (source.equals("INF"))
        return new Double(Double.POSITIVE_INFINITY); 
      if (source.equals("-INF"))
        return new Double(Double.NEGATIVE_INFINITY); 
      return new Double(source);
    } 
    if (this.javaType == int.class || this.javaType == Integer.class)
      return new Integer(source); 
    if (this.javaType == short.class || this.javaType == Short.class)
      return new Short(source); 
    if (this.javaType == long.class || this.javaType == Long.class)
      return new Long(source); 
    if (this.javaType == byte.class || this.javaType == Byte.class)
      return new Byte(source); 
    if (this.javaType == URI.class)
      return new URI(source); 
    return null;
  }
  
  public void onStartElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    this.context = context;
    for (int i = 0; i < attributes.getLength(); i++) {
      QName attrQName = new QName(attributes.getURI(i), attributes.getLocalName(i));
      String fieldName = attributes.getLocalName(i);
      if (this.typeDesc != null) {
        fieldName = this.typeDesc.getFieldNameForAttribute(attrQName);
        if (fieldName == null)
          continue; 
      } 
      if (this.propertyMap != null) {
        BeanPropertyDescriptor bpd = (BeanPropertyDescriptor)this.propertyMap.get(fieldName);
        if (bpd != null && 
          bpd.isWriteable() && !bpd.isIndexed()) {
          TypeMapping tm = context.getTypeMapping();
          Class type = bpd.getType();
          QName qn = tm.getTypeQName(type);
          if (qn == null)
            throw new SAXException(Messages.getMessage("unregistered00", type.toString())); 
          Deserializer dSer = context.getDeserializerForType(qn);
          if (dSer == null)
            throw new SAXException(Messages.getMessage("noDeser00", type.toString())); 
          if (!(dSer instanceof SimpleDeserializer))
            throw new SAXException(Messages.getMessage("AttrNotSimpleType00", bpd.getName(), type.toString())); 
          if (this.attributeMap == null)
            this.attributeMap = new HashMap(); 
          try {
            Object val = ((SimpleDeserializer)dSer).makeValue(attributes.getValue(i));
            this.attributeMap.put(fieldName, val);
          } catch (Exception e) {
            throw new SAXException(e);
          } 
        } 
      } 
      continue;
    } 
  }
  
  private void setSimpleTypeAttributes() {
    if (this.attributeMap == null)
      return; 
    Set entries = this.attributeMap.entrySet();
    for (Iterator iterator = entries.iterator(); iterator.hasNext(); ) {
      Map.Entry entry = (Map.Entry)iterator.next();
      String name = (String)entry.getKey();
      Object val = entry.getValue();
      BeanPropertyDescriptor bpd = (BeanPropertyDescriptor)this.propertyMap.get(name);
      if (!bpd.isWriteable() || bpd.isIndexed())
        continue; 
      try {
        bpd.set(this.value, val);
      } catch (Exception e) {
        throw new SAXException(e);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\SimpleDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */