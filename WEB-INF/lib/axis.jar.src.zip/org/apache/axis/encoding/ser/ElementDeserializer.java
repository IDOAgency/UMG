package org.apache.axis.encoding.ser;

import java.util.List;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.message.MessageElement;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.SAXException;

public class ElementDeserializer extends DeserializerImpl {
  protected static Log log = LogFactory.getLog(ElementDeserializer.class.getName());
  
  public static final String DESERIALIZE_CURRENT_ELEMENT = "DeserializeCurrentElement";
  
  public final void onEndElement(String namespace, String localName, DeserializationContext context) throws SAXException {
    try {
      MessageElement msgElem = context.getCurElement();
      if (msgElem != null) {
        MessageContext messageContext = context.getMessageContext();
        Boolean currentElement = (Boolean)messageContext.getProperty("DeserializeCurrentElement");
        if (currentElement != null && currentElement.booleanValue()) {
          this.value = msgElem.getAsDOM();
          messageContext.setProperty("DeserializeCurrentElement", Boolean.FALSE);
          return;
        } 
        List children = msgElem.getChildren();
        if (children != null) {
          msgElem = (MessageElement)children.get(0);
          if (msgElem != null)
            this.value = msgElem.getAsDOM(); 
        } 
      } 
    } catch (Exception exp) {
      log.error(Messages.getMessage("exception00"), exp);
      throw new SAXException(exp);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\ElementDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */