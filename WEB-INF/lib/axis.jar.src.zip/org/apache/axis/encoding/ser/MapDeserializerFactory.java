package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;

public class MapDeserializerFactory extends BaseDeserializerFactory {
  public MapDeserializerFactory(Class javaType, QName xmlType) { super(MapDeserializer.class, xmlType, javaType); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\MapDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */