/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.encoding.Deserializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArrayDeserializerFactory
/*    */   extends BaseDeserializerFactory
/*    */ {
/*    */   private QName componentXmlType;
/*    */   
/* 31 */   public ArrayDeserializerFactory() { super(ArrayDeserializer.class); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ArrayDeserializerFactory(QName componentXmlType) {
/* 39 */     super(ArrayDeserializer.class);
/* 40 */     this.componentXmlType = componentXmlType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Deserializer getDeserializerAs(String mechanismType) {
/* 51 */     ArrayDeserializer dser = (ArrayDeserializer)super.getDeserializerAs(mechanismType);
/* 52 */     dser.defaultItemType = this.componentXmlType;
/* 53 */     return dser;
/*    */   }
/*    */ 
/*    */   
/* 57 */   public void setComponentType(QName componentType) { this.componentXmlType = componentType; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\ArrayDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */