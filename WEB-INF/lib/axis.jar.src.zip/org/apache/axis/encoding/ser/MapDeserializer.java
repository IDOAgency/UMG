package org.apache.axis.encoding.ser;

import java.util.HashMap;
import java.util.Map;
import javax.xml.namespace.QName;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.encoding.DeserializerTarget;
import org.apache.axis.message.SOAPHandler;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class MapDeserializer extends DeserializerImpl {
  protected static Log log = LogFactory.getLog(MapDeserializer.class.getName());
  
  public static final Object KEYHINT = new Object();
  
  public static final Object VALHINT = new Object();
  
  public static final Object NILHINT = new Object();
  
  public void onStartElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (log.isDebugEnabled())
      log.debug("Enter MapDeserializer::startElement()"); 
    if (context.isNil(attributes))
      return; 
    setValue(new HashMap());
    if (log.isDebugEnabled())
      log.debug("Exit: MapDeserializer::startElement()"); 
  }
  
  public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (log.isDebugEnabled())
      log.debug("Enter: MapDeserializer::onStartChild()"); 
    if (localName.equals("item")) {
      ItemHandler handler = new ItemHandler(this, this);
      addChildDeserializer(handler);
      if (log.isDebugEnabled())
        log.debug("Exit: MapDeserializer::onStartChild()"); 
      return handler;
    } 
    return this;
  }
  
  public void setChildValue(Object value, Object hint) throws SAXException {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("gotValue00", "MapDeserializer", "" + value)); 
    ((Map)this.value).put(hint, value);
  }
  
  class ItemHandler extends DeserializerImpl {
    Object key;
    
    Object myValue;
    
    int numSet;
    
    MapDeserializer md;
    
    private final MapDeserializer this$0;
    
    ItemHandler(MapDeserializer this$0, MapDeserializer md) {
      this.this$0 = this$0;
      this.numSet = 0;
      this.md = null;
      this.md = md;
    }
    
    public void setChildValue(Object val, Object hint) throws SAXException {
      if (hint == MapDeserializer.KEYHINT) {
        this.key = val;
      } else if (hint == MapDeserializer.VALHINT) {
        this.myValue = val;
      } else if (hint != MapDeserializer.NILHINT) {
        return;
      } 
      this.numSet++;
      if (this.numSet == 2)
        this.md.setChildValue(this.myValue, this.key); 
    }
    
    public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
      QName typeQName = context.getTypeFromAttributes(namespace, localName, attributes);
      DeserializerImpl deserializerImpl = context.getDeserializerForType(typeQName);
      if (deserializerImpl == null)
        deserializerImpl = new DeserializerImpl(); 
      DeserializerTarget dt = null;
      if (context.isNil(attributes)) {
        dt = new DeserializerTarget(this, MapDeserializer.NILHINT);
      } else if (localName.equals("key")) {
        dt = new DeserializerTarget(this, MapDeserializer.KEYHINT);
      } else if (localName.equals("value")) {
        dt = new DeserializerTarget(this, MapDeserializer.VALHINT);
      } 
      if (dt != null)
        deserializerImpl.registerValueTarget(dt); 
      addChildDeserializer(deserializerImpl);
      return (SOAPHandler)deserializerImpl;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\MapDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */