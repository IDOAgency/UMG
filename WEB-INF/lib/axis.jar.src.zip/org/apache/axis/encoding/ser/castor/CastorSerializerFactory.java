/*    */ package org.apache.axis.encoding.ser.castor;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializerFactory;
/*    */ import org.apache.axis.encoding.ser.BaseSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CastorSerializerFactory
/*    */   extends BaseSerializerFactory
/*    */ {
/* 31 */   public CastorSerializerFactory(Class javaType, QName xmlType) { super(CastorSerializer.class, xmlType, javaType); }
/*    */ 
/*    */   
/* 34 */   public static SerializerFactory create(Class javaType, QName xmlType) { return new CastorSerializerFactory(javaType, xmlType); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\castor\CastorSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */