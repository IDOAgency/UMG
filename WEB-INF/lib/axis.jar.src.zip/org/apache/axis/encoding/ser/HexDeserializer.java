/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.types.HexBinary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HexDeserializer
/*    */   extends SimpleDeserializer
/*    */ {
/*    */   static Class array$B;
/*    */   
/* 33 */   public HexDeserializer(Class javaType, QName xmlType) { super(javaType, xmlType); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object makeValue(String source) throws Exception {
/*    */     Object result;
/* 45 */     if (this.javaType == ((array$B == null) ? (array$B = class$("[B")) : array$B)) {
/* 46 */       result = HexBinary.decode(source);
/*    */     } else {
/* 48 */       result = new HexBinary(source);
/*    */     } 
/* 50 */     if (result == null) result = new HexBinary(""); 
/* 51 */     return result;
/*    */   }
/*    */   
/*    */   static Class class$(String x0) { try {
/*    */       return Class.forName(x0);
/*    */     } catch (ClassNotFoundException x1) {
/*    */       throw new NoClassDefFoundError(x1.getMessage());
/*    */     }  }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\HexDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */