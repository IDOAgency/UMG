package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;

public class JAFDataHandlerSerializerFactory extends BaseSerializerFactory {
  public JAFDataHandlerSerializerFactory(Class javaType, QName xmlType) { super(getSerializerClass(javaType, xmlType), xmlType, javaType); }
  
  public JAFDataHandlerSerializerFactory() { super(JAFDataHandlerSerializer.class); }
  
  private static Class getSerializerClass(Class javaType, QName xmlType) {
    Class ser;
    if (java.awt.Image.class.isAssignableFrom(javaType)) {
      ser = ImageDataHandlerSerializer.class;
    } else if (String.class.isAssignableFrom(javaType)) {
      ser = PlainTextDataHandlerSerializer.class;
    } else if (javax.xml.transform.Source.class.isAssignableFrom(javaType)) {
      ser = SourceDataHandlerSerializer.class;
    } else if (javax.mail.internet.MimeMultipart.class.isAssignableFrom(javaType)) {
      ser = MimeMultipartDataHandlerSerializer.class;
    } else if (org.apache.axis.attachments.OctetStream.class.isAssignableFrom(javaType)) {
      ser = OctetStreamDataHandlerSerializer.class;
    } else {
      ser = JAFDataHandlerSerializer.class;
    } 
    return ser;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\JAFDataHandlerSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */