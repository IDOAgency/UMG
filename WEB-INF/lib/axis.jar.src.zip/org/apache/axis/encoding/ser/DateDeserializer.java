package org.apache.axis.encoding.ser;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.xml.namespace.QName;
import org.apache.axis.utils.Messages;

public class DateDeserializer extends SimpleDeserializer {
  private static SimpleDateFormat zulu = new SimpleDateFormat("yyyy-MM-dd");
  
  private static Calendar calendar = Calendar.getInstance();
  
  public DateDeserializer(Class javaType, QName xmlType) { super(javaType, xmlType); }
  
  public Object makeValue(String source) {
    Object result;
    boolean bc = false;
    if (source != null) {
      if (source.length() < 10)
        throw new NumberFormatException(Messages.getMessage("badDate00")); 
      if (source.charAt(0) == '+')
        source = source.substring(1); 
      if (source.charAt(0) == '-') {
        source = source.substring(1);
        bc = true;
      } 
      if (source.charAt(4) != '-' || source.charAt(7) != '-')
        throw new NumberFormatException(Messages.getMessage("badDate00")); 
    } 
    synchronized (calendar) {
      try {
        result = zulu.parse((source == null) ? null : source.substring(0, 10));
      } catch (Exception e) {
        throw new NumberFormatException(e.toString());
      } 
      if (bc) {
        calendar.setTime((Date)result);
        calendar.set(0, 0);
        result = calendar.getTime();
      } 
      if (this.javaType == Date.class)
        return result; 
      if (this.javaType == Date.class) {
        result = new Date(((Date)result).getTime());
      } else {
        calendar.setTime((Date)result);
        result = calendar;
      } 
    } 
    return result;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\DateDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */