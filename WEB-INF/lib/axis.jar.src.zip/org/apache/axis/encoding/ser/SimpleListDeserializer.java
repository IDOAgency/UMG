package org.apache.axis.encoding.ser;

import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import javax.xml.namespace.QName;
import org.apache.axis.description.TypeDesc;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.Deserializer;
import org.apache.axis.encoding.TypeMapping;
import org.apache.axis.message.SOAPHandler;
import org.apache.axis.utils.BeanPropertyDescriptor;
import org.apache.axis.utils.Messages;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class SimpleListDeserializer extends SimpleDeserializer {
  StringBuffer val = new StringBuffer();
  
  private Constructor constructor = null;
  
  private Map propertyMap = null;
  
  private HashMap attributeMap = null;
  
  private DeserializationContext context = null;
  
  public QName xmlType;
  
  public Class javaType;
  
  private TypeDesc typeDesc = null;
  
  protected SimpleListDeserializer cacheStringDSer = null;
  
  protected QName cacheXMLType = null;
  
  public SimpleListDeserializer(Class javaType, QName xmlType) {
    super(javaType, xmlType);
    this.xmlType = xmlType;
    this.javaType = javaType;
  }
  
  public SimpleListDeserializer(Class javaType, QName xmlType, TypeDesc typeDesc) {
    super(javaType, xmlType, typeDesc);
    this.xmlType = xmlType;
    this.javaType = javaType;
    this.typeDesc = typeDesc;
  }
  
  public void reset() {
    this.val.setLength(0);
    this.attributeMap = null;
    this.isNil = false;
    this.isEnded = false;
  }
  
  public void setConstructor(Constructor c) { this.constructor = c; }
  
  public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException { throw new SAXException(Messages.getMessage("cantHandle00", "SimpleDeserializer")); }
  
  public void characters(char[] chars, int start, int end) throws SAXException { this.val.append(chars, start, end); }
  
  public void onEndElement(String namespace, String localName, DeserializationContext context) throws SAXException {
    if (this.isNil || this.val == null) {
      this.value = null;
      return;
    } 
    try {
      this.value = makeValue(this.val.toString());
    } catch (InvocationTargetException ite) {
      Throwable realException = ite.getTargetException();
      if (realException instanceof Exception)
        throw new SAXException((Exception)realException); 
      throw new SAXException(ite.getMessage());
    } catch (Exception e) {
      throw new SAXException(e);
    } 
    setSimpleTypeAttributes();
  }
  
  public Object makeValue(String source) throws Exception {
    StringTokenizer tokenizer = new StringTokenizer(source.trim());
    int length = tokenizer.countTokens();
    Object list = Array.newInstance(this.javaType, length);
    for (int i = 0; i < length; i++) {
      String token = tokenizer.nextToken();
      Array.set(list, i, makeUnitValue(token));
    } 
    return list;
  }
  
  private Object makeUnitValue(String source) throws Exception {
    if (this.javaType == boolean.class || this.javaType == Boolean.class) {
      switch (source.charAt(0)) {
        case '0':
        case 'F':
        case 'f':
          return Boolean.FALSE;
        case '1':
        case 'T':
        case 't':
          return Boolean.TRUE;
      } 
      throw new NumberFormatException(Messages.getMessage("badBool00"));
    } 
    if (this.javaType == float.class || this.javaType == Float.class) {
      if (source.equals("NaN"))
        return new Float(NaNF); 
      if (source.equals("INF"))
        return new Float(Float.POSITIVE_INFINITY); 
      if (source.equals("-INF"))
        return new Float(Float.NEGATIVE_INFINITY); 
    } 
    if (this.javaType == double.class || this.javaType == Double.class) {
      if (source.equals("NaN"))
        return new Double(NaND); 
      if (source.equals("INF"))
        return new Double(Double.POSITIVE_INFINITY); 
      if (source.equals("-INF"))
        return new Double(Double.NEGATIVE_INFINITY); 
    } 
    if (this.javaType == QName.class) {
      int colon = source.lastIndexOf(":");
      String namespace = (colon < 0) ? "" : this.context.getNamespaceURI(source.substring(0, colon));
      String localPart = (colon < 0) ? source : source.substring(colon + 1);
      return new QName(namespace, localPart);
    } 
    return this.constructor.newInstance(new Object[] { source });
  }
  
  public void onStartElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    this.context = context;
    if (this.typeDesc == null)
      return; 
    for (int i = 0; i < attributes.getLength(); i++) {
      QName attrQName = new QName(attributes.getURI(i), attributes.getLocalName(i));
      String fieldName = this.typeDesc.getFieldNameForAttribute(attrQName);
      if (fieldName != null) {
        BeanPropertyDescriptor bpd = (BeanPropertyDescriptor)this.propertyMap.get(fieldName);
        if (bpd != null && 
          bpd.isWriteable() && !bpd.isIndexed()) {
          TypeMapping tm = context.getTypeMapping();
          Class type = bpd.getType();
          QName qn = tm.getTypeQName(type);
          if (qn == null)
            throw new SAXException(Messages.getMessage("unregistered00", type.toString())); 
          Deserializer dSer = context.getDeserializerForType(qn);
          if (dSer == null)
            throw new SAXException(Messages.getMessage("noDeser00", type.toString())); 
          if (!(dSer instanceof SimpleListDeserializer))
            throw new SAXException(Messages.getMessage("AttrNotSimpleType00", bpd.getName(), type.toString())); 
          if (this.attributeMap == null)
            this.attributeMap = new HashMap(); 
          try {
            Object val = ((SimpleListDeserializer)dSer).makeValue(attributes.getValue(i));
            this.attributeMap.put(fieldName, val);
          } catch (Exception e) {
            throw new SAXException(e);
          } 
        } 
      } 
    } 
  }
  
  private void setSimpleTypeAttributes() {
    if (!org.apache.axis.encoding.SimpleType.class.isAssignableFrom(this.javaType) || this.attributeMap == null)
      return; 
    Set entries = this.attributeMap.entrySet();
    for (Iterator iterator = entries.iterator(); iterator.hasNext(); ) {
      Map.Entry entry = (Map.Entry)iterator.next();
      String name = (String)entry.getKey();
      Object val = entry.getValue();
      BeanPropertyDescriptor bpd = (BeanPropertyDescriptor)this.propertyMap.get(name);
      if (!bpd.isWriteable() || bpd.isIndexed())
        continue; 
      try {
        bpd.set(this.value, val);
      } catch (Exception e) {
        throw new SAXException(e);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\SimpleListDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */