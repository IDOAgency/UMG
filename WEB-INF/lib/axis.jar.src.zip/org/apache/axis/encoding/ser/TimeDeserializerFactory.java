/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeDeserializerFactory
/*    */   extends BaseDeserializerFactory
/*    */ {
/* 28 */   public TimeDeserializerFactory(Class javaType, QName xmlType) { super(TimeDeserializer.class, xmlType, javaType); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\TimeDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */