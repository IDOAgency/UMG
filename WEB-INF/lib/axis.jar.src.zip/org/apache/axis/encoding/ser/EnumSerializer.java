package org.apache.axis.encoding.ser;

import java.io.IOException;
import java.lang.reflect.Method;
import javax.xml.namespace.QName;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.Messages;
import org.apache.axis.wsdl.fromJava.Types;
import org.apache.commons.logging.Log;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;

public class EnumSerializer extends SimpleSerializer {
  protected static Log log = LogFactory.getLog(EnumSerializer.class.getName());
  
  private Method toStringMethod = null;
  
  public EnumSerializer(Class javaType, QName xmlType) { super(javaType, xmlType); }
  
  public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException {
    context.startElement(name, attributes);
    context.writeString(getValueAsString(value, context));
    context.endElement();
  }
  
  public String getValueAsString(Object value, SerializationContext context) {
    try {
      if (this.toStringMethod == null)
        this.toStringMethod = this.javaType.getMethod("toString", null); 
      return (String)this.toStringMethod.invoke(value, null);
    } catch (Exception e) {
      log.error(Messages.getMessage("exception00"), e);
      return null;
    } 
  }
  
  public Element writeSchema(Class javaType, Types types) throws Exception { return types.writeEnumType(this.xmlType, javaType); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\EnumSerializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */