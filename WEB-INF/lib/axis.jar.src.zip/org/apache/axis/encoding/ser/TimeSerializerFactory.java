package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;

public class TimeSerializerFactory extends BaseSerializerFactory {
  public TimeSerializerFactory(Class javaType, QName xmlType) { super(TimeSerializer.class, xmlType, javaType); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\TimeSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */