/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.axis.utils.cache.MethodCache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseFactory
/*    */ {
/* 32 */   private static final Class[] STRING_CLASS_QNAME_CLASS = { String.class, Class.class, javax.xml.namespace.QName.class };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Method getMethod(Class clazz, String methodName) {
/* 40 */     Method method = null;
/*    */     try {
/* 42 */       method = MethodCache.getInstance().getMethod(clazz, methodName, STRING_CLASS_QNAME_CLASS);
/* 43 */     } catch (NoSuchMethodException e) {}
/*    */     
/* 45 */     return method;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\BaseFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */