/*     */ package org.apache.axis.encoding.ser;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.Deserializer;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.DeserializerFactory;
/*     */ import org.apache.axis.i18n.Messages;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseDeserializerFactory
/*     */   extends BaseFactory
/*     */   implements DeserializerFactory
/*     */ {
/*  42 */   protected static Log log = LogFactory.getLog(BaseDeserializerFactory.class.getName());
/*     */ 
/*     */   
/*  45 */   static Vector mechanisms = null;
/*     */   
/*  47 */   protected Class deserClass = null;
/*  48 */   protected QName xmlType = null;
/*  49 */   protected Class javaType = null;
/*     */   
/*  51 */   protected Constructor deserClassConstructor = null;
/*  52 */   protected Method getDeserializer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseDeserializerFactory(Class deserClass) {
/*  59 */     if (!Deserializer.class.isAssignableFrom(deserClass)) {
/*  60 */       throw new ClassCastException(Messages.getMessage("BadImplementation00", deserClass.getName(), Deserializer.class.getName()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  65 */     this.deserClass = deserClass;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseDeserializerFactory(Class deserClass, QName xmlType, Class javaType) {
/*  71 */     this(deserClass);
/*  72 */     this.xmlType = xmlType;
/*  73 */     this.javaType = javaType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Deserializer getDeserializerAs(String mechanismType) throws JAXRPCException {
/*  79 */     Deserializer deser = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     deser = getSpecialized(mechanismType);
/*     */ 
/*     */ 
/*     */     
/*  88 */     if (deser == null) {
/*  89 */       deser = getGeneralPurpose(mechanismType);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  94 */       if (deser == null) {
/*  95 */         deser = (Deserializer)this.deserClass.newInstance();
/*     */       }
/*  97 */     } catch (Exception e) {
/*  98 */       throw new JAXRPCException(e);
/*     */     } 
/* 100 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Deserializer getGeneralPurpose(String mechanismType) {
/* 108 */     if (this.javaType != null && this.xmlType != null) {
/* 109 */       Constructor deserClassConstructor = getDeserClassConstructor();
/* 110 */       if (deserClassConstructor != null) {
/*     */         try {
/* 112 */           return (Deserializer)deserClassConstructor.newInstance(new Object[] { this.javaType, this.xmlType });
/*     */         
/*     */         }
/* 115 */         catch (InstantiationException e) {
/* 116 */           if (log.isDebugEnabled()) {
/* 117 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/* 119 */         } catch (IllegalAccessException e) {
/* 120 */           if (log.isDebugEnabled()) {
/* 121 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/* 123 */         } catch (InvocationTargetException e) {
/* 124 */           if (log.isDebugEnabled()) {
/* 125 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 130 */     return null;
/*     */   }
/*     */   
/* 133 */   private static final Class[] CLASS_QNAME_CLASS = { Class.class, QName.class };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Constructor getConstructor(Class clazz) {
/*     */     try {
/* 140 */       return clazz.getConstructor(CLASS_QNAME_CLASS);
/* 141 */     } catch (NoSuchMethodException e) {
/* 142 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Deserializer getSpecialized(String mechanismType) {
/* 150 */     if (this.javaType != null && this.xmlType != null) {
/* 151 */       Method getDeserializer = getGetDeserializer();
/* 152 */       if (getDeserializer != null) {
/*     */         try {
/* 154 */           return (Deserializer)getDeserializer.invoke(null, new Object[] { mechanismType, this.javaType, this.xmlType });
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 160 */         catch (IllegalAccessException e) {
/* 161 */           if (log.isDebugEnabled()) {
/* 162 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/* 164 */         } catch (InvocationTargetException e) {
/* 165 */           if (log.isDebugEnabled()) {
/* 166 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getSupportedMechanismTypes() {
/* 180 */     if (mechanisms == null) {
/* 181 */       mechanisms = new Vector(1);
/* 182 */       mechanisms.add("Axis SAX Mechanism");
/*     */     } 
/* 184 */     return mechanisms.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DeserializerFactory createFactory(Class factory, Class javaType, QName xmlType) {
/* 200 */     if (factory == null) {
/* 201 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 205 */       if (factory == BeanDeserializerFactory.class)
/* 206 */         return new BeanDeserializerFactory(javaType, xmlType); 
/* 207 */       if (factory == SimpleDeserializerFactory.class)
/* 208 */         return new SimpleDeserializerFactory(javaType, xmlType); 
/* 209 */       if (factory == EnumDeserializerFactory.class)
/* 210 */         return new EnumDeserializerFactory(javaType, xmlType); 
/* 211 */       if (factory == ElementDeserializerFactory.class)
/* 212 */         return new ElementDeserializerFactory(); 
/* 213 */       if (factory == SimpleListDeserializerFactory.class) {
/* 214 */         return new SimpleListDeserializerFactory(javaType, xmlType);
/*     */       }
/* 216 */     } catch (Exception e) {
/* 217 */       if (log.isDebugEnabled()) {
/* 218 */         log.debug(Messages.getMessage("exception00"), e);
/*     */       }
/* 220 */       return null;
/*     */     } 
/*     */     
/* 223 */     DeserializerFactory df = null;
/*     */     try {
/* 225 */       Method method = factory.getMethod("create", CLASS_QNAME_CLASS);
/*     */       
/* 227 */       df = (DeserializerFactory)method.invoke(null, new Object[] { javaType, xmlType });
/*     */     
/*     */     }
/* 230 */     catch (NoSuchMethodException e) {
/* 231 */       if (log.isDebugEnabled()) {
/* 232 */         log.debug(Messages.getMessage("exception00"), e);
/*     */       }
/* 234 */     } catch (IllegalAccessException e) {
/* 235 */       if (log.isDebugEnabled()) {
/* 236 */         log.debug(Messages.getMessage("exception00"), e);
/*     */       }
/* 238 */     } catch (InvocationTargetException e) {
/* 239 */       if (log.isDebugEnabled()) {
/* 240 */         log.debug(Messages.getMessage("exception00"), e);
/*     */       }
/*     */     } 
/*     */     
/* 244 */     if (df == null) {
/*     */       try {
/* 246 */         Constructor constructor = factory.getConstructor(CLASS_QNAME_CLASS);
/*     */         
/* 248 */         df = (DeserializerFactory)constructor.newInstance(new Object[] { javaType, xmlType });
/*     */       
/*     */       }
/* 251 */       catch (NoSuchMethodException e) {
/* 252 */         if (log.isDebugEnabled()) {
/* 253 */           log.debug(Messages.getMessage("exception00"), e);
/*     */         }
/* 255 */       } catch (InstantiationException e) {
/* 256 */         if (log.isDebugEnabled()) {
/* 257 */           log.debug(Messages.getMessage("exception00"), e);
/*     */         }
/* 259 */       } catch (IllegalAccessException e) {
/* 260 */         if (log.isDebugEnabled()) {
/* 261 */           log.debug(Messages.getMessage("exception00"), e);
/*     */         }
/* 263 */       } catch (InvocationTargetException e) {
/* 264 */         if (log.isDebugEnabled()) {
/* 265 */           log.debug(Messages.getMessage("exception00"), e);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 270 */     if (df == null) {
/*     */       
/* 272 */       try { df = (DeserializerFactory)factory.newInstance(); }
/* 273 */       catch (InstantiationException e) {  }
/* 274 */       catch (IllegalAccessException e) {}
/*     */     }
/* 276 */     return df;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Constructor getDeserClassConstructor() {
/* 283 */     if (this.deserClassConstructor == null) {
/* 284 */       this.deserClassConstructor = getConstructor(this.deserClass);
/*     */     }
/* 286 */     return this.deserClassConstructor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getGetDeserializer() {
/* 294 */     if (this.getDeserializer == null) {
/* 295 */       this.getDeserializer = getMethod(this.javaType, "getDeserializer");
/*     */     }
/* 297 */     return this.getDeserializer;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\BaseDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */