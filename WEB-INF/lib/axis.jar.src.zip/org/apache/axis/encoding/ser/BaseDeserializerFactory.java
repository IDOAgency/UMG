package org.apache.axis.encoding.ser;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.Deserializer;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.Deserializer;
import org.apache.axis.encoding.DeserializerFactory;
import org.apache.axis.i18n.Messages;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public abstract class BaseDeserializerFactory extends BaseFactory implements DeserializerFactory {
  protected static Log log = LogFactory.getLog(BaseDeserializerFactory.class.getName());
  
  static Vector mechanisms = null;
  
  protected Class deserClass = null;
  
  protected QName xmlType = null;
  
  protected Class javaType = null;
  
  protected Constructor deserClassConstructor = null;
  
  protected Method getDeserializer = null;
  
  public BaseDeserializerFactory(Class deserClass) {
    if (!Deserializer.class.isAssignableFrom(deserClass))
      throw new ClassCastException(Messages.getMessage("BadImplementation00", deserClass.getName(), Deserializer.class.getName())); 
    this.deserClass = deserClass;
  }
  
  public BaseDeserializerFactory(Class deserClass, QName xmlType, Class javaType) {
    this(deserClass);
    this.xmlType = xmlType;
    this.javaType = javaType;
  }
  
  public Deserializer getDeserializerAs(String mechanismType) throws JAXRPCException {
    Deserializer deser = null;
    deser = getSpecialized(mechanismType);
    if (deser == null)
      deser = getGeneralPurpose(mechanismType); 
    try {
      if (deser == null)
        deser = (Deserializer)this.deserClass.newInstance(); 
    } catch (Exception e) {
      throw new JAXRPCException(e);
    } 
    return deser;
  }
  
  protected Deserializer getGeneralPurpose(String mechanismType) {
    if (this.javaType != null && this.xmlType != null) {
      Constructor deserClassConstructor = getDeserClassConstructor();
      if (deserClassConstructor != null)
        try {
          return (Deserializer)deserClassConstructor.newInstance(new Object[] { this.javaType, this.xmlType });
        } catch (InstantiationException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        } catch (IllegalAccessException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        } catch (InvocationTargetException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        }  
    } 
    return null;
  }
  
  private static final Class[] CLASS_QNAME_CLASS = { Class.class, QName.class };
  
  private Constructor getConstructor(Class clazz) {
    try {
      return clazz.getConstructor(CLASS_QNAME_CLASS);
    } catch (NoSuchMethodException e) {
      return null;
    } 
  }
  
  protected Deserializer getSpecialized(String mechanismType) {
    if (this.javaType != null && this.xmlType != null) {
      Method getDeserializer = getGetDeserializer();
      if (getDeserializer != null)
        try {
          return (Deserializer)getDeserializer.invoke(null, new Object[] { mechanismType, this.javaType, this.xmlType });
        } catch (IllegalAccessException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        } catch (InvocationTargetException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        }  
    } 
    return null;
  }
  
  public Iterator getSupportedMechanismTypes() {
    if (mechanisms == null) {
      mechanisms = new Vector(1);
      mechanisms.add("Axis SAX Mechanism");
    } 
    return mechanisms.iterator();
  }
  
  public static DeserializerFactory createFactory(Class factory, Class javaType, QName xmlType) {
    if (factory == null)
      return null; 
    try {
      if (factory == BeanDeserializerFactory.class)
        return new BeanDeserializerFactory(javaType, xmlType); 
      if (factory == SimpleDeserializerFactory.class)
        return new SimpleDeserializerFactory(javaType, xmlType); 
      if (factory == EnumDeserializerFactory.class)
        return new EnumDeserializerFactory(javaType, xmlType); 
      if (factory == ElementDeserializerFactory.class)
        return new ElementDeserializerFactory(); 
      if (factory == SimpleListDeserializerFactory.class)
        return new SimpleListDeserializerFactory(javaType, xmlType); 
    } catch (Exception e) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("exception00"), e); 
      return null;
    } 
    DeserializerFactory df = null;
    try {
      Method method = factory.getMethod("create", CLASS_QNAME_CLASS);
      df = (DeserializerFactory)method.invoke(null, new Object[] { javaType, xmlType });
    } catch (NoSuchMethodException e) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("exception00"), e); 
    } catch (IllegalAccessException e) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("exception00"), e); 
    } catch (InvocationTargetException e) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("exception00"), e); 
    } 
    if (df == null)
      try {
        Constructor constructor = factory.getConstructor(CLASS_QNAME_CLASS);
        df = (DeserializerFactory)constructor.newInstance(new Object[] { javaType, xmlType });
      } catch (NoSuchMethodException e) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("exception00"), e); 
      } catch (InstantiationException e) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("exception00"), e); 
      } catch (IllegalAccessException e) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("exception00"), e); 
      } catch (InvocationTargetException e) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("exception00"), e); 
      }  
    if (df == null)
      try {
        df = (DeserializerFactory)factory.newInstance();
      } catch (InstantiationException e) {
      
      } catch (IllegalAccessException e) {} 
    return df;
  }
  
  protected Constructor getDeserClassConstructor() {
    if (this.deserClassConstructor == null)
      this.deserClassConstructor = getConstructor(this.deserClass); 
    return this.deserClassConstructor;
  }
  
  protected Method getGetDeserializer() {
    if (this.getDeserializer == null)
      this.getDeserializer = getMethod(this.javaType, "getDeserializer"); 
    return this.getDeserializer;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\BaseDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */