package org.apache.axis.encoding.ser;

import java.beans.IntrospectionException;
import java.lang.reflect.Method;
import javax.xml.namespace.QName;
import org.apache.axis.utils.cache.MethodCache;

public class EnumDeserializer extends SimpleDeserializer {
  private Method fromStringMethod = null;
  
  private static final Class[] STRING_CLASS = { String.class };
  
  public EnumDeserializer(Class javaType, QName xmlType) { super(javaType, xmlType); }
  
  public Object makeValue(String source) throws Exception {
    if (this.isNil)
      return null; 
    if (this.fromStringMethod == null)
      try {
        this.fromStringMethod = MethodCache.getInstance().getMethod(this.javaType, "fromString", STRING_CLASS);
      } catch (Exception e) {
        throw new IntrospectionException(e.toString());
      }  
    return this.fromStringMethod.invoke(null, new Object[] { source });
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\EnumDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */