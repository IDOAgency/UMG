package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;
import org.apache.axis.Constants;
import org.apache.axis.encoding.Serializer;

public class ArraySerializerFactory extends BaseSerializerFactory {
  private QName componentType;
  
  private QName componentQName;
  
  static Class array$Ljava$lang$Object;
  
  public ArraySerializerFactory() { this((array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object, Constants.SOAP_ARRAY); }
  
  public ArraySerializerFactory(Class javaType, QName xmlType) {
    super(ArraySerializer.class, xmlType, javaType);
    this.componentType = null;
    this.componentQName = null;
  }
  
  public ArraySerializerFactory(QName componentType) {
    super(ArraySerializer.class, Constants.SOAP_ARRAY, (array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object);
    this.componentType = null;
    this.componentQName = null;
    this.componentType = componentType;
  }
  
  public ArraySerializerFactory(QName componentType, QName componentQName) {
    this(componentType);
    this.componentQName = componentQName;
  }
  
  public void setComponentQName(QName componentQName) { this.componentQName = componentQName; }
  
  public void setComponentType(QName componentType) { this.componentType = componentType; }
  
  public QName getComponentQName() { return this.componentQName; }
  
  public QName getComponentType() { return this.componentType; }
  
  protected Serializer getGeneralPurpose(String mechanismType) {
    if (this.componentType == null)
      return super.getGeneralPurpose(mechanismType); 
    return new ArraySerializer(this.javaType, this.xmlType, this.componentType, this.componentQName);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\ArraySerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */