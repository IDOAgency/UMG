/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.Serializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ArraySerializerFactory
/*    */   extends BaseSerializerFactory
/*    */ {
/*    */   private QName componentType;
/*    */   private QName componentQName;
/*    */   static Class array$Ljava$lang$Object;
/*    */   
/* 32 */   public ArraySerializerFactory() { this((array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object, Constants.SOAP_ARRAY); }
/*    */   
/*    */   public ArraySerializerFactory(Class javaType, QName xmlType) {
/* 35 */     super(ArraySerializer.class, xmlType, javaType);
/*    */ 
/*    */     
/* 38 */     this.componentType = null;
/* 39 */     this.componentQName = null;
/*    */   }
/*    */   public ArraySerializerFactory(QName componentType) {
/* 42 */     super(ArraySerializer.class, Constants.SOAP_ARRAY, (array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object); this.componentType = null; this.componentQName = null;
/* 43 */     this.componentType = componentType;
/*    */   }
/*    */   
/*    */   public ArraySerializerFactory(QName componentType, QName componentQName) {
/* 47 */     this(componentType);
/* 48 */     this.componentQName = componentQName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public void setComponentQName(QName componentQName) { this.componentQName = componentQName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public void setComponentType(QName componentType) { this.componentType = componentType; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   public QName getComponentQName() { return this.componentQName; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 75 */   public QName getComponentType() { return this.componentType; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Serializer getGeneralPurpose(String mechanismType) {
/* 85 */     if (this.componentType == null) {
/* 86 */       return super.getGeneralPurpose(mechanismType);
/*    */     }
/* 88 */     return new ArraySerializer(this.javaType, this.xmlType, this.componentType, this.componentQName);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\ArraySerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */