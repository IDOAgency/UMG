/*     */ package org.apache.axis.encoding.ser;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.Serializer;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.SerializerFactory;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseSerializerFactory
/*     */   extends BaseFactory
/*     */   implements SerializerFactory
/*     */ {
/*  42 */   protected static Log log = LogFactory.getLog(BaseSerializerFactory.class.getName());
/*     */ 
/*     */   
/*  45 */   static Vector mechanisms = null;
/*     */   
/*  47 */   protected Class serClass = null;
/*  48 */   protected QName xmlType = null;
/*  49 */   protected Class javaType = null;
/*     */   
/*  51 */   protected Serializer ser = null;
/*  52 */   protected Constructor serClassConstructor = null;
/*  53 */   protected Method getSerializer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSerializerFactory(Class serClass) {
/*  61 */     if (!Serializer.class.isAssignableFrom(serClass)) {
/*  62 */       throw new ClassCastException(Messages.getMessage("BadImplementation00", serClass.getName(), Serializer.class.getName()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.serClass = serClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public BaseSerializerFactory(Class serClass, QName xmlType, Class javaType) {
/*  72 */     this(serClass);
/*  73 */     this.xmlType = xmlType;
/*  74 */     this.javaType = javaType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Serializer getSerializerAs(String mechanismType) throws JAXRPCException {
/*  80 */     synchronized (this) {
/*  81 */       if (this.ser == null) {
/*  82 */         this.ser = getSerializerAsInternal(mechanismType);
/*     */       }
/*  84 */       return this.ser;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Serializer getSerializerAsInternal(String mechanismType) throws JAXRPCException {
/*  91 */     Serializer serializer = getSpecialized(mechanismType);
/*     */ 
/*     */ 
/*     */     
/*  95 */     if (serializer == null) {
/*  96 */       serializer = getGeneralPurpose(mechanismType);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 101 */       if (serializer == null) {
/* 102 */         serializer = (Serializer)this.serClass.newInstance();
/*     */       }
/* 104 */     } catch (Exception e) {
/* 105 */       throw new JAXRPCException(Messages.getMessage("CantGetSerializer", this.serClass.getName()), e);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 110 */     return serializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Serializer getGeneralPurpose(String mechanismType) throws JAXRPCException {
/* 118 */     if (this.javaType != null && this.xmlType != null) {
/* 119 */       Constructor serClassConstructor = getSerClassConstructor();
/* 120 */       if (serClassConstructor != null) {
/*     */         try {
/* 122 */           return (Serializer)serClassConstructor.newInstance(new Object[] { this.javaType, this.xmlType });
/*     */         
/*     */         }
/* 125 */         catch (InstantiationException e) {
/* 126 */           if (log.isDebugEnabled()) {
/* 127 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/* 129 */         } catch (IllegalAccessException e) {
/* 130 */           if (log.isDebugEnabled()) {
/* 131 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/* 133 */         } catch (InvocationTargetException e) {
/* 134 */           if (log.isDebugEnabled()) {
/* 135 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 144 */   private static final Class[] CLASS_QNAME_CLASS = { Class.class, QName.class };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Constructor getConstructor(Class clazz) {
/*     */     try {
/* 151 */       return clazz.getConstructor(CLASS_QNAME_CLASS);
/* 152 */     } catch (NoSuchMethodException e) {
/* 153 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Serializer getSpecialized(String mechanismType) throws JAXRPCException {
/* 161 */     if (this.javaType != null && this.xmlType != null) {
/* 162 */       Method getSerializer = getGetSerializer();
/* 163 */       if (getSerializer != null) {
/*     */         try {
/* 165 */           return (Serializer)getSerializer.invoke(null, new Object[] { mechanismType, this.javaType, this.xmlType });
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 171 */         catch (IllegalAccessException e) {
/* 172 */           if (log.isDebugEnabled()) {
/* 173 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/* 175 */         } catch (InvocationTargetException e) {
/* 176 */           if (log.isDebugEnabled()) {
/* 177 */             log.debug(Messages.getMessage("exception00"), e);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getSupportedMechanismTypes() {
/* 193 */     if (mechanisms == null) {
/* 194 */       mechanisms = new Vector(1);
/* 195 */       mechanisms.add("Axis SAX Mechanism");
/*     */     } 
/* 197 */     return mechanisms.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public QName getXMLType() { return this.xmlType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 213 */   public Class getJavaType() { return this.javaType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SerializerFactory createFactory(Class factory, Class javaType, QName xmlType) {
/* 229 */     if (factory == null) {
/* 230 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 234 */       if (factory == BeanSerializerFactory.class)
/* 235 */         return new BeanSerializerFactory(javaType, xmlType); 
/* 236 */       if (factory == SimpleSerializerFactory.class)
/* 237 */         return new SimpleSerializerFactory(javaType, xmlType); 
/* 238 */       if (factory == EnumSerializerFactory.class)
/* 239 */         return new EnumSerializerFactory(javaType, xmlType); 
/* 240 */       if (factory == ElementSerializerFactory.class)
/* 241 */         return new ElementSerializerFactory(); 
/* 242 */       if (factory == SimpleListSerializerFactory.class) {
/* 243 */         return new SimpleListSerializerFactory(javaType, xmlType);
/*     */       }
/* 245 */     } catch (Exception e) {
/* 246 */       if (log.isDebugEnabled()) {
/* 247 */         log.debug(Messages.getMessage("exception00"), e);
/*     */       }
/* 249 */       return null;
/*     */     } 
/*     */     
/* 252 */     SerializerFactory sf = null;
/*     */     try {
/* 254 */       Method method = factory.getMethod("create", CLASS_QNAME_CLASS);
/*     */       
/* 256 */       sf = (SerializerFactory)method.invoke(null, new Object[] { javaType, xmlType });
/*     */     
/*     */     }
/* 259 */     catch (NoSuchMethodException e) {
/* 260 */       if (log.isDebugEnabled()) {
/* 261 */         log.debug(Messages.getMessage("exception00"), e);
/*     */       }
/* 263 */     } catch (IllegalAccessException e) {
/* 264 */       if (log.isDebugEnabled()) {
/* 265 */         log.debug(Messages.getMessage("exception00"), e);
/*     */       }
/* 267 */     } catch (InvocationTargetException e) {
/* 268 */       if (log.isDebugEnabled()) {
/* 269 */         log.debug(Messages.getMessage("exception00"), e);
/*     */       }
/*     */     } 
/*     */     
/* 273 */     if (sf == null) {
/*     */       try {
/* 275 */         Constructor constructor = factory.getConstructor(CLASS_QNAME_CLASS);
/*     */         
/* 277 */         sf = (SerializerFactory)constructor.newInstance(new Object[] { javaType, xmlType });
/*     */       
/*     */       }
/* 280 */       catch (NoSuchMethodException e) {
/* 281 */         if (log.isDebugEnabled()) {
/* 282 */           log.debug(Messages.getMessage("exception00"), e);
/*     */         }
/* 284 */       } catch (InstantiationException e) {
/* 285 */         if (log.isDebugEnabled()) {
/* 286 */           log.debug(Messages.getMessage("exception00"), e);
/*     */         }
/* 288 */       } catch (IllegalAccessException e) {
/* 289 */         if (log.isDebugEnabled()) {
/* 290 */           log.debug(Messages.getMessage("exception00"), e);
/*     */         }
/* 292 */       } catch (InvocationTargetException e) {
/* 293 */         if (log.isDebugEnabled()) {
/* 294 */           log.debug(Messages.getMessage("exception00"), e);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 299 */     if (sf == null) {
/*     */       
/* 301 */       try { sf = (SerializerFactory)factory.newInstance(); }
/* 302 */       catch (InstantiationException e) {  }
/* 303 */       catch (IllegalAccessException e) {}
/*     */     }
/* 305 */     return sf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Method getGetSerializer() {
/* 313 */     if (this.getSerializer == null) {
/* 314 */       this.getSerializer = getMethod(this.javaType, "getSerializer");
/*     */     }
/* 316 */     return this.getSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Constructor getSerClassConstructor() {
/* 324 */     if (this.serClassConstructor == null) {
/* 325 */       this.serClassConstructor = getConstructor(this.serClass);
/*     */     }
/* 327 */     return this.serClassConstructor;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\BaseSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */