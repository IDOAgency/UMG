package org.apache.axis.encoding.ser;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.Serializer;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.Serializer;
import org.apache.axis.encoding.SerializerFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public abstract class BaseSerializerFactory extends BaseFactory implements SerializerFactory {
  protected static Log log = LogFactory.getLog(BaseSerializerFactory.class.getName());
  
  static Vector mechanisms = null;
  
  protected Class serClass = null;
  
  protected QName xmlType = null;
  
  protected Class javaType = null;
  
  protected Serializer ser = null;
  
  protected Constructor serClassConstructor = null;
  
  protected Method getSerializer = null;
  
  public BaseSerializerFactory(Class serClass) {
    if (!Serializer.class.isAssignableFrom(serClass))
      throw new ClassCastException(Messages.getMessage("BadImplementation00", serClass.getName(), Serializer.class.getName())); 
    this.serClass = serClass;
  }
  
  public BaseSerializerFactory(Class serClass, QName xmlType, Class javaType) {
    this(serClass);
    this.xmlType = xmlType;
    this.javaType = javaType;
  }
  
  public Serializer getSerializerAs(String mechanismType) throws JAXRPCException {
    synchronized (this) {
      if (this.ser == null)
        this.ser = getSerializerAsInternal(mechanismType); 
      return this.ser;
    } 
  }
  
  protected Serializer getSerializerAsInternal(String mechanismType) throws JAXRPCException {
    Serializer serializer = getSpecialized(mechanismType);
    if (serializer == null)
      serializer = getGeneralPurpose(mechanismType); 
    try {
      if (serializer == null)
        serializer = (Serializer)this.serClass.newInstance(); 
    } catch (Exception e) {
      throw new JAXRPCException(Messages.getMessage("CantGetSerializer", this.serClass.getName()), e);
    } 
    return serializer;
  }
  
  protected Serializer getGeneralPurpose(String mechanismType) throws JAXRPCException {
    if (this.javaType != null && this.xmlType != null) {
      Constructor serClassConstructor = getSerClassConstructor();
      if (serClassConstructor != null)
        try {
          return (Serializer)serClassConstructor.newInstance(new Object[] { this.javaType, this.xmlType });
        } catch (InstantiationException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        } catch (IllegalAccessException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        } catch (InvocationTargetException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        }  
    } 
    return null;
  }
  
  private static final Class[] CLASS_QNAME_CLASS = { Class.class, QName.class };
  
  private Constructor getConstructor(Class clazz) {
    try {
      return clazz.getConstructor(CLASS_QNAME_CLASS);
    } catch (NoSuchMethodException e) {
      return null;
    } 
  }
  
  protected Serializer getSpecialized(String mechanismType) throws JAXRPCException {
    if (this.javaType != null && this.xmlType != null) {
      Method getSerializer = getGetSerializer();
      if (getSerializer != null)
        try {
          return (Serializer)getSerializer.invoke(null, new Object[] { mechanismType, this.javaType, this.xmlType });
        } catch (IllegalAccessException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        } catch (InvocationTargetException e) {
          if (log.isDebugEnabled())
            log.debug(Messages.getMessage("exception00"), e); 
        }  
    } 
    return null;
  }
  
  public Iterator getSupportedMechanismTypes() {
    if (mechanisms == null) {
      mechanisms = new Vector(1);
      mechanisms.add("Axis SAX Mechanism");
    } 
    return mechanisms.iterator();
  }
  
  public QName getXMLType() { return this.xmlType; }
  
  public Class getJavaType() { return this.javaType; }
  
  public static SerializerFactory createFactory(Class factory, Class javaType, QName xmlType) {
    if (factory == null)
      return null; 
    try {
      if (factory == BeanSerializerFactory.class)
        return new BeanSerializerFactory(javaType, xmlType); 
      if (factory == SimpleSerializerFactory.class)
        return new SimpleSerializerFactory(javaType, xmlType); 
      if (factory == EnumSerializerFactory.class)
        return new EnumSerializerFactory(javaType, xmlType); 
      if (factory == ElementSerializerFactory.class)
        return new ElementSerializerFactory(); 
      if (factory == SimpleListSerializerFactory.class)
        return new SimpleListSerializerFactory(javaType, xmlType); 
    } catch (Exception e) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("exception00"), e); 
      return null;
    } 
    SerializerFactory sf = null;
    try {
      Method method = factory.getMethod("create", CLASS_QNAME_CLASS);
      sf = (SerializerFactory)method.invoke(null, new Object[] { javaType, xmlType });
    } catch (NoSuchMethodException e) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("exception00"), e); 
    } catch (IllegalAccessException e) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("exception00"), e); 
    } catch (InvocationTargetException e) {
      if (log.isDebugEnabled())
        log.debug(Messages.getMessage("exception00"), e); 
    } 
    if (sf == null)
      try {
        Constructor constructor = factory.getConstructor(CLASS_QNAME_CLASS);
        sf = (SerializerFactory)constructor.newInstance(new Object[] { javaType, xmlType });
      } catch (NoSuchMethodException e) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("exception00"), e); 
      } catch (InstantiationException e) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("exception00"), e); 
      } catch (IllegalAccessException e) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("exception00"), e); 
      } catch (InvocationTargetException e) {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("exception00"), e); 
      }  
    if (sf == null)
      try {
        sf = (SerializerFactory)factory.newInstance();
      } catch (InstantiationException e) {
      
      } catch (IllegalAccessException e) {} 
    return sf;
  }
  
  protected Method getGetSerializer() {
    if (this.getSerializer == null)
      this.getSerializer = getMethod(this.javaType, "getSerializer"); 
    return this.getSerializer;
  }
  
  protected Constructor getSerClassConstructor() {
    if (this.serClassConstructor == null)
      this.serClassConstructor = getConstructor(this.serClass); 
    return this.serClassConstructor;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\BaseSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */