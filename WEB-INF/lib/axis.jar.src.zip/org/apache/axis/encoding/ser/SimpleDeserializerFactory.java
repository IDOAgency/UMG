package org.apache.axis.encoding.ser;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.Constructor;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.Deserializer;
import org.apache.axis.utils.BeanPropertyDescriptor;
import org.apache.axis.utils.BeanUtils;
import org.apache.axis.utils.JavaUtils;

public class SimpleDeserializerFactory extends BaseDeserializerFactory {
  private static final Class[] STRING_STRING_CLASS = { String.class, String.class };
  
  private static final Class[] STRING_CLASS = { String.class };
  
  private Constructor constructor = null;
  
  private boolean isBasicType = false;
  
  public SimpleDeserializerFactory(Class javaType, QName xmlType) {
    super(SimpleDeserializer.class, xmlType, javaType);
    this.isBasicType = JavaUtils.isBasic(javaType);
    initConstructor(javaType);
  }
  
  private void initConstructor(Class javaType) {
    if (!this.isBasicType)
      try {
        if (QName.class.isAssignableFrom(javaType)) {
          this.constructor = javaType.getDeclaredConstructor(STRING_STRING_CLASS);
        } else {
          this.constructor = javaType.getDeclaredConstructor(STRING_CLASS);
        } 
      } catch (NoSuchMethodException e) {
        try {
          this.constructor = javaType.getDeclaredConstructor(new Class[0]);
          BeanPropertyDescriptor[] pds = BeanUtils.getPd(javaType);
          if (pds != null && 
            BeanUtils.getSpecificPD(pds, "_value") != null)
            return; 
          throw new IllegalArgumentException(e.toString());
        } catch (NoSuchMethodException ex) {
          throw new IllegalArgumentException(ex.toString());
        } 
      }  
  }
  
  public Deserializer getDeserializerAs(String mechanismType) throws JAXRPCException {
    if (this.javaType == Object.class)
      return null; 
    if (this.isBasicType)
      return new SimpleDeserializer(this.javaType, this.xmlType); 
    SimpleDeserializer deser = (SimpleDeserializer)super.getDeserializerAs(mechanismType);
    if (deser != null)
      deser.setConstructor(this.constructor); 
    return deser;
  }
  
  private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
    in.defaultReadObject();
    initConstructor(this.javaType);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\SimpleDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */