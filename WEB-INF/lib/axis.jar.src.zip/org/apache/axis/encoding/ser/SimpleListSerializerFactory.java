package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;

public class SimpleListSerializerFactory extends BaseSerializerFactory {
  public SimpleListSerializerFactory(Class javaType, QName xmlType) { super(SimpleListSerializer.class, xmlType, javaType); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\SimpleListSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */