/*    */ package org.apache.axis.encoding.ser.castor;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.encoding.SerializerFactory;
/*    */ import org.apache.axis.encoding.ser.BaseSerializerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CastorEnumTypeSerializerFactory
/*    */   extends BaseSerializerFactory
/*    */ {
/* 31 */   public CastorEnumTypeSerializerFactory(Class javaType, QName xmlType) { super(CastorEnumTypeSerializer.class, xmlType, javaType); }
/*    */ 
/*    */   
/* 34 */   public static SerializerFactory create(Class javaType, QName xmlType) { return new CastorEnumTypeSerializerFactory(javaType, xmlType); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\castor\CastorEnumTypeSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */