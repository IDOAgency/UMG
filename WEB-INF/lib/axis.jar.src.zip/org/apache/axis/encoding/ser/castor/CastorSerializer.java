package org.apache.axis.encoding.ser.castor;

import java.io.IOException;
import javax.xml.namespace.QName;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.encoding.Serializer;
import org.apache.axis.utils.Messages;
import org.apache.axis.wsdl.fromJava.Types;
import org.apache.commons.logging.Log;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.ValidationException;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;

public class CastorSerializer implements Serializer {
  protected static Log log = LogFactory.getLog(CastorSerializer.class.getName());
  
  public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException {
    try {
      AxisContentHandler hand = new AxisContentHandler(context);
      Marshaller marshaller = new Marshaller(hand);
      marshaller.setMarshalAsDocument(false);
      String localPart = name.getLocalPart();
      int arrayDims = localPart.indexOf('[');
      if (arrayDims != -1)
        localPart = localPart.substring(0, arrayDims); 
      marshaller.setRootElement(localPart);
      marshaller.marshal(value);
    } catch (MarshalException me) {
      log.error(Messages.getMessage("castorMarshalException00"), me);
      throw new IOException(Messages.getMessage("castorMarshalException00") + me.getLocalizedMessage());
    } catch (ValidationException ve) {
      log.error(Messages.getMessage("castorValidationException00"), ve);
      throw new IOException(Messages.getMessage("castorValidationException00") + ve.getLocation() + ": " + ve.getLocalizedMessage());
    } 
  }
  
  public String getMechanismType() { return "Axis SAX Mechanism"; }
  
  public Element writeSchema(Class javaType, Types types) throws Exception { return null; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\castor\CastorSerializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */