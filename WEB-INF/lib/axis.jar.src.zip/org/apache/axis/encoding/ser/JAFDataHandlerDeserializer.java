package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;
import org.apache.axis.AxisFault;
import org.apache.axis.Part;
import org.apache.axis.attachments.AttachmentUtils;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.message.SOAPHandler;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class JAFDataHandlerDeserializer extends DeserializerImpl {
  protected static Log log = LogFactory.getLog(JAFDataHandlerDeserializer.class.getName());
  
  public void startElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (!context.isDoneParsing() && 
      this.myElement == null) {
      try {
        this.myElement = makeNewElement(namespace, localName, prefix, attributes, context);
      } catch (AxisFault axisFault) {
        throw new SAXException(axisFault);
      } 
      context.pushNewElement(this.myElement);
    } 
    populateDataHandler(context, namespace, localName, attributes);
  }
  
  private void populateDataHandler(DeserializationContext context, String namespace, String localName, Attributes attributes) {
    SOAPConstants soapConstants = context.getSOAPConstants();
    QName type = context.getTypeFromAttributes(namespace, localName, attributes);
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("gotType00", "Deser", "" + type)); 
    String href = attributes.getValue(soapConstants.getAttrHref());
    if (href != null) {
      Object ref = context.getObjectByRef(href);
      try {
        ref = AttachmentUtils.getActivationDataHandler((Part)ref);
      } catch (AxisFault e) {}
      setValue(ref);
    } 
  }
  
  public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (namespace.equals("http://www.w3.org/2004/08/xop/include") && localName.equals("Include")) {
      populateDataHandler(context, namespace, localName, attributes);
      return null;
    } 
    throw new SAXException(Messages.getMessage("noSubElements", namespace + ":" + localName));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\JAFDataHandlerDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */