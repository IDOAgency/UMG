package org.apache.axis.encoding.ser;

import java.io.IOException;
import java.io.ObjectInputStream;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.Serializer;
import org.apache.axis.description.TypeDesc;
import org.apache.axis.encoding.Serializer;
import org.apache.axis.utils.BeanPropertyDescriptor;
import org.apache.axis.utils.BeanUtils;
import org.apache.axis.utils.JavaUtils;

public class BeanSerializerFactory extends BaseSerializerFactory {
  protected TypeDesc typeDesc = null;
  
  protected BeanPropertyDescriptor[] propertyDescriptor = null;
  
  public BeanSerializerFactory(Class javaType, QName xmlType) {
    super(BeanSerializer.class, xmlType, javaType);
    init(javaType);
  }
  
  private void init(Class javaType) {
    if (JavaUtils.isEnumClass(javaType))
      this.serClass = EnumSerializer.class; 
    this.typeDesc = TypeDesc.getTypeDescForClass(javaType);
    if (this.typeDesc != null) {
      this.propertyDescriptor = this.typeDesc.getPropertyDescriptors();
    } else {
      this.propertyDescriptor = BeanUtils.getPd(javaType, null);
    } 
  }
  
  public Serializer getSerializerAs(String mechanismType) throws JAXRPCException { return (Serializer)super.getSerializerAs(mechanismType); }
  
  protected Serializer getGeneralPurpose(String mechanismType) {
    if (this.javaType == null || this.xmlType == null)
      return super.getGeneralPurpose(mechanismType); 
    if (this.serClass == EnumSerializer.class)
      return super.getGeneralPurpose(mechanismType); 
    return new BeanSerializer(this.javaType, this.xmlType, this.typeDesc, this.propertyDescriptor);
  }
  
  private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
    in.defaultReadObject();
    init(this.javaType);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\BeanSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */