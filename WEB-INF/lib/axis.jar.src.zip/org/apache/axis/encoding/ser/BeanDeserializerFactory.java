package org.apache.axis.encoding.ser;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map;
import javax.xml.namespace.QName;
import org.apache.axis.description.TypeDesc;
import org.apache.axis.encoding.Deserializer;
import org.apache.axis.utils.BeanPropertyDescriptor;
import org.apache.axis.utils.BeanUtils;
import org.apache.axis.utils.JavaUtils;

public class BeanDeserializerFactory extends BaseDeserializerFactory {
  protected TypeDesc typeDesc = null;
  
  protected Map propertyMap = null;
  
  public BeanDeserializerFactory(Class javaType, QName xmlType) {
    super(BeanDeserializer.class, xmlType, javaType);
    if (JavaUtils.isEnumClass(javaType))
      this.deserClass = EnumDeserializer.class; 
    this.typeDesc = TypeDesc.getTypeDescForClass(javaType);
    this.propertyMap = getProperties(javaType, this.typeDesc);
  }
  
  public static Map getProperties(Class javaType, TypeDesc typeDesc) {
    Map propertyMap = null;
    if (typeDesc != null) {
      propertyMap = typeDesc.getPropertyDescriptorMap();
    } else {
      BeanPropertyDescriptor[] pd = BeanUtils.getPd(javaType, null);
      propertyMap = new HashMap();
      for (int i = 0; i < pd.length; i++) {
        BeanPropertyDescriptor descriptor = pd[i];
        propertyMap.put(descriptor.getName(), descriptor);
      } 
    } 
    return propertyMap;
  }
  
  protected Deserializer getGeneralPurpose(String mechanismType) {
    if (this.javaType == null || this.xmlType == null)
      return super.getGeneralPurpose(mechanismType); 
    if (this.deserClass == EnumDeserializer.class)
      return super.getGeneralPurpose(mechanismType); 
    return new BeanDeserializer(this.javaType, this.xmlType, this.typeDesc, this.propertyMap);
  }
  
  private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
    in.defaultReadObject();
    this.typeDesc = TypeDesc.getTypeDescForClass(this.javaType);
    this.propertyMap = getProperties(this.javaType, this.typeDesc);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\BeanDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */