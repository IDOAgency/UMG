/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.rpc.JAXRPCException;
/*    */ import javax.xml.rpc.encoding.Serializer;
/*    */ import org.apache.axis.utils.JavaUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleSerializerFactory
/*    */   extends BaseSerializerFactory
/*    */ {
/*    */   private boolean isBasicType = false;
/*    */   
/*    */   public SimpleSerializerFactory(Class javaType, QName xmlType) {
/* 36 */     super(SimpleSerializer.class, xmlType, javaType);
/* 37 */     this.isBasicType = JavaUtils.isBasic(javaType);
/*    */   }
/*    */   
/*    */   public Serializer getSerializerAs(String mechanismType) throws JAXRPCException {
/* 41 */     if (this.isBasicType) {
/* 42 */       return new SimpleSerializer(this.javaType, this.xmlType);
/*    */     }
/* 44 */     return super.getSerializerAs(mechanismType);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\SimpleSerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */