package org.apache.axis.encoding.ser;

import java.io.IOException;
import java.lang.reflect.Array;
import javax.xml.namespace.QName;
import org.apache.axis.AxisFault;
import org.apache.axis.description.FieldDesc;
import org.apache.axis.description.TypeDesc;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.encoding.SimpleValueSerializer;
import org.apache.axis.utils.BeanPropertyDescriptor;
import org.apache.axis.utils.Messages;
import org.apache.axis.wsdl.fromJava.Types;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.AttributesImpl;

public class SimpleListSerializer implements SimpleValueSerializer {
  public QName xmlType;
  
  public Class javaType;
  
  private BeanPropertyDescriptor[] propertyDescriptor;
  
  private TypeDesc typeDesc;
  
  public SimpleListSerializer(Class javaType, QName xmlType) {
    this.propertyDescriptor = null;
    this.typeDesc = null;
    this.xmlType = xmlType;
    this.javaType = javaType;
  }
  
  public SimpleListSerializer(Class javaType, QName xmlType, TypeDesc typeDesc) {
    this.propertyDescriptor = null;
    this.typeDesc = null;
    this.xmlType = xmlType;
    this.javaType = javaType;
    this.typeDesc = typeDesc;
  }
  
  public void serialize(QName name, Attributes attributes, Object value, SerializationContext context) throws IOException {
    if (value != null && value.getClass() == Object.class)
      throw new IOException(Messages.getMessage("cantSerialize02")); 
    if (value instanceof org.apache.axis.encoding.SimpleType)
      attributes = getObjectAttributes(value, attributes, context); 
    String strValue = null;
    if (value != null)
      strValue = getValueAsString(value, context); 
    context.startElement(name, attributes);
    if (strValue != null)
      context.writeSafeString(strValue); 
    context.endElement();
  }
  
  public String getValueAsString(Object value, SerializationContext context) {
    int length = Array.getLength(value);
    StringBuffer result = new StringBuffer();
    for (int i = 0; i < length; i++) {
      Object object = Array.get(value, i);
      if (object instanceof Float || object instanceof Double) {
        double data = 0.0D;
        if (object instanceof Float) {
          data = ((Float)object).doubleValue();
        } else {
          data = ((Double)object).doubleValue();
        } 
        if (Double.isNaN(data)) {
          result.append("NaN");
        } else if (data == Double.POSITIVE_INFINITY) {
          result.append("INF");
        } else if (data == Double.NEGATIVE_INFINITY) {
          result.append("-INF");
        } else {
          result.append(object.toString());
        } 
      } else if (object instanceof QName) {
        result.append(QNameSerializer.qName2String((QName)object, context));
      } else {
        result.append(object.toString());
      } 
      if (i < length - 1)
        result.append(' '); 
    } 
    return result.toString();
  }
  
  private Attributes getObjectAttributes(Object value, Attributes attributes, SerializationContext context) {
    AttributesImpl attrs;
    if (this.typeDesc == null || !this.typeDesc.hasAttributes())
      return attributes; 
    if (attributes == null) {
      attrs = new AttributesImpl();
    } else if (attributes instanceof AttributesImpl) {
      attrs = (AttributesImpl)attributes;
    } else {
      attrs = new AttributesImpl(attributes);
    } 
    try {
      for (int i = 0; i < this.propertyDescriptor.length; i++) {
        String propName = this.propertyDescriptor[i].getName();
        if (!propName.equals("class")) {
          FieldDesc field = this.typeDesc.getFieldByName(propName);
          if (field != null && !field.isElement()) {
            QName qname = field.getXmlName();
            if (qname == null)
              qname = new QName("", propName); 
            if (this.propertyDescriptor[i].isReadable() && !this.propertyDescriptor[i].isIndexed()) {
              Object propValue = this.propertyDescriptor[i].get(value);
              if (propValue != null) {
                String propString = getValueAsString(propValue, context);
                String namespace = qname.getNamespaceURI();
                String localName = qname.getLocalPart();
                attrs.addAttribute(namespace, localName, context.qName2String(qname), "CDATA", propString);
              } 
            } 
          } 
        } 
      } 
    } catch (Exception e) {
      return attrs;
    } 
    return attrs;
  }
  
  public String getMechanismType() { return "Axis SAX Mechanism"; }
  
  public Element writeSchema(Class javaType, Types types) throws Exception {
    if (!org.apache.axis.encoding.SimpleType.class.isAssignableFrom(javaType))
      return null; 
    Element complexType = types.createElement("complexType");
    types.writeSchemaElementDecl(this.xmlType, complexType);
    complexType.setAttribute("name", this.xmlType.getLocalPart());
    Element simpleContent = types.createElement("simpleContent");
    complexType.appendChild(simpleContent);
    Element extension = types.createElement("extension");
    simpleContent.appendChild(extension);
    String base = "string";
    for (int i = 0; i < this.propertyDescriptor.length; i++) {
      String propName = this.propertyDescriptor[i].getName();
      if (!propName.equals("value")) {
        if (this.typeDesc != null) {
          FieldDesc field = this.typeDesc.getFieldByName(propName);
          if (field != null) {
            if (field.isElement());
            QName qname = field.getXmlName();
            if (qname == null)
              qname = new QName("", propName); 
            Class fieldType = this.propertyDescriptor[i].getType();
            if (!types.isAcceptableAsAttribute(fieldType))
              throw new AxisFault(Messages.getMessage("AttrNotSimpleType00", propName, fieldType.getName())); 
            Element elem = types.createAttributeElement(propName, fieldType, field.getXmlType(), false, extension.getOwnerDocument());
            extension.appendChild(elem);
          } 
        } 
      } else {
        BeanPropertyDescriptor bpd = this.propertyDescriptor[i];
        Class type = bpd.getType();
        if (!types.isAcceptableAsAttribute(type))
          throw new AxisFault(Messages.getMessage("AttrNotSimpleType01", type.getName())); 
        base = types.writeType(type);
        extension.setAttribute("base", base);
      } 
    } 
    return complexType;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\SimpleListSerializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */