package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class JAFDataHandlerDeserializerFactory extends BaseDeserializerFactory {
  protected static Log log = LogFactory.getLog(JAFDataHandlerDeserializerFactory.class.getName());
  
  public JAFDataHandlerDeserializerFactory(Class javaType, QName xmlType) {
    super(getDeserializerClass(javaType, xmlType), xmlType, javaType);
    log.debug("Enter/Exit: JAFDataHandlerDeserializerFactory(" + javaType + ", " + xmlType + ")");
  }
  
  public JAFDataHandlerDeserializerFactory() {
    super(JAFDataHandlerDeserializer.class);
    log.debug("Enter/Exit: JAFDataHandlerDeserializerFactory()");
  }
  
  private static Class getDeserializerClass(Class javaType, QName xmlType) {
    Class deser;
    if (java.awt.Image.class.isAssignableFrom(javaType)) {
      deser = ImageDataHandlerDeserializer.class;
    } else if (String.class.isAssignableFrom(javaType)) {
      deser = PlainTextDataHandlerDeserializer.class;
    } else if (javax.xml.transform.Source.class.isAssignableFrom(javaType)) {
      deser = SourceDataHandlerDeserializer.class;
    } else if (javax.mail.internet.MimeMultipart.class.isAssignableFrom(javaType)) {
      deser = MimeMultipartDataHandlerDeserializer.class;
    } else if (org.apache.axis.attachments.OctetStream.class.isAssignableFrom(javaType)) {
      deser = OctetStreamDataHandlerDeserializer.class;
    } else {
      deser = JAFDataHandlerDeserializer.class;
    } 
    return deser;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\JAFDataHandlerDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */