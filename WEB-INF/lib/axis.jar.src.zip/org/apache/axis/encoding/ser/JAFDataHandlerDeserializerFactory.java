/*    */ package org.apache.axis.encoding.ser;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JAFDataHandlerDeserializerFactory
/*    */   extends BaseDeserializerFactory
/*    */ {
/* 34 */   protected static Log log = LogFactory.getLog(JAFDataHandlerDeserializerFactory.class.getName());
/*    */ 
/*    */   
/*    */   public JAFDataHandlerDeserializerFactory(Class javaType, QName xmlType) {
/* 38 */     super(getDeserializerClass(javaType, xmlType), xmlType, javaType);
/* 39 */     log.debug("Enter/Exit: JAFDataHandlerDeserializerFactory(" + javaType + ", " + xmlType + ")");
/*    */   }
/*    */   
/*    */   public JAFDataHandlerDeserializerFactory() {
/* 43 */     super(JAFDataHandlerDeserializer.class);
/* 44 */     log.debug("Enter/Exit: JAFDataHandlerDeserializerFactory()");
/*    */   }
/*    */   
/*    */   private static Class getDeserializerClass(Class javaType, QName xmlType) {
/*    */     Class deser;
/* 49 */     if (java.awt.Image.class.isAssignableFrom(javaType)) {
/* 50 */       deser = ImageDataHandlerDeserializer.class;
/*    */     }
/* 52 */     else if (String.class.isAssignableFrom(javaType)) {
/* 53 */       deser = PlainTextDataHandlerDeserializer.class;
/*    */     }
/* 55 */     else if (javax.xml.transform.Source.class.isAssignableFrom(javaType)) {
/* 56 */       deser = SourceDataHandlerDeserializer.class;
/*    */     }
/* 58 */     else if (javax.mail.internet.MimeMultipart.class.isAssignableFrom(javaType)) {
/* 59 */       deser = MimeMultipartDataHandlerDeserializer.class;
/*    */     }
/* 61 */     else if (org.apache.axis.attachments.OctetStream.class.isAssignableFrom(javaType)) {
/* 62 */       deser = OctetStreamDataHandlerDeserializer.class;
/*    */     } else {
/*    */       
/* 65 */       deser = JAFDataHandlerDeserializer.class;
/*    */     } 
/* 67 */     return deser;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\JAFDataHandlerDeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */