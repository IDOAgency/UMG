package org.apache.axis.encoding.ser.castor;

import javax.xml.namespace.QName;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.Deserializer;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.message.MessageElement;
import org.apache.axis.utils.Messages;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.SAXException;

public class CastorDeserializer extends DeserializerImpl implements Deserializer {
  public QName xmlType;
  
  public Class javaType;
  
  public CastorDeserializer(Class javaType, QName xmlType) {
    this.xmlType = xmlType;
    this.javaType = javaType;
  }
  
  public void onEndElement(String namespace, String localName, DeserializationContext context) throws SAXException {
    try {
      MessageElement msgElem = context.getCurElement();
      if (msgElem != null)
        this.value = Unmarshaller.unmarshal(this.javaType, msgElem.getAsDOM()); 
    } catch (MarshalException me) {
      log.error(Messages.getMessage("castorMarshalException00"), me);
      throw new SAXException(Messages.getMessage("castorMarshalException00") + me.getLocalizedMessage());
    } catch (ValidationException ve) {
      log.error(Messages.getMessage("castorValidationException00"), ve);
      throw new SAXException(Messages.getMessage("castorValidationException00") + ve.getLocation() + ": " + ve.getLocalizedMessage());
    } catch (Exception exp) {
      log.error(Messages.getMessage("exception00"), exp);
      throw new SAXException(exp);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\castor\CastorDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */