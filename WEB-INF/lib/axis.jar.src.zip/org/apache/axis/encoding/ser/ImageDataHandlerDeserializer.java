package org.apache.axis.encoding.ser;

import java.awt.Image;
import java.io.InputStream;
import javax.activation.DataHandler;
import org.apache.axis.components.image.ImageIOFactory;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class ImageDataHandlerDeserializer extends JAFDataHandlerDeserializer {
  protected static Log log = LogFactory.getLog(ImageDataHandlerDeserializer.class.getName());
  
  public void startElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    super.startElement(namespace, localName, prefix, attributes, context);
    if (getValue() instanceof DataHandler)
      try {
        DataHandler dh = (DataHandler)getValue();
        InputStream is = dh.getInputStream();
        Image image = ImageIOFactory.getImageIO().loadImage(is);
        setValue(image);
      } catch (Exception e) {} 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\ImageDataHandlerDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */