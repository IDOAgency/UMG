package org.apache.axis.encoding.ser;

import java.util.Vector;
import javax.xml.namespace.QName;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.encoding.DeserializerTarget;
import org.apache.axis.message.SOAPHandler;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class VectorDeserializer extends DeserializerImpl {
  protected static Log log = LogFactory.getLog(VectorDeserializer.class.getName());
  
  public int curIndex = 0;
  
  public void onStartElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (log.isDebugEnabled())
      log.debug("Enter: VectorDeserializer::startElement()"); 
    if (context.isNil(attributes))
      return; 
    setValue(new Vector());
    if (log.isDebugEnabled())
      log.debug("Exit: VectorDeserializer::startElement()"); 
  }
  
  public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (log.isDebugEnabled())
      log.debug("Enter: VectorDeserializer::onStartChild()"); 
    if (attributes == null)
      throw new SAXException(Messages.getMessage("noType01")); 
    if (context.isNil(attributes)) {
      setChildValue(null, new Integer(this.curIndex++));
      return null;
    } 
    QName itemType = context.getTypeFromAttributes(namespace, localName, attributes);
    DeserializerImpl deserializerImpl = null;
    if (itemType != null)
      deserializerImpl = context.getDeserializerForType(itemType); 
    if (deserializerImpl == null)
      deserializerImpl = new DeserializerImpl(); 
    deserializerImpl.registerValueTarget(new DeserializerTarget(this, new Integer(this.curIndex)));
    this.curIndex++;
    if (log.isDebugEnabled())
      log.debug("Exit: VectorDeserializer::onStartChild()"); 
    addChildDeserializer(deserializerImpl);
    return (SOAPHandler)deserializerImpl;
  }
  
  public void setChildValue(Object value, Object hint) throws SAXException {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("gotValue00", "VectorDeserializer", "" + value)); 
    int offset = ((Integer)hint).intValue();
    Vector v = (Vector)this.value;
    if (offset >= v.size())
      v.setSize(offset + 1); 
    v.setElementAt(value, offset);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\VectorDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */