package org.apache.axis.encoding.ser;

import javax.xml.namespace.QName;
import org.apache.axis.encoding.Base64;

public class Base64Deserializer extends SimpleDeserializer {
  static Class array$Ljava$lang$Byte;
  
  public Base64Deserializer(Class javaType, QName xmlType) { super(javaType, xmlType); }
  
  public Object makeValue(String source) throws Exception {
    byte[] value = Base64.decode(source);
    if (value == null) {
      if (this.javaType == ((array$Ljava$lang$Byte == null) ? (array$Ljava$lang$Byte = class$("[Ljava.lang.Byte;")) : array$Ljava$lang$Byte))
        return new Byte[0]; 
      return new byte[0];
    } 
    if (this.javaType == ((array$Ljava$lang$Byte == null) ? (array$Ljava$lang$Byte = class$("[Ljava.lang.Byte;")) : array$Ljava$lang$Byte)) {
      Byte[] data = new Byte[value.length];
      for (int i = 0; i < data.length; i++) {
        byte b = value[i];
        data[i] = new Byte(b);
      } 
      return data;
    } 
    return value;
  }
  
  static Class class$(String x0) { try {
      return Class.forName(x0);
    } catch (ClassNotFoundException x1) {
      throw new NoClassDefFoundError(x1.getMessage());
    }  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\Base64Deserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */