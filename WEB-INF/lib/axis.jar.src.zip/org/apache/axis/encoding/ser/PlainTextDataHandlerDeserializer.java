package org.apache.axis.encoding.ser;

import java.io.IOException;
import javax.activation.DataHandler;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class PlainTextDataHandlerDeserializer extends JAFDataHandlerDeserializer {
  protected static Log log = LogFactory.getLog(PlainTextDataHandlerDeserializer.class.getName());
  
  public void startElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    super.startElement(namespace, localName, prefix, attributes, context);
    if (getValue() instanceof DataHandler)
      try {
        DataHandler dh = (DataHandler)getValue();
        setValue(dh.getContent());
      } catch (IOException ioe) {} 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ser\PlainTextDataHandlerDeserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */