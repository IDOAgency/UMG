package org.apache.axis.encoding;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import org.apache.axis.i18n.Messages;
import org.xml.sax.SAXException;

public class ConstructorTarget implements Target {
  private Constructor constructor;
  
  private Deserializer deSerializer;
  
  private List values;
  
  public ConstructorTarget(Constructor constructor, Deserializer deSerializer) {
    this.constructor = null;
    this.deSerializer = null;
    this.values = null;
    this.deSerializer = deSerializer;
    this.constructor = constructor;
    this.values = new ArrayList();
  }
  
  public void set(Object value) throws SAXException {
    try {
      this.values.add(value);
      if (this.constructor.getParameterTypes().length == this.values.size()) {
        Class[] classes = this.constructor.getParameterTypes();
        Object[] args = new Object[this.constructor.getParameterTypes().length];
        for (int c = 0; c < classes.length; c++) {
          boolean found = false;
          int i = 0;
          while (!found && i < this.values.size()) {
            if (this.values.get(i).getClass().getName().toLowerCase().indexOf(classes[c].getName().toLowerCase()) != -1) {
              found = true;
              args[c] = this.values.get(i);
            } 
            i++;
          } 
          if (!found)
            throw new SAXException(Messages.getMessage("cannotFindObjectForClass00", classes[c].toString())); 
        } 
        Object o = this.constructor.newInstance(args);
        this.deSerializer.setValue(o);
      } 
    } catch (Exception e) {
      throw new SAXException(e);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\ConstructorTarget.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */