package org.apache.axis.encoding;

import org.xml.sax.SAXException;

public interface Target {
  void set(Object paramObject) throws SAXException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\Target.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */