package org.apache.axis.encoding;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.DeserializerFactory;
import javax.xml.rpc.encoding.SerializerFactory;
import org.apache.axis.AxisProperties;
import org.apache.axis.Constants;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
import org.apache.axis.encoding.ser.ArraySerializerFactory;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;
import org.apache.axis.encoding.ser.BeanSerializerFactory;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.utils.ArrayUtil;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.Messages;
import org.apache.axis.wsdl.fromJava.Namespaces;
import org.apache.axis.wsdl.fromJava.Types;
import org.apache.axis.wsdl.toJava.Utils;
import org.apache.commons.logging.Log;

public class TypeMappingImpl implements Serializable {
  protected static Log log = LogFactory.getLog(TypeMappingImpl.class.getName());
  
  public static boolean dotnet_soapenc_bugfix = false;
  
  public static class Pair implements Serializable {
    public Class javaType;
    
    public QName xmlType;
    
    public Pair(Class javaType, QName xmlType) throws JAXRPCException {
      this.javaType = javaType;
      this.xmlType = xmlType;
    }
    
    public boolean equals(Object o) {
      if (o == null)
        return false; 
      Pair p = (Pair)o;
      if (p.xmlType == this.xmlType && p.javaType == this.javaType)
        return true; 
      return (p.xmlType.equals(this.xmlType) && p.javaType.equals(this.javaType));
    }
    
    public int hashCode() {
      int hashcode = 0;
      if (this.javaType != null)
        hashcode ^= this.javaType.hashCode(); 
      if (this.xmlType != null)
        hashcode ^= this.xmlType.hashCode(); 
      return hashcode;
    }
  }
  
  protected Boolean doAutoTypes = null;
  
  private HashMap qName2Pair = new HashMap();
  
  private HashMap class2Pair = new HashMap();
  
  private HashMap pair2SF = new HashMap();
  
  private HashMap pair2DF = new HashMap();
  
  private ArrayList namespaces = new ArrayList();
  
  static Class array$Ljava$lang$Object;
  
  private static boolean isArray(Class clazz) { return (clazz.isArray() || java.util.Collection.class.isAssignableFrom(clazz)); }
  
  public String[] getSupportedEncodings() {
    String[] stringArray = new String[this.namespaces.size()];
    return (String[])this.namespaces.toArray(stringArray);
  }
  
  public void setSupportedEncodings(String[] namespaceURIs) {
    this.namespaces.clear();
    for (int i = 0; i < namespaceURIs.length; i++) {
      if (!this.namespaces.contains(namespaceURIs[i]))
        this.namespaces.add(namespaceURIs[i]); 
    } 
  }
  
  public boolean isRegistered(Class javaType, QName xmlType) {
    if (javaType == null || xmlType == null)
      throw new JAXRPCException(Messages.getMessage((javaType == null) ? "badJavaType" : "badXmlType")); 
    if (this.pair2SF.keySet().contains(new Pair(javaType, xmlType)))
      return true; 
    return false;
  }
  
  public void register(Class javaType, QName xmlType, SerializerFactory sf, DeserializerFactory dsf) throws JAXRPCException {
    if (sf == null && dsf == null)
      throw new JAXRPCException(Messages.getMessage("badSerFac")); 
    internalRegister(javaType, xmlType, sf, dsf);
  }
  
  protected void internalRegister(Class javaType, QName xmlType, SerializerFactory sf, DeserializerFactory dsf) throws JAXRPCException {
    if (javaType == null || xmlType == null)
      throw new JAXRPCException(Messages.getMessage((javaType == null) ? "badJavaType" : "badXmlType")); 
    Pair pair = new Pair(javaType, xmlType);
    this.qName2Pair.put(xmlType, pair);
    this.class2Pair.put(javaType, pair);
    if (sf != null)
      this.pair2SF.put(pair, sf); 
    if (dsf != null)
      this.pair2DF.put(pair, dsf); 
  }
  
  public SerializerFactory getSerializer(Class javaType, QName xmlType) throws JAXRPCException {
    SerializerFactory sf = null;
    if (xmlType == null) {
      xmlType = getTypeQName(javaType, null);
      if (xmlType == null)
        return null; 
    } 
    Pair pair = new Pair(javaType, xmlType);
    sf = (SerializerFactory)this.pair2SF.get(pair);
    if (sf == null && javaType.isArray()) {
      int dimension = 1;
      Class componentType = javaType.getComponentType();
      while (componentType.isArray()) {
        dimension++;
        componentType = componentType.getComponentType();
      } 
      int[] dimensions = new int[dimension];
      componentType = componentType.getSuperclass();
      Class superJavaType = null;
      while (componentType != null) {
        superJavaType = Array.newInstance(componentType, dimensions).getClass();
        pair = new Pair(superJavaType, xmlType);
        sf = (SerializerFactory)this.pair2SF.get(pair);
        if (sf != null)
          break; 
        componentType = componentType.getSuperclass();
      } 
    } 
    if (sf == null && javaType.isArray() && xmlType != null) {
      Pair pair2 = (Pair)this.qName2Pair.get(xmlType);
      if (pair2 != null && pair2.javaType != null && !pair2.javaType.isPrimitive() && ArrayUtil.isConvertable(pair2.javaType, javaType))
        sf = (SerializerFactory)this.pair2SF.get(pair2); 
    } 
    if (sf == null && !javaType.isArray() && !Constants.isSchemaXSD(xmlType.getNamespaceURI()) && !Constants.isSOAP_ENC(xmlType.getNamespaceURI())) {
      Pair pair2 = (Pair)this.qName2Pair.get(xmlType);
      if (pair2 != null && pair2.javaType != null && !pair2.javaType.isArray() && (javaType.isAssignableFrom(pair2.javaType) || (pair2.javaType.isPrimitive() && javaType == JavaUtils.getWrapperClass(pair2.javaType))))
        sf = (SerializerFactory)this.pair2SF.get(pair2); 
    } 
    return sf;
  }
  
  public SerializerFactory finalGetSerializer(Class javaType) {
    Pair pair;
    if (isArray(javaType)) {
      pair = (Pair)this.qName2Pair.get(Constants.SOAP_ARRAY);
    } else {
      pair = (Pair)this.class2Pair.get(javaType);
    } 
    if (pair != null)
      return (SerializerFactory)this.pair2SF.get(pair); 
    return null;
  }
  
  public QName getXMLType(Class javaType, QName xmlType, boolean encoded) throws JAXRPCException {
    SerializerFactory sf = null;
    if (xmlType == null) {
      xmlType = getTypeQNameRecursive(javaType);
      if (xmlType == null)
        return null; 
    } 
    Pair pair = new Pair(javaType, xmlType);
    sf = (SerializerFactory)this.pair2SF.get(pair);
    if (sf != null)
      return xmlType; 
    if (isArray(javaType)) {
      if (encoded)
        return Constants.SOAP_ARRAY; 
      pair = (Pair)this.qName2Pair.get(xmlType);
    } 
    if (pair == null)
      pair = (Pair)this.class2Pair.get(javaType); 
    if (pair != null)
      xmlType = pair.xmlType; 
    return xmlType;
  }
  
  public DeserializerFactory getDeserializer(Class javaType, QName xmlType, TypeMappingDelegate start) throws JAXRPCException {
    if (javaType == null) {
      javaType = start.getClassForQName(xmlType);
      if (javaType == null)
        return null; 
    } 
    Pair pair = new Pair(javaType, xmlType);
    return (DeserializerFactory)this.pair2DF.get(pair);
  }
  
  public DeserializerFactory finalGetDeserializer(Class javaType, QName xmlType, TypeMappingDelegate start) {
    ArrayDeserializerFactory arrayDeserializerFactory = null;
    if (javaType != null && javaType.isArray()) {
      Class componentType = javaType.getComponentType();
      if (xmlType != null) {
        Class actualClass = start.getClassForQName(xmlType);
        if (actualClass == componentType || (actualClass != null && (componentType.isAssignableFrom(actualClass) || Utils.getWrapperType(actualClass.getName()).equals(componentType.getName()))))
          return null; 
      } 
      Pair pair = (Pair)this.qName2Pair.get(Constants.SOAP_ARRAY);
      arrayDeserializerFactory = (DeserializerFactory)this.pair2DF.get(pair);
      if (arrayDeserializerFactory instanceof ArrayDeserializerFactory && javaType.isArray()) {
        QName componentXmlType = start.getTypeQName(componentType);
        if (componentXmlType != null)
          arrayDeserializerFactory = new ArrayDeserializerFactory(componentXmlType); 
      } 
    } 
    return arrayDeserializerFactory;
  }
  
  public void removeSerializer(Class javaType, QName xmlType) throws JAXRPCException {
    if (javaType == null || xmlType == null)
      throw new JAXRPCException(Messages.getMessage((javaType == null) ? "badJavaType" : "badXmlType")); 
    Pair pair = new Pair(javaType, xmlType);
    this.pair2SF.remove(pair);
  }
  
  public void removeDeserializer(Class javaType, QName xmlType) throws JAXRPCException {
    if (javaType == null || xmlType == null)
      throw new JAXRPCException(Messages.getMessage((javaType == null) ? "badJavaType" : "badXmlType")); 
    Pair pair = new Pair(javaType, xmlType);
    this.pair2DF.remove(pair);
  }
  
  public QName getTypeQNameRecursive(Class javaType) {
    QName ret = null;
    while (javaType != null) {
      ret = getTypeQName(javaType, null);
      if (ret != null)
        return ret; 
      Class[] interfaces = javaType.getInterfaces();
      if (interfaces != null)
        for (int i = 0; i < interfaces.length; i++) {
          Class iface = interfaces[i];
          ret = getTypeQName(iface, null);
          if (ret != null)
            return ret; 
        }  
      javaType = javaType.getSuperclass();
    } 
    return null;
  }
  
  public QName getTypeQNameExact(Class javaType, TypeMappingDelegate next) {
    if (javaType == null)
      return null; 
    QName xmlType = null;
    Pair pair = (Pair)this.class2Pair.get(javaType);
    if (isDotNetSoapEncFixNeeded() && pair != null) {
      xmlType = pair.xmlType;
      if (Constants.isSOAP_ENC(xmlType.getNamespaceURI()) && !xmlType.getLocalPart().equals("Array"))
        pair = null; 
    } 
    if (pair == null && next != null)
      xmlType = next.delegate.getTypeQNameExact(javaType, next.next); 
    if (pair != null)
      xmlType = pair.xmlType; 
    return xmlType;
  }
  
  private boolean isDotNetSoapEncFixNeeded() {
    MessageContext msgContext = MessageContext.getCurrentContext();
    if (msgContext != null) {
      SOAPService service = msgContext.getService();
      if (service != null) {
        String dotNetSoapEncFix = (String)service.getOption("dotNetSoapEncFix");
        if (dotNetSoapEncFix != null)
          return JavaUtils.isTrue(dotNetSoapEncFix); 
      } 
    } 
    return dotnet_soapenc_bugfix;
  }
  
  public QName getTypeQName(Class javaType, TypeMappingDelegate next) {
    QName xmlType = getTypeQNameExact(javaType, next);
    if (shouldDoAutoTypes() && javaType != java.util.List.class && !java.util.List.class.isAssignableFrom(javaType) && xmlType != null && xmlType.equals(Constants.SOAP_ARRAY)) {
      xmlType = new QName(Namespaces.makeNamespace(javaType.getName()), Types.getLocalNameFromFullName(javaType.getName()));
      internalRegister(javaType, xmlType, new ArraySerializerFactory(), new ArrayDeserializerFactory());
    } 
    if (xmlType == null && isArray(javaType)) {
      Pair pair = (Pair)this.class2Pair.get((array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object);
      if (pair != null) {
        xmlType = pair.xmlType;
      } else {
        xmlType = Constants.SOAP_ARRAY;
      } 
    } 
    if (xmlType == null && shouldDoAutoTypes()) {
      xmlType = new QName(Namespaces.makeNamespace(javaType.getName()), Types.getLocalNameFromFullName(javaType.getName()));
      internalRegister(javaType, xmlType, new BeanSerializerFactory(javaType, xmlType), new BeanDeserializerFactory(javaType, xmlType));
    } 
    return xmlType;
  }
  
  public Class getClassForQName(QName xmlType, Class javaType, TypeMappingDelegate next) {
    if (xmlType == null)
      return null; 
    if (javaType != null) {
      Pair pair = new Pair(javaType, xmlType);
      if (this.pair2DF.get(pair) == null && 
        next != null)
        javaType = next.getClassForQName(xmlType, javaType); 
    } 
    if (javaType == null) {
      Pair pair = (Pair)this.qName2Pair.get(xmlType);
      if (pair == null && next != null) {
        javaType = next.getClassForQName(xmlType);
      } else if (pair != null) {
        javaType = pair.javaType;
      } 
    } 
    if (javaType == null && shouldDoAutoTypes()) {
      String pkg = Namespaces.getPackage(xmlType.getNamespaceURI());
      if (pkg != null) {
        String className = xmlType.getLocalPart();
        if (pkg.length() > 0)
          className = pkg + "." + className; 
        try {
          javaType = ClassUtils.forName(className);
          internalRegister(javaType, xmlType, new BeanSerializerFactory(javaType, xmlType), new BeanDeserializerFactory(javaType, xmlType));
        } catch (ClassNotFoundException e) {}
      } 
    } 
    return javaType;
  }
  
  public void setDoAutoTypes(boolean doAutoTypes) { this.doAutoTypes = doAutoTypes ? Boolean.TRUE : Boolean.FALSE; }
  
  public boolean shouldDoAutoTypes() {
    if (this.doAutoTypes != null)
      return this.doAutoTypes.booleanValue(); 
    MessageContext msgContext = MessageContext.getCurrentContext();
    if (msgContext != null && (
      msgContext.isPropertyTrue("axis.doAutoTypes") || (msgContext.getAxisEngine() != null && JavaUtils.isTrue(msgContext.getAxisEngine().getOption("axis.doAutoTypes")))))
      this.doAutoTypes = Boolean.TRUE; 
    if (this.doAutoTypes == null)
      this.doAutoTypes = AxisProperties.getProperty("axis.doAutoTypes", "false").equals("true") ? Boolean.TRUE : Boolean.FALSE; 
    return this.doAutoTypes.booleanValue();
  }
  
  public Class[] getAllClasses(TypeMappingDelegate next) {
    HashSet temp = new HashSet();
    if (next != null)
      temp.addAll(Arrays.asList(next.getAllClasses())); 
    temp.addAll(this.class2Pair.keySet());
    return (Class[])temp.toArray(new Class[temp.size()]);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\TypeMappingImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */