package org.apache.axis.encoding;

import java.io.StringWriter;
import java.util.HashSet;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.rpc.encoding.Deserializer;
import org.apache.axis.Constants;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.message.EnvelopeHandler;
import org.apache.axis.message.MessageElement;
import org.apache.axis.message.SAX2EventRecorder;
import org.apache.axis.message.SAXOutputter;
import org.apache.axis.message.SOAPHandler;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class DeserializerImpl extends SOAPHandler implements Deserializer, Deserializer, Callback {
  protected static Log log = LogFactory.getLog(DeserializerImpl.class.getName());
  
  protected Object value = null;
  
  private final boolean debugEnabled = log.isDebugEnabled();
  
  protected boolean isEnded = false;
  
  protected Vector targets = null;
  
  protected QName defaultType = null;
  
  protected boolean componentsReadyFlag = false;
  
  private HashSet activeDeserializers = new HashSet();
  
  protected boolean isHref = false;
  
  protected boolean isNil = false;
  
  protected String id = null;
  
  public String getMechanismType() { return "Axis SAX Mechanism"; }
  
  public Object getValue() { return this.value; }
  
  public void setValue(Object value) { this.value = value; }
  
  public Object getValue(Object hint) { return null; }
  
  public void setChildValue(Object value, Object hint) throws SAXException {}
  
  public void setValue(Object value, Object hint) throws SAXException {
    if (hint instanceof Deserializer) {
      this.activeDeserializers.remove(hint);
      if (componentsReady())
        valueComplete(); 
    } 
  }
  
  public void setDefaultType(QName qName) { this.defaultType = qName; }
  
  public QName getDefaultType() { return this.defaultType; }
  
  public void registerValueTarget(Target target) {
    if (this.targets == null)
      this.targets = new Vector(); 
    this.targets.addElement(target);
  }
  
  public Vector getValueTargets() { return this.targets; }
  
  public void removeValueTargets() {
    if (this.targets != null)
      this.targets = null; 
  }
  
  public void moveValueTargets(Deserializer other) {
    if (other == null || other.getValueTargets() == null)
      return; 
    if (this.targets == null)
      this.targets = new Vector(); 
    this.targets.addAll(other.getValueTargets());
    other.removeValueTargets();
  }
  
  public boolean componentsReady() { return (this.componentsReadyFlag || (!this.isHref && this.isEnded && this.activeDeserializers.isEmpty())); }
  
  public void valueComplete() {
    if (componentsReady() && 
      this.targets != null) {
      for (int i = 0; i < this.targets.size(); i++) {
        Target target = (Target)this.targets.get(i);
        target.set(this.value);
        if (this.debugEnabled)
          log.debug(Messages.getMessage("setValueInTarget00", "" + this.value, "" + target)); 
      } 
      removeValueTargets();
    } 
  }
  
  public void addChildDeserializer(Deserializer dSer) {
    if (this.activeDeserializers != null)
      this.activeDeserializers.add(dSer); 
    dSer.registerValueTarget(new CallbackTarget(this, dSer));
  }
  
  public void startElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    super.startElement(namespace, localName, prefix, attributes, context);
    if (context.isNil(attributes)) {
      this.value = null;
      this.isNil = true;
      return;
    } 
    SOAPConstants soapConstants = context.getSOAPConstants();
    this.id = attributes.getValue("id");
    if (this.id != null) {
      context.addObjectById(this.id, this.value);
      if (this.debugEnabled)
        log.debug(Messages.getMessage("deserInitPutValueDebug00", "" + this.value, this.id)); 
      context.registerFixup("#" + this.id, this);
    } 
    String href = attributes.getValue(soapConstants.getAttrHref());
    if (href != null) {
      this.isHref = true;
      Object ref = context.getObjectByRef(href);
      if (this.debugEnabled)
        log.debug(Messages.getMessage("gotForID00", new String[] { "" + ref, href, (ref == null) ? "*null*" : ref.getClass().toString() })); 
      if (ref == null) {
        context.registerFixup(href, this);
        return;
      } 
      if (ref instanceof MessageElement) {
        context.replaceElementHandler(new EnvelopeHandler(this));
        SAX2EventRecorder r = context.getRecorder();
        context.setRecorder(null);
        ((MessageElement)ref).publishToHandler(context);
        context.setRecorder(r);
      } else {
        if (!href.startsWith("#") && this.defaultType != null && ref instanceof org.apache.axis.Part) {
          Deserializer dser = context.getDeserializerForType(this.defaultType);
          if (null != dser) {
            dser.startElement(namespace, localName, prefix, attributes, context);
            ref = dser.getValue();
          } 
        } 
        this.value = ref;
        this.componentsReadyFlag = true;
        valueComplete();
      } 
    } else {
      this.isHref = false;
      onStartElement(namespace, localName, prefix, attributes, context);
    } 
  }
  
  public void onStartElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (getClass().equals(DeserializerImpl.class)) {
      QName type = context.getTypeFromAttributes(namespace, localName, attributes);
      if (type == null) {
        type = this.defaultType;
        if (type == null)
          type = Constants.XSD_STRING; 
      } 
      if (this.debugEnabled)
        log.debug(Messages.getMessage("gotType00", "Deser", "" + type)); 
      if (type != null) {
        Deserializer dser = context.getDeserializerForType(type);
        if (dser == null)
          dser = context.getDeserializerForClass(null); 
        if (dser != null) {
          dser.moveValueTargets(this);
          context.replaceElementHandler((SOAPHandler)dser);
          boolean isRef = context.isProcessingRef();
          context.setProcessingRef(true);
          dser.startElement(namespace, localName, prefix, attributes, context);
          context.setProcessingRef(isRef);
        } else {
          throw new SAXException(Messages.getMessage("noDeser00", "" + type));
        } 
      } 
    } 
  }
  
  public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException { return null; }
  
  public final void endElement(String namespace, String localName, DeserializationContext context) throws SAXException {
    super.endElement(namespace, localName, context);
    this.isEnded = true;
    if (!this.isHref)
      onEndElement(namespace, localName, context); 
    if (componentsReady())
      valueComplete(); 
    if (this.id != null) {
      context.addObjectById(this.id, this.value);
      if (this.debugEnabled)
        log.debug(Messages.getMessage("deserPutValueDebug00", "" + this.value, this.id)); 
    } 
  }
  
  public void onEndElement(String namespace, String localName, DeserializationContext context) throws SAXException {
    if (getClass().equals(DeserializerImpl.class) && this.targets != null && !this.targets.isEmpty()) {
      StringWriter writer = new StringWriter();
      SerializationContext serContext = new SerializationContext(writer, context.getMessageContext());
      serContext.setSendDecl(false);
      SAXOutputter so = null;
      so = new SAXOutputter(serContext);
      context.getCurElement().publishContents(so);
      if (!this.isNil)
        this.value = writer.getBuffer().toString(); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\DeserializerImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */