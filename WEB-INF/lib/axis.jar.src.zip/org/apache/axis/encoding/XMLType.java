package org.apache.axis.encoding;

import javax.xml.namespace.QName;
import org.apache.axis.Constants;

public class XMLType extends Constants {
  public static final QName AXIS_VOID = new QName("http://xml.apache.org/axis/", "Void");
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\XMLType.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */