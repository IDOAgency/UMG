package org.apache.axis.encoding;

import java.lang.reflect.Field;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.SAXException;

public class FieldTarget implements Target {
  protected static Log log = LogFactory.getLog(FieldTarget.class.getName());
  
  private Object targetObject;
  
  private Field targetField;
  
  public FieldTarget(Object targetObject, Field targetField) {
    this.targetObject = targetObject;
    this.targetField = targetField;
  }
  
  public FieldTarget(Object targetObject, String fieldName) throws NoSuchFieldException {
    Class cls = targetObject.getClass();
    this.targetField = cls.getField(fieldName);
    this.targetObject = targetObject;
  }
  
  public void set(Object value) throws SAXException {
    try {
      this.targetField.set(this.targetObject, value);
    } catch (IllegalAccessException accEx) {
      log.error(Messages.getMessage("illegalAccessException00"), accEx);
      throw new SAXException(accEx);
    } catch (IllegalArgumentException argEx) {
      log.error(Messages.getMessage("illegalArgumentException00"), argEx);
      throw new SAXException(argEx);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\FieldTarget.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */