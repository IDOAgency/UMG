package org.apache.axis.encoding;

import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Stack;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.SerializationContext;
import javax.xml.rpc.holders.QNameHolder;
import org.apache.axis.AxisProperties;
import org.apache.axis.Constants;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.attachments.Attachments;
import org.apache.axis.components.encoding.XMLEncoder;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.constants.Use;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.TypeDesc;
import org.apache.axis.encoding.ser.BaseSerializerFactory;
import org.apache.axis.encoding.ser.SimpleListSerializerFactory;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.schema.SchemaVersion;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.IDKey;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.Mapping;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.NSStack;
import org.apache.axis.utils.XMLUtils;
import org.apache.axis.utils.cache.MethodCache;
import org.apache.axis.wsdl.symbolTable.SchemaUtils;
import org.apache.axis.wsdl.symbolTable.Utils;
import org.apache.commons.logging.Log;
import org.w3c.dom.Attr;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.AttributesImpl;

public class SerializationContext implements SerializationContext {
  protected static Log log = LogFactory.getLog(SerializationContext.class.getName());
  
  private final boolean debugEnabled;
  
  private NSStack nsStack;
  
  private boolean writingStartTag;
  
  private boolean onlyXML;
  
  private int indent;
  
  private Stack elementStack;
  
  private Writer writer;
  
  private int lastPrefixIndex;
  
  private MessageContext msgContext;
  
  private QName currentXMLType;
  
  private QName itemQName;
  
  private QName itemType;
  
  private SOAPConstants soapConstants;
  
  private static QName multirefQName = new QName("", "multiRef");
  
  private static Class[] SERIALIZER_CLASSES = { String.class, Class.class, QName.class };
  
  private static final String SERIALIZER_METHOD = "getSerializer";
  
  private boolean doMultiRefs;
  
  private boolean disablePrettyXML;
  
  private boolean enableNamespacePrefixOptimization;
  
  private boolean pretty;
  
  private boolean sendXMLDecl;
  
  private boolean sendXSIType;
  
  private Boolean sendNull;
  
  private HashMap multiRefValues;
  
  private int multiRefIndex;
  
  private boolean noNamespaceMappings;
  
  private QName writeXMLType;
  
  private XMLEncoder encoder;
  
  protected boolean startOfDocument;
  
  private String encoding;
  
  private HashSet secondLevelObjects;
  
  private Object forceSer;
  
  private boolean outputMultiRefsFlag;
  
  SchemaVersion schemaVersion;
  
  HashMap preferredPrefixes;
  
  static Class array$B;
  
  class MultiRefItem {
    String id;
    
    QName xmlType;
    
    Boolean sendType;
    
    Object value;
    
    private final SerializationContext this$0;
    
    MultiRefItem(SerializationContext this$0, String id, QName xmlType, Boolean sendType, Object value) {
      this.this$0 = this$0;
      this.id = id;
      this.xmlType = xmlType;
      this.sendType = sendType;
      this.value = value;
    }
  }
  
  public SerializationContext(Writer writer) {
    this.debugEnabled = log.isDebugEnabled();
    this.nsStack = null;
    this.writingStartTag = false;
    this.onlyXML = true;
    this.indent = 0;
    this.elementStack = new Stack();
    this.lastPrefixIndex = 1;
    this.soapConstants = SOAPConstants.SOAP11_CONSTANTS;
    this.doMultiRefs = false;
    this.disablePrettyXML = false;
    this.enableNamespacePrefixOptimization = false;
    this.pretty = false;
    this.sendXMLDecl = true;
    this.sendXSIType = true;
    this.sendNull = Boolean.TRUE;
    this.multiRefValues = null;
    this.multiRefIndex = -1;
    this.noNamespaceMappings = true;
    this.encoder = null;
    this.startOfDocument = true;
    this.encoding = "UTF-8";
    this.secondLevelObjects = null;
    this.forceSer = null;
    this.outputMultiRefsFlag = false;
    this.schemaVersion = SchemaVersion.SCHEMA_2001;
    this.preferredPrefixes = new HashMap();
    this.writer = writer;
    initialize();
  }
  
  private void initialize() {
    this.preferredPrefixes.put(this.soapConstants.getEncodingURI(), "soapenc");
    this.preferredPrefixes.put("http://www.w3.org/XML/1998/namespace", "xml");
    this.preferredPrefixes.put(this.schemaVersion.getXsdURI(), "xsd");
    this.preferredPrefixes.put(this.schemaVersion.getXsiURI(), "xsi");
    this.preferredPrefixes.put(this.soapConstants.getEnvelopeURI(), "soapenv");
    this.nsStack = new NSStack(this.enableNamespacePrefixOptimization);
  }
  
  public SerializationContext(Writer writer, MessageContext msgContext) {
    this.debugEnabled = log.isDebugEnabled();
    this.nsStack = null;
    this.writingStartTag = false;
    this.onlyXML = true;
    this.indent = 0;
    this.elementStack = new Stack();
    this.lastPrefixIndex = 1;
    this.soapConstants = SOAPConstants.SOAP11_CONSTANTS;
    this.doMultiRefs = false;
    this.disablePrettyXML = false;
    this.enableNamespacePrefixOptimization = false;
    this.pretty = false;
    this.sendXMLDecl = true;
    this.sendXSIType = true;
    this.sendNull = Boolean.TRUE;
    this.multiRefValues = null;
    this.multiRefIndex = -1;
    this.noNamespaceMappings = true;
    this.encoder = null;
    this.startOfDocument = true;
    this.encoding = "UTF-8";
    this.secondLevelObjects = null;
    this.forceSer = null;
    this.outputMultiRefsFlag = false;
    this.schemaVersion = SchemaVersion.SCHEMA_2001;
    this.preferredPrefixes = new HashMap();
    this.writer = writer;
    this.msgContext = msgContext;
    if (msgContext != null) {
      this.soapConstants = msgContext.getSOAPConstants();
      this.schemaVersion = msgContext.getSchemaVersion();
      Boolean shouldSendDecl = (Boolean)msgContext.getProperty("sendXMLDeclaration");
      if (shouldSendDecl != null)
        this.sendXMLDecl = shouldSendDecl.booleanValue(); 
      Boolean shouldSendMultiRefs = (Boolean)msgContext.getProperty("sendMultiRefs");
      if (shouldSendMultiRefs != null)
        this.doMultiRefs = shouldSendMultiRefs.booleanValue(); 
      Boolean shouldDisablePrettyXML = (Boolean)msgContext.getProperty("disablePrettyXML");
      if (shouldDisablePrettyXML != null)
        this.disablePrettyXML = shouldDisablePrettyXML.booleanValue(); 
      Boolean shouldDisableNamespacePrefixOptimization = (Boolean)msgContext.getProperty("enableNamespacePrefixOptimization");
      if (shouldDisableNamespacePrefixOptimization != null) {
        this.enableNamespacePrefixOptimization = shouldDisableNamespacePrefixOptimization.booleanValue();
      } else {
        this.enableNamespacePrefixOptimization = JavaUtils.isTrue(AxisProperties.getProperty("enableNamespacePrefixOptimization", "true"));
      } 
      boolean sendTypesDefault = this.sendXSIType;
      OperationDesc operation = msgContext.getOperation();
      if (operation != null) {
        if (operation.getUse() != Use.ENCODED) {
          this.doMultiRefs = false;
          sendTypesDefault = false;
        } 
      } else {
        SOAPService service = msgContext.getService();
        if (service != null && 
          service.getUse() != Use.ENCODED) {
          this.doMultiRefs = false;
          sendTypesDefault = false;
        } 
      } 
      if (!msgContext.isPropertyTrue("sendXsiTypes", sendTypesDefault))
        this.sendXSIType = false; 
    } else {
      this.enableNamespacePrefixOptimization = JavaUtils.isTrue(AxisProperties.getProperty("enableNamespacePrefixOptimization", "true"));
      this.disablePrettyXML = JavaUtils.isTrue(AxisProperties.getProperty("disablePrettyXML", "true"));
    } 
    initialize();
  }
  
  public boolean getPretty() { return this.pretty; }
  
  public void setPretty(boolean pretty) {
    if (!this.disablePrettyXML)
      this.pretty = pretty; 
  }
  
  public boolean getDoMultiRefs() { return this.doMultiRefs; }
  
  public void setDoMultiRefs(boolean shouldDo) { this.doMultiRefs = shouldDo; }
  
  public void setSendDecl(boolean sendDecl) { this.sendXMLDecl = sendDecl; }
  
  public boolean shouldSendXSIType() { return this.sendXSIType; }
  
  public TypeMapping getTypeMapping() {
    if (this.msgContext == null)
      return DefaultTypeMappingImpl.getSingletonDelegate(); 
    String encodingStyle = this.msgContext.getEncodingStyle();
    if (encodingStyle == null)
      encodingStyle = this.soapConstants.getEncodingURI(); 
    return (TypeMapping)this.msgContext.getTypeMappingRegistry().getTypeMapping(encodingStyle);
  }
  
  public TypeMappingRegistry getTypeMappingRegistry() {
    if (this.msgContext == null)
      return null; 
    return this.msgContext.getTypeMappingRegistry();
  }
  
  public String getPrefixForURI(String uri) { return getPrefixForURI(uri, null, false); }
  
  public String getPrefixForURI(String uri, String defaultPrefix) { return getPrefixForURI(uri, defaultPrefix, false); }
  
  public String getPrefixForURI(String uri, String defaultPrefix, boolean attribute) {
    if (uri == null || uri.length() == 0)
      return null; 
    String prefix = this.nsStack.getPrefix(uri, attribute);
    if (prefix == null) {
      prefix = (String)this.preferredPrefixes.get(uri);
      if (prefix == null)
        if (defaultPrefix == null) {
          prefix = "ns" + this.lastPrefixIndex++;
          while (this.nsStack.getNamespaceURI(prefix) != null)
            prefix = "ns" + this.lastPrefixIndex++; 
        } else {
          prefix = defaultPrefix;
        }  
      registerPrefixForURI(prefix, uri);
    } 
    return prefix;
  }
  
  public void registerPrefixForURI(String prefix, String uri) {
    if (this.debugEnabled)
      log.debug(Messages.getMessage("register00", prefix, uri)); 
    if (uri != null && prefix != null) {
      if (this.noNamespaceMappings) {
        this.nsStack.push();
        this.noNamespaceMappings = false;
      } 
      String activePrefix = this.nsStack.getPrefix(uri, true);
      if (activePrefix == null || !activePrefix.equals(prefix))
        this.nsStack.add(uri, prefix); 
    } 
  }
  
  public Message getCurrentMessage() {
    if (this.msgContext == null)
      return null; 
    return this.msgContext.getCurrentMessage();
  }
  
  public MessageContext getMessageContext() { return this.msgContext; }
  
  public String getEncodingStyle() { return (this.msgContext == null) ? Use.DEFAULT.getEncoding() : this.msgContext.getEncodingStyle(); }
  
  public boolean isEncoded() { return Constants.isSOAP_ENC(getEncodingStyle()); }
  
  public String qName2String(QName qName, boolean writeNS) {
    String prefix = null;
    String namespaceURI = qName.getNamespaceURI();
    String localPart = qName.getLocalPart();
    if (localPart != null && localPart.length() > 0) {
      int index = localPart.indexOf(':');
      if (index != -1) {
        prefix = localPart.substring(0, index);
        if (prefix.length() > 0 && !prefix.equals("urn")) {
          registerPrefixForURI(prefix, namespaceURI);
          localPart = localPart.substring(index + 1);
        } else {
          prefix = null;
        } 
      } 
      localPart = Utils.getLastLocalPart(localPart);
    } 
    if (namespaceURI.length() == 0) {
      if (writeNS) {
        String defaultNS = this.nsStack.getNamespaceURI("");
        if (defaultNS != null && defaultNS.length() > 0)
          registerPrefixForURI("", ""); 
      } 
    } else {
      prefix = getPrefixForURI(namespaceURI);
    } 
    if (prefix == null || prefix.length() == 0)
      return localPart; 
    return prefix + ':' + localPart;
  }
  
  public String qName2String(QName qName) { return qName2String(qName, false); }
  
  public String attributeQName2String(QName qName) {
    String prefix = null;
    String uri = qName.getNamespaceURI();
    if (uri.length() > 0)
      prefix = getPrefixForURI(uri, null, true); 
    if (prefix == null || prefix.length() == 0)
      return qName.getLocalPart(); 
    return prefix + ':' + qName.getLocalPart();
  }
  
  public QName getQNameForClass(Class cls) { return getTypeMapping().getTypeQName(cls); }
  
  public boolean isPrimitive(Object value) {
    if (value == null)
      return true; 
    Class javaType = value.getClass();
    if (javaType.isPrimitive())
      return true; 
    if (javaType == String.class)
      return true; 
    if (java.util.Calendar.class.isAssignableFrom(javaType))
      return true; 
    if (java.util.Date.class.isAssignableFrom(javaType))
      return true; 
    if (org.apache.axis.types.HexBinary.class.isAssignableFrom(javaType))
      return true; 
    if (Element.class.isAssignableFrom(javaType))
      return true; 
    if (javaType == ((array$B == null) ? (array$B = class$("[B")) : array$B))
      return true; 
    if (javaType.isArray())
      return true; 
    QName qName = getQNameForClass(javaType);
    if (qName != null && Constants.isSchemaXSD(qName.getNamespaceURI()) && 
      SchemaUtils.isSimpleSchemaType(qName))
      return true; 
    return false;
  }
  
  public void serialize(QName elemQName, Attributes attributes, Object value) throws IOException { serialize(elemQName, attributes, value, null, null, null, null); }
  
  public void serialize(QName elemQName, Attributes attributes, Object value, QName xmlType) throws IOException { serialize(elemQName, attributes, value, xmlType, null, null, null); }
  
  public void serialize(QName elemQName, Attributes attributes, Object value, QName xmlType, Class javaType) throws IOException { serialize(elemQName, attributes, value, xmlType, javaType, null, null); }
  
  public void serialize(QName elemQName, Attributes attributes, Object value, QName xmlType, boolean sendNull, Boolean sendType) throws IOException { serialize(elemQName, attributes, value, xmlType, null, sendNull ? Boolean.TRUE : Boolean.FALSE, sendType); }
  
  public void serialize(QName elemQName, Attributes attributes, Object value, QName xmlType, Boolean sendNull, Boolean sendType) throws IOException { serialize(elemQName, attributes, value, xmlType, null, sendNull, sendType); }
  
  public void serialize(QName elemQName, Attributes attributes, Object value, QName xmlType, Class javaClass, Boolean sendNull, Boolean sendType) throws IOException {
    sendXSITypeCache = this.sendXSIType;
    if (sendType != null)
      this.sendXSIType = sendType.booleanValue(); 
    boolean shouldSendType = shouldSendXSIType();
    try {
      Boolean sendNullCache = this.sendNull;
      if (sendNull != null) {
        this.sendNull = sendNull;
      } else {
        sendNull = this.sendNull;
      } 
      if (value == null) {
        if (this.sendNull.booleanValue()) {
          AttributesImpl attrs = new AttributesImpl();
          if (attributes != null && 0 < attributes.getLength())
            attrs.setAttributes(attributes); 
          if (shouldSendType)
            attrs = (AttributesImpl)setTypeAttribute(attrs, xmlType); 
          String nil = this.schemaVersion.getNilQName().getLocalPart();
          attrs.addAttribute(this.schemaVersion.getXsiURI(), nil, "xsi:" + nil, "CDATA", "true");
          startElement(elemQName, attrs);
          endElement();
        } 
        this.sendNull = sendNullCache;
        return;
      } 
      Message msg = getCurrentMessage();
      if (null != msg) {
        Attachments attachments = getCurrentMessage().getAttachmentsImpl();
        if (null != attachments && attachments.isAttachment(value)) {
          serializeActual(elemQName, attributes, value, xmlType, javaClass, sendType);
          this.sendNull = sendNullCache;
          return;
        } 
      } 
      if (this.doMultiRefs && isEncoded() && value != this.forceSer && !isPrimitive(value)) {
        String id;
        if (this.multiRefIndex == -1)
          this.multiRefValues = new HashMap(); 
        MultiRefItem mri = (MultiRefItem)this.multiRefValues.get(getIdentityKey(value));
        if (mri == null) {
          this.multiRefIndex++;
          id = "id" + this.multiRefIndex;
          mri = new MultiRefItem(this, id, xmlType, sendType, value);
          this.multiRefValues.put(getIdentityKey(value), mri);
          if (this.soapConstants == SOAPConstants.SOAP12_CONSTANTS) {
            AttributesImpl attrs = new AttributesImpl();
            if (attributes != null && 0 < attributes.getLength())
              attrs.setAttributes(attributes); 
            attrs.addAttribute("", "id", "id", "CDATA", id);
            serializeActual(elemQName, attrs, value, xmlType, javaClass, sendType);
            this.sendNull = sendNullCache;
            return;
          } 
          if (this.outputMultiRefsFlag) {
            if (this.secondLevelObjects == null)
              this.secondLevelObjects = new HashSet(); 
            this.secondLevelObjects.add(getIdentityKey(value));
          } 
        } else {
          id = mri.id;
        } 
        AttributesImpl attrs = new AttributesImpl();
        if (attributes != null && 0 < attributes.getLength())
          attrs.setAttributes(attributes); 
        attrs.addAttribute("", this.soapConstants.getAttrHref(), this.soapConstants.getAttrHref(), "CDATA", '#' + id);
        startElement(elemQName, attrs);
        endElement();
        this.sendNull = sendNullCache;
        return;
      } 
      if (value == this.forceSer)
        this.forceSer = null; 
      serializeActual(elemQName, attributes, value, xmlType, javaClass, sendType);
    } finally {
      this.sendXSIType = sendXSITypeCache;
    } 
  }
  
  private IDKey getIdentityKey(Object value) { return new IDKey(value); }
  
  public void outputMultiRefs() {
    String encodingStyle;
    if (!this.doMultiRefs || this.multiRefValues == null || this.soapConstants == SOAPConstants.SOAP12_CONSTANTS)
      return; 
    this.outputMultiRefsFlag = true;
    AttributesImpl attrs = new AttributesImpl();
    attrs.addAttribute("", "", "", "", "");
    String encodingURI = this.soapConstants.getEncodingURI();
    String prefix = getPrefixForURI(encodingURI);
    String root = prefix + ":root";
    attrs.addAttribute(encodingURI, "root", root, "CDATA", "0");
    if (this.msgContext != null) {
      encodingStyle = this.msgContext.getEncodingStyle();
    } else {
      encodingStyle = this.soapConstants.getEncodingURI();
    } 
    String encStyle = getPrefixForURI(this.soapConstants.getEnvelopeURI()) + ':' + "encodingStyle";
    attrs.addAttribute(this.soapConstants.getEnvelopeURI(), "encodingStyle", encStyle, "CDATA", encodingStyle);
    HashSet keys = new HashSet();
    keys.addAll(this.multiRefValues.keySet());
    Iterator i = keys.iterator();
    while (i.hasNext()) {
      while (i.hasNext()) {
        AttributesImpl attrs2 = new AttributesImpl(attrs);
        Object val = i.next();
        MultiRefItem mri = (MultiRefItem)this.multiRefValues.get(val);
        attrs2.setAttribute(0, "", "id", "id", "CDATA", mri.id);
        this.forceSer = mri.value;
        serialize(multirefQName, attrs2, mri.value, mri.xmlType, null, this.sendNull, Boolean.TRUE);
      } 
      if (this.secondLevelObjects != null) {
        i = this.secondLevelObjects.iterator();
        this.secondLevelObjects = null;
      } 
    } 
    this.forceSer = null;
    this.outputMultiRefsFlag = false;
    this.multiRefValues = null;
    this.multiRefIndex = -1;
    this.secondLevelObjects = null;
  }
  
  public void writeXMLDeclaration() {
    this.writer.write("<?xml version=\"1.0\" encoding=\"");
    this.writer.write(this.encoding);
    this.writer.write("\"?>");
    this.startOfDocument = false;
  }
  
  public void startElement(QName qName, Attributes attributes) throws IOException {
    ArrayList vecQNames = null;
    if (this.debugEnabled)
      log.debug(Messages.getMessage("startElem00", "[" + qName.getNamespaceURI() + "]:" + qName.getLocalPart())); 
    if (this.startOfDocument && this.sendXMLDecl)
      writeXMLDeclaration(); 
    if (this.writingStartTag) {
      this.writer.write(62);
      if (this.pretty)
        this.writer.write(10); 
      this.indent++;
    } 
    if (this.pretty)
      for (int i = 0; i < this.indent; ) {
        this.writer.write(32);
        i++;
      }  
    String elementQName = qName2String(qName, true);
    this.writer.write(60);
    this.writer.write(elementQName);
    if (this.writeXMLType != null) {
      attributes = setTypeAttribute(attributes, this.writeXMLType);
      this.writeXMLType = null;
    } 
    if (attributes != null)
      for (int i = 0; i < attributes.getLength(); i++) {
        String qname = attributes.getQName(i);
        this.writer.write(32);
        String prefix = "";
        String uri = attributes.getURI(i);
        if (uri != null && uri.length() > 0) {
          if (qname.length() == 0) {
            prefix = getPrefixForURI(uri);
          } else {
            int idx = qname.indexOf(':');
            if (idx > -1) {
              prefix = qname.substring(0, idx);
              prefix = getPrefixForURI(uri, prefix, true);
            } 
          } 
          if (prefix.length() > 0) {
            qname = prefix + ':' + attributes.getLocalName(i);
          } else {
            qname = attributes.getLocalName(i);
          } 
        } else {
          qname = attributes.getQName(i);
          if (qname.length() == 0)
            qname = attributes.getLocalName(i); 
        } 
        if (qname.startsWith("xmlns")) {
          if (vecQNames == null)
            vecQNames = new ArrayList(); 
          vecQNames.add(qname);
        } 
        this.writer.write(qname);
        this.writer.write("=\"");
        getEncoder().writeEncoded(this.writer, attributes.getValue(i));
        this.writer.write(34);
      }  
    if (this.noNamespaceMappings) {
      this.nsStack.push();
    } else {
      for (Mapping map = this.nsStack.topOfFrame(); map != null; map = this.nsStack.next()) {
        if ((!map.getNamespaceURI().equals("http://www.w3.org/2000/xmlns/") || !map.getPrefix().equals("xmlns")) && (!map.getNamespaceURI().equals("http://www.w3.org/XML/1998/namespace") || !map.getPrefix().equals("xml"))) {
          StringBuffer sb = new StringBuffer("xmlns");
          if (map.getPrefix().length() > 0) {
            sb.append(':');
            sb.append(map.getPrefix());
          } 
          if (vecQNames == null || vecQNames.indexOf(sb.toString()) == -1) {
            this.writer.write(32);
            sb.append("=\"");
            sb.append(map.getNamespaceURI());
            sb.append('"');
            this.writer.write(sb.toString());
          } 
        } 
      } 
      this.noNamespaceMappings = true;
    } 
    this.writingStartTag = true;
    this.elementStack.push(elementQName);
    this.onlyXML = true;
  }
  
  public void endElement() {
    String elementQName = (String)this.elementStack.pop();
    if (this.debugEnabled)
      log.debug(Messages.getMessage("endElem00", "" + elementQName)); 
    this.nsStack.pop();
    if (this.writingStartTag) {
      this.writer.write("/>");
      if (this.pretty)
        this.writer.write(10); 
      this.writingStartTag = false;
      return;
    } 
    if (this.onlyXML) {
      this.indent--;
      if (this.pretty)
        for (int i = 0; i < this.indent; ) {
          this.writer.write(32);
          i++;
        }  
    } 
    this.writer.write("</");
    this.writer.write(elementQName);
    this.writer.write(62);
    if (this.pretty && this.indent > 0)
      this.writer.write(10); 
    this.onlyXML = true;
  }
  
  public void writeChars(char[] p1, int p2, int p3) throws IOException {
    if (this.startOfDocument && this.sendXMLDecl)
      writeXMLDeclaration(); 
    if (this.writingStartTag) {
      this.writer.write(62);
      this.writingStartTag = false;
    } 
    writeSafeString(String.valueOf(p1, p2, p3));
    this.onlyXML = false;
  }
  
  public void writeString(String string) throws IOException {
    if (this.startOfDocument && this.sendXMLDecl)
      writeXMLDeclaration(); 
    if (this.writingStartTag) {
      this.writer.write(62);
      this.writingStartTag = false;
    } 
    this.writer.write(string);
    this.onlyXML = false;
  }
  
  public void writeSafeString(String string) throws IOException {
    if (this.startOfDocument && this.sendXMLDecl)
      writeXMLDeclaration(); 
    if (this.writingStartTag) {
      this.writer.write(62);
      this.writingStartTag = false;
    } 
    getEncoder().writeEncoded(this.writer, string);
    this.onlyXML = false;
  }
  
  public void writeDOMElement(Element el) throws IOException {
    if (this.startOfDocument && this.sendXMLDecl)
      writeXMLDeclaration(); 
    if (el instanceof org.apache.axis.message.Text) {
      writeSafeString(((Text)el).getData());
      return;
    } 
    AttributesImpl attributes = null;
    NamedNodeMap attrMap = el.getAttributes();
    if (attrMap.getLength() > 0) {
      attributes = new AttributesImpl();
      for (int i = 0; i < attrMap.getLength(); i++) {
        Attr attr = (Attr)attrMap.item(i);
        String tmp = attr.getNamespaceURI();
        if (tmp != null && tmp.equals("http://www.w3.org/2000/xmlns/")) {
          String prefix = attr.getLocalName();
          if (prefix != null) {
            if (prefix.equals("xmlns"))
              prefix = ""; 
            String nsURI = attr.getValue();
            registerPrefixForURI(prefix, nsURI);
          } 
        } else {
          attributes.addAttribute(attr.getNamespaceURI(), attr.getLocalName(), attr.getName(), "CDATA", attr.getValue());
        } 
      } 
    } 
    String namespaceURI = el.getNamespaceURI();
    String localPart = el.getLocalName();
    if (namespaceURI == null || namespaceURI.length() == 0)
      localPart = el.getNodeName(); 
    QName qName = new QName(namespaceURI, localPart);
    startElement(qName, attributes);
    NodeList children = el.getChildNodes();
    for (int i = 0; i < children.getLength(); i++) {
      Node child = children.item(i);
      if (child instanceof Element) {
        writeDOMElement((Element)child);
      } else if (child instanceof org.w3c.dom.CDATASection) {
        writeString("<![CDATA[");
        writeString(((Text)child).getData());
        writeString("]]>");
      } else if (child instanceof org.w3c.dom.Comment) {
        writeString("<!--");
        writeString(((CharacterData)child).getData());
        writeString("-->");
      } else if (child instanceof Text) {
        writeSafeString(((Text)child).getData());
      } 
    } 
    endElement();
  }
  
  public final Serializer getSerializerForJavaType(Class javaType) {
    SerializerFactory serF = null;
    Serializer ser = null;
    try {
      serF = (SerializerFactory)getTypeMapping().getSerializer(javaType);
      if (serF != null)
        ser = (Serializer)serF.getSerializerAs("Axis SAX Mechanism"); 
    } catch (JAXRPCException e) {}
    return ser;
  }
  
  public Attributes setTypeAttribute(Attributes attributes, QName type) {
    SchemaVersion schema = SchemaVersion.SCHEMA_2001;
    if (this.msgContext != null)
      schema = this.msgContext.getSchemaVersion(); 
    if (type == null || type.getLocalPart().indexOf(">") >= 0 || (attributes != null && attributes.getIndex(schema.getXsiURI(), "type") != -1))
      return attributes; 
    AttributesImpl attrs = new AttributesImpl();
    if (attributes != null && 0 < attributes.getLength())
      attrs.setAttributes(attributes); 
    String prefix = getPrefixForURI(schema.getXsiURI(), "xsi");
    attrs.addAttribute(schema.getXsiURI(), "type", prefix + ":type", "CDATA", attributeQName2String(type));
    return attrs;
  }
  
  private void serializeActual(QName elemQName, Attributes attributes, Object value, QName xmlType, Class javaClass, Boolean sendType) throws IOException {
    boolean shouldSendType = (sendType == null) ? shouldSendXSIType() : sendType.booleanValue();
    if (value != null) {
      TypeMapping tm = getTypeMapping();
      if (tm == null)
        throw new IOException(Messages.getMessage("noSerializer00", value.getClass().getName(), "" + this)); 
      this.currentXMLType = xmlType;
      if (Constants.equals(Constants.XSD_ANYTYPE, xmlType)) {
        xmlType = null;
        shouldSendType = true;
      } 
      QNameHolder actualXMLType = new QNameHolder();
      Class javaType = getActualJavaClass(xmlType, javaClass, value);
      Serializer ser = getSerializer(javaType, xmlType, actualXMLType);
      if (ser != null) {
        if (shouldSendType || (xmlType != null && !xmlType.equals(actualXMLType.value)))
          if (!isEncoded()) {
            if (!Constants.isSOAP_ENC(actualXMLType.value.getNamespaceURI()))
              if (!javaType.isPrimitive() || javaClass == null || JavaUtils.getWrapperClass(javaType) != javaClass)
                if (!javaType.isArray() || xmlType == null || !Constants.isSchemaXSD(xmlType.getNamespaceURI()))
                  this.writeXMLType = actualXMLType.value;   
          } else {
            this.writeXMLType = actualXMLType.value;
          }  
        ser.serialize(elemQName, attributes, value, this);
        return;
      } 
      throw new IOException(Messages.getMessage("noSerializer00", value.getClass().getName(), "" + tm));
    } 
  }
  
  private Class getActualJavaClass(QName xmlType, Class javaType, Object obj) {
    Class cls = obj.getClass();
    if ((xmlType != null && Constants.isSchemaXSD(xmlType.getNamespaceURI()) && "anyType".equals(xmlType.getLocalPart())) || (javaType != null && (javaType.isArray() || javaType == Object.class)))
      return cls; 
    if (javaType != null && !javaType.isAssignableFrom(cls) && !cls.isArray())
      return javaType; 
    return cls;
  }
  
  private Serializer getSerializerFromClass(Class javaType, QName qname) {
    Serializer serializer = null;
    try {
      Method method = MethodCache.getInstance().getMethod(javaType, "getSerializer", SERIALIZER_CLASSES);
      if (method != null)
        serializer = (Serializer)method.invoke(null, new Object[] { getEncodingStyle(), javaType, qname }); 
    } catch (NoSuchMethodException e) {
    
    } catch (IllegalAccessException e) {
    
    } catch (InvocationTargetException e) {}
    return serializer;
  }
  
  public QName getCurrentXMLType() { return this.currentXMLType; }
  
  private SerializerFactory getSerializerFactoryFromInterface(Class javaType, QName xmlType, TypeMapping tm) {
    SerializerFactory serFactory = null;
    Class[] interfaces = javaType.getInterfaces();
    if (interfaces != null)
      for (int i = 0; i < interfaces.length; i++) {
        Class iface = interfaces[i];
        serFactory = (SerializerFactory)tm.getSerializer(iface, xmlType);
        if (serFactory == null)
          serFactory = getSerializerFactoryFromInterface(iface, xmlType, tm); 
        if (serFactory != null)
          break; 
      }  
    return serFactory;
  }
  
  private Serializer getSerializer(Class javaType, QName xmlType, QNameHolder actualXMLType) {
    SerializerFactory serFactory = null;
    TypeMapping tm = getTypeMapping();
    if (actualXMLType != null)
      actualXMLType.value = null; 
    while (javaType != null) {
      serFactory = (SerializerFactory)tm.getSerializer(javaType, xmlType);
      if (serFactory != null)
        break; 
      Serializer serializer = getSerializerFromClass(javaType, xmlType);
      if (serializer != null) {
        if (actualXMLType != null) {
          TypeDesc typedesc = TypeDesc.getTypeDescForClass(javaType);
          if (typedesc != null)
            actualXMLType.value = typedesc.getXmlType(); 
        } 
        return serializer;
      } 
      serFactory = getSerializerFactoryFromInterface(javaType, xmlType, tm);
      if (serFactory != null)
        break; 
      javaType = javaType.getSuperclass();
    } 
    Serializer ser = null;
    if (serFactory != null) {
      ser = (Serializer)serFactory.getSerializerAs("Axis SAX Mechanism");
      if (actualXMLType != null) {
        if (serFactory instanceof BaseSerializerFactory)
          actualXMLType.value = ((BaseSerializerFactory)serFactory).getXMLType(); 
        boolean encoded = isEncoded();
        if (actualXMLType.value == null || (!encoded && (actualXMLType.value.equals(Constants.SOAP_ARRAY) || actualXMLType.value.equals(Constants.SOAP_ARRAY12))))
          actualXMLType.value = tm.getXMLType(javaType, xmlType, encoded); 
      } 
    } 
    return ser;
  }
  
  public String getValueAsString(Object value, QName xmlType, Class javaClass) throws IOException {
    Class cls = value.getClass();
    cls = getActualJavaClass(xmlType, javaClass, value);
    Serializer ser = getSerializer(cls, xmlType, null);
    if (ser instanceof org.apache.axis.encoding.ser.ArraySerializer) {
      SimpleListSerializerFactory factory = new SimpleListSerializerFactory(cls, xmlType);
      ser = (Serializer)factory.getSerializerAs(getEncodingStyle());
    } 
    if (!(ser instanceof SimpleValueSerializer))
      throw new IOException(Messages.getMessage("needSimpleValueSer", ser.getClass().getName())); 
    SimpleValueSerializer simpleSer = (SimpleValueSerializer)ser;
    return simpleSer.getValueAsString(value, this);
  }
  
  public void setWriteXMLType(QName type) { this.writeXMLType = type; }
  
  public XMLEncoder getEncoder() {
    if (this.encoder == null)
      this.encoder = XMLUtils.getXMLEncoder(this.encoding); 
    return this.encoder;
  }
  
  public String getEncoding() { return this.encoding; }
  
  public void setEncoding(String encoding) throws IOException { this.encoding = encoding; }
  
  public QName getItemQName() { return this.itemQName; }
  
  public void setItemQName(QName itemQName) { this.itemQName = itemQName; }
  
  public QName getItemType() { return this.itemType; }
  
  public void setItemType(QName itemType) { this.itemType = itemType; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\SerializationContext.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */