/*     */ package org.apache.axis.encoding;
/*     */ 
/*     */ import org.apache.axis.Constants;
/*     */ import org.apache.axis.encoding.ser.CalendarDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.CalendarSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.DateDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.DateSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.TimeDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.TimeSerializerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultJAXRPC11TypeMappingImpl
/*     */   extends DefaultTypeMappingImpl
/*     */ {
/*  33 */   private static DefaultJAXRPC11TypeMappingImpl tm = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeMappingImpl getSingleton() {
/*  39 */     if (tm == null) {
/*  40 */       tm = new DefaultJAXRPC11TypeMappingImpl();
/*     */     }
/*  42 */     return tm;
/*     */   }
/*     */ 
/*     */   
/*  46 */   protected DefaultJAXRPC11TypeMappingImpl() { registerXSDTypes(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerXSDTypes() {
/*  54 */     myRegisterSimple(Constants.XSD_UNSIGNEDINT, Long.class);
/*  55 */     myRegisterSimple(Constants.XSD_UNSIGNEDINT, long.class);
/*  56 */     myRegisterSimple(Constants.XSD_UNSIGNEDSHORT, Integer.class);
/*  57 */     myRegisterSimple(Constants.XSD_UNSIGNEDSHORT, int.class);
/*  58 */     myRegisterSimple(Constants.XSD_UNSIGNEDBYTE, Short.class);
/*  59 */     myRegisterSimple(Constants.XSD_UNSIGNEDBYTE, short.class);
/*  60 */     myRegister(Constants.XSD_DATETIME, java.util.Calendar.class, new CalendarSerializerFactory(java.util.Calendar.class, Constants.XSD_DATETIME), new CalendarDeserializerFactory(java.util.Calendar.class, Constants.XSD_DATETIME));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     myRegister(Constants.XSD_DATE, java.util.Calendar.class, new DateSerializerFactory(java.util.Calendar.class, Constants.XSD_DATE), new DateDeserializerFactory(java.util.Calendar.class, Constants.XSD_DATE));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     myRegister(Constants.XSD_TIME, java.util.Calendar.class, new TimeSerializerFactory(java.util.Calendar.class, Constants.XSD_TIME), new TimeDeserializerFactory(java.util.Calendar.class, Constants.XSD_TIME));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  76 */       myRegisterSimple(Constants.XSD_ANYURI, Class.forName("java.net.URI"));
/*     */     }
/*  78 */     catch (ClassNotFoundException e) {
/*  79 */       myRegisterSimple(Constants.XSD_ANYURI, String.class);
/*     */     } 
/*     */ 
/*     */     
/*  83 */     myRegisterSimple(Constants.XSD_DURATION, String.class);
/*  84 */     myRegisterSimple(Constants.XSD_YEARMONTH, String.class);
/*  85 */     myRegisterSimple(Constants.XSD_YEAR, String.class);
/*  86 */     myRegisterSimple(Constants.XSD_MONTHDAY, String.class);
/*  87 */     myRegisterSimple(Constants.XSD_DAY, String.class);
/*  88 */     myRegisterSimple(Constants.XSD_MONTH, String.class);
/*  89 */     myRegisterSimple(Constants.XSD_NORMALIZEDSTRING, String.class);
/*     */     
/*  91 */     myRegisterSimple(Constants.XSD_TOKEN, String.class);
/*  92 */     myRegisterSimple(Constants.XSD_LANGUAGE, String.class);
/*  93 */     myRegisterSimple(Constants.XSD_NAME, String.class);
/*  94 */     myRegisterSimple(Constants.XSD_NCNAME, String.class);
/*  95 */     myRegisterSimple(Constants.XSD_ID, String.class);
/*  96 */     myRegisterSimple(Constants.XSD_NMTOKEN, String.class);
/*  97 */     myRegisterSimple(Constants.XSD_NMTOKENS, String.class);
/*  98 */     myRegisterSimple(Constants.XSD_STRING, String.class);
/*  99 */     myRegisterSimple(Constants.XSD_NONPOSITIVEINTEGER, java.math.BigInteger.class);
/*     */     
/* 101 */     myRegisterSimple(Constants.XSD_NEGATIVEINTEGER, java.math.BigInteger.class);
/*     */     
/* 103 */     myRegisterSimple(Constants.XSD_NONNEGATIVEINTEGER, java.math.BigInteger.class);
/*     */     
/* 105 */     myRegisterSimple(Constants.XSD_UNSIGNEDLONG, java.math.BigInteger.class);
/*     */     
/* 107 */     myRegisterSimple(Constants.XSD_POSITIVEINTEGER, java.math.BigInteger.class);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\DefaultJAXRPC11TypeMappingImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */