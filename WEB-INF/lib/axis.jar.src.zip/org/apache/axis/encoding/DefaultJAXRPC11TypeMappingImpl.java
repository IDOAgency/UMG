package org.apache.axis.encoding;

import org.apache.axis.Constants;
import org.apache.axis.encoding.ser.CalendarDeserializerFactory;
import org.apache.axis.encoding.ser.CalendarSerializerFactory;
import org.apache.axis.encoding.ser.DateDeserializerFactory;
import org.apache.axis.encoding.ser.DateSerializerFactory;
import org.apache.axis.encoding.ser.TimeDeserializerFactory;
import org.apache.axis.encoding.ser.TimeSerializerFactory;

public class DefaultJAXRPC11TypeMappingImpl extends DefaultTypeMappingImpl {
  private static DefaultJAXRPC11TypeMappingImpl tm = null;
  
  public static TypeMappingImpl getSingleton() {
    if (tm == null)
      tm = new DefaultJAXRPC11TypeMappingImpl(); 
    return tm;
  }
  
  protected DefaultJAXRPC11TypeMappingImpl() { registerXSDTypes(); }
  
  private void registerXSDTypes() {
    myRegisterSimple(Constants.XSD_UNSIGNEDINT, Long.class);
    myRegisterSimple(Constants.XSD_UNSIGNEDINT, long.class);
    myRegisterSimple(Constants.XSD_UNSIGNEDSHORT, Integer.class);
    myRegisterSimple(Constants.XSD_UNSIGNEDSHORT, int.class);
    myRegisterSimple(Constants.XSD_UNSIGNEDBYTE, Short.class);
    myRegisterSimple(Constants.XSD_UNSIGNEDBYTE, short.class);
    myRegister(Constants.XSD_DATETIME, java.util.Calendar.class, new CalendarSerializerFactory(java.util.Calendar.class, Constants.XSD_DATETIME), new CalendarDeserializerFactory(java.util.Calendar.class, Constants.XSD_DATETIME));
    myRegister(Constants.XSD_DATE, java.util.Calendar.class, new DateSerializerFactory(java.util.Calendar.class, Constants.XSD_DATE), new DateDeserializerFactory(java.util.Calendar.class, Constants.XSD_DATE));
    myRegister(Constants.XSD_TIME, java.util.Calendar.class, new TimeSerializerFactory(java.util.Calendar.class, Constants.XSD_TIME), new TimeDeserializerFactory(java.util.Calendar.class, Constants.XSD_TIME));
    try {
      myRegisterSimple(Constants.XSD_ANYURI, Class.forName("java.net.URI"));
    } catch (ClassNotFoundException e) {
      myRegisterSimple(Constants.XSD_ANYURI, String.class);
    } 
    myRegisterSimple(Constants.XSD_DURATION, String.class);
    myRegisterSimple(Constants.XSD_YEARMONTH, String.class);
    myRegisterSimple(Constants.XSD_YEAR, String.class);
    myRegisterSimple(Constants.XSD_MONTHDAY, String.class);
    myRegisterSimple(Constants.XSD_DAY, String.class);
    myRegisterSimple(Constants.XSD_MONTH, String.class);
    myRegisterSimple(Constants.XSD_NORMALIZEDSTRING, String.class);
    myRegisterSimple(Constants.XSD_TOKEN, String.class);
    myRegisterSimple(Constants.XSD_LANGUAGE, String.class);
    myRegisterSimple(Constants.XSD_NAME, String.class);
    myRegisterSimple(Constants.XSD_NCNAME, String.class);
    myRegisterSimple(Constants.XSD_ID, String.class);
    myRegisterSimple(Constants.XSD_NMTOKEN, String.class);
    myRegisterSimple(Constants.XSD_NMTOKENS, String.class);
    myRegisterSimple(Constants.XSD_STRING, String.class);
    myRegisterSimple(Constants.XSD_NONPOSITIVEINTEGER, java.math.BigInteger.class);
    myRegisterSimple(Constants.XSD_NEGATIVEINTEGER, java.math.BigInteger.class);
    myRegisterSimple(Constants.XSD_NONNEGATIVEINTEGER, java.math.BigInteger.class);
    myRegisterSimple(Constants.XSD_UNSIGNEDLONG, java.math.BigInteger.class);
    myRegisterSimple(Constants.XSD_POSITIVEINTEGER, java.math.BigInteger.class);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\DefaultJAXRPC11TypeMappingImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */