package org.apache.axis.encoding;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import javax.xml.rpc.encoding.TypeMapping;
import org.apache.axis.utils.Messages;

public class TypeMappingRegistryImpl implements TypeMappingRegistry {
  private HashMap mapTM;
  
  private TypeMappingDelegate defaultDelTM;
  
  private boolean isDelegated;
  
  public TypeMappingRegistryImpl(TypeMappingImpl tm) {
    this.isDelegated = false;
    this.mapTM = new HashMap();
    this.defaultDelTM = new TypeMappingDelegate(tm);
  }
  
  public TypeMappingRegistryImpl() { this(true); }
  
  public TypeMappingRegistryImpl(boolean registerDefaults) {
    this.isDelegated = false;
    this.mapTM = new HashMap();
    if (registerDefaults) {
      this.defaultDelTM = DefaultTypeMappingImpl.getSingletonDelegate();
      TypeMappingDelegate del = new TypeMappingDelegate(new DefaultSOAPEncodingTypeMappingImpl());
      register("http://schemas.xmlsoap.org/soap/encoding/", del);
    } else {
      this.defaultDelTM = new TypeMappingDelegate(TypeMappingDelegate.placeholder);
    } 
  }
  
  public void delegate(TypeMappingRegistry secondaryTMR) {
    if (this.isDelegated || secondaryTMR == null || secondaryTMR == this)
      return; 
    this.isDelegated = true;
    String[] keys = secondaryTMR.getRegisteredEncodingStyleURIs();
    TypeMappingDelegate otherDefault = ((TypeMappingRegistryImpl)secondaryTMR).defaultDelTM;
    if (keys != null)
      for (int i = 0; i < keys.length; i++) {
        try {
          String nsURI = keys[i];
          TypeMappingDelegate tm = (TypeMappingDelegate)this.mapTM.get(nsURI);
          if (tm == null) {
            tm = (TypeMappingDelegate)createTypeMapping();
            tm.setSupportedEncodings(new String[] { nsURI });
            register(nsURI, tm);
          } 
          if (tm != null) {
            TypeMappingDelegate del = (TypeMappingDelegate)((TypeMappingRegistryImpl)secondaryTMR).mapTM.get(nsURI);
            while (del.next != null) {
              TypeMappingDelegate nu = new TypeMappingDelegate(del.delegate);
              tm.setNext(nu);
              if (del.next == otherDefault) {
                nu.setNext(this.defaultDelTM);
                break;
              } 
              del = del.next;
              tm = nu;
            } 
          } 
        } catch (Exception e) {}
      }  
    if (this.defaultDelTM.delegate != TypeMappingDelegate.placeholder) {
      this.defaultDelTM.setNext(otherDefault);
    } else {
      this.defaultDelTM.delegate = otherDefault.delegate;
    } 
  }
  
  public TypeMapping register(String namespaceURI, TypeMapping mapping) {
    if (mapping == null || !(mapping instanceof TypeMappingDelegate))
      throw new IllegalArgumentException(Messages.getMessage("badTypeMapping")); 
    if (namespaceURI == null)
      throw new IllegalArgumentException(Messages.getMessage("nullNamespaceURI")); 
    TypeMappingDelegate del = (TypeMappingDelegate)mapping;
    TypeMappingDelegate old = (TypeMappingDelegate)this.mapTM.get(namespaceURI);
    if (old == null) {
      del.setNext(this.defaultDelTM);
    } else {
      del.setNext(old);
    } 
    this.mapTM.put(namespaceURI, del);
    return old;
  }
  
  public void registerDefault(TypeMapping mapping) {
    if (mapping == null || !(mapping instanceof TypeMappingDelegate))
      throw new IllegalArgumentException(Messages.getMessage("badTypeMapping")); 
    if (this.defaultDelTM.getNext() != null)
      throw new IllegalArgumentException(Messages.getMessage("defaultTypeMappingSet")); 
    this.defaultDelTM = (TypeMappingDelegate)mapping;
  }
  
  public void doRegisterFromVersion(String version) {
    if (version == null || version.equals("1.0") || version.equals("1.2")) {
      TypeMappingImpl.dotnet_soapenc_bugfix = false;
    } else {
      if (version.equals("1.1")) {
        TypeMappingImpl.dotnet_soapenc_bugfix = true;
        return;
      } 
      if (version.equals("1.3")) {
        this.defaultDelTM = new TypeMappingDelegate(DefaultJAXRPC11TypeMappingImpl.getSingleton());
      } else {
        throw new RuntimeException(Messages.getMessage("j2wBadTypeMapping00"));
      } 
    } 
    registerSOAPENCDefault(new TypeMappingDelegate(DefaultSOAPEncodingTypeMappingImpl.getSingleton()));
  }
  
  private void registerSOAPENCDefault(TypeMappingDelegate mapping) {
    if (!this.mapTM.containsKey("http://schemas.xmlsoap.org/soap/encoding/")) {
      this.mapTM.put("http://schemas.xmlsoap.org/soap/encoding/", mapping);
    } else {
      TypeMappingDelegate del = (TypeMappingDelegate)this.mapTM.get("http://schemas.xmlsoap.org/soap/encoding/");
      while (del.getNext() != null && !(del.delegate instanceof DefaultTypeMappingImpl))
        del = del.getNext(); 
      del.setNext(this.defaultDelTM);
    } 
    if (!this.mapTM.containsKey("http://www.w3.org/2003/05/soap-encoding")) {
      this.mapTM.put("http://www.w3.org/2003/05/soap-encoding", mapping);
    } else {
      TypeMappingDelegate del = (TypeMappingDelegate)this.mapTM.get("http://www.w3.org/2003/05/soap-encoding");
      while (del.getNext() != null && !(del.delegate instanceof DefaultTypeMappingImpl))
        del = del.getNext(); 
      del.setNext(this.defaultDelTM);
    } 
    mapping.setNext(this.defaultDelTM);
  }
  
  public TypeMapping getTypeMapping(String namespaceURI) {
    TypeMapping del = (TypeMappingDelegate)this.mapTM.get(namespaceURI);
    if (del == null)
      del = (TypeMapping)getDefaultTypeMapping(); 
    return del;
  }
  
  public TypeMapping getOrMakeTypeMapping(String encodingStyle) {
    TypeMappingDelegate del = (TypeMappingDelegate)this.mapTM.get(encodingStyle);
    if (del == null || del.delegate instanceof DefaultTypeMappingImpl) {
      del = (TypeMappingDelegate)createTypeMapping();
      del.setSupportedEncodings(new String[] { encodingStyle });
      register(encodingStyle, del);
    } 
    return del;
  }
  
  public TypeMapping unregisterTypeMapping(String namespaceURI) { return (TypeMappingDelegate)this.mapTM.remove(namespaceURI); }
  
  public boolean removeTypeMapping(TypeMapping mapping) {
    String[] ns = getRegisteredEncodingStyleURIs();
    boolean rc = false;
    for (int i = 0; i < ns.length; i++) {
      if (getTypeMapping(ns[i]) == mapping) {
        rc = true;
        unregisterTypeMapping(ns[i]);
      } 
    } 
    return rc;
  }
  
  public TypeMapping createTypeMapping() {
    TypeMappingImpl impl = new TypeMappingImpl();
    TypeMappingDelegate del = new TypeMappingDelegate(impl);
    del.setNext(this.defaultDelTM);
    return del;
  }
  
  public String[] getRegisteredEncodingStyleURIs() {
    Set s = this.mapTM.keySet();
    if (s != null) {
      String[] rc = new String[s.size()];
      int i = 0;
      Iterator it = s.iterator();
      while (it.hasNext())
        rc[i++] = (String)it.next(); 
      return rc;
    } 
    return null;
  }
  
  public void clear() { this.mapTM.clear(); }
  
  public TypeMapping getDefaultTypeMapping() { return this.defaultDelTM; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\TypeMappingRegistryImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */