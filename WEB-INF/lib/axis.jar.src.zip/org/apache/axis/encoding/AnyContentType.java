package org.apache.axis.encoding;

import org.apache.axis.message.MessageElement;

public interface AnyContentType {
  MessageElement[] get_any();
  
  void set_any(MessageElement[] paramArrayOfMessageElement);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\AnyContentType.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */