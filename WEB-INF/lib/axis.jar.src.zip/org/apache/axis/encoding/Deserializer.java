package org.apache.axis.encoding;

import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.rpc.encoding.Deserializer;
import org.apache.axis.message.SOAPHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public interface Deserializer extends Deserializer, Callback {
  Object getValue();
  
  void setValue(Object paramObject);
  
  Object getValue(Object paramObject);
  
  void setChildValue(Object paramObject1, Object paramObject2) throws SAXException;
  
  void setDefaultType(QName paramQName);
  
  QName getDefaultType();
  
  void registerValueTarget(Target paramTarget);
  
  Vector getValueTargets();
  
  void removeValueTargets();
  
  void moveValueTargets(Deserializer paramDeserializer);
  
  boolean componentsReady();
  
  void valueComplete();
  
  void startElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes, DeserializationContext paramDeserializationContext) throws SAXException;
  
  void onStartElement(String paramString1, String paramString2, String paramString3, Attributes paramAttributes, DeserializationContext paramDeserializationContext) throws SAXException;
  
  SOAPHandler onStartChild(String paramString1, String paramString2, String paramString3, Attributes paramAttributes, DeserializationContext paramDeserializationContext) throws SAXException;
  
  void endElement(String paramString1, String paramString2, DeserializationContext paramDeserializationContext) throws SAXException;
  
  void onEndElement(String paramString1, String paramString2, DeserializationContext paramDeserializationContext) throws SAXException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\Deserializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */