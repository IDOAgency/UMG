package org.apache.axis.encoding;

public interface SimpleValueSerializer extends Serializer {
  String getValueAsString(Object paramObject, SerializationContext paramSerializationContext);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\SimpleValueSerializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */