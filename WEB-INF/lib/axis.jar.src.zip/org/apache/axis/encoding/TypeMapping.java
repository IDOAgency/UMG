package org.apache.axis.encoding;

import java.io.Serializable;
import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.DeserializerFactory;
import javax.xml.rpc.encoding.SerializerFactory;
import javax.xml.rpc.encoding.TypeMapping;

public interface TypeMapping extends TypeMapping, Serializable {
  SerializerFactory getSerializer(Class paramClass) throws JAXRPCException;
  
  DeserializerFactory getDeserializer(QName paramQName) throws JAXRPCException;
  
  QName getTypeQName(Class paramClass);
  
  QName getTypeQNameExact(Class paramClass);
  
  Class getClassForQName(QName paramQName);
  
  Class getClassForQName(QName paramQName, Class paramClass);
  
  Class[] getAllClasses();
  
  QName getXMLType(Class paramClass, QName paramQName, boolean paramBoolean) throws JAXRPCException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\TypeMapping.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */