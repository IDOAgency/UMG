package org.apache.axis.encoding;

import java.io.Serializable;
import javax.xml.rpc.encoding.TypeMappingRegistry;

public interface TypeMappingRegistry extends TypeMappingRegistry, Serializable {
  void delegate(TypeMappingRegistry paramTypeMappingRegistry);
  
  TypeMapping getOrMakeTypeMapping(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\TypeMappingRegistry.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */