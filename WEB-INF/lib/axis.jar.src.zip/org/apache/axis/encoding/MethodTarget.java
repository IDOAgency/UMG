package org.apache.axis.encoding;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.SAXException;

public class MethodTarget implements Target {
  protected static Log log = LogFactory.getLog(MethodTarget.class.getName());
  
  private Object targetObject;
  
  private Method targetMethod;
  
  private static final Class[] objArg = { Object.class };
  
  public MethodTarget(Object targetObject, Method targetMethod) {
    this.targetObject = targetObject;
    this.targetMethod = targetMethod;
  }
  
  public MethodTarget(Object targetObject, String methodName) throws NoSuchMethodException {
    this.targetObject = targetObject;
    Class cls = targetObject.getClass();
    this.targetMethod = cls.getMethod(methodName, objArg);
  }
  
  public void set(Object value) throws SAXException {
    try {
      this.targetMethod.invoke(this.targetObject, new Object[] { value });
    } catch (IllegalAccessException accEx) {
      log.error(Messages.getMessage("illegalAccessException00"), accEx);
      throw new SAXException(accEx);
    } catch (IllegalArgumentException argEx) {
      log.error(Messages.getMessage("illegalArgumentException00"), argEx);
      throw new SAXException(argEx);
    } catch (InvocationTargetException targetEx) {
      log.error(Messages.getMessage("invocationTargetException00"), targetEx);
      throw new SAXException(targetEx);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\MethodTarget.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */