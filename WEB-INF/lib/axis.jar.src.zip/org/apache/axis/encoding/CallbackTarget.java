/*    */ package org.apache.axis.encoding;
/*    */ 
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CallbackTarget
/*    */   implements Target
/*    */ {
/*    */   public Callback target;
/*    */   public Object hint;
/*    */   
/*    */   public CallbackTarget(Callback target, Object hint) {
/* 31 */     this.target = target;
/* 32 */     this.hint = hint;
/*    */   }
/*    */ 
/*    */   
/* 36 */   public void set(Object value) throws SAXException { this.target.setValue(value, this.hint); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\CallbackTarget.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */