package org.apache.axis.encoding;

import java.io.IOException;
import javax.xml.namespace.QName;
import javax.xml.rpc.encoding.Serializer;
import org.apache.axis.wsdl.fromJava.Types;
import org.w3c.dom.Element;
import org.xml.sax.Attributes;

public interface Serializer extends Serializer {
  void serialize(QName paramQName, Attributes paramAttributes, Object paramObject, SerializationContext paramSerializationContext) throws IOException;
  
  Element writeSchema(Class paramClass, Types paramTypes) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\Serializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */