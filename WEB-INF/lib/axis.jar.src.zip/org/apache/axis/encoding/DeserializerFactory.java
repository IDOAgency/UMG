package org.apache.axis.encoding;

import javax.xml.rpc.encoding.DeserializerFactory;

public interface DeserializerFactory extends DeserializerFactory {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\DeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */