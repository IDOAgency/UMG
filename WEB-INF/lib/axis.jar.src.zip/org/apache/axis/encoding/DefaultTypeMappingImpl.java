/*     */ package org.apache.axis.encoding;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.DeserializerFactory;
/*     */ import javax.xml.rpc.encoding.SerializerFactory;
/*     */ import org.apache.axis.Constants;
/*     */ import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.ArraySerializerFactory;
/*     */ import org.apache.axis.encoding.ser.Base64DeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.Base64SerializerFactory;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.BeanSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.DateDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.DateSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.DocumentDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.DocumentSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.ElementDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.ElementSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.HexDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.HexSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.JAFDataHandlerDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.JAFDataHandlerSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.MapDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.MapSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.QNameDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.QNameSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.VectorDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.VectorSerializerFactory;
/*     */ import org.apache.axis.schema.SchemaVersion;
/*     */ import org.apache.axis.utils.JavaUtils;
/*     */ import org.apache.axis.utils.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultTypeMappingImpl
/*     */   extends TypeMappingImpl
/*     */ {
/*  77 */   private static DefaultTypeMappingImpl tm = null;
/*     */   
/*     */   private boolean inInitMappings;
/*     */   
/*     */   static Class array$B;
/*     */   
/*     */   public static TypeMappingDelegate getSingletonDelegate() {
/*  84 */     if (tm == null) {
/*  85 */       tm = new DefaultTypeMappingImpl();
/*     */     }
/*  87 */     return new TypeMappingDelegate(tm);
/*     */   }
/*     */   protected DefaultTypeMappingImpl() {
/*     */     this.inInitMappings = false;
/*  91 */     initMappings();
/*     */   }
/*     */   protected DefaultTypeMappingImpl(boolean noMappings) {
/*     */     this.inInitMappings = false;
/*  95 */     if (!noMappings) {
/*  96 */       initMappings();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void initMappings() {
/* 101 */     this.inInitMappings = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     if (JavaUtils.isAttachmentSupported()) {
/* 120 */       myRegister(Constants.MIME_PLAINTEXT, String.class, new JAFDataHandlerSerializerFactory(String.class, Constants.MIME_PLAINTEXT), new JAFDataHandlerDeserializerFactory(String.class, Constants.MIME_PLAINTEXT));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     myRegister(Constants.XSD_HEXBIN, org.apache.axis.types.HexBinary.class, new HexSerializerFactory(org.apache.axis.types.HexBinary.class, Constants.XSD_HEXBIN), new HexDeserializerFactory(org.apache.axis.types.HexBinary.class, Constants.XSD_HEXBIN));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     myRegister(Constants.XSD_HEXBIN, (array$B == null) ? (array$B = class$("[B")) : array$B, new HexSerializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.XSD_HEXBIN), new HexDeserializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.XSD_HEXBIN));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     myRegister(Constants.XSD_BYTE, (array$B == null) ? (array$B = class$("[B")) : array$B, new ArraySerializerFactory(), null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     myRegister(Constants.XSD_BASE64, (array$B == null) ? (array$B = class$("[B")) : array$B, new Base64SerializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.XSD_BASE64), new Base64DeserializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.XSD_BASE64));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     myRegisterSimple(Constants.XSD_ANYSIMPLETYPE, String.class);
/*     */ 
/*     */     
/* 169 */     myRegisterSimple(Constants.XSD_STRING, String.class);
/* 170 */     myRegisterSimple(Constants.XSD_BOOLEAN, Boolean.class);
/* 171 */     myRegisterSimple(Constants.XSD_DOUBLE, Double.class);
/* 172 */     myRegisterSimple(Constants.XSD_FLOAT, Float.class);
/* 173 */     myRegisterSimple(Constants.XSD_INT, Integer.class);
/* 174 */     myRegisterSimple(Constants.XSD_INTEGER, java.math.BigInteger.class);
/*     */     
/* 176 */     myRegisterSimple(Constants.XSD_DECIMAL, java.math.BigDecimal.class);
/*     */     
/* 178 */     myRegisterSimple(Constants.XSD_LONG, Long.class);
/* 179 */     myRegisterSimple(Constants.XSD_SHORT, Short.class);
/* 180 */     myRegisterSimple(Constants.XSD_BYTE, Byte.class);
/*     */ 
/*     */     
/* 183 */     myRegisterSimple(Constants.XSD_BOOLEAN, boolean.class);
/* 184 */     myRegisterSimple(Constants.XSD_DOUBLE, double.class);
/* 185 */     myRegisterSimple(Constants.XSD_FLOAT, float.class);
/* 186 */     myRegisterSimple(Constants.XSD_INT, int.class);
/* 187 */     myRegisterSimple(Constants.XSD_LONG, long.class);
/* 188 */     myRegisterSimple(Constants.XSD_SHORT, short.class);
/* 189 */     myRegisterSimple(Constants.XSD_BYTE, byte.class);
/*     */ 
/*     */     
/* 192 */     myRegister(Constants.XSD_QNAME, QName.class, new QNameSerializerFactory(QName.class, Constants.XSD_QNAME), new QNameDeserializerFactory(QName.class, Constants.XSD_QNAME));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     myRegister(Constants.XSD_ANYTYPE, Object.class, null, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 206 */     myRegister(Constants.XSD_DATE, java.sql.Date.class, new DateSerializerFactory(java.sql.Date.class, Constants.XSD_DATE), new DateDeserializerFactory(java.sql.Date.class, Constants.XSD_DATE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     myRegister(Constants.XSD_DATE, java.util.Date.class, new DateSerializerFactory(java.util.Date.class, Constants.XSD_DATE), new DateDeserializerFactory(java.util.Date.class, Constants.XSD_DATE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     myRegister(Constants.XSD_TIME, org.apache.axis.types.Time.class, new SimpleSerializerFactory(org.apache.axis.types.Time.class, Constants.XSD_TIME), new SimpleDeserializerFactory(org.apache.axis.types.Time.class, Constants.XSD_TIME));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     myRegister(Constants.XSD_YEARMONTH, org.apache.axis.types.YearMonth.class, new SimpleSerializerFactory(org.apache.axis.types.YearMonth.class, Constants.XSD_YEARMONTH), new SimpleDeserializerFactory(org.apache.axis.types.YearMonth.class, Constants.XSD_YEARMONTH));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     myRegister(Constants.XSD_YEAR, org.apache.axis.types.Year.class, new SimpleSerializerFactory(org.apache.axis.types.Year.class, Constants.XSD_YEAR), new SimpleDeserializerFactory(org.apache.axis.types.Year.class, Constants.XSD_YEAR));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     myRegister(Constants.XSD_MONTH, org.apache.axis.types.Month.class, new SimpleSerializerFactory(org.apache.axis.types.Month.class, Constants.XSD_MONTH), new SimpleDeserializerFactory(org.apache.axis.types.Month.class, Constants.XSD_MONTH));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     myRegister(Constants.XSD_DAY, org.apache.axis.types.Day.class, new SimpleSerializerFactory(org.apache.axis.types.Day.class, Constants.XSD_DAY), new SimpleDeserializerFactory(org.apache.axis.types.Day.class, Constants.XSD_DAY));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     myRegister(Constants.XSD_MONTHDAY, org.apache.axis.types.MonthDay.class, new SimpleSerializerFactory(org.apache.axis.types.MonthDay.class, Constants.XSD_MONTHDAY), new SimpleDeserializerFactory(org.apache.axis.types.MonthDay.class, Constants.XSD_MONTHDAY));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     myRegister(Constants.SOAP_MAP, java.util.Hashtable.class, new MapSerializerFactory(java.util.Hashtable.class, Constants.SOAP_MAP), null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     myRegister(Constants.SOAP_MAP, java.util.Map.class, new MapSerializerFactory(java.util.Map.class, Constants.SOAP_MAP), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     myRegister(Constants.SOAP_MAP, java.util.HashMap.class, new MapSerializerFactory(java.util.Map.class, Constants.SOAP_MAP), new MapDeserializerFactory(java.util.HashMap.class, Constants.SOAP_MAP));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     myRegister(Constants.SOAP_ELEMENT, org.w3c.dom.Element.class, new ElementSerializerFactory(), new ElementDeserializerFactory());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 287 */     myRegister(Constants.SOAP_DOCUMENT, org.w3c.dom.Document.class, new DocumentSerializerFactory(), new DocumentDeserializerFactory());
/*     */ 
/*     */ 
/*     */     
/* 291 */     myRegister(Constants.SOAP_VECTOR, java.util.Vector.class, new VectorSerializerFactory(java.util.Vector.class, Constants.SOAP_VECTOR), new VectorDeserializerFactory(java.util.Vector.class, Constants.SOAP_VECTOR));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 300 */     if (JavaUtils.isAttachmentSupported()) {
/* 301 */       myRegister(Constants.MIME_IMAGE, java.awt.Image.class, new JAFDataHandlerSerializerFactory(java.awt.Image.class, Constants.MIME_IMAGE), new JAFDataHandlerDeserializerFactory(java.awt.Image.class, Constants.MIME_IMAGE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 308 */       myRegister(Constants.MIME_MULTIPART, javax.mail.internet.MimeMultipart.class, new JAFDataHandlerSerializerFactory(javax.mail.internet.MimeMultipart.class, Constants.MIME_MULTIPART), new JAFDataHandlerDeserializerFactory(javax.mail.internet.MimeMultipart.class, Constants.MIME_MULTIPART));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 315 */       myRegister(Constants.MIME_SOURCE, javax.xml.transform.Source.class, new JAFDataHandlerSerializerFactory(javax.xml.transform.Source.class, Constants.MIME_SOURCE), new JAFDataHandlerDeserializerFactory(javax.xml.transform.Source.class, Constants.MIME_SOURCE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 322 */       myRegister(Constants.MIME_OCTETSTREAM, org.apache.axis.attachments.OctetStream.class, new JAFDataHandlerSerializerFactory(org.apache.axis.attachments.OctetStream.class, Constants.MIME_OCTETSTREAM), new JAFDataHandlerDeserializerFactory(org.apache.axis.attachments.OctetStream.class, Constants.MIME_OCTETSTREAM));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 329 */       myRegister(Constants.MIME_DATA_HANDLER, javax.activation.DataHandler.class, new JAFDataHandlerSerializerFactory(), new JAFDataHandlerDeserializerFactory());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     myRegister(Constants.XSD_TOKEN, org.apache.axis.types.Token.class, new SimpleSerializerFactory(org.apache.axis.types.Token.class, Constants.XSD_TOKEN), new SimpleDeserializerFactory(org.apache.axis.types.Token.class, Constants.XSD_TOKEN));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 343 */     myRegister(Constants.XSD_NORMALIZEDSTRING, org.apache.axis.types.NormalizedString.class, new SimpleSerializerFactory(org.apache.axis.types.NormalizedString.class, Constants.XSD_NORMALIZEDSTRING), new SimpleDeserializerFactory(org.apache.axis.types.NormalizedString.class, Constants.XSD_NORMALIZEDSTRING));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 351 */     myRegister(Constants.XSD_UNSIGNEDLONG, org.apache.axis.types.UnsignedLong.class, new SimpleSerializerFactory(org.apache.axis.types.UnsignedLong.class, Constants.XSD_UNSIGNEDLONG), new SimpleDeserializerFactory(org.apache.axis.types.UnsignedLong.class, Constants.XSD_UNSIGNEDLONG));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 359 */     myRegister(Constants.XSD_UNSIGNEDINT, org.apache.axis.types.UnsignedInt.class, new SimpleSerializerFactory(org.apache.axis.types.UnsignedInt.class, Constants.XSD_UNSIGNEDINT), new SimpleDeserializerFactory(org.apache.axis.types.UnsignedInt.class, Constants.XSD_UNSIGNEDINT));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     myRegister(Constants.XSD_UNSIGNEDSHORT, org.apache.axis.types.UnsignedShort.class, new SimpleSerializerFactory(org.apache.axis.types.UnsignedShort.class, Constants.XSD_UNSIGNEDSHORT), new SimpleDeserializerFactory(org.apache.axis.types.UnsignedShort.class, Constants.XSD_UNSIGNEDSHORT));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 375 */     myRegister(Constants.XSD_UNSIGNEDBYTE, org.apache.axis.types.UnsignedByte.class, new SimpleSerializerFactory(org.apache.axis.types.UnsignedByte.class, Constants.XSD_UNSIGNEDBYTE), new SimpleDeserializerFactory(org.apache.axis.types.UnsignedByte.class, Constants.XSD_UNSIGNEDBYTE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 383 */     myRegister(Constants.XSD_NONNEGATIVEINTEGER, org.apache.axis.types.NonNegativeInteger.class, new SimpleSerializerFactory(org.apache.axis.types.NonNegativeInteger.class, Constants.XSD_NONNEGATIVEINTEGER), new SimpleDeserializerFactory(org.apache.axis.types.NonNegativeInteger.class, Constants.XSD_NONNEGATIVEINTEGER));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 391 */     myRegister(Constants.XSD_NEGATIVEINTEGER, org.apache.axis.types.NegativeInteger.class, new SimpleSerializerFactory(org.apache.axis.types.NegativeInteger.class, Constants.XSD_NEGATIVEINTEGER), new SimpleDeserializerFactory(org.apache.axis.types.NegativeInteger.class, Constants.XSD_NEGATIVEINTEGER));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 399 */     myRegister(Constants.XSD_POSITIVEINTEGER, org.apache.axis.types.PositiveInteger.class, new SimpleSerializerFactory(org.apache.axis.types.PositiveInteger.class, Constants.XSD_POSITIVEINTEGER), new SimpleDeserializerFactory(org.apache.axis.types.PositiveInteger.class, Constants.XSD_POSITIVEINTEGER));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 407 */     myRegister(Constants.XSD_NONPOSITIVEINTEGER, org.apache.axis.types.NonPositiveInteger.class, new SimpleSerializerFactory(org.apache.axis.types.NonPositiveInteger.class, Constants.XSD_NONPOSITIVEINTEGER), new SimpleDeserializerFactory(org.apache.axis.types.NonPositiveInteger.class, Constants.XSD_NONPOSITIVEINTEGER));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 415 */     myRegister(Constants.XSD_NAME, org.apache.axis.types.Name.class, new SimpleSerializerFactory(org.apache.axis.types.Name.class, Constants.XSD_NAME), new SimpleDeserializerFactory(org.apache.axis.types.Name.class, Constants.XSD_NAME));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 423 */     myRegister(Constants.XSD_NCNAME, org.apache.axis.types.NCName.class, new SimpleSerializerFactory(org.apache.axis.types.NCName.class, Constants.XSD_NCNAME), new SimpleDeserializerFactory(org.apache.axis.types.NCName.class, Constants.XSD_NCNAME));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 431 */     myRegister(Constants.XSD_ID, org.apache.axis.types.Id.class, new SimpleSerializerFactory(org.apache.axis.types.Id.class, Constants.XSD_ID), new SimpleDeserializerFactory(org.apache.axis.types.Id.class, Constants.XSD_ID));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 439 */     myRegister(Constants.XML_LANG, org.apache.axis.types.Language.class, new SimpleSerializerFactory(org.apache.axis.types.Language.class, Constants.XML_LANG), new SimpleDeserializerFactory(org.apache.axis.types.Language.class, Constants.XML_LANG));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 447 */     myRegister(Constants.XSD_LANGUAGE, org.apache.axis.types.Language.class, new SimpleSerializerFactory(org.apache.axis.types.Language.class, Constants.XSD_LANGUAGE), new SimpleDeserializerFactory(org.apache.axis.types.Language.class, Constants.XSD_LANGUAGE));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 455 */     myRegister(Constants.XSD_NMTOKEN, org.apache.axis.types.NMToken.class, new SimpleSerializerFactory(org.apache.axis.types.NMToken.class, Constants.XSD_NMTOKEN), new SimpleDeserializerFactory(org.apache.axis.types.NMToken.class, Constants.XSD_NMTOKEN));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     myRegister(Constants.XSD_NMTOKENS, org.apache.axis.types.NMTokens.class, new SimpleSerializerFactory(org.apache.axis.types.NMTokens.class, Constants.XSD_NMTOKENS), new SimpleDeserializerFactory(org.apache.axis.types.NMTokens.class, Constants.XSD_NMTOKENS));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 471 */     myRegister(Constants.XSD_NOTATION, org.apache.axis.types.Notation.class, new BeanSerializerFactory(org.apache.axis.types.Notation.class, Constants.XSD_NOTATION), new BeanDeserializerFactory(org.apache.axis.types.Notation.class, Constants.XSD_NOTATION));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 479 */     myRegister(Constants.XSD_ENTITY, org.apache.axis.types.Entity.class, new SimpleSerializerFactory(org.apache.axis.types.Entity.class, Constants.XSD_ENTITY), new SimpleDeserializerFactory(org.apache.axis.types.Entity.class, Constants.XSD_ENTITY));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 487 */     myRegister(Constants.XSD_ENTITIES, org.apache.axis.types.Entities.class, new SimpleSerializerFactory(org.apache.axis.types.Entities.class, Constants.XSD_ENTITIES), new SimpleDeserializerFactory(org.apache.axis.types.Entities.class, Constants.XSD_ENTITIES));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 495 */     myRegister(Constants.XSD_IDREF, org.apache.axis.types.IDRef.class, new SimpleSerializerFactory(org.apache.axis.types.IDRef.class, Constants.XSD_IDREF), new SimpleDeserializerFactory(org.apache.axis.types.IDRef.class, Constants.XSD_IDREF));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 503 */     myRegister(Constants.XSD_IDREFS, org.apache.axis.types.IDRefs.class, new SimpleSerializerFactory(org.apache.axis.types.IDRefs.class, Constants.XSD_IDREFS), new SimpleDeserializerFactory(org.apache.axis.types.IDRefs.class, Constants.XSD_IDREFS));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 511 */     myRegister(Constants.XSD_DURATION, org.apache.axis.types.Duration.class, new SimpleSerializerFactory(org.apache.axis.types.Duration.class, Constants.XSD_DURATION), new SimpleDeserializerFactory(org.apache.axis.types.Duration.class, Constants.XSD_DURATION));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 519 */     myRegister(Constants.XSD_ANYURI, org.apache.axis.types.URI.class, new SimpleSerializerFactory(org.apache.axis.types.URI.class, Constants.XSD_ANYURI), new SimpleDeserializerFactory(org.apache.axis.types.URI.class, Constants.XSD_ANYURI));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 527 */     myRegister(Constants.XSD_SCHEMA, org.apache.axis.types.Schema.class, new BeanSerializerFactory(org.apache.axis.types.Schema.class, Constants.XSD_SCHEMA), new BeanDeserializerFactory(org.apache.axis.types.Schema.class, Constants.XSD_SCHEMA));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 538 */     myRegister(Constants.SOAP_ARRAY, java.util.ArrayList.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 546 */     SchemaVersion.SCHEMA_1999.registerSchemaSpecificTypes(this);
/* 547 */     SchemaVersion.SCHEMA_2000.registerSchemaSpecificTypes(this);
/* 548 */     SchemaVersion.SCHEMA_2001.registerSchemaSpecificTypes(this);
/*     */     
/* 550 */     this.inInitMappings = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void myRegisterSimple(QName xmlType, Class javaType) {
/* 559 */     SimpleSerializerFactory simpleSerializerFactory = new SimpleSerializerFactory(javaType, xmlType);
/* 560 */     SimpleDeserializerFactory simpleDeserializerFactory = null;
/* 561 */     if (javaType != Object.class) {
/* 562 */       simpleDeserializerFactory = new SimpleDeserializerFactory(javaType, xmlType);
/*     */     }
/*     */     
/* 565 */     myRegister(xmlType, javaType, simpleSerializerFactory, simpleDeserializerFactory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void myRegister(QName xmlType, Class javaType, SerializerFactory sf, DeserializerFactory df) {
/*     */     try {
/* 584 */       if (xmlType.getNamespaceURI().equals("http://www.w3.org/2001/XMLSchema")) {
/*     */         
/* 586 */         for (int i = 0; i < Constants.URIS_SCHEMA_XSD.length; i++) {
/* 587 */           QName qName = new QName(Constants.URIS_SCHEMA_XSD[i], xmlType.getLocalPart());
/*     */           
/* 589 */           internalRegister(javaType, qName, sf, df);
/*     */         }
/*     */       
/* 592 */       } else if (xmlType.getNamespaceURI().equals(Constants.URI_DEFAULT_SOAP_ENC)) {
/*     */         
/* 594 */         for (int i = 0; i < Constants.URIS_SOAP_ENC.length; i++) {
/* 595 */           QName qName = new QName(Constants.URIS_SOAP_ENC[i], xmlType.getLocalPart());
/*     */           
/* 597 */           internalRegister(javaType, qName, sf, df);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 602 */         internalRegister(javaType, xmlType, sf, df);
/*     */       } 
/* 604 */     } catch (JAXRPCException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 613 */   public void register(Class javaType, QName xmlType, SerializerFactory sf, DeserializerFactory dsf) throws JAXRPCException { super.register(javaType, xmlType, sf, dsf); }
/*     */ 
/*     */ 
/*     */   
/* 617 */   public void removeSerializer(Class javaType, QName xmlType) throws JAXRPCException { throw new JAXRPCException(Messages.getMessage("fixedTypeMapping")); }
/*     */ 
/*     */ 
/*     */   
/* 621 */   public void removeDeserializer(Class javaType, QName xmlType) throws JAXRPCException { throw new JAXRPCException(Messages.getMessage("fixedTypeMapping")); }
/*     */   
/*     */   public void setSupportedEncodings(String[] namespaceURIs) {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\DefaultTypeMappingImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */