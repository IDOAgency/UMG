package org.apache.axis.encoding;

import javax.xml.namespace.QName;
import javax.xml.rpc.JAXRPCException;
import javax.xml.rpc.encoding.DeserializerFactory;
import javax.xml.rpc.encoding.SerializerFactory;
import org.apache.axis.Constants;
import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
import org.apache.axis.encoding.ser.ArraySerializerFactory;
import org.apache.axis.encoding.ser.Base64DeserializerFactory;
import org.apache.axis.encoding.ser.Base64SerializerFactory;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;
import org.apache.axis.encoding.ser.BeanSerializerFactory;
import org.apache.axis.encoding.ser.DateDeserializerFactory;
import org.apache.axis.encoding.ser.DateSerializerFactory;
import org.apache.axis.encoding.ser.DocumentDeserializerFactory;
import org.apache.axis.encoding.ser.DocumentSerializerFactory;
import org.apache.axis.encoding.ser.ElementDeserializerFactory;
import org.apache.axis.encoding.ser.ElementSerializerFactory;
import org.apache.axis.encoding.ser.HexDeserializerFactory;
import org.apache.axis.encoding.ser.HexSerializerFactory;
import org.apache.axis.encoding.ser.JAFDataHandlerDeserializerFactory;
import org.apache.axis.encoding.ser.JAFDataHandlerSerializerFactory;
import org.apache.axis.encoding.ser.MapDeserializerFactory;
import org.apache.axis.encoding.ser.MapSerializerFactory;
import org.apache.axis.encoding.ser.QNameDeserializerFactory;
import org.apache.axis.encoding.ser.QNameSerializerFactory;
import org.apache.axis.encoding.ser.SimpleDeserializerFactory;
import org.apache.axis.encoding.ser.SimpleSerializerFactory;
import org.apache.axis.encoding.ser.VectorDeserializerFactory;
import org.apache.axis.encoding.ser.VectorSerializerFactory;
import org.apache.axis.schema.SchemaVersion;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.Messages;

public class DefaultTypeMappingImpl extends TypeMappingImpl {
  private static DefaultTypeMappingImpl tm = null;
  
  private boolean inInitMappings;
  
  static Class array$B;
  
  public static TypeMappingDelegate getSingletonDelegate() {
    if (tm == null)
      tm = new DefaultTypeMappingImpl(); 
    return new TypeMappingDelegate(tm);
  }
  
  protected DefaultTypeMappingImpl() {
    this.inInitMappings = false;
    initMappings();
  }
  
  protected DefaultTypeMappingImpl(boolean noMappings) {
    this.inInitMappings = false;
    if (!noMappings)
      initMappings(); 
  }
  
  protected void initMappings() {
    this.inInitMappings = true;
    if (JavaUtils.isAttachmentSupported())
      myRegister(Constants.MIME_PLAINTEXT, String.class, new JAFDataHandlerSerializerFactory(String.class, Constants.MIME_PLAINTEXT), new JAFDataHandlerDeserializerFactory(String.class, Constants.MIME_PLAINTEXT)); 
    myRegister(Constants.XSD_HEXBIN, org.apache.axis.types.HexBinary.class, new HexSerializerFactory(org.apache.axis.types.HexBinary.class, Constants.XSD_HEXBIN), new HexDeserializerFactory(org.apache.axis.types.HexBinary.class, Constants.XSD_HEXBIN));
    myRegister(Constants.XSD_HEXBIN, (array$B == null) ? (array$B = class$("[B")) : array$B, new HexSerializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.XSD_HEXBIN), new HexDeserializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.XSD_HEXBIN));
    myRegister(Constants.XSD_BYTE, (array$B == null) ? (array$B = class$("[B")) : array$B, new ArraySerializerFactory(), null);
    myRegister(Constants.XSD_BASE64, (array$B == null) ? (array$B = class$("[B")) : array$B, new Base64SerializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.XSD_BASE64), new Base64DeserializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.XSD_BASE64));
    myRegisterSimple(Constants.XSD_ANYSIMPLETYPE, String.class);
    myRegisterSimple(Constants.XSD_STRING, String.class);
    myRegisterSimple(Constants.XSD_BOOLEAN, Boolean.class);
    myRegisterSimple(Constants.XSD_DOUBLE, Double.class);
    myRegisterSimple(Constants.XSD_FLOAT, Float.class);
    myRegisterSimple(Constants.XSD_INT, Integer.class);
    myRegisterSimple(Constants.XSD_INTEGER, java.math.BigInteger.class);
    myRegisterSimple(Constants.XSD_DECIMAL, java.math.BigDecimal.class);
    myRegisterSimple(Constants.XSD_LONG, Long.class);
    myRegisterSimple(Constants.XSD_SHORT, Short.class);
    myRegisterSimple(Constants.XSD_BYTE, Byte.class);
    myRegisterSimple(Constants.XSD_BOOLEAN, boolean.class);
    myRegisterSimple(Constants.XSD_DOUBLE, double.class);
    myRegisterSimple(Constants.XSD_FLOAT, float.class);
    myRegisterSimple(Constants.XSD_INT, int.class);
    myRegisterSimple(Constants.XSD_LONG, long.class);
    myRegisterSimple(Constants.XSD_SHORT, short.class);
    myRegisterSimple(Constants.XSD_BYTE, byte.class);
    myRegister(Constants.XSD_QNAME, QName.class, new QNameSerializerFactory(QName.class, Constants.XSD_QNAME), new QNameDeserializerFactory(QName.class, Constants.XSD_QNAME));
    myRegister(Constants.XSD_ANYTYPE, Object.class, null, null);
    myRegister(Constants.XSD_DATE, java.sql.Date.class, new DateSerializerFactory(java.sql.Date.class, Constants.XSD_DATE), new DateDeserializerFactory(java.sql.Date.class, Constants.XSD_DATE));
    myRegister(Constants.XSD_DATE, java.util.Date.class, new DateSerializerFactory(java.util.Date.class, Constants.XSD_DATE), new DateDeserializerFactory(java.util.Date.class, Constants.XSD_DATE));
    myRegister(Constants.XSD_TIME, org.apache.axis.types.Time.class, new SimpleSerializerFactory(org.apache.axis.types.Time.class, Constants.XSD_TIME), new SimpleDeserializerFactory(org.apache.axis.types.Time.class, Constants.XSD_TIME));
    myRegister(Constants.XSD_YEARMONTH, org.apache.axis.types.YearMonth.class, new SimpleSerializerFactory(org.apache.axis.types.YearMonth.class, Constants.XSD_YEARMONTH), new SimpleDeserializerFactory(org.apache.axis.types.YearMonth.class, Constants.XSD_YEARMONTH));
    myRegister(Constants.XSD_YEAR, org.apache.axis.types.Year.class, new SimpleSerializerFactory(org.apache.axis.types.Year.class, Constants.XSD_YEAR), new SimpleDeserializerFactory(org.apache.axis.types.Year.class, Constants.XSD_YEAR));
    myRegister(Constants.XSD_MONTH, org.apache.axis.types.Month.class, new SimpleSerializerFactory(org.apache.axis.types.Month.class, Constants.XSD_MONTH), new SimpleDeserializerFactory(org.apache.axis.types.Month.class, Constants.XSD_MONTH));
    myRegister(Constants.XSD_DAY, org.apache.axis.types.Day.class, new SimpleSerializerFactory(org.apache.axis.types.Day.class, Constants.XSD_DAY), new SimpleDeserializerFactory(org.apache.axis.types.Day.class, Constants.XSD_DAY));
    myRegister(Constants.XSD_MONTHDAY, org.apache.axis.types.MonthDay.class, new SimpleSerializerFactory(org.apache.axis.types.MonthDay.class, Constants.XSD_MONTHDAY), new SimpleDeserializerFactory(org.apache.axis.types.MonthDay.class, Constants.XSD_MONTHDAY));
    myRegister(Constants.SOAP_MAP, java.util.Hashtable.class, new MapSerializerFactory(java.util.Hashtable.class, Constants.SOAP_MAP), null);
    myRegister(Constants.SOAP_MAP, java.util.Map.class, new MapSerializerFactory(java.util.Map.class, Constants.SOAP_MAP), null);
    myRegister(Constants.SOAP_MAP, java.util.HashMap.class, new MapSerializerFactory(java.util.Map.class, Constants.SOAP_MAP), new MapDeserializerFactory(java.util.HashMap.class, Constants.SOAP_MAP));
    myRegister(Constants.SOAP_ELEMENT, org.w3c.dom.Element.class, new ElementSerializerFactory(), new ElementDeserializerFactory());
    myRegister(Constants.SOAP_DOCUMENT, org.w3c.dom.Document.class, new DocumentSerializerFactory(), new DocumentDeserializerFactory());
    myRegister(Constants.SOAP_VECTOR, java.util.Vector.class, new VectorSerializerFactory(java.util.Vector.class, Constants.SOAP_VECTOR), new VectorDeserializerFactory(java.util.Vector.class, Constants.SOAP_VECTOR));
    if (JavaUtils.isAttachmentSupported()) {
      myRegister(Constants.MIME_IMAGE, java.awt.Image.class, new JAFDataHandlerSerializerFactory(java.awt.Image.class, Constants.MIME_IMAGE), new JAFDataHandlerDeserializerFactory(java.awt.Image.class, Constants.MIME_IMAGE));
      myRegister(Constants.MIME_MULTIPART, javax.mail.internet.MimeMultipart.class, new JAFDataHandlerSerializerFactory(javax.mail.internet.MimeMultipart.class, Constants.MIME_MULTIPART), new JAFDataHandlerDeserializerFactory(javax.mail.internet.MimeMultipart.class, Constants.MIME_MULTIPART));
      myRegister(Constants.MIME_SOURCE, javax.xml.transform.Source.class, new JAFDataHandlerSerializerFactory(javax.xml.transform.Source.class, Constants.MIME_SOURCE), new JAFDataHandlerDeserializerFactory(javax.xml.transform.Source.class, Constants.MIME_SOURCE));
      myRegister(Constants.MIME_OCTETSTREAM, org.apache.axis.attachments.OctetStream.class, new JAFDataHandlerSerializerFactory(org.apache.axis.attachments.OctetStream.class, Constants.MIME_OCTETSTREAM), new JAFDataHandlerDeserializerFactory(org.apache.axis.attachments.OctetStream.class, Constants.MIME_OCTETSTREAM));
      myRegister(Constants.MIME_DATA_HANDLER, javax.activation.DataHandler.class, new JAFDataHandlerSerializerFactory(), new JAFDataHandlerDeserializerFactory());
    } 
    myRegister(Constants.XSD_TOKEN, org.apache.axis.types.Token.class, new SimpleSerializerFactory(org.apache.axis.types.Token.class, Constants.XSD_TOKEN), new SimpleDeserializerFactory(org.apache.axis.types.Token.class, Constants.XSD_TOKEN));
    myRegister(Constants.XSD_NORMALIZEDSTRING, org.apache.axis.types.NormalizedString.class, new SimpleSerializerFactory(org.apache.axis.types.NormalizedString.class, Constants.XSD_NORMALIZEDSTRING), new SimpleDeserializerFactory(org.apache.axis.types.NormalizedString.class, Constants.XSD_NORMALIZEDSTRING));
    myRegister(Constants.XSD_UNSIGNEDLONG, org.apache.axis.types.UnsignedLong.class, new SimpleSerializerFactory(org.apache.axis.types.UnsignedLong.class, Constants.XSD_UNSIGNEDLONG), new SimpleDeserializerFactory(org.apache.axis.types.UnsignedLong.class, Constants.XSD_UNSIGNEDLONG));
    myRegister(Constants.XSD_UNSIGNEDINT, org.apache.axis.types.UnsignedInt.class, new SimpleSerializerFactory(org.apache.axis.types.UnsignedInt.class, Constants.XSD_UNSIGNEDINT), new SimpleDeserializerFactory(org.apache.axis.types.UnsignedInt.class, Constants.XSD_UNSIGNEDINT));
    myRegister(Constants.XSD_UNSIGNEDSHORT, org.apache.axis.types.UnsignedShort.class, new SimpleSerializerFactory(org.apache.axis.types.UnsignedShort.class, Constants.XSD_UNSIGNEDSHORT), new SimpleDeserializerFactory(org.apache.axis.types.UnsignedShort.class, Constants.XSD_UNSIGNEDSHORT));
    myRegister(Constants.XSD_UNSIGNEDBYTE, org.apache.axis.types.UnsignedByte.class, new SimpleSerializerFactory(org.apache.axis.types.UnsignedByte.class, Constants.XSD_UNSIGNEDBYTE), new SimpleDeserializerFactory(org.apache.axis.types.UnsignedByte.class, Constants.XSD_UNSIGNEDBYTE));
    myRegister(Constants.XSD_NONNEGATIVEINTEGER, org.apache.axis.types.NonNegativeInteger.class, new SimpleSerializerFactory(org.apache.axis.types.NonNegativeInteger.class, Constants.XSD_NONNEGATIVEINTEGER), new SimpleDeserializerFactory(org.apache.axis.types.NonNegativeInteger.class, Constants.XSD_NONNEGATIVEINTEGER));
    myRegister(Constants.XSD_NEGATIVEINTEGER, org.apache.axis.types.NegativeInteger.class, new SimpleSerializerFactory(org.apache.axis.types.NegativeInteger.class, Constants.XSD_NEGATIVEINTEGER), new SimpleDeserializerFactory(org.apache.axis.types.NegativeInteger.class, Constants.XSD_NEGATIVEINTEGER));
    myRegister(Constants.XSD_POSITIVEINTEGER, org.apache.axis.types.PositiveInteger.class, new SimpleSerializerFactory(org.apache.axis.types.PositiveInteger.class, Constants.XSD_POSITIVEINTEGER), new SimpleDeserializerFactory(org.apache.axis.types.PositiveInteger.class, Constants.XSD_POSITIVEINTEGER));
    myRegister(Constants.XSD_NONPOSITIVEINTEGER, org.apache.axis.types.NonPositiveInteger.class, new SimpleSerializerFactory(org.apache.axis.types.NonPositiveInteger.class, Constants.XSD_NONPOSITIVEINTEGER), new SimpleDeserializerFactory(org.apache.axis.types.NonPositiveInteger.class, Constants.XSD_NONPOSITIVEINTEGER));
    myRegister(Constants.XSD_NAME, org.apache.axis.types.Name.class, new SimpleSerializerFactory(org.apache.axis.types.Name.class, Constants.XSD_NAME), new SimpleDeserializerFactory(org.apache.axis.types.Name.class, Constants.XSD_NAME));
    myRegister(Constants.XSD_NCNAME, org.apache.axis.types.NCName.class, new SimpleSerializerFactory(org.apache.axis.types.NCName.class, Constants.XSD_NCNAME), new SimpleDeserializerFactory(org.apache.axis.types.NCName.class, Constants.XSD_NCNAME));
    myRegister(Constants.XSD_ID, org.apache.axis.types.Id.class, new SimpleSerializerFactory(org.apache.axis.types.Id.class, Constants.XSD_ID), new SimpleDeserializerFactory(org.apache.axis.types.Id.class, Constants.XSD_ID));
    myRegister(Constants.XML_LANG, org.apache.axis.types.Language.class, new SimpleSerializerFactory(org.apache.axis.types.Language.class, Constants.XML_LANG), new SimpleDeserializerFactory(org.apache.axis.types.Language.class, Constants.XML_LANG));
    myRegister(Constants.XSD_LANGUAGE, org.apache.axis.types.Language.class, new SimpleSerializerFactory(org.apache.axis.types.Language.class, Constants.XSD_LANGUAGE), new SimpleDeserializerFactory(org.apache.axis.types.Language.class, Constants.XSD_LANGUAGE));
    myRegister(Constants.XSD_NMTOKEN, org.apache.axis.types.NMToken.class, new SimpleSerializerFactory(org.apache.axis.types.NMToken.class, Constants.XSD_NMTOKEN), new SimpleDeserializerFactory(org.apache.axis.types.NMToken.class, Constants.XSD_NMTOKEN));
    myRegister(Constants.XSD_NMTOKENS, org.apache.axis.types.NMTokens.class, new SimpleSerializerFactory(org.apache.axis.types.NMTokens.class, Constants.XSD_NMTOKENS), new SimpleDeserializerFactory(org.apache.axis.types.NMTokens.class, Constants.XSD_NMTOKENS));
    myRegister(Constants.XSD_NOTATION, org.apache.axis.types.Notation.class, new BeanSerializerFactory(org.apache.axis.types.Notation.class, Constants.XSD_NOTATION), new BeanDeserializerFactory(org.apache.axis.types.Notation.class, Constants.XSD_NOTATION));
    myRegister(Constants.XSD_ENTITY, org.apache.axis.types.Entity.class, new SimpleSerializerFactory(org.apache.axis.types.Entity.class, Constants.XSD_ENTITY), new SimpleDeserializerFactory(org.apache.axis.types.Entity.class, Constants.XSD_ENTITY));
    myRegister(Constants.XSD_ENTITIES, org.apache.axis.types.Entities.class, new SimpleSerializerFactory(org.apache.axis.types.Entities.class, Constants.XSD_ENTITIES), new SimpleDeserializerFactory(org.apache.axis.types.Entities.class, Constants.XSD_ENTITIES));
    myRegister(Constants.XSD_IDREF, org.apache.axis.types.IDRef.class, new SimpleSerializerFactory(org.apache.axis.types.IDRef.class, Constants.XSD_IDREF), new SimpleDeserializerFactory(org.apache.axis.types.IDRef.class, Constants.XSD_IDREF));
    myRegister(Constants.XSD_IDREFS, org.apache.axis.types.IDRefs.class, new SimpleSerializerFactory(org.apache.axis.types.IDRefs.class, Constants.XSD_IDREFS), new SimpleDeserializerFactory(org.apache.axis.types.IDRefs.class, Constants.XSD_IDREFS));
    myRegister(Constants.XSD_DURATION, org.apache.axis.types.Duration.class, new SimpleSerializerFactory(org.apache.axis.types.Duration.class, Constants.XSD_DURATION), new SimpleDeserializerFactory(org.apache.axis.types.Duration.class, Constants.XSD_DURATION));
    myRegister(Constants.XSD_ANYURI, org.apache.axis.types.URI.class, new SimpleSerializerFactory(org.apache.axis.types.URI.class, Constants.XSD_ANYURI), new SimpleDeserializerFactory(org.apache.axis.types.URI.class, Constants.XSD_ANYURI));
    myRegister(Constants.XSD_SCHEMA, org.apache.axis.types.Schema.class, new BeanSerializerFactory(org.apache.axis.types.Schema.class, Constants.XSD_SCHEMA), new BeanDeserializerFactory(org.apache.axis.types.Schema.class, Constants.XSD_SCHEMA));
    myRegister(Constants.SOAP_ARRAY, java.util.ArrayList.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
    SchemaVersion.SCHEMA_1999.registerSchemaSpecificTypes(this);
    SchemaVersion.SCHEMA_2000.registerSchemaSpecificTypes(this);
    SchemaVersion.SCHEMA_2001.registerSchemaSpecificTypes(this);
    this.inInitMappings = false;
  }
  
  protected void myRegisterSimple(QName xmlType, Class javaType) {
    SimpleSerializerFactory simpleSerializerFactory = new SimpleSerializerFactory(javaType, xmlType);
    SimpleDeserializerFactory simpleDeserializerFactory = null;
    if (javaType != Object.class)
      simpleDeserializerFactory = new SimpleDeserializerFactory(javaType, xmlType); 
    myRegister(xmlType, javaType, simpleSerializerFactory, simpleDeserializerFactory);
  }
  
  protected void myRegister(QName xmlType, Class javaType, SerializerFactory sf, DeserializerFactory df) {
    try {
      if (xmlType.getNamespaceURI().equals("http://www.w3.org/2001/XMLSchema")) {
        for (int i = 0; i < Constants.URIS_SCHEMA_XSD.length; i++) {
          QName qName = new QName(Constants.URIS_SCHEMA_XSD[i], xmlType.getLocalPart());
          internalRegister(javaType, qName, sf, df);
        } 
      } else if (xmlType.getNamespaceURI().equals(Constants.URI_DEFAULT_SOAP_ENC)) {
        for (int i = 0; i < Constants.URIS_SOAP_ENC.length; i++) {
          QName qName = new QName(Constants.URIS_SOAP_ENC[i], xmlType.getLocalPart());
          internalRegister(javaType, qName, sf, df);
        } 
      } else {
        internalRegister(javaType, xmlType, sf, df);
      } 
    } catch (JAXRPCException e) {}
  }
  
  public void register(Class javaType, QName xmlType, SerializerFactory sf, DeserializerFactory dsf) throws JAXRPCException { super.register(javaType, xmlType, sf, dsf); }
  
  public void removeSerializer(Class javaType, QName xmlType) throws JAXRPCException { throw new JAXRPCException(Messages.getMessage("fixedTypeMapping")); }
  
  public void removeDeserializer(Class javaType, QName xmlType) throws JAXRPCException { throw new JAXRPCException(Messages.getMessage("fixedTypeMapping")); }
  
  public void setSupportedEncodings(String[] namespaceURIs) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\DefaultTypeMappingImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */