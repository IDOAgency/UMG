package org.apache.axis.encoding;

import org.apache.axis.Constants;
import org.apache.axis.MessageContext;
import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
import org.apache.axis.encoding.ser.ArraySerializerFactory;
import org.apache.axis.encoding.ser.Base64DeserializerFactory;
import org.apache.axis.encoding.ser.Base64SerializerFactory;

public class DefaultSOAPEncodingTypeMappingImpl extends DefaultTypeMappingImpl {
  private static DefaultSOAPEncodingTypeMappingImpl tm = null;
  
  static Class array$B;
  
  static Class array$Ljava$lang$Object;
  
  public static TypeMappingImpl getSingleton() {
    if (tm == null)
      tm = new DefaultSOAPEncodingTypeMappingImpl(); 
    return tm;
  }
  
  public static TypeMappingDelegate createWithDelegate() {
    ret = new TypeMappingDelegate(new DefaultSOAPEncodingTypeMappingImpl());
    MessageContext mc = MessageContext.getCurrentContext();
    TypeMappingDelegate tm = null;
    if (mc != null) {
      tm = (TypeMappingDelegate)mc.getTypeMappingRegistry().getDefaultTypeMapping();
    } else {
      tm = DefaultTypeMappingImpl.getSingletonDelegate();
    } 
    ret.setNext(tm);
    return ret;
  }
  
  protected DefaultSOAPEncodingTypeMappingImpl() {
    super(true);
    registerSOAPTypes();
  }
  
  private void registerSOAPTypes() {
    myRegisterSimple(Constants.SOAP_STRING, String.class);
    myRegisterSimple(Constants.SOAP_BOOLEAN, Boolean.class);
    myRegisterSimple(Constants.SOAP_DOUBLE, Double.class);
    myRegisterSimple(Constants.SOAP_FLOAT, Float.class);
    myRegisterSimple(Constants.SOAP_INT, Integer.class);
    myRegisterSimple(Constants.SOAP_INTEGER, java.math.BigInteger.class);
    myRegisterSimple(Constants.SOAP_DECIMAL, java.math.BigDecimal.class);
    myRegisterSimple(Constants.SOAP_LONG, Long.class);
    myRegisterSimple(Constants.SOAP_SHORT, Short.class);
    myRegisterSimple(Constants.SOAP_BYTE, Byte.class);
    myRegister(Constants.SOAP_BASE64, (array$B == null) ? (array$B = class$("[B")) : array$B, new Base64SerializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.SOAP_BASE64), new Base64DeserializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.SOAP_BASE64));
    myRegister(Constants.SOAP_BASE64BINARY, (array$B == null) ? (array$B = class$("[B")) : array$B, new Base64SerializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.SOAP_BASE64BINARY), new Base64DeserializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.SOAP_BASE64BINARY));
    myRegister(Constants.SOAP_ARRAY12, java.util.Collection.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
    myRegister(Constants.SOAP_ARRAY12, java.util.ArrayList.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
    myRegister(Constants.SOAP_ARRAY12, (array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object, new ArraySerializerFactory(), new ArrayDeserializerFactory());
    myRegister(Constants.SOAP_ARRAY, java.util.ArrayList.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
    myRegister(Constants.SOAP_ARRAY, java.util.Collection.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
    myRegister(Constants.SOAP_ARRAY, (array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object, new ArraySerializerFactory(), new ArrayDeserializerFactory());
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\DefaultSOAPEncodingTypeMappingImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */