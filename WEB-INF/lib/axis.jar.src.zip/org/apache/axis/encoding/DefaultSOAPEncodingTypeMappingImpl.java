/*     */ package org.apache.axis.encoding;
/*     */ 
/*     */ import org.apache.axis.Constants;
/*     */ import org.apache.axis.MessageContext;
/*     */ import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.ArraySerializerFactory;
/*     */ import org.apache.axis.encoding.ser.Base64DeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.Base64SerializerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultSOAPEncodingTypeMappingImpl
/*     */   extends DefaultTypeMappingImpl
/*     */ {
/*  34 */   private static DefaultSOAPEncodingTypeMappingImpl tm = null;
/*     */   static Class array$B;
/*     */   static Class array$Ljava$lang$Object;
/*     */   
/*     */   public static TypeMappingImpl getSingleton() {
/*  39 */     if (tm == null) {
/*  40 */       tm = new DefaultSOAPEncodingTypeMappingImpl();
/*     */     }
/*  42 */     return tm;
/*     */   }
/*     */   
/*     */   public static TypeMappingDelegate createWithDelegate() {
/*  46 */     ret = new TypeMappingDelegate(new DefaultSOAPEncodingTypeMappingImpl());
/*  47 */     MessageContext mc = MessageContext.getCurrentContext();
/*  48 */     TypeMappingDelegate tm = null;
/*  49 */     if (mc != null) {
/*  50 */       tm = (TypeMappingDelegate)mc.getTypeMappingRegistry().getDefaultTypeMapping();
/*     */     } else {
/*  52 */       tm = DefaultTypeMappingImpl.getSingletonDelegate();
/*     */     } 
/*  54 */     ret.setNext(tm);
/*  55 */     return ret;
/*     */   }
/*     */   
/*     */   protected DefaultSOAPEncodingTypeMappingImpl() {
/*  59 */     super(true);
/*  60 */     registerSOAPTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerSOAPTypes() {
/*  70 */     myRegisterSimple(Constants.SOAP_STRING, String.class);
/*  71 */     myRegisterSimple(Constants.SOAP_BOOLEAN, Boolean.class);
/*  72 */     myRegisterSimple(Constants.SOAP_DOUBLE, Double.class);
/*  73 */     myRegisterSimple(Constants.SOAP_FLOAT, Float.class);
/*  74 */     myRegisterSimple(Constants.SOAP_INT, Integer.class);
/*  75 */     myRegisterSimple(Constants.SOAP_INTEGER, java.math.BigInteger.class);
/*  76 */     myRegisterSimple(Constants.SOAP_DECIMAL, java.math.BigDecimal.class);
/*  77 */     myRegisterSimple(Constants.SOAP_LONG, Long.class);
/*  78 */     myRegisterSimple(Constants.SOAP_SHORT, Short.class);
/*  79 */     myRegisterSimple(Constants.SOAP_BYTE, Byte.class);
/*     */     
/*  81 */     myRegister(Constants.SOAP_BASE64, (array$B == null) ? (array$B = class$("[B")) : array$B, new Base64SerializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.SOAP_BASE64), new Base64DeserializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.SOAP_BASE64));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     myRegister(Constants.SOAP_BASE64BINARY, (array$B == null) ? (array$B = class$("[B")) : array$B, new Base64SerializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.SOAP_BASE64BINARY), new Base64DeserializerFactory((array$B == null) ? (array$B = class$("[B")) : array$B, Constants.SOAP_BASE64BINARY));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     myRegister(Constants.SOAP_ARRAY12, java.util.Collection.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
/*     */ 
/*     */ 
/*     */     
/*  98 */     myRegister(Constants.SOAP_ARRAY12, java.util.ArrayList.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     myRegister(Constants.SOAP_ARRAY12, (array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object, new ArraySerializerFactory(), new ArrayDeserializerFactory());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     myRegister(Constants.SOAP_ARRAY, java.util.ArrayList.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     myRegister(Constants.SOAP_ARRAY, java.util.Collection.class, new ArraySerializerFactory(), new ArrayDeserializerFactory());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     myRegister(Constants.SOAP_ARRAY, (array$Ljava$lang$Object == null) ? (array$Ljava$lang$Object = class$("[Ljava.lang.Object;")) : array$Ljava$lang$Object, new ArraySerializerFactory(), new ArrayDeserializerFactory());
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\DefaultSOAPEncodingTypeMappingImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */