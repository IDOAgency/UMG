/*     */ package org.apache.axis.encoding;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.JAXRPCException;
/*     */ import javax.xml.rpc.encoding.DeserializerFactory;
/*     */ import javax.xml.rpc.encoding.SerializerFactory;
/*     */ import org.apache.axis.utils.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeMappingDelegate
/*     */   implements TypeMapping
/*     */ {
/*  33 */   static final TypeMappingImpl placeholder = new TypeMappingImpl();
/*     */ 
/*     */   
/*     */   TypeMappingImpl delegate;
/*     */   
/*     */   TypeMappingDelegate next;
/*     */ 
/*     */   
/*     */   TypeMappingDelegate(TypeMappingImpl delegate) {
/*  42 */     if (delegate == null) {
/*  43 */       throw new RuntimeException(Messages.getMessage("NullDelegate"));
/*     */     }
/*  45 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public String[] getSupportedEncodings() { return this.delegate.getSupportedEncodings(); }
/*     */ 
/*     */ 
/*     */   
/*  58 */   public void setSupportedEncodings(String[] namespaceURIs) { this.delegate.setSupportedEncodings(namespaceURIs); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void register(Class javaType, QName xmlType, SerializerFactory sf, DeserializerFactory dsf) throws JAXRPCException { this.delegate.register(javaType, xmlType, sf, dsf); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializerFactory getSerializer(Class javaType, QName xmlType) throws JAXRPCException {
/*  80 */     SerializerFactory sf = this.delegate.getSerializer(javaType, xmlType);
/*     */     
/*  82 */     if (sf == null && this.next != null) {
/*  83 */       sf = this.next.getSerializer(javaType, xmlType);
/*     */     }
/*     */     
/*  86 */     if (sf == null) {
/*  87 */       sf = this.delegate.finalGetSerializer(javaType);
/*     */     }
/*     */     
/*  90 */     return sf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public SerializerFactory getSerializer(Class javaType) throws JAXRPCException { return getSerializer(javaType, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public DeserializerFactory getDeserializer(Class javaType, QName xmlType) throws JAXRPCException { return getDeserializer(javaType, xmlType, this); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeserializerFactory getDeserializer(Class javaType, QName xmlType, TypeMappingDelegate start) throws JAXRPCException {
/* 108 */     DeserializerFactory df = this.delegate.getDeserializer(javaType, xmlType, start);
/*     */     
/* 110 */     if (df == null && this.next != null) {
/* 111 */       df = this.next.getDeserializer(javaType, xmlType, start);
/*     */     }
/* 113 */     if (df == null) {
/* 114 */       df = this.delegate.finalGetDeserializer(javaType, xmlType, start);
/*     */     }
/* 116 */     return df;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public DeserializerFactory getDeserializer(QName xmlType) throws JAXRPCException { return getDeserializer(null, xmlType); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public void removeSerializer(Class javaType, QName xmlType) throws JAXRPCException { this.delegate.removeSerializer(javaType, xmlType); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public void removeDeserializer(Class javaType, QName xmlType) throws JAXRPCException { this.delegate.removeDeserializer(javaType, xmlType); }
/*     */ 
/*     */   
/*     */   public boolean isRegistered(Class javaType, QName xmlType) {
/* 136 */     boolean result = this.delegate.isRegistered(javaType, xmlType);
/* 137 */     if (!result && this.next != null) {
/* 138 */       return this.next.isRegistered(javaType, xmlType);
/*     */     }
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public QName getTypeQName(Class javaType) { return this.delegate.getTypeQName(javaType, this.next); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public Class getClassForQName(QName xmlType) { return getClassForQName(xmlType, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public Class getClassForQName(QName xmlType, Class javaType) { return this.delegate.getClassForQName(xmlType, javaType, this.next); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public QName getTypeQNameExact(Class javaType) { return this.delegate.getTypeQNameExact(javaType, this.next); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNext(TypeMappingDelegate next) {
/* 191 */     if (next == this) {
/*     */       return;
/*     */     }
/* 194 */     this.next = next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   public TypeMappingDelegate getNext() { return this.next; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 208 */   public Class[] getAllClasses() { return this.delegate.getAllClasses(this.next); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName getXMLType(Class javaType, QName xmlType, boolean encoded) throws JAXRPCException {
/* 230 */     QName result = this.delegate.getXMLType(javaType, xmlType, encoded);
/* 231 */     if (result == null && this.next != null) {
/* 232 */       return this.next.getXMLType(javaType, xmlType, encoded);
/*     */     }
/* 234 */     return result;
/*     */   }
/*     */ 
/*     */   
/* 238 */   public void setDoAutoTypes(boolean doAutoTypes) { this.delegate.setDoAutoTypes(doAutoTypes); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\TypeMappingDelegate.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */