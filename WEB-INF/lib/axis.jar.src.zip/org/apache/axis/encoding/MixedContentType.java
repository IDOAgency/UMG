package org.apache.axis.encoding;

import org.apache.axis.message.MessageElement;

public interface MixedContentType {
  MessageElement[] get_any();
  
  void set_any(MessageElement[] paramArrayOfMessageElement);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\encoding\MixedContentType.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */