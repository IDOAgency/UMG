/*    */ package org.apache.axis.attachments;
/*    */ 
/*    */ import java.net.URL;
/*    */ import javax.activation.DataHandler;
/*    */ import javax.activation.DataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicContentDataHandler
/*    */   extends DataHandler
/*    */ {
/* 33 */   int chunkSize = 1048576;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   public DynamicContentDataHandler(DataSource arg0) { super(arg0); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   public DynamicContentDataHandler(Object arg0, String arg1) { super(arg0, arg1); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public DynamicContentDataHandler(URL arg0) { super(arg0); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public int getChunkSize() { return this.chunkSize; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   public void setChunkSize(int chunkSize) { this.chunkSize = chunkSize; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\DynamicContentDataHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */