package org.apache.axis.attachments;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.internet.MimeMultipart;
import javax.xml.soap.MimeHeaders;
import org.apache.axis.AxisFault;
import org.apache.axis.Part;
import org.apache.axis.SOAPPart;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class AttachmentsImpl implements Attachments {
  protected static Log log = LogFactory.getLog(AttachmentsImpl.class.getName());
  
  private HashMap attachments = new HashMap();
  
  private LinkedList orderedAttachments = new LinkedList();
  
  protected SOAPPart soapPart = null;
  
  protected MultiPartInputStream mpartStream = null;
  
  protected int sendtype = 1;
  
  protected String contentLocation = null;
  
  private HashMap stackDataHandler = new HashMap();
  
  private IncomingAttachmentStreams _streams = null;
  
  private boolean _askedForAttachments = false;
  
  private boolean _askedForStreams = false;
  
  public AttachmentsImpl(Object intialContents, String contentType, String contentLocation) throws AxisFault {
    if (contentLocation != null) {
      contentLocation = contentLocation.trim();
      if (contentLocation.length() == 0)
        contentLocation = null; 
    } 
    this.contentLocation = contentLocation;
    if (contentType != null && 
      !contentType.equals("  ")) {
      StringTokenizer st = new StringTokenizer(contentType, " \t;");
      if (st.hasMoreTokens()) {
        String token = st.nextToken();
        if (token.equalsIgnoreCase("multipart/related")) {
          this.sendtype = 2;
          this.mpartStream = new MultiPartRelatedInputStream(contentType, (InputStream)intialContents);
          if (null == contentLocation) {
            contentLocation = this.mpartStream.getContentLocation();
            if (contentLocation != null) {
              contentLocation = contentLocation.trim();
              if (contentLocation.length() == 0)
                contentLocation = null; 
            } 
          } 
          this.soapPart = new SOAPPart(null, this.mpartStream, false);
          MultiPartRelatedInputStream specificType = (MultiPartRelatedInputStream)this.mpartStream;
          this._streams = new MultipartAttachmentStreams(specificType.boundaryDelimitedStream, specificType.orderedParts);
        } else if (token.equalsIgnoreCase("application/dime")) {
          try {
            this.mpartStream = new MultiPartDimeInputStream((InputStream)intialContents);
            this.soapPart = new SOAPPart(null, this.mpartStream, false);
          } catch (Exception e) {
            throw AxisFault.makeFault(e);
          } 
          this.sendtype = 3;
          MultiPartDimeInputStream specificType = (MultiPartDimeInputStream)this.mpartStream;
          this._streams = new DimeAttachmentStreams(specificType.dimeDelimitedStream);
        } else if (token.indexOf("application/xop+xml") != -1) {
          this.sendtype = 4;
        } 
      } 
    } 
  }
  
  private void mergeinAttachments() throws AxisFault {
    if (this.mpartStream != null) {
      Collection atts = this.mpartStream.getAttachments();
      if (this.contentLocation == null)
        this.contentLocation = this.mpartStream.getContentLocation(); 
      this.mpartStream = null;
      setAttachmentParts(atts);
    } 
  }
  
  public Part removeAttachmentPart(String reference) throws AxisFault {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    this.multipart = null;
    this.dimemultipart = null;
    mergeinAttachments();
    Part removedPart = getAttachmentByReference(reference);
    if (removedPart != null) {
      this.attachments.remove(removedPart.getContentId());
      this.attachments.remove(removedPart.getContentLocation());
      this.orderedAttachments.remove(removedPart);
    } 
    return removedPart;
  }
  
  public Part addAttachmentPart(Part newPart) throws AxisFault {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    this.multipart = null;
    this.dimemultipart = null;
    mergeinAttachments();
    Part oldPart = (Part)this.attachments.put(newPart.getContentId(), newPart);
    if (oldPart != null) {
      this.orderedAttachments.remove(oldPart);
      this.attachments.remove(oldPart.getContentLocation());
    } 
    this.orderedAttachments.add(newPart);
    if (newPart.getContentLocation() != null)
      this.attachments.put(newPart.getContentLocation(), newPart); 
    return oldPart;
  }
  
  public Part createAttachmentPart(Object datahandler) throws AxisFault {
    Integer key = new Integer(datahandler.hashCode());
    if (this.stackDataHandler.containsKey(key))
      return (Part)this.stackDataHandler.get(key); 
    this.multipart = null;
    this.dimemultipart = null;
    mergeinAttachments();
    if (!(datahandler instanceof DataHandler))
      throw new AxisFault(Messages.getMessage("unsupportedAttach", datahandler.getClass().getName(), DataHandler.class.getName())); 
    Part ret = new AttachmentPart((DataHandler)datahandler);
    addAttachmentPart(ret);
    this.stackDataHandler.put(key, ret);
    return ret;
  }
  
  public void setAttachmentParts(Collection parts) throws AxisFault {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    removeAllAttachments();
    if (parts != null && !parts.isEmpty())
      for (Iterator i = parts.iterator(); i.hasNext(); ) {
        Object part = i.next();
        if (null != part) {
          if (part instanceof Part) {
            addAttachmentPart((Part)part);
            continue;
          } 
          createAttachmentPart(part);
        } 
      }  
  }
  
  public Part getAttachmentByReference(String reference) throws AxisFault {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    if (null == reference)
      return null; 
    reference = reference.trim();
    if (0 == reference.length())
      return null; 
    mergeinAttachments();
    Part ret = (Part)this.attachments.get(reference);
    if (null != ret)
      return ret; 
    if (!reference.startsWith("cid:") && null != this.contentLocation) {
      String fqreference = this.contentLocation;
      if (!fqreference.endsWith("/"))
        fqreference = fqreference + "/"; 
      if (reference.startsWith("/")) {
        fqreference = fqreference + reference.substring(1);
      } else {
        fqreference = fqreference + reference;
      } 
      ret = (AttachmentPart)this.attachments.get(fqreference);
    } 
    if (null == ret && reference.startsWith("cid:"))
      ret = (Part)this.attachments.get(reference.substring(4)); 
    return ret;
  }
  
  public Collection getAttachments() throws AxisFault {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    mergeinAttachments();
    return new LinkedList(this.orderedAttachments);
  }
  
  public Part getRootPart() { return this.soapPart; }
  
  public void setRootPart(Part newRoot) {
    try {
      this.soapPart = (SOAPPart)newRoot;
      this.multipart = null;
      this.dimemultipart = null;
    } catch (ClassCastException e) {
      throw new ClassCastException(Messages.getMessage("onlySOAPParts"));
    } 
  }
  
  MimeMultipart multipart = null;
  
  DimeMultiPart dimemultipart = null;
  
  public long getContentLength() throws AxisFault {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    mergeinAttachments();
    int sendtype = (this.sendtype == 1) ? 2 : this.sendtype;
    try {
      if (sendtype == 2 || sendtype == 4)
        return MimeUtils.getContentLength((this.multipart != null) ? this.multipart : (this.multipart = MimeUtils.createMP(this.soapPart.getAsString(), this.orderedAttachments, getSendType()))); 
      if (sendtype == 3)
        return createDimeMessage().getTransmissionSize(); 
    } catch (Exception e) {
      throw AxisFault.makeFault(e);
    } 
    return 0L;
  }
  
  protected DimeMultiPart createDimeMessage() throws AxisFault {
    int sendtype = (this.sendtype == 1) ? 2 : this.sendtype;
    if (sendtype == 3 && 
      this.dimemultipart == null) {
      this.dimemultipart = new DimeMultiPart();
      this.dimemultipart.addBodyPart(new DimeBodyPart(this.soapPart.getAsBytes(), DimeTypeNameFormat.URI, "http://schemas.xmlsoap.org/soap/envelope/", "uuid:714C6C40-4531-442E-A498-3AC614200295"));
      Iterator i = this.orderedAttachments.iterator();
      while (i.hasNext()) {
        AttachmentPart part = (AttachmentPart)i.next();
        DataHandler dh = AttachmentUtils.getActivationDataHandler(part);
        this.dimemultipart.addBodyPart(new DimeBodyPart(dh, part.getContentId()));
      } 
    } 
    return this.dimemultipart;
  }
  
  public void writeContentToStream(OutputStream os) throws AxisFault {
    int sendtype = (this.sendtype == 1) ? 2 : this.sendtype;
    try {
      mergeinAttachments();
      if (sendtype == 2 || sendtype == 4) {
        MimeUtils.writeToMultiPartStream(os, (this.multipart != null) ? this.multipart : (this.multipart = MimeUtils.createMP(this.soapPart.getAsString(), this.orderedAttachments, getSendType())));
        Iterator i = this.orderedAttachments.iterator();
        while (i.hasNext()) {
          AttachmentPart part = (AttachmentPart)i.next();
          DataHandler dh = AttachmentUtils.getActivationDataHandler(part);
          DataSource ds = dh.getDataSource();
          if (ds != null && ds instanceof ManagedMemoryDataSource)
            ((ManagedMemoryDataSource)ds).delete(); 
        } 
      } else if (sendtype == 3) {
        createDimeMessage().write(os);
      } 
    } catch (Exception e) {
      throw AxisFault.makeFault(e);
    } 
  }
  
  public String getContentType() throws AxisFault {
    mergeinAttachments();
    int sendtype = (this.sendtype == 1) ? 2 : this.sendtype;
    if (sendtype == 2 || sendtype == 4)
      return MimeUtils.getContentType((this.multipart != null) ? this.multipart : (this.multipart = MimeUtils.createMP(this.soapPart.getAsString(), this.orderedAttachments, getSendType()))); 
    return "application/dime";
  }
  
  public int getAttachmentCount() {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    try {
      mergeinAttachments();
      this.soapPart.saveChanges();
      return this.orderedAttachments.size();
    } catch (AxisFault e) {
      log.warn(Messages.getMessage("exception00"), e);
      return 0;
    } 
  }
  
  public boolean isAttachment(Object value) { return AttachmentUtils.isAttachment(value); }
  
  public void removeAllAttachments() throws AxisFault {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    try {
      this.multipart = null;
      this.dimemultipart = null;
      mergeinAttachments();
      this.attachments.clear();
      this.orderedAttachments.clear();
      this.stackDataHandler.clear();
    } catch (AxisFault af) {
      log.warn(Messages.getMessage("exception00"), af);
    } 
  }
  
  public Iterator getAttachments(MimeHeaders headers) {
    if (this._askedForStreams)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    Vector vecParts = new Vector();
    Iterator iterator = GetAttachmentsIterator();
    while (iterator.hasNext()) {
      Part part = (Part)iterator.next();
      if (part instanceof AttachmentPart && (
        (AttachmentPart)part).matches(headers))
        vecParts.add(part); 
    } 
    return vecParts.iterator();
  }
  
  private Iterator GetAttachmentsIterator() { return this.attachments.values().iterator(); }
  
  public Part createAttachmentPart() { return new AttachmentPart(); }
  
  public void setSendType(int sendtype) {
    if (sendtype < 1)
      throw new IllegalArgumentException(""); 
    if (sendtype > 5)
      throw new IllegalArgumentException(""); 
    this.sendtype = sendtype;
  }
  
  public int getSendType() { return this.sendtype; }
  
  public void dispose() throws AxisFault {
    Iterator iterator = GetAttachmentsIterator();
    while (iterator.hasNext()) {
      Part part = (Part)iterator.next();
      if (part instanceof AttachmentPart) {
        AttachmentPart apart = (AttachmentPart)part;
        apart.dispose();
      } 
    } 
  }
  
  public static int getSendType(String value) {
    if (value.equalsIgnoreCase("MTOM"))
      return 4; 
    if (value.equalsIgnoreCase("MIME"))
      return 2; 
    if (value.equalsIgnoreCase("DIME"))
      return 3; 
    if (value.equalsIgnoreCase("NONE"))
      return 5; 
    return 1;
  }
  
  public static String getSendTypeString(int value) {
    if (value == 4)
      return "MTOM"; 
    if (value == 2)
      return "MIME"; 
    if (value == 3)
      return "DIME"; 
    if (value == 5)
      return "NONE"; 
    return null;
  }
  
  public IncomingAttachmentStreams getIncomingAttachmentStreams() {
    if (this._askedForAttachments)
      throw new IllegalStateException(Messages.getMessage("concurrentModificationOfStream")); 
    this._askedForStreams = true;
    this.mpartStream = null;
    return this._streams;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\AttachmentsImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */