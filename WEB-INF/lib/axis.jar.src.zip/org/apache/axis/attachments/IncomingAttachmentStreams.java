package org.apache.axis.attachments;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import org.apache.axis.AxisFault;
import org.apache.axis.utils.Messages;

public abstract class IncomingAttachmentStreams {
  private boolean _readyToGetNextStream = true;
  
  public abstract IncomingAttachmentInputStream getNextStream() throws AxisFault;
  
  public final boolean isReadyToGetNextStream() { return this._readyToGetNextStream; }
  
  protected final void setReadyToGetNextStream(boolean ready) { this._readyToGetNextStream = ready; }
  
  public final class IncomingAttachmentInputStream extends InputStream {
    private HashMap _headers;
    
    private InputStream _stream;
    
    private final IncomingAttachmentStreams this$0;
    
    public IncomingAttachmentInputStream(IncomingAttachmentStreams this$0, InputStream in) {
      this.this$0 = this$0;
      this._headers = null;
      this._stream = null;
      this._stream = in;
    }
    
    public Map getHeaders() { return this._headers; }
    
    public void addHeader(String name, String value) {
      if (this._headers == null)
        this._headers = new HashMap(); 
      this._headers.put(name, value);
    }
    
    public String getHeader(String name) {
      Object header = null;
      if (this._headers == null || (header = this._headers.get(name)) == null)
        return null; 
      return header.toString();
    }
    
    public String getContentId() { return getHeader("Content-Id"); }
    
    public String getContentLocation() { return getHeader("Content-Location"); }
    
    public String getContentType() { return getHeader("Content-Type"); }
    
    public boolean markSupported() { return false; }
    
    public void reset() { throw new IOException(Messages.getMessage("markNotSupported")); }
    
    public void mark(int readLimit) {}
    
    public int read() throws IOException {
      int retval = this._stream.read();
      this.this$0.setReadyToGetNextStream((retval == -1));
      return retval;
    }
    
    public int read(byte[] b) throws IOException {
      int retval = this._stream.read(b);
      this.this$0.setReadyToGetNextStream((retval == -1));
      return retval;
    }
    
    public int read(byte[] b, int off, int len) throws IOException {
      int retval = this._stream.read(b, off, len);
      this.this$0.setReadyToGetNextStream((retval == -1));
      return retval;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\IncomingAttachmentStreams.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */