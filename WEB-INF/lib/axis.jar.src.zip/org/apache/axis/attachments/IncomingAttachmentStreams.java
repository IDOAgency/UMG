/*     */ package org.apache.axis.attachments;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.utils.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IncomingAttachmentStreams
/*     */ {
/*     */   private boolean _readyToGetNextStream = true;
/*     */   
/*     */   public abstract IncomingAttachmentInputStream getNextStream() throws AxisFault;
/*     */   
/*  44 */   public final boolean isReadyToGetNextStream() { return this._readyToGetNextStream; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected final void setReadyToGetNextStream(boolean ready) { this._readyToGetNextStream = ready; }
/*     */ 
/*     */   
/*     */   public final class IncomingAttachmentInputStream
/*     */     extends InputStream
/*     */   {
/*     */     private HashMap _headers;
/*     */     private InputStream _stream;
/*     */     private final IncomingAttachmentStreams this$0;
/*     */     
/*     */     public IncomingAttachmentInputStream(IncomingAttachmentStreams this$0, InputStream in) {
/*  64 */       this.this$0 = this$0; this._headers = null; this._stream = null;
/*  65 */       this._stream = in;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     public Map getHeaders() { return this._headers; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addHeader(String name, String value) {
/*  83 */       if (this._headers == null) {
/*  84 */         this._headers = new HashMap();
/*     */       }
/*  86 */       this._headers.put(name, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getHeader(String name) {
/*  96 */       Object header = null;
/*  97 */       if (this._headers == null || (header = this._headers.get(name)) == null) {
/*  98 */         return null;
/*     */       }
/* 100 */       return header.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     public String getContentId() { return getHeader("Content-Id"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 115 */     public String getContentLocation() { return getHeader("Content-Location"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     public String getContentType() { return getHeader("Content-Type"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     public boolean markSupported() { return false; }
/*     */ 
/*     */ 
/*     */     
/* 135 */     public void reset() { throw new IOException(Messages.getMessage("markNotSupported")); }
/*     */ 
/*     */ 
/*     */     
/*     */     public void mark(int readLimit) {}
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 143 */       int retval = this._stream.read();
/* 144 */       this.this$0.setReadyToGetNextStream((retval == -1));
/*     */       
/* 146 */       return retval;
/*     */     }
/*     */     
/*     */     public int read(byte[] b) throws IOException {
/* 150 */       int retval = this._stream.read(b);
/* 151 */       this.this$0.setReadyToGetNextStream((retval == -1));
/*     */       
/* 153 */       return retval;
/*     */     }
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 157 */       int retval = this._stream.read(b, off, len);
/* 158 */       this.this$0.setReadyToGetNextStream((retval == -1));
/*     */       
/* 160 */       return retval;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\IncomingAttachmentStreams.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */