/*    */ package org.apache.axis.attachments;
/*    */ 
/*    */ import org.apache.axis.utils.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DimeTypeNameFormat
/*    */ {
/* 33 */   private byte format = 0;
/*    */   static final byte NOCHANGE_VALUE = 0;
/*    */   
/* 36 */   private DimeTypeNameFormat(byte f) { this.format = f; }
/*    */   
/*    */   static final byte MIME_VALUE = 1;
/*    */   static final byte URI_VALUE = 2;
/*    */   static final byte UNKNOWN_VALUE = 3;
/*    */   static final byte NODATA_VALUE = 4;
/*    */   
/*    */   private DimeTypeNameFormat() {}
/*    */   
/* 45 */   static final DimeTypeNameFormat NOCHANGE = new DimeTypeNameFormat((byte)0);
/*    */ 
/*    */   
/* 48 */   public static final DimeTypeNameFormat MIME = new DimeTypeNameFormat((byte)1);
/*    */ 
/*    */   
/* 51 */   public static final DimeTypeNameFormat URI = new DimeTypeNameFormat((byte)2);
/*    */ 
/*    */   
/* 54 */   public static final DimeTypeNameFormat UNKNOWN = new DimeTypeNameFormat((byte)3);
/*    */ 
/*    */   
/* 57 */   static final DimeTypeNameFormat NODATA = new DimeTypeNameFormat((byte)4);
/*    */ 
/*    */   
/* 60 */   private static String[] toEnglish = { "NOCHANGE", "MIME", "URI", "UNKNOWN", "NODATA" };
/*    */   
/* 62 */   private static DimeTypeNameFormat[] fromByte = { NOCHANGE, MIME, URI, UNKNOWN, NODATA };
/*    */ 
/*    */ 
/*    */   
/* 66 */   public final String toString() { return toEnglish[this.format]; }
/*    */ 
/*    */ 
/*    */   
/* 70 */   public final byte toByte() { return this.format; }
/*    */ 
/*    */ 
/*    */   
/* 74 */   public int hashCode() { return this.format; }
/*    */ 
/*    */   
/*    */   public final boolean equals(Object x) {
/* 78 */     if (x == null) {
/* 79 */       return false;
/*    */     }
/* 81 */     if (!(x instanceof DimeTypeNameFormat)) {
/* 82 */       return false;
/*    */     }
/* 84 */     return (((DimeTypeNameFormat)x).format == this.format);
/*    */   }
/*    */   
/*    */   public static DimeTypeNameFormat parseByte(byte x) {
/* 88 */     if (x < 0 || x > fromByte.length) {
/* 89 */       throw new IllegalArgumentException(Messages.getMessage("attach.DimeStreamBadType", "" + x));
/*    */     }
/*    */     
/* 92 */     return fromByte[x];
/*    */   }
/*    */ 
/*    */   
/* 96 */   public static DimeTypeNameFormat parseByte(Byte x) { return parseByte(x.byteValue()); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\DimeTypeNameFormat.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */