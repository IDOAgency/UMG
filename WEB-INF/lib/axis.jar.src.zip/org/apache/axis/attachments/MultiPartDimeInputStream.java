package org.apache.axis.attachments;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import javax.activation.DataHandler;
import org.apache.axis.AxisFault;
import org.apache.axis.Part;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class MultiPartDimeInputStream extends MultiPartInputStream {
  protected static Log log = LogFactory.getLog(MultiPartDimeInputStream.class.getName());
  
  protected HashMap parts = new HashMap();
  
  protected LinkedList orderedParts = new LinkedList();
  
  protected int rootPartLength = 0;
  
  protected boolean closed = false;
  
  protected boolean eos = false;
  
  protected DimeDelimitedInputStream dimeDelimitedStream = null;
  
  protected InputStream soapStream = null;
  
  protected byte[] boundary = null;
  
  protected ByteArrayInputStream cachedSOAPEnvelope = null;
  
  protected String contentId = null;
  
  public MultiPartDimeInputStream(InputStream is) throws IOException {
    super(null);
    this.soapStream = this.dimeDelimitedStream = new DimeDelimitedInputStream(is);
    this.contentId = this.dimeDelimitedStream.getContentId();
  }
  
  public Part getAttachmentByReference(String[] id) throws AxisFault {
    Part ret = null;
    try {
      for (int i = id.length - 1; ret == null && i > -1; i--)
        ret = (AttachmentPart)this.parts.get(id[i]); 
      if (null == ret)
        ret = readTillFound(id); 
      log.debug(Messages.getMessage("return02", "getAttachmentByReference(\"" + id + "\"", (ret == null) ? "null" : ret.toString()));
    } catch (IOException e) {
      throw new AxisFault(e.getClass().getName() + e.getMessage());
    } 
    return ret;
  }
  
  protected void addPart(String contentId, String locationId, AttachmentPart ap) {
    if (contentId != null && contentId.trim().length() != 0)
      this.parts.put(contentId, ap); 
    this.orderedParts.add(ap);
  }
  
  protected static final String[] READ_ALL = { " * \000 ".intern() };
  
  protected void readAll() throws AxisFault {
    try {
      readTillFound(READ_ALL);
    } catch (Exception e) {
      throw AxisFault.makeFault(e);
    } 
  }
  
  public Collection getAttachments() throws AxisFault {
    readAll();
    return new LinkedList(this.orderedParts);
  }
  
  protected Part readTillFound(String[] id) throws AxisFault {
    if (this.dimeDelimitedStream == null)
      return null; 
    Part ret = null;
    try {
      if (this.soapStream != null) {
        if (!this.eos) {
          ByteArrayOutputStream soapdata = new ByteArrayOutputStream(8192);
          byte[] buf = new byte[16384];
          int byteread = 0;
          do {
            byteread = this.soapStream.read(buf);
            if (byteread <= 0)
              continue; 
            soapdata.write(buf, 0, byteread);
          } while (byteread > -1);
          soapdata.close();
          this.soapStream.close();
          this.soapStream = new ByteArrayInputStream(soapdata.toByteArray());
        } 
        this.dimeDelimitedStream = this.dimeDelimitedStream.getNextStream();
      } 
      if (null != this.dimeDelimitedStream)
        do {
          String contentId = this.dimeDelimitedStream.getContentId();
          String type = this.dimeDelimitedStream.getType();
          if (type != null && !this.dimeDelimitedStream.getDimeTypeNameFormat().equals(DimeTypeNameFormat.MIME))
            type = "application/uri; uri=\"" + type + "\""; 
          ManagedMemoryDataSource source = new ManagedMemoryDataSource(this.dimeDelimitedStream, 16384, type, true);
          DataHandler dh = new DataHandler(source);
          AttachmentPart ap = new AttachmentPart(dh);
          if (contentId != null)
            ap.setMimeHeader("Content-Id", contentId); 
          addPart(contentId, "", ap);
          for (int i = id.length - 1; ret == null && i > -1; i--) {
            if (contentId != null && id[i].equals(contentId))
              ret = ap; 
          } 
          this.dimeDelimitedStream = this.dimeDelimitedStream.getNextStream();
        } while (null == ret && null != this.dimeDelimitedStream); 
    } catch (Exception e) {
      throw AxisFault.makeFault(e);
    } 
    return ret;
  }
  
  public String getContentLocation() { return null; }
  
  public String getContentId() { return this.contentId; }
  
  public int read(byte[] b, int off, int len) throws IOException {
    if (this.closed)
      throw new IOException(Messages.getMessage("streamClosed")); 
    if (this.eos)
      return -1; 
    int read = this.soapStream.read(b, off, len);
    if (read < 0)
      this.eos = true; 
    return read;
  }
  
  public int read(byte[] b) throws IOException { return read(b, 0, b.length); }
  
  public int read() throws IOException {
    if (this.closed)
      throw new IOException(Messages.getMessage("streamClosed")); 
    if (this.eos)
      return -1; 
    int ret = this.soapStream.read();
    if (ret < 0)
      this.eos = true; 
    return ret;
  }
  
  public void close() throws AxisFault {
    this.closed = true;
    this.soapStream.close();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\MultiPartDimeInputStream.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */