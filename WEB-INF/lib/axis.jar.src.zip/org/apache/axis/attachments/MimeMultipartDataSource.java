package org.apache.axis.attachments;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.activation.DataSource;
import javax.mail.internet.MimeMultipart;

public class MimeMultipartDataSource implements DataSource {
  public static final String CONTENT_TYPE = "multipart/mixed";
  
  private final String name;
  
  private final String contentType;
  
  private byte[] data;
  
  private ByteArrayOutputStream os;
  
  public MimeMultipartDataSource(String name, MimeMultipart data) {
    this.name = name;
    this.contentType = (data == null) ? "multipart/mixed" : data.getContentType();
    this.os = new ByteArrayOutputStream();
    try {
      if (data != null)
        data.writeTo(this.os); 
    } catch (Exception e) {}
  }
  
  public String getName() { return this.name; }
  
  public String getContentType() { return this.contentType; }
  
  public InputStream getInputStream() throws IOException {
    if (this.os.size() != 0) {
      this.data = this.os.toByteArray();
      this.os.reset();
    } 
    return new ByteArrayInputStream((this.data == null) ? new byte[0] : this.data);
  }
  
  public OutputStream getOutputStream() throws IOException {
    if (this.os.size() != 0) {
      this.data = this.os.toByteArray();
      this.os.reset();
    } 
    return this.os;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\MimeMultipartDataSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */