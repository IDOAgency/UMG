package org.apache.axis.attachments;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.StringTokenizer;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class DimeBodyPart {
  protected static Log log = LogFactory.getLog(DimeBodyPart.class.getName());
  
  protected Object data = null;
  
  protected DimeTypeNameFormat dtnf = null;
  
  protected byte[] type = null;
  
  protected byte[] id = null;
  
  static final byte POSITION_FIRST = 4;
  
  static final byte POSITION_LAST = 2;
  
  private static final byte CHUNK = 1;
  
  private static final byte CHUNK_NEXT = 2;
  
  private static final byte ONLY_CHUNK = -1;
  
  private static final byte LAST_CHUNK = 0;
  
  private static int MAX_TYPE_LENGTH = 65535;
  
  private static int MAX_ID_LENGTH = 65535;
  
  static final long MAX_DWORD = 4294967295L;
  
  public DimeBodyPart(byte[] data, DimeTypeNameFormat format, String type, String id) {
    System.arraycopy(data, 0, this.data = new byte[data.length], 0, data.length);
    this.dtnf = format;
    this.type = type.getBytes();
    if (this.type.length > MAX_TYPE_LENGTH)
      throw new IllegalArgumentException(Messages.getMessage("attach.dimetypeexceedsmax", "" + this.type.length, "" + MAX_TYPE_LENGTH)); 
    this.id = id.getBytes();
    if (this.id.length > MAX_ID_LENGTH)
      throw new IllegalArgumentException(Messages.getMessage("attach.dimelengthexceedsmax", "" + this.id.length, "" + MAX_ID_LENGTH)); 
  }
  
  public DimeBodyPart(DataHandler dh, DimeTypeNameFormat format, String type, String id) {
    this.data = dh;
    this.dtnf = format;
    if (type == null || type.length() == 0)
      type = "application/octet-stream"; 
    this.type = type.getBytes();
    if (this.type.length > MAX_TYPE_LENGTH)
      throw new IllegalArgumentException(Messages.getMessage("attach.dimetypeexceedsmax", "" + this.type.length, "" + MAX_TYPE_LENGTH)); 
    this.id = id.getBytes();
    if (this.id.length > MAX_ID_LENGTH)
      throw new IllegalArgumentException(Messages.getMessage("attach.dimelengthexceedsmax", "" + this.id.length, "" + MAX_ID_LENGTH)); 
  }
  
  public DimeBodyPart(DataHandler dh, String id) {
    this(dh, DimeTypeNameFormat.MIME, dh.getContentType(), id);
    String ct = dh.getContentType();
    if (ct != null) {
      ct = ct.trim();
      if (ct.toLowerCase().startsWith("application/uri")) {
        StringTokenizer st = new StringTokenizer(ct, " \t;");
        String t = st.nextToken(" \t;");
        if (t.equalsIgnoreCase("application/uri"))
          while (st.hasMoreTokens()) {
            t = st.nextToken(" \t;");
            if (t.equalsIgnoreCase("uri")) {
              t = st.nextToken("=");
              if (t != null) {
                t = t.trim();
                if (t.startsWith("\""))
                  t = t.substring(1); 
                if (t.endsWith("\""))
                  t = t.substring(0, t.length() - 1); 
                this.type = t.getBytes();
                this.dtnf = DimeTypeNameFormat.URI;
              } 
              return;
            } 
            if (t.equalsIgnoreCase("uri=")) {
              t = st.nextToken(" \t;");
              if (null != t && t.length() != 0) {
                t = t.trim();
                if (t.startsWith("\""))
                  t = t.substring(1); 
                if (t.endsWith("\""))
                  t = t.substring(0, t.length() - 1); 
                this.type = t.getBytes();
                this.dtnf = DimeTypeNameFormat.URI;
                return;
              } 
              continue;
            } 
            if (t.toLowerCase().startsWith("uri=") && 
              -1 != t.indexOf('=')) {
              t = t.substring(t.indexOf('=')).trim();
              if (t.length() != 0) {
                t = t.trim();
                if (t.startsWith("\""))
                  t = t.substring(1); 
                if (t.endsWith("\""))
                  t = t.substring(0, t.length() - 1); 
                this.type = t.getBytes();
                this.dtnf = DimeTypeNameFormat.URI;
                return;
              } 
            } 
          }  
      } 
    } 
  }
  
  void write(OutputStream os, byte position, long maxchunk) throws IOException {
    if (maxchunk < 1L)
      throw new IllegalArgumentException(Messages.getMessage("attach.dimeMaxChunkSize0", "" + maxchunk)); 
    if (maxchunk > 4294967295L)
      throw new IllegalArgumentException(Messages.getMessage("attach.dimeMaxChunkSize1", "" + maxchunk)); 
    if (this.data instanceof byte[]) {
      send(os, position, (byte[])this.data, maxchunk);
    } else if (this.data instanceof DynamicContentDataHandler) {
      send(os, position, (DynamicContentDataHandler)this.data, maxchunk);
    } else if (this.data instanceof DataHandler) {
      DataSource source = ((DataHandler)this.data).getDataSource();
      DynamicContentDataHandler dh2 = new DynamicContentDataHandler(source);
      send(os, position, dh2, maxchunk);
    } 
  }
  
  void write(OutputStream os, byte position) throws IOException { write(os, position, 4294967295L); }
  
  private static final byte[] pad = new byte[4];
  
  static final byte CURRENT_OPT_T = 0;
  
  void send(OutputStream os, byte position, byte[] data, long maxchunk) throws IOException { send(os, position, data, 0, data.length, maxchunk); }
  
  void send(OutputStream os, byte position, byte[] data, int offset, int length, long maxchunk) throws IOException {
    byte chunknext = 0;
    do {
      int sendlength = (int)Math.min(maxchunk, (length - offset));
      sendChunk(os, position, data, offset, sendlength, (byte)(((sendlength < length - offset) ? 1 : 0) | chunknext));
      offset += sendlength;
      chunknext = 2;
    } while (offset < length);
  }
  
  void send(OutputStream os, byte position, DataHandler dh, long maxchunk) throws IOException {
    InputStream in = null;
    try {
      int bytesread;
      long dataSize = getDataSize();
      in = dh.getInputStream();
      byte[] readbuf = new byte[65536];
      sendHeader(os, position, dataSize, (byte)0);
      long totalsent = 0L;
      do {
        bytesread = in.read(readbuf);
        if (bytesread <= 0)
          continue; 
        os.write(readbuf, 0, bytesread);
        totalsent += bytesread;
      } while (bytesread > -1);
      os.write(pad, 0, dimePadding(totalsent));
    } finally {
      if (in != null)
        try {
          in.close();
        } catch (IOException e) {} 
    } 
  }
  
  void send(OutputStream os, byte position, DynamicContentDataHandler dh, long maxchunk) throws IOException {
    BufferedInputStream in = new BufferedInputStream(dh.getInputStream());
    int myChunkSize = dh.getChunkSize();
    byte[] buffer1 = new byte[myChunkSize];
    byte[] buffer2 = new byte[myChunkSize];
    int bytesRead1 = 0, bytesRead2 = 0;
    bytesRead1 = in.read(buffer1);
    if (bytesRead1 < 0) {
      sendHeader(os, position, 0L, (byte)-1);
      os.write(pad, 0, dimePadding(0L));
      return;
    } 
    byte chunkbyte = 1;
    do {
      bytesRead2 = in.read(buffer2);
      if (bytesRead2 < 0) {
        if (chunkbyte == 1) {
          chunkbyte = -1;
        } else {
          chunkbyte = 0;
        } 
        sendChunk(os, position, buffer1, 0, bytesRead1, chunkbyte);
        break;
      } 
      sendChunk(os, position, buffer1, 0, bytesRead1, chunkbyte);
      chunkbyte = 2;
      System.arraycopy(buffer2, 0, buffer1, 0, myChunkSize);
      bytesRead1 = bytesRead2;
    } while (bytesRead2 > 0);
  }
  
  protected void sendChunk(OutputStream os, byte position, byte[] data, byte chunk) throws IOException { sendChunk(os, position, data, 0, data.length, chunk); }
  
  protected void sendChunk(OutputStream os, byte position, byte[] data, int offset, int length, byte chunk) throws IOException {
    sendHeader(os, position, length, chunk);
    os.write(data, offset, length);
    os.write(pad, 0, dimePadding(length));
  }
  
  protected void sendHeader(OutputStream os, byte position, long length, byte chunk) throws IOException {
    byte[] fixedHeader = new byte[12];
    boolean isFirstChunk = (chunk == 1 || chunk == -1);
    if (chunk == 2) {
      chunk = 1;
    } else if (chunk == -1) {
      chunk = 0;
    } 
    fixedHeader[0] = 8;
    fixedHeader[0] = (byte)(fixedHeader[0] | (byte)(position & 0x6 & (((chunk & true) != 0) ? -3 : -1) & (((chunk & 0x2) != 0) ? -5 : -1)));
    fixedHeader[0] = (byte)(fixedHeader[0] | chunk & true);
    boolean MB = (0 != (0x4 & fixedHeader[0]));
    if (MB || isFirstChunk) {
      fixedHeader[1] = (byte)(this.dtnf.toByte() << 4 & 0xF0);
    } else {
      fixedHeader[1] = 0;
    } 
    fixedHeader[1] = (byte)(fixedHeader[1] | false);
    fixedHeader[2] = 0;
    fixedHeader[3] = 0;
    if ((MB || isFirstChunk) && this.id != null && this.id.length > 0) {
      fixedHeader[4] = (byte)(this.id.length >>> 8 & 0xFF);
      fixedHeader[5] = (byte)(this.id.length & 0xFF);
    } else {
      fixedHeader[4] = 0;
      fixedHeader[5] = 0;
    } 
    if (MB || isFirstChunk) {
      fixedHeader[6] = (byte)(this.type.length >>> 8 & 0xFF);
      fixedHeader[7] = (byte)(this.type.length & 0xFF);
    } else {
      fixedHeader[6] = 0;
      fixedHeader[7] = 0;
    } 
    fixedHeader[8] = (byte)(int)(length >>> 24 & 0xFFL);
    fixedHeader[9] = (byte)(int)(length >>> 16 & 0xFFL);
    fixedHeader[10] = (byte)(int)(length >>> 8 & 0xFFL);
    fixedHeader[11] = (byte)(int)(length & 0xFFL);
    os.write(fixedHeader);
    if ((MB || isFirstChunk) && this.id != null && this.id.length > 0) {
      os.write(this.id);
      os.write(pad, 0, dimePadding(this.id.length));
    } 
    if (MB || isFirstChunk) {
      os.write(this.type);
      os.write(pad, 0, dimePadding(this.type.length));
    } 
  }
  
  static final int dimePadding(long l) { return (int)(4L - (l & 0x3L) & 0x3L); }
  
  long getTransmissionSize(long chunkSize) {
    long size = 0L;
    size += this.id.length;
    size += dimePadding(this.id.length);
    size += this.type.length;
    size += dimePadding(this.type.length);
    long dataSize = getDataSize();
    if (0L == dataSize) {
      size += 12L;
    } else {
      long fullChunks = dataSize / chunkSize;
      long lastChunkSize = dataSize % chunkSize;
      if (0L != lastChunkSize)
        size += 12L; 
      size += 12L * fullChunks;
      size += fullChunks * dimePadding(chunkSize);
      size += dimePadding(lastChunkSize);
      size += dataSize;
    } 
    return size;
  }
  
  long getTransmissionSize() { return getTransmissionSize(4294967295L); }
  
  protected long getDataSize() {
    if (this.data instanceof byte[])
      return (byte[])this.data.length; 
    if (this.data instanceof DataHandler)
      return getDataSize((DataHandler)this.data); 
    return -1L;
  }
  
  protected long getDataSize(DataHandler dh) {
    long dataSize = -1L;
    try {
      DataSource ds = dh.getDataSource();
      if (ds instanceof FileDataSource) {
        FileDataSource fdh = (FileDataSource)ds;
        File df = fdh.getFile();
        if (!df.exists())
          throw new RuntimeException(Messages.getMessage("noFile", df.getAbsolutePath())); 
        dataSize = df.length();
      } else {
        int bytesread;
        dataSize = 0L;
        InputStream in = ds.getInputStream();
        byte[] readbuf = new byte[65536];
        do {
          bytesread = in.read(readbuf);
          if (bytesread <= 0)
            continue; 
          dataSize += bytesread;
        } while (bytesread > -1);
        if (in.markSupported()) {
          in.reset();
        } else {
          in.close();
        } 
      } 
    } catch (Exception e) {
      log.error(Messages.getMessage("exception00"), e);
    } 
    return dataSize;
  }
  
  protected DimeBodyPart() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\DimeBodyPart.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */