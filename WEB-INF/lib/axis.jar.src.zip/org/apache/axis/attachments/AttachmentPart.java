/*     */ package org.apache.axis.attachments;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Iterator;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.xml.soap.AttachmentPart;
/*     */ import javax.xml.soap.MimeHeader;
/*     */ import javax.xml.soap.MimeHeaders;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.apache.axis.Part;
/*     */ import org.apache.axis.components.image.ImageIOFactory;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.utils.IOUtils;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.axis.utils.SessionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AttachmentPart
/*     */   extends AttachmentPart
/*     */   implements Part
/*     */ {
/*  44 */   protected static Log log = LogFactory.getLog(AttachmentPart.class.getName());
/*     */   
/*     */   DataHandler datahandler;
/*     */   private MimeHeaders mimeHeaders;
/*     */   private Object contentObject;
/*     */   private String attachmentFile;
/*     */   
/*     */   public AttachmentPart() {
/*  52 */     this.datahandler = null;
/*     */ 
/*     */     
/*  55 */     this.mimeHeaders = new MimeHeaders();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     setMimeHeader("Content-Id", SessionUtils.generateSessionId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AttachmentPart(DataHandler dh) {
/*     */     this.datahandler = null;
/*     */     this.mimeHeaders = new MimeHeaders();
/*  78 */     setMimeHeader("Content-Id", SessionUtils.generateSessionId());
/*     */     
/*  80 */     this.datahandler = dh;
/*  81 */     if (dh != null) {
/*  82 */       setMimeHeader("Content-Type", dh.getContentType());
/*  83 */       DataSource ds = dh.getDataSource();
/*  84 */       if (ds instanceof ManagedMemoryDataSource) {
/*  85 */         extractFilename((ManagedMemoryDataSource)ds);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   protected void finalize() { dispose(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public DataHandler getActivationDataHandler() { return this.datahandler; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public String getContentType() { return getFirstMimeHeader("Content-Type"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void addMimeHeader(String header, String value) { this.mimeHeaders.addHeader(header, value); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFirstMimeHeader(String header) {
/* 137 */     String[] values = this.mimeHeaders.getHeader(header.toLowerCase());
/* 138 */     if (values != null && values.length > 0) {
/* 139 */       return values[0];
/*     */     }
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matches(MimeHeaders headers) {
/* 153 */     for (Iterator i = headers.getAllHeaders(); i.hasNext(); ) {
/* 154 */       MimeHeader hdr = (MimeHeader)i.next();
/* 155 */       String[] values = this.mimeHeaders.getHeader(hdr.getName());
/* 156 */       boolean found = false;
/* 157 */       if (values != null) {
/* 158 */         for (int j = 0; j < values.length; ) {
/* 159 */           if (!hdr.getValue().equalsIgnoreCase(values[j])) {
/*     */             j++; continue;
/*     */           } 
/* 162 */           found = true;
/*     */         } 
/*     */       }
/*     */       
/* 166 */       if (!found) {
/* 167 */         return false;
/*     */       }
/*     */     } 
/* 170 */     return true;
/*     */   }
/*     */ 
/*     */   
/* 174 */   public String getContentLocation() { return getFirstMimeHeader("Content-Location"); }
/*     */ 
/*     */ 
/*     */   
/* 178 */   public void setContentLocation(String loc) { setMimeHeader("Content-Location", loc); }
/*     */ 
/*     */ 
/*     */   
/* 182 */   public void setContentId(String newCid) { setMimeHeader("Content-Id", newCid); }
/*     */ 
/*     */ 
/*     */   
/* 186 */   public String getContentId() { return getFirstMimeHeader("Content-Id"); }
/*     */ 
/*     */ 
/*     */   
/* 190 */   public Iterator getMatchingMimeHeaders(String[] match) { return this.mimeHeaders.getMatchingHeaders(match); }
/*     */ 
/*     */ 
/*     */   
/* 194 */   public Iterator getNonMatchingMimeHeaders(String[] match) { return this.mimeHeaders.getNonMatchingHeaders(match); }
/*     */ 
/*     */ 
/*     */   
/* 198 */   public Iterator getAllMimeHeaders() { return this.mimeHeaders.getAllHeaders(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   public void setMimeHeader(String name, String value) { this.mimeHeaders.setHeader(name, value); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public void removeAllMimeHeaders() { this.mimeHeaders.removeAllHeaders(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public void removeMimeHeader(String header) { this.mimeHeaders.removeHeader(header); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataHandler getDataHandler() {
/* 245 */     if (this.datahandler == null) {
/* 246 */       throw new SOAPException(Messages.getMessage("noContent"));
/*     */     }
/* 248 */     return this.datahandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDataHandler(DataHandler datahandler) {
/* 266 */     if (datahandler == null) {
/* 267 */       throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
/*     */     }
/*     */     
/* 270 */     this.datahandler = datahandler;
/* 271 */     setMimeHeader("Content-Type", datahandler.getContentType());
/*     */     
/* 273 */     DataSource ds = datahandler.getDataSource();
/* 274 */     if (ds instanceof ManagedMemoryDataSource)
/*     */     {
/* 276 */       extractFilename((ManagedMemoryDataSource)ds);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getContent() throws SOAPException {
/* 316 */     if (this.contentObject != null) {
/* 317 */       return this.contentObject;
/*     */     }
/*     */     
/* 320 */     if (this.datahandler == null) {
/* 321 */       throw new SOAPException(Messages.getMessage("noContent"));
/*     */     }
/*     */     
/* 324 */     DataSource ds = this.datahandler.getDataSource();
/* 325 */     InputStream is = null;
/*     */     try {
/* 327 */       is = ds.getInputStream();
/* 328 */     } catch (IOException io) {
/* 329 */       log.error(Messages.getMessage("javaIOException00"), io);
/* 330 */       throw new SOAPException(io);
/*     */     } 
/* 332 */     if (ds.getContentType().equals("text/plain"))
/*     */       try {
/* 334 */         byte[] bytes = new byte[is.available()];
/* 335 */         IOUtils.readFully(is, bytes);
/* 336 */         return new String(bytes);
/* 337 */       } catch (IOException io) {
/* 338 */         log.error(Messages.getMessage("javaIOException00"), io);
/* 339 */         throw new SOAPException(io);
/*     */       }  
/* 341 */     if (ds.getContentType().equals("text/xml"))
/* 342 */       return new StreamSource(is); 
/* 343 */     if (ds.getContentType().equals("image/gif") || ds.getContentType().equals("image/jpeg")) {
/*     */       
/*     */       try {
/* 346 */         return ImageIOFactory.getImageIO().loadImage(is);
/* 347 */       } catch (Exception ex) {
/* 348 */         log.error(Messages.getMessage("javaIOException00"), ex);
/* 349 */         throw new SOAPException(ex);
/*     */       } 
/*     */     }
/* 352 */     return is;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContent(Object object, String contentType) {
/* 375 */     ManagedMemoryDataSource source = null;
/* 376 */     setMimeHeader("Content-Type", contentType);
/* 377 */     if (object instanceof String) {
/*     */       try {
/* 379 */         String s = (String)object;
/* 380 */         ByteArrayInputStream bais = new ByteArrayInputStream(s.getBytes());
/*     */         
/* 382 */         source = new ManagedMemoryDataSource(bais, 16384, contentType, true);
/*     */ 
/*     */         
/* 385 */         extractFilename(source);
/* 386 */         this.datahandler = new DataHandler(source);
/* 387 */         this.contentObject = object;
/*     */         return;
/* 389 */       } catch (IOException io) {
/* 390 */         log.error(Messages.getMessage("javaIOException00"), io);
/* 391 */         throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
/*     */       } 
/*     */     }
/* 394 */     if (object instanceof InputStream) {
/*     */       try {
/* 396 */         source = new ManagedMemoryDataSource((InputStream)object, 16384, contentType, true);
/*     */ 
/*     */         
/* 399 */         extractFilename(source);
/* 400 */         this.datahandler = new DataHandler(source);
/* 401 */         this.contentObject = null;
/*     */         return;
/* 403 */       } catch (IOException io) {
/* 404 */         log.error(Messages.getMessage("javaIOException00"), io);
/* 405 */         throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
/*     */       } 
/*     */     }
/* 408 */     if (object instanceof StreamSource) {
/*     */       try {
/* 410 */         source = new ManagedMemoryDataSource(((StreamSource)object).getInputStream(), 16384, contentType, true);
/*     */ 
/*     */         
/* 413 */         extractFilename(source);
/* 414 */         this.datahandler = new DataHandler(source);
/* 415 */         this.contentObject = null;
/*     */         return;
/* 417 */       } catch (IOException io) {
/* 418 */         log.error(Messages.getMessage("javaIOException00"), io);
/* 419 */         throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
/*     */       } 
/*     */     }
/*     */     
/* 423 */     throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearContent() {
/* 434 */     this.datahandler = null;
/* 435 */     this.contentObject = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() throws SOAPException {
/* 448 */     if (this.datahandler == null) {
/* 449 */       return 0;
/*     */     }
/* 451 */     ByteArrayOutputStream bout = new ByteArrayOutputStream();
/*     */     try {
/* 453 */       this.datahandler.writeTo(bout);
/* 454 */     } catch (IOException ex) {
/* 455 */       log.error(Messages.getMessage("javaIOException00"), ex);
/* 456 */       throw new SOAPException(Messages.getMessage("javaIOException01", ex.getMessage()), ex);
/*     */     } 
/* 458 */     return bout.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 471 */   public String[] getMimeHeader(String name) { return this.mimeHeaders.getHeader(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 482 */   public String getContentIdRef() { return "cid:" + getContentId(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void extractFilename(ManagedMemoryDataSource source) {
/* 493 */     if (source.getDiskCacheFile() != null) {
/* 494 */       String path = source.getDiskCacheFile().getAbsolutePath();
/* 495 */       setAttachmentFile(path);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 505 */   protected void setAttachmentFile(String path) { this.attachmentFile = path; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 514 */   public void detachAttachmentFile() { this.attachmentFile = null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 523 */   public String getAttachmentFile() { return this.attachmentFile; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 532 */     if (this.attachmentFile != null) {
/* 533 */       DataSource ds = this.datahandler.getDataSource();
/* 534 */       if (ds instanceof ManagedMemoryDataSource) {
/* 535 */         ((ManagedMemoryDataSource)ds).delete();
/*     */       } else {
/* 537 */         File f = new File(this.attachmentFile);
/*     */         
/* 539 */         f.delete();
/*     */       } 
/*     */       
/* 542 */       setAttachmentFile(null);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 547 */     this.datahandler = null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\AttachmentPart.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */