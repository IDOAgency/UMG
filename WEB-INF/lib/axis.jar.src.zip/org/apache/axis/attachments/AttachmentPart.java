package org.apache.axis.attachments;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.transform.stream.StreamSource;
import org.apache.axis.Part;
import org.apache.axis.components.image.ImageIOFactory;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.IOUtils;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.SessionUtils;
import org.apache.commons.logging.Log;

public class AttachmentPart extends AttachmentPart implements Part {
  protected static Log log = LogFactory.getLog(AttachmentPart.class.getName());
  
  DataHandler datahandler;
  
  private MimeHeaders mimeHeaders;
  
  private Object contentObject;
  
  private String attachmentFile;
  
  public AttachmentPart() {
    this.datahandler = null;
    this.mimeHeaders = new MimeHeaders();
    setMimeHeader("Content-Id", SessionUtils.generateSessionId());
  }
  
  public AttachmentPart(DataHandler dh) {
    this.datahandler = null;
    this.mimeHeaders = new MimeHeaders();
    setMimeHeader("Content-Id", SessionUtils.generateSessionId());
    this.datahandler = dh;
    if (dh != null) {
      setMimeHeader("Content-Type", dh.getContentType());
      DataSource ds = dh.getDataSource();
      if (ds instanceof ManagedMemoryDataSource)
        extractFilename((ManagedMemoryDataSource)ds); 
    } 
  }
  
  protected void finalize() { dispose(); }
  
  public DataHandler getActivationDataHandler() { return this.datahandler; }
  
  public String getContentType() { return getFirstMimeHeader("Content-Type"); }
  
  public void addMimeHeader(String header, String value) { this.mimeHeaders.addHeader(header, value); }
  
  public String getFirstMimeHeader(String header) {
    String[] values = this.mimeHeaders.getHeader(header.toLowerCase());
    if (values != null && values.length > 0)
      return values[0]; 
    return null;
  }
  
  public boolean matches(MimeHeaders headers) {
    for (Iterator i = headers.getAllHeaders(); i.hasNext(); ) {
      MimeHeader hdr = (MimeHeader)i.next();
      String[] values = this.mimeHeaders.getHeader(hdr.getName());
      boolean found = false;
      if (values != null)
        for (int j = 0; j < values.length; ) {
          if (!hdr.getValue().equalsIgnoreCase(values[j])) {
            j++;
            continue;
          } 
          found = true;
        }  
      if (!found)
        return false; 
    } 
    return true;
  }
  
  public String getContentLocation() { return getFirstMimeHeader("Content-Location"); }
  
  public void setContentLocation(String loc) { setMimeHeader("Content-Location", loc); }
  
  public void setContentId(String newCid) { setMimeHeader("Content-Id", newCid); }
  
  public String getContentId() { return getFirstMimeHeader("Content-Id"); }
  
  public Iterator getMatchingMimeHeaders(String[] match) { return this.mimeHeaders.getMatchingHeaders(match); }
  
  public Iterator getNonMatchingMimeHeaders(String[] match) { return this.mimeHeaders.getNonMatchingHeaders(match); }
  
  public Iterator getAllMimeHeaders() { return this.mimeHeaders.getAllHeaders(); }
  
  public void setMimeHeader(String name, String value) { this.mimeHeaders.setHeader(name, value); }
  
  public void removeAllMimeHeaders() { this.mimeHeaders.removeAllHeaders(); }
  
  public void removeMimeHeader(String header) { this.mimeHeaders.removeHeader(header); }
  
  public DataHandler getDataHandler() {
    if (this.datahandler == null)
      throw new SOAPException(Messages.getMessage("noContent")); 
    return this.datahandler;
  }
  
  public void setDataHandler(DataHandler datahandler) {
    if (datahandler == null)
      throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00")); 
    this.datahandler = datahandler;
    setMimeHeader("Content-Type", datahandler.getContentType());
    DataSource ds = datahandler.getDataSource();
    if (ds instanceof ManagedMemoryDataSource)
      extractFilename((ManagedMemoryDataSource)ds); 
  }
  
  public Object getContent() throws SOAPException {
    if (this.contentObject != null)
      return this.contentObject; 
    if (this.datahandler == null)
      throw new SOAPException(Messages.getMessage("noContent")); 
    DataSource ds = this.datahandler.getDataSource();
    InputStream is = null;
    try {
      is = ds.getInputStream();
    } catch (IOException io) {
      log.error(Messages.getMessage("javaIOException00"), io);
      throw new SOAPException(io);
    } 
    if (ds.getContentType().equals("text/plain"))
      try {
        byte[] bytes = new byte[is.available()];
        IOUtils.readFully(is, bytes);
        return new String(bytes);
      } catch (IOException io) {
        log.error(Messages.getMessage("javaIOException00"), io);
        throw new SOAPException(io);
      }  
    if (ds.getContentType().equals("text/xml"))
      return new StreamSource(is); 
    if (ds.getContentType().equals("image/gif") || ds.getContentType().equals("image/jpeg"))
      try {
        return ImageIOFactory.getImageIO().loadImage(is);
      } catch (Exception ex) {
        log.error(Messages.getMessage("javaIOException00"), ex);
        throw new SOAPException(ex);
      }  
    return is;
  }
  
  public void setContent(Object object, String contentType) {
    ManagedMemoryDataSource source = null;
    setMimeHeader("Content-Type", contentType);
    if (object instanceof String)
      try {
        String s = (String)object;
        ByteArrayInputStream bais = new ByteArrayInputStream(s.getBytes());
        source = new ManagedMemoryDataSource(bais, 16384, contentType, true);
        extractFilename(source);
        this.datahandler = new DataHandler(source);
        this.contentObject = object;
        return;
      } catch (IOException io) {
        log.error(Messages.getMessage("javaIOException00"), io);
        throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
      }  
    if (object instanceof InputStream)
      try {
        source = new ManagedMemoryDataSource((InputStream)object, 16384, contentType, true);
        extractFilename(source);
        this.datahandler = new DataHandler(source);
        this.contentObject = null;
        return;
      } catch (IOException io) {
        log.error(Messages.getMessage("javaIOException00"), io);
        throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
      }  
    if (object instanceof StreamSource)
      try {
        source = new ManagedMemoryDataSource(((StreamSource)object).getInputStream(), 16384, contentType, true);
        extractFilename(source);
        this.datahandler = new DataHandler(source);
        this.contentObject = null;
        return;
      } catch (IOException io) {
        log.error(Messages.getMessage("javaIOException00"), io);
        throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
      }  
    throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
  }
  
  public void clearContent() {
    this.datahandler = null;
    this.contentObject = null;
  }
  
  public int getSize() throws SOAPException {
    if (this.datahandler == null)
      return 0; 
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    try {
      this.datahandler.writeTo(bout);
    } catch (IOException ex) {
      log.error(Messages.getMessage("javaIOException00"), ex);
      throw new SOAPException(Messages.getMessage("javaIOException01", ex.getMessage()), ex);
    } 
    return bout.size();
  }
  
  public String[] getMimeHeader(String name) { return this.mimeHeaders.getHeader(name); }
  
  public String getContentIdRef() { return "cid:" + getContentId(); }
  
  private void extractFilename(ManagedMemoryDataSource source) {
    if (source.getDiskCacheFile() != null) {
      String path = source.getDiskCacheFile().getAbsolutePath();
      setAttachmentFile(path);
    } 
  }
  
  protected void setAttachmentFile(String path) { this.attachmentFile = path; }
  
  public void detachAttachmentFile() { this.attachmentFile = null; }
  
  public String getAttachmentFile() { return this.attachmentFile; }
  
  public void dispose() {
    if (this.attachmentFile != null) {
      DataSource ds = this.datahandler.getDataSource();
      if (ds instanceof ManagedMemoryDataSource) {
        ((ManagedMemoryDataSource)ds).delete();
      } else {
        File f = new File(this.attachmentFile);
        f.delete();
      } 
      setAttachmentFile(null);
    } 
    this.datahandler = null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\AttachmentPart.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */