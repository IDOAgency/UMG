package org.apache.axis.attachments;

import java.io.IOException;
import org.apache.axis.AxisFault;
import org.apache.axis.utils.Messages;

public final class DimeAttachmentStreams extends IncomingAttachmentStreams {
  private DimeDelimitedInputStream _delimitedStream = null;
  
  public DimeAttachmentStreams(DimeDelimitedInputStream stream) throws AxisFault {
    if (stream == null)
      throw new AxisFault(Messages.getMessage("nullDelimitedStream")); 
    this._delimitedStream = stream;
  }
  
  public IncomingAttachmentStreams.IncomingAttachmentInputStream getNextStream() throws AxisFault {
    IncomingAttachmentStreams.IncomingAttachmentInputStream stream = null;
    if (!isReadyToGetNextStream())
      throw new IllegalStateException(Messages.getMessage("nextStreamNotReady")); 
    try {
      this._delimitedStream = this._delimitedStream.getNextStream();
      if (this._delimitedStream == null)
        return null; 
      stream = new IncomingAttachmentStreams.IncomingAttachmentInputStream(this, this._delimitedStream);
    } catch (IOException e) {
      throw new AxisFault(Messages.getMessage("failedToGetDelimitedAttachmentStream"), e);
    } 
    String value = this._delimitedStream.getContentId();
    if (value != null && value.length() > 0)
      stream.addHeader("Content-Id", value); 
    value = this._delimitedStream.getType();
    if (value != null && value.length() > 0)
      stream.addHeader("Content-Type", value); 
    setReadyToGetNextStream(false);
    return stream;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\DimeAttachmentStreams.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */