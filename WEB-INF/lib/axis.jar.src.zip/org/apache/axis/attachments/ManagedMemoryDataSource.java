/*     */ package org.apache.axis.attachments;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.activation.DataSource;
/*     */ import org.apache.axis.InternalException;
/*     */ import org.apache.axis.MessageContext;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManagedMemoryDataSource
/*     */   implements DataSource
/*     */ {
/*  36 */   protected static Log log = LogFactory.getLog(ManagedMemoryDataSource.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   protected String contentType = "application/octet-stream";
/*     */ 
/*     */   
/*  46 */   InputStream ss = null;
/*     */ 
/*     */   
/*     */   public static final int MIN_MEMORY_DISK_CACHED = -1;
/*     */ 
/*     */   
/*     */   public static final int MAX_MEMORY_DISK_CACHED = 16384;
/*     */ 
/*     */   
/*  55 */   protected int maxCached = 16384;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   protected File diskCacheFile = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected WeakHashMap readers = new WeakHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean deleted = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int READ_CHUNK_SZ = 32768;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean debugEnabled = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public ManagedMemoryDataSource(InputStream ss, int maxCached, String contentType) throws IOException { this(ss, maxCached, contentType, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedMemoryDataSource(InputStream ss, int maxCached, String contentType, boolean readall) throws IOException {
/* 120 */     if (ss instanceof BufferedInputStream) {
/* 121 */       this.ss = ss;
/*     */     } else {
/* 123 */       this.ss = new BufferedInputStream(ss);
/*     */     } 
/* 125 */     this.maxCached = maxCached;
/*     */     
/* 127 */     if (null != contentType && contentType.length() != 0) {
/* 128 */       this.contentType = contentType;
/*     */     }
/*     */     
/* 131 */     if (maxCached < -1) {
/* 132 */       throw new IllegalArgumentException(Messages.getMessage("badMaxCached", "" + maxCached));
/*     */     }
/*     */ 
/*     */     
/* 136 */     if (log.isDebugEnabled()) {
/* 137 */       this.debugEnabled = true;
/*     */     }
/*     */ 
/*     */     
/* 141 */     if (readall) {
/* 142 */       byte[] readbuffer = new byte[32768];
/* 143 */       int read = 0;
/*     */       
/*     */       do {
/* 146 */         read = ss.read(readbuffer);
/*     */         
/* 148 */         if (read <= 0)
/* 149 */           continue;  write(readbuffer, read);
/*     */       }
/* 151 */       while (read > -1);
/*     */       
/* 153 */       close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public String getContentType() { return this.contentType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public InputStream getInputStream() throws IOException { return new Instream(this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 193 */     String ret = null;
/*     */     
/*     */     try {
/* 196 */       flushToDisk();
/*     */       
/* 198 */       if (this.diskCacheFile != null) {
/* 199 */         ret = this.diskCacheFile.getAbsolutePath();
/*     */       }
/* 201 */     } catch (Exception e) {
/* 202 */       this.diskCacheFile = null;
/*     */     } 
/*     */     
/* 205 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   public OutputStream getOutputStream() throws IOException { return null; }
/*     */ 
/*     */ 
/*     */   
/* 223 */   protected LinkedList memorybuflist = new LinkedList();
/*     */ 
/*     */ 
/*     */   
/* 227 */   protected byte[] currentMemoryBuf = null;
/*     */ 
/*     */   
/* 230 */   protected int currentMemoryBufSz = 0;
/*     */ 
/*     */ 
/*     */   
/* 234 */   protected long totalsz = 0L;
/*     */ 
/*     */   
/* 237 */   protected BufferedOutputStream cachediskstream = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean closed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   protected void write(byte[] data) throws IOException { write(data, data.length); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void write(byte[] data, int length) throws IOException {
/* 266 */     if (this.closed) {
/* 267 */       throw new IOException(Messages.getMessage("streamClosed"));
/*     */     }
/*     */     
/* 270 */     int writesz = length;
/* 271 */     int byteswritten = 0;
/*     */     
/* 273 */     if (null != this.memorybuflist && this.totalsz + writesz > this.maxCached)
/*     */     {
/* 275 */       if (null == this.cachediskstream) {
/* 276 */         flushToDisk();
/*     */       }
/*     */     }
/*     */     
/* 280 */     if (this.memorybuflist != null) {
/*     */       do {
/* 282 */         if (null == this.currentMemoryBuf) {
/* 283 */           this.currentMemoryBuf = new byte[32768];
/* 284 */           this.currentMemoryBufSz = 0;
/*     */           
/* 286 */           this.memorybuflist.add(this.currentMemoryBuf);
/*     */         } 
/*     */ 
/*     */         
/* 290 */         int bytes2write = Math.min(writesz - byteswritten, this.currentMemoryBuf.length - this.currentMemoryBufSz);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 295 */         System.arraycopy(data, byteswritten, this.currentMemoryBuf, this.currentMemoryBufSz, bytes2write);
/*     */ 
/*     */         
/* 298 */         byteswritten += bytes2write;
/* 299 */         this.currentMemoryBufSz += bytes2write;
/*     */         
/* 301 */         if (byteswritten >= writesz)
/*     */           continue; 
/* 303 */         this.currentMemoryBuf = new byte[32768];
/* 304 */         this.currentMemoryBufSz = 0;
/*     */         
/* 306 */         this.memorybuflist.add(this.currentMemoryBuf);
/*     */       }
/* 308 */       while (byteswritten < writesz);
/*     */     }
/*     */     
/* 311 */     if (null != this.cachediskstream) {
/* 312 */       this.cachediskstream.write(data, 0, length);
/*     */     }
/*     */     
/* 315 */     this.totalsz += writesz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void close() {
/* 328 */     if (!this.closed) {
/* 329 */       this.closed = true;
/*     */       
/* 331 */       if (null != this.cachediskstream) {
/* 332 */         this.cachediskstream.close();
/*     */         
/* 334 */         this.cachediskstream = null;
/*     */       } 
/*     */       
/* 337 */       if (null != this.memorybuflist) {
/* 338 */         if (this.currentMemoryBufSz > 0) {
/* 339 */           byte[] tmp = new byte[this.currentMemoryBufSz];
/*     */ 
/*     */           
/* 342 */           System.arraycopy(this.currentMemoryBuf, 0, tmp, 0, this.currentMemoryBufSz);
/*     */           
/* 344 */           this.memorybuflist.set(this.memorybuflist.size() - 1, tmp);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 349 */         this.currentMemoryBuf = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() {
/* 356 */     if (null != this.cachediskstream) {
/* 357 */       this.cachediskstream.close();
/*     */       
/* 359 */       this.cachediskstream = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void flushToDisk() {
/* 372 */     LinkedList ml = this.memorybuflist;
/*     */     
/* 374 */     log.debug(Messages.getMessage("maxCached", "" + this.maxCached, "" + this.totalsz));
/*     */ 
/*     */     
/* 377 */     if (ml != null && 
/* 378 */       null == this.cachediskstream) {
/*     */       try {
/* 380 */         MessageContext mc = MessageContext.getCurrentContext();
/* 381 */         String attdir = (mc == null) ? null : mc.getStrProp("attachments.directory");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 386 */         this.diskCacheFile = File.createTempFile("Axis", ".att", (attdir == null) ? null : new File(attdir));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 392 */         if (log.isDebugEnabled()) {
/* 393 */           log.debug(Messages.getMessage("diskCache", this.diskCacheFile.getAbsolutePath()));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 398 */         this.cachediskstream = new BufferedOutputStream(new FileOutputStream(this.diskCacheFile));
/*     */ 
/*     */         
/* 401 */         int listsz = ml.size();
/*     */ 
/*     */         
/* 404 */         Iterator it = ml.iterator();
/* 405 */         while (it.hasNext()) {
/* 406 */           byte[] rbuf = (byte[])it.next();
/* 407 */           int bwrite = (listsz-- == 0) ? this.currentMemoryBufSz : rbuf.length;
/*     */ 
/*     */ 
/*     */           
/* 411 */           this.cachediskstream.write(rbuf, 0, bwrite);
/*     */           
/* 413 */           if (this.closed) {
/* 414 */             this.cachediskstream.close();
/*     */             
/* 416 */             this.cachediskstream = null;
/*     */           } 
/*     */         } 
/*     */         
/* 420 */         this.memorybuflist = null;
/* 421 */       } catch (SecurityException se) {
/* 422 */         this.diskCacheFile = null;
/* 423 */         this.cachediskstream = null;
/* 424 */         this.maxCached = Integer.MAX_VALUE;
/*     */         
/* 426 */         log.info(Messages.getMessage("nodisk00"), se);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean delete() {
/* 434 */     boolean ret = false;
/*     */     
/* 436 */     this.deleted = true;
/*     */     
/* 438 */     this.memorybuflist = null;
/*     */     
/* 440 */     if (this.diskCacheFile != null) {
/* 441 */       if (this.cachediskstream != null) {
/*     */         try {
/* 443 */           this.cachediskstream.close();
/* 444 */         } catch (Exception e) {}
/*     */ 
/*     */         
/* 447 */         this.cachediskstream = null;
/*     */       } 
/*     */       
/* 450 */       Object[] array = this.readers.keySet().toArray();
/* 451 */       for (i = 0; i < array.length; i++) {
/* 452 */         Instream stream = (Instream)array[i];
/* 453 */         if (null != stream) {
/*     */           try {
/* 455 */             stream.close();
/* 456 */           } catch (Exception e) {}
/*     */         }
/*     */       } 
/*     */       
/* 460 */       this.readers.clear();
/*     */       
/*     */       try {
/* 463 */         this.diskCacheFile.delete();
/*     */         
/* 465 */         ret = true;
/* 466 */       } catch (Exception i) {
/*     */         Exception e;
/*     */         
/* 469 */         this.diskCacheFile.deleteOnExit();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 474 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 480 */   protected static Log is_log = LogFactory.getLog(Instream.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Instream
/*     */     extends InputStream
/*     */   {
/*     */     protected long bread;
/*     */ 
/*     */ 
/*     */     
/*     */     FileInputStream fin;
/*     */ 
/*     */ 
/*     */     
/*     */     int currentIndex;
/*     */ 
/*     */ 
/*     */     
/*     */     byte[] currentBuf;
/*     */ 
/*     */     
/*     */     int currentBufPos;
/*     */ 
/*     */     
/*     */     boolean readClosed;
/*     */ 
/*     */     
/*     */     private final ManagedMemoryDataSource this$0;
/*     */ 
/*     */ 
/*     */     
/*     */     protected Instream(ManagedMemoryDataSource this$0) throws IOException {
/* 514 */       this.this$0 = this$0; this.bread = 0L; this.fin = null; this.currentIndex = 0; this.currentBuf = null; this.currentBufPos = 0;
/*     */       this.readClosed = false;
/* 516 */       if (this$0.deleted) {
/* 517 */         throw new IOException(Messages.getMessage("resourceDeleted"));
/*     */       }
/*     */ 
/*     */       
/* 521 */       this$0.readers.put(this, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int available() throws IOException {
/* 534 */       if (this.this$0.deleted) {
/* 535 */         throw new IOException(Messages.getMessage("resourceDeleted"));
/*     */       }
/*     */ 
/*     */       
/* 539 */       if (this.readClosed) {
/* 540 */         throw new IOException(Messages.getMessage("streamClosed"));
/*     */       }
/*     */ 
/*     */       
/* 544 */       int ret = (new Long(Math.min(2147483647L, this.this$0.totalsz - this.bread))).intValue();
/*     */       
/* 546 */       if (this.this$0.debugEnabled) {
/* 547 */         ManagedMemoryDataSource.is_log.debug("available() = " + ret + ".");
/*     */       }
/*     */       
/* 550 */       return ret;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 562 */       synchronized (this.this$0) {
/* 563 */         byte[] retb = new byte[1];
/* 564 */         int br = read(retb, 0, 1);
/*     */         
/* 566 */         if (br == -1) {
/* 567 */           return -1;
/*     */         }
/* 569 */         return 0xFF & retb[0];
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean markSupported() {
/* 580 */       if (this.this$0.debugEnabled) {
/* 581 */         ManagedMemoryDataSource.is_log.debug("markSupported() = false.");
/*     */       }
/*     */       
/* 584 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mark(int readlimit) {
/* 594 */       if (this.this$0.debugEnabled) {
/* 595 */         ManagedMemoryDataSource.is_log.debug("mark()");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void reset() {
/* 606 */       if (this.this$0.debugEnabled) {
/* 607 */         ManagedMemoryDataSource.is_log.debug("reset()");
/*     */       }
/*     */       
/* 610 */       throw new IOException(Messages.getMessage("noResetMark"));
/*     */     }
/*     */ 
/*     */     
/*     */     public long skip(long skipped) throws IOException {
/* 615 */       if (this.this$0.debugEnabled) {
/* 616 */         ManagedMemoryDataSource.is_log.debug("skip(" + skipped + ").");
/*     */       }
/*     */       
/* 619 */       if (this.this$0.deleted) {
/* 620 */         throw new IOException(Messages.getMessage("resourceDeleted"));
/*     */       }
/*     */ 
/*     */       
/* 624 */       if (this.readClosed) {
/* 625 */         throw new IOException(Messages.getMessage("streamClosed"));
/*     */       }
/*     */ 
/*     */       
/* 629 */       if (skipped < 1L) {
/* 630 */         return 0L;
/*     */       }
/*     */       
/* 633 */       synchronized (this.this$0) {
/* 634 */         skipped = Math.min(skipped, this.this$0.totalsz - this.bread);
/*     */ 
/*     */ 
/*     */         
/* 638 */         if (skipped == 0L) {
/* 639 */           return 0L;
/*     */         }
/*     */         
/* 642 */         List ml = this.this$0.memorybuflist;
/* 643 */         int bwritten = 0;
/*     */         
/* 645 */         if (ml != null) {
/* 646 */           if (null == this.currentBuf) {
/* 647 */             this.currentBuf = (byte[])ml.get(this.currentIndex);
/* 648 */             this.currentBufPos = 0;
/*     */           } 
/*     */           
/*     */           do {
/* 652 */             long bcopy = Math.min((this.currentBuf.length - this.currentBufPos), skipped - bwritten);
/*     */ 
/*     */ 
/*     */             
/* 656 */             bwritten = (int)(bwritten + bcopy);
/* 657 */             this.currentBufPos = (int)(this.currentBufPos + bcopy);
/*     */             
/* 659 */             if (bwritten >= skipped)
/* 660 */               continue;  this.currentBuf = (byte[])ml.get(++this.currentIndex);
/* 661 */             this.currentBufPos = 0;
/*     */           }
/* 663 */           while (bwritten < skipped);
/*     */         } 
/*     */         
/* 666 */         if (null != this.fin) {
/* 667 */           this.fin.skip(skipped);
/*     */         }
/*     */         
/* 670 */         this.bread += skipped;
/*     */       } 
/*     */       
/* 673 */       if (this.this$0.debugEnabled) {
/* 674 */         ManagedMemoryDataSource.is_log.debug("skipped " + skipped + ".");
/*     */       }
/*     */       
/* 677 */       return skipped;
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 682 */       if (this.this$0.debugEnabled) {
/* 683 */         ManagedMemoryDataSource.is_log.debug(hashCode() + " read(" + off + ", " + len + ")");
/*     */       }
/*     */ 
/*     */       
/* 687 */       if (this.this$0.deleted) {
/* 688 */         throw new IOException(Messages.getMessage("resourceDeleted"));
/*     */       }
/*     */ 
/*     */       
/* 692 */       if (this.readClosed) {
/* 693 */         throw new IOException(Messages.getMessage("streamClosed"));
/*     */       }
/*     */ 
/*     */       
/* 697 */       if (b == null) {
/* 698 */         throw new InternalException(Messages.getMessage("nullInput"));
/*     */       }
/*     */       
/* 701 */       if (off < 0) {
/* 702 */         throw new IndexOutOfBoundsException(Messages.getMessage("negOffset", "" + off));
/*     */       }
/*     */ 
/*     */       
/* 706 */       if (len < 0) {
/* 707 */         throw new IndexOutOfBoundsException(Messages.getMessage("length", "" + len));
/*     */       }
/*     */ 
/*     */       
/* 711 */       if (len + off > b.length) {
/* 712 */         throw new IndexOutOfBoundsException(Messages.getMessage("writeBeyond"));
/*     */       }
/*     */ 
/*     */       
/* 716 */       if (len == 0) {
/* 717 */         return 0;
/*     */       }
/*     */       
/* 720 */       int bwritten = 0;
/*     */       
/* 722 */       synchronized (this.this$0) {
/* 723 */         if (this.bread == this.this$0.totalsz) {
/* 724 */           return -1;
/*     */         }
/*     */         
/* 727 */         List ml = this.this$0.memorybuflist;
/*     */         
/* 729 */         long longlen = len;
/* 730 */         longlen = Math.min(longlen, this.this$0.totalsz - this.bread);
/*     */ 
/*     */ 
/*     */         
/* 734 */         len = (new Long(longlen)).intValue();
/*     */         
/* 736 */         if (this.this$0.debugEnabled) {
/* 737 */           ManagedMemoryDataSource.is_log.debug("len = " + len);
/*     */         }
/*     */         
/* 740 */         if (ml != null) {
/* 741 */           if (null == this.currentBuf) {
/* 742 */             this.currentBuf = (byte[])ml.get(this.currentIndex);
/* 743 */             this.currentBufPos = 0;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           do {
/* 749 */             int bcopy = Math.min(this.currentBuf.length - this.currentBufPos, len - bwritten);
/*     */ 
/*     */ 
/*     */             
/* 753 */             System.arraycopy(this.currentBuf, this.currentBufPos, b, off + bwritten, bcopy);
/*     */ 
/*     */             
/* 756 */             bwritten += bcopy;
/* 757 */             this.currentBufPos += bcopy;
/*     */             
/* 759 */             if (bwritten >= len)
/* 760 */               continue;  this.currentBuf = (byte[])ml.get(++this.currentIndex);
/* 761 */             this.currentBufPos = 0;
/*     */           }
/* 763 */           while (bwritten < len);
/*     */         } 
/*     */         
/* 766 */         if (bwritten == 0 && null != this.this$0.diskCacheFile) {
/* 767 */           if (this.this$0.debugEnabled) {
/* 768 */             ManagedMemoryDataSource.is_log.debug(Messages.getMessage("reading", "" + len));
/*     */           }
/*     */           
/* 771 */           if (null == this.fin) {
/* 772 */             if (this.this$0.debugEnabled) {
/* 773 */               ManagedMemoryDataSource.is_log.debug(Messages.getMessage("openBread", this.this$0.diskCacheFile.getCanonicalPath()));
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 779 */             if (this.this$0.debugEnabled) {
/* 780 */               ManagedMemoryDataSource.is_log.debug(Messages.getMessage("openBread", "" + this.bread));
/*     */             }
/*     */ 
/*     */             
/* 784 */             this.fin = new FileInputStream(this.this$0.diskCacheFile);
/*     */             
/* 786 */             if (this.bread > 0L) {
/* 787 */               this.fin.skip(this.bread);
/*     */             }
/*     */           } 
/*     */           
/* 791 */           if (this.this$0.cachediskstream != null) {
/* 792 */             if (this.this$0.debugEnabled) {
/* 793 */               ManagedMemoryDataSource.is_log.debug(Messages.getMessage("flushing"));
/*     */             }
/*     */             
/* 796 */             this.this$0.cachediskstream.flush();
/*     */           } 
/*     */           
/* 799 */           if (this.this$0.debugEnabled) {
/* 800 */             ManagedMemoryDataSource.is_log.debug(Messages.getMessage("flushing"));
/* 801 */             ManagedMemoryDataSource.is_log.debug("len=" + len);
/* 802 */             ManagedMemoryDataSource.is_log.debug("off=" + off);
/* 803 */             ManagedMemoryDataSource.is_log.debug("b.length=" + b.length);
/*     */           } 
/*     */           
/* 806 */           bwritten = this.fin.read(b, off, len);
/*     */         } 
/*     */         
/* 809 */         if (bwritten > 0) {
/* 810 */           this.bread += bwritten;
/*     */         }
/*     */       } 
/*     */       
/* 814 */       if (this.this$0.debugEnabled) {
/* 815 */         ManagedMemoryDataSource.is_log.debug(hashCode() + Messages.getMessage("read", "" + bwritten));
/*     */       }
/*     */ 
/*     */       
/* 819 */       return bwritten;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void close() {
/* 829 */       if (this.this$0.debugEnabled) {
/* 830 */         ManagedMemoryDataSource.is_log.debug("close()");
/*     */       }
/*     */       
/* 833 */       if (!this.readClosed) {
/* 834 */         this.this$0.readers.remove(this);
/*     */         
/* 836 */         this.readClosed = true;
/*     */         
/* 838 */         if (this.fin != null) {
/* 839 */           this.fin.close();
/*     */         }
/*     */         
/* 842 */         this.fin = null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 847 */     protected void finalize() { close(); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] arg) {
/*     */     try {
/* 861 */       String readFile = arg[0];
/* 862 */       String writeFile = arg[1];
/* 863 */       FileInputStream ss = new FileInputStream(readFile);
/*     */       
/* 865 */       ManagedMemoryDataSource ms = new ManagedMemoryDataSource(ss, 1048576, "foo/data", true);
/*     */       
/* 867 */       DataHandler dh = new DataHandler(ms);
/*     */       
/* 869 */       InputStream is = dh.getInputStream();
/* 870 */       FileOutputStream fo = new FileOutputStream(writeFile);
/*     */       
/* 872 */       byte[] buf = new byte[512];
/* 873 */       int read = 0;
/*     */       
/*     */       do {
/* 876 */         read = is.read(buf);
/*     */         
/* 878 */         if (read <= 0)
/* 879 */           continue;  fo.write(buf, 0, read);
/*     */       }
/* 881 */       while (read > -1);
/*     */       
/* 883 */       fo.close();
/* 884 */       is.close();
/* 885 */     } catch (Exception e) {
/* 886 */       log.error(Messages.getMessage("exception00"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 895 */   public File getDiskCacheFile() { return this.diskCacheFile; }
/*     */   
/*     */   protected ManagedMemoryDataSource() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\ManagedMemoryDataSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */