package org.apache.axis.attachments;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.WeakHashMap;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import org.apache.axis.InternalException;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class ManagedMemoryDataSource implements DataSource {
  protected static Log log = LogFactory.getLog(ManagedMemoryDataSource.class.getName());
  
  protected String contentType = "application/octet-stream";
  
  InputStream ss = null;
  
  public static final int MIN_MEMORY_DISK_CACHED = -1;
  
  public static final int MAX_MEMORY_DISK_CACHED = 16384;
  
  protected int maxCached = 16384;
  
  protected File diskCacheFile = null;
  
  protected WeakHashMap readers = new WeakHashMap();
  
  protected boolean deleted = false;
  
  public static final int READ_CHUNK_SZ = 32768;
  
  protected boolean debugEnabled = false;
  
  public ManagedMemoryDataSource(InputStream ss, int maxCached, String contentType) throws IOException { this(ss, maxCached, contentType, false); }
  
  public ManagedMemoryDataSource(InputStream ss, int maxCached, String contentType, boolean readall) throws IOException {
    if (ss instanceof BufferedInputStream) {
      this.ss = ss;
    } else {
      this.ss = new BufferedInputStream(ss);
    } 
    this.maxCached = maxCached;
    if (null != contentType && contentType.length() != 0)
      this.contentType = contentType; 
    if (maxCached < -1)
      throw new IllegalArgumentException(Messages.getMessage("badMaxCached", "" + maxCached)); 
    if (log.isDebugEnabled())
      this.debugEnabled = true; 
    if (readall) {
      byte[] readbuffer = new byte[32768];
      int read = 0;
      do {
        read = ss.read(readbuffer);
        if (read <= 0)
          continue; 
        write(readbuffer, read);
      } while (read > -1);
      close();
    } 
  }
  
  public String getContentType() { return this.contentType; }
  
  public InputStream getInputStream() throws IOException { return new Instream(this); }
  
  public String getName() {
    String ret = null;
    try {
      flushToDisk();
      if (this.diskCacheFile != null)
        ret = this.diskCacheFile.getAbsolutePath(); 
    } catch (Exception e) {
      this.diskCacheFile = null;
    } 
    return ret;
  }
  
  public OutputStream getOutputStream() throws IOException { return null; }
  
  protected LinkedList memorybuflist = new LinkedList();
  
  protected byte[] currentMemoryBuf = null;
  
  protected int currentMemoryBufSz = 0;
  
  protected long totalsz = 0L;
  
  protected BufferedOutputStream cachediskstream = null;
  
  protected boolean closed = false;
  
  protected void write(byte[] data) throws IOException { write(data, data.length); }
  
  protected void write(byte[] data, int length) throws IOException {
    if (this.closed)
      throw new IOException(Messages.getMessage("streamClosed")); 
    int writesz = length;
    int byteswritten = 0;
    if (null != this.memorybuflist && this.totalsz + writesz > this.maxCached)
      if (null == this.cachediskstream)
        flushToDisk();  
    if (this.memorybuflist != null)
      do {
        if (null == this.currentMemoryBuf) {
          this.currentMemoryBuf = new byte[32768];
          this.currentMemoryBufSz = 0;
          this.memorybuflist.add(this.currentMemoryBuf);
        } 
        int bytes2write = Math.min(writesz - byteswritten, this.currentMemoryBuf.length - this.currentMemoryBufSz);
        System.arraycopy(data, byteswritten, this.currentMemoryBuf, this.currentMemoryBufSz, bytes2write);
        byteswritten += bytes2write;
        this.currentMemoryBufSz += bytes2write;
        if (byteswritten >= writesz)
          continue; 
        this.currentMemoryBuf = new byte[32768];
        this.currentMemoryBufSz = 0;
        this.memorybuflist.add(this.currentMemoryBuf);
      } while (byteswritten < writesz); 
    if (null != this.cachediskstream)
      this.cachediskstream.write(data, 0, length); 
    this.totalsz += writesz;
  }
  
  protected void close() {
    if (!this.closed) {
      this.closed = true;
      if (null != this.cachediskstream) {
        this.cachediskstream.close();
        this.cachediskstream = null;
      } 
      if (null != this.memorybuflist) {
        if (this.currentMemoryBufSz > 0) {
          byte[] tmp = new byte[this.currentMemoryBufSz];
          System.arraycopy(this.currentMemoryBuf, 0, tmp, 0, this.currentMemoryBufSz);
          this.memorybuflist.set(this.memorybuflist.size() - 1, tmp);
        } 
        this.currentMemoryBuf = null;
      } 
    } 
  }
  
  protected void finalize() {
    if (null != this.cachediskstream) {
      this.cachediskstream.close();
      this.cachediskstream = null;
    } 
  }
  
  protected void flushToDisk() {
    LinkedList ml = this.memorybuflist;
    log.debug(Messages.getMessage("maxCached", "" + this.maxCached, "" + this.totalsz));
    if (ml != null && 
      null == this.cachediskstream)
      try {
        MessageContext mc = MessageContext.getCurrentContext();
        String attdir = (mc == null) ? null : mc.getStrProp("attachments.directory");
        this.diskCacheFile = File.createTempFile("Axis", ".att", (attdir == null) ? null : new File(attdir));
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("diskCache", this.diskCacheFile.getAbsolutePath())); 
        this.cachediskstream = new BufferedOutputStream(new FileOutputStream(this.diskCacheFile));
        int listsz = ml.size();
        Iterator it = ml.iterator();
        while (it.hasNext()) {
          byte[] rbuf = (byte[])it.next();
          int bwrite = (listsz-- == 0) ? this.currentMemoryBufSz : rbuf.length;
          this.cachediskstream.write(rbuf, 0, bwrite);
          if (this.closed) {
            this.cachediskstream.close();
            this.cachediskstream = null;
          } 
        } 
        this.memorybuflist = null;
      } catch (SecurityException se) {
        this.diskCacheFile = null;
        this.cachediskstream = null;
        this.maxCached = Integer.MAX_VALUE;
        log.info(Messages.getMessage("nodisk00"), se);
      }  
  }
  
  public boolean delete() {
    boolean ret = false;
    this.deleted = true;
    this.memorybuflist = null;
    if (this.diskCacheFile != null) {
      if (this.cachediskstream != null) {
        try {
          this.cachediskstream.close();
        } catch (Exception e) {}
        this.cachediskstream = null;
      } 
      Object[] array = this.readers.keySet().toArray();
      for (i = 0; i < array.length; i++) {
        Instream stream = (Instream)array[i];
        if (null != stream)
          try {
            stream.close();
          } catch (Exception e) {} 
      } 
      this.readers.clear();
      try {
        this.diskCacheFile.delete();
        ret = true;
      } catch (Exception i) {
        Exception e;
        this.diskCacheFile.deleteOnExit();
      } 
    } 
    return ret;
  }
  
  protected static Log is_log = LogFactory.getLog(Instream.class.getName());
  
  private class Instream extends InputStream {
    protected long bread;
    
    FileInputStream fin;
    
    int currentIndex;
    
    byte[] currentBuf;
    
    int currentBufPos;
    
    boolean readClosed;
    
    private final ManagedMemoryDataSource this$0;
    
    protected Instream(ManagedMemoryDataSource this$0) throws IOException {
      this.this$0 = this$0;
      this.bread = 0L;
      this.fin = null;
      this.currentIndex = 0;
      this.currentBuf = null;
      this.currentBufPos = 0;
      this.readClosed = false;
      if (this$0.deleted)
        throw new IOException(Messages.getMessage("resourceDeleted")); 
      this$0.readers.put(this, null);
    }
    
    public int available() throws IOException {
      if (this.this$0.deleted)
        throw new IOException(Messages.getMessage("resourceDeleted")); 
      if (this.readClosed)
        throw new IOException(Messages.getMessage("streamClosed")); 
      int ret = (new Long(Math.min(2147483647L, this.this$0.totalsz - this.bread))).intValue();
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug("available() = " + ret + "."); 
      return ret;
    }
    
    public int read() throws IOException {
      synchronized (this.this$0) {
        byte[] retb = new byte[1];
        int br = read(retb, 0, 1);
        if (br == -1)
          return -1; 
        return 0xFF & retb[0];
      } 
    }
    
    public boolean markSupported() {
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug("markSupported() = false."); 
      return false;
    }
    
    public void mark(int readlimit) {
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug("mark()"); 
    }
    
    public void reset() {
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug("reset()"); 
      throw new IOException(Messages.getMessage("noResetMark"));
    }
    
    public long skip(long skipped) throws IOException {
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug("skip(" + skipped + ")."); 
      if (this.this$0.deleted)
        throw new IOException(Messages.getMessage("resourceDeleted")); 
      if (this.readClosed)
        throw new IOException(Messages.getMessage("streamClosed")); 
      if (skipped < 1L)
        return 0L; 
      synchronized (this.this$0) {
        skipped = Math.min(skipped, this.this$0.totalsz - this.bread);
        if (skipped == 0L)
          return 0L; 
        List ml = this.this$0.memorybuflist;
        int bwritten = 0;
        if (ml != null) {
          if (null == this.currentBuf) {
            this.currentBuf = (byte[])ml.get(this.currentIndex);
            this.currentBufPos = 0;
          } 
          do {
            long bcopy = Math.min((this.currentBuf.length - this.currentBufPos), skipped - bwritten);
            bwritten = (int)(bwritten + bcopy);
            this.currentBufPos = (int)(this.currentBufPos + bcopy);
            if (bwritten >= skipped)
              continue; 
            this.currentBuf = (byte[])ml.get(++this.currentIndex);
            this.currentBufPos = 0;
          } while (bwritten < skipped);
        } 
        if (null != this.fin)
          this.fin.skip(skipped); 
        this.bread += skipped;
      } 
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug("skipped " + skipped + "."); 
      return skipped;
    }
    
    public int read(byte[] b, int off, int len) throws IOException {
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug(hashCode() + " read(" + off + ", " + len + ")"); 
      if (this.this$0.deleted)
        throw new IOException(Messages.getMessage("resourceDeleted")); 
      if (this.readClosed)
        throw new IOException(Messages.getMessage("streamClosed")); 
      if (b == null)
        throw new InternalException(Messages.getMessage("nullInput")); 
      if (off < 0)
        throw new IndexOutOfBoundsException(Messages.getMessage("negOffset", "" + off)); 
      if (len < 0)
        throw new IndexOutOfBoundsException(Messages.getMessage("length", "" + len)); 
      if (len + off > b.length)
        throw new IndexOutOfBoundsException(Messages.getMessage("writeBeyond")); 
      if (len == 0)
        return 0; 
      int bwritten = 0;
      synchronized (this.this$0) {
        if (this.bread == this.this$0.totalsz)
          return -1; 
        List ml = this.this$0.memorybuflist;
        long longlen = len;
        longlen = Math.min(longlen, this.this$0.totalsz - this.bread);
        len = (new Long(longlen)).intValue();
        if (this.this$0.debugEnabled)
          ManagedMemoryDataSource.is_log.debug("len = " + len); 
        if (ml != null) {
          if (null == this.currentBuf) {
            this.currentBuf = (byte[])ml.get(this.currentIndex);
            this.currentBufPos = 0;
          } 
          do {
            int bcopy = Math.min(this.currentBuf.length - this.currentBufPos, len - bwritten);
            System.arraycopy(this.currentBuf, this.currentBufPos, b, off + bwritten, bcopy);
            bwritten += bcopy;
            this.currentBufPos += bcopy;
            if (bwritten >= len)
              continue; 
            this.currentBuf = (byte[])ml.get(++this.currentIndex);
            this.currentBufPos = 0;
          } while (bwritten < len);
        } 
        if (bwritten == 0 && null != this.this$0.diskCacheFile) {
          if (this.this$0.debugEnabled)
            ManagedMemoryDataSource.is_log.debug(Messages.getMessage("reading", "" + len)); 
          if (null == this.fin) {
            if (this.this$0.debugEnabled)
              ManagedMemoryDataSource.is_log.debug(Messages.getMessage("openBread", this.this$0.diskCacheFile.getCanonicalPath())); 
            if (this.this$0.debugEnabled)
              ManagedMemoryDataSource.is_log.debug(Messages.getMessage("openBread", "" + this.bread)); 
            this.fin = new FileInputStream(this.this$0.diskCacheFile);
            if (this.bread > 0L)
              this.fin.skip(this.bread); 
          } 
          if (this.this$0.cachediskstream != null) {
            if (this.this$0.debugEnabled)
              ManagedMemoryDataSource.is_log.debug(Messages.getMessage("flushing")); 
            this.this$0.cachediskstream.flush();
          } 
          if (this.this$0.debugEnabled) {
            ManagedMemoryDataSource.is_log.debug(Messages.getMessage("flushing"));
            ManagedMemoryDataSource.is_log.debug("len=" + len);
            ManagedMemoryDataSource.is_log.debug("off=" + off);
            ManagedMemoryDataSource.is_log.debug("b.length=" + b.length);
          } 
          bwritten = this.fin.read(b, off, len);
        } 
        if (bwritten > 0)
          this.bread += bwritten; 
      } 
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug(hashCode() + Messages.getMessage("read", "" + bwritten)); 
      return bwritten;
    }
    
    public void close() {
      if (this.this$0.debugEnabled)
        ManagedMemoryDataSource.is_log.debug("close()"); 
      if (!this.readClosed) {
        this.this$0.readers.remove(this);
        this.readClosed = true;
        if (this.fin != null)
          this.fin.close(); 
        this.fin = null;
      } 
    }
    
    protected void finalize() { close(); }
  }
  
  public static void main(String[] arg) {
    try {
      String readFile = arg[0];
      String writeFile = arg[1];
      FileInputStream ss = new FileInputStream(readFile);
      ManagedMemoryDataSource ms = new ManagedMemoryDataSource(ss, 1048576, "foo/data", true);
      DataHandler dh = new DataHandler(ms);
      InputStream is = dh.getInputStream();
      FileOutputStream fo = new FileOutputStream(writeFile);
      byte[] buf = new byte[512];
      int read = 0;
      do {
        read = is.read(buf);
        if (read <= 0)
          continue; 
        fo.write(buf, 0, read);
      } while (read > -1);
      fo.close();
      is.close();
    } catch (Exception e) {
      log.error(Messages.getMessage("exception00"), e);
    } 
  }
  
  public File getDiskCacheFile() { return this.diskCacheFile; }
  
  protected ManagedMemoryDataSource() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\ManagedMemoryDataSource.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */