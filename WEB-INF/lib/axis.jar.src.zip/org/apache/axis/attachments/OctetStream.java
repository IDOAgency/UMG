package org.apache.axis.attachments;

public class OctetStream {
  private byte[] bytes = null;
  
  public OctetStream() {}
  
  public OctetStream(byte[] bytes) { this.bytes = bytes; }
  
  public byte[] getBytes() { return this.bytes; }
  
  public void setBytes(byte[] bytes) { this.bytes = bytes; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\OctetStream.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */