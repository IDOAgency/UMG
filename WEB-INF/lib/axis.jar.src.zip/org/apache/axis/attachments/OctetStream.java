/*    */ package org.apache.axis.attachments;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OctetStream
/*    */ {
/* 21 */   private byte[] bytes = null;
/*    */ 
/*    */   
/*    */   public OctetStream() {}
/*    */ 
/*    */   
/* 27 */   public OctetStream(byte[] bytes) { this.bytes = bytes; }
/*    */ 
/*    */ 
/*    */   
/* 31 */   public byte[] getBytes() { return this.bytes; }
/*    */ 
/*    */ 
/*    */   
/* 35 */   public void setBytes(byte[] bytes) { this.bytes = bytes; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\OctetStream.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */