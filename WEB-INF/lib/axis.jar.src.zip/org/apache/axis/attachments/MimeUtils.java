package org.apache.axis.attachments;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Header;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.xml.soap.MimeHeader;
import org.apache.axis.AxisFault;
import org.apache.axis.AxisProperties;
import org.apache.axis.Part;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.SessionUtils;
import org.apache.commons.logging.Log;

public class MimeUtils {
  protected static Log log = LogFactory.getLog(MimeUtils.class.getName());
  
  public static long getContentLength(Multipart mp) throws MessagingException, IOException {
    int totalParts = mp.getCount();
    long totalContentLength = 0L;
    for (int i = 0; i < totalParts; i++) {
      MimeBodyPart bp = (MimeBodyPart)mp.getBodyPart(i);
      totalContentLength += getContentLength(bp);
    } 
    String ctype = mp.getContentType();
    ContentType ct = new ContentType(ctype);
    String boundaryStr = ct.getParameter("boundary");
    int boundaryStrLen = boundaryStr.length() + 4;
    return totalContentLength + (boundaryStrLen * (totalParts + 1)) + (2 * totalParts) + 4L;
  }
  
  protected static long getContentLength(MimeBodyPart bp) {
    long headerLength = -1L;
    long dataSize = -1L;
    try {
      headerLength = getHeaderLength(bp);
      DataHandler dh = bp.getDataHandler();
      DataSource ds = dh.getDataSource();
      if (ds instanceof FileDataSource) {
        FileDataSource fdh = (FileDataSource)ds;
        File df = fdh.getFile();
        if (!df.exists())
          throw new RuntimeException(Messages.getMessage("noFile", df.getAbsolutePath())); 
        dataSize = df.length();
      } else {
        dataSize = bp.getSize();
        if (-1L == dataSize) {
          int bytesread;
          dataSize = 0L;
          InputStream in = ds.getInputStream();
          byte[] readbuf = new byte[65536];
          do {
            bytesread = in.read(readbuf);
            if (bytesread <= 0)
              continue; 
            dataSize += bytesread;
          } while (bytesread > -1);
          in.close();
        } 
      } 
    } catch (Exception e) {
      log.error(Messages.getMessage("exception00"), e);
    } 
    return dataSize + headerLength;
  }
  
  private static long getHeaderLength(MimeBodyPart bp) {
    MimeBodyPart headersOnly = new MimeBodyPart(new InternetHeaders(), new byte[0]);
    Enumeration en = bp.getAllHeaders();
    while (en.hasMoreElements()) {
      Header header = (Header)en.nextElement();
      headersOnly.addHeader(header.getName(), header.getValue());
    } 
    ByteArrayOutputStream bas = new ByteArrayOutputStream(16384);
    headersOnly.writeTo(bas);
    bas.close();
    return bas.size();
  }
  
  public static String[] filter = { "Message-ID", "Mime-Version", "Content-Type" };
  
  public static void writeToMultiPartStream(OutputStream os, MimeMultipart mp) {
    try {
      Properties props = AxisProperties.getProperties();
      props.setProperty("mail.smtp.host", "localhost");
      Session session = Session.getInstance(props, null);
      MimeMessage message = new MimeMessage(session);
      message.setContent(mp);
      message.saveChanges();
      message.writeTo(os, filter);
    } catch (MessagingException e) {
      log.error(Messages.getMessage("javaxMailMessagingException00"), e);
    } catch (IOException e) {
      log.error(Messages.getMessage("javaIOException00"), e);
    } 
  }
  
  public static String getContentType(MimeMultipart mp) {
    StringBuffer contentType = new StringBuffer(mp.getContentType());
    for (int i = 0; i < contentType.length(); ) {
      char ch = contentType.charAt(i);
      if (ch == '\r' || ch == '\n') {
        contentType.deleteCharAt(i);
        continue;
      } 
      i++;
    } 
    return contentType.toString();
  }
  
  public static MimeMultipart createMP(String env, Collection parts, int sendType) throws AxisFault {
    MimeMultipart multipart = null;
    try {
      String rootCID = SessionUtils.generateSessionId();
      if (sendType == 4) {
        multipart = new MimeMultipart("related;type=\"application/xop+xml\"; start=\"<" + rootCID + ">\"; start-info=\"text/xml; charset=utf-8\"");
      } else {
        multipart = new MimeMultipart("related; type=\"text/xml\"; start=\"<" + rootCID + ">\"");
      } 
      MimeBodyPart messageBodyPart = new MimeBodyPart();
      messageBodyPart.setText(env, "UTF-8");
      if (sendType == 4) {
        messageBodyPart.setHeader("Content-Type", "application/xop+xml; charset=utf-8; type=\"text/xml; charset=utf-8\"");
      } else {
        messageBodyPart.setHeader("Content-Type", "text/xml; charset=UTF-8");
      } 
      messageBodyPart.setHeader("Content-Id", "<" + rootCID + ">");
      messageBodyPart.setHeader("Content-Transfer-Encoding", "binary");
      multipart.addBodyPart(messageBodyPart);
      for (Iterator it = parts.iterator(); it.hasNext(); ) {
        Part part = (Part)it.next();
        DataHandler dh = AttachmentUtils.getActivationDataHandler(part);
        String contentID = part.getContentId();
        messageBodyPart = new MimeBodyPart();
        messageBodyPart.setDataHandler(dh);
        String contentType = part.getContentType();
        if (contentType == null || contentType.trim().length() == 0)
          contentType = dh.getContentType(); 
        if (contentType == null || contentType.trim().length() == 0)
          contentType = "application/octet-stream"; 
        messageBodyPart.setHeader("Content-Type", contentType);
        messageBodyPart.setHeader("Content-Id", "<" + contentID + ">");
        messageBodyPart.setHeader("Content-Transfer-Encoding", "binary");
        Iterator i = part.getNonMatchingMimeHeaders(new String[] { "Content-Type", "Content-Id", "Content-Transfer-Encoding" });
        while (i.hasNext()) {
          MimeHeader header = (MimeHeader)i.next();
          messageBodyPart.setHeader(header.getName(), header.getValue());
        } 
        multipart.addBodyPart(messageBodyPart);
      } 
    } catch (MessagingException e) {
      log.error(Messages.getMessage("javaxMailMessagingException00"), e);
    } 
    return multipart;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\MimeUtils.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */