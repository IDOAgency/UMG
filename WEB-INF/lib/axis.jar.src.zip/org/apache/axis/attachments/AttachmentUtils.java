package org.apache.axis.attachments;

import javax.activation.DataHandler;
import org.apache.axis.AxisFault;
import org.apache.axis.Part;
import org.apache.axis.utils.Messages;

public class AttachmentUtils {
  public static DataHandler getActivationDataHandler(Part part) throws AxisFault {
    if (null == part)
      throw new AxisFault(Messages.getMessage("gotNullPart")); 
    if (!(part instanceof AttachmentPart))
      throw new AxisFault(Messages.getMessage("unsupportedAttach", part.getClass().getName(), AttachmentPart.class.getName())); 
    return ((AttachmentPart)part).getActivationDataHandler();
  }
  
  public static boolean isAttachment(Object value) {
    if (null == value)
      return false; 
    return value instanceof DataHandler;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\AttachmentUtils.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */