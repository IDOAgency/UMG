/*    */ package org.apache.axis.attachments;
/*    */ 
/*    */ import javax.activation.DataHandler;
/*    */ import org.apache.axis.AxisFault;
/*    */ import org.apache.axis.Part;
/*    */ import org.apache.axis.utils.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttachmentUtils
/*    */ {
/*    */   public static DataHandler getActivationDataHandler(Part part) throws AxisFault {
/* 45 */     if (null == part) {
/* 46 */       throw new AxisFault(Messages.getMessage("gotNullPart"));
/*    */     }
/*    */     
/* 49 */     if (!(part instanceof AttachmentPart)) {
/* 50 */       throw new AxisFault(Messages.getMessage("unsupportedAttach", part.getClass().getName(), AttachmentPart.class.getName()));
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     return ((AttachmentPart)part).getActivationDataHandler();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isAttachment(Object value) {
/* 69 */     if (null == value) {
/* 70 */       return false;
/*    */     }
/*    */     
/* 73 */     return value instanceof DataHandler;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\AttachmentUtils.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */