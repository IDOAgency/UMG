package org.apache.axis.attachments;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Vector;

public final class DimeMultiPart {
  static final long transSize = 2147483647L;
  
  static final byte CURRENT_VERSION = 1;
  
  protected Vector parts = new Vector();
  
  public void addBodyPart(DimeBodyPart part) { this.parts.add(part); }
  
  public void write(OutputStream os) throws IOException {
    int size = this.parts.size();
    int last = size - 1;
    for (int i = 0; i < size; i++)
      ((DimeBodyPart)this.parts.elementAt(i)).write(os, (byte)(((i == 0) ? 4 : 0) | ((i == last) ? 2 : 0)), 2147483647L); 
  }
  
  public long getTransmissionSize() {
    long size = 0L;
    for (int i = this.parts.size() - 1; i > -1; i--)
      size += ((DimeBodyPart)this.parts.elementAt(i)).getTransmissionSize(2147483647L); 
    return size;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\DimeMultiPart.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */