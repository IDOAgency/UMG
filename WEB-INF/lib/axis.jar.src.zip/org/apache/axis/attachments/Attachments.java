package org.apache.axis.attachments;

import java.io.OutputStream;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import javax.xml.soap.MimeHeaders;
import org.apache.axis.AxisFault;
import org.apache.axis.Part;

public interface Attachments extends Serializable {
  public static final int SEND_TYPE_NOTSET = 1;
  
  public static final int SEND_TYPE_MIME = 2;
  
  public static final int SEND_TYPE_DIME = 3;
  
  public static final int SEND_TYPE_MTOM = 4;
  
  public static final int SEND_TYPE_NONE = 5;
  
  public static final int SEND_TYPE_MAX = 5;
  
  public static final int SEND_TYPE_DEFAULT = 2;
  
  public static final String CIDprefix = "cid:";
  
  Part addAttachmentPart(Part paramPart) throws AxisFault;
  
  Part removeAttachmentPart(String paramString) throws AxisFault;
  
  void removeAllAttachments();
  
  Part getAttachmentByReference(String paramString) throws AxisFault;
  
  Collection getAttachments() throws AxisFault;
  
  Iterator getAttachments(MimeHeaders paramMimeHeaders);
  
  Part createAttachmentPart(Object paramObject) throws AxisFault;
  
  Part createAttachmentPart() throws AxisFault;
  
  void setAttachmentParts(Collection paramCollection) throws AxisFault;
  
  Part getRootPart() throws AxisFault;
  
  void setRootPart(Part paramPart);
  
  long getContentLength() throws AxisFault;
  
  void writeContentToStream(OutputStream paramOutputStream) throws AxisFault;
  
  String getContentType() throws AxisFault;
  
  int getAttachmentCount();
  
  boolean isAttachment(Object paramObject);
  
  void setSendType(int paramInt);
  
  int getSendType();
  
  void dispose();
  
  IncomingAttachmentStreams getIncomingAttachmentStreams();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\attachments\Attachments.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */