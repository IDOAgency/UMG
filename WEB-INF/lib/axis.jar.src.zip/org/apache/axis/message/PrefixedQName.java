/*    */ package org.apache.axis.message;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.soap.Name;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrefixedQName
/*    */   implements Name
/*    */ {
/* 24 */   private static final String emptyString = "".intern();
/*    */   
/*    */   private String prefix;
/*    */   private QName qName;
/*    */   
/*    */   public PrefixedQName(String uri, String localName, String pre) {
/* 30 */     this.qName = new QName(uri, localName);
/* 31 */     this.prefix = (pre == null) ? emptyString : pre.intern();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PrefixedQName(QName qname) {
/* 37 */     this.qName = qname;
/* 38 */     this.prefix = emptyString;
/*    */   }
/*    */ 
/*    */   
/* 42 */   public String getLocalName() { return this.qName.getLocalPart(); }
/*    */ 
/*    */   
/*    */   public String getQualifiedName() {
/* 46 */     StringBuffer buf = new StringBuffer(this.prefix);
/* 47 */     if (this.prefix != emptyString)
/* 48 */       buf.append(':'); 
/* 49 */     buf.append(this.qName.getLocalPart());
/* 50 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   
/* 54 */   public String getURI() { return this.qName.getNamespaceURI(); }
/*    */ 
/*    */ 
/*    */   
/* 58 */   public String getPrefix() { return this.prefix; }
/*    */   
/*    */   public boolean equals(Object obj) {
/* 61 */     if (obj == this) {
/* 62 */       return true;
/*    */     }
/* 64 */     if (!(obj instanceof PrefixedQName)) {
/* 65 */       return false;
/*    */     }
/* 67 */     if (!this.qName.equals(((PrefixedQName)obj).qName)) {
/* 68 */       return false;
/*    */     }
/* 70 */     if (this.prefix == ((PrefixedQName)obj).prefix) {
/* 71 */       return true;
/*    */     }
/* 73 */     return false;
/*    */   }
/*    */ 
/*    */   
/* 77 */   public int hashCode() { return this.prefix.hashCode() + this.qName.hashCode(); }
/*    */ 
/*    */ 
/*    */   
/* 81 */   public String toString() { return this.qName.toString(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\PrefixedQName.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */