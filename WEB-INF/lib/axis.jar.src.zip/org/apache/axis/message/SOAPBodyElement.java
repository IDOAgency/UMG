/*     */ package org.apache.axis.message;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.soap.Name;
/*     */ import javax.xml.soap.SOAPBodyElement;
/*     */ import javax.xml.soap.SOAPElement;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.InternalException;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.encoding.DeserializationContext;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.axis.utils.XMLUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPBodyElement
/*     */   extends MessageElement
/*     */   implements SOAPBodyElement
/*     */ {
/*  40 */   private static Log log = LogFactory.getLog(SOAPBodyElement.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public SOAPBodyElement(String namespace, String localPart, String prefix, Attributes attributes, DeserializationContext context) throws AxisFault { super(namespace, localPart, prefix, attributes, context); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public SOAPBodyElement(Name name) { super(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public SOAPBodyElement(QName qname) { super(qname); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public SOAPBodyElement(QName qname, Object value) { super(qname, value); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public SOAPBodyElement(Element elem) { super(elem); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPBodyElement() {}
/*     */ 
/*     */ 
/*     */   
/*  79 */   public SOAPBodyElement(InputStream input) { super(getDocumentElement(input)); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public SOAPBodyElement(String namespace, String localPart) { super(namespace, localPart); }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Element getDocumentElement(InputStream input) {
/*     */     try {
/*  90 */       return XMLUtils.newDocument(input).getDocumentElement();
/*  91 */     } catch (Exception e) {
/*  92 */       throw new InternalException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setParentElement(SOAPElement parent) throws SOAPException {
/*  97 */     if (parent == null) {
/*  98 */       throw new IllegalArgumentException(Messages.getMessage("nullParent00"));
/*     */     }
/*     */     
/* 101 */     if (parent instanceof SOAPEnvelope) {
/* 102 */       log.warn(Messages.getMessage("bodyElementParent"));
/* 103 */       parent = ((SOAPEnvelope)parent).getBody();
/*     */     } 
/* 105 */     if (!(parent instanceof SOAPBody) && !(parent instanceof RPCElement)) {
/* 106 */       throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00"));
/*     */     }
/*     */     
/* 109 */     super.setParentElement(parent);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPBodyElement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */