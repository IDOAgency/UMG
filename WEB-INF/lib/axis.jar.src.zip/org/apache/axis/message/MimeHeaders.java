package org.apache.axis.message;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Iterator;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;

public class MimeHeaders extends MimeHeaders implements Externalizable {
  public MimeHeaders() {}
  
  public MimeHeaders(MimeHeaders h) {
    Iterator iterator = h.getAllHeaders();
    while (iterator.hasNext()) {
      MimeHeader hdr = (MimeHeader)iterator.next();
      addHeader(hdr.getName(), hdr.getValue());
    } 
  }
  
  public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
    int size = in.readInt();
    for (int i = 0; i < size; i++) {
      Object key = in.readObject();
      Object value = in.readObject();
      addHeader((String)key, (String)value);
    } 
  }
  
  public void writeExternal(ObjectOutput out) throws IOException {
    out.writeInt(getHeaderSize());
    Iterator iterator = getAllHeaders();
    while (iterator.hasNext()) {
      MimeHeader hdr = (MimeHeader)iterator.next();
      out.writeObject(hdr.getName());
      out.writeObject(hdr.getValue());
    } 
  }
  
  private int getHeaderSize() {
    int size = 0;
    Iterator iterator = getAllHeaders();
    while (iterator.hasNext()) {
      iterator.next();
      size++;
    } 
    return size;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\MimeHeaders.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */