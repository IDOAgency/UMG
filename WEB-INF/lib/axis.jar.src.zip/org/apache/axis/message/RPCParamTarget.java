package org.apache.axis.message;

import org.apache.axis.encoding.Target;
import org.xml.sax.SAXException;

public class RPCParamTarget implements Target {
  private RPCParam param;
  
  public RPCParamTarget(RPCParam param) { this.param = param; }
  
  public void set(Object value) throws SAXException { this.param.set(value); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\RPCParamTarget.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */