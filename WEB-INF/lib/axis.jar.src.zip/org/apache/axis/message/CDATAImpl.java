/*    */ package org.apache.axis.message;
/*    */ 
/*    */ import org.w3c.dom.CDATASection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CDATAImpl
/*    */   extends Text
/*    */   implements CDATASection
/*    */ {
/*    */   static final String cdataUC = "<![CDATA[";
/*    */   static final String cdataLC = "<![cdata[";
/*    */   
/* 29 */   public CDATAImpl(String text) { super(text); }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public boolean isComment() { return false; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\CDATAImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */