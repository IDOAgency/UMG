package org.apache.axis.message;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPBodyElement;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import org.apache.axis.AxisFault;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.w3c.dom.Document;
import org.xml.sax.Attributes;

public class SOAPBody extends MessageElement implements SOAPBody {
  private static Log log = LogFactory.getLog(SOAPBody.class.getName());
  
  private SOAPConstants soapConstants;
  
  private boolean disableFormatting = false;
  
  private boolean doSAAJEncodingCompliance = false;
  
  private static ArrayList knownEncodingStyles = new ArrayList();
  
  static  {
    knownEncodingStyles.add("http://schemas.xmlsoap.org/soap/encoding/");
    knownEncodingStyles.add("http://www.w3.org/2003/05/soap-encoding");
    knownEncodingStyles.add("");
    knownEncodingStyles.add("http://www.w3.org/2003/05/soap-envelope/encoding/none");
  }
  
  SOAPBody(SOAPEnvelope env, SOAPConstants soapConsts) {
    super(soapConsts.getEnvelopeURI(), "Body");
    this.soapConstants = soapConsts;
    try {
      setParentElement(env);
    } catch (SOAPException ex) {
      log.fatal(Messages.getMessage("exception00"), ex);
    } 
  }
  
  public SOAPBody(String namespace, String localPart, String prefix, Attributes attributes, DeserializationContext context, SOAPConstants soapConsts) throws AxisFault {
    super(namespace, localPart, prefix, attributes, context);
    this.soapConstants = soapConsts;
  }
  
  public void setParentElement(SOAPElement parent) throws SOAPException {
    if (parent == null)
      throw new IllegalArgumentException(Messages.getMessage("nullParent00")); 
    try {
      SOAPEnvelope env = (SOAPEnvelope)parent;
      super.setParentElement(env);
      setEnvelope(env);
    } catch (Throwable t) {
      throw new SOAPException(t);
    } 
  }
  
  public void disableFormatting() { this.disableFormatting = true; }
  
  public void setEncodingStyle(String encodingStyle) throws SOAPException {
    if (encodingStyle == null)
      encodingStyle = ""; 
    if (this.doSAAJEncodingCompliance)
      if (!knownEncodingStyles.contains(encodingStyle))
        throw new IllegalArgumentException(Messages.getMessage("badEncodingStyle1", encodingStyle));  
    super.setEncodingStyle(encodingStyle);
  }
  
  protected void outputImpl(SerializationContext context) throws Exception {
    boolean oldPretty = context.getPretty();
    if (!this.disableFormatting) {
      context.setPretty(true);
    } else {
      context.setPretty(false);
    } 
    List bodyElements = getChildren();
    if (bodyElements == null || bodyElements.isEmpty());
    context.startElement(new QName(this.soapConstants.getEnvelopeURI(), "Body"), getAttributesEx());
    if (bodyElements != null) {
      Iterator e = bodyElements.iterator();
      while (e.hasNext()) {
        MessageElement body = (MessageElement)e.next();
        body.output(context);
      } 
    } 
    context.outputMultiRefs();
    context.endElement();
    context.setPretty(oldPretty);
  }
  
  Vector getBodyElements() throws AxisFault {
    initializeChildren();
    return new Vector(getChildren());
  }
  
  SOAPBodyElement getFirstBody() throws AxisFault {
    if (!hasChildNodes())
      return null; 
    return (SOAPBodyElement)getChildren().get(0);
  }
  
  void addBodyElement(SOAPBodyElement element) {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("addBody00")); 
    try {
      addChildElement(element);
    } catch (SOAPException ex) {
      log.fatal(Messages.getMessage("exception00"), ex);
    } 
  }
  
  void removeBodyElement(SOAPBodyElement element) {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("removeBody00")); 
    removeChild(element);
  }
  
  void clearBody() { removeContents(); }
  
  SOAPBodyElement getBodyByName(String namespace, String localPart) throws AxisFault {
    QName name = new QName(namespace, localPart);
    return (SOAPBodyElement)getChildElement(name);
  }
  
  public SOAPBodyElement addBodyElement(Name name) throws SOAPException {
    SOAPBodyElement bodyElement = new SOAPBodyElement(name);
    addChildElement(bodyElement);
    return bodyElement;
  }
  
  public SOAPFault addFault(Name name, String s, Locale locale) throws SOAPException {
    AxisFault af = new AxisFault(new QName(name.getURI(), name.getLocalName()), s, "", new org.w3c.dom.Element[0]);
    SOAPFault fault = new SOAPFault(af);
    addChildElement(fault);
    return fault;
  }
  
  public SOAPFault addFault(Name name, String s) throws SOAPException {
    AxisFault af = new AxisFault(new QName(name.getURI(), name.getLocalName()), s, "", new org.w3c.dom.Element[0]);
    SOAPFault fault = new SOAPFault(af);
    addChildElement(fault);
    return fault;
  }
  
  public SOAPBodyElement addDocument(Document document) throws SOAPException {
    SOAPBodyElement bodyElement = new SOAPBodyElement(document.getDocumentElement());
    addChildElement(bodyElement);
    return bodyElement;
  }
  
  public SOAPFault addFault() throws SOAPException {
    AxisFault af = new AxisFault(new QName("http://xml.apache.org/axis/", "Server.generalException"), "", "", new org.w3c.dom.Element[0]);
    SOAPFault fault = new SOAPFault(af);
    addChildElement(fault);
    return fault;
  }
  
  public SOAPFault getFault() throws SOAPException {
    List bodyElements = getChildren();
    if (bodyElements != null) {
      Iterator e = bodyElements.iterator();
      while (e.hasNext()) {
        Object element = e.next();
        if (element instanceof SOAPFault)
          return (SOAPFault)element; 
      } 
    } 
    return null;
  }
  
  public boolean hasFault() { return (getFault() != null); }
  
  public void addChild(MessageElement element) throws SOAPException {
    element.setEnvelope(getEnvelope());
    super.addChild(element);
  }
  
  public SOAPElement addChildElement(SOAPElement element) throws SOAPException {
    SOAPElement child = super.addChildElement(element);
    setDirty();
    return child;
  }
  
  public SOAPElement addChildElement(Name name) throws SOAPException {
    SOAPBodyElement child = new SOAPBodyElement(name);
    addChildElement(child);
    return child;
  }
  
  public SOAPElement addChildElement(String localName) throws SOAPException {
    SOAPBodyElement child = new SOAPBodyElement(getNamespaceURI(), localName);
    addChildElement(child);
    return child;
  }
  
  public SOAPElement addChildElement(String localName, String prefix) throws SOAPException {
    SOAPBodyElement child = new SOAPBodyElement(getNamespaceURI(prefix), localName);
    child.setPrefix(prefix);
    addChildElement(child);
    return child;
  }
  
  public SOAPElement addChildElement(String localName, String prefix, String uri) throws SOAPException {
    SOAPBodyElement child = new SOAPBodyElement(uri, localName);
    child.setPrefix(prefix);
    child.addNamespaceDeclaration(prefix, uri);
    addChildElement(child);
    return child;
  }
  
  public void setSAAJEncodingCompliance(boolean comply) { this.doSAAJEncodingCompliance = true; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPBody.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */