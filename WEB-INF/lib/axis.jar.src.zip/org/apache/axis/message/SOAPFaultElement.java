package org.apache.axis.message;

import javax.xml.soap.SOAPFaultElement;

public class SOAPFaultElement extends MessageElement implements SOAPFaultElement {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPFaultElement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */