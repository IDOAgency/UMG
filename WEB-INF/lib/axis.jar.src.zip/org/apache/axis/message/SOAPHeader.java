package org.apache.axis.message;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import org.apache.axis.AxisFault;
import org.apache.axis.Constants;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.Attributes;

public class SOAPHeader extends MessageElement implements SOAPHeader {
  private static Log log = LogFactory.getLog(SOAPHeader.class.getName());
  
  private SOAPConstants soapConstants;
  
  SOAPHeader(SOAPEnvelope env, SOAPConstants soapConsts) {
    super("Header", "soapenv", (soapConsts != null) ? soapConsts.getEnvelopeURI() : Constants.DEFAULT_SOAP_VERSION.getEnvelopeURI());
    this.soapConstants = (soapConsts != null) ? soapConsts : Constants.DEFAULT_SOAP_VERSION;
    try {
      setParentElement(env);
    } catch (SOAPException ex) {
      log.fatal(Messages.getMessage("exception00"), ex);
    } 
  }
  
  public SOAPHeader(String namespace, String localPart, String prefix, Attributes attributes, DeserializationContext context, SOAPConstants soapConsts) throws AxisFault {
    super(namespace, localPart, prefix, attributes, context);
    this.soapConstants = (soapConsts != null) ? soapConsts : Constants.DEFAULT_SOAP_VERSION;
  }
  
  public void setParentElement(SOAPElement parent) throws SOAPException {
    if (parent == null)
      throw new IllegalArgumentException(Messages.getMessage("nullParent00")); 
    try {
      SOAPEnvelope env = (SOAPEnvelope)parent;
      super.setParentElement(env);
      setEnvelope(env);
    } catch (Throwable t) {
      throw new SOAPException(t);
    } 
  }
  
  public SOAPHeaderElement addHeaderElement(Name name) throws SOAPException {
    SOAPHeaderElement headerElement = new SOAPHeaderElement(name);
    addChildElement(headerElement);
    return headerElement;
  }
  
  private Vector findHeaderElements(String actor) {
    ArrayList actors = new ArrayList();
    actors.add(actor);
    return getHeadersByActor(actors);
  }
  
  public Iterator examineHeaderElements(String actor) { return findHeaderElements(actor).iterator(); }
  
  public Iterator extractHeaderElements(String actor) {
    Vector results = findHeaderElements(actor);
    Iterator iterator = results.iterator();
    while (iterator.hasNext())
      ((SOAPHeaderElement)iterator.next()).detachNode(); 
    return results.iterator();
  }
  
  public Iterator examineMustUnderstandHeaderElements(String actor) {
    if (actor == null)
      return null; 
    Vector result = new Vector();
    List headers = getChildren();
    if (headers != null)
      for (int i = 0; i < headers.size(); i++) {
        SOAPHeaderElement she = (SOAPHeaderElement)headers.get(i);
        if (she.getMustUnderstand()) {
          String candidate = she.getActor();
          if (actor.equals(candidate))
            result.add(headers.get(i)); 
        } 
      }  
    return result.iterator();
  }
  
  public Iterator examineAllHeaderElements() { return getChildElements(); }
  
  public Iterator extractAllHeaderElements() {
    Vector result = new Vector();
    List headers = getChildren();
    if (headers != null) {
      for (int i = 0; i < headers.size(); i++)
        result.add(headers.get(i)); 
      headers.clear();
    } 
    return result.iterator();
  }
  
  Vector getHeaders() {
    initializeChildren();
    return new Vector(getChildren());
  }
  
  Vector getHeadersByActor(ArrayList actors) {
    Vector results = new Vector();
    List headers = getChildren();
    if (headers == null)
      return results; 
    Iterator i = headers.iterator();
    SOAPConstants soapVer = getEnvelope().getSOAPConstants();
    boolean isSOAP12 = (soapVer == SOAPConstants.SOAP12_CONSTANTS);
    String nextActor = soapVer.getNextRoleURI();
    while (i.hasNext()) {
      SOAPHeaderElement header = (SOAPHeaderElement)i.next();
      String actor = header.getActor();
      if (isSOAP12 && "http://www.w3.org/2003/05/soap-envelope/role/none".equals(actor))
        continue; 
      if (actor == null || nextActor.equals(actor) || (isSOAP12 && "http://www.w3.org/2003/05/soap-envelope/role/ultimateReceiver".equals(actor)) || (actors != null && actors.contains(actor)))
        results.add(header); 
    } 
    return results;
  }
  
  void addHeader(SOAPHeaderElement header) {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("addHeader00")); 
    try {
      addChildElement(header);
    } catch (SOAPException ex) {
      log.fatal(Messages.getMessage("exception00"), ex);
    } 
  }
  
  void removeHeader(SOAPHeaderElement header) {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("removeHeader00")); 
    removeChild(header);
  }
  
  SOAPHeaderElement getHeaderByName(String namespace, String localPart, boolean accessAllHeaders) {
    QName name = new QName(namespace, localPart);
    SOAPHeaderElement header = (SOAPHeaderElement)getChildElement(name);
    if (!accessAllHeaders) {
      MessageContext mc = MessageContext.getCurrentContext();
      if (mc != null && 
        header != null) {
        String actor = header.getActor();
        String nextActor = getEnvelope().getSOAPConstants().getNextRoleURI();
        if (nextActor.equals(actor))
          return header; 
        SOAPService soapService = mc.getService();
        if (soapService != null) {
          ArrayList actors = mc.getService().getActors();
          if (actor != null && (actors == null || !actors.contains(actor)))
            header = null; 
        } 
      } 
    } 
    return header;
  }
  
  Enumeration getHeadersByName(String namespace, String localPart, boolean accessAllHeaders) {
    ArrayList actors = null;
    boolean firstTime = false;
    Vector v = new Vector();
    List headers = getChildren();
    if (headers == null)
      return v.elements(); 
    Iterator e = headers.iterator();
    String nextActor = getEnvelope().getSOAPConstants().getNextRoleURI();
    while (e.hasNext()) {
      SOAPHeaderElement header = (SOAPHeaderElement)e.next();
      if (header.getNamespaceURI().equals(namespace) && header.getName().equals(localPart)) {
        if (!accessAllHeaders) {
          if (firstTime) {
            MessageContext mc = MessageContext.getCurrentContext();
            if (mc != null && mc.getAxisEngine() != null)
              actors = mc.getAxisEngine().getActorURIs(); 
            firstTime = false;
          } 
          String actor = header.getActor();
          if (actor != null && !nextActor.equals(actor) && (actors == null || !actors.contains(actor)))
            continue; 
        } 
        v.addElement(header);
      } 
    } 
    return v.elements();
  }
  
  protected void outputImpl(SerializationContext context) throws Exception {
    List headers = getChildren();
    if (headers == null)
      return; 
    boolean oldPretty = context.getPretty();
    context.setPretty(true);
    if (log.isDebugEnabled())
      log.debug(headers.size() + " " + Messages.getMessage("headers00")); 
    if (!headers.isEmpty()) {
      context.startElement(new QName(this.soapConstants.getEnvelopeURI(), "Header"), null);
      Iterator enumeration = headers.iterator();
      while (enumeration.hasNext())
        ((NodeImpl)enumeration.next()).output(context); 
      context.endElement();
    } 
    context.setPretty(oldPretty);
  }
  
  public void addChild(MessageElement element) throws SOAPException {
    if (!(element instanceof SOAPHeaderElement))
      throw new SOAPException(Messages.getMessage("badSOAPHeader00")); 
    element.setEnvelope(getEnvelope());
    super.addChild(element);
  }
  
  public SOAPElement addChildElement(SOAPElement element) throws SOAPException {
    if (!(element instanceof SOAPHeaderElement))
      throw new SOAPException(Messages.getMessage("badSOAPHeader00")); 
    SOAPElement child = super.addChildElement(element);
    setDirty();
    return child;
  }
  
  public SOAPElement addChildElement(Name name) throws SOAPException {
    SOAPHeaderElement child = new SOAPHeaderElement(name);
    addChildElement(child);
    return child;
  }
  
  public SOAPElement addChildElement(String localName) throws SOAPException {
    SOAPHeaderElement child = new SOAPHeaderElement(getNamespaceURI(), localName);
    addChildElement(child);
    return child;
  }
  
  public SOAPElement addChildElement(String localName, String prefix) throws SOAPException {
    SOAPHeaderElement child = new SOAPHeaderElement(getNamespaceURI(prefix), localName);
    child.setPrefix(prefix);
    addChildElement(child);
    return child;
  }
  
  public SOAPElement addChildElement(String localName, String prefix, String uri) throws SOAPException {
    SOAPHeaderElement child = new SOAPHeaderElement(uri, localName);
    child.setPrefix(prefix);
    child.addNamespaceDeclaration(prefix, uri);
    addChildElement(child);
    return child;
  }
  
  public Node appendChild(Node newChild) throws DOMException {
    SOAPHeaderElement headerElement = null;
    if (newChild instanceof SOAPHeaderElement) {
      headerElement = (SOAPHeaderElement)newChild;
    } else {
      headerElement = new SOAPHeaderElement((Element)newChild);
    } 
    try {
      addChildElement(headerElement);
    } catch (SOAPException e) {
      throw new DOMException((short)11, e.toString());
    } 
    return headerElement;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPHeader.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */