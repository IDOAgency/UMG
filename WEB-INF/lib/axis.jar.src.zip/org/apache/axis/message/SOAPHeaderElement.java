package org.apache.axis.message;

import javax.xml.namespace.QName;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeaderElement;
import org.apache.axis.AxisFault;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.soap.SOAP11Constants;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.xml.sax.Attributes;

public class SOAPHeaderElement extends MessageElement implements SOAPHeaderElement {
  protected boolean processed = false;
  
  protected String actor = "http://schemas.xmlsoap.org/soap/actor/next";
  
  protected boolean mustUnderstand = false;
  
  protected boolean relay = false;
  
  boolean alreadySerialized;
  
  public SOAPHeaderElement(String namespace, String localPart) {
    super(namespace, localPart);
    this.alreadySerialized = false;
  }
  
  public SOAPHeaderElement(Name name) {
    super(name);
    this.alreadySerialized = false;
  }
  
  public SOAPHeaderElement(QName qname) {
    super(qname);
    this.alreadySerialized = false;
  }
  
  public SOAPHeaderElement(String namespace, String localPart, Object value) {
    super(namespace, localPart, value);
    this.alreadySerialized = false;
  }
  
  public SOAPHeaderElement(QName qname, Object value) {
    super(qname, value);
    this.alreadySerialized = false;
  }
  
  public SOAPHeaderElement(Element elem) {
    super(elem);
    this.alreadySerialized = false;
    SOAPConstants soapConstants = getSOAPConstants();
    String val = elem.getAttributeNS(soapConstants.getEnvelopeURI(), "mustUnderstand");
    try {
      setMustUnderstandFromString(val, (soapConstants == SOAPConstants.SOAP12_CONSTANTS));
    } catch (AxisFault axisFault) {
      log.error(axisFault);
    } 
    QName roleQName = soapConstants.getRoleAttributeQName();
    this.actor = elem.getAttributeNS(roleQName.getNamespaceURI(), roleQName.getLocalPart());
    if (soapConstants == SOAPConstants.SOAP12_CONSTANTS) {
      String relayVal = elem.getAttributeNS(soapConstants.getEnvelopeURI(), "relay");
      this.relay = (relayVal != null && (relayVal.equals("true") || relayVal.equals("1")));
    } 
  }
  
  public void setParentElement(SOAPElement parent) throws SOAPException {
    if (parent == null)
      throw new IllegalArgumentException(Messages.getMessage("nullParent00")); 
    if (parent instanceof SOAPEnvelope) {
      log.warn(Messages.getMessage("bodyHeaderParent"));
      parent = ((SOAPEnvelope)parent).getHeader();
    } 
    if (!(parent instanceof SOAPHeader))
      throw new IllegalArgumentException(Messages.getMessage("illegalArgumentException00")); 
    super.setParentElement(parent);
  }
  
  public SOAPHeaderElement(String namespace, String localPart, String prefix, Attributes attributes, DeserializationContext context) throws AxisFault {
    super(namespace, localPart, prefix, attributes, context);
    this.alreadySerialized = false;
    SOAPConstants soapConstants = getSOAPConstants();
    String val = attributes.getValue(soapConstants.getEnvelopeURI(), "mustUnderstand");
    setMustUnderstandFromString(val, (soapConstants == SOAPConstants.SOAP12_CONSTANTS));
    QName roleQName = soapConstants.getRoleAttributeQName();
    this.actor = attributes.getValue(roleQName.getNamespaceURI(), roleQName.getLocalPart());
    if (soapConstants == SOAPConstants.SOAP12_CONSTANTS) {
      String relayVal = attributes.getValue(soapConstants.getEnvelopeURI(), "relay");
      this.relay = (relayVal != null && (relayVal.equals("true") || relayVal.equals("1")));
    } 
    this.processed = false;
    this.alreadySerialized = true;
  }
  
  private void setMustUnderstandFromString(String val, boolean isSOAP12) throws AxisFault {
    if (val != null && val.length() > 0)
      if ("0".equals(val)) {
        this.mustUnderstand = false;
      } else if ("1".equals(val)) {
        this.mustUnderstand = true;
      } else if (isSOAP12) {
        if ("true".equalsIgnoreCase(val)) {
          this.mustUnderstand = true;
        } else if ("false".equalsIgnoreCase(val)) {
          this.mustUnderstand = false;
        } else {
          throw new AxisFault(Messages.getMessage("badMUVal", val, (new QName(this.namespaceURI, this.name)).toString()));
        } 
      } else {
        throw new AxisFault(Messages.getMessage("badMUVal", val, (new QName(this.namespaceURI, this.name)).toString()));
      }  
  }
  
  public boolean getMustUnderstand() { return this.mustUnderstand; }
  
  public void setMustUnderstand(boolean b) { this.mustUnderstand = b; }
  
  public String getActor() { return this.actor; }
  
  public void setActor(String a) { this.actor = a; }
  
  public String getRole() { return this.actor; }
  
  public void setRole(String a) { this.actor = a; }
  
  public boolean getRelay() { return this.relay; }
  
  public void setRelay(boolean relay) { this.relay = relay; }
  
  public void setProcessed(boolean value) { this.processed = value; }
  
  public boolean isProcessed() { return this.processed; }
  
  protected void outputImpl(SerializationContext context) throws Exception {
    if (!this.alreadySerialized) {
      String val;
      SOAPConstants soapVer = getSOAPConstants();
      QName roleQName = soapVer.getRoleAttributeQName();
      if (this.actor != null)
        setAttribute(roleQName.getNamespaceURI(), roleQName.getLocalPart(), this.actor); 
      if (context.getMessageContext() != null && context.getMessageContext().getSOAPConstants() == SOAPConstants.SOAP12_CONSTANTS) {
        val = this.mustUnderstand ? "true" : "false";
      } else {
        val = this.mustUnderstand ? "1" : "0";
      } 
      setAttribute(soapVer.getEnvelopeURI(), "mustUnderstand", val);
      if (soapVer == SOAPConstants.SOAP12_CONSTANTS && this.relay)
        setAttribute(soapVer.getEnvelopeURI(), "relay", "true"); 
    } 
    super.outputImpl(context);
  }
  
  public NamedNodeMap getAttributes() {
    makeAttributesEditable();
    SOAPConstants soapConstants = getSOAPConstants();
    String mustUnderstand = this.attributes.getValue(soapConstants.getEnvelopeURI(), "mustUnderstand");
    QName roleQName = soapConstants.getRoleAttributeQName();
    String actor = this.attributes.getValue(roleQName.getNamespaceURI(), roleQName.getLocalPart());
    if (mustUnderstand == null)
      if (soapConstants == SOAPConstants.SOAP12_CONSTANTS) {
        setAttributeNS(soapConstants.getEnvelopeURI(), "mustUnderstand", "false");
      } else {
        setAttributeNS(soapConstants.getEnvelopeURI(), "mustUnderstand", "0");
      }  
    if (actor == null)
      setAttributeNS(roleQName.getNamespaceURI(), roleQName.getLocalPart(), this.actor); 
    return super.getAttributes();
  }
  
  private SOAPConstants getSOAPConstants() {
    SOAP11Constants sOAP11Constants = null;
    if (this.context != null)
      return this.context.getSOAPConstants(); 
    if (getNamespaceURI() != null && getNamespaceURI().equals(SOAPConstants.SOAP12_CONSTANTS.getEnvelopeURI()))
      sOAP11Constants = SOAPConstants.SOAP12_CONSTANTS; 
    if (sOAP11Constants == null && getEnvelope() != null)
      sOAP11Constants = getEnvelope().getSOAPConstants(); 
    if (sOAP11Constants == null)
      sOAP11Constants = SOAPConstants.SOAP11_CONSTANTS; 
    return sOAP11Constants;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPHeaderElement.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */