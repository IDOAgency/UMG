/*     */ package org.apache.axis.message;
/*     */ 
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.soap.Text;
/*     */ import org.apache.axis.InternalException;
/*     */ import org.apache.axis.utils.XMLUtils;
/*     */ import org.w3c.dom.CharacterData;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Text
/*     */   extends NodeImpl
/*     */   implements Text
/*     */ {
/*     */   public Text(CharacterData data) {
/*  33 */     if (data == null)
/*     */     {
/*  35 */       throw new IllegalArgumentException("Text value may not be null.");
/*     */     }
/*  37 */     this.textRep = data;
/*     */   }
/*     */   
/*     */   public Text(String s) {
/*     */     try {
/*  42 */       Document doc = XMLUtils.newDocument();
/*  43 */       this.textRep = doc.createTextNode(s);
/*  44 */     } catch (ParserConfigurationException e) {
/*  45 */       throw new InternalException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  51 */   public Text() { this((String)null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isComment() {
/*  61 */     String temp = this.textRep.getNodeValue().trim();
/*  62 */     if (temp.startsWith("<!--") && temp.endsWith("-->"))
/*  63 */       return true; 
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public String getNodeValue() throws DOMException { return this.textRep.getNodeValue(); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNodeValue(String nodeValue) {
/*  79 */     setDirty();
/*  80 */     this.textRep.setNodeValue(nodeValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Text splitText(int offset) throws DOMException {
/*  97 */     int length = this.textRep.getLength();
/*     */ 
/*     */     
/* 100 */     String tailData = this.textRep.substringData(offset, length);
/* 101 */     this.textRep.deleteData(offset, length);
/*     */ 
/*     */     
/* 104 */     Text tailText = new Text(tailData);
/* 105 */     Node myParent = getParentNode();
/* 106 */     if (myParent != null) {
/* 107 */       NodeList brothers = myParent.getChildNodes();
/* 108 */       for (int i = 0; i < brothers.getLength(); i++) {
/* 109 */         if (brothers.item(i).equals(this)) {
/* 110 */           myParent.insertBefore(tailText, this);
/* 111 */           return tailText;
/*     */         } 
/*     */       } 
/*     */     } 
/* 115 */     return tailText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   public String getData() throws DOMException { return this.textRep.getData(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public void setData(String data) { this.textRep.setData(data); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public int getLength() { return this.textRep.getLength(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public String substringData(int offset, int count) throws DOMException { return this.textRep.substringData(offset, count); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public void appendData(String arg) { this.textRep.appendData(arg); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public void insertData(int offset, String arg) throws DOMException { this.textRep.insertData(offset, arg); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public void replaceData(int offset, int count, String arg) throws DOMException { this.textRep.replaceData(offset, count, arg); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 190 */   public void deleteData(int offset, int count) throws DOMException { this.textRep.deleteData(offset, count); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public String toString() throws DOMException { return this.textRep.getNodeValue(); }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 200 */     if (!(obj instanceof Text))
/*     */     {
/* 202 */       return false;
/*     */     }
/* 204 */     return (this == obj || hashCode() == obj.hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 209 */     if (this.textRep == null)
/*     */     {
/* 211 */       return -1;
/*     */     }
/* 213 */     return (this.textRep.getData() != null) ? this.textRep.getData().hashCode() : 0;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\Text.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */