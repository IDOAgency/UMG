package org.apache.axis.message;

import java.util.Iterator;
import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPException;

public class Detail extends SOAPFaultElement implements Detail {
  public DetailEntry addDetailEntry(Name name) throws SOAPException {
    DetailEntry entry = new DetailEntry(name);
    addChildElement(entry);
    return entry;
  }
  
  public Iterator getDetailEntries() { return getChildElements(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\Detail.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */