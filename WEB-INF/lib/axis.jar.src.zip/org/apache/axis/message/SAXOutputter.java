/*     */ package org.apache.axis.message;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.encoding.SerializationContext;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAXOutputter
/*     */   extends DefaultHandler
/*     */   implements LexicalHandler
/*     */ {
/*  32 */   protected static Log log = LogFactory.getLog(SAXOutputter.class.getName());
/*     */   SerializationContext context;
/*     */   
/*     */   public SAXOutputter(SerializationContext context) {
/*  36 */     this.isCDATA = false;
/*     */ 
/*     */ 
/*     */     
/*  40 */     this.context = context;
/*     */   }
/*     */   boolean isCDATA;
/*     */   
/*  44 */   public void startDocument() throws SAXException { this.context.setSendDecl(true); }
/*     */ 
/*     */   
/*     */   public void endDocument() throws SAXException {
/*  48 */     if (log.isDebugEnabled()) {
/*  49 */       log.debug("SAXOutputter.endDocument");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  54 */   public void startPrefixMapping(String p1, String p2) throws SAXException { this.context.registerPrefixForURI(p1, p2); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endPrefixMapping(String p1) throws SAXException {}
/*     */ 
/*     */   
/*     */   public void characters(char[] p1, int p2, int p3) throws SAXException {
/*  62 */     if (log.isDebugEnabled()) {
/*  63 */       log.debug("SAXOutputter.characters ['" + new String(p1, p2, p3) + "']");
/*     */     }
/*     */     try {
/*  66 */       if (!this.isCDATA) {
/*  67 */         this.context.writeChars(p1, p2, p3);
/*     */       } else {
/*  69 */         this.context.writeString(new String(p1, p2, p3));
/*     */       } 
/*  71 */     } catch (IOException e) {
/*  72 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ignorableWhitespace(char[] p1, int p2, int p3) throws SAXException {
/*     */     try {
/*  80 */       this.context.writeChars(p1, p2, p3);
/*  81 */     } catch (IOException e) {
/*  82 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void skippedEntity(String p1) throws SAXException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String namespace, String localName, String qName, Attributes attributes) throws SAXException {
/*  93 */     if (log.isDebugEnabled()) {
/*  94 */       log.debug("SAXOutputter.startElement ['" + namespace + "' " + localName + "]");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  99 */       this.context.startElement(new QName(namespace, localName), attributes);
/* 100 */     } catch (IOException e) {
/* 101 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String namespace, String localName, String qName) throws SAXException {
/* 108 */     if (log.isDebugEnabled()) {
/* 109 */       log.debug("SAXOutputter.endElement ['" + namespace + "' " + localName + "]");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 114 */       this.context.endElement();
/* 115 */     } catch (IOException e) {
/* 116 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endDTD() throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endEntity(String name) throws SAXException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startCDATA() throws SAXException {
/*     */     try {
/* 146 */       this.isCDATA = true;
/* 147 */       this.context.writeString("<![CDATA[");
/* 148 */     } catch (IOException e) {
/* 149 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endCDATA() throws SAXException {
/*     */     try {
/* 157 */       this.isCDATA = false;
/* 158 */       this.context.writeString("]]>");
/* 159 */     } catch (IOException e) {
/* 160 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) throws SAXException {
/* 169 */     if (log.isDebugEnabled()) {
/* 170 */       log.debug("SAXOutputter.comment ['" + new String(ch, start, length) + "']");
/*     */     }
/*     */     try {
/* 173 */       this.context.writeString("<!--");
/* 174 */       this.context.writeChars(ch, start, length);
/* 175 */       this.context.writeString("-->");
/* 176 */     } catch (IOException e) {
/* 177 */       throw new SAXException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SAXOutputter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */