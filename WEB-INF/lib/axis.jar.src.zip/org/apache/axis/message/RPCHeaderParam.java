package org.apache.axis.message;

import org.apache.axis.MessageContext;
import org.apache.axis.encoding.SerializationContext;

public class RPCHeaderParam extends SOAPHeaderElement {
  public RPCHeaderParam(RPCParam rpcParam) { super(rpcParam.getQName().getNamespaceURI(), rpcParam.getQName().getLocalPart(), rpcParam); }
  
  protected void outputImpl(SerializationContext context) throws Exception {
    MessageContext msgContext = context.getMessageContext();
    RPCParam rpcParam = (RPCParam)getObjectValue();
    if (this.encodingStyle != null && this.encodingStyle.equals(""))
      context.registerPrefixForURI("", rpcParam.getQName().getNamespaceURI()); 
    rpcParam.serialize(context);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\RPCHeaderParam.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */