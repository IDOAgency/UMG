/*    */ package org.apache.axis.message;
/*    */ 
/*    */ import org.apache.axis.MessageContext;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RPCHeaderParam
/*    */   extends SOAPHeaderElement
/*    */ {
/* 28 */   public RPCHeaderParam(RPCParam rpcParam) { super(rpcParam.getQName().getNamespaceURI(), rpcParam.getQName().getLocalPart(), rpcParam); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void outputImpl(SerializationContext context) throws Exception {
/* 38 */     MessageContext msgContext = context.getMessageContext();
/*    */ 
/*    */     
/* 41 */     RPCParam rpcParam = (RPCParam)getObjectValue();
/* 42 */     if (this.encodingStyle != null && this.encodingStyle.equals("")) {
/* 43 */       context.registerPrefixForURI("", rpcParam.getQName().getNamespaceURI());
/*    */     }
/* 45 */     rpcParam.serialize(context);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\RPCHeaderParam.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */