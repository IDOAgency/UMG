package org.apache.axis.message;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;
import javax.xml.namespace.QName;
import org.apache.axis.AxisFault;
import org.apache.axis.Constants;
import org.apache.axis.encoding.Callback;
import org.apache.axis.encoding.CallbackTarget;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.Deserializer;
import org.apache.axis.soap.SOAP11Constants;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.XMLUtils;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class SOAPFaultBuilder extends SOAPHandler implements Callback {
  boolean waiting;
  
  boolean passedEnd;
  
  protected SOAPFault element;
  
  protected DeserializationContext context;
  
  static HashMap fields_soap11 = new HashMap();
  
  static HashMap fields_soap12 = new HashMap();
  
  protected QName faultCode;
  
  protected QName[] faultSubCode;
  
  protected String faultString;
  
  protected String faultActor;
  
  protected Element[] faultDetails;
  
  protected String faultNode;
  
  protected SOAPFaultCodeBuilder code;
  
  protected Class faultClass;
  
  protected Object faultData;
  
  private static HashMap TYPES;
  
  static  {
    fields_soap11.put("faultcode", Constants.XSD_QNAME);
    fields_soap11.put("faultstring", Constants.XSD_STRING);
    fields_soap11.put("faultactor", Constants.XSD_STRING);
    fields_soap11.put("detail", null);
    fields_soap12.put("Reason", null);
    fields_soap12.put("Role", Constants.XSD_STRING);
    fields_soap12.put("Node", Constants.XSD_STRING);
    fields_soap12.put("Detail", null);
    TYPES = new HashMap(7);
    TYPES.put(Integer.class, int.class);
    TYPES.put(Float.class, float.class);
    TYPES.put(Boolean.class, boolean.class);
    TYPES.put(Double.class, double.class);
    TYPES.put(Byte.class, byte.class);
    TYPES.put(Short.class, short.class);
    TYPES.put(Long.class, long.class);
  }
  
  public SOAPFaultBuilder(SOAPFault element, DeserializationContext context) {
    this.waiting = false;
    this.passedEnd = false;
    this.faultCode = null;
    this.faultSubCode = null;
    this.faultString = null;
    this.faultActor = null;
    this.faultNode = null;
    this.faultClass = null;
    this.faultData = null;
    this.element = element;
    this.context = context;
  }
  
  public void startElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    SOAPConstants soapConstants = context.getSOAPConstants();
    if (soapConstants == SOAPConstants.SOAP12_CONSTANTS && attributes.getValue("http://www.w3.org/2003/05/soap-envelope", "encodingStyle") != null) {
      AxisFault fault = new AxisFault(Constants.FAULT_SOAP12_SENDER, null, Messages.getMessage("noEncodingStyleAttrAppear", "Fault"), null, null, null);
      throw new SAXException(fault);
    } 
    super.startElement(namespace, localName, prefix, attributes, context);
  }
  
  void setFaultData(Object data) {
    this.faultData = data;
    if (this.waiting && this.passedEnd)
      createFault(); 
    this.waiting = false;
  }
  
  public void setFaultClass(Class faultClass) { this.faultClass = faultClass; }
  
  public void endElement(String namespace, String localName, DeserializationContext context) throws SAXException {
    super.endElement(namespace, localName, context);
    if (!this.waiting) {
      createFault();
    } else {
      this.passedEnd = true;
    } 
  }
  
  void setWaiting(boolean waiting) { this.waiting = waiting; }
  
  private void createFault() {
    AxisFault f = null;
    SOAP11Constants sOAP11Constants = (this.context.getMessageContext() == null) ? SOAPConstants.SOAP11_CONSTANTS : this.context.getMessageContext().getSOAPConstants();
    if (this.faultClass != null)
      try {
        if (this.faultData != null)
          if (this.faultData instanceof AxisFault) {
            f = (AxisFault)this.faultData;
          } else {
            Class argClass = ConvertWrapper(this.faultData.getClass());
            try {
              Constructor con = this.faultClass.getConstructor(new Class[] { argClass });
              f = (AxisFault)con.newInstance(new Object[] { this.faultData });
            } catch (Exception e) {}
            if (f == null && this.faultData instanceof Exception)
              f = AxisFault.makeFault((Exception)this.faultData); 
          }  
        if (AxisFault.class.isAssignableFrom(this.faultClass)) {
          if (f == null)
            f = (AxisFault)this.faultClass.newInstance(); 
          if (sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS) {
            f.setFaultCode(this.code.getFaultCode());
            SOAPFaultCodeBuilder c = this.code;
            while ((c = c.getNext()) != null)
              f.addFaultSubCode(c.getFaultCode()); 
          } else {
            f.setFaultCode(this.faultCode);
          } 
          f.setFaultString(this.faultString);
          f.setFaultActor(this.faultActor);
          f.setFaultNode(this.faultNode);
          f.setFaultDetail(this.faultDetails);
        } 
      } catch (Exception e) {} 
    if (f == null) {
      if (sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS) {
        this.faultCode = this.code.getFaultCode();
        if (this.code.getNext() != null) {
          Vector v = new Vector();
          SOAPFaultCodeBuilder c = this.code;
          while ((c = c.getNext()) != null)
            v.add(c.getFaultCode()); 
          this.faultSubCode = (QName[])v.toArray(new QName[v.size()]);
        } 
      } 
      f = new AxisFault(this.faultCode, this.faultSubCode, this.faultString, this.faultActor, this.faultNode, this.faultDetails);
      try {
        Vector headers = this.element.getEnvelope().getHeaders();
        for (int i = 0; i < headers.size(); i++) {
          SOAPHeaderElement header = (SOAPHeaderElement)headers.elementAt(i);
          f.addHeader(header);
        } 
      } catch (AxisFault axisFault) {}
    } 
    this.element.setFault(f);
  }
  
  public SOAPHandler onStartChild(String namespace, String name, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    QName qName;
    SOAPHandler retHandler = null;
    SOAP11Constants sOAP11Constants = (context.getMessageContext() == null) ? SOAPConstants.SOAP11_CONSTANTS : context.getMessageContext().getSOAPConstants();
    if (sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS) {
      qName = (QName)fields_soap12.get(name);
      if (qName == null) {
        QName thisQName = new QName(namespace, name);
        if (thisQName.equals(Constants.QNAME_FAULTCODE_SOAP12))
          return this.code = new SOAPFaultCodeBuilder(); 
        if (thisQName.equals(Constants.QNAME_FAULTREASON_SOAP12))
          return new SOAPFaultReasonBuilder(this); 
        if (thisQName.equals(Constants.QNAME_FAULTDETAIL_SOAP12))
          return new SOAPFaultDetailsBuilder(this); 
      } 
    } else {
      qName = (QName)fields_soap11.get(name);
      if (qName == null && name.equals("detail"))
        return new SOAPFaultDetailsBuilder(this); 
    } 
    if (qName != null) {
      Deserializer currentDeser = context.getDeserializerForType(qName);
      if (currentDeser != null)
        currentDeser.registerValueTarget(new CallbackTarget(this, new QName(namespace, name))); 
      retHandler = (SOAPHandler)currentDeser;
    } 
    return retHandler;
  }
  
  public void onEndChild(String namespace, String localName, DeserializationContext context) throws SAXException {
    if ("detail".equals(localName)) {
      MessageElement el = context.getCurElement();
      List children = el.getChildren();
      if (children != null) {
        Element[] elements = new Element[children.size()];
        for (int i = 0; i < elements.length; i++) {
          try {
            Node node = (Node)children.get(i);
            if (node instanceof MessageElement) {
              elements[i] = ((MessageElement)node).getAsDOM();
            } else if (node instanceof Text) {
              elements[i] = XMLUtils.newDocument().createElement("text");
              elements[i].appendChild(node);
            } 
          } catch (Exception e) {
            throw new SAXException(e);
          } 
        } 
        this.faultDetails = elements;
      } 
    } 
  }
  
  public void setValue(Object value, Object hint) {
    String local = ((QName)hint).getLocalPart();
    if (((QName)hint).getNamespaceURI().equals("http://www.w3.org/2003/05/soap-envelope")) {
      if (local.equals("Role")) {
        this.faultActor = (String)value;
      } else if (local.equals("Text")) {
        this.faultString = (String)value;
      } else if (local.equals("Node")) {
        this.faultNode = (String)value;
      } 
    } else if (local.equals("faultcode")) {
      this.faultCode = (QName)value;
    } else if (local.equals("faultstring")) {
      this.faultString = (String)value;
    } else if (local.equals("faultactor")) {
      this.faultActor = (String)value;
    } 
  }
  
  private Class ConvertWrapper(Class cls) {
    Class ret = (Class)TYPES.get(cls);
    if (ret != null)
      return ret; 
    return cls;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPFaultBuilder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */