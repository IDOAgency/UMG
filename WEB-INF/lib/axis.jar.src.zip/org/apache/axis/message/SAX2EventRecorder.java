/*     */ package org.apache.axis.message;
/*     */ 
/*     */ import org.apache.axis.encoding.DeserializationContext;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SAX2EventRecorder
/*     */ {
/*  29 */   private static final Integer Z = new Integer(0);
/*     */   
/*  31 */   private static final Integer STATE_SET_DOCUMENT_LOCATOR = new Integer(0);
/*  32 */   private static final Integer STATE_START_DOCUMENT = new Integer(1);
/*  33 */   private static final Integer STATE_END_DOCUMENT = new Integer(2);
/*  34 */   private static final Integer STATE_START_PREFIX_MAPPING = new Integer(3);
/*  35 */   private static final Integer STATE_END_PREFIX_MAPPING = new Integer(4);
/*  36 */   private static final Integer STATE_START_ELEMENT = new Integer(5);
/*  37 */   private static final Integer STATE_END_ELEMENT = new Integer(6);
/*  38 */   private static final Integer STATE_CHARACTERS = new Integer(7);
/*  39 */   private static final Integer STATE_IGNORABLE_WHITESPACE = new Integer(8);
/*  40 */   private static final Integer STATE_PROCESSING_INSTRUCTION = new Integer(9);
/*  41 */   private static final Integer STATE_SKIPPED_ENTITY = new Integer(10);
/*     */ 
/*     */ 
/*     */   
/*  45 */   private static final Integer STATE_NEWELEMENT = new Integer(11);
/*     */ 
/*     */   
/*  48 */   private static final Integer STATE_START_DTD = new Integer(12);
/*  49 */   private static final Integer STATE_END_DTD = new Integer(13);
/*  50 */   private static final Integer STATE_START_ENTITY = new Integer(14);
/*  51 */   private static final Integer STATE_END_ENTITY = new Integer(15);
/*  52 */   private static final Integer STATE_START_CDATA = new Integer(16);
/*  53 */   private static final Integer STATE_END_CDATA = new Integer(17);
/*  54 */   private static final Integer STATE_COMMENT = new Integer(18);
/*     */   
/*     */   Locator locator;
/*  57 */   objArrayVector events = new objArrayVector(this);
/*     */   
/*     */   public void clear() {
/*  60 */     this.locator = null;
/*  61 */     this.events = new objArrayVector(this);
/*     */   }
/*     */ 
/*     */   
/*  65 */   public int getLength() { return this.events.getLength(); }
/*     */ 
/*     */   
/*     */   public int setDocumentLocator(Locator p1) {
/*  69 */     this.locator = p1;
/*  70 */     return this.events.add(STATE_SET_DOCUMENT_LOCATOR, Z, Z, Z, Z);
/*     */   }
/*     */   
/*  73 */   public int startDocument() { return this.events.add(STATE_START_DOCUMENT, Z, Z, Z, Z); }
/*     */ 
/*     */   
/*  76 */   public int endDocument() { return this.events.add(STATE_END_DOCUMENT, Z, Z, Z, Z); }
/*     */ 
/*     */   
/*  79 */   public int startPrefixMapping(String p1, String p2) { return this.events.add(STATE_START_PREFIX_MAPPING, p1, p2, Z, Z); }
/*     */ 
/*     */   
/*  82 */   public int endPrefixMapping(String p1) { return this.events.add(STATE_END_PREFIX_MAPPING, p1, Z, Z, Z); }
/*     */ 
/*     */   
/*  85 */   public int startElement(String p1, String p2, String p3, Attributes p4) { return this.events.add(STATE_START_ELEMENT, p1, p2, p3, p4); }
/*     */ 
/*     */   
/*  88 */   public int endElement(String p1, String p2, String p3) { return this.events.add(STATE_END_ELEMENT, p1, p2, p3, Z); }
/*     */ 
/*     */   
/*  91 */   public int characters(char[] p1, int p2, int p3) { return this.events.add(STATE_CHARACTERS, clone(p1, p2, p3), Z, Z, Z); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public int ignorableWhitespace(char[] p1, int p2, int p3) { return this.events.add(STATE_IGNORABLE_WHITESPACE, clone(p1, p2, p3), Z, Z, Z); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public int processingInstruction(String p1, String p2) { return this.events.add(STATE_PROCESSING_INSTRUCTION, p1, p2, Z, Z); }
/*     */ 
/*     */   
/* 104 */   public int skippedEntity(String p1) { return this.events.add(STATE_SKIPPED_ENTITY, p1, Z, Z, Z); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public void startDTD(String name, String publicId, String systemId) { this.events.add(STATE_START_DTD, name, publicId, systemId, Z); }
/*     */ 
/*     */   
/* 113 */   public void endDTD() { this.events.add(STATE_END_DTD, Z, Z, Z, Z); }
/*     */ 
/*     */   
/* 116 */   public void startEntity(String name) { this.events.add(STATE_START_ENTITY, name, Z, Z, Z); }
/*     */ 
/*     */   
/* 119 */   public void endEntity(String name) { this.events.add(STATE_END_ENTITY, name, Z, Z, Z); }
/*     */ 
/*     */   
/* 122 */   public void startCDATA() { this.events.add(STATE_START_CDATA, Z, Z, Z, Z); }
/*     */ 
/*     */   
/* 125 */   public void endCDATA() { this.events.add(STATE_END_CDATA, Z, Z, Z, Z); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public void comment(char[] ch, int start, int length) { this.events.add(STATE_COMMENT, clone(ch, start, length), Z, Z, Z); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public int newElement(MessageElement elem) { return this.events.add(STATE_NEWELEMENT, elem, Z, Z, Z); }
/*     */ 
/*     */   
/*     */   public void replay(ContentHandler handler) throws SAXException {
/* 140 */     if (this.events.getLength() > 0) {
/* 141 */       replay(0, this.events.getLength() - 1, handler);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void replay(int start, int stop, ContentHandler handler) throws SAXException {
/* 147 */     if (start == 0 && stop == -1) {
/* 148 */       replay(handler);
/*     */       
/*     */       return;
/*     */     } 
/* 152 */     if (stop + 1 > this.events.getLength() || stop < start) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 157 */     LexicalHandler lexicalHandler = null;
/* 158 */     if (handler instanceof LexicalHandler) {
/* 159 */       lexicalHandler = (LexicalHandler)handler;
/*     */     }
/*     */     
/* 162 */     for (int n = start; n <= stop; n++) {
/* 163 */       Object event = this.events.get(n, 0);
/* 164 */       if (event == STATE_START_ELEMENT) {
/* 165 */         handler.startElement((String)this.events.get(n, 1), (String)this.events.get(n, 2), (String)this.events.get(n, 3), (Attributes)this.events.get(n, 4));
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 170 */       else if (event == STATE_END_ELEMENT) {
/* 171 */         handler.endElement((String)this.events.get(n, 1), (String)this.events.get(n, 2), (String)this.events.get(n, 3));
/*     */ 
/*     */       
/*     */       }
/* 175 */       else if (event == STATE_CHARACTERS) {
/* 176 */         char[] data = (char[])this.events.get(n, 1);
/* 177 */         handler.characters(data, 0, data.length);
/*     */       }
/* 179 */       else if (event == STATE_IGNORABLE_WHITESPACE) {
/* 180 */         char[] data = (char[])this.events.get(n, 1);
/* 181 */         handler.ignorableWhitespace(data, 0, data.length);
/*     */       }
/* 183 */       else if (event == STATE_PROCESSING_INSTRUCTION) {
/* 184 */         handler.processingInstruction((String)this.events.get(n, 1), (String)this.events.get(n, 2));
/*     */       
/*     */       }
/* 187 */       else if (event == STATE_SKIPPED_ENTITY) {
/* 188 */         handler.skippedEntity((String)this.events.get(n, 1));
/*     */       }
/* 190 */       else if (event == STATE_SET_DOCUMENT_LOCATOR) {
/* 191 */         handler.setDocumentLocator(this.locator);
/*     */       }
/* 193 */       else if (event == STATE_START_DOCUMENT) {
/* 194 */         handler.startDocument();
/*     */       }
/* 196 */       else if (event == STATE_END_DOCUMENT) {
/* 197 */         handler.endDocument();
/*     */       }
/* 199 */       else if (event == STATE_START_PREFIX_MAPPING) {
/* 200 */         handler.startPrefixMapping((String)this.events.get(n, 1), (String)this.events.get(n, 2));
/*     */       
/*     */       }
/* 203 */       else if (event == STATE_END_PREFIX_MAPPING) {
/* 204 */         handler.endPrefixMapping((String)this.events.get(n, 1));
/*     */       }
/* 206 */       else if (event == STATE_START_DTD && lexicalHandler != null) {
/* 207 */         lexicalHandler.startDTD((String)this.events.get(n, 1), (String)this.events.get(n, 2), (String)this.events.get(n, 3));
/*     */       
/*     */       }
/* 210 */       else if (event == STATE_END_DTD && lexicalHandler != null) {
/* 211 */         lexicalHandler.endDTD();
/*     */       }
/* 213 */       else if (event == STATE_START_ENTITY && lexicalHandler != null) {
/* 214 */         lexicalHandler.startEntity((String)this.events.get(n, 1));
/*     */       }
/* 216 */       else if (event == STATE_END_ENTITY && lexicalHandler != null) {
/* 217 */         lexicalHandler.endEntity((String)this.events.get(n, 1));
/*     */       }
/* 219 */       else if (event == STATE_START_CDATA && lexicalHandler != null) {
/* 220 */         lexicalHandler.startCDATA();
/*     */       }
/* 222 */       else if (event == STATE_END_CDATA && lexicalHandler != null) {
/* 223 */         lexicalHandler.endCDATA();
/*     */       }
/* 225 */       else if (event == STATE_COMMENT && lexicalHandler != null) {
/* 226 */         char[] data = (char[])this.events.get(n, 1);
/* 227 */         lexicalHandler.comment(data, 0, data.length);
/*     */       }
/* 229 */       else if (event == STATE_NEWELEMENT && 
/* 230 */         handler instanceof DeserializationContext) {
/* 231 */         DeserializationContext context = (DeserializationContext)handler;
/*     */         
/* 233 */         context.setCurElement((MessageElement)this.events.get(n, 1));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] clone(char[] in, int off, int len) {
/* 241 */     char[] out = new char[len];
/* 242 */     System.arraycopy(in, off, out, 0, len);
/* 243 */     return out;
/*     */   }
/*     */   class objArrayVector { private int RECORD_SIZE; private int currentSize;
/*     */     objArrayVector(SAX2EventRecorder this$0) {
/* 247 */       this.this$0 = this$0;
/* 248 */       this.RECORD_SIZE = 5;
/* 249 */       this.currentSize = 0;
/* 250 */       this.objarray = new Object[50 * this.RECORD_SIZE];
/*     */     } private Object[] objarray; private final SAX2EventRecorder this$0;
/*     */     public int add(Object p1, Object p2, Object p3, Object p4, Object p5) {
/* 253 */       if (this.currentSize == this.objarray.length) {
/* 254 */         Object[] newarray = new Object[this.currentSize * 2];
/* 255 */         System.arraycopy(this.objarray, 0, newarray, 0, this.currentSize);
/* 256 */         this.objarray = newarray;
/*     */       } 
/* 258 */       int pos = this.currentSize / this.RECORD_SIZE;
/* 259 */       this.objarray[this.currentSize++] = p1;
/* 260 */       this.objarray[this.currentSize++] = p2;
/* 261 */       this.objarray[this.currentSize++] = p3;
/* 262 */       this.objarray[this.currentSize++] = p4;
/* 263 */       this.objarray[this.currentSize++] = p5;
/* 264 */       return pos;
/*     */     }
/*     */ 
/*     */     
/* 268 */     public Object get(int pos, int fld) { return this.objarray[pos * this.RECORD_SIZE + fld]; }
/*     */ 
/*     */ 
/*     */     
/* 272 */     public int getLength() { return this.currentSize / this.RECORD_SIZE; } }
/*     */ 
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SAX2EventRecorder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */