package org.apache.axis.message;

import javax.xml.namespace.QName;
import org.apache.axis.AxisFault;
import org.apache.axis.Constants;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.constants.Style;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.ParameterDesc;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.DeserializerImpl;
import org.apache.axis.encoding.XMLType;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class RPCHandler extends SOAPHandler {
  protected static Log log = LogFactory.getLog(RPCHandler.class.getName());
  
  private RPCElement rpcElem;
  
  private RPCParam currentParam;
  
  private boolean isResponse;
  
  private OperationDesc operation;
  
  private boolean isHeaderElement;
  
  public RPCHandler(RPCElement rpcElem, boolean isResponse) throws SAXException {
    this.currentParam = null;
    this.rpcElem = rpcElem;
    this.isResponse = isResponse;
  }
  
  public void setOperation(OperationDesc myOperation) { this.operation = myOperation; }
  
  public void setHeaderElement(boolean value) { this.isHeaderElement = true; }
  
  public void startElement(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    super.startElement(namespace, localName, prefix, attributes, context);
    this.currentParam = null;
  }
  
  public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
    if (log.isDebugEnabled())
      log.debug("Enter: RPCHandler.onStartChild()"); 
    if (!context.isDoneParsing())
      try {
        context.pushNewElement(new MessageElement(namespace, localName, prefix, attributes, context));
      } catch (AxisFault axisFault) {
        throw new SAXException(axisFault);
      }  
    MessageElement curEl = context.getCurElement();
    QName type = null;
    QName qname = new QName(namespace, localName);
    ParameterDesc paramDesc = null;
    SOAPConstants soapConstants = context.getSOAPConstants();
    if (soapConstants == SOAPConstants.SOAP12_CONSTANTS && Constants.QNAME_RPC_RESULT.equals(qname))
      return new DeserializerImpl(); 
    if (this.currentParam == null || !this.currentParam.getQName().getNamespaceURI().equals(namespace) || !this.currentParam.getQName().getLocalPart().equals(localName)) {
      this.currentParam = new RPCParam(namespace, localName, null);
      this.rpcElem.addParam(this.currentParam);
    } 
    type = curEl.getType();
    if (type == null)
      type = context.getTypeFromAttributes(namespace, localName, attributes); 
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("typeFromAttr00", "" + type)); 
    Class destClass = null;
    if (this.operation != null) {
      if (this.isResponse) {
        paramDesc = this.operation.getOutputParamByQName(qname);
      } else {
        paramDesc = this.operation.getInputParamByQName(qname);
      } 
      if (paramDesc == null)
        if (this.isResponse) {
          paramDesc = this.operation.getReturnParamDesc();
        } else {
          paramDesc = this.operation.getParameter(this.rpcElem.getParams().size() - 1);
        }  
      if (paramDesc == null)
        throw new SAXException(Messages.getMessage("noParmDesc")); 
      if (!this.isHeaderElement && ((this.isResponse && paramDesc.isOutHeader()) || (!this.isResponse && paramDesc.isInHeader())))
        throw new SAXException(Messages.getMessage("expectedHeaderParam", paramDesc.getQName().toString())); 
      destClass = paramDesc.getJavaType();
      if (destClass != null && destClass.isArray())
        context.setDestinationClass(destClass); 
      this.currentParam.setParamDesc(paramDesc);
      if (type == null)
        type = paramDesc.getTypeQName(); 
    } 
    if (type != null && type.equals(XMLType.AXIS_VOID)) {
      DeserializerImpl deserializerImpl1 = new DeserializerImpl();
      return (SOAPHandler)deserializerImpl1;
    } 
    if (context.isNil(attributes)) {
      DeserializerImpl deserializerImpl1 = new DeserializerImpl();
      deserializerImpl1.registerValueTarget(new RPCParamTarget(this.currentParam));
      return (SOAPHandler)deserializerImpl1;
    } 
    DeserializerImpl deserializerImpl = null;
    if (type == null && namespace != null && !namespace.equals("")) {
      deserializerImpl = context.getDeserializerForType(qname);
    } else {
      deserializerImpl = context.getDeserializer(destClass, type);
      if (deserializerImpl == null && destClass != null && destClass.isArray() && this.operation.getStyle() == Style.DOCUMENT)
        deserializerImpl = context.getDeserializerForClass(destClass); 
    } 
    if (deserializerImpl == null)
      if (type != null) {
        deserializerImpl = context.getDeserializerForType(type);
        if (null != destClass && deserializerImpl == null && org.w3c.dom.Element.class.isAssignableFrom(destClass))
          deserializerImpl = context.getDeserializerForType(Constants.SOAP_ELEMENT); 
        if (deserializerImpl == null)
          deserializerImpl = context.getDeserializerForClass(destClass); 
        if (deserializerImpl == null)
          throw new SAXException(Messages.getMessage("noDeser01", localName, "" + type)); 
        if (paramDesc != null && paramDesc.getJavaType() != null) {
          Class xsiClass = context.getTypeMapping().getClassForQName(type);
          if (null != xsiClass && !JavaUtils.isConvertable(xsiClass, destClass))
            throw new SAXException("Bad types (" + xsiClass + " -> " + destClass + ")"); 
        } 
      } else {
        deserializerImpl = context.getDeserializerForClass(destClass);
        if (deserializerImpl == null)
          deserializerImpl = new DeserializerImpl(); 
      }  
    deserializerImpl.setDefaultType(type);
    deserializerImpl.registerValueTarget(new RPCParamTarget(this.currentParam));
    if (log.isDebugEnabled())
      log.debug("Exit: RPCHandler.onStartChild()"); 
    return (SOAPHandler)deserializerImpl;
  }
  
  public void endElement(String namespace, String localName, DeserializationContext context) throws SAXException {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("setProp00", "MessageContext", "RPCHandler.endElement().")); 
    context.getMessageContext().setProperty("RPC", this.rpcElem);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\RPCHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */