package org.apache.axis.message;

import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.xml.namespace.QName;
import javax.xml.soap.Detail;
import javax.xml.soap.DetailEntry;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import org.apache.axis.AxisFault;
import org.apache.axis.Constants;
import org.apache.axis.description.FaultDesc;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.encoding.DeserializationContext;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.soap.SOAP11Constants;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.AttributesImpl;

public class SOAPFault extends SOAPBodyElement implements SOAPFault {
  protected AxisFault fault;
  
  protected String prefix;
  
  private Locale locale;
  
  protected Detail detail = null;
  
  public SOAPFault(String namespace, String localName, String prefix, Attributes attrs, DeserializationContext context) throws AxisFault { super(namespace, localName, prefix, attrs, context); }
  
  public SOAPFault(AxisFault fault) { this.fault = fault; }
  
  public void outputImpl(SerializationContext context) throws Exception {
    SOAP11Constants sOAP11Constants = (context.getMessageContext() == null) ? SOAPConstants.SOAP11_CONSTANTS : context.getMessageContext().getSOAPConstants();
    this.namespaceURI = sOAP11Constants.getEnvelopeURI();
    this.name = "Fault";
    context.registerPrefixForURI(this.prefix, sOAP11Constants.getEnvelopeURI());
    context.startElement(new QName(getNamespaceURI(), getName()), this.attributes);
    if (this.fault instanceof AxisFault) {
      AxisFault axisFault = this.fault;
      if (axisFault.getFaultCode() != null)
        if (sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS) {
          String faultCode = context.qName2String(axisFault.getFaultCode());
          context.startElement(Constants.QNAME_FAULTCODE_SOAP12, null);
          context.startElement(Constants.QNAME_FAULTVALUE_SOAP12, null);
          context.writeSafeString(faultCode);
          context.endElement();
          QName[] subcodes = axisFault.getFaultSubCodes();
          if (subcodes != null) {
            for (int i = 0; i < subcodes.length; i++) {
              faultCode = context.qName2String(subcodes[i]);
              context.startElement(Constants.QNAME_FAULTSUBCODE_SOAP12, null);
              context.startElement(Constants.QNAME_FAULTVALUE_SOAP12, null);
              context.writeSafeString(faultCode);
              context.endElement();
            } 
            for (int i = 0; i < subcodes.length; i++)
              context.endElement(); 
          } 
          context.endElement();
        } else {
          String faultCode = context.qName2String(axisFault.getFaultCode());
          context.startElement(Constants.QNAME_FAULTCODE, null);
          context.writeSafeString(faultCode);
          context.endElement();
        }  
      if (axisFault.getFaultString() != null) {
        if (sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS) {
          context.startElement(Constants.QNAME_FAULTREASON_SOAP12, null);
          AttributesImpl attrs = new AttributesImpl();
          attrs.addAttribute("http://www.w3.org/XML/1998/namespace", "lang", "xml:lang", "CDATA", "en");
          context.startElement(Constants.QNAME_TEXT_SOAP12, attrs);
        } else {
          context.startElement(Constants.QNAME_FAULTSTRING, null);
        } 
        context.writeSafeString(axisFault.getFaultString());
        context.endElement();
        if (sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS)
          context.endElement(); 
      } 
      if (axisFault.getFaultActor() != null) {
        if (sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS) {
          context.startElement(Constants.QNAME_FAULTROLE_SOAP12, null);
        } else {
          context.startElement(Constants.QNAME_FAULTACTOR, null);
        } 
        context.writeSafeString(axisFault.getFaultActor());
        context.endElement();
      } 
      if (axisFault.getFaultNode() != null && 
        sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS) {
        context.startElement(Constants.QNAME_FAULTNODE_SOAP12, null);
        context.writeSafeString(axisFault.getFaultNode());
        context.endElement();
      } 
      QName qname = getFaultQName(this.fault.getClass(), context);
      if (qname == null && this.fault.detail != null)
        qname = getFaultQName(this.fault.detail.getClass(), context); 
      if (qname == null)
        qname = new QName("", "faultData"); 
      Element[] faultDetails = axisFault.getFaultDetails();
      if (faultDetails != null) {
        if (sOAP11Constants == SOAPConstants.SOAP12_CONSTANTS) {
          context.startElement(Constants.QNAME_FAULTDETAIL_SOAP12, null);
        } else {
          context.startElement(Constants.QNAME_FAULTDETAILS, null);
        } 
        axisFault.writeDetails(qname, context);
        for (int i = 0; i < faultDetails.length; i++)
          context.writeDOMElement(faultDetails[i]); 
        if (this.detail != null)
          for (Iterator it = this.detail.getChildren().iterator(); it.hasNext();)
            ((NodeImpl)it.next()).output(context);  
        context.endElement();
      } 
    } 
    context.endElement();
  }
  
  private QName getFaultQName(Class cls, SerializationContext context) {
    QName qname = null;
    if (!cls.equals(AxisFault.class)) {
      FaultDesc faultDesc = null;
      if (context.getMessageContext() != null) {
        OperationDesc op = context.getMessageContext().getOperation();
        if (op != null)
          faultDesc = op.getFaultByClass(cls); 
      } 
      if (faultDesc != null)
        qname = faultDesc.getQName(); 
    } 
    return qname;
  }
  
  public AxisFault getFault() { return this.fault; }
  
  public void setFault(AxisFault fault) { this.fault = fault; }
  
  public void setFaultCode(String faultCode) throws SOAPException { this.fault.setFaultCodeAsString(faultCode); }
  
  public String getFaultCode() { return this.fault.getFaultCode().getLocalPart(); }
  
  public void setFaultActor(String faultActor) throws SOAPException { this.fault.setFaultActor(faultActor); }
  
  public String getFaultActor() { return this.fault.getFaultActor(); }
  
  public void setFaultString(String faultString) throws SOAPException { this.fault.setFaultString(faultString); }
  
  public String getFaultString() { return this.fault.getFaultString(); }
  
  public Detail getDetail() {
    List children = getChildren();
    if (children == null || children.size() <= 0)
      return null; 
    for (int i = 0; i < children.size(); i++) {
      Object obj = children.get(i);
      if (obj instanceof Detail)
        return (Detail)obj; 
    } 
    return null;
  }
  
  public Detail addDetail() {
    if (getDetail() != null)
      throw new SOAPException(Messages.getMessage("valuePresent")); 
    Detail detail = convertToDetail(this.fault);
    addChildElement(detail);
    return detail;
  }
  
  public void setFaultCode(Name faultCodeQName) throws SOAPException {
    String uri = faultCodeQName.getURI();
    String local = faultCodeQName.getLocalName();
    String prefix = faultCodeQName.getPrefix();
    this.prefix = prefix;
    QName qname = new QName(uri, local);
    this.fault.setFaultCode(qname);
  }
  
  public Name getFaultCodeAsName() {
    QName qname = this.fault.getFaultCode();
    String uri = qname.getNamespaceURI();
    String local = qname.getLocalPart();
    return new PrefixedQName(uri, local, this.prefix);
  }
  
  public void setFaultString(String faultString, Locale locale) throws SOAPException {
    this.fault.setFaultString(faultString);
    this.locale = locale;
  }
  
  public Locale getFaultStringLocale() { return this.locale; }
  
  private Detail convertToDetail(AxisFault fault) throws SOAPException {
    this.detail = new Detail();
    Element[] darray = fault.getFaultDetails();
    fault.setFaultDetail(new Element[0]);
    for (int i = 0; i < darray.length; i++) {
      Element detailtEntryElem = darray[i];
      DetailEntry detailEntry = this.detail.addDetailEntry(new PrefixedQName(detailtEntryElem.getNamespaceURI(), detailtEntryElem.getLocalName(), detailtEntryElem.getPrefix()));
      copyChildren(detailEntry, detailtEntryElem);
    } 
    return this.detail;
  }
  
  private static void copyChildren(SOAPElement soapElement, Element domElement) throws SOAPException {
    NodeList nl = domElement.getChildNodes();
    for (int j = 0; j < nl.getLength(); j++) {
      Node childNode = nl.item(j);
      if (childNode.getNodeType() == 3) {
        soapElement.addTextNode(childNode.getNodeValue());
        break;
      } 
      if (childNode.getNodeType() == 1) {
        String uri = childNode.getNamespaceURI();
        SOAPElement childSoapElement = null;
        if (uri == null) {
          childSoapElement = soapElement.addChildElement(childNode.getLocalName());
        } else {
          childSoapElement = soapElement.addChildElement(childNode.getLocalName(), childNode.getPrefix(), uri);
        } 
        copyChildren(childSoapElement, (Element)childNode);
      } 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPFault.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */