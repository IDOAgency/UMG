/*     */ package org.apache.axis.message;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.soap.SOAPException;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.SOAPPart;
/*     */ import org.apache.axis.soap.SOAP11Constants;
/*     */ import org.apache.axis.soap.SOAP12Constants;
/*     */ import org.apache.axis.soap.SOAPConstants;
/*     */ import org.apache.axis.utils.Mapping;
/*     */ import org.apache.axis.utils.XMLUtils;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.CDATASection;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentFragment;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.EntityReference;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SOAPDocumentImpl
/*     */   implements Document, Serializable
/*     */ {
/*  60 */   protected Document delegate = null;
/*  61 */   protected SOAPPart soapPart = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SOAPDocumentImpl(SOAPPart sp) {
/*     */     try {
/*  70 */       this.delegate = XMLUtils.newDocument();
/*  71 */     } catch (ParserConfigurationException e) {}
/*     */ 
/*     */     
/*  74 */     this.soapPart = sp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public DocumentType getDoctype() { return this.delegate.getDoctype(); }
/*     */ 
/*     */ 
/*     */   
/*  87 */   public DOMImplementation getImplementation() { return this.delegate.getImplementation(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public Element getDocumentElement() { return this.soapPart.getDocumentElement(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element createElement(String tagName) throws DOMException {
/*     */     String localname, prefix;
/* 112 */     int index = tagName.indexOf(":");
/*     */     
/* 114 */     if (index < 0) {
/* 115 */       prefix = "";
/* 116 */       localname = tagName;
/*     */     } else {
/* 118 */       prefix = tagName.substring(0, index);
/* 119 */       localname = tagName.substring(index + 1);
/*     */     } 
/*     */     
/*     */     try {
/* 123 */       SOAPEnvelope soapenv = (SOAPEnvelope)this.soapPart.getEnvelope();
/*     */       
/* 125 */       if (soapenv != null) {
/* 126 */         if (tagName.equalsIgnoreCase("Envelope"))
/* 127 */           new SOAPEnvelope(); 
/* 128 */         if (tagName.equalsIgnoreCase("Header"))
/* 129 */           return new SOAPHeader(soapenv, soapenv.getSOAPConstants()); 
/* 130 */         if (tagName.equalsIgnoreCase("Body"))
/* 131 */           return new SOAPBody(soapenv, soapenv.getSOAPConstants()); 
/* 132 */         if (tagName.equalsIgnoreCase("Fault"))
/* 133 */           return new SOAPEnvelope(); 
/* 134 */         if (tagName.equalsIgnoreCase("detail")) {
/* 135 */           return new SOAPFault(new AxisFault(tagName));
/*     */         }
/* 137 */         return new MessageElement("", prefix, localname);
/*     */       } 
/*     */       
/* 140 */       return new MessageElement("", prefix, localname);
/*     */     
/*     */     }
/* 143 */     catch (SOAPException se) {
/* 144 */       throw new DOMException((short)11, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public DocumentFragment createDocumentFragment() { return this.delegate.createDocumentFragment(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Text createTextNode(String data) {
/* 166 */     Text me = new Text(this.delegate.createTextNode(data));
/*     */     
/* 168 */     me.setOwnerDocument(this.soapPart);
/* 169 */     return me;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   public Comment createComment(String data) { return new CommentImpl(data); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public CDATASection createCDATASection(String data) throws DOMException { return new CDATAImpl(data); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   public ProcessingInstruction createProcessingInstruction(String target, String data) throws DOMException { throw new UnsupportedOperationException("createProcessingInstruction"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public Attr createAttribute(String name) throws DOMException { return this.delegate.createAttribute(name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   public EntityReference createEntityReference(String name) throws DOMException { throw new UnsupportedOperationException("createEntityReference"); }
/*     */ 
/*     */   
/*     */   public Node importNode(Node importedNode, boolean deep) throws DOMException {
/*     */     ProcessingInstruction pi;
/*     */     Element el;
/* 241 */     targetNode = null;
/*     */     
/* 243 */     int type = importedNode.getNodeType();
/* 244 */     switch (type) {
/*     */       case 1:
/* 246 */         el = (Element)importedNode;
/* 247 */         if (deep) {
/* 248 */           targetNode = new SOAPBodyElement(el);
/*     */         }
/*     */         else {
/*     */           
/* 252 */           SOAPBodyElement target = new SOAPBodyElement();
/* 253 */           NamedNodeMap attrs = el.getAttributes();
/* 254 */           for (int i = 0; i < attrs.getLength(); i++) {
/* 255 */             Node att = attrs.item(i);
/* 256 */             if (att.getNamespaceURI() != null && att.getPrefix() != null && att.getNamespaceURI().equals("http://www.w3.org/2000/xmlns/") && att.getPrefix().equals("xmlns")) {
/*     */ 
/*     */ 
/*     */               
/* 260 */               Mapping map = new Mapping(att.getNodeValue(), att.getLocalName());
/* 261 */               target.addMapping(map);
/*     */             } 
/* 263 */             if (att.getLocalName() != null) {
/* 264 */               target.addAttribute(att.getPrefix(), att.getNamespaceURI(), att.getLocalName(), att.getNodeValue());
/*     */ 
/*     */             
/*     */             }
/* 268 */             else if (att.getNodeName() != null) {
/* 269 */               target.addAttribute(att.getPrefix(), att.getNamespaceURI(), att.getNodeName(), att.getNodeValue());
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 276 */           if (el.getLocalName() == null) {
/* 277 */             target.setName(el.getNodeName());
/*     */           } else {
/* 279 */             target.setQName(new QName(el.getNamespaceURI(), el.getLocalName()));
/*     */           } 
/* 281 */           targetNode = target;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 342 */         return targetNode;case 2: if (importedNode.getLocalName() == null) { targetNode = createAttribute(importedNode.getNodeName()); } else { targetNode = createAttributeNS(importedNode.getNamespaceURI(), importedNode.getLocalName()); }  return targetNode;case 3: return createTextNode(importedNode.getNodeValue());case 4: return createCDATASection(importedNode.getNodeValue());case 8: return createComment(importedNode.getNodeValue());case 11: targetNode = createDocumentFragment(); if (deep) { NodeList children = importedNode.getChildNodes(); for (int i = 0; i < children.getLength(); i++) targetNode.appendChild(importNode(children.item(i), true));  }  return targetNode;
/*     */       case 5:
/*     */         return createEntityReference(importedNode.getNodeName());
/*     */       case 7:
/*     */         pi = (ProcessingInstruction)importedNode; return createProcessingInstruction(pi.getTarget(), pi.getData());
/*     */       case 6:
/*     */         throw new DOMException((short)9, "Entity nodes are not supported.");
/*     */       case 12:
/*     */         throw new DOMException((short)9, "Notation nodes are not supported.");
/*     */       case 10:
/*     */         throw new DOMException((short)9, "DocumentType nodes cannot be imported.");
/*     */       case 9:
/*     */         throw new DOMException((short)9, "Document nodes cannot be imported.");
/* 355 */     }  throw new DOMException((short)9, "Node type (" + type + ") cannot be imported."); } public Element createElementNS(String namespaceURI, String qualifiedName) throws DOMException { SOAP12Constants sOAP12Constants = null;
/* 356 */     if ("http://schemas.xmlsoap.org/soap/envelope/".equals(namespaceURI)) {
/* 357 */       SOAP11Constants sOAP11Constants = SOAPConstants.SOAP11_CONSTANTS;
/* 358 */     } else if ("http://www.w3.org/2003/05/soap-envelope".equals(namespaceURI)) {
/* 359 */       sOAP12Constants = SOAPConstants.SOAP12_CONSTANTS;
/*     */     } 
/*     */ 
/*     */     
/* 363 */     MessageElement me = null;
/* 364 */     if (sOAP12Constants != null) {
/* 365 */       if (qualifiedName.equals("Envelope")) {
/*     */         
/* 367 */         me = new SOAPEnvelope(sOAP12Constants);
/* 368 */       } else if (qualifiedName.equals("Header")) {
/* 369 */         me = new SOAPHeader(null, sOAP12Constants);
/*     */       }
/* 371 */       else if (qualifiedName.equals("Body")) {
/* 372 */         me = new SOAPBody(null, sOAP12Constants);
/* 373 */       } else if (qualifiedName.equals("Fault")) {
/* 374 */         me = null;
/* 375 */       } else if (qualifiedName.equals("detail")) {
/*     */         
/* 377 */         me = null;
/*     */       } else {
/* 379 */         throw new DOMException((short)11, "No such Localname for SOAP URI");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 384 */       return null;
/*     */     } 
/*     */     
/* 387 */     me = new MessageElement(namespaceURI, qualifiedName);
/*     */ 
/*     */     
/* 390 */     if (me != null) {
/* 391 */       me.setOwnerDocument(this.soapPart);
/*     */     }
/* 393 */     return me; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 403 */   public Attr createAttributeNS(String namespaceURI, String qualifiedName) throws DOMException { return this.delegate.createAttributeNS(namespaceURI, qualifiedName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeList getElementsByTagNameNS(String namespaceURI, String localName) {
/*     */     try {
/* 415 */       NodeListImpl list = new NodeListImpl();
/* 416 */       if (this.soapPart != null) {
/* 417 */         SOAPEnvelope soapEnv = (SOAPEnvelope)this.soapPart.getEnvelope();
/*     */ 
/*     */         
/* 420 */         SOAPHeader header = (SOAPHeader)soapEnv.getHeader();
/*     */         
/* 422 */         if (header != null) {
/* 423 */           list.addNodeList(header.getElementsByTagNameNS(namespaceURI, localName));
/*     */         }
/*     */ 
/*     */         
/* 427 */         SOAPBody body = (SOAPBody)soapEnv.getBody();
/*     */         
/* 429 */         if (body != null) {
/* 430 */           list.addNodeList(body.getElementsByTagNameNS(namespaceURI, localName));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 435 */       return list;
/* 436 */     } catch (SOAPException se) {
/* 437 */       throw new DOMException((short)11, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeList getElementsByTagName(String localName) {
/*     */     try {
/* 449 */       NodeListImpl list = new NodeListImpl();
/* 450 */       if (this.soapPart != null) {
/* 451 */         SOAPEnvelope soapEnv = (SOAPEnvelope)this.soapPart.getEnvelope();
/*     */ 
/*     */         
/* 454 */         SOAPHeader header = (SOAPHeader)soapEnv.getHeader();
/*     */         
/* 456 */         if (header != null) {
/* 457 */           list.addNodeList(header.getElementsByTagName(localName));
/*     */         }
/* 459 */         SOAPBody body = (SOAPBody)soapEnv.getBody();
/*     */         
/* 461 */         if (body != null) {
/* 462 */           list.addNodeList(body.getElementsByTagName(localName));
/*     */         }
/*     */       } 
/* 465 */       return list;
/* 466 */     } catch (SOAPException se) {
/* 467 */       throw new DOMException((short)11, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 485 */   public Element getElementById(String elementId) throws DOMException { return this.delegate.getElementById(elementId); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 494 */   public String getNodeName() { return null; }
/*     */ 
/*     */ 
/*     */   
/* 498 */   public String getNodeValue() { throw new DOMException((short)6, "Cannot use TextNode.get in " + this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 504 */   public void setNodeValue(String nodeValue) throws DOMException { throw new DOMException((short)6, "Cannot use TextNode.set in " + this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 515 */   public short getNodeType() { return 9; }
/*     */ 
/*     */ 
/*     */   
/* 519 */   public Node getParentNode() { return null; }
/*     */ 
/*     */   
/*     */   public NodeList getChildNodes() {
/*     */     try {
/* 524 */       if (this.soapPart != null) {
/* 525 */         NodeListImpl children = new NodeListImpl();
/* 526 */         children.addNode(this.soapPart.getEnvelope());
/* 527 */         return children;
/*     */       } 
/* 529 */       return NodeListImpl.EMPTY_NODELIST;
/*     */     }
/* 531 */     catch (SOAPException se) {
/* 532 */       throw new DOMException((short)11, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getFirstChild() {
/*     */     try {
/* 544 */       if (this.soapPart != null) {
/* 545 */         return (SOAPEnvelope)this.soapPart.getEnvelope();
/*     */       }
/*     */       
/* 548 */       return null;
/* 549 */     } catch (SOAPException se) {
/* 550 */       throw new DOMException((short)11, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Node getLastChild() {
/*     */     try {
/* 560 */       if (this.soapPart != null) {
/* 561 */         return (SOAPEnvelope)this.soapPart.getEnvelope();
/*     */       }
/*     */       
/* 564 */       return null;
/* 565 */     } catch (SOAPException se) {
/* 566 */       throw new DOMException((short)11, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 572 */   public Node getPreviousSibling() { return null; }
/*     */ 
/*     */ 
/*     */   
/* 576 */   public Node getNextSibling() { return null; }
/*     */ 
/*     */ 
/*     */   
/* 580 */   public NamedNodeMap getAttributes() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 588 */   public Document getOwnerDocument() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 595 */   public Node insertBefore(Node newChild, Node refChild) throws DOMException { throw new DOMException((short)9, ""); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 600 */   public Node replaceChild(Node newChild, Node oldChild) throws DOMException { throw new DOMException((short)9, ""); }
/*     */ 
/*     */ 
/*     */   
/*     */   public Node removeChild(Node oldChild) throws DOMException {
/*     */     try {
/* 606 */       if (this.soapPart != null) {
/* 607 */         Node envNode = this.soapPart.getEnvelope();
/* 608 */         if (envNode.equals(oldChild)) {
/* 609 */           return envNode;
/*     */         }
/*     */       } 
/* 612 */       throw new DOMException((short)9, "");
/* 613 */     } catch (SOAPException se) {
/* 614 */       throw new DOMException((short)11, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 619 */   public Node appendChild(Node newChild) throws DOMException { throw new DOMException((short)9, ""); }
/*     */ 
/*     */   
/*     */   public boolean hasChildNodes() {
/*     */     try {
/* 624 */       if (this.soapPart != null && 
/* 625 */         this.soapPart.getEnvelope() != null) {
/* 626 */         return true;
/*     */       }
/*     */       
/* 629 */       return false;
/* 630 */     } catch (SOAPException se) {
/* 631 */       throw new DOMException((short)11, "");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 641 */   public Node cloneNode(boolean deep) { throw new DOMException((short)9, ""); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 649 */   public void normalize() { throw new DOMException((short)9, ""); }
/*     */ 
/*     */ 
/*     */   
/* 653 */   private String[] features = { "foo", "bar" };
/* 654 */   private String version = "version 2.0";
/*     */   
/*     */   public boolean isSupported(String feature, String version) {
/* 657 */     if (!version.equalsIgnoreCase(version)) {
/* 658 */       return false;
/*     */     }
/* 660 */     return true;
/*     */   }
/*     */ 
/*     */   
/* 664 */   public String getPrefix() { throw new DOMException((short)9, ""); }
/*     */ 
/*     */   
/* 667 */   public void setPrefix(String prefix) throws DOMException { throw new DOMException((short)9, ""); }
/*     */ 
/*     */ 
/*     */   
/* 671 */   public String getNamespaceURI() { throw new DOMException((short)9, ""); }
/*     */ 
/*     */   
/* 674 */   public void setNamespaceURI(String nsURI) throws DOMException { throw new DOMException((short)9, ""); }
/*     */ 
/*     */ 
/*     */   
/* 678 */   public String getLocalName() { throw new DOMException((short)9, ""); }
/*     */ 
/*     */ 
/*     */   
/* 682 */   public boolean hasAttributes() { throw new DOMException((short)9, ""); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPDocumentImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */