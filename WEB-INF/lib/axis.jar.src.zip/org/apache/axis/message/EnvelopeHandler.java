/*    */ package org.apache.axis.message;
/*    */ 
/*    */ import org.apache.axis.encoding.DeserializationContext;
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvelopeHandler
/*    */   extends SOAPHandler
/*    */ {
/*    */   SOAPHandler realHandler;
/*    */   
/* 33 */   public EnvelopeHandler(SOAPHandler realHandler) { this.realHandler = realHandler; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public SOAPHandler onStartChild(String namespace, String localName, String prefix, Attributes attributes, DeserializationContext context) throws SAXException { return this.realHandler; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\EnvelopeHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */