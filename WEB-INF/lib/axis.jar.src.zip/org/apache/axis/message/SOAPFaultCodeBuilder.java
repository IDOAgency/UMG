/*    */ package org.apache.axis.message;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.Constants;
/*    */ import org.apache.axis.encoding.Callback;
/*    */ import org.apache.axis.encoding.CallbackTarget;
/*    */ import org.apache.axis.encoding.DeserializationContext;
/*    */ import org.apache.axis.encoding.Deserializer;
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPFaultCodeBuilder
/*    */   extends SOAPHandler
/*    */   implements Callback
/*    */ {
/* 38 */   protected QName faultCode = null;
/* 39 */   protected SOAPFaultCodeBuilder next = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public QName getFaultCode() { return this.faultCode; }
/*    */ 
/*    */ 
/*    */   
/* 49 */   public SOAPFaultCodeBuilder getNext() { return this.next; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SOAPHandler onStartChild(String namespace, String name, String prefix, Attributes attributes, DeserializationContext context) throws SAXException {
/* 60 */     QName thisQName = new QName(namespace, name);
/* 61 */     if (thisQName.equals(Constants.QNAME_FAULTVALUE_SOAP12)) {
/* 62 */       Deserializer currentDeser = null;
/* 63 */       currentDeser = context.getDeserializerForType(Constants.XSD_QNAME);
/* 64 */       if (currentDeser != null) {
/* 65 */         currentDeser.registerValueTarget(new CallbackTarget(this, thisQName));
/*    */       }
/* 67 */       return (SOAPHandler)currentDeser;
/* 68 */     }  if (thisQName.equals(Constants.QNAME_FAULTSUBCODE_SOAP12)) {
/* 69 */       return this.next = new SOAPFaultCodeBuilder();
/*    */     }
/* 71 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setValue(Object value, Object hint) {
/* 81 */     QName thisQName = (QName)hint;
/* 82 */     if (thisQName.equals(Constants.QNAME_FAULTVALUE_SOAP12))
/* 83 */       this.faultCode = (QName)value; 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\SOAPFaultCodeBuilder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */