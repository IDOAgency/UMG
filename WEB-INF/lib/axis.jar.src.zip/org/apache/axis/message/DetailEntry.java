package org.apache.axis.message;

import javax.xml.soap.DetailEntry;
import javax.xml.soap.Name;

public class DetailEntry extends MessageElement implements DetailEntry {
  public DetailEntry(Name name) { super(name); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\DetailEntry.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */