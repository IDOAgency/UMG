package org.apache.axis.message;

public interface IDResolver {
  Object getReferencedObject(String paramString);
  
  void addReferencedObject(String paramString, Object paramObject);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\IDResolver.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */