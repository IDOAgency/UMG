/*    */ package org.apache.axis.message;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.axis.encoding.SerializationContext;
/*    */ import org.apache.axis.utils.IOUtils;
/*    */ import org.apache.axis.utils.Messages;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InputStreamBody
/*    */   extends SOAPBodyElement
/*    */ {
/* 31 */   protected static Log log = LogFactory.getLog(InputStreamBody.class.getName());
/*    */ 
/*    */   
/*    */   protected InputStream inputStream;
/*    */ 
/*    */ 
/*    */   
/* 38 */   public InputStreamBody(InputStream inputStream) { this.inputStream = inputStream; }
/*    */ 
/*    */ 
/*    */   
/*    */   public void outputImpl(SerializationContext context) throws IOException {
/*    */     try {
/* 44 */       byte[] buf = new byte[this.inputStream.available()];
/* 45 */       IOUtils.readFully(this.inputStream, buf);
/* 46 */       String contents = new String(buf);
/* 47 */       context.writeString(contents);
/*    */     }
/* 49 */     catch (IOException ex) {
/* 50 */       throw ex;
/*    */     }
/* 52 */     catch (Exception e) {
/* 53 */       log.error(Messages.getMessage("exception00"), e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\InputStreamBody.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */