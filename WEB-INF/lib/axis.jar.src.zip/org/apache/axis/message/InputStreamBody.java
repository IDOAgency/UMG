package org.apache.axis.message;

import java.io.IOException;
import java.io.InputStream;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.IOUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class InputStreamBody extends SOAPBodyElement {
  protected static Log log = LogFactory.getLog(InputStreamBody.class.getName());
  
  protected InputStream inputStream;
  
  public InputStreamBody(InputStream inputStream) { this.inputStream = inputStream; }
  
  public void outputImpl(SerializationContext context) throws IOException {
    try {
      byte[] buf = new byte[this.inputStream.available()];
      IOUtils.readFully(this.inputStream, buf);
      String contents = new String(buf);
      context.writeString(contents);
    } catch (IOException ex) {
      throw ex;
    } catch (Exception e) {
      log.error(Messages.getMessage("exception00"), e);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\InputStreamBody.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */