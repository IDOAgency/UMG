package org.apache.axis.message;

import javax.xml.soap.Text;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

public class CommentImpl extends Text implements Text, Comment {
  public CommentImpl(String text) { super(text); }
  
  public boolean isComment() { return true; }
  
  public Text splitText(int offset) throws DOMException {
    int length = this.textRep.getLength();
    String tailData = this.textRep.substringData(offset, length);
    this.textRep.deleteData(offset, length);
    Text tailText = new CommentImpl(tailData);
    Node myParent = getParentNode();
    if (myParent != null) {
      NodeList brothers = myParent.getChildNodes();
      for (int i = 0; i < brothers.getLength(); i++) {
        if (brothers.item(i).equals(this)) {
          myParent.insertBefore(tailText, this);
          return tailText;
        } 
      } 
    } 
    return tailText;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\CommentImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */