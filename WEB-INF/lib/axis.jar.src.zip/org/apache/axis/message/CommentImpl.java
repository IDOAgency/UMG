/*    */ package org.apache.axis.message;
/*    */ 
/*    */ import javax.xml.soap.Text;
/*    */ import org.w3c.dom.Comment;
/*    */ import org.w3c.dom.DOMException;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ import org.w3c.dom.Text;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommentImpl
/*    */   extends Text
/*    */   implements Text, Comment
/*    */ {
/* 36 */   public CommentImpl(String text) { super(text); }
/*    */ 
/*    */ 
/*    */   
/* 40 */   public boolean isComment() { return true; }
/*    */ 
/*    */   
/*    */   public Text splitText(int offset) throws DOMException {
/* 44 */     int length = this.textRep.getLength();
/*    */ 
/*    */ 
/*    */     
/* 48 */     String tailData = this.textRep.substringData(offset, length);
/* 49 */     this.textRep.deleteData(offset, length);
/*    */ 
/*    */     
/* 52 */     Text tailText = new CommentImpl(tailData);
/* 53 */     Node myParent = getParentNode();
/* 54 */     if (myParent != null) {
/* 55 */       NodeList brothers = myParent.getChildNodes();
/*    */       
/* 57 */       for (int i = 0; i < brothers.getLength(); i++) {
/* 58 */         if (brothers.item(i).equals(this)) {
/* 59 */           myParent.insertBefore(tailText, this);
/* 60 */           return tailText;
/*    */         } 
/*    */       } 
/*    */     } 
/* 64 */     return tailText;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\CommentImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */