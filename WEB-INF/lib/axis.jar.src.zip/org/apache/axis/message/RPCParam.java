package org.apache.axis.message;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import org.apache.axis.Constants;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.constants.Style;
import org.apache.axis.description.ParameterDesc;
import org.apache.axis.encoding.SerializationContext;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class RPCParam extends MessageElement implements Serializable {
  protected static Log log = LogFactory.getLog(RPCParam.class.getName());
  
  private Object value = null;
  
  private int countSetCalls = 0;
  
  private ParameterDesc paramDesc;
  
  private Boolean wantXSIType = null;
  
  private static Method valueSetMethod;
  
  static  {
    cls = RPCParam.class;
    try {
      valueSetMethod = cls.getMethod("set", new Class[] { Object.class });
    } catch (NoSuchMethodException e) {
      log.error(Messages.getMessage("noValue00", "" + e));
      throw new RuntimeException(e.getMessage());
    } 
  }
  
  public RPCParam(String name, Object value) { this(new QName("", name), value); }
  
  public RPCParam(QName qname, Object value) {
    super(qname);
    if (value instanceof String) {
      try {
        addTextNode((String)value);
      } catch (SOAPException e) {
        throw new RuntimeException(Messages.getMessage("cannotCreateTextNode00"));
      } 
    } else {
      this.value = value;
    } 
  }
  
  public RPCParam(String namespace, String name, Object value) { this(new QName(namespace, name), value); }
  
  public void setRPCCall(RPCElement call) { this.parent = call; }
  
  public Object getObjectValue() { return this.value; }
  
  public void setObjectValue(Object value) { this.value = value; }
  
  public void set(Object newValue) {
    this.countSetCalls++;
    if (this.countSetCalls == 1) {
      this.value = newValue;
      return;
    } 
    if (this.countSetCalls == 2) {
      ArrayList list = new ArrayList();
      list.add(this.value);
      this.value = list;
    } 
    ((ArrayList)this.value).add(newValue);
  }
  
  public static Method getValueSetMethod() { return valueSetMethod; }
  
  public ParameterDesc getParamDesc() { return this.paramDesc; }
  
  public void setParamDesc(ParameterDesc paramDesc) { this.paramDesc = paramDesc; }
  
  public void setXSITypeGeneration(Boolean value) { this.wantXSIType = value; }
  
  public Boolean getXSITypeGeneration() { return this.wantXSIType; }
  
  public void serialize(SerializationContext context) throws IOException {
    Class javaType = (this.value == null) ? null : this.value.getClass();
    QName xmlType = null;
    Boolean sendNull = Boolean.TRUE;
    if (this.paramDesc != null) {
      if (javaType == null) {
        javaType = (this.paramDesc.getJavaType() != null) ? this.paramDesc.getJavaType() : javaType;
      } else if (!javaType.equals(this.paramDesc.getJavaType())) {
        Class clazz = JavaUtils.getPrimitiveClass(javaType);
        if ((clazz == null || !clazz.equals(this.paramDesc.getJavaType())) && 
          !javaType.equals(JavaUtils.getHolderValueType(this.paramDesc.getJavaType())))
          this.wantXSIType = Boolean.TRUE; 
      } 
      xmlType = this.paramDesc.getTypeQName();
      QName itemQName = this.paramDesc.getItemQName();
      if (itemQName == null) {
        MessageContext mc = context.getMessageContext();
        if (mc != null && mc.getOperation() != null && mc.getOperation().getStyle() == Style.DOCUMENT)
          itemQName = Constants.QNAME_LITERAL_ITEM; 
      } 
      context.setItemQName(itemQName);
      QName itemType = this.paramDesc.getItemType();
      context.setItemType(itemType);
      if (this.paramDesc.isOmittable() && !this.paramDesc.isNillable())
        sendNull = Boolean.FALSE; 
    } 
    context.serialize(getQName(), null, this.value, xmlType, sendNull, this.wantXSIType);
  }
  
  private void writeObject(ObjectOutputStream out) throws IOException {
    if (getQName() == null) {
      out.writeBoolean(false);
    } else {
      out.writeBoolean(true);
      out.writeObject(getQName().getNamespaceURI());
      out.writeObject(getQName().getLocalPart());
    } 
    out.defaultWriteObject();
  }
  
  private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
    if (in.readBoolean())
      setQName(new QName((String)in.readObject(), (String)in.readObject())); 
    in.defaultReadObject();
  }
  
  protected void outputImpl(SerializationContext context) throws IOException { serialize(context); }
  
  public String getValue() { return getValueDOM(); }
  
  public SOAPElement addTextNode(String s) throws SOAPException {
    this.value = s;
    return super.addTextNode(s);
  }
  
  public void setValue(String value) {
    this.value = value;
    super.setValue(value);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\RPCParam.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */