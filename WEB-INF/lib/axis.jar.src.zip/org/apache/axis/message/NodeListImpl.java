/*    */ package org.apache.axis.message;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NodeListImpl
/*    */   implements NodeList
/*    */ {
/* 37 */   public static final NodeList EMPTY_NODELIST = new NodeListImpl(Collections.EMPTY_LIST);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   List mNodes = new ArrayList();
/*    */ 
/*    */   
/*    */   NodeListImpl(List nodes) {
/* 48 */     this();
/* 49 */     this.mNodes.addAll(nodes);
/*    */   }
/*    */   NodeListImpl() {}
/*    */   
/* 53 */   void addNode(Node node) { this.mNodes.add(node); }
/*    */ 
/*    */   
/*    */   void addNodeList(NodeList nodes) {
/* 57 */     for (int i = 0; i < nodes.getLength(); i++) {
/* 58 */       this.mNodes.add(nodes.item(i));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Node item(int index) {
/* 69 */     if (this.mNodes != null && this.mNodes.size() > index) {
/* 70 */       return (Node)this.mNodes.get(index);
/*    */     }
/* 72 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 77 */   public int getLength() { return this.mNodes.size(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\message\NodeListImpl.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */