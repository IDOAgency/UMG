/*    */ package org.apache.axis.security.servlet;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.axis.security.AuthenticatedUser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ServletAuthenticatedUser
/*    */   implements AuthenticatedUser
/*    */ {
/*    */   private String name;
/*    */   private HttpServletRequest req;
/*    */   
/*    */   public ServletAuthenticatedUser(HttpServletRequest req) {
/* 38 */     this.req = req;
/* 39 */     Principal principal = req.getUserPrincipal();
/* 40 */     this.name = (principal == null) ? null : principal.getName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public String getName() { return this.name; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public HttpServletRequest getRequest() { return this.req; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\security\servlet\ServletAuthenticatedUser.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */