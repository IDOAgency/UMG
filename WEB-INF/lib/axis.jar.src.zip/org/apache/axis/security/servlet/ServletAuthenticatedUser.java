package org.apache.axis.security.servlet;

import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.apache.axis.security.AuthenticatedUser;

public class ServletAuthenticatedUser implements AuthenticatedUser {
  private String name;
  
  private HttpServletRequest req;
  
  public ServletAuthenticatedUser(HttpServletRequest req) {
    this.req = req;
    Principal principal = req.getUserPrincipal();
    this.name = (principal == null) ? null : principal.getName();
  }
  
  public String getName() { return this.name; }
  
  public HttpServletRequest getRequest() { return this.req; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\security\servlet\ServletAuthenticatedUser.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */