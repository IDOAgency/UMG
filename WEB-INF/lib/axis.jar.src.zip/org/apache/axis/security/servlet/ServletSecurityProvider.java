package org.apache.axis.security.servlet;

import java.security.Principal;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.security.AuthenticatedUser;
import org.apache.axis.security.SecurityProvider;
import org.apache.axis.transport.http.HTTPConstants;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class ServletSecurityProvider implements SecurityProvider {
  protected static Log log = LogFactory.getLog(ServletSecurityProvider.class.getName());
  
  static HashMap users = null;
  
  public AuthenticatedUser authenticate(MessageContext msgContext) {
    HttpServletRequest req = (HttpServletRequest)msgContext.getProperty(HTTPConstants.MC_HTTP_SERVLETREQUEST);
    if (req == null)
      return null; 
    log.debug(Messages.getMessage("got00", "HttpServletRequest"));
    Principal principal = req.getUserPrincipal();
    if (principal == null) {
      log.debug(Messages.getMessage("noPrincipal00"));
      return null;
    } 
    log.debug(Messages.getMessage("gotPrincipal00", principal.getName()));
    return new ServletAuthenticatedUser(req);
  }
  
  public boolean userMatches(AuthenticatedUser user, String principal) {
    if (user == null)
      return (principal == null); 
    if (user instanceof ServletAuthenticatedUser) {
      ServletAuthenticatedUser servletUser = (ServletAuthenticatedUser)user;
      return servletUser.getRequest().isUserInRole(principal);
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\security\servlet\ServletSecurityProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */