package org.apache.axis.security;

import org.apache.axis.MessageContext;

public interface SecurityProvider {
  AuthenticatedUser authenticate(MessageContext paramMessageContext);
  
  boolean userMatches(AuthenticatedUser paramAuthenticatedUser, String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\security\SecurityProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */