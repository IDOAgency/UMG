/*    */ package org.apache.axis.security.simple;
/*    */ 
/*    */ import org.apache.axis.security.AuthenticatedUser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleAuthenticatedUser
/*    */   implements AuthenticatedUser
/*    */ {
/*    */   private String name;
/*    */   
/* 33 */   public SimpleAuthenticatedUser(String name) { this.name = name; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public String getName() { return this.name; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\security\simple\SimpleAuthenticatedUser.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */