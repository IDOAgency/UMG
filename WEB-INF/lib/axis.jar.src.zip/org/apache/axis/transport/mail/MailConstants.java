package org.apache.axis.transport.mail;

public class MailConstants {
  public static final String FROM_ADDRESS = "transport.mail.from";
  
  public static final String TO_ADDRESS = "transport.mail.to";
  
  public static final String SMTP_HOST = "transport.mail.smtp.host";
  
  public static final String POP3_HOST = "transport.mail.pop3.host";
  
  public static final String POP3_USERID = "transport.mail.pop3.userid";
  
  public static final String POP3_PASSWORD = "transport.mail.pop3.password";
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\mail\MailConstants.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */