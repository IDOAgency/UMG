package org.apache.axis.transport.mail;

import org.apache.axis.AxisEngine;
import org.apache.axis.MessageContext;
import org.apache.axis.client.Call;
import org.apache.axis.client.Transport;

public class MailTransport extends Transport {
  public void setupMessageContextImpl(MessageContext mc, Call call, AxisEngine engine) {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\mail\MailTransport.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */