package org.apache.axis.transport.mail;

import java.io.ByteArrayOutputStream;
import java.io.Writer;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.axis.AxisFault;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.message.SOAPFault;
import org.apache.axis.server.AxisServer;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;
import org.apache.commons.net.smtp.SMTPClient;
import org.apache.commons.net.smtp.SMTPReply;

public class MailWorker implements Runnable {
  protected static Log log = LogFactory.getLog(MailWorker.class.getName());
  
  private MailServer server;
  
  private MimeMessage mimeMessage;
  
  private static String transportName = "Mail";
  
  private Properties prop;
  
  private Session session;
  
  public MailWorker(MailServer server, MimeMessage mimeMessage) {
    this.prop = new Properties();
    this.session = Session.getDefaultInstance(this.prop, null);
    this.server = server;
    this.mimeMessage = mimeMessage;
  }
  
  public void run() {
    AxisServer engine = MailServer.getAxisServer();
    MessageContext msgContext = new MessageContext(engine);
    StringBuffer soapAction = new StringBuffer();
    StringBuffer fileName = new StringBuffer();
    StringBuffer contentType = new StringBuffer();
    StringBuffer contentLocation = new StringBuffer();
    Message responseMsg = null;
    try {
      msgContext.setTargetService(null);
    } catch (AxisFault fault) {}
    msgContext.setResponseMessage(null);
    msgContext.reset();
    msgContext.setTransportName(transportName);
    responseMsg = null;
    try {
      try {
        parseHeaders(this.mimeMessage, contentType, contentLocation, soapAction);
        msgContext.setProperty("realpath", fileName.toString());
        msgContext.setProperty("path", fileName.toString());
        msgContext.setProperty("jws.classDir", "jwsClasses");
        String soapActionString = soapAction.toString();
        if (soapActionString != null) {
          msgContext.setUseSOAPAction(true);
          msgContext.setSOAPActionURI(soapActionString);
        } 
        Message requestMsg = new Message(this.mimeMessage.getInputStream(), false, contentType.toString(), contentLocation.toString());
        msgContext.setRequestMessage(requestMsg);
        engine.invoke(msgContext);
        responseMsg = msgContext.getResponseMessage();
        if (responseMsg == null)
          throw new AxisFault(Messages.getMessage("nullResponse00")); 
      } catch (Exception e) {
        AxisFault af;
        e.printStackTrace();
        if (e instanceof AxisFault) {
          af = (AxisFault)e;
          log.debug(Messages.getMessage("serverFault00"), af);
        } else {
          af = AxisFault.makeFault(e);
        } 
        responseMsg = msgContext.getResponseMessage();
        if (responseMsg == null) {
          responseMsg = new Message(af);
        } else {
          try {
            SOAPEnvelope env = responseMsg.getSOAPEnvelope();
            env.clearBody();
            env.addBodyElement(new SOAPFault((AxisFault)e));
          } catch (AxisFault fault) {}
        } 
      } 
      String replyTo = ((InternetAddress)this.mimeMessage.getReplyTo()[0]).getAddress();
      String sendFrom = ((InternetAddress)this.mimeMessage.getAllRecipients()[0]).getAddress();
      String subject = "Re: " + this.mimeMessage.getSubject();
      writeUsingSMTP(msgContext, this.server.getHost(), sendFrom, replyTo, subject, responseMsg);
    } catch (Exception e) {
      e.printStackTrace();
      log.debug(Messages.getMessage("exception00"), e);
    } 
    if (msgContext.getProperty("quit.requested") != null)
      try {
        this.server.stop();
      } catch (Exception e) {} 
  }
  
  private void writeUsingSMTP(MessageContext msgContext, String smtpHost, String sendFrom, String replyTo, String subject, Message output) throws Exception {
    SMTPClient client = new SMTPClient();
    client.connect(smtpHost);
    System.out.print(client.getReplyString());
    int reply = client.getReplyCode();
    if (!SMTPReply.isPositiveCompletion(reply)) {
      client.disconnect();
      AxisFault fault = new AxisFault("SMTP", "( SMTP server refused connection )", null, null);
      throw fault;
    } 
    client.login(smtpHost);
    System.out.print(client.getReplyString());
    reply = client.getReplyCode();
    if (!SMTPReply.isPositiveCompletion(reply)) {
      client.disconnect();
      AxisFault fault = new AxisFault("SMTP", "( SMTP server refused connection )", null, null);
      throw fault;
    } 
    MimeMessage msg = new MimeMessage(this.session);
    msg.setFrom(new InternetAddress(sendFrom));
    msg.addRecipient(MimeMessage.RecipientType.TO, new InternetAddress(replyTo));
    msg.setDisposition("inline");
    msg.setSubject(subject);
    ByteArrayOutputStream out = new ByteArrayOutputStream(8192);
    output.writeTo(out);
    msg.setContent(out.toString(), output.getContentType(msgContext.getSOAPConstants()));
    ByteArrayOutputStream out2 = new ByteArrayOutputStream(8192);
    msg.writeTo(out2);
    client.setSender(sendFrom);
    System.out.print(client.getReplyString());
    client.addRecipient(replyTo);
    System.out.print(client.getReplyString());
    Writer writer = client.sendMessageData();
    System.out.print(client.getReplyString());
    writer.write(out2.toString());
    writer.flush();
    writer.close();
    System.out.print(client.getReplyString());
    if (!client.completePendingCommand()) {
      System.out.print(client.getReplyString());
      AxisFault fault = new AxisFault("SMTP", "( Failed to send email )", null, null);
      throw fault;
    } 
    System.out.print(client.getReplyString());
    client.logout();
    client.disconnect();
  }
  
  private void parseHeaders(MimeMessage mimeMessage, StringBuffer contentType, StringBuffer contentLocation, StringBuffer soapAction) throws Exception {
    contentType.append(mimeMessage.getContentType());
    contentLocation.append(mimeMessage.getContentID());
    String[] values = mimeMessage.getHeader("SOAPAction");
    if (values != null)
      soapAction.append(values[0]); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\mail\MailWorker.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */