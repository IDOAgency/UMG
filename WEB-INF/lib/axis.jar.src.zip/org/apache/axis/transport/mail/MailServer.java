/*     */ package org.apache.axis.transport.mail;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.i18n.Messages;
/*     */ import org.apache.axis.server.AxisServer;
/*     */ import org.apache.axis.utils.Options;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.net.pop3.POP3Client;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MailServer
/*     */   implements Runnable
/*     */ {
/*  46 */   protected static Log log = LogFactory.getLog(MailServer.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String host;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int port;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String userid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MailServer(String host, int port, String userid, String password) {
/*  88 */     this.stopped = false;
/*     */     this.host = host;
/*     */     this.port = port;
/*     */     this.userid = userid;
/*     */     this.password = password;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean doThreads = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDoThreads(boolean value) { doThreads = value; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDoThreads() { return doThreads; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHost() { return this.host; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AxisServer myAxisServer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean stopped;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private POP3Client pop3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static AxisServer getAxisServer() {
/*     */     if (myAxisServer == null) {
/*     */       myAxisServer = new AxisServer();
/*     */     }
/*     */     return myAxisServer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() { // Byte code:
/*     */     //   0: getstatic org/apache/axis/transport/mail/MailServer.log : Lorg/apache/commons/logging/Log;
/*     */     //   3: ldc 'start00'
/*     */     //   5: ldc 'MailServer'
/*     */     //   7: new java/lang/StringBuffer
/*     */     //   10: dup
/*     */     //   11: invokespecial <init> : ()V
/*     */     //   14: aload_0
/*     */     //   15: getfield host : Ljava/lang/String;
/*     */     //   18: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   21: ldc ':'
/*     */     //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*     */     //   26: aload_0
/*     */     //   27: getfield port : I
/*     */     //   30: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*     */     //   33: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   36: invokestatic getMessage : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   39: invokeinterface info : (Ljava/lang/Object;)V
/*     */     //   44: aload_0
/*     */     //   45: getfield stopped : Z
/*     */     //   48: ifne -> 383
/*     */     //   51: aload_0
/*     */     //   52: getfield pop3 : Lorg/apache/commons/net/pop3/POP3Client;
/*     */     //   55: aload_0
/*     */     //   56: getfield host : Ljava/lang/String;
/*     */     //   59: aload_0
/*     */     //   60: getfield port : I
/*     */     //   63: invokevirtual connect : (Ljava/lang/String;I)V
/*     */     //   66: aload_0
/*     */     //   67: getfield pop3 : Lorg/apache/commons/net/pop3/POP3Client;
/*     */     //   70: aload_0
/*     */     //   71: getfield userid : Ljava/lang/String;
/*     */     //   74: aload_0
/*     */     //   75: getfield password : Ljava/lang/String;
/*     */     //   78: invokevirtual login : (Ljava/lang/String;Ljava/lang/String;)Z
/*     */     //   81: pop
/*     */     //   82: aload_0
/*     */     //   83: getfield pop3 : Lorg/apache/commons/net/pop3/POP3Client;
/*     */     //   86: invokevirtual listMessages : ()[Lorg/apache/commons/net/pop3/POP3MessageInfo;
/*     */     //   89: astore_1
/*     */     //   90: aload_1
/*     */     //   91: ifnull -> 296
/*     */     //   94: aload_1
/*     */     //   95: arraylength
/*     */     //   96: ifle -> 296
/*     */     //   99: iconst_0
/*     */     //   100: istore_2
/*     */     //   101: iload_2
/*     */     //   102: aload_1
/*     */     //   103: arraylength
/*     */     //   104: if_icmpge -> 296
/*     */     //   107: aload_0
/*     */     //   108: getfield pop3 : Lorg/apache/commons/net/pop3/POP3Client;
/*     */     //   111: aload_1
/*     */     //   112: iload_2
/*     */     //   113: aaload
/*     */     //   114: getfield number : I
/*     */     //   117: invokevirtual retrieveMessage : (I)Ljava/io/Reader;
/*     */     //   120: astore_3
/*     */     //   121: aload_3
/*     */     //   122: ifnonnull -> 128
/*     */     //   125: goto -> 290
/*     */     //   128: new java/lang/StringBuffer
/*     */     //   131: dup
/*     */     //   132: invokespecial <init> : ()V
/*     */     //   135: astore #4
/*     */     //   137: new java/io/BufferedReader
/*     */     //   140: dup
/*     */     //   141: aload_3
/*     */     //   142: invokespecial <init> : (Ljava/io/Reader;)V
/*     */     //   145: astore #5
/*     */     //   147: aload #5
/*     */     //   149: invokevirtual read : ()I
/*     */     //   152: dup
/*     */     //   153: istore #6
/*     */     //   155: iconst_m1
/*     */     //   156: if_icmpeq -> 171
/*     */     //   159: aload #4
/*     */     //   161: iload #6
/*     */     //   163: i2c
/*     */     //   164: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   167: pop
/*     */     //   168: goto -> 147
/*     */     //   171: aload #5
/*     */     //   173: invokevirtual close : ()V
/*     */     //   176: new java/io/ByteArrayInputStream
/*     */     //   179: dup
/*     */     //   180: aload #4
/*     */     //   182: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   185: invokevirtual getBytes : ()[B
/*     */     //   188: invokespecial <init> : ([B)V
/*     */     //   191: astore #7
/*     */     //   193: new java/util/Properties
/*     */     //   196: dup
/*     */     //   197: invokespecial <init> : ()V
/*     */     //   200: astore #8
/*     */     //   202: aload #8
/*     */     //   204: aconst_null
/*     */     //   205: invokestatic getDefaultInstance : (Ljava/util/Properties;Ljavax/mail/Authenticator;)Ljavax/mail/Session;
/*     */     //   208: astore #9
/*     */     //   210: new javax/mail/internet/MimeMessage
/*     */     //   213: dup
/*     */     //   214: aload #9
/*     */     //   216: aload #7
/*     */     //   218: invokespecial <init> : (Ljavax/mail/Session;Ljava/io/InputStream;)V
/*     */     //   221: astore #10
/*     */     //   223: aload_0
/*     */     //   224: getfield pop3 : Lorg/apache/commons/net/pop3/POP3Client;
/*     */     //   227: aload_1
/*     */     //   228: iload_2
/*     */     //   229: aaload
/*     */     //   230: getfield number : I
/*     */     //   233: invokevirtual deleteMessage : (I)Z
/*     */     //   236: pop
/*     */     //   237: aload #10
/*     */     //   239: ifnull -> 290
/*     */     //   242: new org/apache/axis/transport/mail/MailWorker
/*     */     //   245: dup
/*     */     //   246: aload_0
/*     */     //   247: aload #10
/*     */     //   249: invokespecial <init> : (Lorg/apache/axis/transport/mail/MailServer;Ljavax/mail/internet/MimeMessage;)V
/*     */     //   252: astore #11
/*     */     //   254: getstatic org/apache/axis/transport/mail/MailServer.doThreads : Z
/*     */     //   257: ifeq -> 285
/*     */     //   260: new java/lang/Thread
/*     */     //   263: dup
/*     */     //   264: aload #11
/*     */     //   266: invokespecial <init> : (Ljava/lang/Runnable;)V
/*     */     //   269: astore #12
/*     */     //   271: aload #12
/*     */     //   273: iconst_1
/*     */     //   274: invokevirtual setDaemon : (Z)V
/*     */     //   277: aload #12
/*     */     //   279: invokevirtual start : ()V
/*     */     //   282: goto -> 290
/*     */     //   285: aload #11
/*     */     //   287: invokevirtual run : ()V
/*     */     //   290: iinc #2, 1
/*     */     //   293: goto -> 101
/*     */     //   296: jsr -> 338
/*     */     //   299: goto -> 44
/*     */     //   302: astore_1
/*     */     //   303: jsr -> 338
/*     */     //   306: goto -> 44
/*     */     //   309: astore_1
/*     */     //   310: getstatic org/apache/axis/transport/mail/MailServer.log : Lorg/apache/commons/logging/Log;
/*     */     //   313: ldc 'exception00'
/*     */     //   315: invokestatic getMessage : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   318: aload_1
/*     */     //   319: invokeinterface debug : (Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   324: jsr -> 338
/*     */     //   327: goto -> 383
/*     */     //   330: astore #13
/*     */     //   332: jsr -> 338
/*     */     //   335: aload #13
/*     */     //   337: athrow
/*     */     //   338: astore #14
/*     */     //   340: aload_0
/*     */     //   341: getfield pop3 : Lorg/apache/commons/net/pop3/POP3Client;
/*     */     //   344: invokevirtual logout : ()Z
/*     */     //   347: pop
/*     */     //   348: aload_0
/*     */     //   349: getfield pop3 : Lorg/apache/commons/net/pop3/POP3Client;
/*     */     //   352: invokevirtual disconnect : ()V
/*     */     //   355: ldc2_w 3000
/*     */     //   358: invokestatic sleep : (J)V
/*     */     //   361: goto -> 381
/*     */     //   364: astore #15
/*     */     //   366: getstatic org/apache/axis/transport/mail/MailServer.log : Lorg/apache/commons/logging/Log;
/*     */     //   369: ldc 'exception00'
/*     */     //   371: invokestatic getMessage : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   374: aload #15
/*     */     //   376: invokeinterface error : (Ljava/lang/Object;Ljava/lang/Throwable;)V
/*     */     //   381: ret #14
/*     */     //   383: getstatic org/apache/axis/transport/mail/MailServer.log : Lorg/apache/commons/logging/Log;
/*     */     //   386: ldc 'quit00'
/*     */     //   388: ldc 'MailServer'
/*     */     //   390: invokestatic getMessage : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   393: invokeinterface info : (Ljava/lang/Object;)V
/*     */     //   398: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #95	-> 0
/*     */     //   #98	-> 44
/*     */     //   #100	-> 51
/*     */     //   #101	-> 66
/*     */     //   #103	-> 82
/*     */     //   #104	-> 90
/*     */     //   #105	-> 99
/*     */     //   #106	-> 107
/*     */     //   #107	-> 121
/*     */     //   #108	-> 125
/*     */     //   #111	-> 128
/*     */     //   #112	-> 137
/*     */     //   #115	-> 147
/*     */     //   #116	-> 159
/*     */     //   #118	-> 171
/*     */     //   #119	-> 176
/*     */     //   #120	-> 193
/*     */     //   #121	-> 202
/*     */     //   #123	-> 210
/*     */     //   #124	-> 223
/*     */     //   #125	-> 237
/*     */     //   #126	-> 242
/*     */     //   #127	-> 254
/*     */     //   #128	-> 260
/*     */     //   #129	-> 271
/*     */     //   #130	-> 277
/*     */     //   #132	-> 285
/*     */     //   #105	-> 290
/*     */     //   #137	-> 296
/*     */     //   #149	-> 299
/*     */     //   #137	-> 302
/*     */     //   #138	-> 303
/*     */     //   #149	-> 306
/*     */     //   #138	-> 309
/*     */     //   #139	-> 310
/*     */     //   #140	-> 324
/*     */     //   #142	-> 330
/*     */     //   #143	-> 340
/*     */     //   #144	-> 348
/*     */     //   #145	-> 355
/*     */     //   #148	-> 361
/*     */     //   #146	-> 364
/*     */     //   #147	-> 366
/*     */     //   #148	-> 381
/*     */     //   #151	-> 383
/*     */     //   #152	-> 398
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   271	11	12	thread	Ljava/lang/Thread;
/*     */     //   254	36	11	worker	Lorg/apache/axis/transport/mail/MailWorker;
/*     */     //   121	169	3	reader	Ljava/io/Reader;
/*     */     //   137	153	4	buffer	Ljava/lang/StringBuffer;
/*     */     //   147	143	5	bufferedReader	Ljava/io/BufferedReader;
/*     */     //   155	135	6	ch	I
/*     */     //   193	97	7	bais	Ljava/io/ByteArrayInputStream;
/*     */     //   202	88	8	prop	Ljava/util/Properties;
/*     */     //   210	80	9	session	Ljavax/mail/Session;
/*     */     //   223	67	10	mimeMsg	Ljavax/mail/internet/MimeMessage;
/*     */     //   101	195	2	i	I
/*     */     //   90	206	1	messages	[Lorg/apache/commons/net/pop3/POP3MessageInfo;
/*     */     //   303	0	1	iie	Ljava/io/InterruptedIOException;
/*     */     //   310	20	1	e	Ljava/lang/Exception;
/*     */     //   366	15	15	e	Ljava/lang/Exception;
/*     */     //   0	399	0	this	Lorg/apache/axis/transport/mail/MailServer;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   51	296	302	java/io/InterruptedIOException
/*     */     //   51	296	309	java/lang/Exception
/*     */     //   51	299	330	finally
/*     */     //   302	306	330	finally
/*     */     //   309	327	330	finally
/*     */     //   330	335	330	finally
/*     */     //   340	361	364	java/lang/Exception }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public POP3Client getPOP3() { return this.pop3; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public void setPOP3(POP3Client pop3) { this.pop3 = pop3; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(boolean daemon) {
/* 183 */     if (doThreads) {
/* 184 */       Thread thread = new Thread(this);
/* 185 */       thread.setDaemon(daemon);
/* 186 */       thread.start();
/*     */     } else {
/* 188 */       run();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public void start() { start(false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 209 */     this.stopped = true;
/* 210 */     log.info(Messages.getMessage("quit00", "MailServer"));
/*     */ 
/*     */     
/* 213 */     System.exit(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 220 */     Options opts = null;
/*     */     try {
/* 222 */       opts = new Options(args);
/* 223 */     } catch (MalformedURLException e) {
/* 224 */       log.error(Messages.getMessage("malformedURLException00"), e);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 229 */       doThreads = (opts.isFlagSet('t') > 0);
/* 230 */       String host = opts.getHost();
/* 231 */       int port = (opts.isFlagSet('p') > 0) ? opts.getPort() : 110;
/* 232 */       POP3Client pop3 = new POP3Client();
/* 233 */       MailServer sas = new MailServer(host, port, opts.getUser(), opts.getPassword());
/*     */       
/* 235 */       sas.setPOP3(pop3);
/* 236 */       sas.start();
/* 237 */     } catch (Exception e) {
/* 238 */       log.error(Messages.getMessage("exception00"), e);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\mail\MailServer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */