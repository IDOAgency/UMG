package org.apache.axis.transport.mail;

import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;

public class Handler extends URLStreamHandler {
  protected URLConnection openConnection(URL u) { return null; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\mail\Handler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */