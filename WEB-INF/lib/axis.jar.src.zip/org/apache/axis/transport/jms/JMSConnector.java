package org.apache.axis.transport.jms;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import org.apache.axis.components.jms.JMSVendorAdapter;

public abstract class JMSConnector {
  protected int m_numRetries;
  
  protected long m_connectRetryInterval;
  
  protected long m_interactRetryInterval;
  
  protected long m_timeoutTime;
  
  protected long m_poolTimeout;
  
  protected AsyncConnection m_receiveConnection;
  
  protected SyncConnection m_sendConnection;
  
  protected int m_numSessions;
  
  protected boolean m_allowReceive;
  
  protected JMSVendorAdapter m_adapter;
  
  protected JMSURLHelper m_jmsurl;
  
  public JMSConnector(ConnectionFactory connectionFactory, int numRetries, int numSessions, long connectRetryInterval, long interactRetryInterval, long timeoutTime, boolean allowReceive, String clientID, String username, String password, JMSVendorAdapter adapter, JMSURLHelper jmsurl) throws JMSException {
    this.m_numRetries = numRetries;
    this.m_connectRetryInterval = connectRetryInterval;
    this.m_interactRetryInterval = interactRetryInterval;
    this.m_timeoutTime = timeoutTime;
    this.m_poolTimeout = timeoutTime / numRetries;
    this.m_numSessions = numSessions;
    this.m_allowReceive = allowReceive;
    this.m_adapter = adapter;
    this.m_jmsurl = jmsurl;
    Connection sendConnection = createConnectionWithRetry(connectionFactory, username, password);
    this.m_sendConnection = createSyncConnection(connectionFactory, sendConnection, this.m_numSessions, "SendThread", clientID, username, password);
    this.m_sendConnection.start();
    if (this.m_allowReceive) {
      Connection receiveConnection = createConnectionWithRetry(connectionFactory, username, password);
      this.m_receiveConnection = createAsyncConnection(connectionFactory, receiveConnection, "ReceiveThread", clientID, username, password);
      this.m_receiveConnection.start();
    } 
  }
  
  public int getNumRetries() { return this.m_numRetries; }
  
  public int numSessions() { return this.m_numSessions; }
  
  public ConnectionFactory getConnectionFactory() { return getSendConnection().getConnectionFactory(); }
  
  public String getClientID() { return getSendConnection().getClientID(); }
  
  public String getUsername() { return getSendConnection().getUsername(); }
  
  public String getPassword() { return getSendConnection().getPassword(); }
  
  public JMSVendorAdapter getVendorAdapter() { return this.m_adapter; }
  
  public JMSURLHelper getJMSURL() { return this.m_jmsurl; }
  
  protected Connection createConnectionWithRetry(ConnectionFactory connectionFactory, String username, String password) throws JMSException {
    Connection connection = null;
    for (int numTries = 1; connection == null; numTries++) {
      try {
        connection = internalConnect(connectionFactory, username, password);
      } catch (JMSException jmse) {
        if (!this.m_adapter.isRecoverable(jmse, 1) || numTries == this.m_numRetries)
          throw jmse; 
        try {
          Thread.sleep(this.m_connectRetryInterval);
        } catch (InterruptedException ie) {}
      } 
    } 
    return connection;
  }
  
  public void stop() {
    JMSConnectorManager.getInstance().removeConnectorFromPool(this);
    this.m_sendConnection.stopConnection();
    if (this.m_allowReceive)
      this.m_receiveConnection.stopConnection(); 
  }
  
  public void start() {
    this.m_sendConnection.startConnection();
    if (this.m_allowReceive)
      this.m_receiveConnection.startConnection(); 
    JMSConnectorManager.getInstance().addConnectorToPool(this);
  }
  
  public void shutdown() {
    this.m_sendConnection.shutdown();
    if (this.m_allowReceive)
      this.m_receiveConnection.shutdown(); 
  }
  
  public abstract JMSEndpoint createEndpoint(String paramString) throws JMSException;
  
  public abstract JMSEndpoint createEndpoint(Destination paramDestination) throws JMSException;
  
  protected abstract Connection internalConnect(ConnectionFactory paramConnectionFactory, String paramString1, String paramString2) throws JMSException;
  
  protected abstract SyncConnection createSyncConnection(ConnectionFactory paramConnectionFactory, Connection paramConnection, int paramInt, String paramString1, String paramString2, String paramString3, String paramString4) throws JMSException;
  
  private abstract class Connection extends Thread implements ExceptionListener {
    private ConnectionFactory m_connectionFactory;
    
    protected Connection m_connection;
    
    protected boolean m_isActive;
    
    private boolean m_needsToConnect;
    
    private boolean m_startConnection;
    
    private String m_clientID;
    
    private String m_username;
    
    private String m_password;
    
    private Object m_jmsLock;
    
    private Object m_lifecycleLock;
    
    private final JMSConnector this$0;
    
    protected Connection(JMSConnector this$0, ConnectionFactory connectionFactory, Connection connection, String threadName, String clientID, String username, String password) throws JMSException {
      super(threadName);
      this.this$0 = this$0;
      this.m_connectionFactory = connectionFactory;
      this.m_clientID = clientID;
      this.m_username = username;
      this.m_password = password;
      this.m_jmsLock = new Object();
      this.m_lifecycleLock = new Object();
      if (connection != null) {
        this.m_needsToConnect = false;
        this.m_connection = connection;
        this.m_connection.setExceptionListener(this);
        if (this.m_clientID != null)
          this.m_connection.setClientID(this.m_clientID); 
      } else {
        this.m_needsToConnect = true;
      } 
      this.m_isActive = true;
    }
    
    public ConnectionFactory getConnectionFactory() { return this.m_connectionFactory; }
    
    public String getClientID() { return this.m_clientID; }
    
    public String getUsername() { return this.m_username; }
    
    public String getPassword() { return this.m_password; }
    
    public void run() {
      while (this.m_isActive) {
        if (this.m_needsToConnect) {
          this.m_connection = null;
          try {
            this.m_connection = this.this$0.internalConnect(this.m_connectionFactory, this.m_username, this.m_password);
            this.m_connection.setExceptionListener(this);
            if (this.m_clientID != null)
              this.m_connection.setClientID(this.m_clientID); 
          } catch (JMSException e) {
            try {
              Thread.sleep(this.this$0.m_connectRetryInterval);
              continue;
            } catch (InterruptedException ie) {
              continue;
            } 
          } 
        } else {
          this.m_needsToConnect = true;
        } 
        try {
          internalOnConnect();
        } catch (Exception e) {
          continue;
        } 
        synchronized (this.m_jmsLock) {
          try {
            this.m_jmsLock.wait();
          } catch (InterruptedException ie) {}
        } 
      } 
      internalOnShutdown();
    }
    
    void startConnection() {
      synchronized (this.m_lifecycleLock) {
        if (this.m_startConnection)
          return; 
        this.m_startConnection = true;
        try {
          this.m_connection.start();
        } catch (Throwable e) {}
      } 
    }
    
    void stopConnection() {
      synchronized (this.m_lifecycleLock) {
        if (!this.m_startConnection)
          return; 
        this.m_startConnection = false;
        try {
          this.m_connection.stop();
        } catch (Throwable e) {}
      } 
    }
    
    void shutdown() {
      this.m_isActive = false;
      synchronized (this.m_jmsLock) {
        this.m_jmsLock.notifyAll();
      } 
    }
    
    public void onException(JMSException exception) {
      if (this.this$0.m_adapter.isRecoverable(exception, 4))
        return; 
      onException();
      synchronized (this.m_jmsLock) {
        this.m_jmsLock.notifyAll();
      } 
    }
    
    private final void internalOnConnect() {
      onConnect();
      synchronized (this.m_lifecycleLock) {
        if (this.m_startConnection)
          try {
            this.m_connection.start();
          } catch (Throwable e) {} 
      } 
    }
    
    private final void internalOnShutdown() {
      stopConnection();
      onShutdown();
      try {
        this.m_connection.close();
      } catch (Throwable e) {}
    }
    
    protected abstract void onConnect();
    
    protected abstract void onShutdown();
    
    protected abstract void onException();
  }
  
  SyncConnection getSendConnection() { return this.m_sendConnection; }
  
  protected abstract class SyncConnection extends Connection {
    LinkedList m_senders;
    
    int m_numSessions;
    
    Object m_senderLock;
    
    private final JMSConnector this$0;
    
    SyncConnection(JMSConnector this$0, ConnectionFactory connectionFactory, Connection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException {
      super(this$0, connectionFactory, connection, threadName, clientID, username, password);
      this.this$0 = this$0;
      this.m_senders = new LinkedList();
      this.m_numSessions = numSessions;
      this.m_senderLock = new Object();
    }
    
    protected void onConnect() {
      synchronized (this.m_senderLock) {
        for (int i = 0; i < this.m_numSessions; i++)
          this.m_senders.add(createSendSession(this.m_connection)); 
        this.m_senderLock.notifyAll();
      } 
    }
    
    byte[] call(JMSEndpoint endpoint, byte[] message, long timeout, HashMap properties) throws Exception {
      long timeoutTime = System.currentTimeMillis() + timeout;
      while (true) {
        if (System.currentTimeMillis() > timeoutTime)
          throw new InvokeTimeoutException("Unable to complete call in time allotted"); 
        SendSession sendSession = null;
        try {
          sendSession = getSessionFromPool(this.this$0.m_poolTimeout);
          byte[] response = sendSession.call(endpoint, message, timeoutTime - System.currentTimeMillis(), properties);
          returnSessionToPool(sendSession);
          if (response == null)
            throw new InvokeTimeoutException("Unable to complete call in time allotted"); 
          return response;
        } catch (JMSException jmse) {
          if (!this.this$0.m_adapter.isRecoverable(jmse, 0)) {
            returnSessionToPool(sendSession);
            throw jmse;
          } 
          Thread.yield();
        } catch (NullPointerException npe) {
          Thread.yield();
        } 
      } 
    }
    
    void send(JMSEndpoint endpoint, byte[] message, HashMap properties) throws Exception {
      long timeoutTime = System.currentTimeMillis() + this.this$0.m_timeoutTime;
      while (true) {
        if (System.currentTimeMillis() > timeoutTime)
          throw new InvokeTimeoutException("Cannot complete send in time allotted"); 
        SendSession sendSession = null;
        try {
          sendSession = getSessionFromPool(this.this$0.m_poolTimeout);
          sendSession.send(endpoint, message, properties);
          returnSessionToPool(sendSession);
          break;
        } catch (JMSException jmse) {
          if (!this.this$0.m_adapter.isRecoverable(jmse, 0)) {
            returnSessionToPool(sendSession);
            throw jmse;
          } 
          Thread.yield();
        } catch (NullPointerException npe) {
          Thread.yield();
        } 
      } 
    }
    
    protected void onException() {
      synchronized (this.m_senderLock) {
        this.m_senders.clear();
      } 
    }
    
    protected void onShutdown() {
      synchronized (this.m_senderLock) {
        Iterator senders = this.m_senders.iterator();
        while (senders.hasNext()) {
          SendSession session = (SendSession)senders.next();
          session.cleanup();
        } 
        this.m_senders.clear();
      } 
    }
    
    private SendSession getSessionFromPool(long timeout) {
      synchronized (this.m_senderLock) {
        while (this.m_senders.size() == 0) {
          try {
            this.m_senderLock.wait(timeout);
            if (this.m_senders.size() == 0)
              return null; 
          } catch (InterruptedException ignore) {
            return null;
          } 
        } 
        return (SendSession)this.m_senders.removeFirst();
      } 
    }
    
    private void returnSessionToPool(SendSession sendSession) {
      synchronized (this.m_senderLock) {
        this.m_senders.addLast(sendSession);
        this.m_senderLock.notifyAll();
      } 
    }
    
    protected abstract SendSession createSendSession(Connection param1Connection) throws JMSException;
    
    protected abstract class SendSession extends JMSConnector.ConnectorSession {
      MessageProducer m_producer;
      
      private final JMSConnector.SyncConnection this$1;
      
      SendSession(JMSConnector.SyncConnection this$1, Session session, MessageProducer producer) throws JMSException {
        super(this$1.this$0, session);
        this.this$1 = this$1;
        this.m_producer = producer;
      }
      
      protected abstract Destination createTemporaryDestination() throws JMSException;
      
      protected abstract void deleteTemporaryDestination(Destination param2Destination) throws JMSException;
      
      protected abstract MessageConsumer createConsumer(Destination param2Destination) throws JMSException;
      
      protected abstract void send(Destination param2Destination, Message param2Message, int param2Int1, int param2Int2, long param2Long) throws JMSException;
      
      void send(JMSEndpoint endpoint, byte[] message, HashMap properties) throws Exception {
        BytesMessage jmsMessage = this.m_session.createBytesMessage();
        jmsMessage.writeBytes(message);
        int deliveryMode = extractDeliveryMode(properties);
        int priority = extractPriority(properties);
        long timeToLive = extractTimeToLive(properties);
        if (properties != null && !properties.isEmpty())
          setProperties(properties, jmsMessage); 
        send(endpoint.getDestination(this.m_session), jmsMessage, deliveryMode, priority, timeToLive);
      }
      
      void cleanup() {
        try {
          this.m_producer.close();
        } catch (Throwable t) {}
        try {
          this.m_session.close();
        } catch (Throwable t) {}
      }
      
      byte[] call(JMSEndpoint endpoint, byte[] message, long timeout, HashMap properties) throws Exception {
        Destination reply = createTemporaryDestination();
        MessageConsumer subscriber = createConsumer(reply);
        BytesMessage jmsMessage = this.m_session.createBytesMessage();
        jmsMessage.writeBytes(message);
        jmsMessage.setJMSReplyTo(reply);
        int deliveryMode = extractDeliveryMode(properties);
        int priority = extractPriority(properties);
        long timeToLive = extractTimeToLive(properties);
        if (properties != null && !properties.isEmpty())
          setProperties(properties, jmsMessage); 
        send(endpoint.getDestination(this.m_session), jmsMessage, deliveryMode, priority, timeToLive);
        BytesMessage response = null;
        try {
          response = (BytesMessage)subscriber.receive(timeout);
        } catch (ClassCastException cce) {
          throw new InvokeException("Error: unexpected message type received - expected BytesMessage");
        } 
        byte[] respBytes = null;
        if (response != null) {
          byte[] buffer = new byte[8192];
          ByteArrayOutputStream out = new ByteArrayOutputStream();
          int bytesRead = response.readBytes(buffer);
          for (; bytesRead != -1; bytesRead = response.readBytes(buffer))
            out.write(buffer, 0, bytesRead); 
          respBytes = out.toByteArray();
        } 
        subscriber.close();
        deleteTemporaryDestination(reply);
        return respBytes;
      }
      
      private int extractPriority(HashMap properties) { return MapUtils.removeIntProperty(properties, "transport.jms.priority", 4); }
      
      private int extractDeliveryMode(HashMap properties) { return MapUtils.removeIntProperty(properties, "transport.jms.deliveryMode", 1); }
      
      private long extractTimeToLive(HashMap properties) { return MapUtils.removeLongProperty(properties, "transport.jms.ttl", 0L); }
      
      private void setProperties(HashMap properties, Message message) throws JMSException {
        Iterator propertyIter = properties.entrySet().iterator();
        while (propertyIter.hasNext()) {
          Map.Entry property = (Map.Entry)propertyIter.next();
          setProperty((String)property.getKey(), property.getValue(), message);
        } 
      }
      
      private void setProperty(String property, Object value, Message message) throws JMSException {
        if (property == null)
          return; 
        if (property.equals("transport.jms.jmsCorrelationID")) {
          message.setJMSCorrelationID((String)value);
        } else if (property.equals("transport.jms.jmsCorrelationIDAsBytes")) {
          message.setJMSCorrelationIDAsBytes((byte[])value);
        } else if (property.equals("transport.jms.jmsType")) {
          message.setJMSType((String)value);
        } else {
          message.setObjectProperty(property, value);
        } 
      }
    }
  }
  
  AsyncConnection getReceiveConnection() { return this.m_receiveConnection; }
  
  protected abstract AsyncConnection createAsyncConnection(ConnectionFactory paramConnectionFactory, Connection paramConnection, String paramString1, String paramString2, String paramString3, String paramString4) throws JMSException;
  
  protected abstract class AsyncConnection extends Connection {
    HashMap m_subscriptions;
    
    Object m_subscriptionLock;
    
    private final JMSConnector this$0;
    
    protected AsyncConnection(JMSConnector this$0, ConnectionFactory connectionFactory, Connection connection, String threadName, String clientID, String username, String password) throws JMSException {
      super(this$0, connectionFactory, connection, threadName, clientID, username, password);
      this.this$0 = this$0;
      this.m_subscriptions = new HashMap();
      this.m_subscriptionLock = new Object();
    }
    
    protected void onShutdown() {
      synchronized (this.m_subscriptionLock) {
        Iterator subscriptions = this.m_subscriptions.keySet().iterator();
        while (subscriptions.hasNext()) {
          Subscription subscription = (Subscription)subscriptions.next();
          ListenerSession session = (ListenerSession)this.m_subscriptions.get(subscription);
          if (session != null)
            session.cleanup(); 
        } 
        this.m_subscriptions.clear();
      } 
    }
    
    void subscribe(Subscription subscription) throws Exception {
      long timeoutTime = System.currentTimeMillis() + this.this$0.m_timeoutTime;
      synchronized (this.m_subscriptionLock) {
        if (this.m_subscriptions.containsKey(subscription))
          return; 
        while (true) {
          if (System.currentTimeMillis() > timeoutTime)
            throw new InvokeTimeoutException("Cannot subscribe listener"); 
          try {
            ListenerSession session = createListenerSession(this.m_connection, subscription);
            this.m_subscriptions.put(subscription, session);
            break;
          } catch (JMSException jmse) {
            if (!this.this$0.m_adapter.isRecoverable(jmse, 2))
              throw jmse; 
            try {
              this.m_subscriptionLock.wait(this.this$0.m_interactRetryInterval);
            } catch (InterruptedException ignore) {}
            Thread.yield();
          } catch (NullPointerException jmse) {
            try {
              this.m_subscriptionLock.wait(this.this$0.m_interactRetryInterval);
            } catch (InterruptedException ignore) {}
            Thread.yield();
          } 
        } 
      } 
    }
    
    void unsubscribe(Subscription subscription) throws Exception {
      long timeoutTime = System.currentTimeMillis() + this.this$0.m_timeoutTime;
      synchronized (this.m_subscriptionLock) {
        if (!this.m_subscriptions.containsKey(subscription))
          return; 
        while (true) {
          if (System.currentTimeMillis() > timeoutTime)
            throw new InvokeTimeoutException("Cannot unsubscribe listener"); 
          Thread.yield();
          try {
            ListenerSession session = (ListenerSession)this.m_subscriptions.get(subscription);
            session.cleanup();
            this.m_subscriptions.remove(subscription);
            break;
          } catch (NullPointerException jmse) {
            try {
              this.m_subscriptionLock.wait(this.this$0.m_interactRetryInterval);
            } catch (InterruptedException ignore) {}
          } 
        } 
      } 
    }
    
    protected void onConnect() {
      synchronized (this.m_subscriptionLock) {
        Iterator subscriptions = this.m_subscriptions.keySet().iterator();
        while (subscriptions.hasNext()) {
          Subscription subscription = (Subscription)subscriptions.next();
          if (this.m_subscriptions.get(subscription) == null)
            this.m_subscriptions.put(subscription, createListenerSession(this.m_connection, subscription)); 
        } 
        this.m_subscriptionLock.notifyAll();
      } 
    }
    
    protected void onException() {
      synchronized (this.m_subscriptionLock) {
        Iterator subscriptions = this.m_subscriptions.keySet().iterator();
        while (subscriptions.hasNext()) {
          Subscription subscription = (Subscription)subscriptions.next();
          this.m_subscriptions.put(subscription, null);
        } 
      } 
    }
    
    protected abstract ListenerSession createListenerSession(Connection param1Connection, Subscription param1Subscription) throws Exception;
    
    protected class ListenerSession extends JMSConnector.ConnectorSession {
      protected MessageConsumer m_consumer;
      
      protected Subscription m_subscription;
      
      private final JMSConnector.AsyncConnection this$1;
      
      ListenerSession(JMSConnector.AsyncConnection this$1, Session session, MessageConsumer consumer, Subscription subscription) throws Exception {
        super(this$1.this$0, session);
        this.this$1 = this$1;
        this.m_subscription = subscription;
        this.m_consumer = consumer;
        Destination destination = subscription.m_endpoint.getDestination(this.m_session);
        this.m_consumer.setMessageListener(subscription.m_listener);
      }
      
      void cleanup() {
        try {
          this.m_consumer.close();
        } catch (Exception ignore) {}
        try {
          this.m_session.close();
        } catch (Exception ignore) {}
      }
    }
  }
  
  private abstract class ConnectorSession {
    Session m_session;
    
    private final JMSConnector this$0;
    
    ConnectorSession(JMSConnector this$0, Session session) throws JMSException {
      this.this$0 = this$0;
      this.m_session = session;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\JMSConnector.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */