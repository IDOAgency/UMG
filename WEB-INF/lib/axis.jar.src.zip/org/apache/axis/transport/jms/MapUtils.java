/*     */ package org.apache.axis.transport.jms;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapUtils
/*     */ {
/*     */   public static int removeIntProperty(Map properties, String key, int defaultValue) {
/*  40 */     int value = defaultValue;
/*  41 */     if (properties != null && properties.containsKey(key)) {
/*     */       
/*  43 */       try { value = ((Integer)properties.remove(key)).intValue(); } catch (Exception ignore) {}
/*     */     }
/*  45 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long removeLongProperty(Map properties, String key, long defaultValue) {
/*  58 */     long value = defaultValue;
/*  59 */     if (properties != null && properties.containsKey(key)) {
/*     */       
/*  61 */       try { value = ((Long)properties.remove(key)).longValue(); } catch (Exception ignore) {}
/*     */     }
/*  63 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String removeStringProperty(Map properties, String key, String defaultValue) {
/*  76 */     String value = defaultValue;
/*  77 */     if (properties != null && properties.containsKey(key)) {
/*     */       
/*  79 */       try { value = (String)properties.remove(key); } catch (Exception ignore) {}
/*     */     }
/*  81 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean removeBooleanProperty(Map properties, String key, boolean defaultValue) {
/*  94 */     boolean value = defaultValue;
/*  95 */     if (properties != null && properties.containsKey(key)) {
/*     */       
/*  97 */       try { value = ((Boolean)properties.remove(key)).booleanValue(); } catch (Exception ignore) {}
/*     */     }
/*  99 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object removeObjectProperty(Map properties, String key, Object defaultValue) {
/* 112 */     Object value = defaultValue;
/* 113 */     if (properties != null && properties.containsKey(key))
/*     */     {
/* 115 */       value = properties.remove(key);
/*     */     }
/* 117 */     return value;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\MapUtils.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */