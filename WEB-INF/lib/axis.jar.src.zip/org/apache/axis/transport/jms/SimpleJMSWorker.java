package org.apache.axis.transport.jms;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import javax.jms.BytesMessage;
import javax.jms.Destination;
import org.apache.axis.AxisFault;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.server.AxisServer;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class SimpleJMSWorker implements Runnable {
  protected static Log log = LogFactory.getLog(SimpleJMSWorker.class.getName());
  
  SimpleJMSListener listener;
  
  BytesMessage message;
  
  public SimpleJMSWorker(SimpleJMSListener listener, BytesMessage message) {
    this.listener = listener;
    this.message = message;
  }
  
  public void run() {
    InputStream in = null;
    try {
      byte[] buffer = new byte[8192];
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      int bytesRead = this.message.readBytes(buffer);
      for (; bytesRead != -1; bytesRead = this.message.readBytes(buffer))
        out.write(buffer, 0, bytesRead); 
      in = new ByteArrayInputStream(out.toByteArray());
    } catch (Exception e) {
      log.error(Messages.getMessage("exception00"), e);
      e.printStackTrace();
      return;
    } 
    AxisServer server = SimpleJMSListener.getAxisServer();
    String contentType = null;
    try {
      contentType = this.message.getStringProperty("contentType");
    } catch (Exception e) {
      e.printStackTrace();
    } 
    Message msg = null;
    if (contentType != null && !contentType.trim().equals("")) {
      msg = new Message(in, true, contentType, null);
    } else {
      msg = new Message(in);
    } 
    MessageContext msgContext = new MessageContext(server);
    msgContext.setRequestMessage(msg);
    try {
      server.invoke(msgContext);
      msg = msgContext.getResponseMessage();
    } catch (AxisFault af) {
      msg = new Message(af);
      msg.setMessageContext(msgContext);
    } catch (Exception e) {
      msg = new Message(new AxisFault(e.toString()));
      msg.setMessageContext(msgContext);
    } 
    try {
      Destination destination = this.message.getJMSReplyTo();
      if (destination == null)
        return; 
      JMSEndpoint replyTo = this.listener.getConnector().createEndpoint(destination);
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      msg.writeTo(out);
      replyTo.send(out.toByteArray());
    } catch (Exception e) {
      e.printStackTrace();
    } 
    if (msgContext.getProperty("quit.requested") != null)
      try {
        this.listener.shutdown();
      } catch (Exception e) {} 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\SimpleJMSWorker.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */