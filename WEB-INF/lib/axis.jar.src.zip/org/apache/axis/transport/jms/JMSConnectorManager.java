package org.apache.axis.transport.jms;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import org.apache.axis.AxisFault;
import org.apache.axis.components.jms.JMSVendorAdapter;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class JMSConnectorManager {
  protected static Log log = LogFactory.getLog(JMSConnectorManager.class.getName());
  
  private static JMSConnectorManager s_instance = new JMSConnectorManager();
  
  private static HashMap vendorConnectorPools = new HashMap();
  
  private int DEFAULT_WAIT_FOR_SHUTDOWN = 90000;
  
  public static JMSConnectorManager getInstance() { return s_instance; }
  
  public ShareableObjectPool getVendorPool(String vendorId) { return (ShareableObjectPool)vendorConnectorPools.get(vendorId); }
  
  public JMSConnector getConnector(HashMap connectorProperties, HashMap connectionFactoryProperties, String username, String password, JMSVendorAdapter vendorAdapter) throws AxisFault {
    JMSConnector connector = null;
    try {
      ShareableObjectPool vendorConnectors = getVendorPool(vendorAdapter.getVendorId());
      if (vendorConnectors == null)
        synchronized (vendorConnectorPools) {
          vendorConnectors = getVendorPool(vendorAdapter.getVendorId());
          if (vendorConnectors == null) {
            vendorConnectors = new ShareableObjectPool(this);
            vendorConnectorPools.put(vendorAdapter.getVendorId(), vendorConnectors);
          } 
        }  
      synchronized (vendorConnectors) {
        try {
          connector = JMSConnectorFactory.matchConnector(vendorConnectors.getElements(), connectorProperties, connectionFactoryProperties, username, password, vendorAdapter);
        } catch (Exception e) {}
        if (connector == null) {
          connector = JMSConnectorFactory.createClientConnector(connectorProperties, connectionFactoryProperties, username, password, vendorAdapter);
          connector.start();
        } 
      } 
    } catch (Exception e) {
      log.error(Messages.getMessage("cannotConnectError"), e);
      if (e instanceof AxisFault)
        throw (AxisFault)e; 
      throw new AxisFault("cannotConnect", e);
    } 
    return connector;
  }
  
  void closeAllConnectors() {
    if (log.isDebugEnabled())
      log.debug("Enter: JMSConnectorManager::closeAllConnectors"); 
    synchronized (vendorConnectorPools) {
      Iterator iter = vendorConnectorPools.values().iterator();
      while (iter.hasNext()) {
        ShareableObjectPool pool = (ShareableObjectPool)iter.next();
        synchronized (pool) {
          Iterator connectors = pool.getElements().iterator();
          while (connectors.hasNext()) {
            JMSConnector conn = (JMSConnector)connectors.next();
            try {
              reserve(conn);
              closeConnector(conn);
            } catch (Exception e) {}
          } 
        } 
      } 
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: JMSConnectorManager::closeAllConnectors"); 
  }
  
  void closeMatchingJMSConnectors(HashMap connectorProps, HashMap cfProps, String username, String password, JMSVendorAdapter vendorAdapter) {
    if (log.isDebugEnabled())
      log.debug("Enter: JMSConnectorManager::closeMatchingJMSConnectors"); 
    try {
      String vendorId = vendorAdapter.getVendorId();
      ShareableObjectPool vendorConnectors = null;
      synchronized (vendorConnectorPools) {
        vendorConnectors = getVendorPool(vendorId);
      } 
      if (vendorConnectors == null)
        return; 
      synchronized (vendorConnectors) {
        JMSConnector connector = null;
        while (vendorConnectors.size() > 0 && (connector = JMSConnectorFactory.matchConnector(vendorConnectors.getElements(), connectorProps, cfProps, username, password, vendorAdapter)) != null)
          closeConnector(connector); 
      } 
    } catch (Exception e) {
      log.warn(Messages.getMessage("failedJMSConnectorShutdown"), e);
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: JMSConnectorManager::closeMatchingJMSConnectors"); 
  }
  
  private void closeConnector(JMSConnector conn) {
    conn.stop();
    conn.shutdown();
  }
  
  public void addConnectorToPool(JMSConnector conn) {
    if (log.isDebugEnabled())
      log.debug("Enter: JMSConnectorManager::addConnectorToPool"); 
    ShareableObjectPool vendorConnectors = null;
    synchronized (vendorConnectorPools) {
      String vendorId = conn.getVendorAdapter().getVendorId();
      vendorConnectors = getVendorPool(vendorId);
      if (vendorConnectors == null) {
        vendorConnectors = new ShareableObjectPool(this);
        vendorConnectorPools.put(vendorId, vendorConnectors);
      } 
    } 
    synchronized (vendorConnectors) {
      vendorConnectors.addObject(conn);
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: JMSConnectorManager::addConnectorToPool"); 
  }
  
  public void removeConnectorFromPool(JMSConnector conn) {
    if (log.isDebugEnabled())
      log.debug("Enter: JMSConnectorManager::removeConnectorFromPool"); 
    ShareableObjectPool vendorConnectors = null;
    synchronized (vendorConnectorPools) {
      vendorConnectors = getVendorPool(conn.getVendorAdapter().getVendorId());
    } 
    if (vendorConnectors == null)
      return; 
    synchronized (vendorConnectors) {
      vendorConnectors.release(conn);
      vendorConnectors.removeObject(conn);
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: JMSConnectorManager::removeConnectorFromPool"); 
  }
  
  public void reserve(JMSConnector connector) {
    ShareableObjectPool pool = null;
    synchronized (vendorConnectorPools) {
      pool = getVendorPool(connector.getVendorAdapter().getVendorId());
    } 
    if (pool != null)
      pool.reserve(connector); 
  }
  
  public void release(JMSConnector connector) {
    ShareableObjectPool pool = null;
    synchronized (vendorConnectorPools) {
      pool = getVendorPool(connector.getVendorAdapter().getVendorId());
    } 
    if (pool != null)
      pool.release(connector); 
  }
  
  public class ShareableObjectPool {
    private HashMap m_elements;
    
    private HashMap m_expiring;
    
    private int m_numElements;
    
    private final JMSConnectorManager this$0;
    
    public ShareableObjectPool(JMSConnectorManager this$0) {
      this.this$0 = this$0;
      this.m_numElements = 0;
      this.m_elements = new HashMap();
      this.m_expiring = new HashMap();
    }
    
    public void addObject(Object obj) {
      ReferenceCountedObject ref = new ReferenceCountedObject(this, obj);
      synchronized (this.m_elements) {
        if (!this.m_elements.containsKey(obj) && !this.m_expiring.containsKey(obj))
          this.m_elements.put(obj, ref); 
      } 
    }
    
    public void removeObject(Object obj, long waitTime) {
      ReferenceCountedObject ref = null;
      synchronized (this.m_elements) {
        ref = (ReferenceCountedObject)this.m_elements.get(obj);
        if (ref == null)
          return; 
        this.m_elements.remove(obj);
        if (ref.count() == 0)
          return; 
        this.m_expiring.put(obj, ref);
      } 
      long expiration = System.currentTimeMillis() + waitTime;
      while (ref.count() > 0) {
        try {
          Thread.sleep(5000L);
        } catch (InterruptedException e) {}
        if (System.currentTimeMillis() > expiration)
          break; 
      } 
      this.m_expiring.remove(obj);
    }
    
    public void removeObject(Object obj) { removeObject(obj, this.this$0.DEFAULT_WAIT_FOR_SHUTDOWN); }
    
    public void reserve(Object obj) {
      synchronized (this.m_elements) {
        if (this.m_expiring.containsKey(obj))
          throw new Exception("resourceUnavailable"); 
        ReferenceCountedObject ref = (ReferenceCountedObject)this.m_elements.get(obj);
        ref.increment();
      } 
    }
    
    public void release(Object obj) {
      synchronized (this.m_elements) {
        ReferenceCountedObject ref = (ReferenceCountedObject)this.m_elements.get(obj);
        ref.decrement();
      } 
    }
    
    public Set getElements() { return this.m_elements.keySet(); }
    
    public int size() { return this.m_elements.size(); }
    
    public class ReferenceCountedObject {
      private Object m_object;
      
      private int m_refCount;
      
      private final JMSConnectorManager.ShareableObjectPool this$1;
      
      public ReferenceCountedObject(JMSConnectorManager.ShareableObjectPool this$1, Object obj) {
        this.this$1 = this$1;
        this.m_object = obj;
        this.m_refCount = 0;
      }
      
      public void increment() { this.m_refCount++; }
      
      public void decrement() {
        if (this.m_refCount > 0)
          this.m_refCount--; 
      }
      
      public int count() { return this.m_refCount; }
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\JMSConnectorManager.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */