package org.apache.axis.transport.jms;

import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import org.apache.axis.client.Call;

public class Handler extends URLStreamHandler {
  static  {
    Call.setTransportForProtocol("jms", JMSTransport.class);
  }
  
  protected String toExternalForm(URL url) {
    String destination = url.getPath().substring(1);
    String query = url.getQuery();
    StringBuffer jmsurl = new StringBuffer("jms:/");
    jmsurl.append(destination).append("?").append(query);
    return jmsurl.toString();
  }
  
  protected URLConnection openConnection(URL url) { return new JMSURLConnection(url); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\Handler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */