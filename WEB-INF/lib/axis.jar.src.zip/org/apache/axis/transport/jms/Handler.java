/*    */ package org.apache.axis.transport.jms;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import java.net.URLStreamHandler;
/*    */ import org.apache.axis.client.Call;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Handler
/*    */   extends URLStreamHandler
/*    */ {
/*    */   static  {
/* 32 */     Call.setTransportForProtocol("jms", JMSTransport.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String toExternalForm(URL url) {
/* 40 */     String destination = url.getPath().substring(1);
/* 41 */     String query = url.getQuery();
/*    */     
/* 43 */     StringBuffer jmsurl = new StringBuffer("jms:/");
/* 44 */     jmsurl.append(destination).append("?").append(query);
/*    */     
/* 46 */     return jmsurl.toString();
/*    */   }
/*    */ 
/*    */   
/* 50 */   protected URLConnection openConnection(URL url) { return new JMSURLConnection(url); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\Handler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */