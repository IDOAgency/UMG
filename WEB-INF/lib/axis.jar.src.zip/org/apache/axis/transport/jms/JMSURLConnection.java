package org.apache.axis.transport.jms;

import java.net.URL;
import java.net.URLConnection;

public class JMSURLConnection extends URLConnection {
  public JMSURLConnection(URL url) { super(url); }
  
  public void connect() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\JMSURLConnection.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */