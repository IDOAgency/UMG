package org.apache.axis.transport.jms;

import java.util.HashMap;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TemporaryTopic;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import org.apache.axis.components.jms.JMSVendorAdapter;

public class TopicConnector extends JMSConnector {
  public TopicConnector(TopicConnectionFactory factory, int numRetries, int numSessions, long connectRetryInterval, long interactRetryInterval, long timeoutTime, boolean allowReceive, String clientID, String username, String password, JMSVendorAdapter adapter, JMSURLHelper jmsurl) throws JMSException { super(factory, numRetries, numSessions, connectRetryInterval, interactRetryInterval, timeoutTime, allowReceive, clientID, username, password, adapter, jmsurl); }
  
  protected Connection internalConnect(ConnectionFactory connectionFactory, String username, String password) throws JMSException {
    TopicConnectionFactory tcf = (TopicConnectionFactory)connectionFactory;
    if (username == null)
      return tcf.createTopicConnection(); 
    return tcf.createTopicConnection(username, password);
  }
  
  protected JMSConnector.SyncConnection createSyncConnection(ConnectionFactory factory, Connection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException { return new TopicSyncConnection(this, (TopicConnectionFactory)factory, (TopicConnection)connection, numSessions, threadName, clientID, username, password); }
  
  protected JMSConnector.AsyncConnection createAsyncConnection(ConnectionFactory factory, Connection connection, String threadName, String clientID, String username, String password) throws JMSException { return new TopicAsyncConnection(this, (TopicConnectionFactory)factory, (TopicConnection)connection, threadName, clientID, username, password); }
  
  public JMSEndpoint createEndpoint(String destination) { return new TopicEndpoint(this, destination); }
  
  public JMSEndpoint createEndpoint(Destination destination) throws JMSException {
    if (!(destination instanceof Topic))
      throw new IllegalArgumentException("The input be a topic for this connector"); 
    return new TopicDestinationEndpoint(this, (Topic)destination);
  }
  
  private TopicSession createTopicSession(TopicConnection connection, int ackMode) throws JMSException { return connection.createTopicSession(false, ackMode); }
  
  private Topic createTopic(TopicSession session, String subject) throws Exception { return this.m_adapter.getTopic(session, subject); }
  
  private TopicSubscriber createSubscriber(TopicSession session, TopicSubscription subscription) throws Exception {
    if (subscription.isDurable())
      return createDurableSubscriber(session, (Topic)subscription.m_endpoint.getDestination(session), subscription.m_subscriptionName, subscription.m_messageSelector, subscription.m_noLocal); 
    return createSubscriber(session, (Topic)subscription.m_endpoint.getDestination(session), subscription.m_messageSelector, subscription.m_noLocal);
  }
  
  private TopicSubscriber createDurableSubscriber(TopicSession session, Topic topic, String subscriptionName, String messageSelector, boolean noLocal) throws JMSException { return session.createDurableSubscriber(topic, subscriptionName, messageSelector, noLocal); }
  
  private TopicSubscriber createSubscriber(TopicSession session, Topic topic, String messageSelector, boolean noLocal) throws JMSException { return session.createSubscriber(topic, messageSelector, noLocal); }
  
  private final class TopicAsyncConnection extends JMSConnector.AsyncConnection {
    private final TopicConnector this$0;
    
    TopicAsyncConnection(TopicConnector this$0, TopicConnectionFactory connectionFactory, TopicConnection connection, String threadName, String clientID, String username, String password) throws JMSException {
      super(this$0, connectionFactory, connection, threadName, clientID, username, password);
      this.this$0 = this$0;
    }
    
    protected JMSConnector.AsyncConnection.ListenerSession createListenerSession(Connection connection, Subscription subscription) throws Exception {
      TopicSession session = this.this$0.createTopicSession((TopicConnection)connection, subscription.m_ackMode);
      TopicSubscriber subscriber = this.this$0.createSubscriber(session, (TopicConnector.TopicSubscription)subscription);
      return new TopicListenerSession(this, session, subscriber, (TopicConnector.TopicSubscription)subscription);
    }
    
    private final class TopicListenerSession extends JMSConnector.AsyncConnection.ListenerSession {
      private final TopicConnector.TopicAsyncConnection this$1;
      
      TopicListenerSession(TopicConnector.TopicAsyncConnection this$1, TopicSession session, TopicSubscriber subscriber, TopicConnector.TopicSubscription subscription) throws Exception {
        super(this$1, session, subscriber, subscription);
        this.this$1 = this$1;
      }
      
      void cleanup() {
        try {
          this.m_consumer.close();
        } catch (Exception ignore) {}
        try {
          TopicConnector.TopicSubscription sub = (TopicConnector.TopicSubscription)this.m_subscription;
          if (sub.isDurable() && sub.m_unsubscribe)
            ((TopicSession)this.m_session).unsubscribe(sub.m_subscriptionName); 
        } catch (Exception ignore) {}
        try {
          this.m_session.close();
        } catch (Exception ignore) {}
      }
    }
  }
  
  private final class TopicSyncConnection extends JMSConnector.SyncConnection {
    private final TopicConnector this$0;
    
    TopicSyncConnection(TopicConnector this$0, TopicConnectionFactory connectionFactory, TopicConnection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException {
      super(this$0, connectionFactory, connection, numSessions, threadName, clientID, username, password);
      this.this$0 = this$0;
    }
    
    protected JMSConnector.SyncConnection.SendSession createSendSession(Connection connection) throws JMSException {
      TopicSession session = this.this$0.createTopicSession((TopicConnection)connection, 3);
      TopicPublisher publisher = session.createPublisher(null);
      return new TopicSendSession(this, session, publisher);
    }
    
    private final class TopicSendSession extends JMSConnector.SyncConnection.SendSession {
      private final TopicConnector.TopicSyncConnection this$1;
      
      TopicSendSession(TopicConnector.TopicSyncConnection this$1, TopicSession session, TopicPublisher publisher) throws JMSException {
        super(this$1, session, publisher);
        this.this$1 = this$1;
      }
      
      protected MessageConsumer createConsumer(Destination destination) throws JMSException { return this.this$1.this$0.createSubscriber((TopicSession)this.m_session, (Topic)destination, null, false); }
      
      protected void deleteTemporaryDestination(Destination destination) throws JMSException { ((TemporaryTopic)destination).delete(); }
      
      protected Destination createTemporaryDestination() throws JMSException { return ((TopicSession)this.m_session).createTemporaryTopic(); }
      
      protected void send(Destination destination, Message message, int deliveryMode, int priority, long timeToLive) throws JMSException { ((TopicPublisher)this.m_producer).publish((Topic)destination, message, deliveryMode, priority, timeToLive); }
    }
  }
  
  private class TopicEndpoint extends JMSEndpoint {
    String m_topicName;
    
    private final TopicConnector this$0;
    
    TopicEndpoint(TopicConnector this$0, String topicName) {
      super(this$0);
      this.this$0 = this$0;
      this.m_topicName = topicName;
    }
    
    Destination getDestination(Session session) { return this.this$0.createTopic((TopicSession)session, this.m_topicName); }
    
    protected Subscription createSubscription(MessageListener listener, HashMap properties) { return new TopicConnector.TopicSubscription(this.this$0, listener, this, properties); }
    
    public String toString() {
      StringBuffer buffer = new StringBuffer("TopicEndpoint:");
      buffer.append(this.m_topicName);
      return buffer.toString();
    }
    
    public boolean equals(Object object) {
      if (!super.equals(object))
        return false; 
      if (!(object instanceof TopicEndpoint))
        return false; 
      return this.m_topicName.equals(((TopicEndpoint)object).m_topicName);
    }
  }
  
  private final class TopicSubscription extends Subscription {
    String m_subscriptionName;
    
    boolean m_unsubscribe;
    
    boolean m_noLocal;
    
    private final TopicConnector this$0;
    
    TopicSubscription(TopicConnector this$0, MessageListener listener, JMSEndpoint endpoint, HashMap properties) {
      super(listener, endpoint, properties);
      this.this$0 = this$0;
      this.m_subscriptionName = MapUtils.removeStringProperty(properties, "transport.jms.subscriptionName", null);
      this.m_unsubscribe = MapUtils.removeBooleanProperty(properties, "transport.jms.unsubscribe", false);
      this.m_noLocal = MapUtils.removeBooleanProperty(properties, "transport.jms.noLocal", false);
    }
    
    boolean isDurable() { return (this.m_subscriptionName != null); }
    
    public boolean equals(Object obj) {
      if (!super.equals(obj))
        return false; 
      if (!(obj instanceof TopicSubscription))
        return false; 
      TopicSubscription other = (TopicSubscription)obj;
      if (other.m_unsubscribe != this.m_unsubscribe || other.m_noLocal != this.m_noLocal)
        return false; 
      if (isDurable())
        return (other.isDurable() && other.m_subscriptionName.equals(this.m_subscriptionName)); 
      if (other.isDurable())
        return false; 
      return true;
    }
    
    public String toString() {
      StringBuffer buffer = new StringBuffer(super.toString());
      buffer.append(":").append(this.m_noLocal).append(":").append(this.m_unsubscribe);
      if (isDurable()) {
        buffer.append(":");
        buffer.append(this.m_subscriptionName);
      } 
      return buffer.toString();
    }
  }
  
  private final class TopicDestinationEndpoint extends TopicEndpoint {
    Topic m_topic;
    
    private final TopicConnector this$0;
    
    TopicDestinationEndpoint(TopicConnector this$0, Topic topic) throws JMSException {
      super(this$0, topic.getTopicName());
      this.this$0 = this$0;
      this.m_topic = topic;
    }
    
    Destination getDestination(Session session) { return this.m_topic; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\TopicConnector.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */