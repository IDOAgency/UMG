/*     */ package org.apache.axis.transport.jms;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageConsumer;
/*     */ import javax.jms.MessageListener;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.TemporaryTopic;
/*     */ import javax.jms.Topic;
/*     */ import javax.jms.TopicConnection;
/*     */ import javax.jms.TopicConnectionFactory;
/*     */ import javax.jms.TopicPublisher;
/*     */ import javax.jms.TopicSession;
/*     */ import javax.jms.TopicSubscriber;
/*     */ import org.apache.axis.components.jms.JMSVendorAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopicConnector
/*     */   extends JMSConnector
/*     */ {
/*  62 */   public TopicConnector(TopicConnectionFactory factory, int numRetries, int numSessions, long connectRetryInterval, long interactRetryInterval, long timeoutTime, boolean allowReceive, String clientID, String username, String password, JMSVendorAdapter adapter, JMSURLHelper jmsurl) throws JMSException { super(factory, numRetries, numSessions, connectRetryInterval, interactRetryInterval, timeoutTime, allowReceive, clientID, username, password, adapter, jmsurl); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection internalConnect(ConnectionFactory connectionFactory, String username, String password) throws JMSException {
/*  71 */     TopicConnectionFactory tcf = (TopicConnectionFactory)connectionFactory;
/*  72 */     if (username == null) {
/*  73 */       return tcf.createTopicConnection();
/*     */     }
/*  75 */     return tcf.createTopicConnection(username, password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   protected JMSConnector.SyncConnection createSyncConnection(ConnectionFactory factory, Connection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException { return new TopicSyncConnection(this, (TopicConnectionFactory)factory, (TopicConnection)connection, numSessions, threadName, clientID, username, password); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   protected JMSConnector.AsyncConnection createAsyncConnection(ConnectionFactory factory, Connection connection, String threadName, String clientID, String username, String password) throws JMSException { return new TopicAsyncConnection(this, (TopicConnectionFactory)factory, (TopicConnection)connection, threadName, clientID, username, password); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public JMSEndpoint createEndpoint(String destination) { return new TopicEndpoint(this, destination); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JMSEndpoint createEndpoint(Destination destination) throws JMSException {
/* 121 */     if (!(destination instanceof Topic))
/* 122 */       throw new IllegalArgumentException("The input be a topic for this connector"); 
/* 123 */     return new TopicDestinationEndpoint(this, (Topic)destination);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   private TopicSession createTopicSession(TopicConnection connection, int ackMode) throws JMSException { return connection.createTopicSession(false, ackMode); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   private Topic createTopic(TopicSession session, String subject) throws Exception { return this.m_adapter.getTopic(session, subject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TopicSubscriber createSubscriber(TopicSession session, TopicSubscription subscription) throws Exception {
/* 143 */     if (subscription.isDurable()) {
/* 144 */       return createDurableSubscriber(session, (Topic)subscription.m_endpoint.getDestination(session), subscription.m_subscriptionName, subscription.m_messageSelector, subscription.m_noLocal);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     return createSubscriber(session, (Topic)subscription.m_endpoint.getDestination(session), subscription.m_messageSelector, subscription.m_noLocal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   private TopicSubscriber createDurableSubscriber(TopicSession session, Topic topic, String subscriptionName, String messageSelector, boolean noLocal) throws JMSException { return session.createDurableSubscriber(topic, subscriptionName, messageSelector, noLocal); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   private TopicSubscriber createSubscriber(TopicSession session, Topic topic, String messageSelector, boolean noLocal) throws JMSException { return session.createSubscriber(topic, messageSelector, noLocal); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class TopicAsyncConnection
/*     */     extends JMSConnector.AsyncConnection
/*     */   {
/*     */     private final TopicConnector this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TopicAsyncConnection(TopicConnector this$0, TopicConnectionFactory connectionFactory, TopicConnection connection, String threadName, String clientID, String username, String password) throws JMSException {
/* 191 */       super(this$0, connectionFactory, connection, threadName, clientID, username, password);
/*     */       this.this$0 = this$0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected JMSConnector.AsyncConnection.ListenerSession createListenerSession(Connection connection, Subscription subscription) throws Exception {
/* 199 */       TopicSession session = this.this$0.createTopicSession((TopicConnection)connection, subscription.m_ackMode);
/*     */       
/* 201 */       TopicSubscriber subscriber = this.this$0.createSubscriber(session, (TopicConnector.TopicSubscription)subscription);
/*     */       
/* 203 */       return new TopicListenerSession(this, session, subscriber, (TopicConnector.TopicSubscription)subscription);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final class TopicListenerSession
/*     */       extends JMSConnector.AsyncConnection.ListenerSession
/*     */     {
/*     */       private final TopicConnector.TopicAsyncConnection this$1;
/*     */ 
/*     */       
/*     */       TopicListenerSession(TopicConnector.TopicAsyncConnection this$1, TopicSession session, TopicSubscriber subscriber, TopicConnector.TopicSubscription subscription) throws Exception {
/* 215 */         super(this$1, session, subscriber, subscription);
/*     */         this.this$1 = this$1;
/*     */       }
/*     */       void cleanup() {
/*     */         
/* 220 */         try { this.m_consumer.close(); } catch (Exception ignore) {}
/*     */         
/*     */         try {
/* 223 */           TopicConnector.TopicSubscription sub = (TopicConnector.TopicSubscription)this.m_subscription;
/* 224 */           if (sub.isDurable() && sub.m_unsubscribe)
/*     */           {
/* 226 */             ((TopicSession)this.m_session).unsubscribe(sub.m_subscriptionName);
/*     */           }
/*     */         }
/* 229 */         catch (Exception ignore) {} 
/* 230 */         try { this.m_session.close(); } catch (Exception ignore) {}
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class TopicSyncConnection
/*     */     extends JMSConnector.SyncConnection
/*     */   {
/*     */     private final TopicConnector this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TopicSyncConnection(TopicConnector this$0, TopicConnectionFactory connectionFactory, TopicConnection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException {
/* 248 */       super(this$0, connectionFactory, connection, numSessions, threadName, clientID, username, password);
/*     */       this.this$0 = this$0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected JMSConnector.SyncConnection.SendSession createSendSession(Connection connection) throws JMSException {
/* 255 */       TopicSession session = this.this$0.createTopicSession((TopicConnection)connection, 3);
/*     */       
/* 257 */       TopicPublisher publisher = session.createPublisher(null);
/* 258 */       return new TopicSendSession(this, session, publisher);
/*     */     }
/*     */     
/*     */     private final class TopicSendSession
/*     */       extends JMSConnector.SyncConnection.SendSession
/*     */     {
/*     */       private final TopicConnector.TopicSyncConnection this$1;
/*     */       
/*     */       TopicSendSession(TopicConnector.TopicSyncConnection this$1, TopicSession session, TopicPublisher publisher) throws JMSException {
/* 267 */         super(this$1, session, publisher);
/*     */         this.this$1 = this$1;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 274 */       protected MessageConsumer createConsumer(Destination destination) throws JMSException { return this.this$1.this$0.createSubscriber((TopicSession)this.m_session, (Topic)destination, null, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 281 */       protected void deleteTemporaryDestination(Destination destination) throws JMSException { ((TemporaryTopic)destination).delete(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 288 */       protected Destination createTemporaryDestination() throws JMSException { return ((TopicSession)this.m_session).createTemporaryTopic(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 295 */       protected void send(Destination destination, Message message, int deliveryMode, int priority, long timeToLive) throws JMSException { ((TopicPublisher)this.m_producer).publish((Topic)destination, message, deliveryMode, priority, timeToLive); }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class TopicEndpoint
/*     */     extends JMSEndpoint
/*     */   {
/*     */     String m_topicName;
/*     */ 
/*     */     
/*     */     private final TopicConnector this$0;
/*     */ 
/*     */     
/*     */     TopicEndpoint(TopicConnector this$0, String topicName) {
/* 311 */       super(this$0); this.this$0 = this$0;
/* 312 */       this.m_topicName = topicName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     Destination getDestination(Session session) { return this.this$0.createTopic((TopicSession)session, this.m_topicName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 324 */     protected Subscription createSubscription(MessageListener listener, HashMap properties) { return new TopicConnector.TopicSubscription(this.this$0, listener, this, properties); }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 329 */       StringBuffer buffer = new StringBuffer("TopicEndpoint:");
/* 330 */       buffer.append(this.m_topicName);
/* 331 */       return buffer.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object object) {
/* 336 */       if (!super.equals(object)) {
/* 337 */         return false;
/*     */       }
/* 339 */       if (!(object instanceof TopicEndpoint)) {
/* 340 */         return false;
/*     */       }
/* 342 */       return this.m_topicName.equals(((TopicEndpoint)object).m_topicName);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class TopicSubscription
/*     */     extends Subscription
/*     */   {
/*     */     String m_subscriptionName;
/*     */     boolean m_unsubscribe;
/*     */     boolean m_noLocal;
/*     */     private final TopicConnector this$0;
/*     */     
/*     */     TopicSubscription(TopicConnector this$0, MessageListener listener, JMSEndpoint endpoint, HashMap properties) {
/* 356 */       super(listener, endpoint, properties); this.this$0 = this$0;
/* 357 */       this.m_subscriptionName = MapUtils.removeStringProperty(properties, "transport.jms.subscriptionName", null);
/*     */ 
/*     */       
/* 360 */       this.m_unsubscribe = MapUtils.removeBooleanProperty(properties, "transport.jms.unsubscribe", false);
/*     */ 
/*     */       
/* 363 */       this.m_noLocal = MapUtils.removeBooleanProperty(properties, "transport.jms.noLocal", false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 370 */     boolean isDurable() { return (this.m_subscriptionName != null); }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 375 */       if (!super.equals(obj))
/* 376 */         return false; 
/* 377 */       if (!(obj instanceof TopicSubscription)) {
/* 378 */         return false;
/*     */       }
/* 380 */       TopicSubscription other = (TopicSubscription)obj;
/* 381 */       if (other.m_unsubscribe != this.m_unsubscribe || other.m_noLocal != this.m_noLocal) {
/* 382 */         return false;
/*     */       }
/* 384 */       if (isDurable())
/*     */       {
/* 386 */         return (other.isDurable() && other.m_subscriptionName.equals(this.m_subscriptionName));
/*     */       }
/* 388 */       if (other.isDurable()) {
/* 389 */         return false;
/*     */       }
/* 391 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 396 */       StringBuffer buffer = new StringBuffer(super.toString());
/* 397 */       buffer.append(":").append(this.m_noLocal).append(":").append(this.m_unsubscribe);
/* 398 */       if (isDurable()) {
/*     */         
/* 400 */         buffer.append(":");
/* 401 */         buffer.append(this.m_subscriptionName);
/*     */       } 
/* 403 */       return buffer.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class TopicDestinationEndpoint
/*     */     extends TopicEndpoint
/*     */   {
/*     */     Topic m_topic;
/*     */     
/*     */     private final TopicConnector this$0;
/*     */     
/*     */     TopicDestinationEndpoint(TopicConnector this$0, Topic topic) throws JMSException {
/* 416 */       super(this$0, topic.getTopicName()); this.this$0 = this$0;
/* 417 */       this.m_topic = topic;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 422 */     Destination getDestination(Session session) { return this.m_topic; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\TopicConnector.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */