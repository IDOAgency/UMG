package org.apache.axis.transport.jms;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TemporaryQueue;
import org.apache.axis.components.jms.JMSVendorAdapter;

public class QueueConnector extends JMSConnector {
  public QueueConnector(ConnectionFactory factory, int numRetries, int numSessions, long connectRetryInterval, long interactRetryInterval, long timeoutTime, boolean allowReceive, String clientID, String username, String password, JMSVendorAdapter adapter, JMSURLHelper jmsurl) throws JMSException { super(factory, numRetries, numSessions, connectRetryInterval, interactRetryInterval, timeoutTime, allowReceive, clientID, username, password, adapter, jmsurl); }
  
  public JMSEndpoint createEndpoint(String destination) { return new QueueEndpoint(this, destination); }
  
  public JMSEndpoint createEndpoint(Destination destination) throws JMSException {
    if (!(destination instanceof Queue))
      throw new IllegalArgumentException("The input must be a queue for this connector"); 
    return new QueueDestinationEndpoint(this, (Queue)destination);
  }
  
  protected Connection internalConnect(ConnectionFactory connectionFactory, String username, String password) throws JMSException {
    QueueConnectionFactory qcf = (QueueConnectionFactory)connectionFactory;
    if (username == null)
      return qcf.createQueueConnection(); 
    return qcf.createQueueConnection(username, password);
  }
  
  protected JMSConnector.SyncConnection createSyncConnection(ConnectionFactory factory, Connection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException { return new QueueSyncConnection(this, (QueueConnectionFactory)factory, (QueueConnection)connection, numSessions, threadName, clientID, username, password); }
  
  private QueueSession createQueueSession(QueueConnection connection, int ackMode) throws JMSException { return connection.createQueueSession(false, ackMode); }
  
  private Queue createQueue(QueueSession session, String subject) throws Exception { return this.m_adapter.getQueue(session, subject); }
  
  private QueueReceiver createReceiver(QueueSession session, Queue queue, String messageSelector) throws JMSException { return session.createReceiver(queue, messageSelector); }
  
  private final class QueueSyncConnection extends JMSConnector.SyncConnection {
    private final QueueConnector this$0;
    
    QueueSyncConnection(QueueConnector this$0, QueueConnectionFactory connectionFactory, QueueConnection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException {
      super(this$0, connectionFactory, connection, numSessions, threadName, clientID, username, password);
      this.this$0 = this$0;
    }
    
    protected JMSConnector.SyncConnection.SendSession createSendSession(Connection connection) throws JMSException {
      QueueSession session = this.this$0.createQueueSession((QueueConnection)connection, 3);
      QueueSender sender = session.createSender(null);
      return new QueueSendSession(this, session, sender);
    }
    
    private final class QueueSendSession extends JMSConnector.SyncConnection.SendSession {
      private final QueueConnector.QueueSyncConnection this$1;
      
      QueueSendSession(QueueConnector.QueueSyncConnection this$1, QueueSession session, QueueSender sender) throws JMSException {
        super(this$1, session, sender);
        this.this$1 = this$1;
      }
      
      protected MessageConsumer createConsumer(Destination destination) throws JMSException { return this.this$1.this$0.createReceiver((QueueSession)this.m_session, (Queue)destination, null); }
      
      protected Destination createTemporaryDestination() throws JMSException { return ((QueueSession)this.m_session).createTemporaryQueue(); }
      
      protected void deleteTemporaryDestination(Destination destination) throws JMSException { ((TemporaryQueue)destination).delete(); }
      
      protected void send(Destination destination, Message message, int deliveryMode, int priority, long timeToLive) throws JMSException { ((QueueSender)this.m_producer).send((Queue)destination, message, deliveryMode, priority, timeToLive); }
    }
  }
  
  private class QueueEndpoint extends JMSEndpoint {
    String m_queueName;
    
    private final QueueConnector this$0;
    
    QueueEndpoint(QueueConnector this$0, String queueName) {
      super(this$0);
      this.this$0 = this$0;
      this.m_queueName = queueName;
    }
    
    Destination getDestination(Session session) { return this.this$0.createQueue((QueueSession)session, this.m_queueName); }
    
    public String toString() {
      StringBuffer buffer = new StringBuffer("QueueEndpoint:");
      buffer.append(this.m_queueName);
      return buffer.toString();
    }
    
    public boolean equals(Object object) {
      if (!super.equals(object))
        return false; 
      if (!(object instanceof QueueEndpoint))
        return false; 
      return this.m_queueName.equals(((QueueEndpoint)object).m_queueName);
    }
  }
  
  private final class QueueDestinationEndpoint extends QueueEndpoint {
    Queue m_queue;
    
    private final QueueConnector this$0;
    
    QueueDestinationEndpoint(QueueConnector this$0, Queue queue) throws JMSException {
      super(this$0, queue.getQueueName());
      this.this$0 = this$0;
      this.m_queue = queue;
    }
    
    Destination getDestination(Session session) { return this.m_queue; }
  }
  
  protected JMSConnector.AsyncConnection createAsyncConnection(ConnectionFactory factory, Connection connection, String threadName, String clientID, String username, String password) throws JMSException { return new QueueAsyncConnection(this, (QueueConnectionFactory)factory, (QueueConnection)connection, threadName, clientID, username, password); }
  
  private final class QueueAsyncConnection extends JMSConnector.AsyncConnection {
    private final QueueConnector this$0;
    
    QueueAsyncConnection(QueueConnector this$0, QueueConnectionFactory connectionFactory, QueueConnection connection, String threadName, String clientID, String username, String password) throws JMSException {
      super(this$0, connectionFactory, connection, threadName, clientID, username, password);
      this.this$0 = this$0;
    }
    
    protected JMSConnector.AsyncConnection.ListenerSession createListenerSession(Connection connection, Subscription subscription) throws Exception {
      QueueSession session = this.this$0.createQueueSession((QueueConnection)connection, subscription.m_ackMode);
      QueueReceiver receiver = this.this$0.createReceiver(session, (Queue)subscription.m_endpoint.getDestination(session), subscription.m_messageSelector);
      return new JMSConnector.AsyncConnection.ListenerSession(this, session, receiver, subscription);
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\QueueConnector.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */