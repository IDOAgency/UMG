/*     */ package org.apache.axis.transport.jms;
/*     */ 
/*     */ import javax.jms.Connection;
/*     */ import javax.jms.ConnectionFactory;
/*     */ import javax.jms.Destination;
/*     */ import javax.jms.JMSException;
/*     */ import javax.jms.Message;
/*     */ import javax.jms.MessageConsumer;
/*     */ import javax.jms.Queue;
/*     */ import javax.jms.QueueConnection;
/*     */ import javax.jms.QueueConnectionFactory;
/*     */ import javax.jms.QueueReceiver;
/*     */ import javax.jms.QueueSender;
/*     */ import javax.jms.QueueSession;
/*     */ import javax.jms.Session;
/*     */ import javax.jms.TemporaryQueue;
/*     */ import org.apache.axis.components.jms.JMSVendorAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QueueConnector
/*     */   extends JMSConnector
/*     */ {
/*  61 */   public QueueConnector(ConnectionFactory factory, int numRetries, int numSessions, long connectRetryInterval, long interactRetryInterval, long timeoutTime, boolean allowReceive, String clientID, String username, String password, JMSVendorAdapter adapter, JMSURLHelper jmsurl) throws JMSException { super(factory, numRetries, numSessions, connectRetryInterval, interactRetryInterval, timeoutTime, allowReceive, clientID, username, password, adapter, jmsurl); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public JMSEndpoint createEndpoint(String destination) { return new QueueEndpoint(this, destination); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JMSEndpoint createEndpoint(Destination destination) throws JMSException {
/*  81 */     if (!(destination instanceof Queue))
/*  82 */       throw new IllegalArgumentException("The input must be a queue for this connector"); 
/*  83 */     return new QueueDestinationEndpoint(this, (Queue)destination);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection internalConnect(ConnectionFactory connectionFactory, String username, String password) throws JMSException {
/*  91 */     QueueConnectionFactory qcf = (QueueConnectionFactory)connectionFactory;
/*  92 */     if (username == null) {
/*  93 */       return qcf.createQueueConnection();
/*     */     }
/*  95 */     return qcf.createQueueConnection(username, password);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   protected JMSConnector.SyncConnection createSyncConnection(ConnectionFactory factory, Connection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException { return new QueueSyncConnection(this, (QueueConnectionFactory)factory, (QueueConnection)connection, numSessions, threadName, clientID, username, password); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   private QueueSession createQueueSession(QueueConnection connection, int ackMode) throws JMSException { return connection.createQueueSession(false, ackMode); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   private Queue createQueue(QueueSession session, String subject) throws Exception { return this.m_adapter.getQueue(session, subject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   private QueueReceiver createReceiver(QueueSession session, Queue queue, String messageSelector) throws JMSException { return session.createReceiver(queue, messageSelector); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class QueueSyncConnection
/*     */     extends JMSConnector.SyncConnection
/*     */   {
/*     */     private final QueueConnector this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     QueueSyncConnection(QueueConnector this$0, QueueConnectionFactory connectionFactory, QueueConnection connection, int numSessions, String threadName, String clientID, String username, String password) throws JMSException {
/* 145 */       super(this$0, connectionFactory, connection, numSessions, threadName, clientID, username, password);
/*     */       this.this$0 = this$0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected JMSConnector.SyncConnection.SendSession createSendSession(Connection connection) throws JMSException {
/* 152 */       QueueSession session = this.this$0.createQueueSession((QueueConnection)connection, 3);
/*     */       
/* 154 */       QueueSender sender = session.createSender(null);
/* 155 */       return new QueueSendSession(this, session, sender);
/*     */     }
/*     */     
/*     */     private final class QueueSendSession
/*     */       extends JMSConnector.SyncConnection.SendSession
/*     */     {
/*     */       private final QueueConnector.QueueSyncConnection this$1;
/*     */       
/*     */       QueueSendSession(QueueConnector.QueueSyncConnection this$1, QueueSession session, QueueSender sender) throws JMSException {
/* 164 */         super(this$1, session, sender);
/*     */         this.this$1 = this$1;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 170 */       protected MessageConsumer createConsumer(Destination destination) throws JMSException { return this.this$1.this$0.createReceiver((QueueSession)this.m_session, (Queue)destination, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       protected Destination createTemporaryDestination() throws JMSException { return ((QueueSession)this.m_session).createTemporaryQueue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 183 */       protected void deleteTemporaryDestination(Destination destination) throws JMSException { ((TemporaryQueue)destination).delete(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       protected void send(Destination destination, Message message, int deliveryMode, int priority, long timeToLive) throws JMSException { ((QueueSender)this.m_producer).send((Queue)destination, message, deliveryMode, priority, timeToLive); }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class QueueEndpoint
/*     */     extends JMSEndpoint
/*     */   {
/*     */     String m_queueName;
/*     */     
/*     */     private final QueueConnector this$0;
/*     */ 
/*     */     
/*     */     QueueEndpoint(QueueConnector this$0, String queueName) {
/* 204 */       super(this$0); this.this$0 = this$0;
/* 205 */       this.m_queueName = queueName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     Destination getDestination(Session session) { return this.this$0.createQueue((QueueSession)session, this.m_queueName); }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 216 */       StringBuffer buffer = new StringBuffer("QueueEndpoint:");
/* 217 */       buffer.append(this.m_queueName);
/* 218 */       return buffer.toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object object) {
/* 223 */       if (!super.equals(object)) {
/* 224 */         return false;
/*     */       }
/* 226 */       if (!(object instanceof QueueEndpoint)) {
/* 227 */         return false;
/*     */       }
/* 229 */       return this.m_queueName.equals(((QueueEndpoint)object).m_queueName);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class QueueDestinationEndpoint
/*     */     extends QueueEndpoint
/*     */   {
/*     */     Queue m_queue;
/*     */     
/*     */     private final QueueConnector this$0;
/*     */     
/*     */     QueueDestinationEndpoint(QueueConnector this$0, Queue queue) throws JMSException {
/* 242 */       super(this$0, queue.getQueueName()); this.this$0 = this$0;
/* 243 */       this.m_queue = queue;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 248 */     Destination getDestination(Session session) { return this.m_queue; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   protected JMSConnector.AsyncConnection createAsyncConnection(ConnectionFactory factory, Connection connection, String threadName, String clientID, String username, String password) throws JMSException { return new QueueAsyncConnection(this, (QueueConnectionFactory)factory, (QueueConnection)connection, threadName, clientID, username, password); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class QueueAsyncConnection
/*     */     extends JMSConnector.AsyncConnection
/*     */   {
/*     */     private final QueueConnector this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     QueueAsyncConnection(QueueConnector this$0, QueueConnectionFactory connectionFactory, QueueConnection connection, String threadName, String clientID, String username, String password) throws JMSException {
/* 277 */       super(this$0, connectionFactory, connection, threadName, clientID, username, password);
/*     */       this.this$0 = this$0;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected JMSConnector.AsyncConnection.ListenerSession createListenerSession(Connection connection, Subscription subscription) throws Exception {
/* 284 */       QueueSession session = this.this$0.createQueueSession((QueueConnection)connection, subscription.m_ackMode);
/*     */       
/* 286 */       QueueReceiver receiver = this.this$0.createReceiver(session, (Queue)subscription.m_endpoint.getDestination(session), subscription.m_messageSelector);
/*     */ 
/*     */       
/* 289 */       return new JMSConnector.AsyncConnection.ListenerSession(this, session, receiver, subscription);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\jms\QueueConnector.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */