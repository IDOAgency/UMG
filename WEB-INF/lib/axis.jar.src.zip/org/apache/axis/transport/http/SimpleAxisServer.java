/*     */ package org.apache.axis.transport.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.net.BindException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.util.Map;
/*     */ import org.apache.axis.EngineConfiguration;
/*     */ import org.apache.axis.collections.LRUMap;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.components.threadpool.ThreadPool;
/*     */ import org.apache.axis.configuration.EngineConfigurationFactoryFinder;
/*     */ import org.apache.axis.management.ServiceAdmin;
/*     */ import org.apache.axis.server.AxisServer;
/*     */ import org.apache.axis.session.Session;
/*     */ import org.apache.axis.session.SimpleSession;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.axis.utils.NetworkUtils;
/*     */ import org.apache.axis.utils.Options;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleAxisServer
/*     */   implements Runnable
/*     */ {
/*  54 */   protected static Log log = LogFactory.getLog(SimpleAxisServer.class.getName());
/*     */ 
/*     */ 
/*     */   
/*     */   private Map sessions;
/*     */ 
/*     */ 
/*     */   
/*     */   private int maxSessions;
/*     */ 
/*     */   
/*     */   public static final int MAX_SESSIONS_DEFAULT = 100;
/*     */ 
/*     */   
/*     */   private static ThreadPool pool;
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static ThreadPool getPool() { return pool; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean doThreads = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean doSessions = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public SimpleAxisServer() { this(100); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public SimpleAxisServer(int maxPoolSize) { this(maxPoolSize, 100); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finalize() {
/*     */     stop();
/*     */     super.finalize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxSessions() { return this.maxSessions; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxSessions(int maxSessions) {
/*     */     this.maxSessions = maxSessions;
/*     */     ((LRUMap)this.sessions).setMaximumSize(maxSessions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSessionUsed() { return doSessions; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleAxisServer(int maxPoolSize, int maxSessions) {
/* 197 */     this.myConfig = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     this.stopped = false;
/*     */     this.maxSessions = maxSessions;
/*     */     this.sessions = new LRUMap(maxSessions);
/*     */     pool = new ThreadPool(maxPoolSize);
/*     */   } public void setDoThreads(boolean value) { doThreads = value; }
/*     */   public boolean getDoThreads() { return doThreads; }
/*     */   public EngineConfiguration getMyConfig() { return this.myConfig; }
/* 227 */   public void run() { log.info(Messages.getMessage("start01", "SimpleAxisServer", (new Integer(getServerSocket().getLocalPort())).toString(), getCurrentDirectory()));
/*     */ 
/*     */ 
/*     */     
/* 231 */     while (!this.stopped) {
/* 232 */       Socket socket = null;
/*     */       
/* 234 */       try { socket = this.serverSocket.accept(); }
/* 235 */       catch (InterruptedIOException iie) {  }
/* 236 */       catch (Exception e)
/* 237 */       { log.debug(Messages.getMessage("exception00"), e);
/*     */         break; }
/*     */       
/* 240 */       if (socket != null) {
/* 241 */         SimpleAxisWorker worker = new SimpleAxisWorker(this, socket);
/* 242 */         if (doThreads) {
/* 243 */           pool.addWorker(worker); continue;
/*     */         } 
/* 245 */         worker.run();
/*     */       } 
/*     */     } 
/*     */     
/* 249 */     log.info(Messages.getMessage("quit00", "SimpleAxisServer")); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMyConfig(EngineConfiguration myConfig) { this.myConfig = myConfig; }
/*     */ 
/*     */   
/* 257 */   private String getCurrentDirectory() { return System.getProperty("user.dir"); }
/*     */   protected Session createSession(String cooky) { SimpleSession simpleSession = null; if (this.sessions.containsKey(cooky)) {
/*     */       simpleSession = (Session)this.sessions.get(cooky);
/*     */     } else {
/*     */       simpleSession = new SimpleSession(); this.sessions.put(cooky, simpleSession);
/*     */     } 
/*     */     return simpleSession; }
/*     */   public static int sessionIndex = 0; private static AxisServer myAxisServer = null; private EngineConfiguration myConfig; private boolean stopped; private ServerSocket serverSocket; public AxisServer getAxisServer() { if (myAxisServer == null) {
/*     */       if (this.myConfig == null)
/*     */         this.myConfig = EngineConfigurationFactoryFinder.newFactory().getServerEngineConfig(); 
/*     */       myAxisServer = new AxisServer(this.myConfig);
/*     */       ServiceAdmin.setEngine(myAxisServer, NetworkUtils.getLocalHostname() + "@" + this.serverSocket.getLocalPort());
/*     */     } 
/* 270 */     return myAxisServer; } public ServerSocket getServerSocket() { return this.serverSocket; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   public void setServerSocket(ServerSocket serverSocket) { this.serverSocket = serverSocket; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(boolean daemon) {
/* 290 */     this.stopped = false;
/* 291 */     if (doThreads) {
/* 292 */       Thread thread = new Thread(this);
/* 293 */       thread.setDaemon(daemon);
/* 294 */       thread.start();
/*     */     } else {
/* 296 */       run();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 304 */   public void start() { start(false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 315 */     if (this.stopped) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 322 */     this.stopped = true;
/*     */     
/*     */     try {
/* 325 */       if (this.serverSocket != null) {
/* 326 */         this.serverSocket.close();
/*     */       }
/* 328 */     } catch (IOException e) {
/* 329 */       log.info(Messages.getMessage("exception00"), e);
/*     */     } finally {
/* 331 */       this.serverSocket = null;
/*     */     } 
/*     */     
/* 334 */     log.info(Messages.getMessage("quit00", "SimpleAxisServer"));
/*     */ 
/*     */     
/* 337 */     pool.shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 345 */     Options opts = null;
/*     */     try {
/* 347 */       opts = new Options(args);
/* 348 */     } catch (MalformedURLException e) {
/* 349 */       log.error(Messages.getMessage("malformedURLException00"), e);
/*     */       
/*     */       return;
/*     */     } 
/* 353 */     String maxPoolSize = opts.isValueSet('t');
/* 354 */     if (maxPoolSize == null) maxPoolSize = "100";
/*     */     
/* 356 */     String maxSessions = opts.isValueSet('m');
/* 357 */     if (maxSessions == null) maxSessions = "100";
/*     */     
/* 359 */     SimpleAxisServer sas = new SimpleAxisServer(Integer.parseInt(maxPoolSize), Integer.parseInt(maxSessions));
/*     */ 
/*     */     
/*     */     try {
/* 363 */       doThreads = (opts.isFlagSet('t') > 0);
/*     */       
/* 365 */       int port = opts.getPort();
/* 366 */       ServerSocket ss = null;
/*     */       
/* 368 */       int retries = 5;
/* 369 */       for (int i = 0; i < 5; i++) {
/*     */         try {
/* 371 */           ss = new ServerSocket(port);
/*     */           break;
/* 373 */         } catch (BindException be) {
/* 374 */           log.debug(Messages.getMessage("exception00"), be);
/* 375 */           if (i < 4) {
/*     */             
/* 377 */             Thread.sleep(3000L);
/*     */           } else {
/* 379 */             throw new Exception(Messages.getMessage("unableToStartServer00", Integer.toString(port)));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 384 */       sas.setServerSocket(ss);
/* 385 */       sas.start();
/* 386 */     } catch (Exception e) {
/* 387 */       log.error(Messages.getMessage("exception00"), e);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\SimpleAxisServer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */