package org.apache.axis.transport.http;

import java.net.Socket;

public class SocketHolder {
  private Socket value;
  
  public SocketHolder(Socket value) {
    this.value = null;
    this.value = value;
  }
  
  public Socket getSocket() { return this.value; }
  
  public void setSocket(Socket value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\SocketHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */