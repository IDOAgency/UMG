package org.apache.axis.transport.http;

import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.axis.session.Session;

public class AxisHttpSession implements Session {
  public static final String AXIS_SESSION_MARKER = "axis.isAxisSession";
  
  private HttpSession rep;
  
  private HttpServletRequest req;
  
  public AxisHttpSession(HttpServletRequest realRequest) { this.req = realRequest; }
  
  public AxisHttpSession(HttpSession realSession) {
    if (realSession != null)
      setRep(realSession); 
  }
  
  public HttpSession getRep() {
    ensureSession();
    return this.rep;
  }
  
  private void setRep(HttpSession realSession) {
    this.rep = realSession;
    this.rep.setAttribute("axis.isAxisSession", Boolean.TRUE);
  }
  
  public Object get(String key) {
    ensureSession();
    return this.rep.getAttribute(key);
  }
  
  public void set(String key, Object value) {
    ensureSession();
    this.rep.setAttribute(key, value);
  }
  
  public void remove(String key) {
    ensureSession();
    this.rep.removeAttribute(key);
  }
  
  public Enumeration getKeys() {
    ensureSession();
    return this.rep.getAttributeNames();
  }
  
  public void setTimeout(int timeout) {
    ensureSession();
    this.rep.setMaxInactiveInterval(timeout);
  }
  
  public int getTimeout() {
    ensureSession();
    return this.rep.getMaxInactiveInterval();
  }
  
  public void touch() {}
  
  public void invalidate() { this.rep.invalidate(); }
  
  protected void ensureSession() {
    if (this.rep == null)
      setRep(this.req.getSession()); 
  }
  
  public Object getLockObject() {
    ensureSession();
    return this.rep;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\AxisHttpSession.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */