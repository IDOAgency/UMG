package org.apache.axis.transport.http;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpUtils;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import org.apache.axis.AxisEngine;
import org.apache.axis.AxisFault;
import org.apache.axis.ConfigurationException;
import org.apache.axis.Constants;
import org.apache.axis.Handler;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.SOAPPart;
import org.apache.axis.SimpleTargetedChain;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.description.ServiceDesc;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.management.ServiceAdmin;
import org.apache.axis.security.servlet.ServletSecurityProvider;
import org.apache.axis.server.AxisServer;
import org.apache.axis.utils.JavaUtils;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.XMLUtils;
import org.apache.commons.logging.Log;
import org.w3c.dom.Element;

public class AxisServlet extends AxisServletBase {
  protected static Log log = LogFactory.getLog(AxisServlet.class.getName());
  
  private static Log tlog = LogFactory.getLog("org.apache.axis.TIME");
  
  private static Log exceptionLog = LogFactory.getLog("org.apache.axis.EXCEPTIONS");
  
  public static final String INIT_PROPERTY_TRANSPORT_NAME = "transport.name";
  
  public static final String INIT_PROPERTY_USE_SECURITY = "use-servlet-security";
  
  public static final String INIT_PROPERTY_ENABLE_LIST = "axis.enableListQuery";
  
  public static final String INIT_PROPERTY_JWS_CLASS_DIR = "axis.jws.servletClassDir";
  
  public static final String INIT_PROPERTY_DISABLE_SERVICES_LIST = "axis.disableServiceList";
  
  public static final String INIT_PROPERTY_SERVICES_PATH = "axis.servicesPath";
  
  private String transportName;
  
  private Handler transport;
  
  private ServletSecurityProvider securityProvider = null;
  
  private String servicesPath;
  
  private static boolean isDebug = false;
  
  private boolean enableList = false;
  
  private boolean disableServicesList = false;
  
  private String jwsClassDir = null;
  
  protected String getJWSClassDir() { return this.jwsClassDir; }
  
  public void init() {
    super.init();
    ServletContext context = getServletConfig().getServletContext();
    isDebug = log.isDebugEnabled();
    if (isDebug)
      log.debug("In servlet init"); 
    this.transportName = getOption(context, "transport.name", "http");
    if (JavaUtils.isTrueExplicitly(getOption(context, "use-servlet-security", null)))
      this.securityProvider = new ServletSecurityProvider(); 
    this.enableList = JavaUtils.isTrueExplicitly(getOption(context, "axis.enableListQuery", null));
    this.jwsClassDir = getOption(context, "axis.jws.servletClassDir", null);
    this.disableServicesList = JavaUtils.isTrue(getOption(context, "axis.disableServiceList", "false"));
    this.servicesPath = getOption(context, "axis.servicesPath", "/services/");
    if (this.jwsClassDir != null) {
      if (getHomeDir() != null)
        this.jwsClassDir = getHomeDir() + this.jwsClassDir; 
    } else {
      this.jwsClassDir = getDefaultJWSClassDir();
    } 
    initQueryStringHandlers();
    try {
      ServiceAdmin.setEngine(getEngine(), context.getServerInfo());
    } catch (AxisFault af) {
      exceptionLog.info("Exception setting AxisEngine on ServiceAdmin " + af);
    } 
  }
  
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    if (isDebug)
      log.debug("Enter: doGet()"); 
    PrintWriter writer = new FilterPrintWriter(response);
    try {
      AxisServer axisServer = getEngine();
      ServletContext servletContext = getServletConfig().getServletContext();
      String pathInfo = request.getPathInfo();
      String realpath = servletContext.getRealPath(request.getServletPath());
      if (realpath == null)
        realpath = request.getServletPath(); 
      boolean isJWSPage = request.getRequestURI().endsWith(".jws");
      if (isJWSPage)
        pathInfo = request.getServletPath(); 
      if (processQuery(request, response, writer) == true)
        return; 
      boolean hasNoPath = (pathInfo == null || pathInfo.equals(""));
      if (!this.disableServicesList) {
        if (hasNoPath) {
          reportAvailableServices(response, writer, request);
        } else if (realpath != null) {
          String serviceName;
          MessageContext msgContext = createMessageContext(axisServer, request, response);
          String url = HttpUtils.getRequestURL(request).toString();
          msgContext.setProperty("transport.url", url);
          if (pathInfo.startsWith("/")) {
            serviceName = pathInfo.substring(1);
          } else {
            serviceName = pathInfo;
          } 
          SOAPService s = axisServer.getService(serviceName);
          if (s == null) {
            if (isJWSPage) {
              reportCantGetJWSService(request, response, writer);
            } else {
              reportCantGetAxisService(request, response, writer);
            } 
          } else {
            reportServiceInfo(response, writer, s, serviceName);
          } 
        } 
      } else {
        response.setContentType("text/html; charset=utf-8");
        writer.println("<html><h1>Axis HTTP Servlet</h1>");
        writer.println(Messages.getMessage("reachedServlet00"));
        writer.println("<p>" + Messages.getMessage("transportName00", "<b>" + this.transportName + "</b>"));
        writer.println("</html>");
      } 
    } catch (AxisFault fault) {
      reportTroubleInGet(fault, response, writer);
    } catch (Exception e) {
      reportTroubleInGet(e, response, writer);
    } finally {
      writer.close();
      if (isDebug)
        log.debug("Exit: doGet()"); 
    } 
  }
  
  private void reportTroubleInGet(Throwable exception, HttpServletResponse response, PrintWriter writer) {
    response.setContentType("text/html; charset=utf-8");
    response.setStatus(500);
    writer.println("<h2>" + Messages.getMessage("error00") + "</h2>");
    writer.println("<p>" + Messages.getMessage("somethingWrong00") + "</p>");
    if (exception instanceof AxisFault) {
      AxisFault fault = (AxisFault)exception;
      processAxisFault(fault);
      writeFault(writer, fault);
    } else {
      logException(exception);
      writer.println("<pre>Exception - " + exception + "<br>");
      if (isDevelopment())
        writer.println(JavaUtils.stackToString(exception)); 
      writer.println("</pre>");
    } 
  }
  
  protected void processAxisFault(AxisFault fault) {
    Element runtimeException = fault.lookupFaultDetail(Constants.QNAME_FAULTDETAIL_RUNTIMEEXCEPTION);
    if (runtimeException != null) {
      exceptionLog.info(Messages.getMessage("axisFault00"), fault);
      fault.removeFaultDetail(Constants.QNAME_FAULTDETAIL_RUNTIMEEXCEPTION);
    } else if (exceptionLog.isDebugEnabled()) {
      exceptionLog.debug(Messages.getMessage("axisFault00"), fault);
    } 
    if (!isDevelopment())
      fault.removeFaultDetail(Constants.QNAME_FAULTDETAIL_STACKTRACE); 
  }
  
  protected void logException(Throwable e) { exceptionLog.info(Messages.getMessage("exception00"), e); }
  
  private void writeFault(PrintWriter writer, AxisFault axisFault) {
    String localizedMessage = XMLUtils.xmlEncodeString(axisFault.getLocalizedMessage());
    writer.println("<pre>Fault - " + localizedMessage + "<br>");
    writer.println(axisFault.dumpToString());
    writer.println("</pre>");
  }
  
  protected void reportServiceInfo(HttpServletResponse response, PrintWriter writer, SOAPService service, String serviceName) {
    response.setContentType("text/html; charset=utf-8");
    writer.println("<h1>" + service.getName() + "</h1>");
    writer.println("<p>" + Messages.getMessage("axisService00") + "</p>");
    writer.println("<i>" + Messages.getMessage("perhaps00") + "</i>");
  }
  
  protected void reportNoWSDL(HttpServletResponse res, PrintWriter writer, String moreDetailCode, AxisFault axisFault) {}
  
  protected void reportAvailableServices(HttpServletResponse response, PrintWriter writer, HttpServletRequest request) throws ConfigurationException, AxisFault {
    Iterator i;
    AxisServer axisServer = getEngine();
    response.setContentType("text/html; charset=utf-8");
    writer.println("<h2>And now... Some Services</h2>");
    try {
      i = axisServer.getConfig().getDeployedServices();
    } catch (ConfigurationException configException) {
      if (configException.getContainedException() instanceof AxisFault)
        throw (AxisFault)configException.getContainedException(); 
      throw configException;
    } 
    String defaultBaseURL = getWebappBase(request) + this.servicesPath;
    writer.println("<ul>");
    while (i.hasNext()) {
      ServiceDesc sd = (ServiceDesc)i.next();
      StringBuffer sb = new StringBuffer();
      sb.append("<li>");
      String name = sd.getName();
      sb.append(name);
      sb.append(" <a href=\"");
      String endpointURL = sd.getEndpointURL();
      String baseURL = (endpointURL == null) ? defaultBaseURL : endpointURL;
      sb.append(baseURL);
      sb.append(name);
      sb.append("?wsdl\"><i>(wsdl)</i></a></li>");
      writer.println(sb.toString());
      ArrayList operations = sd.getOperations();
      if (!operations.isEmpty()) {
        writer.println("<ul>");
        for (Iterator it = operations.iterator(); it.hasNext(); ) {
          OperationDesc desc = (OperationDesc)it.next();
          writer.println("<li>" + desc.getName());
        } 
        writer.println("</ul>");
      } 
    } 
    writer.println("</ul>");
  }
  
  protected void reportCantGetAxisService(HttpServletRequest request, HttpServletResponse response, PrintWriter writer) {
    response.setStatus(404);
    response.setContentType("text/html; charset=utf-8");
    writer.println("<h2>" + Messages.getMessage("error00") + "</h2>");
    writer.println("<p>" + Messages.getMessage("noService06") + "</p>");
  }
  
  protected void reportCantGetJWSService(HttpServletRequest request, HttpServletResponse response, PrintWriter writer) {
    String requestPath = request.getServletPath() + ((request.getPathInfo() != null) ? request.getPathInfo() : "");
    String realpath = getServletConfig().getServletContext().getRealPath(requestPath);
    log.debug("JWS real path: " + realpath);
    boolean foundJWSFile = ((new File(realpath)).exists() && realpath.endsWith(".jws"));
    response.setContentType("text/html; charset=utf-8");
    if (foundJWSFile) {
      response.setStatus(200);
      writer.println(Messages.getMessage("foundJWS00") + "<p>");
      String url = request.getRequestURI();
      String urltext = Messages.getMessage("foundJWS01");
      writer.println("<a href='" + url + "?wsdl'>" + urltext + "</a>");
    } else {
      response.setStatus(404);
      writer.println(Messages.getMessage("noService06"));
    } 
  }
  
  public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    long t0 = 0L, t1 = 0L, t2 = 0L, t3 = 0L, t4 = 0L;
    String soapAction = null;
    MessageContext msgContext = null;
    if (isDebug)
      log.debug("Enter: doPost()"); 
    if (tlog.isDebugEnabled())
      t0 = System.currentTimeMillis(); 
    Message responseMsg = null;
    String contentType = null;
    try {
      AxisServer axisServer = getEngine();
      if (axisServer == null) {
        ServletException se = new ServletException(Messages.getMessage("noEngine00"));
        log.debug("No Engine!", se);
        throw se;
      } 
      res.setBufferSize(8192);
      msgContext = createMessageContext(axisServer, req, res);
      if (this.securityProvider != null) {
        if (isDebug)
          log.debug("securityProvider:" + this.securityProvider); 
        msgContext.setProperty("securityProvider", this.securityProvider);
      } 
      Message requestMsg = new Message(req.getInputStream(), false, req.getHeader("Content-Type"), req.getHeader("Content-Location"));
      MimeHeaders requestMimeHeaders = requestMsg.getMimeHeaders();
      for (Enumeration e = req.getHeaderNames(); e.hasMoreElements(); ) {
        String headerName = (String)e.nextElement();
        Enumeration f = req.getHeaders(headerName);
        while (f.hasMoreElements()) {
          String headerValue = (String)f.nextElement();
          requestMimeHeaders.addHeader(headerName, headerValue);
        } 
      } 
      if (isDebug)
        log.debug("Request Message:" + requestMsg); 
      msgContext.setRequestMessage(requestMsg);
      String url = HttpUtils.getRequestURL(req).toString();
      msgContext.setProperty("transport.url", url);
      try {
        String requestEncoding = (String)requestMsg.getProperty("javax.xml.soap.character-set-encoding");
        if (requestEncoding != null)
          msgContext.setProperty("javax.xml.soap.character-set-encoding", requestEncoding); 
      } catch (SOAPException e1) {}
      try {
        soapAction = getSoapAction(req);
        if (soapAction != null) {
          msgContext.setUseSOAPAction(true);
          msgContext.setSOAPActionURI(soapAction);
        } 
        msgContext.setSession(new AxisHttpSession(req));
        if (tlog.isDebugEnabled())
          t1 = System.currentTimeMillis(); 
        if (isDebug)
          log.debug("Invoking Axis Engine."); 
        axisServer.invoke(msgContext);
        if (isDebug)
          log.debug("Return from Axis Engine."); 
        if (tlog.isDebugEnabled())
          t2 = System.currentTimeMillis(); 
        responseMsg = msgContext.getResponseMessage();
      } catch (AxisFault fault) {
        processAxisFault(fault);
        configureResponseFromAxisFault(res, fault);
        responseMsg = msgContext.getResponseMessage();
        if (responseMsg == null) {
          responseMsg = new Message(fault);
          ((SOAPPart)responseMsg.getSOAPPart()).getMessage().setMessageContext(msgContext);
        } 
      } catch (Exception e) {
        responseMsg = msgContext.getResponseMessage();
        res.setStatus(500);
        responseMsg = convertExceptionToAxisFault(e, responseMsg);
        ((SOAPPart)responseMsg.getSOAPPart()).getMessage().setMessageContext(msgContext);
      } catch (Throwable t) {
        logException(t);
        responseMsg = msgContext.getResponseMessage();
        res.setStatus(500);
        responseMsg = new Message(new AxisFault(t.toString(), t));
        ((SOAPPart)responseMsg.getSOAPPart()).getMessage().setMessageContext(msgContext);
      } 
    } catch (AxisFault fault) {
      processAxisFault(fault);
      configureResponseFromAxisFault(res, fault);
      responseMsg = msgContext.getResponseMessage();
      if (responseMsg == null) {
        responseMsg = new Message(fault);
        ((SOAPPart)responseMsg.getSOAPPart()).getMessage().setMessageContext(msgContext);
      } 
    } 
    if (tlog.isDebugEnabled())
      t3 = System.currentTimeMillis(); 
    if (responseMsg != null) {
      MimeHeaders responseMimeHeaders = responseMsg.getMimeHeaders();
      for (Iterator i = responseMimeHeaders.getAllHeaders(); i.hasNext(); ) {
        MimeHeader responseMimeHeader = (MimeHeader)i.next();
        res.addHeader(responseMimeHeader.getName(), responseMimeHeader.getValue());
      } 
      String responseEncoding = (String)msgContext.getProperty("javax.xml.soap.character-set-encoding");
      if (responseEncoding != null)
        try {
          responseMsg.setProperty("javax.xml.soap.character-set-encoding", responseEncoding);
        } catch (SOAPException e) {} 
      contentType = responseMsg.getContentType(msgContext.getSOAPConstants());
      sendResponse(contentType, res, responseMsg);
    } else {
      res.setStatus(202);
    } 
    if (isDebug) {
      log.debug("Response sent.");
      log.debug("Exit: doPost()");
    } 
    if (tlog.isDebugEnabled()) {
      t4 = System.currentTimeMillis();
      tlog.debug("axisServlet.doPost: " + soapAction + " pre=" + (t1 - t0) + " invoke=" + (t2 - t1) + " post=" + (t3 - t2) + " send=" + (t4 - t3) + " " + msgContext.getTargetService() + "." + ((msgContext.getOperation() == null) ? "" : msgContext.getOperation().getName()));
    } 
  }
  
  private void configureResponseFromAxisFault(HttpServletResponse response, AxisFault fault) {
    int status = getHttpServletResponseStatus(fault);
    if (status == 401)
      response.setHeader("WWW-Authenticate", "Basic realm=\"AXIS\""); 
    response.setStatus(status);
  }
  
  private Message convertExceptionToAxisFault(Exception exception, Message responseMsg) {
    logException(exception);
    if (responseMsg == null) {
      AxisFault fault = AxisFault.makeFault(exception);
      processAxisFault(fault);
      responseMsg = new Message(fault);
    } 
    return responseMsg;
  }
  
  protected int getHttpServletResponseStatus(AxisFault af) { return af.getFaultCode().getLocalPart().startsWith("Server.Unauth") ? 401 : 500; }
  
  private void sendResponse(String contentType, HttpServletResponse res, Message responseMsg) throws AxisFault, IOException {
    if (responseMsg == null) {
      res.setStatus(204);
      if (isDebug)
        log.debug("NO AXIS MESSAGE TO RETURN!"); 
    } else {
      if (isDebug)
        log.debug("Returned Content-Type:" + contentType); 
      try {
        res.setContentType(contentType);
        responseMsg.writeTo(res.getOutputStream());
      } catch (SOAPException e) {
        logException(e);
      } 
    } 
    if (!res.isCommitted())
      res.flushBuffer(); 
  }
  
  private MessageContext createMessageContext(AxisEngine engine, HttpServletRequest req, HttpServletResponse res) {
    MessageContext msgContext = new MessageContext(engine);
    String requestPath = getRequestPath(req);
    if (isDebug) {
      log.debug("MessageContext:" + msgContext);
      log.debug("HEADER_CONTENT_TYPE:" + req.getHeader("Content-Type"));
      log.debug("HEADER_CONTENT_LOCATION:" + req.getHeader("Content-Location"));
      log.debug("Constants.MC_HOME_DIR:" + String.valueOf(getHomeDir()));
      log.debug("Constants.MC_RELATIVE_PATH:" + requestPath);
      log.debug("HTTPConstants.MC_HTTP_SERVLETLOCATION:" + String.valueOf(getWebInfPath()));
      log.debug("HTTPConstants.MC_HTTP_SERVLETPATHINFO:" + req.getPathInfo());
      log.debug("HTTPConstants.HEADER_AUTHORIZATION:" + req.getHeader("Authorization"));
      log.debug("Constants.MC_REMOTE_ADDR:" + req.getRemoteAddr());
      log.debug("configPath:" + String.valueOf(getWebInfPath()));
    } 
    msgContext.setTransportName(this.transportName);
    msgContext.setProperty("jws.classDir", this.jwsClassDir);
    msgContext.setProperty("home.dir", getHomeDir());
    msgContext.setProperty("path", requestPath);
    msgContext.setProperty(HTTPConstants.MC_HTTP_SERVLET, this);
    msgContext.setProperty(HTTPConstants.MC_HTTP_SERVLETREQUEST, req);
    msgContext.setProperty(HTTPConstants.MC_HTTP_SERVLETRESPONSE, res);
    msgContext.setProperty(HTTPConstants.MC_HTTP_SERVLETLOCATION, getWebInfPath());
    msgContext.setProperty(HTTPConstants.MC_HTTP_SERVLETPATHINFO, req.getPathInfo());
    msgContext.setProperty("Authorization", req.getHeader("Authorization"));
    msgContext.setProperty("remoteaddr", req.getRemoteAddr());
    ServletEndpointContextImpl sec = new ServletEndpointContextImpl();
    msgContext.setProperty("servletEndpointContext", sec);
    String realpath = getServletConfig().getServletContext().getRealPath(requestPath);
    if (realpath != null)
      msgContext.setProperty("realpath", realpath); 
    msgContext.setProperty("configPath", getWebInfPath());
    return msgContext;
  }
  
  private String getSoapAction(HttpServletRequest req) throws AxisFault {
    String soapAction = req.getHeader("SOAPAction");
    if (soapAction == null) {
      String contentType = req.getHeader("Content-Type");
      if (contentType != null) {
        int index = contentType.indexOf("action");
        if (index != -1)
          soapAction = contentType.substring(index + 7); 
      } 
    } 
    if (isDebug)
      log.debug("HEADER_SOAP_ACTION:" + soapAction); 
    if (soapAction == null) {
      AxisFault af = new AxisFault("Client.NoSOAPAction", Messages.getMessage("noHeader00", "SOAPAction"), null, null);
      exceptionLog.error(Messages.getMessage("genFault00"), af);
      throw af;
    } 
    if (soapAction.startsWith("\"") && soapAction.endsWith("\"") && soapAction.length() >= 2) {
      int end = soapAction.length() - 1;
      soapAction = soapAction.substring(1, end);
    } 
    if (soapAction.length() == 0)
      soapAction = req.getContextPath(); 
    return soapAction;
  }
  
  protected String getDefaultJWSClassDir() { return (getWebInfPath() == null) ? null : (getWebInfPath() + File.separator + "jwsClasses"); }
  
  public void initQueryStringHandlers() {
    try {
      this.transport = getEngine().getTransport(this.transportName);
      if (this.transport == null) {
        this.transport = new SimpleTargetedChain();
        this.transport.setOption("qs.list", "org.apache.axis.transport.http.QSListHandler");
        this.transport.setOption("qs.method", "org.apache.axis.transport.http.QSMethodHandler");
        this.transport.setOption("qs.wsdl", "org.apache.axis.transport.http.QSWSDLHandler");
        return;
      } 
      boolean defaultQueryStrings = true;
      String useDefaults = (String)this.transport.getOption("useDefaultQueryStrings");
      if (useDefaults != null && useDefaults.toLowerCase().equals("false"))
        defaultQueryStrings = false; 
      if (defaultQueryStrings == true) {
        this.transport.setOption("qs.list", "org.apache.axis.transport.http.QSListHandler");
        this.transport.setOption("qs.method", "org.apache.axis.transport.http.QSMethodHandler");
        this.transport.setOption("qs.wsdl", "org.apache.axis.transport.http.QSWSDLHandler");
      } 
    } catch (AxisFault e) {
      this.transport = new SimpleTargetedChain();
      this.transport.setOption("qs.list", "org.apache.axis.transport.http.QSListHandler");
      this.transport.setOption("qs.method", "org.apache.axis.transport.http.QSMethodHandler");
      this.transport.setOption("qs.wsdl", "org.apache.axis.transport.http.QSWSDLHandler");
      return;
    } 
  }
  
  private boolean processQuery(HttpServletRequest request, HttpServletResponse response, PrintWriter writer) throws AxisFault {
    String serviceName, path = request.getServletPath();
    String queryString = request.getQueryString();
    AxisServer axisServer = getEngine();
    Iterator i = this.transport.getOptions().keySet().iterator();
    if (queryString == null)
      return false; 
    String servletURI = request.getContextPath() + path;
    String reqURI = request.getRequestURI();
    if (servletURI.length() + 1 < reqURI.length()) {
      serviceName = reqURI.substring(servletURI.length() + 1);
    } else {
      serviceName = "";
    } 
    while (i.hasNext() == true) {
      String queryHandler = (String)i.next();
      if (queryHandler.startsWith("qs.") == true) {
        String handlerName = queryHandler.substring(queryHandler.indexOf(".") + 1).toLowerCase();
        int length = 0;
        boolean firstParamFound = false;
        while (!firstParamFound && length < queryString.length()) {
          char ch = queryString.charAt(length++);
          if (ch == '&' || ch == '=') {
            firstParamFound = true;
            length--;
          } 
        } 
        if (length < queryString.length())
          queryString = queryString.substring(0, length); 
        if (queryString.toLowerCase().equals(handlerName) == true) {
          if (this.transport.getOption(queryHandler).equals(""))
            return false; 
          try {
            MessageContext msgContext = createMessageContext(axisServer, request, response);
            Class plugin = Class.forName((String)this.transport.getOption(queryHandler));
            Method pluginMethod = plugin.getDeclaredMethod("invoke", new Class[] { msgContext.getClass() });
            String url = HttpUtils.getRequestURL(request).toString();
            msgContext.setProperty("transport.url", url);
            msgContext.setProperty("transport.http.plugin.serviceName", serviceName);
            msgContext.setProperty("transport.http.plugin.pluginName", handlerName);
            msgContext.setProperty("transport.http.plugin.isDevelopment", new Boolean(isDevelopment()));
            msgContext.setProperty("transport.http.plugin.enableList", new Boolean(this.enableList));
            msgContext.setProperty("transport.http.plugin.engine", axisServer);
            msgContext.setProperty("transport.http.plugin.writer", writer);
            msgContext.setProperty("transport.http.plugin.log", log);
            msgContext.setProperty("transport.http.plugin.exceptionLog", exceptionLog);
            pluginMethod.invoke(plugin.newInstance(), new Object[] { msgContext });
            writer.close();
            return true;
          } catch (InvocationTargetException ie) {
            reportTroubleInGet(ie.getTargetException(), response, writer);
            return true;
          } catch (Exception e) {
            reportTroubleInGet(e, response, writer);
            return true;
          } 
        } 
      } 
    } 
    return false;
  }
  
  private static String getRequestPath(HttpServletRequest request) throws AxisFault { return request.getServletPath() + ((request.getPathInfo() != null) ? request.getPathInfo() : ""); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\AxisServlet.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */