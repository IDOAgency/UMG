/*    */ package org.apache.axis.transport.http;
/*    */ 
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChunkedOutputStream
/*    */   extends FilterOutputStream
/*    */ {
/*    */   boolean eos = false;
/*    */   
/* 33 */   private ChunkedOutputStream() { super(null); }
/*    */ 
/*    */ 
/*    */   
/* 37 */   public ChunkedOutputStream(OutputStream os) { super(os); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public void write(int b) throws IOException { write(new byte[] { (byte)b }, 0, 1); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public void write(byte[] b) throws IOException { write(b, 0, b.length); }
/*    */ 
/*    */   
/* 51 */   static final byte[] CRLF = "\r\n".getBytes();
/* 52 */   static final byte[] LAST_TOKEN = "0\r\n\r\n".getBytes();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void write(byte[] b, int off, int len) throws IOException {
/* 58 */     if (len == 0)
/*    */       return; 
/* 60 */     this.out.write(Integer.toHexString(len).getBytes());
/* 61 */     this.out.write(CRLF);
/* 62 */     this.out.write(b, off, len);
/* 63 */     this.out.write(CRLF);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void eos() {
/* 74 */     synchronized (this) {
/* 75 */       if (this.eos)
/* 76 */         return;  this.eos = true;
/*    */     } 
/* 78 */     this.out.write(LAST_TOKEN);
/* 79 */     this.out.flush();
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/* 84 */     eos();
/* 85 */     this.out.close();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\ChunkedOutputStream.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */