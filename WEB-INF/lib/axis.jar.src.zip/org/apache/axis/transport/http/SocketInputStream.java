package org.apache.axis.transport.http;

import java.io.FilterInputStream;
import java.io.InputStream;
import java.net.Socket;

public class SocketInputStream extends FilterInputStream {
  Socket socket = null;
  
  private SocketInputStream() { super(null); }
  
  public SocketInputStream(InputStream is, Socket socket) {
    super(is);
    this.socket = socket;
  }
  
  public void close() {
    synchronized (this) {
      if (this.closed)
        return; 
      this.closed = true;
    } 
    this.in.close();
    this.in = null;
    this.socket.close();
    this.socket = null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\SocketInputStream.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */