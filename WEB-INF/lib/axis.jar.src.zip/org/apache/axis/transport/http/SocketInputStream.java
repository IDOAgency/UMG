/*    */ package org.apache.axis.transport.http;
/*    */ 
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.net.Socket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SocketInputStream
/*    */   extends FilterInputStream
/*    */ {
/* 35 */   Socket socket = null;
/*    */ 
/*    */   
/* 38 */   private SocketInputStream() { super(null); }
/*    */ 
/*    */ 
/*    */   
/*    */   public SocketInputStream(InputStream is, Socket socket) {
/* 43 */     super(is);
/* 44 */     this.socket = socket;
/*    */   }
/*    */   
/*    */   public void close() {
/* 48 */     synchronized (this) {
/* 49 */       if (this.closed)
/* 50 */         return;  this.closed = true;
/*    */     } 
/* 52 */     this.in.close();
/* 53 */     this.in = null;
/* 54 */     this.socket.close();
/* 55 */     this.socket = null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\SocketInputStream.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */