package org.apache.axis.transport.http;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import org.apache.axis.AxisFault;
import org.apache.axis.Constants;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.components.net.BooleanHolder;
import org.apache.axis.components.net.DefaultSocketFactory;
import org.apache.axis.components.net.SocketFactory;
import org.apache.axis.components.net.SocketFactoryFactory;
import org.apache.axis.encoding.Base64;
import org.apache.axis.handlers.BasicHandler;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.TeeOutputStream;
import org.apache.commons.logging.Log;

public class HTTPSender extends BasicHandler {
  protected static Log log = LogFactory.getLog(HTTPSender.class.getName());
  
  private static final String ACCEPT_HEADERS = "Accept: application/soap+xml, application/dime, multipart/related, text/*\r\nUser-Agent: " + Messages.getMessage("axisUserAgent") + "\r\n";
  
  private static final String CACHE_HEADERS = "Cache-Control: no-cache\r\nPragma: no-cache\r\n";
  
  private static final String CHUNKED_HEADER = HTTPConstants.HEADER_TRANSFER_ENCODING + ": " + HTTPConstants.HEADER_TRANSFER_ENCODING_CHUNKED + "\r\n";
  
  private static final String HEADER_CONTENT_TYPE_LC = "Content-Type".toLowerCase();
  
  private static final String HEADER_LOCATION_LC = "Location".toLowerCase();
  
  private static final String HEADER_CONTENT_LOCATION_LC = "Content-Location".toLowerCase();
  
  private static final String HEADER_CONTENT_LENGTH_LC = "Content-Length".toLowerCase();
  
  private static final String HEADER_TRANSFER_ENCODING_LC = HTTPConstants.HEADER_TRANSFER_ENCODING.toLowerCase();
  
  URL targetURL;
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("enter00", "HTTPSender::invoke")); 
    SocketHolder socketHolder = new SocketHolder(null);
    try {
      BooleanHolder useFullURL = new BooleanHolder(false);
      StringBuffer otherHeaders = new StringBuffer();
      this.targetURL = new URL(msgContext.getStrProp("transport.url"));
      String host = this.targetURL.getHost();
      int port = this.targetURL.getPort();
      InputStream inp = writeToSocket(socketHolder, msgContext, this.targetURL, otherHeaders, host, port, msgContext.getTimeout(), useFullURL);
      Hashtable headers = new Hashtable();
      inp = readHeadersFromSocket(socketHolder, msgContext, inp, headers);
      readFromSocket(socketHolder, msgContext, inp, headers);
    } catch (Exception e) {
      log.debug(e);
      try {
        if (socketHolder.getSocket() != null)
          socketHolder.getSocket().close(); 
      } catch (IOException ie) {}
      throw AxisFault.makeFault(e);
    } 
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("exit00", "HTTPDispatchHandler::invoke")); 
  }
  
  protected void getSocket(SocketHolder sockHolder, MessageContext msgContext, String protocol, String host, int port, int timeout, StringBuffer otherHeaders, BooleanHolder useFullURL) throws Exception {
    Hashtable options = getOptions();
    if (timeout > 0) {
      if (options == null)
        options = new Hashtable(); 
      options.put(DefaultSocketFactory.CONNECT_TIMEOUT, Integer.toString(timeout));
    } 
    SocketFactory factory = SocketFactoryFactory.getFactory(protocol, options);
    if (factory == null)
      throw new IOException(Messages.getMessage("noSocketFactory", protocol)); 
    Socket sock = factory.create(host, port, otherHeaders, useFullURL);
    if (timeout > 0)
      sock.setSoTimeout(timeout); 
    sockHolder.setSocket(sock);
  }
  
  private InputStream writeToSocket(SocketHolder sockHolder, MessageContext msgContext, URL tmpURL, StringBuffer otherHeaders, String host, int port, int timeout, BooleanHolder useFullURL) throws Exception {
    String userID = msgContext.getUsername();
    String passwd = msgContext.getPassword();
    String action = msgContext.useSOAPAction() ? msgContext.getSOAPActionURI() : "";
    if (action == null)
      action = ""; 
    if (userID == null && tmpURL.getUserInfo() != null) {
      String info = tmpURL.getUserInfo();
      int sep = info.indexOf(':');
      if (sep >= 0 && sep + 1 < info.length()) {
        userID = info.substring(0, sep);
        passwd = info.substring(sep + 1);
      } else {
        userID = info;
      } 
    } 
    if (userID != null) {
      StringBuffer tmpBuf = new StringBuffer();
      tmpBuf.append(userID).append(":").append((passwd == null) ? "" : passwd);
      otherHeaders.append("Authorization").append(": Basic ").append(Base64.encode(tmpBuf.toString().getBytes())).append("\r\n");
    } 
    if (msgContext.getMaintainSession()) {
      fillHeaders(msgContext, "Cookie", otherHeaders);
      fillHeaders(msgContext, "Cookie2", otherHeaders);
    } 
    StringBuffer header2 = new StringBuffer();
    String webMethod = null;
    boolean posting = true;
    Message reqMessage = msgContext.getRequestMessage();
    boolean http10 = true;
    boolean httpChunkStream = false;
    boolean httpContinueExpected = false;
    String httpConnection = null;
    String httpver = msgContext.getStrProp("axis.transport.version");
    if (null == httpver)
      httpver = HTTPConstants.HEADER_PROTOCOL_V10; 
    httpver = httpver.trim();
    if (httpver.equals(HTTPConstants.HEADER_PROTOCOL_V11))
      http10 = false; 
    Hashtable userHeaderTable = (Hashtable)msgContext.getProperty("HTTP-Request-Headers");
    if (userHeaderTable != null) {
      if (null == otherHeaders)
        otherHeaders = new StringBuffer(1024); 
      Iterator e = userHeaderTable.entrySet().iterator();
      while (e.hasNext()) {
        Map.Entry me = (Map.Entry)e.next();
        Object keyObj = me.getKey();
        if (null == keyObj)
          continue; 
        String key = keyObj.toString().trim();
        if (key.equalsIgnoreCase(HTTPConstants.HEADER_TRANSFER_ENCODING)) {
          if (!http10) {
            String val = me.getValue().toString();
            if (null != val && val.trim().equalsIgnoreCase(HTTPConstants.HEADER_TRANSFER_ENCODING_CHUNKED))
              httpChunkStream = true; 
          } 
          continue;
        } 
        if (key.equalsIgnoreCase("Connection")) {
          if (!http10) {
            String val = me.getValue().toString();
            if (val.trim().equalsIgnoreCase(HTTPConstants.HEADER_CONNECTION_CLOSE))
              httpConnection = HTTPConstants.HEADER_CONNECTION_CLOSE; 
          } 
          continue;
        } 
        if (!http10 && key.equalsIgnoreCase("Expect")) {
          String val = me.getValue().toString();
          if (null != val && val.trim().equalsIgnoreCase("100-continue"))
            httpContinueExpected = true; 
        } 
        otherHeaders.append(key).append(": ").append(me.getValue()).append("\r\n");
      } 
    } 
    if (!http10)
      httpConnection = HTTPConstants.HEADER_CONNECTION_CLOSE; 
    header2.append(" ");
    header2.append(http10 ? "HTTP/1.0" : "HTTP/1.1").append("\r\n");
    MimeHeaders mimeHeaders = reqMessage.getMimeHeaders();
    if (posting) {
      String contentType, header[] = mimeHeaders.getHeader("Content-Type");
      if (header != null && header.length > 0) {
        contentType = mimeHeaders.getHeader("Content-Type")[0];
      } else {
        contentType = reqMessage.getContentType(msgContext.getSOAPConstants());
      } 
      if (contentType == null || contentType.equals(""))
        throw new Exception(Messages.getMessage("missingContentType")); 
      header2.append("Content-Type").append(": ").append(contentType).append("\r\n");
    } 
    header2.append(ACCEPT_HEADERS).append("Host").append(": ").append(host).append((port == -1) ? "" : (":" + port)).append("\r\n").append("Cache-Control: no-cache\r\nPragma: no-cache\r\n").append("SOAPAction").append(": \"").append(action).append("\"\r\n");
    if (posting)
      if (!httpChunkStream) {
        header2.append("Content-Length").append(": ").append(reqMessage.getContentLength()).append("\r\n");
      } else {
        header2.append(CHUNKED_HEADER);
      }  
    if (mimeHeaders != null)
      for (Iterator i = mimeHeaders.getAllHeaders(); i.hasNext(); ) {
        MimeHeader mimeHeader = (MimeHeader)i.next();
        String headerName = mimeHeader.getName();
        if (headerName.equals("Content-Type") || headerName.equals("SOAPAction"))
          continue; 
        header2.append(mimeHeader.getName()).append(": ").append(mimeHeader.getValue()).append("\r\n");
      }  
    if (null != httpConnection) {
      header2.append("Connection");
      header2.append(": ");
      header2.append(httpConnection);
      header2.append("\r\n");
    } 
    getSocket(sockHolder, msgContext, this.targetURL.getProtocol(), host, port, timeout, otherHeaders, useFullURL);
    if (null != otherHeaders)
      header2.append(otherHeaders.toString()); 
    header2.append("\r\n");
    StringBuffer header = new StringBuffer();
    if (msgContext.getSOAPConstants() == SOAPConstants.SOAP12_CONSTANTS)
      webMethod = msgContext.getStrProp("soap12.webmethod"); 
    if (webMethod == null) {
      webMethod = "POST";
    } else {
      posting = webMethod.equals("POST");
    } 
    header.append(webMethod).append(" ");
    if (useFullURL.value) {
      header.append(tmpURL.toExternalForm());
    } else {
      header.append((tmpURL.getFile() == null || tmpURL.getFile().equals("")) ? "/" : tmpURL.getFile());
    } 
    header.append(header2.toString());
    TeeOutputStream teeOutputStream = sockHolder.getSocket().getOutputStream();
    if (!posting) {
      teeOutputStream.write(header.toString().getBytes("iso-8859-1"));
      teeOutputStream.flush();
      return null;
    } 
    InputStream inp = null;
    if (httpChunkStream || httpContinueExpected)
      teeOutputStream.write(header.toString().getBytes("iso-8859-1")); 
    if (httpContinueExpected) {
      teeOutputStream.flush();
      Hashtable cheaders = new Hashtable();
      inp = readHeadersFromSocket(sockHolder, msgContext, null, cheaders);
      int returnCode = -1;
      Integer Irc = (Integer)msgContext.getProperty(HTTPConstants.MC_HTTP_STATUS_CODE);
      if (null != Irc)
        returnCode = Irc.intValue(); 
      if (100 == returnCode) {
        msgContext.removeProperty(HTTPConstants.MC_HTTP_STATUS_CODE);
        msgContext.removeProperty(HTTPConstants.MC_HTTP_STATUS_MESSAGE);
      } else {
        String statusMessage = (String)msgContext.getProperty(HTTPConstants.MC_HTTP_STATUS_MESSAGE);
        AxisFault fault = new AxisFault("HTTP", "(" + returnCode + ")" + statusMessage, null, null);
        fault.setFaultDetailString(Messages.getMessage("return01", "" + returnCode, ""));
        throw fault;
      } 
    } 
    ByteArrayOutputStream baos = null;
    if (log.isDebugEnabled()) {
      log.debug(Messages.getMessage("xmlSent00"));
      log.debug("---------------------------------------------------");
      baos = new ByteArrayOutputStream();
    } 
    if (httpChunkStream) {
      ChunkedOutputStream chunkedOutputStream = new ChunkedOutputStream(teeOutputStream);
      teeOutputStream = new BufferedOutputStream(chunkedOutputStream, 8192);
      try {
        if (baos != null)
          teeOutputStream = new TeeOutputStream(teeOutputStream, baos); 
        reqMessage.writeTo(teeOutputStream);
      } catch (SOAPException e) {
        log.error(Messages.getMessage("exception00"), e);
      } 
      teeOutputStream.flush();
      chunkedOutputStream.eos();
    } else {
      TeeOutputStream teeOutputStream1 = new BufferedOutputStream(teeOutputStream, 8192);
      try {
        if (!httpContinueExpected)
          teeOutputStream1.write(header.toString().getBytes("iso-8859-1")); 
        if (baos != null)
          teeOutputStream1 = new TeeOutputStream(teeOutputStream1, baos); 
        reqMessage.writeTo(teeOutputStream1);
      } catch (SOAPException e) {
        log.error(Messages.getMessage("exception00"), e);
      } 
      teeOutputStream1.flush();
    } 
    if (log.isDebugEnabled())
      log.debug(header + new String(baos.toByteArray())); 
    return inp;
  }
  
  private void fillHeaders(MessageContext msgContext, String header, StringBuffer otherHeaders) {
    Object ck1 = msgContext.getProperty(header);
    if (ck1 != null)
      if (ck1 instanceof String[]) {
        String[] cookies = (String[])ck1;
        for (int i = 0; i < cookies.length; i++)
          addCookie(otherHeaders, header, cookies[i]); 
      } else {
        addCookie(otherHeaders, header, (String)ck1);
      }  
  }
  
  private void addCookie(StringBuffer otherHeaders, String header, String cookie) { otherHeaders.append(header).append(": ").append(cookie).append("\r\n"); }
  
  private InputStream readHeadersFromSocket(SocketHolder sockHolder, MessageContext msgContext, InputStream inp, Hashtable headers) throws IOException {
    byte b = 0;
    int len = 0;
    int colonIndex = -1;
    int returnCode = 0;
    if (null == inp)
      inp = new BufferedInputStream(sockHolder.getSocket().getInputStream()); 
    if (headers == null)
      headers = new Hashtable(); 
    boolean readTooMuch = false;
    ByteArrayOutputStream buf = new ByteArrayOutputStream(4097);
    while (true) {
      String value, name;
      if (!readTooMuch)
        b = (byte)inp.read(); 
      if (b == -1)
        break; 
      readTooMuch = false;
      if (b != 13 && b != 10) {
        if (b == 58 && colonIndex == -1)
          colonIndex = len; 
        len++;
        buf.write(b);
        continue;
      } 
      if (b == 13)
        continue; 
      if (len == 0)
        break; 
      b = (byte)inp.read();
      readTooMuch = true;
      if (b == 32 || b == 9)
        continue; 
      buf.close();
      byte[] hdata = buf.toByteArray();
      buf.reset();
      if (colonIndex != -1) {
        name = new String(hdata, 0, colonIndex, "iso-8859-1");
        value = new String(hdata, colonIndex + 1, len - 1 - colonIndex, "iso-8859-1");
        colonIndex = -1;
      } else {
        name = new String(hdata, 0, len, "iso-8859-1");
        value = "";
      } 
      if (log.isDebugEnabled())
        log.debug(name + value); 
      if (msgContext.getProperty(HTTPConstants.MC_HTTP_STATUS_CODE) == null) {
        int start = name.indexOf(' ') + 1;
        String tmp = name.substring(start).trim();
        int end = tmp.indexOf(' ');
        if (end != -1)
          tmp = tmp.substring(0, end); 
        returnCode = Integer.parseInt(tmp);
        msgContext.setProperty(HTTPConstants.MC_HTTP_STATUS_CODE, new Integer(returnCode));
        msgContext.setProperty(HTTPConstants.MC_HTTP_STATUS_MESSAGE, name.substring(start + end + 1));
      } else if (msgContext.getMaintainSession()) {
        String nameLowerCase = name.toLowerCase();
        if (nameLowerCase.equalsIgnoreCase("Set-Cookie")) {
          handleCookie("Cookie", null, value, msgContext);
        } else if (nameLowerCase.equalsIgnoreCase("Set-Cookie2")) {
          handleCookie("Cookie2", null, value, msgContext);
        } else {
          headers.put(name.toLowerCase(), value);
        } 
      } else {
        headers.put(name.toLowerCase(), value);
      } 
      len = 0;
    } 
    return inp;
  }
  
  private InputStream readFromSocket(SocketHolder socketHolder, MessageContext msgContext, InputStream inp, Hashtable headers) throws IOException {
    Message outMsg = null;
    Integer rc = (Integer)msgContext.getProperty(HTTPConstants.MC_HTTP_STATUS_CODE);
    int returnCode = 0;
    if (rc != null)
      returnCode = rc.intValue(); 
    String contentType = (String)headers.get(HEADER_CONTENT_TYPE_LC);
    contentType = (null == contentType) ? null : contentType.trim();
    String location = (String)headers.get(HEADER_LOCATION_LC);
    location = (null == location) ? null : location.trim();
    if (returnCode > 199 && returnCode < 300) {
      if (returnCode == 202)
        return inp; 
    } else if (msgContext.getSOAPConstants() != SOAPConstants.SOAP12_CONSTANTS) {
      if (contentType == null || contentType.startsWith("text/html") || returnCode <= 499 || returnCode >= 600) {
        if (location != null && (returnCode == 302 || returnCode == 307)) {
          inp.close();
          socketHolder.getSocket().close();
          msgContext.removeProperty(HTTPConstants.MC_HTTP_STATUS_CODE);
          msgContext.setProperty("transport.url", location);
          invoke(msgContext);
          return inp;
        } 
        if (returnCode == 100) {
          msgContext.removeProperty(HTTPConstants.MC_HTTP_STATUS_CODE);
          msgContext.removeProperty(HTTPConstants.MC_HTTP_STATUS_MESSAGE);
          readHeadersFromSocket(socketHolder, msgContext, inp, headers);
          return readFromSocket(socketHolder, msgContext, inp, headers);
        } 
        ByteArrayOutputStream buf = new ByteArrayOutputStream(4097);
        byte b;
        while (-1 != (b = (byte)inp.read()))
          buf.write(b); 
        String statusMessage = msgContext.getStrProp(HTTPConstants.MC_HTTP_STATUS_MESSAGE);
        AxisFault fault = new AxisFault("HTTP", "(" + returnCode + ")" + statusMessage, null, null);
        fault.setFaultDetailString(Messages.getMessage("return01", "" + returnCode, buf.toString()));
        fault.addFaultDetail(Constants.QNAME_FAULTDETAIL_HTTPERRORCODE, Integer.toString(returnCode));
        throw fault;
      } 
    } 
    String contentLocation = (String)headers.get(HEADER_CONTENT_LOCATION_LC);
    contentLocation = (null == contentLocation) ? null : contentLocation.trim();
    String contentLength = (String)headers.get(HEADER_CONTENT_LENGTH_LC);
    contentLength = (null == contentLength) ? null : contentLength.trim();
    String transferEncoding = (String)headers.get(HEADER_TRANSFER_ENCODING_LC);
    if (null != transferEncoding) {
      transferEncoding = transferEncoding.trim().toLowerCase();
      if (transferEncoding.equals(HTTPConstants.HEADER_TRANSFER_ENCODING_CHUNKED))
        inp = new ChunkedInputStream(inp); 
    } 
    outMsg = new Message(new SocketInputStream(inp, socketHolder.getSocket()), false, contentType, contentLocation);
    MimeHeaders mimeHeaders = outMsg.getMimeHeaders();
    for (Enumeration e = headers.keys(); e.hasMoreElements(); ) {
      String key = (String)e.nextElement();
      mimeHeaders.addHeader(key, ((String)headers.get(key)).trim());
    } 
    outMsg.setMessageType("response");
    msgContext.setResponseMessage(outMsg);
    if (log.isDebugEnabled()) {
      if (null == contentLength)
        log.debug("\n" + Messages.getMessage("no00", "Content-Length")); 
      log.debug("\n" + Messages.getMessage("xmlRecd00"));
      log.debug("-----------------------------------------------");
      log.debug(outMsg.getSOAPEnvelope().toString());
    } 
    return inp;
  }
  
  public void handleCookie(String cookieName, String setCookieName, String cookie, MessageContext msgContext) {
    cookie = cleanupCookie(cookie);
    int keyIndex = cookie.indexOf("=");
    String key = (keyIndex != -1) ? cookie.substring(0, keyIndex) : cookie;
    ArrayList cookies = new ArrayList();
    Object oldCookies = msgContext.getProperty(cookieName);
    boolean alreadyExist = false;
    if (oldCookies != null)
      if (oldCookies instanceof String[]) {
        String[] oldCookiesArray = (String[])oldCookies;
        for (int i = 0; i < oldCookiesArray.length; i++) {
          String anOldCookie = oldCookiesArray[i];
          if (key != null && anOldCookie.indexOf(key) == 0) {
            anOldCookie = cookie;
            alreadyExist = true;
          } 
          cookies.add(anOldCookie);
        } 
      } else {
        String oldCookie = (String)oldCookies;
        if (key != null && oldCookie.indexOf(key) == 0) {
          oldCookie = cookie;
          alreadyExist = true;
        } 
        cookies.add(oldCookie);
      }  
    if (!alreadyExist)
      cookies.add(cookie); 
    if (cookies.size() == 1) {
      msgContext.setProperty(cookieName, cookies.get(0));
    } else if (cookies.size() > 1) {
      msgContext.setProperty(cookieName, cookies.toArray(new String[cookies.size()]));
    } 
  }
  
  private String cleanupCookie(String cookie) {
    cookie = cookie.trim();
    int index = cookie.indexOf(';');
    if (index != -1)
      cookie = cookie.substring(0, index); 
    return cookie;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\HTTPSender.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */