package org.apache.axis.transport.http;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.axis.AxisFault;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.WSDDEngineConfiguration;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.deployment.wsdd.WSDDDeployment;
import org.apache.axis.deployment.wsdd.WSDDDocument;
import org.apache.axis.i18n.Messages;
import org.apache.axis.server.AxisServer;
import org.apache.axis.utils.XMLUtils;
import org.apache.commons.logging.Log;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class AutoRegisterServlet extends AxisServletBase {
  private static Log log = LogFactory.getLog(AutoRegisterServlet.class.getName());
  
  public void init() {
    log.debug(Messages.getMessage("autoRegServletInit00"));
    autoRegister();
  }
  
  public void registerStream(InputStream instream) throws SAXException, ParserConfigurationException, IOException {
    try {
      Document doc = XMLUtils.newDocument(instream);
      WSDDDocument wsddDoc = new WSDDDocument(doc);
      WSDDDeployment deployment = getDeployment();
      if (deployment != null)
        wsddDoc.deploy(deployment); 
    } finally {
      instream.close();
    } 
  }
  
  public void registerResource(String resourcename) throws SAXException, ParserConfigurationException, IOException {
    InputStream in = getServletContext().getResourceAsStream(resourcename);
    if (in == null)
      throw new FileNotFoundException(resourcename); 
    registerStream(in);
  }
  
  public void registerFile(File file) throws IOException, SAXException, ParserConfigurationException {
    InputStream in = new BufferedInputStream(new FileInputStream(file));
    registerStream(in);
  }
  
  public String[] getResourcesToRegister() { return null; }
  
  private WSDDDeployment getDeployment() throws AxisFault {
    WSDDDeployment deployment;
    AxisServer axisServer = getEngine();
    EngineConfiguration config = axisServer.getConfig();
    if (config instanceof WSDDEngineConfiguration) {
      deployment = ((WSDDEngineConfiguration)config).getDeployment();
    } else {
      deployment = null;
    } 
    return deployment;
  }
  
  protected void logSuccess(String item) throws SAXException, ParserConfigurationException, IOException { log.debug(Messages.getMessage("autoRegServletLoaded01", item)); }
  
  protected void autoRegister() {
    String[] resources = getResourcesToRegister();
    if (resources == null || resources.length == 0)
      return; 
    for (i = 0; i < resources.length; i++) {
      String resource = resources[i];
      registerAndLogResource(resource);
    } 
    registerAnythingElse();
    try {
      applyAndSaveSettings();
    } catch (Exception i) {
      Exception e;
      log.error(Messages.getMessage("autoRegServletApplyAndSaveSettings00"), e);
    } 
  }
  
  protected void registerAnythingElse() {}
  
  public void registerAndLogResource(String resource) throws SAXException, ParserConfigurationException, IOException {
    try {
      registerResource(resource);
      logSuccess(resource);
    } catch (Exception e) {
      log.error(Messages.getMessage("autoRegServletLoadFailed01", resource), e);
    } 
  }
  
  protected void applyAndSaveSettings() {
    AxisServer axisServer = getEngine();
    axisServer.refreshGlobalOptions();
    axisServer.saveConfiguration();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\AutoRegisterServlet.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */