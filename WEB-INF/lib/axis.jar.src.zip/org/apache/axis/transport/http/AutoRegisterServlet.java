/*     */ package org.apache.axis.transport.http;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.EngineConfiguration;
/*     */ import org.apache.axis.WSDDEngineConfiguration;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.deployment.wsdd.WSDDDeployment;
/*     */ import org.apache.axis.deployment.wsdd.WSDDDocument;
/*     */ import org.apache.axis.i18n.Messages;
/*     */ import org.apache.axis.server.AxisServer;
/*     */ import org.apache.axis.utils.XMLUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoRegisterServlet
/*     */   extends AxisServletBase
/*     */ {
/*  49 */   private static Log log = LogFactory.getLog(AutoRegisterServlet.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  56 */     log.debug(Messages.getMessage("autoRegServletInit00"));
/*  57 */     autoRegister();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerStream(InputStream instream) throws SAXException, ParserConfigurationException, IOException {
/*     */     try {
/*  69 */       Document doc = XMLUtils.newDocument(instream);
/*  70 */       WSDDDocument wsddDoc = new WSDDDocument(doc);
/*     */       
/*  72 */       WSDDDeployment deployment = getDeployment();
/*  73 */       if (deployment != null) {
/*  74 */         wsddDoc.deploy(deployment);
/*     */       }
/*     */     } finally {
/*  77 */       instream.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerResource(String resourcename) throws SAXException, ParserConfigurationException, IOException {
/*  90 */     InputStream in = getServletContext().getResourceAsStream(resourcename);
/*  91 */     if (in == null) {
/*  92 */       throw new FileNotFoundException(resourcename);
/*     */     }
/*  94 */     registerStream(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerFile(File file) throws IOException, SAXException, ParserConfigurationException {
/* 105 */     InputStream in = new BufferedInputStream(new FileInputStream(file));
/* 106 */     registerStream(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public String[] getResourcesToRegister() { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WSDDDeployment getDeployment() throws AxisFault {
/*     */     WSDDDeployment deployment;
/* 126 */     AxisServer axisServer = getEngine();
/* 127 */     EngineConfiguration config = axisServer.getConfig();
/* 128 */     if (config instanceof WSDDEngineConfiguration) {
/* 129 */       deployment = ((WSDDEngineConfiguration)config).getDeployment();
/*     */     } else {
/* 131 */       deployment = null;
/*     */     } 
/* 133 */     return deployment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   protected void logSuccess(String item) throws SAXException, ParserConfigurationException, IOException { log.debug(Messages.getMessage("autoRegServletLoaded01", item)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void autoRegister() {
/* 149 */     String[] resources = getResourcesToRegister();
/* 150 */     if (resources == null || resources.length == 0) {
/*     */       return;
/*     */     }
/* 153 */     for (i = 0; i < resources.length; i++) {
/* 154 */       String resource = resources[i];
/* 155 */       registerAndLogResource(resource);
/*     */     } 
/* 157 */     registerAnythingElse();
/*     */     try {
/* 159 */       applyAndSaveSettings();
/* 160 */     } catch (Exception i) {
/* 161 */       Exception e; log.error(Messages.getMessage("autoRegServletApplyAndSaveSettings00"), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerAnythingElse() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerAndLogResource(String resource) throws SAXException, ParserConfigurationException, IOException {
/*     */     try {
/* 177 */       registerResource(resource);
/* 178 */       logSuccess(resource);
/* 179 */     } catch (Exception e) {
/* 180 */       log.error(Messages.getMessage("autoRegServletLoadFailed01", resource), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyAndSaveSettings() {
/* 191 */     AxisServer axisServer = getEngine();
/* 192 */     axisServer.refreshGlobalOptions();
/* 193 */     axisServer.saveConfiguration();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\AutoRegisterServlet.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */