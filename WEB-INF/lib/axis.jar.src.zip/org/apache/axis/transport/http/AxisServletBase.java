package org.apache.axis.transport.http;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.axis.AxisFault;
import org.apache.axis.AxisProperties;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.configuration.EngineConfigurationFactoryFinder;
import org.apache.axis.server.AxisServer;
import org.apache.axis.utils.JavaUtils;
import org.apache.commons.logging.Log;

public class AxisServletBase extends HttpServlet {
  protected AxisServer axisServer = null;
  
  private static Log log = LogFactory.getLog(AxisServlet.class.getName());
  
  private static boolean isDebug = false;
  
  private static int loadCounter = 0;
  
  private static Object loadCounterLock = new Object();
  
  protected static final String ATTR_AXIS_ENGINE = "AxisEngine";
  
  private String webInfPath = null;
  
  private String homeDir = null;
  
  private boolean isDevelopment;
  
  private static final String INIT_PROPERTY_DEVELOPMENT_SYSTEM = "axis.development.system";
  
  public void init() {
    ServletContext context = getServletConfig().getServletContext();
    this.webInfPath = context.getRealPath("/WEB-INF");
    this.homeDir = context.getRealPath("/");
    isDebug = log.isDebugEnabled();
    if (log.isDebugEnabled())
      log.debug("In AxisServletBase init"); 
    this.isDevelopment = JavaUtils.isTrueExplicitly(getOption(context, "axis.development.system", null));
  }
  
  public void destroy() {
    super.destroy();
    if (this.axisServer != null)
      synchronized (this.axisServer) {
        if (this.axisServer != null) {
          this.axisServer.cleanup();
          this.axisServer = null;
          storeEngine(this, null);
        } 
      }  
  }
  
  public AxisServer getEngine() throws AxisFault {
    if (this.axisServer == null)
      this.axisServer = getEngine(this); 
    return this.axisServer;
  }
  
  public static AxisServer getEngine(HttpServlet servlet) throws AxisFault {
    AxisServer engine = null;
    if (isDebug)
      log.debug("Enter: getEngine()"); 
    ServletContext context = servlet.getServletContext();
    synchronized (context) {
      engine = retrieveEngine(servlet);
      if (engine == null) {
        Map environment = getEngineEnvironment(servlet);
        engine = AxisServer.getServer(environment);
        engine.setName(servlet.getServletName());
        storeEngine(servlet, engine);
      } 
    } 
    if (isDebug)
      log.debug("Exit: getEngine()"); 
    return engine;
  }
  
  private static void storeEngine(HttpServlet servlet, AxisServer engine) {
    ServletContext context = servlet.getServletContext();
    String axisServletName = servlet.getServletName();
    if (engine == null) {
      context.removeAttribute(axisServletName + "AxisEngine");
      AxisServer server = (AxisServer)context.getAttribute("AxisEngine");
      if (server != null && servlet.getServletName().equals(server.getName()))
        context.removeAttribute("AxisEngine"); 
    } else {
      if (context.getAttribute("AxisEngine") == null)
        context.setAttribute("AxisEngine", engine); 
      context.setAttribute(axisServletName + "AxisEngine", engine);
    } 
  }
  
  private static AxisServer retrieveEngine(HttpServlet servlet) throws AxisFault {
    Object contextObject = servlet.getServletContext().getAttribute(servlet.getServletName() + "AxisEngine");
    if (contextObject == null)
      contextObject = servlet.getServletContext().getAttribute("AxisEngine"); 
    if (contextObject instanceof AxisServer) {
      AxisServer server = (AxisServer)contextObject;
      if (server != null && servlet.getServletName().equals(server.getName()))
        return server; 
      return null;
    } 
    return null;
  }
  
  protected static Map getEngineEnvironment(HttpServlet servlet) {
    Map environment = new HashMap();
    String attdir = servlet.getInitParameter("axis.attachments.Directory");
    if (attdir != null)
      environment.put("axis.attachments.Directory", attdir); 
    ServletContext context = servlet.getServletContext();
    environment.put("servletContext", context);
    String webInfPath = context.getRealPath("/WEB-INF");
    if (webInfPath != null)
      environment.put("servlet.realpath", webInfPath + File.separator + "attachments"); 
    EngineConfiguration config = EngineConfigurationFactoryFinder.newFactory(servlet).getServerEngineConfig();
    if (config != null)
      environment.put("engineConfig", config); 
    return environment;
  }
  
  public static int getLoadCounter() { return loadCounter; }
  
  protected static void incLockCounter() {
    synchronized (loadCounterLock) {
      loadCounter++;
    } 
  }
  
  protected static void decLockCounter() {
    synchronized (loadCounterLock) {
      loadCounter--;
    } 
  }
  
  protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    incLockCounter();
    try {
      super.service(req, resp);
    } finally {
      decLockCounter();
    } 
  }
  
  protected String getWebappBase(HttpServletRequest request) {
    StringBuffer baseURL = new StringBuffer(128);
    baseURL.append(request.getScheme());
    baseURL.append("://");
    baseURL.append(request.getServerName());
    if (request.getServerPort() != 80) {
      baseURL.append(":");
      baseURL.append(request.getServerPort());
    } 
    baseURL.append(request.getContextPath());
    return baseURL.toString();
  }
  
  public ServletContext getServletContext() { return getServletConfig().getServletContext(); }
  
  protected String getWebInfPath() { return this.webInfPath; }
  
  protected String getHomeDir() { return this.homeDir; }
  
  protected String getOption(ServletContext context, String param, String dephault) {
    String value = AxisProperties.getProperty(param);
    if (value == null)
      value = getInitParameter(param); 
    if (value == null)
      value = context.getInitParameter(param); 
    try {
      AxisServer engine = getEngine(this);
      if (value == null && engine != null)
        value = (String)engine.getOption(param); 
    } catch (AxisFault axisFault) {}
    return (value != null) ? value : dephault;
  }
  
  public boolean isDevelopment() { return this.isDevelopment; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\AxisServletBase.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */