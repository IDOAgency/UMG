package org.apache.axis.transport.http;

import java.util.Enumeration;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import javax.xml.rpc.server.ServiceLifecycle;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class AxisHTTPSessionListener implements HttpSessionListener {
  protected static Log log = LogFactory.getLog(AxisHTTPSessionListener.class.getName());
  
  static void destroySession(HttpSession session) {
    if (session.getAttribute("axis.isAxisSession") == null)
      return; 
    if (log.isDebugEnabled())
      log.debug("Got destroySession event : " + session); 
    Enumeration e = session.getAttributeNames();
    while (e.hasMoreElements()) {
      Object next = e.nextElement();
      if (next instanceof ServiceLifecycle)
        ((ServiceLifecycle)next).destroy(); 
    } 
  }
  
  public void sessionCreated(HttpSessionEvent event) {}
  
  public void sessionDestroyed(HttpSessionEvent event) {
    HttpSession session = event.getSession();
    destroySession(session);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\AxisHTTPSessionListener.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */