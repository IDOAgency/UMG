package org.apache.axis.transport.http;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletResponse;

public class FilterPrintWriter extends PrintWriter {
  private PrintWriter _writer = null;
  
  private HttpServletResponse _response = null;
  
  private static OutputStream _sink = new NullOutputStream();
  
  public FilterPrintWriter(HttpServletResponse aResponse) {
    super(_sink);
    this._response = aResponse;
  }
  
  private PrintWriter getPrintWriter() {
    if (this._writer == null)
      try {
        this._writer = this._response.getWriter();
      } catch (IOException e) {
        throw new RuntimeException(e.toString());
      }  
    return this._writer;
  }
  
  public void write(int i) { getPrintWriter().write(i); }
  
  public void write(char[] chars) { getPrintWriter().write(chars); }
  
  public void write(char[] chars, int i, int i1) { getPrintWriter().write(chars, i, i1); }
  
  public void write(String string) { getPrintWriter().write(string); }
  
  public void write(String string, int i, int i1) { getPrintWriter().write(string, i, i1); }
  
  public void flush() { getPrintWriter().flush(); }
  
  public void close() { getPrintWriter().close(); }
  
  public boolean checkError() { return getPrintWriter().checkError(); }
  
  public void print(boolean b) { getPrintWriter().print(b); }
  
  public void print(char c) { getPrintWriter().print(c); }
  
  public void print(int i) { getPrintWriter().print(i); }
  
  public void print(long l) { getPrintWriter().print(l); }
  
  public void print(float v) { getPrintWriter().print(v); }
  
  public void print(double v) { getPrintWriter().print(v); }
  
  public void print(char[] chars) { getPrintWriter().print(chars); }
  
  public void print(String string) { getPrintWriter().print(string); }
  
  public void print(Object object) { getPrintWriter().print(object); }
  
  public void println() { getPrintWriter().println(); }
  
  public void println(boolean b) { getPrintWriter().println(b); }
  
  public void println(char c) { getPrintWriter().println(c); }
  
  public void println(int i) { getPrintWriter().println(i); }
  
  public void println(long l) { getPrintWriter().println(l); }
  
  public void println(float v) { getPrintWriter().println(v); }
  
  public void println(double v) { getPrintWriter().println(v); }
  
  public void println(char[] chars) { getPrintWriter().println(chars); }
  
  public void println(String string) { getPrintWriter().println(string); }
  
  public void println(Object object) { getPrintWriter().println(object); }
  
  public static class NullOutputStream extends OutputStream {
    public void write(int b) {}
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\FilterPrintWriter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */