/*     */ package org.apache.axis.transport.http;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterPrintWriter
/*     */   extends PrintWriter
/*     */ {
/*  36 */   private PrintWriter _writer = null;
/*  37 */   private HttpServletResponse _response = null;
/*  38 */   private static OutputStream _sink = new NullOutputStream();
/*     */   
/*     */   public FilterPrintWriter(HttpServletResponse aResponse) {
/*  41 */     super(_sink);
/*  42 */     this._response = aResponse;
/*     */   }
/*     */   
/*     */   private PrintWriter getPrintWriter() {
/*  46 */     if (this._writer == null) {
/*     */       try {
/*  48 */         this._writer = this._response.getWriter();
/*  49 */       } catch (IOException e) {
/*  50 */         throw new RuntimeException(e.toString());
/*     */       } 
/*     */     }
/*  53 */     return this._writer;
/*     */   }
/*     */ 
/*     */   
/*  57 */   public void write(int i) { getPrintWriter().write(i); }
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void write(char[] chars) { getPrintWriter().write(chars); }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void write(char[] chars, int i, int i1) { getPrintWriter().write(chars, i, i1); }
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void write(String string) { getPrintWriter().write(string); }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void write(String string, int i, int i1) { getPrintWriter().write(string, i, i1); }
/*     */ 
/*     */ 
/*     */   
/*  77 */   public void flush() { getPrintWriter().flush(); }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void close() { getPrintWriter().close(); }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public boolean checkError() { return getPrintWriter().checkError(); }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void print(boolean b) { getPrintWriter().print(b); }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public void print(char c) { getPrintWriter().print(c); }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void print(int i) { getPrintWriter().print(i); }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void print(long l) { getPrintWriter().print(l); }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void print(float v) { getPrintWriter().print(v); }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public void print(double v) { getPrintWriter().print(v); }
/*     */ 
/*     */ 
/*     */   
/* 113 */   public void print(char[] chars) { getPrintWriter().print(chars); }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void print(String string) { getPrintWriter().print(string); }
/*     */ 
/*     */ 
/*     */   
/* 121 */   public void print(Object object) { getPrintWriter().print(object); }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void println() { getPrintWriter().println(); }
/*     */ 
/*     */ 
/*     */   
/* 129 */   public void println(boolean b) { getPrintWriter().println(b); }
/*     */ 
/*     */ 
/*     */   
/* 133 */   public void println(char c) { getPrintWriter().println(c); }
/*     */ 
/*     */ 
/*     */   
/* 137 */   public void println(int i) { getPrintWriter().println(i); }
/*     */ 
/*     */ 
/*     */   
/* 141 */   public void println(long l) { getPrintWriter().println(l); }
/*     */ 
/*     */ 
/*     */   
/* 145 */   public void println(float v) { getPrintWriter().println(v); }
/*     */ 
/*     */ 
/*     */   
/* 149 */   public void println(double v) { getPrintWriter().println(v); }
/*     */ 
/*     */ 
/*     */   
/* 153 */   public void println(char[] chars) { getPrintWriter().println(chars); }
/*     */ 
/*     */ 
/*     */   
/* 157 */   public void println(String string) { getPrintWriter().println(string); }
/*     */ 
/*     */ 
/*     */   
/* 161 */   public void println(Object object) { getPrintWriter().println(object); }
/*     */   
/*     */   public static class NullOutputStream extends OutputStream {
/*     */     public void write(int b) {}
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\FilterPrintWriter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */