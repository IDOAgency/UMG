package org.apache.axis.transport.http;

import org.apache.axis.AxisEngine;
import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.client.Call;
import org.apache.axis.client.Transport;

public class HTTPTransport extends Transport {
  public static final String DEFAULT_TRANSPORT_NAME = "http";
  
  public static final String URL = "transport.url";
  
  private Object cookie;
  
  private Object cookie2;
  
  private String action;
  
  public HTTPTransport() { this.transportName = "http"; }
  
  public HTTPTransport(String url, String action) {
    this.transportName = "http";
    this.url = url;
    this.action = action;
  }
  
  public void setupMessageContextImpl(MessageContext mc, Call call, AxisEngine engine) throws AxisFault {
    if (this.action != null) {
      mc.setUseSOAPAction(true);
      mc.setSOAPActionURI(this.action);
    } 
    if (this.cookie != null)
      mc.setProperty("Cookie", this.cookie); 
    if (this.cookie2 != null)
      mc.setProperty("Cookie2", this.cookie2); 
    if (mc.getService() == null)
      mc.setTargetService(mc.getSOAPActionURI()); 
  }
  
  public void processReturnedMessageContext(MessageContext context) {
    this.cookie = context.getProperty("Cookie");
    this.cookie2 = context.getProperty("Cookie2");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\HTTPTransport.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */