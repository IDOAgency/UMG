/*    */ package org.apache.axis.transport.http;
/*    */ 
/*    */ import org.apache.axis.AxisEngine;
/*    */ import org.apache.axis.AxisFault;
/*    */ import org.apache.axis.MessageContext;
/*    */ import org.apache.axis.client.Call;
/*    */ import org.apache.axis.client.Transport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HTTPTransport
/*    */   extends Transport
/*    */ {
/*    */   public static final String DEFAULT_TRANSPORT_NAME = "http";
/*    */   public static final String URL = "transport.url";
/*    */   private Object cookie;
/*    */   private Object cookie2;
/*    */   private String action;
/*    */   
/* 49 */   public HTTPTransport() { this.transportName = "http"; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HTTPTransport(String url, String action) {
/* 57 */     this.transportName = "http";
/* 58 */     this.url = url;
/* 59 */     this.action = action;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setupMessageContextImpl(MessageContext mc, Call call, AxisEngine engine) throws AxisFault {
/* 74 */     if (this.action != null) {
/* 75 */       mc.setUseSOAPAction(true);
/* 76 */       mc.setSOAPActionURI(this.action);
/*    */     } 
/*    */ 
/*    */     
/* 80 */     if (this.cookie != null)
/* 81 */       mc.setProperty("Cookie", this.cookie); 
/* 82 */     if (this.cookie2 != null) {
/* 83 */       mc.setProperty("Cookie2", this.cookie2);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 88 */     if (mc.getService() == null) {
/* 89 */       mc.setTargetService(mc.getSOAPActionURI());
/*    */     }
/*    */   }
/*    */   
/*    */   public void processReturnedMessageContext(MessageContext context) {
/* 94 */     this.cookie = context.getProperty("Cookie");
/* 95 */     this.cookie2 = context.getProperty("Cookie2");
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\HTTPTransport.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */