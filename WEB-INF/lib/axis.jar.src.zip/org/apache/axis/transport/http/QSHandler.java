package org.apache.axis.transport.http;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;

public interface QSHandler {
  void invoke(MessageContext paramMessageContext) throws AxisFault;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\http\QSHandler.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */