package org.apache.axis.transport.local;

import org.apache.axis.AxisFault;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.handlers.BasicHandler;
import org.apache.commons.logging.Log;

public class LocalResponder extends BasicHandler {
  protected static Log log = LogFactory.getLog(LocalResponder.class.getName());
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug("Enter: LocalResponder::invoke"); 
    String msgStr = msgContext.getResponseMessage().getSOAPPartAsString();
    if (log.isDebugEnabled()) {
      log.debug(msgStr);
      log.debug("Exit: LocalResponder::invoke");
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\local\LocalResponder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */