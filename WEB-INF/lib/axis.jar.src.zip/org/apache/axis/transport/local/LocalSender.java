package org.apache.axis.transport.local;

import java.net.URL;
import org.apache.axis.AxisFault;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.attachments.Attachments;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.handlers.BasicHandler;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.message.SOAPFault;
import org.apache.axis.server.AxisServer;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class LocalSender extends BasicHandler {
  protected static Log log = LogFactory.getLog(LocalSender.class.getName());
  
  public void init() { this.server = new AxisServer(); }
  
  public void invoke(MessageContext clientContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug("Enter: LocalSender::invoke"); 
    AxisServer targetServer = (AxisServer)clientContext.getProperty("LocalTransport.AxisServer");
    if (log.isDebugEnabled())
      log.debug(Messages.getMessage("usingServer00", "LocalSender", "" + targetServer)); 
    if (targetServer == null) {
      if (this.server == null)
        init(); 
      targetServer = this.server;
    } 
    MessageContext serverContext = new MessageContext(targetServer);
    Message clientRequest = clientContext.getRequestMessage();
    String msgStr = clientRequest.getSOAPPartAsString();
    if (log.isDebugEnabled()) {
      log.debug(Messages.getMessage("sendingXML00", "LocalSender"));
      log.debug(msgStr);
    } 
    Message serverRequest = new Message(msgStr);
    Attachments serverAttachments = serverRequest.getAttachmentsImpl();
    Attachments clientAttachments = clientRequest.getAttachmentsImpl();
    if (null != clientAttachments && null != serverAttachments)
      serverAttachments.setAttachmentParts(clientAttachments.getAttachments()); 
    serverContext.setRequestMessage(serverRequest);
    serverContext.setTransportName("local");
    String user = clientContext.getUsername();
    if (user != null) {
      serverContext.setUsername(user);
      String pass = clientContext.getPassword();
      if (pass != null)
        serverContext.setPassword(pass); 
    } 
    String transURL = clientContext.getStrProp("transport.url");
    if (transURL != null)
      try {
        URL url = new URL(transURL);
        String file = url.getFile();
        if (file.length() > 0 && file.charAt(0) == '/')
          file = file.substring(1); 
        serverContext.setProperty("realpath", file);
        serverContext.setProperty("transport.url", "local:///" + file);
        serverContext.setTargetService(file);
      } catch (Exception e) {
        throw AxisFault.makeFault(e);
      }  
    String remoteService = clientContext.getStrProp("LocalTransport.RemoteService");
    if (remoteService != null)
      serverContext.setTargetService(remoteService); 
    try {
      targetServer.invoke(serverContext);
    } catch (AxisFault fault) {
      Message respMsg = serverContext.getResponseMessage();
      if (respMsg == null) {
        respMsg = new Message(fault);
        serverContext.setResponseMessage(respMsg);
      } else {
        SOAPFault faultEl = new SOAPFault(fault);
        SOAPEnvelope env = respMsg.getSOAPEnvelope();
        env.clearBody();
        env.addBodyElement(faultEl);
      } 
    } 
    clientContext.setResponseMessage(serverContext.getResponseMessage());
    clientContext.getResponseMessage().getSOAPPartAsString();
    if (log.isDebugEnabled())
      log.debug("Exit: LocalSender::invoke"); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\transport\local\LocalSender.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */