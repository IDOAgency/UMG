package org.apache.axis.constants;

import java.io.ObjectStreamException;
import org.apache.axis.Constants;

public class Use extends Enum {
  private static final Type type = new Type(null);
  
  public static final String ENCODED_STR = "encoded";
  
  public static final String LITERAL_STR = "literal";
  
  public static final Use ENCODED = type.getUse("encoded");
  
  public static final Use LITERAL = type.getUse("literal");
  
  public static final Use DEFAULT = ENCODED;
  
  private String encoding;
  
  static  {
    type.setDefault(DEFAULT);
  }
  
  public static Use getDefault() { return (Use)type.getDefault(); }
  
  public final String getEncoding() { return this.encoding; }
  
  public static final Use getUse(int style) { return type.getUse(style); }
  
  public static final Use getUse(String style) { return type.getUse(style); }
  
  public static final Use getUse(String style, Use dephault) { return type.getUse(style, dephault); }
  
  public static final boolean isValid(String style) { return type.isValid(style); }
  
  public static final int size() { return type.size(); }
  
  public static final String[] getUses() { return type.getEnumNames(); }
  
  private Object readResolve() throws ObjectStreamException { return type.getUse(this.value); }
  
  public static class Type extends Enum.Type {
    private Type() { super("style", new Enum[] { new Use(0, "encoded", Constants.URI_DEFAULT_SOAP_ENC, null), new Use(1, "literal", "", null) }); }
    
    public final Use getUse(int style) { return (Use)getEnum(style); }
    
    public final Use getUse(String style) { return (Use)getEnum(style); }
    
    public final Use getUse(String style, Use dephault) { return (Use)getEnum(style, dephault); }
  }
  
  private Use(int value, String name, String encoding) {
    super(type, value, name);
    this.encoding = encoding;
  }
  
  protected Use() {
    super(type, DEFAULT.getValue(), DEFAULT.getName());
    this.encoding = DEFAULT.getEncoding();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\constants\Use.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */