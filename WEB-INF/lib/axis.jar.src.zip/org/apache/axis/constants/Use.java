/*     */ package org.apache.axis.constants;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import org.apache.axis.Constants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Use
/*     */   extends Enum
/*     */ {
/*  33 */   private static final Type type = new Type(null);
/*     */   
/*     */   public static final String ENCODED_STR = "encoded";
/*     */   
/*     */   public static final String LITERAL_STR = "literal";
/*  38 */   public static final Use ENCODED = type.getUse("encoded");
/*  39 */   public static final Use LITERAL = type.getUse("literal");
/*     */   
/*  41 */   public static final Use DEFAULT = ENCODED;
/*     */   static  {
/*  43 */     type.setDefault(DEFAULT);
/*     */   }
/*     */   private String encoding;
/*  46 */   public static Use getDefault() { return (Use)type.getDefault(); }
/*     */   
/*  48 */   public final String getEncoding() { return this.encoding; }
/*     */ 
/*     */   
/*  51 */   public static final Use getUse(int style) { return type.getUse(style); }
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final Use getUse(String style) { return type.getUse(style); }
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final Use getUse(String style, Use dephault) { return type.getUse(style, dephault); }
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final boolean isValid(String style) { return type.isValid(style); }
/*     */ 
/*     */ 
/*     */   
/*  67 */   public static final int size() { return type.size(); }
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final String[] getUses() { return type.getEnumNames(); }
/*     */ 
/*     */ 
/*     */   
/*  75 */   private Object readResolve() throws ObjectStreamException { return type.getUse(this.value); }
/*     */   
/*     */   public static class Type
/*     */     extends Enum.Type
/*     */   {
/*  80 */     private Type() { super("style", new Enum[] { new Use(0, "encoded", Constants.URI_DEFAULT_SOAP_ENC, null), new Use(1, "literal", "", null) }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     public final Use getUse(int style) { return (Use)getEnum(style); }
/*     */ 
/*     */ 
/*     */     
/*  93 */     public final Use getUse(String style) { return (Use)getEnum(style); }
/*     */ 
/*     */ 
/*     */     
/*  97 */     public final Use getUse(String style, Use dephault) { return (Use)getEnum(style, dephault); }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Use(int value, String name, String encoding) {
/* 103 */     super(type, value, name);
/* 104 */     this.encoding = encoding;
/*     */   }
/*     */   
/*     */   protected Use() {
/* 108 */     super(type, DEFAULT.getValue(), DEFAULT.getName());
/* 109 */     this.encoding = DEFAULT.getEncoding();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\constants\Use.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */