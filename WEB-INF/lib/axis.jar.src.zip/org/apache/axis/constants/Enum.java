/*     */ package org.apache.axis.constants;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Hashtable;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.utils.Messages;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Enum
/*     */   implements Serializable
/*     */ {
/*  33 */   private static final Hashtable types = new Hashtable(13);
/*     */   
/*  35 */   protected static Log log = LogFactory.getLog(Enum.class.getName());
/*     */   
/*     */   private final Type type;
/*     */   
/*     */   public final int value;
/*     */   public final String name;
/*     */   
/*     */   protected Enum(Type type, int value, String name) {
/*  43 */     this.type = type;
/*  44 */     this.value = value;
/*  45 */     this.name = name.intern();
/*     */   }
/*     */   
/*  48 */   public final int getValue() { return this.value; }
/*  49 */   public final String getName() { return this.name; }
/*  50 */   public final Type getType() { return this.type; }
/*     */ 
/*     */   
/*  53 */   public String toString() { return this.name; }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public final boolean equals(Object obj) { return (obj != null && obj instanceof Enum) ? _equals((Enum)obj) : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public int hashCode() { return this.value; }
/*     */ 
/*     */ 
/*     */   
/*  67 */   public final boolean equals(Enum obj) { return (obj != null) ? _equals(obj) : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private final boolean _equals(Enum obj) { return (obj.type == this.type && obj.value == this.value); }
/*     */   
/*     */   public static abstract class Type implements Serializable {
/*     */     private final String name;
/*     */     private final Enum[] enums;
/*     */     private Enum dephault;
/*     */     
/*     */     protected Type(String name, Enum[] enums) {
/*  85 */       this.dephault = null;
/*     */ 
/*     */       
/*  88 */       this.name = name.intern();
/*  89 */       this.enums = enums;
/*  90 */       synchronized (types) {
/*  91 */         types.put(name, this);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  96 */     public void setDefault(Enum dephault) { this.dephault = dephault; }
/*     */ 
/*     */ 
/*     */     
/* 100 */     public Enum getDefault() { return this.dephault; }
/*     */ 
/*     */ 
/*     */     
/* 104 */     public final String getName() { return this.name; }
/*     */ 
/*     */     
/*     */     public final boolean isValid(String enumName) {
/* 108 */       for (int enumElt = 0; enumElt < this.enums.length; enumElt++) {
/* 109 */         if (this.enums[enumElt].getName().equalsIgnoreCase(enumName)) {
/* 110 */           return true;
/*     */         }
/*     */       } 
/* 113 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 117 */     public final int size() { return this.enums.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final String[] getEnumNames() {
/* 124 */       String[] nms = new String[size()];
/*     */       
/* 126 */       for (int idx = 0; idx < this.enums.length; idx++) {
/* 127 */         nms[idx] = this.enums[idx].getName();
/*     */       }
/* 129 */       return nms;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     public final Enum getEnum(int enumElt) { return (enumElt >= 0 && enumElt < this.enums.length) ? this.enums[enumElt] : null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Enum getEnum(String enumName) {
/* 143 */       Enum e = getEnum(enumName, null);
/*     */       
/* 145 */       if (e == null) {
/* 146 */         Enum.log.error(Messages.getMessage("badEnum02", this.name, enumName));
/*     */       }
/*     */       
/* 149 */       return e;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Enum getEnum(String enumName, Enum dephault) {
/* 160 */       if (enumName != null && enumName.length() > 0) {
/* 161 */         for (int enumElt = 0; enumElt < this.enums.length; enumElt++) {
/* 162 */           Enum e = this.enums[enumElt];
/* 163 */           if (e.getName().equalsIgnoreCase(enumName)) {
/* 164 */             return e;
/*     */           }
/*     */         } 
/*     */       }
/* 168 */       return dephault;
/*     */     }
/*     */     
/*     */     private Object readResolve() throws ObjectStreamException {
/* 172 */       Object type = types.get(this.name);
/* 173 */       if (type == null) {
/* 174 */         type = this;
/* 175 */         types.put(this.name, type);
/*     */       } 
/* 177 */       return type;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\constants\Enum.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */