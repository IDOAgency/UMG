package org.apache.axis.constants;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Hashtable;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public abstract class Enum implements Serializable {
  private static final Hashtable types = new Hashtable(13);
  
  protected static Log log = LogFactory.getLog(Enum.class.getName());
  
  private final Type type;
  
  public final int value;
  
  public final String name;
  
  protected Enum(Type type, int value, String name) {
    this.type = type;
    this.value = value;
    this.name = name.intern();
  }
  
  public final int getValue() { return this.value; }
  
  public final String getName() { return this.name; }
  
  public final Type getType() { return this.type; }
  
  public String toString() { return this.name; }
  
  public final boolean equals(Object obj) { return (obj != null && obj instanceof Enum) ? _equals((Enum)obj) : 0; }
  
  public int hashCode() { return this.value; }
  
  public final boolean equals(Enum obj) { return (obj != null) ? _equals(obj) : 0; }
  
  private final boolean _equals(Enum obj) { return (obj.type == this.type && obj.value == this.value); }
  
  public static abstract class Type implements Serializable {
    private final String name;
    
    private final Enum[] enums;
    
    private Enum dephault;
    
    protected Type(String name, Enum[] enums) {
      this.dephault = null;
      this.name = name.intern();
      this.enums = enums;
      synchronized (types) {
        types.put(name, this);
      } 
    }
    
    public void setDefault(Enum dephault) { this.dephault = dephault; }
    
    public Enum getDefault() { return this.dephault; }
    
    public final String getName() { return this.name; }
    
    public final boolean isValid(String enumName) {
      for (int enumElt = 0; enumElt < this.enums.length; enumElt++) {
        if (this.enums[enumElt].getName().equalsIgnoreCase(enumName))
          return true; 
      } 
      return false;
    }
    
    public final int size() { return this.enums.length; }
    
    public final String[] getEnumNames() {
      String[] nms = new String[size()];
      for (int idx = 0; idx < this.enums.length; idx++)
        nms[idx] = this.enums[idx].getName(); 
      return nms;
    }
    
    public final Enum getEnum(int enumElt) { return (enumElt >= 0 && enumElt < this.enums.length) ? this.enums[enumElt] : null; }
    
    public final Enum getEnum(String enumName) {
      Enum e = getEnum(enumName, null);
      if (e == null)
        Enum.log.error(Messages.getMessage("badEnum02", this.name, enumName)); 
      return e;
    }
    
    public final Enum getEnum(String enumName, Enum dephault) {
      if (enumName != null && enumName.length() > 0)
        for (int enumElt = 0; enumElt < this.enums.length; enumElt++) {
          Enum e = this.enums[enumElt];
          if (e.getName().equalsIgnoreCase(enumName))
            return e; 
        }  
      return dephault;
    }
    
    private Object readResolve() throws ObjectStreamException {
      Object type = types.get(this.name);
      if (type == null) {
        type = this;
        types.put(this.name, type);
      } 
      return type;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\constants\Enum.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */