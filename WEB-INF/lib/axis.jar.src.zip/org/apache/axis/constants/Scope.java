/*     */ package org.apache.axis.constants;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Scope
/*     */   extends Enum
/*     */ {
/*  26 */   private static final Type type = new Type(null);
/*     */   
/*     */   public static final String REQUEST_STR = "Request";
/*     */   
/*     */   public static final String APPLICATION_STR = "Application";
/*     */   public static final String SESSION_STR = "Session";
/*     */   public static final String FACTORY_STR = "Factory";
/*  33 */   public static final Scope REQUEST = type.getScope("Request");
/*  34 */   public static final Scope APPLICATION = type.getScope("Application");
/*  35 */   public static final Scope SESSION = type.getScope("Session");
/*  36 */   public static final Scope FACTORY = type.getScope("Factory");
/*     */   
/*  38 */   public static final Scope DEFAULT = REQUEST;
/*     */   static  {
/*  40 */     type.setDefault(DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static Scope getDefault() { return (Scope)type.getDefault(); }
/*     */ 
/*     */   
/*  49 */   public static final Scope getScope(int scope) { return type.getScope(scope); }
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final Scope getScope(String scope) { return type.getScope(scope); }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final Scope getScope(String scope, Scope dephault) { return type.getScope(scope, dephault); }
/*     */ 
/*     */ 
/*     */   
/*  61 */   public static final boolean isValid(String scope) { return type.isValid(scope); }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final int size() { return type.size(); }
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static final String[] getScopes() { return type.getEnumNames(); }
/*     */ 
/*     */ 
/*     */   
/*  73 */   private Object readResolve() throws ObjectStreamException { return type.getScope(this.value); }
/*     */   
/*     */   public static class Type
/*     */     extends Enum.Type {
/*  77 */     private Type() { super("scope", new Enum[] { new Scope(0, "Request", null), new Scope(1, "Application", null), new Scope(2, "Session", null), new Scope(3, "Factory", null) }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     public final Scope getScope(int scope) { return (Scope)getEnum(scope); }
/*     */ 
/*     */ 
/*     */     
/*  90 */     public final Scope getScope(String scope) { return (Scope)getEnum(scope); }
/*     */ 
/*     */ 
/*     */     
/*  94 */     public final Scope getScope(String scope, Scope dephault) { return (Scope)getEnum(scope, dephault); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private Scope(int value, String name) { super(type, value, name); }
/*     */ 
/*     */ 
/*     */   
/* 104 */   protected Scope() { super(type, DEFAULT.getValue(), DEFAULT.getName()); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\constants\Scope.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */