/*     */ package org.apache.axis.constants;
/*     */ 
/*     */ import java.io.ObjectStreamException;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.deployment.wsdd.WSDDConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Style
/*     */   extends Enum
/*     */ {
/*  83 */   private static final Type type = new Type(null);
/*     */   
/*     */   public static final String RPC_STR = "rpc";
/*     */   
/*     */   public static final String DOCUMENT_STR = "document";
/*     */   
/*     */   public static final String WRAPPED_STR = "wrapped";
/*     */   public static final String MESSAGE_STR = "message";
/*  91 */   public static final Style RPC = type.getStyle("rpc");
/*  92 */   public static final Style DOCUMENT = type.getStyle("document");
/*  93 */   public static final Style WRAPPED = type.getStyle("wrapped");
/*  94 */   public static final Style MESSAGE = type.getStyle("message");
/*     */   
/*  96 */   public static final Style DEFAULT = RPC;
/*     */   static  {
/*  98 */     type.setDefault(DEFAULT);
/*     */   }
/*     */   
/*     */   private QName provider;
/*     */   
/* 103 */   public static Style getDefault() { return (Style)type.getDefault(); }
/*     */   
/* 105 */   public final QName getProvider() { return this.provider; }
/*     */ 
/*     */   
/* 108 */   public static final Style getStyle(int style) { return type.getStyle(style); }
/*     */ 
/*     */ 
/*     */   
/* 112 */   public static final Style getStyle(String style) { return type.getStyle(style); }
/*     */ 
/*     */ 
/*     */   
/* 116 */   public static final Style getStyle(String style, Style dephault) { return type.getStyle(style, dephault); }
/*     */ 
/*     */ 
/*     */   
/* 120 */   public static final boolean isValid(String style) { return type.isValid(style); }
/*     */ 
/*     */ 
/*     */   
/* 124 */   public static final int size() { return type.size(); }
/*     */ 
/*     */ 
/*     */   
/* 128 */   public static final String[] getStyles() { return type.getEnumNames(); }
/*     */ 
/*     */ 
/*     */   
/* 132 */   private Object readResolve() throws ObjectStreamException { return type.getStyle(this.value); }
/*     */   
/*     */   public static class Type
/*     */     extends Enum.Type
/*     */   {
/* 137 */     private Type() { super("style", new Enum[] { new Style(0, "rpc", WSDDConstants.QNAME_JAVARPC_PROVIDER, null), new Style(1, "document", WSDDConstants.QNAME_JAVARPC_PROVIDER, null), new Style(2, "wrapped", WSDDConstants.QNAME_JAVARPC_PROVIDER, null), new Style(3, "message", WSDDConstants.QNAME_JAVAMSG_PROVIDER, null) }); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     public final Style getStyle(int style) { return (Style)getEnum(style); }
/*     */ 
/*     */ 
/*     */     
/* 154 */     public final Style getStyle(String style) { return (Style)getEnum(style); }
/*     */ 
/*     */ 
/*     */     
/* 158 */     public final Style getStyle(String style, Style dephault) { return (Style)getEnum(style, dephault); }
/*     */   }
/*     */ 
/*     */   
/*     */   private Style(int value, String name, QName provider) {
/* 163 */     super(type, value, name);
/* 164 */     this.provider = provider;
/*     */   }
/*     */   
/*     */   protected Style() {
/* 168 */     super(type, DEFAULT.getValue(), DEFAULT.getName());
/* 169 */     this.provider = DEFAULT.getProvider();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\constants\Style.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */