package org.apache.axis.constants;

import java.io.ObjectStreamException;
import javax.xml.namespace.QName;
import org.apache.axis.deployment.wsdd.WSDDConstants;

public class Style extends Enum {
  private static final Type type = new Type(null);
  
  public static final String RPC_STR = "rpc";
  
  public static final String DOCUMENT_STR = "document";
  
  public static final String WRAPPED_STR = "wrapped";
  
  public static final String MESSAGE_STR = "message";
  
  public static final Style RPC = type.getStyle("rpc");
  
  public static final Style DOCUMENT = type.getStyle("document");
  
  public static final Style WRAPPED = type.getStyle("wrapped");
  
  public static final Style MESSAGE = type.getStyle("message");
  
  public static final Style DEFAULT = RPC;
  
  private QName provider;
  
  static  {
    type.setDefault(DEFAULT);
  }
  
  public static Style getDefault() { return (Style)type.getDefault(); }
  
  public final QName getProvider() { return this.provider; }
  
  public static final Style getStyle(int style) { return type.getStyle(style); }
  
  public static final Style getStyle(String style) { return type.getStyle(style); }
  
  public static final Style getStyle(String style, Style dephault) { return type.getStyle(style, dephault); }
  
  public static final boolean isValid(String style) { return type.isValid(style); }
  
  public static final int size() { return type.size(); }
  
  public static final String[] getStyles() { return type.getEnumNames(); }
  
  private Object readResolve() throws ObjectStreamException { return type.getStyle(this.value); }
  
  public static class Type extends Enum.Type {
    private Type() { super("style", new Enum[] { new Style(0, "rpc", WSDDConstants.QNAME_JAVARPC_PROVIDER, null), new Style(1, "document", WSDDConstants.QNAME_JAVARPC_PROVIDER, null), new Style(2, "wrapped", WSDDConstants.QNAME_JAVARPC_PROVIDER, null), new Style(3, "message", WSDDConstants.QNAME_JAVAMSG_PROVIDER, null) }); }
    
    public final Style getStyle(int style) { return (Style)getEnum(style); }
    
    public final Style getStyle(String style) { return (Style)getEnum(style); }
    
    public final Style getStyle(String style, Style dephault) { return (Style)getEnum(style, dephault); }
  }
  
  private Style(int value, String name, QName provider) {
    super(type, value, name);
    this.provider = provider;
  }
  
  protected Style() {
    super(type, DEFAULT.getValue(), DEFAULT.getName());
    this.provider = DEFAULT.getProvider();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\constants\Style.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */