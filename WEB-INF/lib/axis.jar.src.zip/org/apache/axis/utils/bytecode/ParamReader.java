package org.apache.axis.utils.bytecode;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import org.apache.axis.utils.Messages;

public class ParamReader extends ClassReader {
  private String methodName;
  
  private Map methods = new HashMap();
  
  private Class[] paramTypes;
  
  public ParamReader(Class c) throws IOException { this(getBytes(c)); }
  
  public ParamReader(byte[] b) throws IOException {
    super(b, findAttributeReaders(ParamReader.class));
    if (readInt() != -889275714)
      throw new IOException(Messages.getMessage("badClassFile00")); 
    readShort();
    readShort();
    readCpool();
    readShort();
    readShort();
    readShort();
    int count = readShort();
    for (int i = 0; i < count; i++)
      readShort(); 
    count = readShort();
    for (int i = 0; i < count; i++) {
      readShort();
      readShort();
      readShort();
      skipAttributes();
    } 
    count = readShort();
    for (int i = 0; i < count; i++) {
      readShort();
      int m = readShort();
      String name = resolveUtf8(m);
      int d = readShort();
      this.methodName = name + resolveUtf8(d);
      readAttributes();
    } 
  }
  
  public void readCode() throws IOException {
    readShort();
    int maxLocals = readShort();
    MethodInfo info = new MethodInfo(maxLocals);
    if (this.methods != null && this.methodName != null)
      this.methods.put(this.methodName, info); 
    skipFully(readInt());
    skipFully(8 * readShort());
    readAttributes();
  }
  
  public String[] getParameterNames(Constructor ctor) {
    this.paramTypes = ctor.getParameterTypes();
    return getParameterNames(ctor, this.paramTypes);
  }
  
  public String[] getParameterNames(Method method) {
    this.paramTypes = method.getParameterTypes();
    return getParameterNames(method, this.paramTypes);
  }
  
  protected String[] getParameterNames(Member member, Class[] paramTypes) {
    MethodInfo info = (MethodInfo)this.methods.get(getSignature(member, paramTypes));
    if (info != null) {
      String[] paramNames = new String[paramTypes.length];
      int j = Modifier.isStatic(member.getModifiers()) ? 0 : 1;
      boolean found = false;
      for (int i = 0; i < paramNames.length; i++) {
        if (info.names[j] != null) {
          found = true;
          paramNames[i] = info.names[j];
        } 
        j++;
        if (paramTypes[i] == double.class || paramTypes[i] == long.class)
          j++; 
      } 
      if (found)
        return paramNames; 
      return null;
    } 
    return null;
  }
  
  private static class MethodInfo {
    String[] names;
    
    int maxLocals;
    
    public MethodInfo(int maxLocals) {
      this.maxLocals = maxLocals;
      this.names = new String[maxLocals];
    }
  }
  
  private MethodInfo getMethodInfo() {
    MethodInfo info = null;
    if (this.methods != null && this.methodName != null)
      info = (MethodInfo)this.methods.get(this.methodName); 
    return info;
  }
  
  public void readLocalVariableTable() throws IOException {
    int len = readShort();
    MethodInfo info = getMethodInfo();
    for (int j = 0; j < len; j++) {
      readShort();
      readShort();
      int nameIndex = readShort();
      readShort();
      int index = readShort();
      if (info != null)
        info.names[index] = resolveUtf8(nameIndex); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axi\\utils\bytecode\ParamReader.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */