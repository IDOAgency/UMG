package org.apache.axis.utils.bytecode;

import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class ParamNameExtractor {
  protected static Log log = LogFactory.getLog(ParamNameExtractor.class.getName());
  
  public static String[] getParameterNamesFromDebugInfo(Method method) {
    int numParams = method.getParameterTypes().length;
    if (numParams == 0)
      return null; 
    Class c = method.getDeclaringClass();
    if (Proxy.isProxyClass(c))
      return null; 
    try {
      ParamReader pr = new ParamReader(c);
      return pr.getParameterNames(method);
    } catch (IOException e) {
      log.info(Messages.getMessage("error00") + ":" + e);
      return null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axi\\utils\bytecode\ParamNameExtractor.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */