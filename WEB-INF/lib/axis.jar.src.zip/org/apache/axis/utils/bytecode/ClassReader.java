package org.apache.axis.utils.bytecode;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import org.apache.axis.utils.Messages;

public class ClassReader extends ByteArrayInputStream {
  private static final int CONSTANT_Class = 7;
  
  private static final int CONSTANT_Fieldref = 9;
  
  private static final int CONSTANT_Methodref = 10;
  
  private static final int CONSTANT_InterfaceMethodref = 11;
  
  private static final int CONSTANT_String = 8;
  
  private static final int CONSTANT_Integer = 3;
  
  private static final int CONSTANT_Float = 4;
  
  private static final int CONSTANT_Long = 5;
  
  private static final int CONSTANT_Double = 6;
  
  private static final int CONSTANT_NameAndType = 12;
  
  private static final int CONSTANT_Utf8 = 1;
  
  private int[] cpoolIndex;
  
  private Object[] cpool;
  
  private Map attrMethods;
  
  protected static byte[] getBytes(Class c) throws IOException {
    fin = c.getResourceAsStream('/' + c.getName().replace('.', '/') + ".class");
    if (fin == null)
      throw new IOException(Messages.getMessage("cantLoadByecode", c.getName())); 
    try {
      int actual;
      ByteArrayOutputStream out = new ByteArrayOutputStream();
      byte[] buf = new byte[1024];
      do {
        actual = fin.read(buf);
        if (actual <= 0)
          continue; 
        out.write(buf, 0, actual);
      } while (actual > 0);
      return out.toByteArray();
    } finally {
      fin.close();
    } 
  }
  
  static String classDescriptorToName(String desc) { return desc.replace('/', '.'); }
  
  protected static Map findAttributeReaders(Class c) {
    HashMap map = new HashMap();
    Method[] methods = c.getMethods();
    for (int i = 0; i < methods.length; i++) {
      String name = methods[i].getName();
      if (name.startsWith("read") && methods[i].getReturnType() == void.class)
        map.put(name.substring(4), methods[i]); 
    } 
    return map;
  }
  
  protected static String getSignature(Member method, Class[] paramTypes) {
    StringBuffer b = new StringBuffer((method instanceof Method) ? method.getName() : "<init>");
    b.append('(');
    for (int i = 0; i < paramTypes.length; i++)
      addDescriptor(b, paramTypes[i]); 
    b.append(')');
    if (method instanceof Method) {
      addDescriptor(b, ((Method)method).getReturnType());
    } else if (method instanceof Constructor) {
      addDescriptor(b, void.class);
    } 
    return b.toString();
  }
  
  private static void addDescriptor(StringBuffer b, Class c) {
    if (c.isPrimitive()) {
      if (c == void.class) {
        b.append('V');
      } else if (c == int.class) {
        b.append('I');
      } else if (c == boolean.class) {
        b.append('Z');
      } else if (c == byte.class) {
        b.append('B');
      } else if (c == short.class) {
        b.append('S');
      } else if (c == long.class) {
        b.append('J');
      } else if (c == char.class) {
        b.append('C');
      } else if (c == float.class) {
        b.append('F');
      } else if (c == double.class) {
        b.append('D');
      } 
    } else if (c.isArray()) {
      b.append('[');
      addDescriptor(b, c.getComponentType());
    } else {
      b.append('L').append(c.getName().replace('.', '/')).append(';');
    } 
  }
  
  protected final int readShort() { return read() << 8 | read(); }
  
  protected final int readInt() { return read() << 24 | read() << 16 | read() << 8 | read(); }
  
  protected void skipFully(int n) throws IOException {
    while (n > 0) {
      int c = (int)skip(n);
      if (c <= 0)
        throw new EOFException(Messages.getMessage("unexpectedEOF00")); 
      n -= c;
    } 
  }
  
  protected final Member resolveMethod(int index) throws IOException, ClassNotFoundException, NoSuchMethodException {
    oldPos = this.pos;
    try {
      Member m = (Member)this.cpool[index];
      if (m == null) {
        this.pos = this.cpoolIndex[index];
        Class owner = resolveClass(readShort());
        NameAndType nt = resolveNameAndType(readShort());
        String signature = nt.name + nt.type;
        if (nt.name.equals("<init>")) {
          Constructor[] ctors = owner.getConstructors();
          for (int i = 0; i < ctors.length; i++) {
            String sig = getSignature(ctors[i], ctors[i].getParameterTypes());
            if (sig.equals(signature)) {
              this.cpool[index] = m = ctors[i];
              return m;
            } 
          } 
        } else {
          Method[] methods = owner.getDeclaredMethods();
          for (int i = 0; i < methods.length; i++) {
            String sig = getSignature(methods[i], methods[i].getParameterTypes());
            if (sig.equals(signature)) {
              this.cpool[index] = m = methods[i];
              return m;
            } 
          } 
        } 
        throw new NoSuchMethodException(signature);
      } 
      return m;
    } finally {
      this.pos = oldPos;
    } 
  }
  
  protected final Field resolveField(int i) throws IOException, ClassNotFoundException, NoSuchFieldException {
    oldPos = this.pos;
    try {
      Field f = (Field)this.cpool[i];
      if (f == null) {
        this.pos = this.cpoolIndex[i];
        Class owner = resolveClass(readShort());
        NameAndType nt = resolveNameAndType(readShort());
        this.cpool[i] = f = owner.getDeclaredField(nt.name);
      } 
      return f;
    } finally {
      this.pos = oldPos;
    } 
  }
  
  private static class NameAndType {
    String name;
    
    String type;
    
    public NameAndType(String name, String type) {
      this.name = name;
      this.type = type;
    }
  }
  
  protected final NameAndType resolveNameAndType(int i) throws IOException {
    oldPos = this.pos;
    try {
      NameAndType nt = (NameAndType)this.cpool[i];
      if (nt == null) {
        this.pos = this.cpoolIndex[i];
        String name = resolveUtf8(readShort());
        String type = resolveUtf8(readShort());
        this.cpool[i] = nt = new NameAndType(name, type);
      } 
      return nt;
    } finally {
      this.pos = oldPos;
    } 
  }
  
  protected final Class resolveClass(int i) throws IOException, ClassNotFoundException {
    oldPos = this.pos;
    try {
      Class c = (Class)this.cpool[i];
      if (c == null) {
        this.pos = this.cpoolIndex[i];
        String name = resolveUtf8(readShort());
        this.cpool[i] = c = Class.forName(classDescriptorToName(name));
      } 
      return c;
    } finally {
      this.pos = oldPos;
    } 
  }
  
  protected final String resolveUtf8(int i) throws IOException {
    oldPos = this.pos;
    try {
      String s = (String)this.cpool[i];
      if (s == null) {
        this.pos = this.cpoolIndex[i];
        int len = readShort();
        skipFully(len);
        this.cpool[i] = s = new String(this.buf, this.pos - len, len, "utf-8");
      } 
      return s;
    } finally {
      this.pos = oldPos;
    } 
  }
  
  protected final void readCpool() throws IOException {
    int count = readShort();
    this.cpoolIndex = new int[count];
    this.cpool = new Object[count];
    for (int i = 1; i < count; i++) {
      int len, c = read();
      this.cpoolIndex[i] = this.pos;
      switch (c) {
        case 9:
        case 10:
        case 11:
        case 12:
          readShort();
        case 7:
        case 8:
          readShort();
          break;
        case 5:
        case 6:
          readInt();
          i++;
        case 3:
        case 4:
          readInt();
          break;
        case 1:
          len = readShort();
          skipFully(len);
          break;
        default:
          throw new IllegalStateException(Messages.getMessage("unexpectedBytes00"));
      } 
    } 
  }
  
  protected final void skipAttributes() throws IOException {
    int count = readShort();
    for (int i = 0; i < count; i++) {
      readShort();
      skipFully(readInt());
    } 
  }
  
  protected final void readAttributes() throws IOException {
    int count = readShort();
    for (int i = 0; i < count; i++) {
      int nameIndex = readShort();
      int attrLen = readInt();
      int curPos = this.pos;
      String attrName = resolveUtf8(nameIndex);
      Method m = (Method)this.attrMethods.get(attrName);
      if (m != null) {
        try {
          m.invoke(this, new Object[0]);
        } catch (IllegalAccessException e) {
          this.pos = curPos;
          skipFully(attrLen);
        } catch (InvocationTargetException e) {
          try {
            throw e.getTargetException();
          } catch (Error ex) {
            throw ex;
          } catch (RuntimeException ex) {
            throw ex;
          } catch (IOException ex) {
            throw ex;
          } catch (Throwable ex) {
            this.pos = curPos;
            skipFully(attrLen);
          } 
        } 
      } else {
        skipFully(attrLen);
      } 
    } 
  }
  
  public void readCode() throws IOException {
    readShort();
    readShort();
    skipFully(readInt());
    skipFully(8 * readShort());
    readAttributes();
  }
  
  protected ClassReader(byte[] buf, Map attrMethods) {
    super(buf);
    this.attrMethods = attrMethods;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axi\\utils\bytecode\ClassReader.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */