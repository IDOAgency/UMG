/*     */ package org.apache.axis.utils.bytecode;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.axis.utils.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassReader
/*     */   extends ByteArrayInputStream
/*     */ {
/*     */   private static final int CONSTANT_Class = 7;
/*     */   private static final int CONSTANT_Fieldref = 9;
/*     */   private static final int CONSTANT_Methodref = 10;
/*     */   private static final int CONSTANT_InterfaceMethodref = 11;
/*     */   private static final int CONSTANT_String = 8;
/*     */   private static final int CONSTANT_Integer = 3;
/*     */   private static final int CONSTANT_Float = 4;
/*     */   private static final int CONSTANT_Long = 5;
/*     */   private static final int CONSTANT_Double = 6;
/*     */   private static final int CONSTANT_NameAndType = 12;
/*     */   private static final int CONSTANT_Utf8 = 1;
/*     */   private int[] cpoolIndex;
/*     */   private Object[] cpool;
/*     */   private Map attrMethods;
/*     */   
/*     */   protected static byte[] getBytes(Class c) throws IOException {
/*  81 */     fin = c.getResourceAsStream('/' + c.getName().replace('.', '/') + ".class");
/*  82 */     if (fin == null) {
/*  83 */       throw new IOException(Messages.getMessage("cantLoadByecode", c.getName()));
/*     */     }
/*     */     try {
/*     */       int actual;
/*  87 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  88 */       byte[] buf = new byte[1024];
/*     */       
/*     */       do {
/*  91 */         actual = fin.read(buf);
/*  92 */         if (actual <= 0)
/*  93 */           continue;  out.write(buf, 0, actual);
/*     */       }
/*  95 */       while (actual > 0);
/*  96 */       return out.toByteArray();
/*     */     } finally {
/*  98 */       fin.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 103 */   static String classDescriptorToName(String desc) { return desc.replace('/', '.'); }
/*     */ 
/*     */   
/*     */   protected static Map findAttributeReaders(Class c) {
/* 107 */     HashMap map = new HashMap();
/* 108 */     Method[] methods = c.getMethods();
/*     */     
/* 110 */     for (int i = 0; i < methods.length; i++) {
/* 111 */       String name = methods[i].getName();
/* 112 */       if (name.startsWith("read") && methods[i].getReturnType() == void.class) {
/* 113 */         map.put(name.substring(4), methods[i]);
/*     */       }
/*     */     } 
/*     */     
/* 117 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getSignature(Member method, Class[] paramTypes) {
/* 124 */     StringBuffer b = new StringBuffer((method instanceof Method) ? method.getName() : "<init>");
/* 125 */     b.append('(');
/*     */     
/* 127 */     for (int i = 0; i < paramTypes.length; i++) {
/* 128 */       addDescriptor(b, paramTypes[i]);
/*     */     }
/*     */     
/* 131 */     b.append(')');
/* 132 */     if (method instanceof Method) {
/* 133 */       addDescriptor(b, ((Method)method).getReturnType());
/* 134 */     } else if (method instanceof Constructor) {
/* 135 */       addDescriptor(b, void.class);
/*     */     } 
/*     */     
/* 138 */     return b.toString();
/*     */   }
/*     */   
/*     */   private static void addDescriptor(StringBuffer b, Class c) {
/* 142 */     if (c.isPrimitive()) {
/* 143 */       if (c == void.class)
/* 144 */       { b.append('V'); }
/* 145 */       else if (c == int.class)
/* 146 */       { b.append('I'); }
/* 147 */       else if (c == boolean.class)
/* 148 */       { b.append('Z'); }
/* 149 */       else if (c == byte.class)
/* 150 */       { b.append('B'); }
/* 151 */       else if (c == short.class)
/* 152 */       { b.append('S'); }
/* 153 */       else if (c == long.class)
/* 154 */       { b.append('J'); }
/* 155 */       else if (c == char.class)
/* 156 */       { b.append('C'); }
/* 157 */       else if (c == float.class)
/* 158 */       { b.append('F'); }
/* 159 */       else if (c == double.class) { b.append('D'); } 
/* 160 */     } else if (c.isArray()) {
/* 161 */       b.append('[');
/* 162 */       addDescriptor(b, c.getComponentType());
/*     */     } else {
/* 164 */       b.append('L').append(c.getName().replace('.', '/')).append(';');
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   protected final int readShort() { return read() << 8 | read(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   protected final int readInt() { return read() << 24 | read() << 16 | read() << 8 | read(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void skipFully(int n) throws IOException {
/* 187 */     while (n > 0) {
/* 188 */       int c = (int)skip(n);
/* 189 */       if (c <= 0)
/* 190 */         throw new EOFException(Messages.getMessage("unexpectedEOF00")); 
/* 191 */       n -= c;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final Member resolveMethod(int index) throws IOException, ClassNotFoundException, NoSuchMethodException {
/* 196 */     oldPos = this.pos;
/*     */     try {
/* 198 */       Member m = (Member)this.cpool[index];
/* 199 */       if (m == null) {
/* 200 */         this.pos = this.cpoolIndex[index];
/* 201 */         Class owner = resolveClass(readShort());
/* 202 */         NameAndType nt = resolveNameAndType(readShort());
/* 203 */         String signature = nt.name + nt.type;
/* 204 */         if (nt.name.equals("<init>")) {
/* 205 */           Constructor[] ctors = owner.getConstructors();
/* 206 */           for (int i = 0; i < ctors.length; i++) {
/* 207 */             String sig = getSignature(ctors[i], ctors[i].getParameterTypes());
/* 208 */             if (sig.equals(signature)) {
/* 209 */               this.cpool[index] = m = ctors[i];
/* 210 */               return m;
/*     */             } 
/*     */           } 
/*     */         } else {
/* 214 */           Method[] methods = owner.getDeclaredMethods();
/* 215 */           for (int i = 0; i < methods.length; i++) {
/* 216 */             String sig = getSignature(methods[i], methods[i].getParameterTypes());
/* 217 */             if (sig.equals(signature)) {
/* 218 */               this.cpool[index] = m = methods[i];
/* 219 */               return m;
/*     */             } 
/*     */           } 
/*     */         } 
/* 223 */         throw new NoSuchMethodException(signature);
/*     */       } 
/* 225 */       return m;
/*     */     } finally {
/* 227 */       this.pos = oldPos;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final Field resolveField(int i) throws IOException, ClassNotFoundException, NoSuchFieldException {
/* 233 */     oldPos = this.pos;
/*     */     try {
/* 235 */       Field f = (Field)this.cpool[i];
/* 236 */       if (f == null) {
/* 237 */         this.pos = this.cpoolIndex[i];
/* 238 */         Class owner = resolveClass(readShort());
/* 239 */         NameAndType nt = resolveNameAndType(readShort());
/* 240 */         this.cpool[i] = f = owner.getDeclaredField(nt.name);
/*     */       } 
/* 242 */       return f;
/*     */     } finally {
/* 244 */       this.pos = oldPos;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class NameAndType {
/*     */     String name;
/*     */     String type;
/*     */     
/*     */     public NameAndType(String name, String type) {
/* 253 */       this.name = name;
/* 254 */       this.type = type;
/*     */     }
/*     */   }
/*     */   
/*     */   protected final NameAndType resolveNameAndType(int i) throws IOException {
/* 259 */     oldPos = this.pos;
/*     */     try {
/* 261 */       NameAndType nt = (NameAndType)this.cpool[i];
/* 262 */       if (nt == null) {
/* 263 */         this.pos = this.cpoolIndex[i];
/* 264 */         String name = resolveUtf8(readShort());
/* 265 */         String type = resolveUtf8(readShort());
/* 266 */         this.cpool[i] = nt = new NameAndType(name, type);
/*     */       } 
/* 268 */       return nt;
/*     */     } finally {
/* 270 */       this.pos = oldPos;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final Class resolveClass(int i) throws IOException, ClassNotFoundException {
/* 276 */     oldPos = this.pos;
/*     */     try {
/* 278 */       Class c = (Class)this.cpool[i];
/* 279 */       if (c == null) {
/* 280 */         this.pos = this.cpoolIndex[i];
/* 281 */         String name = resolveUtf8(readShort());
/* 282 */         this.cpool[i] = c = Class.forName(classDescriptorToName(name));
/*     */       } 
/* 284 */       return c;
/*     */     } finally {
/* 286 */       this.pos = oldPos;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final String resolveUtf8(int i) throws IOException {
/* 291 */     oldPos = this.pos;
/*     */     try {
/* 293 */       String s = (String)this.cpool[i];
/* 294 */       if (s == null) {
/* 295 */         this.pos = this.cpoolIndex[i];
/* 296 */         int len = readShort();
/* 297 */         skipFully(len);
/* 298 */         this.cpool[i] = s = new String(this.buf, this.pos - len, len, "utf-8");
/*     */       } 
/* 300 */       return s;
/*     */     } finally {
/* 302 */       this.pos = oldPos;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void readCpool() throws IOException {
/* 307 */     int count = readShort();
/* 308 */     this.cpoolIndex = new int[count];
/* 309 */     this.cpool = new Object[count];
/* 310 */     for (int i = 1; i < count; i++) {
/* 311 */       int len, c = read();
/* 312 */       this.cpoolIndex[i] = this.pos;
/* 313 */       switch (c) {
/*     */ 
/*     */         
/*     */         case 9:
/*     */         case 10:
/*     */         case 11:
/*     */         case 12:
/* 320 */           readShort();
/*     */ 
/*     */ 
/*     */         
/*     */         case 7:
/*     */         case 8:
/* 326 */           readShort();
/*     */           break;
/*     */ 
/*     */         
/*     */         case 5:
/*     */         case 6:
/* 332 */           readInt();
/*     */ 
/*     */ 
/*     */           
/* 336 */           i++;
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/*     */         case 4:
/* 342 */           readInt();
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/* 347 */           len = readShort();
/* 348 */           skipFully(len);
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 353 */           throw new IllegalStateException(Messages.getMessage("unexpectedBytes00"));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void skipAttributes() throws IOException {
/* 360 */     int count = readShort();
/* 361 */     for (int i = 0; i < count; i++) {
/* 362 */       readShort();
/* 363 */       skipFully(readInt());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void readAttributes() throws IOException {
/* 373 */     int count = readShort();
/* 374 */     for (int i = 0; i < count; i++) {
/* 375 */       int nameIndex = readShort();
/* 376 */       int attrLen = readInt();
/* 377 */       int curPos = this.pos;
/*     */       
/* 379 */       String attrName = resolveUtf8(nameIndex);
/*     */       
/* 381 */       Method m = (Method)this.attrMethods.get(attrName);
/*     */       
/* 383 */       if (m != null) {
/*     */         try {
/* 385 */           m.invoke(this, new Object[0]);
/* 386 */         } catch (IllegalAccessException e) {
/* 387 */           this.pos = curPos;
/* 388 */           skipFully(attrLen);
/* 389 */         } catch (InvocationTargetException e) {
/*     */           try {
/* 391 */             throw e.getTargetException();
/* 392 */           } catch (Error ex) {
/* 393 */             throw ex;
/* 394 */           } catch (RuntimeException ex) {
/* 395 */             throw ex;
/* 396 */           } catch (IOException ex) {
/* 397 */             throw ex;
/* 398 */           } catch (Throwable ex) {
/* 399 */             this.pos = curPos;
/* 400 */             skipFully(attrLen);
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 405 */         skipFully(attrLen);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readCode() throws IOException {
/* 415 */     readShort();
/* 416 */     readShort();
/* 417 */     skipFully(readInt());
/* 418 */     skipFully(8 * readShort());
/*     */ 
/*     */ 
/*     */     
/* 422 */     readAttributes();
/*     */   }
/*     */   
/*     */   protected ClassReader(byte[] buf, Map attrMethods) {
/* 426 */     super(buf);
/*     */     
/* 428 */     this.attrMethods = attrMethods;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axi\\utils\bytecode\ClassReader.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */