package org.apache.axis.utils.cache;

import java.lang.reflect.Method;
import java.util.Vector;

public class JavaMethod {
  private Method[] methods = null;
  
  public JavaMethod(Class jc, String name) {
    Method[] methods = jc.getMethods();
    Vector workinglist = new Vector();
    for (int i = 0; i < methods.length; i++) {
      if (methods[i].getName().equals(name))
        workinglist.addElement(methods[i]); 
    } 
    if (workinglist.size() > 0) {
      this.methods = new Method[workinglist.size()];
      workinglist.copyInto(this.methods);
    } 
  }
  
  public Method[] getMethod() { return this.methods; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axi\\utils\cache\JavaMethod.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */