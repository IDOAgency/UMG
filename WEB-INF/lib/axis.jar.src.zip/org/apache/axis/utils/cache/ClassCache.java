/*    */ package org.apache.axis.utils.cache;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import org.apache.axis.utils.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassCache
/*    */ {
/* 31 */   Hashtable classCache = new Hashtable();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerClass(String name, Class cls) {
/* 45 */     if (name == null)
/* 46 */       return;  JavaClass oldClass = (JavaClass)this.classCache.get(name);
/* 47 */     if (oldClass != null && oldClass.getJavaClass() == cls)
/* 48 */       return;  this.classCache.put(name, new JavaClass(cls));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   public void deregisterClass(String name) { this.classCache.remove(name); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   public boolean isClassRegistered(String name) { return (this.classCache != null && this.classCache.get(name) != null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JavaClass lookup(String className, ClassLoader cl) throws ClassNotFoundException {
/* 79 */     if (className == null) {
/* 80 */       return null;
/*    */     }
/* 82 */     JavaClass jc = (JavaClass)this.classCache.get(className);
/* 83 */     if (jc == null && cl != null) {
/*    */       
/* 85 */       Class cls = ClassUtils.forName(className, true, cl);
/* 86 */       jc = new JavaClass(cls);
/*    */     } 
/* 88 */     return jc;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axi\\utils\cache\ClassCache.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */