/*    */ package org.apache.axis.utils.cache;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaClass
/*    */   implements Serializable
/*    */ {
/* 30 */   private static Hashtable classes = new Hashtable();
/*    */ 
/*    */   
/*    */   private Hashtable methods;
/*    */ 
/*    */   
/*    */   private Class jc;
/*    */ 
/*    */   
/*    */   public static JavaClass find(Class jc) {
/* 40 */     JavaClass result = (JavaClass)classes.get(jc);
/*    */     
/* 42 */     if (result == null) {
/* 43 */       result = new JavaClass(jc);
/* 44 */       classes.put(jc, result);
/*    */     } 
/*    */     
/* 47 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public JavaClass(Class jc) {
/*    */     this.methods = new Hashtable();
/* 54 */     this.jc = jc;
/* 55 */     classes.put(jc, this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public Class getJavaClass() { return this.jc; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Method[] getMethod(String name) {
/* 71 */     JavaMethod jm = (JavaMethod)this.methods.get(name);
/*    */     
/* 73 */     if (jm == null) {
/* 74 */       this.methods.put(name, jm = new JavaMethod(this.jc, name));
/*    */     }
/*    */     
/* 77 */     return jm.getMethod();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axi\\utils\cache\JavaClass.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */