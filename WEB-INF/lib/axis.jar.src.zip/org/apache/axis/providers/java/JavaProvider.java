package org.apache.axis.providers.java;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.wsdl.OperationType;
import javax.xml.rpc.holders.IntHolder;
import javax.xml.rpc.server.ServiceLifecycle;
import org.apache.axis.AxisEngine;
import org.apache.axis.AxisFault;
import org.apache.axis.Constants;
import org.apache.axis.Handler;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.constants.Scope;
import org.apache.axis.description.JavaServiceDesc;
import org.apache.axis.description.OperationDesc;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.providers.BasicProvider;
import org.apache.axis.session.Session;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;
import org.apache.axis.utils.XMLUtils;
import org.apache.axis.utils.cache.ClassCache;
import org.apache.axis.utils.cache.JavaClass;
import org.apache.commons.logging.Log;
import org.xml.sax.SAXException;

public abstract class JavaProvider extends BasicProvider {
  protected static Log log = LogFactory.getLog(JavaProvider.class.getName());
  
  protected static Log entLog = LogFactory.getLog("org.apache.axis.enterprise");
  
  public static final String OPTION_CLASSNAME = "className";
  
  public static final String OPTION_ALLOWEDMETHODS = "allowedMethods";
  
  public static final String OPTION_SCOPE = "scope";
  
  public Object getServiceObject(MessageContext msgContext, Handler service, String clsName, IntHolder scopeHolder) throws Exception {
    String serviceName = msgContext.getService().getName();
    Scope scope = Scope.getScope((String)service.getOption("scope"), Scope.DEFAULT);
    scopeHolder.value = scope.getValue();
    if (scope == Scope.REQUEST)
      return getNewServiceObject(msgContext, clsName); 
    if (scope == Scope.SESSION) {
      if (serviceName == null)
        serviceName = msgContext.getService().toString(); 
      Session session = msgContext.getSession();
      if (session != null)
        return getSessionServiceObject(session, serviceName, msgContext, clsName); 
      scopeHolder.value = Scope.DEFAULT.getValue();
      return getNewServiceObject(msgContext, clsName);
    } 
    if (scope == Scope.APPLICATION)
      return getApplicationScopedObject(msgContext, serviceName, clsName, scopeHolder); 
    if (scope == Scope.FACTORY) {
      String objectID = msgContext.getStrProp("objectID");
      if (objectID == null)
        return getApplicationScopedObject(msgContext, serviceName, clsName, scopeHolder); 
      SOAPService svc = (SOAPService)service;
      Object ret = svc.serviceObjects.get(objectID);
      if (ret == null)
        throw new AxisFault("NoSuchObject", null, null, null); 
      return ret;
    } 
    return null;
  }
  
  private Object getApplicationScopedObject(MessageContext msgContext, String serviceName, String clsName, IntHolder scopeHolder) throws Exception {
    AxisEngine engine = msgContext.getAxisEngine();
    Session appSession = engine.getApplicationSession();
    if (appSession != null)
      return getSessionServiceObject(appSession, serviceName, msgContext, clsName); 
    log.error(Messages.getMessage("noAppSession"));
    scopeHolder.value = Scope.DEFAULT.getValue();
    return getNewServiceObject(msgContext, clsName);
  }
  
  class LockObject implements Serializable {
    private boolean completed;
    
    private final JavaProvider this$0;
    
    LockObject(JavaProvider this$0) {
      this.this$0 = this$0;
      this.completed = false;
    }
    
    void waitUntilComplete() {
      while (!this.completed)
        wait(); 
    }
    
    void complete() {
      this.completed = true;
      notifyAll();
    }
  }
  
  private Object getSessionServiceObject(Session session, String serviceName, MessageContext msgContext, String clsName) throws Exception {
    Object obj = null;
    boolean makeNewObject = false;
    synchronized (session.getLockObject()) {
      obj = session.get(serviceName);
      if (obj == null) {
        obj = new LockObject(this);
        makeNewObject = true;
        session.set(serviceName, obj);
        msgContext.getService().addSession(session);
      } 
    } 
    if (LockObject.class == obj.getClass()) {
      lock = (LockObject)obj;
      if (makeNewObject) {
        try {
          obj = getNewServiceObject(msgContext, clsName);
          session.set(serviceName, obj);
          msgContext.getService().addSession(session);
        } catch (Exception e) {
          session.remove(serviceName);
          throw e;
        } finally {
          lock.complete();
        } 
      } else {
        lock.waitUntilComplete();
        obj = session.get(serviceName);
      } 
    } 
    return obj;
  }
  
  private Object getNewServiceObject(MessageContext msgContext, String clsName) throws Exception {
    Object serviceObject = makeNewServiceObject(msgContext, clsName);
    if (serviceObject != null && serviceObject instanceof ServiceLifecycle)
      ((ServiceLifecycle)serviceObject).init(msgContext.getProperty("servletEndpointContext")); 
    return serviceObject;
  }
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug("Enter: JavaProvider::invoke (" + this + ")"); 
    String serviceName = msgContext.getTargetService();
    SOAPService sOAPService = msgContext.getService();
    String clsName = getServiceClassName(sOAPService);
    if (clsName == null || clsName.equals(""))
      throw new AxisFault("Server.NoClassForService", Messages.getMessage("noOption00", getServiceClassNameOptionName(), serviceName), null, null); 
    IntHolder scope = new IntHolder();
    Object serviceObject = null;
    try {
      serviceObject = getServiceObject(msgContext, sOAPService, clsName, scope);
      SOAPEnvelope resEnv = null;
      OperationDesc operation = msgContext.getOperation();
      if (operation != null && OperationType.ONE_WAY.equals(operation.getMep())) {
        msgContext.setResponseMessage(null);
      } else {
        Message resMsg = msgContext.getResponseMessage();
        if (resMsg == null) {
          resEnv = new SOAPEnvelope(msgContext.getSOAPConstants(), msgContext.getSchemaVersion());
          resMsg = new Message(resEnv);
          String encoding = XMLUtils.getEncoding(msgContext);
          resMsg.setProperty("javax.xml.soap.character-set-encoding", encoding);
          msgContext.setResponseMessage(resMsg);
        } else {
          resEnv = resMsg.getSOAPEnvelope();
        } 
      } 
      Message reqMsg = msgContext.getRequestMessage();
      SOAPEnvelope reqEnv = reqMsg.getSOAPEnvelope();
      processMessage(msgContext, reqEnv, resEnv, serviceObject);
    } catch (SAXException exp) {
      entLog.debug(Messages.getMessage("toAxisFault00"), exp);
      Exception real = exp.getException();
      if (real == null)
        real = exp; 
      throw AxisFault.makeFault(real);
    } catch (Exception exp) {
      entLog.debug(Messages.getMessage("toAxisFault00"), exp);
      AxisFault fault = AxisFault.makeFault(exp);
      if (exp instanceof RuntimeException)
        fault.addFaultDetail(Constants.QNAME_FAULTDETAIL_RUNTIMEEXCEPTION, "true"); 
      throw fault;
    } finally {
      if (serviceObject != null && scope.value == Scope.REQUEST.getValue() && serviceObject instanceof ServiceLifecycle)
        ((ServiceLifecycle)serviceObject).destroy(); 
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: JavaProvider::invoke (" + this + ")"); 
  }
  
  private String getAllowedMethods(Handler service) {
    String val = (String)service.getOption("allowedMethods");
    if (val == null || val.length() == 0)
      val = (String)service.getOption("methodName"); 
    return val;
  }
  
  protected Object makeNewServiceObject(MessageContext msgContext, String clsName) throws Exception {
    ClassLoader cl = msgContext.getClassLoader();
    ClassCache cache = msgContext.getAxisEngine().getClassCache();
    JavaClass jc = cache.lookup(clsName, cl);
    return jc.getJavaClass().newInstance();
  }
  
  protected String getServiceClassName(Handler service) { return (String)service.getOption(getServiceClassNameOptionName()); }
  
  protected String getServiceClassNameOptionName() { return "className"; }
  
  protected Class getServiceClass(String clsName, SOAPService service, MessageContext msgContext) throws AxisFault {
    ClassLoader cl = null;
    Class serviceClass = null;
    AxisEngine engine = service.getEngine();
    if (msgContext != null) {
      cl = msgContext.getClassLoader();
    } else {
      cl = Thread.currentThread().getContextClassLoader();
    } 
    if (engine != null) {
      ClassCache cache = engine.getClassCache();
      try {
        JavaClass jc = cache.lookup(clsName, cl);
        serviceClass = jc.getJavaClass();
      } catch (ClassNotFoundException e) {
        log.error(Messages.getMessage("exception00"), e);
        throw new AxisFault(Messages.getMessage("noClassForService00", clsName), e);
      } 
    } else {
      try {
        serviceClass = ClassUtils.forName(clsName, true, cl);
      } catch (ClassNotFoundException e) {
        log.error(Messages.getMessage("exception00"), e);
        throw new AxisFault(Messages.getMessage("noClassForService00", clsName), e);
      } 
    } 
    return serviceClass;
  }
  
  public void initServiceDesc(SOAPService service, MessageContext msgContext) throws AxisFault {
    String clsName = getServiceClassName(service);
    if (clsName == null)
      throw new AxisFault(Messages.getMessage("noServiceClass")); 
    Class cls = getServiceClass(clsName, service, msgContext);
    JavaServiceDesc serviceDescription = (JavaServiceDesc)service.getServiceDescription();
    if (serviceDescription.getAllowedMethods() == null && service != null) {
      String allowedMethods = getAllowedMethods(service);
      if (allowedMethods != null && !"*".equals(allowedMethods)) {
        ArrayList methodList = new ArrayList();
        StringTokenizer tokenizer = new StringTokenizer(allowedMethods, " ,");
        while (tokenizer.hasMoreTokens())
          methodList.add(tokenizer.nextToken()); 
        serviceDescription.setAllowedMethods(methodList);
      } 
    } 
    serviceDescription.loadServiceDescByIntrospection(cls);
  }
  
  public abstract void processMessage(MessageContext paramMessageContext, SOAPEnvelope paramSOAPEnvelope1, SOAPEnvelope paramSOAPEnvelope2, Object paramObject) throws Exception;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\providers\java\JavaProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */