package org.apache.axis.providers.java;

import java.lang.reflect.Method;
import java.util.Properties;
import org.apache.axis.Handler;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.ClassUtils;
import org.apache.commons.logging.Log;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextHelper;

public class CORBAProvider extends RPCProvider {
  protected static Log log = LogFactory.getLog(CORBAProvider.class.getName());
  
  private static final String DEFAULT_ORB_INITIAL_HOST = "localhost";
  
  private static final String DEFAULT_ORB_INITIAL_PORT = "900";
  
  protected static Log entLog = LogFactory.getLog("org.apache.axis.enterprise");
  
  public static final String OPTION_ORB_INITIAL_HOST = "ORBInitialHost";
  
  public static final String OPTION_ORB_INITIAL_PORT = "ORBInitialPort";
  
  public static final String OPTION_NAME_ID = "NameID";
  
  public static final String OPTION_NAME_KIND = "NameKind";
  
  public static final String OPTION_INTERFACE_CLASSNAME = "InterfaceClassName";
  
  public static final String OPTION_HELPER_CLASSNAME = "HelperClassName";
  
  protected Object makeNewServiceObject(MessageContext msgContext, String clsName) throws Exception {
    String orbInitialHost = getStrOption("ORBInitialHost", msgContext.getService());
    if (orbInitialHost == null)
      orbInitialHost = "localhost"; 
    String orbInitialPort = getStrOption("ORBInitialPort", msgContext.getService());
    if (orbInitialPort == null)
      orbInitialPort = "900"; 
    String nameId = getStrOption("NameID", msgContext.getService());
    String nameKind = getStrOption("NameKind", msgContext.getService());
    String helperClassName = getStrOption("HelperClassName", msgContext.getService());
    Properties orbProps = new Properties();
    orbProps.put("org.omg.CORBA.ORBInitialHost", orbInitialHost);
    orbProps.put("org.omg.CORBA.ORBInitialPort", orbInitialPort);
    ORB orb = ORB.init(new String[0], orbProps);
    NamingContext root = NamingContextHelper.narrow(orb.resolve_initial_references("NameService"));
    NameComponent nc = new NameComponent(nameId, nameKind);
    NameComponent[] ncs = { nc };
    Object corbaObject = root.resolve(ncs);
    Class helperClass = ClassUtils.forName(helperClassName);
    Method narrowMethod = helperClass.getMethod("narrow", CORBA_OBJECT_CLASS);
    return narrowMethod.invoke(null, new Object[] { corbaObject });
  }
  
  private static final Class[] CORBA_OBJECT_CLASS = { Object.class };
  
  protected String getServiceClassNameOptionName() { return "InterfaceClassName"; }
  
  protected String getStrOption(String optionName, Handler service) {
    String value = null;
    if (service != null)
      value = (String)service.getOption(optionName); 
    if (value == null)
      value = (String)getOption(optionName); 
    return value;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\providers\java\CORBAProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */