package org.apache.axis.providers.java;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import org.apache.axis.AxisFault;
import org.apache.axis.Handler;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class EJBProvider extends RPCProvider {
  protected static Log log = LogFactory.getLog(EJBProvider.class.getName());
  
  protected static Log entLog = LogFactory.getLog("org.apache.axis.enterprise");
  
  public static final String OPTION_BEANNAME = "beanJndiName";
  
  public static final String OPTION_HOMEINTERFACENAME = "homeInterfaceName";
  
  public static final String OPTION_REMOTEINTERFACENAME = "remoteInterfaceName";
  
  public static final String OPTION_LOCALHOMEINTERFACENAME = "localHomeInterfaceName";
  
  public static final String OPTION_LOCALINTERFACENAME = "localInterfaceName";
  
  public static final String jndiContextClass = "jndiContextClass";
  
  public static final String jndiURL = "jndiURL";
  
  public static final String jndiUsername = "jndiUser";
  
  public static final String jndiPassword = "jndiPassword";
  
  protected static final Class[] empty_class_array = new Class[0];
  
  protected static final Object[] empty_object_array = new Object[0];
  
  private static InitialContext cached_context = null;
  
  protected Object makeNewServiceObject(MessageContext msgContext, String clsName) throws Exception {
    String remoteHomeName = getStrOption("homeInterfaceName", msgContext.getService());
    String localHomeName = getStrOption("localHomeInterfaceName", msgContext.getService());
    String homeName = (remoteHomeName != null) ? remoteHomeName : localHomeName;
    if (homeName == null)
      throw new AxisFault(Messages.getMessage("noOption00", "homeInterfaceName", msgContext.getTargetService())); 
    Class homeClass = ClassUtils.forName(homeName, true, msgContext.getClassLoader());
    if (remoteHomeName != null)
      return createRemoteEJB(msgContext, clsName, homeClass); 
    return createLocalEJB(msgContext, clsName, homeClass);
  }
  
  private Object createRemoteEJB(MessageContext msgContext, String beanJndiName, Class homeClass) throws Exception {
    Object ejbHome = getEJBHome(msgContext.getService(), msgContext, beanJndiName);
    Object ehome = PortableRemoteObject.narrow(ejbHome, homeClass);
    Method createMethod = homeClass.getMethod("create", empty_class_array);
    return createMethod.invoke(ehome, empty_object_array);
  }
  
  private Object createLocalEJB(MessageContext msgContext, String beanJndiName, Class homeClass) throws Exception {
    Object ehome, ejbHome = getEJBHome(msgContext.getService(), msgContext, beanJndiName);
    if (homeClass.isInstance(ejbHome)) {
      ehome = ejbHome;
    } else {
      throw new ClassCastException(Messages.getMessage("badEjbHomeType"));
    } 
    Method createMethod = homeClass.getMethod("create", empty_class_array);
    return createMethod.invoke(ehome, empty_object_array);
  }
  
  private boolean isRemoteEjb(SOAPService service) { return (getStrOption("homeInterfaceName", service) != null); }
  
  private boolean isLocalEjb(SOAPService service) { return (!isRemoteEjb(service) && getStrOption("localHomeInterfaceName", service) != null); }
  
  protected String getServiceClassNameOptionName() { return "beanJndiName"; }
  
  protected String getStrOption(String optionName, Handler service) {
    String value = null;
    if (service != null)
      value = (String)service.getOption(optionName); 
    if (value == null)
      value = (String)getOption(optionName); 
    return value;
  }
  
  private Class getRemoteInterfaceClassFromHome(String beanJndiName, SOAPService service, MessageContext msgContext) throws Exception {
    Object ejbHome = getEJBHome(service, msgContext, beanJndiName);
    String homeName = getStrOption("homeInterfaceName", service);
    if (homeName == null)
      throw new AxisFault(Messages.getMessage("noOption00", "homeInterfaceName", service.getName())); 
    ClassLoader cl = (msgContext != null) ? msgContext.getClassLoader() : Thread.currentThread().getContextClassLoader();
    Class homeClass = ClassUtils.forName(homeName, true, cl);
    Object ehome = PortableRemoteObject.narrow(ejbHome, homeClass);
    Method getEJBMetaData = homeClass.getMethod("getEJBMetaData", empty_class_array);
    Object metaData = getEJBMetaData.invoke(ehome, empty_object_array);
    Method getRemoteInterfaceClass = metaData.getClass().getMethod("getRemoteInterfaceClass", empty_class_array);
    return (Class)getRemoteInterfaceClass.invoke(metaData, empty_object_array);
  }
  
  protected Class getServiceClass(String beanJndiName, SOAPService service, MessageContext msgContext) throws Exception {
    Class interfaceClass = null;
    try {
      String remoteInterfaceName = getStrOption("remoteInterfaceName", service);
      String localInterfaceName = getStrOption("localInterfaceName", service);
      String interfaceName = (remoteInterfaceName != null) ? remoteInterfaceName : localInterfaceName;
      if (interfaceName != null) {
        ClassLoader cl = (msgContext != null) ? msgContext.getClassLoader() : Thread.currentThread().getContextClassLoader();
        interfaceClass = ClassUtils.forName(interfaceName, true, cl);
      } else if (isRemoteEjb(service)) {
        interfaceClass = getRemoteInterfaceClassFromHome(beanJndiName, service, msgContext);
      } else {
        if (isLocalEjb(service))
          throw new AxisFault(Messages.getMessage("noOption00", "localInterfaceName", service.getName())); 
        throw new AxisFault(Messages.getMessage("noOption00", "homeInterfaceName", service.getName()));
      } 
    } catch (Exception e) {
      throw AxisFault.makeFault(e);
    } 
    return interfaceClass;
  }
  
  private Object getEJBHome(SOAPService serviceHandler, MessageContext msgContext, String beanJndiName) throws AxisFault {
    Object ejbHome = null;
    try {
      Properties properties = null;
      String username = getStrOption("jndiUser", serviceHandler);
      if (username == null && msgContext != null)
        username = msgContext.getUsername(); 
      if (username != null) {
        if (properties == null)
          properties = new Properties(); 
        properties.setProperty("java.naming.security.principal", username);
      } 
      String password = getStrOption("jndiPassword", serviceHandler);
      if (password == null && msgContext != null)
        password = msgContext.getPassword(); 
      if (password != null) {
        if (properties == null)
          properties = new Properties(); 
        properties.setProperty("java.naming.security.credentials", password);
      } 
      String factoryClass = getStrOption("jndiContextClass", serviceHandler);
      if (factoryClass != null) {
        if (properties == null)
          properties = new Properties(); 
        properties.setProperty("java.naming.factory.initial", factoryClass);
      } 
      String contextUrl = getStrOption("jndiURL", serviceHandler);
      if (contextUrl != null) {
        if (properties == null)
          properties = new Properties(); 
        properties.setProperty("java.naming.provider.url", contextUrl);
      } 
      InitialContext context = getContext(properties);
      if (context == null)
        throw new AxisFault(Messages.getMessage("cannotCreateInitialContext00")); 
      ejbHome = getEJBHome(context, beanJndiName);
      if (ejbHome == null)
        throw new AxisFault(Messages.getMessage("cannotFindJNDIHome00", beanJndiName)); 
    } catch (Exception exception) {
      entLog.info(Messages.getMessage("toAxisFault00"), exception);
      throw AxisFault.makeFault(exception);
    } 
    return ejbHome;
  }
  
  protected InitialContext getCachedContext() throws NamingException {
    if (cached_context == null)
      cached_context = new InitialContext(); 
    return cached_context;
  }
  
  protected InitialContext getContext(Properties properties) throws AxisFault, NamingException { return (properties == null) ? getCachedContext() : new InitialContext(properties); }
  
  protected Object getEJBHome(InitialContext context, String beanJndiName) throws AxisFault, NamingException { return context.lookup(beanJndiName); }
  
  protected Object invokeMethod(MessageContext msgContext, Method method, Object obj, Object[] argValues) throws Exception {
    try {
      return super.invokeMethod(msgContext, method, obj, argValues);
    } catch (InvocationTargetException ite) {
      Throwable cause = getCause(ite);
      if (cause instanceof java.rmi.ServerException)
        throw new InvocationTargetException(getCause(cause)); 
      throw ite;
    } 
  }
  
  private Throwable getCause(Throwable original) {
    try {
      Method method = original.getClass().getMethod("getCause", null);
      Throwable cause = (Throwable)method.invoke(original, null);
      if (cause != null)
        return cause; 
    } catch (NoSuchMethodException nsme) {
    
    } catch (Throwable t) {}
    return original;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\providers\java\EJBProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */