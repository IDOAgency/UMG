package org.apache.axis.providers.java;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import org.apache.axis.Handler;
import org.apache.axis.MessageContext;
import org.apache.axis.components.logger.LogFactory;
import org.apache.commons.logging.Log;

public class RMIProvider extends RPCProvider {
  protected static Log log = LogFactory.getLog(RMIProvider.class.getName());
  
  protected static Log entLog = LogFactory.getLog("org.apache.axis.enterprise");
  
  public static final String OPTION_NAMING_LOOKUP = "NamingLookup";
  
  public static final String OPTION_INTERFACE_CLASSNAME = "InterfaceClassName";
  
  protected Object makeNewServiceObject(MessageContext msgContext, String clsName) throws Exception {
    String namingLookup = getStrOption("NamingLookup", msgContext.getService());
    if (System.getSecurityManager() == null)
      System.setSecurityManager(new RMISecurityManager()); 
    return Naming.lookup(namingLookup);
  }
  
  protected String getServiceClassNameOptionName() { return "InterfaceClassName"; }
  
  protected String getStrOption(String optionName, Handler service) {
    String value = null;
    if (service != null)
      value = (String)service.getOption(optionName); 
    if (value == null)
      value = (String)getOption(optionName); 
    return value;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\providers\java\RMIProvider.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */