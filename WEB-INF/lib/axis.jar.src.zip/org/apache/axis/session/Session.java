package org.apache.axis.session;

import java.util.Enumeration;

public interface Session {
  Object get(String paramString);
  
  void set(String paramString, Object paramObject);
  
  void remove(String paramString);
  
  Enumeration getKeys();
  
  void setTimeout(int paramInt);
  
  int getTimeout();
  
  void touch();
  
  void invalidate();
  
  Object getLockObject();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\session\Session.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */