package org.apache.axis.session;

import java.util.Enumeration;
import java.util.Hashtable;

public class SimpleSession implements Session {
  private Hashtable rep = null;
  
  private int timeout = -1;
  
  private long lastTouched = System.currentTimeMillis();
  
  public Object get(String key) {
    if (this.rep == null)
      return null; 
    this.lastTouched = System.currentTimeMillis();
    return this.rep.get(key);
  }
  
  public void set(String key, Object value) {
    synchronized (this) {
      if (this.rep == null)
        this.rep = new Hashtable(); 
    } 
    this.lastTouched = System.currentTimeMillis();
    this.rep.put(key, value);
  }
  
  public void remove(String key) {
    if (this.rep != null)
      this.rep.remove(key); 
    this.lastTouched = System.currentTimeMillis();
  }
  
  public Enumeration getKeys() {
    if (this.rep != null)
      return this.rep.keys(); 
    return null;
  }
  
  public void setTimeout(int timeout) { this.timeout = timeout; }
  
  public int getTimeout() { return this.timeout; }
  
  public void touch() { this.lastTouched = System.currentTimeMillis(); }
  
  public void invalidate() {
    this.rep = null;
    this.lastTouched = System.currentTimeMillis();
    this.timeout = -1;
  }
  
  public long getLastAccessTime() { return this.lastTouched; }
  
  public Object getLockObject() {
    if (this.rep == null)
      this.rep = new Hashtable(); 
    return this.rep;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\session\SimpleSession.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */