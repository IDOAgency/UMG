package org.apache.axis.management.jmx;

import org.apache.axis.deployment.wsdd.WSDDGlobalConfiguration;
import org.apache.axis.deployment.wsdd.WSDDHandler;

public interface DeploymentAdministratorMBean {
  void saveConfiguration();
  
  void configureGlobalConfig(WSDDGlobalConfiguration paramWSDDGlobalConfiguration);
  
  void deployHandler(WSDDHandler paramWSDDHandler);
  
  void deployService(WSDDServiceWrapper paramWSDDServiceWrapper);
  
  void deployTransport(WSDDTransportWrapper paramWSDDTransportWrapper);
  
  void undeployHandler(String paramString);
  
  void undeployService(String paramString);
  
  void undeployTransport(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\jmx\DeploymentAdministratorMBean.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */