package org.apache.axis.management.jmx;

import org.apache.axis.AxisFault;
import org.apache.axis.ConfigurationException;

public interface ServiceAdministratorMBean {
  String getVersion();
  
  void start();
  
  void stop();
  
  void restart();
  
  void startService(String paramString) throws AxisFault, ConfigurationException;
  
  void stopService(String paramString) throws AxisFault, ConfigurationException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\jmx\ServiceAdministratorMBean.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */