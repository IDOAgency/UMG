package org.apache.axis.management.jmx;

import org.apache.axis.deployment.wsdd.WSDDTransport;

public class WSDDTransportWrapper {
  private WSDDTransport _wsddTransport;
  
  public WSDDTransport getWSDDTransport() { return this._wsddTransport; }
  
  public void setWSDDTransport(WSDDTransport _wsddTransport) { this._wsddTransport = _wsddTransport; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\jmx\WSDDTransportWrapper.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */