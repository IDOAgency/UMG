/*    */ package org.apache.axis.management.jmx;
/*    */ 
/*    */ import org.apache.axis.deployment.wsdd.WSDDService;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WSDDServiceWrapper
/*    */ {
/*    */   private WSDDService _wsddService;
/*    */   
/* 24 */   public WSDDService getWSDDService() { return this._wsddService; }
/*    */ 
/*    */ 
/*    */   
/* 28 */   public void setWSDDService(WSDDService wsddService) { this._wsddService = wsddService; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\jmx\WSDDServiceWrapper.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */