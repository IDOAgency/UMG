package org.apache.axis.management.jmx;

import org.apache.axis.AxisFault;
import org.apache.axis.ConfigurationException;
import org.apache.axis.deployment.wsdd.WSDDGlobalConfiguration;
import org.apache.axis.deployment.wsdd.WSDDHandler;
import org.apache.axis.deployment.wsdd.WSDDService;
import org.apache.axis.deployment.wsdd.WSDDTransport;

public interface DeploymentQueryMBean {
  WSDDGlobalConfiguration findGlobalConfig();
  
  WSDDHandler findHandler(String paramString);
  
  WSDDHandler[] findHandlers();
  
  WSDDService findService(String paramString);
  
  WSDDService[] findServices();
  
  WSDDTransport findTransport(String paramString);
  
  WSDDTransport[] findTransports();
  
  String[] listServices() throws AxisFault, ConfigurationException;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\jmx\DeploymentQueryMBean.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */