/*     */ package org.apache.axis.management.jmx;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.ConfigurationException;
/*     */ import org.apache.axis.deployment.wsdd.WSDDGlobalConfiguration;
/*     */ import org.apache.axis.deployment.wsdd.WSDDHandler;
/*     */ import org.apache.axis.deployment.wsdd.WSDDService;
/*     */ import org.apache.axis.deployment.wsdd.WSDDTransport;
/*     */ import org.apache.axis.management.ServiceAdmin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeploymentQuery
/*     */   implements DeploymentQueryMBean
/*     */ {
/*  35 */   public WSDDGlobalConfiguration findGlobalConfig() { return ServiceAdmin.getGlobalConfig(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public WSDDHandler findHandler(String qname) { return ServiceAdmin.getHandler(new QName(qname)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public WSDDHandler[] findHandlers() { return ServiceAdmin.getHandlers(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public WSDDService findService(String qname) { return ServiceAdmin.getService(new QName(qname)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public WSDDService[] findServices() { return ServiceAdmin.getServices(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public WSDDTransport findTransport(String qname) { return ServiceAdmin.getTransport(new QName(qname)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public WSDDTransport[] findTransports() { return ServiceAdmin.getTransports(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public String[] listServices() throws AxisFault, ConfigurationException { return ServiceAdmin.listServices(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\jmx\DeploymentQuery.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */