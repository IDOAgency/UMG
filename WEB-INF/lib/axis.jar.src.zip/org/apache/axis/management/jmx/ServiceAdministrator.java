package org.apache.axis.management.jmx;

import org.apache.axis.AxisFault;
import org.apache.axis.ConfigurationException;
import org.apache.axis.Version;
import org.apache.axis.management.ServiceAdmin;

public class ServiceAdministrator implements ServiceAdministratorMBean {
  public void start() { ServiceAdmin.start(); }
  
  public void stop() { ServiceAdmin.stop(); }
  
  public void restart() { ServiceAdmin.restart(); }
  
  public void startService(String serviceName) throws AxisFault, ConfigurationException { ServiceAdmin.startService(serviceName); }
  
  public void stopService(String serviceName) throws AxisFault, ConfigurationException { ServiceAdmin.stopService(serviceName); }
  
  public String getVersion() { return Version.getVersionText(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\jmx\ServiceAdministrator.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */