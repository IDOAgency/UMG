package org.apache.axis.management;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.i18n.Messages;
import org.apache.commons.logging.Log;

public class Registrar {
  protected static Log log = LogFactory.getLog(Registrar.class.getName());
  
  public static boolean register(Object objectToRegister, String name, String context) {
    if (isBound()) {
      if (log.isDebugEnabled())
        log.debug("Registering " + objectToRegister + " as " + name); 
      return modelerBinding.register(objectToRegister, name, context);
    } 
    return false;
  }
  
  public static boolean isBound() {
    createModelerBinding();
    return modelerBinding.canBind();
  }
  
  private static void createModelerBinding() {
    if (modelerBinding == null)
      modelerBinding = new ModelerBinding(); 
  }
  
  private static ModelerBinding modelerBinding = null;
  
  static Class class$org$apache$axis$management$Registrar$ModelerBinding;
  
  static Class class$java$lang$Object;
  
  static Class class$java$lang$String;
  
  static class ModelerBinding {
    public ModelerBinding() { bindToModeler(); }
    
    public boolean canBind() { return (this.registry != null); }
    
    protected static Log log = LogFactory.getLog(((Registrar.class$org$apache$axis$management$Registrar$ModelerBinding == null) ? (Registrar.class$org$apache$axis$management$Registrar$ModelerBinding = Registrar.class$("org.apache.axis.management.Registrar$ModelerBinding")) : Registrar.class$org$apache$axis$management$Registrar$ModelerBinding).getName());
    
    Object registry;
    
    Method registerComponent;
    
    public boolean register(Object objectToRegister, String name, String context) {
      if (this.registry != null) {
        Object[] args = { objectToRegister, name, context };
        try {
          this.registerComponent.invoke(this.registry, args);
          if (log.isDebugEnabled())
            log.debug("Registered " + name + " in " + context); 
        } catch (IllegalAccessException e) {
          log.error(e);
          return false;
        } catch (IllegalArgumentException e) {
          log.error(e);
          return false;
        } catch (InvocationTargetException e) {
          log.error(e);
          return false;
        } 
        return true;
      } 
      return false;
    }
    
    private boolean bindToModeler() {
      Class clazz;
      Exception ex = null;
      try {
        clazz = Class.forName("org.apache.commons.modeler.Registry");
      } catch (ClassNotFoundException e) {
        this.registry = null;
        return false;
      } 
      try {
        Class[] getRegistryArgs = { (Registrar.class$java$lang$Object == null) ? (Registrar.class$java$lang$Object = Registrar.class$("java.lang.Object")) : Registrar.class$java$lang$Object, (Registrar.class$java$lang$Object == null) ? (Registrar.class$java$lang$Object = Registrar.class$("java.lang.Object")) : Registrar.class$java$lang$Object };
        Method getRegistry = clazz.getMethod("getRegistry", getRegistryArgs);
        Object[] getRegistryOptions = { null, null };
        this.registry = getRegistry.invoke(null, getRegistryOptions);
        Class[] registerArgs = { (Registrar.class$java$lang$Object == null) ? (Registrar.class$java$lang$Object = Registrar.class$("java.lang.Object")) : Registrar.class$java$lang$Object, (Registrar.class$java$lang$String == null) ? (Registrar.class$java$lang$String = Registrar.class$("java.lang.String")) : Registrar.class$java$lang$String, (Registrar.class$java$lang$String == null) ? (Registrar.class$java$lang$String = Registrar.class$("java.lang.String")) : Registrar.class$java$lang$String };
        this.registerComponent = clazz.getMethod("registerComponent", registerArgs);
      } catch (IllegalAccessException e) {
        ex = e;
      } catch (IllegalArgumentException e) {
        ex = e;
      } catch (InvocationTargetException e) {
        ex = e;
      } catch (NoSuchMethodException e) {
        ex = e;
      } 
      if (ex != null) {
        log.warn(Messages.getMessage("Registrar.cantregister"), ex);
        this.registry = null;
        return false;
      } 
      return true;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\Registrar.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */