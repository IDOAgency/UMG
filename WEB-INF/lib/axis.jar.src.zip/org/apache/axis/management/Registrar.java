/*     */ package org.apache.axis.management;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.axis.components.logger.LogFactory;
/*     */ import org.apache.axis.i18n.Messages;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Registrar
/*     */ {
/*  35 */   protected static Log log = LogFactory.getLog(Registrar.class.getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean register(Object objectToRegister, String name, String context) {
/*  47 */     if (isBound()) {
/*  48 */       if (log.isDebugEnabled()) {
/*  49 */         log.debug("Registering " + objectToRegister + " as " + name);
/*     */       }
/*     */       
/*  52 */       return modelerBinding.register(objectToRegister, name, context);
/*     */     } 
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBound() {
/*  66 */     createModelerBinding();
/*  67 */     return modelerBinding.canBind();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void createModelerBinding() {
/*  75 */     if (modelerBinding == null) {
/*  76 */       modelerBinding = new ModelerBinding();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private static ModelerBinding modelerBinding = null;
/*     */   
/*     */   static Class class$org$apache$axis$management$Registrar$ModelerBinding;
/*     */   
/*     */   static Class class$java$lang$Object;
/*     */   
/*     */   static Class class$java$lang$String;
/*     */ 
/*     */   
/*     */   static class ModelerBinding
/*     */   {
/*  94 */     public ModelerBinding() { bindToModeler(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     public boolean canBind() { return (this.registry != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     protected static Log log = LogFactory.getLog(((Registrar.class$org$apache$axis$management$Registrar$ModelerBinding == null) ? (Registrar.class$org$apache$axis$management$Registrar$ModelerBinding = Registrar.class$("org.apache.axis.management.Registrar$ModelerBinding")) : Registrar.class$org$apache$axis$management$Registrar$ModelerBinding).getName());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object registry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Method registerComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean register(Object objectToRegister, String name, String context) {
/* 128 */       if (this.registry != null) {
/* 129 */         Object[] args = { objectToRegister, name, context };
/*     */         try {
/* 131 */           this.registerComponent.invoke(this.registry, args);
/* 132 */           if (log.isDebugEnabled()) {
/* 133 */             log.debug("Registered " + name + " in " + context);
/*     */           }
/* 135 */         } catch (IllegalAccessException e) {
/* 136 */           log.error(e);
/* 137 */           return false;
/* 138 */         } catch (IllegalArgumentException e) {
/* 139 */           log.error(e);
/* 140 */           return false;
/* 141 */         } catch (InvocationTargetException e) {
/* 142 */           log.error(e);
/* 143 */           return false;
/*     */         } 
/* 145 */         return true;
/*     */       } 
/* 147 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean bindToModeler() {
/*     */       Class clazz;
/* 157 */       Exception ex = null;
/*     */       
/*     */       try {
/* 160 */         clazz = Class.forName("org.apache.commons.modeler.Registry");
/* 161 */       } catch (ClassNotFoundException e) {
/*     */         
/* 163 */         this.registry = null;
/* 164 */         return false;
/*     */       } 
/*     */       try {
/* 167 */         Class[] getRegistryArgs = { (Registrar.class$java$lang$Object == null) ? (Registrar.class$java$lang$Object = Registrar.class$("java.lang.Object")) : Registrar.class$java$lang$Object, (Registrar.class$java$lang$Object == null) ? (Registrar.class$java$lang$Object = Registrar.class$("java.lang.Object")) : Registrar.class$java$lang$Object };
/* 168 */         Method getRegistry = clazz.getMethod("getRegistry", getRegistryArgs);
/* 169 */         Object[] getRegistryOptions = { null, null };
/* 170 */         this.registry = getRegistry.invoke(null, getRegistryOptions);
/* 171 */         Class[] registerArgs = { (Registrar.class$java$lang$Object == null) ? (Registrar.class$java$lang$Object = Registrar.class$("java.lang.Object")) : Registrar.class$java$lang$Object, (Registrar.class$java$lang$String == null) ? (Registrar.class$java$lang$String = Registrar.class$("java.lang.String")) : Registrar.class$java$lang$String, (Registrar.class$java$lang$String == null) ? (Registrar.class$java$lang$String = Registrar.class$("java.lang.String")) : Registrar.class$java$lang$String };
/*     */ 
/*     */         
/* 174 */         this.registerComponent = clazz.getMethod("registerComponent", registerArgs);
/* 175 */       } catch (IllegalAccessException e) {
/* 176 */         ex = e;
/* 177 */       } catch (IllegalArgumentException e) {
/* 178 */         ex = e;
/* 179 */       } catch (InvocationTargetException e) {
/* 180 */         ex = e;
/* 181 */       } catch (NoSuchMethodException e) {
/* 182 */         ex = e;
/*     */       } 
/*     */       
/* 185 */       if (ex != null) {
/*     */         
/* 187 */         log.warn(Messages.getMessage("Registrar.cantregister"), ex);
/*     */         
/* 189 */         this.registry = null;
/*     */         
/* 191 */         return false;
/*     */       } 
/*     */       
/* 194 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\Registrar.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */