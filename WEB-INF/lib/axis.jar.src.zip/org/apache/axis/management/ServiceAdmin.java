/*     */ package org.apache.axis.management;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.ConfigurationException;
/*     */ import org.apache.axis.EngineConfiguration;
/*     */ import org.apache.axis.WSDDEngineConfiguration;
/*     */ import org.apache.axis.deployment.wsdd.WSDDGlobalConfiguration;
/*     */ import org.apache.axis.deployment.wsdd.WSDDHandler;
/*     */ import org.apache.axis.deployment.wsdd.WSDDService;
/*     */ import org.apache.axis.deployment.wsdd.WSDDTransport;
/*     */ import org.apache.axis.description.ServiceDesc;
/*     */ import org.apache.axis.handlers.soap.SOAPService;
/*     */ import org.apache.axis.management.jmx.DeploymentAdministrator;
/*     */ import org.apache.axis.management.jmx.DeploymentQuery;
/*     */ import org.apache.axis.management.jmx.ServiceAdministrator;
/*     */ import org.apache.axis.server.AxisServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceAdmin
/*     */ {
/*  46 */   private static AxisServer axisServer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void startService(String serviceName) throws AxisFault, ConfigurationException {
/*  56 */     AxisServer server = getEngine();
/*     */     try {
/*  58 */       SOAPService service = server.getConfig().getService(new QName("", serviceName));
/*     */       
/*  60 */       service.start();
/*  61 */     } catch (ConfigurationException configException) {
/*  62 */       if (configException.getContainedException() instanceof AxisFault) {
/*  63 */         throw (AxisFault)configException.getContainedException();
/*     */       }
/*  65 */       throw configException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void stopService(String serviceName) throws AxisFault, ConfigurationException {
/*  78 */     AxisServer server = getEngine();
/*     */     try {
/*  80 */       SOAPService service = server.getConfig().getService(new QName("", serviceName));
/*     */       
/*  82 */       service.stop();
/*  83 */     } catch (ConfigurationException configException) {
/*  84 */       if (configException.getContainedException() instanceof AxisFault) {
/*  85 */         throw (AxisFault)configException.getContainedException();
/*     */       }
/*  87 */       throw configException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] listServices() throws AxisFault, ConfigurationException {
/*     */     Iterator iter;
/* 100 */     list = new ArrayList();
/* 101 */     AxisServer server = getEngine();
/*     */     
/*     */     try {
/* 104 */       iter = server.getConfig().getDeployedServices();
/* 105 */     } catch (ConfigurationException configException) {
/* 106 */       if (configException.getContainedException() instanceof AxisFault) {
/* 107 */         throw (AxisFault)configException.getContainedException();
/*     */       }
/* 109 */       throw configException;
/*     */     } 
/*     */     
/* 112 */     while (iter.hasNext()) {
/* 113 */       ServiceDesc sd = (ServiceDesc)iter.next();
/* 114 */       String name = sd.getName();
/* 115 */       list.add(name);
/*     */     } 
/* 117 */     return (String[])list.toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AxisServer getEngine() throws AxisFault {
/* 127 */     if (axisServer == null)
/*     */     {
/* 129 */       throw new AxisFault("Unable to locate AxisEngine for ServiceAdmin Object");
/*     */     }
/*     */     
/* 132 */     return axisServer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setEngine(AxisServer axisSrv, String name) {
/* 141 */     axisServer = axisSrv;
/* 142 */     Registrar.register(new ServiceAdministrator(), "axis:type=server", "ServiceAdministrator");
/* 143 */     Registrar.register(new DeploymentAdministrator(), "axis:type=deploy", "DeploymentAdministrator");
/* 144 */     Registrar.register(new DeploymentQuery(), "axis:type=query", "DeploymentQuery");
/*     */   }
/*     */   
/*     */   public static void start() {
/* 148 */     if (axisServer != null) {
/* 149 */       axisServer.start();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void stop() {
/* 154 */     if (axisServer != null) {
/* 155 */       axisServer.stop();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void restart() {
/* 160 */     if (axisServer != null) {
/* 161 */       axisServer.stop();
/* 162 */       axisServer.start();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void saveConfiguration() {
/* 167 */     if (axisServer != null) {
/* 168 */       axisServer.saveConfiguration();
/*     */     }
/*     */   }
/*     */   
/*     */   private static WSDDEngineConfiguration getWSDDEngineConfiguration() {
/* 173 */     if (axisServer != null) {
/* 174 */       config = axisServer.getConfig();
/* 175 */       if (config instanceof WSDDEngineConfiguration) {
/* 176 */         return (WSDDEngineConfiguration)config;
/*     */       }
/* 178 */       throw new RuntimeException("WSDDDeploymentHelper.getWSDDEngineConfiguration(): EngineConguration not of type WSDDEngineConfiguration");
/*     */     } 
/*     */     
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   
/* 185 */   public static void setGlobalConfig(WSDDGlobalConfiguration globalConfig) { getWSDDEngineConfiguration().getDeployment().setGlobalConfiguration(globalConfig); }
/*     */ 
/*     */ 
/*     */   
/* 189 */   public static WSDDGlobalConfiguration getGlobalConfig() { return getWSDDEngineConfiguration().getDeployment().getGlobalConfiguration(); }
/*     */ 
/*     */ 
/*     */   
/* 193 */   public static WSDDHandler getHandler(QName qname) { return getWSDDEngineConfiguration().getDeployment().getWSDDHandler(qname); }
/*     */ 
/*     */ 
/*     */   
/* 197 */   public static WSDDHandler[] getHandlers() { return getWSDDEngineConfiguration().getDeployment().getHandlers(); }
/*     */ 
/*     */ 
/*     */   
/* 201 */   public static WSDDService getService(QName qname) { return getWSDDEngineConfiguration().getDeployment().getWSDDService(qname); }
/*     */ 
/*     */ 
/*     */   
/* 205 */   public static WSDDService[] getServices() { return getWSDDEngineConfiguration().getDeployment().getServices(); }
/*     */ 
/*     */ 
/*     */   
/* 209 */   public static WSDDTransport getTransport(QName qname) { return getWSDDEngineConfiguration().getDeployment().getWSDDTransport(qname); }
/*     */ 
/*     */ 
/*     */   
/* 213 */   public static WSDDTransport[] getTransports() { return getWSDDEngineConfiguration().getDeployment().getTransports(); }
/*     */ 
/*     */ 
/*     */   
/* 217 */   public static void deployHandler(WSDDHandler handler) { getWSDDEngineConfiguration().getDeployment().deployHandler(handler); }
/*     */ 
/*     */ 
/*     */   
/* 221 */   public static void deployService(WSDDService service) { getWSDDEngineConfiguration().getDeployment().deployService(service); }
/*     */ 
/*     */ 
/*     */   
/* 225 */   public static void deployTransport(WSDDTransport transport) { getWSDDEngineConfiguration().getDeployment().deployTransport(transport); }
/*     */ 
/*     */ 
/*     */   
/* 229 */   public static void undeployHandler(QName qname) { getWSDDEngineConfiguration().getDeployment().undeployHandler(qname); }
/*     */ 
/*     */ 
/*     */   
/* 233 */   public static void undeployService(QName qname) { getWSDDEngineConfiguration().getDeployment().undeployService(qname); }
/*     */ 
/*     */ 
/*     */   
/* 237 */   public static void undeployTransport(QName qname) { getWSDDEngineConfiguration().getDeployment().undeployTransport(qname); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\ServiceAdmin.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */