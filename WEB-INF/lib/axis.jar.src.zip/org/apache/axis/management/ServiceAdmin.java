package org.apache.axis.management;

import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.namespace.QName;
import org.apache.axis.AxisFault;
import org.apache.axis.ConfigurationException;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.WSDDEngineConfiguration;
import org.apache.axis.deployment.wsdd.WSDDGlobalConfiguration;
import org.apache.axis.deployment.wsdd.WSDDHandler;
import org.apache.axis.deployment.wsdd.WSDDService;
import org.apache.axis.deployment.wsdd.WSDDTransport;
import org.apache.axis.description.ServiceDesc;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.management.jmx.DeploymentAdministrator;
import org.apache.axis.management.jmx.DeploymentQuery;
import org.apache.axis.management.jmx.ServiceAdministrator;
import org.apache.axis.server.AxisServer;

public class ServiceAdmin {
  private static AxisServer axisServer = null;
  
  public static void startService(String serviceName) throws AxisFault, ConfigurationException {
    AxisServer server = getEngine();
    try {
      SOAPService service = server.getConfig().getService(new QName("", serviceName));
      service.start();
    } catch (ConfigurationException configException) {
      if (configException.getContainedException() instanceof AxisFault)
        throw (AxisFault)configException.getContainedException(); 
      throw configException;
    } 
  }
  
  public static void stopService(String serviceName) throws AxisFault, ConfigurationException {
    AxisServer server = getEngine();
    try {
      SOAPService service = server.getConfig().getService(new QName("", serviceName));
      service.stop();
    } catch (ConfigurationException configException) {
      if (configException.getContainedException() instanceof AxisFault)
        throw (AxisFault)configException.getContainedException(); 
      throw configException;
    } 
  }
  
  public static String[] listServices() throws AxisFault, ConfigurationException {
    Iterator iter;
    list = new ArrayList();
    AxisServer server = getEngine();
    try {
      iter = server.getConfig().getDeployedServices();
    } catch (ConfigurationException configException) {
      if (configException.getContainedException() instanceof AxisFault)
        throw (AxisFault)configException.getContainedException(); 
      throw configException;
    } 
    while (iter.hasNext()) {
      ServiceDesc sd = (ServiceDesc)iter.next();
      String name = sd.getName();
      list.add(name);
    } 
    return (String[])list.toArray(new String[list.size()]);
  }
  
  public static AxisServer getEngine() throws AxisFault {
    if (axisServer == null)
      throw new AxisFault("Unable to locate AxisEngine for ServiceAdmin Object"); 
    return axisServer;
  }
  
  public static void setEngine(AxisServer axisSrv, String name) {
    axisServer = axisSrv;
    Registrar.register(new ServiceAdministrator(), "axis:type=server", "ServiceAdministrator");
    Registrar.register(new DeploymentAdministrator(), "axis:type=deploy", "DeploymentAdministrator");
    Registrar.register(new DeploymentQuery(), "axis:type=query", "DeploymentQuery");
  }
  
  public static void start() {
    if (axisServer != null)
      axisServer.start(); 
  }
  
  public static void stop() {
    if (axisServer != null)
      axisServer.stop(); 
  }
  
  public static void restart() {
    if (axisServer != null) {
      axisServer.stop();
      axisServer.start();
    } 
  }
  
  public static void saveConfiguration() {
    if (axisServer != null)
      axisServer.saveConfiguration(); 
  }
  
  private static WSDDEngineConfiguration getWSDDEngineConfiguration() {
    if (axisServer != null) {
      config = axisServer.getConfig();
      if (config instanceof WSDDEngineConfiguration)
        return (WSDDEngineConfiguration)config; 
      throw new RuntimeException("WSDDDeploymentHelper.getWSDDEngineConfiguration(): EngineConguration not of type WSDDEngineConfiguration");
    } 
    return null;
  }
  
  public static void setGlobalConfig(WSDDGlobalConfiguration globalConfig) { getWSDDEngineConfiguration().getDeployment().setGlobalConfiguration(globalConfig); }
  
  public static WSDDGlobalConfiguration getGlobalConfig() { return getWSDDEngineConfiguration().getDeployment().getGlobalConfiguration(); }
  
  public static WSDDHandler getHandler(QName qname) { return getWSDDEngineConfiguration().getDeployment().getWSDDHandler(qname); }
  
  public static WSDDHandler[] getHandlers() { return getWSDDEngineConfiguration().getDeployment().getHandlers(); }
  
  public static WSDDService getService(QName qname) { return getWSDDEngineConfiguration().getDeployment().getWSDDService(qname); }
  
  public static WSDDService[] getServices() { return getWSDDEngineConfiguration().getDeployment().getServices(); }
  
  public static WSDDTransport getTransport(QName qname) { return getWSDDEngineConfiguration().getDeployment().getWSDDTransport(qname); }
  
  public static WSDDTransport[] getTransports() { return getWSDDEngineConfiguration().getDeployment().getTransports(); }
  
  public static void deployHandler(WSDDHandler handler) { getWSDDEngineConfiguration().getDeployment().deployHandler(handler); }
  
  public static void deployService(WSDDService service) { getWSDDEngineConfiguration().getDeployment().deployService(service); }
  
  public static void deployTransport(WSDDTransport transport) { getWSDDEngineConfiguration().getDeployment().deployTransport(transport); }
  
  public static void undeployHandler(QName qname) { getWSDDEngineConfiguration().getDeployment().undeployHandler(qname); }
  
  public static void undeployService(QName qname) { getWSDDEngineConfiguration().getDeployment().undeployService(qname); }
  
  public static void undeployTransport(QName qname) { getWSDDEngineConfiguration().getDeployment().undeployTransport(qname); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\management\ServiceAdmin.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */