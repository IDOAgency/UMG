package org.apache.axis.server;

import java.util.Map;
import org.apache.axis.AxisFault;

public interface AxisServerFactory {
  AxisServer getServer(Map paramMap) throws AxisFault;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\server\AxisServerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */