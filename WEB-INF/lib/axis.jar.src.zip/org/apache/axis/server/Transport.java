/*    */ package org.apache.axis.server;
/*    */ 
/*    */ import org.apache.axis.SimpleTargetedChain;
/*    */ import org.apache.axis.components.logger.LogFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Transport
/*    */   extends SimpleTargetedChain
/*    */ {
/* 32 */   protected static Log log = LogFactory.getLog(Transport.class.getName());
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\server\Transport.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */