/*    */ package org.apache.axis.server;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParamList
/*    */   extends Vector
/*    */ {
/*    */   public ParamList() {}
/*    */   
/* 29 */   public ParamList(Collection c) { super(c); }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public ParamList(int initialCapacity) { super(initialCapacity); }
/*    */ 
/*    */ 
/*    */   
/* 37 */   public ParamList(int initialCapacity, int capacityIncrement) { super(initialCapacity, capacityIncrement); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\server\ParamList.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */