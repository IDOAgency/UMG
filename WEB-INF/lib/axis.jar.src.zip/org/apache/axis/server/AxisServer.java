package org.apache.axis.server;

import java.util.Map;
import org.apache.axis.AxisEngine;
import org.apache.axis.AxisFault;
import org.apache.axis.AxisProperties;
import org.apache.axis.Constants;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.Handler;
import org.apache.axis.Message;
import org.apache.axis.MessageContext;
import org.apache.axis.SimpleTargetedChain;
import org.apache.axis.client.AxisClient;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.configuration.EngineConfigurationFactoryFinder;
import org.apache.axis.handlers.soap.SOAPService;
import org.apache.axis.message.SOAPEnvelope;
import org.apache.axis.soap.SOAPConstants;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class AxisServer extends AxisEngine {
  protected static Log log = LogFactory.getLog(AxisServer.class.getName());
  
  private static Log tlog = LogFactory.getLog("org.apache.axis.TIME");
  
  private static AxisServerFactory factory = null;
  
  private AxisEngine clientEngine;
  
  private boolean running;
  
  public static AxisServer getServer(Map environment) throws AxisFault {
    if (factory == null) {
      String factoryClassName = AxisProperties.getProperty("axis.ServerFactory");
      if (factoryClassName != null)
        try {
          Class factoryClass = ClassUtils.forName(factoryClassName);
          if (AxisServerFactory.class.isAssignableFrom(factoryClass))
            factory = (AxisServerFactory)factoryClass.newInstance(); 
        } catch (Exception e) {
          log.error(Messages.getMessage("exception00"), e);
        }  
      if (factory == null)
        factory = new DefaultAxisServerFactory(); 
    } 
    return factory.getServer(environment);
  }
  
  public AxisServer() { this(EngineConfigurationFactoryFinder.newFactory().getServerEngineConfig()); }
  
  public AxisServer(EngineConfiguration config) {
    super(config);
    this.running = true;
    setShouldSaveConfig(true);
  }
  
  public boolean isRunning() { return this.running; }
  
  public void start() {
    init();
    this.running = true;
  }
  
  public void stop() { this.running = false; }
  
  public AxisEngine getClientEngine() {
    if (this.clientEngine == null)
      this.clientEngine = new AxisClient(); 
    return this.clientEngine;
  }
  
  public void invoke(MessageContext msgContext) throws AxisFault {
    long t0 = 0L, t1 = 0L, t2 = 0L, t3 = 0L, t4 = 0L, t5 = 0L;
    if (tlog.isDebugEnabled())
      t0 = System.currentTimeMillis(); 
    if (log.isDebugEnabled())
      log.debug("Enter: AxisServer::invoke"); 
    if (!isRunning())
      throw new AxisFault("Server.disabled", Messages.getMessage("serverDisabled00"), null, null); 
    String hName = null;
    Handler h = null;
    previousContext = getCurrentMessageContext();
    try {
      setCurrentMessageContext(msgContext);
      hName = msgContext.getStrProp("engine.handler");
      if (hName != null) {
        if ((h = getHandler(hName)) == null) {
          ClassLoader cl = msgContext.getClassLoader();
          try {
            log.debug(Messages.getMessage("tryingLoad00", hName));
            Class cls = ClassUtils.forName(hName, true, cl);
            h = (Handler)cls.newInstance();
          } catch (Exception e) {
            h = null;
          } 
        } 
        if (tlog.isDebugEnabled())
          t1 = System.currentTimeMillis(); 
        if (h != null) {
          h.invoke(msgContext);
        } else {
          throw new AxisFault("Server.error", Messages.getMessage("noHandler00", hName), null, null);
        } 
        if (tlog.isDebugEnabled()) {
          t2 = System.currentTimeMillis();
          tlog.debug("AxisServer.invoke " + hName + " invoke=" + (t2 - t1) + " pre=" + (t1 - t0));
        } 
      } else {
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("defaultLogic00")); 
        hName = msgContext.getTransportName();
        SimpleTargetedChain transportChain = null;
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("transport01", "AxisServer.invoke", hName)); 
        if (tlog.isDebugEnabled())
          t1 = System.currentTimeMillis(); 
        if (hName != null && (h = getTransport(hName)) != null && 
          h instanceof SimpleTargetedChain) {
          transportChain = (SimpleTargetedChain)h;
          h = transportChain.getRequestHandler();
          if (h != null)
            h.invoke(msgContext); 
        } 
        if (tlog.isDebugEnabled())
          t2 = System.currentTimeMillis(); 
        if ((h = getGlobalRequest()) != null)
          h.invoke(msgContext); 
        SOAPService sOAPService = msgContext.getService();
        if (sOAPService == null) {
          Message rm = msgContext.getRequestMessage();
          rm.getSOAPEnvelope().getFirstBody();
          sOAPService = msgContext.getService();
          if (sOAPService == null)
            throw new AxisFault("Server.NoService", Messages.getMessage("noService05", "" + msgContext.getTargetService()), null, null); 
        } 
        if (tlog.isDebugEnabled())
          t3 = System.currentTimeMillis(); 
        initSOAPConstants(msgContext);
        try {
          sOAPService.invoke(msgContext);
        } catch (AxisFault ae) {
          Handler handler1;
          if ((handler1 = getGlobalRequest()) != null)
            handler1.onFault(msgContext); 
          throw ae;
        } 
        if (tlog.isDebugEnabled())
          t4 = System.currentTimeMillis(); 
        Handler handler;
        if ((handler = getGlobalResponse()) != null)
          handler.invoke(msgContext); 
        if (transportChain != null) {
          handler = transportChain.getResponseHandler();
          if (handler != null)
            handler.invoke(msgContext); 
        } 
        if (tlog.isDebugEnabled()) {
          t5 = System.currentTimeMillis();
          tlog.debug("AxisServer.invoke2  preTr=" + (t1 - t0) + " tr=" + (t2 - t1) + " preInvoke=" + (t3 - t2) + " invoke=" + (t4 - t3) + " postInvoke=" + (t5 - t4) + " " + msgContext.getTargetService() + "." + ((msgContext.getOperation() == null) ? "" : msgContext.getOperation().getName()));
        } 
      } 
    } catch (AxisFault e) {
      throw e;
    } catch (Exception e) {
      throw AxisFault.makeFault(e);
    } finally {
      setCurrentMessageContext(previousContext);
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: AxisServer::invoke"); 
  }
  
  private void initSOAPConstants(MessageContext msgContext) throws AxisFault {
    Message msg = msgContext.getRequestMessage();
    if (msg == null)
      return; 
    SOAPEnvelope env = msg.getSOAPEnvelope();
    if (env == null)
      return; 
    SOAPConstants constants = env.getSOAPConstants();
    if (constants == null)
      return; 
    msgContext.setSOAPConstants(constants);
  }
  
  public void generateWSDL(MessageContext msgContext) throws AxisFault {
    if (log.isDebugEnabled())
      log.debug("Enter: AxisServer::generateWSDL"); 
    if (!isRunning())
      throw new AxisFault("Server.disabled", Messages.getMessage("serverDisabled00"), null, null); 
    String hName = null;
    Handler h = null;
    previousContext = getCurrentMessageContext();
    try {
      setCurrentMessageContext(msgContext);
      hName = msgContext.getStrProp("engine.handler");
      if (hName != null) {
        if ((h = getHandler(hName)) == null) {
          ClassLoader cl = msgContext.getClassLoader();
          try {
            log.debug(Messages.getMessage("tryingLoad00", hName));
            Class cls = ClassUtils.forName(hName, true, cl);
            h = (Handler)cls.newInstance();
          } catch (Exception e) {
            throw new AxisFault("Server.error", Messages.getMessage("noHandler00", hName), null, null);
          } 
        } 
        h.generateWSDL(msgContext);
      } else {
        log.debug(Messages.getMessage("defaultLogic00"));
        hName = msgContext.getTransportName();
        SimpleTargetedChain transportChain = null;
        if (log.isDebugEnabled())
          log.debug(Messages.getMessage("transport01", "AxisServer.generateWSDL", hName)); 
        if (hName != null && (h = getTransport(hName)) != null && 
          h instanceof SimpleTargetedChain) {
          transportChain = (SimpleTargetedChain)h;
          h = transportChain.getRequestHandler();
          if (h != null)
            h.generateWSDL(msgContext); 
        } 
        if ((h = getGlobalRequest()) != null)
          h.generateWSDL(msgContext); 
        SOAPService sOAPService = msgContext.getService();
        if (sOAPService == null) {
          Message rm = msgContext.getRequestMessage();
          if (rm != null) {
            rm.getSOAPEnvelope().getFirstBody();
            sOAPService = msgContext.getService();
          } 
          if (sOAPService == null)
            throw new AxisFault(Constants.QNAME_NO_SERVICE_FAULT_CODE, Messages.getMessage("noService05", "" + msgContext.getTargetService()), null, null); 
        } 
        sOAPService.generateWSDL(msgContext);
        Handler handler;
        if ((handler = getGlobalResponse()) != null)
          handler.generateWSDL(msgContext); 
        if (transportChain != null) {
          handler = transportChain.getResponseHandler();
          if (handler != null)
            handler.generateWSDL(msgContext); 
        } 
      } 
    } catch (AxisFault e) {
      throw e;
    } catch (Exception e) {
      throw AxisFault.makeFault(e);
    } finally {
      setCurrentMessageContext(previousContext);
    } 
    if (log.isDebugEnabled())
      log.debug("Exit: AxisServer::generateWSDL"); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\server\AxisServer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */