package org.apache.axis.server;

import java.io.File;
import java.util.Map;
import org.apache.axis.AxisFault;
import org.apache.axis.AxisProperties;
import org.apache.axis.EngineConfiguration;
import org.apache.axis.components.logger.LogFactory;
import org.apache.axis.utils.ClassUtils;
import org.apache.axis.utils.Messages;
import org.apache.commons.logging.Log;

public class DefaultAxisServerFactory implements AxisServerFactory {
  protected static Log log = LogFactory.getLog(DefaultAxisServerFactory.class.getName());
  
  public AxisServer getServer(Map environment) throws AxisFault {
    log.debug("Enter: DefaultAxisServerFactory::getServer");
    AxisServer ret = createServer(environment);
    if (ret != null) {
      if (environment != null) {
        ret.setOptionDefault("attachments.Directory", (String)environment.get("axis.attachments.Directory"));
        ret.setOptionDefault("attachments.Directory", (String)environment.get("servlet.realpath"));
      } 
      String attachmentsdir = (String)ret.getOption("attachments.Directory");
      if (attachmentsdir != null) {
        File attdirFile = new File(attachmentsdir);
        if (!attdirFile.isDirectory())
          attdirFile.mkdirs(); 
      } 
    } 
    log.debug("Exit: DefaultAxisServerFactory::getServer");
    return ret;
  }
  
  private static AxisServer createServer(Map environment) throws AxisFault {
    EngineConfiguration config = getEngineConfiguration(environment);
    return (config == null) ? new AxisServer() : new AxisServer(config);
  }
  
  private static EngineConfiguration getEngineConfiguration(Map environment) {
    log.debug("Enter: DefaultAxisServerFactory::getEngineConfiguration");
    EngineConfiguration config = null;
    if (environment != null)
      try {
        config = (EngineConfiguration)environment.get("engineConfig");
      } catch (ClassCastException e) {
        log.warn(Messages.getMessage("engineConfigWrongClass00"), e);
      }  
    if (config == null) {
      String configClass = AxisProperties.getProperty("axis.engineConfigClass");
      if (configClass != null)
        try {
          Class cls = ClassUtils.forName(configClass);
          config = (EngineConfiguration)cls.newInstance();
        } catch (ClassNotFoundException e) {
          log.warn(Messages.getMessage("engineConfigNoClass00", configClass), e);
        } catch (InstantiationException e) {
          log.warn(Messages.getMessage("engineConfigNoInstance00", configClass), e);
        } catch (IllegalAccessException e) {
          log.warn(Messages.getMessage("engineConfigIllegalAccess00", configClass), e);
        } catch (ClassCastException e) {
          log.warn(Messages.getMessage("engineConfigWrongClass01", configClass), e);
        }  
    } 
    log.debug("Exit: DefaultAxisServerFactory::getEngineConfiguration");
    return config;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\axis.jar!\org\apache\axis\server\DefaultAxisServerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */