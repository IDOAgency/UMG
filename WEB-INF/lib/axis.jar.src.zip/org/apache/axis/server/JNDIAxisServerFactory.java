package org.apache.axis.server;

import java.util.Map;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletContext;
import org.apache.axis.AxisFault;
import org.apache.axis.utils.Messages;

public class JNDIAxisServerFactory extends DefaultAxisServerFactory {
  public AxisServer getServer(Map environment) throws AxisFault {
    log.debug("Enter: JNDIAxisServerFactory::getServer");
    InitialContext context = null;
    try {
      context = new InitialContext();
    } catch (NamingException e) {
      log.warn(Messages.getMessage("jndiNotFound00"), e);
    } 
    ServletContext servletContext = null;
    try {
      servletContext = (ServletContext)environment.get("servletContext");
    } catch (ClassCastException e) {
      log.warn(Messages.getMessage("servletContextWrongClass00"), e);
    } 
    AxisServer server = null;
    if (context != null && servletContext != null) {
      String name = servletContext.getRealPath("/WEB-INF/Server");
      if (name != null)
        try {
          server = (AxisServer)context.lookup(name);
        } catch (NamingException e) {
          server = super.getServer(environment);
          try {
            context.bind(name, server);
          } catch (NamingException e1) {}
        }  
    } 
    if (server == null)
      server = super.getServer(environment); 
    log.debug("Exit: JNDIAxisServerFactory::getServer");
    return server;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\server\JNDIAxisServerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */