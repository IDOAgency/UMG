package org.apache.axis.collections;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Iterator;

public class LRUMap extends SequencedHashMap implements Externalizable {
  private int maximumSize = 0;
  
  private static final long serialVersionUID = 2197433140769957051L;
  
  public LRUMap() { this(100); }
  
  public LRUMap(int i) {
    super(i);
    this.maximumSize = i;
  }
  
  public Object get(Object key) {
    if (!containsKey(key))
      return null; 
    Object value = remove(key);
    super.put(key, value);
    return value;
  }
  
  public Object put(Object key, Object value) {
    int mapSize = size();
    retval = null;
    if (mapSize >= this.maximumSize)
      if (!containsKey(key))
        removeLRU();  
    return super.put(key, value);
  }
  
  protected void removeLRU() {
    Object key = getFirstKey();
    Object value = super.get(key);
    remove(key);
    processRemovedLRU(key, value);
  }
  
  protected void processRemovedLRU(Object key, Object value) {}
  
  public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
    this.maximumSize = in.readInt();
    int size = in.readInt();
    for (int i = 0; i < size; i++) {
      Object key = in.readObject();
      Object value = in.readObject();
      put(key, value);
    } 
  }
  
  public void writeExternal(ObjectOutput out) throws IOException {
    out.writeInt(this.maximumSize);
    out.writeInt(size());
    for (Iterator iterator = keySet().iterator(); iterator.hasNext(); ) {
      Object key = iterator.next();
      out.writeObject(key);
      Object value = super.get(key);
      out.writeObject(value);
    } 
  }
  
  public int getMaximumSize() { return this.maximumSize; }
  
  public void setMaximumSize(int maximumSize) {
    this.maximumSize = maximumSize;
    while (size() > maximumSize)
      removeLRU(); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\collections\LRUMap.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */