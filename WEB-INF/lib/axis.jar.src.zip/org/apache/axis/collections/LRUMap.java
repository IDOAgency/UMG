/*     */ package org.apache.axis.collections;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LRUMap
/*     */   extends SequencedHashMap
/*     */   implements Externalizable
/*     */ {
/*  52 */   private int maximumSize = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long serialVersionUID = 2197433140769957051L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public LRUMap() { this(100); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LRUMap(int i) {
/*  72 */     super(i);
/*  73 */     this.maximumSize = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/*  89 */     if (!containsKey(key)) return null;
/*     */     
/*  91 */     Object value = remove(key);
/*  92 */     super.put(key, value);
/*  93 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 110 */     int mapSize = size();
/* 111 */     retval = null;
/*     */     
/* 113 */     if (mapSize >= this.maximumSize)
/*     */     {
/*     */ 
/*     */       
/* 117 */       if (!containsKey(key))
/*     */       {
/* 119 */         removeLRU();
/*     */       }
/*     */     }
/*     */     
/* 123 */     return super.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeLRU() {
/* 133 */     Object key = getFirstKey();
/*     */ 
/*     */     
/* 136 */     Object value = super.get(key);
/*     */     
/* 138 */     remove(key);
/*     */     
/* 140 */     processRemovedLRU(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processRemovedLRU(Object key, Object value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 158 */     this.maximumSize = in.readInt();
/* 159 */     int size = in.readInt();
/*     */     
/* 161 */     for (int i = 0; i < size; i++) {
/* 162 */       Object key = in.readObject();
/* 163 */       Object value = in.readObject();
/* 164 */       put(key, value);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 169 */     out.writeInt(this.maximumSize);
/* 170 */     out.writeInt(size());
/* 171 */     for (Iterator iterator = keySet().iterator(); iterator.hasNext(); ) {
/* 172 */       Object key = iterator.next();
/* 173 */       out.writeObject(key);
/*     */ 
/*     */       
/* 176 */       Object value = super.get(key);
/* 177 */       out.writeObject(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public int getMaximumSize() { return this.maximumSize; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaximumSize(int maximumSize) {
/* 194 */     this.maximumSize = maximumSize;
/* 195 */     while (size() > maximumSize)
/* 196 */       removeLRU(); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\axis.jar!\org\apache\axis\collections\LRUMap.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */