/*     */ package inetsoft.widget;
/*     */ 
/*     */ import inetsoft.widget.util.EventMgr;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.TextEvent;
/*     */ import java.awt.event.TextListener;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateSelector
/*     */   extends JPanel
/*     */ {
/*     */   protected EventMgr eventMgr;
/*     */   Calendar cal;
/*     */   SCalendar calendar;
/*     */   Spinner year;
/*     */   JComboBox month;
/*     */   
/*  50 */   public DateSelector() { this(new Date()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateSelector(Date paramDate) {
/* 211 */     this.eventMgr = new EventMgr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     this.cal = Calendar.getInstance();
/* 244 */     this.calendar = new SCalendar();
/* 245 */     this.year = new Spinner(1900, 9000);
/* 246 */     this.month = new JComboBox(mname); this.cal.setTimeZone(TimeZone.getDefault()); this.month.setEditable(false); this.month.setLightWeightPopupEnabled(false); this.calendar.setTitle(3); JPanel jPanel = new JPanel(); jPanel.add(this.month); jPanel.add(this.year); setLayout(new BorderLayout()); add(jPanel, "North"); add(this.calendar, "Center"); this.month.addItemListener(new ItemListener(this) { private final DateSelector this$0; public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.calendar.setMonth(this.this$0.month.getSelectedIndex()); } }); this.year.addActionListener(new ActionListener(this) { private final DateSelector this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.calendar.setYear(this.this$0.year.getCurrent()); this.this$0.eventMgr.postEvent(new ActionEvent(this.this$0, 1001, "Year")); } }); this.year.addTextListener(new TextListener(this) { private final DateSelector this$0; public void textValueChanged(TextEvent param1TextEvent) { this.this$0.calendar.setYear(this.this$0.year.getCurrent()); } }); this.calendar.addItemListener(new ItemListener(this) { private final DateSelector this$0; public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.eventMgr.postEvent(param1ItemEvent); } }); this.calendar.addActionListener(new ActionListener(this) { private final DateSelector this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.eventMgr.postEvent(new ActionEvent(this.this$0, 1001, "Select")); } }); setSelectedDate(paramDate);
/* 247 */   } static String[] mname = { "January", "Feburary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
/*     */   
/*     */   public void setSelectedDate(Date paramDate) {
/*     */     this.cal.setTime((paramDate == null) ? new Date() : paramDate);
/*     */     this.year.setCurrent(this.cal.get(1));
/*     */     this.month.setSelectedIndex(this.cal.get(2));
/*     */     this.calendar.setYear(this.cal.get(1));
/*     */     this.calendar.setMonth(this.cal.get(2));
/*     */     this.calendar.select(this.cal.get(5), this.cal.get(5));
/*     */   }
/*     */   
/*     */   public Date getSelectedDate() {
/*     */     this.cal.set(getYear(), getMonth(), getDay(), 0, 0, 0);
/*     */     this.cal.set(14, 0);
/*     */     return this.cal.getTime();
/*     */   }
/*     */   
/*     */   public int getYear() { return this.year.getCurrent(); }
/*     */   
/*     */   public int getMonth() { return this.month.getSelectedIndex(); }
/*     */   
/*     */   public int getDay() {
/*     */     int i = this.calendar.getStartDay();
/*     */     return (i > 0) ? i : 1;
/*     */   }
/*     */   
/*     */   public static void setMonthNames(String[] paramArrayOfString) { mname = paramArrayOfString; }
/*     */   
/*     */   public void setForeground(Color paramColor) {
/*     */     super.setForeground(paramColor);
/*     */     if (this.year != null) {
/*     */       this.calendar.setForeground(paramColor);
/*     */       this.year.setForeground(paramColor);
/*     */       this.month.setForeground(paramColor);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setBackground(Color paramColor) {
/*     */     super.setBackground(paramColor);
/*     */     if (this.year != null) {
/*     */       this.calendar.setBackground(paramColor);
/*     */       this.year.setBackground(paramColor);
/*     */       this.month.setBackground(paramColor);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setFont(Font paramFont) {
/*     */     super.setFont(paramFont);
/*     */     if (this.year != null) {
/*     */       this.calendar.setFont(paramFont);
/*     */       this.year.setFont(paramFont);
/*     */       this.month.setFont(paramFont);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
/*     */   
/*     */   public void addItemListener(ItemListener paramItemListener) { this.eventMgr.addItemListener(paramItemListener); }
/*     */   
/*     */   public void removeItemListener(ItemListener paramItemListener) { this.eventMgr.removeItemListener(paramItemListener); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\DateSelector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */