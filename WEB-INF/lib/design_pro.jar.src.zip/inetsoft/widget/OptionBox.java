/*     */ package inetsoft.widget;
/*     */ 
/*     */ import inetsoft.widget.util.EventMgr;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.ItemSelectable;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.border.TitledBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionBox
/*     */   extends JPanel
/*     */   implements ItemSelectable
/*     */ {
/*     */   protected EventMgr eventMgr;
/*     */   protected JPanel pnl;
/*     */   private ItemListener listener;
/*     */   private int row;
/*     */   private int col;
/*     */   private Hashtable cbmap;
/*     */   private GridLayout layout;
/*     */   private TitledBorder border;
/*     */   
/*  53 */   public OptionBox() { this(1, 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OptionBox(int paramInt1, int paramInt2) {
/* 266 */     this.eventMgr = new EventMgr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 305 */     this.listener = new OptionListener(this, null);
/* 306 */     this.row = 1; this.col = 1;
/* 307 */     this.cbmap = new Hashtable();
/*     */     
/* 309 */     this.border = new TitledBorder((String)null);
/*     */     setLayout(new BorderLayout());
/*     */     add(this.pnl = new JPanel(), "Center");
/*     */     this.pnl.setLayout(this.layout = new GridLayout(this.row = paramInt1, this.col = paramInt2));
/*     */     EmptyBorder emptyBorder = new EmptyBorder(5, 5, 5, 5);
/*     */     this.pnl.setBorder(new CompoundBorder(this.border, emptyBorder));
/*     */   }
/*     */   
/*     */   public void setRowCount(int paramInt) { this.layout.setRows(paramInt); }
/*     */   
/*     */   public int getRowCount() { return this.layout.getRows(); }
/*     */   
/*     */   public void setColCount(int paramInt) { this.layout.setColumns(paramInt); }
/*     */   
/*     */   public int getColCount() { return this.layout.getColumns(); }
/*     */   
/*     */   public void add(String paramString, boolean paramBoolean) {
/*     */     JToggleButton jToggleButton = createCheckbox(paramString, paramBoolean);
/*     */     jToggleButton.addItemListener(this.listener);
/*     */     this.pnl.add(jToggleButton);
/*     */     this.cbmap.put(paramString, jToggleButton);
/*     */   }
/*     */   
/*     */   public void remove(String paramString) {
/*     */     JToggleButton jToggleButton = (JToggleButton)this.cbmap.get(paramString);
/*     */     if (jToggleButton != null) {
/*     */       this.pnl.remove(jToggleButton);
/*     */       this.cbmap.remove(paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setSelectedItem(String paramString) {
/*     */     JToggleButton jToggleButton = (JToggleButton)this.cbmap.get(paramString);
/*     */     if (jToggleButton != null)
/*     */       jToggleButton.setSelected(true); 
/*     */   }
/*     */   
/*     */   public Object[] getSelectedObjects() {
/*     */     Vector vector = new Vector();
/*     */     Enumeration enumeration = this.cbmap.keys();
/*     */     while (enumeration.hasMoreElements()) {
/*     */       Object object = enumeration.nextElement();
/*     */       JToggleButton jToggleButton = (JToggleButton)this.cbmap.get(object);
/*     */       if (jToggleButton.isSelected())
/*     */         vector.addElement(object); 
/*     */     } 
/*     */     Object[] arrayOfObject = new Object[vector.size()];
/*     */     vector.copyInto(arrayOfObject);
/*     */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   public boolean isSelected(String paramString) {
/*     */     Checkbox checkbox = (Checkbox)this.cbmap.get(paramString);
/*     */     return (checkbox != null) ? checkbox.getState() : 0;
/*     */   }
/*     */   
/*     */   public String getTitle() { return this.border.getTitle(); }
/*     */   
/*     */   public Border getBorder() { return (this.border == null) ? null : this.border.getBorder(); }
/*     */   
/*     */   public int getTitlePosition() { return this.border.getTitlePosition(); }
/*     */   
/*     */   public int getTitleJustification() { return this.border.getTitleJustification(); }
/*     */   
/*     */   public Font getTitleFont() { return this.border.getTitleFont(); }
/*     */   
/*     */   public Color getTitleColor() { return this.border.getTitleColor(); }
/*     */   
/*     */   public void setTitle(String paramString) { this.border.setTitle(paramString); }
/*     */   
/*     */   public void setBorder(Border paramBorder) {
/*     */     if (this.border != null) {
/*     */       this.border.setBorder(paramBorder);
/*     */     } else {
/*     */       super.setBorder(paramBorder);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setTitlePosition(int paramInt) { this.border.setTitlePosition(paramInt); }
/*     */   
/*     */   public void setTitleJustification(int paramInt) { this.border.setTitleJustification(paramInt); }
/*     */   
/*     */   public void setTitleFont(Font paramFont) { this.border.setTitleFont(paramFont); }
/*     */   
/*     */   public void setTitleColor(Color paramColor) { this.border.setTitleColor(paramColor); }
/*     */   
/*     */   public void addItemListener(ItemListener paramItemListener) { this.eventMgr.addItemListener(paramItemListener); }
/*     */   
/*     */   public void removeItemListener(ItemListener paramItemListener) { this.eventMgr.removeItemListener(paramItemListener); }
/*     */   
/*     */   protected JToggleButton createCheckbox(String paramString, boolean paramBoolean) { return new JCheckBox(paramString, paramBoolean); }
/*     */   
/*     */   private class OptionListener implements ItemListener {
/*     */     private Object oItem;
/*     */     private final OptionBox this$0;
/*     */     
/*     */     private OptionListener(OptionBox this$0) {
/*     */       this.this$0 = this$0;
/*     */       this.oItem = "";
/*     */     }
/*     */     
/*     */     public void itemStateChanged(ItemEvent param1ItemEvent) {
/*     */       if (!this.oItem.equals(param1ItemEvent.getItem())) {
/*     */         this.this$0.eventMgr.postEvent(new ItemEvent(this.this$0, param1ItemEvent.getID(), param1ItemEvent.getItem(), param1ItemEvent.getStateChange()));
/*     */         this.oItem = param1ItemEvent.getItem();
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\OptionBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */