package inetsoft.widget;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.ItemSelectable;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.Icon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.tree.TreeModel;

public class TreeCombo extends ComboBase implements ItemSelectable {
  STree tree;
  
  boolean usePath;
  
  public TreeCombo() {
    super(8);
    this.usePath = false;
  }
  
  public TreeCombo(int paramInt) {
    super(paramInt);
    this.usePath = false;
  }
  
  public TreeCombo(String paramString) {
    super(paramString);
    this.usePath = false;
  }
  
  public TreeCombo(String paramString, int paramInt) {
    super(paramString, paramInt);
    this.usePath = false;
  }
  
  public void setTreeModel(TreeModel paramTreeModel) { this.tree.setModel(paramTreeModel); }
  
  public TreeModel getTreeModel() { return this.tree.getModel(); }
  
  public void setUsePath(boolean paramBoolean) { this.usePath = paramBoolean; }
  
  public boolean isUsePath() { return this.usePath; }
  
  public void addItemListener(ItemListener paramItemListener) { this.eventMgr.addItemListener(paramItemListener); }
  
  public void removeItemListener(ItemListener paramItemListener) { this.eventMgr.removeItemListener(paramItemListener); }
  
  public Object[] getSelectedObjects() { return this.tree.getSelectedObjects(); }
  
  public char getSeparator() { return this.tree.getSeparator(); }
  
  public void setSeparator(char paramChar) { this.tree.setSeparator(paramChar); }
  
  public STree.Node add(String paramString) { return findNode(paramString, true); }
  
  public void setSelected(String paramString, boolean paramBoolean) { this.tree.setSelected(paramString, paramBoolean); }
  
  public void clearSelection() { this.tree.clearSelection(); }
  
  public void expand(String paramString) { this.tree.expand(paramString); }
  
  public void expand(String paramString, int paramInt) { this.tree.expand(paramString, paramInt); }
  
  public void setForceExpanded(String paramString, boolean paramBoolean) { this.tree.setForceExpanded(paramString, paramBoolean); }
  
  public boolean isForceExpanded(String paramString) { return this.tree.isForceExpanded(paramString); }
  
  public void expand(int paramInt) { this.tree.expand(paramInt); }
  
  public void expandAll() { this.tree.expandAll(); }
  
  public void collapse(String paramString) { this.tree.collapse(paramString); }
  
  public void collapse(String paramString, int paramInt) { this.tree.collapse(paramString, paramInt); }
  
  public void remove(String paramString) { this.tree.remove(paramString); }
  
  public void removeAll() { this.tree.removeAll(); }
  
  public String getSelectedLabel() { return this.tree.getSelectedLabel(); }
  
  public String getSelectedPath() { return this.tree.getSelectedPath(); }
  
  public void setMultiSelect(boolean paramBoolean) { this.tree.setMultiSelect(paramBoolean); }
  
  public boolean isMultiSelect() { return this.tree.isMultiSelect(); }
  
  public void setSelectLeafOnly(boolean paramBoolean) { this.tree.setSelectLeafOnly(paramBoolean); }
  
  public boolean isSelectLeafOnly() { return this.tree.isSelectLeafOnly(); }
  
  public void setIcon(Icon paramIcon, int paramInt) { this.tree.setIcon(paramIcon, paramInt); }
  
  public void setIcon(String paramString, Icon paramIcon) { this.tree.setIcon(paramString, paramIcon); }
  
  public STree.Node findNode(String paramString, boolean paramBoolean) { return this.tree.findNode(paramString, paramBoolean); }
  
  public Icon getIcon(int paramInt) { return this.tree.getIcon(paramInt); }
  
  public void setSortint(int paramInt) { this.tree.setSorting(paramInt); }
  
  public int getSortint() { return this.tree.getSorting(); }
  
  protected void init() {
    super.init();
    this.tree = new STree();
    this.tree.addItemListener(new ItemListener(this) {
          private final TreeCombo this$0;
          
          public void itemStateChanged(ItemEvent param1ItemEvent) {
            if (param1ItemEvent.getStateChange() == 1) {
              STree.Node node = (STree.Node)param1ItemEvent.getItem();
              this.this$0.setText(this.this$0.usePath ? node.getPath() : node.getLabel());
              this.this$0.popdown();
            } 
            this.this$0.eventMgr.postEvent(new ItemEvent(this.this$0, 701, param1ItemEvent.getItem(), param1ItemEvent.getStateChange()));
          }
        });
  }
  
  protected JPanel createMenu() { return new TreeWin(this); }
  
  private class TreeWin extends JPanel {
    private final TreeCombo this$0;
    
    public TreeWin(TreeCombo this$0) {
      this.this$0 = this$0;
      setLayout(new BorderLayout());
      Dimension dimension = this$0.getSize();
      JScrollPane jScrollPane = new JScrollPane(this$0.tree);
      jScrollPane.setPreferredSize(new Dimension(Math.max(200, dimension.width), 200));
      add(jScrollPane, "Center");
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\TreeCombo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */