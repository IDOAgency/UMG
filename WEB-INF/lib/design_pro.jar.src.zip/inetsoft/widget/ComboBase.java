/*     */ package inetsoft.widget;
/*     */ 
/*     */ import inetsoft.widget.util.EventMgr;
/*     */ import inetsoft.widget.util.Tool;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.TextEvent;
/*     */ import java.awt.event.TextListener;
/*     */ import java.lang.reflect.Constructor;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.JWindow;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ComboBase
/*     */   extends JPanel
/*     */ {
/*     */   protected EventMgr eventMgr;
/*     */   JTextField text;
/*     */   JWindow win;
/*     */   JButton button;
/*     */   
/*     */   public ComboBase() {
/* 151 */     this.eventMgr = new EventMgr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 405 */     this.text = new JTextField();
/* 406 */     this.win = null;
/* 407 */     this.button = new JButton(); init(); } public ComboBase(int paramInt) { this.eventMgr = new EventMgr(); this.text = new JTextField(); this.win = null; this.button = new JButton(); this.text.setColumns(paramInt); init(); } public ComboBase(String paramString) { this.eventMgr = new EventMgr(); this.text = new JTextField(); this.win = null; this.button = new JButton(); this.text.setText(paramString); init(); } public ComboBase(String paramString, int paramInt) { this.eventMgr = new EventMgr(); this.text = new JTextField(); this.win = null; this.button = new JButton();
/*     */     this.text.setText(paramString);
/*     */     this.text.setColumns(paramInt);
/*     */     init(); }
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/*     */     this.button.setEnabled(paramBoolean);
/*     */     this.text.setEnabled(paramBoolean);
/*     */     super.setEnabled(paramBoolean);
/*     */   }
/*     */   
/*     */   public int getColumns() { return this.text.getColumns(); }
/*     */   
/*     */   public void setColumns(int paramInt) { this.text.setColumns(paramInt); }
/*     */   
/*     */   public void setForeground(Color paramColor) {
/*     */     super.setForeground(paramColor);
/*     */     if (this.text != null)
/*     */       this.text.setForeground(paramColor); 
/*     */   }
/*     */   
/*     */   public void setBackground(Color paramColor) {
/*     */     super.setBackground(paramColor);
/*     */     if (this.text != null)
/*     */       this.text.setBackground(paramColor); 
/*     */   }
/*     */   
/*     */   public void setFont(Font paramFont) {
/*     */     super.setFont(paramFont);
/*     */     if (this.text != null)
/*     */       this.text.setFont(paramFont); 
/*     */   }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
/*     */   
/*     */   public void addTextListener(TextListener paramTextListener) { this.eventMgr.addTextListener(paramTextListener); }
/*     */   
/*     */   public void removeTextListener(TextListener paramTextListener) { this.eventMgr.removeTextListener(paramTextListener); }
/*     */   
/*     */   public boolean isPopuped() { return (this.win != null && this.win.isVisible()); }
/*     */   
/*     */   public void popup() {
/*     */     if (!isPopuped()) {
/*     */       if (this.win == null) {
/*     */         this.win = createWindow();
/*     */         this.win.getContentPane().add(createMenu());
/*     */       } 
/*     */       this.win.setSize(1, 1);
/*     */       this.win.pack();
/*     */       Dimension dimension1 = getSize();
/*     */       Point point2 = getLocationOnScreen();
/*     */       Dimension dimension2 = this.win.getSize();
/*     */       point2.x += ((dimension1.width - dimension2.width > 0) ? (dimension1.width - dimension2.width) : 0);
/*     */       Point point1 = new Point(point2.x, point2.y + dimension1.height);
/*     */       this.win.setLocation(point1.x, point1.y);
/*     */       this.win.setVisible(true);
/*     */       this.win.setLocation(point1.x, point1.y);
/*     */       this.win.show();
/*     */       if (isEditable())
/*     */         requestFocus(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void popdown() {
/*     */     if (this.win != null) {
/*     */       this.win.hide();
/*     */       requestFocus();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setText(String paramString) { this.text.setText(paramString); }
/*     */   
/*     */   public String getText() { return this.text.getText(); }
/*     */   
/*     */   public boolean isEditable() { return this.text.isEditable(); }
/*     */   
/*     */   public void setEditable(boolean paramBoolean) { this.text.setEditable(paramBoolean); }
/*     */   
/*     */   public int getSelectionStart() { return this.text.getSelectionStart(); }
/*     */   
/*     */   public int getSelectionEnd() { return this.text.getSelectionEnd(); }
/*     */   
/*     */   public void select(int paramInt1, int paramInt2) { this.text.select(paramInt1, paramInt2); }
/*     */   
/*     */   public void selectAll() { this.text.selectAll(); }
/*     */   
/*     */   protected void init() {
/*     */     setLayout(new BorderLayout());
/*     */     this.text.setEditable(false);
/*     */     String str = "/inetsoft/widget/images/menuarrow.gif";
/*     */     this.button.setIcon(new ImageIcon(getClass().getResource(str)));
/*     */     this.button.setPreferredSize(new Dimension(12, 12));
/*     */     this.button.addActionListener(new ActionListener(this) {
/*     */           private final ComboBase this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */             if (this.this$0.isPopuped()) {
/*     */               this.this$0.popdown();
/*     */             } else {
/*     */               this.this$0.popup();
/*     */             } 
/*     */           }
/*     */         });
/*     */     this.text.addActionListener(new ActionListener(this) {
/*     */           private final ComboBase this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.eventMgr.postEvent(new ActionEvent(this.this$0, 1001, param1ActionEvent.getActionCommand())); }
/*     */         });
/*     */     this.text.getDocument().addDocumentListener(new DocumentListener(this) {
/*     */           private final ComboBase this$0;
/*     */           
/*     */           public void insertUpdate(DocumentEvent param1DocumentEvent) { changedUpdate(param1DocumentEvent); }
/*     */           
/*     */           public void removeUpdate(DocumentEvent param1DocumentEvent) { changedUpdate(param1DocumentEvent); }
/*     */           
/*     */           public void changedUpdate(DocumentEvent param1DocumentEvent) { this.this$0.eventMgr.postEvent(new TextEvent(this.this$0, 900)); }
/*     */         });
/*     */     this.text.addMouseListener(new MouseAdapter(this) {
/*     */           private final ComboBase this$0;
/*     */           
/*     */           public void mousePressed(MouseEvent param1MouseEvent) {
/*     */             if (!this.this$0.isEditable() && this.this$0.text.isEnabled())
/*     */               if (this.this$0.isPopuped()) {
/*     */                 this.this$0.popdown();
/*     */               } else {
/*     */                 this.this$0.popup();
/*     */               }  
/*     */           }
/*     */         });
/*     */     add(this.text, "Center");
/*     */     add(this.button, "East");
/*     */   }
/*     */   
/*     */   public void addNotify() {
/*     */     super.addNotify();
/*     */     Tool.findWindow(this).addComponentListener(new ComponentAdapter(this) {
/*     */           private final ComboBase this$0;
/*     */           
/*     */           public void componentMoved(ComponentEvent param1ComponentEvent) { this.this$0.popdown(); }
/*     */         });
/*     */   }
/*     */   
/*     */   protected JWindow createWindow() {
/*     */     try {
/*     */       Class clazz = Class.forName("javax.swing.JWindow");
/*     */       Constructor constructor = null;
/*     */       Object[] arrayOfObject = { null };
/*     */       try {
/*     */         constructor = clazz.getConstructor(new Class[] { java.awt.Window.class });
/*     */         arrayOfObject[0] = Tool.findWindow(this);
/*     */       } catch (Exception exception) {
/*     */         constructor = clazz.getConstructor(new Class[] { java.awt.Frame.class });
/*     */         arrayOfObject[0] = Tool.findFrame(this);
/*     */       } 
/*     */       return (JWindow)constructor.newInstance(arrayOfObject);
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract JPanel createMenu();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\ComboBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */