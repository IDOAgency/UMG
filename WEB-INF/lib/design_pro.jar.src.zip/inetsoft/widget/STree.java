package inetsoft.widget;

import inetsoft.util.internal.FVector;
import inetsoft.widget.util.EventMgr;
import java.awt.Component;
import java.awt.ItemSelectable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.Collator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.ExpandVetoException;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class STree extends JTree implements ItemSelectable {
  public static final int ICON_OPEN = 1;
  
  public static final int ICON_CLOSED = 2;
  
  public static final int ICON_LEAF = 3;
  
  public static final int SORT_NONE = 0;
  
  public static final int SORT_ASCENT = 1;
  
  public static final int SORT_DESCENT = 2;
  
  protected EventMgr eventMgr;
  
  MouseListener mouseListener;
  
  Icon folderExpanded;
  
  Icon folderCollapse;
  
  Icon folderLeaf;
  
  boolean suspended;
  
  char separator;
  
  Node root;
  
  boolean selLeafOnly;
  
  int order;
  
  Hashtable editmap;
  
  DefaultTreeModel model;
  
  public STree() {
    this.eventMgr = new EventMgr();
    this.mouseListener = new MouseAdapter(this) {
        private final STree this$0;
        
        public void mouseClicked(MouseEvent param1MouseEvent) {
          int i = this.this$0.getRowForLocation(param1MouseEvent.getX(), param1MouseEvent.getY());
          if (i != -1 && param1MouseEvent.getClickCount() == 2) {
            STree.Node node = (STree.Node)this.this$0.getPathForRow(i).getLastPathComponent();
            if (!this.this$0.selLeafOnly || node.isLeaf())
              this.this$0.eventMgr.postEvent(new ActionEvent(this.this$0, 1001, node.getPath(), param1MouseEvent.getModifiers())); 
          } 
        }
      };
    this.suspended = false;
    this.separator = '.';
    this.root = createNode(null, "");
    this.selLeafOnly = false;
    this.order = 0;
    this.editmap = new Hashtable();
    super.setModel(this.model = new DefaultTreeModel(this.root));
    setRootVisible(false);
    setShowsRootHandles(true);
    addMouseListener(this.mouseListener);
    addTreeWillExpandListener(new TreeWillExpandListener(this) {
          private final STree this$0;
          
          public void treeWillExpand(TreeExpansionEvent param1TreeExpansionEvent) throws ExpandVetoException {}
          
          public void treeWillCollapse(TreeExpansionEvent param1TreeExpansionEvent) throws ExpandVetoException {
            STree.Node node = (STree.Node)param1TreeExpansionEvent.getPath().getLastPathComponent();
            if (node.isForceExpanded())
              throw new ExpandVetoException(param1TreeExpansionEvent); 
          }
        });
    addTreeSelectionListener(new TreeSelectionListener(this) {
          private final STree this$0;
          
          public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {}
        });
    setCellRenderer(new CellRenderer(this));
  }
  
  public void setModel(TreeModel paramTreeModel) {
    if (!(paramTreeModel instanceof DefaultTreeModel))
      return; 
    DefaultTreeModel defaultTreeModel = (DefaultTreeModel)paramTreeModel;
    if (!(defaultTreeModel.getRoot() instanceof Node))
      return; 
    this.root = (Node)defaultTreeModel.getRoot();
    super.setModel(paramTreeModel);
  }
  
  public Node getRoot() { return this.root; }
  
  public char getSeparator() { return this.separator; }
  
  public void setSeparator(char paramChar) { this.separator = paramChar; }
  
  public Node add(String paramString) { return findNode(paramString, true); }
  
  public boolean isPathEditable(TreePath paramTreePath) {
    if (this.editmap.size() == 0)
      return isEditable(); 
    return isEditable(((Node)paramTreePath.getLastPathComponent()).getPath());
  }
  
  public void setEditable(String paramString, boolean paramBoolean) {
    if (paramBoolean)
      setEditable(true); 
    this.editmap.put(paramString, new Boolean(paramBoolean));
  }
  
  public boolean isEditable(String paramString) {
    Boolean bool = (Boolean)this.editmap.get(paramString);
    return (bool != null && bool.booleanValue());
  }
  
  public void setSelected(String paramString, boolean paramBoolean) {
    Node node = findNode(paramString, false);
    if (node != null)
      if (paramBoolean) {
        addSelectionPath(node.getTreePath());
      } else {
        removeSelectionPath(node.getTreePath());
      }  
  }
  
  public void setMultiSelect(boolean paramBoolean) { getSelectionModel().setSelectionMode(paramBoolean ? 4 : 1); }
  
  public boolean isMultiSelect() { return (getSelectionModel().getSelectionMode() != 1); }
  
  public void expand(String paramString) { expand(paramString, 0); }
  
  public void expand(String paramString, int paramInt) {
    Node node = findNode(paramString, false);
    if (node != null)
      node.expand(paramInt); 
  }
  
  public void setForceExpanded(String paramString, boolean paramBoolean) {
    Node node = findNode(paramString, false);
    if (node != null)
      node.setForceExpanded(paramBoolean); 
  }
  
  public boolean isForceExpanded(String paramString) {
    Node node = findNode(paramString, false);
    return (node != null) ? node.isForceExpanded() : 0;
  }
  
  public void expand(int paramInt) { this.root.expand(paramInt - 1); }
  
  public void expandAll() { this.root.expandAll(); }
  
  public void collapse(String paramString) { collapse(paramString, 0); }
  
  public void collapse(String paramString, int paramInt) {
    Node node = findNode(paramString, false);
    if (node != null)
      node.collapse(paramInt); 
  }
  
  public void setLeaf(String paramString, boolean paramBoolean) {
    Node node = findNode(paramString, false);
    if (node != null)
      node.setLeaf(paramBoolean); 
  }
  
  public void remove(String paramString) {
    synchronized (getTreeLock()) {
      Node node = this.root.findNode(paramString, false);
      if (node == null)
        return; 
      node.remove();
    } 
  }
  
  public void removeAll() {
    synchronized (getTreeLock()) {
      this.root.removeAll();
    } 
  }
  
  public String getSelectedLabel() {
    TreePath treePath = getSelectionPath();
    return (treePath == null) ? null : ((Node)treePath.getLastPathComponent()).getLabel();
  }
  
  public String getSelectedPath() {
    TreePath treePath = getSelectionPath();
    return (treePath == null) ? null : ((Node)treePath.getLastPathComponent()).getPath();
  }
  
  public Node getSelectedNode() {
    TreePath treePath = getSelectionPath();
    return (treePath == null) ? null : (Node)treePath.getLastPathComponent();
  }
  
  public Object[] getSelectedObjects() { return getSelectedPaths(); }
  
  public String[] getSelectedPaths() {
    TreePath[] arrayOfTreePath = getSelectionPaths();
    String[] arrayOfString = new String[arrayOfTreePath.length];
    for (byte b = 0; b < arrayOfTreePath.length; b++)
      arrayOfString[b] = ((Node)arrayOfTreePath[b].getLastPathComponent()).getPath(); 
    return arrayOfString;
  }
  
  public void setSelectLeafOnly(boolean paramBoolean) { this.selLeafOnly = paramBoolean; }
  
  public boolean isSelectLeafOnly() { return this.selLeafOnly; }
  
  public void setIcon(Icon paramIcon, int paramInt) {
    switch (paramInt) {
      case 1:
        this.folderExpanded = paramIcon;
        break;
      case 2:
        this.folderCollapse = paramIcon;
        break;
      case 3:
        this.folderLeaf = paramIcon;
        break;
    } 
    repaint(200L);
  }
  
  public Icon getIcon(int paramInt) {
    switch (paramInt) {
      case 1:
        return this.folderExpanded;
      case 2:
        return this.folderCollapse;
    } 
    return this.folderLeaf;
  }
  
  public void setIcon(String paramString, Icon paramIcon) {
    Node node = this.root.findNode(paramString, true);
    if (node != null) {
      node.setIcon(paramIcon);
      repaint(200L);
    } 
  }
  
  public Node findNode(String paramString, boolean paramBoolean) { return this.root.findNode(paramString, paramBoolean); }
  
  public TreePath getTreePath(String paramString) {
    Node node = findNode(paramString, false);
    return (node == null) ? null : node.getTreePath();
  }
  
  public void setSuspended(boolean paramBoolean) {
    if (this.suspended != paramBoolean)
      this.suspended = paramBoolean; 
  }
  
  public boolean isSuspended() { return this.suspended; }
  
  public void setSorting(int paramInt) {
    if (this.order != paramInt) {
      this.order = paramInt;
      if (paramInt != 0)
        this.root.sort(paramInt); 
    } 
  }
  
  protected void sort(Vector paramVector, boolean paramBoolean) {
    for (byte b = 1; b < paramVector.size(); b++) {
      for (byte b1 = b; !b1; ) {
        Node node1 = (Node)paramVector.elementAt(b1);
        Node node2 = (Node)paramVector.elementAt(b1 - 1);
        int i = node1.compare(node2);
        if ((paramBoolean && i < 0) || (!paramBoolean && i > 0)) {
          paramVector.setElementAt(node1, b1 - 1);
          paramVector.setElementAt(node2, b1);
          b1--;
        } 
        break;
      } 
    } 
  }
  
  public int getSorting() { return this.order; }
  
  public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
  
  public void addItemListener(ItemListener paramItemListener) { this.eventMgr.addItemListener(paramItemListener); }
  
  public void removeItemListener(ItemListener paramItemListener) { this.eventMgr.removeItemListener(paramItemListener); }
  
  public void fireItemEvent(ItemEvent paramItemEvent) { this.eventMgr.postEvent(paramItemEvent); }
  
  protected void fireValueChanged(TreeSelectionEvent paramTreeSelectionEvent) {
    if (this.selLeafOnly && paramTreeSelectionEvent.isAddedPath()) {
      TreePath[] arrayOfTreePath1 = paramTreeSelectionEvent.getPaths();
      for (byte b1 = 0; b1 < arrayOfTreePath1.length; b1++) {
        Node node = (Node)arrayOfTreePath1[b1].getLastPathComponent();
        if (!node.isLeaf()) {
          removeSelectionPath(arrayOfTreePath1[b1]);
          return;
        } 
      } 
    } 
    TreePath[] arrayOfTreePath = paramTreeSelectionEvent.getPaths();
    for (byte b = 0; b < arrayOfTreePath.length; b++) {
      Node node = (Node)arrayOfTreePath[b].getLastPathComponent();
      fireItemEvent(new ItemEvent(this, 701, node, paramTreeSelectionEvent.isAddedPath(arrayOfTreePath[b]) ? 1 : 2));
      super.fireValueChanged(paramTreeSelectionEvent);
    } 
  }
  
  protected Node createNode(Node paramNode, String paramString) { return new Node(this, paramNode, paramString); }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException { paramObjectOutputStream.defaultWriteObject(); }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException { paramObjectInputStream.defaultReadObject(); }
  
  public class Node implements MutableTreeNode, Serializable {
    protected Node parent;
    
    protected FVector children;
    
    private Icon nodeIcon;
    
    private String label;
    
    private boolean alwaysExpanded;
    
    private Boolean overleaf;
    
    private Object userData;
    
    private int treeW;
    
    private final STree this$0;
    
    protected Node(STree this$0, String param1String) {
      this.this$0 = this$0;
      this.parent = null;
      this.children = new FVector();
      this.alwaysExpanded = false;
      this.overleaf = null;
      this.treeW = -1;
      this.label = param1String;
    }
    
    protected Node(STree this$0, Node param1Node, String param1String) {
      this(this$0, param1String);
      this.parent = param1Node;
    }
    
    public TreeNode getChildAt(int param1Int) { return (TreeNode)this.children.getElement(param1Int); }
    
    public int getChildCount() { return this.children.size(); }
    
    public Node getChild(int param1Int) { return (Node)this.children.getElement(param1Int); }
    
    public int getTreeWidth() { return (this.treeW >= 0) ? this.treeW : (this.treeW = getTreeWidth(0, true)); }
    
    private int getTreeWidth(int param1Int, boolean param1Boolean) {
      synchronized (this.this$0.getTreeLock()) {
        int i = param1Int + 1;
        if (param1Boolean || this.this$0.isExpanded(getTreePath()))
          for (byte b = 0; b < this.children.size(); b++) {
            Node node = (Node)this.children.getElement(b);
            i += node.getTreeWidth(param1Int, param1Boolean);
          }  
        return i;
      } 
    }
    
    public TreeNode getParent() { return this.parent; }
    
    public int getIndex(TreeNode param1TreeNode) { return this.children.indexOf(param1TreeNode); }
    
    public boolean getAllowsChildren() { return (this.overleaf == null || !this.overleaf.booleanValue()); }
    
    public void setLeaf(boolean param1Boolean) { this.overleaf = new Boolean(param1Boolean); }
    
    public boolean isLeaf() { return ((this.overleaf == null || this.overleaf.booleanValue()) && this.children.size() == 0); }
    
    public Enumeration children() { return this.children.elements(); }
    
    public TreePath getTreePath() {
      if (this.parent == null)
        return new TreePath(this); 
      return new STree.TreePath2(this.this$0, this.parent.getTreePath(), this);
    }
    
    void setIcon(Icon param1Icon) { this.nodeIcon = param1Icon; }
    
    Icon getIcon() { return (this.nodeIcon == null) ? this.this$0.getIcon(isLeaf() ? 3 : (this.this$0.isExpanded(getTreePath()) ? 1 : 2)) : this.nodeIcon; }
    
    public void setUserData(Object param1Object) { this.userData = param1Object; }
    
    public Object getUserData() { return this.userData; }
    
    public boolean isAncestor(Node param1Node) {
      for (Node node = this.parent; node != null; node = node.parent) {
        if (node == param1Node)
          return true; 
      } 
      return false;
    }
    
    void addChild(Node param1Node) {
      if (param1Node.parent != null)
        param1Node.parent.remove(param1Node); 
      param1Node.parent = this;
      insertNode(param1Node);
    }
    
    Node insertNode(Node param1Node) {
      setLeaf(false);
      if (this.this$0.getSorting() == 0) {
        int m = this.children.indexOf(param1Node);
        if (m < 0) {
          insert(param1Node, this.children.size());
          this.this$0.model.nodesWereInserted(this, new int[] { this.children.size() - 1 });
          if (this == this.this$0.root)
            this.this$0.expandPath(this.this$0.root.getTreePath()); 
          return param1Node;
        } 
        return (Node)this.children.getElement(m);
      } 
      boolean bool = (this.this$0.getSorting() == 1) ? 1 : 0;
      int i = 0, j = this.children.size() - 1, k = -1;
      while (j >= i) {
        k = (j + i) / 2;
        int m = param1Node.compare((Node)this.children.getElement(k));
        if (m == 0)
          return (Node)this.children.getElement(k); 
        if (m > 0) {
          if (bool) {
            i = k + 1;
            continue;
          } 
          j = k - 1;
          continue;
        } 
        if (!bool) {
          i = k + 1;
          continue;
        } 
        j = k - 1;
      } 
      if (k >= 0) {
        int m = param1Node.compare((Node)this.children.getElement(k));
        if ((bool && m >= 0) || (!bool && m <= 0))
          k++; 
      } 
      if (k < 0)
        k = 0; 
      insert(param1Node, k);
      this.this$0.model.nodesWereInserted(this, new int[] { k });
      if (this == this.this$0.root)
        this.this$0.expandPath(this.this$0.root.getTreePath()); 
      return param1Node;
    }
    
    public void remove(MutableTreeNode param1MutableTreeNode) {
      int i = this.children.indexOf(param1MutableTreeNode);
      if (i >= 0) {
        remove(i);
        this.this$0.model.nodesWereRemoved(this, new int[] { i }, new Object[] { param1MutableTreeNode });
        ((Node)param1MutableTreeNode).parent = null;
        invalidate();
      } 
    }
    
    void removeAll() {
      this.children.removeAllElements();
      this.this$0.model.reload(this);
      invalidate();
    }
    
    void collapse(int param1Int) {
      synchronized (this.this$0.getTreeLock()) {
        if (param1Int <= 0) {
          this.this$0.collapsePath(getTreePath());
        } else {
          for (byte b = 0; b < this.children.size(); b++)
            ((Node)this.children.getElement(b)).collapse(param1Int - 1); 
        } 
      } 
    }
    
    void expandAll() {
      synchronized (this.this$0.getTreeLock()) {
        this.this$0.expandPath(getTreePath());
        for (byte b = 0; b < this.children.size(); b++)
          ((Node)this.children.getElement(b)).expandAll(); 
      } 
    }
    
    void expand(int param1Int) {
      synchronized (this.this$0.getTreeLock()) {
        if (param1Int >= 0) {
          this.this$0.expandPath(getTreePath());
          if (param1Int > 0)
            for (byte b = 0; b < this.children.size(); b++)
              ((Node)this.children.getElement(b)).expand(param1Int - 1);  
        } 
      } 
    }
    
    void setForceExpanded(boolean param1Boolean) {
      if (param1Boolean && !this.alwaysExpanded && !this.this$0.isExpanded(getTreePath()))
        expand(1); 
      this.alwaysExpanded = param1Boolean;
    }
    
    public boolean isForceExpanded() { return this.alwaysExpanded; }
    
    public void setLabel(String param1String) {
      String str = getPath();
      this.label = param1String;
      this.this$0.firePropertyChange("nodeLabel", str, getPath());
    }
    
    public String getLabel() { return this.label; }
    
    public String getPath() {
      synchronized (this.this$0.getTreeLock()) {
        String str = this.label;
        for (Node node = this.parent; node != null && node.parent != null; node = node.parent)
          str = node.label + this.this$0.separator + str; 
        return str;
      } 
    }
    
    public String toString() { return getLabel(); }
    
    public int compare(Node param1Node) { return Collator.getInstance().compare(this.label, param1Node.label); }
    
    Node findNode(String param1String, boolean param1Boolean) {
      synchronized (this.this$0.getTreeLock()) {
        int i = param1String.indexOf(this.this$0.separator);
        String str = (i >= 0) ? param1String.substring(0, i) : param1String;
        param1String = (i < 0) ? null : param1String.substring(i + 1);
        for (byte b = 0; b < this.children.size(); b++) {
          Node node1 = (Node)this.children.getElement(b);
          if (node1.getLabel().equals(str)) {
            if (i < 0)
              return node1; 
            return node1.findNode(param1String, param1Boolean);
          } 
        } 
        Node node = this.this$0.createNode(this, str);
        if (param1Boolean) {
          node = insertNode(node);
        } else if (this.this$0.getSorting() == 0) {
          int j = this.children.indexOf(node);
          if (j < 0) {
            node = null;
          } else {
            node = (Node)this.children.getElement(j);
          } 
        } else {
          boolean bool = (this.this$0.getSorting() == 1) ? 1 : 0;
          int j = 0, k = this.children.size() - 1;
          while (k >= j) {
            int m = (k + j) / 2;
            int n = node.compare((Node)this.children.getElement(m));
            if (n == 0) {
              node = (Node)this.children.getElement(m);
              break;
            } 
            if (n > 0) {
              if (bool) {
                j = m + 1;
                continue;
              } 
              k = m - 1;
              continue;
            } 
            if (!bool) {
              j = m + 1;
              continue;
            } 
            k = m - 1;
          } 
          if (k < j)
            node = null; 
        } 
        if (param1String != null && node != null)
          return node.findNode(param1String, param1Boolean); 
        return node;
      } 
    }
    
    public void sort(int param1Int) {
      this.this$0.sort(this.children, (param1Int == 1));
      for (byte b = 0; b < this.children.size(); b++)
        ((Node)this.children.getElement(b)).sort(param1Int); 
      this.this$0.model.reload(this);
    }
    
    void remove() {
      synchronized (this.this$0.getTreeLock()) {
        for (byte b = 0; b < this.children.size(); b++)
          ((Node)this.children.getElement(b)).remove(); 
        if (this.parent != null)
          this.parent.remove(this); 
      } 
      this.this$0.model.reload();
      invalidate();
    }
    
    public void insert(MutableTreeNode param1MutableTreeNode, int param1Int) {
      this.children.insertElementAt(param1MutableTreeNode, param1Int);
      invalidate();
    }
    
    public void remove(int param1Int) {
      this.children.removeElementAt(param1Int);
      invalidate();
    }
    
    public void removeFromParent() {
      if (this.parent != null)
        this.parent.remove(this); 
    }
    
    public void setParent(MutableTreeNode param1MutableTreeNode) {
      if (this.parent != param1MutableTreeNode)
        ((Node)param1MutableTreeNode).insertNode(this); 
    }
    
    public void setUserObject(Object param1Object) {
      String str = (String)param1Object;
      int i = str.indexOf(this.this$0.separator);
      while (i == 0) {
        str = str.substring(1);
        i = str.indexOf(this.this$0.separator);
      } 
      if (i > 0) {
        setLabel(str.substring(0, i));
        findNode(str.substring(i + 1), true);
      } else {
        setLabel(str);
      } 
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object instanceof Node) {
        Node node = (Node)param1Object;
        return (this.label != null && this.label.equals(node.label) && ((this.parent == null && node.parent == null) || (this.parent != null && this.parent.equals(node.parent))));
      } 
      return false;
    }
    
    private void invalidate() {
      this.treeW = -1;
      if (this.parent != null)
        this.parent.invalidate(); 
    }
  }
  
  class TreePath2 extends TreePath {
    private final STree this$0;
    
    public TreePath2(STree this$0, TreePath param1TreePath, Object param1Object) {
      super(param1TreePath, param1Object);
      this.this$0 = this$0;
    }
  }
  
  class CellRenderer extends DefaultTreeCellRenderer {
    Icon over;
    
    private final STree this$0;
    
    CellRenderer(STree this$0) { this.this$0 = this$0; }
    
    public Component getTreeCellRendererComponent(JTree param1JTree, Object param1Object, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, int param1Int, boolean param1Boolean4) {
      STree.Node node = (STree.Node)param1Object;
      if (node.getIcon() != null)
        this.over = node.getIcon(); 
      return super.getTreeCellRendererComponent(param1JTree, param1Object, param1Boolean1, param1Boolean2, param1Boolean3, param1Int, param1Boolean4);
    }
    
    public Icon getLeafIcon() {
      if (this.over != null) {
        Icon icon = this.over;
        this.over = null;
        return icon;
      } 
      return (this.this$0.folderLeaf != null) ? this.this$0.folderLeaf : super.getLeafIcon();
    }
    
    public Icon getClosedIcon() {
      if (this.over != null) {
        Icon icon = this.over;
        this.over = null;
        return icon;
      } 
      return (this.this$0.folderCollapse != null) ? this.this$0.folderCollapse : super.getClosedIcon();
    }
    
    public Icon getOpenIcon() {
      if (this.over != null) {
        Icon icon = this.over;
        this.over = null;
        return icon;
      } 
      return (this.this$0.folderExpanded != null) ? this.this$0.folderExpanded : super.getOpenIcon();
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\STree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */