package inetsoft.widget;

import inetsoft.widget.util.EventMgr;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateSpinner extends Spinner {
  public static final int SECOND = 1000;
  
  public static final int MINUTE = 60000;
  
  public static final int HOUR = 3600000;
  
  public static final int DAY = 86400000;
  
  public static final int MONTH = -1;
  
  public static final int YEAR = -2;
  
  protected EventMgr eventMgr;
  
  Date date;
  
  DateFormat fmt;
  
  int inc;
  
  public DateSpinner() {
    super(new String[0]);
    setEditable(false);
    this.up.setEnabled(true);
    this.down.setEnabled(true);
    this.eventMgr = new EventMgr();
    this.date = new Date();
    this.fmt = DateFormat.getDateTimeInstance();
    this.fmt.setTimeZone(TimeZone.getDefault());
    this.inc = 3600000;
    setText(this.fmt.format(this.date));
    setColumns(getText().length());
  }
  
  public DateSpinner(Date paramDate, DateFormat paramDateFormat, int paramInt) {
    super(new String[0]);
    setEditable(false);
    this.up.setEnabled(true);
    this.down.setEnabled(true);
    this.eventMgr = new EventMgr();
    this.date = new Date();
    this.fmt = DateFormat.getDateTimeInstance();
    this.fmt.setTimeZone(TimeZone.getDefault());
    this.inc = 3600000;
    setDate(paramDate);
    setFormat(paramDateFormat);
    setIncrement(paramInt);
    setColumns(getText().length());
  }
  
  public void setDate(Date paramDate) {
    this.date = paramDate;
    setText(this.fmt.format(paramDate));
    repaint();
  }
  
  public Date getDate() { return this.date; }
  
  public void setFormat(DateFormat paramDateFormat) {
    this.fmt = paramDateFormat;
    setText(this.fmt.format(this.date));
    repaint();
  }
  
  public DateFormat getFormat() { return this.fmt; }
  
  public void setIncrement(int paramInt) { this.inc = paramInt; }
  
  public int getIncrement() { return this.inc; }
  
  protected void scrollUp() {
    if (this.inc > 0) {
      setDate(new Date(getDate().getTime() + this.inc));
    } else {
      Calendar calendar = Calendar.getInstance();
      calendar.setTimeZone(TimeZone.getDefault());
      calendar.setTime(getDate());
      if (this.inc == -2) {
        calendar.roll(1, true);
      } else if (this.inc == -1) {
        calendar.roll(2, true);
      } 
      setDate(calendar.getTime());
    } 
    this.eventMgr.postEvent(new ActionEvent(this, 1001, getText()));
  }
  
  protected void scrollDown() {
    if (this.inc > 0) {
      setDate(new Date(getDate().getTime() - this.inc));
    } else {
      Calendar calendar = Calendar.getInstance();
      calendar.setTimeZone(TimeZone.getDefault());
      calendar.setTime(getDate());
      if (this.inc == -2) {
        calendar.roll(1, false);
      } else if (this.inc == -1) {
        calendar.roll(2, false);
      } 
      setDate(calendar.getTime());
    } 
    this.eventMgr.postEvent(new ActionEvent(this, 1001, getText()));
  }
  
  public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\DateSpinner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */