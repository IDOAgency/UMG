package inetsoft.widget;

import inetsoft.widget.util.EventMgr;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class Folder extends JPanel {
  public static final int LEFT = 1;
  
  public static final int BOTTOM = 2;
  
  public static final int RIGHT = 3;
  
  public static final int TOP = 4;
  
  public static final int LAYERED_TAB = 1;
  
  public static final int SCROLLED_TAB = 2;
  
  public static final int TAB_SLANTED = 1;
  
  public static final int TAB_ROUNDED = 2;
  
  public static final int TAB_CHAMFERED = 3;
  
  public static final int TAB_STRAIGHT = 4;
  
  public static final int TAB_CUTCORNER = 5;
  
  private boolean folderRemove;
  
  protected EventMgr eventMgr;
  
  private Image buffer;
  
  long lastime;
  
  Dimension oSize;
  
  int style;
  
  int tabstyle;
  
  Vector tabs;
  
  Tab currTab;
  
  FontMetrics fm;
  
  Point framePos;
  
  Dimension frameSize;
  
  TabInfo tabLayout;
  
  Point compPos;
  
  Dimension compSize;
  
  Insets border;
  
  boolean mode3D;
  
  JButton leftB;
  
  JButton rightB;
  
  int firstTab;
  
  int gap;
  
  int tabHeightAdj;
  
  int appearance;
  
  Container tabPanel;
  
  Container compPanel;
  
  boolean manageComp;
  
  Dimension margin;
  
  Dimension psize;
  
  public Folder() { this(4); }
  
  public Folder(int paramInt) {
    this.folderRemove = true;
    this.eventMgr = new EventMgr();
    this.buffer = null;
    this.lastime = 0L;
    this.oSize = new Dimension(0, 0);
    this.style = 3;
    this.tabstyle = 1;
    this.tabs = new Vector();
    this.currTab = null;
    this.fm = null;
    this.compPos = null;
    this.compSize = null;
    this.border = new Insets(0, 0, 0, 0);
    this.mode3D = true;
    this.firstTab = 0;
    this.gap = 2;
    this.tabHeightAdj = 5;
    this.appearance = 3;
    this.compPanel = new JPanel();
    this.manageComp = true;
    this.margin = new Dimension(0, 0);
    this.psize = null;
    this.style = paramInt;
    setLayout(null);
    setOpaque(false);
    this.tabPanel = createTabPanel();
    getTabPanel(this.tabPanel).setLayout(null);
    add(this.tabPanel);
    this.compPanel.setLayout(null);
    add(this.compPanel);
  }
  
  public void setTabPlacement(int paramInt) {
    if (this.style != paramInt) {
      this.style = paramInt;
      this.oSize.width = 0;
      doLayout();
      repaint();
    } 
  }
  
  public int getTabPlacement() { return this.style; }
  
  public void setTabLayout(int paramInt) {
    if (this.tabstyle != paramInt) {
      this.tabstyle = paramInt;
      doLayout();
      repaint();
    } 
  }
  
  public int getTabLayout() { return this.tabstyle; }
  
  public void setTabAppearance(int paramInt) {
    if (this.appearance != paramInt) {
      this.appearance = paramInt;
      repaint();
    } 
  }
  
  public int getTabAppearance() { return this.appearance; }
  
  public void setPageInsets(Insets paramInsets) {
    this.border = paramInsets;
    doLayout();
    repaint();
  }
  
  public Insets getPageInsets() { return this.border; }
  
  public void set3D(boolean paramBoolean) {
    if (paramBoolean == this.mode3D)
      return; 
    this.mode3D = paramBoolean;
    this.gap = this.mode3D ? 2 : 1;
    doLayout();
    repaint();
  }
  
  public boolean is3D() { return this.mode3D; }
  
  public void add(Component paramComponent, Object paramObject) {
    int i = getIndex(paramObject.toString());
    Tab tab = null;
    if (i >= 0) {
      tab = (Tab)this.tabs.elementAt(i);
      if (paramComponent != tab.getComponent()) {
        this.compPanel.remove(tab.getComponent());
        this.compPanel.add(paramComponent);
        tab.setComponent(paramComponent);
      } 
    } else {
      paramComponent = (paramComponent != null) ? paramComponent : new Panel();
      tab = new Tab(this, paramObject.toString(), paramComponent);
      this.tabs.addElement(tab);
      getTabPanel(this.tabPanel).add(tab);
      this.compPanel.add(paramComponent);
    } 
    paramComponent.setVisible(tab.isShown());
    validate();
    repaint(10L);
  }
  
  public void remove(String paramString) {
    int i = getIndex(paramString);
    if (i >= 0)
      remove(i); 
  }
  
  public void remove(int paramInt) {
    if (!this.folderRemove) {
      super.remove(paramInt);
    } else if (paramInt >= 0) {
      Tab tab = (Tab)this.tabs.elementAt(paramInt);
      this.compPanel.remove(tab.getComponent());
      getTabPanel(this.tabPanel).remove(tab);
      this.tabs.removeElementAt(paramInt);
      validate();
      repaint();
    } 
  }
  
  public void rename(String paramString1, String paramString2) { ((Tab)this.tabs.elementAt(getIndex(paramString1))).setName(paramString2); }
  
  public int getPageCount() { return this.tabs.size(); }
  
  public Component getPage(int paramInt) { return ((Tab)this.tabs.elementAt(paramInt)).getComponent(); }
  
  public int getIndex(String paramString) {
    for (byte b = 0; b < this.tabs.size(); b++) {
      if (paramString.equals(this.tabs.elementAt(b).toString()))
        return b; 
    } 
    return -1;
  }
  
  public String getName(int paramInt) { return (paramInt >= 0 && paramInt < this.tabs.size()) ? ((Tab)this.tabs.elementAt(paramInt)).getName() : null; }
  
  public void setVisible(int paramInt, boolean paramBoolean) {
    if (paramInt >= 0 && paramInt < this.tabs.size()) {
      Tab tab = (Tab)this.tabs.elementAt(paramInt);
      tab.setShown(paramBoolean);
      tab.setVisible(paramBoolean);
      repaint();
    } 
  }
  
  public void setVisible(String paramString, boolean paramBoolean) { setVisible(getIndex(paramString), paramBoolean); }
  
  public void setTabComponent(int paramInt, Component paramComponent) {
    ((Tab)this.tabs.elementAt(paramInt)).setTabComponent(paramComponent);
    repaint();
  }
  
  public void setTabComponent(String paramString, Component paramComponent) { setTabComponent(getIndex(paramString), paramComponent); }
  
  public void toFront(int paramInt) {
    if (paramInt < this.tabs.size() && paramInt >= 0)
      showTab((Tab)this.tabs.elementAt(paramInt)); 
  }
  
  public void toFront(String paramString) { toFront(getIndex(paramString)); }
  
  public String getCurrentTab() { return (this.currTab != null) ? this.currTab.getName() : null; }
  
  public Component getCurrentComponent() { return (this.currTab != null) ? this.currTab.getComponent() : null; }
  
  public void setTabForeground(int paramInt, Color paramColor) {
    Tab tab = (Tab)this.tabs.elementAt(paramInt);
    if (!tab.getForeground().equals(paramColor)) {
      tab.setForeground(paramColor);
      tab.repaint();
    } 
  }
  
  public void setTabForeground(String paramString, Color paramColor) { setTabForeground(getIndex(paramString), paramColor); }
  
  public Color getTabForeground(int paramInt) { return ((Tab)this.tabs.elementAt(paramInt)).getForeground(); }
  
  public Color getTabForeground(String paramString) { return getTabForeground(getIndex(paramString)); }
  
  public void setTabBackground(int paramInt, Color paramColor) {
    Tab tab = (Tab)this.tabs.elementAt(paramInt);
    if (!tab.getBackground().equals(paramColor)) {
      tab.setBackground(paramColor);
      tab.repaint();
    } 
  }
  
  public void setTabBackground(String paramString, Color paramColor) { setTabBackground(getIndex(paramString), paramColor); }
  
  public Color getTabBackground(int paramInt) { return ((Tab)this.tabs.elementAt(paramInt)).getBackground(); }
  
  public Color getTabBackground(String paramString) { return getTabBackground(getIndex(paramString)); }
  
  public void setTabFont(int paramInt, Font paramFont) {
    Tab tab = (Tab)this.tabs.elementAt(paramInt);
    if (tab.getFont() != null && !tab.getFont().equals(paramFont)) {
      tab.setFont(paramFont);
      tab.repaint();
    } 
  }
  
  public void setTabFont(String paramString, Font paramFont) { setTabFont(getIndex(paramString), paramFont); }
  
  public Font getTabFont(int paramInt) { return ((Tab)this.tabs.elementAt(paramInt)).getFont(); }
  
  public Font getTabFont(String paramString) { return getTabFont(getIndex(paramString)); }
  
  public void reset() {
    if (this.currTab != null) {
      this.currTab.getComponent().setVisible(false);
      this.currTab = null;
      repaint();
    } 
  }
  
  public Dimension getMinimumSize() { return calcSize(true); }
  
  public void setPreferredSize(Dimension paramDimension) { this.psize = paramDimension; }
  
  public Dimension getPreferredSize() { return (this.psize != null) ? this.psize : calcSize(false); }
  
  public void doLayout() { layoutFolder(); }
  
  protected void layoutFolder() {
    Dimension dimension1 = getSize();
    if (this.tabs.size() == 0 || dimension1.width <= 0 || dimension1.height <= 0)
      return; 
    Point point1 = null;
    Point point2 = null;
    Point point3 = null;
    Dimension dimension2 = null;
    Point point4 = null;
    if ((this.tabPanel.getSize()).width == 0 || dimension1.width != this.oSize.width || dimension1.height != this.oSize.height)
      layoutTabPanel(20, 0, null); 
    if ((this.tabLayout = getTabInfo()) == null)
      return; 
    dimension1.width -= this.margin.width;
    dimension1.height -= this.margin.height;
    int i = 0;
    if (this.tabstyle == 2 && this.tabLayout.layers > 1) {
      if (this.leftB == null) {
        String str1 = "/inetsoft/widget/images/up.gif";
        String str2 = "/inetsoft/widget/images/down.gif";
        if (this.style == 4 || this.style == 2) {
          str1 = "/inetsoft/widget/images/left.gif";
          str2 = "/inetsoft/widget/images/right.gif";
        } 
        this.leftB = new JButton(new ImageIcon(Folder.class.getResource(str1)));
        this.leftB.setPreferredSize(new Dimension(this.tabLayout.height, this.tabLayout.height));
        this.leftB.setEnabled(false);
        this.rightB = new JButton(new ImageIcon(Folder.class.getResource(str2)));
        this.rightB.setPreferredSize(new Dimension(this.tabLayout.height, this.tabLayout.height));
        this.leftB.addActionListener(new LeftListener(this, null));
        this.rightB.addActionListener(new RightListener(this, null));
        add(this.leftB);
        add(this.rightB);
      } 
      i = this.tabLayout.height * 2;
      this.tabLayout.layers = 1;
      this.tabLayout.perLayer = this.tabs.size();
    } else if (this.leftB != null) {
      this.folderRemove = false;
      remove(this.leftB);
      remove(this.rightB);
      this.folderRemove = true;
      this.leftB = this.rightB = null;
      this.firstTab = 0;
    } 
    int j = this.tabLayout.layers * this.tabLayout.height;
    switch (this.style) {
      case 1:
        this.compPos = new Point(j, this.gap);
        this.framePos = new Point(j - 1, 0);
        point1 = new Point(j - this.tabLayout.height, 0);
        dimension2 = new Dimension(this.tabLayout.height, this.tabLayout.width);
        this.compSize = new Dimension(dimension1.width - j - this.gap, dimension1.height - 2 * this.gap);
        this.frameSize = new Dimension(dimension1.width - j + 1, dimension1.height);
        point2 = new Point(0, dimension2.height);
        point3 = new Point(-this.tabLayout.height, -this.tabLayout.perLayer * this.tabLayout.width);
        point4 = new Point(0, dimension1.height + point3.y);
        break;
      case 2:
        this.compPos = new Point(this.gap, this.gap);
        this.framePos = new Point(0, 0);
        point1 = new Point(0, 0);
        this.compSize = new Dimension(dimension1.width - 2 * this.gap, dimension1.height - j - this.gap);
        this.frameSize = new Dimension(dimension1.width, dimension1.height - j + 1);
        dimension2 = new Dimension(this.tabLayout.width, this.tabLayout.height);
        point2 = new Point(dimension2.width, 0);
        point3 = new Point(-this.tabLayout.perLayer * this.tabLayout.width, this.tabLayout.height);
        point4 = new Point(dimension1.width + point3.x, 0);
        break;
      case 3:
        this.compPos = new Point(this.gap, this.gap);
        this.framePos = new Point(0, 0);
        point1 = new Point(0, 0);
        this.compSize = new Dimension(dimension1.width - j - this.gap, dimension1.height - 2 * this.gap);
        this.frameSize = new Dimension(dimension1.width - j + 1, dimension1.height);
        dimension2 = new Dimension(this.tabLayout.height, this.tabLayout.width);
        point2 = new Point(0, dimension2.height);
        point3 = new Point(this.tabLayout.height, -this.tabLayout.perLayer * this.tabLayout.width);
        point4 = new Point(0, dimension1.height + point3.y);
        break;
      case 4:
        this.compPos = new Point(this.gap, j);
        this.framePos = new Point(0, j - 1);
        point1 = new Point(0, j - this.tabLayout.height);
        this.compSize = new Dimension(dimension1.width - 2 * this.gap, dimension1.height - j - this.gap);
        this.frameSize = new Dimension(dimension1.width, dimension1.height - j + 1);
        dimension2 = new Dimension(this.tabLayout.width, this.tabLayout.height);
        point2 = new Point(dimension2.width, 0);
        point3 = new Point(-this.tabLayout.perLayer * this.tabLayout.width, -this.tabLayout.height);
        point4 = new Point(dimension1.width + point3.x, 0);
        break;
    } 
    if (this.leftB != null) {
      int k = this.tabLayout.height;
      switch (this.style) {
        case 1:
          this.leftB.setBounds(0, 0, k, k);
          this.rightB.setBounds(0, k, k, k);
          break;
        case 3:
          this.leftB.setBounds(dimension1.width - k, 0, k, k);
          this.rightB.setBounds(dimension1.width - k, k, k, k);
          break;
        case 4:
          this.leftB.setBounds(0, 0, k, k);
          this.rightB.setBounds(k, 0, k, k);
          break;
        case 2:
          this.leftB.setBounds(0, dimension1.height - k, k, k);
          this.rightB.setBounds(k, dimension1.height - k, k, k);
          break;
      } 
    } 
    Dimension dimension3 = new Dimension(0, 0);
    this.compPanel.setBounds(this.compPos.x + this.border.left, this.compPos.y + this.border.top, this.compSize.width - this.border.left - this.border.right, this.compSize.height - this.border.top - this.border.bottom);
    this.compPanel.validate();
    for (byte b = 0; b < this.tabs.size(); b++) {
      Tab tab = (Tab)this.tabs.elementAt(b);
      if (b < this.firstTab) {
        tab.setLocation(-1000, 1000);
        tab.setVisible(false);
      } else {
        if (this.tabstyle == 2)
          tab.setVisible(true); 
        Point point = ((b + 1) % this.tabLayout.perLayer == 0 && this.tabstyle == 1) ? point4 : new Point(0, 0);
        tab.setBounds(point1.x, point1.y, dimension2.width + point.x, dimension2.height + point.y);
        tab.validate();
        if (this.manageComp) {
          Component component = tab.getComponent();
          component.setBounds(0, 0, this.compSize.width - this.border.left - this.border.right, this.compSize.height - this.border.top - this.border.bottom);
          component.validate();
        } 
        dimension3.width = Math.max(dimension3.width, point1.x + dimension2.width + point.x);
        dimension3.height = Math.max(dimension3.height, point1.y + dimension2.height + point.y);
        point1.x += point2.x;
        point1.y += point2.y;
        if ((b + 1) % this.tabLayout.perLayer == 0) {
          point1.x += point3.x;
          point1.y += point3.y;
        } 
      } 
    } 
    if (this.tabPanel == getTabPanel(this.tabPanel)) {
      layoutTabPanel(j, i, dimension3);
    } else {
      layoutTabPanel(j, i, null);
    } 
  }
  
  public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
  
  Dimension calcSize(boolean paramBoolean) {
    Dimension dimension = new Dimension(0, 0);
    if (this.fm == null && getFont() != null)
      this.fm = getFontMetrics(getFont()); 
    if (this.fm == null)
      return dimension; 
    int i = 0;
    for (byte b = 0; b < this.tabs.size(); b++) {
      Component component = ((Tab)this.tabs.elementAt(b)).getComponent();
      Dimension dimension1 = paramBoolean ? component.getMinimumSize() : component.getPreferredSize();
      Dimension dimension2 = ((Tab)this.tabs.elementAt(b)).getPreferredSize();
      int j = (this.style == 4 || this.style == 2) ? dimension2.width : dimension2.height;
      if (dimension1.width > dimension.width)
        dimension.width = dimension1.width; 
      if (dimension1.height > dimension.height)
        dimension.height = dimension1.height; 
      if (j > i)
        i = j; 
    } 
    if (paramBoolean) {
      i += 2 * this.gap;
    } else {
      i = (i + 2 * this.gap) * this.tabs.size();
    } 
    switch (this.style) {
      case 2:
      case 4:
        if (dimension.width < i)
          dimension.width = i; 
        dimension.width += 2 * this.gap;
        dimension.height += (paramBoolean ? this.tabs.size() : 1) * (this.fm.getHeight() + this.tabHeightAdj);
        break;
      case 1:
      case 3:
        if (dimension.height < i)
          dimension.height = i; 
        dimension.height += 2 * this.gap;
        dimension.width += (paramBoolean ? this.tabs.size() : 1) * (this.fm.charWidth('M') + this.tabHeightAdj);
        break;
    } 
    return dimension;
  }
  
  protected void showTab(Tab paramTab) {
    if (paramTab == this.currTab)
      return; 
    if (this.currTab != null) {
      this.currTab.setShown(false);
      this.currTab.getComponent().setVisible(false);
    } 
    if (this.tabLayout != null && this.tabstyle == 1) {
      int i = 0;
      for (; paramTab != (Tab)this.tabs.elementAt(i); i++);
      if (paramTab == (Tab)this.tabs.elementAt(i))
        if (i >= this.tabLayout.perLayer) {
          int j = i - i % this.tabLayout.perLayer;
          int k = 0;
          for (; k < this.tabLayout.perLayer && k + j < this.tabs.size(); k++) {
            Tab tab = (Tab)this.tabs.elementAt(k + j);
            this.tabs.setElementAt(this.tabs.elementAt(k), k + j);
            this.tabs.setElementAt(tab, k);
          } 
          doLayout();
        }  
    } 
    this.currTab = paramTab;
    Component component = this.currTab.getComponent();
    component.setVisible(true);
    this.currTab.setShown(true);
    this.compPanel.setBackground(component.getBackground());
    if (this.compPos != null && this.compSize != null && this.manageComp) {
      component.setBounds(0, 0, this.compSize.width - this.border.left - this.border.right, this.compSize.height - this.border.top - this.border.bottom);
      component.validate();
    } 
    validate();
    repaint();
  }
  
  public void paint(Graphics paramGraphics) {
    Dimension dimension = getSize();
    if (this.tabs.size() <= 0 || dimension.width <= 0 || dimension.height <= 0)
      return; 
    if (this.oSize.width != dimension.width || this.oSize.height != dimension.height) {
      doLayout();
      this.oSize = dimension;
      this.buffer = createImage(dimension.width, dimension.height);
    } 
    Graphics graphics = this.buffer.getGraphics();
    graphics.setColor(getBackground());
    graphics.fillRect(0, 0, dimension.width, dimension.height);
    if (this.mode3D) {
      graphics.setColor(getBackground());
      graphics.draw3DRect(this.framePos.x, this.framePos.y, this.frameSize.width - 1, this.frameSize.height - 1, true);
    } else {
      graphics.setColor(getForeground());
      graphics.drawRect(this.framePos.x, this.framePos.y, this.frameSize.width - 1, this.frameSize.height - 1);
    } 
    graphics.setClip(0, 0, dimension.width, dimension.height);
    graphics.setColor(getForeground());
    super.paint(graphics);
    graphics.dispose();
    paramGraphics.drawImage(this.buffer, 0, 0, this);
  }
  
  public void update(Graphics paramGraphics) { paint(paramGraphics); }
  
  protected Container createTabPanel() { return new Container(); }
  
  protected Container getTabPanel(Container paramContainer) { return paramContainer; }
  
  protected Container getPane() { return this.compPanel; }
  
  protected void setGaps(Dimension paramDimension) {
    if (!this.margin.equals(paramDimension)) {
      this.margin = paramDimension;
      doLayout();
      repaint();
    } 
  }
  
  protected void setManageComponent(boolean paramBoolean) { this.manageComp = paramBoolean; }
  
  private void layoutTabPanel(int paramInt1, int paramInt2, Dimension paramDimension) {
    Dimension dimension = getSize();
    dimension.width -= this.margin.width;
    dimension.height -= this.margin.height;
    int i = dimension.height - paramInt2;
    int j = dimension.width - paramInt2;
    switch (this.style) {
      case 1:
        this.tabPanel.setBounds(0, paramInt2, paramInt1, (paramDimension == null) ? i : Math.min(i, paramDimension.height));
        break;
      case 3:
        this.tabPanel.setBounds(dimension.width - paramInt1, paramInt2, paramInt1, (paramDimension == null) ? i : Math.min(i, paramDimension.height));
        break;
      case 4:
        this.tabPanel.setBounds(paramInt2, 0, (paramDimension == null) ? j : Math.min(j, paramDimension.width), paramInt1);
        break;
      case 2:
        this.tabPanel.setBounds(paramInt2, dimension.height - paramInt1, (paramDimension == null) ? j : Math.min(j, paramDimension.width), paramInt1);
        break;
    } 
    this.tabPanel.validate();
  }
  
  private class LeftListener implements ActionListener, Serializable {
    private final Folder this$0;
    
    private LeftListener(Folder this$0) { this.this$0 = this$0; }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      this.this$0.firstTab--;
      this.this$0.rightB.setEnabled(true);
      this.this$0.doLayout();
      if (this.this$0.firstTab == 0)
        this.this$0.leftB.setEnabled(false); 
    }
  }
  
  private class RightListener implements ActionListener, Serializable {
    private final Folder this$0;
    
    private RightListener(Folder this$0) { this.this$0 = this$0; }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      synchronized (this.this$0) {
        this.this$0.firstTab++;
        this.this$0.leftB.setEnabled(true);
        this.this$0.doLayout();
        Folder.Tab tab = (Folder.Tab)this.this$0.tabs.elementAt(this.this$0.tabs.size() - 1);
        if (!tab.isOutside() || this.this$0.firstTab >= this.this$0.tabs.size() - 1)
          this.this$0.rightB.setEnabled(false); 
      } 
    }
  }
  
  private TabInfo getTabInfo() {
    Container container = getTabPanel(this.tabPanel);
    int i = (this.style == 1 || this.style == 3) ? (container.getSize()).height : (container.getSize()).width;
    int j = this.tabs.size();
    int k = 0;
    if (this.fm == null)
      this.fm = getFontMetrics(getFont()); 
    if (this.fm == null || j == 0)
      return null; 
    int m = 0;
    for (byte b = 0; b < this.tabs.size(); b++) {
      Dimension dimension = ((Tab)this.tabs.elementAt(b)).getPreferredSize();
      if (this.style == 1 || this.style == 3) {
        k = Math.max(dimension.height, k);
        m = Math.max(m, dimension.width);
      } else {
        k = Math.max(dimension.width, k);
        m = Math.max(m, dimension.height);
      } 
    } 
    if (i == 0 || i / k > j)
      return new TabInfo(this, i / j, m, 1, j); 
    int n = i / i / Math.min(k, i);
    int i1 = i / n;
    TabInfo tabInfo = new TabInfo(this, n, m, (int)Math.ceil(j / i1), i1);
    if (tabInfo.layers > 1 && this.tabstyle == 2)
      tabInfo.width = Math.min(k, n); 
    return tabInfo;
  }
  
  class TabInfo implements Serializable {
    int width;
    
    int height;
    
    int layers;
    
    int perLayer;
    
    private final Folder this$0;
    
    TabInfo(Folder this$0, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.this$0 = this$0;
      this.width = param1Int1;
      this.height = param1Int2;
      this.layers = param1Int3;
      this.perLayer = param1Int4;
    }
    
    public String toString() { return "TabInfo[" + this.width + "," + this.height + "," + this.layers + "," + this.perLayer + "]"; }
  }
  
  class Tab extends Container implements MouseListener {
    private Dimension oSize;
    
    private Image buffer;
    
    boolean shown;
    
    FontMetrics fm;
    
    Component comp;
    
    boolean vis;
    
    private final Folder this$0;
    
    public Tab(Folder this$0, String param1String, Component param1Component) {
      this.this$0 = this$0;
      this.oSize = new Dimension(0, 0);
      this.buffer = null;
      this.fm = null;
      this.vis = true;
      setName(param1String);
      this.comp = param1Component;
      addMouseListener(this);
    }
    
    public void setName(String param1String) {
      super.setName(param1String);
      repaint();
    }
    
    public Component getComponent() { return this.comp; }
    
    public void setComponent(Component param1Component) { this.comp = param1Component; }
    
    public void setTabComponent(Component param1Component) {
      if (getComponentCount() > 0)
        remove(getComponent(0)); 
      add(param1Component);
      registerTabListener(param1Component);
    }
    
    private void registerTabListener(Component param1Component) {
      param1Component.addMouseListener(this);
      if (param1Component instanceof Container) {
        Container container = (Container)param1Component;
        for (byte b = 0; b < container.getComponentCount(); b++)
          registerTabListener(container.getComponent(b)); 
      } 
    }
    
    public void setVisible(boolean param1Boolean) { this.vis = param1Boolean; }
    
    public boolean isVisible() { return this.vis; }
    
    public void setShown(boolean param1Boolean) {
      this.shown = param1Boolean;
      repaint();
    }
    
    public boolean isShown() { return this.shown; }
    
    public Dimension getPreferredSize() {
      if (getComponentCount() > 0) {
        Dimension dimension1 = new Dimension(getComponent(0).getPreferredSize());
        dimension1.width += ((this.this$0.style == 4 || this.this$0.style == 2) ? (4 * this.this$0.gap) : this.this$0.gap);
        dimension1.height += ((this.this$0.style == 4 || this.this$0.style == 2) ? this.this$0.gap : (4 * this.this$0.gap));
        return dimension1;
      } 
      if (this.fm == null)
        this.fm = getFontMetrics(getFont()); 
      Dimension dimension = null;
      switch (this.this$0.style) {
        case 2:
        case 4:
          dimension = new Dimension(this.fm.stringWidth(getName()) + 4 * this.this$0.gap, this.fm.getHeight() + this.this$0.gap);
          break;
        case 1:
        case 3:
          dimension = new Dimension(this.fm.charWidth('M') + this.this$0.gap, this.fm.getAscent() * getName().length() + 4 * this.this$0.gap);
          break;
      } 
      return dimension;
    }
    
    public void doLayout() {
      if (getComponentCount() > 0) {
        int i = (this.this$0.appearance == 2 || this.this$0.appearance == 1) ? (2 * this.this$0.gap) : 0;
        getComponent(0).setBounds(this.this$0.gap + i, this.this$0.gap, (getSize()).width - 2 * this.this$0.gap - 2 * i, (getSize()).height - 2 * this.this$0.gap);
        getComponent(0).validate();
      } 
    }
    
    public String toString() { return getName(); }
    
    public boolean isOutside() {
      Rectangle rectangle1 = this.this$0.getTabPanel(this.this$0.tabPanel).getBounds();
      rectangle1.x = rectangle1.y = 0;
      Rectangle rectangle2 = getBounds();
      rectangle2.width--;
      rectangle2.height--;
      return (!rectangle1.contains(rectangle2.x, rectangle2.y) || !rectangle1.contains(rectangle2.x, rectangle2.y + rectangle2.height) || !rectangle1.contains(rectangle2.x + rectangle2.width, rectangle2.y) || !rectangle1.contains(rectangle2.x + rectangle2.width, rectangle2.y + rectangle2.height));
    }
    
    public void paint(Graphics param1Graphics) {
      byte b;
      int m, arrayOfInt2[], arrayOfInt1[], k;
      Dimension dimension = getSize();
      if (this.oSize.width != dimension.width || this.oSize.height != dimension.height || this.buffer == null) {
        this.oSize = dimension;
        this.buffer = createImage(dimension.width, dimension.height);
      } 
      Graphics graphics = this.buffer.getGraphics();
      graphics.setFont(getFont());
      graphics.setColor(getParent().getBackground());
      graphics.fillRect(0, 0, dimension.width, dimension.height);
      super.paint(graphics);
      if (!isVisible()) {
        drawBaseline(graphics);
        param1Graphics.drawImage(this.buffer, 0, 0, this);
        return;
      } 
      if (this.fm == null)
        this.fm = getFontMetrics(getFont()); 
      int i = this.fm.getMaxAscent();
      dimension.width--;
      dimension.height--;
      int j = (this.this$0.appearance != 2) ? 3 : ((this.this$0.style == 1 || this.this$0.style == 3) ? (dimension.width / 2) : (dimension.height / 2));
      Color color = this.this$0.mode3D ? getBackground() : getForeground();
      graphics.setColor(getBackground());
      switch (this.this$0.style) {
        case 1:
          arrayOfInt1 = new int[] { dimension.width, j, 0, 0, j, dimension.width };
          arrayOfInt2 = new int[] { 0, 0, j, dimension.height - j, dimension.height, dimension.height };
          switch (this.this$0.appearance) {
            case 1:
              arrayOfInt1[1] = arrayOfInt1[2];
              arrayOfInt2[1] = arrayOfInt2[2];
              arrayOfInt1[4] = arrayOfInt1[3];
              arrayOfInt2[4] = arrayOfInt2[3];
            case 2:
              graphics.fillArc(0, 0, dimension.width, dimension.width, 90, 90);
              graphics.fillArc(0, dimension.height - dimension.width, dimension.width, dimension.width, 180, 90);
              break;
            case 4:
              arrayOfInt2[2] = 0;
              arrayOfInt1[4] = 0;
              arrayOfInt1[1] = 0;
              arrayOfInt2[3] = dimension.height;
              break;
            case 5:
              arrayOfInt1[4] = 0;
              arrayOfInt2[3] = dimension.height;
              break;
          } 
          graphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
          graphics.setColor(this.this$0.mode3D ? color.brighter().brighter() : getForeground());
          graphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[1], arrayOfInt2[1]);
          if (this.this$0.appearance == 2) {
            graphics.drawArc(0, 0, dimension.width, dimension.width, 90, 90);
          } else {
            graphics.drawLine(arrayOfInt1[1], arrayOfInt2[1], arrayOfInt1[2], arrayOfInt2[2]);
          } 
          graphics.drawLine(arrayOfInt1[2], arrayOfInt2[2], arrayOfInt1[3], arrayOfInt2[3]);
          if (this.this$0.mode3D)
            graphics.setColor(color.darker().darker()); 
          if (this.this$0.appearance == 2) {
            graphics.drawArc(0, dimension.height - dimension.width, dimension.width, dimension.width, 180, 90);
          } else {
            graphics.drawLine(arrayOfInt1[3], arrayOfInt2[3], arrayOfInt1[4], arrayOfInt2[4]);
          } 
          graphics.drawLine(arrayOfInt1[4], arrayOfInt2[4], arrayOfInt1[5], arrayOfInt2[5]);
          if (!this.shown)
            drawBaseline(graphics); 
          break;
        case 3:
          arrayOfInt1 = new int[] { 0, dimension.width - j, dimension.width, dimension.width, dimension.width - j, 0 };
          arrayOfInt2 = new int[] { 0, 0, j, dimension.height - j, dimension.height, dimension.height };
          graphics.setColor(getBackground());
          switch (this.this$0.appearance) {
            case 1:
              arrayOfInt1[1] = arrayOfInt1[2];
              arrayOfInt2[1] = arrayOfInt2[2];
              arrayOfInt1[4] = arrayOfInt1[3];
              arrayOfInt2[4] = arrayOfInt2[3];
            case 2:
              graphics.fillArc(0, 0, dimension.width, dimension.width, 0, 90);
              graphics.fillArc(0, dimension.height - dimension.width, dimension.width, dimension.width, 270, 90);
              break;
            case 4:
              arrayOfInt1[4] = dimension.width;
              arrayOfInt1[1] = dimension.width;
              arrayOfInt2[2] = 0;
              arrayOfInt2[3] = dimension.height;
              break;
            case 5:
              arrayOfInt1[4] = dimension.width;
              arrayOfInt2[3] = dimension.height;
              break;
          } 
          graphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
          graphics.setColor(this.this$0.mode3D ? color.brighter().brighter() : getForeground());
          graphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[1], arrayOfInt2[1]);
          if (this.this$0.mode3D)
            graphics.setColor(color.darker().darker()); 
          if (this.this$0.appearance == 2) {
            graphics.drawArc(0, 0, dimension.width, dimension.width, 0, 90);
          } else {
            graphics.drawLine(arrayOfInt1[1], arrayOfInt2[1], arrayOfInt1[2], arrayOfInt2[2]);
          } 
          graphics.drawLine(arrayOfInt1[2], arrayOfInt2[2], arrayOfInt1[3], arrayOfInt2[3]);
          if (this.this$0.appearance == 2) {
            graphics.drawArc(0, dimension.height - dimension.width, dimension.width, dimension.width, 270, 90);
          } else {
            graphics.drawLine(arrayOfInt1[3], arrayOfInt2[3], arrayOfInt1[4], arrayOfInt2[4]);
          } 
          graphics.drawLine(arrayOfInt1[4], arrayOfInt2[4], arrayOfInt1[5], arrayOfInt2[5]);
          if (!this.shown)
            drawBaseline(graphics); 
          break;
        case 4:
          arrayOfInt1 = new int[] { 0, 0, j, dimension.width - j, dimension.width, dimension.width };
          arrayOfInt2 = new int[] { dimension.height, j, 0, 0, j, dimension.height };
          graphics.setColor(getBackground());
          switch (this.this$0.appearance) {
            case 1:
              arrayOfInt1[1] = arrayOfInt1[2];
              arrayOfInt2[1] = arrayOfInt2[2];
              arrayOfInt1[4] = arrayOfInt1[3];
              arrayOfInt2[4] = arrayOfInt2[3];
            case 2:
              graphics.fillArc(0, 0, dimension.height, dimension.height, 90, 90);
              graphics.fillArc(dimension.width - dimension.height, 0, dimension.height, dimension.height, 0, 90);
              break;
            case 4:
              arrayOfInt2[4] = 0;
              arrayOfInt2[1] = 0;
              arrayOfInt1[1] = 0;
              arrayOfInt1[3] = dimension.width;
              break;
            case 5:
              arrayOfInt2[4] = 0;
              arrayOfInt1[3] = dimension.width;
              break;
          } 
          graphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
          graphics.setColor(this.this$0.mode3D ? color.brighter().brighter() : getForeground());
          graphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[1], arrayOfInt2[1]);
          if (this.this$0.appearance == 2) {
            graphics.drawArc(0, 0, dimension.height, dimension.height, 90, 90);
          } else {
            graphics.drawLine(arrayOfInt1[1], arrayOfInt2[1], arrayOfInt1[2], arrayOfInt2[2]);
          } 
          graphics.drawLine(arrayOfInt1[2], arrayOfInt2[2], arrayOfInt1[3], arrayOfInt2[3]);
          if (this.this$0.mode3D)
            graphics.setColor(color.darker().darker()); 
          if (this.this$0.appearance == 2) {
            graphics.drawArc(dimension.width - dimension.height, 0, dimension.height, dimension.height, 0, 90);
          } else {
            graphics.drawLine(arrayOfInt1[3], arrayOfInt2[3], arrayOfInt1[4], arrayOfInt2[4]);
          } 
          graphics.drawLine(arrayOfInt1[4], arrayOfInt2[4], arrayOfInt1[5], arrayOfInt2[5]);
          if (!this.shown)
            drawBaseline(graphics); 
          break;
        case 2:
          arrayOfInt1 = new int[] { 0, 0, j, dimension.width - j, dimension.width, dimension.width };
          arrayOfInt2 = new int[] { 0, dimension.height - j, dimension.height, dimension.height, dimension.height - j, 0 };
          graphics.setColor(getBackground());
          switch (this.this$0.appearance) {
            case 1:
              arrayOfInt1[1] = arrayOfInt1[2];
              arrayOfInt2[1] = arrayOfInt2[2];
              arrayOfInt1[4] = arrayOfInt1[3];
              arrayOfInt2[4] = arrayOfInt2[3];
            case 2:
              graphics.fillArc(0, 0, dimension.height, dimension.height, 180, 90);
              graphics.fillArc(dimension.width - dimension.height, 0, dimension.height, dimension.height, 270, 90);
              break;
            case 4:
              arrayOfInt1[2] = 0;
              arrayOfInt1[3] = dimension.width;
              arrayOfInt2[4] = dimension.height;
              arrayOfInt2[1] = dimension.height;
              break;
            case 5:
              arrayOfInt1[3] = dimension.width;
              arrayOfInt2[4] = dimension.height;
              break;
          } 
          graphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
          graphics.setColor(this.this$0.mode3D ? color.brighter().brighter() : getForeground());
          graphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[1], arrayOfInt2[1]);
          if (this.this$0.mode3D)
            graphics.setColor(color.darker().darker()); 
          if (this.this$0.appearance == 2) {
            graphics.drawArc(0, 0, dimension.height, dimension.height, 180, 90);
          } else {
            graphics.drawLine(arrayOfInt1[1], arrayOfInt2[1], arrayOfInt1[2], arrayOfInt2[2]);
          } 
          graphics.drawLine(arrayOfInt1[2], arrayOfInt2[2], arrayOfInt1[3], arrayOfInt2[3]);
          if (this.this$0.appearance == 2) {
            graphics.drawArc(dimension.width - dimension.height, 0, dimension.height, dimension.height, 270, 90);
          } else {
            graphics.drawLine(arrayOfInt1[3], arrayOfInt2[3], arrayOfInt1[4], arrayOfInt2[4]);
          } 
          graphics.drawLine(arrayOfInt1[4], arrayOfInt2[4], arrayOfInt1[5], arrayOfInt2[5]);
          if (!this.shown)
            drawBaseline(graphics); 
          break;
      } 
      graphics.setColor(getForeground());
      switch (this.this$0.style) {
        case 1:
        case 3:
          k = this.fm.stringWidth("M");
          m = ((getSize()).height - i * (getName().length() - 1)) / 2;
          for (b = 0; b < getName().length(); b++) {
            String str = getName().substring(b, b + true);
            graphics.drawString(str, 2 + (k - this.fm.stringWidth(str)) / 2, m);
            m += i;
          } 
          break;
        case 2:
        case 4:
          graphics.drawString(getName(), ((getSize()).width - this.fm.stringWidth(getName())) / 2 + 1, ((getSize()).height - this.fm.getHeight()) / 2 + i);
          break;
      } 
      graphics.dispose();
      param1Graphics.drawImage(this.buffer, 0, 0, this);
    }
    
    public void update(Graphics param1Graphics) { paint(param1Graphics); }
    
    private void drawBaseline(Graphics param1Graphics) {
      Dimension dimension = getSize();
      Color color = getBackground();
      switch (this.this$0.style) {
        case 4:
          if (this.this$0.mode3D)
            param1Graphics.setColor(color.brighter()); 
          param1Graphics.drawLine(0, dimension.height - 1, dimension.width, dimension.height - 1);
          break;
        case 1:
          if (this.this$0.mode3D)
            param1Graphics.setColor(color.brighter()); 
          param1Graphics.drawLine(dimension.width - 1, 0, dimension.width - 1, dimension.height);
          break;
        case 2:
          if (this.this$0.mode3D)
            param1Graphics.setColor(color.darker()); 
          param1Graphics.drawLine(0, 0, dimension.width, 0);
          break;
        case 3:
          if (this.this$0.mode3D)
            param1Graphics.setColor(color.darker()); 
          param1Graphics.drawLine(0, 0, 0, dimension.height);
          break;
      } 
      if (this.this$0.mode3D)
        param1Graphics.setColor(getForeground()); 
    }
    
    public void mouseReleased(MouseEvent param1MouseEvent) {}
    
    public void mouseEntered(MouseEvent param1MouseEvent) {}
    
    public void mouseExited(MouseEvent param1MouseEvent) {}
    
    public void mouseClicked(MouseEvent param1MouseEvent) {}
    
    public void mousePressed(MouseEvent param1MouseEvent) {
      if (this.this$0.lastime + 300L >= param1MouseEvent.getWhen())
        return; 
      this.this$0.lastime = param1MouseEvent.getWhen();
      if (!this.shown) {
        this.this$0.showTab(this);
        this.this$0.eventMgr.postEvent(new ActionEvent(this.this$0, 1001, getName()));
      } 
    }
    
    private void readObject(ObjectInputStream param1ObjectInputStream) throws ClassNotFoundException, IOException {
      param1ObjectInputStream.defaultReadObject();
      this.oSize = new Dimension(0, 0);
    }
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.oSize = new Dimension(0, 0);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\Folder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */