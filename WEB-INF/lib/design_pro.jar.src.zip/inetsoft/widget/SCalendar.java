/*     */ package inetsoft.widget;
/*     */ 
/*     */ import inetsoft.widget.util.EventMgr;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.ItemSelectable;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.util.GregorianCalendar;
/*     */ import javax.swing.JComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SCalendar
/*     */   extends JComponent
/*     */   implements ItemSelectable
/*     */ {
/*     */   public static final int NO_TITLE = 0;
/*     */   public static final int WEEK = 1;
/*     */   public static final int MONTH_WEEK = 2;
/*     */   public static final int ALL = 3;
/*     */   private String[] header;
/*     */   private FontMetrics fm;
/*     */   protected EventMgr eventMgr;
/*     */   
/*     */   public SCalendar() {
/*  49 */     enableEvents(48L);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 379 */     this.header = new String[] { "S", "M", "T", "W", "T", "F", "S" };
/* 380 */     this.fm = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 543 */     this.eventMgr = new EventMgr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 823 */     this.tFlag = 2;
/* 824 */     this.tPosition = new int[2];
/* 825 */     this.xPosition = new int[8];
/* 826 */     this.yPosition = new int[7];
/* 827 */     this.dayWidth = 0;
/* 828 */     this.dayHeight = 0;
/*     */     
/* 830 */     this.oSize = new Dimension(0, 0);
/* 831 */     this.buffer = null;
/* 832 */     this.dayLayout = new int[6][7];
/* 833 */     this.startRow = -1; this.startCol = -1;
/* 834 */     this.currRow = -1; this.currCol = -1;
/*     */     
/* 836 */     this.hlightMap = new boolean[32];
/* 837 */     this.hlightColorMap = new Color[32];
/* 838 */     this.hlightColor = Color.red; GregorianCalendar gregorianCalendar = new GregorianCalendar(); this.year = gregorianCalendar.get(1); this.month = gregorianCalendar.get(2); calcDayLayout(); } public SCalendar(int paramInt1, int paramInt2) { enableEvents(48L); this.header = new String[] { "S", "M", "T", "W", "T", "F", "S" }; this.fm = null; this.eventMgr = new EventMgr(); this.tFlag = 2; this.tPosition = new int[2]; this.xPosition = new int[8]; this.yPosition = new int[7]; this.dayWidth = 0; this.dayHeight = 0; this.oSize = new Dimension(0, 0); this.buffer = null; this.dayLayout = new int[6][7]; this.startRow = -1; this.startCol = -1; this.currRow = -1; this.currCol = -1; this.hlightMap = new boolean[32]; this.hlightColorMap = new Color[32]; this.hlightColor = Color.red;
/*     */     this.year = paramInt1;
/*     */     this.month = paramInt2;
/*     */     calcDayLayout(); }
/*     */   public void setTitle(int paramInt) { this.tFlag = paramInt;
/*     */     repaint(); }
/*     */   public int getTitle() { return this.tFlag; } public void setYear(int paramInt) { if (this.year != paramInt) {
/*     */       this.year = paramInt;
/*     */       clear();
/*     */       calcDayLayout();
/*     */       repaint();
/* 849 */     }  } public int getYear() { return this.year; } private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException { paramObjectInputStream.defaultReadObject();
/* 850 */     this.oSize = new Dimension(0, 0); }
/*     */ 
/*     */   
/*     */   public void setMonth(int paramInt) {
/*     */     if (this.month != paramInt) {
/*     */       this.month = paramInt;
/*     */       clear();
/*     */       calcDayLayout();
/*     */       repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getMonth() { return this.month; }
/*     */   
/*     */   public void highlight(int paramInt) {
/*     */     try {
/*     */       this.hlightMap[paramInt] = true;
/*     */       this.hlightColorMap[paramInt] = this.hlightColor;
/*     */     } catch (Exception exception) {}
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void highlight(int paramInt1, int paramInt2) {
/*     */     try {
/*     */       for (int i = paramInt1; i <= paramInt2; i++) {
/*     */         this.hlightMap[i] = true;
/*     */         this.hlightColorMap[i] = this.hlightColor;
/*     */       } 
/*     */     } catch (Exception exception) {}
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void dehighlight(int paramInt) {
/*     */     try {
/*     */       this.hlightMap[paramInt] = false;
/*     */     } catch (Exception exception) {}
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void dehighlight(int paramInt1, int paramInt2) {
/*     */     try {
/*     */       for (int i = paramInt1; i <= paramInt2; i++)
/*     */         this.hlightMap[i] = false; 
/*     */     } catch (Exception exception) {}
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public boolean isHighlighted(int paramInt) {
/*     */     try {
/*     */       return this.hlightMap[paramInt];
/*     */     } catch (Exception exception) {
/*     */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setHighlight(Color paramColor) {
/*     */     this.hlightColor = paramColor;
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public Dimension getMinimumSize() {
/*     */     if (this.fm == null)
/*     */       this.fm = getFontMetrics(getFont()); 
/*     */     return new Dimension(7 * (this.fm.charWidth('M') * 2 + 2), (6 + this.tPosition.length) * (this.fm.getHeight() + 2));
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() { return getMinimumSize(); }
/*     */   
/*     */   public Object[] getSelectedObjects() { return null; }
/*     */   
/*     */   public int getStartDay() {
/*     */     if (this.startRow < 0 || this.startCol < 0 || this.currRow < 0 || this.currCol < 0)
/*     */       return -1; 
/*     */     return Math.min(dayAt(this.startRow, this.startCol), dayAt(this.currRow, this.currCol));
/*     */   }
/*     */   
/*     */   public int getEndDay() {
/*     */     if (this.startRow < 0 || this.startCol < 0 || this.currRow < 0 || this.currCol < 0)
/*     */       return -1; 
/*     */     return Math.max(dayAt(this.startRow, this.startCol), dayAt(this.currRow, this.currCol));
/*     */   }
/*     */   
/*     */   public void clear() {
/*     */     int i = this.startRow, j = this.startCol;
/*     */     this.startRow = this.startCol = this.currRow = this.currCol = -1;
/*     */     if (i != this.startRow || j != this.startCol)
/*     */       repaint(); 
/*     */   }
/*     */   
/*     */   public void select(int paramInt) { select(paramInt, paramInt); }
/*     */   
/*     */   public void select(int paramInt1, int paramInt2) {
/*     */     int i = this.startRow, j = this.startCol;
/*     */     int k = this.currRow, m = this.currCol;
/*     */     Point point = dayCoord(paramInt1);
/*     */     this.startRow = point.y;
/*     */     this.startCol = point.x;
/*     */     point = dayCoord(paramInt2);
/*     */     this.currRow = point.y;
/*     */     this.currCol = point.x;
/*     */     if (i != this.startRow || j != this.startCol || k != this.currRow || m != this.currCol)
/*     */       repaint(); 
/*     */   }
/*     */   
/*     */   public void selectAll() {
/*     */     int i = this.startRow, j = this.startCol;
/*     */     int k = this.currRow, m = this.currCol;
/*     */     setStartAtStart();
/*     */     setEndAtEnd();
/*     */     if (i != this.startRow || j != this.startCol || k != this.currRow || m != this.currCol)
/*     */       repaint(); 
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*     */     if (paramObject instanceof SCalendar)
/*     */       return (this.year == ((SCalendar)paramObject).year && this.month == ((SCalendar)paramObject).month); 
/*     */     return false;
/*     */   }
/*     */   
/*     */   public int compareTo(SCalendar paramSCalendar) { return (this.year - paramSCalendar.year) * 12 + this.month - paramSCalendar.month; }
/*     */   
/*     */   public String toString() { return "[SCalendar " + this.year + "/" + this.month + "]"; }
/*     */   
/*     */   public void update(Graphics paramGraphics) { paint(paramGraphics); }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     byte b2;
/*     */     if (this.fm == null)
/*     */       this.fm = getFontMetrics(getFont()); 
/*     */     int i = this.fm.charWidth('M');
/*     */     Dimension dimension = getSize();
/*     */     if (this.oSize.width != dimension.width || this.oSize.height != dimension.height) {
/*     */       this.oSize = dimension;
/*     */       this.buffer = createImage(dimension.width, dimension.height);
/*     */       calcPosition();
/*     */     } 
/*     */     Graphics graphics = this.buffer.getGraphics();
/*     */     graphics.setFont(getFont());
/*     */     graphics.setColor(getBackground());
/*     */     graphics.fillRect(0, 0, dimension.width, dimension.height);
/*     */     graphics.setColor(getForeground());
/*     */     byte b1 = 0;
/*     */     String str = "";
/*     */     switch (this.tFlag) {
/*     */       case 3:
/*     */         str = Integer.toString(getYear()) + " ";
/*     */       case 2:
/*     */         str = str + getMonthName(this.month);
/*     */         graphics.drawString(str, (dimension.width - this.fm.stringWidth(str)) / 2, this.tPosition[b1]);
/*     */         b1++;
/*     */       case 1:
/*     */         for (b2 = 0; b2 < 7; b2++)
/*     */           graphics.drawString(this.header[b2], this.xPosition[b2] + i / 2, this.tPosition[b1]); 
/*     */         b1++;
/*     */         break;
/*     */     } 
/*     */     int j = -1, k = -1, m = -1, n = -1;
/*     */     if (this.startRow == this.currRow) {
/*     */       j = m = this.startRow;
/*     */       k = Math.min(this.startCol, this.currCol);
/*     */       n = Math.max(this.startCol, this.currCol);
/*     */     } else if (this.startRow < this.currRow) {
/*     */       j = this.startRow;
/*     */       k = this.startCol;
/*     */       m = this.currRow;
/*     */       n = this.currCol;
/*     */     } else if (this.startRow > this.currRow) {
/*     */       j = this.currRow;
/*     */       k = this.currCol;
/*     */       m = this.startRow;
/*     */       n = this.startCol;
/*     */     } 
/*     */     Color color1 = getForeground();
/*     */     Color color2 = getBackground();
/*     */     for (byte b3 = 0; b3 < 6; b3++) {
/*     */       for (byte b = 0; b < 7; b++) {
/*     */         if (this.dayLayout[b3][b] != 0) {
/*     */           int i1 = (this.dayLayout[b3][b] < 10) ? (i / 2) : 0;
/*     */           boolean bool = (j != -1 && k != -1 && m != -1 && n != -1 && ((b3 == j && b3 < m && b >= k) || (b3 == m && b3 > j && b <= n) || (b3 > j && b3 < m) || (b3 == j && b3 == m && b >= k && b <= n))) ? 1 : 0;
/*     */           boolean bool1 = this.hlightMap[this.dayLayout[b3][b]];
/*     */           Color color = this.hlightColorMap[this.dayLayout[b3][b]];
/*     */           if (bool || bool1) {
/*     */             if (bool1 && bool) {
/*     */               graphics.setColor(color.darker());
/*     */             } else if (bool1) {
/*     */               graphics.setColor(color);
/*     */             } else {
/*     */               graphics.setColor(color1);
/*     */             } 
/*     */             graphics.fillRect(this.xPosition[b], this.yPosition[b3], this.dayWidth, this.dayHeight);
/*     */             if (bool) {
/*     */               graphics.setColor(color2);
/*     */             } else {
/*     */               graphics.setColor(color1);
/*     */             } 
/*     */           } 
/*     */           graphics.drawString(Integer.toString(this.dayLayout[b3][b]), this.xPosition[b] + i1, this.yPosition[b3 + true] - this.fm.getMaxDescent());
/*     */           if (bool)
/*     */             graphics.setColor(color1); 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     paramGraphics.drawImage(this.buffer, 0, 0, this);
/*     */     graphics.dispose();
/*     */   }
/*     */   
/*     */   boolean insideMonth(int paramInt1, int paramInt2) {
/*     */     Point point = getLocation();
/*     */     Dimension dimension = getSize();
/*     */     return (paramInt1 - point.x >= 0 && paramInt1 - point.x < dimension.width && paramInt2 - point.y >= 0 && paramInt2 - point.y < dimension.height);
/*     */   }
/*     */   
/*     */   private void calcPosition() {
/*     */     Dimension dimension = getSize();
/*     */     this.dayWidth = (dimension.width - 2) / 7;
/*     */     this.dayHeight = (dimension.height - 2) / (6 + this.tFlag);
/*     */     for (byte b = 0; b < this.tPosition.length; b++)
/*     */       this.tPosition[b] = this.dayHeight * (b + true); 
/*     */     for (int i = 0; i < 8; i++)
/*     */       this.xPosition[i] = i * this.dayWidth + 2; 
/*     */     for (int j = 0; j < 7; j++)
/*     */       this.yPosition[j] = (j + this.tPosition.length) * this.dayHeight; 
/*     */   }
/*     */   
/*     */   private void calcDayLayout() {
/*     */     int i = dayOfWeek(this.year, this.month, 1);
/*     */     int j = daysInMonth(this.year, this.month);
/*     */     byte b1 = 1;
/*     */     for (byte b2 = 0; b2 < 6; b2++) {
/*     */       for (byte b = 0; b < 7; b++)
/*     */         this.dayLayout[b2][b] = (b1 <= j && (!b2 || b >= i)) ? b1++ : 0; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
/*     */   
/*     */   public void addItemListener(ItemListener paramItemListener) { this.eventMgr.addItemListener(paramItemListener); }
/*     */   
/*     */   public void removeItemListener(ItemListener paramItemListener) { this.eventMgr.removeItemListener(paramItemListener); }
/*     */   
/*     */   public void processMouseEvent(MouseEvent paramMouseEvent) {
/*     */     if (paramMouseEvent.getID() == 501) {
/*     */       this.startRow = this.currRow = findRow(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */       this.startCol = this.currCol = findCol(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */     } else if (paramMouseEvent.getID() == 502) {
/*     */       if (handleParent(paramMouseEvent))
/*     */         return; 
/*     */       this.currRow = findRow(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */       this.currCol = findCol(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */       repaint();
/*     */       this.eventMgr.postEvent(new ItemEvent(this, 701, "select", 1));
/*     */     } 
/*     */     if (paramMouseEvent.getID() == 501 && paramMouseEvent.getClickCount() == 2)
/*     */       this.eventMgr.postEvent(new ActionEvent(this, 1001, "select")); 
/*     */     super.processMouseEvent(paramMouseEvent);
/*     */   }
/*     */   
/*     */   public void processMouseMotionEvent(MouseEvent paramMouseEvent) {
/*     */     if (paramMouseEvent.getID() == 506) {
/*     */       if (handleParent(paramMouseEvent))
/*     */         return; 
/*     */       if (this.startRow >= 0) {
/*     */         int i = this.currRow, j = this.currCol;
/*     */         this.currRow = findRow(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */         this.currCol = findCol(paramMouseEvent.getX(), paramMouseEvent.getY());
/*     */         if (i != this.currRow || j != this.currCol)
/*     */           repaint(); 
/*     */       } 
/*     */     } 
/*     */     super.processMouseMotionEvent(paramMouseEvent);
/*     */   }
/*     */   
/*     */   private boolean handleParent(MouseEvent paramMouseEvent) {
/*     */     Point point = getLocation();
/*     */     if (!insideMonth(point.x + paramMouseEvent.getX(), point.y + paramMouseEvent.getY())) {
/*     */       paramMouseEvent.translatePoint(point.x, point.y);
/*     */       Container container = getParent();
/*     */       for (byte b = 0; b < container.getComponentCount(); b++) {
/*     */         if (container.getComponent(b) instanceof SCalendar) {
/*     */           SCalendar sCalendar = (SCalendar)container.getComponent(b);
/*     */           if (sCalendar.insideMonth(paramMouseEvent.getX(), paramMouseEvent.getY())) {
/*     */             paramMouseEvent.translatePoint(-(sCalendar.getLocation()).x, -(sCalendar.getLocation()).y);
/*     */             sCalendar.processEvent(paramMouseEvent);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       return true;
/*     */     } 
/*     */     return false;
/*     */   }
/*     */   
/*     */   private Point dayCoord(int paramInt) {
/*     */     int i = dayOfWeek(this.year, this.month, 1);
/*     */     int j = (paramInt + i - 1) / 7;
/*     */     int k = (paramInt + i - 1) % 7;
/*     */     return new Point(k, j);
/*     */   }
/*     */   
/*     */   private int dayAt(int paramInt1, int paramInt2) { return (this.dayLayout[paramInt1][paramInt2] > 0) ? this.dayLayout[paramInt1][paramInt2] : ((paramInt1 > 0) ? daysInMonth(this.year, this.month) : 1); }
/*     */   
/*     */   private int findRow(int paramInt1, int paramInt2) {
/*     */     byte b1 = -1;
/*     */     for (byte b2 = 0; b2 < 6; b2++) {
/*     */       if (paramInt2 > this.yPosition[b2] && paramInt2 <= this.yPosition[b2 + true]) {
/*     */         b1 = b2;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     return b1;
/*     */   }
/*     */   
/*     */   private int findCol(int paramInt1, int paramInt2) {
/*     */     byte b1 = -1;
/*     */     for (byte b2 = 0; b2 < 7; b2++) {
/*     */       if (paramInt1 > this.xPosition[b2] && paramInt1 <= this.xPosition[b2 + true]) {
/*     */         b1 = b2;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     return b1;
/*     */   }
/*     */   
/*     */   void setStartAtStart() {
/*     */     int i = this.startRow, j = this.startCol;
/*     */     this.startRow = 0;
/*     */     this.startCol = 0;
/*     */     if (i != this.startRow || j != this.startCol)
/*     */       repaint(); 
/*     */   }
/*     */   
/*     */   void setStartAtEnd() {
/*     */     int i = this.startRow, j = this.startCol;
/*     */     this.startRow = 5;
/*     */     this.startCol = 6;
/*     */     if (i != this.startRow || j != this.startCol)
/*     */       repaint(); 
/*     */   }
/*     */   
/*     */   void setEndAtStart() {
/*     */     int i = this.currRow, j = this.currCol;
/*     */     this.currRow = 0;
/*     */     this.currCol = 0;
/*     */     if (i != this.currRow || j != this.currCol)
/*     */       repaint(); 
/*     */   }
/*     */   
/*     */   void setEndAtEnd() {
/*     */     int i = this.currRow, j = this.currCol;
/*     */     this.currRow = 5;
/*     */     this.currCol = 6;
/*     */     if (i != this.currRow || j != this.currCol)
/*     */       repaint(); 
/*     */   }
/*     */   
/*     */   static int[] mtbl = { 
/*     */       0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 
/*     */       304, 334, 365 };
/*     */   
/*     */   public static int daysInMonth(int paramInt1, int paramInt2) {
/*     */     paramInt2++;
/*     */     int i = mtbl[paramInt2] - mtbl[paramInt2 - 1];
/*     */     if (paramInt2 == 2 && paramInt1 % 4 == 0 && (paramInt1 % 100 != 0 || paramInt1 % 400 == 0))
/*     */       i++; 
/*     */     return i;
/*     */   }
/*     */   
/*     */   public static int dayOfWeek(int paramInt1, int paramInt2, int paramInt3) {
/*     */     paramInt2++;
/*     */     if (paramInt1 >= 1900)
/*     */       paramInt1 -= 1900; 
/*     */     long l = paramInt1 * 365L + ((paramInt1 + 3) / 4);
/*     */     l += (mtbl[paramInt2 - 1] + paramInt3 + 6);
/*     */     if (paramInt2 > 2 && paramInt1 % 4 == 0)
/*     */       l++; 
/*     */     return (int)(l % 7L);
/*     */   }
/*     */   
/*     */   private static String[] mName = { 
/*     */       "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", 
/*     */       "Nov", "Dec" };
/*     */   private int tFlag;
/*     */   private int[] tPosition;
/*     */   private int[] xPosition;
/*     */   private int[] yPosition;
/*     */   private int dayWidth;
/*     */   private int dayHeight;
/*     */   private Dimension oSize;
/*     */   private Image buffer;
/*     */   private int[][] dayLayout;
/*     */   private int startRow;
/*     */   private int startCol;
/*     */   private int currRow;
/*     */   private int currCol;
/*     */   private boolean[] hlightMap;
/*     */   private Color[] hlightColorMap;
/*     */   private Color hlightColor;
/*     */   private int year;
/*     */   private int month;
/*     */   private static final int ROWS = 6;
/*     */   private static final int COLS = 7;
/*     */   
/*     */   public static String getMonthName(int paramInt) {
/*     */     if (paramInt < 0 || paramInt > 11)
/*     */       return null; 
/*     */     return mName[paramInt];
/*     */   }
/*     */   
/*     */   public static void setMonthNames(String[] paramArrayOfString) { mName = paramArrayOfString; }
/*     */   
/*     */   public boolean isFocusTraversable() { return true; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\SCalendar.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */