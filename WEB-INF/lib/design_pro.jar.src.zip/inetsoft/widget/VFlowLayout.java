/*     */ package inetsoft.widget;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VFlowLayout
/*     */   extends FlowLayout
/*     */ {
/*     */   public static final int V_TOP = 8;
/*     */   public static final int V_CENTER = 16;
/*     */   public static final int V_BOTTOM = 32;
/*     */   
/*     */   public VFlowLayout() {}
/*     */   
/*  51 */   public VFlowLayout(int paramInt) { super(paramInt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public VFlowLayout(int paramInt1, int paramInt2, int paramInt3) { super(paramInt1, paramInt2, paramInt3); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLayoutComponent(String paramString, Component paramComponent) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeLayoutComponent(Component paramComponent) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension preferredLayoutSize(Container paramContainer) {
/*  89 */     Component[] arrayOfComponent = paramContainer.getComponents();
/*  90 */     Dimension dimension = new Dimension(0, 0);
/*  91 */     boolean bool = true;
/*     */     
/*  93 */     for (byte b = 0; b < arrayOfComponent.length; b++) {
/*  94 */       if (arrayOfComponent[b].isVisible()) {
/*  95 */         Dimension dimension1 = arrayOfComponent[b].getPreferredSize();
/*  96 */         dimension.height += dimension1.height;
/*  97 */         dimension.width = Math.max(dimension.width, dimension1.width);
/*     */         
/*  99 */         bool = false;
/*     */       } 
/*     */     } 
/* 102 */     dimension.height += (arrayOfComponent.length - 1) * getVgap();
/*     */     
/* 104 */     Insets insets = paramContainer.getInsets();
/* 105 */     dimension.width += insets.left + insets.right + getHgap() * 2;
/* 106 */     dimension.height += insets.top + insets.bottom + getVgap() * 2;
/*     */     
/* 108 */     return dimension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public Dimension minimumLayoutSize(Container paramContainer) { return preferredLayoutSize(paramContainer); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void layoutContainer(Container paramContainer) {
/* 126 */     Dimension dimension = paramContainer.getSize();
/* 127 */     if (dimension.width <= 0 || dimension.height <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 131 */     Insets insets = paramContainer.getInsets();
/* 132 */     dimension = new Dimension(dimension.width - insets.left - insets.right, dimension.height - insets.top - insets.bottom);
/*     */     
/* 134 */     Component[] arrayOfComponent = paramContainer.getComponents();
/* 135 */     Dimension[] arrayOfDimension = new Dimension[arrayOfComponent.length];
/*     */ 
/*     */     
/* 138 */     for (byte b1 = 0; b1 < arrayOfComponent.length; b1++) {
/* 139 */       arrayOfDimension[b1] = arrayOfComponent[b1].getPreferredSize();
/*     */     }
/*     */ 
/*     */     
/* 143 */     int i = insets.left + getHgap();
/* 144 */     byte b2 = 0;
/*     */     
/* 146 */     while (b2 < arrayOfComponent.length) {
/*     */       Point point;
/* 148 */       int j = 0;
/* 149 */       int k = 0;
/*     */       
/*     */       byte b3;
/* 152 */       for (b3 = b2; b3 < arrayOfComponent.length; b3++) {
/* 153 */         int m = (arrayOfDimension[b3]).height + (j ? getVgap() : 0);
/* 154 */         j += m;
/* 155 */         if (j > dimension.height) {
/* 156 */           j -= m;
/*     */           break;
/*     */         } 
/* 159 */         k = Math.max(k, (arrayOfDimension[b3]).width + getHgap());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 164 */       if ((getAlignment() & 0x10) != 0) {
/* 165 */         point = new Point(i, insets.top + (dimension.height - j) / 2);
/*     */       }
/* 167 */       else if ((getAlignment() & 0x20) != 0) {
/* 168 */         point = new Point(i, insets.top + dimension.height - j);
/*     */       }
/*     */       else {
/*     */         
/* 172 */         point = new Point(i, insets.top);
/*     */       } 
/*     */ 
/*     */       
/* 176 */       i += k;
/*     */ 
/*     */       
/* 179 */       if (b3 == arrayOfComponent.length) {
/* 180 */         k = dimension.width - point.x - insets.right;
/*     */       }
/*     */ 
/*     */       
/* 184 */       for (byte b4 = b2; b4 < b3; b4++) {
/* 185 */         if ((getAlignment() & true) != 0) {
/* 186 */           arrayOfComponent[b4].setBounds(point.x + (k - (arrayOfDimension[b4]).width) / 2, point.y, (arrayOfDimension[b4]).width, (arrayOfDimension[b4]).height);
/*     */         
/*     */         }
/* 189 */         else if ((getAlignment() & 0x2) != 0) {
/* 190 */           arrayOfComponent[b4].setBounds(point.x + k - (arrayOfDimension[b4]).width, point.y, (arrayOfDimension[b4]).width, (arrayOfDimension[b4]).height);
/*     */         }
/*     */         else {
/*     */           
/* 194 */           arrayOfComponent[b4].setBounds(point.x, point.y, (arrayOfDimension[b4]).width, (arrayOfDimension[b4]).height);
/*     */         } 
/* 196 */         point.y += (arrayOfDimension[b4]).height + getVgap();
/*     */       } 
/*     */       
/* 199 */       if (b2 == b3) {
/*     */         break;
/*     */       }
/* 202 */       b2 = b3;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\VFlowLayout.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */