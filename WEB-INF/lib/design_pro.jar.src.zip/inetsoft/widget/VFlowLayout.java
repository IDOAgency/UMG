package inetsoft.widget;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.Point;

public class VFlowLayout extends FlowLayout {
  public static final int V_TOP = 8;
  
  public static final int V_CENTER = 16;
  
  public static final int V_BOTTOM = 32;
  
  public VFlowLayout() {}
  
  public VFlowLayout(int paramInt) { super(paramInt); }
  
  public VFlowLayout(int paramInt1, int paramInt2, int paramInt3) { super(paramInt1, paramInt2, paramInt3); }
  
  public void addLayoutComponent(String paramString, Component paramComponent) {}
  
  public void removeLayoutComponent(Component paramComponent) {}
  
  public Dimension preferredLayoutSize(Container paramContainer) {
    Component[] arrayOfComponent = paramContainer.getComponents();
    Dimension dimension = new Dimension(0, 0);
    boolean bool = true;
    for (byte b = 0; b < arrayOfComponent.length; b++) {
      if (arrayOfComponent[b].isVisible()) {
        Dimension dimension1 = arrayOfComponent[b].getPreferredSize();
        dimension.height += dimension1.height;
        dimension.width = Math.max(dimension.width, dimension1.width);
        bool = false;
      } 
    } 
    dimension.height += (arrayOfComponent.length - 1) * getVgap();
    Insets insets = paramContainer.getInsets();
    dimension.width += insets.left + insets.right + getHgap() * 2;
    dimension.height += insets.top + insets.bottom + getVgap() * 2;
    return dimension;
  }
  
  public Dimension minimumLayoutSize(Container paramContainer) { return preferredLayoutSize(paramContainer); }
  
  public void layoutContainer(Container paramContainer) {
    Dimension dimension = paramContainer.getSize();
    if (dimension.width <= 0 || dimension.height <= 0)
      return; 
    Insets insets = paramContainer.getInsets();
    dimension = new Dimension(dimension.width - insets.left - insets.right, dimension.height - insets.top - insets.bottom);
    Component[] arrayOfComponent = paramContainer.getComponents();
    Dimension[] arrayOfDimension = new Dimension[arrayOfComponent.length];
    for (byte b1 = 0; b1 < arrayOfComponent.length; b1++)
      arrayOfDimension[b1] = arrayOfComponent[b1].getPreferredSize(); 
    int i = insets.left + getHgap();
    byte b2 = 0;
    while (b2 < arrayOfComponent.length) {
      Point point;
      int j = 0;
      int k = 0;
      byte b3;
      for (b3 = b2; b3 < arrayOfComponent.length; b3++) {
        int m = (arrayOfDimension[b3]).height + (j ? getVgap() : 0);
        j += m;
        if (j > dimension.height) {
          j -= m;
          break;
        } 
        k = Math.max(k, (arrayOfDimension[b3]).width + getHgap());
      } 
      if ((getAlignment() & 0x10) != 0) {
        point = new Point(i, insets.top + (dimension.height - j) / 2);
      } else if ((getAlignment() & 0x20) != 0) {
        point = new Point(i, insets.top + dimension.height - j);
      } else {
        point = new Point(i, insets.top);
      } 
      i += k;
      if (b3 == arrayOfComponent.length)
        k = dimension.width - point.x - insets.right; 
      for (byte b4 = b2; b4 < b3; b4++) {
        if ((getAlignment() & true) != 0) {
          arrayOfComponent[b4].setBounds(point.x + (k - (arrayOfDimension[b4]).width) / 2, point.y, (arrayOfDimension[b4]).width, (arrayOfDimension[b4]).height);
        } else if ((getAlignment() & 0x2) != 0) {
          arrayOfComponent[b4].setBounds(point.x + k - (arrayOfDimension[b4]).width, point.y, (arrayOfDimension[b4]).width, (arrayOfDimension[b4]).height);
        } else {
          arrayOfComponent[b4].setBounds(point.x, point.y, (arrayOfDimension[b4]).width, (arrayOfDimension[b4]).height);
        } 
        point.y += (arrayOfDimension[b4]).height + getVgap();
      } 
      if (b2 == b3)
        break; 
      b2 = b3;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\VFlowLayout.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */