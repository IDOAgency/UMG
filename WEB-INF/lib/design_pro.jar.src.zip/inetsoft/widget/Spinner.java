/*     */ package inetsoft.widget;
/*     */ 
/*     */ import inetsoft.widget.util.EventMgr;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.ItemSelectable;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.TextEvent;
/*     */ import java.awt.event.TextListener;
/*     */ import java.util.Vector;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Spinner
/*     */   extends JPanel
/*     */   implements ItemSelectable
/*     */ {
/*     */   protected EventMgr eventMgr;
/*     */   private JTextField cell;
/*     */   private boolean number;
/*     */   private int low;
/*     */   private int high;
/*     */   private int curr;
/*     */   private Vector items;
/*     */   protected JButton up;
/*     */   protected JButton down;
/*     */   
/*  65 */   public Spinner() { this(-2147483648, 2147483647); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spinner(int paramInt1, int paramInt2)
/*     */   {
/* 539 */     this.eventMgr = new EventMgr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 592 */     this.cell = new JTextField();
/* 593 */     this.number = true;
/*     */     
/* 595 */     this.curr = 0;
/* 596 */     this.items = new Vector();
/* 597 */     this.up = new JButton(); this.down = new JButton(); init(); setRange(paramInt1, paramInt2); setColumns(Math.max(Integer.toString(paramInt1).length(), Integer.toString(paramInt2).length())); } public int getColumns() { return this.cell.getColumns(); } public void setColumns(int paramInt) { this.cell.setColumns(paramInt); } public void setRange(int paramInt1, int paramInt2) { this.number = true; this.low = paramInt1; this.high = paramInt2; this.curr = paramInt1; if (this.cell != null) { setEditable(false); this.cell.setText(Integer.toString(this.curr)); repaint(); }  } public boolean isNumeric() { return this.number; } public void setRangeLow(int paramInt) { setRange(paramInt, this.high); } public int getRangeLow() { return this.number ? this.low : -1; } public void setRangeHigh(int paramInt) { setRange(this.low, paramInt); } public int getRangeHigh() { return this.number ? this.high : -1; } public String[] getItems() { String[] arrayOfString = new String[this.items.size()]; this.items.copyInto(arrayOfString); return arrayOfString; } public Spinner(String[] paramArrayOfString) { this.eventMgr = new EventMgr(); this.cell = new JTextField(); this.number = true; this.curr = 0; this.items = new Vector(); this.up = new JButton(); this.down = new JButton(); this.number = false; for (byte b = 0; b < paramArrayOfString.length; b++) add(paramArrayOfString[b]);  init(); }
/*     */   public void add(String paramString) { this.number = false; this.items.addElement(paramString); repaint(); }
/* 599 */   public void remove(String paramString) { this.items.removeElement(paramString); if (this.curr >= this.items.size()) this.curr = this.items.size() - 1;  this.cell.setText(this.items.elementAt(this.curr).toString()); } public void setCurrent(int paramInt) { if (this.number) { this.curr = (paramInt < this.low) ? this.low : ((paramInt > this.high) ? this.high : paramInt); try { if (!this.cell.getText().equals(this.curr + "")) this.cell.setText(Integer.toString(this.curr));  } catch (Exception exception) {} if (this.curr == this.low) { this.down.setEnabled(false); this.up.setEnabled(true); } else if (this.curr == this.high) { this.up.setEnabled(false); this.down.setEnabled(true); } else { this.up.setEnabled(true); this.down.setEnabled(true); }  } else if (this.items.size() > 0) { this.curr = paramInt; this.cell.setText(this.items.elementAt(this.curr).toString()); if (this.curr == this.items.size() - 1) { this.up.setEnabled(false); this.down.setEnabled(true); } else if (this.curr == 0) { this.down.setEnabled(false); this.up.setEnabled(true); } else { this.up.setEnabled(true); this.down.setEnabled(true); }  }  repaint(); } public void setEnabled(boolean paramBoolean) { super.setEnabled(paramBoolean); if (paramBoolean) { if (this.number || this.items.size() > 0) { setCurrent(this.curr); } else { this.up.setEnabled(true); this.down.setEnabled(true); }  } else { this.up.setEnabled(false); this.down.setEnabled(false); }  } public int getCurrent() { return this.curr; } public Object[] getSelectedObjects() { return new Integer[] { new Integer(getCurrent()) }; } public void setForeground(Color paramColor) { super.setForeground(paramColor); if (this.cell != null) this.cell.setForeground(paramColor);  } public void setBackground(Color paramColor) { super.setBackground(paramColor); if (this.cell != null) this.cell.setBackground(paramColor);  } public void setFont(Font paramFont) { super.setFont(paramFont); if (this.cell != null) this.cell.setFont(paramFont);  } static ImageIcon up_gif = new ImageIcon(Spinner.class.getResource("/inetsoft/widget/images/uparrow.gif")); private void init() { int i = 0; String str = ""; if (this.number) { str = Integer.toString(this.low); i = Integer.toString(this.high).length(); } else { for (byte b = 0; b < this.items.size(); b++) { if (this.items.elementAt(b).toString().length() > i) i = this.items.elementAt(b).toString().length();  }  str = (this.items.size() > 0) ? this.items.elementAt(0).toString() : ""; }  setLayout(new BorderLayout()); this.cell.setText(str); this.cell.setColumns(i); add(this.cell, "Center"); JPanel jPanel = new JPanel(this) { private final Spinner this$0; public void doLayout() { Dimension dimension = getSize(); int i = dimension.height / 2; this.this$0.up.setBounds(0, 0, dimension.width, i + 1); this.this$0.down.setBounds(0, i, dimension.width, dimension.height - i + 1); } }
/*     */       ; jPanel.setLayout(new GridLayout(2, 1)); this.up.setIcon(up_gif); this.down.setIcon(down_gif); jPanel.add(this.up); jPanel.add(this.down); this.up.setPreferredSize(new Dimension(12, 6)); this.down.setPreferredSize(new Dimension(12, 6)); this.down.setEnabled(false); add(jPanel, "East"); this.up.addActionListener(new ActionListener(this) { private final Spinner this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.scrollUp(); this.this$0.eventMgr.postEvent(new ItemEvent(this.this$0, 701, this.this$0.cell.getText(), 0)); } }
/*     */       ); this.down.addActionListener(new ActionListener(this) { private final Spinner this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.scrollDown(); this.this$0.eventMgr.postEvent(new ItemEvent(this.this$0, 701, this.this$0.cell.getText(), 0)); } }
/* 602 */       ); this.cell.addActionListener(new ActionListener(this) { private final Spinner this$0; public void actionPerformed(ActionEvent param1ActionEvent) { if (!this.this$0.number) { this.this$0.items.insertElementAt(this.this$0.cell.getText(), this.this$0.curr); } else { try { this.this$0.setCurrent(Integer.parseInt(this.this$0.cell.getText())); } catch (Exception exception) {} }  this.this$0.eventMgr.postEvent(new ActionEvent(this.this$0, 1001, this.this$0.cell.getText())); this.this$0.eventMgr.postEvent(new ItemEvent(this.this$0, 701, this.this$0.cell.getText(), 0)); } }); this.cell.getDocument().addDocumentListener(new DocumentListener(this) { private final Spinner this$0; public void insertUpdate(DocumentEvent param1DocumentEvent) { changedUpdate(param1DocumentEvent); } public void removeUpdate(DocumentEvent param1DocumentEvent) { changedUpdate(param1DocumentEvent); } public void changedUpdate(DocumentEvent param1DocumentEvent) { if (this.this$0.number) { String str = this.this$0.cell.getText(); this.this$0.setCurrent((str.length() == 0) ? 0 : Integer.parseInt(str)); }  this.this$0.eventMgr.postEvent(new TextEvent(this.this$0, 900)); } }); setEditable(false); } protected void scrollUp() { if ((this.number && this.curr < this.high) || this.curr < this.items.size() - 1) { setCurrent(this.curr + 1); this.eventMgr.postEvent(new TextEvent(this, 900)); }  } protected void scrollDown() { if ((this.number && this.curr > this.low) || this.curr > 0) { setCurrent(this.curr - 1); this.eventMgr.postEvent(new TextEvent(this, 900)); }  } public void setText(String paramString) { this.cell.setText(paramString); } public String getText() { return this.cell.getText(); } public String getSelectedText() { return this.cell.getSelectedText(); } public boolean isEditable() { return this.cell.isEditable(); } public void setEditable(boolean paramBoolean) { this.cell.setEditable(paramBoolean); } public int getSelectionStart() { return this.cell.getSelectionStart(); } static ImageIcon down_gif = new ImageIcon(Spinner.class.getResource("/inetsoft/widget/images/downarrow.gif"));
/*     */   
/*     */   public int getSelectionEnd() { return this.cell.getSelectionEnd(); }
/*     */   
/*     */   public void select(int paramInt1, int paramInt2) { this.cell.select(paramInt1, paramInt2); }
/*     */   
/*     */   public void selectAll() { this.cell.selectAll(); }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
/*     */   
/*     */   public void addItemListener(ItemListener paramItemListener) { this.eventMgr.addItemListener(paramItemListener); }
/*     */   
/*     */   public void removeItemListener(ItemListener paramItemListener) { this.eventMgr.removeItemListener(paramItemListener); }
/*     */   
/*     */   public void addTextListener(TextListener paramTextListener) { this.eventMgr.addTextListener(paramTextListener); }
/*     */   
/*     */   public void removeTextListener(TextListener paramTextListener) { this.eventMgr.removeTextListener(paramTextListener); }
/*     */   
/*     */   protected JTextField getField() { return this.cell; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\Spinner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */