/*    */ package inetsoft.widget;
/*    */ 
/*    */ import inetsoft.beans.AutoBeanInfo;
/*    */ import java.awt.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class STreeBeanInfo
/*    */   extends AutoBeanInfo
/*    */ {
/* 28 */   public STreeBeanInfo() { super(STree.class); }
/*    */ 
/*    */ 
/*    */   
/*    */   public Image getIcon(int paramInt) {
/*    */     Image image;
/* 34 */     switch (paramInt) {
/*    */       case 1:
/*    */       case 3:
/* 37 */         image = loadImage("beans/STreeBean.gif");
/* 38 */         return image.getScaledInstance(16, 16, 4);
/*    */       case 2:
/*    */       case 4:
/* 41 */         image = loadImage("beans/STreeBean32.gif");
/* 42 */         return image.getScaledInstance(32, 32, 4);
/*    */     } 
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\STreeBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */