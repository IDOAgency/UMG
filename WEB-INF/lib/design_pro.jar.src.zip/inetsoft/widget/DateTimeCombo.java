package inetsoft.widget;

import java.text.DateFormat;
import java.util.TimeZone;

public class DateTimeCombo extends DateCombo {
  DateTimeSelector ts;
  
  public DateTimeCombo() { super(14); }
  
  public DateTimeCombo(int paramInt) { super(paramInt); }
  
  public DateTimeCombo(String paramString) { super(paramString); }
  
  public DateTimeCombo(String paramString, int paramInt) { super(paramString, paramInt); }
  
  public int getHour() { return this.ts.getHour(); }
  
  public int getHourOfDay() { return this.ts.getHourOfDay(); }
  
  public int getMinute() { return this.ts.getMinute(); }
  
  public int getSecond() { return this.ts.getSecond(); }
  
  public int getAmPm() { return this.ts.getSecond(); }
  
  protected DateSelector createSelector() { return this.ts = new DateTimeSelector(); }
  
  protected DateFormat createDateFormat() {
    DateFormat dateFormat = DateFormat.getDateTimeInstance();
    dateFormat.setTimeZone(TimeZone.getDefault());
    return dateFormat;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\DateTimeCombo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */