package inetsoft.widget;

import java.awt.ItemSelectable;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.JToggleButton;

public class RadioBox extends OptionBox implements ItemSelectable {
  private ButtonGroup group;
  
  public RadioBox() { this(1, 1); }
  
  public RadioBox(int paramInt1, int paramInt2) {
    super(paramInt1, paramInt2);
    this.group = new ButtonGroup();
  }
  
  public String getSelectedItem() {
    for (byte b = 0; b < this.pnl.getComponentCount(); b++) {
      if (this.pnl.getComponent(b) instanceof JToggleButton) {
        JToggleButton jToggleButton = (JToggleButton)this.pnl.getComponent(b);
        if (jToggleButton.isSelected())
          return jToggleButton.getLabel(); 
      } 
    } 
    return null;
  }
  
  protected JToggleButton createCheckbox(String paramString, boolean paramBoolean) {
    JRadioButton jRadioButton = new JRadioButton(paramString, paramBoolean);
    this.group.add(jRadioButton);
    return jRadioButton;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\RadioBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */