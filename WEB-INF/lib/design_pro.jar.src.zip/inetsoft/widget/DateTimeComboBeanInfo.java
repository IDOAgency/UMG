package inetsoft.widget;

import java.awt.Image;
import java.beans.SimpleBeanInfo;

public class DateTimeComboBeanInfo extends SimpleBeanInfo {
  public Image getIcon(int paramInt) {
    Image image;
    switch (paramInt) {
      case 1:
      case 3:
        image = loadImage("beans/DateTimeComboBean.gif");
        return image.getScaledInstance(16, 16, 4);
      case 2:
      case 4:
        image = loadImage("beans/DateTimeComboBean32.gif");
        return image.getScaledInstance(32, 32, 4);
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\DateTimeComboBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */