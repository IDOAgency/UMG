package inetsoft.widget;

import java.awt.Image;
import java.beans.SimpleBeanInfo;

public class MenuButtonBeanInfo extends SimpleBeanInfo {
  public Image getIcon(int paramInt) {
    Image image;
    switch (paramInt) {
      case 1:
      case 3:
        image = loadImage("beans/MenuButtonBean.gif");
        return image.getScaledInstance(16, 16, 4);
      case 2:
      case 4:
        image = loadImage("beans/MenuButtonBean32.gif");
        return image.getScaledInstance(32, 32, 4);
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\MenuButtonBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */