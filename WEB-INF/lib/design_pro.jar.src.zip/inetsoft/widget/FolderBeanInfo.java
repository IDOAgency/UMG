package inetsoft.widget;

import inetsoft.beans.AutoBeanInfo;
import java.awt.Image;
import java.beans.PropertyEditorSupport;

public class FolderBeanInfo extends AutoBeanInfo {
  public FolderBeanInfo() {
    super(Folder.class);
    registerEditor("tabPlacement", PositionEditor.class);
    registerEditor("tabLayout", Editor.class);
    registerEditor("tabAppearance", Appearance.class);
  }
  
  public Image getIcon(int paramInt) {
    Image image;
    switch (paramInt) {
      case 1:
      case 3:
        image = loadImage("beans/FolderBean.gif");
        return image.getScaledInstance(16, 16, 4);
      case 2:
      case 4:
        image = loadImage("beans/FolderBean32.gif");
        return image.getScaledInstance(32, 32, 4);
    } 
    return null;
  }
  
  public static class Editor extends PropertyEditorSupport {
    public void setAsText(String param1String) {
      if (param1String.equals("LAYERED_TAB")) {
        setValue(new Integer(1));
      } else if (param1String.equals("SCROLLED_TAB")) {
        setValue(new Integer(2));
      } 
    }
    
    public String[] getTags() { return new String[] { "LAYERED_TAB", "SCROLLED_TAB" }; }
  }
  
  public static class PositionEditor extends PropertyEditorSupport {
    public void setAsText(String param1String) {
      if (param1String.equals("LEFT")) {
        setValue(new Integer(1));
      } else if (param1String.equals("TOP")) {
        setValue(new Integer(4));
      } else if (param1String.equals("RIGHT")) {
        setValue(new Integer(3));
      } else if (param1String.equals("BOTTOM")) {
        setValue(new Integer(3));
      } 
    }
    
    public String[] getTags() { return new String[] { "LEFT", "TOP", "RIGHT", "BOTTOM" }; }
  }
  
  public static class Appearance extends PropertyEditorSupport {
    public void setAsText(String param1String) {
      if (param1String.equals("TAB_SLANTED")) {
        setValue(new Integer(1));
      } else if (param1String.equals("TAB_ROUNDED")) {
        setValue(new Integer(2));
      } else if (param1String.equals("TAB_CHAMFERED")) {
        setValue(new Integer(3));
      } else if (param1String.equals("TAB_STRAIGHT")) {
        setValue(new Integer(4));
      } else if (param1String.equals("TAB_CUTCORNER")) {
        setValue(new Integer(5));
      } 
    }
    
    public String[] getTags() { return new String[] { "TAB_SLANTED", "TAB_ROUNDED", "TAB_CHAMFERED", "TAB_STRAIGHT", "TAB_CUTCPRNER" }; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\FolderBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */