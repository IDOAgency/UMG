/*     */ package inetsoft.widget;
/*     */ 
/*     */ import inetsoft.beans.AutoBeanInfo;
/*     */ import java.awt.Image;
/*     */ import java.beans.PropertyEditorSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FolderBeanInfo
/*     */   extends AutoBeanInfo
/*     */ {
/*     */   public FolderBeanInfo() {
/*  28 */     super(Folder.class);
/*  29 */     registerEditor("tabPlacement", PositionEditor.class);
/*  30 */     registerEditor("tabLayout", Editor.class);
/*  31 */     registerEditor("tabAppearance", Appearance.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Image getIcon(int paramInt) {
/*     */     Image image;
/*  37 */     switch (paramInt) {
/*     */       case 1:
/*     */       case 3:
/*  40 */         image = loadImage("beans/FolderBean.gif");
/*  41 */         return image.getScaledInstance(16, 16, 4);
/*     */       case 2:
/*     */       case 4:
/*  44 */         image = loadImage("beans/FolderBean32.gif");
/*  45 */         return image.getScaledInstance(32, 32, 4);
/*     */     } 
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Editor
/*     */     extends PropertyEditorSupport
/*     */   {
/*     */     public void setAsText(String param1String) {
/*  55 */       if (param1String.equals("LAYERED_TAB")) {
/*  56 */         setValue(new Integer(1));
/*     */       }
/*  58 */       else if (param1String.equals("SCROLLED_TAB")) {
/*  59 */         setValue(new Integer(2));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     public String[] getTags() { return new String[] { "LAYERED_TAB", "SCROLLED_TAB" }; }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PositionEditor
/*     */     extends PropertyEditorSupport
/*     */   {
/*     */     public void setAsText(String param1String) {
/*  76 */       if (param1String.equals("LEFT")) {
/*  77 */         setValue(new Integer(1));
/*     */       }
/*  79 */       else if (param1String.equals("TOP")) {
/*  80 */         setValue(new Integer(4));
/*     */       }
/*  82 */       else if (param1String.equals("RIGHT")) {
/*  83 */         setValue(new Integer(3));
/*     */       }
/*  85 */       else if (param1String.equals("BOTTOM")) {
/*  86 */         setValue(new Integer(3));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     public String[] getTags() { return new String[] { "LEFT", "TOP", "RIGHT", "BOTTOM" }; }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Appearance
/*     */     extends PropertyEditorSupport
/*     */   {
/*     */     public void setAsText(String param1String) {
/* 103 */       if (param1String.equals("TAB_SLANTED")) {
/* 104 */         setValue(new Integer(1));
/*     */       }
/* 106 */       else if (param1String.equals("TAB_ROUNDED")) {
/* 107 */         setValue(new Integer(2));
/*     */       }
/* 109 */       else if (param1String.equals("TAB_CHAMFERED")) {
/* 110 */         setValue(new Integer(3));
/*     */       }
/* 112 */       else if (param1String.equals("TAB_STRAIGHT")) {
/* 113 */         setValue(new Integer(4));
/*     */       }
/* 115 */       else if (param1String.equals("TAB_CUTCORNER")) {
/* 116 */         setValue(new Integer(5));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     public String[] getTags() { return new String[] { "TAB_SLANTED", "TAB_ROUNDED", "TAB_CHAMFERED", "TAB_STRAIGHT", "TAB_CUTCPRNER" }; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\FolderBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */