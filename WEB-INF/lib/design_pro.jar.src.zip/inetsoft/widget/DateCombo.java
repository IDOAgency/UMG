/*     */ package inetsoft.widget;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Panel;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.border.EtchedBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateCombo
/*     */   extends ComboBase
/*     */ {
/*     */   ActionListener okListener;
/*     */   DateSelector selector;
/*     */   JButton okB;
/*     */   JButton cancelB;
/*     */   boolean click2;
/*     */   Date date;
/*     */   DateFormat fmt;
/*     */   
/*  59 */   public DateCombo() { this(11); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateCombo(int paramInt) {
/*  67 */     super(paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     this.click2 = false; setEditable(false); } public DateCombo(String paramString) { super(paramString); this.click2 = false; setEditable(false); } public DateCombo(String paramString, int paramInt) { super(paramString, paramInt); this.click2 = false;
/*     */     setEditable(false); }
/*     */ 
/*     */   
/*     */   public void setFormat(DateFormat paramDateFormat) {
/*     */     this.fmt = paramDateFormat;
/*     */     if (this.date != null)
/*     */       setText(" " + paramDateFormat.format(getDate()) + " "); 
/*     */   }
/*     */   
/*     */   public DateFormat getFormat() { return this.fmt; }
/*     */   
/*     */   public void setDate(Date paramDate) {
/*     */     this.date = paramDate;
/*     */     this.selector.setSelectedDate(paramDate);
/*     */     if (paramDate != null) {
/*     */       setText(" " + this.fmt.format(paramDate) + " ");
/*     */     } else {
/*     */       setText("");
/*     */     } 
/*     */   }
/*     */   
/*     */   public Date getDate() { return this.selector.getSelectedDate(); }
/*     */   
/*     */   public int getYear() { return this.selector.getYear(); }
/*     */   
/*     */   public int getMonth() { return this.selector.getMonth(); }
/*     */   
/*     */   public int getDay() { return this.selector.getDay(); }
/*     */   
/*     */   public void setDoubleClickSelect(boolean paramBoolean) { this.click2 = paramBoolean; }
/*     */   
/*     */   public boolean isDoubleClickSelect() { return this.click2; }
/*     */   
/*     */   protected void init() {
/*     */     super.init();
/*     */     this.fmt = createDateFormat();
/*     */     this.selector = createSelector();
/*     */     this.selector.addActionListener(this.okListener = new OKListener(this));
/*     */     this.okB = new JButton("OK");
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.cancelB = new JButton("Cancel");
/*     */     this.cancelB.addActionListener(new ActionListener(this) {
/*     */           private final DateCombo this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.popdown(); }
/*     */         });
/*     */   }
/*     */   
/*     */   protected JPanel createMenu() { return new DateWin(this); }
/*     */   
/*     */   protected DateSelector createSelector() { return new DateSelector(); }
/*     */   
/*     */   protected DateFormat createDateFormat() {
/*     */     DateFormat dateFormat = DateFormat.getDateInstance(1);
/*     */     dateFormat.setTimeZone(TimeZone.getDefault());
/*     */     return dateFormat;
/*     */   }
/*     */   
/*     */   private class DateWin extends JPanel {
/*     */     private final DateCombo this$0;
/*     */     
/*     */     public DateWin(DateCombo this$0) {
/*     */       this.this$0 = this$0;
/*     */       setLayout(new BorderLayout());
/*     */       JPanel jPanel = new JPanel();
/*     */       jPanel.setBorder(new CompoundBorder(new EtchedBorder(), new EmptyBorder(5, 9, 5, 9)));
/*     */       jPanel.setLayout(new BorderLayout());
/*     */       add(jPanel, "Center");
/*     */       jPanel.add(this$0.selector, "Center");
/*     */       if (!this$0.click2) {
/*     */         Panel panel = new Panel();
/*     */         panel.add(this$0.okB);
/*     */         panel.add(this$0.cancelB);
/*     */         jPanel.add(panel, "South");
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class OKListener implements ActionListener {
/*     */     private final DateCombo this$0;
/*     */     
/*     */     OKListener(DateCombo this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */       this.this$0.date = this.this$0.selector.getSelectedDate();
/*     */       this.this$0.setText(" " + this.this$0.fmt.format(this.this$0.date) + " ");
/*     */       this.this$0.popdown();
/*     */       this.this$0.eventMgr.postEvent(new ActionEvent(this.this$0, 1001, this.this$0.getText()));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\DateCombo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */