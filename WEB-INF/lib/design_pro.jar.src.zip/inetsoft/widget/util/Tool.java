/*     */ package inetsoft.widget.util;
/*     */ 
/*     */ import java.applet.Applet;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Window;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tool
/*     */ {
/*     */   public static final int WIDTH_MASK = 15;
/*     */   public static final int DASH_MASK = 240;
/*     */   public static final int SOLID_MASK = 4096;
/*     */   public static final int DOUBLE_MASK = 8192;
/*     */   public static final int RAISED_MASK = 16384;
/*     */   public static final int LOWERED_MASK = 32768;
/*     */   public static final int THIN_LINE = 4097;
/*     */   public static final int MEDIUM_LINE = 4098;
/*     */   public static final int THICK_LINE = 4099;
/*     */   public static final int RAISED = 24578;
/*     */   public static final int LOWERED = 40962;
/*     */   public static final int DOT_LINE = 4113;
/*     */   public static final int RAISED_FRAME = 24580;
/*     */   public static final int LOWERED_FRAME = 40964;
/*     */   
/*     */   public static void drawHLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  95 */     if (paramInt4 == 4113) {
/*  96 */       drawDotLine(paramGraphics, paramInt2, paramInt1, paramInt3, paramInt1);
/*     */     }
/*  98 */     else if ((paramInt4 & 0x1000) != 0) {
/*  99 */       paramGraphics.fillRect(paramInt2, paramInt1, paramInt3 - paramInt2, paramInt4 & 0xF);
/*     */     } else {
/*     */       
/* 102 */       draw3DLine(paramGraphics, paramInt2, paramInt1, paramInt3, paramInt1, paramGraphics.getColor(), paramInt4 & 0xF, (paramInt4 == 24578 || paramInt4 == 24580), (paramInt4 == 24580 || paramInt4 == 40964));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawVLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 110 */     if (paramInt4 == 4113) {
/* 111 */       drawDotLine(paramGraphics, paramInt1, paramInt2, paramInt1, paramInt3);
/*     */     }
/* 113 */     else if ((paramInt4 & 0x1000) != 0) {
/* 114 */       paramGraphics.fillRect(paramInt1, paramInt2, paramInt4 & 0xF, paramInt3 - paramInt2);
/*     */     } else {
/*     */       
/* 117 */       draw3DLine(paramGraphics, paramInt1, paramInt2, paramInt1, paramInt3, paramGraphics.getColor(), paramInt4 & 0xF, (paramInt4 == 24578 || paramInt4 == 24580), (paramInt4 == 24580 || paramInt4 == 40964));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public static void draw3DLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, int paramInt5) { draw3DLine(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramColor, paramInt5, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   public static void draw3DLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, int paramInt5, boolean paramBoolean) { draw3DLine(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramColor, paramInt5, paramBoolean, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void draw3DLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, int paramInt5, boolean paramBoolean1, boolean paramBoolean2) {
/* 169 */     Color color = paramGraphics.getColor();
/* 170 */     paramGraphics.setColor(paramBoolean1 ? paramColor.brighter() : paramColor.darker());
/*     */     
/* 172 */     for (byte b = 0; b < paramInt5; b++) {
/*     */       
/* 174 */       if ((paramBoolean2 && b == paramInt5 - 1) || (!paramBoolean2 && b == paramInt5 / 2)) {
/* 175 */         paramGraphics.setColor(paramBoolean1 ? paramColor.darker() : paramColor.brighter());
/*     */       }
/* 177 */       else if (paramBoolean2 && b) {
/* 178 */         paramGraphics.setColor(paramColor);
/*     */       } 
/*     */       
/* 181 */       paramGraphics.drawLine(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */       
/* 183 */       if (paramInt1 == paramInt3) {
/* 184 */         paramInt1++;
/* 185 */         paramInt3++;
/*     */       }
/* 187 */       else if (paramInt2 == paramInt4) {
/* 188 */         paramInt2++;
/* 189 */         paramInt4++;
/*     */       }
/* 191 */       else if (paramInt1 < paramInt3) {
/* 192 */         paramInt2 += (paramInt4 - paramInt2) / (paramInt3 - paramInt1);
/* 193 */         paramInt3++;
/*     */       }
/* 195 */       else if (paramInt3 > paramInt1) {
/* 196 */         paramInt4 += (paramInt2 - paramInt4) / (paramInt1 - paramInt3);
/* 197 */         paramInt1++;
/*     */       } 
/*     */     } 
/*     */     
/* 201 */     paramGraphics.setColor(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawDotLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 213 */     boolean bool = true;
/* 214 */     if (paramInt1 != paramInt3) {
/* 215 */       int i = (paramInt3 > paramInt1) ? 1 : -1;
/* 216 */       for (int j = paramInt1; j - i != paramInt3; j += i, bool = !bool ? 1 : 0) {
/* 217 */         if (bool) {
/* 218 */           int k = (int)(paramInt4 - (paramInt3 - j) * (paramInt4 - paramInt2) / (paramInt3 - paramInt1));
/* 219 */           paramGraphics.drawLine(j, k, j, k);
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 224 */       int i = (paramInt4 > paramInt2) ? 1 : -1;
/* 225 */       for (int j = paramInt2; j - i != paramInt4; j += i, bool = !bool ? 1 : 0) {
/* 226 */         if (bool) {
/* 227 */           paramGraphics.drawLine(paramInt1, j, paramInt3, j);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawDotRect(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 242 */     drawDotLine(paramGraphics, paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2);
/* 243 */     drawDotLine(paramGraphics, paramInt1 + paramInt3, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
/* 244 */     drawDotLine(paramGraphics, paramInt1, paramInt2 + paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
/* 245 */     drawDotLine(paramGraphics, paramInt1, paramInt2, paramInt1, paramInt2 + paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Frame findFrame(Component paramComponent) {
/* 254 */     for (Component component = paramComponent; component != null; component = component.getParent()) {
/* 255 */       if (component instanceof Frame) {
/* 256 */         return (Frame)component;
/*     */       }
/*     */     } 
/* 259 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Window findWindow(Component paramComponent) {
/* 268 */     for (Component component = paramComponent; component != null; component = component.getParent()) {
/* 269 */       if (component instanceof Window) {
/* 270 */         return (Window)component;
/*     */       }
/*     */     } 
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Applet findApplet(Component paramComponent) {
/* 282 */     for (Component component = paramComponent; component != null; component = component.getParent()) {
/* 283 */       if (component instanceof Applet) {
/* 284 */         return (Applet)component;
/*     */       }
/*     */     } 
/* 287 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Container findTopContainer(Component paramComponent) {
/* 296 */     Container container1 = paramComponent.getParent();
/* 297 */     for (Container container2 = container1; container2 != null; container2 = container2.getParent()) {
/* 298 */       container1 = container2;
/*     */     }
/* 300 */     return container1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point locationInFrame(Component paramComponent) {
/* 309 */     Point point = paramComponent.getLocation();
/* 310 */     for (Container container = paramComponent.getParent(); !(container instanceof Frame); 
/* 311 */       container = container.getParent()) {
/* 312 */       point.translate((container.getLocation()).x, (container.getLocation()).y);
/*     */     }
/*     */     
/* 315 */     return point;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point locationInWindow(Component paramComponent) {
/* 324 */     Point point = paramComponent.getLocation();
/* 325 */     for (Container container = paramComponent.getParent(); !(container instanceof Window); 
/* 326 */       container = container.getParent()) {
/* 327 */       point.translate((container.getLocation()).x, (container.getLocation()).y);
/*     */     }
/*     */     
/* 330 */     return point;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Point absLocation(Component paramComponent) {
/* 339 */     Point point1 = findWindow(paramComponent).getLocation();
/* 340 */     Point point2 = locationInWindow(paramComponent);
/*     */     
/* 342 */     return new Point(point1.x + point2.x, point1.y + point2.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawDownArrow(Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 353 */     int[] arrayOfInt1 = { paramInt1 - 4, paramInt1 + 4, paramInt1 };
/* 354 */     int[] arrayOfInt2 = { paramInt2 - 4, paramInt2 - 4, paramInt2 + 4 };
/*     */     
/* 356 */     Color color = paramGraphics.getColor();
/* 357 */     paramGraphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
/* 358 */     paramGraphics.setColor(paramBoolean ? color.brighter() : color.darker());
/* 359 */     paramGraphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[1], arrayOfInt2[1]);
/* 360 */     paramGraphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[2], arrayOfInt2[2]);
/* 361 */     paramGraphics.setColor(paramBoolean ? color.darker() : color.brighter());
/* 362 */     paramGraphics.drawLine(arrayOfInt1[2], arrayOfInt2[2], arrayOfInt1[1], arrayOfInt2[1]);
/* 363 */     paramGraphics.setColor(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawUpArrow(Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 374 */     int[] arrayOfInt1 = { paramInt1 - 4, paramInt1 + 4, paramInt1 };
/* 375 */     int[] arrayOfInt2 = { paramInt2 + 4, paramInt2 + 4, paramInt2 - 4 };
/*     */     
/* 377 */     Color color = paramGraphics.getColor();
/* 378 */     paramGraphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
/* 379 */     paramGraphics.setColor(paramBoolean ? color.brighter() : color.darker());
/* 380 */     paramGraphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[2], arrayOfInt2[2]);
/* 381 */     paramGraphics.setColor(paramBoolean ? color.darker() : color.brighter());
/* 382 */     paramGraphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[1], arrayOfInt2[1]);
/* 383 */     paramGraphics.drawLine(arrayOfInt1[2], arrayOfInt2[2], arrayOfInt1[1], arrayOfInt2[1]);
/* 384 */     paramGraphics.setColor(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String parseString(String paramString) {
/* 394 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 396 */     for (byte b = 0; b < paramString.length(); b++) {
/* 397 */       if (paramString.charAt(b) == '\\') {
/* 398 */         b++;
/* 399 */         if (b < paramString.length()) {
/* 400 */           if (paramString.charAt(b) == 't') {
/* 401 */             stringBuffer.append("\t");
/*     */           }
/* 403 */           else if (paramString.charAt(b) == 'n') {
/* 404 */             stringBuffer.append("\n");
/*     */           } else {
/*     */             
/* 407 */             stringBuffer.append(paramString.charAt(b));
/*     */           } 
/*     */         }
/*     */       } else {
/*     */         
/* 412 */         stringBuffer.append(paramString.charAt(b));
/*     */       } 
/*     */     } 
/*     */     
/* 416 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] tokenize(String paramString1, String paramString2) {
/* 427 */     Vector vector = new Vector();
/*     */     
/*     */     try {
/* 430 */       StringTokenizer stringTokenizer = new StringTokenizer(paramString1, paramString2);
/* 431 */       while (stringTokenizer.hasMoreTokens()) {
/* 432 */         vector.addElement(stringTokenizer.nextToken());
/*     */       }
/*     */     } catch (Exception exception) {
/*     */       
/* 436 */       exception.printStackTrace();
/*     */     } 
/*     */     
/* 439 */     String[] arrayOfString = new String[vector.size()];
/* 440 */     vector.copyInto(arrayOfString);
/* 441 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object[] toArray(Vector paramVector) {
/* 448 */     Class clazz = (paramVector.size() > 0) ? paramVector.elementAt(0).getClass() : String.class;
/* 449 */     Object[] arrayOfObject = (Object[])Array.newInstance(clazz, paramVector.size());
/* 450 */     paramVector.copyInto(arrayOfObject);
/* 451 */     return arrayOfObject;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widge\\util\Tool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */