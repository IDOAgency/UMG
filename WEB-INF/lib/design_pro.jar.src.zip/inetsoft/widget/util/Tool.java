package inetsoft.widget.util;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Window;
import java.lang.reflect.Array;
import java.util.StringTokenizer;
import java.util.Vector;

public class Tool {
  public static final int WIDTH_MASK = 15;
  
  public static final int DASH_MASK = 240;
  
  public static final int SOLID_MASK = 4096;
  
  public static final int DOUBLE_MASK = 8192;
  
  public static final int RAISED_MASK = 16384;
  
  public static final int LOWERED_MASK = 32768;
  
  public static final int THIN_LINE = 4097;
  
  public static final int MEDIUM_LINE = 4098;
  
  public static final int THICK_LINE = 4099;
  
  public static final int RAISED = 24578;
  
  public static final int LOWERED = 40962;
  
  public static final int DOT_LINE = 4113;
  
  public static final int RAISED_FRAME = 24580;
  
  public static final int LOWERED_FRAME = 40964;
  
  public static void drawHLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt4 == 4113) {
      drawDotLine(paramGraphics, paramInt2, paramInt1, paramInt3, paramInt1);
    } else if ((paramInt4 & 0x1000) != 0) {
      paramGraphics.fillRect(paramInt2, paramInt1, paramInt3 - paramInt2, paramInt4 & 0xF);
    } else {
      draw3DLine(paramGraphics, paramInt2, paramInt1, paramInt3, paramInt1, paramGraphics.getColor(), paramInt4 & 0xF, (paramInt4 == 24578 || paramInt4 == 24580), (paramInt4 == 24580 || paramInt4 == 40964));
    } 
  }
  
  public static void drawVLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (paramInt4 == 4113) {
      drawDotLine(paramGraphics, paramInt1, paramInt2, paramInt1, paramInt3);
    } else if ((paramInt4 & 0x1000) != 0) {
      paramGraphics.fillRect(paramInt1, paramInt2, paramInt4 & 0xF, paramInt3 - paramInt2);
    } else {
      draw3DLine(paramGraphics, paramInt1, paramInt2, paramInt1, paramInt3, paramGraphics.getColor(), paramInt4 & 0xF, (paramInt4 == 24578 || paramInt4 == 24580), (paramInt4 == 24580 || paramInt4 == 40964));
    } 
  }
  
  public static void draw3DLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, int paramInt5) { draw3DLine(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramColor, paramInt5, true); }
  
  public static void draw3DLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, int paramInt5, boolean paramBoolean) { draw3DLine(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramColor, paramInt5, paramBoolean, false); }
  
  public static void draw3DLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor, int paramInt5, boolean paramBoolean1, boolean paramBoolean2) {
    Color color = paramGraphics.getColor();
    paramGraphics.setColor(paramBoolean1 ? paramColor.brighter() : paramColor.darker());
    for (byte b = 0; b < paramInt5; b++) {
      if ((paramBoolean2 && b == paramInt5 - 1) || (!paramBoolean2 && b == paramInt5 / 2)) {
        paramGraphics.setColor(paramBoolean1 ? paramColor.darker() : paramColor.brighter());
      } else if (paramBoolean2 && b) {
        paramGraphics.setColor(paramColor);
      } 
      paramGraphics.drawLine(paramInt1, paramInt2, paramInt3, paramInt4);
      if (paramInt1 == paramInt3) {
        paramInt1++;
        paramInt3++;
      } else if (paramInt2 == paramInt4) {
        paramInt2++;
        paramInt4++;
      } else if (paramInt1 < paramInt3) {
        paramInt2 += (paramInt4 - paramInt2) / (paramInt3 - paramInt1);
        paramInt3++;
      } else if (paramInt3 > paramInt1) {
        paramInt4 += (paramInt2 - paramInt4) / (paramInt1 - paramInt3);
        paramInt1++;
      } 
    } 
    paramGraphics.setColor(color);
  }
  
  public static void drawDotLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool = true;
    if (paramInt1 != paramInt3) {
      int i = (paramInt3 > paramInt1) ? 1 : -1;
      for (int j = paramInt1; j - i != paramInt3; j += i, bool = !bool ? 1 : 0) {
        if (bool) {
          int k = (int)(paramInt4 - (paramInt3 - j) * (paramInt4 - paramInt2) / (paramInt3 - paramInt1));
          paramGraphics.drawLine(j, k, j, k);
        } 
      } 
    } else {
      int i = (paramInt4 > paramInt2) ? 1 : -1;
      for (int j = paramInt2; j - i != paramInt4; j += i, bool = !bool ? 1 : 0) {
        if (bool)
          paramGraphics.drawLine(paramInt1, j, paramInt3, j); 
      } 
    } 
  }
  
  public static void drawDotRect(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    drawDotLine(paramGraphics, paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2);
    drawDotLine(paramGraphics, paramInt1 + paramInt3, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
    drawDotLine(paramGraphics, paramInt1, paramInt2 + paramInt4, paramInt1 + paramInt3, paramInt2 + paramInt4);
    drawDotLine(paramGraphics, paramInt1, paramInt2, paramInt1, paramInt2 + paramInt4);
  }
  
  public static Frame findFrame(Component paramComponent) {
    for (Component component = paramComponent; component != null; component = component.getParent()) {
      if (component instanceof Frame)
        return (Frame)component; 
    } 
    return null;
  }
  
  public static Window findWindow(Component paramComponent) {
    for (Component component = paramComponent; component != null; component = component.getParent()) {
      if (component instanceof Window)
        return (Window)component; 
    } 
    return null;
  }
  
  public static Applet findApplet(Component paramComponent) {
    for (Component component = paramComponent; component != null; component = component.getParent()) {
      if (component instanceof Applet)
        return (Applet)component; 
    } 
    return null;
  }
  
  public static Container findTopContainer(Component paramComponent) {
    Container container1 = paramComponent.getParent();
    for (Container container2 = container1; container2 != null; container2 = container2.getParent())
      container1 = container2; 
    return container1;
  }
  
  public static Point locationInFrame(Component paramComponent) {
    Point point = paramComponent.getLocation();
    for (Container container = paramComponent.getParent(); !(container instanceof Frame); 
      container = container.getParent())
      point.translate((container.getLocation()).x, (container.getLocation()).y); 
    return point;
  }
  
  public static Point locationInWindow(Component paramComponent) {
    Point point = paramComponent.getLocation();
    for (Container container = paramComponent.getParent(); !(container instanceof Window); 
      container = container.getParent())
      point.translate((container.getLocation()).x, (container.getLocation()).y); 
    return point;
  }
  
  public static Point absLocation(Component paramComponent) {
    Point point1 = findWindow(paramComponent).getLocation();
    Point point2 = locationInWindow(paramComponent);
    return new Point(point1.x + point2.x, point1.y + point2.y);
  }
  
  public static void drawDownArrow(Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean) {
    int[] arrayOfInt1 = { paramInt1 - 4, paramInt1 + 4, paramInt1 };
    int[] arrayOfInt2 = { paramInt2 - 4, paramInt2 - 4, paramInt2 + 4 };
    Color color = paramGraphics.getColor();
    paramGraphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
    paramGraphics.setColor(paramBoolean ? color.brighter() : color.darker());
    paramGraphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[1], arrayOfInt2[1]);
    paramGraphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[2], arrayOfInt2[2]);
    paramGraphics.setColor(paramBoolean ? color.darker() : color.brighter());
    paramGraphics.drawLine(arrayOfInt1[2], arrayOfInt2[2], arrayOfInt1[1], arrayOfInt2[1]);
    paramGraphics.setColor(color);
  }
  
  public static void drawUpArrow(Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean) {
    int[] arrayOfInt1 = { paramInt1 - 4, paramInt1 + 4, paramInt1 };
    int[] arrayOfInt2 = { paramInt2 + 4, paramInt2 + 4, paramInt2 - 4 };
    Color color = paramGraphics.getColor();
    paramGraphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
    paramGraphics.setColor(paramBoolean ? color.brighter() : color.darker());
    paramGraphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[2], arrayOfInt2[2]);
    paramGraphics.setColor(paramBoolean ? color.darker() : color.brighter());
    paramGraphics.drawLine(arrayOfInt1[0], arrayOfInt2[0], arrayOfInt1[1], arrayOfInt2[1]);
    paramGraphics.drawLine(arrayOfInt1[2], arrayOfInt2[2], arrayOfInt1[1], arrayOfInt2[1]);
    paramGraphics.setColor(color);
  }
  
  public static String parseString(String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramString.length(); b++) {
      if (paramString.charAt(b) == '\\') {
        b++;
        if (b < paramString.length())
          if (paramString.charAt(b) == 't') {
            stringBuffer.append("\t");
          } else if (paramString.charAt(b) == 'n') {
            stringBuffer.append("\n");
          } else {
            stringBuffer.append(paramString.charAt(b));
          }  
      } else {
        stringBuffer.append(paramString.charAt(b));
      } 
    } 
    return stringBuffer.toString();
  }
  
  public static String[] tokenize(String paramString1, String paramString2) {
    Vector vector = new Vector();
    try {
      StringTokenizer stringTokenizer = new StringTokenizer(paramString1, paramString2);
      while (stringTokenizer.hasMoreTokens())
        vector.addElement(stringTokenizer.nextToken()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    String[] arrayOfString = new String[vector.size()];
    vector.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public static Object[] toArray(Vector paramVector) {
    Class clazz = (paramVector.size() > 0) ? paramVector.elementAt(0).getClass() : String.class;
    Object[] arrayOfObject = (Object[])Array.newInstance(clazz, paramVector.size());
    paramVector.copyInto(arrayOfObject);
    return arrayOfObject;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widge\\util\Tool.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */