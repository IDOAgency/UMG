package inetsoft.widget.util;

import java.beans.PropertyEditorSupport;

public class PositionEditor extends PropertyEditorSupport {
  public void setAsText(String paramString) {
    if (paramString.equals("LEFT")) {
      setValue(new Integer(1));
    } else if (paramString.equals("TOP")) {
      setValue(new Integer(4));
    } else if (paramString.equals("RIGHT")) {
      setValue(new Integer(3));
    } else if (paramString.equals("BOTTOM")) {
      setValue(new Integer(2));
    } 
  }
  
  public String[] getTags() { return new String[] { "LEFT", "TOP", "RIGHT", "BOTTOM" }; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widge\\util\PositionEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */