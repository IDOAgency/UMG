/*    */ package inetsoft.widget.util;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PositionEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String paramString) {
/* 30 */     if (paramString.equals("LEFT")) {
/* 31 */       setValue(new Integer(1));
/*    */     }
/* 33 */     else if (paramString.equals("TOP")) {
/* 34 */       setValue(new Integer(4));
/*    */     }
/* 36 */     else if (paramString.equals("RIGHT")) {
/* 37 */       setValue(new Integer(3));
/*    */     }
/* 39 */     else if (paramString.equals("BOTTOM")) {
/* 40 */       setValue(new Integer(2));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public String[] getTags() { return new String[] { "LEFT", "TOP", "RIGHT", "BOTTOM" }; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widge\\util\PositionEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */