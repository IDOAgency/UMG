/*     */ package inetsoft.widget.util;
/*     */ 
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.Component;
/*     */ import java.awt.MenuComponent;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.AdjustmentEvent;
/*     */ import java.awt.event.AdjustmentListener;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.TextEvent;
/*     */ import java.awt.event.TextListener;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventMgr
/*     */   implements Serializable
/*     */ {
/*  37 */   public void addComponentListener(ComponentListener paramComponentListener) { this.componentListener = AWTEventMulticaster.add(this.componentListener, paramComponentListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public void addItemListener(ItemListener paramItemListener) { this.itemListener = AWTEventMulticaster.add(this.itemListener, paramItemListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public void addTextListener(TextListener paramTextListener) { this.textListener = AWTEventMulticaster.add(this.textListener, paramTextListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void addAdjustmentListener(AdjustmentListener paramAdjustmentListener) { this.adjustmentListener = AWTEventMulticaster.add(this.adjustmentListener, paramAdjustmentListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void removeItemListener(ItemListener paramItemListener) { this.itemListener = AWTEventMulticaster.remove(this.itemListener, paramItemListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void removeComponentListener(ComponentListener paramComponentListener) { this.componentListener = AWTEventMulticaster.remove(this.componentListener, paramComponentListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void removeTextListener(TextListener paramTextListener) { this.textListener = AWTEventMulticaster.remove(this.textListener, paramTextListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public void removeAdjustmentListener(AdjustmentListener paramAdjustmentListener) { this.adjustmentListener = AWTEventMulticaster.remove(this.adjustmentListener, paramAdjustmentListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void postEvent(AWTEvent paramAWTEvent) {
/* 121 */     if (paramAWTEvent instanceof ItemEvent) {
/* 122 */       if (this.itemListener != null) {
/* 123 */         this.itemListener.itemStateChanged((ItemEvent)paramAWTEvent);
/*     */       }
/*     */     }
/* 126 */     else if (paramAWTEvent instanceof ActionEvent) {
/* 127 */       if (this.actionListener != null) {
/* 128 */         this.actionListener.actionPerformed((ActionEvent)paramAWTEvent);
/*     */       }
/*     */     }
/* 131 */     else if (paramAWTEvent instanceof TextEvent) {
/* 132 */       if (this.textListener != null) {
/* 133 */         this.textListener.textValueChanged((TextEvent)paramAWTEvent);
/*     */       }
/*     */     }
/* 136 */     else if (paramAWTEvent instanceof AdjustmentEvent) {
/* 137 */       if (this.adjustmentListener != null) {
/* 138 */         this.adjustmentListener.adjustmentValueChanged((AdjustmentEvent)paramAWTEvent);
/*     */       }
/*     */     }
/* 141 */     else if (paramAWTEvent instanceof ComponentEvent) {
/* 142 */       if (this.componentListener != null) {
/* 143 */         if (paramAWTEvent.getID() == 101) {
/* 144 */           this.componentListener.componentResized((ComponentEvent)paramAWTEvent);
/*     */         }
/* 146 */         else if (paramAWTEvent.getID() == 100) {
/* 147 */           this.componentListener.componentMoved((ComponentEvent)paramAWTEvent);
/*     */         } 
/*     */       }
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/* 154 */         ((Component)paramAWTEvent.getSource()).dispatchEvent(paramAWTEvent);
/*     */       } catch (ClassCastException classCastException) {
/* 156 */         ((MenuComponent)paramAWTEvent.getSource()).dispatchEvent(paramAWTEvent);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException { paramObjectInputStream.defaultReadObject(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   static Thread dispatcher = null;
/* 171 */   private ComponentListener componentListener = null;
/* 172 */   private ItemListener itemListener = null;
/* 173 */   private ActionListener actionListener = null;
/* 174 */   private TextListener textListener = null;
/* 175 */   private AdjustmentListener adjustmentListener = null;
/*     */   private static boolean limited = false;
/*     */   
/*     */   static  {
/* 179 */     if (limited) {
/* 180 */       EvalWin evalWin = new EvalWin();
/* 181 */       evalWin.pack();
/* 182 */       evalWin.setVisible(true);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widge\\util\EventMgr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */