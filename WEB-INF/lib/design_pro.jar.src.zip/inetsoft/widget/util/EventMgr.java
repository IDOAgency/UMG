package inetsoft.widget.util;

import java.awt.AWTEvent;
import java.awt.AWTEventMulticaster;
import java.awt.Component;
import java.awt.MenuComponent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class EventMgr implements Serializable {
  public void addComponentListener(ComponentListener paramComponentListener) { this.componentListener = AWTEventMulticaster.add(this.componentListener, paramComponentListener); }
  
  public void addItemListener(ItemListener paramItemListener) { this.itemListener = AWTEventMulticaster.add(this.itemListener, paramItemListener); }
  
  public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
  
  public void addTextListener(TextListener paramTextListener) { this.textListener = AWTEventMulticaster.add(this.textListener, paramTextListener); }
  
  public void addAdjustmentListener(AdjustmentListener paramAdjustmentListener) { this.adjustmentListener = AWTEventMulticaster.add(this.adjustmentListener, paramAdjustmentListener); }
  
  public void removeItemListener(ItemListener paramItemListener) { this.itemListener = AWTEventMulticaster.remove(this.itemListener, paramItemListener); }
  
  public void removeComponentListener(ComponentListener paramComponentListener) { this.componentListener = AWTEventMulticaster.remove(this.componentListener, paramComponentListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
  
  public void removeTextListener(TextListener paramTextListener) { this.textListener = AWTEventMulticaster.remove(this.textListener, paramTextListener); }
  
  public void removeAdjustmentListener(AdjustmentListener paramAdjustmentListener) { this.adjustmentListener = AWTEventMulticaster.remove(this.adjustmentListener, paramAdjustmentListener); }
  
  public void postEvent(AWTEvent paramAWTEvent) {
    if (paramAWTEvent instanceof ItemEvent) {
      if (this.itemListener != null)
        this.itemListener.itemStateChanged((ItemEvent)paramAWTEvent); 
    } else if (paramAWTEvent instanceof ActionEvent) {
      if (this.actionListener != null)
        this.actionListener.actionPerformed((ActionEvent)paramAWTEvent); 
    } else if (paramAWTEvent instanceof TextEvent) {
      if (this.textListener != null)
        this.textListener.textValueChanged((TextEvent)paramAWTEvent); 
    } else if (paramAWTEvent instanceof AdjustmentEvent) {
      if (this.adjustmentListener != null)
        this.adjustmentListener.adjustmentValueChanged((AdjustmentEvent)paramAWTEvent); 
    } else if (paramAWTEvent instanceof ComponentEvent) {
      if (this.componentListener != null)
        if (paramAWTEvent.getID() == 101) {
          this.componentListener.componentResized((ComponentEvent)paramAWTEvent);
        } else if (paramAWTEvent.getID() == 100) {
          this.componentListener.componentMoved((ComponentEvent)paramAWTEvent);
        }  
    } else {
      try {
        ((Component)paramAWTEvent.getSource()).dispatchEvent(paramAWTEvent);
      } catch (ClassCastException classCastException) {
        ((MenuComponent)paramAWTEvent.getSource()).dispatchEvent(paramAWTEvent);
      } 
    } 
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException { paramObjectInputStream.defaultReadObject(); }
  
  static Thread dispatcher = null;
  
  private ComponentListener componentListener = null;
  
  private ItemListener itemListener = null;
  
  private ActionListener actionListener = null;
  
  private TextListener textListener = null;
  
  private AdjustmentListener adjustmentListener = null;
  
  private static boolean limited = false;
  
  static  {
    if (limited) {
      EvalWin evalWin = new EvalWin();
      evalWin.pack();
      evalWin.setVisible(true);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widge\\util\EventMgr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */