package inetsoft.widget.util;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

class EvalWin extends JDialog {
  static final String msg = "This is an evaluation copy of the Tea Set Widgets. Please go to\nour Web site for most up-to-date product information and release\nannouncement. Once you finish the evaluation, you can purchase\nthe Professional version from our Web site.\n\nWe welcome any suggestions or comments. If you find any feature\nmissing from the product, please contact us at support@inetsoftcorp.com\nand we will take that into account in future product planning.\n\nThank you for choosing the Tea Set Widgets!";
  
  public EvalWin() {
    setModal(true);
    getContentPane().setLayout(new BorderLayout(10, 10));
    getContentPane().setBackground(Color.white);
    setDefaultCloseOperation(0);
    ImageIcon imageIcon = new ImageIcon(EvalWin.class.getResource("/inetsoft/widget/util/logo.gif"));
    JLabel jLabel = new JLabel("Tea Set Widgets", imageIcon, 2);
    jLabel.setOpaque(true);
    jLabel.setBackground(Color.white);
    jLabel.setFont(new Font("Serif", 3, 24));
    getContentPane().add(jLabel, "North");
    JTextArea jTextArea = new JTextArea("This is an evaluation copy of the Tea Set Widgets. Please go to\nour Web site for most up-to-date product information and release\nannouncement. Once you finish the evaluation, you can purchase\nthe Professional version from our Web site.\n\nWe welcome any suggestions or comments. If you find any feature\nmissing from the product, please contact us at support@inetsoftcorp.com\nand we will take that into account in future product planning.\n\nThank you for choosing the Tea Set Widgets!");
    jTextArea.setBackground(Color.white);
    jTextArea.setEditable(false);
    getContentPane().add(jTextArea, "Center");
    JPanel jPanel = new JPanel();
    JButton jButton = new JButton("Close");
    jPanel.add(jButton);
    getContentPane().add(jPanel, "South");
    jButton.addActionListener(new ActionListener(this) {
          private final EvalWin this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            try {
              Thread.sleep(800L);
            } catch (Exception exception) {}
            this.this$0.dispose();
          }
        });
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widge\\util\EvalWin.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */