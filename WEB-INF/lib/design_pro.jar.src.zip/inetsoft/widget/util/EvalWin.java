/*    */ package inetsoft.widget.util;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextArea;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EvalWin
/*    */   extends JDialog
/*    */ {
/*    */   static final String msg = "This is an evaluation copy of the Tea Set Widgets. Please go to\nour Web site for most up-to-date product information and release\nannouncement. Once you finish the evaluation, you can purchase\nthe Professional version from our Web site.\n\nWe welcome any suggestions or comments. If you find any feature\nmissing from the product, please contact us at support@inetsoftcorp.com\nand we will take that into account in future product planning.\n\nThank you for choosing the Tea Set Widgets!";
/*    */   
/*    */   public EvalWin() {
/* 26 */     setModal(true);
/* 27 */     getContentPane().setLayout(new BorderLayout(10, 10));
/* 28 */     getContentPane().setBackground(Color.white);
/* 29 */     setDefaultCloseOperation(0);
/*    */     
/* 31 */     ImageIcon imageIcon = new ImageIcon(EvalWin.class.getResource("/inetsoft/widget/util/logo.gif"));
/*    */ 
/*    */ 
/*    */     
/* 35 */     JLabel jLabel = new JLabel("Tea Set Widgets", imageIcon, 2);
/* 36 */     jLabel.setOpaque(true);
/* 37 */     jLabel.setBackground(Color.white);
/* 38 */     jLabel.setFont(new Font("Serif", 3, 24));
/* 39 */     getContentPane().add(jLabel, "North");
/*    */     
/* 41 */     JTextArea jTextArea = new JTextArea("This is an evaluation copy of the Tea Set Widgets. Please go to\nour Web site for most up-to-date product information and release\nannouncement. Once you finish the evaluation, you can purchase\nthe Professional version from our Web site.\n\nWe welcome any suggestions or comments. If you find any feature\nmissing from the product, please contact us at support@inetsoftcorp.com\nand we will take that into account in future product planning.\n\nThank you for choosing the Tea Set Widgets!");
/* 42 */     jTextArea.setBackground(Color.white);
/* 43 */     jTextArea.setEditable(false);
/* 44 */     getContentPane().add(jTextArea, "Center");
/*    */     
/* 46 */     JPanel jPanel = new JPanel();
/* 47 */     JButton jButton = new JButton("Close");
/* 48 */     jPanel.add(jButton);
/* 49 */     getContentPane().add(jPanel, "South");
/*    */     
/* 51 */     jButton.addActionListener(new ActionListener(this) { public void actionPerformed(ActionEvent param1ActionEvent) {
/*    */             
/* 53 */             try { Thread.sleep(800L); } catch (Exception exception) {}
/* 54 */             this.this$0.dispose();
/*    */           }
/*    */           
/*    */           private final EvalWin this$0; }
/*    */       );
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widge\\util\EvalWin.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */