/*     */ package inetsoft.widget;
/*     */ 
/*     */ import inetsoft.widget.util.EventMgr;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.TextEvent;
/*     */ import java.awt.event.TextListener;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.TimeZone;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeSpinner
/*     */   extends Spinner
/*     */ {
/*     */   protected EventMgr eventMgr;
/*     */   Runnable checktext;
/*     */   Calendar cal;
/*     */   int inc;
/*     */   
/*     */   public TimeSpinner() {
/*  92 */     super(new String[0]);
/*     */     setEditable(true);
/*     */     this.up.setEnabled(true);
/*     */     this.down.setEnabled(true);
/*     */     getField().addActionListener(new ActionListener(this)
/*     */         {
/*     */           private final TimeSpinner this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.eventMgr.postEvent(new ActionEvent(this, param1ActionEvent.getID(), this.this$0.getText())); }
/*     */         });
/*     */     getField().addMouseListener(new MouseAdapter(this)
/*     */         {
/*     */           private final TimeSpinner this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void mouseReleased(MouseEvent param1MouseEvent) { this.this$0.checkCaret(); }
/*     */         });
/*     */     getField().addKeyListener(new KeyAdapter(this)
/*     */         {
/*     */           private final TimeSpinner this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void keyPressed(KeyEvent param1KeyEvent) {
/*     */             if (param1KeyEvent.getKeyCode() == 38) {
/*     */               this.this$0.scrollUp();
/*     */             } else if (param1KeyEvent.getKeyCode() == 40) {
/*     */               this.this$0.scrollDown();
/*     */             } 
/*     */           }
/*     */         });
/*     */     getField().getDocument().addDocumentListener(new DocumentListener(this)
/*     */         {
/*     */           private final TimeSpinner this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void insertUpdate(DocumentEvent param1DocumentEvent) { changedUpdate(param1DocumentEvent); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void removeUpdate(DocumentEvent param1DocumentEvent) { changedUpdate(param1DocumentEvent); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void changedUpdate(DocumentEvent param1DocumentEvent) { SwingUtilities.invokeLater(this.this$0.checktext); }
/*     */         });
/* 295 */     this.eventMgr = new EventMgr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     this.checktext = new Runnable(this) { String otext;
/*     */         private final TimeSpinner this$0;
/*     */         
/*     */         public void run() {
/* 332 */           String str1 = this.this$0.getText();
/* 333 */           if (str1.length() == 0 || str1.equals(this.otext)) {
/*     */             return;
/*     */           }
/* 336 */           this.otext = str1;
/*     */           
/* 338 */           JTextField jTextField = this.this$0.getField();
/* 339 */           int i = jTextField.getCaretPosition();
/* 340 */           i = (i > 10) ? 10 : i;
/*     */           
/* 342 */           if (str1.length() != 10) {
/*     */             
/* 344 */             if (str1.length() == 9) {
/*     */               try {
/* 346 */                 jTextField.getDocument().insertString(i, " ", null);
/*     */               } catch (Exception exception) {
/* 348 */                 exception.printStackTrace();
/*     */               }
/*     */             
/*     */             }
/* 352 */             else if (str1.length() == 11) {
/*     */               try {
/* 354 */                 jTextField.getDocument().remove(i, 1);
/*     */               } catch (Exception exception) {
/* 356 */                 exception.printStackTrace();
/*     */               } 
/*     */             } 
/*     */             
/* 360 */             jTextField.setCaretPosition(i);
/* 361 */             str1 = this.this$0.getText();
/*     */           } 
/*     */           
/* 364 */           String str2 = str1.substring(8).toUpperCase();
/* 365 */           if (!str2.startsWith("AM") && !str2.startsWith("PM")) {
/* 366 */             str2 = str2.startsWith("A") ? "AM" : "PM";
/*     */             
/*     */             try {
/* 369 */               jTextField.getDocument().remove(8, 2);
/* 370 */               jTextField.getDocument().insertString(8, str2, null);
/*     */             } catch (Exception exception) {
/* 372 */               exception.printStackTrace();
/*     */             } 
/*     */           } 
/*     */           
/*     */           try {
/* 377 */             if (str1.length() != 10 || str1.charAt(2) != ':' || str1.charAt(5) != ':')
/*     */             {
/* 379 */               throw new NumberFormatException("AM_PM");
/*     */             }
/*     */             
/* 382 */             int j = Integer.parseInt("0" + str1.substring(0, 2).trim());
/* 383 */             int k = Integer.parseInt("0" + str1.substring(3, 5).trim());
/* 384 */             int m = Integer.parseInt("0" + str1.substring(6, 8).trim());
/*     */             
/* 386 */             Date date = this.this$0.cal.getTime();
/*     */             
/* 388 */             this.this$0.cal.set(10, j);
/* 389 */             this.this$0.cal.set(12, k);
/* 390 */             this.this$0.cal.set(13, m);
/* 391 */             this.this$0.cal.set(9, str2.startsWith("A") ? 0 : 1);
/*     */ 
/*     */             
/* 394 */             if (!this.this$0.cal.getTime().equals(date)) {
/* 395 */               this.this$0.eventMgr.postEvent(new TextEvent(this, 900));
/*     */             }
/*     */           } catch (NumberFormatException numberFormatException) {
/*     */             
/* 399 */             this.this$0.setText(TimeSpinner.format(this.this$0.cal));
/* 400 */             this.this$0.getField().setCaretPosition(i);
/*     */           } 
/*     */         } }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 423 */     this.cal = new GregorianCalendar();
/* 424 */     this.cal.setTimeZone(TimeZone.getDefault());
/* 425 */     this.inc = 0; setDate(this.cal.getTime()); setColumns(getText().length()); } public TimeSpinner(Date paramDate) { super(new String[0]); setEditable(true); this.up.setEnabled(true); this.down.setEnabled(true); getField().addActionListener(new ActionListener(this) { private final TimeSpinner this$0; public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.eventMgr.postEvent(new ActionEvent(this, param1ActionEvent.getID(), this.this$0.getText())); } }); getField().addMouseListener(new MouseAdapter(this) { private final TimeSpinner this$0; public void mouseReleased(MouseEvent param1MouseEvent) { this.this$0.checkCaret(); } }); getField().addKeyListener(new KeyAdapter(this) { private final TimeSpinner this$0; public void keyPressed(KeyEvent param1KeyEvent) { if (param1KeyEvent.getKeyCode() == 38) { this.this$0.scrollUp(); } else if (param1KeyEvent.getKeyCode() == 40) { this.this$0.scrollDown(); }  } }); getField().getDocument().addDocumentListener(new DocumentListener(this) { private final TimeSpinner this$0; public void insertUpdate(DocumentEvent param1DocumentEvent) { changedUpdate(param1DocumentEvent); } public void removeUpdate(DocumentEvent param1DocumentEvent) { changedUpdate(param1DocumentEvent); } public void changedUpdate(DocumentEvent param1DocumentEvent) { SwingUtilities.invokeLater(this.this$0.checktext); } }); this.eventMgr = new EventMgr(); this.checktext = new Runnable(this) { String otext; private final TimeSpinner this$0; public void run() { String str1 = this.this$0.getText(); if (str1.length() == 0 || str1.equals(this.otext)) return;  this.otext = str1; JTextField jTextField = this.this$0.getField(); int i = jTextField.getCaretPosition(); i = (i > 10) ? 10 : i; if (str1.length() != 10) { if (str1.length() == 9) { try { jTextField.getDocument().insertString(i, " ", null); } catch (Exception exception) { exception.printStackTrace(); }  } else if (str1.length() == 11) { try { jTextField.getDocument().remove(i, 1); } catch (Exception exception) { exception.printStackTrace(); }  }  jTextField.setCaretPosition(i); str1 = this.this$0.getText(); }  String str2 = str1.substring(8).toUpperCase(); if (!str2.startsWith("AM") && !str2.startsWith("PM")) { str2 = str2.startsWith("A") ? "AM" : "PM"; try { jTextField.getDocument().remove(8, 2); jTextField.getDocument().insertString(8, str2, null); } catch (Exception exception) { exception.printStackTrace(); }  }  try { if (str1.length() != 10 || str1.charAt(2) != ':' || str1.charAt(5) != ':') throw new NumberFormatException("AM_PM");  int j = Integer.parseInt("0" + str1.substring(0, 2).trim()); int k = Integer.parseInt("0" + str1.substring(3, 5).trim()); int m = Integer.parseInt("0" + str1.substring(6, 8).trim()); Date date = this.this$0.cal.getTime(); this.this$0.cal.set(10, j); this.this$0.cal.set(12, k); this.this$0.cal.set(13, m); this.this$0.cal.set(9, str2.startsWith("A") ? 0 : 1); if (!this.this$0.cal.getTime().equals(date)) this.this$0.eventMgr.postEvent(new TextEvent(this, 900));  } catch (NumberFormatException numberFormatException) { this.this$0.setText(TimeSpinner.format(this.this$0.cal)); this.this$0.getField().setCaretPosition(i); }  } }; this.cal = new GregorianCalendar(); this.cal.setTimeZone(TimeZone.getDefault()); this.inc = 0;
/*     */     setDate(paramDate);
/*     */     setColumns(getText().length()); }
/*     */ 
/*     */   
/*     */   public void setDate(Date paramDate) {
/*     */     this.cal.setTime((paramDate == null) ? new Date() : paramDate);
/*     */     int i = getField().getCaretPosition();
/*     */     int j = getSelectionStart(), k = getSelectionEnd();
/*     */     setText(format(this.cal));
/*     */     getField().setCaretPosition(i);
/*     */     select(j, k);
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public Date getDate() { return this.cal.getTime(); }
/*     */   
/*     */   public Date getTimeOfDay() {
/*     */     Calendar calendar = (Calendar)this.cal.clone();
/*     */     calendar.set(1970, 0, 1);
/*     */     calendar.set(14, 0);
/*     */     return calendar.getTime();
/*     */   }
/*     */   
/*     */   public int getHour() { return this.cal.get(10); }
/*     */   
/*     */   public int getHourOfDay() { return this.cal.get(11); }
/*     */   
/*     */   public int getMinute() { return this.cal.get(12); }
/*     */   
/*     */   public int getSecond() { return this.cal.get(13); }
/*     */   
/*     */   public int getAmPm() { return this.cal.get(9); }
/*     */   
/*     */   public void setHour(int paramInt) {
/*     */     this.cal.set(10, paramInt);
/*     */     setDate(this.cal.getTime());
/*     */   }
/*     */   
/*     */   public void setHourOfDay(int paramInt) {
/*     */     this.cal.set(11, paramInt);
/*     */     setDate(this.cal.getTime());
/*     */   }
/*     */   
/*     */   public void setMinute(int paramInt) {
/*     */     this.cal.set(12, paramInt);
/*     */     setDate(this.cal.getTime());
/*     */   }
/*     */   
/*     */   public void setSecond(int paramInt) {
/*     */     this.cal.set(13, paramInt);
/*     */     setDate(this.cal.getTime());
/*     */   }
/*     */   
/*     */   public void setAmPm(int paramInt) {
/*     */     this.cal.set(9, paramInt);
/*     */     setDate(this.cal.getTime());
/*     */   }
/*     */   
/*     */   public void setTime(int paramInt1, int paramInt2, int paramInt3) {
/*     */     this.cal.set(11, paramInt1);
/*     */     this.cal.set(12, paramInt2);
/*     */     this.cal.set(13, paramInt3);
/*     */     setDate(this.cal.getTime());
/*     */   }
/*     */   
/*     */   private void checkCaret() {
/*     */     int i = getField().getCaretPosition();
/*     */     if (i <= 2) {
/*     */       getField().setCaretPosition(0);
/*     */       select(0, 2);
/*     */       this.inc = 3600000;
/*     */     } else if (i <= 5) {
/*     */       getField().setCaretPosition(3);
/*     */       select(3, 5);
/*     */       this.inc = 60000;
/*     */     } else if (i <= 8) {
/*     */       getField().setCaretPosition(6);
/*     */       select(6, 8);
/*     */       this.inc = 1000;
/*     */     } else {
/*     */       getField().setCaretPosition(8);
/*     */       select(8, 10);
/*     */       this.inc = 43200000;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void scrollUp() {
/*     */     setDate(new Date(getDate().getTime() + this.inc));
/*     */     this.eventMgr.postEvent(new TextEvent(this, 900));
/*     */   }
/*     */   
/*     */   protected void scrollDown() {
/*     */     setDate(new Date(getDate().getTime() - this.inc));
/*     */     this.eventMgr.postEvent(new TextEvent(this, 900));
/*     */   }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
/*     */   
/*     */   public void addTextListener(TextListener paramTextListener) { this.eventMgr.addTextListener(paramTextListener); }
/*     */   
/*     */   public void removeTextListener(TextListener paramTextListener) { this.eventMgr.removeTextListener(paramTextListener); }
/*     */   
/*     */   static String format(Calendar paramCalendar) {
/*     */     int i = paramCalendar.get(10);
/*     */     int j = paramCalendar.get(12);
/*     */     int k = paramCalendar.get(13);
/*     */     boolean bool = (paramCalendar.get(9) == 1) ? 1 : 0;
/*     */     i = (bool && i == 0) ? 12 : i;
/*     */     return ((i > 9) ? Integer.toString(i) : ("0" + i)) + ":" + ((j > 9) ? Integer.toString(j) : ("0" + j)) + ":" + ((k > 9) ? Integer.toString(k) : ("0" + k)) + (bool ? "PM" : "AM");
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\TimeSpinner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */