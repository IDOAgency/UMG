package inetsoft.widget;

import inetsoft.beans.AutoBeanInfo;
import java.awt.Image;
import java.beans.PropertyEditorSupport;

public class SCalendarBeanInfo extends AutoBeanInfo {
  public SCalendarBeanInfo() {
    super(SCalendar.class);
    registerEditor("title", Editor.class);
  }
  
  public Image getIcon(int paramInt) {
    Image image;
    switch (paramInt) {
      case 1:
      case 3:
        image = loadImage("beans/SCalendarBean.gif");
        return image.getScaledInstance(16, 16, 4);
      case 2:
      case 4:
        image = loadImage("beans/SCalendarBean32.gif");
        return image.getScaledInstance(32, 32, 4);
    } 
    return null;
  }
  
  public static class Editor extends PropertyEditorSupport {
    public void setAsText(String param1String) {
      if (param1String.equals("NO_TITLE")) {
        setValue(new Integer(0));
      } else if (param1String.equals("WEEK")) {
        setValue(new Integer(1));
      } else if (param1String.equals("MONTH_WEEK")) {
        setValue(new Integer(2));
      } else if (param1String.equals("ALL")) {
        setValue(new Integer(3));
      } 
    }
    
    public String[] getTags() { return new String[] { "NO_TITLE", "WEEK", "MONTH_WEEK", "ALL" }; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\SCalendarBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */