/*    */ package inetsoft.widget;
/*    */ 
/*    */ import inetsoft.beans.AutoBeanInfo;
/*    */ import java.awt.Image;
/*    */ import java.beans.PropertyEditorSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SCalendarBeanInfo
/*    */   extends AutoBeanInfo
/*    */ {
/*    */   public SCalendarBeanInfo() {
/* 28 */     super(SCalendar.class);
/* 29 */     registerEditor("title", Editor.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Image getIcon(int paramInt) {
/*    */     Image image;
/* 35 */     switch (paramInt) {
/*    */       case 1:
/*    */       case 3:
/* 38 */         image = loadImage("beans/SCalendarBean.gif");
/* 39 */         return image.getScaledInstance(16, 16, 4);
/*    */       case 2:
/*    */       case 4:
/* 42 */         image = loadImage("beans/SCalendarBean32.gif");
/* 43 */         return image.getScaledInstance(32, 32, 4);
/*    */     } 
/* 45 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static class Editor
/*    */     extends PropertyEditorSupport
/*    */   {
/*    */     public void setAsText(String param1String) {
/* 53 */       if (param1String.equals("NO_TITLE")) {
/* 54 */         setValue(new Integer(0));
/*    */       }
/* 56 */       else if (param1String.equals("WEEK")) {
/* 57 */         setValue(new Integer(1));
/*    */       }
/* 59 */       else if (param1String.equals("MONTH_WEEK")) {
/* 60 */         setValue(new Integer(2));
/*    */       }
/* 62 */       else if (param1String.equals("ALL")) {
/* 63 */         setValue(new Integer(3));
/*    */       } 
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 71 */     public String[] getTags() { return new String[] { "NO_TITLE", "WEEK", "MONTH_WEEK", "ALL" }; }
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\SCalendarBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */