package inetsoft.widget;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPopupMenu;

public class MenuButton extends JButton {
  ImageIcon arrow;
  
  Rectangle arrowBox;
  
  boolean inTrigger;
  
  JPopupMenu menu;
  
  public MenuButton() {
    this.arrowBox = new Rectangle();
    this.inTrigger = false;
    this.menu = null;
    init();
  }
  
  public MenuButton(Icon paramIcon) {
    super(paramIcon);
    this.arrowBox = new Rectangle();
    this.inTrigger = false;
    this.menu = null;
    init();
  }
  
  public MenuButton(String paramString) {
    super(paramString);
    this.arrowBox = new Rectangle();
    this.inTrigger = false;
    this.menu = null;
    init();
  }
  
  public MenuButton(String paramString, Icon paramIcon) {
    super(paramString, paramIcon);
    this.arrowBox = new Rectangle();
    this.inTrigger = false;
    this.menu = null;
    init();
  }
  
  private void init() {
    this.arrow = new ImageIcon(getClass().getResource("/inetsoft/widget/images/menutrigger.gif"));
    this.arrowBox.width = this.arrow.getIconWidth();
    this.arrowBox.height = this.arrow.getIconHeight();
    enableEvents(16L);
  }
  
  public JPopupMenu getMenu() { return this.menu; }
  
  public void setMenu(JPopupMenu paramJPopupMenu) { this.menu = paramJPopupMenu; }
  
  public void paint(Graphics paramGraphics) {
    super.paint(paramGraphics);
    Dimension dimension = getSize();
    Insets insets = (getIcon() != null && getText() == null) ? getInsets() : new Insets(2, 2, 2, 2);
    this.arrowBox.x = dimension.width - insets.right - this.arrowBox.width;
    this.arrowBox.y = dimension.height - insets.bottom - this.arrowBox.height;
    this.arrow.paintIcon(this, paramGraphics, this.arrowBox.x, this.arrowBox.y);
  }
  
  protected void fireActionPerformed(ActionEvent paramActionEvent) {
    if (!this.inTrigger)
      super.fireActionPerformed(paramActionEvent); 
  }
  
  protected void processMouseEvent(MouseEvent paramMouseEvent) {
    if (paramMouseEvent.getID() == 501)
      this.inTrigger = this.arrowBox.contains(paramMouseEvent.getX(), paramMouseEvent.getY()); 
    super.processMouseEvent(paramMouseEvent);
    if (paramMouseEvent.getID() == 502 && this.inTrigger && this.menu != null) {
      this.inTrigger = false;
      this.menu.show(this, this.arrowBox.x, this.arrowBox.y + this.arrowBox.height);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\MenuButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */