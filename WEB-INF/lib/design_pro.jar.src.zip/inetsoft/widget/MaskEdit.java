package inetsoft.widget;

import inetsoft.widget.util.EventMgr;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.util.Date;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class MaskEdit extends JComponent implements ClipboardOwner {
  protected EventMgr eventMgr;
  
  private boolean newSel;
  
  private Date oTime;
  
  private Mask mask;
  
  int startPos;
  
  int endPos;
  
  boolean editable;
  
  boolean focus;
  
  FontMetrics fm;
  
  int curPos;
  
  StringBuffer text;
  
  String disptext;
  
  int sIdx;
  
  int cwidth;
  
  Dimension minSize;
  
  String template;
  
  int border;
  
  public MaskEdit() {
    enableEvents(60L);
    this.eventMgr = new EventMgr();
    this.newSel = true;
    this.oTime = new Date();
    this.startPos = -1;
    this.endPos = -1;
    this.editable = true;
    this.focus = false;
    this.text = new StringBuffer("");
    this.disptext = "";
    this.sIdx = 0;
    this.minSize = null;
    this.template = null;
    this.border = 1;
    setForeground(UIManager.getColor("TextField.foreground"));
    setBackground(UIManager.getColor("TextField.background"));
  }
  
  public MaskEdit(int paramInt) {
    this();
    setColumns(paramInt);
    StringBuffer stringBuffer = new StringBuffer("[");
    for (byte b = 0; b < paramInt; b++)
      stringBuffer.append("X"); 
    stringBuffer.append("]");
    setMask(stringBuffer.toString());
  }
  
  public MaskEdit(String paramString) {
    this();
    setMask(paramString);
    setColumns(this.mask.length());
  }
  
  public void setMask(String paramString) {
    this.mask = new Mask(this, paramString);
    this.template = this.mask.toString('_');
    setText(this.mask.toString(' '));
    setCaretPos(this.mask.nextPos(0, true));
    repaint();
  }
  
  public String getMask() { return this.mask.getMask(); }
  
  public boolean isEditable() { return this.editable; }
  
  public void setEditable(boolean paramBoolean) {
    if (this.editable != paramBoolean) {
      this.editable = paramBoolean;
      repaint();
    } 
  }
  
  public void setText(String paramString) {
    this.text = new StringBuffer(paramString);
    this.sIdx = 0;
    this.curPos = (this.curPos > this.text.length()) ? this.text.length() : this.curPos;
    clearSelection();
    if (this.mask != null)
      setCaretPos(this.mask.nextPos(0, true)); 
    repaint();
  }
  
  public String getText() { return this.text.toString(); }
  
  protected String getDisplayText(String paramString) {
    StringBuffer stringBuffer = new StringBuffer(paramString);
    String str = this.template;
    if (str != null && str.length() == stringBuffer.length())
      for (byte b = 0; b < str.length(); b++) {
        if (str.charAt(b) == '_' && stringBuffer.charAt(b) == ' ')
          stringBuffer.setCharAt(b, '_'); 
      }  
    return stringBuffer.toString();
  }
  
  public Dimension getMinimumSize() {
    if (this.minSize == null)
      setSize(); 
    return (this.minSize == null) ? new Dimension(0, 0) : this.minSize;
  }
  
  public Dimension getPreferredSize() { return getMinimumSize(); }
  
  public String getSelectedText() { return (getSelectionStart() >= 0) ? getText().substring(getSelectionStart(), getSelectionEnd()) : ""; }
  
  public int getSelectionStart() { return Math.min(this.startPos, this.endPos); }
  
  public int getSelectionEnd() { return Math.max(this.startPos, this.endPos); }
  
  public void select(int paramInt1, int paramInt2) {
    this.startPos = paramInt1;
    this.endPos = paramInt2;
    repaint();
  }
  
  public void selectAll() {
    this.startPos = 0;
    this.endPos = this.text.length();
    repaint();
  }
  
  public void clearSelection() { this.startPos = this.endPos = -1; }
  
  public int getColumns() { return this.cwidth; }
  
  public void setColumns(int paramInt) { this.cwidth = paramInt; }
  
  public void append(String paramString) {
    this.text.append(paramString);
    repaint();
  }
  
  public void insert(int paramInt, String paramString) {
    this.text.insert(paramInt, paramString);
    repaint();
  }
  
  public void setCaretPos(int paramInt) {
    this.curPos = paramInt;
    repaint();
  }
  
  public int getCaretPos() { return this.curPos; }
  
  public void remove(int paramInt1, int paramInt2) {
    if (paramInt1 >= this.text.toString().length())
      return; 
    String str = this.text.toString().substring(paramInt2);
    this.text.setLength(paramInt1);
    this.text.append(str);
    if (this.sIdx >= paramInt2) {
      this.sIdx -= paramInt2 - paramInt1;
    } else if (this.sIdx > paramInt1 && this.sIdx < paramInt2) {
      this.sIdx = paramInt1;
    } 
    if (this.sIdx + this.curPos > this.text.length())
      this.curPos = this.text.length() - this.sIdx; 
    repaint();
  }
  
  public void removeSelectedText() {
    if (this.startPos >= 0 && this.endPos >= 0) {
      int i = getSelectionStart();
      int j = getSelectionEnd();
      this.curPos = Math.max(i - this.sIdx, 0);
      remove(i, j);
      clearSelection();
    } 
  }
  
  public void replace(int paramInt, String paramString) {
    for (int i = 0; i < paramString.length(); i++)
      this.text.setCharAt(i + paramInt, paramString.charAt(i)); 
    repaint();
  }
  
  public void setBorder(boolean paramBoolean) {
    this.border = paramBoolean ? 1 : 0;
    repaint();
  }
  
  public boolean isBorder() { return (this.border > 0); }
  
  public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
  
  public void addTextListener(TextListener paramTextListener) { this.eventMgr.addTextListener(paramTextListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
  
  public void removeTextListener(TextListener paramTextListener) { this.eventMgr.removeTextListener(paramTextListener); }
  
  public void lostOwnership(Clipboard paramClipboard, Transferable paramTransferable) {}
  
  protected void paintComponent(Graphics paramGraphics) {
    if (this.fm == null)
      setSize(); 
    Color color1 = getForeground();
    Color color2 = getBackground();
    String str = (this.disptext = getDisplayText(this.text.toString())).substring(this.sIdx);
    Dimension dimension = getSize();
    paramGraphics.setColor(color2);
    paramGraphics.fillRect(0, 0, dimension.width, dimension.height);
    paramGraphics.setColor(isEnabled() ? color1 : color2.darker());
    int i = (dimension.height - this.fm.getHeight()) / 2 + this.fm.getMaxAscent();
    paramGraphics.drawString(str, this.border, i);
    if (this.startPos >= 0 && this.endPos >= 0) {
      int j = Math.min(this.startPos, this.endPos);
      int k = Math.max(this.startPos, this.endPos);
      j = (j < this.sIdx) ? 0 : (j - this.sIdx);
      k = (k < this.sIdx) ? 0 : (k - this.sIdx);
      String str1 = str.substring(j, k);
      int m = nthCharX(j);
      paramGraphics.fillRect(m, i - this.fm.getMaxAscent(), this.fm.stringWidth(str1), this.fm.getHeight());
      paramGraphics.setColor(color2);
      paramGraphics.drawString(str1, m, i);
      paramGraphics.setColor(color1);
    } 
    if (this.focus && isEnabled())
      paintCaret(paramGraphics); 
    if (this.border > 0) {
      paramGraphics.setColor(Color.lightGray);
      paramGraphics.draw3DRect(0, 0, dimension.width - 1, dimension.height - 1, false);
    } 
  }
  
  public void processKeyEvent(KeyEvent paramKeyEvent) {
    if (!this.editable)
      return; 
    boolean bool1 = false;
    boolean bool2 = false;
    String str = getText();
    int i = getCaretPos();
    if (paramKeyEvent.getID() == 401) {
      Font font;
      if (paramKeyEvent.getKeyChar() == '\b' && paramKeyEvent.getKeyCode() != 8)
        return; 
      if ((paramKeyEvent.getModifiers() & 0x2) != 0 && paramKeyEvent.getKeyChar() == '\003') {
        Clipboard clipboard = getToolkit().getSystemClipboard();
        clipboard.setContents(new StringSelection(getSelectedText()), this);
      } 
      switch (paramKeyEvent.getKeyCode()) {
        case 8:
        case 127:
          if (getSelectionStart() >= 0) {
            setCaretPos(getSelectionStart());
            removeSelectedText();
          } else if (paramKeyEvent.getKeyCode() == 8) {
            if (this.curPos > 0) {
              int m = this.curPos;
              remove(this.sIdx + this.curPos - 1, this.sIdx + this.curPos);
              if (m == this.curPos)
                this.curPos--; 
            } else if (this.sIdx > 0) {
              this.sIdx--;
              remove(this.sIdx, this.sIdx + 1);
            } 
          } else if (this.curPos < this.text.length()) {
            remove(this.sIdx + this.curPos, this.sIdx + this.curPos + 1);
          } 
          bool1 = true;
          break;
        case 37:
          if (this.curPos > 0) {
            this.curPos--;
          } else if (this.sIdx > 0) {
            this.sIdx--;
          } 
          bool2 = true;
          break;
        case 36:
          this.sIdx = this.curPos = 0;
          bool2 = true;
          break;
        case 35:
          this.curPos = this.text.length();
        case 39:
          if (this.curPos < this.text.length())
            this.curPos++; 
          font = getFont();
          if (font != null) {
            FontMetrics fontMetrics = getFontMetrics(font);
            String str2 = this.text.toString();
            while (fontMetrics.stringWidth(str2.substring(this.sIdx, this.curPos)) > (getSize()).width)
              this.sIdx++; 
          } 
          bool2 = true;
          break;
        case 10:
          this.eventMgr.postEvent(new ActionEvent(this, 1001, getText()));
        case 9:
          transferFocus();
          break;
      } 
      if ((paramKeyEvent.getKeyCode() == 37 || paramKeyEvent.getKeyCode() == 39) && (paramKeyEvent.getModifiers() & true) != 0) {
        if (this.startPos == -1 || this.newSel) {
          this.startPos = i;
          this.endPos = this.curPos;
          this.newSel = false;
        } else {
          this.endPos = this.curPos;
        } 
        bool2 = true;
      } 
      if ((paramKeyEvent.getModifiers() & 0x2) != 0) {
        Transferable transferable;
        Clipboard clipboard = getToolkit().getSystemClipboard();
        switch (paramKeyEvent.getKeyChar()) {
          case '\030':
            clipboard.setContents(new StringSelection(getSelectedText()), this);
            removeSelectedText();
            bool1 = true;
            break;
          case '\026':
            transferable = clipboard.getContents(this);
            try {
              String str2 = (String)transferable.getTransferData(DataFlavor.stringFlavor);
              replace(this.curPos, str2);
              bool1 = true;
            } catch (Exception exception) {}
            break;
        } 
      } 
      String str1 = getText();
      int j = getCaretPos();
      if (str1.length() != str.length()) {
        int m = this.mask.lastPos(j);
        if (m >= 0) {
          int n = str.length() - str1.length();
          if (n > 0)
            for (byte b = 0; b < n; b++)
              insert(m, " ");  
        } else if (str1.charAt(j) != str.charAt(j)) {
          char[] arrayOfChar = { str.charAt(j) };
          insert(j, new String(arrayOfChar));
          int n = this.mask.nextPos(j, false);
          if (n >= 0)
            replace(n, " "); 
        } 
        str1 = getText();
      } 
      int k = this.mask.nextPos(j, (paramKeyEvent.getKeyCode() != 8 && paramKeyEvent.getKeyCode() != 37));
      setCaretPos((k >= 0) ? k : i);
    } else if (paramKeyEvent.getID() == 400 && this.curPos < this.template.length() && (paramKeyEvent.getModifiers() & 0x4) == 0 && (paramKeyEvent.getModifiers() & 0x2) == 0 && (paramKeyEvent.getModifiers() & 0x8) == 0 && paramKeyEvent.getKeyChar() != '\b' && paramKeyEvent.getKeyChar() != '\r' && paramKeyEvent.getKeyChar() != '\n' && paramKeyEvent.getKeyChar() != '\t') {
      remove(this.sIdx + this.curPos, this.sIdx + this.curPos + 1);
      this.text.insert(this.sIdx + this.curPos++, paramKeyEvent.getKeyChar());
      bool1 = true;
    } else if (paramKeyEvent.getKeyCode() == 16 && paramKeyEvent.getID() == 402) {
      this.newSel = true;
    } 
    try {
      this.mask.verify(getText());
    } catch (FormatException formatException) {
      showError(formatException);
      setText(str);
      setCaretPos(i);
    } 
    if (bool1 || bool2)
      repaint(); 
    if (bool1)
      this.eventMgr.postEvent(new TextEvent(this, 900)); 
    super.processKeyEvent(paramKeyEvent);
  }
  
  protected void showError(FormatException paramFormatException) { JOptionPane.showMessageDialog(this, paramFormatException.toString()); }
  
  public void processMouseEvent(MouseEvent paramMouseEvent) {
    int i = getCaretPos();
    switch (paramMouseEvent.getID()) {
      case 501:
        this.startPos = this.sIdx + findPosition(paramMouseEvent.getX());
        break;
      case 502:
        this.curPos = findPosition(paramMouseEvent.getX());
        if (this.curPos + this.sIdx == this.startPos) {
          clearSelection();
        } else if (this.startPos >= 0) {
          this.endPos = this.curPos + this.sIdx;
          this.curPos = Math.max(this.startPos - this.sIdx, 0);
        } 
        requestFocus();
        repaint();
        break;
    } 
    super.processMouseEvent(paramMouseEvent);
    if (i != getCaretPos()) {
      int j = this.mask.nextPos(getCaretPos(), true);
      setCaretPos((j >= 0) ? j : i);
    } 
  }
  
  public void processFocusEvent(FocusEvent paramFocusEvent) {
    if (paramFocusEvent.getID() == 1004) {
      this.focus = true;
    } else if (paramFocusEvent.getID() == 1005) {
      this.focus = false;
    } 
    repaint();
    super.processFocusEvent(paramFocusEvent);
  }
  
  public void processMouseMotionEvent(MouseEvent paramMouseEvent) {
    if (paramMouseEvent.getID() == 506) {
      if (paramMouseEvent.getX() < 0 || paramMouseEvent.getX() > (getSize()).width) {
        Date date = new Date();
        if (date.getTime() - this.oTime.getTime() > 30L) {
          this.oTime = date;
          if (paramMouseEvent.getX() < 0 && this.sIdx > 0) {
            this.sIdx--;
          } else if (this.fm.stringWidth(this.text.toString().substring(this.sIdx)) > (getSize()).width && paramMouseEvent.getX() > (getSize()).width) {
            this.sIdx++;
          } 
          repaint();
        } 
      } 
      int i = findPosition(paramMouseEvent.getX()) + this.sIdx;
      if (this.startPos != i && i != this.endPos) {
        this.endPos = i;
        repaint();
      } 
    } 
    super.processMouseMotionEvent(paramMouseEvent);
  }
  
  public boolean isFocusTraversable() { return isEditable(); }
  
  private int findPosition(int paramInt) {
    for (int i = 0; i + this.sIdx < this.disptext.length(); i++) {
      int j = this.border + this.fm.stringWidth(this.disptext.substring(this.sIdx, this.sIdx + i));
      if (paramInt < j + this.fm.charWidth(this.disptext.charAt(this.sIdx + i)) / 2)
        break; 
    } 
    return i;
  }
  
  private void paintCaret(Graphics paramGraphics) {
    Dimension dimension = getSize();
    int i = nthCharX(this.curPos);
    int j = (dimension.height - this.fm.getHeight()) / 2 + 2;
    int k = dimension.height - j * 2;
    paramGraphics.drawLine(i, j, i, k);
    paramGraphics.drawLine(i - 1, j - 1, i - 1, j - 1);
    paramGraphics.drawLine(i + 1, j - 1, i + 1, j - 1);
    paramGraphics.drawLine(i - 1, k + 1, i - 1, k + 1);
    paramGraphics.drawLine(i + 1, k + 1, i + 1, k + 1);
  }
  
  private int nthCharX(int paramInt) {
    if (paramInt < 0)
      return this.border; 
    String str = this.disptext.substring(this.sIdx);
    return this.fm.stringWidth((paramInt >= str.length()) ? str : str.substring(0, paramInt)) + this.border;
  }
  
  private void setSize() {
    if (this.fm == null) {
      Font font = getFont();
      if (font != null)
        this.fm = getFontMetrics(getFont()); 
    } 
    if (this.fm == null)
      return; 
    int i = (this.template == null) ? (this.fm.charWidth('M') * this.cwidth) : this.fm.stringWidth(this.template);
    Insets insets = getInsets();
    this.minSize = new Dimension(i + 2 * (this.border + 1) + insets.left + insets.right, this.fm.getHeight() + 2 + insets.top + insets.bottom);
  }
  
  protected boolean isPunct(char paramChar) { return (paramChar == ',' || paramChar == '.' || paramChar == '\'' || paramChar == '"' || paramChar == ';' || paramChar == ':' || paramChar == '/' || paramChar == '?' || paramChar == '!'); }
  
  class Mask {
    private String mask;
    
    private final MaskEdit this$0;
    
    public Mask(MaskEdit this$0, String param1String) {
      this.this$0 = this$0;
      this.mask = param1String;
    }
    
    public int length() { return toString().length(); }
    
    public boolean verify(String param1String) throws FormatException {
      boolean bool = false;
      for (byte b1 = 0, b2 = 0; b1 < param1String.length() && b2 < this.mask.length(); b1++, b2++) {
        if (bool) {
          if (this.mask.charAt(b2) == ']') {
            bool = false;
            b1--;
          } else if (param1String.charAt(b1) != ' ') {
            char c = param1String.charAt(b1);
            switch (this.mask.charAt(b2)) {
              case 'c':
                if (!Character.isLowerCase(c))
                  throw new FormatException("Lowercase character expected at " + b1 + "'th character(" + c + ")"); 
                break;
              case 'C':
                if (!Character.isUpperCase(c))
                  throw new FormatException("Uppercase character expected at " + b1 + "'th character(" + c + ")"); 
                break;
              case 'A':
                if (!Character.isLowerCase(c) && !Character.isUpperCase(c) && c != ' ' && c != '_')
                  throw new FormatException("Alphabet character expected at " + b1 + "'th character(" + c + ")"); 
                break;
              case ',':
                if (!this.this$0.isPunct(c))
                  throw new FormatException("Punctuation char expected at " + b1 + "'th character(" + c + ")"); 
              case 'S':
                if (!Character.isLowerCase(c) && !Character.isUpperCase(c) && c != ' ' && c != '_' && !this.this$0.isPunct(c) && !Character.isDigit(c))
                  throw new FormatException("Alphabet character expected at " + b1 + "'th character(" + c + ")"); 
                break;
              case '9':
                if (!Character.isDigit(c))
                  throw new FormatException("Digit expected at " + b1 + "'th character(" + c + ")"); 
                break;
              case 'V':
                if (!Character.isDigit(c) && c != '.')
                  throw new FormatException("Digit expected at " + b1 + "'th character(" + c + ")"); 
                break;
            } 
          } 
        } else if (this.mask.charAt(b2) == '[') {
          bool = true;
          b1--;
        } else if (this.mask.charAt(b2) == '\\') {
          b2++;
        } else if (this.mask.charAt(b2) != param1String.charAt(b1)) {
          throw new FormatException("Mask static text modified");
        } 
      } 
      return true;
    }
    
    public int nextPos(int param1Int, boolean param1Boolean) {
      Position position = nthPos(param1Int);
      boolean bool = position.inPic;
      int i = param1Int, j = position.idx;
      if (!bool)
        if (param1Boolean) {
          for (; j < this.mask.length(); j++) {
            if (this.mask.charAt(j) == '[') {
              bool = true;
              break;
            } 
            if (this.mask.charAt(j) == '\\')
              j++; 
            i++;
          } 
        } else {
          for (; j >= 0; j--) {
            if (this.mask.charAt(j) == ']' && (j == 0 || this.mask.charAt(j - 1) != '\\')) {
              bool = true;
              break;
            } 
            if (this.mask.charAt(j) == '\\')
              j--; 
            i--;
          } 
        }  
      return bool ? Math.min(i, this.this$0.text.length()) : -1;
    }
    
    public int lastPos(int param1Int) {
      Position position = nthPos(param1Int);
      boolean bool = position.inPic;
      int i = position.idx;
      if (bool) {
        for (; i < this.mask.length(); i++) {
          if (this.mask.charAt(i) != '\\') {
            if (this.mask.charAt(i) == ']') {
              param1Int--;
              break;
            } 
            param1Int++;
          } 
        } 
      } else {
        return -1;
      } 
      return param1Int;
    }
    
    public String toString() { return toString(' '); }
    
    public String toString(char param1Char) {
      StringBuffer stringBuffer = new StringBuffer();
      boolean bool = false;
      for (byte b = 0; b < this.mask.length(); b++) {
        if (this.mask.charAt(b) == '\\') {
          b++;
        } else if (this.mask.charAt(b) == '[') {
          bool = true;
          continue;
        } 
        if (bool) {
          if (this.mask.charAt(b) == ']') {
            bool = false;
          } else {
            stringBuffer.append(param1Char);
          } 
        } else {
          stringBuffer.append(this.mask.charAt(b));
        } 
        continue;
      } 
      return stringBuffer.toString();
    }
    
    public String getMask() { return this.mask; }
    
    private class Position {
      int idx;
      
      boolean inPic;
      
      private final MaskEdit.Mask this$1;
      
      private Position(MaskEdit.Mask this$0) { this.this$1 = this$0; }
    }
    
    private Position nthPos(int param1Int) {
      Position position = new Position(this, null);
      for (position.idx = 0; position.idx < this.mask.length(); position.idx++) {
        if (position.inPic) {
          if (this.mask.charAt(position.idx) == ']') {
            position.inPic = false;
            continue;
          } 
        } else {
          if (this.mask.charAt(position.idx) == '[') {
            position.inPic = true;
          } else {
            if (this.mask.charAt(position.idx) == '\\')
              position.idx++; 
            if (param1Int == 0)
              break; 
          } 
          continue;
        } 
        if (param1Int == 0)
          break; 
      } 
      return position;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\MaskEdit.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */