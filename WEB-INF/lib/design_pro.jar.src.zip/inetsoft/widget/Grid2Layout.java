/*     */ package inetsoft.widget;
/*     */ 
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Grid2Layout
/*     */   extends GridBagLayout
/*     */ {
/*     */   public static final int H_LEFT = 1;
/*     */   public static final int H_CENTER = 2;
/*     */   public static final int H_RIGHT = 4;
/*     */   public static final int H_FILL = 64;
/*     */   public static final int V_TOP = 8;
/*     */   public static final int V_CENTER = 16;
/*     */   public static final int V_BOTTOM = 32;
/*     */   public static final int V_FILL = 128;
/*     */   
/*  82 */   public Grid2Layout(Insets paramInsets) { this.gaps = paramInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public Constraints at(int paramInt1, int paramInt2) { return new Constraints(this, paramInt1, paramInt2, 1, 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public Constraints at(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { return new Constraints(this, paramInt1, paramInt2, paramInt3, paramInt4); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public Constraints at(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) { return new Constraints(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public Constraints at(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, Insets paramInsets) { return new Constraints(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInsets); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public Insets getGaps() { return this.gaps; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public void setGaps(Insets paramInsets) { this.gaps = paramInsets; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Constraints
/*     */     extends GridBagConstraints
/*     */   {
/*     */     private final Grid2Layout this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     public Constraints(Grid2Layout this$0, int param1Int1, int param1Int2) { this(this$0, param1Int1, param1Int2, 1, 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Constraints(Grid2Layout this$0, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 173 */       this.this$0 = this$0;
/* 174 */       this.gridx = param1Int2;
/* 175 */       this.gridy = param1Int1;
/* 176 */       this.gridwidth = param1Int4;
/* 177 */       this.gridheight = param1Int3;
/* 178 */       this.insets = this$0.gaps;
/* 179 */       this.weightx = this.weighty = 1.0D;
/* 180 */       this.fill = 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Constraints(Grid2Layout this$0, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
/* 192 */       this(this$0, param1Int1, param1Int2, param1Int3, param1Int4);
/* 193 */       this.fill = 0;
/*     */       
/* 195 */       if ((param1Int5 & true) != 0) {
/* 196 */         this.anchor = ((param1Int5 & 0x8) != 0) ? 18 : (((param1Int5 & 0x20) != 0) ? 16 : 17);
/*     */       
/*     */       }
/* 199 */       else if ((param1Int5 & 0x4) != 0) {
/* 200 */         this.anchor = ((param1Int5 & 0x8) != 0) ? 12 : (((param1Int5 & 0x20) != 0) ? 14 : 13);
/*     */       }
/*     */       else {
/*     */         
/* 204 */         this.anchor |= (((param1Int5 & 0x8) != 0) ? 11 : (((param1Int5 & 0x20) != 0) ? 15 : 10));
/*     */       } 
/*     */ 
/*     */       
/* 208 */       if ((param1Int5 & 0x40) != 0) {
/* 209 */         this.fill |= 0x2;
/*     */       }
/*     */       
/* 212 */       if ((param1Int5 & 0x80) != 0) {
/* 213 */         this.fill |= 0x3;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Constraints(Grid2Layout this$0, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, Insets param1Insets) {
/* 228 */       this(this$0, param1Int1, param1Int2, param1Int3, param1Int4, param1Int5);
/* 229 */       this.insets = param1Insets;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 234 */   private Insets gaps = new Insets(0, 0, 0, 0);
/*     */   
/*     */   public Grid2Layout() {}
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\Grid2Layout.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */