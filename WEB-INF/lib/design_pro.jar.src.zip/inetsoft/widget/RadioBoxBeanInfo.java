/*    */ package inetsoft.widget;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import java.beans.SimpleBeanInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RadioBoxBeanInfo
/*    */   extends SimpleBeanInfo
/*    */ {
/*    */   public Image getIcon(int paramInt) {
/*    */     Image image;
/* 28 */     switch (paramInt) {
/*    */       case 1:
/*    */       case 3:
/* 31 */         image = loadImage("beans/RadioBoxBean.gif");
/* 32 */         return image.getScaledInstance(16, 16, 4);
/*    */       case 2:
/*    */       case 4:
/* 35 */         image = loadImage("beans/RadioBoxBean32.gif");
/* 36 */         return image.getScaledInstance(32, 32, 4);
/*    */     } 
/* 38 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\RadioBoxBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */