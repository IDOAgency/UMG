package inetsoft.widget;

import inetsoft.widget.util.Tool;
import java.awt.AWTEventMulticaster;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JWindow;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class ColorComboBox extends Container implements FocusListener, ActionListener {
  protected ActionListener actionListener;
  
  ColorCell cell;
  
  JButton arrow;
  
  ColorMenu menu;
  
  JWindow popwin;
  
  MoveListener moveListener;
  
  Component selectedCell;
  
  Color[] menucolors;
  
  public ColorComboBox() {
    this.actionListener = null;
    this.cell = new ColorCell(this);
    this.popwin = null;
    this.menucolors = new Color[] { 
        Color.white, Color.black, Color.lightGray, Color.gray, Color.red, new Color(128, 0, 0), Color.yellow, new Color(128, 128, 0), Color.green, new Color(0, 128, 0), 
        Color.cyan, new Color(0, 0, 128), Color.blue, new Color(0, 0, 128), Color.magenta, new Color(128, 0, 128), new Color(192, 220, 192), new Color(166, 202, 240), new Color(255, 251, 240), new Color(160, 160, 164) };
    setLayout(new BorderLayout());
    this.cell.setBorder(new BevelBorder(1));
    add(this.cell, "Center");
    this.cell.setPreferredSize(new Dimension(18, 18));
    URL uRL = getClass().getResource("/inetsoft/widget/images/menuarrow.gif");
    this.arrow = new JButton(new ImageIcon(uRL));
    this.arrow.setPreferredSize(new Dimension(12, 18));
    add(this.arrow, "East");
    this.arrow.addActionListener(this);
    this.arrow.addFocusListener(this);
  }
  
  public ColorComboBox(Color[] paramArrayOfColor) {
    this();
    setColors(paramArrayOfColor);
  }
  
  public void setColors(Color[] paramArrayOfColor) {
    popdown();
    this.menu = null;
    this.menucolors = paramArrayOfColor;
  }
  
  public Color[] getColors() { return this.menucolors; }
  
  public void setSelectedColor(Color paramColor) {
    if (this.menu == null)
      this.menu = new ColorMenu(this); 
    this.menu.setSelectedColor(paramColor);
    this.cell.setColor(paramColor);
  }
  
  public Color getSelectedColor() { return this.cell.getColor(); }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    this.arrow.setEnabled(paramBoolean);
  }
  
  public void popup() {
    if (this.menu == null)
      this.menu = new ColorMenu(this); 
    if (this.popwin == null) {
      this.popwin = createWindow();
      this.popwin.getContentPane().add(this.menu, "Center");
    } 
    if (this.moveListener == null) {
      this.moveListener = new MoveListener(this, null);
      Tool.findWindow(this).addComponentListener(this.moveListener);
    } 
    Point point = getLocationOnScreen();
    this.popwin.setLocation(point.x, point.y + (getSize()).height);
    this.popwin.setSize(1, 1);
    this.popwin.pack();
    this.popwin.setVisible(true);
    this.popwin.setLocation(point.x, point.y + (getSize()).height);
    this.arrow.requestFocus();
    this.popwin.toFront();
  }
  
  public void popdown() {
    if (this.popwin != null)
      this.popwin.setVisible(false); 
  }
  
  public boolean isPopuped() { return (this.menu != null && this.menu.isVisible()); }
  
  public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
  
  public void processActionEvent(ActionEvent paramActionEvent) {
    if (this.actionListener != null)
      this.actionListener.actionPerformed(paramActionEvent); 
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (this.popwin != null && this.popwin.isVisible()) {
      popdown();
    } else {
      popup();
    } 
  }
  
  public void focusLost(FocusEvent paramFocusEvent) {}
  
  public void focusGained(FocusEvent paramFocusEvent) {}
  
  private class MoveListener extends ComponentAdapter implements Serializable {
    private final ColorComboBox this$0;
    
    private MoveListener(ColorComboBox this$0) { this.this$0 = this$0; }
    
    public void componentMoved(ComponentEvent param1ComponentEvent) { this.this$0.popdown(); }
  }
  
  protected JWindow createWindow() {
    try {
      Class clazz = Class.forName("javax.swing.JWindow");
      Constructor constructor = null;
      Object[] arrayOfObject = { null };
      try {
        constructor = clazz.getConstructor(new Class[] { java.awt.Window.class });
        arrayOfObject[0] = Tool.findWindow(this);
      } catch (Exception exception) {
        constructor = clazz.getConstructor(new Class[] { java.awt.Frame.class });
        arrayOfObject[0] = Tool.findFrame(this);
      } 
      return (JWindow)constructor.newInstance(arrayOfObject);
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  private class ColorMenu extends JPanel {
    ColorComboBox.ColorCell[] cells;
    
    JButton otherB;
    
    ColorComboBox.ColorCell other;
    
    private final ColorComboBox this$0;
    
    public ColorMenu(ColorComboBox this$0) {
      this.this$0 = this$0;
      this.other = new ColorComboBox.ColorCell(this.this$0);
      setLayout(new BorderLayout());
      add(new ColorComboBox.TransparentCell(this$0), "North");
      JPanel jPanel = new JPanel();
      jPanel.setBorder(new BevelBorder(0));
      add(jPanel, "Center");
      int i = (int)Math.ceil((this$0.menucolors.length / 5.0F));
      Grid2Layout grid2Layout = new Grid2Layout(new Insets(2, 2, 2, 2));
      jPanel.setLayout(grid2Layout);
      this.cells = new ColorComboBox.ColorCell[this$0.menucolors.length];
      for (byte b = 0; b < this$0.menucolors.length; b++) {
        this.cells[b] = new ColorComboBox.ColorCell(this$0, this$0.menucolors[b]);
        this.cells[b].setBorder(new LineBorder(Color.gray));
        jPanel.add(this.cells[b], grid2Layout.at(b / 5, b % 5));
      } 
      jPanel = new JPanel();
      jPanel.setBorder(new BevelBorder(0));
      jPanel.setLayout(new BorderLayout());
      jPanel.add(this.otherB = new JButton("Other..."), "Center");
      jPanel.add(this.other, "East");
      add(jPanel, "South");
      this.other.setColor(getBackground());
      this.other.setBorder(new EmptyBorder(4, 1, 4, 1));
      this.otherB.addActionListener(new ActionListener(this) {
            private final ColorComboBox.ColorMenu this$1;
            
            public void actionPerformed(ActionEvent param1ActionEvent) {
              Color color = JColorChooser.showDialog(this.this$1.this$0, "Select Color", this.this$1.other.getColor());
              if (color != null) {
                this.this$1.other.setColor(color);
                this.this$1.other.processMouseEvent(null);
              } 
            }
          });
    }
    
    public void setSelectedColor(Color param1Color) {
      for (byte b = 0; b < this.cells.length; b++) {
        if (this.cells[b].getColor().equals(param1Color)) {
          this.this$0.selectedCell = this.cells[b];
          return;
        } 
      } 
      this.this$0.selectedCell = this.other;
      this.other.setColor(param1Color);
    }
  }
  
  private class ColorCell extends JComponent {
    private Color color;
    
    private final ColorComboBox this$0;
    
    public ColorCell(ColorComboBox this$0) {
      this.this$0 = this$0;
      this.color = Color.white;
      enableEvents(16L);
      setPreferredSize(new Dimension(15, 15));
    }
    
    public ColorCell(ColorComboBox this$0, Color param1Color) {
      this(this$0);
      setColor(param1Color);
    }
    
    public void setColor(Color param1Color) {
      this.color = param1Color;
      repaint();
    }
    
    public Color getColor() { return this.color; }
    
    public void paintComponent(Graphics param1Graphics) {
      Dimension dimension = getSize();
      Insets insets = getInsets();
      param1Graphics.setColor((this.color == null) ? Color.white : this.color);
      param1Graphics.fillRect(insets.left, insets.top, dimension.width - insets.left - insets.right, dimension.height - insets.top - insets.bottom);
      if (this.this$0.selectedCell == this) {
        param1Graphics.setColor(Color.black);
        param1Graphics.drawRect(insets.left, insets.top, dimension.width - 1 - insets.left - insets.right, dimension.height - 1 - insets.top - insets.bottom);
      } 
    }
    
    public void processMouseEvent(MouseEvent param1MouseEvent) {
      if (param1MouseEvent == null || param1MouseEvent.getID() == 500) {
        this.this$0.setSelectedColor(this.color);
        this.this$0.selectedCell = this;
        this.this$0.popdown();
        String str = (this.color == null) ? "" : this.color.toString();
        this.this$0.processActionEvent(new ActionEvent(this.this$0, 1001, str));
      } 
      if (param1MouseEvent != null)
        super.processMouseEvent(param1MouseEvent); 
    }
    
    public Dimension getMinimumSize() { return getPreferredSize(); }
  }
  
  private class TransparentCell extends JButton {
    String label;
    
    private final ColorComboBox this$0;
    
    public TransparentCell(ColorComboBox this$0) {
      this.this$0 = this$0;
      this.label = "Transparent";
      enableEvents(16L);
      setPreferredSize(new Dimension(60, 20));
      setFont(new Font("Serif", 0, 10));
      setText(this.label);
      addActionListener(new ColorComboBox$2(this));
    }
    
    public Dimension getMinimumSize() { return getPreferredSize(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\widget\ColorComboBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */