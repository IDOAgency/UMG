package inetsoft.grid.internal;

import inetsoft.util.Comparer;
import java.util.BitSet;
import javax.swing.JPopupMenu;

public class ColInfo extends GridInfo {
  public Integer width;
  
  public Integer pwidth;
  
  public BitSet calc = new BitSet();
  
  public boolean hiden;
  
  public boolean selected;
  
  public JPopupMenu menu;
  
  public int minwidth;
  
  public Comparer comparer;
  
  public void reset() {
    this.pwidth = null;
    this.calc = new BitSet();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\internal\ColInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */