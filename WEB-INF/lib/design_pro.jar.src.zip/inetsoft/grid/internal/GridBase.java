/*     */ package inetsoft.grid.internal;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GridBase
/*     */ {
/*     */   public static void paintText(Graphics paramGraphics, String paramString, Rectangle paramRectangle, int paramInt, boolean paramBoolean) {
/*  38 */     FontMetrics fontMetrics = paramGraphics.getFontMetrics();
/*  39 */     Vector vector = new Vector();
/*  40 */     Dimension dimension = new Dimension(0, 0);
/*  41 */     String str = null;
/*     */ 
/*     */     
/*  44 */     while (paramString.length() > 0 || str != null) {
/*  45 */       String str1 = null;
/*     */       
/*  47 */       if (str != null) {
/*  48 */         str1 = str;
/*  49 */         str = null;
/*     */       } else {
/*     */         
/*  52 */         int j = paramString.indexOf('\n');
/*     */         
/*  54 */         if (j >= 0) {
/*  55 */           str1 = paramString.substring(0, j);
/*  56 */           paramString = paramString.substring(j + 1);
/*     */         } else {
/*     */           
/*  59 */           str1 = paramString;
/*  60 */           paramString = "";
/*     */         } 
/*     */       } 
/*     */       
/*  64 */       if (paramBoolean) {
/*  65 */         int j = Math.min(str1.length(), paramRectangle.width / fontMetrics.charWidth('x'));
/*  66 */         String str2 = str1.substring(0, j);
/*     */ 
/*     */         
/*  69 */         while (j < str1.length() && fontMetrics.stringWidth(str2) <= paramRectangle.width) {
/*  70 */           str2 = str1.substring(0, ++j);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  75 */         if (fontMetrics.stringWidth(str2) > paramRectangle.width) {
/*  76 */           j--;
/*     */           
/*  78 */           while ((j > 0 && !Character.isWhitespace(str1.charAt(j))) || fontMetrics.stringWidth(str2.substring(0, j)) > paramRectangle.width) {
/*  79 */             j--;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*  85 */         if (j <= 0) {
/*  86 */           j = Math.max(str2.length(), 0);
/*     */         }
/*     */         
/*  89 */         String str3 = str1.substring(0, j);
/*  90 */         vector.addElement(str3);
/*  91 */         dimension.width = Math.max(dimension.width, fontMetrics.stringWidth(str3));
/*     */         
/*  93 */         if (j < str1.length()) {
/*  94 */           str = str1.substring(Character.isWhitespace(str1.charAt(j)) ? (j + 1) : j);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*  99 */       dimension.width = Math.max(dimension.width, fontMetrics.stringWidth(str1));
/* 100 */       vector.addElement(str1);
/*     */     } 
/*     */ 
/*     */     
/* 104 */     dimension.height = fontMetrics.getHeight() * vector.size();
/*     */ 
/*     */     
/* 107 */     Rectangle rectangle = new Rectangle(paramRectangle);
/* 108 */     paramRectangle = alignCell(paramRectangle, dimension, paramInt);
/*     */     
/* 110 */     int i = paramRectangle.y + Math.max((paramRectangle.height - dimension.height) / 2, 0) + fontMetrics.getMaxAscent();
/*     */ 
/*     */ 
/*     */     
/* 114 */     for (byte b = 0; b < vector.size(); b++) {
/* 115 */       paramGraphics.drawString((String)vector.elementAt(b), paramRectangle.x, i);
/* 116 */       i += fontMetrics.getHeight();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Rectangle alignCell(Rectangle paramRectangle, Dimension paramDimension, int paramInt) {
/* 132 */     Rectangle rectangle = new Rectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*     */     
/* 134 */     if (paramInt != 0) {
/* 135 */       if (paramDimension.width < rectangle.width) {
/* 136 */         if ((paramInt & 0x2) != 0) {
/* 137 */           rectangle.x += (rectangle.width - paramDimension.width) / 2;
/* 138 */           rectangle.width = paramDimension.width;
/*     */         }
/* 140 */         else if ((paramInt & 0x4) != 0) {
/* 141 */           rectangle.x += rectangle.width - paramDimension.width;
/* 142 */           rectangle.width = paramDimension.width;
/*     */         }
/* 144 */         else if ((paramInt & true) != 0) {
/* 145 */           rectangle.width = paramDimension.width;
/*     */         } 
/*     */       }
/*     */       
/* 149 */       if (paramDimension.height < rectangle.height) {
/* 150 */         if ((paramInt & 0x10) != 0) {
/* 151 */           rectangle.y += (rectangle.height - paramDimension.height) / 2;
/* 152 */           rectangle.height = paramDimension.height;
/*     */         }
/* 154 */         else if ((paramInt & 0x20) != 0) {
/* 155 */           rectangle.y += rectangle.height - paramDimension.height;
/* 156 */           rectangle.height = paramDimension.height;
/*     */         }
/* 158 */         else if ((paramInt & 0x8) != 0) {
/* 159 */           rectangle.height = paramDimension.height;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 164 */     return rectangle;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\internal\GridBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */