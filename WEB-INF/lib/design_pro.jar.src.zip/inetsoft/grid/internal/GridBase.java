package inetsoft.grid.internal;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Vector;

public class GridBase {
  public static void paintText(Graphics paramGraphics, String paramString, Rectangle paramRectangle, int paramInt, boolean paramBoolean) {
    FontMetrics fontMetrics = paramGraphics.getFontMetrics();
    Vector vector = new Vector();
    Dimension dimension = new Dimension(0, 0);
    String str = null;
    while (paramString.length() > 0 || str != null) {
      String str1 = null;
      if (str != null) {
        str1 = str;
        str = null;
      } else {
        int j = paramString.indexOf('\n');
        if (j >= 0) {
          str1 = paramString.substring(0, j);
          paramString = paramString.substring(j + 1);
        } else {
          str1 = paramString;
          paramString = "";
        } 
      } 
      if (paramBoolean) {
        int j = Math.min(str1.length(), paramRectangle.width / fontMetrics.charWidth('x'));
        String str2 = str1.substring(0, j);
        while (j < str1.length() && fontMetrics.stringWidth(str2) <= paramRectangle.width)
          str2 = str1.substring(0, ++j); 
        if (fontMetrics.stringWidth(str2) > paramRectangle.width) {
          j--;
          while ((j > 0 && !Character.isWhitespace(str1.charAt(j))) || fontMetrics.stringWidth(str2.substring(0, j)) > paramRectangle.width)
            j--; 
        } 
        if (j <= 0)
          j = Math.max(str2.length(), 0); 
        String str3 = str1.substring(0, j);
        vector.addElement(str3);
        dimension.width = Math.max(dimension.width, fontMetrics.stringWidth(str3));
        if (j < str1.length())
          str = str1.substring(Character.isWhitespace(str1.charAt(j)) ? (j + 1) : j); 
        continue;
      } 
      dimension.width = Math.max(dimension.width, fontMetrics.stringWidth(str1));
      vector.addElement(str1);
    } 
    dimension.height = fontMetrics.getHeight() * vector.size();
    Rectangle rectangle = new Rectangle(paramRectangle);
    paramRectangle = alignCell(paramRectangle, dimension, paramInt);
    int i = paramRectangle.y + Math.max((paramRectangle.height - dimension.height) / 2, 0) + fontMetrics.getMaxAscent();
    for (byte b = 0; b < vector.size(); b++) {
      paramGraphics.drawString((String)vector.elementAt(b), paramRectangle.x, i);
      i += fontMetrics.getHeight();
    } 
  }
  
  public static Rectangle alignCell(Rectangle paramRectangle, Dimension paramDimension, int paramInt) {
    Rectangle rectangle = new Rectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    if (paramInt != 0) {
      if (paramDimension.width < rectangle.width)
        if ((paramInt & 0x2) != 0) {
          rectangle.x += (rectangle.width - paramDimension.width) / 2;
          rectangle.width = paramDimension.width;
        } else if ((paramInt & 0x4) != 0) {
          rectangle.x += rectangle.width - paramDimension.width;
          rectangle.width = paramDimension.width;
        } else if ((paramInt & true) != 0) {
          rectangle.width = paramDimension.width;
        }  
      if (paramDimension.height < rectangle.height)
        if ((paramInt & 0x10) != 0) {
          rectangle.y += (rectangle.height - paramDimension.height) / 2;
          rectangle.height = paramDimension.height;
        } else if ((paramInt & 0x20) != 0) {
          rectangle.y += rectangle.height - paramDimension.height;
          rectangle.height = paramDimension.height;
        } else if ((paramInt & 0x8) != 0) {
          rectangle.height = paramDimension.height;
        }  
    } 
    return rectangle;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\internal\GridBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */