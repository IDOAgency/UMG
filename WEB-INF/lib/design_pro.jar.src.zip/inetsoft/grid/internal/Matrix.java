/*     */ package inetsoft.grid.internal;
/*     */ 
/*     */ import inetsoft.util.internal.FVector;
/*     */ import java.io.Serializable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Matrix
/*     */   implements Serializable, Cloneable
/*     */ {
/*     */   private FVector data;
/*     */   private FVector rowInfo;
/*     */   private FVector colInfo;
/*     */   private int nrow;
/*     */   private int ncol;
/*     */   private MatrixHelper helper;
/*     */   
/*     */   public Matrix(int paramInt1, int paramInt2, MatrixHelper paramMatrixHelper) {
/* 291 */     this.data = new FVector();
/* 292 */     this.rowInfo = new FVector();
/* 293 */     this.colInfo = new FVector();
/*     */     this.helper = paramMatrixHelper;
/*     */     setColCount(paramInt2);
/*     */     setRowCount(paramInt1);
/*     */   }
/*     */   
/*     */   public Object getRowInfo(int paramInt) {
/*     */     Object object = this.rowInfo.getElement(paramInt);
/*     */     if (object == null && this.helper != null)
/*     */       setRowInfo(paramInt, object = this.helper.createRowInfo()); 
/*     */     return object;
/*     */   }
/*     */   
/*     */   public void setRowInfo(int paramInt, Object paramObject) { this.rowInfo.setElementAt(paramObject, paramInt); }
/*     */   
/*     */   public Object getColInfo(int paramInt) {
/*     */     Object object = this.colInfo.getElement(paramInt);
/*     */     if (object == null && this.helper != null)
/*     */       setColInfo(paramInt, object = this.helper.createColInfo()); 
/*     */     return object;
/*     */   }
/*     */   
/*     */   public void setColInfo(int paramInt, Object paramObject) { this.colInfo.setElementAt(paramObject, paramInt); }
/*     */   
/*     */   public void insertRow(int paramInt1, int paramInt2) {
/*     */     for (byte b = 0; b < paramInt2; b++) {
/*     */       FVector fVector = new FVector(this.ncol);
/*     */       fVector.setSize(this.ncol);
/*     */       this.data.insertElementAt(fVector, paramInt1);
/*     */       this.rowInfo.insertElementAt(null, paramInt1);
/*     */       if (this.helper != null)
/*     */         for (byte b1 = 0; b1 < fVector.size(); b1++)
/*     */           fVector.setElementAt(null, b1);  
/*     */     } 
/*     */     this.nrow += paramInt2;
/*     */   }
/*     */   
/*     */   public void removeRow(int paramInt1, int paramInt2) {
/*     */     for (byte b = 0; b < paramInt2; b++) {
/*     */       this.data.removeElementAt(paramInt1);
/*     */       this.rowInfo.removeElementAt(paramInt1);
/*     */     } 
/*     */     this.nrow -= paramInt2;
/*     */   }
/*     */   
/*     */   public void moveRow(int paramInt1, int paramInt2) {
/*     */     this.data.insertElementAt(this.data.getElement(paramInt1), paramInt2);
/*     */     this.rowInfo.insertElementAt(this.rowInfo.getElement(paramInt1), paramInt2);
/*     */     this.data.removeElementAt((paramInt2 > paramInt1) ? paramInt1 : ++paramInt1);
/*     */     this.rowInfo.removeElementAt(paramInt1);
/*     */   }
/*     */   
/*     */   public void insertCol(int paramInt1, int paramInt2) {
/*     */     for (byte b1 = 0; b1 < this.nrow; b1++) {
/*     */       Vector vector = (Vector)this.data.getElement(b1);
/*     */       for (byte b = 0; b < paramInt2; b++)
/*     */         vector.insertElementAt(null, paramInt1); 
/*     */     } 
/*     */     for (byte b2 = 0; b2 < paramInt2; b2++)
/*     */       this.colInfo.insertElementAt(null, paramInt1); 
/*     */     this.ncol += paramInt2;
/*     */   }
/*     */   
/*     */   public void removeCol(int paramInt1, int paramInt2) {
/*     */     for (byte b1 = 0; b1 < this.nrow; b1++) {
/*     */       Vector vector = (Vector)this.data.getElement(b1);
/*     */       for (byte b = 0; b < paramInt2; b++)
/*     */         vector.removeElementAt(paramInt1); 
/*     */     } 
/*     */     for (byte b2 = 0; b2 < paramInt2; b2++)
/*     */       this.colInfo.removeElementAt(paramInt1); 
/*     */     this.ncol -= paramInt2;
/*     */   }
/*     */   
/*     */   public void moveCol(int paramInt1, int paramInt2) {
/*     */     for (byte b = 0; b < this.nrow; b++) {
/*     */       FVector fVector = (FVector)this.data.getElement(b);
/*     */       fVector.insertElementAt(fVector.getElement(paramInt1), paramInt2);
/*     */       fVector.removeElementAt((paramInt2 > paramInt1) ? paramInt1 : (paramInt1 + 1));
/*     */     } 
/*     */     this.colInfo.insertElementAt(this.colInfo.getElement(paramInt1), paramInt2);
/*     */     this.colInfo.removeElementAt((paramInt2 > paramInt1) ? paramInt1 : ++paramInt1);
/*     */   }
/*     */   
/*     */   public int getRowCount() { return this.nrow; }
/*     */   
/*     */   public void setRowCount(int paramInt) {
/*     */     if (paramInt > this.nrow) {
/*     */       insertRow(this.nrow, paramInt - this.nrow);
/*     */     } else {
/*     */       removeRow(paramInt, this.nrow - paramInt);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getColCount() { return this.ncol; }
/*     */   
/*     */   public void setColCount(int paramInt) {
/*     */     if (paramInt > this.ncol) {
/*     */       insertCol(this.ncol, paramInt - this.ncol);
/*     */     } else {
/*     */       removeCol(paramInt, this.ncol - paramInt);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2, boolean paramBoolean) {
/*     */     Object object = ((FVector)this.data.getElement(paramInt1)).getElement(paramInt2);
/*     */     if (object == null && paramBoolean && this.helper != null)
/*     */       setObject(paramInt1, paramInt2, object = this.helper.createObject()); 
/*     */     return object;
/*     */   }
/*     */   
/*     */   public void setObject(int paramInt1, int paramInt2, Object paramObject) { ((Vector)this.data.getElement(paramInt1)).setElementAt(paramObject, paramInt2); }
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*     */       Matrix matrix = (Matrix)super.clone();
/*     */       matrix.data = (FVector)this.data.clone();
/*     */       for (byte b = 0; b < this.data.size(); b++)
/*     */         matrix.data.setElementAt(((Vector)this.data.getElement(b)).clone(), b); 
/*     */       matrix.rowInfo = (FVector)this.rowInfo.clone();
/*     */       matrix.colInfo = (FVector)this.colInfo.clone();
/*     */       return matrix;
/*     */     } catch (Exception exception) {
/*     */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\internal\Matrix.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */