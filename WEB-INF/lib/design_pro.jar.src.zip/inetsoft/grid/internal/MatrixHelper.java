package inetsoft.grid.internal;

public interface MatrixHelper {
  Object createRowInfo();
  
  Object createColInfo();
  
  Object createObject();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\internal\MatrixHelper.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */