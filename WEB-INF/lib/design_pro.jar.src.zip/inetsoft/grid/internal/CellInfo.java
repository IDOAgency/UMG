package inetsoft.grid.internal;

import java.awt.Component;

public class CellInfo extends GridInfo {
  public Component component;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\internal\CellInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */