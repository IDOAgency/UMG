package inetsoft.grid.internal;

import inetsoft.grid.Grid;
import inetsoft.grid.GridCellEditor;
import inetsoft.grid.GridCellRenderer;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.io.Serializable;
import java.text.Format;

public class GridInfo implements Serializable {
  public Grid.Region span;
  
  public Integer align;
  
  public Font font;
  
  public Integer border;
  
  public Insets gap;
  
  public Boolean highlighted;
  
  public Color foreground;
  
  public Color background;
  
  public Boolean editable;
  
  public Boolean copiable;
  
  public Format format;
  
  public GridCellEditor editor;
  
  public GridCellRenderer renderer;
  
  public void reset() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\internal\GridInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */