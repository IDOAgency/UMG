/*    */ package inetsoft.grid.internal;
/*    */ 
/*    */ import javax.swing.JPopupMenu;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowInfo
/*    */   extends GridInfo
/*    */ {
/*    */   public Integer height;
/*    */   public Integer pheight;
/*    */   public boolean hiden;
/*    */   public boolean selected;
/*    */   public JPopupMenu menu;
/*    */   public int minheight;
/*    */   
/* 50 */   public void reset() { this.pheight = null; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\internal\RowInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */