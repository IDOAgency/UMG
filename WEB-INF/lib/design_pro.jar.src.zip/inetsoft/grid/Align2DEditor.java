package inetsoft.grid;

import java.beans.PropertyEditorSupport;

class Align2DEditor extends PropertyEditorSupport {
  public void setAsText(String paramString) {
    if (paramString.equals("FILL")) {
      setValue(new Integer(0));
    } else if (paramString.equals("LEFT_TOP")) {
      setValue(new Integer(9));
    } else if (paramString.equals("LEFT_CENTER")) {
      setValue(new Integer(17));
    } else if (paramString.equals("LEFT_BOTTOM")) {
      setValue(new Integer(33));
    } else if (paramString.equals("CENTER_TOP")) {
      setValue(new Integer(10));
    } else if (paramString.equals("CENTER_CENTER")) {
      setValue(new Integer(18));
    } else if (paramString.equals("CENTER_BOTTOM")) {
      setValue(new Integer(34));
    } else if (paramString.equals("RIGHT_TOP")) {
      setValue(new Integer(12));
    } else if (paramString.equals("RIGHT_CENTER")) {
      setValue(new Integer(20));
    } else if (paramString.equals("RIGHT_BOTTOM")) {
      setValue(new Integer(36));
    } 
  }
  
  public String[] getTags() { return new String[] { "FILL", "LEFT_TOP", "LEFT_CENTER", "LEFT_BOTTOM", "CENTER_TOP", "CENTER_CENTER", "CENTER_BOTTOM", "RIGHT_TOP", "RIGHT_CENTER", "RIGHT_BOTTOM" }; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\Align2DEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */