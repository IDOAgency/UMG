/*    */ package inetsoft.grid;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Align2DEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String paramString) {
/* 30 */     if (paramString.equals("FILL")) {
/* 31 */       setValue(new Integer(0));
/*    */     }
/* 33 */     else if (paramString.equals("LEFT_TOP")) {
/* 34 */       setValue(new Integer(9));
/*    */     }
/* 36 */     else if (paramString.equals("LEFT_CENTER")) {
/* 37 */       setValue(new Integer(17));
/*    */     }
/* 39 */     else if (paramString.equals("LEFT_BOTTOM")) {
/* 40 */       setValue(new Integer(33));
/*    */     }
/* 42 */     else if (paramString.equals("CENTER_TOP")) {
/* 43 */       setValue(new Integer(10));
/*    */     }
/* 45 */     else if (paramString.equals("CENTER_CENTER")) {
/* 46 */       setValue(new Integer(18));
/*    */     }
/* 48 */     else if (paramString.equals("CENTER_BOTTOM")) {
/* 49 */       setValue(new Integer(34));
/*    */     }
/* 51 */     else if (paramString.equals("RIGHT_TOP")) {
/* 52 */       setValue(new Integer(12));
/*    */     }
/* 54 */     else if (paramString.equals("RIGHT_CENTER")) {
/* 55 */       setValue(new Integer(20));
/*    */     }
/* 57 */     else if (paramString.equals("RIGHT_BOTTOM")) {
/* 58 */       setValue(new Integer(36));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   public String[] getTags() { return new String[] { "FILL", "LEFT_TOP", "LEFT_CENTER", "LEFT_BOTTOM", "CENTER_TOP", "CENTER_CENTER", "CENTER_BOTTOM", "RIGHT_TOP", "RIGHT_CENTER", "RIGHT_BOTTOM" }; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\Align2DEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */