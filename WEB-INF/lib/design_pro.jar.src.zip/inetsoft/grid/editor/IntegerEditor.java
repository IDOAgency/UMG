/*    */ package inetsoft.grid.editor;
/*    */ 
/*    */ import inetsoft.grid.GridCellEditor;
/*    */ import inetsoft.widget.Spinner;
/*    */ import java.awt.event.ActionListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerEditor
/*    */   extends Spinner
/*    */   implements GridCellEditor
/*    */ {
/*    */   private int row;
/*    */   private int col;
/*    */   
/*    */   public IntegerEditor() {}
/*    */   
/* 39 */   public IntegerEditor(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
/* 49 */     this.row = paramInt1;
/* 50 */     this.col = paramInt2;
/* 51 */     setCurrent((paramObject instanceof Number) ? ((Number)paramObject).intValue() : 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   public Object getCellEditorValue() { return new Integer(getCurrent()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 66 */   public void addActionListener(ActionListener paramActionListener) { super.addActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 73 */   public void removeActionListener(ActionListener paramActionListener) { super.removeActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 80 */   public int getRow() { return this.row; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 87 */   public int getCol() { return this.col; }
/*    */ 
/*    */ 
/*    */   
/* 91 */   public boolean isManagingFocus() { return true; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\IntegerEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */