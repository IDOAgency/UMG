/*     */ package inetsoft.grid.editor;
/*     */ 
/*     */ import inetsoft.grid.GridCellEditor;
/*     */ import inetsoft.widget.DateCombo;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateEditor
/*     */   extends DateCombo
/*     */   implements GridCellEditor
/*     */ {
/*     */   private int row;
/*     */   private int col;
/*     */   
/*  33 */   public DateEditor() { this(DateFormat.getDateInstance()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public DateEditor(String paramString) { this(new SimpleDateFormat(paramString)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public DateEditor(DateFormat paramDateFormat) { setFormat(paramDateFormat); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
/*  60 */     this.row = paramInt1;
/*  61 */     this.col = paramInt2;
/*  62 */     setDate((Date)paramObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public Object getCellEditorValue() { return getDate(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public void addActionListener(ActionListener paramActionListener) { super.addActionListener(paramActionListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public void removeActionListener(ActionListener paramActionListener) { super.removeActionListener(paramActionListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public int getRow() { return this.row; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public int getCol() { return this.col; }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public boolean isManagingFocus() { return true; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\DateEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */