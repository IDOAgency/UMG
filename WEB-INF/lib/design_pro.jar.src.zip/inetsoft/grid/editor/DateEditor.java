package inetsoft.grid.editor;

import inetsoft.grid.GridCellEditor;
import inetsoft.widget.DateCombo;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateEditor extends DateCombo implements GridCellEditor {
  private int row;
  
  private int col;
  
  public DateEditor() { this(DateFormat.getDateInstance()); }
  
  public DateEditor(String paramString) { this(new SimpleDateFormat(paramString)); }
  
  public DateEditor(DateFormat paramDateFormat) { setFormat(paramDateFormat); }
  
  public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
    this.row = paramInt1;
    this.col = paramInt2;
    setDate((Date)paramObject);
  }
  
  public Object getCellEditorValue() { return getDate(); }
  
  public void addActionListener(ActionListener paramActionListener) { super.addActionListener(paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { super.removeActionListener(paramActionListener); }
  
  public int getRow() { return this.row; }
  
  public int getCol() { return this.col; }
  
  public boolean isManagingFocus() { return true; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\DateEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */