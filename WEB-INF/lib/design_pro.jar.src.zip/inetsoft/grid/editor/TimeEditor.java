/*    */ package inetsoft.grid.editor;
/*    */ 
/*    */ import inetsoft.grid.GridCellEditor;
/*    */ import inetsoft.widget.TimeSpinner;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TimeEditor
/*    */   extends TimeSpinner
/*    */   implements GridCellEditor
/*    */ {
/*    */   private int row;
/*    */   private int col;
/*    */   
/*    */   public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
/* 35 */     this.row = paramInt1;
/* 36 */     this.col = paramInt2;
/* 37 */     setDate((Date)paramObject);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public Object getCellEditorValue() { return getDate(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 51 */   public void addActionListener(ActionListener paramActionListener) { super.addActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 58 */   public void removeActionListener(ActionListener paramActionListener) { super.removeActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   public int getRow() { return this.row; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   public int getCol() { return this.col; }
/*    */ 
/*    */ 
/*    */   
/* 76 */   public boolean isManagingFocus() { return true; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\TimeEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */