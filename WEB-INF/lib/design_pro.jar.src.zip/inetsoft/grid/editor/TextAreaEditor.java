/*    */ package inetsoft.grid.editor;
/*    */ 
/*    */ import inetsoft.grid.GridCellEditor;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JTextArea;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextAreaEditor
/*    */   extends JTextArea
/*    */   implements GridCellEditor
/*    */ {
/*    */   private int row;
/*    */   private int col;
/*    */   
/*    */   public TextAreaEditor() {
/* 33 */     setLineWrap(true);
/* 34 */     setWrapStyleWord(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TextAreaEditor(int paramInt1, int paramInt2) {
/* 43 */     super(paramInt1, paramInt2);
/* 44 */     setLineWrap(true);
/* 45 */     setWrapStyleWord(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
/* 55 */     this.row = paramInt1;
/* 56 */     this.col = paramInt2;
/* 57 */     setText((paramObject == null) ? "" : paramObject.toString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public Object getCellEditorValue() { return getText(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addActionListener(ActionListener paramActionListener) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeActionListener(ActionListener paramActionListener) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 83 */   public int getRow() { return this.row; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 90 */   public int getCol() { return this.col; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\TextAreaEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */