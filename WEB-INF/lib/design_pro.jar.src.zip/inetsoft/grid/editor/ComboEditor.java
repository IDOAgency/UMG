/*    */ package inetsoft.grid.editor;
/*    */ 
/*    */ import inetsoft.grid.GridCellEditor;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JComboBox;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComboEditor
/*    */   extends JComboBox
/*    */   implements GridCellEditor
/*    */ {
/*    */   private int row;
/*    */   private int col;
/*    */   
/* 29 */   public ComboEditor(Object[] paramArrayOfObject) { super(paramArrayOfObject); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
/* 39 */     this.row = paramInt1;
/* 40 */     this.col = paramInt2;
/* 41 */     setSelectedItem(paramObject);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getCellEditorValue() {
/* 48 */     String str = (String)getEditor().getItem();
/* 49 */     return (str == null || str.length() == 0) ? getSelectedItem() : str;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   public void addActionListener(ActionListener paramActionListener) { super.addActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 63 */   public void removeActionListener(ActionListener paramActionListener) { super.removeActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   public int getRow() { return this.row; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   public int getCol() { return this.col; }
/*    */ 
/*    */ 
/*    */   
/* 81 */   public boolean isManagingFocus() { return true; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\ComboEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */