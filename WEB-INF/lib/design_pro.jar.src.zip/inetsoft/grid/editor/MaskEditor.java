package inetsoft.grid.editor;

import inetsoft.grid.GridCellEditor;
import inetsoft.widget.MaskEdit;

public class MaskEditor extends MaskEdit implements GridCellEditor {
  private int row;
  
  private int col;
  
  public MaskEditor() { this(null); }
  
  public MaskEditor(String paramString) { super(paramString); }
  
  public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
    this.row = paramInt1;
    this.col = paramInt2;
    setText((paramObject == null) ? "" : paramObject.toString());
  }
  
  public Object getCellEditorValue() { return getText(); }
  
  public int getRow() { return this.row; }
  
  public int getCol() { return this.col; }
  
  public boolean isManagingFocus() { return true; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\MaskEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */