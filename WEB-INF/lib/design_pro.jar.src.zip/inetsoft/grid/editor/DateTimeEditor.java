/*    */ package inetsoft.grid.editor;
/*    */ 
/*    */ import inetsoft.grid.GridCellEditor;
/*    */ import inetsoft.widget.DateTimeCombo;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.text.DateFormat;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateTimeEditor
/*    */   extends DateTimeCombo
/*    */   implements GridCellEditor
/*    */ {
/*    */   private int row;
/*    */   private int col;
/*    */   
/* 36 */   public DateTimeEditor(String paramString) { this(new SimpleDateFormat(paramString)); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public DateTimeEditor(DateFormat paramDateFormat) { setFormat(paramDateFormat); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
/* 54 */     this.row = paramInt1;
/* 55 */     this.col = paramInt2;
/* 56 */     setDate((Date)paramObject);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 63 */   public Object getCellEditorValue() { return getDate(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   public void addActionListener(ActionListener paramActionListener) { super.addActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   public void removeActionListener(ActionListener paramActionListener) { super.removeActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 84 */   public int getRow() { return this.row; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 91 */   public int getCol() { return this.col; }
/*    */ 
/*    */ 
/*    */   
/* 95 */   public boolean isManagingFocus() { return true; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\DateTimeEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */