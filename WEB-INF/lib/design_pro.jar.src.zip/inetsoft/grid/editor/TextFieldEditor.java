/*    */ package inetsoft.grid.editor;
/*    */ 
/*    */ import inetsoft.grid.GridCellEditor;
/*    */ import java.text.Format;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextFieldEditor
/*    */   extends JTextField
/*    */   implements GridCellEditor
/*    */ {
/*    */   Format format;
/*    */   private int row;
/*    */   private int col;
/*    */   
/* 32 */   public TextFieldEditor() { this(null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public TextFieldEditor(Format paramFormat) { this.format = paramFormat; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
/* 51 */     this.row = paramInt1;
/* 52 */     this.col = paramInt2;
/* 53 */     setText(toString(paramObject));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getCellEditorValue() {
/*    */     try {
/* 61 */       return this.format.parseObject(getText());
/*    */     } catch (Exception exception) {
/* 63 */       return getText();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public void setFormat(Format paramFormat) { this.format = paramFormat; }
/*    */ 
/*    */ 
/*    */   
/* 75 */   String toString(Object paramObject) { return (paramObject == null) ? "" : ((this.format != null) ? this.format.format(paramObject) : paramObject.toString()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 85 */   public int getRow() { return this.row; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 92 */   public int getCol() { return this.col; }
/*    */ 
/*    */ 
/*    */   
/* 96 */   public boolean isManagingFocus() { return true; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\TextFieldEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */