package inetsoft.grid.editor;

import inetsoft.grid.GridCellEditor;
import java.text.Format;
import javax.swing.JTextField;

public class TextFieldEditor extends JTextField implements GridCellEditor {
  Format format;
  
  private int row;
  
  private int col;
  
  public TextFieldEditor() { this(null); }
  
  public TextFieldEditor(Format paramFormat) { this.format = paramFormat; }
  
  public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
    this.row = paramInt1;
    this.col = paramInt2;
    setText(toString(paramObject));
  }
  
  public Object getCellEditorValue() {
    try {
      return this.format.parseObject(getText());
    } catch (Exception exception) {
      return getText();
    } 
  }
  
  public void setFormat(Format paramFormat) { this.format = paramFormat; }
  
  String toString(Object paramObject) { return (paramObject == null) ? "" : ((this.format != null) ? this.format.format(paramObject) : paramObject.toString()); }
  
  public int getRow() { return this.row; }
  
  public int getCol() { return this.col; }
  
  public boolean isManagingFocus() { return true; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\TextFieldEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */