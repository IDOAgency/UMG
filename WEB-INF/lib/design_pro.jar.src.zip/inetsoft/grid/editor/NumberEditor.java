package inetsoft.grid.editor;

import inetsoft.grid.GridCellEditor;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import javax.swing.JTextField;

public class NumberEditor extends JTextField implements GridCellEditor {
  private int row;
  
  private int col;
  
  public void setFormat(NumberFormat paramNumberFormat) { this.format = paramNumberFormat; }
  
  public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
    this.row = paramInt1;
    this.col = paramInt2;
    setText(this.format.format(paramObject));
  }
  
  public Object getCellEditorValue() {
    try {
      return this.format.parse(getText());
    } catch (Exception exception) {
      return Double.valueOf(getText());
    } 
  }
  
  public void addActionListener(ActionListener paramActionListener) { super.addActionListener(paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { super.removeActionListener(paramActionListener); }
  
  public int getRow() { return this.row; }
  
  public int getCol() { return this.col; }
  
  public boolean isManagingFocus() { return true; }
  
  private NumberFormat format = NumberFormat.getInstance();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\NumberEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */