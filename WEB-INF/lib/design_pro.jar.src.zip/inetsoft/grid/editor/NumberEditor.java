/*    */ package inetsoft.grid.editor;
/*    */ 
/*    */ import inetsoft.grid.GridCellEditor;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.text.NumberFormat;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NumberEditor
/*    */   extends JTextField
/*    */   implements GridCellEditor
/*    */ {
/*    */   private int row;
/*    */   private int col;
/*    */   
/* 38 */   public void setFormat(NumberFormat paramNumberFormat) { this.format = paramNumberFormat; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setCellValue(int paramInt1, int paramInt2, Object paramObject) {
/* 48 */     this.row = paramInt1;
/* 49 */     this.col = paramInt2;
/* 50 */     setText(this.format.format(paramObject));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getCellEditorValue() {
/*    */     try {
/* 58 */       return this.format.parse(getText());
/*    */     } catch (Exception exception) {
/* 60 */       return Double.valueOf(getText());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   public void addActionListener(ActionListener paramActionListener) { super.addActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 75 */   public void removeActionListener(ActionListener paramActionListener) { super.removeActionListener(paramActionListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public int getRow() { return this.row; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 89 */   public int getCol() { return this.col; }
/*    */ 
/*    */ 
/*    */   
/* 93 */   public boolean isManagingFocus() { return true; }
/*    */ 
/*    */ 
/*    */   
/* 97 */   private NumberFormat format = NumberFormat.getInstance();
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\editor\NumberEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */