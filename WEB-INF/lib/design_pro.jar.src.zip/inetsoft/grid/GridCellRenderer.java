package inetsoft.grid;

public interface GridCellRenderer {
  void setCellValue(int paramInt1, int paramInt2, Object paramObject);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\GridCellRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */