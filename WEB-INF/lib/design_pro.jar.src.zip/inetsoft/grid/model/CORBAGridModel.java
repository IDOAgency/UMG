package inetsoft.grid.model;

import java.lang.reflect.Field;
import java.util.Hashtable;
import java.util.Vector;

public class CORBAGridModel extends AbstractGridModel {
  Object[] data;
  
  Field[] fields;
  
  public CORBAGridModel(Vector paramVector) {
    Object[] arrayOfObject = new Object[paramVector.size()];
    paramVector.copyInto(arrayOfObject);
    init(arrayOfObject);
  }
  
  public CORBAGridModel(Object[] paramArrayOfObject) { init(paramArrayOfObject); }
  
  public void setColumns(int[] paramArrayOfInt) { this.columns = paramArrayOfInt; }
  
  public int[] getColumns() { return this.columns; }
  
  public void addNameMapping(String paramString1, String paramString2) { this.namemap.put(paramString1, paramString2); }
  
  public String getName(String paramString) {
    String str = (String)this.namemap.get(paramString);
    return (str == null) ? paramString : str;
  }
  
  private void init(Object[] paramArrayOfObject) {
    this.data = paramArrayOfObject;
    this.fields = paramArrayOfObject.getClass().getComponentType().getFields();
    if (this.columns == null) {
      this.columns = new int[this.fields.length];
      for (byte b = 0; b < this.columns.length; b++)
        this.columns[b] = b; 
    } 
  }
  
  public int getRowCount() { return this.data.length; }
  
  public int getColCount() { return this.columns.length; }
  
  public int getHeaderRowCount() { return 1; }
  
  public int getHeaderColCount() { return 0; }
  
  public Object getColHeader(int paramInt1, int paramInt2) { return getName(this.fields[this.columns[paramInt2]].getName()); }
  
  public Object getValue(int paramInt1, int paramInt2) {
    try {
      if (this.data[paramInt1] == null)
        load(paramInt1); 
      return (this.data[paramInt1] == null) ? null : this.fields[this.columns[paramInt2]].get(this.data[paramInt1]);
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public void setObject(int paramInt1, int paramInt2, Object paramObject) {
    try {
      if (this.data[paramInt1] == null)
        load(paramInt1); 
      if (this.data[paramInt1] != null) {
        this.fields[this.columns[paramInt2]].set(this.data[paramInt1], paramObject);
        fireGridModelEvent(1, paramInt1, paramInt2, 1, 1);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  protected void load(int paramInt) {}
  
  protected void setData(int paramInt, Object paramObject) { this.data[paramInt] = paramObject; }
  
  protected Object getData(int paramInt) { return this.data[paramInt]; }
  
  Hashtable namemap = new Hashtable();
  
  int[] columns;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\model\CORBAGridModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */