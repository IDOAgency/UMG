/*     */ package inetsoft.grid.model;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CORBAGridModel
/*     */   extends AbstractGridModel
/*     */ {
/*     */   Object[] data;
/*     */   Field[] fields;
/*     */   
/*     */   public CORBAGridModel(Vector paramVector) {
/*  51 */     Object[] arrayOfObject = new Object[paramVector.size()];
/*  52 */     paramVector.copyInto(arrayOfObject);
/*  53 */     init(arrayOfObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public CORBAGridModel(Object[] paramArrayOfObject) { init(paramArrayOfObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public void setColumns(int[] paramArrayOfInt) { this.columns = paramArrayOfInt; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public int[] getColumns() { return this.columns; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public void addNameMapping(String paramString1, String paramString2) { this.namemap.put(paramString1, paramString2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName(String paramString) {
/*  97 */     String str = (String)this.namemap.get(paramString);
/*  98 */     return (str == null) ? paramString : str;
/*     */   }
/*     */ 
/*     */   
/*     */   private void init(Object[] paramArrayOfObject) {
/* 103 */     this.data = paramArrayOfObject;
/* 104 */     this.fields = paramArrayOfObject.getClass().getComponentType().getFields();
/*     */     
/* 106 */     if (this.columns == null) {
/* 107 */       this.columns = new int[this.fields.length];
/*     */       
/* 109 */       for (byte b = 0; b < this.columns.length; b++) {
/* 110 */         this.columns[b] = b;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public int getRowCount() { return this.data.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public int getColCount() { return this.columns.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public int getHeaderRowCount() { return 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public int getHeaderColCount() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public Object getColHeader(int paramInt1, int paramInt2) { return getName(this.fields[this.columns[paramInt2]].getName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(int paramInt1, int paramInt2) {
/*     */     try {
/* 163 */       if (this.data[paramInt1] == null) {
/* 164 */         load(paramInt1);
/*     */       }
/*     */       
/* 167 */       return (this.data[paramInt1] == null) ? null : this.fields[this.columns[paramInt2]].get(this.data[paramInt1]);
/*     */     } catch (Exception exception) {
/* 169 */       exception.printStackTrace();
/*     */ 
/*     */       
/* 172 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObject(int paramInt1, int paramInt2, Object paramObject) {
/*     */     try {
/* 183 */       if (this.data[paramInt1] == null) {
/* 184 */         load(paramInt1);
/*     */       }
/*     */       
/* 187 */       if (this.data[paramInt1] != null) {
/* 188 */         this.fields[this.columns[paramInt2]].set(this.data[paramInt1], paramObject);
/* 189 */         fireGridModelEvent(1, paramInt1, paramInt2, 1, 1);
/*     */       } 
/*     */     } catch (Exception exception) {
/* 192 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void load(int paramInt) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   protected void setData(int paramInt, Object paramObject) { this.data[paramInt] = paramObject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 220 */   protected Object getData(int paramInt) { return this.data[paramInt]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   Hashtable namemap = new Hashtable();
/*     */   int[] columns;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\model\CORBAGridModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */