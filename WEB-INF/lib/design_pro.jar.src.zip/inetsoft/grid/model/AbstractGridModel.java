/*     */ package inetsoft.grid.model;
/*     */ 
/*     */ import inetsoft.grid.event.GridModelEvent;
/*     */ import inetsoft.grid.event.GridModelListener;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractGridModel
/*     */   implements GridModel
/*     */ {
/*     */   public abstract int getRowCount();
/*     */   
/*     */   public abstract int getColCount();
/*     */   
/*  59 */   protected Object getValue(int paramInt1, int paramInt2) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/*  73 */     if (paramInt1 <= -1) {
/*  74 */       return getColHeader(paramInt1 + getHeaderRowCount(), paramInt2);
/*     */     }
/*  76 */     if (paramInt2 <= -1) {
/*  77 */       return getRowHeader(paramInt1, paramInt2 + getHeaderColCount());
/*     */     }
/*     */     
/*  80 */     return getValue(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   protected Object getColHeader(int paramInt1, int paramInt2) { return new Character((char)(65 + paramInt2 % 26)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   protected Object getRowHeader(int paramInt1, int paramInt2) { return new Integer(paramInt1 + 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObject(int paramInt1, int paramInt2, Object paramObject) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public int getHeaderRowCount() { return 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public int getHeaderColCount() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public int headerR(int paramInt) { return paramInt - getHeaderRowCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public int headerC(int paramInt) { return paramInt - getHeaderColCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public void addGridModelListener(GridModelListener paramGridModelListener) { this.listeners.addElement(paramGridModelListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public void removeGridModelListener(GridModelListener paramGridModelListener) { this.listeners.removeElement(paramGridModelListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireGridModelEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*     */     try {
/* 188 */       Vector vector = (Vector)this.listeners.clone();
/* 189 */       GridModelEvent gridModelEvent = new GridModelEvent(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */       
/* 191 */       for (int i = vector.size() - 1; i >= 0; i--) {
/* 192 */         ((GridModelListener)vector.elementAt(i)).valueChanged(gridModelEvent);
/*     */       }
/*     */     } catch (Exception exception) {
/* 195 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/* 199 */   private Vector listeners = new Vector();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\model\AbstractGridModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */