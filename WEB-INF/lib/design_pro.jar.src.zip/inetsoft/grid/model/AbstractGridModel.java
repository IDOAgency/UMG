package inetsoft.grid.model;

import inetsoft.grid.event.GridModelEvent;
import inetsoft.grid.event.GridModelListener;
import java.util.Vector;

public abstract class AbstractGridModel implements GridModel {
  public abstract int getRowCount();
  
  public abstract int getColCount();
  
  protected Object getValue(int paramInt1, int paramInt2) { return null; }
  
  public Object getObject(int paramInt1, int paramInt2) {
    if (paramInt1 <= -1)
      return getColHeader(paramInt1 + getHeaderRowCount(), paramInt2); 
    if (paramInt2 <= -1)
      return getRowHeader(paramInt1, paramInt2 + getHeaderColCount()); 
    return getValue(paramInt1, paramInt2);
  }
  
  protected Object getColHeader(int paramInt1, int paramInt2) { return new Character((char)(65 + paramInt2 % 26)); }
  
  protected Object getRowHeader(int paramInt1, int paramInt2) { return new Integer(paramInt1 + 1); }
  
  public void setObject(int paramInt1, int paramInt2, Object paramObject) {}
  
  public int getHeaderRowCount() { return 1; }
  
  public int getHeaderColCount() { return 0; }
  
  public int headerR(int paramInt) { return paramInt - getHeaderRowCount(); }
  
  public int headerC(int paramInt) { return paramInt - getHeaderColCount(); }
  
  public void addGridModelListener(GridModelListener paramGridModelListener) { this.listeners.addElement(paramGridModelListener); }
  
  public void removeGridModelListener(GridModelListener paramGridModelListener) { this.listeners.removeElement(paramGridModelListener); }
  
  public void fireGridModelEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    try {
      Vector vector = (Vector)this.listeners.clone();
      GridModelEvent gridModelEvent = new GridModelEvent(this, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      for (int i = vector.size() - 1; i >= 0; i--)
        ((GridModelListener)vector.elementAt(i)).valueChanged(gridModelEvent); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  private Vector listeners = new Vector();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\model\AbstractGridModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */