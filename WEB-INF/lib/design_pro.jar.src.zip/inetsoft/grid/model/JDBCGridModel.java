/*     */ package inetsoft.grid.model;
/*     */ 
/*     */ import inetsoft.util.internal.FVector;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCGridModel
/*     */   extends AbstractGridModel
/*     */ {
/*     */   private ResultSet result;
/*     */   private int nrow;
/*     */   private int ncol;
/*     */   private boolean more;
/*     */   private int last;
/*     */   private FVector rows;
/*     */   
/*     */   public JDBCGridModel(ResultSet paramResultSet) throws SQLException {
/* 127 */     this.more = true;
/* 128 */     this.last = 0;
/* 129 */     this.rows = new FVector();
/*     */     this.result = paramResultSet;
/*     */     ResultSetMetaData resultSetMetaData = paramResultSet.getMetaData();
/*     */     this.ncol = resultSetMetaData.getColumnCount();
/*     */     for (byte b = 0; b < this.ncol; b++)
/*     */       setObject(-1, b, resultSetMetaData.getColumnLabel(b + true)); 
/*     */     fetch();
/*     */   }
/*     */   
/*     */   public int getRowCount() { return this.nrow = this.more ? ((int)(this.last * 1.2D) + 100) : this.last; }
/*     */   
/*     */   public int getColCount() { return this.ncol; }
/*     */   
/*     */   public Object getObject(int paramInt1, int paramInt2) {
/*     */     if (paramInt1 >= this.last)
/*     */       fetch(); 
/*     */     int i = paramInt1 + getHeaderRowCount();
/*     */     return (i < this.rows.size()) ? ((FVector)this.rows.getElement(i)).getElement(paramInt2) : null;
/*     */   }
/*     */   
/*     */   public void setObject(int paramInt1, int paramInt2, Object paramObject) {
/*     */     int i = paramInt1 + getHeaderRowCount();
/*     */     if (i >= this.rows.size())
/*     */       this.rows.setSize(i + 1); 
/*     */     FVector fVector = (FVector)this.rows.getElement(i);
/*     */     if (fVector == null)
/*     */       this.rows.setElementAt(fVector = new FVector(), i); 
/*     */     if (paramInt2 >= fVector.size())
/*     */       fVector.setSize(paramInt2 + 1); 
/*     */     fVector.setElementAt(paramObject, paramInt2);
/*     */   }
/*     */   
/*     */   private void fetch() {
/*     */     try {
/*     */       for (byte b = 0; (this.more = this.result.next()) && b < 50; b++) {
/*     */         for (byte b1 = 0; b1 < this.ncol; b1++)
/*     */           setObject(this.last, b1, this.result.getObject(b1 + true)); 
/*     */         this.last++;
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */     } 
/*     */     int i = this.nrow;
/*     */     int j = getRowCount();
/*     */     if (j > i) {
/*     */       fireGridModelEvent(16, i, -1, j - i, -1);
/*     */     } else if (j < i) {
/*     */       fireGridModelEvent(32, j, -1, i - j, -1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\model\JDBCGridModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */