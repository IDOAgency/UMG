package inetsoft.grid.model;

import inetsoft.util.internal.FVector;
import java.util.Vector;

public class DefaultGridModel extends AbstractGridModel {
  private FVector data;
  
  private int nrow;
  
  private int ncol;
  
  private int hrow;
  
  private int hcol;
  
  public DefaultGridModel(int paramInt1, int paramInt2) {
    this.data = new FVector();
    this.nrow = paramInt1;
    this.ncol = paramInt2;
    this.data.setSize(paramInt1);
    for (byte b = 0; b < this.data.size(); b++) {
      FVector fVector = new FVector();
      fVector.setSize(paramInt2);
      this.data.setElementAt(fVector, b);
    } 
  }
  
  public void insertRow(int paramInt1, int paramInt2) {
    boolean bool = (paramInt1 <= -1) ? 1 : 0;
    if (bool && this.hrow == 0)
      paramInt1 = 0; 
    for (byte b = 0; b < paramInt2; b++) {
      FVector fVector = new FVector();
      fVector.setSize(this.ncol + this.hcol);
      this.data.insertElementAt(fVector, paramInt1 + this.hrow);
    } 
    if (bool) {
      this.hrow += paramInt2;
    } else {
      this.nrow += paramInt2;
    } 
    fireGridModelEvent(16, paramInt1, -1, paramInt2, 0);
  }
  
  public void removeRow(int paramInt1, int paramInt2) {
    for (byte b = 0; b < paramInt2; b++)
      this.data.removeElementAt(paramInt1 + this.hrow); 
    if (paramInt1 <= -1) {
      this.hrow -= paramInt2;
    } else {
      this.nrow -= paramInt2;
    } 
    fireGridModelEvent(32, paramInt1, -1, paramInt2, 0);
  }
  
  public void insertCol(int paramInt1, int paramInt2) {
    boolean bool = (paramInt1 <= -1) ? 1 : 0;
    if (bool && this.hcol == 0)
      paramInt1 = 0; 
    for (byte b = 0; b < this.data.size(); b++) {
      Vector vector = (Vector)this.data.getElement(b);
      for (byte b1 = 0; b1 < paramInt2; b1++)
        vector.insertElementAt(null, paramInt1 + this.hcol); 
    } 
    if (bool) {
      this.hcol += paramInt2;
    } else {
      this.ncol += paramInt2;
    } 
    fireGridModelEvent(48, -1, paramInt1, -1, paramInt2);
  }
  
  public void removeCol(int paramInt1, int paramInt2) {
    for (byte b = 0; b < this.data.size(); b++) {
      Vector vector = (Vector)this.data.getElement(b);
      for (byte b1 = 0; b1 < paramInt2; b1++)
        vector.removeElementAt(paramInt1 + this.hcol); 
    } 
    if (paramInt1 <= -1) {
      this.hcol -= paramInt2;
    } else {
      this.ncol -= paramInt2;
    } 
    fireGridModelEvent(64, -1, paramInt1, -1, paramInt2);
  }
  
  public int getRowCount() { return this.nrow; }
  
  public void setRowCount(int paramInt) {
    if (paramInt > this.nrow) {
      insertRow(this.nrow, paramInt - this.nrow);
    } else {
      removeRow(paramInt, this.nrow - paramInt);
    } 
  }
  
  public int getColCount() { return this.ncol; }
  
  public void setColCount(int paramInt) {
    if (paramInt > this.ncol) {
      insertCol(this.ncol, paramInt - this.ncol);
    } else {
      removeCol(paramInt, this.ncol - paramInt);
    } 
  }
  
  public int getHeaderRowCount() { return this.hrow; }
  
  public void setHeaderRowCount(int paramInt) {
    if (paramInt > this.hrow) {
      insertRow(-1, paramInt - this.hrow);
    } else {
      removeRow(-paramInt, this.hrow - paramInt);
    } 
  }
  
  public int getHeaderColCount() { return this.hcol; }
  
  public void setHeaderColCount(int paramInt) {
    if (paramInt > this.hcol) {
      insertCol(-1, paramInt - this.hcol);
    } else {
      removeCol(-paramInt, this.hcol - paramInt);
    } 
  }
  
  public Object getObject(int paramInt1, int paramInt2) { return ((FVector)this.data.getElement(paramInt1 + this.hrow)).getElement(paramInt2 + this.hcol); }
  
  public void setObject(int paramInt1, int paramInt2, Object paramObject) {
    ((Vector)this.data.getElement(paramInt1 + this.hrow)).setElementAt(paramObject, paramInt2 + this.hcol);
    fireGridModelEvent(1, paramInt1, paramInt2, 1, 1);
  }
  
  public Object clone() {
    try {
      DefaultGridModel defaultGridModel = (DefaultGridModel)super.clone();
      defaultGridModel.data = (FVector)this.data.clone();
      for (byte b = 0; b < this.data.size(); b++)
        defaultGridModel.data.setElementAt(((Vector)this.data.getElement(b)).clone(), b); 
      return defaultGridModel;
    } catch (Exception exception) {
      return null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\model\DefaultGridModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */