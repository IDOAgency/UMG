package inetsoft.grid.model;

import inetsoft.grid.event.GridModelListener;
import java.io.Serializable;

public interface GridModel extends Serializable, Cloneable {
  int getRowCount();
  
  int getColCount();
  
  int getHeaderRowCount();
  
  int getHeaderColCount();
  
  Object getObject(int paramInt1, int paramInt2);
  
  void setObject(int paramInt1, int paramInt2, Object paramObject);
  
  void addGridModelListener(GridModelListener paramGridModelListener);
  
  void removeGridModelListener(GridModelListener paramGridModelListener);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\model\GridModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */