package inetsoft.grid;

import inetsoft.widget.Folder;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Hashtable;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JSplitPane;

public class MultiSheet extends Folder implements ScrollControl, ActionListener, AdjustmentListener {
  private Dimension oSize;
  
  ComponentListener viewListener;
  
  private JSplitPane splitpane;
  
  private JScrollBar vscroll;
  
  private JScrollBar hscroll;
  
  private Hashtable soptmap;
  
  private int scrollopt;
  
  private static final int scrollW = 15;
  
  public MultiSheet() {
    this.oSize = new Dimension(0, 0);
    this.viewListener = new ComponentAdapter(this) {
        private final MultiSheet this$0;
        
        public void componentResized(ComponentEvent param1ComponentEvent) { this.this$0.notifyUpdate((Component)param1ComponentEvent.getSource()); }
      };
    this.vscroll = new JScrollBar(1);
    this.hscroll = new JScrollBar(0);
    this.soptmap = new Hashtable();
    this.scrollopt = 5;
    setGaps(new Dimension(15, 0));
    super.setTabPlacement(2);
    setTabLayout(2);
    setManageComponent(false);
    ((Container)this.splitpane.getRightComponent()).setLayout(new BorderLayout());
    ((Container)this.splitpane.getRightComponent()).add(this.hscroll, "Center");
    addActionListener(this);
    this.vscroll.addAdjustmentListener(this);
    this.hscroll.addAdjustmentListener(this);
    add(this.vscroll);
  }
  
  public void add(Component paramComponent, Object paramObject) {
    if (paramComponent instanceof Scrollable) {
      ((Scrollable)paramComponent).registerScrollControl(this);
    } else {
      paramComponent.addComponentListener(this.viewListener);
    } 
    super.add(paramComponent, paramObject);
  }
  
  public void setTabPlacement(int paramInt) {}
  
  public void adjust(int paramInt1, int paramInt2) {
    JScrollBar jScrollBar = (paramInt1 == 2) ? this.hscroll : this.vscroll;
    if (jScrollBar == null)
      return; 
    adjustmentValueChanged(new AdjustmentEvent(jScrollBar, 601, paramInt2, jScrollBar.getValue()));
  }
  
  public int getScrollOption() { return this.scrollopt; }
  
  public void setScrollOption(int paramInt) { this.scrollopt = paramInt; }
  
  public int getScrollOption(String paramString) {
    Integer integer = (Integer)this.soptmap.get(paramString);
    return (integer == null) ? this.scrollopt : integer.intValue();
  }
  
  public void setScrollOption(String paramString, int paramInt) { this.soptmap.put(paramString, new Integer(paramInt)); }
  
  public void setUnitIncrement(int paramInt1, int paramInt2) {
    if (paramInt1 == 1) {
      this.vscroll.setUnitIncrement(paramInt2);
    } else {
      this.hscroll.setUnitIncrement(paramInt2);
    } 
  }
  
  public void setBlockIncrement(int paramInt1, int paramInt2) {
    if (paramInt1 == 1) {
      this.vscroll.setBlockIncrement(paramInt2);
    } else {
      this.hscroll.setBlockIncrement(paramInt2);
    } 
  }
  
  public void notifySync() {
    Component component = getCurrentComponent();
    if (component == null)
      return; 
    if (component instanceof Scrollable) {
      this.hscroll.setValue(((Scrollable)component).getValue(2));
      this.vscroll.setValue(((Scrollable)component).getValue(1));
    } else {
      this.hscroll.setValue(-(component.getLocation()).x);
      this.hscroll.setValue(-(component.getLocation()).y);
    } 
  }
  
  public void notifyUpdate() { notifyUpdate(null); }
  
  public void notifyUpdate(Component paramComponent) {
    Component component = getCurrentComponent();
    if (component == null)
      return; 
    for (; paramComponent != null && paramComponent != component; paramComponent = paramComponent.getParent());
    if (paramComponent != component)
      return; 
    if (component instanceof Scrollable) {
      Scrollable scrollable = (Scrollable)component;
      this.hscroll.setValues(scrollable.getValue(2), scrollable.getVisibleAmount(2), scrollable.getMinimum(2), scrollable.getMaximum(2));
      this.hscroll.setBlockIncrement(scrollable.getIncrement(2, 4));
      this.vscroll.setValues(scrollable.getValue(1), scrollable.getVisibleAmount(1), scrollable.getMinimum(1), scrollable.getMaximum(1));
      this.vscroll.setBlockIncrement(scrollable.getIncrement(1, 4));
    } else {
      Dimension dimension = component.getPreferredSize();
      Point point = component.getLocation();
      component.setBounds(point.x, point.y, dimension.width, dimension.height);
      component.validate();
      this.hscroll.setValues(-(component.getLocation()).x, (getPane().getSize()).width, 0, (component.getSize()).width);
      this.hscroll.setBlockIncrement(this.hscroll.getVisibleAmount());
      this.vscroll.setValues(-(component.getLocation()).y, (getPane().getSize()).height, 0, (component.getSize()).height);
      this.vscroll.setBlockIncrement(this.vscroll.getVisibleAmount());
    } 
  }
  
  public void doLayout() {
    super.doLayout();
    if (this.vscroll == null || this.hscroll == null)
      return; 
    this.vscroll.setBounds((getSize()).width - 15, 0, 15, (getSize()).height - (this.hscroll.getSize()).height);
    Dimension dimension = getPane().getSize();
    for (byte b = 0; b < getPageCount(); b++) {
      Component component = getPage(b);
      if (component instanceof Scrollable) {
        component.setBounds(0, 0, dimension.width, dimension.height);
      } else {
        Dimension dimension1 = component.getPreferredSize();
        int i = getScrollOption(getName(b));
        if ((i & 0x2) != 0)
          dimension1.width = dimension.width; 
        if ((i & 0x8) != 0)
          dimension1.height = dimension.height; 
        component.setBounds(0, 0, dimension1.width, dimension1.height);
      } 
      component.validate();
    } 
    dimension = getSize();
    if (this.oSize.width != dimension.width || this.oSize.height != dimension.height) {
      this.oSize = dimension;
      notifyUpdate();
    } 
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    Component component = getCurrentComponent();
    if (component != null && !(component instanceof Scrollable) && (component.getSize()).width == 0) {
      Dimension dimension = component.getPreferredSize();
      component.setBounds(0, 0, dimension.width, dimension.height);
      component.validate();
    } 
    notifyUpdate();
  }
  
  public void adjustmentValueChanged(AdjustmentEvent paramAdjustmentEvent) {
    Component component = getCurrentComponent();
    paramAdjustmentEvent.getAdjustable().setValue(paramAdjustmentEvent.getValue());
    int i = paramAdjustmentEvent.getAdjustable().getValue();
    if (component instanceof Scrollable) {
      if (paramAdjustmentEvent.getAdjustable() == this.vscroll) {
        ((Scrollable)component).setValue(1, i);
      } else {
        ((Scrollable)component).setValue(2, i);
      } 
    } else if (component != null) {
      Point point = component.getLocation();
      if (paramAdjustmentEvent.getAdjustable() == this.vscroll) {
        component.setLocation(point.x, -i);
      } else {
        component.setLocation(-i, point.y);
      } 
    } 
  }
  
  protected void layoutFolder() { super.layoutFolder(); }
  
  protected Container createTabPanel() {
    JPanel jPanel1 = new JPanel(this) {
        int dloc;
        
        private final MultiSheet this$0;
        
        public void paint(Graphics param1Graphics) {
          param1Graphics.setColor(getBackground().darker());
          param1Graphics.drawLine(0, 0, (getSize()).width, 0);
          super.paint(param1Graphics);
        }
        
        public void doLayout() {
          if (this.dloc != this.this$0.splitpane.getDividerLocation()) {
            this.dloc = this.this$0.splitpane.getDividerLocation();
            this.this$0.layoutFolder();
          } 
          super.doLayout();
        }
      };
    JPanel jPanel2 = new JPanel();
    jPanel1.setPreferredSize(new Dimension(250, 18));
    jPanel2.setPreferredSize(new Dimension(10, 18));
    this.splitpane = new JSplitPane(1, jPanel1, jPanel2);
    this.splitpane.setBorder(null);
    return this.splitpane;
  }
  
  protected Container getTabPanel(Container paramContainer) {
    if (paramContainer instanceof JSplitPane)
      return (Container)((JSplitPane)paramContainer).getLeftComponent(); 
    return paramContainer;
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.oSize = new Dimension(0, 0);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\MultiSheet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */