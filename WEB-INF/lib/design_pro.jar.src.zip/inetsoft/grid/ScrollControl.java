package inetsoft.grid;

import java.awt.Component;

public interface ScrollControl {
  public static final int HORIZONTAL = 2;
  
  public static final int VERTICAL = 1;
  
  public static final int H_SCROLL = 1;
  
  public static final int H_FILL = 2;
  
  public static final int V_SCROLL = 4;
  
  public static final int V_FILL = 8;
  
  void adjust(int paramInt1, int paramInt2);
  
  int getScrollOption();
  
  void setScrollOption(int paramInt);
  
  void setUnitIncrement(int paramInt1, int paramInt2);
  
  void setBlockIncrement(int paramInt1, int paramInt2);
  
  void notifySync();
  
  void notifyUpdate();
  
  void notifyUpdate(Component paramComponent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\ScrollControl.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */