package inetsoft.grid;

public interface Scrollable {
  public static final int VERTICAL = 1;
  
  public static final int HORIZONTAL = 2;
  
  public static final int BLOCK_DECREMENT = 3;
  
  public static final int BLOCK_INCREMENT = 4;
  
  public static final int UNIT_DECREMENT = 2;
  
  public static final int UNIT_INCREMENT = 1;
  
  void registerScrollControl(ScrollControl paramScrollControl);
  
  int getMinimum(int paramInt);
  
  int getMaximum(int paramInt);
  
  int getValue(int paramInt);
  
  int getVisibleAmount(int paramInt);
  
  int getIncrement(int paramInt1, int paramInt2);
  
  void setValue(int paramInt1, int paramInt2);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\Scrollable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */