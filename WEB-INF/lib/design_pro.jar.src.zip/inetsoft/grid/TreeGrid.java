package inetsoft.grid;

import inetsoft.grid.event.GridActionEvent;
import inetsoft.grid.event.GridItemEvent;
import inetsoft.grid.internal.GridBase;
import inetsoft.grid.model.DefaultGridModel;
import inetsoft.widget.STree;
import inetsoft.widget.util.EventMgr;
import inetsoft.widget.util.Tool;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.ItemSelectable;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.Format;
import java.util.Vector;
import javax.swing.Icon;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeCellEditor;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;

public class TreeGrid extends JPanel implements Scrollable, ItemListener, ActionListener, ItemSelectable {
  public static final int HORIZONTAL = 2;
  
  public static final int VERTICAL = 1;
  
  protected EventMgr eventMgr;
  
  Vector treeHlines;
  
  Vector treeVlines;
  
  GTree tree;
  
  TreePanel treePnl;
  
  private Component headerCell;
  
  DefaultGridModel tablemodel;
  
  Grid table;
  
  Pane pane;
  
  int rowH;
  
  JPanel leftPnl;
  
  Integer treeRule;
  
  String treeHeader;
  
  int treeWidth;
  
  boolean heightSet;
  
  public TreeGrid() {
    this.eventMgr = new EventMgr();
    this.treeHlines = new Vector();
    this.treeVlines = new Vector();
    this.tree = new GTree(this) {
        private final TreeGrid this$0;
        
        protected void sort(Vector param1Vector, boolean param1Boolean) {
          for (byte b = 1; b < param1Vector.size(); b++) {
            for (byte b1 = b; !b1; ) {
              GNode gNode1 = (GNode)param1Vector.elementAt(b1);
              GNode gNode2 = (GNode)param1Vector.elementAt(b1 - 1);
              int i = gNode1.compare(gNode2);
              if ((param1Boolean && i < 0) || (!param1Boolean && i > 0)) {
                param1Vector.setElementAt(gNode1, b1 - 1);
                param1Vector.setElementAt(gNode2, b1);
                this.this$0.table.moveRow(gNode1.getRowIndex(), gNode2.getRowIndex());
                int j = gNode1.getRowIndex();
                gNode1.setRowIndex(gNode2.getRowIndex());
                gNode2.setRowIndex(j);
                b1--;
              } 
              break;
            } 
          } 
        }
        
        public void paint(Graphics param1Graphics) {
          super.paint(param1Graphics);
          synchronized (this.this$0.getTreeLock()) {
            if (this.this$0.treeHlines == null || this.this$0.treeVlines == null) {
              this.this$0.table.validate();
              Rectangle rectangle = this.this$0.tree.getBounds();
              int[] arrayOfInt = this.this$0.table.getGridY();
              this.this$0.treeHlines = new Vector();
              this.this$0.treeVlines = new Vector();
              int i = arrayOfInt[this.this$0.table.getHeaderRowCount()];
              int j = arrayOfInt[arrayOfInt.length - 1] - i;
              int k = this.this$0.table.getBorder(-99, -99);
              int m = this.this$0.table.getLineStyle();
              int n = m & 0xF;
              if ((this.this$0.treeRule != null && (this.this$0.treeRule.intValue() & 0x2) != 0) || (this.this$0.treeRule == null && (k & 0x2) != 0))
                for (byte b = 0; b < arrayOfInt.length; b++) {
                  int i1 = arrayOfInt[b] - n - i;
                  if (i1 >= -rectangle.y)
                    this.this$0.treeHlines.addElement(new int[] { i1, rectangle.x, rectangle.x + rectangle.width, m }); 
                }  
              if ((this.this$0.treeRule != null && (this.this$0.treeRule.intValue() & true) != 0) || (this.this$0.treeRule == null && (k & true) != 0)) {
                Dimension dimension = getSize();
                int i1 = j - n;
                this.this$0.treeVlines.addElement(new int[] { dimension.width - n, 0, i1, m });
              } 
            } 
            Color color = this.this$0.table.getBorderColor();
            if (color == null) {
              color = this.this$0.getBackground();
              if ((this.this$0.table.getLineStyle() & 0x1000) != 0) {
                Color color1 = this.this$0.getForeground();
                color = new Color((color.getRed() + color1.getRed()) / 2, (color.getGreen() + color1.getGreen()) / 2, (color.getBlue() + color1.getBlue()) / 2);
              } 
            } 
            param1Graphics.setColor(color);
            for (byte b1 = 0; b1 < this.this$0.treeHlines.size(); b1++) {
              int[] arrayOfInt = (int[])this.this$0.treeHlines.elementAt(b1);
              Tool.drawHLine(param1Graphics, arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3]);
            } 
            for (byte b2 = 0; b2 < this.this$0.treeVlines.size(); b2++) {
              int[] arrayOfInt = (int[])this.this$0.treeVlines.elementAt(b2);
              Tool.drawVLine(param1Graphics, arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3]);
            } 
          } 
        }
      };
    this.treePnl = new TreePanel(this);
    this.headerCell = new Component(this) {
        private final TreeGrid this$0;
        
        public Dimension getPreferredSize() {
          int i = this.this$0.table.getBorder(-99, -99);
          int j = this.this$0.table.getLineStyle() & 0xF;
          int k = this.this$0.rowH + (((i & 0x2) != 0) ? j : 0);
          k *= this.this$0.table.getHeaderRowCount();
          Font font = getFont();
          if (font == null || this.this$0.treeHeader == null)
            return new Dimension(1, k); 
          int m = this.this$0.treeHeader.indexOf("\n");
          FontMetrics fontMetrics = getFontMetrics(font);
          return new Dimension(fontMetrics.stringWidth((m > 0) ? this.this$0.treeHeader.substring(0, m) : this.this$0.treeHeader) + 4, k);
        }
        
        public void paint(Graphics param1Graphics) {
          Dimension dimension = getSize();
          int i = dimension.height;
          int j = this.this$0.table.getBorder(-99, -99);
          int k = this.this$0.table.getLineStyle() & 0xF;
          Rectangle rectangle = new Rectangle(0, 0, dimension.width, dimension.height);
          Color color = this.this$0.table.getBorderColor();
          if (color == null) {
            color = this.this$0.table.getBackground(-1, 0);
            if ((this.this$0.table.getLineStyle() & 0x1000) != 0) {
              Color color1 = this.this$0.getForeground();
              color = new Color((color.getRed() + color1.getRed()) / 2, (color.getGreen() + color1.getGreen()) / 2, (color.getBlue() + color1.getBlue()) / 2);
            } 
          } 
          param1Graphics.setColor(color);
          if ((j & 0x2) != 0) {
            Tool.drawHLine(param1Graphics, rectangle.height, 0, dimension.width, this.this$0.table.getLineStyle());
            i -= k;
          } 
          if ((j & true) != 0)
            Tool.drawVLine(param1Graphics, rectangle.width, 0, i, this.this$0.table.getLineStyle()); 
          if (this.this$0.treeHeader != null) {
            param1Graphics.setColor(this.this$0.table.getForeground(-1, 0));
            GridBase.paintText(param1Graphics, this.this$0.treeHeader, rectangle, 18, this.this$0.table.isLineWrap());
          } 
          param1Graphics.setColor(this.this$0.table.getBackground(-1, 0));
          param1Graphics.draw3DRect(0, 0, rectangle.width - 1, rectangle.height - 1, true);
        }
      };
    this.tablemodel = new DefaultGridModel(0, 0);
    this.table = new Grid(this.tablemodel);
    this.pane = new Pane(this);
    this.rowH = 0;
    this.leftPnl = new JPanel();
    this.treeRule = null;
    this.treeHeader = null;
    this.treeWidth = 150;
    this.heightSet = false;
    setLayout(new BorderLayout());
    add(this.pane, "Center");
    this.pane.setLayout(null);
    this.leftPnl.setLayout(new BorderLayout());
    this.leftPnl.add(this.treePnl, "Center");
    this.pane.add(this.leftPnl);
    this.pane.add(this.table);
    this.table.setAbsolute(1);
    this.table.setRowSelectable(true);
    this.table.setResizable(2);
    this.table.setLineWrap(false);
    this.tree.addItemListener(new ItemListener(this) {
          private final TreeGrid this$0;
          
          public void itemStateChanged(ItemEvent param1ItemEvent) {
            STree.Node node = (STree.Node)param1ItemEvent.getItem();
            if (param1ItemEvent.getStateChange() == 0) {
              this.this$0.syncVisible(node);
            } else {
              this.this$0.table.setRowSelected(this.this$0.getRowIndex(node.getPath()), (param1ItemEvent.getStateChange() == 1));
            } 
          }
        });
    this.table.addItemListener(new ItemListener(this) {
          private final TreeGrid this$0;
          
          public void itemStateChanged(ItemEvent param1ItemEvent) {
            if (param1ItemEvent.getItem() instanceof Integer && param1ItemEvent instanceof GridItemEvent && ((GridItemEvent)param1ItemEvent).getType().equals(GridItemEvent.ROW)) {
              int i = ((Integer)param1ItemEvent.getItem()).intValue();
              this.this$0.tree.setSelected(this.this$0.getPath(i), (param1ItemEvent.getStateChange() == 1));
            } 
          }
        });
    this.tree.addTreeExpansionListener(new TreeExpansionListener(this) {
          private final TreeGrid this$0;
          
          public void treeExpanded(TreeExpansionEvent param1TreeExpansionEvent) { this.this$0.syncVisible((STree.Node)param1TreeExpansionEvent.getPath().getLastPathComponent()); }
          
          public void treeCollapsed(TreeExpansionEvent param1TreeExpansionEvent) { this.this$0.syncVisible((STree.Node)param1TreeExpansionEvent.getPath().getLastPathComponent()); }
        });
    this.tree.getModel().addTreeModelListener(new TreeModelListener(this) {
          private final TreeGrid this$0;
          
          public void treeNodesChanged(TreeModelEvent param1TreeModelEvent) {}
          
          public void treeNodesInserted(TreeModelEvent param1TreeModelEvent) {
            STree.Node node = (STree.Node)param1TreeModelEvent.getTreePath().getLastPathComponent();
            Object[] arrayOfObject = param1TreeModelEvent.getChildren();
            for (byte b = 0; b < arrayOfObject.length; b++)
              this.this$0.tablemodel.insertRow(((TreeGrid.GTree.GNode)arrayOfObject[b]).getRowIndex(), 1); 
            this.this$0.syncVisible(node);
          }
          
          public void treeNodesRemoved(TreeModelEvent param1TreeModelEvent) {
            Object[] arrayOfObject = param1TreeModelEvent.getChildren();
            for (byte b = 0; b < arrayOfObject.length; b++) {
              TreeGrid.GTree.GNode gNode = (TreeGrid.GTree.GNode)arrayOfObject[b];
              this.this$0.tablemodel.removeRow(gNode.getRowIndex(), gNode.getTreeWidth());
            } 
          }
          
          public void treeStructureChanged(TreeModelEvent param1TreeModelEvent) {}
        });
    this.tree.addActionListener(this);
    this.tree.addItemListener(this);
    this.table.addActionListener(this);
    this.table.addItemListener(this);
  }
  
  void syncVisible(STree.Node paramNode) {
    boolean bool = this.table.isSuspended();
    this.table.setSuspended(true);
    syncVisibleImpl(paramNode);
    if (!bool)
      this.table.setSuspended(false); 
    this.treePnl.reset();
  }
  
  private void syncVisibleImpl(STree.Node paramNode) {
    int i = getRowIndex(paramNode.getPath());
    if (i >= 0)
      this.table.setRowVisible(i, isVisible(paramNode.getTreePath())); 
    for (byte b = 0; b < paramNode.getChildCount(); b++)
      syncVisibleImpl(paramNode.getChild(b)); 
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent) {
    if (paramItemEvent instanceof GridItemEvent) {
      GridItemEvent gridItemEvent = (GridItemEvent)paramItemEvent;
      this.eventMgr.postEvent(new GridItemEvent(this, paramItemEvent.getItem(), paramItemEvent.getStateChange(), gridItemEvent.getType()));
    } else {
      this.eventMgr.postEvent(new ItemEvent(this, 701, paramItemEvent.getItem(), paramItemEvent.getStateChange()));
    } 
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (paramActionEvent instanceof GridActionEvent) {
      GridActionEvent gridActionEvent = (GridActionEvent)paramActionEvent;
      this.eventMgr.postEvent(new GridActionEvent(this, paramActionEvent.getActionCommand(), gridActionEvent.getLocation()));
    } 
  }
  
  public int getRowIndex(String paramString) {
    GTree.GNode gNode = (GTree.GNode)findNode(paramString, false);
    return (gNode == null) ? -1 : gNode.getRowIndex();
  }
  
  public String getPath(int paramInt) { return getPath(this.tree.getRoot(), new int[] { paramInt + 1 }); }
  
  private String getPath(STree.Node paramNode, int[] paramArrayOfInt) {
    if (paramArrayOfInt[0] == 0)
      return paramNode.getPath(); 
    paramArrayOfInt[0] = paramArrayOfInt[0] - 1;
    for (byte b = 0; b < paramNode.getChildCount(); b++) {
      String str = getPath(paramNode.getChild(b), paramArrayOfInt);
      if (str != null)
        return str; 
    } 
    return null;
  }
  
  public void setTreeBorder(int paramInt) {
    this.treeRule = new Integer(paramInt);
    this.pane.repaint();
  }
  
  public int getTreeBorder() { return (this.treeRule != null) ? this.treeRule.intValue() : this.table.getBorder(-99, -99); }
  
  public void setTreeHeader(String paramString) {
    this.treeHeader = paramString;
    if (getHeaderRowCount() == 0)
      setHeaderRowCount(1); 
    this.pane.repaint();
  }
  
  public String getTreeHeader() { return this.treeHeader; }
  
  public void setTreeWidth(int paramInt) { this.treeWidth = paramInt; }
  
  public int getTreeWidth() { return this.treeWidth; }
  
  public void addNotify() {
    super.addNotify();
    this.rowH = 0;
    if (this.heightSet) {
      this.rowH = this.tree.getRowHeight();
    } else {
      this.rowH = this.tree.getFontMetrics(this.tree.getFont()).getHeight() + 6;
      this.tree.setRowHeight(this.rowH);
    } 
    this.rowH -= (((this.table.getBorder(-99, -99) & 0x2) != 0) ? (this.table.getLineStyle() & 0xF) : 0);
    this.table.setRowHeight(-99, this.rowH);
  }
  
  public Object[] getSelectedObjects() { return this.tree.getSelectedObjects(); }
  
  public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
  
  public void addItemListener(ItemListener paramItemListener) { this.eventMgr.addItemListener(paramItemListener); }
  
  public void removeItemListener(ItemListener paramItemListener) { this.eventMgr.removeItemListener(paramItemListener); }
  
  public void setSelected(String paramString, boolean paramBoolean) {
    this.tree.setSelected(paramString, paramBoolean);
    int i = getRowIndex(paramString);
    if (i >= 0)
      this.table.setRowSelected(i, paramBoolean); 
  }
  
  public void expand(String paramString) {
    this.tree.expand(paramString);
    int i = getRowIndex(paramString);
    if (i >= 0)
      this.table.setRowVisible(i, true); 
  }
  
  public void expand(String paramString, int paramInt) { this.tree.expand(paramString, paramInt); }
  
  public void setForceExpanded(String paramString, boolean paramBoolean) { this.tree.setForceExpanded(paramString, paramBoolean); }
  
  public boolean isForceExpanded(String paramString) { return this.tree.isForceExpanded(paramString); }
  
  public void expand(int paramInt) { this.tree.expand(paramInt); }
  
  public void expandAll() { this.tree.expandAll(); }
  
  public void collapse(String paramString) {
    this.tree.collapse(paramString);
    int i = getRowIndex(paramString);
    if (i >= 0)
      this.table.setRowVisible(i, false); 
  }
  
  public void collapse(String paramString, int paramInt) { this.tree.collapse(paramString, paramInt); }
  
  public void remove(String paramString) { this.tree.remove(paramString); }
  
  public void removeAll() {
    synchronized (getTreeLock()) {
      this.tree.removeAll();
      this.tablemodel.setRowCount(0);
    } 
  }
  
  public void setMultiSelect(boolean paramBoolean) {
    this.tree.setMultiSelect(paramBoolean);
    this.table.setMultiSelect(paramBoolean);
  }
  
  public boolean isMultiSelect() { return this.tree.isMultiSelect(); }
  
  public STree.Node findNode(String paramString, boolean paramBoolean) { return this.tree.findNode(paramString, paramBoolean); }
  
  public void setRowHeight(int paramInt) {
    this.heightSet = (paramInt != 0);
    this.tree.setRowHeight(paramInt);
  }
  
  public int getRowHeight() { return this.tree.getRowHeight(); }
  
  public void registerScrollControl(ScrollControl paramScrollControl) { this.table.registerScrollControl(paramScrollControl); }
  
  public int getMinimum(int paramInt) { return this.table.getMinimum(paramInt); }
  
  public int getMaximum(int paramInt) { return this.table.getMaximum(paramInt); }
  
  public int getValue(int paramInt) { return this.table.getValue(paramInt); }
  
  public int getVisibleAmount(int paramInt) { return this.table.getVisibleAmount(paramInt); }
  
  public int getIncrement(int paramInt1, int paramInt2) { return this.table.getIncrement(paramInt1, paramInt2); }
  
  public void setValue(int paramInt1, int paramInt2) {
    this.table.setValue(paramInt1, paramInt2);
    if (paramInt1 == 1) {
      this.treePnl.doLayout();
      this.treePnl.reset();
    } 
  }
  
  public STree.Node getRoot() { return this.tree.getRoot(); }
  
  public char getSeparator() { return this.tree.getSeparator(); }
  
  public void setSeparator(char paramChar) { this.tree.setSeparator(paramChar); }
  
  public int add(String paramString) {
    GTree.GNode gNode = (GTree.GNode)findNode(paramString, true);
    return gNode.getRowIndex();
  }
  
  public String getSelectedLabel() { return this.tree.getSelectedLabel(); }
  
  public String getSelectedPath() { return this.tree.getSelectedPath(); }
  
  public STree.Node getSelectedNode() { return this.tree.getSelectedNode(); }
  
  public String[] getSelectedPaths() { return this.tree.getSelectedPaths(); }
  
  public void setSelectLeafOnly(boolean paramBoolean) { this.tree.setSelectLeafOnly(paramBoolean); }
  
  public boolean isSelectLeafOnly() { return this.tree.isSelectLeafOnly(); }
  
  public void setIcon(Icon paramIcon, int paramInt) { this.tree.setIcon(paramIcon, paramInt); }
  
  public Icon getIcon(int paramInt) { return this.tree.getIcon(paramInt); }
  
  public void setIcon(String paramString, Icon paramIcon) { this.tree.setIcon(paramString, paramIcon); }
  
  public TreePath getTreePath(String paramString) { return this.tree.getTreePath(paramString); }
  
  public void setSorting(int paramInt) {
    this.table.setReorderable(this.table.getReorderable() | true);
    this.tree.setSorting(paramInt);
    syncVisible(getRoot());
  }
  
  public int getSorting() { return this.tree.getSorting(); }
  
  public TreeCellRenderer getCellRenderer() { return this.tree.getCellRenderer(); }
  
  public void setCellRenderer(TreeCellRenderer paramTreeCellRenderer) { this.tree.setCellRenderer(paramTreeCellRenderer); }
  
  public void setEditable(boolean paramBoolean) { this.tree.setEditable(paramBoolean); }
  
  public boolean isEditable() { return this.tree.isEditable(); }
  
  public void setCellEditor(TreeCellEditor paramTreeCellEditor) { this.tree.setCellEditor(paramTreeCellEditor); }
  
  public TreeCellEditor getCellEditor() { return this.tree.getCellEditor(); }
  
  public void setShowsRootHandles(boolean paramBoolean) { this.tree.setShowsRootHandles(paramBoolean); }
  
  public boolean getShowsRootHandles() { return this.tree.getShowsRootHandles(); }
  
  public void setInvokesStopCellEditing(boolean paramBoolean) { this.tree.setInvokesStopCellEditing(paramBoolean); }
  
  public boolean getInvokesStopCellEditing() { return this.tree.getInvokesStopCellEditing(); }
  
  public void setScrollsOnExpand(boolean paramBoolean) { this.tree.setScrollsOnExpand(paramBoolean); }
  
  public boolean getScrollsOnExpand() { return this.tree.getScrollsOnExpand(); }
  
  public boolean isExpanded(TreePath paramTreePath) { return this.tree.isExpanded(paramTreePath); }
  
  public boolean isCollapsed(TreePath paramTreePath) { return this.tree.isCollapsed(paramTreePath); }
  
  public Rectangle getPathBounds(TreePath paramTreePath) { return this.tree.getPathBounds(paramTreePath); }
  
  public void makeVisible(TreePath paramTreePath) { this.tree.makeVisible(paramTreePath); }
  
  public boolean isVisible(TreePath paramTreePath) { return this.tree.isVisible(paramTreePath); }
  
  public TreePath getPathForLocation(int paramInt1, int paramInt2) { return this.tree.getPathForLocation(paramInt1, paramInt2); }
  
  public TreePath getClosestPathForLocation(int paramInt1, int paramInt2) { return this.tree.getClosestPathForLocation(paramInt1, paramInt2); }
  
  public boolean stopEditing() { return this.tree.stopEditing(); }
  
  public void cancelEditing() { this.tree.cancelEditing(); }
  
  public void startEditingAtPath(TreePath paramTreePath) { this.tree.startEditingAtPath(paramTreePath); }
  
  public TreePath getEditingPath() { return this.tree.getEditingPath(); }
  
  public void addTreeExpansionListener(TreeExpansionListener paramTreeExpansionListener) { this.tree.addTreeExpansionListener(paramTreeExpansionListener); }
  
  public void removeTreeExpansionListener(TreeExpansionListener paramTreeExpansionListener) { this.tree.removeTreeExpansionListener(paramTreeExpansionListener); }
  
  public void addTreeWillExpandListener(TreeWillExpandListener paramTreeWillExpandListener) { this.tree.addTreeWillExpandListener(paramTreeWillExpandListener); }
  
  public void removeTreeWillExpandListener(TreeWillExpandListener paramTreeWillExpandListener) { this.tree.removeTreeWillExpandListener(paramTreeWillExpandListener); }
  
  public void addTreeSelectionListener(TreeSelectionListener paramTreeSelectionListener) { this.tree.addTreeSelectionListener(paramTreeSelectionListener); }
  
  public void removeTreeSelectionListener(TreeSelectionListener paramTreeSelectionListener) { this.tree.removeTreeSelectionListener(paramTreeSelectionListener); }
  
  public int headerR(int paramInt) { return this.table.headerR(paramInt); }
  
  public int headerC(int paramInt) { return this.table.headerC(paramInt); }
  
  public void setObject(int paramInt1, int paramInt2, Object paramObject) { this.table.setObject(paramInt1, paramInt2, paramObject); }
  
  public Object getObject(int paramInt1, int paramInt2) { return this.table.getObject(paramInt1, paramInt2); }
  
  public int getModelRowIndex(int paramInt) { return this.table.getModelRowIndex(paramInt); }
  
  public int getModelColIndex(int paramInt) { return this.table.getModelColIndex(paramInt); }
  
  public int getViewRowIndex(int paramInt) { return this.table.getViewRowIndex(paramInt); }
  
  public int getViewColIndex(int paramInt) { return this.table.getViewColIndex(paramInt); }
  
  public int getRowCount() { return this.table.getRowCount(); }
  
  public int getColCount() { return this.table.getColCount(); }
  
  public int getHeaderRowCount() { return this.table.getHeaderRowCount(); }
  
  public int getHeaderColCount() { return this.table.getHeaderColCount(); }
  
  public void setColCount(int paramInt) { this.tablemodel.setColCount(paramInt); }
  
  public void setHeaderRowCount(int paramInt) {
    this.tablemodel.setHeaderRowCount(paramInt);
    if (paramInt > 0)
      this.leftPnl.add(this.headerCell, "North"); 
  }
  
  public void setHeaderColCount(int paramInt) { this.tablemodel.setHeaderColCount(paramInt); }
  
  public void setGap(int paramInt1, int paramInt2, Insets paramInsets) { this.table.setGap(paramInt1, paramInt2, paramInsets); }
  
  public Insets getGap(int paramInt1, int paramInt2) { return this.table.getGap(paramInt1, paramInt2); }
  
  public void setAbsolute(int paramInt) { this.table.setAbsolute(paramInt); }
  
  public int getAbsolute() { return this.table.getAbsolute(); }
  
  public void setResizable(int paramInt) { this.table.setResizable(paramInt & 0x2); }
  
  public int getResizable() { return this.table.getResizable(); }
  
  public void setReorderable(int paramInt) { this.table.setReorderable(paramInt & 0x2); }
  
  public int getReorderable() { return this.table.getReorderable(); }
  
  public void setInPlaceResize(boolean paramBoolean) { this.table.setInPlaceResize(paramBoolean); }
  
  public boolean isInPlaceResize() { return this.table.isInPlaceResize(); }
  
  public void setFillLastCol(boolean paramBoolean) { this.table.setFillLastCol(paramBoolean); }
  
  public boolean isFillLastCol() { return this.table.isFillLastCol(); }
  
  public void setSuspended(boolean paramBoolean) { this.table.setSuspended(paramBoolean); }
  
  public boolean isSuspended() { return this.table.isSuspended(); }
  
  public void setMinColWidth(int paramInt1, int paramInt2) { this.table.setMinColWidth(paramInt1, paramInt2); }
  
  public int getMinColWidth(int paramInt) { return this.table.getMinColWidth(paramInt); }
  
  public void setColWidth(int paramInt1, int paramInt2) { this.table.setColWidth(paramInt1, paramInt2); }
  
  public int getColWidth(int paramInt) { return this.table.getColWidth(paramInt); }
  
  public void setBorder(int paramInt1, int paramInt2, int paramInt3) { this.table.setBorder(paramInt1, paramInt2, paramInt3); }
  
  public int getBorder(int paramInt1, int paramInt2) { return this.table.getBorder(paramInt1, paramInt2); }
  
  public void setLineStyle(int paramInt) { this.table.setLineStyle(paramInt); }
  
  public int getLineStyle() { return this.table.getLineStyle(); }
  
  public void setBorderColor(Color paramColor) { this.table.setBorderColor(paramColor); }
  
  public Color getBorderColor() { return this.table.getBorderColor(); }
  
  public void setRowSelectable(boolean paramBoolean) { this.table.setRowSelectable(paramBoolean); }
  
  public void setColSelectable(boolean paramBoolean) { this.table.setColSelectable(paramBoolean); }
  
  public boolean isRowSelectable() { return this.table.isRowSelectable(); }
  
  public boolean isColSelectable() { return this.table.isColSelectable(); }
  
  public void setRowHeaderSelect(boolean paramBoolean) { this.table.setRowHeaderSelect(paramBoolean); }
  
  public boolean isRowHeaderSelect() { return this.table.isRowHeaderSelect(); }
  
  public void setColHeaderSelect(boolean paramBoolean) { this.table.setColHeaderSelect(paramBoolean); }
  
  public boolean isColHeaderSelect() { return this.table.isColHeaderSelect(); }
  
  public void setRegionSelectable(boolean paramBoolean) { this.table.setRegionSelectable(paramBoolean); }
  
  public boolean isRegionSelectable() { return this.table.isRegionSelectable(); }
  
  public void setRowMenu(int paramInt, JPopupMenu paramJPopupMenu) { this.table.setRowMenu(paramInt, paramJPopupMenu); }
  
  public JPopupMenu getRowMenu(int paramInt) { return this.table.getRowMenu(paramInt); }
  
  public void setColMenu(int paramInt, JPopupMenu paramJPopupMenu) { this.table.setColMenu(paramInt, paramJPopupMenu); }
  
  public JPopupMenu getColMenu(int paramInt) { return this.table.getColMenu(paramInt); }
  
  public void setSpan(int paramInt1, int paramInt2, Dimension paramDimension) { this.table.setSpan(paramInt1, paramInt2, paramDimension); }
  
  public Dimension getSpan(int paramInt1, int paramInt2) { return this.table.getSpan(paramInt1, paramInt2); }
  
  public void setAlignment(int paramInt1, int paramInt2, int paramInt3) { this.table.setAlignment(paramInt1, paramInt2, paramInt3); }
  
  public int getAlignment(int paramInt1, int paramInt2) { return this.table.getAlignment(paramInt1, paramInt2); }
  
  public void setFont(int paramInt1, int paramInt2, Font paramFont) { this.table.setFont(paramInt1, paramInt2, paramFont); }
  
  public Font getFont(int paramInt1, int paramInt2) { return this.table.getFont(paramInt1, paramInt2); }
  
  public boolean isRowVisible(int paramInt) { return this.table.isRowVisible(paramInt); }
  
  public void setColVisible(int paramInt, boolean paramBoolean) { this.table.setColVisible(paramInt, paramBoolean); }
  
  public boolean isColVisible(int paramInt) { return this.table.isColVisible(paramInt); }
  
  public void setRowSelected(int paramInt, boolean paramBoolean) { this.table.setRowSelected(paramInt, paramBoolean); }
  
  public void setColSelected(int paramInt, boolean paramBoolean) { this.table.setColSelected(paramInt, paramBoolean); }
  
  public int getSelectedRow() { return this.table.getSelectedRow(); }
  
  public int[] getSelectedRows() { return this.table.getSelectedRows(); }
  
  public int getSelectedCol() { return this.table.getSelectedCol(); }
  
  public int[] getSelectedCols() { return this.table.getSelectedCols(); }
  
  public boolean isRowSelected(int paramInt) { return this.table.isRowSelected(paramInt); }
  
  public boolean isColSelected(int paramInt) { return this.table.isColSelected(paramInt); }
  
  public void clearSelection() {
    this.table.clearSelection();
    this.tree.clearSelection();
  }
  
  public void setSelectedRegion(Grid.Region paramRegion) { this.table.setSelectedRegion(paramRegion); }
  
  public Grid.Region getSelectedRegion() { return this.table.getSelectedRegion(); }
  
  public boolean isSelected(int paramInt1, int paramInt2) { return this.table.isSelected(paramInt1, paramInt2); }
  
  public void makeCellVisible(int paramInt1, int paramInt2) { this.table.makeCellVisible(paramInt1, paramInt2); }
  
  public void setTopRow(int paramInt) { this.table.setTopRow(paramInt); }
  
  public void setLeftCol(int paramInt) { this.table.setLeftCol(paramInt); }
  
  public int getTopRow() { return this.table.getTopRow(); }
  
  public int getLeftCol() { return this.table.getLeftCol(); }
  
  public void setFrozenCol(int paramInt) { this.table.setFrozenCol(paramInt); }
  
  public int getFrozenCol() { return this.table.getFrozenCol(); }
  
  public void setHighlightFG(Color paramColor) { this.table.setHighlightFG(paramColor); }
  
  public Color getHighlightFG() { return this.table.getHighlightFG(); }
  
  public void setHighlightBG(Color paramColor) { this.table.setHighlightBG(paramColor); }
  
  public Color getHighlightBG() { return this.table.getHighlightBG(); }
  
  public void setHighlighted(int paramInt1, int paramInt2, boolean paramBoolean) { this.table.setHighlighted(paramInt1, paramInt2, paramBoolean); }
  
  public boolean isHighlighted(int paramInt1, int paramInt2) { return this.table.isHighlighted(paramInt1, paramInt2); }
  
  public void setSelectOnEntry(boolean paramBoolean) { this.table.setSelectOnEntry(paramBoolean); }
  
  public boolean isSelectOnEntry() { return this.table.isSelectOnEntry(); }
  
  public void setEditable(int paramInt1, int paramInt2, boolean paramBoolean) { this.table.setEditable(paramInt1, paramInt2, paramBoolean); }
  
  public boolean isEditable(int paramInt1, int paramInt2) { return this.table.isEditable(paramInt1, paramInt2); }
  
  public void setCopyEnabled(int paramInt1, int paramInt2, boolean paramBoolean) { this.table.setCopyEnabled(paramInt1, paramInt2, paramBoolean); }
  
  public boolean isCopyEnabled(int paramInt1, int paramInt2) { return this.table.isCopyEnabled(paramInt1, paramInt2); }
  
  public void setEditor(int paramInt1, int paramInt2, GridCellEditor paramGridCellEditor) { this.table.setEditor(paramInt1, paramInt2, paramGridCellEditor); }
  
  public GridCellEditor getEditor(int paramInt1, int paramInt2) { return this.table.getEditor(paramInt1, paramInt2); }
  
  public void setRenderer(int paramInt1, int paramInt2, GridCellRenderer paramGridCellRenderer) { this.table.setRenderer(paramInt1, paramInt2, paramGridCellRenderer); }
  
  public GridCellRenderer getRenderer(int paramInt1, int paramInt2) { return this.table.getRenderer(paramInt1, paramInt2); }
  
  public void setDemandLoading(boolean paramBoolean) { this.table.setDemandLoading(paramBoolean); }
  
  public boolean isDemandLoading() { return this.table.isDemandLoading(); }
  
  public void setFormat(int paramInt1, int paramInt2, Format paramFormat) { this.table.setFormat(paramInt1, paramInt2, paramFormat); }
  
  public Format getFormat(int paramInt1, int paramInt2) { return this.table.getFormat(paramInt1, paramInt2); }
  
  public void setForeground(int paramInt1, int paramInt2, Color paramColor) { this.table.setForeground(paramInt1, paramInt2, paramColor); }
  
  public Color getForeground(int paramInt1, int paramInt2) { return this.table.getForeground(paramInt1, paramInt2); }
  
  public void setBackground(int paramInt1, int paramInt2, Color paramColor) { this.table.setBackground(paramInt1, paramInt2, paramColor); }
  
  public Color getBackground(int paramInt1, int paramInt2) { return this.table.getBackground(paramInt1, paramInt2); }
  
  public void setFocus(int paramInt1, int paramInt2) { this.table.setFocus(paramInt1, paramInt2); }
  
  class Pane extends JPanel {
    private final TreeGrid this$0;
    
    Pane(TreeGrid this$0) { this.this$0 = this$0; }
    
    public void doLayout() {
      Dimension dimension1 = getSize();
      Dimension dimension2 = this.this$0.leftPnl.getPreferredSize();
      this.this$0.table.setBounds(dimension2.width, 0, dimension1.width - dimension2.width, dimension1.height);
      this.this$0.table.validate();
      this.this$0.leftPnl.setBounds(0, 0, dimension2.width, dimension1.height);
      this.this$0.leftPnl.validate();
      this.this$0.treePnl.reset();
    }
    
    public Dimension getPreferredSize() {
      Dimension dimension1 = this.this$0.leftPnl.getPreferredSize();
      Dimension dimension2 = this.this$0.table.getPreferredSize();
      return new Dimension(dimension1.width + dimension2.width, Math.max(dimension1.height, dimension2.height));
    }
  }
  
  class TreePanel extends JPanel {
    private final TreeGrid this$0;
    
    TreePanel(TreeGrid this$0) {
      this.this$0 = this$0;
      setLayout(null);
      add(this.this$0.tree);
    }
    
    public void doLayout() {
      Dimension dimension = getSize();
      int i = this.this$0.table.getGridY()[this.this$0.table.getHeaderRowCount()];
      int j = Math.max(i, this.this$0.table.getValue(1));
      this.this$0.tree.setBounds(0, i - j, dimension.width, dimension.height - i + j);
    }
    
    public Dimension getPreferredSize() {
      Dimension dimension = this.this$0.tree.getPreferredSize();
      dimension.width = Math.max(dimension.width, this.this$0.treeWidth);
      return dimension;
    }
    
    public void reset() {
      synchronized (this.this$0.getTreeLock()) {
        this.this$0.treeHlines = this.this$0.treeVlines = null;
      } 
    }
  }
  
  class GTree extends STree {
    private final TreeGrid this$0;
    
    GTree(TreeGrid this$0) { this.this$0 = this$0; }
    
    public STree.Node createNode(STree.Node param1Node, String param1String) { return new GNode(this, param1Node, param1String); }
    
    class GNode extends STree.Node {
      int row;
      
      private final TreeGrid.GTree this$1;
      
      public GNode(TreeGrid.GTree this$0, STree.Node param2Node, String param2String) {
        super(this$0, param2Node, param2String);
        this.this$1 = this$0;
        this.row = -1;
      }
      
      public void insert(MutableTreeNode param2MutableTreeNode, int param2Int) {
        super.insert(param2MutableTreeNode, param2Int);
        if (param2Int > 0) {
          GNode gNode = (GNode)getChild(param2Int - 1);
          gNode.row += gNode.getTreeWidth();
        } else {
          this.row++;
        } 
        ((GNode)param2MutableTreeNode).adjustRow(1);
      }
      
      public void remove(int param2Int) {
        if (param2Int < getChildCount()) {
          GNode gNode = (GNode)getChild(param2Int);
          gNode.adjustRow(-gNode.getTreeWidth());
          super.remove(param2Int);
        } 
      }
      
      public int getRowIndex() { return this.row; }
      
      public void setRowIndex(int param2Int) { this.row = param2Int; }
      
      void adjustRow(int param2Int) {
        if (this.parent != null) {
          int i = this.parent.getIndex(this);
          for (int j = i + 1; j < this.parent.getChildCount(); j++) {
            GNode gNode = (GNode)this.parent.getChild(j);
            gNode.adjustRowDrillDown(param2Int);
          } 
          ((GNode)this.parent).adjustRow(param2Int);
        } 
      }
      
      void adjustRowDrillDown(int param2Int) {
        this.row += param2Int;
        for (byte b = 0; b < getChildCount(); b++)
          ((GNode)getChild(b)).adjustRowDrillDown(param2Int); 
      }
    }
  }
  
  class GNode extends STree.Node {
    int row;
    
    private final TreeGrid.GTree this$1;
    
    public GNode(TreeGrid this$0, STree.Node param1Node, String param1String) {
      super(this$0, param1Node, param1String);
      this.this$1 = this$0;
      this.row = -1;
    }
    
    public void insert(MutableTreeNode param1MutableTreeNode, int param1Int) {
      super.insert(param1MutableTreeNode, param1Int);
      if (param1Int > 0) {
        GNode gNode = (GNode)getChild(param1Int - 1);
        gNode.row += gNode.getTreeWidth();
      } else {
        this.row++;
      } 
      ((GNode)param1MutableTreeNode).adjustRow(1);
    }
    
    public void remove(int param1Int) {
      if (param1Int < getChildCount()) {
        GNode gNode = (GNode)getChild(param1Int);
        gNode.adjustRow(-gNode.getTreeWidth());
        super.remove(param1Int);
      } 
    }
    
    public int getRowIndex() { return this.row; }
    
    public void setRowIndex(int param1Int) { this.row = param1Int; }
    
    void adjustRow(int param1Int) {
      if (this.parent != null) {
        int i = this.parent.getIndex(this);
        for (int j = i + 1; j < this.parent.getChildCount(); j++) {
          GNode gNode = (GNode)this.parent.getChild(j);
          gNode.adjustRowDrillDown(param1Int);
        } 
        ((GNode)this.parent).adjustRow(param1Int);
      } 
    }
    
    void adjustRowDrillDown(int param1Int) {
      this.row += param1Int;
      for (byte b = 0; b < getChildCount(); b++)
        ((GNode)getChild(b)).adjustRowDrillDown(param1Int); 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\TreeGrid.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */