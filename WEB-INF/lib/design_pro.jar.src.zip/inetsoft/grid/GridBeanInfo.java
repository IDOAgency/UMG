/*     */ package inetsoft.grid;
/*     */ 
/*     */ import inetsoft.beans.AutoBeanInfo;
/*     */ import java.awt.Image;
/*     */ import java.beans.PropertyEditorSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GridBeanInfo
/*     */   extends AutoBeanInfo
/*     */ {
/*     */   public GridBeanInfo() {
/*  30 */     super(Grid.class);
/*  31 */     registerEditor("alignment", Align2DEditor.class);
/*  32 */     registerEditor("absolute", Align2DEditor.class);
/*  33 */     registerEditor("resizable", RuleEditor.class);
/*  34 */     registerEditor("reorderable", RuleEditor.class);
/*  35 */     registerEditor("lineStyle", R3DEditor.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Image getIcon(int paramInt) {
/*     */     Image image;
/*  41 */     switch (paramInt) {
/*     */       case 1:
/*     */       case 3:
/*  44 */         image = loadImage("beans/GridBean.gif");
/*  45 */         return image.getScaledInstance(16, 16, 4);
/*     */       case 2:
/*     */       case 4:
/*  48 */         image = loadImage("beans/GridBean32.gif");
/*  49 */         return image.getScaledInstance(32, 32, 4);
/*     */     } 
/*  51 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class RuleEditor
/*     */     extends PropertyEditorSupport
/*     */   {
/*     */     public void setAsText(String param1String) {
/*  59 */       if (param1String.equals("NONE")) {
/*  60 */         setValue(new Integer(0));
/*     */       }
/*  62 */       else if (param1String.equals("HORIZONTAL")) {
/*  63 */         setValue(new Integer(2));
/*     */       }
/*  65 */       else if (param1String.equals("VERTICAL")) {
/*  66 */         setValue(new Integer(1));
/*     */       }
/*  68 */       else if (param1String.equals("ALL")) {
/*  69 */         setValue(new Integer(-99));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     public String[] getTags() { return new String[] { "NONE", "HORIZONTAL", "VERTICAL", "ALL" }; }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class R3DEditor
/*     */     extends PropertyEditorSupport
/*     */   {
/*     */     public void setAsText(String param1String) {
/*  86 */       if (param1String.equals("THIN_LINE")) {
/*  87 */         setValue(new Integer(4097));
/*     */       }
/*  89 */       else if (param1String.equals("RAISED")) {
/*  90 */         setValue(new Integer(24578));
/*     */       }
/*  92 */       else if (param1String.equals("LOWERED")) {
/*  93 */         setValue(new Integer(40962));
/*     */       }
/*  95 */       else if (param1String.equals("DOT_LINE")) {
/*  96 */         setValue(new Integer(4113));
/*     */       }
/*  98 */       else if (param1String.equals("RAISED_FRAME")) {
/*  99 */         setValue(new Integer(24580));
/*     */       }
/* 101 */       else if (param1String.equals("LOWERED_FRAME")) {
/* 102 */         setValue(new Integer(40964));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     public String[] getTags() { return new String[] { "PLAIN", "RAISED", "LOWERED", "DOT_LINE", "RAISED_FRAME", "LOWERED_FRAME" }; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\GridBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */