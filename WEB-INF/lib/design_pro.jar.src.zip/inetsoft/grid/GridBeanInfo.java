package inetsoft.grid;

import inetsoft.beans.AutoBeanInfo;
import java.awt.Image;
import java.beans.PropertyEditorSupport;

public class GridBeanInfo extends AutoBeanInfo {
  public GridBeanInfo() {
    super(Grid.class);
    registerEditor("alignment", Align2DEditor.class);
    registerEditor("absolute", Align2DEditor.class);
    registerEditor("resizable", RuleEditor.class);
    registerEditor("reorderable", RuleEditor.class);
    registerEditor("lineStyle", R3DEditor.class);
  }
  
  public Image getIcon(int paramInt) {
    Image image;
    switch (paramInt) {
      case 1:
      case 3:
        image = loadImage("beans/GridBean.gif");
        return image.getScaledInstance(16, 16, 4);
      case 2:
      case 4:
        image = loadImage("beans/GridBean32.gif");
        return image.getScaledInstance(32, 32, 4);
    } 
    return null;
  }
  
  public static class RuleEditor extends PropertyEditorSupport {
    public void setAsText(String param1String) {
      if (param1String.equals("NONE")) {
        setValue(new Integer(0));
      } else if (param1String.equals("HORIZONTAL")) {
        setValue(new Integer(2));
      } else if (param1String.equals("VERTICAL")) {
        setValue(new Integer(1));
      } else if (param1String.equals("ALL")) {
        setValue(new Integer(-99));
      } 
    }
    
    public String[] getTags() { return new String[] { "NONE", "HORIZONTAL", "VERTICAL", "ALL" }; }
  }
  
  public static class R3DEditor extends PropertyEditorSupport {
    public void setAsText(String param1String) {
      if (param1String.equals("THIN_LINE")) {
        setValue(new Integer(4097));
      } else if (param1String.equals("RAISED")) {
        setValue(new Integer(24578));
      } else if (param1String.equals("LOWERED")) {
        setValue(new Integer(40962));
      } else if (param1String.equals("DOT_LINE")) {
        setValue(new Integer(4113));
      } else if (param1String.equals("RAISED_FRAME")) {
        setValue(new Integer(24580));
      } else if (param1String.equals("LOWERED_FRAME")) {
        setValue(new Integer(40964));
      } 
    }
    
    public String[] getTags() { return new String[] { "PLAIN", "RAISED", "LOWERED", "DOT_LINE", "RAISED_FRAME", "LOWERED_FRAME" }; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\GridBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */