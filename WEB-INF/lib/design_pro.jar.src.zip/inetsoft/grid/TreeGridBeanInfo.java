/*    */ package inetsoft.grid;
/*    */ 
/*    */ import inetsoft.beans.AutoBeanInfo;
/*    */ import java.awt.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeGridBeanInfo
/*    */   extends AutoBeanInfo
/*    */ {
/*    */   public TreeGridBeanInfo() {
/* 28 */     super(TreeGrid.class);
/* 29 */     registerEditor("alignment", Align2DEditor.class);
/* 30 */     registerEditor("resizable", GridBeanInfo.RuleEditor.class);
/* 31 */     registerEditor("reorderable", GridBeanInfo.RuleEditor.class);
/* 32 */     registerEditor("lineStyle", GridBeanInfo.R3DEditor.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Image getIcon(int paramInt) {
/*    */     Image image;
/* 38 */     switch (paramInt) {
/*    */       case 1:
/*    */       case 3:
/* 41 */         image = loadImage("beans/TreeGridBean.gif");
/* 42 */         return image.getScaledInstance(16, 16, 4);
/*    */       case 2:
/*    */       case 4:
/* 45 */         image = loadImage("beans/TreeGridBean32.gif");
/* 46 */         return image.getScaledInstance(32, 32, 4);
/*    */     } 
/* 48 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\TreeGridBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */