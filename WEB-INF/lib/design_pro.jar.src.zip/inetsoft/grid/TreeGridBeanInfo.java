package inetsoft.grid;

import inetsoft.beans.AutoBeanInfo;
import java.awt.Image;

public class TreeGridBeanInfo extends AutoBeanInfo {
  public TreeGridBeanInfo() {
    super(TreeGrid.class);
    registerEditor("alignment", Align2DEditor.class);
    registerEditor("resizable", GridBeanInfo.RuleEditor.class);
    registerEditor("reorderable", GridBeanInfo.RuleEditor.class);
    registerEditor("lineStyle", GridBeanInfo.R3DEditor.class);
  }
  
  public Image getIcon(int paramInt) {
    Image image;
    switch (paramInt) {
      case 1:
      case 3:
        image = loadImage("beans/TreeGridBean.gif");
        return image.getScaledInstance(16, 16, 4);
      case 2:
      case 4:
        image = loadImage("beans/TreeGridBean32.gif");
        return image.getScaledInstance(32, 32, 4);
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\TreeGridBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */