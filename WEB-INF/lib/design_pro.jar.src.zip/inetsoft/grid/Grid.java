package inetsoft.grid;

import inetsoft.grid.editor.TextAreaEditor;
import inetsoft.grid.editor.TextFieldEditor;
import inetsoft.grid.event.GridActionEvent;
import inetsoft.grid.event.GridComponentEvent;
import inetsoft.grid.event.GridItemEvent;
import inetsoft.grid.event.GridModelEvent;
import inetsoft.grid.event.GridModelListener;
import inetsoft.grid.internal.CellInfo;
import inetsoft.grid.internal.ColInfo;
import inetsoft.grid.internal.GridBase;
import inetsoft.grid.internal.GridInfo;
import inetsoft.grid.internal.Matrix;
import inetsoft.grid.internal.MatrixHelper;
import inetsoft.grid.internal.RowInfo;
import inetsoft.grid.model.DefaultGridModel;
import inetsoft.grid.model.GridModel;
import inetsoft.util.Comparer;
import inetsoft.widget.util.EventMgr;
import inetsoft.widget.util.Tool;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.ItemSelectable;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.TextComponent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.Format;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.MenuElement;
import javax.swing.UIManager;
import javax.swing.text.JTextComponent;

public class Grid extends JPanel implements GridModelListener, ItemSelectable, Scrollable {
  public static final int HEADER = -1;
  
  public static final int ALL = -99;
  
  public static final int NONE = 0;
  
  public static final int HORIZONTAL = 2;
  
  public static final int VERTICAL = 1;
  
  static final int WIDTH_MASK = 15;
  
  static final int DASH_MASK = 240;
  
  static final int SOLID_MASK = 4096;
  
  static final int DOUBLE_MASK = 8192;
  
  static final int RAISED_MASK = 16384;
  
  static final int LOWERED_MASK = 32768;
  
  public static final int THIN_LINE = 4097;
  
  public static final int MEDIUM_LINE = 4098;
  
  public static final int THICK_LINE = 4099;
  
  public static final int RAISED = 24578;
  
  public static final int LOWERED = 40962;
  
  public static final int DOT_LINE = 4113;
  
  public static final int RAISED_FRAME = 24580;
  
  public static final int LOWERED_FRAME = 40964;
  
  public static final int H_LEFT = 1;
  
  public static final int H_CENTER = 2;
  
  public static final int H_RIGHT = 4;
  
  public static final int V_TOP = 8;
  
  public static final int V_CENTER = 16;
  
  public static final int V_BOTTOM = 32;
  
  public static final int FILL = 0;
  
  public static final int LEFT_TOP = 9;
  
  public static final int LEFT_CENTER = 17;
  
  public static final int LEFT_BOTTOM = 33;
  
  public static final int CENTER_TOP = 10;
  
  public static final int CENTER_CENTER = 18;
  
  public static final int CENTER_BOTTOM = 34;
  
  public static final int RIGHT_TOP = 12;
  
  public static final int RIGHT_CENTER = 20;
  
  public static final int RIGHT_BOTTOM = 36;
  
  protected EventMgr eventMgr;
  
  ScrollControl scroller;
  
  private Hashtable propertyMethods;
  
  private ActionListener menuListener;
  
  private EventForwarder forwarder;
  
  EditorListener editorListener;
  
  FocusListener focusListener;
  
  static Field gapProperty;
  
  static Field borderProperty;
  
  static Field alignProperty;
  
  static Field fontProperty;
  
  static Field highlightedProperty;
  
  static Field editableProperty;
  
  static Field copiableProperty;
  
  static Field formatProperty;
  
  static Field foregroundProperty;
  
  static Field backgroundProperty;
  
  static Field editorProperty;
  
  static Field rendererProperty;
  
  public Grid() { this(10, 5); }
  
  public Grid(int paramInt1, int paramInt2) { this(new DefaultGridModel(paramInt1, paramInt2)); }
  
  public Grid(GridModel paramGridModel) {
    this.eventMgr = new EventMgr();
    this.scroller = null;
    this.propertyMethods = new Hashtable();
    this.menuListener = new ActionListener(this) {
        private final Grid this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (!(param1ActionEvent instanceof GridActionEvent))
            this.this$0.eventMgr.postEvent(new GridActionEvent(param1ActionEvent.getSource(), param1ActionEvent.getActionCommand(), this.this$0.menuPos)); 
        }
      };
    this.forwarder = new EventForwarder(this, null);
    this.editorListener = new EditorListener(this, null);
    this.focusListener = new FocusAdapter(this) {
        private final Grid this$0;
        
        public void focusGained(FocusEvent param1FocusEvent) {
          Component component = (Component)param1FocusEvent.getSource();
          if (this.this$0.lastFocus.x < 0 || this.this$0.lastFocus.y < 0 || this.this$0.getObject(this.this$0.lastFocus.y, this.this$0.lastFocus.x) != component) {
            byte b;
            label19: for (b = 0; b < this.this$0.getRowCount(); b++) {
              for (byte b1 = 0; b1 < this.this$0.getColCount(); b1++) {
                if (this.this$0.getObject(b, b1) == component) {
                  this.this$0.lastFocus = new Point(b1, b);
                  break label19;
                } 
              } 
            } 
          } 
        }
        
        public void focusLost(FocusEvent param1FocusEvent) {
          if (param1FocusEvent.getSource() instanceof TextComponent) {
            TextComponent textComponent = (TextComponent)param1FocusEvent.getSource();
            textComponent.select(0, 0);
          } 
        }
      };
    this.ginfo = new GridInfo();
    this.rowHeight = null;
    this.colWidth = null;
    this.rowmap = null;
    this.colmap = null;
    this.absolute = 0;
    this.resizable = 3;
    this.inPlace = false;
    this.fillLastCol = true;
    this.cursorChanged = false;
    this.resizeR = -1;
    this.resizeC = -1;
    this.resizeLineC = new ResizeLine(this);
    this.resizeLineR = new ResizeLine(this);
    this.frozen = new Point(0, 0);
    this.hrow = 0;
    this.hcol = 0;
    this.lineWrap = true;
    this.root = new Point(0, 0);
    this.pixelOff = new Point(0, 0);
    this.mode3D = 4097;
    this.borderC = null;
    this.lineWidth = 1;
    this.oSize = new Dimension(0, 0);
    this.needLayout = false;
    this.buffer = null;
    this.multiSel = true;
    this.rowSelectable = true;
    this.colSelectable = false;
    this.regSelectable = false;
    this.useRowHeader = false;
    this.useColHeader = false;
    this.highlightMask = 12566463;
    this.highlightFG = null;
    this.highlightBG = null;
    this.reorderable = 0;
    this.moving = false;
    this.movePos = null;
    this.moveBox = new ResizeLine(this);
    this.moveOff = new Point(0, 0);
    this.rowMenu = null;
    this.colMenu = null;
    this.gridRowHeight = 0;
    this.gridColWidth = 0;
    this.gridMinRowHeight = 14;
    this.gridMinColWidth = 10;
    this.arrow = null;
    this.arrowDown = true;
    this.lastFocus = new Point(-1, -1);
    this.textfield = new TextFieldEditor();
    this.textarea = new TextAreaEditor();
    this.ignoreFocus = 0;
    this.csort = false;
    this.lastSort = -1;
    this.selectOnEntry = true;
    this.pane = new Pane(this);
    this.suspend = false;
    this.visReg = new Rectangle();
    this.lookahead = 50;
    this.delayed = true;
    this.mvalid = false;
    this.defaultCursor = null;
    setLayout(new BorderLayout());
    this.ginfo.border = new Integer(3);
    setFont(UIManager.getFont("Table.font"));
    setForeground(UIManager.getColor("Table.foreground"));
    setBackground(UIManager.getColor("Table.background"));
    setHighlightFG(UIManager.getColor("Table.selectionForeground"));
    setHighlightBG(UIManager.getColor("Table.selectionBackground"));
    setBorderColor(UIManager.getColor("Table.gridColor"));
    add(getPane(), "Center");
    getPane().setLayout(null);
    setModel(paramGridModel);
    getPane().add(this.resizeLineC);
    getPane().add(this.resizeLineR);
    getPane().add(this.moveBox);
    this.resizeLineC.setVisible(false);
    this.resizeLineR.setVisible(false);
    this.moveBox.setVisible(false);
    enableEvents(128L);
    this.textfield.setForeground(Color.black);
    this.textarea.setForeground(Color.black);
    this.textfield.setBackground(Color.white);
    this.textarea.setBackground(Color.white);
    this.textfield.addKeyListener(this.editorListener);
  }
  
  public GridModel getModel() { return this.model; }
  
  public void setModel(GridModel paramGridModel) {
    synchronized (getTreeLock()) {
      if (this.model != null) {
        this.model.removeGridModelListener(this);
        if (this.gridinfo != null)
          removeComponents(); 
      } 
      this.model = paramGridModel;
      this.mvalid = false;
      paramGridModel.addGridModelListener(this);
      this.hrow = paramGridModel.getHeaderRowCount();
      this.hcol = paramGridModel.getHeaderColCount();
      this.nrow = paramGridModel.getRowCount() + this.hrow;
      this.ncol = paramGridModel.getColCount() + this.hcol;
      GridHelper gridHelper = new GridHelper(this, null);
      this.gridinfo = new Matrix(this.nrow, this.ncol, gridHelper);
      this.gridX = new int[this.ncol + 1];
      this.gridY = new int[this.nrow + 1];
      setReorderable(this.reorderable);
      doRepaint(true);
    } 
  }
  
  public int headerR(int paramInt) { return paramInt - this.hrow; }
  
  public int headerC(int paramInt) { return paramInt - this.hcol; }
  
  public void setObject(int paramInt1, int paramInt2, Object paramObject) { this.model.setObject(getModelRowIndex(paramInt1), getModelColIndex(paramInt2), paramObject); }
  
  public Object getObject(int paramInt1, int paramInt2) { return this.model.getObject(getModelRowIndex(paramInt1), getModelColIndex(paramInt2)); }
  
  public int getModelRowIndex(int paramInt) { return (this.rowmap != null && paramInt + this.hrow < this.rowmap.length) ? (this.rowmap[paramInt + this.hrow] - this.hrow) : paramInt; }
  
  public int getModelColIndex(int paramInt) { return (this.colmap != null && paramInt + this.hcol < this.colmap.length) ? (this.colmap[paramInt + this.hcol] - this.hcol) : paramInt; }
  
  public int getViewRowIndex(int paramInt) {
    if (this.rowmap != null)
      for (byte b = 0; b < this.rowmap.length; b++) {
        if (this.rowmap[b] == paramInt + this.hrow)
          return b; 
      }  
    return paramInt;
  }
  
  public int getViewColIndex(int paramInt) {
    if (this.colmap != null)
      for (byte b = 0; b < this.colmap.length; b++) {
        if (this.colmap[b] == paramInt + this.hcol)
          return b; 
      }  
    return paramInt;
  }
  
  public int getRowCount() { return this.model.getRowCount(); }
  
  public int getColCount() { return this.model.getColCount(); }
  
  public int getHeaderRowCount() { return this.model.getHeaderRowCount(); }
  
  public int getHeaderColCount() { return this.model.getHeaderColCount(); }
  
  public void valueChanged(GridModelEvent paramGridModelEvent) {
    if (this.gridinfo == null)
      return; 
    if (paramGridModelEvent.getID() == 16) {
      int i = paramGridModelEvent.getRow();
      int j = paramGridModelEvent.getRowCount();
      this.mvalid = false;
      if (i <= this.lastFocus.y)
        this.lastFocus.y += j; 
      popdownEditor();
      synchronized (getTreeLock()) {
        if (this.rowmap != null) {
          int[] arrayOfInt = new int[this.rowmap.length + j];
          for (byte b1 = 0, b2 = 0; b1 < this.rowmap.length; b1++) {
            if (this.rowmap[b1] < i + this.hrow) {
              arrayOfInt[b2++] = this.rowmap[b1];
            } else if (this.rowmap[b1] > i + this.hrow) {
              arrayOfInt[b2++] = this.rowmap[b1] + j;
            } else {
              for (int k = 0; k <= j; k++)
                arrayOfInt[b2++] = this.rowmap[b1] + k; 
            } 
          } 
          if (i + this.hrow >= this.rowmap.length)
            for (int k = 0; k < j; k++)
              arrayOfInt[this.rowmap.length + k] = this.rowmap.length + k;  
          this.rowmap = arrayOfInt;
        } 
        if (i + this.hrow < this.nrow)
          for (int k = 0; k < this.ncol; k++) {
            CellInfo cellInfo = getCellInfo(i, k - this.hcol, false);
            if (cellInfo != null && cellInfo.span != null && cellInfo.span.row != 0)
              setSpan(i, k - this.hcol, null); 
          }  
        this.gridinfo.insertRow(i + this.hrow, j);
        this.hrow = this.model.getHeaderRowCount();
        this.nrow = this.model.getRowCount() + this.hrow;
        this.gridY = new int[this.nrow + 1];
        this.selReg = null;
        this.lastFocus = new Point(-1, -1);
        resetCols();
      } 
    } else if (paramGridModelEvent.getID() == 32) {
      int i = paramGridModelEvent.getRow();
      int j = paramGridModelEvent.getRowCount();
      this.mvalid = false;
      if (i <= this.lastFocus.y) {
        this.lastFocus.y -= j;
        if (this.lastFocus.y <= i)
          this.lastFocus = new Point(-1, -1); 
      } 
      popdownEditor();
      synchronized (getTreeLock()) {
        for (int k = 0; k < this.ncol; k++) {
          for (int m = i; m < i + j; m++) {
            CellInfo cellInfo = getCellInfo(m, k - this.hcol, false);
            if (cellInfo != null && cellInfo.span != null)
              setSpan(m, k - this.hcol, null); 
            if (cellInfo != null && cellInfo.component != null)
              getPane().remove(cellInfo.component); 
          } 
        } 
        if (this.rowmap != null) {
          int[] arrayOfInt = new int[this.rowmap.length - j];
          for (byte b1 = 0, b2 = 0; b1 < this.rowmap.length; b1++) {
            if (this.rowmap[b1] < i + this.hrow) {
              arrayOfInt[b2++] = this.rowmap[b1];
            } else if (this.rowmap[b1] >= i + this.hrow + j) {
              arrayOfInt[b2++] = this.rowmap[b1] - j;
            } 
          } 
          this.rowmap = arrayOfInt;
        } 
        this.gridinfo.removeRow(i + this.hrow, j);
        this.hrow = this.model.getHeaderRowCount();
        this.nrow = this.model.getRowCount() + this.hrow;
        this.gridY = new int[this.nrow + 1];
        this.selReg = null;
        this.lastFocus = new Point(-1, -1);
        resetCols();
      } 
    } else if (paramGridModelEvent.getID() == 48) {
      int i = paramGridModelEvent.getCol();
      int j = paramGridModelEvent.getColCount();
      this.mvalid = false;
      if (i <= this.lastFocus.x)
        this.lastFocus.x += j; 
      popdownEditor();
      synchronized (getTreeLock()) {
        if (this.colmap != null) {
          int[] arrayOfInt = new int[this.colmap.length + j];
          for (byte b1 = 0, b2 = 0; b1 < this.colmap.length; b1++) {
            if (this.colmap[b1] < i + this.hcol) {
              arrayOfInt[b2++] = this.colmap[b1];
            } else if (this.colmap[b1] > i + this.hcol) {
              arrayOfInt[b2++] = this.colmap[b1] + j;
            } else {
              for (int k = 0; k <= j; k++)
                arrayOfInt[b2++] = this.colmap[b1] + k; 
            } 
          } 
          if (i + this.hcol >= this.colmap.length)
            for (int k = 0; k < j; k++)
              arrayOfInt[this.colmap.length + k] = this.colmap.length + k;  
          this.colmap = arrayOfInt;
        } 
        if (i + this.hcol < this.ncol)
          for (int k = 0; k < this.nrow; k++) {
            CellInfo cellInfo = getCellInfo(k - this.hrow, i, false);
            if (cellInfo != null && cellInfo.span != null && cellInfo.span.col != 0)
              setSpan(k - this.hrow, i, null); 
          }  
        this.gridinfo.insertCol(i + this.hcol, j);
        this.hcol = this.model.getHeaderColCount();
        this.ncol = this.model.getColCount() + this.hcol;
        this.gridX = new int[this.ncol + 1];
        this.selReg = null;
        this.lastFocus = new Point(-1, -1);
        resetRows();
      } 
    } else if (paramGridModelEvent.getID() == 64) {
      int i = paramGridModelEvent.getCol();
      int j = paramGridModelEvent.getColCount();
      this.mvalid = false;
      if (i <= this.lastFocus.x) {
        this.lastFocus.x -= j;
        if (this.lastFocus.x <= i)
          this.lastFocus = new Point(-1, -1); 
      } 
      popdownEditor();
      synchronized (getTreeLock()) {
        for (int k = 0; k < this.nrow; k++) {
          for (int m = i; m < i + j; m++) {
            CellInfo cellInfo = getCellInfo(k - this.hrow, m, false);
            if (cellInfo != null && cellInfo.span != null)
              setSpan(k - this.hrow, m, null); 
            if (cellInfo != null && cellInfo.component != null)
              getPane().remove(cellInfo.component); 
          } 
        } 
        if (this.colmap != null) {
          int[] arrayOfInt = new int[this.colmap.length - j];
          for (byte b1 = 0, b2 = 0; b1 < this.colmap.length; b1++) {
            if (this.colmap[b1] < i + this.hcol) {
              arrayOfInt[b2++] = this.colmap[b1];
            } else if (this.colmap[b1] >= i + this.hcol + j) {
              arrayOfInt[b2++] = this.colmap[b1] - j;
            } 
          } 
          this.colmap = arrayOfInt;
        } 
        this.gridinfo.removeCol(i + this.hcol, j);
        this.hcol = this.model.getHeaderColCount();
        this.ncol = this.model.getColCount() + this.hcol;
        this.gridX = new int[this.ncol + 1];
        this.selReg = null;
        this.lastFocus = new Point(-1, -1);
        resetRows();
      } 
    } else if (paramGridModelEvent.getID() == 1) {
      int i = paramGridModelEvent.getRow();
      int j = paramGridModelEvent.getRowCount();
      int k = paramGridModelEvent.getColCount();
      synchronized (getTreeLock()) {
        for (byte b = 0; b < j; b++, i++) {
          byte b1;
          int m;
          for (b1 = 0, m = paramGridModelEvent.getCol(); b1 < k; b1++, m++) {
            Object object1 = this.model.getObject(i, m);
            Object object2 = this.model.getObject(i, m);
            if (object1 instanceof Component) {
              Component component = (Component)object1;
              CellInfo cellInfo = getCellInfo(i, m, false);
              if (object2 != component && object2 instanceof Component) {
                ((Component)object2).removeMouseListener(this.forwarder);
                ((Component)object2).removeFocusListener(this.focusListener);
                ((Component)object2).removeMouseMotionListener(this.forwarder);
                getPane().remove((Component)object2);
                if (cellInfo != null) {
                  cellInfo.component = null;
                  if (cellInfo.span != null) {
                    Region region = cellInfo.span;
                    for (int n = 0; n < region.numRow; n++) {
                      for (int i1 = 0; i1 < region.numCol; i1++)
                        (getCellInfo(i + region.row + n, m + region.col + i1, true)).span = null; 
                    } 
                  } 
                } 
              } 
              if (component != null)
                addComponent(i, m, component); 
            } 
            getRowInfo(i).reset();
            getColInfo(m).reset();
          } 
        } 
      } 
    } 
    doRepaint(true);
  }
  
  public void moveRow(int paramInt1, int paramInt2) {
    if ((this.reorderable & true) == 0)
      throw new RuntimeException("Row re-ordering is not enabled!"); 
    synchronized (getTreeLock()) {
      int[] arrayOfInt = { paramInt1, paramInt2 };
      for (byte b1 = 0; b1 < arrayOfInt.length && arrayOfInt[b1] < this.model.getRowCount(); b1++) {
        for (int k = 0; k < this.ncol; k++) {
          CellInfo cellInfo = getCellInfo(arrayOfInt[b1], k - this.hcol, false);
          if (cellInfo != null && cellInfo.span != null && (arrayOfInt[b1] != paramInt2 || cellInfo.span.row != 0))
            setSpan(arrayOfInt[b1], k - this.hcol, null); 
        } 
      } 
      paramInt2 += this.hrow;
      paramInt1 += this.hrow;
      this.selReg = null;
      int i = this.rowmap[paramInt2];
      int j = this.rowmap[paramInt1];
      for (byte b2 = 0; b2 < this.rowmap.length; b2++) {
        if (b2 == paramInt2) {
          this.rowmap[b2] = j;
        } else if (b2 >= paramInt1 && b2 < paramInt2) {
          this.rowmap[b2] = this.rowmap[b2 + true];
        } else if (b2 > paramInt2 && b2 <= paramInt1) {
          int k = this.rowmap[b2];
          this.rowmap[b2] = i;
          i = k;
        } 
      } 
    } 
    doRepaint(true);
  }
  
  public void moveCol(int paramInt1, int paramInt2) {
    if ((this.reorderable & 0x2) == 0)
      throw new RuntimeException("Column re-ordering is not enabled!"); 
    synchronized (getTreeLock()) {
      int[] arrayOfInt = { paramInt1, paramInt2 };
      for (byte b1 = 0; b1 < arrayOfInt.length && arrayOfInt[b1] < this.model.getColCount(); b1++) {
        for (int k = 0; k < this.nrow; k++) {
          CellInfo cellInfo = getCellInfo(k - this.hrow, arrayOfInt[b1], false);
          if (cellInfo != null && cellInfo.span != null && (arrayOfInt[b1] != paramInt2 || cellInfo.span.col != 0))
            setSpan(k - this.hrow, arrayOfInt[b1], null); 
        } 
      } 
      paramInt2 += this.hcol;
      paramInt1 += this.hcol;
      this.selReg = null;
      int i = this.colmap[paramInt2];
      int j = this.colmap[paramInt1];
      for (byte b2 = 0; b2 < this.colmap.length; b2++) {
        if (b2 == paramInt2) {
          this.colmap[b2] = j;
        } else if (b2 >= paramInt1 && b2 < paramInt2) {
          this.colmap[b2] = this.colmap[b2 + true];
        } else if (b2 > paramInt2 && b2 <= paramInt1) {
          int k = this.colmap[b2];
          this.colmap[b2] = i;
          i = k;
        } 
      } 
    } 
    doRepaint(true);
  }
  
  public void setGap(int paramInt1, int paramInt2, Insets paramInsets) {
    synchronized (getTreeLock()) {
      setProperty(paramInt1, paramInt2, paramInsets, gapProperty);
      doRepaint(true);
    } 
  }
  
  public Insets getGap(int paramInt1, int paramInt2) { return (Insets)getProperty(paramInt1, paramInt2, gapProperty); }
  
  public void setAbsolute(int paramInt) {
    if (this.absolute != paramInt) {
      this.absolute = paramInt;
      doRepaint(true);
    } 
  }
  
  public int getAbsolute() { return this.absolute; }
  
  public void setResizable(int paramInt) { this.resizable = paramInt; }
  
  public int getResizable() { return this.resizable; }
  
  public void setReorderable(int paramInt) {
    this.reorderable = paramInt;
    synchronized (getTreeLock()) {
      if ((this.reorderable & true) != 0 || this.csort) {
        this.rowmap = new int[this.nrow];
        for (byte b = 0; b < this.rowmap.length; b++)
          this.rowmap[b] = b; 
      } else {
        this.rowmap = null;
      } 
      if ((this.reorderable & 0x2) != 0) {
        this.colmap = new int[this.ncol];
        for (byte b = 0; b < this.colmap.length; b++)
          this.colmap[b] = b; 
      } else {
        this.colmap = null;
      } 
    } 
  }
  
  public int getReorderable() { return this.reorderable; }
  
  public void setInPlaceResize(boolean paramBoolean) { this.inPlace = paramBoolean; }
  
  public boolean isInPlaceResize() { return this.inPlace; }
  
  public void setFillLastCol(boolean paramBoolean) {
    if (this.fillLastCol != paramBoolean) {
      this.fillLastCol = paramBoolean;
      doRepaint(true);
    } 
  }
  
  public boolean isFillLastCol() { return this.fillLastCol; }
  
  public void setSuspended(boolean paramBoolean) {
    this.suspend = paramBoolean;
    if (!paramBoolean)
      doRepaint(true); 
  }
  
  public boolean isSuspended() { return this.suspend; }
  
  public void setMinRowHeight(int paramInt1, int paramInt2) {
    synchronized (getTreeLock()) {
      if (paramInt1 == -99) {
        this.gridMinRowHeight = paramInt2;
      } else {
        RowInfo rowInfo = getRowInfo(paramInt1);
        rowInfo.minheight = paramInt2;
      } 
      doRepaint(true);
    } 
  }
  
  public int getMinRowHeight(int paramInt) { return (paramInt == -99) ? this.gridMinRowHeight : (getRowInfo(paramInt)).minheight; }
  
  public void setMinColWidth(int paramInt1, int paramInt2) {
    synchronized (getTreeLock()) {
      if (paramInt1 == -99) {
        this.gridMinColWidth = paramInt2;
      } else {
        ColInfo colInfo = getColInfo(paramInt1);
        colInfo.minwidth = paramInt2;
      } 
      doRepaint(true);
    } 
  }
  
  public int getMinColWidth(int paramInt) { return (paramInt == -99) ? this.gridMinColWidth : (getColInfo(paramInt)).minwidth; }
  
  public void setRowHeight(int paramInt1, int paramInt2) {
    synchronized (getTreeLock()) {
      if (paramInt1 == -99) {
        this.gridRowHeight = paramInt2;
      } else {
        (getRowInfo(paramInt1)).height = (paramInt2 > 0) ? new Integer(paramInt2) : null;
      } 
      doRepaint(true);
    } 
  }
  
  public int getRowHeight(int paramInt) {
    paramInt += this.hrow;
    return (this.rowHeight != null && paramInt < this.rowHeight.length) ? this.rowHeight[paramInt] : 0;
  }
  
  public void setColWidth(int paramInt1, int paramInt2) {
    synchronized (getTreeLock()) {
      if (paramInt1 == -99) {
        this.gridColWidth = paramInt2;
      } else {
        (getColInfo(paramInt1)).width = (paramInt2 > 0) ? new Integer(paramInt2) : null;
      } 
      if (isLineWrap())
        resetRows(); 
      doRepaint(true);
    } 
  }
  
  public int getColWidth(int paramInt) {
    paramInt += this.hcol;
    return (this.colWidth != null && paramInt < this.colWidth.length) ? this.colWidth[paramInt] : 0;
  }
  
  protected int[] calcRowHeight() {
    synchronized (getTreeLock()) {
      int[] arrayOfInt = new int[this.nrow];
      for (int i = 0; i < arrayOfInt.length && i < this.nrow; i++)
        arrayOfInt[i] = getPreferredRowHeight(i - this.hrow); 
      return arrayOfInt;
    } 
  }
  
  protected int[] calcColWidth() {
    synchronized (getTreeLock()) {
      int[] arrayOfInt = new int[this.ncol];
      for (int i = 0; i < arrayOfInt.length && i < this.ncol; i++)
        arrayOfInt[i] = getPreferredColWidth(i - this.hcol); 
      return arrayOfInt;
    } 
  }
  
  public void setBorder(int paramInt1, int paramInt2, int paramInt3) {
    setProperty(paramInt1, paramInt2, new Integer(paramInt3), borderProperty);
    doRepaint(true);
  }
  
  public int getBorder(int paramInt1, int paramInt2) {
    Integer integer = (Integer)getProperty(paramInt1, paramInt2, borderProperty);
    return (integer == null) ? 0 : integer.intValue();
  }
  
  public void setLineStyle(int paramInt) {
    if (this.mode3D != paramInt) {
      this.mode3D = paramInt;
      this.lineWidth = paramInt & 0xF;
      doRepaint(true);
    } 
  }
  
  public int getLineStyle() { return this.mode3D; }
  
  public void setBorderColor(Color paramColor) { this.borderC = paramColor; }
  
  public Color getBorderColor() { return this.borderC; }
  
  public void setMultiSelect(boolean paramBoolean) { this.multiSel = paramBoolean; }
  
  public boolean isMultiSelect() { return this.multiSel; }
  
  public void setRowSelectable(boolean paramBoolean) { this.rowSelectable = paramBoolean; }
  
  public void setColSelectable(boolean paramBoolean) { this.colSelectable = paramBoolean; }
  
  public boolean isRowSelectable() { return this.rowSelectable; }
  
  public boolean isColSelectable() { return this.colSelectable; }
  
  public void setRowHeaderSelect(boolean paramBoolean) { this.useRowHeader = paramBoolean; }
  
  public boolean isRowHeaderSelect() { return this.useRowHeader; }
  
  public void setColHeaderSelect(boolean paramBoolean) { this.useColHeader = paramBoolean; }
  
  public boolean isColHeaderSelect() { return this.useColHeader; }
  
  public void setRegionSelectable(boolean paramBoolean) { this.regSelectable = paramBoolean; }
  
  public boolean isRegionSelectable() { return this.regSelectable; }
  
  public void setRowMenu(int paramInt, JPopupMenu paramJPopupMenu) {
    JPopupMenu jPopupMenu;
    if (paramInt == -99) {
      jPopupMenu = this.rowMenu;
      this.rowMenu = paramJPopupMenu;
    } else {
      RowInfo rowInfo = getRowInfo(paramInt);
      jPopupMenu = rowInfo.menu;
      rowInfo.menu = paramJPopupMenu;
    } 
    if (jPopupMenu != null)
      remove(jPopupMenu); 
    if (paramJPopupMenu != null) {
      paramJPopupMenu.setLightWeightPopupEnabled(false);
      getPane().add(paramJPopupMenu);
      registerMenu(paramJPopupMenu);
    } 
  }
  
  public JPopupMenu getRowMenu(int paramInt) { return (paramInt == -99) ? this.rowMenu : (getRowInfo(paramInt)).menu; }
  
  public void setColMenu(int paramInt, JPopupMenu paramJPopupMenu) {
    JPopupMenu jPopupMenu;
    if (paramInt == -99) {
      jPopupMenu = this.colMenu;
      this.colMenu = paramJPopupMenu;
    } else {
      ColInfo colInfo = getColInfo(paramInt);
      jPopupMenu = colInfo.menu;
      colInfo.menu = paramJPopupMenu;
    } 
    if (jPopupMenu != null)
      remove(jPopupMenu); 
    if (paramJPopupMenu != null) {
      paramJPopupMenu.setLightWeightPopupEnabled(false);
      getPane().add(paramJPopupMenu);
      registerMenu(paramJPopupMenu);
    } 
  }
  
  public JPopupMenu getColMenu(int paramInt) { return (paramInt == -99) ? this.colMenu : (getColInfo(paramInt)).menu; }
  
  public void setSpan(int paramInt1, int paramInt2, Dimension paramDimension) {
    if (paramInt1 == -99 || paramInt2 == -99)
      throw new RuntimeException("ALL not suppored in Grid.setSpan()"); 
    if (paramDimension != null) {
      synchronized (getTreeLock()) {
        for (int i = 0; i < paramDimension.height; i++) {
          for (int j = 0; j < paramDimension.width; j++)
            (getCellInfo(paramInt1 + i, paramInt2 + j, true)).span = new Region(this, -i, -j, paramDimension.height, paramDimension.width); 
        } 
        getRowInfo(paramInt1).reset();
        getColInfo(paramInt2).reset();
        doRepaint(true);
      } 
    } else {
      synchronized (getTreeLock()) {
        CellInfo cellInfo = getCellInfo(paramInt1, paramInt2, false);
        if (cellInfo != null && cellInfo.span != null) {
          paramInt1 += cellInfo.span.row;
          paramInt2 += cellInfo.span.col;
          int i = cellInfo.span.numRow, j = cellInfo.span.numCol;
          for (int k = 0; k < i; k++) {
            for (int m = 0; m < j; m++)
              (getCellInfo(paramInt1 + k, paramInt2 + m, false)).span = null; 
          } 
        } 
      } 
    } 
  }
  
  public Dimension getSpan(int paramInt1, int paramInt2) {
    CellInfo cellInfo = getCellInfo(paramInt1, paramInt2, false);
    Region region = (cellInfo == null) ? null : cellInfo.span;
    return (region != null && 0 == region.row && 0 == region.col) ? new Dimension(region.numCol, region.numRow) : null;
  }
  
  public void setAlignment(int paramInt1, int paramInt2, int paramInt3) {
    setProperty(paramInt1, paramInt2, new Integer(paramInt3), alignProperty);
    doRepaint(true);
  }
  
  public int getAlignment(int paramInt1, int paramInt2) {
    Integer integer = (Integer)getProperty(paramInt1, paramInt2, alignProperty);
    return (integer == null) ? 0 : integer.intValue();
  }
  
  public void setFont(int paramInt1, int paramInt2, Font paramFont) {
    setProperty(paramInt1, paramInt2, paramFont, fontProperty);
    doRepaint(true);
  }
  
  public Font getFont(int paramInt1, int paramInt2) {
    Font font = (Font)getProperty(paramInt1, paramInt2, fontProperty);
    return (font == null) ? getFont() : font;
  }
  
  public void setRowVisible(int paramInt, boolean paramBoolean) {
    if (paramInt == -99) {
      for (byte b = 0; b < getRowCount(); b++)
        (getRowInfo(b)).hiden = paramBoolean; 
      doRepaint(true);
    } else if ((getRowInfo(paramInt)).hiden == paramBoolean) {
      (getRowInfo(paramInt)).hiden = !paramBoolean;
      doRepaint(true);
    } 
  }
  
  public boolean isRowVisible(int paramInt) { return !(getRowInfo(paramInt)).hiden; }
  
  public void setColVisible(int paramInt, boolean paramBoolean) {
    if (paramInt == -99) {
      for (byte b = 0; b < getColCount(); b++)
        (getColInfo(b)).hiden = paramBoolean; 
      doRepaint(true);
    } else if ((getColInfo(paramInt)).hiden == paramBoolean) {
      (getColInfo(paramInt)).hiden = !paramBoolean;
      doRepaint(true);
    } 
  }
  
  public boolean isColVisible(int paramInt) { return !(getColInfo(paramInt)).hiden; }
  
  public void setRowSelected(int paramInt, boolean paramBoolean) {
    if (paramInt == -99) {
      if (this.multiSel || !paramBoolean)
        for (byte b = 0; b < getRowCount(); b++)
          setRowSelected(b, paramBoolean);  
    } else if ((getRowInfo(paramInt)).selected != paramBoolean) {
      if (paramBoolean) {
        setSelectedRegion(null);
        if (!this.multiSel)
          clearSelection(); 
      } 
      (getRowInfo(paramInt)).selected = paramBoolean;
      doRepaint(false);
      this.eventMgr.postEvent(new GridItemEvent(this, new Integer(paramInt), paramBoolean ? 1 : 2, GridItemEvent.ROW));
    } 
  }
  
  public void setColSelected(int paramInt, boolean paramBoolean) {
    if (paramInt == -99) {
      if (this.multiSel)
        for (byte b = 0; b < getColCount(); b++)
          setColSelected(b, paramBoolean);  
    } else if ((getColInfo(paramInt)).selected != paramBoolean) {
      if (paramBoolean) {
        setSelectedRegion(null);
        if (!this.multiSel)
          clearSelection(); 
      } 
      (getColInfo(paramInt)).selected = paramBoolean;
      doRepaint(false);
      this.eventMgr.postEvent(new GridItemEvent(this, new Integer(paramInt), paramBoolean ? 1 : 2, GridItemEvent.COL));
    } 
  }
  
  public int getSelectedRow() {
    synchronized (getTreeLock()) {
      for (byte b = 0; b < getRowCount(); b++) {
        if ((getRowInfo(b)).selected)
          return b; 
      } 
    } 
    return -1;
  }
  
  public int[] getSelectedRows() {
    synchronized (getTreeLock()) {
      int[] arrayOfInt1 = new int[this.nrow];
      byte b1 = 0;
      for (byte b2 = 0; b2 < getRowCount(); b2++) {
        if ((getRowInfo(b2)).selected)
          arrayOfInt1[b1++] = b2; 
      } 
      int[] arrayOfInt2 = new int[b1];
      System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, b1);
      return arrayOfInt2;
    } 
  }
  
  public int getSelectedCol() {
    synchronized (getTreeLock()) {
      for (byte b = 0; b < getColCount(); b++) {
        if ((getColInfo(b)).selected)
          return b; 
      } 
    } 
    return -1;
  }
  
  public int[] getSelectedCols() {
    synchronized (getTreeLock()) {
      int[] arrayOfInt1 = new int[this.ncol];
      byte b1 = 0;
      for (byte b2 = 0; b2 < getColCount(); b2++) {
        if ((getColInfo(b2)).selected)
          arrayOfInt1[b1++] = b2; 
      } 
      int[] arrayOfInt2 = new int[b1];
      System.arraycopy(arrayOfInt1, 0, arrayOfInt2, 0, b1);
      return arrayOfInt2;
    } 
  }
  
  public Object[] getSelectedObjects() {
    if (this.hcol > 0)
      try {
        int[] arrayOfInt = getSelectedRows();
        String[] arrayOfString = new String[arrayOfInt.length];
        for (byte b = 0; b < arrayOfString.length; b++) {
          arrayOfString[b] = getObject(b, -1);
          validateModel();
        } 
        return arrayOfString;
      } catch (ModelChangedException modelChangedException) {
        doRepaint(true);
      }  
    return null;
  }
  
  public boolean isRowSelected(int paramInt) { return (getRowInfo(paramInt)).selected; }
  
  public boolean isColSelected(int paramInt) { return (getColInfo(paramInt)).selected; }
  
  public void clearSelection() {
    synchronized (getTreeLock()) {
      setSelectedRegion(null);
      setRowSelected(-99, false);
      setColSelected(-99, false);
    } 
  }
  
  public void setSelectedRegion(Region paramRegion) {
    if (paramRegion != null) {
      if (this.selReg == null || !this.selReg.equals(paramRegion)) {
        clearSelection();
        this.selReg = paramRegion;
        doRepaint(false);
        this.eventMgr.postEvent(new GridItemEvent(this, this.selReg, 1, GridItemEvent.REGION));
      } 
    } else if (this.selReg != null) {
      Region region = this.selReg;
      this.selReg = null;
      doRepaint(false);
      this.eventMgr.postEvent(new GridItemEvent(this, region, 2, GridItemEvent.REGION));
    } 
  }
  
  public Region getSelectedRegion() { return (this.selReg == null) ? null : this.selReg.normalize(); }
  
  public boolean isSelected(int paramInt1, int paramInt2) { return (isRowSelected(paramInt1) || isColSelected(paramInt2) || (this.selReg != null && this.selReg.contains(paramInt1, paramInt2))); }
  
  public void makeCellVisible(int paramInt1, int paramInt2) {
    if (!isRowOnScreen(paramInt1))
      setTopRow(paramInt1); 
    if (!isColOnScreen(paramInt2))
      setLeftCol(paramInt2); 
  }
  
  public void setTopRow(int paramInt) {
    this.root.y = paramInt;
    paramInt += this.hrow;
    try {
      Dimension dimension = getSize();
      if (this.oSize.width != dimension.width || this.oSize.height != dimension.height || this.rowHeight == null || this.colWidth == null || this.rowHeight.length != this.nrow || this.colWidth.length != this.ncol)
        recalc(); 
    } catch (ModelChangedException modelChangedException) {
      doRepaint(true);
      return;
    } 
    if (this.pixelOff.y != this.gridY[paramInt]) {
      this.pixelOff.y = this.gridY[paramInt];
      this.needLayout = true;
      getPane().repaint();
      if (this.scroller != null)
        this.scroller.notifySync(); 
    } 
  }
  
  public void setLeftCol(int paramInt) {
    this.root.x = paramInt;
    paramInt += this.hcol;
    try {
      Dimension dimension = getSize();
      if (this.oSize.width != dimension.width || this.oSize.height != dimension.height || this.rowHeight == null || this.colWidth == null || this.rowHeight.length != this.nrow || this.colWidth.length != this.ncol)
        recalc(); 
    } catch (ModelChangedException modelChangedException) {
      doRepaint(true);
      return;
    } 
    if (this.pixelOff.x != this.gridX[paramInt]) {
      this.pixelOff.x = this.gridX[paramInt];
      this.needLayout = true;
      getPane().repaint();
      if (this.scroller != null)
        this.scroller.notifySync(); 
    } 
  }
  
  public int getTopRow() { return Math.max(this.root.y, 0); }
  
  public int getLeftCol() { return Math.max(this.root.x, 0); }
  
  public void setFrozenRow(int paramInt) {
    if (this.frozen.y != paramInt) {
      this.frozen.y = paramInt;
      doRepaint(true);
    } 
  }
  
  public void setFrozenCol(int paramInt) {
    if (this.frozen.x != paramInt) {
      this.frozen.x = paramInt;
      doRepaint(true);
    } 
  }
  
  public int getFrozenRow() { return this.frozen.y; }
  
  public int getFrozenCol() { return this.frozen.x; }
  
  public void setHighlightFG(Color paramColor) { this.highlightFG = paramColor; }
  
  public Color getHighlightFG() { return this.highlightFG; }
  
  public void setHighlightBG(Color paramColor) { this.highlightBG = paramColor; }
  
  public Color getHighlightBG() { return this.highlightBG; }
  
  public void setHighlighted(int paramInt1, int paramInt2, boolean paramBoolean) {
    setProperty(paramInt1, paramInt2, new Boolean(paramBoolean), highlightedProperty);
    doRepaint(false);
  }
  
  public boolean isHighlighted(int paramInt1, int paramInt2) {
    Boolean bool = (Boolean)getProperty(paramInt1, paramInt2, highlightedProperty);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  public void validate() {
    if (this.needLayout)
      this.pane.layoutGrid(); 
    super.validate();
  }
  
  protected void registerMenu(MenuElement paramMenuElement) {
    if (paramMenuElement instanceof JMenuItem) {
      ((JMenuItem)paramMenuElement).removeActionListener(this.menuListener);
      ((JMenuItem)paramMenuElement).addActionListener(this.menuListener);
    } 
    MenuElement[] arrayOfMenuElement = paramMenuElement.getSubElements();
    for (byte b = 0; b < arrayOfMenuElement.length; b++)
      registerMenu(arrayOfMenuElement[b]); 
  }
  
  public void addComponentListener(ComponentListener paramComponentListener) { this.eventMgr.addComponentListener(paramComponentListener); }
  
  public void removeComponentListener(ComponentListener paramComponentListener) { this.eventMgr.removeComponentListener(paramComponentListener); }
  
  public void addItemListener(ItemListener paramItemListener) { this.eventMgr.addItemListener(paramItemListener); }
  
  public void removeItemListener(ItemListener paramItemListener) { this.eventMgr.removeItemListener(paramItemListener); }
  
  public void addActionListener(ActionListener paramActionListener) { this.eventMgr.addActionListener(paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.eventMgr.removeActionListener(paramActionListener); }
  
  public void addMouseListener(MouseListener paramMouseListener) { getPane().addMouseListener(paramMouseListener); }
  
  public void removeMouseListener(MouseListener paramMouseListener) { getPane().removeMouseListener(paramMouseListener); }
  
  public void addKeyListener(KeyListener paramKeyListener) { getPane().addKeyListener(paramKeyListener); }
  
  public void removeKeyListener(KeyListener paramKeyListener) { getPane().removeKeyListener(paramKeyListener); }
  
  protected void fetchRow(int paramInt) {}
  
  protected int[] getGridY() { return this.gridY; }
  
  protected int[] getGridX() { return this.gridX; }
  
  public void setSelectOnEntry(boolean paramBoolean) { this.selectOnEntry = paramBoolean; }
  
  public boolean isSelectOnEntry() { return this.selectOnEntry; }
  
  public void setEditable(int paramInt1, int paramInt2, boolean paramBoolean) { setProperty(paramInt1, paramInt2, new Boolean(paramBoolean), editableProperty); }
  
  public boolean isEditable(int paramInt1, int paramInt2) {
    Boolean bool = (Boolean)getProperty(paramInt1, paramInt2, editableProperty);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  public void setCopyEnabled(int paramInt1, int paramInt2, boolean paramBoolean) { setProperty(paramInt1, paramInt2, new Boolean(paramBoolean), copiableProperty); }
  
  public boolean isCopyEnabled(int paramInt1, int paramInt2) {
    Boolean bool = (Boolean)getProperty(paramInt1, paramInt2, copiableProperty);
    return (bool == null) ? false : bool.booleanValue();
  }
  
  public void setEditor(int paramInt1, int paramInt2, GridCellEditor paramGridCellEditor) {
    if (paramGridCellEditor != null) {
      Component component = (Component)paramGridCellEditor;
      component.setBackground(Color.white);
      component.setForeground(Color.black);
      component.removeKeyListener(this.forwarder);
      component.removeKeyListener(this.editorListener);
      component.removeFocusListener(this.editorListener);
      component.addKeyListener(this.forwarder);
      component.addKeyListener(this.editorListener);
      component.addFocusListener(this.editorListener);
      setEditable(paramInt1, paramInt2, true);
    } 
    setProperty(paramInt1, paramInt2, paramGridCellEditor, editorProperty);
  }
  
  public GridCellEditor getEditor(int paramInt1, int paramInt2) { return (GridCellEditor)getProperty(paramInt1, paramInt2, editorProperty); }
  
  public void setRenderer(int paramInt1, int paramInt2, GridCellRenderer paramGridCellRenderer) {
    ((Component)paramGridCellRenderer).setVisible(false);
    getPane().add((Component)paramGridCellRenderer);
    setProperty(paramInt1, paramInt2, paramGridCellRenderer, rendererProperty);
  }
  
  public GridCellRenderer getRenderer(int paramInt1, int paramInt2) { return (GridCellRenderer)getProperty(paramInt1, paramInt2, rendererProperty); }
  
  public void setLineWrap(boolean paramBoolean) {
    if (this.lineWrap != paramBoolean) {
      this.lineWrap = paramBoolean;
      doRepaint(true);
    } 
  }
  
  public boolean isLineWrap() { return this.lineWrap; }
  
  public void setDemandLoading(boolean paramBoolean) { this.delayed = paramBoolean; }
  
  public boolean isDemandLoading() { return this.delayed; }
  
  public void setFormat(int paramInt1, int paramInt2, Format paramFormat) {
    setProperty(paramInt1, paramInt2, paramFormat, formatProperty);
    doRepaint(true);
  }
  
  public Format getFormat(int paramInt1, int paramInt2) { return (Format)getProperty(paramInt1, paramInt2, formatProperty); }
  
  public void setComparer(int paramInt, Comparer paramComparer) { (getColInfo(paramInt)).comparer = paramComparer; }
  
  public Comparer getComparer(int paramInt) { return (getColInfo(paramInt)).comparer; }
  
  public void setForeground(int paramInt1, int paramInt2, Color paramColor) {
    setProperty(paramInt1, paramInt2, paramColor, foregroundProperty);
    doRepaint(false);
  }
  
  public Color getForeground(int paramInt1, int paramInt2) {
    Color color = (Color)getProperty(paramInt1, paramInt2, foregroundProperty);
    if (color == null)
      color = (paramInt1 <= -1 || paramInt2 <= -1) ? UIManager.getColor("TableHeader.foreground") : getForeground(); 
    return color;
  }
  
  public void setBackground(int paramInt1, int paramInt2, Color paramColor) {
    setProperty(paramInt1, paramInt2, paramColor, backgroundProperty);
    doRepaint(false);
  }
  
  public Color getBackground(int paramInt1, int paramInt2) {
    Color color = (Color)getProperty(paramInt1, paramInt2, backgroundProperty);
    if (color == null)
      color = (paramInt1 <= -1 || paramInt2 <= -1) ? UIManager.getColor("TableHeader.background") : getBackground(); 
    return color;
  }
  
  public void setSortable(boolean paramBoolean) {
    if (this.csort != paramBoolean) {
      this.csort = paramBoolean;
      if (paramBoolean)
        setReorderable(getReorderable() | true); 
      resetCols();
      doRepaint(true);
    } 
  }
  
  public boolean isSortable() { return this.csort; }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    for (byte b = 0; b < getComponentCount(); b++)
      setEnabled(getComponent(b), paramBoolean); 
    repaint();
  }
  
  private void setEnabled(Component paramComponent, boolean paramBoolean) {
    paramComponent.setEnabled(paramBoolean);
    if (paramComponent instanceof Container) {
      Container container = (Container)paramComponent;
      for (byte b = 0; b < getComponentCount(); b++)
        setEnabled(container.getComponent(b), paramBoolean); 
    } 
  }
  
  public void setFocus(int paramInt1, int paramInt2) {
    CellInfo cellInfo = getCellInfo(paramInt1, paramInt2, false);
    if (cellInfo != null && cellInfo.component != null) {
      cellInfo.component.requestFocus();
    } else if (isEditable(paramInt1, paramInt2) || isCopyEnabled(paramInt1, paramInt2)) {
      popupEditor(paramInt1, paramInt2);
    } 
  }
  
  public void popdownEditor() {
    synchronized (getTreeLock()) {
      if (this.editor != null) {
        GridCellEditor gridCellEditor = this.editor;
        this.editor = null;
        try {
          Object object = gridCellEditor.getCellEditorValue();
          ((Component)gridCellEditor).setVisible(false);
          getPane().remove((Component)gridCellEditor);
          getPane().requestFocus();
          if (this.lastFocus.x >= 0 && this.lastFocus.y >= 0 && this.lastFocus.x < getColCount() && this.lastFocus.y < getRowCount()) {
            Object object1 = getObject(this.lastFocus.y, this.lastFocus.x);
            if (object1 == null || !object1.equals(object))
              setObject(this.lastFocus.y, this.lastFocus.x, object); 
            this.eventMgr.postEvent(new GridActionEvent(this, "edit", this.lastFocus));
          } 
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
      } 
      this.ignoreFocus++;
    } 
  }
  
  public void popupEditor(int paramInt1, int paramInt2) {
    synchronized (getTreeLock()) {
      makeCellVisible(paramInt1, paramInt2);
      CellInfo cellInfo = getCellInfo(paramInt1, paramInt2, false);
      TextFieldEditor textFieldEditor = getEditor(paramInt1, paramInt2);
      Rectangle rectangle = getBounds(paramInt1, paramInt2);
      int i = (cellInfo != null && cellInfo.span != null) ? cellInfo.span.numRow : 1;
      boolean bool = isEditable(paramInt1, paramInt2);
      if (textFieldEditor == null)
        if (i > 1) {
          TextAreaEditor textAreaEditor = this.textarea;
        } else {
          textFieldEditor = this.textfield;
          this.textfield.setFormat(getFormat(paramInt1, paramInt2));
        }  
      textFieldEditor.removeActionListener(this.editorListener);
      textFieldEditor.setCellValue(paramInt1, paramInt2, getObject(paramInt1, paramInt2));
      if (textFieldEditor instanceof JTextComponent) {
        ((JTextComponent)textFieldEditor).setEditable(bool);
        if (this.selectOnEntry)
          ((JTextComponent)textFieldEditor).selectAll(); 
      } 
      Component component = (Component)textFieldEditor;
      getPane().add(component);
      textFieldEditor.addActionListener(this.editorListener);
      component.setBounds(rectangle);
      component.validate();
      component.setVisible(true);
      component.requestFocus();
      this.editor = textFieldEditor;
      this.lastFocus = new Point(paramInt2, paramInt1);
    } 
    doRepaint(false);
  }
  
  protected void nextCellFocus() {
    popdownEditor();
    if (getRowCount() == 0 || getColCount() == 0)
      return; 
    int i = this.lastFocus.y, j = this.lastFocus.x;
    if (this.lastFocus.y == -1 || this.lastFocus.x == -1)
      i = 0; 
    while (true) {
      j++;
      if (j >= getColCount()) {
        i++;
        j = 0;
      } 
      if (i >= getRowCount())
        i = 0; 
      if (i == this.lastFocus.y && j == this.lastFocus.x) {
        this.lastFocus.x = this.lastFocus.y = -1;
        break;
      } 
      CellInfo cellInfo = getCellInfo(i, j, false);
      Component component = (cellInfo != null) ? cellInfo.component : null;
      if (component != null && component.isFocusTraversable() && component.isEnabled()) {
        this.lastFocus = new Point(j, i);
        if (this.selectOnEntry && component instanceof TextComponent)
          ((TextComponent)component).selectAll(); 
        component.requestFocus();
        break;
      } 
      if (isEditable(i, j)) {
        popupEditor(i, j);
        break;
      } 
    } 
    Dimension dimension = getPane().getSize();
    Rectangle rectangle = getBounds(i, j);
    if (rectangle.x + rectangle.width > dimension.width) {
      setLeftCol(getLeftCol() + 1);
    } else if (rectangle.x < 0) {
      setLeftCol(j);
    } 
    if (rectangle.y + rectangle.height > dimension.height) {
      setTopRow(getTopRow() + 1);
    } else if (rectangle.y < 0) {
      setTopRow(i);
    } 
  }
  
  protected Container getPane() { return this.pane; }
  
  class Pane extends Container implements Scrollable {
    private int startRow;
    
    private int startCol;
    
    private Point pressedLoc;
    
    private final Grid this$0;
    
    Pane(Grid this$0) {
      this.this$0 = this$0;
      enableEvents(56L);
      this.startRow = -1;
      this.startCol = -1;
      this.pressedLoc = null;
    }
    
    public void registerScrollControl(ScrollControl param1ScrollControl) {
      this.this$0.scroller = param1ScrollControl;
      byte b = ((param1ScrollControl.getScrollOption() & true) != 0) ? 2 : 0;
      b |= (((param1ScrollControl.getScrollOption() & 0x4) != 0) ? 1 : 0);
      this.this$0.setAbsolute(b);
    }
    
    public Dimension getPreferredSize() {
      Dimension dimension = new Dimension(0, 0);
      int i = this.this$0.getBorder(-99, -99);
      synchronized (getTreeLock()) {
        try {
          if (!this.this$0.mvalid)
            this.this$0.recalc(); 
          for (int j = 0; j < this.this$0.nrow; j++)
            dimension.height += this.this$0.getPreferredRowHeight(j - this.this$0.hrow); 
          dimension.height += (((i & 0x2) != 0) ? ((this.this$0.visibleRows(this.this$0.nrow) - 1) * this.this$0.lineWidth) : 0);
          for (int k = 0; k < this.this$0.ncol; k++)
            dimension.width += this.this$0.getPreferredColWidth(k - this.this$0.hcol); 
          dimension.width += (((i & true) != 0) ? ((this.this$0.visibleCols(this.this$0.ncol) - 1) * this.this$0.lineWidth) : 0);
        } catch (ModelChangedException modelChangedException) {
          this.this$0.doRepaint(true);
        } 
      } 
      return dimension;
    }
    
    public Dimension getMinimumSize() { return getPreferredSize(); }
    
    public void layoutGrid() {
      synchronized (getTreeLock()) {
        Dimension dimension = getSize();
        int i = this.this$0.getBorder(-99, -99);
        int j = ((i & true) != 0) ? this.this$0.lineWidth : 0;
        int k = ((i & 0x2) != 0) ? this.this$0.lineWidth : 0;
        if (dimension.width == 0 || dimension.height == 0 || this.this$0.suspend)
          return; 
        this.this$0.needLayout = false;
        this.this$0.recalc();
        this.this$0.validateModel();
        Rectangle rectangle = new Rectangle(0, 0, 0, 0);
        for (int m = 0; m < this.this$0.nrow; m++) {
          int i1 = m - this.this$0.hrow;
          if (this.this$0.isRowOnScreen(i1)) {
            if (i1 >= this.this$0.getFrozenRow() && rectangle.height == 0)
              rectangle.y = i1; 
            rectangle.height = i1 - rectangle.y + 1;
            for (int i2 = 0; i2 < this.this$0.ncol; i2++) {
              int i3 = i2 - this.this$0.hcol;
              if (this.this$0.isColOnScreen(i3)) {
                if (i3 >= this.this$0.getFrozenCol() && rectangle.width == 0)
                  rectangle.x = i3; 
                rectangle.width = i3 - rectangle.x + 1;
                Object object = this.this$0.getObject(i1, i3);
                this.this$0.validateModel();
                if (object instanceof Component) {
                  Component component = (Component)object;
                  Rectangle rectangle1 = this.this$0.getVirtualBounds(i1, i3);
                  Rectangle rectangle2 = this.this$0.getBounds(i1, i3, rectangle1);
                  boolean bool = (rectangle2.x != rectangle1.x || rectangle2.y != rectangle1.y) ? 1 : 0;
                  if (!bool && component.getParent() != null && component.getParent() != this) {
                    this.this$0.getPane().remove(component.getParent());
                    this.this$0.getPane().add(component);
                  } 
                  Container container = component.getParent();
                  if (container != this && (container == null || container.getParent() != this))
                    this.this$0.addComponent(i1, i3, component); 
                  component.setVisible(true);
                  if (bool) {
                    if (container == this || container == null) {
                      container = new JPanel();
                      container.add(component);
                      container.setLayout(null);
                      this.this$0.getPane().add(container);
                    } 
                    container.setBounds(rectangle2);
                    rectangle1.x -= rectangle2.x;
                    rectangle1.y -= rectangle2.y;
                    rectangle2.width = rectangle1.width;
                    rectangle2.height = rectangle1.height;
                  } 
                  int i4 = this.this$0.getAlignment(i1, i3);
                  if (i4 != 0) {
                    Dimension dimension1 = this.this$0.getPreferredSize(i1, i3);
                    rectangle2 = GridBase.alignCell(rectangle2, dimension1, i4);
                  } 
                  component.setBounds(rectangle2.x, rectangle2.y, rectangle2.width, rectangle2.height);
                  component.validate();
                } 
              } 
            } 
          } 
        } 
        this.this$0.validateModel();
        int n = this.this$0.visReg.y;
        for (; n < this.this$0.visReg.y + this.this$0.visReg.height && n < this.this$0.getRowCount(); n++) {
          int i1 = this.this$0.visReg.x;
          for (; i1 < this.this$0.visReg.x + this.this$0.visReg.width && i1 < this.this$0.getColCount(); i1++) {
            if (!rectangle.contains(i1, n)) {
              CellInfo cellInfo = this.this$0.getCellInfo(n, i1, false);
              if (cellInfo != null && cellInfo.component != null) {
                cellInfo.component.setVisible(false);
                Container container = cellInfo.component.getParent();
                if (container != null && container != this)
                  container.setVisible(false); 
              } 
            } 
          } 
        } 
        this.this$0.visReg = rectangle;
      } 
      if (this.this$0.editor != null) {
        Point point = ((Component)this.this$0.editor).getLocation();
        Rectangle rectangle = this.this$0.getVirtualBounds(this.this$0.lastFocus.y, this.this$0.lastFocus.x);
        if (point.x != rectangle.x || point.y != rectangle.y)
          ((Component)this.this$0.editor).setBounds(rectangle); 
      } 
      if (this.this$0.scroller != null)
        this.this$0.scroller.notifyUpdate(this.this$0); 
    }
    
    public void paint(Graphics param1Graphics) {
      synchronized (getTreeLock()) {
        Dimension dimension = getSize();
        if (dimension.width <= 0 || dimension.height <= 0 || this.this$0.suspend || this.this$0.getBackground() == null)
          return; 
        if (this.this$0.oSize.width != dimension.width || this.this$0.oSize.height != dimension.height) {
          this.this$0.needLayout = true;
          this.this$0.oSize = dimension;
          this.this$0.buffer = createImage(dimension.width, dimension.height);
        } 
        if (this.this$0.needLayout)
          try {
            layoutGrid();
          } catch (ModelChangedException modelChangedException) {
            this.this$0.doRepaint(true);
            return;
          }  
        Graphics graphics = (param1Graphics instanceof java.awt.PrintGraphics) ? param1Graphics : this.this$0.buffer.getGraphics();
        graphics.setColor(this.this$0.getBackground());
        graphics.fillRect(0, 0, dimension.width, dimension.height);
        graphics.setFont(this.this$0.getFont());
        Color color1 = this.this$0.borderC;
        if (color1 == null) {
          color1 = this.this$0.getBackground();
          if ((this.this$0.mode3D & 0x1000) != 0) {
            Color color = this.this$0.getForeground();
            color1 = new Color((color1.getRed() + color.getRed()) / 2, (color1.getGreen() + color.getGreen()) / 2, (color1.getBlue() + color.getBlue()) / 2);
          } 
        } 
        graphics.setColor(color1);
        Vector vector1 = new Vector();
        Vector vector2 = new Vector();
        Point point = new Point(this.this$0.gridX[this.this$0.hcol + this.this$0.frozen.x], this.this$0.gridY[this.this$0.hrow + this.this$0.frozen.y]);
        int i;
        label174: for (i = 0; i < this.this$0.nrow; i++) {
          int j = i - this.this$0.hrow;
          if (this.this$0.isRowOnScreen(j)) {
            this.this$0.fetchRow(j);
            for (int k = 0; k < this.this$0.ncol; k++) {
              int m = k - this.this$0.hcol;
              j = i - this.this$0.hrow;
              if (!this.this$0.isColOnScreen(m))
                continue; 
              CellInfo cellInfo = this.this$0.getCellInfo(j, m, false);
              if (cellInfo != null && cellInfo.span != null)
                if ((cellInfo.span.row == 0 || (this.this$0.gridY[j + this.this$0.hrow] <= this.this$0.pixelOff.y && this.this$0.gridY[j + this.this$0.hrow + 1] > this.this$0.pixelOff.y)) && (cellInfo.span.col == 0 || (this.this$0.gridX[m + this.this$0.hcol] <= this.this$0.pixelOff.x && this.this$0.gridX[m + this.this$0.hcol + 1] > this.this$0.pixelOff.x))) {
                  j += cellInfo.span.row;
                  m += cellInfo.span.col;
                  cellInfo = this.this$0.getCellInfo(j, m, false);
                } else {
                  continue;
                }  
              Rectangle rectangle1 = this.this$0.getVirtualBounds(j, m, false);
              Rectangle rectangle2 = this.this$0.getBounds(j, m, rectangle1);
              if (rectangle1.y > dimension.height)
                break label174; 
              if (rectangle1.x > dimension.width)
                break; 
              boolean bool1 = (this.this$0.hasBorder(j, m, 1) && j > -1 && m > -1) ? 1 : 0;
              boolean bool2 = (this.this$0.hasBorder(j, m, 2) && j > -1 && m > -1) ? 1 : 0;
              int n = (this.this$0.lineWidth > 1 && bool1) ? this.this$0.lineWidth : 0;
              int i1 = (this.this$0.lineWidth > 1 && bool2) ? this.this$0.lineWidth : 0;
              graphics.setColor(color1);
              if (bool1 && rectangle2.x + rectangle2.width < dimension.width)
                Tool.drawVLine(graphics, rectangle2.x + rectangle2.width, rectangle2.y, rectangle2.y + rectangle2.height, this.this$0.mode3D); 
              if (bool2 && rectangle2.y + rectangle2.height < dimension.height)
                Tool.drawHLine(graphics, rectangle2.y + rectangle2.height, rectangle2.x, rectangle2.x + rectangle2.width, this.this$0.mode3D); 
              if (this.this$0.mode3D != 4113 && bool1 && bool2 && rectangle2.y + rectangle2.height < dimension.height && rectangle2.x + rectangle2.width < dimension.width) {
                vector1.addElement(new Point(rectangle2.x + rectangle2.width, rectangle2.y + rectangle2.height));
                vector2.addElement(new Point(m, j));
              } 
              if (cellInfo == null || cellInfo.component == null)
                try {
                  if (j <= -1 || m <= -1) {
                    this.this$0.paintHeader(graphics, j, m);
                  } else {
                    paintCell(graphics, j, m, rectangle2);
                  } 
                } catch (ModelChangedException modelChangedException) {
                  this.this$0.doRepaint(true);
                  return;
                }  
              continue;
            } 
          } 
        } 
        Color color2 = (this.this$0.mode3D == 24578) ? color1.darker() : color1.brighter();
        Color color3 = (this.this$0.mode3D == 24578) ? color1.brighter() : color1.darker();
        for (byte b = 0; b < vector2.size(); b++) {
          Point point1 = (Point)vector1.elementAt(b);
          Point point2 = (Point)vector2.elementAt(b);
          graphics.setColor(color1);
          graphics.fillRect(point1.x, point1.y, this.this$0.lineWidth, this.this$0.lineWidth);
          if ((this.this$0.mode3D & 0x1000) == 0) {
            boolean bool1 = false;
            boolean bool2 = false;
            if (point2.x + this.this$0.hcol < this.this$0.ncol - 1) {
              CellInfo cellInfo = this.this$0.getCellInfo(point2.y, point2.x + 1, false);
              if (cellInfo != null && cellInfo.span != null && 1 - cellInfo.span.row != cellInfo.span.numRow) {
                bool1 = false;
              } else {
                Point point3 = (cellInfo == null || cellInfo.span == null) ? point2 : new Point(point2.y + cellInfo.span.row, point2.x + cellInfo.span.col);
                bool1 = ((this.this$0.getBorder(point3.y, point3.x + 1) & 0x2) != 0) ? 1 : 0;
              } 
            } 
            if (point2.y + this.this$0.hrow < this.this$0.nrow - 1) {
              CellInfo cellInfo = this.this$0.getCellInfo(point2.y + 1, point2.x, false);
              if (cellInfo != null && cellInfo.span != null && 1 - cellInfo.span.col != cellInfo.span.numCol) {
                bool2 = false;
              } else {
                Point point3 = (cellInfo == null || cellInfo.span == null) ? point2 : new Point(point2.y + cellInfo.span.row, point2.x + cellInfo.span.col);
                bool2 = ((this.this$0.getBorder(point3.y + 1, point3.x) & true) != 0) ? 1 : 0;
              } 
            } 
            if (this.this$0.mode3D == 24578 || this.this$0.mode3D == 40962) {
              int j = this.this$0.lineWidth / 2;
              int[] arrayOfInt1 = { point1.x, point1.x + j, point1.x + j };
              int[] arrayOfInt2 = { point1.y + this.this$0.lineWidth, point1.y + j, point1.y + this.this$0.lineWidth };
              int[] arrayOfInt3 = { point1.x + j, point1.x + this.this$0.lineWidth, point1.x + this.this$0.lineWidth };
              int[] arrayOfInt4 = { point1.y + j, point1.y, point1.y + j };
              graphics.setColor(color2);
              graphics.fillRect(point1.x, point1.y, this.this$0.lineWidth, this.this$0.lineWidth);
              graphics.setColor(color3);
              graphics.fillRect(point1.x, point1.y, j, j);
              if (bool2)
                graphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length); 
              if (bool1)
                graphics.fillPolygon(arrayOfInt3, arrayOfInt4, arrayOfInt3.length); 
            } else if (this.this$0.mode3D == 24580 || this.this$0.mode3D == 40964) {
              graphics.setColor(color3);
              if (!bool2)
                graphics.drawLine(point1.x, point1.y + this.this$0.lineWidth - 1, point1.x + this.this$0.lineWidth - 1, point1.y + this.this$0.lineWidth - 1); 
              if (!bool1)
                graphics.drawLine(point1.x + this.this$0.lineWidth - 1, point1.y, point1.x + this.this$0.lineWidth - 1, point1.y + this.this$0.lineWidth - 1); 
            } 
          } 
        } 
        graphics.setClip(0, 0, dimension.width, dimension.height);
        super.paint(graphics);
        if (!(param1Graphics instanceof java.awt.PrintGraphics)) {
          param1Graphics.drawImage(this.this$0.buffer, 0, 0, this);
          graphics.dispose();
        } 
      } 
    }
    
    public void update(Graphics param1Graphics) { paint(param1Graphics); }
    
    protected void paintCell(Graphics param1Graphics, int param1Int1, int param1Int2, Rectangle param1Rectangle) {
      CellInfo cellInfo = this.this$0.getCellInfo(param1Int1, param1Int2, false);
      int i = this.this$0.getAlignment(param1Int1, param1Int2);
      Object object = this.this$0.getObject(param1Int1, param1Int2);
      this.this$0.validateModel();
      if (cellInfo != null && cellInfo.span != null && (cellInfo.span.row != 0 || cellInfo.span.col != 0))
        return; 
      Rectangle rectangle1 = this.this$0.getVirtualBounds(param1Int1, param1Int2);
      Rectangle rectangle2 = this.this$0.getBounds(param1Int1, param1Int2, rectangle1);
      boolean bool = (this.this$0.isHighlighted(param1Int1, param1Int2) || this.this$0.isSelected(param1Int1, param1Int2)) ? 1 : 0;
      Color color1 = (bool && this.this$0.getHighlightFG() != null) ? this.this$0.getHighlightFG() : this.this$0.getForeground(param1Int1, param1Int2);
      Color color2 = (bool && this.this$0.getHighlightBG() != null) ? this.this$0.getHighlightBG() : this.this$0.getBackground(param1Int1, param1Int2);
      if (!color2.equals(this.this$0.getBackground())) {
        param1Graphics.setColor(color2);
        param1Graphics.fillRect(param1Rectangle.x, param1Rectangle.y, param1Rectangle.width, param1Rectangle.height);
      } 
      this.this$0.validateModel();
      if (rectangle2.width > 0 && rectangle2.height > 0) {
        Graphics graphics = param1Graphics.create(rectangle2.x, rectangle2.y, rectangle2.width, rectangle2.height);
        if (object instanceof Image) {
          graphics.drawImage((Image)object, 0, 0, this.this$0);
        } else {
          GridCellRenderer gridCellRenderer = this.this$0.getRenderer(param1Int1, param1Int2);
          if (gridCellRenderer != null) {
            gridCellRenderer.setCellValue(param1Int1, param1Int2, object);
            Component component = (Component)gridCellRenderer;
            component.setForeground(color1);
            component.setBackground(color2);
            Dimension dimension = component.getPreferredSize();
            rectangle2.x = rectangle2.y = 0;
            Rectangle rectangle = GridBase.alignCell(rectangle2, dimension, this.this$0.getAlignment(param1Int1, param1Int2));
            component.setBounds(0, 0, rectangle.width, rectangle.height);
            component.validate();
            graphics.translate(rectangle.x, rectangle.y);
            component.paint(graphics);
          } else if (object != null) {
            Format format = this.this$0.getFormat(param1Int1, param1Int2);
            String str = object.toString();
            if (format != null)
              try {
                str = format.format(object);
              } catch (Exception exception) {} 
            graphics.setColor(isEnabled() ? color1 : (color1.equals(Color.black) ? Color.gray : color1.brighter()));
            graphics.setFont(this.this$0.getFont(param1Int1, param1Int2));
            rectangle1.x -= rectangle2.x;
            rectangle1.y -= rectangle2.y;
            GridBase.paintText(graphics, str, rectangle1, i, this.this$0.isLineWrap());
          } 
        } 
        graphics.dispose();
      } 
    }
    
    public void setCursor0(Cursor param1Cursor) {
      if (this.this$0.defaultCursor == null)
        this.this$0.defaultCursor = getCursor(); 
      if (param1Cursor != null)
        setCursor(param1Cursor); 
    }
    
    public void processMouseMotionEvent(MouseEvent param1MouseEvent) {
      if (!isEnabled())
        return; 
      if (!this.this$0.moving && this.this$0.resizable != 0 && param1MouseEvent.getX() >= 0 && param1MouseEvent.getY() >= 0)
        if (param1MouseEvent.getID() == 503) {
          if (!this.this$0.resizeLineC.isVisible() && !this.this$0.resizeLineR.isVisible()) {
            Point point = this.this$0.findResizeCell(param1MouseEvent.getX(), param1MouseEvent.getY());
            if (this.this$0.cursorChanged && point.x < 0 && point.y < 0) {
              setCursor0(this.this$0.defaultCursor);
              this.this$0.cursorChanged = false;
            } else if ((!this.this$0.cursorChanged || this.this$0.resizeC < 0 || this.this$0.resizeR < 0) && point.x >= 0 && point.y >= 0 && (this.this$0.resizable & true) != 0 && (this.this$0.resizable & 0x2) != 0) {
              setCursor0(new Cursor(5));
              this.this$0.resizeC = point.x;
              this.this$0.resizeR = point.y;
              this.this$0.cursorChanged = true;
            } else if ((!this.this$0.cursorChanged || this.this$0.resizeC < 0 || this.this$0.resizeR >= 0) && point.x >= 0 && (this.this$0.resizable & 0x2) != 0) {
              setCursor0(new Cursor(11));
              this.this$0.resizeC = point.x;
              this.this$0.resizeR = -1;
              this.this$0.cursorChanged = true;
            } else if ((!this.this$0.cursorChanged || this.this$0.resizeR < 0 || this.this$0.resizeC >= 0) && point.y >= 0 && (this.this$0.resizable & true) != 0) {
              setCursor0(new Cursor(9));
              this.this$0.resizeR = point.y;
              this.this$0.resizeC = -1;
              this.this$0.cursorChanged = true;
            } 
          } 
        } else if (param1MouseEvent.getID() == 506) {
          if (this.this$0.resizeLineC.isVisible() || this.this$0.resizeLineR.isVisible()) {
            if (this.this$0.resizeC >= 0 && param1MouseEvent.getX() > this.this$0.colX(this.this$0.resizeC - this.this$0.hcol) && (!this.this$0.inPlace || param1MouseEvent.getX() < this.this$0.colX(this.this$0.resizeC + 2 - this.this$0.hcol))) {
              this.this$0.resizeLineC.setLocation(param1MouseEvent.getX(), 0);
              this.this$0.linePos.x = param1MouseEvent.getX();
            } 
            if (this.this$0.resizeR >= 0 && param1MouseEvent.getY() > this.this$0.rowY(this.this$0.resizeR - this.this$0.hrow) && (!this.this$0.inPlace || param1MouseEvent.getY() < this.this$0.rowY(this.this$0.resizeR + 2 - this.this$0.hrow))) {
              this.this$0.resizeLineR.setLocation(0, param1MouseEvent.getY());
              this.this$0.linePos.y = param1MouseEvent.getY();
            } 
          } 
        }  
      if (param1MouseEvent.getID() == 506) {
        Point point = this.this$0.locateCell(param1MouseEvent.getX(), param1MouseEvent.getY());
        if (this.this$0.moving) {
          this.this$0.moveBox.setLocation(this.this$0.moveOff.x + param1MouseEvent.getX(), this.this$0.moveOff.y + param1MouseEvent.getY());
        } else if (point != null && !this.this$0.resizeLineC.isVisible() && !this.this$0.resizeLineR.isVisible()) {
          if ((point.x <= -1 && (this.this$0.reorderable & true) != 0) || (point.y <= -1 && (this.this$0.reorderable & 0x2) != 0)) {
            this.this$0.moving = true;
            this.this$0.movePos = point;
            Rectangle rectangle = this.this$0.getBounds(point.y, point.x);
            this.this$0.moveOff = new Point(rectangle.x - param1MouseEvent.getX(), rectangle.y - param1MouseEvent.getY());
            this.this$0.moveBox.setLocation(this.this$0.moveOff.x + param1MouseEvent.getX(), this.this$0.moveOff.y + param1MouseEvent.getY());
            this.this$0.moveBox.setSize(rectangle.width, rectangle.height);
            this.this$0.moveBox.setVisible(true);
            setCursor0(new Cursor(12));
          } else if (this.this$0.selReg != null && this.this$0.isRegionSelectable()) {
            this.this$0.setSelectedRegion(new Grid.Region(this.this$0, this.this$0.selReg.row, this.this$0.selReg.col, point.y - this.this$0.selReg.row + 1, point.x - this.this$0.selReg.col + 1));
          } else if (!this.this$0.useRowHeader && point.y > -1 && this.this$0.isRowSelectable()) {
            if (this.this$0.multiSel) {
              this.this$0.clearSelection();
              int i = Math.min(this.startRow, point.y);
              int j = Math.max(this.startRow, point.y);
              for (; i <= j; i++)
                this.this$0.setRowSelected(i, true); 
            } else {
              this.this$0.setRowSelected(point.y, true);
            } 
          } else if (!this.this$0.useColHeader && point.x > -1 && this.this$0.isColSelectable()) {
            if (this.this$0.multiSel) {
              this.this$0.clearSelection();
              int i = Math.min(this.startCol, point.x);
              int j = Math.max(this.startCol, point.x);
              for (; i <= j; i++)
                this.this$0.setColSelected(i, true); 
            } else {
              this.this$0.setColSelected(point.x, true);
            } 
          } 
        } 
      } 
      super.processMouseMotionEvent(param1MouseEvent);
    }
    
    public void processMouseEvent(MouseEvent param1MouseEvent) {
      if (!isEnabled())
        return; 
      Point point1 = this.this$0.locateCell(param1MouseEvent.getX(), param1MouseEvent.getY());
      int i = this.this$0.getBorder(-99, -99);
      if (param1MouseEvent.getID() == 501) {
        this.pressedLoc = point1;
        if (point1 == null || point1.x != this.this$0.lastFocus.x || point1.y != this.this$0.lastFocus.y)
          this.this$0.popdownEditor(); 
      } else if (param1MouseEvent.getID() == 502 && this.pressedLoc != null && point1 != null && this.pressedLoc.x == point1.x && this.pressedLoc.y == point1.y) {
        this.pressedLoc = null;
        if (this.this$0.csort && point1.y <= -1 && point1.x > -1) {
          this.this$0.lastOrder = (this.this$0.lastSort != point1.x) ? true : (!this.this$0.lastOrder);
          this.this$0.arrow = point1;
          this.this$0.arrowDown = this.this$0.lastOrder;
          this.this$0.sort(this.this$0.lastSort = point1.x, this.this$0.lastOrder);
        } else if (point1 != null && (this.this$0.editor == null || point1.x != this.this$0.lastFocus.x || point1.y != this.this$0.lastFocus.y) && point1.y > -1 && point1.x > -1) {
          CellInfo cellInfo = this.this$0.getCellInfo(point1.y, point1.x, false);
          if ((cellInfo == null || cellInfo.component == null) && (this.this$0.isEditable(point1.y, point1.x) || this.this$0.isCopyEnabled(point1.y, point1.x))) {
            this.this$0.popupEditor(point1.y, point1.x);
            Component component = (Component)this.this$0.editor;
            Point point = component.getLocation();
            MouseEvent mouseEvent = new MouseEvent(component, 501, param1MouseEvent.getWhen(), param1MouseEvent.getModifiers(), param1MouseEvent.getX() - point.x, param1MouseEvent.getY() - point.y, param1MouseEvent.getClickCount(), param1MouseEvent.isPopupTrigger());
            component.dispatchEvent(mouseEvent);
            mouseEvent = new MouseEvent(component, 502, param1MouseEvent.getWhen(), param1MouseEvent.getModifiers(), param1MouseEvent.getX() - point.x, param1MouseEvent.getY() - point.y, param1MouseEvent.getClickCount(), param1MouseEvent.isPopupTrigger());
            component.dispatchEvent(mouseEvent);
          } 
        } 
      } 
      if (param1MouseEvent.getID() == 501 && param1MouseEvent.getSource() == this)
        requestFocus(); 
      if (!this.this$0.moving && this.this$0.resizable != 0 && param1MouseEvent.getX() >= 0 && param1MouseEvent.getY() >= 0) {
        if (param1MouseEvent.getID() == 501 && this.this$0.cursorChanged && !this.this$0.resizeLineC.isVisible() && !this.this$0.resizeLineR.isVisible()) {
          this.this$0.linePos = new Point(param1MouseEvent.getX(), param1MouseEvent.getY());
          if (this.this$0.resizeC >= 0) {
            this.this$0.linePos.x = this.this$0.colX(this.this$0.resizeC + 1 - this.this$0.hcol) - (((i & true) != 0) ? this.this$0.lineWidth : 0);
            this.this$0.resizeLineC.setVisible(true);
            this.this$0.resizeLineC.setBounds(this.this$0.linePos.x, 0, this.this$0.lineWidth, (getSize()).height);
          } 
          if (this.this$0.resizeR >= 0) {
            this.this$0.linePos.y = this.this$0.rowY(this.this$0.resizeR + 1 - this.this$0.hrow) - (((i & 0x2) != 0) ? this.this$0.lineWidth : 0);
            this.this$0.resizeLineR.setVisible(true);
            this.this$0.resizeLineR.setBounds(0, this.this$0.linePos.y, (getSize()).width, this.this$0.lineWidth);
          } 
          return;
        } 
        if (param1MouseEvent.getID() == 502)
          if (this.this$0.resizeLineC.isVisible() || this.this$0.resizeLineR.isVisible()) {
            setCursor0(this.this$0.defaultCursor);
            this.this$0.cursorChanged = false;
            if (this.this$0.resizeC >= 0) {
              this.this$0.setColWidth(this.this$0.resizeC - this.this$0.hcol, this.this$0.linePos.x - this.this$0.colX(this.this$0.resizeC - this.this$0.hcol));
              if (this.this$0.inPlace)
                this.this$0.setColWidth(this.this$0.resizeC + 1 - this.this$0.hcol, this.this$0.colX(this.this$0.resizeC + 2 - this.this$0.hcol) - this.this$0.linePos.x); 
              this.this$0.setAbsolute(this.this$0.getAbsolute() | 0x2);
            } 
            if (this.this$0.resizeR >= 0) {
              this.this$0.setRowHeight(this.this$0.resizeR - this.this$0.hrow, this.this$0.linePos.y - this.this$0.rowY(this.this$0.resizeR - this.this$0.hrow));
              if (this.this$0.inPlace)
                this.this$0.setRowHeight(this.this$0.resizeR + 1 - this.this$0.hrow, this.this$0.rowY(this.this$0.resizeR + 2 - this.this$0.hrow) - this.this$0.linePos.y); 
              this.this$0.setAbsolute(this.this$0.getAbsolute() | true);
            } 
            this.this$0.resizeLineC.setVisible(false);
            this.this$0.resizeLineR.setVisible(false);
            this.this$0.resizeR = this.this$0.resizeC = -1;
            requestFocus();
            this.this$0.eventMgr.postEvent(new ComponentEvent(this.this$0, 101));
          }  
      } 
      Point point2 = this.this$0.locateCell(param1MouseEvent.getX(), param1MouseEvent.getY());
      if (!this.this$0.moving && !this.this$0.resizeLineR.isVisible() && !this.this$0.resizeLineC.isVisible() && point2 != null)
        if (param1MouseEvent.isPopupTrigger()) {
          JPopupMenu jPopupMenu = null;
          if (point2.x <= -1) {
            jPopupMenu = this.this$0.getRowMenu(point2.y);
            jPopupMenu = (jPopupMenu == null) ? this.this$0.rowMenu : jPopupMenu;
          } else if (point2.y <= -1) {
            jPopupMenu = this.this$0.getColMenu(point2.x);
            jPopupMenu = (jPopupMenu == null) ? this.this$0.colMenu : jPopupMenu;
          } 
          if (jPopupMenu != null) {
            this.this$0.menuPos = point2;
            jPopupMenu.show(this, this.this$0.colX(point2.x), this.this$0.rowY(point2.y + 1));
          } 
        } else if (param1MouseEvent.getID() == 501 && !param1MouseEvent.isAltDown() && !param1MouseEvent.isMetaDown()) {
          CellInfo cellInfo = this.this$0.getCellInfo(point2.y, point2.x, false);
          if (param1MouseEvent.getClickCount() == 2) {
            this.this$0.eventMgr.postEvent(new GridActionEvent(this.this$0, "select", point2));
          } else if (this.this$0.isRegionSelectable() && point2 != null && point2.x > -1 && point2.y > -1) {
            this.this$0.setSelectedRegion(new Grid.Region(this.this$0, point2.y, point2.x, 1, 1));
          } else if (this.this$0.isRowSelectable() && (!this.this$0.useRowHeader || point2.x <= -1) && point2 != null && point2.y > -1) {
            if (param1MouseEvent.isControlDown()) {
              this.this$0.setRowSelected(point2.y, !this.this$0.isRowSelected(point2.y));
              this.startRow = point2.y;
            } else if (param1MouseEvent.isShiftDown() && this.this$0.multiSel) {
              this.startRow = this.this$0.getSelectedRow();
              if (this.startRow < 0)
                this.startRow = point2.y; 
              this.this$0.clearSelection();
              int j = Math.min(this.startRow, point2.y);
              int k = Math.max(this.startRow, point2.y);
              for (; j <= k; j++)
                this.this$0.setRowSelected(j, true); 
            } else {
              this.startRow = point2.y;
              if (this.this$0.multiSel)
                this.this$0.clearSelection(); 
              if (this.this$0.multiSel && cellInfo != null && cellInfo.span != null) {
                for (int j = 0; j < cellInfo.span.numRow; j++)
                  this.this$0.setRowSelected(point2.y + j + cellInfo.span.row, true); 
              } else {
                this.this$0.setRowSelected(point2.y, true);
              } 
            } 
          } else if (this.this$0.isColSelectable() && (!this.this$0.useColHeader || point2.y <= -1) && point2 != null && point2.x > -1) {
            if (param1MouseEvent.isControlDown()) {
              this.this$0.setColSelected(point2.x, !this.this$0.isColSelected(point2.x));
              this.startCol = point2.x;
            } else if (param1MouseEvent.isShiftDown() && this.this$0.multiSel) {
              this.startCol = this.this$0.getSelectedCol();
              if (this.startCol < 0)
                this.startCol = point2.x; 
              this.this$0.clearSelection();
              int j = Math.min(this.startCol, point2.x);
              int k = Math.max(this.startCol, point2.x);
              for (; j <= k; j++)
                this.this$0.setColSelected(j, true); 
            } else {
              this.startCol = point2.x;
              boolean bool = !this.this$0.isColSelected(point2.x);
              if (this.this$0.multiSel)
                this.this$0.clearSelection(); 
              if (this.this$0.multiSel && cellInfo != null && cellInfo.span != null) {
                for (int j = 0; j < cellInfo.span.numCol; j++)
                  this.this$0.setColSelected(point2.x + j + cellInfo.span.col, bool); 
              } else {
                this.this$0.setColSelected(point2.x, bool);
              } 
            } 
          } 
        } else if (param1MouseEvent.getID() == 502 && this.this$0.selReg != null && this.this$0.isRegionSelectable() && point2 != null && point2.x > -1 && point2.y > -1) {
          this.this$0.setSelectedRegion(new Grid.Region(this.this$0, this.this$0.selReg.row, this.this$0.selReg.col, point2.y - this.this$0.selReg.row + 1, point2.x - this.this$0.selReg.col + 1));
        }  
      if (this.this$0.moving && param1MouseEvent.getID() == 502 && point2 != null) {
        if (point2 != null) {
          Rectangle rectangle = this.this$0.getBounds(point2.y, point2.x);
          if (point2.y == this.this$0.movePos.y && point2.x != this.this$0.movePos.x) {
            if ((this.this$0.moveBox.getLocation()).x > rectangle.x + rectangle.width / 2)
              point2.x++; 
            this.this$0.moveCol(this.this$0.movePos.x, point2.x);
            this.this$0.eventMgr.postEvent(new GridComponentEvent(this.this$0, 100, this.this$0.movePos.x, point2.x, 2));
          } else if (point2.x == this.this$0.movePos.x && point2.y != this.this$0.movePos.y) {
            if ((this.this$0.moveBox.getLocation()).y > rectangle.y + rectangle.height / 2)
              point2.y++; 
            this.this$0.moveRow(this.this$0.movePos.y, point2.y);
            this.this$0.eventMgr.postEvent(new GridComponentEvent(this.this$0, 100, this.this$0.movePos.y, point2.y, 1));
          } 
        } 
        this.this$0.moving = false;
        this.this$0.moveBox.setVisible(false);
        setCursor0(this.this$0.defaultCursor);
      } 
      super.processMouseEvent(param1MouseEvent);
    }
    
    public int getMinimum(int param1Int) {
      synchronized (getTreeLock()) {
        return (param1Int == 1) ? this.this$0.gridY[this.this$0.getFrozenRow() + this.this$0.hrow] : this.this$0.gridX[this.this$0.getFrozenCol() + this.this$0.hcol];
      } 
    }
    
    public int getMaximum(int param1Int) {
      synchronized (getTreeLock()) {
        if ((getSize()).width <= 0)
          return 1; 
        try {
          if (this.this$0.rowHeight == null || this.this$0.colWidth == null || this.this$0.rowHeight.length != this.this$0.nrow || this.this$0.colWidth.length != this.this$0.ncol)
            this.this$0.recalc(); 
        } catch (ModelChangedException modelChangedException) {
          this.this$0.doRepaint(true);
        } 
        return (param1Int == 1) ? (this.this$0.gridY[this.this$0.gridY.length - 1] - (((this.this$0.getBorder(-99, -99) & true) != 0) ? this.this$0.lineWidth : 0)) : (this.this$0.gridX[this.this$0.gridX.length - 1] - (((this.this$0.getBorder(-99, -99) & 0x2) != 0) ? this.this$0.lineWidth : 0));
      } 
    }
    
    public int getValue(int param1Int) { return (param1Int == 1) ? this.this$0.pixelOff.y : this.this$0.pixelOff.x; }
    
    public int getVisibleAmount(int param1Int) {
      synchronized (getTreeLock()) {
        return (param1Int == 1) ? ((getSize()).height - this.this$0.gridY[this.this$0.hrow + this.this$0.frozen.y]) : ((getSize()).width - this.this$0.gridX[this.this$0.hcol + this.this$0.frozen.x]);
      } 
    }
    
    public int getIncrement(int param1Int1, int param1Int2) {
      synchronized (getTreeLock()) {
        FontMetrics fontMetrics;
        Dimension dimension = getSize();
        if (this.this$0.rowHeight == null || this.this$0.colWidth == null || dimension.width <= 0 || this.this$0.rowHeight.length != this.this$0.nrow || this.this$0.colWidth.length != this.this$0.ncol)
          return 1; 
        switch (param1Int2) {
          case 1:
          case 2:
            fontMetrics = getFontMetrics(getFont());
            return (param1Int1 == 1) ? (fontMetrics.getHeight() + this.this$0.lineWidth + 2) : fontMetrics.charWidth('M');
          case 3:
          case 4:
            return getVisibleAmount(param1Int1);
        } 
      } 
      return 1;
    }
    
    public void setValue(int param1Int1, int param1Int2) {
      switch (param1Int1) {
        case 1:
          if (this.this$0.pixelOff.y != param1Int2) {
            this.this$0.pixelOff.y = param1Int2;
            for (int i = 0; i < this.this$0.gridY.length - 1; i++) {
              if (param1Int2 >= this.this$0.gridY[i] && param1Int2 <= this.this$0.gridY[i + true]) {
                this.this$0.root.y = i - this.this$0.hrow;
                break;
              } 
            } 
            this.this$0.needLayout = true;
          } 
          break;
        case 2:
          if (this.this$0.pixelOff.x != param1Int2) {
            this.this$0.pixelOff.x = param1Int2;
            for (int i = 0; i < this.this$0.gridX.length - 1; i++) {
              if (param1Int2 >= this.this$0.gridX[i] && param1Int2 <= this.this$0.gridX[i + true]) {
                this.this$0.root.x = i - this.this$0.hcol;
                break;
              } 
            } 
            this.this$0.needLayout = true;
          } 
          break;
      } 
      if (this.this$0.needLayout)
        this.this$0.getPane().repaint(); 
    }
    
    public void processKeyEvent(KeyEvent param1KeyEvent) {
      if (!isEnabled())
        return; 
      if (param1KeyEvent.getID() == 401) {
        if (param1KeyEvent.getKeyChar() == '\t' && param1KeyEvent.getModifiers() == 0 && !(param1KeyEvent.getSource() instanceof javax.swing.JTextArea)) {
          this.this$0.nextCellFocus();
          param1KeyEvent.consume();
          return;
        } 
        if ((param1KeyEvent.getKeyCode() == 38 || param1KeyEvent.getKeyCode() == 40) && this.this$0.isRowSelectable() && this.this$0.getSelectedRow() >= 0) {
          int i = (this.startRow >= 0 && this.this$0.isRowSelected(this.startRow)) ? this.startRow : this.this$0.getSelectedRow();
          if (param1KeyEvent.getKeyCode() == 38 && i > 0) {
            if (!param1KeyEvent.isShiftDown())
              this.this$0.setRowSelected(i, false); 
            i--;
            this.this$0.setRowSelected(this.startRow = i, true);
          } else if (param1KeyEvent.getKeyCode() == 40 && i < this.this$0.getRowCount() - 1) {
            if (!param1KeyEvent.isShiftDown())
              this.this$0.setRowSelected(i, false); 
            i++;
            this.this$0.setRowSelected(this.startRow = i, true);
          } 
        } else if ((param1KeyEvent.getKeyCode() == 37 || param1KeyEvent.getKeyCode() == 39) && this.this$0.isColSelectable() && this.this$0.getSelectedCol() >= 0) {
          int i = (this.startCol >= 0 && this.this$0.isColSelected(this.startCol)) ? this.startCol : this.this$0.getSelectedCol();
          if (param1KeyEvent.getKeyCode() == 37 && i > 0) {
            if (!param1KeyEvent.isShiftDown())
              this.this$0.setColSelected(i, false); 
            i--;
            this.this$0.setColSelected(this.startCol = i, true);
          } else if (param1KeyEvent.getKeyCode() == 39 && i < this.this$0.getColCount() - 1) {
            if (!param1KeyEvent.isShiftDown())
              this.this$0.setColSelected(i, false); 
            i++;
            this.this$0.setColSelected(this.startCol = i, true);
          } 
        } else if ((param1KeyEvent.getKeyCode() == 33 || param1KeyEvent.getKeyCode() == 34) && this.this$0.scroller != null) {
          byte b = (param1KeyEvent.getKeyCode() == 33) ? 3 : 4;
          this.this$0.scroller.adjust(1, b);
        } 
      } 
    }
    
    public boolean isFocusTraversable() { return true; }
  }
  
  public void registerScrollControl(ScrollControl paramScrollControl) { ((Pane)getPane()).registerScrollControl(paramScrollControl); }
  
  public int getMinimum(int paramInt) { return ((Pane)getPane()).getMinimum(paramInt); }
  
  public int getMaximum(int paramInt) { return ((Pane)getPane()).getMaximum(paramInt); }
  
  public int getValue(int paramInt) { return ((Pane)getPane()).getValue(paramInt); }
  
  public int getVisibleAmount(int paramInt) { return ((Pane)getPane()).getVisibleAmount(paramInt); }
  
  public int getIncrement(int paramInt1, int paramInt2) { return ((Pane)getPane()).getIncrement(paramInt1, paramInt2); }
  
  public void setValue(int paramInt1, int paramInt2) { ((Pane)getPane()).setValue(paramInt1, paramInt2); }
  
  public Rectangle getBounds(int paramInt1, int paramInt2) {
    Rectangle rectangle = getVirtualBounds(paramInt1, paramInt2);
    return getBounds(paramInt1, paramInt2, rectangle);
  }
  
  protected Rectangle getBounds(int paramInt1, int paramInt2, Rectangle paramRectangle) {
    Point point = new Point(this.gridX[this.hcol + this.frozen.x], this.gridY[this.hrow + this.frozen.y]);
    Rectangle rectangle = new Rectangle(paramRectangle);
    if (paramInt2 >= this.frozen.x) {
      rectangle.x = Math.max(rectangle.x, point.x);
      rectangle.width = Math.min(rectangle.width, rectangle.width - point.x - paramRectangle.x);
      rectangle.width = Math.max(rectangle.width, 0);
    } 
    if (paramInt1 >= this.frozen.y) {
      rectangle.y = Math.max(rectangle.y, point.y);
      rectangle.height = Math.min(rectangle.height, rectangle.height - point.y - paramRectangle.y);
      rectangle.height = Math.max(rectangle.height, 0);
    } 
    return rectangle;
  }
  
  protected Rectangle getVirtualBounds(int paramInt1, int paramInt2) { return getVirtualBounds(paramInt1, paramInt2, true); }
  
  protected Rectangle getVirtualBounds(int paramInt1, int paramInt2, boolean paramBoolean) {
    Rectangle rectangle = null;
    CellInfo cellInfo = getCellInfo(paramInt1, paramInt2, false);
    if (cellInfo != null && cellInfo.span != null) {
      paramInt1 += cellInfo.span.row;
      paramInt2 += cellInfo.span.col;
      rectangle = new Rectangle(this.gridX[paramInt2 + this.hcol], this.gridY[paramInt1 + this.hrow], this.gridX[paramInt2 + this.hcol + cellInfo.span.numCol] - this.gridX[paramInt2 + this.hcol], this.gridY[paramInt1 + this.hrow + cellInfo.span.numRow] - this.gridY[paramInt1 + this.hrow]);
    } else {
      rectangle = new Rectangle(this.gridX[paramInt2 + this.hcol], this.gridY[paramInt1 + this.hrow], this.gridX[paramInt2 + this.hcol + 1] - this.gridX[paramInt2 + this.hcol], this.gridY[paramInt1 + this.hrow + 1] - this.gridY[paramInt1 + this.hrow]);
    } 
    int i = hasBorder(paramInt1, paramInt2, 1) ? this.lineWidth : 0;
    int j = hasBorder(paramInt1, paramInt2, 2) ? this.lineWidth : 0;
    if (paramInt1 > -1 && paramInt2 > -1) {
      rectangle.width -= i;
      rectangle.height -= j;
    } else if (paramInt1 <= -1) {
      if (paramInt2 + this.hcol == 0) {
        rectangle.width -= this.lineWidth / 2;
      } else {
        rectangle.x -= this.lineWidth / 2;
      } 
    } else if (paramInt2 <= -1) {
      if (paramInt1 + this.hrow == 0) {
        rectangle.height -= this.lineWidth / 2;
      } else {
        rectangle.y -= this.lineWidth / 2;
      } 
    } 
    Insets insets = getGap(paramInt1, paramInt2);
    if (paramBoolean && insets != null && paramInt1 > -1 && paramInt2 > -1) {
      rectangle.x += insets.left;
      rectangle.y += insets.top;
      rectangle.width -= insets.left + insets.right;
      rectangle.height -= insets.top + insets.bottom;
    } 
    Point point = new Point(this.gridX[this.hcol + this.frozen.x], this.gridY[this.hrow + this.frozen.y]);
    if (rectangle.x >= this.pixelOff.x || rectangle.x + rectangle.width + i > this.pixelOff.x) {
      rectangle.x -= Math.max(0, this.pixelOff.x - point.x);
    } else if (paramInt2 >= this.frozen.x) {
      rectangle.x = -1;
      rectangle.width = 0;
    } 
    if (rectangle.y >= this.pixelOff.y || rectangle.y + rectangle.height + i > this.pixelOff.y) {
      rectangle.y -= Math.max(0, this.pixelOff.y - point.y);
    } else if (paramInt1 >= this.frozen.y) {
      rectangle.y = -1;
      rectangle.height = 0;
    } 
    return rectangle;
  }
  
  public Point locateCell(int paramInt1, int paramInt2) { return locateCell(paramInt1, paramInt2, true); }
  
  protected boolean isRowOnScreen(int paramInt) { return (isRowVisible(paramInt) && (paramInt < this.frozen.y || this.gridY[paramInt + this.hrow + 1] > this.pixelOff.y) && this.gridY[paramInt + this.hrow] - this.pixelOff.y < (getSize()).height); }
  
  protected boolean isColOnScreen(int paramInt) { return (isColVisible(paramInt) && (paramInt < this.frozen.x || this.gridX[paramInt + this.hcol + 1] > this.pixelOff.x) && this.gridX[paramInt + this.hcol] - this.pixelOff.x < (getSize()).width); }
  
  protected CellInfo getCellInfo(int paramInt1, int paramInt2, boolean paramBoolean) {
    paramInt1 = getModelRowIndex(paramInt1);
    paramInt2 = getModelColIndex(paramInt2);
    return (CellInfo)this.gridinfo.getObject(paramInt1 + this.hrow, paramInt2 + this.hcol, paramBoolean);
  }
  
  protected CellInfo createCellInfo() { return new CellInfo(); }
  
  protected RowInfo getRowInfo(int paramInt) {
    paramInt = getModelRowIndex(paramInt);
    return (RowInfo)this.gridinfo.getRowInfo(paramInt + this.hrow);
  }
  
  protected RowInfo createRowInfo() { return new RowInfo(); }
  
  protected ColInfo getColInfo(int paramInt) {
    paramInt = getModelColIndex(paramInt);
    return (ColInfo)this.gridinfo.getColInfo(paramInt + this.hcol);
  }
  
  protected ColInfo createColInfo() { return new ColInfo(); }
  
  protected Dimension getPreferredSize(int paramInt1, int paramInt2) {
    Object object = getObject(paramInt1, paramInt2);
    validateModel();
    Insets insets = getGap(paramInt1, paramInt2);
    Dimension dimension = (insets != null) ? new Dimension(insets.left + insets.right, insets.top + insets.bottom) : new Dimension(0, 0);
    boolean bool = object instanceof Component;
    if (!bool) {
      try {
        GridCellRenderer gridCellRenderer = getRenderer(paramInt1, paramInt2);
        if (gridCellRenderer != null) {
          gridCellRenderer.setCellValue(paramInt1, paramInt2, object);
          Dimension dimension1 = ((Component)gridCellRenderer).getPreferredSize();
          dimension.width += dimension1.width;
          dimension.height += dimension1.height;
          return dimension;
        } 
        if (object == null)
          return dimension; 
        CellInfo cellInfo = getCellInfo(paramInt1, paramInt2, false);
        Format format = getFormat(paramInt1, paramInt2);
        String str = (format != null) ? format.format(object) : object.toString();
        Font font = getFont(paramInt1, paramInt2);
        if (font == null)
          return dimension; 
        FontMetrics fontMetrics = getFontMetrics(font);
        if (str != null) {
          Dimension dimension1 = new Dimension(0, 0);
          ColInfo colInfo = getColInfo(paramInt2);
          int i = (colInfo.width != null) ? colInfo.width.intValue() : 0;
          for (String str1 = str; str1.length() > 0; ) {
            int j = str1.indexOf('\n');
            if (this.lineWrap && i > 0) {
              int k = (j >= 0) ? (j + 1) : Math.min(str1.length(), i / fontMetrics.charWidth('x'));
              String str3 = str1.substring(0, k);
              while (k < str1.length() && fontMetrics.stringWidth(str3) <= i)
                str3 = str1.substring(0, ++k); 
              if (fontMetrics.stringWidth(str3) > i)
                while (--k > 0 && (fontMetrics.stringWidth(str1.substring(0, k)) > i || !Character.isWhitespace(str1.charAt(k))))
                  k--;  
              if (k <= 0) {
                k = Math.max(str3.length() - 1, 1);
              } else {
                k++;
              } 
              dimension1.height += fontMetrics.getHeight();
              if (k >= str1.length())
                break; 
              str1 = str1.substring(k);
              continue;
            } 
            String str2 = str1.substring(0, (j > 0) ? j : str1.length());
            dimension1.width = Math.max(dimension1.width, fontMetrics.stringWidth(str2));
            dimension1.height += fontMetrics.getHeight();
            if (j > 0) {
              str1 = str1.substring(j + 1);
              continue;
            } 
            break;
          } 
          if (isLineWrap() && i > 0)
            dimension1.width = i; 
          dimension.width += dimension1.width + 2;
          dimension.height += dimension1.height + 2;
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } else {
      Dimension dimension1 = ((Component)object).getPreferredSize();
      dimension.width += dimension1.width;
      dimension.height += dimension1.height;
    } 
    return dimension;
  }
  
  protected int getPreferredRowHeight(int paramInt) {
    RowInfo rowInfo = getRowInfo(paramInt);
    if (rowInfo.height != null)
      return rowInfo.height.intValue(); 
    if (this.gridRowHeight > 0)
      return this.gridRowHeight; 
    if (rowInfo.pheight != null)
      return rowInfo.pheight.intValue(); 
    if (this.delayed) {
      int j = Math.min(this.nrow, this.root.y + this.lookahead);
      if ((paramInt > this.hrow && paramInt < this.root.y) || paramInt + this.hrow > j)
        return getMinRowHeight(paramInt); 
    } 
    int i = 0;
    synchronized (getTreeLock()) {
      for (int j = 0; j < this.ncol; j++) {
        Dimension dimension = getPreferredSize(paramInt, j - this.hcol);
        CellInfo cellInfo = getCellInfo(paramInt, j - this.hcol, false);
        Insets insets = getGap(paramInt, j - this.hcol);
        if (dimension.height > 0 || (cellInfo != null && cellInfo.span != null)) {
          int k = (cellInfo != null && insets != null) ? (insets.top + insets.bottom) : 0;
          if (cellInfo != null && cellInfo.span != null) {
            k = (k + (getPreferredSize(paramInt + cellInfo.span.row, j + cellInfo.span.col - this.hcol)).height) / cellInfo.span.numRow;
          } else {
            k += dimension.height;
          } 
          i = Math.max(k, i);
        } 
      } 
      i = (rowInfo.minheight > 0) ? Math.max(i, rowInfo.minheight) : Math.max(i, this.gridMinRowHeight);
      rowInfo.pheight = new Integer(i);
    } 
    return i;
  }
  
  protected int getPreferredColWidth(int paramInt) {
    ColInfo colInfo = getColInfo(paramInt);
    if (colInfo.width != null)
      return colInfo.width.intValue(); 
    if (this.gridColWidth > 0)
      return this.gridColWidth; 
    if (colInfo.pwidth != null && (!this.delayed || colInfo.calc.get(this.root.y + this.hrow)))
      return colInfo.pwidth.intValue(); 
    int i = this.delayed ? Math.min(getRowCount(), this.root.y + this.lookahead) : getRowCount();
    int j = (colInfo.pwidth != null) ? colInfo.pwidth.intValue() : 0;
    synchronized (getTreeLock()) {
      int[][] arrayOfInt = { { -this.hrow, 0 }, { this.root.y, i } };
      for (byte b = 0; b < arrayOfInt.length; b++) {
        for (int k = arrayOfInt[b][0]; k < arrayOfInt[b][1]; k++) {
          if (!colInfo.calc.get(k + this.hrow)) {
            Dimension dimension = getPreferredSize(k, paramInt);
            validateModel();
            CellInfo cellInfo = getCellInfo(k, paramInt, false);
            Insets insets = getGap(k, paramInt);
            colInfo.calc.set(k + this.hrow);
            if (k <= -1 && this.csort)
              dimension.width += 12; 
            if (dimension.width > 0 || (cellInfo != null && cellInfo.span != null)) {
              int m = (cellInfo != null && insets != null) ? (insets.left + insets.right) : 0;
              if (cellInfo != null && cellInfo.span != null) {
                m = (m + (getPreferredSize(k + cellInfo.span.row, paramInt + cellInfo.span.col)).width) / cellInfo.span.numCol;
              } else {
                m += dimension.width;
              } 
              j = Math.max(j, m);
            } 
          } 
        } 
      } 
      j = (colInfo.minwidth > 0) ? Math.max(j, colInfo.minwidth) : Math.max(j, this.gridMinColWidth);
      colInfo.pwidth = new Integer(j);
    } 
    return j;
  }
  
  protected void setProperty(int paramInt1, int paramInt2, Object paramObject, Field paramField) {
    try {
      CellInfo cellInfo;
      boolean bool = (resetFields.indexOf(paramField) >= 0) ? 1 : 0;
      if (paramInt1 == -99 && paramInt2 == -99) {
        cellInfo = this.ginfo;
      } else if (paramInt1 == -99) {
        cellInfo = getColInfo(paramInt2);
      } else if (paramInt2 == -99) {
        cellInfo = getRowInfo(paramInt1);
      } else {
        cellInfo = getCellInfo(paramInt1, paramInt2, true);
      } 
      if (bool) {
        cellInfo.reset();
        if (paramInt1 == -99)
          resetRows(); 
        if (paramInt2 == -99)
          resetCols(); 
        if (paramInt1 != -99 && paramInt2 != -99) {
          getRowInfo(paramInt1).reset();
          getColInfo(paramInt2).reset();
        } 
      } 
      paramField.set(cellInfo, paramObject);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  protected Object getProperty(int paramInt1, int paramInt2, Field paramField) {
    try {
      GridInfo[] arrayOfGridInfo;
      if (paramInt1 == -99 && paramInt2 == -99) {
        arrayOfGridInfo = new GridInfo[] { this.ginfo };
      } else if (paramInt1 == -99) {
        arrayOfGridInfo = new GridInfo[] { getColInfo(paramInt2), this.ginfo };
      } else if (paramInt2 == -99) {
        arrayOfGridInfo = new GridInfo[] { getRowInfo(paramInt1), this.ginfo };
      } else if (paramInt1 <= -1) {
        arrayOfGridInfo = new GridInfo[] { getCellInfo(paramInt1, paramInt2, false), getRowInfo(paramInt1), this.ginfo };
      } else if (paramInt2 <= -1) {
        arrayOfGridInfo = new GridInfo[] { getCellInfo(paramInt1, paramInt2, false), getColInfo(paramInt2), this.ginfo };
      } else {
        arrayOfGridInfo = new GridInfo[] { getCellInfo(paramInt1, paramInt2, false), getRowInfo(paramInt1), getColInfo(paramInt2), this.ginfo };
      } 
      for (byte b = 0; b < arrayOfGridInfo.length; b++) {
        if (arrayOfGridInfo[b] != null) {
          Object object = paramField.get(arrayOfGridInfo[b]);
          if (object != null)
            return object; 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return null;
  }
  
  private void resetRows() {
    for (int i = 0; i < this.nrow; i++)
      getRowInfo(i - this.hrow).reset(); 
  }
  
  private void resetCols() {
    for (int i = 0; i < this.ncol; i++)
      getColInfo(i - this.hcol).reset(); 
  }
  
  private void doRepaint(boolean paramBoolean) {
    if (this.suspend)
      return; 
    if (paramBoolean)
      this.needLayout = true; 
    getPane().repaint(50L);
  }
  
  private void validateModel() {
    if (!this.mvalid)
      throw new ModelChangedException(); 
  }
  
  protected void paintHeader(Graphics paramGraphics, int paramInt1, int paramInt2) {
    CellInfo cellInfo = getCellInfo(paramInt1, paramInt2, false);
    Rectangle rectangle1 = getVirtualBounds(paramInt1, paramInt2);
    Rectangle rectangle2 = getBounds(paramInt1, paramInt2, rectangle1);
    Object object = getObject(paramInt1, paramInt2);
    validateModel();
    if (cellInfo != null && cellInfo.span != null && (cellInfo.span.row != 0 || cellInfo.span.col != 0))
      return; 
    if (rectangle2.width > 0 && rectangle2.height > 0) {
      Graphics graphics = paramGraphics.create(rectangle2.x, rectangle2.y, rectangle2.width, rectangle2.height);
      rectangle1.x -= rectangle2.x;
      rectangle1.y -= rectangle2.y;
      GridCellRenderer gridCellRenderer = getRenderer(paramInt1, paramInt2);
      if (gridCellRenderer != null) {
        gridCellRenderer.setCellValue(paramInt1, paramInt2, object);
        Component component = (Component)gridCellRenderer;
        component.setForeground(getForeground(paramInt1, paramInt2));
        component.setBackground(getBackground(paramInt1, paramInt2));
        component.setBounds(rectangle1.x, rectangle1.y, rectangle1.width, rectangle1.height);
        component.validate();
        component.paint(graphics);
      } else {
        graphics.setColor(getBackground(paramInt1, paramInt2));
        graphics.fillRect(rectangle1.x, rectangle1.y, rectangle1.width - 1, rectangle1.height - 1);
        graphics.draw3DRect(rectangle1.x, rectangle1.y, rectangle1.width - 1, rectangle1.height - 1, ((paramInt1 <= -1 && !isColSelected(paramInt2)) || (paramInt2 <= -1 && !isRowSelected(paramInt1))));
        if (object != null && !(object instanceof Component)) {
          Color color = getForeground(paramInt1, paramInt2);
          graphics.setColor(isEnabled() ? color : (color.equals(Color.black) ? Color.gray : color.brighter()));
          graphics.setFont(getFont(paramInt1, paramInt2));
          if (this.arrow != null && this.arrow.x == paramInt2 && this.arrow.y == paramInt1)
            rectangle1.width -= 12; 
          Format format = getFormat(paramInt1, paramInt2);
          String str = object.toString();
          if (format != null)
            try {
              str = format.format(object);
            } catch (Exception exception) {} 
          GridBase.paintText(graphics, str, rectangle1, 18, this.lineWrap);
        } 
      } 
      if (this.arrow != null && this.arrow.x == paramInt2 && this.arrow.y == paramInt1) {
        graphics.setColor(Color.lightGray);
        if (this.arrowDown) {
          Tool.drawDownArrow(graphics, rectangle1.x + rectangle1.width + 2, rectangle1.y + rectangle1.height / 2, false);
        } else {
          Tool.drawUpArrow(graphics, rectangle1.x + rectangle1.width + 2, rectangle1.y + rectangle1.height / 2, false);
        } 
      } 
      graphics.dispose();
    } 
  }
  
  private int colX(int paramInt) {
    int i = this.gridX[this.hcol + this.frozen.x];
    int j = this.gridX[paramInt + this.hcol];
    return (j < i) ? j : ((j >= this.pixelOff.x) ? (j - Math.max(this.pixelOff.x - i, 0)) : -1);
  }
  
  private int rowY(int paramInt) {
    int i = this.gridY[this.hrow + this.frozen.y];
    int j = this.gridY[paramInt + this.hrow];
    return (j < i) ? j : ((j >= this.pixelOff.y) ? (j - Math.max(0, this.pixelOff.y - i)) : -1);
  }
  
  private Point locateCell(int paramInt1, int paramInt2, boolean paramBoolean) {
    synchronized (getTreeLock()) {
      Point point = new Point(this.gridX[this.hcol + this.frozen.x], this.gridY[this.hrow + this.frozen.y]);
      if (paramInt1 >= point.x)
        paramInt1 += Math.max(0, this.pixelOff.x - point.x); 
      if (paramInt2 >= point.y)
        paramInt2 += Math.max(0, this.pixelOff.y - point.y); 
      int i = -1, j = -1;
      for (byte b1 = 0; b1 < this.gridX.length - 1; b1++) {
        if (paramInt1 >= this.gridX[b1] && paramInt1 < this.gridX[b1 + true]) {
          j = b1;
          break;
        } 
      } 
      for (byte b2 = 0; b2 < this.gridY.length - 1; b2++) {
        if (paramInt2 >= this.gridY[b2] && paramInt2 < this.gridY[b2 + true]) {
          i = b2;
          break;
        } 
      } 
      if (j >= 0 && i >= 0) {
        CellInfo cellInfo = getCellInfo(i - this.hrow, j - this.hcol, false);
        if (paramBoolean && cellInfo != null && cellInfo.span != null)
          return new Point(j + cellInfo.span.col - this.hcol, i + cellInfo.span.row - this.hrow); 
        return new Point(j - this.hcol, i - this.hrow);
      } 
    } 
    return null;
  }
  
  private Point findResizeCell(int paramInt1, int paramInt2) {
    synchronized (getTreeLock()) {
      Point point1 = locateCell(paramInt1, paramInt2, false);
      int i = getBorder(-99, -99);
      if (point1 == null)
        return new Point(-1, -1); 
      Point point2 = new Point(this.gridX[this.hcol + this.frozen.x], this.gridY[this.hrow + this.frozen.y]);
      if (paramInt1 >= point2.x)
        paramInt1 += Math.max(0, this.pixelOff.x - point2.x); 
      if (paramInt2 >= point2.y)
        paramInt2 += Math.max(0, this.pixelOff.y - point2.y); 
      CellInfo cellInfo = getCellInfo(point1.y, point1.x, false);
      int j = point1.y + this.hrow, k = point1.x + this.hcol;
      point1.x = point1.y = -1;
      if (((i & true) != 0 || j < this.hrow) && paramInt1 >= this.gridX[k + 1] - this.lineWidth - 1 && paramInt1 < this.gridX[k + 1] + 1 && (cellInfo == null || cellInfo.span == null || -cellInfo.span.col == cellInfo.span.numCol - 1))
        point1.x = k; 
      if (((i & 0x2) != 0 || k < this.hcol) && paramInt2 >= this.gridY[j + 1] - this.lineWidth - 1 && paramInt2 < this.gridY[j + 1] + 1 && (cellInfo == null || cellInfo.span == null || -cellInfo.span.row == cellInfo.span.numRow - 1))
        point1.y = j; 
      return point1;
    } 
  }
  
  private void recalc() {
    if (this.suspend)
      return; 
    int i = 0, j = 0;
    int k = getBorder(-99, -99);
    int m = ((k & true) != 0) ? this.lineWidth : 0;
    int n = ((k & 0x2) != 0) ? this.lineWidth : 0;
    synchronized (getTreeLock()) {
      this.mvalid = true;
      this.rowHeight = calcRowHeight();
      validateModel();
      this.colWidth = calcColWidth();
      validateModel();
      Dimension dimension = getPane().getSize();
      if ((this.absolute & true) == 0) {
        for (int i6 = 0; i6 < this.nrow && i6 < this.rowHeight.length; i6++)
          i += (isRowVisible(i6 - this.hrow) ? this.rowHeight[i6] : 0); 
        int i7 = dimension.height - (visibleRows(this.nrow) - 1) * n;
        for (int i8 = 0; i8 < this.nrow && i > 0; i8++) {
          int i9 = i7 * this.rowHeight[i8] / i;
          boolean bool = isRowVisible(i8 - this.hrow);
          i -= (bool ? this.rowHeight[i8] : 0);
          this.rowHeight[i8] = i9;
          i7 -= (bool ? this.rowHeight[i8] : 0);
        } 
      } 
      if ((this.absolute & 0x2) == 0) {
        for (int i6 = 0; i6 < this.ncol && i6 < this.colWidth.length; i6++)
          j += (isColVisible(i6 - this.hcol) ? this.colWidth[i6] : 0); 
        int i7 = dimension.width - (visibleCols(this.ncol) - 1) * m;
        for (int i8 = 0; i8 < this.ncol && j > 0; i8++) {
          int i9 = i7 * this.colWidth[i8] / j;
          boolean bool = isColVisible(i8 - this.hcol);
          j -= (bool ? this.colWidth[i8] : 0);
          this.colWidth[i8] = i9;
          i7 -= (bool ? this.colWidth[i8] : 0);
        } 
      } 
      for (int i1 = 0, i2 = 0; i1 <= this.nrow; i1++) {
        this.gridY[i1] = i2;
        if (i1 < this.nrow && isRowVisible(i1 - this.hrow))
          i2 += this.rowHeight[i1] + n; 
      } 
      for (int i3 = 0, i4 = 0; i3 <= this.ncol; i3++) {
        this.gridX[i3] = i4;
        if (i3 < this.ncol && isColVisible(i3 - this.hcol))
          i4 += this.colWidth[i3] + m; 
      } 
      int i5 = this.ncol - 1 - this.hcol;
      while (i5 > 0 && !isColVisible(i5))
        i5--; 
      if (this.fillLastCol && (this.absolute & 0x2) != 0 && this.gridX[i5 + this.hcol + 1] < dimension.width)
        this.gridX[i5 + this.hcol + 1] = dimension.width + this.lineWidth; 
    } 
  }
  
  private int visibleRows(int paramInt) {
    synchronized (getTreeLock()) {
      int i = paramInt;
      for (int j = 0; j < paramInt; j++) {
        if (j < this.nrow && !isRowVisible(j - this.hrow))
          i--; 
      } 
      return i;
    } 
  }
  
  private int visibleCols(int paramInt) {
    synchronized (getTreeLock()) {
      int i = paramInt;
      for (int j = 0; j < paramInt; j++) {
        if (j < this.ncol && !isColVisible(j - this.hcol))
          i--; 
      } 
      return i;
    } 
  }
  
  private boolean hasBorder(int paramInt1, int paramInt2, int paramInt3) {
    CellInfo cellInfo = getCellInfo(paramInt1, paramInt2, false);
    if (cellInfo != null && cellInfo.span != null) {
      paramInt1 += cellInfo.span.row;
      paramInt2 += cellInfo.span.col;
    } 
    return ((getBorder(paramInt1, paramInt2) & paramInt3) != 0);
  }
  
  private Method getMethod(String paramString1, Class[] paramArrayOfClass, String paramString2) {
    String str = paramString1 + paramString2;
    Method method = (Method)this.propertyMethods.get(str);
    if (method == null)
      try {
        method = getClass().getMethod(paramString1, paramArrayOfClass);
        this.propertyMethods.put(str, method);
      } catch (Exception exception) {} 
    return method;
  }
  
  public class Region implements Serializable {
    public int row;
    
    public int col;
    
    public int numRow;
    
    public int numCol;
    
    private final Grid this$0;
    
    public Region(Grid this$0, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.this$0 = this$0;
      this.row = param1Int1;
      this.col = param1Int2;
      this.numRow = param1Int3;
      this.numCol = param1Int4;
    }
    
    public int getRow() { return this.row; }
    
    public void setRow(int param1Int) { this.row = param1Int; }
    
    public int getCol() { return this.col; }
    
    public void setCol(int param1Int) { this.col = param1Int; }
    
    public int getRowCount() { return this.numRow; }
    
    public void setRowCount(int param1Int) { this.numRow = param1Int; }
    
    public int getColCount() { return this.numCol; }
    
    public void setColCount(int param1Int) { this.numCol = param1Int; }
    
    public boolean contains(int param1Int1, int param1Int2) {
      Region region = (this.numRow <= 0 || this.numCol <= 0) ? normalize() : this;
      return (param1Int1 >= region.row && param1Int1 < region.row + region.numRow && param1Int2 >= region.col && param1Int2 < region.col + region.numCol);
    }
    
    public Region normalize() {
      int i = this.row, j = this.col, k = this.numRow, m = this.numCol;
      if (this.numRow <= 0) {
        i += this.numRow - 1;
        k = 2 - this.numRow;
      } 
      if (this.numCol <= 0) {
        j += this.numCol - 1;
        m = 2 - this.numCol;
      } 
      return new Region(this.this$0, i, j, k, m);
    }
    
    public String toString() { return "Region[" + this.row + "," + this.col + ":" + this.numRow + "x" + this.numCol + "]"; }
    
    public boolean equals(Object param1Object) { return (param1Object instanceof Region && ((Region)param1Object).row == this.row && ((Region)param1Object).col == this.col && ((Region)param1Object).numRow == this.numRow && ((Region)param1Object).numCol == this.numCol); }
  }
  
  private class GridHelper implements MatrixHelper, Serializable {
    private final Grid this$0;
    
    private GridHelper(Grid this$0) { this.this$0 = this$0; }
    
    public Object createRowInfo() { return this.this$0.createRowInfo(); }
    
    public Object createColInfo() { return this.this$0.createColInfo(); }
    
    public Object createObject() { return this.this$0.createCellInfo(); }
  }
  
  class ResizeLine extends Component {
    private final Grid this$0;
    
    public ResizeLine(Grid this$0) {
      this.this$0 = this$0;
      enableEvents(48L);
    }
    
    public void paint(Graphics param1Graphics) {
      param1Graphics.setColor(this.this$0.getForeground());
      Dimension dimension = getSize();
      Tool.drawDotLine(param1Graphics, 0, 0, dimension.width - 1, 0);
      Tool.drawDotLine(param1Graphics, 0, dimension.height - 1, dimension.width - 1, dimension.height - 1);
      Tool.drawDotLine(param1Graphics, 0, 0, 0, dimension.height - 1);
      Tool.drawDotLine(param1Graphics, dimension.width - 1, 0, dimension.width - 1, dimension.height - 1);
    }
    
    public void processMouseEvent(MouseEvent param1MouseEvent) {
      param1MouseEvent.translatePoint((((Component)param1MouseEvent.getSource()).getLocation()).x, (((Component)param1MouseEvent.getSource()).getLocation()).y);
      ((Grid.Pane)this.this$0.getPane()).processMouseEvent(param1MouseEvent);
    }
    
    public void processMouseMotionEvent(MouseEvent param1MouseEvent) {
      param1MouseEvent.translatePoint((((Component)param1MouseEvent.getSource()).getLocation()).x, (((Component)param1MouseEvent.getSource()).getLocation()).y);
      ((Grid.Pane)this.this$0.getPane()).processMouseMotionEvent(param1MouseEvent);
    }
  }
  
  private class EventForwarder implements MouseListener, MouseMotionListener, KeyListener, Serializable {
    private final Grid this$0;
    
    private EventForwarder(Grid this$0) { this.this$0 = this$0; }
    
    public void forwardMouse(MouseEvent param1MouseEvent) {
      param1MouseEvent.translatePoint((((Component)param1MouseEvent.getSource()).getLocation()).x, (((Component)param1MouseEvent.getSource()).getLocation()).y);
      ((Grid.Pane)this.this$0.getPane()).processMouseEvent(param1MouseEvent);
    }
    
    public void forwardMouseMotion(MouseEvent param1MouseEvent) {
      param1MouseEvent.translatePoint((((Component)param1MouseEvent.getSource()).getLocation()).x, (((Component)param1MouseEvent.getSource()).getLocation()).y);
      ((Grid.Pane)this.this$0.getPane()).processMouseMotionEvent(param1MouseEvent);
    }
    
    public void forwardKey(KeyEvent param1KeyEvent) { ((Grid.Pane)this.this$0.getPane()).processKeyEvent(param1KeyEvent); }
    
    public void keyPressed(KeyEvent param1KeyEvent) { forwardKey(param1KeyEvent); }
    
    public void keyReleased(KeyEvent param1KeyEvent) { forwardKey(param1KeyEvent); }
    
    public void keyTyped(KeyEvent param1KeyEvent) { forwardKey(param1KeyEvent); }
    
    public void mouseClicked(MouseEvent param1MouseEvent) { forwardMouse(param1MouseEvent); }
    
    public void mousePressed(MouseEvent param1MouseEvent) { forwardMouse(param1MouseEvent); }
    
    public void mouseReleased(MouseEvent param1MouseEvent) { forwardMouse(param1MouseEvent); }
    
    public void mouseEntered(MouseEvent param1MouseEvent) { forwardMouse(param1MouseEvent); }
    
    public void mouseExited(MouseEvent param1MouseEvent) { forwardMouse(param1MouseEvent); }
    
    public void mouseDragged(MouseEvent param1MouseEvent) { forwardMouseMotion(param1MouseEvent); }
    
    public void mouseMoved(MouseEvent param1MouseEvent) { forwardMouseMotion(param1MouseEvent); }
  }
  
  private class EditorListener extends KeyAdapter implements ActionListener, FocusListener, TextListener {
    private long gtime;
    
    private final Grid this$0;
    
    private EditorListener(Grid this$0) {
      this.this$0 = this$0;
      this.gtime = System.currentTimeMillis();
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      this.this$0.popdownEditor();
      if (param1ActionEvent.getSource() instanceof JTextComponent)
        this.this$0.nextCellFocus(); 
    }
    
    public void textValueChanged(TextEvent param1TextEvent) {
      String str = ((TextComponent)this.this$0.editor).getText();
      this.this$0.setObject(this.this$0.lastFocus.y, this.this$0.lastFocus.x, str);
    }
    
    public void focusLost(FocusEvent param1FocusEvent) {
      synchronized (this.this$0) {
        if (this.this$0.ignoreFocus > 0) {
          this.this$0.ignoreFocus--;
          return;
        } 
        if (System.currentTimeMillis() - this.gtime > 500L) {
          this.this$0.popdownEditor();
        } else if (this.this$0.editor != null) {
          ((Component)this.this$0.editor).requestFocus();
        } 
      } 
    }
    
    public void focusGained(FocusEvent param1FocusEvent) { this.gtime = System.currentTimeMillis(); }
    
    public void keyPressed(KeyEvent param1KeyEvent) {
      if (param1KeyEvent.getKeyChar() == '\t' && param1KeyEvent.getModifiers() == 0 && param1KeyEvent.getSource() == this.this$0.textfield) {
        this.this$0.nextCellFocus();
        param1KeyEvent.consume();
      } 
    }
  }
  
  protected int compare(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramObject1 == paramObject2)
      return 0; 
    if (paramObject1 == null)
      return -1; 
    if (paramObject2 == null)
      return 1; 
    ColInfo colInfo = getColInfo(paramInt);
    if (colInfo.comparer != null)
      return colInfo.comparer.compare(paramObject1, paramObject2); 
    if (paramObject1 instanceof Number && paramObject2 instanceof Number)
      return (int)Math.ceil(((Number)paramObject1).doubleValue() - ((Number)paramObject2).doubleValue()); 
    if (paramObject1 instanceof Date && paramObject2 instanceof Date)
      return (int)(((Date)paramObject1).getTime() - ((Date)paramObject2).getTime()); 
    return paramObject1.toString().compareTo(paramObject2.toString());
  }
  
  protected int compare(int[] paramArrayOfInt, int paramInt1, int paramInt2) {
    for (byte b = 0; b < paramArrayOfInt.length; b++) {
      int i = compare(paramArrayOfInt[b], getObject(paramInt1, paramArrayOfInt[b]), getObject(paramInt2, paramArrayOfInt[b]));
      if (i != 0)
        return i / Math.abs(i); 
    } 
    return 0;
  }
  
  public void sort(int paramInt, boolean paramBoolean) { sort(new int[] { paramInt }, paramBoolean); }
  
  public void sort(int[] paramArrayOfInt, boolean paramBoolean) {
    synchronized (getTreeLock()) {
      if (this.rowmap == null)
        setReorderable(getReorderable() | true); 
      setSuspended(true);
      qsort(paramArrayOfInt, paramBoolean, 0, getRowCount() - 1);
      setSuspended(false);
    } 
  }
  
  private void qsort(int[] paramArrayOfInt, boolean paramBoolean, int paramInt1, int paramInt2) {
    if (paramInt1 >= paramInt2)
      return; 
    int i = paramInt1;
    int j = paramInt2;
    byte b = paramBoolean ? -1 : 1;
    boolean bool = paramBoolean ? 1 : -1;
    while (i < j) {
      int m;
      while (i < paramInt2 && ((m = compare(paramArrayOfInt, i, paramInt1)) == b || m == 0))
        i++; 
      while (compare(paramArrayOfInt, j, paramInt1) == bool)
        j--; 
      if (i < j) {
        int n = this.rowmap[i + this.hrow];
        this.rowmap[i + this.hrow] = this.rowmap[j + this.hrow];
        this.rowmap[j + this.hrow] = n;
      } 
    } 
    int k = this.rowmap[paramInt1 + this.hrow];
    this.rowmap[paramInt1 + this.hrow] = this.rowmap[j + this.hrow];
    this.rowmap[j + this.hrow] = k;
    qsort(paramArrayOfInt, paramBoolean, paramInt1, j - 1);
    qsort(paramArrayOfInt, paramBoolean, j + 1, paramInt2);
  }
  
  public int find(int paramInt1, String paramString, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    if (!paramBoolean2)
      paramString = paramString.toUpperCase(); 
    for (int i = paramInt2; (paramBoolean1 && i < getRowCount()) || (!paramBoolean1 && i >= 0); i++) {
      Object object = getObject(i, paramInt1);
      if (object != null && ((paramBoolean2 && object.toString().indexOf(paramString) >= 0) || (!paramBoolean2 && object.toString().toUpperCase().indexOf(paramString) >= 0)))
        return i; 
    } 
    return -1;
  }
  
  private void addComponent(int paramInt1, int paramInt2, Component paramComponent) {
    paramComponent.setFont(getFont(paramInt1, paramInt2));
    paramComponent.addMouseListener(this.forwarder);
    paramComponent.addMouseMotionListener(this.forwarder);
    paramComponent.addKeyListener(this.forwarder);
    paramComponent.addFocusListener(this.focusListener);
    getPane().add(paramComponent);
    (getCellInfo(paramInt1, paramInt2, true)).component = paramComponent;
  }
  
  private void removeComponents() {
    for (byte b = 0; b < this.gridinfo.getRowCount(); b++) {
      for (byte b1 = 0; b1 < this.gridinfo.getColCount(); b1++) {
        CellInfo cellInfo = (CellInfo)this.gridinfo.getObject(b, b1, false);
        if (cellInfo != null && cellInfo.component != null) {
          Component component = cellInfo.component;
          if (component.getParent() == getPane()) {
            getPane().remove(component);
          } else if (component.getParent() != null) {
            getPane().remove(component.getParent());
          } 
        } 
      } 
    } 
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) throws ClassNotFoundException, IOException {
    paramObjectInputStream.defaultReadObject();
    this.oSize = new Dimension(0, 0);
  }
  
  static Vector resetFields = new Vector();
  
  int nrow;
  
  int ncol;
  
  Matrix gridinfo;
  
  GridInfo ginfo;
  
  int[] gridX;
  
  int[] gridY;
  
  int[] rowHeight;
  
  int[] colWidth;
  
  int[] rowmap;
  
  int[] colmap;
  
  int absolute;
  
  int resizable;
  
  boolean inPlace;
  
  boolean fillLastCol;
  
  boolean cursorChanged;
  
  int resizeR;
  
  int resizeC;
  
  Point linePos;
  
  Component resizeLineC;
  
  Component resizeLineR;
  
  Point frozen;
  
  int hrow;
  
  int hcol;
  
  private boolean lineWrap;
  
  Point root;
  
  Point pixelOff;
  
  int mode3D;
  
  Color borderC;
  
  int lineWidth;
  
  Dimension oSize;
  
  boolean needLayout;
  
  Image buffer;
  
  boolean multiSel;
  
  boolean rowSelectable;
  
  boolean colSelectable;
  
  boolean regSelectable;
  
  Region selReg;
  
  boolean useRowHeader;
  
  boolean useColHeader;
  
  int highlightMask;
  
  Color highlightFG;
  
  Color highlightBG;
  
  Point menuPos;
  
  int reorderable;
  
  boolean moving;
  
  Point movePos;
  
  Component moveBox;
  
  Point moveOff;
  
  JPopupMenu rowMenu;
  
  JPopupMenu colMenu;
  
  int gridRowHeight;
  
  int gridColWidth;
  
  int gridMinRowHeight;
  
  int gridMinColWidth;
  
  Point arrow;
  
  boolean arrowDown;
  
  GridModel model;
  
  Point lastFocus;
  
  GridCellEditor editor;
  
  TextFieldEditor textfield;
  
  TextAreaEditor textarea;
  
  int ignoreFocus;
  
  boolean csort;
  
  int lastSort;
  
  boolean lastOrder;
  
  boolean selectOnEntry;
  
  Pane pane;
  
  boolean suspend;
  
  Rectangle visReg;
  
  int lookahead;
  
  boolean delayed;
  
  boolean mvalid;
  
  Cursor defaultCursor;
  
  static  {
    try {
      gapProperty = GridInfo.class.getField("gap");
      borderProperty = GridInfo.class.getField("border");
      alignProperty = GridInfo.class.getField("align");
      fontProperty = GridInfo.class.getField("font");
      highlightedProperty = GridInfo.class.getField("highlighted");
      editableProperty = GridInfo.class.getField("editable");
      copiableProperty = GridInfo.class.getField("copiable");
      formatProperty = GridInfo.class.getField("format");
      foregroundProperty = GridInfo.class.getField("foreground");
      backgroundProperty = GridInfo.class.getField("background");
      editorProperty = GridInfo.class.getField("editor");
      rendererProperty = GridInfo.class.getField("renderer");
      resetFields.addElement(gapProperty);
      resetFields.addElement(fontProperty);
      resetFields.addElement(formatProperty);
      resetFields.addElement(rendererProperty);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\Grid.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */