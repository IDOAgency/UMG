package inetsoft.grid.event;

import java.awt.Component;
import java.awt.event.ComponentEvent;

public class GridComponentEvent extends ComponentEvent {
  private int from;
  
  private int to;
  
  private int dir;
  
  public GridComponentEvent(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super((Component)paramObject, paramInt1);
    this.from = paramInt2;
    this.to = paramInt3;
    this.dir = paramInt4;
  }
  
  public int getFrom() { return this.from; }
  
  public int getTo() { return this.to; }
  
  public int getDirection() { return this.dir; }
  
  public String paramString() { return super.paramString() + ",from=" + this.from + ",to=" + this.to + ",direction=" + this.dir; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\event\GridComponentEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */