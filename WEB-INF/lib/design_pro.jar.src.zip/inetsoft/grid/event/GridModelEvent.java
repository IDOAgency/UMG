/*    */ package inetsoft.grid.event;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GridModelEvent
/*    */   extends EventObject
/*    */ {
/*    */   public static final int ROW_INSERTED = 16;
/*    */   public static final int ROW_REMOVED = 32;
/*    */   public static final int COL_INSERTED = 48;
/*    */   public static final int COL_REMOVED = 64;
/*    */   public static final int CELL_UPDATED = 1;
/*    */   private int id;
/*    */   private int row;
/*    */   private int col;
/*    */   private int nrow;
/*    */   private int ncol;
/*    */   
/*    */   public GridModelEvent(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 57 */     super(paramObject);
/* 58 */     this.id = paramInt1;
/* 59 */     this.row = paramInt2;
/* 60 */     this.col = paramInt3;
/* 61 */     this.nrow = paramInt4;
/* 62 */     this.ncol = paramInt5;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   public int getID() { return this.id; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 76 */   public int getRow() { return this.row; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 83 */   public int getCol() { return this.col; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 90 */   public int getRowCount() { return this.nrow; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 97 */   public int getColCount() { return this.ncol; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\event\GridModelEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */