package inetsoft.grid.event;

import java.util.EventObject;

public class GridModelEvent extends EventObject {
  public static final int ROW_INSERTED = 16;
  
  public static final int ROW_REMOVED = 32;
  
  public static final int COL_INSERTED = 48;
  
  public static final int COL_REMOVED = 64;
  
  public static final int CELL_UPDATED = 1;
  
  private int id;
  
  private int row;
  
  private int col;
  
  private int nrow;
  
  private int ncol;
  
  public GridModelEvent(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    super(paramObject);
    this.id = paramInt1;
    this.row = paramInt2;
    this.col = paramInt3;
    this.nrow = paramInt4;
    this.ncol = paramInt5;
  }
  
  public int getID() { return this.id; }
  
  public int getRow() { return this.row; }
  
  public int getCol() { return this.col; }
  
  public int getRowCount() { return this.nrow; }
  
  public int getColCount() { return this.ncol; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\event\GridModelEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */