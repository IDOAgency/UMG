package inetsoft.grid.event;

import java.awt.Point;
import java.awt.event.ActionEvent;

public class GridActionEvent extends ActionEvent {
  public static final String SELECT = "select";
  
  public static final String EDIT = "edit";
  
  private Point pos;
  
  public GridActionEvent(Object paramObject, String paramString, Point paramPoint) {
    super(paramObject, 1001, paramString);
    this.pos = paramPoint;
  }
  
  public Point getLocation() { return this.pos; }
  
  public String paramString() { return super.paramString() + ",cell=" + this.pos; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\event\GridActionEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */