package inetsoft.grid.event;

import java.util.EventListener;

public interface GridModelListener extends EventListener {
  void valueChanged(GridModelEvent paramGridModelEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\event\GridModelListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */