/*    */ package inetsoft.grid.event;
/*    */ 
/*    */ import java.awt.ItemSelectable;
/*    */ import java.awt.event.ItemEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GridItemEvent
/*    */   extends ItemEvent
/*    */ {
/* 29 */   public static final Object ROW = "row";
/*    */ 
/*    */ 
/*    */   
/* 33 */   public static final Object COL = "col";
/*    */ 
/*    */ 
/*    */   
/* 37 */   public static final Object REGION = "region";
/*    */ 
/*    */ 
/*    */   
/*    */   private Object type;
/*    */ 
/*    */ 
/*    */   
/*    */   public GridItemEvent(ItemSelectable paramItemSelectable, Object paramObject1, int paramInt, Object paramObject2) {
/* 46 */     super(paramItemSelectable, 701, paramObject1, paramInt);
/* 47 */     this.type = paramObject2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public Object getType() { return this.type; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   public String paramString() { return super.paramString() + ",type=" + this.type; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\event\GridItemEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */