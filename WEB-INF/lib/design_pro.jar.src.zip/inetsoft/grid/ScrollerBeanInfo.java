/*    */ package inetsoft.grid;
/*    */ 
/*    */ import inetsoft.beans.AutoBeanInfo;
/*    */ import inetsoft.beans.RadioEditorSupport;
/*    */ import java.awt.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScrollerBeanInfo
/*    */   extends AutoBeanInfo
/*    */ {
/*    */   public ScrollerBeanInfo() {
/* 29 */     super(Scroller.class);
/* 30 */     registerEditor("scrollOption", Editor.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Image getIcon(int paramInt) {
/*    */     Image image;
/* 36 */     switch (paramInt) {
/*    */       case 1:
/*    */       case 3:
/* 39 */         image = loadImage("beans/ScrollerBean.gif");
/* 40 */         return image.getScaledInstance(16, 16, 4);
/*    */       case 2:
/*    */       case 4:
/* 43 */         image = loadImage("beans/ScrollerBean32.gif");
/* 44 */         return image.getScaledInstance(32, 32, 4);
/*    */     } 
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Editor
/*    */     extends RadioEditorSupport
/*    */   {
/* 54 */     public String[] getOptionTags() { return new String[] { "H_SCROLL", "H_FILL", "V_SCROLL", "V_FILL" }; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     public int[] getOptionMasks() { return new int[] { 1, 2, 4, 8 }; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     public int[] getRadioGroups() { return new int[] { 2, 2 }; }
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\ScrollerBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */