package inetsoft.grid;

import inetsoft.beans.AutoBeanInfo;
import inetsoft.beans.RadioEditorSupport;
import java.awt.Image;

public class ScrollerBeanInfo extends AutoBeanInfo {
  public ScrollerBeanInfo() {
    super(Scroller.class);
    registerEditor("scrollOption", Editor.class);
  }
  
  public Image getIcon(int paramInt) {
    Image image;
    switch (paramInt) {
      case 1:
      case 3:
        image = loadImage("beans/ScrollerBean.gif");
        return image.getScaledInstance(16, 16, 4);
      case 2:
      case 4:
        image = loadImage("beans/ScrollerBean32.gif");
        return image.getScaledInstance(32, 32, 4);
    } 
    return null;
  }
  
  public static class Editor extends RadioEditorSupport {
    public String[] getOptionTags() { return new String[] { "H_SCROLL", "H_FILL", "V_SCROLL", "V_FILL" }; }
    
    public int[] getOptionMasks() { return new int[] { 1, 2, 4, 8 }; }
    
    public int[] getRadioGroups() { return new int[] { 2, 2 }; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\ScrollerBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */