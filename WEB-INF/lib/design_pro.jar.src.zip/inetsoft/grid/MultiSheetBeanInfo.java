package inetsoft.grid;

import inetsoft.beans.AutoBeanInfo;
import java.awt.Image;

public class MultiSheetBeanInfo extends AutoBeanInfo {
  public MultiSheetBeanInfo() {
    super(MultiSheet.class);
    registerEditor("scrollOption", ScrollerBeanInfo.Editor.class);
    registerEditor("tabPlacement", inetsoft.widget.util.PositionEditor.class);
    registerEditor("tabLayout", inetsoft.widget.FolderBeanInfo.Editor.class);
    registerEditor("tabAppearance", inetsoft.widget.FolderBeanInfo.Appearance.class);
  }
  
  public Image getIcon(int paramInt) {
    Image image;
    switch (paramInt) {
      case 1:
      case 3:
        image = loadImage("beans/MultiSheetBean.gif");
        return image.getScaledInstance(16, 16, 4);
      case 2:
      case 4:
        image = loadImage("beans/MultiSheetBean32.gif");
        return image.getScaledInstance(32, 32, 4);
    } 
    return null;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\MultiSheetBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */