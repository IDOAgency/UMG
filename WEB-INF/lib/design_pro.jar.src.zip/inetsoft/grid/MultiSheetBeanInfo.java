/*    */ package inetsoft.grid;
/*    */ 
/*    */ import inetsoft.beans.AutoBeanInfo;
/*    */ import java.awt.Image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiSheetBeanInfo
/*    */   extends AutoBeanInfo
/*    */ {
/*    */   public MultiSheetBeanInfo() {
/* 31 */     super(MultiSheet.class);
/* 32 */     registerEditor("scrollOption", ScrollerBeanInfo.Editor.class);
/* 33 */     registerEditor("tabPlacement", inetsoft.widget.util.PositionEditor.class);
/* 34 */     registerEditor("tabLayout", inetsoft.widget.FolderBeanInfo.Editor.class);
/* 35 */     registerEditor("tabAppearance", inetsoft.widget.FolderBeanInfo.Appearance.class);
/*    */   }
/*    */ 
/*    */   
/*    */   public Image getIcon(int paramInt) {
/*    */     Image image;
/* 41 */     switch (paramInt) {
/*    */       case 1:
/*    */       case 3:
/* 44 */         image = loadImage("beans/MultiSheetBean.gif");
/* 45 */         return image.getScaledInstance(16, 16, 4);
/*    */       case 2:
/*    */       case 4:
/* 48 */         image = loadImage("beans/MultiSheetBean32.gif");
/* 49 */         return image.getScaledInstance(32, 32, 4);
/*    */     } 
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\MultiSheetBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */