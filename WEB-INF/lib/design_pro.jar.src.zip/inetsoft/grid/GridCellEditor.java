package inetsoft.grid;

import java.awt.event.ActionListener;

public interface GridCellEditor extends GridCellRenderer {
  Object getCellEditorValue();
  
  void addActionListener(ActionListener paramActionListener);
  
  void removeActionListener(ActionListener paramActionListener);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\GridCellEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */