/*     */ package inetsoft.grid;
/*     */ 
/*     */ import java.awt.Adjustable;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.AdjustmentEvent;
/*     */ import java.awt.event.AdjustmentListener;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.io.Serializable;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Scroller
/*     */   extends JPanel
/*     */   implements ScrollControl
/*     */ {
/*     */   Thread thread;
/*     */   private ScrollListener adjListener;
/*     */   ComponentListener viewListener;
/*     */   int sopt;
/*     */   boolean auto;
/*     */   Dimension pSize;
/*     */   JPanel viewport;
/*     */   JPanel hscrollPanel;
/*     */   JScrollBar vscroll;
/*     */   JScrollBar hscroll;
/*     */   PlaceHolder placeHolder;
/*     */   Component comp;
/*     */   Dimension compSize;
/*     */   boolean hUpdate;
/*     */   boolean vUpdate;
/*     */   Integer vval;
/*     */   Integer hval;
/*     */   
/*     */   public Scroller() {
/* 646 */     this.thread = new Thread(this) {
/*     */         public void run() {
/*     */           while (true) {
/* 649 */             Integer integer1 = null, integer2 = null;
/*     */             
/* 651 */             synchronized (this.this$0) {
/* 652 */               while (this.this$0.hval == null && this.this$0.vval == null) { 
/* 653 */                 try { this.this$0.wait(); } catch (Exception exception) {} }
/*     */ 
/*     */               
/* 656 */               integer1 = this.this$0.vval;
/* 657 */               integer2 = this.this$0.hval;
/* 658 */               this.this$0.hval = this.this$0.vval = null;
/*     */             } 
/* 660 */             yield();
/*     */             
/* 662 */             if (integer2 != null) {
/* 663 */               ((Scrollable)this.this$0.comp).setValue(2, integer2.intValue());
/*     */             }
/*     */             
/* 666 */             if (integer1 != null) {
/* 667 */               ((Scrollable)this.this$0.comp).setValue(1, integer1.intValue());
/*     */             }
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         private final Scroller this$0;
/*     */       };
/* 676 */     this.adjListener = new ScrollListener(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 735 */     this.viewListener = new ComponentAdapter(this) { private final Scroller this$0;
/*     */         
/* 737 */         public void componentResized(ComponentEvent param1ComponentEvent) { this.this$0.notifyUpdate((Component)param1ComponentEvent.getSource()); }
/*     */          }
/*     */       ;
/*     */ 
/*     */     
/* 742 */     this.sopt = 5;
/* 743 */     this.auto = true;
/* 744 */     this.pSize = null;
/*     */ 
/*     */     
/* 747 */     this.vscroll = null; this.hscroll = null;
/* 748 */     this.placeHolder = null;
/*     */ 
/*     */     
/* 751 */     this.hUpdate = false; this.vUpdate = false;
/* 752 */     this.vval = null; this.hval = null;
/*     */     setLayout(new BorderLayout());
/*     */     this.thread.start();
/*     */   }
/*     */   
/*     */   public Scroller(Component paramComponent) {
/*     */     this();
/*     */     setComponent(paramComponent);
/*     */   }
/*     */   
/*     */   public Scroller(Component paramComponent, int paramInt1, int paramInt2) { this(paramComponent, paramInt1, paramInt2, true); }
/*     */   
/*     */   public Scroller(Component paramComponent, int paramInt1, int paramInt2, boolean paramBoolean) {
/*     */     this(paramComponent);
/*     */     this.auto = paramBoolean;
/*     */     this.pSize = new Dimension(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public void adjust(int paramInt1, int paramInt2) {
/*     */     JScrollBar jScrollBar = (paramInt1 == 2) ? this.hscroll : this.vscroll;
/*     */     if (jScrollBar == null)
/*     */       return; 
/*     */     this.adjListener.adjustmentValueChanged(new AdjustmentEvent(jScrollBar, 601, paramInt2, jScrollBar.getValue()));
/*     */   }
/*     */   
/*     */   public void setPreferredSize(int paramInt1, int paramInt2) { this.pSize = new Dimension(paramInt1, paramInt2); }
/*     */   
/*     */   public void setPreferredSize(Dimension paramDimension) { this.pSize = paramDimension; }
/*     */   
/*     */   public Component add(Component paramComponent) {
/*     */     setComponent(paramComponent);
/*     */     return paramComponent;
/*     */   }
/*     */   
/*     */   public void add(Component paramComponent, Object paramObject) { add(paramComponent); }
/*     */   
/*     */   public void remove(Component paramComponent) {
/*     */     paramComponent.removeComponentListener(this.viewListener);
/*     */     super.remove(paramComponent);
/*     */   }
/*     */   
/*     */   public void setComponent(Component paramComponent) {
/*     */     this.comp = paramComponent;
/*     */     for (int i = getComponentCount() - 1; i >= 0; i--)
/*     */       remove(i); 
/*     */     this.viewport = new JPanel();
/*     */     if (paramComponent instanceof Scrollable) {
/*     */       this.viewport.setLayout(new BorderLayout());
/*     */       this.viewport.add(paramComponent, "Center");
/*     */       if (paramComponent instanceof Scrollable)
/*     */         ((Scrollable)paramComponent).registerScrollControl(this); 
/*     */     } else {
/*     */       this.viewport.setLayout(null);
/*     */       this.viewport.add(paramComponent);
/*     */       paramComponent.setLocation(0, 0);
/*     */       paramComponent.addComponentListener(this.viewListener);
/*     */     } 
/*     */     super.add(this.viewport, "Center");
/*     */     validate();
/*     */   }
/*     */   
/*     */   public Component getComponent() { return (getComponentCount() > 0) ? getComponent(0) : null; }
/*     */   
/*     */   public int getScrollOption() { return this.sopt; }
/*     */   
/*     */   public void setScrollOption(int paramInt) {
/*     */     if (paramInt != this.sopt) {
/*     */       this.sopt = paramInt;
/*     */       if (!(this.comp instanceof Scrollable)) {
/*     */         doLayout();
/*     */       } else {
/*     */         ((Scrollable)this.comp).registerScrollControl(this);
/*     */       } 
/*     */       checkScroll(false);
/*     */       setValues();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setUnitIncrement(int paramInt1, int paramInt2) {
/*     */     JScrollBar jScrollBar = (paramInt1 == 2) ? this.hscroll : this.vscroll;
/*     */     if (jScrollBar != null)
/*     */       jScrollBar.setUnitIncrement(paramInt2); 
/*     */   }
/*     */   
/*     */   public void setBlockIncrement(int paramInt1, int paramInt2) {
/*     */     JScrollBar jScrollBar = (paramInt1 == 2) ? this.hscroll : this.vscroll;
/*     */     if (jScrollBar != null)
/*     */       jScrollBar.setBlockIncrement(paramInt2); 
/*     */   }
/*     */   
/*     */   public void notifySync() {
/*     */     if (this.vval != null || this.hval != null)
/*     */       return; 
/*     */     if (this.comp instanceof Scrollable) {
/*     */       Scrollable scrollable = (Scrollable)this.comp;
/*     */       if (this.vscroll != null)
/*     */         this.vscroll.setValue(scrollable.getValue(1)); 
/*     */       if (this.hscroll != null)
/*     */         this.hscroll.setValue(scrollable.getValue(2)); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void notifyUpdate() {
/*     */     if (!(this.comp instanceof Scrollable))
/*     */       doLayout(); 
/*     */     checkScroll(false);
/*     */     setValues();
/*     */   }
/*     */   
/*     */   public void notifyUpdate(Component paramComponent) { notifyUpdate(); }
/*     */   
/*     */   public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*     */     super.setBounds(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     validate();
/*     */     if (!(this.comp instanceof Scrollable))
/*     */       doLayout(); 
/*     */     checkScroll(false);
/*     */     setValues();
/*     */   }
/*     */   
/*     */   public void doLayout() {
/*     */     super.doLayout();
/*     */     if (this.comp != null && !(this.comp instanceof Scrollable)) {
/*     */       Dimension dimension1 = new Dimension(-1, -1);
/*     */       Dimension dimension2 = this.comp.getPreferredSize();
/*     */       for (byte b = 0; b < 3 && (dimension2.width != dimension1.width || dimension2.height != dimension1.height); b++, dimension2 = this.comp.getPreferredSize()) {
/*     */         dimension1 = dimension2;
/*     */         Point point = this.comp.getLocation();
/*     */         if ((this.sopt & 0x2) != 0)
/*     */           dimension2.width = (getSize()).width; 
/*     */         if ((this.sopt & 0x8) != 0)
/*     */           dimension2.height = (getSize()).height; 
/*     */         this.comp.setBounds(point.x, point.y, dimension2.width, dimension2.height);
/*     */         this.comp.validate();
/*     */         this.compSize = this.comp.getSize();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension getViewportSize() {
/*     */     Dimension dimension = getSize();
/*     */     return new Dimension(dimension.width - ((this.vscroll != null) ? (this.vscroll.getSize()).width : 0), dimension.height - ((this.hscroll != null) ? (this.hscroll.getSize()).height : 0));
/*     */   }
/*     */   
/*     */   public Adjustable getVAdjustable() { return this.vscroll; }
/*     */   
/*     */   public Adjustable getHAdjustable() { return this.hscroll; }
/*     */   
/*     */   public Dimension getPreferredSize() { return (this.pSize != null) ? this.pSize : ((this.comp == null) ? new Dimension(20, 20) : this.comp.getPreferredSize()); }
/*     */   
/*     */   private void checkScroll(boolean paramBoolean) {
/*     */     if (this.comp == null)
/*     */       return; 
/*     */     Dimension dimension = getSize();
/*     */     boolean bool1 = true, bool2 = true, bool3 = false;
/*     */     if (this.auto)
/*     */       if (this.comp instanceof Scrollable) {
/*     */         Scrollable scrollable = (Scrollable)this.comp;
/*     */         bool1 = (scrollable.getMaximum(1) > scrollable.getMinimum(1) + scrollable.getVisibleAmount(1)) ? 1 : 0;
/*     */         bool2 = (scrollable.getMaximum(2) > scrollable.getMinimum(2) + scrollable.getVisibleAmount(2)) ? 1 : 0;
/*     */       } else {
/*     */         int i = (this.hscroll == null) ? 0 : (this.hscroll.getSize()).height;
/*     */         int j = (this.vscroll == null) ? 0 : (this.vscroll.getSize()).width;
/*     */         bool1 = (this.compSize.height > dimension.height - i) ? 1 : 0;
/*     */         bool2 = (this.compSize.width > dimension.width - j) ? 1 : 0;
/*     */       }  
/*     */     if (!paramBoolean && !bool1 && this.vscroll != null) {
/*     */       if (this.comp instanceof Scrollable) {
/*     */         setValue(1, this.vscroll.getMinimum());
/*     */       } else {
/*     */         this.comp.setLocation((this.comp.getLocation()).x, 0);
/*     */       } 
/*     */       remove(this.vscroll);
/*     */       this.vscroll = null;
/*     */       bool3 = (bool3 || this.hscroll != null) ? 1 : 0;
/*     */     } 
/*     */     if (!paramBoolean && !bool2 && this.hscroll != null) {
/*     */       if (this.comp instanceof Scrollable) {
/*     */         setValue(2, this.hscroll.getMinimum());
/*     */       } else {
/*     */         this.comp.setLocation(0, (this.comp.getLocation()).y);
/*     */       } 
/*     */       remove(this.hscrollPanel);
/*     */       this.hscroll = null;
/*     */       this.placeHolder = null;
/*     */       bool3 = (bool3 || this.vscroll != null) ? 1 : 0;
/*     */     } 
/*     */     if ((!bool1 || !bool2) && this.placeHolder != null) {
/*     */       this.hscrollPanel.remove(this.placeHolder);
/*     */       this.placeHolder = null;
/*     */     } 
/*     */     if (bool1 && this.vscroll == null) {
/*     */       this.vscroll = new JScrollBar(1);
/*     */       this.vscroll.addAdjustmentListener(this.adjListener);
/*     */       super.add(this.vscroll, "East");
/*     */       bool3 = (bool3 || this.hscroll == null) ? 1 : 0;
/*     */     } 
/*     */     if (bool2 && this.hscroll == null) {
/*     */       this.hscrollPanel = new JPanel();
/*     */       this.hscrollPanel.setLayout(new BorderLayout());
/*     */       this.hscroll = new JScrollBar(0);
/*     */       this.hscroll.addAdjustmentListener(this.adjListener);
/*     */       this.hscrollPanel.add(this.hscroll, "Center");
/*     */       super.add(this.hscrollPanel, "South");
/*     */       bool3 = (bool3 || this.vscroll == null) ? 1 : 0;
/*     */     } 
/*     */     if (this.vscroll != null && this.hscroll != null && this.placeHolder == null) {
/*     */       this.placeHolder = new PlaceHolder(this, (this.vscroll.getPreferredSize()).width, (this.hscroll.getPreferredSize()).height);
/*     */       this.hscrollPanel.add(this.placeHolder, "East");
/*     */     } 
/*     */     if (bool3) {
/*     */       validate();
/*     */       checkScroll(true);
/*     */       return;
/*     */     } 
/*     */     setValues();
/*     */   }
/*     */   
/*     */   private void setValues() {
/*     */     if (this.comp == null || (this.viewport.getSize()).width <= 0 || (this.viewport.getSize()).height <= 0)
/*     */       return; 
/*     */     Dimension dimension = getSize();
/*     */     if (this.comp instanceof Scrollable) {
/*     */       Scrollable scrollable = (Scrollable)this.comp;
/*     */       if (this.vscroll != null) {
/*     */         int i = scrollable.getVisibleAmount(1);
/*     */         i = (i >= 0) ? i : 0;
/*     */         boolean bool = (this.vscroll.getValue() == this.vscroll.getMinimum()) ? 1 : 0;
/*     */         this.vscroll.setMinimum(scrollable.getMinimum(1));
/*     */         this.vscroll.setMaximum(scrollable.getMaximum(1));
/*     */         this.vscroll.setBlockIncrement(scrollable.getIncrement(1, 4));
/*     */         this.vscroll.setUnitIncrement(scrollable.getIncrement(1, 1));
/*     */         if (bool)
/*     */           this.vscroll.setValue(this.vscroll.getMinimum()); 
/*     */         if (this.vscroll.getVisibleAmount() != i)
/*     */           this.vscroll.setVisibleAmount(i); 
/*     */       } else {
/*     */         scrollable.setValue(1, scrollable.getMinimum(1));
/*     */       } 
/*     */       if (this.hscroll != null) {
/*     */         int i = scrollable.getVisibleAmount(2);
/*     */         i = (i >= 0) ? i : 0;
/*     */         boolean bool = (this.hscroll.getValue() == this.hscroll.getMinimum()) ? 1 : 0;
/*     */         this.hscroll.setMinimum(scrollable.getMinimum(2));
/*     */         this.hscroll.setMaximum(scrollable.getMaximum(2));
/*     */         this.hscroll.setBlockIncrement(scrollable.getIncrement(2, 4));
/*     */         this.hscroll.setUnitIncrement(scrollable.getIncrement(2, 1));
/*     */         if (bool)
/*     */           this.hscroll.setValue(this.hscroll.getMinimum()); 
/*     */         if (this.hscroll.getVisibleAmount() != i)
/*     */           this.hscroll.setVisibleAmount(i); 
/*     */       } else {
/*     */         scrollable.setValue(2, scrollable.getMinimum(2));
/*     */       } 
/*     */     } else {
/*     */       if (this.vscroll != null) {
/*     */         this.vscroll.setValues(-(this.comp.getLocation()).y, (this.viewport.getSize()).height, 0, this.compSize.height);
/*     */         this.vscroll.setBlockIncrement((this.viewport.getSize()).height);
/*     */       } 
/*     */       if (this.hscroll != null) {
/*     */         this.hscroll.setValues(-(this.comp.getLocation()).x, (this.viewport.getSize()).width, 0, this.compSize.width);
/*     */         this.hscroll.setBlockIncrement((this.viewport.getSize()).width);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setValue(int paramInt1, int paramInt2) {
/*     */     if (paramInt1 == 2) {
/*     */       this.hval = new Integer(paramInt2);
/*     */     } else {
/*     */       this.vval = new Integer(paramInt2);
/*     */     } 
/*     */     notifyAll();
/*     */   }
/*     */   
/*     */   class ScrollListener implements AdjustmentListener, Serializable {
/*     */     private final Scroller this$0;
/*     */     
/*     */     ScrollListener(Scroller this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public void adjustmentValueChanged(AdjustmentEvent param1AdjustmentEvent) {
/*     */       Adjustable adjustable = param1AdjustmentEvent.getAdjustable();
/*     */       if (adjustable == this.this$0.hscroll) {
/*     */         int i = adjustable.getValue();
/*     */         if (this.this$0.comp instanceof Scrollable) {
/*     */           this.this$0.setValue(2, this.this$0.hscroll.getValue());
/*     */         } else {
/*     */           Point point = this.this$0.comp.getLocation();
/*     */           this.this$0.comp.setLocation(-this.this$0.hscroll.getValue(), point.y);
/*     */         } 
/*     */       } else if (adjustable == this.this$0.vscroll) {
/*     */         int i = adjustable.getValue();
/*     */         if (this.this$0.comp instanceof Scrollable) {
/*     */           this.this$0.setValue(1, this.this$0.vscroll.getValue());
/*     */         } else {
/*     */           Point point = this.this$0.comp.getLocation();
/*     */           this.this$0.comp.setLocation(point.x, -this.this$0.vscroll.getValue());
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class PlaceHolder extends Component {
/*     */     private Dimension pSize;
/*     */     private final Scroller this$0;
/*     */     
/*     */     public PlaceHolder(Scroller this$0, int param1Int1, int param1Int2) {
/*     */       this.this$0 = this$0;
/*     */       this.pSize = new Dimension(param1Int1, param1Int2);
/*     */     }
/*     */     
/*     */     public Dimension getPreferredSize() { return this.pSize; }
/*     */     
/*     */     public Dimension getMinimumSize() { return this.pSize; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\grid\Scroller.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */