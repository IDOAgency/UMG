package inetsoft.uql.corba.gui;

import inetsoft.uql.XDataSource;
import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.corba.CorbaDataSource;
import inetsoft.uql.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class CorbaDataSourceWizard extends DataSourceWizard {
  public CorbaDataSourceWizard() throws Exception {
    super(dialogs);
    this.xds = new CorbaDataSource();
    this.namesTF = new JTextField("", 20);
    this.descTF = new JTextArea(Catalog.getString("Please enter the Corba name service name."));
    JPanel jPanel1 = getMainPane();
    JPanel jPanel2 = new JPanel();
    jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel2.setLayout(new BorderLayout(2, 2));
    jPanel2.add(new JLabel(Catalog.getString("Name Service") + ":"), "West");
    jPanel2.add(this.namesTF, "Center");
    jPanel1.add(jPanel2, "North");
    this.descTF.setEditable(false);
    this.descTF.setLineWrap(true);
    this.descTF.setWrapStyleWord(true);
    this.descTF.setBackground(jPanel1.getBackground());
    jPanel1.add(this.descTF, "Center");
    jPanel1.setPreferredSize(new Dimension(280, 200));
  }
  
  public XDataSource getDataSource() { return this.xds; }
  
  public void setDataSource(XDataSource paramXDataSource) { this.xds = (CorbaDataSource)paramXDataSource; }
  
  public void populate() throws Exception { this.namesTF.setText(this.xds.getNameService()); }
  
  public String complete() {
    if (this.namesTF.getText().length() == 0)
      return Catalog.getString("Corba name service must be specified!"); 
    this.xds.setNameService(this.namesTF.getText());
    return null;
  }
  
  static final String[] dialogs = { "inetsoft.uql.corba.gui.NameWizard", "inetsoft.uql.corba.gui.ImportWizard" };
  
  CorbaDataSource xds;
  
  JTextField namesTF;
  
  JTextArea descTF;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\corba\gui\CorbaDataSourceWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */