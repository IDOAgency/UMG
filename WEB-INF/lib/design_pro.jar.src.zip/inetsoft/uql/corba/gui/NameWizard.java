/*    */ package inetsoft.uql.corba.gui;
/*    */ 
/*    */ import inetsoft.uql.builder.DataSourceWizard;
/*    */ import inetsoft.uql.corba.CorbaDataSource;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import inetsoft.uql.util.XUtil;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NameWizard
/*    */   extends DataSourceWizard
/*    */ {
/*    */   public NameWizard() throws Exception {
/* 39 */     JPanel jPanel1 = getMainPane();
/*    */     
/* 41 */     jPanel1.setBorder(new EmptyBorder(2, 2, 5, 2));
/*    */     
/* 43 */     JPanel jPanel2 = new JPanel();
/* 44 */     jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
/* 45 */     jPanel2.setLayout(new BorderLayout(2, 2));
/* 46 */     jPanel2.add(new JLabel(Catalog.getString("Server Name") + ":"), "West");
/*    */     
/* 48 */     jPanel2.add(this.nameTF, "Center");
/*    */     
/* 50 */     jPanel1.add(jPanel2, "North");
/* 51 */     this.descTF.setEditable(false);
/* 52 */     this.descTF.setLineWrap(true);
/* 53 */     this.descTF.setWrapStyleWord(true);
/* 54 */     this.descTF.setBackground(jPanel1.getBackground());
/* 55 */     jPanel1.add(this.descTF, "Center");
/*    */     
/* 57 */     jPanel1.setPreferredSize(new Dimension(280, 200));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void populate() throws Exception {
/* 65 */     CorbaDataSource corbaDataSource = (CorbaDataSource)getDataSource();
/* 66 */     StringBuffer stringBuffer = new StringBuffer();
/* 67 */     String[] arrayOfString = corbaDataSource.getNameComponents();
/*    */     
/* 69 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 70 */       if (b) {
/* 71 */         stringBuffer.append('/');
/*    */       }
/*    */       
/* 74 */       stringBuffer.append(arrayOfString[b]);
/*    */     } 
/*    */     
/* 77 */     this.nameTF.setText(stringBuffer.toString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String complete() {
/* 84 */     if (this.nameTF.getText().length() == 0) {
/* 85 */       return Catalog.getString("Corba name must be specified!");
/*    */     }
/*    */     
/* 88 */     CorbaDataSource corbaDataSource = (CorbaDataSource)getDataSource();
/* 89 */     corbaDataSource.setNameComponents(XUtil.split(this.nameTF.getText(), '/'));
/*    */     
/* 91 */     return null;
/*    */   }
/*    */   
/* 94 */   JTextField nameTF = new JTextField("", 20);
/* 95 */   JTextArea descTF = new JTextArea(Catalog.getString("Please enter the Corba name components (use '/' to separate the name components)."));
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\corba\gui\NameWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */