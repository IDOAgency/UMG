package inetsoft.uql.corba.gui;

import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.corba.CorbaDataSource;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.util.XUtil;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class NameWizard extends DataSourceWizard {
  public NameWizard() throws Exception {
    JPanel jPanel1 = getMainPane();
    jPanel1.setBorder(new EmptyBorder(2, 2, 5, 2));
    JPanel jPanel2 = new JPanel();
    jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel2.setLayout(new BorderLayout(2, 2));
    jPanel2.add(new JLabel(Catalog.getString("Server Name") + ":"), "West");
    jPanel2.add(this.nameTF, "Center");
    jPanel1.add(jPanel2, "North");
    this.descTF.setEditable(false);
    this.descTF.setLineWrap(true);
    this.descTF.setWrapStyleWord(true);
    this.descTF.setBackground(jPanel1.getBackground());
    jPanel1.add(this.descTF, "Center");
    jPanel1.setPreferredSize(new Dimension(280, 200));
  }
  
  public void populate() throws Exception {
    CorbaDataSource corbaDataSource = (CorbaDataSource)getDataSource();
    StringBuffer stringBuffer = new StringBuffer();
    String[] arrayOfString = corbaDataSource.getNameComponents();
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (b)
        stringBuffer.append('/'); 
      stringBuffer.append(arrayOfString[b]);
    } 
    this.nameTF.setText(stringBuffer.toString());
  }
  
  public String complete() {
    if (this.nameTF.getText().length() == 0)
      return Catalog.getString("Corba name must be specified!"); 
    CorbaDataSource corbaDataSource = (CorbaDataSource)getDataSource();
    corbaDataSource.setNameComponents(XUtil.split(this.nameTF.getText(), '/'));
    return null;
  }
  
  JTextField nameTF = new JTextField("", 20);
  
  JTextArea descTF = new JTextArea(Catalog.getString("Please enter the Corba name components (use '/' to separate the name components)."));
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\corba\gui\NameWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */