package inetsoft.uql.corba.gui;

import inetsoft.uql.xml.gui.XMLQueryProperty;

public class CorbaQueryProperty extends XMLQueryProperty {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\corba\gui\CorbaQueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */