/*    */ package inetsoft.uql.corba.gui;
/*    */ 
/*    */ import inetsoft.uql.builder.DataSourceWizard;
/*    */ import inetsoft.uql.corba.CorbaDataSource;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImportWizard
/*    */   extends DataSourceWizard
/*    */ {
/*    */   public ImportWizard() throws Exception {
/* 38 */     JPanel jPanel1 = getMainPane();
/*    */     
/* 40 */     jPanel1.setBorder(new EmptyBorder(2, 2, 5, 2));
/*    */     
/* 42 */     JPanel jPanel2 = new JPanel();
/* 43 */     jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
/* 44 */     jPanel2.setLayout(new BorderLayout(2, 2));
/* 45 */     jPanel2.add(new JLabel(Catalog.getString("Server Interface") + ":"), "West");
/*    */     
/* 47 */     jPanel2.add(this.serverTF, "Center");
/*    */     
/* 49 */     jPanel1.add(jPanel2, "North");
/* 50 */     this.descTF.setEditable(false);
/* 51 */     this.descTF.setLineWrap(true);
/* 52 */     this.descTF.setWrapStyleWord(true);
/* 53 */     this.descTF.setBackground(jPanel1.getBackground());
/* 54 */     jPanel1.add(this.descTF, "Center");
/*    */     
/* 56 */     jPanel1.setPreferredSize(new Dimension(280, 200));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void populate() throws Exception {
/* 64 */     CorbaDataSource corbaDataSource = (CorbaDataSource)getDataSource();
/* 65 */     this.serverTF.setText(corbaDataSource.getInterface());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String complete() {
/* 72 */     if (this.serverTF.getText().length() == 0) {
/* 73 */       return Catalog.getString("Corba server interface must be specified!");
/*    */     }
/*    */     
/*    */     try {
/* 77 */       CorbaDataSource corbaDataSource = (CorbaDataSource)getDataSource();
/* 78 */       Class clazz = Class.forName(this.serverTF.getText());
/*    */       
/* 80 */       corbaDataSource.importInterface(clazz);
/*    */     } catch (Exception exception) {
/*    */       
/* 83 */       return exception.toString();
/*    */     } 
/*    */     
/* 86 */     return null;
/*    */   }
/*    */   
/* 89 */   JTextField serverTF = new JTextField("", 20);
/* 90 */   JTextArea descTF = new JTextArea(Catalog.getString("Please enter the Corba server interface (class) to import the data definition."));
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\corba\gui\ImportWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */