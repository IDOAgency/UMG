package inetsoft.uql.corba.gui;

import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.corba.CorbaDataSource;
import inetsoft.uql.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ImportWizard extends DataSourceWizard {
  public ImportWizard() throws Exception {
    JPanel jPanel1 = getMainPane();
    jPanel1.setBorder(new EmptyBorder(2, 2, 5, 2));
    JPanel jPanel2 = new JPanel();
    jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel2.setLayout(new BorderLayout(2, 2));
    jPanel2.add(new JLabel(Catalog.getString("Server Interface") + ":"), "West");
    jPanel2.add(this.serverTF, "Center");
    jPanel1.add(jPanel2, "North");
    this.descTF.setEditable(false);
    this.descTF.setLineWrap(true);
    this.descTF.setWrapStyleWord(true);
    this.descTF.setBackground(jPanel1.getBackground());
    jPanel1.add(this.descTF, "Center");
    jPanel1.setPreferredSize(new Dimension(280, 200));
  }
  
  public void populate() throws Exception {
    CorbaDataSource corbaDataSource = (CorbaDataSource)getDataSource();
    this.serverTF.setText(corbaDataSource.getInterface());
  }
  
  public String complete() {
    if (this.serverTF.getText().length() == 0)
      return Catalog.getString("Corba server interface must be specified!"); 
    try {
      CorbaDataSource corbaDataSource = (CorbaDataSource)getDataSource();
      Class clazz = Class.forName(this.serverTF.getText());
      corbaDataSource.importInterface(clazz);
    } catch (Exception exception) {
      return exception.toString();
    } 
    return null;
  }
  
  JTextField serverTF = new JTextField("", 20);
  
  JTextArea descTF = new JTextArea(Catalog.getString("Please enter the Corba server interface (class) to import the data definition."));
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\corba\gui\ImportWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */