package inetsoft.uql.corba.gui;

import inetsoft.uql.XDataSource;
import inetsoft.uql.XNode;
import inetsoft.uql.builder.DataSourceProperty;
import inetsoft.uql.corba.CorbaDataSource;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.schema.XTypeNode;
import inetsoft.uql.util.gui.XEditPane;
import inetsoft.uql.util.gui.XTypeTree;
import inetsoft.widget.VFlowLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class CorbaDataSourceProperty extends DataSourceProperty {
  ListSelectionListener itemListener;
  
  ValueChangeListener changeListener;
  
  ActionListener addListener;
  
  ActionListener removeListener;
  
  ListSelectionListener nameListener;
  
  ActionListener importListener;
  
  CorbaDataSource xds;
  
  ItemModel itemModel;
  
  ListModel nameM;
  
  JTextField nsTF;
  
  JTextField nameTF;
  
  JList nameLT;
  
  JButton addB;
  
  JButton removeB;
  
  JTextField serverTF;
  
  JButton importB;
  
  JList itemLT;
  
  XEditPane xedit;
  
  XTypeTree xtree;
  
  JTabbedPane folder;
  
  OutputPane outpane;
  
  public CorbaDataSourceProperty() {
    this.itemListener = new ListSelectionListener(this) {
        private final CorbaDataSourceProperty this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
          String str = (String)this.this$0.itemLT.getSelectedValue();
          if (str != null) {
            XNode xNode = this.this$0.xds.getRequestParameters(str);
            XTypeNode xTypeNode1 = this.this$0.xds.getRequestInputType(str);
            XTypeNode xTypeNode2 = this.this$0.xds.getRequestOutputType(str);
            if (xNode == null)
              xNode = this.this$0.xds.getRequestInputType(str).newInstance(); 
            this.this$0.xedit.setType(xTypeNode1);
            this.this$0.xedit.setValue(xNode);
            this.this$0.xtree.setEnabled(true);
            this.this$0.xtree.setType(xTypeNode2);
          } 
          this.this$0.setEnabled();
        }
      };
    this.changeListener = new ValueChangeListener(this);
    this.addListener = new ActionListener(this) {
        private final CorbaDataSourceProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.nameM.addElement(this.this$0.nameTF.getText());
          String[] arrayOfString = new String[this.this$0.nameM.size()];
          this.this$0.nameM.copyInto(arrayOfString);
          this.this$0.xds.setNameComponents(arrayOfString);
          this.this$0.valueChanged();
        }
      };
    this.removeListener = new ActionListener(this) {
        private final CorbaDataSourceProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.nameM.removeElementAt(this.this$0.nameLT.getSelectedIndex());
          String[] arrayOfString = new String[this.this$0.nameM.size()];
          this.this$0.nameM.copyInto(arrayOfString);
          this.this$0.xds.setNameComponents(arrayOfString);
          this.this$0.valueChanged();
        }
      };
    this.nameListener = new ListSelectionListener(this) {
        private final CorbaDataSourceProperty this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) { this.this$0.setEnabled(); }
      };
    this.importListener = new ActionListener(this) {
        private final CorbaDataSourceProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            String str = this.this$0.serverTF.getText();
            this.this$0.xds.importInterface(Class.forName(str));
            this.this$0.itemLT.setModel(new CorbaDataSourceProperty.ItemModel(this.this$0));
            this.this$0.valueChanged();
          } catch (ClassNotFoundException classNotFoundException) {
          
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, exception.toString());
          } 
        }
      };
    this.xds = null;
    this.nsTF = new JTextField(20);
    this.nameTF = new JTextField(15);
    this.nameLT = new JList();
    this.addB = new JButton(Catalog.getString("Add"));
    this.removeB = new JButton(Catalog.getString("Remove"));
    this.serverTF = new JTextField(15);
    this.importB = new JButton(Catalog.getString("Import Server Class"));
    this.itemLT = new JList();
    this.xedit = new XEditPane();
    this.xtree = new XTypeTree();
    this.folder = new JTabbedPane();
    this.outpane = new OutputPane(this);
    setLayout(new BorderLayout());
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout(5, 5));
    add(jPanel1, "North");
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout(5, 5));
    jPanel1.add(jPanel2, "Center");
    JPanel jPanel3 = new JPanel();
    jPanel3.add(new JLabel(Catalog.getString("Name Service")));
    jPanel3.add(this.nsTF);
    jPanel2.add(jPanel3, "North");
    jPanel3 = new JPanel();
    jPanel3.setBorder(new TitledBorder(Catalog.getString("Name Components")));
    jPanel3.setLayout(new BorderLayout(5, 5));
    jPanel2.add(jPanel3, "Center");
    JPanel jPanel4 = new JPanel();
    jPanel4.setLayout(new VFlowLayout(16, 5, 5));
    jPanel4.add(this.nameTF);
    jPanel4.add(this.addB);
    jPanel4.add(this.removeB);
    jPanel3.add(jPanel4, "West");
    JScrollPane jScrollPane1 = new JScrollPane(this.nameLT);
    jScrollPane1.setPreferredSize(new Dimension(140, 60));
    jPanel3.add(jScrollPane1, "Center");
    jPanel2 = new JPanel();
    jPanel2.setBorder(new TitledBorder(Catalog.getString("Interface")));
    jPanel2.setLayout(new BorderLayout(5, 5));
    jPanel1.add(jPanel2, "East");
    JPanel jPanel5 = new JPanel();
    jPanel5.setLayout(new BorderLayout(5, 5));
    jPanel5.add(this.serverTF, "North");
    jPanel4 = new JPanel();
    jPanel4.add(this.importB);
    jPanel5.add(jPanel4, "South");
    jPanel2.add(jPanel5, "North");
    JScrollPane jScrollPane2 = new JScrollPane(this.itemLT);
    jScrollPane2.setPreferredSize(new Dimension(140, 60));
    jPanel2.add(jScrollPane2, "Center");
    this.folder.add(this.xedit, Catalog.getString("Parameters"));
    this.folder.add(this.outpane, Catalog.getString("Output"));
    add(this.folder, "Center");
    this.itemLT.addListSelectionListener(this.itemListener);
    this.xedit.addChangeListener(this.changeListener);
    this.nsTF.getDocument().addDocumentListener(this.changeListener);
    this.serverTF.getDocument().addDocumentListener(this.changeListener);
    this.nameLT.addListSelectionListener(this.nameListener);
    this.addB.addActionListener(this.addListener);
    this.removeB.addActionListener(this.removeListener);
    this.importB.addActionListener(this.importListener);
    setEnabled();
  }
  
  public void setDataSource(XDataSource paramXDataSource) {
    this.xds = (CorbaDataSource)paramXDataSource;
    this.nsTF.setText(this.xds.getNameService());
    this.serverTF.setText(this.xds.getInterface());
    this.nameLT.setModel(this.nameM = new ListModel(this, this.xds.getNameComponents()));
    this.itemLT.setModel(new ItemModel(this));
    if (this.xds.getRequestCount() > 0)
      this.itemLT.setSelectedIndex(0); 
    setValueChanged(false);
    setEnabled();
  }
  
  public XDataSource getDataSource() { return this.xds; }
  
  private void setEnabled() {
    this.xedit.setEnabled((this.itemLT.getSelectedIndex() >= 0));
    this.xtree.setEnabled((this.itemLT.getSelectedIndex() >= 0));
    this.outpane.setEnabled((this.itemLT.getSelectedIndex() >= 0));
    this.addB.setEnabled((this.nameM != null));
    this.removeB.setEnabled((this.nameM != null && this.nameLT.getSelectedIndex() >= 0));
    this.importB.setEnabled((this.serverTF.getText().trim().length() > 0));
  }
  
  public void verify() {
    if (this.nsTF.getText().trim().length() == 0)
      throw new Exception(Catalog.getString("Name service can not be empty!")); 
    if (this.xds.getNameComponents() == null || this.xds.getNameComponents().length == 0)
      throw new Exception(Catalog.getString("Name components can not be empty!")); 
    if (this.xds.getInterface() == null)
      throw new Exception(Catalog.getString("CORBA server interface must be imported!")); 
    if (this.xds.getRequestCount() == 0)
      throw new Exception(Catalog.getString("Datasource must have at least one request defined!")); 
  }
  
  class ListModel extends DefaultListModel {
    private final CorbaDataSourceProperty this$0;
    
    public ListModel(CorbaDataSourceProperty this$0, Object[] param1ArrayOfObject) {
      this.this$0 = this$0;
      for (byte b = 0; b < param1ArrayOfObject.length; b++)
        addElement(param1ArrayOfObject[b]); 
    }
  }
  
  class ItemModel extends AbstractListModel {
    private final CorbaDataSourceProperty this$0;
    
    ItemModel(CorbaDataSourceProperty this$0) { this.this$0 = this$0; }
    
    public int getSize() { return this.this$0.xds.getRequestCount(); }
    
    public Object getElementAt(int param1Int) { return this.this$0.xds.getRequest(param1Int); }
    
    public void valueAdded() {
      fireIntervalAdded(this, getSize() - 1, getSize() - 1);
      this.this$0.valueChanged();
    }
    
    public void valueRemoved(int param1Int) {
      fireIntervalRemoved(this, param1Int, param1Int);
      this.this$0.valueChanged();
    }
  }
  
  class ValueChangeListener implements ItemListener, DocumentListener, ChangeListener, ActionListener {
    private final CorbaDataSourceProperty this$0;
    
    ValueChangeListener(CorbaDataSourceProperty this$0) { this.this$0 = this$0; }
    
    public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.valueChanged(); }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.valueChanged(); }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      if (param1ChangeEvent.getSource() == this.this$0.xedit) {
        String str = (String)this.this$0.itemLT.getSelectedValue();
        if (str != null) {
          this.this$0.xds.setRequestParameters(str, this.this$0.xedit.getValue());
          this.this$0.xedit.setValueChanged(false);
        } 
      } 
      this.this$0.valueChanged();
    }
    
    public void insertUpdate(DocumentEvent param1DocumentEvent) {
      if (param1DocumentEvent.getDocument() == this.this$0.nsTF.getDocument())
        this.this$0.xds.setNameService(this.this$0.nsTF.getText()); 
      this.this$0.valueChanged();
      this.this$0.setEnabled();
    }
    
    public void removeUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
    
    public void changedUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
  }
  
  class OutputPane extends JPanel {
    private final CorbaDataSourceProperty this$0;
    
    public OutputPane(CorbaDataSourceProperty this$0) {
      this.this$0 = this$0;
      setLayout(new BorderLayout(10, 10));
      add(new JScrollPane(this$0.xtree), "Center");
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\corba\gui\CorbaDataSourceProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */