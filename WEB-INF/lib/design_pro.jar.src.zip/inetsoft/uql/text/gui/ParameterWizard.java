package inetsoft.uql.text.gui;

import inetsoft.uql.XNode;
import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.text.TextDataSource;
import inetsoft.uql.util.gui.XEditPane;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class ParameterWizard extends DataSourceWizard {
  public ParameterWizard() throws Exception {
    JPanel jPanel = getMainPane();
    jPanel.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel.setLayout(new BorderLayout(2, 2));
    jPanel.add(new JLabel(Catalog.getString("Request Parameter") + ":"), "North");
    jPanel.add(this.xedit, "Center");
    jPanel.setPreferredSize(new Dimension(500, 250));
  }
  
  public void populate() throws Exception {
    TextDataSource textDataSource = (TextDataSource)getDataSource();
    String str = textDataSource.getRequest(0);
    XNode xNode = textDataSource.getRequestParameters(str);
    if (xNode == null)
      xNode = textDataSource.getRequestInputType(str).newInstance(); 
    this.xedit.setType(textDataSource.getRequestInputType(str));
    this.xedit.setValue(xNode);
  }
  
  public String complete() {
    TextDataSource textDataSource = (TextDataSource)getDataSource();
    textDataSource.setRequestParameters(textDataSource.getRequest(0), this.xedit.getValue());
    return null;
  }
  
  XEditPane xedit = new XEditPane();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\text\gui\ParameterWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */