/*     */ package inetsoft.uql.text.gui;
/*     */ 
/*     */ import inetsoft.grid.Grid;
/*     */ import inetsoft.grid.MultiSheet;
/*     */ import inetsoft.grid.editor.BooleanEditor;
/*     */ import inetsoft.grid.editor.ComboEditor;
/*     */ import inetsoft.grid.editor.TextFieldEditor;
/*     */ import inetsoft.grid.event.GridModelEvent;
/*     */ import inetsoft.grid.event.GridModelListener;
/*     */ import inetsoft.grid.model.DefaultGridModel;
/*     */ import inetsoft.uql.VariableTable;
/*     */ import inetsoft.uql.XDataService;
/*     */ import inetsoft.uql.XFactory;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.XQuery;
/*     */ import inetsoft.uql.XTableNode;
/*     */ import inetsoft.uql.builder.QueryProperty;
/*     */ import inetsoft.uql.builder.VariableEntry;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.path.XSelection;
/*     */ import inetsoft.uql.schema.UserVariable;
/*     */ import inetsoft.uql.text.TextDataSource;
/*     */ import inetsoft.uql.text.TextQuery;
/*     */ import inetsoft.uql.util.gui.XTableNodeModel;
/*     */ import inetsoft.util.internal.Property2Panel;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextQueryProperty
/*     */   extends QueryProperty
/*     */ {
/*     */   ActionListener addListener;
/*     */   ActionListener removeListener;
/*     */   ActionListener importListener;
/*     */   ItemListener selListener;
/*     */   ActionListener prevListener;
/*     */   GridModelListener selectTbListener;
/*     */   DocumentListener delimListener;
/*     */   ItemListener tabListener;
/*     */   ItemListener headerListener;
/*     */   ItemListener reqListener;
/*     */   
/*     */   public TextQueryProperty() {
/* 249 */     this.addListener = new ActionListener(this) { private final TextQueryProperty this$0;
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 251 */           int i = this.this$0.selectTb.getSelectedCol();
/* 252 */           if (i < 0) {
/* 253 */             i = this.this$0.selectTb.getColCount();
/*     */           }
/*     */           
/* 256 */           this.this$0.model.insertCol(i, 1);
/* 257 */           this.this$0.model.setObject(0, i, Boolean.TRUE);
/*     */         } }
/*     */       ;
/*     */     
/* 261 */     this.removeListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 263 */           int i = this.this$0.selectTb.getSelectedCol();
/* 264 */           if (i >= 0)
/* 265 */             this.this$0.model.removeCol(i, 1); 
/*     */         }
/*     */         
/*     */         private final TextQueryProperty this$0;
/*     */       };
/* 270 */     this.importListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 272 */           JFileChooser jFileChooser = new JFileChooser();
/* 273 */           jFileChooser.setCurrentDirectory(new File("."));
/* 274 */           int i = jFileChooser.showOpenDialog(this.this$0);
/* 275 */           if (i == 0) {
/*     */             try {
/* 277 */               FileInputStream fileInputStream = new FileInputStream(jFileChooser.getSelectedFile());
/*     */               
/* 279 */               BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
/*     */               
/*     */               String str;
/*     */               
/* 283 */               if ((str = bufferedReader.readLine()) != null) {
/* 284 */                 this.this$0.model.setColCount(0);
/* 285 */                 StringTokenizer stringTokenizer = new StringTokenizer(str, this.this$0.delimTF.getText());
/*     */ 
/*     */                 
/* 288 */                 while (stringTokenizer.hasMoreTokens()) {
/* 289 */                   String str1 = stringTokenizer.nextToken();
/* 290 */                   int j = this.this$0.model.getColCount();
/* 291 */                   this.this$0.model.insertCol(j, 1);
/* 292 */                   this.this$0.model.setObject(0, j, new Boolean(true));
/* 293 */                   this.this$0.model.setObject(1, j, str1);
/*     */                 } 
/*     */               } 
/*     */               
/* 297 */               fileInputStream.close();
/*     */             } catch (Exception exception) {
/* 299 */               exception.printStackTrace();
/* 300 */               JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
/*     */               return;
/*     */             } 
/*     */           }
/*     */         }
/*     */ 
/*     */         
/*     */         private final TextQueryProperty this$0;
/*     */       };
/* 309 */     this.selListener = new ItemListener(this) { private final TextQueryProperty this$0;
/*     */         
/* 311 */         public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setEnabled(); }
/*     */          }
/*     */       ;
/*     */     
/* 315 */     this.prevListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */           try {
/* 318 */             XDataService xDataService = XFactory.getDataService();
/* 319 */             UserVariable[] arrayOfUserVariable = xDataService.getQueryParameters(this.this$0.getSession(), this.this$0.xquery.getName(), true);
/*     */             
/* 321 */             VariableTable variableTable = null;
/*     */             
/* 323 */             if (arrayOfUserVariable != null && arrayOfUserVariable.length > 0) {
/* 324 */               variableTable = VariableEntry.show(arrayOfUserVariable);
/*     */ 
/*     */               
/* 327 */               if (variableTable == null) {
/*     */                 return;
/*     */               }
/*     */             } 
/*     */             
/* 332 */             XNode xNode = xDataService.execute(this.this$0.getSession(), this.this$0.xquery.getName(), variableTable);
/*     */             
/* 334 */             if (xNode != null) {
/* 335 */               this.this$0.prevTb.setModel(new XTableNodeModel((XTableNode)xNode));
/*     */             }
/*     */             
/* 338 */             this.this$0.tables.toFront(1);
/*     */           } catch (Exception exception) {
/* 340 */             exception.printStackTrace();
/* 341 */             JOptionPane.showMessageDialog(this.this$0, exception.toString());
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         private final TextQueryProperty this$0;
/*     */       };
/* 348 */     this.selectTbListener = new GridModelListener(this) {
/*     */         public void valueChanged(GridModelEvent param1GridModelEvent) {
/* 350 */           this.this$0.valueChanged();
/* 351 */           this.this$0.updateQuery();
/*     */         }
/*     */         
/*     */         private final TextQueryProperty this$0;
/*     */       };
/* 356 */     this.delimListener = new DocumentListener(this) {
/*     */         public void insertUpdate(DocumentEvent param1DocumentEvent) {
/* 358 */           if (this.this$0.delimTF.getText().length() > 0) {
/* 359 */             this.this$0.xquery.setDelimiter(this.this$0.delimTF.getText());
/* 360 */             this.this$0.valueChanged();
/*     */           } 
/*     */         }
/*     */         private final TextQueryProperty this$0;
/*     */         
/* 365 */         public void removeUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
/*     */ 
/*     */         
/*     */         public void changedUpdate(DocumentEvent param1DocumentEvent) {
/* 369 */           insertUpdate(param1DocumentEvent);
/*     */         }
/*     */       };
/*     */ 
/*     */     
/* 374 */     this.tabListener = new ItemListener(this) {
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 376 */           this.this$0.xquery.setDelimiter(this.this$0.tabCB.isSelected() ? "\t" : this.this$0.delimTF.getText());
/* 377 */           this.this$0.setEnabled();
/* 378 */           this.this$0.valueChanged();
/*     */         }
/*     */         private final TextQueryProperty this$0;
/*     */       };
/* 382 */     this.headerListener = new ItemListener(this) {
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 384 */           this.this$0.xquery.setFirstHeaderRow(this.this$0.headerCB.isSelected());
/* 385 */           this.this$0.setEnabled();
/* 386 */           this.this$0.valueChanged();
/*     */         }
/*     */         private final TextQueryProperty this$0;
/*     */       };
/* 390 */     this.reqListener = new ItemListener(this) {
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 392 */           this.this$0.xquery.setRequest((String)this.this$0.reqCB.getSelectedItem());
/* 393 */           this.this$0.valueChanged();
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         private final TextQueryProperty this$0;
/*     */       };
/* 400 */     this.reqCB = new JComboBox();
/* 401 */     this.delimTF = new JTextField(5);
/* 402 */     this.tabCB = new JCheckBox(Catalog.getString("Tab"));
/* 403 */     this.headerCB = new JCheckBox(Catalog.getString("First Row as Header"));
/*     */     
/* 405 */     this.tables = new MultiSheet();
/* 406 */     this.model = null;
/* 407 */     this.selectTb = new Grid(this.model = new DefaultGridModel(4, 1));
/* 408 */     this.prevTb = new Grid();
/* 409 */     this.addB = new JButton(Catalog.getString("Insert Column"));
/* 410 */     this.removeB = new JButton(Catalog.getString("Remove Column"));
/* 411 */     this.previewB = new JButton(Catalog.getString("Preview"));
/* 412 */     this.importB = new JButton(Catalog.getString("Import Header"));
/*     */     setLayout(new BorderLayout(5, 5));
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     property2Panel.add(Catalog.getString("Text Input"), new Object[][] { { Catalog.getString("Request") + ":", this.reqCB, this.headerCB }, { Catalog.getString("Delimiter") + ":", this.delimTF, this.tabCB } });
/*     */     add(property2Panel, "North");
/*     */     JPanel jPanel1 = new JPanel();
/*     */     jPanel1.setLayout(new BorderLayout(5, 5));
/*     */     add(jPanel1, "Center");
/*     */     this.tables.add(this.selectTb, Catalog.getString("Selection"));
/*     */     this.tables.add(this.prevTb, Catalog.getString("Preview"));
/*     */     this.tables.toFront(0);
/*     */     jPanel1.add(this.tables, "Center");
/*     */     JPanel jPanel2 = new JPanel();
/*     */     jPanel2.setLayout(new BorderLayout());
/*     */     jPanel1.add(jPanel2, "North");
/*     */     JPanel jPanel3 = new JPanel();
/*     */     jPanel3.setLayout(new FlowLayout(0, 5, 5));
/*     */     jPanel3.add(this.addB);
/*     */     jPanel3.add(this.removeB);
/*     */     jPanel2.add(jPanel3, "West");
/*     */     jPanel3 = new JPanel();
/*     */     jPanel3.add(this.importB);
/*     */     jPanel2.add(jPanel3, "East");
/*     */     this.model.setHeaderRowCount(1);
/*     */     this.model.setHeaderColCount(1);
/*     */     this.selectTb.setRowSelectable(false);
/*     */     this.selectTb.setColSelectable(true);
/*     */     this.selectTb.setFillLastCol(false);
/*     */     this.selectTb.setReorderable(0);
/*     */     this.selectTb.setMinColWidth(-99, 100);
/*     */     this.selectTb.setMinColWidth(-1, 50);
/*     */     this.delimTF.getDocument().addDocumentListener(this.delimListener);
/*     */     this.tabCB.addItemListener(this.tabListener);
/*     */     this.selectTb.addItemListener(this.selListener);
/*     */     this.addB.addActionListener(this.addListener);
/*     */     this.removeB.addActionListener(this.removeListener);
/*     */     this.importB.addActionListener(this.importListener);
/*     */     this.previewB.addActionListener(this.prevListener);
/*     */     this.model.addGridModelListener(this.selectTbListener);
/*     */     this.reqCB.addItemListener(this.reqListener);
/*     */     this.headerCB.addItemListener(this.headerListener);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public void setQuery(XQuery paramXQuery) {
/*     */     this.xquery = (TextQuery)paramXQuery;
/*     */     this.xds = (TextDataSource)paramXQuery.getDataSource();
/*     */     this.model.removeGridModelListener(this.selectTbListener);
/*     */     DefaultComboBoxModel defaultComboBoxModel = new DefaultComboBoxModel();
/*     */     for (byte b = 0; b < this.xds.getRequestCount(); b++)
/*     */       defaultComboBoxModel.addElement(this.xds.getRequest(b)); 
/*     */     populateSelectionTable();
/*     */     this.reqCB.setModel(defaultComboBoxModel);
/*     */     this.reqCB.setSelectedItem(this.xquery.getRequest());
/*     */     String str = this.xquery.getDelimiter();
/*     */     if (str.length() == 1 && str.charAt(0) == '\t') {
/*     */       this.tabCB.setSelected(true);
/*     */     } else {
/*     */       this.delimTF.setText(str);
/*     */     } 
/*     */     this.headerCB.setSelected(this.xquery.isFirstHeaderRow());
/*     */     this.model.addGridModelListener(this.selectTbListener);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public XQuery getQuery() { return this.xquery; }
/*     */   
/*     */   public Component getCommandPane() { return this.previewB; }
/*     */   
/*     */   protected void updateQuery() {
/*     */     XSelection xSelection = new XSelection();
/*     */     Vector vector = new Vector();
/*     */     for (byte b1 = 0; b1 < this.selectTb.getColCount(); b1++) {
/*     */       String str1 = "column" + b1;
/*     */       xSelection.addColumn(str1);
/*     */       String str2 = (String)this.selectTb.getObject(1, b1);
/*     */       if (str2 != null && str2.length() > 0)
/*     */         xSelection.setAlias(str1, str2); 
/*     */       String str3 = (String)this.selectTb.getObject(2, b1);
/*     */       if (str3 != null && str3.length() > 0)
/*     */         xSelection.setConversion(str1, str3, (String)this.selectTb.getObject(3, b1)); 
/*     */       Boolean bool = (Boolean)this.selectTb.getObject(0, b1);
/*     */       if (bool != null && bool.booleanValue())
/*     */         vector.addElement(new Integer(b1)); 
/*     */     } 
/*     */     int[] arrayOfInt = new int[vector.size()];
/*     */     for (byte b2 = 0; b2 < arrayOfInt.length; b2++)
/*     */       arrayOfInt[b2] = ((Integer)vector.elementAt(b2)).intValue(); 
/*     */     this.xquery.setTableSpec(xSelection);
/*     */     this.xquery.setSelectedCols(arrayOfInt);
/*     */     valueChanged();
/*     */   }
/*     */   
/*     */   protected void populateSelectionTable() {
/*     */     if (this.xquery == null)
/*     */       return; 
/*     */     this.model.removeGridModelListener(this.selectTbListener);
/*     */     XSelection xSelection = this.xquery.getTableSpec();
/*     */     int i = (xSelection != null) ? xSelection.getColumnCount() : 0;
/*     */     this.model.setRowCount(4);
/*     */     this.model.setColCount(i);
/*     */     this.model.setObject(0, -1, Catalog.getString("Select"));
/*     */     this.model.setObject(1, -1, Catalog.getString("Alias"));
/*     */     this.model.setObject(2, -1, Catalog.getString("Type"));
/*     */     this.model.setObject(3, -1, Catalog.getString("Format"));
/*     */     for (byte b = 0; b < i; b++) {
/*     */       String str1 = xSelection.getColumn(b);
/*     */       String str2 = xSelection.getAlias(str1);
/*     */       this.model.setObject(2, b, xSelection.getType(str1));
/*     */       this.model.setObject(3, b, xSelection.getFormat(str1));
/*     */       if (str2 != null)
/*     */         this.model.setObject(1, b, str2); 
/*     */     } 
/*     */     int[] arrayOfInt = this.xquery.getSelectedCols();
/*     */     if (arrayOfInt != null)
/*     */       for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/*     */         if (arrayOfInt[b1] < i)
/*     */           this.model.setObject(0, arrayOfInt[b1], Boolean.TRUE); 
/*     */       }  
/*     */     this.selectTb.setModel(this.model);
/*     */     this.selectTb.setRenderer(0, -99, new BooleanEditor());
/*     */     this.selectTb.setEditor(0, -99, new BooleanEditor());
/*     */     this.selectTb.setAlignment(0, -99, 2);
/*     */     this.selectTb.setEditor(1, -99, new TextFieldEditor());
/*     */     this.selectTb.setEditor(2, -99, new ComboEditor(typestrs));
/*     */     this.selectTb.setEditable(3, -99, true);
/*     */     this.model.addGridModelListener(this.selectTbListener);
/*     */   }
/*     */   
/*     */   private void setEnabled() {
/*     */     this.previewB.setEnabled((this.xquery != null));
/*     */     this.removeB.setEnabled((this.selectTb.getSelectedCol() >= 0));
/*     */     this.delimTF.setEnabled(!this.tabCB.isSelected());
/*     */   }
/*     */   
/*     */   static final String[] typestrs = { "", "integer", "long", "float", "double", "date", "boolean" };
/*     */   JComboBox reqCB;
/*     */   JTextField delimTF;
/*     */   JCheckBox tabCB;
/*     */   JCheckBox headerCB;
/*     */   MultiSheet tables;
/*     */   DefaultGridModel model;
/*     */   Grid selectTb;
/*     */   Grid prevTb;
/*     */   JButton addB;
/*     */   JButton removeB;
/*     */   JButton previewB;
/*     */   JButton importB;
/*     */   TextDataSource xds;
/*     */   TextQuery xquery;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\text\gui\TextQueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */