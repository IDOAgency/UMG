/*    */ package inetsoft.uql.text.gui;
/*    */ 
/*    */ import inetsoft.uql.xml.gui.XMLDataSourceProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextDataSourceProperty
/*    */   extends XMLDataSourceProperty
/*    */ {
/* 42 */   public TextDataSourceProperty() { super(false); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\text\gui\TextDataSourceProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */