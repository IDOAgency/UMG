package inetsoft.uql.text.gui;

import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.text.TextDataSource;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class RequestWizard extends DataSourceWizard {
  public RequestWizard() throws Exception {
    JPanel jPanel1 = getMainPane();
    JPanel jPanel2 = new JPanel();
    jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel2.setLayout(new BorderLayout(2, 2));
    jPanel2.add(new JLabel(Catalog.getString("Request Name") + ":"), "West");
    jPanel2.add(this.requestTF, "Center");
    jPanel1.add(jPanel2, "North");
    this.descTF.setEditable(false);
    this.descTF.setLineWrap(true);
    this.descTF.setWrapStyleWord(true);
    this.descTF.setBackground(jPanel1.getBackground());
    jPanel1.add(this.descTF, "Center");
    this.requestTF.requestFocus();
    jPanel1.setPreferredSize(new Dimension(320, 220));
  }
  
  public void populate() throws Exception {
    TextDataSource textDataSource = (TextDataSource)getDataSource();
    this.requestTF.setText((textDataSource.getRequestCount() == 0) ? "default" : textDataSource.getRequest(0));
  }
  
  public String complete() {
    if (this.requestTF.getText().length() == 0)
      return Catalog.getString("Request name must be specified!"); 
    ((TextDataSource)getDataSource()).addRequest(this.requestTF.getText());
    return null;
  }
  
  JTextField requestTF = new JTextField("default", 20);
  
  JTextArea descTF = new JTextArea(Catalog.getString("Please enter the name of this request. Each request is bound to a pre-defined Text output. More requests can be added after the data source has been created."));
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\text\gui\RequestWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */