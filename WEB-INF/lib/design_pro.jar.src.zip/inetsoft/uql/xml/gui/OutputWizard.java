/*    */ package inetsoft.uql.xml.gui;
/*    */ 
/*    */ import inetsoft.uql.builder.DataSourceWizard;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import inetsoft.uql.xml.XMLDataSource;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OutputWizard
/*    */   extends DataSourceWizard
/*    */ {
/*    */   public OutputWizard() throws Exception {
/* 37 */     JPanel jPanel = getMainPane();
/*    */     
/* 39 */     jPanel.setBorder(new EmptyBorder(2, 2, 5, 2));
/* 40 */     jPanel.setLayout(new BorderLayout(2, 2));
/* 41 */     jPanel.add(new JLabel(Catalog.getString("Request Parameter") + ":"), "North");
/* 42 */     jPanel.add(this.outpane, "Center");
/*    */     
/* 44 */     jPanel.setPreferredSize(new Dimension(500, 250));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void populate() throws Exception {
/* 52 */     XMLDataSource xMLDataSource = (XMLDataSource)getDataSource();
/* 53 */     this.outpane.setDataSource(xMLDataSource);
/* 54 */     this.outpane.setRequest(xMLDataSource.getRequest(0));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public String complete() { return null; }
/*    */ 
/*    */   
/* 64 */   OutputPane outpane = new OutputPane();
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\OutputWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */