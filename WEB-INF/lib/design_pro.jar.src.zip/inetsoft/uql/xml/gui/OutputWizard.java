package inetsoft.uql.xml.gui;

import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.xml.XMLDataSource;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class OutputWizard extends DataSourceWizard {
  public OutputWizard() throws Exception {
    JPanel jPanel = getMainPane();
    jPanel.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel.setLayout(new BorderLayout(2, 2));
    jPanel.add(new JLabel(Catalog.getString("Request Parameter") + ":"), "North");
    jPanel.add(this.outpane, "Center");
    jPanel.setPreferredSize(new Dimension(500, 250));
  }
  
  public void populate() throws Exception {
    XMLDataSource xMLDataSource = (XMLDataSource)getDataSource();
    this.outpane.setDataSource(xMLDataSource);
    this.outpane.setRequest(xMLDataSource.getRequest(0));
  }
  
  public String complete() { return null; }
  
  OutputPane outpane = new OutputPane();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\OutputWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */