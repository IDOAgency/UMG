/*    */ package inetsoft.uql.xml.gui;
/*    */ 
/*    */ import inetsoft.uql.XNode;
/*    */ import inetsoft.uql.builder.DataSourceWizard;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import inetsoft.uql.util.gui.XEditPane;
/*    */ import inetsoft.uql.xml.XMLDataSource;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterWizard
/*    */   extends DataSourceWizard
/*    */ {
/*    */   public ParameterWizard() throws Exception {
/* 38 */     JPanel jPanel = getMainPane();
/*    */     
/* 40 */     jPanel.setBorder(new EmptyBorder(2, 2, 5, 2));
/* 41 */     jPanel.setLayout(new BorderLayout(2, 2));
/* 42 */     jPanel.add(new JLabel(Catalog.getString("Request Parameter") + ":"), "North");
/* 43 */     jPanel.add(this.xedit, "Center");
/*    */     
/* 45 */     jPanel.setPreferredSize(new Dimension(500, 250));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void populate() throws Exception {
/* 53 */     XMLDataSource xMLDataSource = (XMLDataSource)getDataSource();
/* 54 */     String str = xMLDataSource.getRequest(0);
/* 55 */     XNode xNode = xMLDataSource.getRequestParameters(str);
/*    */     
/* 57 */     if (xNode == null) {
/* 58 */       xNode = xMLDataSource.getRequestInputType(str).newInstance();
/*    */     }
/*    */     
/* 61 */     this.xedit.setType(xMLDataSource.getRequestInputType(str));
/* 62 */     this.xedit.setValue(xNode);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String complete() {
/* 69 */     XMLDataSource xMLDataSource = (XMLDataSource)getDataSource();
/* 70 */     xMLDataSource.setRequestParameters(xMLDataSource.getRequest(0), this.xedit.getValue());
/*    */     
/* 72 */     return null;
/*    */   }
/*    */   
/* 75 */   XEditPane xedit = new XEditPane();
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\ParameterWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */