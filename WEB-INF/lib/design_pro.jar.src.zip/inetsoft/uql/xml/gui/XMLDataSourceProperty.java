/*     */ package inetsoft.uql.xml.gui;
/*     */ 
/*     */ import inetsoft.uql.XDataSource;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.builder.DataSourceProperty;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.util.gui.XEditPane;
/*     */ import inetsoft.uql.xml.XMLDataSource;
/*     */ import inetsoft.util.internal.Property2Panel;
/*     */ import inetsoft.widget.VFlowLayout;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import javax.swing.AbstractListModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLDataSourceProperty
/*     */   extends DataSourceProperty
/*     */ {
/*     */   ListSelectionListener itemListener;
/*     */   ValueChangeListener changeListener;
/*     */   ActionListener addListener;
/*     */   ActionListener removeListener;
/*     */   
/*  46 */   public XMLDataSourceProperty() { this(true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLDataSourceProperty(boolean paramBoolean) {
/* 170 */     this.itemListener = new ListSelectionListener(this) {
/*     */         public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
/* 172 */           String str = (String)this.this$0.itemLT.getSelectedValue();
/*     */           
/* 174 */           if (str != null) {
/* 175 */             XNode xNode = this.this$0.xds.getRequestParameters(str);
/*     */             
/* 177 */             if (xNode == null) {
/* 178 */               xNode = this.this$0.xds.getRequestInputType(str).newInstance();
/*     */             }
/*     */             
/* 181 */             this.this$0.xedit.setType(this.this$0.xds.getRequestInputType(str));
/* 182 */             this.this$0.xedit.setValue(xNode);
/*     */             
/* 184 */             this.this$0.outpane.setRequest(str);
/*     */           } 
/*     */           
/* 187 */           this.this$0.setEnabled();
/*     */         }
/*     */         
/*     */         private final XMLDataSourceProperty this$0;
/*     */       };
/* 192 */     this.changeListener = new ValueChangeListener(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     this.addListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 236 */           String str = JOptionPane.showInputDialog(this.this$0, Catalog.getString("Name") + ":", Catalog.getString("Add Request"), -1);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 241 */           if (str != null) {
/* 242 */             this.this$0.xds.addRequest(str);
/* 243 */             this.this$0.itemModel.valueAdded();
/*     */           } 
/*     */         }
/*     */         
/*     */         private final XMLDataSourceProperty this$0;
/*     */       };
/* 249 */     this.removeListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 251 */           int i = this.this$0.itemLT.getSelectedIndex();
/* 252 */           if (i >= 0) {
/* 253 */             this.this$0.xds.removeRequest(i);
/* 254 */             this.this$0.itemModel.valueRemoved(i);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         private final XMLDataSourceProperty this$0;
/*     */       };
/* 261 */     this.xds = null;
/*     */ 
/*     */     
/* 264 */     this.addB = new JButton(Catalog.getString("Add"));
/* 265 */     this.removeB = new JButton(Catalog.getString("Remove"));
/* 266 */     this.urlTF = new JTextField(25);
/* 267 */     this.methodCB = new JComboBox(methodstrs);
/* 268 */     this.itemLT = new JList();
/* 269 */     this.xedit = new XEditPane();
/* 270 */     this.folder = new JTabbedPane();
/* 271 */     this.outpane = new OutputPane();
/*     */     setLayout(new BorderLayout());
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     add(property2Panel, "Center");
/*     */     JPanel jPanel1 = new JPanel();
/*     */     JPanel jPanel2 = new JPanel();
/*     */     jPanel1.setLayout(new BorderLayout(15, 5));
/*     */     JScrollPane jScrollPane = new JScrollPane(this.itemLT);
/*     */     jScrollPane.setPreferredSize(new Dimension(250, 80));
/*     */     jScrollPane.setMinimumSize(new Dimension(250, 80));
/*     */     jPanel1.add(jScrollPane, "Center");
/*     */     jPanel2.setLayout(new VFlowLayout(16));
/*     */     jPanel2.add(this.addB);
/*     */     jPanel2.add(this.removeB);
/*     */     jPanel1.add(jPanel2, "East");
/*     */     property2Panel.add(Catalog.getString("Data Source"), new Object[][] { { Catalog.getString("Base URL") + ":", this.urlTF, this.methodCB } });
/*     */     property2Panel.add(Catalog.getString("Requests"), new Object[][] { { jPanel1 } });
/*     */     this.folder.add(this.xedit, Catalog.getString("Parameters"));
/*     */     if (paramBoolean)
/*     */       this.folder.add(this.outpane, Catalog.getString("Output")); 
/*     */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*     */     gridBagConstraints.fill = 1;
/*     */     property2Panel.add(this.folder, gridBagConstraints);
/*     */     this.itemLT.addListSelectionListener(this.itemListener);
/*     */     this.xedit.addChangeListener(this.changeListener);
/*     */     this.outpane.addChangeListener(this.changeListener);
/*     */     this.urlTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.methodCB.addItemListener(this.changeListener);
/*     */     this.addB.addActionListener(this.addListener);
/*     */     this.removeB.addActionListener(this.removeListener);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public void setDataSource(XDataSource paramXDataSource) {
/*     */     this.xds = (XMLDataSource)paramXDataSource;
/*     */     this.outpane.setDataSource(this.xds);
/*     */     this.urlTF.setText(this.xds.getURL());
/*     */     this.itemLT.setModel(this.itemModel = new ItemModel(this));
/*     */     if (this.xds.getRequestCount() > 0)
/*     */       this.itemLT.setSelectedIndex(0); 
/*     */     setValueChanged(false);
/*     */   }
/*     */   
/*     */   public XDataSource getDataSource() { return this.xds; }
/*     */   
/*     */   private void setEnabled() {
/*     */     this.xedit.setEnabled((this.itemLT.getSelectedIndex() >= 0));
/*     */     this.outpane.setEnabled((this.itemLT.getSelectedIndex() >= 0));
/*     */   }
/*     */   
/*     */   public void verify() {
/*     */     if (this.urlTF.getText().trim().length() == 0)
/*     */       throw new Exception(Catalog.getString("URL can not be empty!")); 
/*     */     if (this.xds.getRequestCount() == 0)
/*     */       throw new Exception(Catalog.getString("Datasource must have at least one request defined!")); 
/*     */   }
/*     */   
/*     */   class ItemModel extends AbstractListModel {
/*     */     private final XMLDataSourceProperty this$0;
/*     */     
/*     */     ItemModel(XMLDataSourceProperty this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public int getSize() { return this.this$0.xds.getRequestCount(); }
/*     */     
/*     */     public Object getElementAt(int param1Int) { return this.this$0.xds.getRequest(param1Int); }
/*     */     
/*     */     public void valueAdded() {
/*     */       fireIntervalAdded(this, getSize() - 1, getSize() - 1);
/*     */       this.this$0.valueChanged();
/*     */     }
/*     */     
/*     */     public void valueRemoved(int param1Int) {
/*     */       fireIntervalRemoved(this, param1Int, param1Int);
/*     */       this.this$0.valueChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   class ValueChangeListener implements ItemListener, DocumentListener, ChangeListener, ActionListener {
/*     */     private final XMLDataSourceProperty this$0;
/*     */     
/*     */     ValueChangeListener(XMLDataSourceProperty this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.valueChanged(); }
/*     */     
/*     */     public void itemStateChanged(ItemEvent param1ItemEvent) {
/*     */       this.this$0.xds.setMethod((String)this.this$0.methodCB.getSelectedItem());
/*     */       this.this$0.valueChanged();
/*     */     }
/*     */     
/*     */     public void stateChanged(ChangeEvent param1ChangeEvent) {
/*     */       if (param1ChangeEvent.getSource() == this.this$0.xedit) {
/*     */         String str = (String)this.this$0.itemLT.getSelectedValue();
/*     */         if (str != null) {
/*     */           this.this$0.xds.setRequestParameters(str, this.this$0.xedit.getValue());
/*     */           this.this$0.xedit.setValueChanged(false);
/*     */         } 
/*     */       } 
/*     */       this.this$0.valueChanged();
/*     */     }
/*     */     
/*     */     public void insertUpdate(DocumentEvent param1DocumentEvent) {
/*     */       this.this$0.xds.setURL(this.this$0.urlTF.getText());
/*     */       this.this$0.valueChanged();
/*     */     }
/*     */     
/*     */     public void removeUpdate(DocumentEvent param1DocumentEvent) {
/*     */       this.this$0.xds.setURL(this.this$0.urlTF.getText());
/*     */       this.this$0.valueChanged();
/*     */     }
/*     */     
/*     */     public void changedUpdate(DocumentEvent param1DocumentEvent) {
/*     */       this.this$0.xds.setURL(this.this$0.urlTF.getText());
/*     */       this.this$0.valueChanged();
/*     */     }
/*     */   }
/*     */   static final String[] methodstrs = { "post", "get" };
/*     */   XMLDataSource xds;
/*     */   ItemModel itemModel;
/*     */   JButton addB;
/*     */   JButton removeB;
/*     */   JTextField urlTF;
/*     */   JComboBox methodCB;
/*     */   JList itemLT;
/*     */   XEditPane xedit;
/*     */   JTabbedPane folder;
/*     */   OutputPane outpane;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\XMLDataSourceProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */