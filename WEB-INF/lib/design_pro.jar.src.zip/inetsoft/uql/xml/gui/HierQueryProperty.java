/*     */ package inetsoft.uql.xml.gui;
/*     */ 
/*     */ import inetsoft.grid.Grid;
/*     */ import inetsoft.grid.MultiSheet;
/*     */ import inetsoft.grid.editor.BooleanEditor;
/*     */ import inetsoft.grid.editor.ComboEditor;
/*     */ import inetsoft.grid.editor.TextFieldEditor;
/*     */ import inetsoft.grid.event.GridModelEvent;
/*     */ import inetsoft.grid.event.GridModelListener;
/*     */ import inetsoft.grid.model.DefaultGridModel;
/*     */ import inetsoft.uql.VariableTable;
/*     */ import inetsoft.uql.XDataService;
/*     */ import inetsoft.uql.XFactory;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.XQuery;
/*     */ import inetsoft.uql.XTableNode;
/*     */ import inetsoft.uql.builder.QueryProperty;
/*     */ import inetsoft.uql.builder.VariableEntry;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.path.XNodePath;
/*     */ import inetsoft.uql.path.XSelection;
/*     */ import inetsoft.uql.schema.UserVariable;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import inetsoft.uql.util.XUtil;
/*     */ import inetsoft.uql.util.gui.XNodePathEditor;
/*     */ import inetsoft.uql.util.gui.XTableNodeModel;
/*     */ import inetsoft.uql.xml.HierQuery;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.ComponentListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HierQueryProperty
/*     */   extends QueryProperty
/*     */ {
/*     */   ItemListener cbListener;
/*     */   ActionListener selectListener;
/*     */   ComponentListener orderListener;
/*     */   GridModelListener selectTbListener;
/*     */   ActionListener prevListener;
/*     */   ActionListener paramListener;
/*     */   
/*     */   public HierQueryProperty() {
/* 269 */     this.cbListener = new ItemListener(this) {
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 271 */           this.this$0.populateSelectionTable();
/*     */           
/* 273 */           if (param1ItemEvent.getSource() == this.this$0.attrCB) {
/* 274 */             this.this$0.xquery.setAttribute("attributes", this.this$0.attrCB.isSelected() + "");
/*     */           }
/* 276 */           else if (param1ItemEvent.getSource() == this.this$0.childCB) {
/* 277 */             this.this$0.xquery.setAttribute("children", this.this$0.childCB.isSelected() + "");
/*     */           }
/* 279 */           else if (param1ItemEvent.getSource() == this.this$0.collapseCB) {
/* 280 */             this.this$0.xquery.setAttribute("collapse", this.this$0.collapseCB.isSelected() + "");
/*     */           }
/* 282 */           else if (param1ItemEvent.getSource() == this.this$0.expandCB) {
/* 283 */             this.this$0.xselect.setExpandSubtree(this.this$0.expandCB.isSelected());
/* 284 */             this.this$0.xquery.setSelection(this.this$0.xselect);
/*     */           }
/* 286 */           else if (param1ItemEvent.getSource() == this.this$0.mapTblCB) {
/*     */             
/* 288 */             if (this.this$0.mapTblCB.isSelected()) {
/* 289 */               this.this$0.selectTbListener.valueChanged(null);
/* 290 */               this.this$0.tables.toFront(0);
/*     */             } else {
/*     */               
/* 293 */               this.this$0.xquery.setSelection(null);
/*     */             } 
/*     */           } 
/*     */           
/* 297 */           this.this$0.valueChanged();
/* 298 */           this.this$0.setEnabled();
/*     */         }
/*     */         
/*     */         private final HierQueryProperty this$0;
/*     */       };
/* 303 */     this.selectListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 305 */           this.this$0.xquery.setNodePath(this.this$0.xpath = this.this$0.patheditor.getNodePath());
/* 306 */           this.this$0.populateSelectionTable();
/* 307 */           this.this$0.setEnabled();
/* 308 */           this.this$0.valueChanged();
/*     */         }
/*     */         
/*     */         private final HierQueryProperty this$0;
/*     */       };
/* 313 */     this.orderListener = new ComponentAdapter(this)
/*     */       {
/* 315 */         public void componentMoved(ComponentEvent param1ComponentEvent) { this.this$0.selectTbListener.valueChanged(null); }
/*     */ 
/*     */         
/*     */         private final HierQueryProperty this$0;
/*     */       };
/* 320 */     this.selectTbListener = new GridModelListener(this) { private final HierQueryProperty this$0;
/*     */         public void valueChanged(GridModelEvent param1GridModelEvent) {
/* 322 */           this.this$0.selectTb.popdownEditor();
/* 323 */           this.this$0.xselect = new XSelection();
/*     */           
/* 325 */           for (byte b = 0; b < this.this$0.selectTb.getColCount(); b++) {
/* 326 */             Boolean bool = (Boolean)this.this$0.selectTb.getObject(0, b);
/* 327 */             if (bool != null && bool.booleanValue()) {
/* 328 */               String str1 = (String)this.this$0.selectTb.getObject(-1, b);
/* 329 */               String str2 = (String)this.this$0.selectTb.getObject(1, b);
/* 330 */               String str3 = (String)this.this$0.selectTb.getObject(2, b);
/* 331 */               String str4 = (String)this.this$0.selectTb.getObject(3, b);
/*     */               
/* 333 */               this.this$0.xselect.addColumn(str1);
/* 334 */               if (str2 != null && str2.length() > 0) {
/* 335 */                 this.this$0.xselect.setAlias(str1, str2);
/*     */               }
/*     */               
/* 338 */               if (str3 != null && str3.length() > 0) {
/* 339 */                 str4 = (str4 != null && str4.length() > 0) ? str4 : null;
/* 340 */                 this.this$0.xselect.setConversion(str1, str3, str4);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 345 */           this.this$0.xselect.setExpandSubtree(this.this$0.expandCB.isSelected());
/* 346 */           this.this$0.xquery.setSelection(this.this$0.mapTblCB.isSelected() ? this.this$0.xselect : null);
/* 347 */           this.this$0.valueChanged();
/*     */         } }
/*     */       ;
/*     */     
/* 351 */     this.prevListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */           try {
/* 354 */             XDataService xDataService = XFactory.getDataService();
/* 355 */             UserVariable[] arrayOfUserVariable = xDataService.getQueryParameters(this.this$0.getSession(), this.this$0.xquery.getName(), true);
/*     */             
/* 357 */             VariableTable variableTable = null;
/*     */             
/* 359 */             if (arrayOfUserVariable != null && arrayOfUserVariable.length > 0) {
/* 360 */               variableTable = VariableEntry.show(arrayOfUserVariable);
/*     */ 
/*     */               
/* 363 */               if (variableTable == null) {
/*     */                 return;
/*     */               }
/*     */             } 
/*     */             
/* 368 */             XNode xNode = xDataService.execute(this.this$0.getSession(), this.this$0.xquery.getName(), variableTable);
/*     */             
/* 370 */             this.this$0.prevTb.setModel(new XTableNodeModel((XTableNode)xNode));
/* 371 */             this.this$0.tables.toFront(1);
/*     */           } catch (Exception exception) {
/* 373 */             exception.printStackTrace();
/* 374 */             JOptionPane.showMessageDialog(this.this$0, exception.toString());
/*     */           } 
/*     */         }
/*     */         
/*     */         private final HierQueryProperty this$0;
/*     */       };
/* 380 */     this.paramListener = new ActionListener(this) { private final HierQueryProperty this$0;
/*     */         
/* 382 */         public void actionPerformed(ActionEvent param1ActionEvent) { ParamsDialog.show(this.this$0); }
/*     */          }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 389 */     this.patheditor = new XNodePathEditor();
/* 390 */     this.mapTblCB = new JCheckBox(Catalog.getString("Map to Table"));
/* 391 */     this.collapseCB = new JCheckBox(Catalog.getString("Collapse Sub-trees"));
/* 392 */     this.expandCB = new JCheckBox(Catalog.getString("Expand Sub-trees"));
/* 393 */     this.attrCB = new JCheckBox(Catalog.getString("Attributes"));
/* 394 */     this.childCB = new JCheckBox(Catalog.getString("Children"));
/* 395 */     this.tables = new MultiSheet();
/* 396 */     this.selectTb = new Grid();
/* 397 */     this.prevTb = new Grid();
/* 398 */     this.previewB = new JButton(Catalog.getString("Preview"));
/* 399 */     this.paramB = new JButton(Catalog.getString("Parameters") + "...");
/*     */     setLayout(new BorderLayout());
/*     */     JPanel jPanel1 = new JPanel();
/*     */     jPanel1.setLayout(new BorderLayout(0, 0));
/*     */     add(jPanel1, "North");
/*     */     Component component = getTopPane();
/*     */     if (component != null)
/*     */       jPanel1.add(component, "West"); 
/*     */     JPanel jPanel2 = new JPanel();
/*     */     jPanel2.setLayout(new FlowLayout(2, 5, 4));
/*     */     jPanel2.add(this.paramB);
/*     */     jPanel1.add(jPanel2, "East");
/*     */     add(this.patheditor, "Center");
/*     */     JPanel jPanel3 = new JPanel();
/*     */     jPanel3.setLayout(new BorderLayout());
/*     */     JPanel jPanel4 = new JPanel();
/*     */     JPanel jPanel5 = new JPanel(), jPanel6 = new JPanel();
/*     */     jPanel5.setLayout(new FlowLayout(0, 10, 0));
/*     */     jPanel6.setLayout(new FlowLayout(0, 10, 0));
/*     */     jPanel4.setLayout(new BorderLayout(0, 0));
/*     */     jPanel5.add(this.mapTblCB);
/*     */     jPanel6.add(this.attrCB);
/*     */     jPanel6.add(this.childCB);
/*     */     jPanel6.add(this.collapseCB);
/*     */     jPanel6.add(this.expandCB);
/*     */     jPanel4.add(jPanel5, "North");
/*     */     jPanel4.add(jPanel6, "South");
/*     */     jPanel3.add(jPanel4, "North");
/*     */     this.tables.add(this.selectTb, Catalog.getString("Selection"));
/*     */     this.tables.add(this.prevTb, Catalog.getString("Preview"));
/*     */     this.tables.setPreferredSize(new Dimension(400, 150));
/*     */     jPanel3.add(this.tables, "Center");
/*     */     add(jPanel3, "South");
/*     */     this.patheditor.addActionListener(this.selectListener);
/*     */     this.mapTblCB.addItemListener(this.cbListener);
/*     */     this.collapseCB.addItemListener(this.cbListener);
/*     */     this.expandCB.addItemListener(this.cbListener);
/*     */     this.attrCB.addItemListener(this.cbListener);
/*     */     this.childCB.addItemListener(this.cbListener);
/*     */     this.previewB.addActionListener(this.prevListener);
/*     */     this.paramB.addActionListener(this.paramListener);
/*     */     this.selectTb.addComponentListener(this.orderListener);
/*     */     this.selectTb.setMinColWidth(-99, 50);
/*     */     this.selectTb.setRowSelectable(false);
/*     */     this.prevTb.setGap(-99, -99, new Insets(0, 4, 0, 4));
/*     */     this.prevTb.setRowSelectable(false);
/*     */     this.prevTb.setMinColWidth(-99, 50);
/*     */     this.tables.toFront(0);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   protected Component getTopPane() { return null; }
/*     */   
/*     */   public void setQuery(XQuery paramXQuery) {
/*     */     this.xquery = (HierQuery)paramXQuery;
/*     */     this.selectTb.getModel().removeGridModelListener(this.selectTbListener);
/*     */     this.mapTblCB.removeItemListener(this.cbListener);
/*     */     this.attrCB.removeItemListener(this.cbListener);
/*     */     this.childCB.removeItemListener(this.cbListener);
/*     */     this.collapseCB.removeItemListener(this.cbListener);
/*     */     this.expandCB.removeItemListener(this.cbListener);
/*     */     this.patheditor.setTree(this.xtype = this.xquery.getSourceType(), this.xpath = this.xquery.getNodePath());
/*     */     this.xselect = this.xquery.getSelection();
/*     */     this.mapTblCB.setSelected((this.xselect != null));
/*     */     String str = this.xquery.getAttribute("attributes");
/*     */     this.attrCB.setSelected((str != null && str.equals("true")));
/*     */     str = this.xquery.getAttribute("children");
/*     */     this.childCB.setSelected((str == null || str.equals("true")));
/*     */     str = this.xquery.getAttribute("collapse");
/*     */     this.collapseCB.setSelected((str != null && str.equals("true")));
/*     */     this.expandCB.setSelected((this.xselect != null && this.xselect.isExpandSubtree()));
/*     */     populateSelectionTable();
/*     */     this.mapTblCB.addItemListener(this.cbListener);
/*     */     this.attrCB.addItemListener(this.cbListener);
/*     */     this.childCB.addItemListener(this.cbListener);
/*     */     this.collapseCB.addItemListener(this.cbListener);
/*     */     this.expandCB.addItemListener(this.cbListener);
/*     */     setValueChanged(false);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public XQuery getQuery() {
/*     */     this.xquery.setNodePath(this.patheditor.getNodePath());
/*     */     return this.xquery;
/*     */   }
/*     */   
/*     */   public Component getCommandPane() { return this.previewB; }
/*     */   
/*     */   public void verify() {
/*     */     if (this.xquery.getNodePath() == null)
/*     */       throw new Exception(Catalog.getString("Output node path is not selected!")); 
/*     */   }
/*     */   
/*     */   protected void populateSelectionTable() {
/*     */     if (this.xtype == null || this.xpath == null)
/*     */       return; 
/*     */     XTypeNode xTypeNode = (XTypeNode)this.xtype.getNode(this.xpath.getPath(null));
/*     */     Vector vector = XUtil.getAllColumnPaths(xTypeNode, this.attrCB.isSelected(), this.childCB.isSelected(), this.collapseCB.isSelected());
/*     */     if (this.xselect != null) {
/*     */       Vector vector1 = new Vector();
/*     */       vector1.setSize(vector.size());
/*     */       int i = vector.size() - 1;
/*     */       for (int j = i; j >= 0; j--) {
/*     */         String str = (String)vector.elementAt(j);
/*     */         int k = this.xselect.indexOf(str);
/*     */         if (k < 0)
/*     */           k = i--; 
/*     */         vector1.setElementAt(str, k);
/*     */       } 
/*     */       vector = vector1;
/*     */     } 
/*     */     DefaultGridModel defaultGridModel = new DefaultGridModel(4, vector.size());
/*     */     defaultGridModel.setHeaderRowCount(1);
/*     */     defaultGridModel.setHeaderColCount(1);
/*     */     defaultGridModel.setObject(0, -1, Catalog.getString("Select"));
/*     */     defaultGridModel.setObject(1, -1, Catalog.getString("Alias"));
/*     */     defaultGridModel.setObject(2, -1, Catalog.getString("Type"));
/*     */     defaultGridModel.setObject(3, -1, Catalog.getString("Format"));
/*     */     for (byte b = 0; b < vector.size(); b++) {
/*     */       String str1 = (String)vector.elementAt(b);
/*     */       String str2 = (this.xselect == null) ? null : this.xselect.getAlias(str1);
/*     */       defaultGridModel.setObject(-1, b, str1);
/*     */       defaultGridModel.setObject(0, b, new Boolean((this.xselect == null || this.xselect.contains(str1))));
/*     */       if (this.xselect != null) {
/*     */         defaultGridModel.setObject(2, b, this.xselect.getType(str1));
/*     */         defaultGridModel.setObject(3, b, this.xselect.getFormat(str1));
/*     */       } 
/*     */       if (str2 != null)
/*     */         defaultGridModel.setObject(1, b, str2); 
/*     */     } 
/*     */     this.selectTb.setModel(defaultGridModel);
/*     */     this.selectTb.setReorderable(2);
/*     */     this.selectTb.setRenderer(0, -99, new BooleanEditor());
/*     */     this.selectTb.setEditor(0, -99, new BooleanEditor());
/*     */     this.selectTb.setAlignment(0, -99, 2);
/*     */     this.selectTb.setEditor(1, -99, new TextFieldEditor());
/*     */     this.selectTb.setEditor(2, -99, new ComboEditor(typestrs));
/*     */     this.selectTb.setEditable(3, -99, true);
/*     */     defaultGridModel.addGridModelListener(this.selectTbListener);
/*     */   }
/*     */   
/*     */   private void setEnabled() {
/*     */     this.attrCB.setEnabled(this.mapTblCB.isSelected());
/*     */     this.childCB.setEnabled(this.mapTblCB.isSelected());
/*     */     this.collapseCB.setEnabled((this.mapTblCB.isSelected() && this.childCB.isSelected()));
/*     */     this.expandCB.setEnabled(this.mapTblCB.isSelected());
/*     */     this.selectTb.setEnabled(this.mapTblCB.isSelected());
/*     */     this.previewB.setEnabled(this.mapTblCB.isSelected());
/*     */   }
/*     */   
/*     */   static final String[] typestrs = { "", "integer", "long", "float", "double", "date", "boolean" };
/*     */   protected XNodePathEditor patheditor;
/*     */   JCheckBox mapTblCB;
/*     */   JCheckBox collapseCB;
/*     */   JCheckBox expandCB;
/*     */   JCheckBox attrCB;
/*     */   JCheckBox childCB;
/*     */   MultiSheet tables;
/*     */   Grid selectTb;
/*     */   Grid prevTb;
/*     */   JButton previewB;
/*     */   JButton paramB;
/*     */   protected HierQuery xquery;
/*     */   protected XSelection xselect;
/*     */   protected XTypeNode xtype;
/*     */   protected XNodePath xpath;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\HierQueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */