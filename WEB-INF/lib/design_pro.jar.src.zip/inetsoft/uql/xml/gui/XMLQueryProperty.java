package inetsoft.uql.xml.gui;

import inetsoft.uql.XQuery;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.xml.HierDataSource;
import inetsoft.uql.xml.HierQuery;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JPanel;

public class XMLQueryProperty extends HierQueryProperty {
  ItemListener reqListener;
  
  JComboBox reqCB;
  
  HierDataSource xds;
  
  HierQuery xquery;
  
  public XMLQueryProperty() {
    this.reqListener = new ItemListener(this) {
        private final XMLQueryProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          this.this$0.xquery.setRequest((String)this.this$0.reqCB.getSelectedItem());
          this.this$0.patheditor.setTree(this.this$0.xtype = this.this$0.xds.getRequestOutputType(this.this$0.xquery.getRequest()), this.this$0.xpath);
          this.this$0.valueChanged();
        }
      };
    this.reqCB.addItemListener(this.reqListener);
  }
  
  public void setQuery(XQuery paramXQuery) {
    this.xquery = (HierQuery)paramXQuery;
    this.xds = (HierDataSource)this.xquery.getDataSource();
    DefaultComboBoxModel defaultComboBoxModel = new DefaultComboBoxModel();
    for (byte b = 0; b < this.xds.getRequestCount(); b++)
      defaultComboBoxModel.addElement(this.xds.getRequest(b)); 
    this.reqCB.setModel(defaultComboBoxModel);
    this.reqCB.setSelectedItem(this.xquery.getRequest());
    super.setQuery(paramXQuery);
  }
  
  public Component getTopPane() {
    this.reqCB = new JComboBox();
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(0, 5, 4));
    jPanel.add(this.reqCB);
    this.reqCB.setFont(new Font("Dialog", 0, 10));
    return jPanel;
  }
  
  public void verify() {
    super.verify();
    if (this.xquery.getRequest() == null)
      throw new Exception(Catalog.getString("Must select a datasource request for the query!")); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\XMLQueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */