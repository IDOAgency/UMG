/*     */ package inetsoft.uql.xml.gui;
/*     */ 
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import inetsoft.uql.util.dtd.DTDParser;
/*     */ import inetsoft.uql.util.gui.XTypeTree;
/*     */ import inetsoft.uql.xml.XMLDataSource;
/*     */ import inetsoft.widget.VFlowLayout;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Vector;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.TitledBorder;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.TreeSelectionEvent;
/*     */ import javax.swing.event.TreeSelectionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OutputPane
/*     */   extends JPanel
/*     */ {
/*     */   ActionListener importListener;
/*     */   private Vector listeners;
/*     */   ItemListener cbListener;
/*     */   TreeSelectionListener xtreeListener;
/*     */   ActionListener typeListener;
/*     */   
/*     */   public OutputPane() {
/*  89 */     this.importListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*  91 */           InputStream inputStream = null;
/*     */           
/*  93 */           if (this.this$0.urlRB.isSelected()) {
/*  94 */             String str = JOptionPane.showInputDialog(this.this$0, OutputPane.msg1);
/*  95 */             if (str != null) {
/*     */               try {
/*  97 */                 URL uRL = new URL(str);
/*  98 */                 inputStream = uRL.openStream();
/*     */               } catch (Exception exception) {
/* 100 */                 exception.printStackTrace();
/* 101 */                 JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
/*     */ 
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/*     */             }
/*     */           } else {
/* 109 */             JFileChooser jFileChooser = new JFileChooser();
/* 110 */             jFileChooser.setCurrentDirectory(new File("."));
/* 111 */             int i = jFileChooser.showOpenDialog(this.this$0);
/* 112 */             if (i == 0) {
/*     */               try {
/* 114 */                 inputStream = new FileInputStream(jFileChooser.getSelectedFile());
/*     */               } catch (Exception exception) {
/* 116 */                 exception.printStackTrace();
/* 117 */                 JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
/*     */ 
/*     */                 
/*     */                 return;
/*     */               } 
/*     */             }
/*     */           } 
/*     */           
/* 125 */           if (inputStream != null) {
/*     */             try {
/* 127 */               DTDParser dTDParser = new DTDParser(inputStream);
/* 128 */               dTDParser.parse();
/* 129 */               this.this$0.xtree.setType(dTDParser.getRoot());
/*     */               
/* 131 */               if (this.this$0.item != null) {
/* 132 */                 this.this$0.xds.setRequestOutputType(this.this$0.item, dTDParser.getRoot());
/*     */               }
/*     */               
/* 135 */               this.this$0.valueChanged();
/*     */             } catch (Exception exception) {
/* 137 */               exception.printStackTrace();
/* 138 */               JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
/*     */             } 
/*     */           }
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final OutputPane this$0;
/*     */       };
/* 163 */     this.listeners = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     this.cbListener = new ItemListener(this)
/*     */       {
/* 202 */         public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.fmtTF.setText(""); }
/*     */         
/*     */         private final OutputPane this$0;
/*     */       };
/* 206 */     this.xtreeListener = new TreeSelectionListener(this) { private final OutputPane this$0;
/*     */         public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
/* 208 */           XTypeNode xTypeNode = this.this$0.xtree.getSelectedNode();
/* 209 */           if (xTypeNode != null) {
/* 210 */             this.this$0.typeCB.setSelectedItem(xTypeNode.getType());
/* 211 */             this.this$0.fmtTF.setText((xTypeNode.getFormat() == null) ? "" : xTypeNode.getFormat());
/*     */           } 
/*     */           
/* 214 */           this.this$0.setEnabled();
/*     */         } }
/*     */       ;
/*     */     
/* 218 */     this.typeListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 220 */           XTypeNode xTypeNode = this.this$0.xtree.getSelectedNode();
/* 221 */           String str = (String)this.this$0.typeCB.getSelectedItem();
/*     */ 
/*     */           
/* 224 */           if (xTypeNode != null && xTypeNode.getChildCount() == 0) {
/* 225 */             if (!xTypeNode.getType().equals(str) && xTypeNode.getParent() != null) {
/* 226 */               XNode xNode = xTypeNode.getParent();
/* 227 */               int i = xNode.getChildIndex(xTypeNode);
/* 228 */               xNode.setChild(i, xTypeNode = xTypeNode.clone(str));
/*     */               
/* 230 */               this.this$0.xtree.treeChanged(xNode);
/* 231 */               this.this$0.valueChanged();
/*     */             } 
/*     */             
/* 234 */             if (this.this$0.fmtTF.getText().trim().length() > 0) {
/* 235 */               xTypeNode.setFormat(this.this$0.fmtTF.getText());
/* 236 */               this.this$0.valueChanged();
/*     */             } 
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final OutputPane this$0;
/*     */       };
/* 252 */     this.xtree = new XTypeTree();
/* 253 */     this.typeCB = new JComboBox(xtypestrs);
/* 254 */     this.fmtTF = new JTextField(10);
/* 255 */     this.typeB = new JButton(Catalog.getString("Set Type"));
/* 256 */     this.importB = new JButton(Catalog.getString("Import DTD"));
/* 257 */     this.urlRB = new JRadioButton(Catalog.getString("URL"));
/* 258 */     this.fileRB = new JRadioButton(Catalog.getString("Local File"));
/*     */     setLayout(new BorderLayout(10, 10));
/*     */     add(new JScrollPane(this.xtree), "Center");
/*     */     JPanel jPanel1 = new JPanel();
/*     */     jPanel1.setLayout(new VFlowLayout(0));
/*     */     add(jPanel1, "East");
/*     */     ButtonGroup buttonGroup = new ButtonGroup();
/*     */     buttonGroup.add(this.urlRB);
/*     */     buttonGroup.add(this.fileRB);
/*     */     JPanel jPanel2 = new JPanel();
/*     */     jPanel2.add(this.urlRB);
/*     */     jPanel2.add(this.fileRB);
/*     */     jPanel1.add(jPanel2);
/*     */     jPanel1.add(this.importB);
/*     */     jPanel1.add(new JLabel(""));
/*     */     JPanel jPanel3 = new JPanel();
/*     */     jPanel3.setLayout(new VFlowLayout(0));
/*     */     jPanel3.setBorder(new TitledBorder(Catalog.getString("Type")));
/*     */     jPanel2 = new JPanel();
/*     */     jPanel2.add(this.typeCB);
/*     */     jPanel2.add(this.typeB);
/*     */     jPanel3.add(jPanel2);
/*     */     jPanel2 = new JPanel();
/*     */     jPanel2.add(new JLabel(Catalog.getString("Format:")));
/*     */     jPanel2.add(this.fmtTF);
/*     */     jPanel3.add(jPanel2);
/*     */     jPanel1.add(jPanel3);
/*     */     this.fileRB.setSelected(true);
/*     */     this.importB.addActionListener(this.importListener);
/*     */     this.typeCB.addItemListener(this.cbListener);
/*     */     this.typeCB.addActionListener(this.typeListener);
/*     */     this.fmtTF.addActionListener(this.typeListener);
/*     */     this.typeB.addActionListener(this.typeListener);
/*     */     this.xtree.addTreeSelectionListener(this.xtreeListener);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public void setDataSource(XMLDataSource paramXMLDataSource) { this.xds = paramXMLDataSource; }
/*     */   
/*     */   public void setRequest(String paramString) {
/*     */     this.item = paramString;
/*     */     XTypeNode xTypeNode = this.xds.getRequestOutputType(paramString);
/*     */     this.xtree.setEnabled(true);
/*     */     this.xtree.setType(xTypeNode);
/*     */   }
/*     */   
/*     */   public void addChangeListener(ChangeListener paramChangeListener) { this.listeners.addElement(paramChangeListener); }
/*     */   
/*     */   public void removeChangeListener(ChangeListener paramChangeListener) { this.listeners.removeElement(paramChangeListener); }
/*     */   
/*     */   public void valueChanged() {
/*     */     ChangeEvent changeEvent = new ChangeEvent(this);
/*     */     for (byte b = 0; b < this.listeners.size(); b++)
/*     */       ((ChangeListener)this.listeners.elementAt(b)).stateChanged(changeEvent); 
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/*     */     this.xtree.setEnabled(paramBoolean);
/*     */     this.importB.setEnabled(paramBoolean);
/*     */     this.urlRB.setEnabled(paramBoolean);
/*     */     this.fileRB.setEnabled(paramBoolean);
/*     */   }
/*     */   
/*     */   public void setEnabled() {
/*     */     XTypeNode xTypeNode = this.xtree.getSelectedNode();
/*     */     boolean bool = (xTypeNode != null && xTypeNode.isPrimitive());
/*     */     this.typeB.setEnabled(bool);
/*     */     this.typeCB.setEnabled(bool);
/*     */     this.fmtTF.setEnabled(bool);
/*     */   }
/*     */   
/*     */   static final String[] xtypestrs = { 
/*     */       "string", "boolean", "integer", "double", "timeInstant", "date", "time", "float", "char", "byte", 
/*     */       "short", "long" };
/*     */   static final String msg1 = Catalog.getString("URL") + ":";
/*     */   XMLDataSource xds;
/*     */   String item;
/*     */   XTypeTree xtree;
/*     */   JComboBox typeCB;
/*     */   JTextField fmtTF;
/*     */   JButton typeB;
/*     */   JButton importB;
/*     */   JRadioButton urlRB;
/*     */   JRadioButton fileRB;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\OutputPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */