package inetsoft.uql.xml.gui;

import inetsoft.uql.XNode;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.schema.XTypeNode;
import inetsoft.uql.util.dtd.DTDParser;
import inetsoft.uql.util.gui.XTypeTree;
import inetsoft.uql.xml.XMLDataSource;
import inetsoft.widget.VFlowLayout;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.Vector;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

class OutputPane extends JPanel {
  ActionListener importListener;
  
  private Vector listeners;
  
  ItemListener cbListener;
  
  TreeSelectionListener xtreeListener;
  
  ActionListener typeListener;
  
  public OutputPane() {
    this.importListener = new ActionListener(this) {
        private final OutputPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          InputStream inputStream = null;
          if (this.this$0.urlRB.isSelected()) {
            String str = JOptionPane.showInputDialog(this.this$0, OutputPane.msg1);
            if (str != null)
              try {
                URL uRL = new URL(str);
                inputStream = uRL.openStream();
              } catch (Exception exception) {
                exception.printStackTrace();
                JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
                return;
              }  
          } else {
            JFileChooser jFileChooser = new JFileChooser();
            jFileChooser.setCurrentDirectory(new File("."));
            int i = jFileChooser.showOpenDialog(this.this$0);
            if (i == 0)
              try {
                inputStream = new FileInputStream(jFileChooser.getSelectedFile());
              } catch (Exception exception) {
                exception.printStackTrace();
                JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
                return;
              }  
          } 
          if (inputStream != null)
            try {
              DTDParser dTDParser = new DTDParser(inputStream);
              dTDParser.parse();
              this.this$0.xtree.setType(dTDParser.getRoot());
              if (this.this$0.item != null)
                this.this$0.xds.setRequestOutputType(this.this$0.item, dTDParser.getRoot()); 
              this.this$0.valueChanged();
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
            }  
        }
      };
    this.listeners = new Vector();
    this.cbListener = new ItemListener(this) {
        private final OutputPane this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.fmtTF.setText(""); }
      };
    this.xtreeListener = new TreeSelectionListener(this) {
        private final OutputPane this$0;
        
        public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
          XTypeNode xTypeNode = this.this$0.xtree.getSelectedNode();
          if (xTypeNode != null) {
            this.this$0.typeCB.setSelectedItem(xTypeNode.getType());
            this.this$0.fmtTF.setText((xTypeNode.getFormat() == null) ? "" : xTypeNode.getFormat());
          } 
          this.this$0.setEnabled();
        }
      };
    this.typeListener = new ActionListener(this) {
        private final OutputPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          XTypeNode xTypeNode = this.this$0.xtree.getSelectedNode();
          String str = (String)this.this$0.typeCB.getSelectedItem();
          if (xTypeNode != null && xTypeNode.getChildCount() == 0) {
            if (!xTypeNode.getType().equals(str) && xTypeNode.getParent() != null) {
              XNode xNode = xTypeNode.getParent();
              int i = xNode.getChildIndex(xTypeNode);
              xNode.setChild(i, xTypeNode = xTypeNode.clone(str));
              this.this$0.xtree.treeChanged(xNode);
              this.this$0.valueChanged();
            } 
            if (this.this$0.fmtTF.getText().trim().length() > 0) {
              xTypeNode.setFormat(this.this$0.fmtTF.getText());
              this.this$0.valueChanged();
            } 
          } 
        }
      };
    this.xtree = new XTypeTree();
    this.typeCB = new JComboBox(xtypestrs);
    this.fmtTF = new JTextField(10);
    this.typeB = new JButton(Catalog.getString("Set Type"));
    this.importB = new JButton(Catalog.getString("Import DTD"));
    this.urlRB = new JRadioButton(Catalog.getString("URL"));
    this.fileRB = new JRadioButton(Catalog.getString("Local File"));
    setLayout(new BorderLayout(10, 10));
    add(new JScrollPane(this.xtree), "Center");
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new VFlowLayout(0));
    add(jPanel1, "East");
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(this.urlRB);
    buttonGroup.add(this.fileRB);
    JPanel jPanel2 = new JPanel();
    jPanel2.add(this.urlRB);
    jPanel2.add(this.fileRB);
    jPanel1.add(jPanel2);
    jPanel1.add(this.importB);
    jPanel1.add(new JLabel(""));
    JPanel jPanel3 = new JPanel();
    jPanel3.setLayout(new VFlowLayout(0));
    jPanel3.setBorder(new TitledBorder(Catalog.getString("Type")));
    jPanel2 = new JPanel();
    jPanel2.add(this.typeCB);
    jPanel2.add(this.typeB);
    jPanel3.add(jPanel2);
    jPanel2 = new JPanel();
    jPanel2.add(new JLabel(Catalog.getString("Format:")));
    jPanel2.add(this.fmtTF);
    jPanel3.add(jPanel2);
    jPanel1.add(jPanel3);
    this.fileRB.setSelected(true);
    this.importB.addActionListener(this.importListener);
    this.typeCB.addItemListener(this.cbListener);
    this.typeCB.addActionListener(this.typeListener);
    this.fmtTF.addActionListener(this.typeListener);
    this.typeB.addActionListener(this.typeListener);
    this.xtree.addTreeSelectionListener(this.xtreeListener);
    setEnabled();
  }
  
  public void setDataSource(XMLDataSource paramXMLDataSource) { this.xds = paramXMLDataSource; }
  
  public void setRequest(String paramString) {
    this.item = paramString;
    XTypeNode xTypeNode = this.xds.getRequestOutputType(paramString);
    this.xtree.setEnabled(true);
    this.xtree.setType(xTypeNode);
  }
  
  public void addChangeListener(ChangeListener paramChangeListener) { this.listeners.addElement(paramChangeListener); }
  
  public void removeChangeListener(ChangeListener paramChangeListener) { this.listeners.removeElement(paramChangeListener); }
  
  public void valueChanged() {
    ChangeEvent changeEvent = new ChangeEvent(this);
    for (byte b = 0; b < this.listeners.size(); b++)
      ((ChangeListener)this.listeners.elementAt(b)).stateChanged(changeEvent); 
  }
  
  public void setEnabled(boolean paramBoolean) {
    this.xtree.setEnabled(paramBoolean);
    this.importB.setEnabled(paramBoolean);
    this.urlRB.setEnabled(paramBoolean);
    this.fileRB.setEnabled(paramBoolean);
  }
  
  public void setEnabled() {
    XTypeNode xTypeNode = this.xtree.getSelectedNode();
    boolean bool = (xTypeNode != null && xTypeNode.isPrimitive());
    this.typeB.setEnabled(bool);
    this.typeCB.setEnabled(bool);
    this.fmtTF.setEnabled(bool);
  }
  
  static final String[] xtypestrs = { 
      "string", "boolean", "integer", "double", "timeInstant", "date", "time", "float", "char", "byte", 
      "short", "long" };
  
  static final String msg1 = Catalog.getString("URL") + ":";
  
  XMLDataSource xds;
  
  String item;
  
  XTypeTree xtree;
  
  JComboBox typeCB;
  
  JTextField fmtTF;
  
  JButton typeB;
  
  JButton importB;
  
  JRadioButton urlRB;
  
  JRadioButton fileRB;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\OutputPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */