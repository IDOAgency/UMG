package inetsoft.uql.xml.gui;

import inetsoft.uql.XQuery;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.xml.DerivedQuery;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DerivedQueryProperty extends HierQueryProperty {
  DerivedQuery xquery;
  
  JLabel baseLB;
  
  public void setQuery(XQuery paramXQuery) {
    this.xquery = (DerivedQuery)paramXQuery;
    super.setQuery(paramXQuery);
    this.baseLB.setText(this.xquery.getBaseQuery().getName());
  }
  
  public Component getTopPane() {
    JPanel jPanel = new JPanel();
    this.baseLB = new JLabel("");
    jPanel.add(new JLabel(Catalog.getString("Base Query") + ": "));
    jPanel.add(this.baseLB);
    return jPanel;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\DerivedQueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */