/*    */ package inetsoft.uql.xml.gui;
/*    */ 
/*    */ import inetsoft.uql.XQuery;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import inetsoft.uql.xml.DerivedQuery;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DerivedQueryProperty
/*    */   extends HierQueryProperty
/*    */ {
/*    */   DerivedQuery xquery;
/*    */   JLabel baseLB;
/*    */   
/*    */   public void setQuery(XQuery paramXQuery) {
/* 52 */     this.xquery = (DerivedQuery)paramXQuery;
/* 53 */     super.setQuery(paramXQuery);
/* 54 */     this.baseLB.setText(this.xquery.getBaseQuery().getName());
/*    */   }
/*    */   
/*    */   public Component getTopPane() {
/* 58 */     JPanel jPanel = new JPanel();
/* 59 */     this.baseLB = new JLabel("");
/* 60 */     jPanel.add(new JLabel(Catalog.getString("Base Query") + ": "));
/* 61 */     jPanel.add(this.baseLB);
/* 62 */     return jPanel;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\DerivedQueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */