/*    */ package inetsoft.uql.xml.gui;
/*    */ 
/*    */ import inetsoft.uql.builder.DataSourceWizard;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import inetsoft.uql.xml.XMLDataSource;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestWizard
/*    */   extends DataSourceWizard
/*    */ {
/*    */   public RequestWizard() throws Exception {
/* 37 */     JPanel jPanel1 = getMainPane();
/*    */     
/* 39 */     JPanel jPanel2 = new JPanel();
/* 40 */     jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
/* 41 */     jPanel2.setLayout(new BorderLayout(2, 2));
/* 42 */     jPanel2.add(new JLabel(Catalog.getString("Request Name") + ":"), "West");
/* 43 */     jPanel2.add(this.requestTF, "Center");
/*    */     
/* 45 */     jPanel1.add(jPanel2, "North");
/* 46 */     this.descTF.setEditable(false);
/* 47 */     this.descTF.setLineWrap(true);
/* 48 */     this.descTF.setWrapStyleWord(true);
/* 49 */     this.descTF.setBackground(jPanel1.getBackground());
/* 50 */     jPanel1.add(this.descTF, "Center");
/*    */     
/* 52 */     this.requestTF.requestFocus();
/* 53 */     jPanel1.setPreferredSize(new Dimension(320, 220));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void populate() throws Exception {
/* 61 */     XMLDataSource xMLDataSource = (XMLDataSource)getDataSource();
/* 62 */     this.requestTF.setText((xMLDataSource.getRequestCount() == 0) ? "default" : xMLDataSource.getRequest(0));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String complete() {
/* 70 */     if (this.requestTF.getText().length() == 0) {
/* 71 */       return Catalog.getString("Request name must be specified!");
/*    */     }
/*    */     
/* 74 */     ((XMLDataSource)getDataSource()).addRequest(this.requestTF.getText());
/*    */     
/* 76 */     return null;
/*    */   }
/*    */   
/* 79 */   JTextField requestTF = new JTextField("default", 20);
/* 80 */   JTextArea descTF = new JTextArea(Catalog.getString("Please enter the name of this request. Each request is bound to a pre-defined XML output type (DTD). More requests can be added after the data source has been created."));
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\RequestWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */