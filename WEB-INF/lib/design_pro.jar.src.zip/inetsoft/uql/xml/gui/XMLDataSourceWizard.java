package inetsoft.uql.xml.gui;

import inetsoft.uql.XDataSource;
import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.xml.XMLDataSource;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class XMLDataSourceWizard extends DataSourceWizard {
  public XMLDataSourceWizard() throws Exception {
    super(dialogs);
    this.xds = new XMLDataSource();
    this.urlTF = new JTextField(this.xds.getURL(), 20);
    this.methodCB = new JComboBox(methodstrs);
    this.descTF = new JTextArea(Catalog.getString("Please enter the URL of the XML server."));
    JPanel jPanel1 = getMainPane();
    JPanel jPanel2 = new JPanel();
    jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel2.setLayout(new BorderLayout(2, 2));
    jPanel2.add(new JLabel(Catalog.getString("XML Server URL") + ":"), "West");
    jPanel2.add(this.urlTF, "Center");
    jPanel2.add(this.methodCB, "East");
    jPanel1.add(jPanel2, "North");
    this.descTF.setEditable(false);
    this.descTF.setLineWrap(true);
    this.descTF.setWrapStyleWord(true);
    this.descTF.setBackground(jPanel1.getBackground());
    jPanel1.add(this.descTF, "Center");
    this.urlTF.requestFocus();
    jPanel1.setPreferredSize(new Dimension(320, 220));
  }
  
  public XDataSource getDataSource() { return this.xds; }
  
  public void setDataSource(XDataSource paramXDataSource) { this.xds = (XMLDataSource)paramXDataSource; }
  
  public void populate() throws Exception {
    this.urlTF.setText(this.xds.getURL());
    this.methodCB.setSelectedItem(this.xds.getMethod());
  }
  
  public String complete() {
    if (this.urlTF.getText().length() == 0)
      return Catalog.getString("XML Driver must be specified!"); 
    this.xds.setURL(this.urlTF.getText());
    this.xds.setMethod((String)this.methodCB.getSelectedItem());
    return null;
  }
  
  static final String[] dialogs = { "inetsoft.uql.xml.gui.RequestWizard", "inetsoft.uql.xml.gui.ParameterWizard", "inetsoft.uql.xml.gui.OutputWizard" };
  
  static final String[] methodstrs = { "post", "get" };
  
  XMLDataSource xds;
  
  JTextField urlTF;
  
  JComboBox methodCB;
  
  JTextArea descTF;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\XMLDataSourceWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */