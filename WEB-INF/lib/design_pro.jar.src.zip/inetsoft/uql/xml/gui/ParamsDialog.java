/*     */ package inetsoft.uql.xml.gui;
/*     */ 
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import inetsoft.uql.util.gui.XEditPane;
/*     */ import inetsoft.uql.xml.HierDataSource;
/*     */ import inetsoft.uql.xml.HierQuery;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ParamsDialog
/*     */   extends JDialog
/*     */ {
/*     */   ActionListener okListener;
/*     */   ActionListener cancelListener;
/*     */   ItemListener dsparamListener;
/*     */   XEditPane editor;
/*     */   JCheckBox dsparamCB;
/*     */   JButton okB;
/*     */   JButton cancelB;
/*     */   HierQueryProperty pane;
/*     */   HierQuery xquery;
/*     */   
/*     */   public static void show(HierQueryProperty paramHierQueryProperty) {
/*  39 */     ParamsDialog paramsDialog = new ParamsDialog(paramHierQueryProperty);
/*  40 */     paramsDialog.pack();
/*  41 */     paramsDialog.setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParamsDialog(HierQueryProperty paramHierQueryProperty) {
/*  82 */     this.okListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*  84 */           this.this$0.xquery.setCustomParameters(!this.this$0.dsparamCB.isSelected() ? this.this$0.editor.getValue() : null);
/*     */           
/*  86 */           this.this$0.pane.valueChanged();
/*  87 */           this.this$0.dispose();
/*     */         }
/*     */         private final ParamsDialog this$0;
/*     */       };
/*  91 */     this.cancelListener = new ActionListener(this)
/*     */       {
/*  93 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */         
/*     */         private final ParamsDialog this$0;
/*     */       };
/*  97 */     this.dsparamListener = new ItemListener(this) { private final ParamsDialog this$0;
/*     */         
/*  99 */         public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setEnabled(); }
/*     */          }
/*     */       ;
/*     */     
/* 103 */     this.editor = new XEditPane();
/* 104 */     this.dsparamCB = new JCheckBox(Catalog.getString("Use Datasource Defined Parameters"));
/*     */     
/* 106 */     this.okB = new JButton(Catalog.getString("OK"));
/* 107 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*     */     this.pane = paramHierQueryProperty;
/*     */     this.xquery = (HierQuery)paramHierQueryProperty.getQuery();
/*     */     HierDataSource hierDataSource = (HierDataSource)this.xquery.getDataSource();
/*     */     getContentPane().setLayout(new BorderLayout(5, 5));
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setLayout(new FlowLayout(0, 5, 5));
/*     */     jPanel.add(this.dsparamCB);
/*     */     getContentPane().add(jPanel, "North");
/*     */     getContentPane().add(this.editor, "Center");
/*     */     jPanel = new JPanel();
/*     */     jPanel.add(this.okB);
/*     */     jPanel.add(this.cancelB);
/*     */     getContentPane().add(jPanel, "South");
/*     */     this.dsparamCB.setSelected((this.xquery.getCustomParameters() == null));
/*     */     XTypeNode xTypeNode = hierDataSource.getRequestInputType(this.xquery.getRequest());
/*     */     XNode xNode = this.xquery.getRequestParameters();
/*     */     this.editor.setType(xTypeNode);
/*     */     this.editor.setValue((xNode == null) ? xTypeNode.newInstance() : xNode);
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.cancelB.addActionListener(this.cancelListener);
/*     */     this.dsparamCB.addItemListener(this.dsparamListener);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   private void setEnabled() { this.editor.setEnabled(!this.dsparamCB.isSelected()); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\xml\gui\ParamsDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */