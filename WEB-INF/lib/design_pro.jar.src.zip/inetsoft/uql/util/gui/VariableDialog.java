package inetsoft.uql.util.gui;

import inetsoft.uql.XQuery;
import inetsoft.uql.XRepository;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.schema.QueryVariable;
import inetsoft.uql.schema.UserVariable;
import inetsoft.uql.schema.XSchema;
import inetsoft.uql.schema.XValueNode;
import inetsoft.uql.schema.XVariable;
import inetsoft.widget.VFlowLayout;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.AbstractListModel;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class VariableDialog extends JDialog {
  ListSelectionListener listListener;
  
  ActionListener deleteListener;
  
  ActionListener closeListener;
  
  public VariableDialog(XRepository paramXRepository, XQuery paramXQuery) {
    this.listListener = new ListSelectionListener(this) {
        private final VariableDialog this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
          String str = (String)this.this$0.vlist.getSelectedValue();
          if (str != null) {
            XVariable xVariable = this.this$0.query.getVariable(str);
            this.this$0.varpane.update();
            this.this$0.varpane.setVariable(xVariable);
          } 
        }
      };
    this.deleteListener = new ActionListener(this) {
        private final VariableDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.nameTF.setText("");
          this.this$0.varModel.remove(this.this$0.vlist.getSelectedIndex());
        }
      };
    this.closeListener = new ActionListener(this) {
        private final VariableDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.nameTF = new JTextField(15);
    this.vlist = new JList();
    this.deleteB = new JButton(Catalog.getString("Delete"));
    this.closeB = new JButton(Catalog.getString("Close"));
    this.applyB = new JButton(Catalog.getString("Apply"));
    this.okB = new JButton(Catalog.getString("OK"));
    this.repository = paramXRepository;
    this.query = paramXQuery;
    getContentPane().setLayout(new BorderLayout(10, 10));
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout());
    JScrollPane jScrollPane = new JScrollPane(this.vlist);
    jScrollPane.setVerticalScrollBarPolicy(22);
    jScrollPane.setBorder(new TitledBorder(Catalog.getString("Variable List")));
    jScrollPane.setPreferredSize(new Dimension(120, 100));
    jPanel1.add(jScrollPane, "Center");
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new VFlowLayout(17, 5, 5));
    jPanel2.add(this.deleteB);
    jPanel1.add(jPanel2, "East");
    getContentPane().add(jPanel1, "North");
    this.varpane = new VarPane(this);
    getContentPane().add(this.varpane, "Center");
    this.vlist.setModel(this.varModel = new VarModel(this, paramXQuery));
    this.vlist.setSelectionMode(0);
    this.vlist.addListSelectionListener(this.listListener);
    JPanel jPanel3 = new JPanel();
    jPanel3.setLayout(new FlowLayout(1, 20, 10));
    jPanel3.add(this.okB);
    jPanel3.add(this.applyB);
    jPanel3.add(this.closeB);
    getContentPane().add(jPanel3, "South");
    this.deleteB.addActionListener(this.deleteListener);
    this.closeB.addActionListener(this.closeListener);
  }
  
  class VarPane extends JPanel {
    ActionListener typeListener;
    
    ActionListener applyListener;
    
    ActionListener okListener;
    
    JRadioButton userRB;
    
    JRadioButton queryRB;
    
    VariableDialog.UserPane userpane;
    
    VariableDialog.QueryPane querypane;
    
    JPanel pane;
    
    CardLayout paneLO;
    
    private final VariableDialog this$0;
    
    public VarPane(VariableDialog this$0) {
      this.this$0 = this$0;
      this.typeListener = new VariableDialog$1(this);
      this.applyListener = new VariableDialog$2(this);
      this.okListener = new VariableDialog$3(this);
      this.userRB = new JRadioButton(Catalog.getString("User Variable"));
      this.queryRB = new JRadioButton(Catalog.getString("Query Variable"));
      this.userpane = new VariableDialog.UserPane(this.this$0);
      this.querypane = new VariableDialog.QueryPane(this.this$0);
      this.pane = new JPanel();
      this.paneLO = new CardLayout();
      setLayout(new BorderLayout());
      JPanel jPanel1 = new JPanel();
      jPanel1.setLayout(new FlowLayout(0, 5, 2));
      jPanel1.add(new JLabel(Catalog.getString("Name") + ":"));
      jPanel1.add(this$0.nameTF);
      add(jPanel1, "North");
      JPanel jPanel2 = new JPanel();
      jPanel2.setLayout(new BorderLayout());
      jPanel1 = new JPanel();
      jPanel1.add(this.userRB);
      jPanel1.add(this.queryRB);
      jPanel2.add(jPanel1, "North");
      this.pane.setLayout(this.paneLO);
      this.pane.add(new JLabel(""), "null");
      this.pane.add(this.userpane, "user");
      this.pane.add(this.querypane, "query");
      this.paneLO.show(this.pane, "user");
      jPanel2.add(this.pane, "Center");
      add(jPanel2, "Center");
      ButtonGroup buttonGroup = new ButtonGroup();
      buttonGroup.add(this.userRB);
      buttonGroup.add(this.queryRB);
      this.userRB.setSelected(true);
      this$0.okB.addActionListener(this.okListener);
      this$0.applyB.addActionListener(this.applyListener);
      this.userRB.addActionListener(this.typeListener);
      this.queryRB.addActionListener(this.typeListener);
    }
    
    public void setVariable(XVariable param1XVariable) {
      this.this$0.nameTF.setText(param1XVariable.getName());
      if (param1XVariable instanceof QueryVariable) {
        this.queryRB.setSelected(true);
        this.querypane.setVariable((QueryVariable)param1XVariable);
      } else {
        this.userRB.setSelected(true);
        this.userpane.setVariable((UserVariable)param1XVariable);
      } 
      this.typeListener.actionPerformed(null);
    }
    
    public void update() {
      if (this.this$0.nameTF.getText().length() > 0)
        this.applyListener.actionPerformed(null); 
    }
    
    public Dimension getPreferredSize() { return new Dimension(480, 260); }
  }
  
  class UserPane extends JPanel {
    JTextField labelTF;
    
    JCheckBox promptCB;
    
    XValueEditor editor;
    
    private final VariableDialog this$0;
    
    public UserPane(VariableDialog this$0) {
      this.this$0 = this$0;
      this.labelTF = new JTextField(15);
      this.promptCB = new JCheckBox(Catalog.getString("Prompt User"));
      this.editor = new XValueEditor();
      setLayout(new VFlowLayout(17, 5, 5));
      JPanel jPanel = new JPanel();
      jPanel.setLayout(new FlowLayout(0, 10, 5));
      jPanel.add(new JLabel(Catalog.getString("Alias") + ":"));
      jPanel.add(this.labelTF);
      jPanel.add(this.promptCB);
      add(jPanel);
      add(this.editor);
    }
    
    public void setVariable(UserVariable param1UserVariable) {
      this.labelTF.setText(param1UserVariable.getAlias());
      this.editor.setValueNode(param1UserVariable.getValueNode());
      this.promptCB.setSelected(param1UserVariable.isPrompt());
    }
    
    public XVariable getVariable() {
      UserVariable userVariable = new UserVariable();
      XValueNode xValueNode = this.editor.getValueNode();
      userVariable.setName(this.this$0.nameTF.getText());
      userVariable.setAlias(this.labelTF.getText());
      userVariable.setValueNode(xValueNode);
      userVariable.setTypeNode(XSchema.createPrimitiveType(xValueNode.getType()));
      userVariable.setPrompt(this.promptCB.isSelected());
      return userVariable;
    }
  }
  
  class QueryPane extends JPanel {
    ItemListener queryListener;
    
    JComboBox queryCB;
    
    JComboBox aggregateCB;
    
    XNodePathEditor editor;
    
    private final VariableDialog this$0;
    
    public QueryPane(VariableDialog this$0) {
      this.this$0 = this$0;
      this.queryListener = new VariableDialog$4(this);
      this.aggregateCB = new JComboBox(new Object[] { "(none)", "sum", "avg", "min", "max", "count" });
      this.editor = new XNodePathEditor();
      setLayout(new BorderLayout());
      try {
        this.queryCB = new JComboBox(this$0.repository.getQueryNames());
        JPanel jPanel1 = new JPanel();
        jPanel1.setLayout(new BorderLayout(5, 5));
        add(jPanel1, "North");
        JPanel jPanel2 = new JPanel();
        jPanel2.setLayout(new FlowLayout(0, 5, 5));
        jPanel2.add(this.queryCB);
        jPanel1.add(jPanel2, "West");
        jPanel2 = new JPanel();
        jPanel2.setLayout(new FlowLayout(2, 10, 5));
        jPanel2.add(this.aggregateCB);
        jPanel1.add(jPanel2, "East");
        add(this.editor, "Center");
        this.queryCB.addItemListener(this.queryListener);
      } catch (Exception exception) {
        exception.printStackTrace();
        JOptionPane.showMessageDialog(this$0, exception.toString());
      } 
    }
    
    public void setVariable(QueryVariable param1QueryVariable) {
      try {
        XQuery xQuery = this.this$0.repository.getQuery(param1QueryVariable.getQuery());
        if (xQuery != null) {
          this.queryCB.setSelectedItem(param1QueryVariable.getQuery());
          String str = param1QueryVariable.getAggregate();
          this.aggregateCB.setSelectedItem((str == null) ? "(none)" : str);
          this.editor.setTree(xQuery.getOutputType(), param1QueryVariable.getNodePath());
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
        JOptionPane.showMessageDialog(this.this$0, exception.toString());
      } 
    }
    
    public XVariable getVariable() {
      QueryVariable queryVariable = new QueryVariable();
      queryVariable.setName(this.this$0.nameTF.getText());
      queryVariable.setQuery((String)this.queryCB.getSelectedItem());
      String str = (String)this.aggregateCB.getSelectedItem();
      queryVariable.setAggregate((str == null || str.equals("(none)")) ? null : str);
      queryVariable.setNodePath(this.editor.getNodePath());
      return queryVariable;
    }
  }
  
  class VarModel extends AbstractListModel {
    XQuery query;
    
    Vector vars;
    
    private final VariableDialog this$0;
    
    public VarModel(VariableDialog this$0, XQuery param1XQuery) {
      this.this$0 = this$0;
      this.vars = new Vector();
      this.query = param1XQuery;
      Enumeration enumeration = param1XQuery.getVariableNames();
      while (enumeration.hasMoreElements())
        this.vars.addElement(enumeration.nextElement()); 
    }
    
    public void add(String param1String) {
      if (this.vars.indexOf(param1String) < 0) {
        this.vars.addElement(param1String);
        fireIntervalAdded(this, this.vars.size() - 1, this.vars.size() - 1);
      } 
    }
    
    public void remove(int param1Int) {
      this.query.removeVariable((String)this.vars.elementAt(param1Int));
      this.vars.removeElementAt(param1Int);
      fireIntervalRemoved(this, param1Int, param1Int);
    }
    
    public int getSize() { return this.vars.size(); }
    
    public Object getElementAt(int param1Int) { return this.vars.elementAt(param1Int); }
  }
  
  static final String msg1 = Catalog.getString("Name field can't be empty!");
  
  JTextField nameTF;
  
  JList vlist;
  
  VarModel varModel;
  
  JButton deleteB;
  
  JButton closeB;
  
  JButton applyB;
  
  JButton okB;
  
  VarPane varpane;
  
  XQuery query;
  
  XRepository repository;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\VariableDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */