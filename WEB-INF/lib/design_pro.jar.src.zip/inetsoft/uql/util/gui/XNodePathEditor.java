package inetsoft.uql.util.gui;

import inetsoft.uql.locale.Catalog;
import inetsoft.uql.path.PathNode;
import inetsoft.uql.path.XCondition;
import inetsoft.uql.path.XNodePath;
import inetsoft.uql.schema.XTypeNode;
import inetsoft.util.internal.Property2Panel;
import java.awt.AWTEventMulticaster;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

public class XNodePathEditor extends JPanel {
  ActionListener actionListener;
  
  TreeSelectionListener treeListener;
  
  ActionListener editListener;
  
  ActionListener applyListener;
  
  ActionListener clearListener;
  
  ActionListener selectListener;
  
  XTypeTree tree;
  
  JTextArea condTF;
  
  JButton editB;
  
  JButton applyB;
  
  JButton clearB;
  
  JButton selectB;
  
  JPanel selectPnl;
  
  XTypeNode xtype;
  
  XTypeNode currnode;
  
  XNodePath xpath;
  
  PathNode pnode;
  
  Hashtable condmap;
  
  boolean changed;
  
  public XNodePathEditor() {
    this.actionListener = null;
    this.treeListener = new TreeSelectionListener(this) {
        private final XNodePathEditor this$0;
        
        public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
          this.this$0.currnode = this.this$0.tree.getSelectedNode();
          this.this$0.pnode = null;
          if (this.this$0.currnode != null && this.this$0.xpath != null) {
            this.this$0.pnode = this.this$0.xpath.find(this.this$0.xtype, this.this$0.currnode);
            if (this.this$0.pnode != null) {
              XCondition xCondition = this.this$0.pnode.getCondition();
              this.this$0.condTF.setText((xCondition != null) ? xCondition.toString() : "");
            } 
          } 
          this.this$0.setEnabled();
        }
      };
    this.editListener = new ActionListener(this) {
        private final XNodePathEditor this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          String str = ConditionEditor.show(this.this$0.currnode);
          if (str != null && str.length() > 0) {
            this.this$0.condTF.setText(str);
            this.this$0.applyListener.actionPerformed(null);
          } 
        }
      };
    this.applyListener = new ActionListener(this) {
        private final XNodePathEditor this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.pnode != null)
            try {
              String str = this.this$0.condTF.getText().trim();
              XCondition xCondition = (str.length() > 0) ? XCondition.parse(str) : null;
              this.this$0.pnode.setCondition(xCondition);
              if (xCondition != null) {
                String str1 = xCondition.toString();
                if (str1.startsWith("(") && str1.endsWith(")"))
                  str1 = str1.substring(1, str1.length() - 1); 
                this.this$0.condTF.setText(str1);
              } 
              if (xCondition == null) {
                this.this$0.condmap.remove(this.this$0.xpath.getPath(this.this$0.pnode));
              } else {
                this.this$0.condmap.put(this.this$0.xpath.getPath(this.this$0.pnode), this.this$0.pnode.getCondition());
              } 
              this.this$0.valueChanged();
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(null, exception.toString());
            }  
        }
      };
    this.clearListener = new ActionListener(this) {
        private final XNodePathEditor this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.pnode != null) {
            this.this$0.pnode.setCondition(null);
            this.this$0.condTF.setText("");
            this.this$0.valueChanged();
          } 
        }
      };
    this.selectListener = new ActionListener(this) {
        private final XNodePathEditor this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          XTypeNode xTypeNode = this.this$0.tree.getSelectedNode();
          if (xTypeNode != null) {
            Vector vector = new Vector();
            for (; xTypeNode != this.this$0.xtype && xTypeNode != null; 
              xTypeNode = (XTypeNode)xTypeNode.getParent())
              vector.insertElementAt(xTypeNode.getName(), 0); 
            vector.insertElementAt(this.this$0.xtype.getName(), 0);
            StringBuffer stringBuffer = new StringBuffer();
            this.this$0.xpath = new XNodePath();
            for (byte b = 0; b < vector.size(); b++) {
              if (b)
                stringBuffer.append("."); 
              stringBuffer.append(vector.elementAt(b));
              this.this$0.xpath.add((String)vector.elementAt(b), (XCondition)this.this$0.condmap.get(stringBuffer.toString()));
            } 
            this.this$0.tree.setNodePath(this.this$0.xpath);
            this.this$0.treeListener.valueChanged(null);
            this.this$0.valueChanged();
          } 
        }
      };
    this.tree = new XTypeTree();
    this.condTF = new JTextArea(3, 25);
    this.editB = new JButton(Catalog.getString("Create") + "...");
    this.applyB = new JButton(Catalog.getString("Apply"));
    this.clearB = new JButton(Catalog.getString("Clear"));
    this.selectB = new JButton(Catalog.getString("Select Path"));
    this.xpath = null;
    this.pnode = null;
    this.condmap = new Hashtable();
    this.changed = false;
    setLayout(new BorderLayout());
    JScrollPane jScrollPane1 = new JScrollPane(this.tree);
    add(jScrollPane1, "Center");
    JScrollPane jScrollPane2 = new JScrollPane(this.condTF);
    jScrollPane2.setPreferredSize(this.condTF.getPreferredSize());
    Property2Panel property2Panel = new Property2Panel();
    property2Panel.add(Catalog.getString("Condition"), new Object[][] { { jScrollPane2 }, { this.editB, this.applyB, this.clearB } });
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new BorderLayout(5, 5));
    jPanel.add(property2Panel, "North");
    this.selectPnl = new JPanel();
    this.selectPnl.setLayout(new FlowLayout(0, 5, 5));
    this.selectPnl.add(this.selectB);
    jPanel.add(this.selectPnl, "South");
    add(jPanel, "East");
    this.tree.addTreeSelectionListener(this.treeListener);
    this.tree.getSelectionModel().setSelectionMode(1);
    this.editB.addActionListener(this.editListener);
    this.applyB.addActionListener(this.applyListener);
    this.clearB.addActionListener(this.clearListener);
    this.selectB.addActionListener(this.selectListener);
    setEnabled();
  }
  
  public void setTree(XTypeNode paramXTypeNode, XNodePath paramXNodePath) {
    this.tree.setType(this.xtype = paramXTypeNode);
    this.tree.setNodePath(this.xpath = paramXNodePath);
    this.condTF.setText("");
    this.condmap.clear();
    for (byte b = 0; paramXNodePath != null && b < paramXNodePath.getPathNodeCount(); b++) {
      PathNode pathNode = paramXNodePath.getPathNode(b);
      if (pathNode.getCondition() != null)
        this.condmap.put(paramXNodePath.getPath(pathNode), pathNode.getCondition()); 
    } 
    this.changed = false;
  }
  
  public XNodePath getNodePath() { return this.xpath; }
  
  public boolean isChanged() { return this.changed; }
  
  public void addControl(Component paramComponent) { this.selectPnl.add(paramComponent); }
  
  public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
  
  private void setEnabled() {
    XTypeNode xTypeNode = this.tree.getSelectedNode();
    this.condTF.setEnabled((this.pnode != null && xTypeNode.getMaxOccurs() > 1));
    this.editB.setEnabled((this.pnode != null && xTypeNode.getMaxOccurs() > 1));
    this.applyB.setEnabled((this.pnode != null && xTypeNode.getMaxOccurs() > 1));
    this.clearB.setEnabled((this.pnode != null && xTypeNode.getMaxOccurs() > 1));
    this.selectB.setEnabled((xTypeNode != null));
  }
  
  private void valueChanged() {
    this.changed = true;
    if (this.actionListener != null)
      this.actionListener.actionPerformed(new ActionEvent(this, 1001, "path")); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\XNodePathEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */