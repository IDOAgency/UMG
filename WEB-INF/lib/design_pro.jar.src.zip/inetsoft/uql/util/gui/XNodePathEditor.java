/*     */ package inetsoft.uql.util.gui;
/*     */ 
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.path.PathNode;
/*     */ import inetsoft.uql.path.XCondition;
/*     */ import inetsoft.uql.path.XNodePath;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import inetsoft.util.internal.Property2Panel;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.TreeSelectionEvent;
/*     */ import javax.swing.event.TreeSelectionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XNodePathEditor
/*     */   extends JPanel
/*     */ {
/*     */   ActionListener actionListener;
/*     */   TreeSelectionListener treeListener;
/*     */   ActionListener editListener;
/*     */   ActionListener applyListener;
/*     */   ActionListener clearListener;
/*     */   ActionListener selectListener;
/*     */   XTypeTree tree;
/*     */   JTextArea condTF;
/*     */   JButton editB;
/*     */   JButton applyB;
/*     */   JButton clearB;
/*     */   JButton selectB;
/*     */   JPanel selectPnl;
/*     */   XTypeNode xtype;
/*     */   XTypeNode currnode;
/*     */   XNodePath xpath;
/*     */   PathNode pnode;
/*     */   Hashtable condmap;
/*     */   boolean changed;
/*     */   
/*     */   public XNodePathEditor() {
/* 114 */     this.actionListener = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     this.treeListener = new TreeSelectionListener(this) { private final XNodePathEditor this$0;
/*     */         public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
/* 151 */           this.this$0.currnode = this.this$0.tree.getSelectedNode();
/* 152 */           this.this$0.pnode = null;
/*     */           
/* 154 */           if (this.this$0.currnode != null && this.this$0.xpath != null) {
/* 155 */             this.this$0.pnode = this.this$0.xpath.find(this.this$0.xtype, this.this$0.currnode);
/* 156 */             if (this.this$0.pnode != null) {
/* 157 */               XCondition xCondition = this.this$0.pnode.getCondition();
/* 158 */               this.this$0.condTF.setText((xCondition != null) ? xCondition.toString() : "");
/*     */             } 
/*     */           } 
/*     */           
/* 162 */           this.this$0.setEnabled();
/*     */         } }
/*     */       ;
/*     */     
/* 166 */     this.editListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 168 */           String str = ConditionEditor.show(this.this$0.currnode);
/* 169 */           if (str != null && str.length() > 0) {
/* 170 */             this.this$0.condTF.setText(str);
/* 171 */             this.this$0.applyListener.actionPerformed(null);
/*     */           } 
/*     */         }
/*     */         private final XNodePathEditor this$0;
/*     */       };
/* 176 */     this.applyListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 178 */           if (this.this$0.pnode != null)
/*     */             try {
/* 180 */               String str = this.this$0.condTF.getText().trim();
/* 181 */               XCondition xCondition = (str.length() > 0) ? XCondition.parse(str) : null;
/*     */               
/* 183 */               this.this$0.pnode.setCondition(xCondition);
/*     */               
/* 185 */               if (xCondition != null) {
/* 186 */                 String str1 = xCondition.toString();
/* 187 */                 if (str1.startsWith("(") && str1.endsWith(")")) {
/* 188 */                   str1 = str1.substring(1, str1.length() - 1);
/*     */                 }
/*     */                 
/* 191 */                 this.this$0.condTF.setText(str1);
/*     */               } 
/*     */               
/* 194 */               if (xCondition == null) {
/* 195 */                 this.this$0.condmap.remove(this.this$0.xpath.getPath(this.this$0.pnode));
/*     */               } else {
/*     */                 
/* 198 */                 this.this$0.condmap.put(this.this$0.xpath.getPath(this.this$0.pnode), this.this$0.pnode.getCondition());
/*     */               } 
/* 200 */               this.this$0.valueChanged();
/*     */             } catch (Exception exception) {
/* 202 */               exception.printStackTrace();
/* 203 */               JOptionPane.showMessageDialog(null, exception.toString());
/*     */             }  
/*     */         }
/*     */         
/*     */         private final XNodePathEditor this$0;
/*     */       };
/* 209 */     this.clearListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 211 */           if (this.this$0.pnode != null) {
/* 212 */             this.this$0.pnode.setCondition(null);
/* 213 */             this.this$0.condTF.setText("");
/* 214 */             this.this$0.valueChanged();
/*     */           } 
/*     */         }
/*     */         
/*     */         private final XNodePathEditor this$0;
/*     */       };
/* 220 */     this.selectListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 222 */           XTypeNode xTypeNode = this.this$0.tree.getSelectedNode();
/* 223 */           if (xTypeNode != null) {
/* 224 */             Vector vector = new Vector();
/* 225 */             for (; xTypeNode != this.this$0.xtype && xTypeNode != null; 
/* 226 */               xTypeNode = (XTypeNode)xTypeNode.getParent()) {
/* 227 */               vector.insertElementAt(xTypeNode.getName(), 0);
/*     */             }
/* 229 */             vector.insertElementAt(this.this$0.xtype.getName(), 0);
/*     */             
/* 231 */             StringBuffer stringBuffer = new StringBuffer();
/* 232 */             this.this$0.xpath = new XNodePath();
/* 233 */             for (byte b = 0; b < vector.size(); b++) {
/* 234 */               if (b) {
/* 235 */                 stringBuffer.append(".");
/*     */               }
/* 237 */               stringBuffer.append(vector.elementAt(b));
/*     */               
/* 239 */               this.this$0.xpath.add((String)vector.elementAt(b), (XCondition)this.this$0.condmap.get(stringBuffer.toString()));
/*     */             } 
/*     */ 
/*     */             
/* 243 */             this.this$0.tree.setNodePath(this.this$0.xpath);
/*     */             
/* 245 */             this.this$0.treeListener.valueChanged(null);
/* 246 */             this.this$0.valueChanged();
/*     */           } 
/*     */         }
/*     */         private final XNodePathEditor this$0;
/*     */       };
/* 251 */     this.tree = new XTypeTree();
/* 252 */     this.condTF = new JTextArea(3, 25);
/* 253 */     this.editB = new JButton(Catalog.getString("Create") + "...");
/* 254 */     this.applyB = new JButton(Catalog.getString("Apply"));
/* 255 */     this.clearB = new JButton(Catalog.getString("Clear"));
/* 256 */     this.selectB = new JButton(Catalog.getString("Select Path"));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 261 */     this.xpath = null;
/* 262 */     this.pnode = null;
/* 263 */     this.condmap = new Hashtable();
/* 264 */     this.changed = false;
/*     */     setLayout(new BorderLayout());
/*     */     JScrollPane jScrollPane1 = new JScrollPane(this.tree);
/*     */     add(jScrollPane1, "Center");
/*     */     JScrollPane jScrollPane2 = new JScrollPane(this.condTF);
/*     */     jScrollPane2.setPreferredSize(this.condTF.getPreferredSize());
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     property2Panel.add(Catalog.getString("Condition"), new Object[][] { { jScrollPane2 }, { this.editB, this.applyB, this.clearB } });
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setLayout(new BorderLayout(5, 5));
/*     */     jPanel.add(property2Panel, "North");
/*     */     this.selectPnl = new JPanel();
/*     */     this.selectPnl.setLayout(new FlowLayout(0, 5, 5));
/*     */     this.selectPnl.add(this.selectB);
/*     */     jPanel.add(this.selectPnl, "South");
/*     */     add(jPanel, "East");
/*     */     this.tree.addTreeSelectionListener(this.treeListener);
/*     */     this.tree.getSelectionModel().setSelectionMode(1);
/*     */     this.editB.addActionListener(this.editListener);
/*     */     this.applyB.addActionListener(this.applyListener);
/*     */     this.clearB.addActionListener(this.clearListener);
/*     */     this.selectB.addActionListener(this.selectListener);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public void setTree(XTypeNode paramXTypeNode, XNodePath paramXNodePath) {
/*     */     this.tree.setType(this.xtype = paramXTypeNode);
/*     */     this.tree.setNodePath(this.xpath = paramXNodePath);
/*     */     this.condTF.setText("");
/*     */     this.condmap.clear();
/*     */     for (byte b = 0; paramXNodePath != null && b < paramXNodePath.getPathNodeCount(); b++) {
/*     */       PathNode pathNode = paramXNodePath.getPathNode(b);
/*     */       if (pathNode.getCondition() != null)
/*     */         this.condmap.put(paramXNodePath.getPath(pathNode), pathNode.getCondition()); 
/*     */     } 
/*     */     this.changed = false;
/*     */   }
/*     */   
/*     */   public XNodePath getNodePath() { return this.xpath; }
/*     */   
/*     */   public boolean isChanged() { return this.changed; }
/*     */   
/*     */   public void addControl(Component paramComponent) { this.selectPnl.add(paramComponent); }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
/*     */   
/*     */   private void setEnabled() {
/*     */     XTypeNode xTypeNode = this.tree.getSelectedNode();
/*     */     this.condTF.setEnabled((this.pnode != null && xTypeNode.getMaxOccurs() > 1));
/*     */     this.editB.setEnabled((this.pnode != null && xTypeNode.getMaxOccurs() > 1));
/*     */     this.applyB.setEnabled((this.pnode != null && xTypeNode.getMaxOccurs() > 1));
/*     */     this.clearB.setEnabled((this.pnode != null && xTypeNode.getMaxOccurs() > 1));
/*     */     this.selectB.setEnabled((xTypeNode != null));
/*     */   }
/*     */   
/*     */   private void valueChanged() {
/*     */     this.changed = true;
/*     */     if (this.actionListener != null)
/*     */       this.actionListener.actionPerformed(new ActionEvent(this, 1001, "path")); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\XNodePathEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */