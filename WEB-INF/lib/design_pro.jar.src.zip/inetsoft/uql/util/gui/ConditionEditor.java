package inetsoft.uql.util.gui;

import inetsoft.grid.Grid;
import inetsoft.grid.GridCellEditor;
import inetsoft.grid.Scroller;
import inetsoft.grid.editor.BooleanEditor;
import inetsoft.grid.editor.ComboEditor;
import inetsoft.grid.editor.DateEditor;
import inetsoft.grid.editor.DateTimeEditor;
import inetsoft.grid.editor.IntegerEditor;
import inetsoft.grid.editor.NumberEditor;
import inetsoft.grid.editor.TimeEditor;
import inetsoft.grid.model.DefaultGridModel;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.schema.XTypeNode;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

public class ConditionEditor extends JDialog {
  ActionListener okListener;
  
  ActionListener cancelListener;
  
  public static String show(XTypeNode paramXTypeNode) {
    ConditionEditor conditionEditor = new ConditionEditor(paramXTypeNode);
    conditionEditor.setModal(true);
    conditionEditor.pack();
    conditionEditor.setVisible(true);
    return conditionEditor.getCondition();
  }
  
  public ConditionEditor(XTypeNode paramXTypeNode) {
    this.okListener = new ActionListener(this) {
        private final ConditionEditor this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          StringBuffer stringBuffer = new StringBuffer();
          this.this$0.table.popdownEditor();
          for (byte b = 0; b < this.this$0.table.getColCount(); b++) {
            String str = (String)this.this$0.table.getObject(1, b);
            if (str != null && str.length() != 0) {
              Object object = this.this$0.table.getObject(2, b);
              if (str.startsWith("is ")) {
                object = null;
              } else if (object == null) {
                object = "''";
              } else if (!(object instanceof Number)) {
                object = "'" + object + "'";
              } 
              if (stringBuffer.length() > 0)
                stringBuffer.append(" and "); 
              if (object != null) {
                stringBuffer.append("(" + this.this$0.table.getObject(0, b) + " " + str + " " + object + ")");
              } else {
                stringBuffer.append("(" + this.this$0.table.getObject(0, b) + " " + str + ")");
              } 
            } 
          } 
          this.this$0.cond = stringBuffer.toString();
          this.this$0.dispose();
        }
      };
    this.cancelListener = new ActionListener(this) {
        private final ConditionEditor this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.opCB = new ComboEditor(ops);
    this.okB = new JButton(Catalog.getString("OK"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.cond = null;
    this.root = paramXTypeNode;
    DefaultGridModel defaultGridModel = new DefaultGridModel(3, 0);
    this.table = new Grid();
    defaultGridModel.setHeaderColCount(1);
    defaultGridModel.setObject(0, -1, Catalog.getString("Field"));
    defaultGridModel.setObject(1, -1, Catalog.getString("Comparison"));
    defaultGridModel.setObject(2, -1, Catalog.getString("Value"));
    this.table.setModel(defaultGridModel);
    this.table.setMinColWidth(-99, 80);
    this.table.setMinRowHeight(-99, 20);
    this.table.setRowSelectable(false);
    populateTable(defaultGridModel, paramXTypeNode, "");
    getContentPane().setLayout(new BorderLayout(5, 5));
    Scroller scroller = new Scroller(this.table);
    scroller.setPreferredSize(new Dimension(400, 150));
    getContentPane().add(scroller, "Center");
    JPanel jPanel = new JPanel();
    jPanel.add(this.okB);
    jPanel.add(this.cancelB);
    getContentPane().add(jPanel, "South");
    this.okB.addActionListener(this.okListener);
    this.cancelB.addActionListener(this.cancelListener);
  }
  
  public String getCondition() { return this.cond; }
  
  private void populateTable(DefaultGridModel paramDefaultGridModel, XTypeNode paramXTypeNode, String paramString) {
    for (byte b1 = 0; b1 < paramXTypeNode.getAttributeCount(); b1++)
      addColumn(paramDefaultGridModel, paramXTypeNode.getAttribute(b1), paramString + "@"); 
    paramString = paramString + paramXTypeNode.getName() + ".";
    for (byte b2 = 0; b2 < paramXTypeNode.getChildCount(); b2++)
      addColumn(paramDefaultGridModel, (XTypeNode)paramXTypeNode.getChild(b2), paramString); 
  }
  
  private void addColumn(DefaultGridModel paramDefaultGridModel, XTypeNode paramXTypeNode, String paramString) {
    int i = paramDefaultGridModel.getColCount();
    paramDefaultGridModel.insertCol(i, 1);
    paramDefaultGridModel.setObject(0, i, paramString + paramXTypeNode.getName());
    paramDefaultGridModel.setObject(1, i, "");
    this.table.setEditor(1, i, this.opCB);
    this.table.setEditor(2, i, getEditor(paramXTypeNode));
    this.table.setEditable(2, i, true);
  }
  
  private GridCellEditor getEditor(XTypeNode paramXTypeNode) {
    String str = paramXTypeNode.getType();
    if (str.equals("boolean"))
      return new BooleanEditor(); 
    if (str.equals("float"))
      return new NumberEditor(); 
    if (str.equals("double"))
      return new NumberEditor(); 
    if (str.equals("integer"))
      return new IntegerEditor(); 
    if (str.equals("long"))
      return new IntegerEditor(); 
    if (str.equals("timeInstant"))
      return new DateTimeEditor(paramXTypeNode.getFormat()); 
    if (str.equals("date"))
      return new DateEditor(paramXTypeNode.getFormat()); 
    if (str.equals("time"))
      return new TimeEditor(); 
    return null;
  }
  
  static final String[] ops = { 
      "", "=", "<", ">", "<=", ">=", "!=", "like", "match", "is null", 
      "is not null" };
  
  ComboEditor opCB;
  
  Grid table;
  
  JButton okB;
  
  JButton cancelB;
  
  XTypeNode root;
  
  String cond;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\ConditionEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */