/*    */ package inetsoft.uql.util.gui;
/*    */ 
/*    */ import inetsoft.grid.model.AbstractGridModel;
/*    */ import inetsoft.uql.XTableNode;
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XTableNodeModel
/*    */   extends AbstractGridModel
/*    */ {
/*    */   XTableNode table;
/*    */   Vector rows;
/*    */   
/*    */   public XTableNodeModel(XTableNode paramXTableNode) {
/* 57 */     this.rows = new Vector();
/*    */     this.table = paramXTableNode;
/*    */     while (paramXTableNode.next()) {
/*    */       Object[] arrayOfObject = new Object[paramXTableNode.getColCount()];
/*    */       for (byte b = 0; b < paramXTableNode.getColCount(); b++)
/*    */         arrayOfObject[b] = paramXTableNode.getObject(b); 
/*    */       this.rows.addElement(arrayOfObject);
/*    */     } 
/*    */   }
/*    */   
/*    */   public int getRowCount() { return this.rows.size(); }
/*    */   
/*    */   public int getColCount() { return this.table.getColCount(); }
/*    */   
/*    */   protected Object getColHeader(int paramInt1, int paramInt2) { return this.table.getName(paramInt2); }
/*    */   
/*    */   public Object getValue(int paramInt1, int paramInt2) { return (Object[])this.rows.elementAt(paramInt1)[paramInt2]; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\XTableNodeModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */