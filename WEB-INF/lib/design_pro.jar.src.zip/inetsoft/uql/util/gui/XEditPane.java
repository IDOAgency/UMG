/*     */ package inetsoft.uql.util.gui;
/*     */ 
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.schema.BooleanValue;
/*     */ import inetsoft.uql.schema.ByteValue;
/*     */ import inetsoft.uql.schema.CharacterValue;
/*     */ import inetsoft.uql.schema.DoubleValue;
/*     */ import inetsoft.uql.schema.EnumType;
/*     */ import inetsoft.uql.schema.FloatValue;
/*     */ import inetsoft.uql.schema.IntegerValue;
/*     */ import inetsoft.uql.schema.LongValue;
/*     */ import inetsoft.uql.schema.ShortValue;
/*     */ import inetsoft.uql.schema.UserDefinedType;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import inetsoft.uql.schema.XValueNode;
/*     */ import inetsoft.util.internal.NumField;
/*     */ import inetsoft.widget.DateCombo;
/*     */ import inetsoft.widget.DateTimeCombo;
/*     */ import inetsoft.widget.Grid2Layout;
/*     */ import inetsoft.widget.TimeSpinner;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.CardLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.awt.event.TextEvent;
/*     */ import java.awt.event.TextListener;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.border.TitledBorder;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.event.EventListenerList;
/*     */ import javax.swing.event.TreeModelEvent;
/*     */ import javax.swing.event.TreeModelListener;
/*     */ import javax.swing.event.TreeSelectionEvent;
/*     */ import javax.swing.event.TreeSelectionListener;
/*     */ import javax.swing.tree.TreeModel;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XEditPane
/*     */   extends JPanel
/*     */ {
/*     */   TreeSelectionListener treeListener;
/*     */   ActionListener addChildListener;
/*     */   ActionListener addChildMenuListener;
/*     */   ActionListener addListener;
/*     */   ActionListener removeListener;
/*     */   FieldChangeListener changeListener;
/*     */   ActionListener setListener;
/*     */   ItemListener varListener;
/*     */   ItemListener nullListener;
/*     */   
/*     */   public XEditPane() {
/* 475 */     this.treeListener = new TreeSelectionListener(this) {
/*     */         public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
/* 477 */           if (this.this$0.root == null) {
/*     */             return;
/*     */           }
/*     */           
/* 481 */           TreePath treePath = this.this$0.tree.getSelectionPath();
/* 482 */           this.this$0.setCurrent((treePath == null) ? null : (XNode)treePath.getLastPathComponent());
/*     */ 
/*     */           
/* 485 */           if (this.this$0.currnode != null && !(this.this$0.currnode instanceof XValueNode))
/* 486 */             this.this$0.tree.expandPath(treePath); 
/*     */         }
/*     */         
/*     */         private final XEditPane this$0;
/*     */       };
/* 491 */     this.addChildListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 493 */           if (this.this$0.childMenu != null) {
/* 494 */             if (this.this$0.childMenu.isVisible()) {
/* 495 */               this.this$0.childMenu.setVisible(false);
/*     */             } else {
/*     */               
/* 498 */               this.this$0.childMenu.show(this.this$0.addChildB, 0, (this.this$0.addChildB.getSize()).height);
/*     */             } 
/*     */           }
/*     */         }
/*     */         
/*     */         private final XEditPane this$0;
/*     */       };
/* 505 */     this.addChildMenuListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 507 */           String str = this.this$0.currnode.getPath();
/*     */           
/* 509 */           if (!(this.this$0.currnode instanceof inetsoft.uql.XSequenceNode)) {
/* 510 */             str = str + "." + param1ActionEvent.getActionCommand();
/*     */           }
/*     */           
/* 513 */           XTypeNode xTypeNode = this.this$0.xtype.getTypeNode(str);
/* 514 */           XNode xNode = xTypeNode.newInstance();
/* 515 */           this.this$0.currnode.addChild(xNode);
/* 516 */           this.this$0.treemodel.treeChanged(this.this$0.currnode);
/*     */         }
/*     */         
/*     */         private final XEditPane this$0;
/*     */       };
/* 521 */     this.addListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 523 */           if (this.this$0.currnode instanceof inetsoft.uql.XSequenceNode) {
/* 524 */             XTypeNode xTypeNode = this.this$0.xtype.getTypeNode(this.this$0.currnode.getPath());
/* 525 */             this.this$0.currnode.addChild(xTypeNode.newInstance());
/* 526 */             this.this$0.treemodel.treeChanged(this.this$0.currnode);
/*     */           } 
/*     */         }
/*     */         
/*     */         private final XEditPane this$0;
/*     */       };
/* 532 */     this.removeListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 534 */           if (this.this$0.currnode != null && this.this$0.currnode.getParent() != null) {
/* 535 */             XNode xNode = this.this$0.currnode.getParent();
/* 536 */             xNode.removeChild(this.this$0.currnode);
/* 537 */             this.this$0.treemodel.treeChanged(xNode);
/*     */           } 
/*     */         }
/*     */         
/*     */         private final XEditPane this$0;
/*     */       };
/* 543 */     this.changeListener = new FieldChangeListener(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 574 */     this.setListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 576 */           if (this.this$0.currnode == null) {
/*     */             return;
/*     */           }
/*     */ 
/*     */           
/* 581 */           Object object = this.this$0.currnode.getValue();
/* 582 */           Date date = null;
/*     */           
/* 584 */           if (this.this$0.varCB.isSelected()) {
/* 585 */             if (this.this$0.varTF.getText().trim().length() == 0) {
/* 586 */               JOptionPane.showMessageDialog(this.this$0, XEditPane.msg1);
/*     */               
/*     */               return;
/*     */             } 
/* 590 */             object = ((XValueNode)this.this$0.currnode).getVariable();
/* 591 */             date = this.this$0.varTF.getText();
/* 592 */             ((XValueNode)this.this$0.currnode).setVariable(this.this$0.varTF.getText());
/*     */           }
/* 594 */           else if (this.this$0.nullCB.isSelected()) {
/* 595 */             this.this$0.currnode.setValue(null);
/*     */           }
/* 597 */           else if (this.this$0.currnode instanceof inetsoft.uql.schema.EnumValue) {
/* 598 */             Object object1; this.this$0.currnode.setValue(object1 = this.this$0.enumCB.getSelectedItem());
/*     */           }
/* 600 */           else if (this.this$0.currnode instanceof BooleanValue) {
/* 601 */             Boolean bool; this.this$0.currnode.setValue(bool = new Boolean(this.this$0.booleanCB.isSelected()));
/*     */           }
/* 603 */           else if (this.this$0.currnode instanceof inetsoft.uql.schema.DateValue) {
/* 604 */             Date date1; this.this$0.currnode.setValue(date1 = this.this$0.dateCB.getDate());
/*     */           }
/* 606 */           else if (this.this$0.currnode instanceof DoubleValue) {
/* 607 */             Double double; this.this$0.currnode.setValue(double = new Double(this.this$0.doubleTF.doubleValue()));
/*     */           }
/* 609 */           else if (this.this$0.currnode instanceof FloatValue) {
/* 610 */             Float float; this.this$0.currnode.setValue(float = new Float(this.this$0.floatTF.floatValue()));
/*     */           }
/* 612 */           else if (this.this$0.currnode instanceof CharacterValue) {
/* 613 */             String str = this.this$0.charTF.getText();
/* 614 */             char c = (str.length() > 0) ? str.charAt(0) : 0; Character character;
/* 615 */             this.this$0.currnode.setValue(character = new Character(c));
/*     */           }
/* 617 */           else if (this.this$0.currnode instanceof ByteValue) {
/* 618 */             Byte byte; this.this$0.currnode.setValue(byte = new Byte((byte)this.this$0.byteTF.intValue()));
/*     */           }
/* 620 */           else if (this.this$0.currnode instanceof ShortValue) {
/* 621 */             Short short; this.this$0.currnode.setValue(short = new Short((short)this.this$0.shortTF.intValue()));
/*     */           }
/* 623 */           else if (this.this$0.currnode instanceof IntegerValue) {
/* 624 */             Integer integer; this.this$0.currnode.setValue(integer = new Integer(this.this$0.integerTF.intValue()));
/*     */           }
/* 626 */           else if (this.this$0.currnode instanceof LongValue) {
/* 627 */             Long long; this.this$0.currnode.setValue(long = new Long(this.this$0.longTF.longValue()));
/*     */           }
/* 629 */           else if (this.this$0.currnode instanceof inetsoft.uql.schema.StringValue) {
/* 630 */             this.this$0.currnode.setValue(date = this.this$0.stringTF.getText());
/*     */           }
/* 632 */           else if (this.this$0.currnode instanceof inetsoft.uql.schema.TimeInstantValue) {
/* 633 */             Date date1; this.this$0.currnode.setValue(date1 = this.this$0.datetimeCB.getDate());
/*     */           }
/* 635 */           else if (this.this$0.currnode instanceof inetsoft.uql.schema.TimeValue) {
/* 636 */             this.this$0.currnode.setValue(date = this.this$0.timeSP.getDate());
/*     */           } 
/*     */           
/* 639 */           if ((object == null && date != null) || (object != null && date == null) || (object != null && date != null && !object.equals(date)))
/*     */           {
/* 641 */             this.this$0.treemodel.treeChanged(this.this$0.currnode); } 
/*     */         }
/*     */         
/*     */         private final XEditPane this$0;
/*     */       };
/* 646 */     this.varListener = new ItemListener(this) {
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 648 */           boolean bool = (this.this$0.currnode instanceof XValueNode && ((XValueNode)this.this$0.currnode).getVariable() != null) ? 1 : 0;
/*     */ 
/*     */           
/* 651 */           if (this.this$0.varCB.isSelected() != bool) {
/* 652 */             if (!this.this$0.varCB.isSelected()) {
/* 653 */               ((XValueNode)this.this$0.currnode).setVariable(null);
/*     */             } else {
/*     */               
/* 656 */               ((XValueNode)this.this$0.currnode).setVariable("");
/* 657 */               this.this$0.nullCB.setSelected(false);
/*     */             } 
/*     */             
/* 660 */             this.this$0.showEditor();
/*     */           } 
/*     */         }
/*     */         private final XEditPane this$0;
/*     */       };
/* 665 */     this.nullListener = new ItemListener(this) {
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/* 667 */           if (this.this$0.nullCB.isSelected()) {
/* 668 */             this.this$0.varCB.setSelected(false);
/*     */           }
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         private final XEditPane this$0;
/*     */       };
/* 676 */     this.currnode = null;
/* 677 */     this.currtype = null;
/*     */     
/* 679 */     this.listeners = new Vector();
/* 680 */     this.changed = false;
/*     */     
/* 682 */     this.varTF = new JTextField(10);
/* 683 */     this.stringTF = new JTextField(10);
/* 684 */     this.booleanCB = new JCheckBox("");
/* 685 */     this.floatTF = new NumField(5, false);
/* 686 */     this.doubleTF = new NumField(5, false);
/* 687 */     this.charTF = new JTextField(1);
/* 688 */     this.byteTF = new NumField(5, true);
/* 689 */     this.shortTF = new NumField(5, true);
/* 690 */     this.integerTF = new NumField(5, true);
/* 691 */     this.longTF = new NumField(5, true);
/* 692 */     this.datetimeCB = new DateTimeCombo();
/* 693 */     this.dateCB = new DateCombo();
/* 694 */     this.timeSP = new TimeSpinner();
/* 695 */     this.enumCB = new JComboBox();
/* 696 */     this.setPnl = new JPanel();
/* 697 */     this.varCB = new JCheckBox(Catalog.getString("Variable"));
/* 698 */     this.nullCB = new JCheckBox(Catalog.getString("null"));
/* 699 */     this.setB = new JButton(Catalog.getString("Set"));
/*     */     
/* 701 */     this.addB = new JButton(Catalog.getString("Add"));
/* 702 */     this.removeB = new JButton(Catalog.getString("Remove"));
/* 703 */     this.addChildB = new JButton(Catalog.getString("Add Child"));
/* 704 */     this.editorLO = new CardLayout();
/* 705 */     this.editorPane = new JPanel();
/* 706 */     this.tree = new JTree(new Object[0]);
/*     */     
/* 708 */     this.childMenu = null;
/*     */     setLayout(new BorderLayout());
/*     */     JPanel jPanel1 = new JPanel();
/*     */     jPanel1.setLayout(new BorderLayout());
/*     */     this.spliter = new JSplitPane(1, new JScrollPane(this.tree), jPanel1);
/*     */     this.spliter.setPreferredSize(new Dimension(450, 200));
/*     */     this.spliter.setMinimumSize(new Dimension(450, 200));
/*     */     this.spliter.setDividerLocation(250);
/*     */     add(this.spliter, "Center");
/*     */     Grid2Layout grid2Layout = new Grid2Layout(new Insets(5, 5, 5, 5));
/*     */     JPanel jPanel2 = new JPanel();
/*     */     jPanel2.setLayout(grid2Layout);
/*     */     JPanel jPanel3 = new JPanel();
/*     */     jPanel3.setLayout(new BorderLayout());
/*     */     jPanel3.setBorder(new TitledBorder(Catalog.getString("Value")));
/*     */     jPanel3.add(this.editorPane, "North");
/*     */     this.setPnl.add(this.nullCB);
/*     */     this.setPnl.add(this.varCB);
/*     */     this.setPnl.add(this.setB);
/*     */     this.setB.addActionListener(this.setListener);
/*     */     this.setPnl.setVisible(false);
/*     */     jPanel3.add(this.setPnl, "South");
/*     */     jPanel1.add(jPanel3, "North");
/*     */     jPanel2.add(this.addB, grid2Layout.at(0, 0, 1, 1, 1));
/*     */     jPanel2.add(this.removeB, grid2Layout.at(0, 1, 1, 1, 1));
/*     */     jPanel2.add(this.addChildB, grid2Layout.at(1, 0, 1, 2, 1));
/*     */     jPanel1.add(jPanel2, "South");
/*     */     this.editorPane.setLayout(this.editorLO);
/*     */     this.editorPane.add(new JLabel(" "), "null");
/*     */     this.editorPane.add(this.stringTF, "string");
/*     */     this.editorPane.add(this.booleanCB, "boolean");
/*     */     this.editorPane.add(this.floatTF, "float");
/*     */     this.editorPane.add(this.doubleTF, "double");
/*     */     this.editorPane.add(this.charTF, "char");
/*     */     this.editorPane.add(this.byteTF, "byte");
/*     */     this.editorPane.add(this.shortTF, "short");
/*     */     this.editorPane.add(this.integerTF, "integer");
/*     */     this.editorPane.add(this.longTF, "long");
/*     */     this.editorPane.add(this.datetimeCB, "timeInstant");
/*     */     this.editorPane.add(this.dateCB, "date");
/*     */     this.editorPane.add(this.timeSP, "time");
/*     */     this.editorPane.add(this.enumCB, "enum");
/*     */     JPanel jPanel4 = new JPanel();
/*     */     jPanel4.setLayout(new BorderLayout(0, 0));
/*     */     jPanel4.add(new JLabel("$("), "West");
/*     */     jPanel4.add(this.varTF, "Center");
/*     */     jPanel4.add(new JLabel(")"), "East");
/*     */     this.editorPane.add(jPanel4, "variable");
/*     */     this.tree.setRootVisible(false);
/*     */     this.tree.setShowsRootHandles(true);
/*     */     this.tree.addTreeSelectionListener(this.treeListener);
/*     */     ImageIcon imageIcon = new ImageIcon(getClass().getResource("images/trigger.gif"));
/*     */     this.addChildB.setIcon(imageIcon);
/*     */     this.addChildB.setHorizontalTextPosition(2);
/*     */     this.addChildB.addActionListener(this.addChildListener);
/*     */     this.removeB.addActionListener(this.removeListener);
/*     */     this.addB.addActionListener(this.addListener);
/*     */     this.varTF.addActionListener(this.setListener);
/*     */     this.stringTF.addActionListener(this.setListener);
/*     */     this.floatTF.addActionListener(this.setListener);
/*     */     this.doubleTF.addActionListener(this.setListener);
/*     */     this.charTF.addActionListener(this.setListener);
/*     */     this.byteTF.addActionListener(this.setListener);
/*     */     this.shortTF.addActionListener(this.setListener);
/*     */     this.integerTF.addActionListener(this.setListener);
/*     */     this.longTF.addActionListener(this.setListener);
/*     */     this.booleanCB.addActionListener(this.setListener);
/*     */     this.datetimeCB.addActionListener(this.setListener);
/*     */     this.dateCB.addActionListener(this.setListener);
/*     */     this.timeSP.addActionListener(this.setListener);
/*     */     this.enumCB.addActionListener(this.setListener);
/*     */     this.varCB.addItemListener(this.varListener);
/*     */     this.nullCB.addItemListener(this.nullListener);
/*     */     this.varTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.stringTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.floatTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.doubleTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.charTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.byteTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.shortTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.integerTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.longTF.getDocument().addDocumentListener(this.changeListener);
/*     */     this.datetimeCB.addActionListener(this.changeListener);
/*     */     this.dateCB.addActionListener(this.changeListener);
/*     */     this.booleanCB.addActionListener(this.changeListener);
/*     */     this.timeSP.addTextListener(this.changeListener);
/*     */     this.enumCB.addItemListener(this.changeListener);
/*     */     setEnabled();
/*     */   }
/*     */   
/*     */   public void setType(XTypeNode paramXTypeNode) { this.xtype = paramXTypeNode; }
/*     */   
/*     */   public void setValue(XNode paramXNode) {
/*     */     this.root = paramXNode;
/*     */     this.tree.setModel(this.treemodel = new XTreeModel(this));
/*     */     this.tree.setRootVisible((paramXNode != null));
/*     */     this.changed = false;
/*     */   }
/*     */   
/*     */   public XNode getValue() { return this.root; }
/*     */   
/*     */   void setCurrent(XNode paramXNode) {
/*     */     if (this.currnode != null && this.currnode instanceof XValueNode)
/*     */       this.setListener.actionPerformed(null); 
/*     */     this.currnode = paramXNode;
/*     */     if (this.currnode == null) {
/*     */       this.childMenu = null;
/*     */     } else {
/*     */       this.currtype = this.xtype.getTypeNode(paramXNode.getPath());
/*     */       if (this.currtype == null)
/*     */         throw new RuntimeException("Internal Error: type not found: " + paramXNode.getPath()); 
/*     */       Vector vector = getAddList(this.currnode, this.currtype);
/*     */       if (vector.size() == 0) {
/*     */         this.childMenu = null;
/*     */       } else {
/*     */         this.childMenu = new JPopupMenu();
/*     */         for (byte b = 0; b < vector.size(); b++) {
/*     */           JMenuItem jMenuItem = new JMenuItem((String)vector.elementAt(b));
/*     */           jMenuItem.addActionListener(this.addChildMenuListener);
/*     */           this.childMenu.add(jMenuItem);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     this.setPnl.setVisible(true);
/*     */     setEnabled();
/*     */     showEditor();
/*     */   }
/*     */   
/*     */   public void setEnableStructureChange(boolean paramBoolean) {
/*     */     this.addB.setVisible(paramBoolean);
/*     */     this.removeB.setVisible(paramBoolean);
/*     */     this.addChildB.setVisible(paramBoolean);
/*     */   }
/*     */   
/*     */   private void showEditor() {
/*     */     if (this.currnode == null || !(this.currnode instanceof XValueNode)) {
/*     */       this.editorLO.show(this.editorPane, "null");
/*     */       this.setPnl.setVisible(false);
/*     */       return;
/*     */     } 
/*     */     Object object = this.currnode.getValue();
/*     */     XValueNode xValueNode = (XValueNode)this.currnode;
/*     */     this.nullCB.setSelected(false);
/*     */     if (xValueNode.getVariable() != null) {
/*     */       this.editorLO.show(this.editorPane, "variable");
/*     */       this.varTF.setText(xValueNode.getVariable());
/*     */       this.varCB.setSelected(true);
/*     */       return;
/*     */     } 
/*     */     this.varCB.setSelected(false);
/*     */     this.editorLO.show(this.editorPane, xValueNode.getType());
/*     */     XTypeNode xTypeNode = (this.currtype instanceof UserDefinedType) ? ((UserDefinedType)this.currtype).getUserType() : this.currtype;
/*     */     if (xTypeNode instanceof EnumType) {
/*     */       String[] arrayOfString = ((EnumType)xTypeNode).getEnums();
/*     */       this.enumCB.setModel(new DefaultComboBoxModel(arrayOfString));
/*     */     } 
/*     */     if (object == null) {
/*     */       this.nullCB.setSelected(true);
/*     */     } else if (this.currnode instanceof inetsoft.uql.schema.EnumValue) {
/*     */       this.enumCB.setSelectedItem(object);
/*     */     } else if (this.currnode instanceof BooleanValue) {
/*     */       this.booleanCB.setSelected(((BooleanValue)this.currnode).booleanValue());
/*     */     } else if (this.currnode instanceof inetsoft.uql.schema.DateValue) {
/*     */       this.dateCB.setDate((object == null) ? new Date() : (Date)object);
/*     */     } else if (this.currnode instanceof DoubleValue) {
/*     */       this.doubleTF.setValue(((DoubleValue)this.currnode).doubleValue());
/*     */     } else if (this.currnode instanceof FloatValue) {
/*     */       this.floatTF.setValue(((FloatValue)this.currnode).floatValue());
/*     */     } else if (this.currnode instanceof CharacterValue) {
/*     */       this.charTF.setText(((CharacterValue)this.currnode).charValue() + "");
/*     */     } else if (this.currnode instanceof ByteValue) {
/*     */       this.byteTF.setValue(((ByteValue)this.currnode).byteValue());
/*     */     } else if (this.currnode instanceof ShortValue) {
/*     */       this.shortTF.setValue(((ShortValue)this.currnode).shortValue());
/*     */     } else if (this.currnode instanceof IntegerValue) {
/*     */       this.integerTF.setValue(((IntegerValue)this.currnode).intValue());
/*     */     } else if (this.currnode instanceof LongValue) {
/*     */       this.longTF.setValue(((LongValue)this.currnode).longValue());
/*     */     } else if (this.currnode instanceof inetsoft.uql.schema.StringValue) {
/*     */       this.stringTF.setText((object == null) ? "" : (String)object);
/*     */     } else if (this.currnode instanceof inetsoft.uql.schema.TimeInstantValue) {
/*     */       this.datetimeCB.setDate((object == null) ? new Date() : (Date)object);
/*     */     } else if (this.currnode instanceof inetsoft.uql.schema.TimeValue) {
/*     */       this.timeSP.setDate((object == null) ? new Date() : (Date)object);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addChangeListener(ChangeListener paramChangeListener) { this.listeners.addElement(paramChangeListener); }
/*     */   
/*     */   public void removeChangeListener(ChangeListener paramChangeListener) { this.listeners.removeElement(paramChangeListener); }
/*     */   
/*     */   protected void valueChanged() {
/*     */     this.changed = true;
/*     */     for (byte b = 0; b < this.listeners.size(); b++)
/*     */       ((ChangeListener)this.listeners.elementAt(b)).stateChanged(new ChangeEvent(this)); 
/*     */   }
/*     */   
/*     */   public void setValueChanged(boolean paramBoolean) { this.changed = paramBoolean; }
/*     */   
/*     */   public boolean isValueChanged() { return this.changed; }
/*     */   
/*     */   public void setEnabled(boolean paramBoolean) {
/*     */     this.stringTF.setEnabled(paramBoolean);
/*     */     this.booleanCB.setEnabled(paramBoolean);
/*     */     this.floatTF.setEnabled(paramBoolean);
/*     */     this.doubleTF.setEnabled(paramBoolean);
/*     */     this.charTF.setEnabled(paramBoolean);
/*     */     this.byteTF.setEnabled(paramBoolean);
/*     */     this.shortTF.setEnabled(paramBoolean);
/*     */     this.integerTF.setEnabled(paramBoolean);
/*     */     this.longTF.setEnabled(paramBoolean);
/*     */     this.datetimeCB.setEnabled(paramBoolean);
/*     */     this.dateCB.setEnabled(paramBoolean);
/*     */     this.timeSP.setEnabled(paramBoolean);
/*     */     this.enumCB.setEnabled(paramBoolean);
/*     */     this.varCB.setEnabled(paramBoolean);
/*     */     this.nullCB.setEnabled(paramBoolean);
/*     */     this.setB.setEnabled(paramBoolean);
/*     */     this.addB.setEnabled(paramBoolean);
/*     */     this.removeB.setEnabled(paramBoolean);
/*     */     this.addChildB.setEnabled(paramBoolean);
/*     */     this.tree.setEnabled(paramBoolean);
/*     */     if (paramBoolean)
/*     */       setEnabled(); 
/*     */   }
/*     */   
/*     */   private void setEnabled() {
/*     */     XTypeNode xTypeNode = (this.currnode == null) ? null : this.xtype.getTypeNode(this.currnode.getPath());
/*     */     this.removeB.setEnabled((this.currnode != null && this.currnode.getParent() != null && xTypeNode != null && xTypeNode.getMinOccurs() == 0 && !(this.currnode instanceof inetsoft.uql.XSequenceNode)));
/*     */     this.addB.setEnabled((this.currnode != null && this.currnode instanceof inetsoft.uql.XSequenceNode));
/*     */     this.addChildB.setEnabled((this.childMenu != null));
/*     */   }
/*     */   
/*     */   private Vector getAddList(XNode paramXNode, XTypeNode paramXTypeNode) {
/*     */     Vector vector = new Vector();
/*     */     if (paramXNode instanceof inetsoft.uql.XSequenceNode) {
/*     */       if (paramXNode.getChildCount() < paramXTypeNode.getMaxOccurs())
/*     */         vector.addElement(paramXTypeNode.getName()); 
/*     */     } else {
/*     */       for (byte b = 0; b < paramXTypeNode.getChildCount(); b++) {
/*     */         XTypeNode xTypeNode = (XTypeNode)paramXTypeNode.getChild(b);
/*     */         if (xTypeNode.getMaxOccurs() > 1 || paramXNode.getChild(xTypeNode.getName()) == null)
/*     */           vector.addElement(xTypeNode.getName()); 
/*     */       } 
/*     */     } 
/*     */     return vector;
/*     */   }
/*     */   
/*     */   class XTreeModel implements TreeModel {
/*     */     protected EventListenerList listenerList;
/*     */     private final XEditPane this$0;
/*     */     
/*     */     XTreeModel(XEditPane this$0) {
/*     */       this.this$0 = this$0;
/*     */       this.listenerList = new EventListenerList();
/*     */     }
/*     */     
/*     */     public Object getRoot() { return this.this$0.root; }
/*     */     
/*     */     public Object getChild(Object param1Object, int param1Int) { return ((XNode)param1Object).getChild(param1Int); }
/*     */     
/*     */     public int getChildCount(Object param1Object) { return ((XNode)param1Object).getChildCount(); }
/*     */     
/*     */     public boolean isLeaf(Object param1Object) { return (((XNode)param1Object).getChildCount() == 0); }
/*     */     
/*     */     public void valueForPathChanged(TreePath param1TreePath, Object param1Object) {}
/*     */     
/*     */     public int getIndexOfChild(Object param1Object1, Object param1Object2) { return ((XNode)param1Object1).getChildIndex((XNode)param1Object2); }
/*     */     
/*     */     public void addTreeModelListener(TreeModelListener param1TreeModelListener) { this.listenerList.add(TreeModelListener.class, param1TreeModelListener); }
/*     */     
/*     */     public void removeTreeModelListener(TreeModelListener param1TreeModelListener) { this.listenerList.remove(TreeModelListener.class, param1TreeModelListener); }
/*     */     
/*     */     public Object[] getTreePath(XNode param1XNode) {
/*     */       Vector vector = new Vector();
/*     */       for (; param1XNode != null; param1XNode = param1XNode.getParent())
/*     */         vector.insertElementAt(param1XNode, 0); 
/*     */       Object[] arrayOfObject = new Object[vector.size()];
/*     */       vector.copyInto(arrayOfObject);
/*     */       return arrayOfObject;
/*     */     }
/*     */     
/*     */     public void treeChanged(XNode param1XNode) {
/*     */       Object[] arrayOfObject = this.listenerList.getListenerList();
/*     */       TreeModelEvent treeModelEvent = null;
/*     */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/*     */         if (arrayOfObject[i] == TreeModelListener.class) {
/*     */           if (treeModelEvent == null)
/*     */             treeModelEvent = new TreeModelEvent(this, getTreePath(param1XNode), null, null); 
/*     */           ((TreeModelListener)arrayOfObject[i + 1]).treeStructureChanged(treeModelEvent);
/*     */         } 
/*     */       } 
/*     */       this.this$0.valueChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   class FieldChangeListener implements DocumentListener, ActionListener, TextListener, ItemListener {
/*     */     private final XEditPane this$0;
/*     */     
/*     */     FieldChangeListener(XEditPane this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public void textValueChanged(TextEvent param1TextEvent) { actionPerformed(null); }
/*     */     
/*     */     public void insertUpdate(DocumentEvent param1DocumentEvent) { actionPerformed(null); }
/*     */     
/*     */     public void removeUpdate(DocumentEvent param1DocumentEvent) { actionPerformed(null); }
/*     */     
/*     */     public void changedUpdate(DocumentEvent param1DocumentEvent) { actionPerformed(null); }
/*     */     
/*     */     public void itemStateChanged(ItemEvent param1ItemEvent) { actionPerformed(null); }
/*     */     
/*     */     public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.nullCB.setSelected(false); }
/*     */   }
/*     */   static final String msg1 = Catalog.getString("Variable name can't be empty!");
/*     */   XTypeNode xtype;
/*     */   XNode root;
/*     */   XNode currnode;
/*     */   XTypeNode currtype;
/*     */   XTreeModel treemodel;
/*     */   Vector listeners;
/*     */   boolean changed;
/*     */   JTextField varTF;
/*     */   JTextField stringTF;
/*     */   JCheckBox booleanCB;
/*     */   NumField floatTF;
/*     */   NumField doubleTF;
/*     */   JTextField charTF;
/*     */   NumField byteTF;
/*     */   NumField shortTF;
/*     */   NumField integerTF;
/*     */   NumField longTF;
/*     */   DateTimeCombo datetimeCB;
/*     */   DateCombo dateCB;
/*     */   TimeSpinner timeSP;
/*     */   JComboBox enumCB;
/*     */   JPanel setPnl;
/*     */   JCheckBox varCB;
/*     */   JCheckBox nullCB;
/*     */   JButton setB;
/*     */   JButton addB;
/*     */   JButton removeB;
/*     */   JButton addChildB;
/*     */   CardLayout editorLO;
/*     */   JPanel editorPane;
/*     */   JTree tree;
/*     */   JSplitPane spliter;
/*     */   JPopupMenu childMenu;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\XEditPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */