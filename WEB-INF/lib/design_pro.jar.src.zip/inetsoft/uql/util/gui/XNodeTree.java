/*     */ package inetsoft.uql.util.gui;
/*     */ 
/*     */ import inetsoft.uql.XNode;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.event.EventListenerList;
/*     */ import javax.swing.event.TreeModelEvent;
/*     */ import javax.swing.event.TreeModelListener;
/*     */ import javax.swing.tree.TreeModel;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XNodeTree
/*     */   extends JTree
/*     */ {
/*     */   XNode root;
/*     */   XTreeModel treemodel;
/*     */   
/*  37 */   public XNodeTree() { super(new Object[0]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoot(XNode paramXNode) {
/*  44 */     this.root = paramXNode;
/*  45 */     setModel(this.treemodel = new XTreeModel(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public XNode getRoot() { return this.root; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XNode getSelectedNode() {
/*  59 */     Object object = getLastSelectedPathComponent();
/*  60 */     return (XNode)object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XNode[] getSelectedNodes() {
/*  67 */     TreePath[] arrayOfTreePath = getSelectionPaths();
/*  68 */     XNode[] arrayOfXNode = new XNode[arrayOfTreePath.length];
/*     */     
/*  70 */     for (byte b = 0; b < arrayOfXNode.length; b++) {
/*  71 */       arrayOfXNode[b] = (XNode)arrayOfTreePath[b].getLastPathComponent();
/*     */     }
/*     */     
/*  74 */     return arrayOfXNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSelectedNode(XNode paramXNode) {
/*  81 */     Vector vector = new Vector();
/*  82 */     for (; paramXNode != null; paramXNode = paramXNode.getParent()) {
/*  83 */       vector.insertElementAt(paramXNode, 0);
/*     */     }
/*     */     
/*  86 */     Object[] arrayOfObject = new Object[vector.size()];
/*  87 */     vector.copyInto(arrayOfObject);
/*  88 */     addSelectionPath(new TreePath(arrayOfObject));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandAll() {
/*  95 */     for (byte b = 0; b < getRowCount(); b++)
/*  96 */       expandRow(b); 
/*     */   } class XTreeModel implements TreeModel { protected EventListenerList listenerList; private final XNodeTree this$0;
/*     */     public Object getRoot() { return this.this$0.root; }
/*     */     public Object getChild(Object param1Object, int param1Int) { return ((XNode)param1Object).getChild(param1Int); }
/*     */     XTreeModel(XNodeTree this$0) {
/* 101 */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 125 */       this.listenerList = new EventListenerList();
/*     */     } public int getChildCount(Object param1Object) { return ((XNode)param1Object).getChildCount(); }
/* 127 */     public void addTreeModelListener(TreeModelListener param1TreeModelListener) { this.listenerList.add(TreeModelListener.class, param1TreeModelListener); }
/*     */     public boolean isLeaf(Object param1Object) { return (((XNode)param1Object).getChildCount() == 0); }
/*     */     public void valueForPathChanged(TreePath param1TreePath, Object param1Object) {}
/*     */     public int getIndexOfChild(Object param1Object1, Object param1Object2) { return ((XNode)param1Object1).getChildIndex((XNode)param1Object2); }
/* 131 */     public void removeTreeModelListener(TreeModelListener param1TreeModelListener) { this.listenerList.remove(TreeModelListener.class, param1TreeModelListener); }
/*     */ 
/*     */     
/*     */     public Object[] getTreePath(XNode param1XNode) {
/* 135 */       Vector vector = new Vector();
/* 136 */       for (; param1XNode != null; param1XNode = param1XNode.getParent()) {
/* 137 */         vector.insertElementAt(param1XNode, 0);
/*     */       }
/*     */       
/* 140 */       Object[] arrayOfObject = new Object[vector.size()];
/* 141 */       vector.copyInto(arrayOfObject);
/* 142 */       return arrayOfObject;
/*     */     }
/*     */ 
/*     */     
/*     */     public void treeChanged(XNode param1XNode) {
/* 147 */       Object[] arrayOfObject = this.listenerList.getListenerList();
/* 148 */       TreeModelEvent treeModelEvent = null;
/*     */ 
/*     */       
/* 151 */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 152 */         if (arrayOfObject[i] == TreeModelListener.class) {
/*     */           
/* 154 */           if (treeModelEvent == null)
/* 155 */             treeModelEvent = new TreeModelEvent(this, getTreePath(param1XNode), null, null); 
/* 156 */           ((TreeModelListener)arrayOfObject[i + 1]).treeStructureChanged(treeModelEvent);
/*     */         } 
/*     */       } 
/*     */     } }
/*     */ 
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\XNodeTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */