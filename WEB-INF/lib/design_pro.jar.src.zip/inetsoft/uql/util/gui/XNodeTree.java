package inetsoft.uql.util.gui;

import inetsoft.uql.XNode;
import java.util.Vector;
import javax.swing.JTree;
import javax.swing.event.EventListenerList;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

public class XNodeTree extends JTree {
  XNode root;
  
  XTreeModel treemodel;
  
  public XNodeTree() { super(new Object[0]); }
  
  public void setRoot(XNode paramXNode) {
    this.root = paramXNode;
    setModel(this.treemodel = new XTreeModel(this));
  }
  
  public XNode getRoot() { return this.root; }
  
  public XNode getSelectedNode() {
    Object object = getLastSelectedPathComponent();
    return (XNode)object;
  }
  
  public XNode[] getSelectedNodes() {
    TreePath[] arrayOfTreePath = getSelectionPaths();
    XNode[] arrayOfXNode = new XNode[arrayOfTreePath.length];
    for (byte b = 0; b < arrayOfXNode.length; b++)
      arrayOfXNode[b] = (XNode)arrayOfTreePath[b].getLastPathComponent(); 
    return arrayOfXNode;
  }
  
  public void addSelectedNode(XNode paramXNode) {
    Vector vector = new Vector();
    for (; paramXNode != null; paramXNode = paramXNode.getParent())
      vector.insertElementAt(paramXNode, 0); 
    Object[] arrayOfObject = new Object[vector.size()];
    vector.copyInto(arrayOfObject);
    addSelectionPath(new TreePath(arrayOfObject));
  }
  
  public void expandAll() {
    for (byte b = 0; b < getRowCount(); b++)
      expandRow(b); 
  }
  
  class XTreeModel implements TreeModel {
    protected EventListenerList listenerList;
    
    private final XNodeTree this$0;
    
    XTreeModel(XNodeTree this$0) {
      this.this$0 = this$0;
      this.listenerList = new EventListenerList();
    }
    
    public Object getRoot() { return this.this$0.root; }
    
    public Object getChild(Object param1Object, int param1Int) { return ((XNode)param1Object).getChild(param1Int); }
    
    public int getChildCount(Object param1Object) { return ((XNode)param1Object).getChildCount(); }
    
    public boolean isLeaf(Object param1Object) { return (((XNode)param1Object).getChildCount() == 0); }
    
    public void valueForPathChanged(TreePath param1TreePath, Object param1Object) {}
    
    public int getIndexOfChild(Object param1Object1, Object param1Object2) { return ((XNode)param1Object1).getChildIndex((XNode)param1Object2); }
    
    public void addTreeModelListener(TreeModelListener param1TreeModelListener) { this.listenerList.add(TreeModelListener.class, param1TreeModelListener); }
    
    public void removeTreeModelListener(TreeModelListener param1TreeModelListener) { this.listenerList.remove(TreeModelListener.class, param1TreeModelListener); }
    
    public Object[] getTreePath(XNode param1XNode) {
      Vector vector = new Vector();
      for (; param1XNode != null; param1XNode = param1XNode.getParent())
        vector.insertElementAt(param1XNode, 0); 
      Object[] arrayOfObject = new Object[vector.size()];
      vector.copyInto(arrayOfObject);
      return arrayOfObject;
    }
    
    public void treeChanged(XNode param1XNode) {
      Object[] arrayOfObject = this.listenerList.getListenerList();
      TreeModelEvent treeModelEvent = null;
      for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
        if (arrayOfObject[i] == TreeModelListener.class) {
          if (treeModelEvent == null)
            treeModelEvent = new TreeModelEvent(this, getTreePath(param1XNode), null, null); 
          ((TreeModelListener)arrayOfObject[i + 1]).treeStructureChanged(treeModelEvent);
        } 
      } 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\XNodeTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */