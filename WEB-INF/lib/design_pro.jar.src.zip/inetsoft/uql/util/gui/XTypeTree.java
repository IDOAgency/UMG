/*     */ package inetsoft.uql.util.gui;
/*     */ 
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.path.XNodePath;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import java.awt.Component;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.event.EventListenerList;
/*     */ import javax.swing.event.TreeModelEvent;
/*     */ import javax.swing.event.TreeModelListener;
/*     */ import javax.swing.tree.DefaultTreeCellRenderer;
/*     */ import javax.swing.tree.TreeModel;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XTypeTree
/*     */   extends JTree
/*     */ {
/*     */   XTypeNode xtype;
/*     */   XTreeModel treemodel;
/*     */   XNodePath xpath;
/*     */   Hashtable pathmap;
/*     */   static ImageIcon pathicon;
/*     */   static ImageIcon path2icon;
/*     */   
/*     */   public XTypeTree() {
/*  37 */     super(new Object[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 212 */     this.xpath = null;
/* 213 */     this.pathmap = new Hashtable();
/*     */     setRootVisible(false);
/*     */     setCellRenderer(new CellRenderer(this)); } static  {
/*     */     try {
/* 217 */       pathicon = new ImageIcon(XTypeTree.class.getResource("images/pathnode.gif"));
/*     */       
/* 219 */       path2icon = new ImageIcon(XTypeTree.class.getResource("images/pathnode2.gif"));
/*     */     } catch (Exception exception) {
/*     */       
/* 222 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setType(XTypeNode paramXTypeNode) {
/*     */     this.xtype = (paramXTypeNode != null) ? paramXTypeNode : new XTypeNode();
/*     */     setRootVisible((paramXTypeNode != null));
/*     */     setModel(this.treemodel = new XTreeModel(this));
/*     */   }
/*     */   
/*     */   public void setNodePath(XNodePath paramXNodePath) {
/*     */     this.xpath = paramXNodePath;
/*     */     this.pathmap.clear();
/*     */     if (paramXNodePath != null) {
/*     */       String str = paramXNodePath.getPath(null);
/*     */       XNode xNode = this.xtype.getNode(str.toString());
/*     */       if (xNode != null)
/*     */         expandPath(new TreePath(this.treemodel.getTreePath(xNode))); 
/*     */     } 
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public void treeChanged(XNode paramXNode) {
/*     */     if (this.treemodel != null)
/*     */       this.treemodel.treeChanged(paramXNode); 
/*     */   }
/*     */   
/*     */   public XTypeNode getSelectedNode() {
/*     */     Object object = getLastSelectedPathComponent();
/*     */     return (XTypeNode)object;
/*     */   }
/*     */   
/*     */   class XTreeModel implements TreeModel {
/*     */     protected EventListenerList listenerList;
/*     */     private final XTypeTree this$0;
/*     */     
/*     */     XTreeModel(XTypeTree this$0) {
/*     */       this.this$0 = this$0;
/*     */       this.listenerList = new EventListenerList();
/*     */     }
/*     */     
/*     */     public Object getRoot() { return this.this$0.xtype; }
/*     */     
/*     */     public Object getChild(Object param1Object, int param1Int) {
/*     */       XTypeNode xTypeNode = (XTypeNode)param1Object;
/*     */       return xTypeNode.getChild(param1Int);
/*     */     }
/*     */     
/*     */     public int getChildCount(Object param1Object) { return ((XTypeNode)param1Object).getChildCount(); }
/*     */     
/*     */     public boolean isLeaf(Object param1Object) {
/*     */       XTypeNode xTypeNode = (XTypeNode)param1Object;
/*     */       return (xTypeNode == null || xTypeNode.getChildCount() == 0);
/*     */     }
/*     */     
/*     */     public void valueForPathChanged(TreePath param1TreePath, Object param1Object) {}
/*     */     
/*     */     public int getIndexOfChild(Object param1Object1, Object param1Object2) { return ((XNode)param1Object1).getChildIndex((XNode)param1Object2); }
/*     */     
/*     */     public void addTreeModelListener(TreeModelListener param1TreeModelListener) { this.listenerList.add(TreeModelListener.class, param1TreeModelListener); }
/*     */     
/*     */     public void removeTreeModelListener(TreeModelListener param1TreeModelListener) { this.listenerList.remove(TreeModelListener.class, param1TreeModelListener); }
/*     */     
/*     */     public Object[] getTreePath(XNode param1XNode) {
/*     */       Vector vector = new Vector();
/*     */       for (; param1XNode != null; param1XNode = param1XNode.getParent())
/*     */         vector.insertElementAt(param1XNode, 0); 
/*     */       Object[] arrayOfObject = new Object[vector.size()];
/*     */       vector.copyInto(arrayOfObject);
/*     */       return arrayOfObject;
/*     */     }
/*     */     
/*     */     public void treeChanged(XNode param1XNode) {
/*     */       Object[] arrayOfObject = this.listenerList.getListenerList();
/*     */       TreeModelEvent treeModelEvent = null;
/*     */       for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/*     */         if (arrayOfObject[i] == TreeModelListener.class) {
/*     */           if (treeModelEvent == null)
/*     */             treeModelEvent = new TreeModelEvent(this, getTreePath(param1XNode), null, null); 
/*     */           ((TreeModelListener)arrayOfObject[i + 1]).treeStructureChanged(treeModelEvent);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class CellRenderer extends DefaultTreeCellRenderer {
/*     */     Icon over;
/*     */     private final XTypeTree this$0;
/*     */     
/*     */     CellRenderer(XTypeTree this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public Component getTreeCellRendererComponent(JTree param1JTree, Object param1Object, boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, int param1Int, boolean param1Boolean4) {
/*     */       if (param1Object instanceof XTypeNode) {
/*     */         XTypeNode xTypeNode = (XTypeNode)param1Object;
/*     */         Boolean bool = (Boolean)this.this$0.pathmap.get(xTypeNode);
/*     */         if (this.this$0.xpath != null && bool == null)
/*     */           this.this$0.pathmap.put(xTypeNode, bool = new Boolean((this.this$0.xpath.find(this.this$0.xtype, xTypeNode) != null))); 
/*     */         if (this.this$0.xpath != null && bool.booleanValue())
/*     */           if (xTypeNode.getMaxOccurs() > 1 && XTypeTree.path2icon != null) {
/*     */             this.over = XTypeTree.path2icon;
/*     */           } else {
/*     */             this.over = XTypeTree.pathicon;
/*     */           }  
/*     */       } 
/*     */       return super.getTreeCellRendererComponent(param1JTree, param1Object, param1Boolean1, param1Boolean2, param1Boolean3, param1Int, param1Boolean4);
/*     */     }
/*     */     
/*     */     public Icon getLeafIcon() {
/*     */       if (this.over != null) {
/*     */         Icon icon = this.over;
/*     */         this.over = null;
/*     */         return icon;
/*     */       } 
/*     */       return super.getLeafIcon();
/*     */     }
/*     */     
/*     */     public Icon getClosedIcon() {
/*     */       if (this.over != null) {
/*     */         Icon icon = this.over;
/*     */         this.over = null;
/*     */         return icon;
/*     */       } 
/*     */       return super.getClosedIcon();
/*     */     }
/*     */     
/*     */     public Icon getOpenIcon() {
/*     */       if (this.over != null) {
/*     */         Icon icon = this.over;
/*     */         this.over = null;
/*     */         return icon;
/*     */       } 
/*     */       return super.getOpenIcon();
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\XTypeTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */