package inetsoft.uql.util.gui;

import inetsoft.uql.locale.Catalog;
import inetsoft.uql.schema.BooleanValue;
import inetsoft.uql.schema.ByteValue;
import inetsoft.uql.schema.CharacterValue;
import inetsoft.uql.schema.DoubleValue;
import inetsoft.uql.schema.FloatValue;
import inetsoft.uql.schema.IntegerValue;
import inetsoft.uql.schema.LongValue;
import inetsoft.uql.schema.ShortValue;
import inetsoft.uql.schema.XSchema;
import inetsoft.uql.schema.XValueNode;
import inetsoft.util.internal.NumField;
import inetsoft.widget.DateCombo;
import inetsoft.widget.DateTimeCombo;
import inetsoft.widget.TimeSpinner;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Date;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class XValueEditor extends JPanel {
  ItemListener typeListener;
  
  public XValueEditor() {
    this.typeListener = new ItemListener(this) {
        private final XValueEditor this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.editorLO.show(this.this$0.editorPane, (String)this.this$0.typeCB.getSelectedItem()); }
      };
    this.typeCB = new JComboBox(types);
    this.stringTF = new JTextField(10);
    this.booleanCB = new JCheckBox("");
    this.floatTF = new NumField(5, false);
    this.doubleTF = new NumField(5, false);
    this.charTF = new JTextField(1);
    this.byteTF = new NumField(5, true);
    this.shortTF = new NumField(5, true);
    this.integerTF = new NumField(5, true);
    this.longTF = new NumField(5, true);
    this.datetimeCB = new DateTimeCombo();
    this.dateCB = new DateCombo();
    this.timeSP = new TimeSpinner();
    this.editorLO = new CardLayout();
    this.editorPane = new JPanel();
    setLayout(new FlowLayout(0, 10, 2));
    add(this.typeCB);
    add(new JLabel(Catalog.getString("Value") + ":"));
    add(this.editorPane);
    this.editorPane.setLayout(this.editorLO);
    this.editorPane.add(new JLabel(" "), "null");
    this.editorPane.add(this.stringTF, "string");
    this.editorPane.add(this.booleanCB, "boolean");
    this.editorPane.add(this.floatTF, "float");
    this.editorPane.add(this.doubleTF, "double");
    this.editorPane.add(this.charTF, "char");
    this.editorPane.add(this.byteTF, "byte");
    this.editorPane.add(this.shortTF, "short");
    this.editorPane.add(this.integerTF, "integer");
    this.editorPane.add(this.longTF, "long");
    this.editorPane.add(this.datetimeCB, "timeInstant");
    this.editorPane.add(this.dateCB, "date");
    this.editorPane.add(this.timeSP, "time");
    this.editorLO.show(this.editorPane, "string");
    this.typeCB.addItemListener(this.typeListener);
  }
  
  public void setValueNode(XValueNode paramXValueNode) {
    this.value = paramXValueNode;
    if (paramXValueNode != null) {
      this.typeCB.setSelectedItem(paramXValueNode.getType());
      Object object = paramXValueNode.getValue();
      if (paramXValueNode instanceof BooleanValue) {
        this.booleanCB.setSelected(((BooleanValue)paramXValueNode).booleanValue());
      } else if (paramXValueNode instanceof inetsoft.uql.schema.DateValue) {
        this.dateCB.setDate((object == null) ? new Date() : (Date)object);
      } else if (paramXValueNode instanceof DoubleValue) {
        this.doubleTF.setValue(((DoubleValue)paramXValueNode).doubleValue());
      } else if (paramXValueNode instanceof FloatValue) {
        this.floatTF.setValue(((FloatValue)paramXValueNode).floatValue());
      } else if (paramXValueNode instanceof CharacterValue) {
        this.charTF.setText(((CharacterValue)paramXValueNode).charValue() + "");
      } else if (paramXValueNode instanceof ByteValue) {
        this.byteTF.setValue(((ByteValue)paramXValueNode).byteValue());
      } else if (paramXValueNode instanceof ShortValue) {
        this.shortTF.setValue(((ShortValue)paramXValueNode).shortValue());
      } else if (paramXValueNode instanceof IntegerValue) {
        this.integerTF.setValue(((IntegerValue)paramXValueNode).intValue());
      } else if (paramXValueNode instanceof LongValue) {
        this.longTF.setValue(((LongValue)paramXValueNode).longValue());
      } else if (paramXValueNode instanceof inetsoft.uql.schema.StringValue) {
        this.stringTF.setText((object == null) ? "" : (String)object);
      } else if (paramXValueNode instanceof inetsoft.uql.schema.TimeInstantValue) {
        this.datetimeCB.setDate((object == null) ? new Date() : (Date)object);
      } else if (paramXValueNode instanceof inetsoft.uql.schema.TimeValue) {
        this.timeSP.setDate((object == null) ? new Date() : (Date)object);
      } 
    } 
  }
  
  public XValueNode getValueNode() {
    String str = (this.value != null) ? this.value.getName() : "value";
    XValueNode xValueNode = XSchema.createValueNode((String)this.typeCB.getSelectedItem());
    xValueNode.setName(str);
    if (xValueNode instanceof BooleanValue) {
      xValueNode.setValue(new Boolean(this.booleanCB.isSelected()));
    } else if (xValueNode instanceof inetsoft.uql.schema.DateValue) {
      xValueNode.setValue(this.dateCB.getDate());
    } else if (xValueNode instanceof DoubleValue) {
      xValueNode.setValue(new Double(this.doubleTF.doubleValue()));
    } else if (xValueNode instanceof FloatValue) {
      xValueNode.setValue(new Float(this.floatTF.floatValue()));
    } else if (xValueNode instanceof CharacterValue) {
      String str1 = this.charTF.getText();
      char c = (str1.length() > 0) ? str1.charAt(0) : 0;
      xValueNode.setValue(new Character(c));
    } else if (xValueNode instanceof ByteValue) {
      xValueNode.setValue(new Byte((byte)this.byteTF.intValue()));
    } else if (xValueNode instanceof ShortValue) {
      xValueNode.setValue(new Short((short)this.shortTF.intValue()));
    } else if (xValueNode instanceof IntegerValue) {
      xValueNode.setValue(new Integer(this.integerTF.intValue()));
    } else if (xValueNode instanceof LongValue) {
      xValueNode.setValue(new Long(this.longTF.longValue()));
    } else if (xValueNode instanceof inetsoft.uql.schema.StringValue) {
      xValueNode.setValue(this.stringTF.getText());
    } else if (xValueNode instanceof inetsoft.uql.schema.TimeInstantValue) {
      xValueNode.setValue(this.datetimeCB.getDate());
    } else if (xValueNode instanceof inetsoft.uql.schema.TimeValue) {
      xValueNode.setValue(this.timeSP.getDate());
    } 
    return xValueNode;
  }
  
  static final String[] types = { "string", "boolean", "float", "double", "integer", "long", "timeInstant", "date", "time" };
  
  JComboBox typeCB;
  
  JTextField stringTF;
  
  JCheckBox booleanCB;
  
  NumField floatTF;
  
  NumField doubleTF;
  
  JTextField charTF;
  
  NumField byteTF;
  
  NumField shortTF;
  
  NumField integerTF;
  
  NumField longTF;
  
  DateTimeCombo datetimeCB;
  
  DateCombo dateCB;
  
  TimeSpinner timeSP;
  
  CardLayout editorLO;
  
  JPanel editorPane;
  
  XValueNode value;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\gui\XValueEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */