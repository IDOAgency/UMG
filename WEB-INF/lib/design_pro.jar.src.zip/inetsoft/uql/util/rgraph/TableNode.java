/*     */ package inetsoft.uql.util.rgraph;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableNode
/*     */ {
/*     */   private String name;
/*     */   private Vector cols;
/*     */   private Vector objs;
/*     */   private Hashtable rels;
/*     */   private Object userObj;
/*     */   
/*     */   public TableNode(String paramString) {
/* 188 */     this.cols = new Vector();
/* 189 */     this.objs = new Vector();
/* 190 */     this.rels = new Hashtable();
/*     */     this.name = paramString;
/*     */   }
/*     */   
/*     */   public String getName() { return this.name; }
/*     */   
/*     */   public void addColumn(String paramString) { addColumn(paramString, null); }
/*     */   
/*     */   public void addColumn(String paramString, Object paramObject) {
/*     */     this.cols.addElement(paramString);
/*     */     this.objs.addElement(paramObject);
/*     */   }
/*     */   
/*     */   public int getColumnCount() { return this.cols.size(); }
/*     */   
/*     */   public String getColumn(int paramInt) { return (String)this.cols.elementAt(paramInt); }
/*     */   
/*     */   public Object getUserObject(int paramInt) { return this.objs.elementAt(paramInt); }
/*     */   
/*     */   public void addRelation(String paramString, TableColumn paramTableColumn) {
/*     */     Vector vector = (Vector)this.rels.get(paramString);
/*     */     if (vector == null)
/*     */       this.rels.put(paramString, vector = new Vector()); 
/*     */     if (!vector.contains(paramTableColumn))
/*     */       vector.addElement(paramTableColumn); 
/*     */   }
/*     */   
/*     */   public void removeRelation(String paramString, TableColumn paramTableColumn) {
/*     */     Vector vector = (Vector)this.rels.get(paramString);
/*     */     if (vector != null) {
/*     */       vector.removeElement(paramTableColumn);
/*     */       if (vector.size() == 0)
/*     */         this.rels.remove(paramString); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeRelationToTable(TableNode paramTableNode) {
/*     */     for (byte b = 0; b < getColumnCount(); b++) {
/*     */       TableColumn[] arrayOfTableColumn = getRelations(getColumn(b));
/*     */       if (arrayOfTableColumn != null)
/*     */         for (byte b1 = 0; b1 < arrayOfTableColumn.length; b1++) {
/*     */           if (arrayOfTableColumn[b1].getTable().equals(paramTableNode))
/*     */             removeRelation(getColumn(b), arrayOfTableColumn[b1]); 
/*     */         }  
/*     */     } 
/*     */   }
/*     */   
/*     */   public TableColumn[] getRelations() {
/*     */     Enumeration enumeration = this.rels.elements();
/*     */     Vector vector = new Vector();
/*     */     while (enumeration.hasMoreElements()) {
/*     */       Vector vector1 = (Vector)enumeration.nextElement();
/*     */       for (byte b = 0; b < vector1.size(); b++)
/*     */         vector.addElement(vector1.elementAt(b)); 
/*     */     } 
/*     */     TableColumn[] arrayOfTableColumn = new TableColumn[vector.size()];
/*     */     vector.copyInto(arrayOfTableColumn);
/*     */     return arrayOfTableColumn;
/*     */   }
/*     */   
/*     */   public TableColumn[] getRelations(String paramString) {
/*     */     Vector vector = (Vector)this.rels.get(paramString);
/*     */     if (vector != null) {
/*     */       TableColumn[] arrayOfTableColumn = new TableColumn[vector.size()];
/*     */       vector.copyInto(arrayOfTableColumn);
/*     */       return arrayOfTableColumn;
/*     */     } 
/*     */     return new TableColumn[0];
/*     */   }
/*     */   
/*     */   public void removeAllRelations() { this.rels.clear(); }
/*     */   
/*     */   public void setUserObject(Object paramObject) { this.userObj = paramObject; }
/*     */   
/*     */   public Object getUserObject() { return this.userObj; }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/*     */     if (paramObject instanceof TableNode)
/*     */       return ((TableNode)paramObject).name.equals(this.name); 
/*     */     return false;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\rgraph\TableNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */