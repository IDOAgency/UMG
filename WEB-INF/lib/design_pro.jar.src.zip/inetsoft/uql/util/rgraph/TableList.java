/*     */ package inetsoft.uql.util.rgraph;
/*     */ 
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionAdapter;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.border.EtchedBorder;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableList
/*     */   extends JPanel
/*     */ {
/*     */   MouseListener mouseListener;
/*     */   MouseMotionListener mouseMotionListener;
/*     */   private JLabel title;
/*     */   private ColumnScroll scroll;
/*     */   private TableNode table;
/*     */   private ColumnList list;
/*     */   private JPopupMenu menu;
/*     */   private JPopupMenu titlemenu;
/*     */   private ActionListener actionListener;
/*     */   private Vector listlisteners;
/*     */   
/*     */   public TableList(TableNode paramTableNode) {
/* 191 */     this.mouseListener = null;
/* 192 */     this.mouseMotionListener = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     this.menu = new JPopupMenu();
/* 307 */     this.titlemenu = null;
/* 308 */     this.actionListener = null;
/* 309 */     this.listlisteners = new Vector();
/*     */     setLayout(new BorderLayout());
/*     */     setBorder(new EtchedBorder(0));
/*     */     this.table = paramTableNode;
/*     */     this.title = new JLabel(paramTableNode.getName(), 0);
/*     */     this.title.setForeground(Color.white);
/*     */     this.title.setBackground(new Color(100, 100, 100));
/*     */     this.title.setOpaque(true);
/*     */     add(this.title, "North");
/*     */     this.list = new ColumnList(this);
/*     */     this.scroll = new ColumnScroll(this, this.list);
/*     */     add(this.scroll, "Center");
/*     */     this.list.setSelectionMode(0);
/*     */     JMenuItem jMenuItem = new JMenuItem(Catalog.getString("Add Relationship") + "...");
/*     */     jMenuItem.addActionListener(new ActionListener(this) {
/*     */           private final TableList this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */             String str = (String)this.this$0.list.getSelectedValue();
/*     */             if (this.this$0.actionListener != null && str != null)
/*     */               this.this$0.actionListener.actionPerformed(new ActionEvent(this.this$0, 1001, str)); 
/*     */           }
/*     */         });
/*     */     this.menu.add(jMenuItem);
/*     */     this.list.addMouseListener(new MouseAdapter(this) {
/*     */           private final TableList this$0;
/*     */           
/*     */           public void mousePressed(MouseEvent param1MouseEvent) {
/*     */             if (param1MouseEvent.isPopupTrigger() && this.this$0.list.getSelectedValue() != null)
/*     */               this.this$0.menu.show((Component)param1MouseEvent.getSource(), param1MouseEvent.getX(), param1MouseEvent.getY()); 
/*     */           }
/*     */           
/*     */           public void mouseReleased(MouseEvent param1MouseEvent) { mousePressed(param1MouseEvent); }
/*     */         });
/*     */     this.list.addListSelectionListener(new ListSelectionListener(this) {
/*     */           private final TableList this$0;
/*     */           
/*     */           public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
/*     */             ListSelectionEvent listSelectionEvent = new ListSelectionEvent(this.this$0, param1ListSelectionEvent.getFirstIndex(), param1ListSelectionEvent.getLastIndex(), param1ListSelectionEvent.getValueIsAdjusting());
/*     */             for (byte b = 0; b < this.this$0.listlisteners.size(); b++)
/*     */               ((ListSelectionListener)this.this$0.listlisteners.elementAt(b)).valueChanged(listSelectionEvent); 
/*     */           }
/*     */         });
/*     */     this.title.addMouseListener(new MouseAdapter(this) {
/*     */           private final TableList this$0;
/*     */           
/*     */           public void mousePressed(MouseEvent param1MouseEvent) {
/*     */             if (param1MouseEvent.isPopupTrigger() && this.this$0.titlemenu != null)
/*     */               this.this$0.titlemenu.show((Component)param1MouseEvent.getSource(), param1MouseEvent.getX(), param1MouseEvent.getY()); 
/*     */             if (this.this$0.mouseListener != null && param1MouseEvent.getID() == 501)
/*     */               this.this$0.mouseListener.mousePressed(new MouseEvent(this.this$0, param1MouseEvent.getID(), param1MouseEvent.getWhen(), param1MouseEvent.getModifiers(), param1MouseEvent.getX(), param1MouseEvent.getY(), param1MouseEvent.getClickCount(), param1MouseEvent.isPopupTrigger())); 
/*     */           }
/*     */           
/*     */           public void mouseReleased(MouseEvent param1MouseEvent) { mousePressed(param1MouseEvent); }
/*     */         });
/*     */     this.title.addMouseMotionListener(new MouseMotionAdapter(this) {
/*     */           private final TableList this$0;
/*     */           
/*     */           public void mouseDragged(MouseEvent param1MouseEvent) {
/*     */             if (this.this$0.mouseMotionListener != null)
/*     */               this.this$0.mouseMotionListener.mouseDragged(new MouseEvent(this.this$0, param1MouseEvent.getID(), param1MouseEvent.getWhen(), param1MouseEvent.getModifiers(), param1MouseEvent.getX(), param1MouseEvent.getY(), param1MouseEvent.getClickCount(), param1MouseEvent.isPopupTrigger())); 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public TableNode getTable() { return this.table; }
/*     */   
/*     */   public String getSelectedColumn() { return (String)this.list.getSelectedValue(); }
/*     */   
/*     */   public Rectangle getItemBounds(int paramInt) {
/*     */     Point point1 = this.list.indexToLocation(paramInt);
/*     */     if (point1 == null)
/*     */       return null; 
/*     */     Point point2 = this.scroll.getLocation();
/*     */     Point point3 = this.list.getLocation();
/*     */     point1.y += point2.y + point3.y;
/*     */     int i = (this.list.getSize()).height / this.table.getColumnCount();
/*     */     if (point1.y + i < (this.title.getSize()).height) {
/*     */       point1.y = 2;
/*     */     } else if (point1.y + i / 2 > (getSize()).height) {
/*     */       point1.y = (getSize()).height - i / 2;
/*     */     } 
/*     */     return new Rectangle(0, point1.y, (getSize()).width, i);
/*     */   }
/*     */   
/*     */   public Rectangle getItemBounds(String paramString) {
/*     */     for (byte b = 0; b < this.table.getColumnCount(); b++) {
/*     */       if (this.table.getColumn(b).equals(paramString))
/*     */         return getItemBounds(b); 
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public void setTitleMenu(JPopupMenu paramJPopupMenu) { this.titlemenu = paramJPopupMenu; }
/*     */   
/*     */   public void addMouseListener(MouseListener paramMouseListener) {
/*     */     super.addMouseListener(paramMouseListener);
/*     */     this.mouseListener = AWTEventMulticaster.add(this.mouseListener, paramMouseListener);
/*     */   }
/*     */   
/*     */   public void removeMouseListener(MouseListener paramMouseListener) {
/*     */     super.removeMouseListener(paramMouseListener);
/*     */     this.mouseListener = AWTEventMulticaster.remove(this.mouseListener, paramMouseListener);
/*     */   }
/*     */   
/*     */   public void addMouseMotionListener(MouseMotionListener paramMouseMotionListener) {
/*     */     super.addMouseMotionListener(paramMouseMotionListener);
/*     */     this.mouseMotionListener = AWTEventMulticaster.add(this.mouseMotionListener, paramMouseMotionListener);
/*     */   }
/*     */   
/*     */   public void removeMouseMotionListener(MouseMotionListener paramMouseMotionListener) {
/*     */     super.removeMouseMotionListener(paramMouseMotionListener);
/*     */     this.mouseMotionListener = AWTEventMulticaster.remove(this.mouseMotionListener, paramMouseMotionListener);
/*     */   }
/*     */   
/*     */   public void addChangeListener(ChangeListener paramChangeListener) { this.scroll.getViewport().addChangeListener(paramChangeListener); }
/*     */   
/*     */   public void removeChangeListener(ChangeListener paramChangeListener) { this.scroll.getViewport().removeChangeListener(paramChangeListener); }
/*     */   
/*     */   public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
/*     */   
/*     */   public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
/*     */   
/*     */   public void addListSelectionListener(ListSelectionListener paramListSelectionListener) { this.listlisteners.addElement(paramListSelectionListener); }
/*     */   
/*     */   public void removeListSelectionListener(ListSelectionListener paramListSelectionListener) { this.listlisteners.removeElement(paramListSelectionListener); }
/*     */   
/*     */   class ColumnList extends JList {
/*     */     private final TableList this$0;
/*     */     
/*     */     public ColumnList(TableList this$0) {
/*     */       this.this$0 = this$0;
/*     */       setModel(new TableList$6(this));
/*     */       setBackground(Color.lightGray);
/*     */     }
/*     */   }
/*     */   
/*     */   class ColumnScroll extends JScrollPane {
/*     */     private final TableList this$0;
/*     */     
/*     */     public ColumnScroll(TableList this$0, TableList.ColumnList param1ColumnList) {
/*     */       super(param1ColumnList);
/*     */       this.this$0 = this$0;
/*     */       setBorder(new EtchedBorder());
/*     */     }
/*     */     
/*     */     public Dimension getPreferredSize() {
/*     */       Dimension dimension = this.this$0.list.getPreferredSize();
/*     */       dimension.width = Math.max(dimension.width, (this.this$0.title.getPreferredSize()).width);
/*     */       dimension.height = Math.min(dimension.height, 100);
/*     */       dimension.width += 20;
/*     */       dimension.height += 5;
/*     */       return dimension;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\rgraph\TableList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */