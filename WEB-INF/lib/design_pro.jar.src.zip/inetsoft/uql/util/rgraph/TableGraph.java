/*     */ package inetsoft.uql.util.rgraph;
/*     */ 
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableGraph
/*     */   extends JPanel
/*     */ {
/*     */   ChangeListener scrollListener;
/*     */   DnDListener dragListener;
/*     */   ActionListener createListener;
/*     */   ListSelectionListener selListener;
/*     */   MouseListener selectionListener;
/*     */   static final String msg1 = "Relationship must be between two different tables!";
/*     */   static final String msg2 = "Delete the selected relationship?";
/*     */   static final String msg3 = "Select a table column to create a relationship!";
/*     */   static final int XGAP = 30;
/*     */   static final int YGAP = 20;
/*     */   static final int STUD = 10;
/*     */   
/*     */   public TableGraph() {
/* 421 */     this.scrollListener = new ChangeListener(this) { private final TableGraph this$0;
/*     */         
/* 423 */         public void stateChanged(ChangeEvent param1ChangeEvent) { this.this$0.repaint(); }
/*     */          }
/*     */       ;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 430 */     this.dragListener = new DnDListener(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 465 */     this.createListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 467 */           TableList tableList = (TableList)param1ActionEvent.getSource();
/* 468 */           this.this$0.setCursor(new Cursor(1));
/* 469 */           this.this$0.createR = new TableColumn(tableList.getTable(), tableList.getSelectedColumn());
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         private final TableGraph this$0;
/*     */       };
/* 476 */     this.selListener = new ListSelectionListener(this) {
/*     */         public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
/* 478 */           if (this.this$0.createR != null) {
/* 479 */             TableList tableList = (TableList)param1ListSelectionEvent.getSource();
/* 480 */             TableNode tableNode = tableList.getTable();
/*     */             
/* 482 */             if (tableNode.equals(this.this$0.createR.getTable())) {
/* 483 */               JOptionPane.showMessageDialog(this.this$0, "Relationship must be between two different tables!");
/*     */             } else {
/*     */               
/* 486 */               tableNode.addRelation(tableList.getSelectedColumn(), this.this$0.createR);
/* 487 */               this.this$0.repaint();
/*     */             } 
/*     */             
/* 490 */             this.this$0.createR = null;
/* 491 */             this.this$0.setCursor(new Cursor(0));
/* 492 */             this.this$0.valueChanged();
/*     */           } 
/*     */         }
/*     */         
/*     */         private final TableGraph this$0;
/*     */       };
/* 498 */     this.selectionListener = new MouseAdapter(this) {
/*     */         public void mousePressed(MouseEvent param1MouseEvent) {
/* 500 */           if (this.this$0.createR != null) {
/* 501 */             JOptionPane.showMessageDialog(this.this$0, "Select a table column to create a relationship!");
/*     */             
/*     */             return;
/*     */           } 
/* 505 */           if (param1MouseEvent.isPopupTrigger()) {
/* 506 */             if (this.this$0.edge != null) {
/* 507 */               this.this$0.edgeMenu.show((Component)param1MouseEvent.getSource(), param1MouseEvent.getX(), param1MouseEvent.getY());
/*     */             }
/*     */             
/*     */             return;
/*     */           } 
/*     */           
/* 513 */           Point point = param1MouseEvent.getPoint();
/*     */           
/* 515 */           for (byte b = 0; b < this.this$0.lines.size(); b++) {
/* 516 */             Polygon polygon = (Polygon)this.this$0.lines.elementAt(b);
/* 517 */             if (polygon.contains(point)) {
/* 518 */               this.this$0.edge = (TableColumn[])this.this$0.relations.elementAt(b);
/* 519 */               this.this$0.repaint();
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/*     */           
/* 525 */           if (this.this$0.edge != null) {
/* 526 */             this.this$0.edge = null;
/* 527 */             this.this$0.repaint();
/*     */           } 
/*     */         }
/*     */         private final TableGraph this$0;
/*     */         public void mouseReleased(MouseEvent param1MouseEvent) {
/* 532 */           if (param1MouseEvent.isPopupTrigger()) {
/* 533 */             mousePressed(param1MouseEvent);
/*     */           }
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 547 */     this.needLayout = true;
/* 548 */     this.createR = null;
/* 549 */     this.edge = null;
/*     */     
/* 551 */     this.tablecols = new Vector();
/*     */     
/* 553 */     this.edgeMenu = new JPopupMenu();
/*     */     
/* 555 */     this.lines = new Vector();
/*     */     
/* 557 */     this.relations = new Vector();
/*     */     
/* 559 */     this.listeners = new Vector();
/* 560 */     this.changed = false;
/*     */     setLayout(null);
/*     */     setOpaque(false);
/*     */     addMouseListener(this.selectionListener);
/*     */     JMenuItem jMenuItem = new JMenuItem("Delete");
/*     */     jMenuItem.addActionListener(new ActionListener(this) {
/*     */           private final TableGraph this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */             if (this.this$0.edge != null && JOptionPane.showConfirmDialog(this.this$0, "Delete the selected relationship?", "Delete", 2) == 0) {
/*     */               this.this$0.edge[0].getTable().removeRelation(this.this$0.edge[0].getColumn(), this.this$0.edge[1]);
/*     */               this.this$0.repaint();
/*     */               this.this$0.valueChanged();
/*     */             } 
/*     */           }
/*     */         });
/*     */     this.edgeMenu.add(jMenuItem);
/*     */   }
/*     */   
/*     */   public void setTables(TableNode[] paramArrayOfTableNode) {
/*     */     this.tables = paramArrayOfTableNode;
/*     */     this.edge = null;
/*     */     this.tablecols.removeAllElements();
/*     */     this.lines.removeAllElements();
/*     */     this.relations.removeAllElements();
/*     */     while (getComponentCount() > 0)
/*     */       remove(0); 
/*     */     for (byte b = 0; b < paramArrayOfTableNode.length; b++) {
/*     */       if (findTable(paramArrayOfTableNode[b], false) == null) {
/*     */         TableColumn[] arrayOfTableColumn = paramArrayOfTableNode[b].getRelations();
/*     */         int i = 0;
/*     */         for (byte b1 = 0; b1 < arrayOfTableColumn.length; b1++) {
/*     */           Point point = findTable(arrayOfTableColumn[b1].getTable(), true);
/*     */           i = Math.max((point == null) ? 0 : (point.x + 1), i);
/*     */         } 
/*     */         addTable(paramArrayOfTableNode[b], i);
/*     */       } 
/*     */     } 
/*     */     if (this.tablecols.size() == 1 && paramArrayOfTableNode.length > 1) {
/*     */       Vector vector = (Vector)this.tablecols.elementAt(0);
/*     */       this.tablecols = new Vector(paramArrayOfTableNode.length);
/*     */       for (byte b1 = 0; b1 < vector.size(); b1++) {
/*     */         Vector vector1 = new Vector();
/*     */         vector1.addElement(vector.elementAt(b1));
/*     */         this.tablecols.addElement(vector1);
/*     */       } 
/*     */     } 
/*     */     this.needLayout = true;
/*     */     validate();
/*     */     repaint();
/*     */   }
/*     */   
/*     */   public TableNode[] getTables() { return this.tables; }
/*     */   
/*     */   public void doLayout() {
/*     */     if (this.needLayout) {
/*     */       this.needLayout = false;
/*     */       int i = margin.left;
/*     */       for (byte b = 0; b < this.tablecols.size(); b++) {
/*     */         int j = margin.top, k = 0;
/*     */         Vector vector = (Vector)this.tablecols.elementAt(b);
/*     */         for (byte b1 = 0; b1 < vector.size(); b1++) {
/*     */           TableList tableList = (TableList)vector.elementAt(b1);
/*     */           Dimension dimension = tableList.getPreferredSize();
/*     */           tableList.setBounds(i, j, dimension.width, dimension.height);
/*     */           j += dimension.height + 20;
/*     */           k = Math.max(k, dimension.width);
/*     */         } 
/*     */         i += k + 30;
/*     */       } 
/*     */       setSize(getPreferredSize());
/*     */       for (Container container = this; container.getParent() != null;)
/*     */         container = container.getParent(); 
/*     */       container.validate();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     paramGraphics.setColor(Color.black);
/*     */     this.lines.removeAllElements();
/*     */     this.relations.removeAllElements();
/*     */     for (byte b = 0; b < this.tablecols.size(); b++) {
/*     */       Vector vector = (Vector)this.tablecols.elementAt(b);
/*     */       for (byte b1 = 0; b1 < vector.size(); b1++) {
/*     */         TableList tableList = (TableList)vector.elementAt(b1);
/*     */         TableNode tableNode = tableList.getTable();
/*     */         for (byte b2 = 0; b2 < tableNode.getColumnCount(); b2++) {
/*     */           String str = tableNode.getColumn(b2);
/*     */           TableColumn tableColumn = new TableColumn(tableNode, str);
/*     */           TableColumn[] arrayOfTableColumn = tableNode.getRelations(str);
/*     */           if (arrayOfTableColumn.length != 0) {
/*     */             Rectangle rectangle = tableList.getItemBounds(b2);
/*     */             Point point = tableList.getLocation();
/*     */             rectangle.x += point.x;
/*     */             rectangle.y += point.y;
/*     */             int i = rectangle.y + rectangle.height / 2;
/*     */             int j = rectangle.x + rectangle.width;
/*     */             for (byte b3 = 0; b3 < arrayOfTableColumn.length; b3++) {
/*     */               Point point1 = findTable(arrayOfTableColumn[b3].getTable(), false);
/*     */               if (point1 != null) {
/*     */                 TableColumn[] arrayOfTableColumn1 = { tableColumn, arrayOfTableColumn[b3] };
/*     */                 TableList tableList1 = getTableList(point1.x, point1.y);
/*     */                 Point point2 = tableList1.getLocation();
/*     */                 Rectangle rectangle1 = tableList1.getItemBounds(arrayOfTableColumn[b3].getColumn());
/*     */                 rectangle1.x += point2.x;
/*     */                 rectangle1.y += point2.y;
/*     */                 int k = rectangle1.y + rectangle1.height / 2;
/*     */                 int m = rectangle1.x + rectangle1.width;
/*     */                 if (rectangle.x > rectangle1.x + rectangle1.width) {
/*     */                   drawDot(paramGraphics, m, k);
/*     */                   drawDot(paramGraphics, -rectangle.x, i);
/*     */                   drawLine(paramGraphics, rectangle.x, i, m, k, -10, 10, arrayOfTableColumn1);
/*     */                 } else if (rectangle.x + rectangle.width < rectangle1.x) {
/*     */                   drawDot(paramGraphics, j, i);
/*     */                   drawDot(paramGraphics, -rectangle1.x, k);
/*     */                   drawLine(paramGraphics, rectangle1.x, k, j, i, -10, 10, arrayOfTableColumn1);
/*     */                 } else {
/*     */                   drawDot(paramGraphics, -rectangle.x, i);
/*     */                   drawDot(paramGraphics, -rectangle1.x, k);
/*     */                   drawLine(paramGraphics, rectangle.x, i, rectangle1.x, k, -10, -10, arrayOfTableColumn1);
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     super.paint(paramGraphics);
/*     */   }
/*     */   
/*     */   public Dimension getPreferredSize() {
/*     */     Dimension dimension = new Dimension();
/*     */     doLayout();
/*     */     for (byte b = 0; b < this.tablecols.size(); b++) {
/*     */       Vector vector = (Vector)this.tablecols.elementAt(b);
/*     */       for (byte b1 = 0; b1 < vector.size(); b1++) {
/*     */         TableList tableList = (TableList)vector.elementAt(b1);
/*     */         Rectangle rectangle = tableList.getBounds();
/*     */         dimension.width = Math.max(dimension.width, rectangle.x + rectangle.width);
/*     */         dimension.height = Math.max(dimension.height, rectangle.y + rectangle.height);
/*     */       } 
/*     */     } 
/*     */     dimension.width += margin.right;
/*     */     dimension.height += margin.bottom;
/*     */     return dimension;
/*     */   }
/*     */   
/*     */   public void addChangeListener(ChangeListener paramChangeListener) { this.listeners.addElement(paramChangeListener); }
/*     */   
/*     */   public void removeChangeListener(ChangeListener paramChangeListener) { this.listeners.removeElement(paramChangeListener); }
/*     */   
/*     */   protected void valueChanged() {
/*     */     this.changed = true;
/*     */     for (byte b = 0; b < this.listeners.size(); b++)
/*     */       ((ChangeListener)this.listeners.elementAt(b)).stateChanged(new ChangeEvent(this)); 
/*     */   }
/*     */   
/*     */   public void setValueChanged(boolean paramBoolean) { this.changed = paramBoolean; }
/*     */   
/*     */   public boolean isValueChanged() { return this.changed; }
/*     */   
/*     */   private void addTable(TableNode paramTableNode, int paramInt) {
/*     */     if (this.tablecols.size() <= paramInt) {
/*     */       int i = this.tablecols.size();
/*     */       this.tablecols.setSize(paramInt + 1);
/*     */       for (int j = i; j < this.tablecols.size(); j++)
/*     */         this.tablecols.setElementAt(new Vector(), j); 
/*     */     } 
/*     */     TableList tableList = new TableList(paramTableNode);
/*     */     tableList.addMouseListener(this.dragListener);
/*     */     tableList.addMouseMotionListener(this.dragListener);
/*     */     tableList.addChangeListener(this.scrollListener);
/*     */     tableList.addActionListener(this.createListener);
/*     */     tableList.addListSelectionListener(this.selListener);
/*     */     JPopupMenu jPopupMenu = new JPopupMenu();
/*     */     JMenuItem jMenuItem = new JMenuItem(Catalog.getString("Remove Table"));
/*     */     jPopupMenu.add(jMenuItem);
/*     */     jMenuItem.addActionListener(new ActionListener(this, paramTableNode) {
/*     */           private final TableNode val$table;
/*     */           private final TableGraph this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */             TableNode[] arrayOfTableNode = new TableNode[this.this$0.tables.length - 1];
/*     */             for (byte b1 = 0, b2 = 0; b1 < this.this$0.tables.length; b1++) {
/*     */               if (this.this$0.tables[b1] != this.val$table) {
/*     */                 arrayOfTableNode[b2++] = this.this$0.tables[b1];
/*     */                 this.this$0.tables[b1].removeRelationToTable(this.val$table);
/*     */               } 
/*     */             } 
/*     */             this.val$table.removeAllRelations();
/*     */             this.this$0.setTables(arrayOfTableNode);
/*     */             this.this$0.valueChanged();
/*     */           }
/*     */         });
/*     */     tableList.setTitleMenu(jPopupMenu);
/*     */     add(tableList);
/*     */     ((Vector)this.tablecols.elementAt(paramInt)).addElement(tableList);
/*     */   }
/*     */   
/*     */   private TableList getTableList(int paramInt1, int paramInt2) {
/*     */     if (paramInt1 < this.tablecols.size())
/*     */       return (TableList)((Vector)this.tablecols.elementAt(paramInt1)).elementAt(paramInt2); 
/*     */     return null;
/*     */   }
/*     */   
/*     */   private Point findTable(TableNode paramTableNode, boolean paramBoolean) {
/*     */     for (byte b = 0; b < this.tablecols.size(); b++) {
/*     */       Vector vector = (Vector)this.tablecols.elementAt(b);
/*     */       for (byte b1 = 0; b1 < vector.size(); b1++) {
/*     */         TableList tableList = (TableList)vector.elementAt(b1);
/*     */         if (tableList.getTable().equals(paramTableNode))
/*     */           return new Point(b, b1); 
/*     */       } 
/*     */     } 
/*     */     if (paramBoolean) {
/*     */       addTable(paramTableNode, 0);
/*     */       return new Point(0, ((Vector)this.tablecols.elementAt(0)).size() - 1);
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   private void drawDot(Graphics paramGraphics, int paramInt1, int paramInt2) {
/*     */     if (paramInt1 < 0)
/*     */       paramInt1 = -paramInt1 - 2; 
/*     */     paramGraphics.fillRect(paramInt1, paramInt2 - 1, 2, 3);
/*     */   }
/*     */   
/*     */   private void drawLine(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, TableColumn[] paramArrayOfTableColumn) {
/*     */     paramGraphics.drawLine(paramInt1, paramInt2, paramInt1 + paramInt5, paramInt2);
/*     */     paramGraphics.drawLine(paramInt3, paramInt4, paramInt3 + paramInt6, paramInt4);
/*     */     paramGraphics.drawLine(paramInt1 + paramInt5, paramInt2, paramInt3 + paramInt6, paramInt4);
/*     */     if (this.edge != null && this.edge[0].equals(paramArrayOfTableColumn[0]) && this.edge[1].equals(paramArrayOfTableColumn[1])) {
/*     */       paramGraphics.drawLine(paramInt1, paramInt2 + 1, paramInt1 + paramInt5, paramInt2 + 1);
/*     */       paramGraphics.drawLine(paramInt3, paramInt4 + 1, paramInt3 + paramInt6, paramInt4 + 1);
/*     */       paramGraphics.drawLine(paramInt1 + paramInt5, paramInt2 + 1, paramInt3 + paramInt6, paramInt4 + 1);
/*     */       paramGraphics.drawLine(paramInt1, paramInt2 - 1, paramInt1 + paramInt5, paramInt2 - 1);
/*     */       paramGraphics.drawLine(paramInt3, paramInt4 - 1, paramInt3 + paramInt6, paramInt4 - 1);
/*     */       paramGraphics.drawLine(paramInt1 + paramInt5, paramInt2 - 1, paramInt3 + paramInt6, paramInt4 - 1);
/*     */     } 
/*     */     Polygon polygon = new Polygon();
/*     */     polygon.addPoint(paramInt1, paramInt2 - 2);
/*     */     polygon.addPoint(paramInt1 + paramInt5 - 2, paramInt2 - 2);
/*     */     polygon.addPoint(paramInt3 + paramInt6 - 2, paramInt4 - 2);
/*     */     polygon.addPoint(paramInt3, paramInt4 - 2);
/*     */     polygon.addPoint(paramInt3, paramInt4 + 2);
/*     */     polygon.addPoint(paramInt3 + paramInt6 + 2, paramInt4 + 2);
/*     */     polygon.addPoint(paramInt1 + paramInt5 + 2, paramInt2 + 2);
/*     */     polygon.addPoint(paramInt1, paramInt2 + 2);
/*     */     this.lines.addElement(polygon);
/*     */     this.relations.addElement(paramArrayOfTableColumn);
/*     */   }
/*     */   
/*     */   class DnDListener implements MouseListener, MouseMotionListener {
/*     */     Point startLoc;
/*     */     private final TableGraph this$0;
/*     */     
/*     */     DnDListener(TableGraph this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public void mouseClicked(MouseEvent param1MouseEvent) {}
/*     */     
/*     */     public void mousePressed(MouseEvent param1MouseEvent) { this.startLoc = new Point(param1MouseEvent.getX(), param1MouseEvent.getY()); }
/*     */     
/*     */     public void mouseReleased(MouseEvent param1MouseEvent) {}
/*     */     
/*     */     public void mouseEntered(MouseEvent param1MouseEvent) {}
/*     */     
/*     */     public void mouseExited(MouseEvent param1MouseEvent) {}
/*     */     
/*     */     public void mouseDragged(MouseEvent param1MouseEvent) {
/*     */       TableList tableList = (TableList)param1MouseEvent.getSource();
/*     */       Point point = tableList.getLocation();
/*     */       tableList.setLocation(new Point(point.x + param1MouseEvent.getX() - this.startLoc.x, point.y + param1MouseEvent.getY() - this.startLoc.y));
/*     */       this.this$0.repaint();
/*     */     }
/*     */     
/*     */     public void mouseMoved(MouseEvent param1MouseEvent) {}
/*     */   }
/*     */   static final Insets margin = new Insets(15, 15, 15, 15);
/*     */   boolean needLayout;
/*     */   TableColumn createR;
/*     */   TableColumn[] edge;
/*     */   TableNode[] tables;
/*     */   Vector tablecols;
/*     */   JPopupMenu edgeMenu;
/*     */   Vector lines;
/*     */   Vector relations;
/*     */   Vector listeners;
/*     */   boolean changed;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\rgraph\TableGraph.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */