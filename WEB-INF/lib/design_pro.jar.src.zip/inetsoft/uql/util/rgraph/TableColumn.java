package inetsoft.uql.util.rgraph;

public class TableColumn {
  private TableNode table;
  
  private String col;
  
  public TableColumn(TableNode paramTableNode, String paramString) {
    this.table = paramTableNode;
    this.col = paramString;
  }
  
  public TableNode getTable() { return this.table; }
  
  public String getColumn() { return this.col; }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof TableColumn) {
      TableColumn tableColumn = (TableColumn)paramObject;
      return (this.table.equals(tableColumn.table) && this.col.equals(tableColumn.col));
    } 
    return false;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uq\\util\rgraph\TableColumn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */