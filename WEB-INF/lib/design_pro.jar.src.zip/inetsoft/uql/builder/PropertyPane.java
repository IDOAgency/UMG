package inetsoft.uql.builder;

import java.util.Vector;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public abstract class PropertyPane extends JPanel {
  public void addChangeListener(ChangeListener paramChangeListener) { this.listeners.addElement(paramChangeListener); }
  
  public void removeChangeListener(ChangeListener paramChangeListener) { this.listeners.removeElement(paramChangeListener); }
  
  public void valueChanged() {
    this.changed = true;
    for (byte b = 0; b < this.listeners.size(); b++)
      ((ChangeListener)this.listeners.elementAt(b)).stateChanged(new ChangeEvent(this)); 
  }
  
  public boolean isValueChanged() { return this.changed; }
  
  protected void setValueChanged(boolean paramBoolean) { this.changed = paramBoolean; }
  
  public void verify() {}
  
  protected boolean changed = false;
  
  Vector listeners = new Vector();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\PropertyPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */