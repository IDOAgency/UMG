/*    */ package inetsoft.uql.builder;
/*    */ 
/*    */ import java.util.Vector;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.event.ChangeEvent;
/*    */ import javax.swing.event.ChangeListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PropertyPane
/*    */   extends JPanel
/*    */ {
/* 34 */   public void addChangeListener(ChangeListener paramChangeListener) { this.listeners.addElement(paramChangeListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public void removeChangeListener(ChangeListener paramChangeListener) { this.listeners.removeElement(paramChangeListener); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void valueChanged() {
/* 49 */     this.changed = true;
/*    */     
/* 51 */     for (byte b = 0; b < this.listeners.size(); b++) {
/* 52 */       ((ChangeListener)this.listeners.elementAt(b)).stateChanged(new ChangeEvent(this));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public boolean isValueChanged() { return this.changed; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   protected void setValueChanged(boolean paramBoolean) { this.changed = paramBoolean; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void verify() {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean changed = false;
/*    */ 
/*    */ 
/*    */   
/* 83 */   Vector listeners = new Vector();
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\PropertyPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */