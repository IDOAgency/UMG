package inetsoft.uql.builder;

import inetsoft.uql.XDataSource;

public abstract class DataSourceProperty extends PropertyPane {
  public abstract void setDataSource(XDataSource paramXDataSource);
  
  public abstract XDataSource getDataSource();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\DataSourceProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */