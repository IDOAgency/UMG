/*    */ package inetsoft.uql.builder;
/*    */ 
/*    */ import inetsoft.uql.XDataSource;
/*    */ import inetsoft.uql.XQuery;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTextArea;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DescriptionDialog
/*    */   extends JDialog
/*    */ {
/*    */   ActionListener okListener;
/*    */   boolean ok;
/*    */   Object xobj;
/*    */   JTextArea descTF;
/*    */   JButton okB;
/*    */   JButton cancelB;
/*    */   
/*    */   public static boolean show(Object paramObject) {
/* 38 */     DescriptionDialog descriptionDialog = new DescriptionDialog(paramObject);
/* 39 */     descriptionDialog.pack();
/* 40 */     descriptionDialog.setVisible(true);
/* 41 */     return descriptionDialog.ok;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DescriptionDialog(Object paramObject) {
/* 79 */     this.okListener = new ActionListener(this) {
/*    */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 81 */           String str = this.this$0.descTF.getText();
/*    */           
/* 83 */           if (this.this$0.xobj instanceof XDataSource) {
/* 84 */             ((XDataSource)this.this$0.xobj).setDescription(this.this$0.descTF.getText());
/*    */           }
/* 86 */           else if (this.this$0.xobj instanceof XQuery) {
/* 87 */             ((XQuery)this.this$0.xobj).setDescription(this.this$0.descTF.getText());
/*    */           } 
/*    */           
/* 90 */           this.this$0.ok = true;
/* 91 */           this.this$0.dispose();
/*    */         }
/*    */         private final DescriptionDialog this$0;
/*    */       };
/* 95 */     this.ok = false;
/*    */     
/* 97 */     this.descTF = new JTextArea();
/* 98 */     this.okB = new JButton(Catalog.getString("OK"));
/* 99 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*    */     this.xobj = paramObject;
/*    */     setModal(true);
/*    */     getContentPane().setLayout(new BorderLayout(5, 5));
/*    */     JScrollPane jScrollPane = new JScrollPane(this.descTF);
/*    */     jScrollPane.setPreferredSize(new Dimension(300, 80));
/*    */     getContentPane().add(new JLabel(Catalog.getString("Description") + ":"), "North");
/*    */     getContentPane().add(jScrollPane, "Center");
/*    */     JPanel jPanel = new JPanel();
/*    */     jPanel.add(this.okB);
/*    */     jPanel.add(this.cancelB);
/*    */     getContentPane().add(jPanel, "South");
/*    */     if (paramObject instanceof XDataSource) {
/*    */       this.descTF.setText(((XDataSource)paramObject).getDescription());
/*    */     } else if (paramObject instanceof XQuery) {
/*    */       this.descTF.setText(((XQuery)paramObject).getDescription());
/*    */     } 
/*    */     this.okB.addActionListener(this.okListener);
/*    */     this.cancelB.addActionListener(new ActionListener(this) {
/*    */           private final DescriptionDialog this$0;
/*    */           
/*    */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*    */         });
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\DescriptionDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */