package inetsoft.uql.builder;

import inetsoft.uql.XDataSource;
import inetsoft.uql.XQuery;
import inetsoft.uql.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

class DescriptionDialog extends JDialog {
  ActionListener okListener;
  
  boolean ok;
  
  Object xobj;
  
  JTextArea descTF;
  
  JButton okB;
  
  JButton cancelB;
  
  public static boolean show(Object paramObject) {
    DescriptionDialog descriptionDialog = new DescriptionDialog(paramObject);
    descriptionDialog.pack();
    descriptionDialog.setVisible(true);
    return descriptionDialog.ok;
  }
  
  public DescriptionDialog(Object paramObject) {
    this.okListener = new ActionListener(this) {
        private final DescriptionDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          String str = this.this$0.descTF.getText();
          if (this.this$0.xobj instanceof XDataSource) {
            ((XDataSource)this.this$0.xobj).setDescription(this.this$0.descTF.getText());
          } else if (this.this$0.xobj instanceof XQuery) {
            ((XQuery)this.this$0.xobj).setDescription(this.this$0.descTF.getText());
          } 
          this.this$0.ok = true;
          this.this$0.dispose();
        }
      };
    this.ok = false;
    this.descTF = new JTextArea();
    this.okB = new JButton(Catalog.getString("OK"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.xobj = paramObject;
    setModal(true);
    getContentPane().setLayout(new BorderLayout(5, 5));
    JScrollPane jScrollPane = new JScrollPane(this.descTF);
    jScrollPane.setPreferredSize(new Dimension(300, 80));
    getContentPane().add(new JLabel(Catalog.getString("Description") + ":"), "North");
    getContentPane().add(jScrollPane, "Center");
    JPanel jPanel = new JPanel();
    jPanel.add(this.okB);
    jPanel.add(this.cancelB);
    getContentPane().add(jPanel, "South");
    if (paramObject instanceof XDataSource) {
      this.descTF.setText(((XDataSource)paramObject).getDescription());
    } else if (paramObject instanceof XQuery) {
      this.descTF.setText(((XQuery)paramObject).getDescription());
    } 
    this.okB.addActionListener(this.okListener);
    this.cancelB.addActionListener(new ActionListener(this) {
          private final DescriptionDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
        });
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\DescriptionDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */