/*     */ package inetsoft.uql.builder;
/*     */ import inetsoft.uql.XDataSource;
/*     */ import inetsoft.uql.XLog;
/*     */ import inetsoft.uql.XQuery;
/*     */ import inetsoft.uql.XRepository;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.util.Config;
/*     */ import inetsoft.uql.util.gui.VariableDialog;
/*     */ import inetsoft.widget.STree;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.CardLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.io.IOException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.TreeSelectionEvent;
/*     */ import javax.swing.event.TreeSelectionListener;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ public class XBuildPane extends JPanel {
/*  44 */   public XBuildPane() { this(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public XRepository getRepository() { return this.repository; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public Object getSession() { return this.session; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void showQuery(String paramString) {
/*     */     try {
/* 172 */       this.xquery = this.repository.getQuery(paramString);
/*     */       
/* 174 */       if (this.xquery == null) {
/* 175 */         showMessage("Query not defined: " + paramString);
/*     */         
/*     */         return;
/*     */       } 
/* 179 */       QueryProperty queryProperty = (QueryProperty)this.qmap.get(this.xquery.getType());
/* 180 */       if (queryProperty == null) {
/* 181 */         showMessage("Internal Error: query editor missing: " + this.xquery.getType());
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 186 */       queryProperty.setSession(this.session);
/* 187 */       queryProperty.setQuery(this.xquery);
/*     */ 
/*     */       
/* 190 */       while (this.qcommand.getComponentCount() > 0) {
/* 191 */         this.qcommand.remove(0);
/*     */       }
/*     */ 
/*     */       
/* 195 */       if (queryProperty.getCommandPane() != null) {
/* 196 */         this.qcommand.add(queryProperty.getCommandPane());
/*     */       }
/*     */       
/* 199 */       this.contentLO.show(this.content, "q_" + this.xquery.getType());
/* 200 */       this.currpane = queryProperty;
/* 201 */       this.currpane.setValueChanged(false);
/*     */       
/* 203 */       this.qtree.removeTreeSelectionListener(this.qtreeListener);
/* 204 */       this.qtree.setSelected(this.xquery.getDataSource().getName() + "." + this.xquery.getName(), true);
/*     */       
/* 206 */       this.qtree.addTreeSelectionListener(this.qtreeListener);
/* 207 */       setEnabled();
/*     */       
/* 209 */       if (this.xquery.getDescription() != null) {
/* 210 */         this.status.setText(this.xquery.getDescription().replace('\n', ' '));
/*     */       } else {
/*     */         
/* 213 */         this.status.setText(" ");
/*     */       } 
/*     */     } catch (RemoteException remoteException) {
/* 216 */       remoteException.printStackTrace();
/* 217 */       showMessage(remoteException.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XDataSource newDataSource(String paramString) {
/* 229 */     XDataSource xDataSource = DataSourceDialog.prompt(paramString);
/*     */     
/* 231 */     if (xDataSource != null) {
/*     */       try {
/* 233 */         if (this.repository.getDataSource(xDataSource.getName()) != null) {
/* 234 */           JOptionPane.showMessageDialog(this, msg2 + xDataSource.getName());
/*     */           
/* 236 */           return null;
/*     */         } 
/*     */         
/* 239 */         String str = Config.getDataSourceWizard(xDataSource.getType());
/* 240 */         if (str != null) {
/* 241 */           DataSourceWizard dataSourceWizard = (DataSourceWizard)Class.forName(str).newInstance();
/*     */           
/* 243 */           dataSourceWizard.setDataSource(xDataSource);
/* 244 */           dataSourceWizard.show(new ActionListener(this, dataSourceWizard) { private final DataSourceWizard val$win; private final XBuildPane this$0;
/*     */                 
/* 246 */                 public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.addDataSource(this.val$win.getDataSource()); }
/*     */                  }
/*     */             );
/*     */         } else {
/*     */           
/* 251 */           addDataSource(xDataSource);
/*     */         } 
/*     */       } catch (Exception exception) {
/* 254 */         exception.printStackTrace();
/* 255 */         JOptionPane.showMessageDialog(this, exception.toString());
/*     */       } 
/*     */     }
/*     */     
/* 259 */     return xDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDataSource(XDataSource paramXDataSource) {
/*     */     try {
/* 267 */       this.repository.updateDataSource(paramXDataSource, null);
/* 268 */       refresh();
/*     */ 
/*     */       
/* 271 */       this.folder.setSelectedIndex(0);
/* 272 */       this.dxtree.setSelected(paramXDataSource.getType() + "." + paramXDataSource.getName(), true);
/*     */     } catch (Exception exception) {
/*     */       
/* 275 */       exception.printStackTrace();
/* 276 */       JOptionPane.showMessageDialog(this, exception.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XQuery newQuery(String paramString1, String paramString2) {
/* 286 */     XQuery xQuery = QueryDialog.prompt(this.dxnames, this.repository, paramString1, paramString2);
/*     */     
/* 288 */     if (xQuery != null) {
/*     */       try {
/* 290 */         if (this.repository.getQuery(xQuery.getName()) != null) {
/* 291 */           JOptionPane.showMessageDialog(this, msg3 + xQuery.getName());
/*     */           
/* 293 */           return null;
/*     */         } 
/*     */         
/* 296 */         this.repository.updateQuery(xQuery, null);
/* 297 */         refresh();
/*     */ 
/*     */         
/* 300 */         this.folder.setSelectedIndex(1);
/* 301 */         this.qtree.setSelected(xQuery.getDataSource().getName() + "." + xQuery.getName(), true);
/*     */       } catch (Exception exception) {
/*     */         
/* 304 */         exception.printStackTrace();
/* 305 */         JOptionPane.showMessageDialog(this, exception.toString());
/*     */       } 
/*     */     }
/*     */     
/* 309 */     return xQuery;
/*     */   }
/*     */   
/* 312 */   protected ActionListener actionListener = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 319 */   public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 327 */   public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireActionEvent(String paramString) {
/* 334 */     if (this.actionListener != null) {
/* 335 */       this.actionListener.actionPerformed(new ActionEvent(this, 1001, paramString));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 344 */   public boolean isValueChanged() { return (this.currpane != null && this.currpane.isValueChanged()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean save() {
/* 351 */     if (this.currpane != null) {
/*     */       try {
/* 353 */         this.currpane.verify();
/*     */       } catch (Exception exception) {
/* 355 */         showMessage(exception.getMessage());
/* 356 */         return false;
/*     */       } 
/*     */       
/*     */       try {
/* 360 */         if (this.currpane instanceof DataSourceProperty) {
/* 361 */           this.repository.updateDataSource(((DataSourceProperty)this.currpane).getDataSource(), null);
/*     */         
/*     */         }
/* 364 */         else if (this.currpane instanceof QueryProperty) {
/* 365 */           this.repository.updateQuery(((QueryProperty)this.currpane).getQuery(), null);
/*     */         } 
/*     */ 
/*     */         
/* 369 */         fireActionEvent("save");
/* 370 */         this.currpane.setValueChanged(false);
/* 371 */         setEnabled();
/*     */       } catch (Exception exception) {
/* 373 */         exception.printStackTrace();
/* 374 */         showMessage(exception.toString());
/* 375 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 379 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void refresh() {
/* 386 */     refreshDataSources();
/* 387 */     refreshQueries();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void refreshDataSources() {
/* 393 */     this.dxnames = this.repository.getDataSourceNames();
/* 394 */     this.dxtree.removeAll();
/*     */ 
/*     */     
/* 397 */     for (byte b = 0; b < this.dxnames.length; b++) {
/* 398 */       XDataSource xDataSource = this.repository.getDataSource(this.dxnames[b]);
/* 399 */       String str = xDataSource.getType() + "." + xDataSource.getName();
/* 400 */       this.dxtree.add(str);
/* 401 */       this.dxtree.setEditable(str, true);
/*     */       
/* 403 */       Image image = Config.getIcon(xDataSource.getType());
/* 404 */       if (image != null) {
/* 405 */         this.dxtree.setIcon(str, new ImageIcon(image));
/* 406 */         this.qtree.setIcon(xDataSource.getName(), new ImageIcon(image));
/*     */       } 
/*     */     } 
/*     */     
/* 410 */     this.dxtree.expandAll();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void refreshQueries() {
/* 416 */     String[] arrayOfString = this.repository.getQueryNames();
/* 417 */     this.qtree.removeAll();
/* 418 */     this.dxnames = this.repository.getDataSourceNames();
/*     */ 
/*     */     
/* 421 */     for (byte b1 = 0; b1 < this.dxnames.length; b1++) {
/* 422 */       XDataSource xDataSource = this.repository.getDataSource(this.dxnames[b1]);
/*     */       
/* 424 */       Image image1 = Config.getIcon(xDataSource.getType());
/* 425 */       if (image1 != null) {
/* 426 */         this.qtree.setIcon(xDataSource.getName(), new ImageIcon(image1));
/*     */       }
/*     */     } 
/*     */     
/* 430 */     Image image = Config.getQueryIcon();
/* 431 */     for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
/* 432 */       XQuery xQuery = this.repository.getQuery(arrayOfString[b2]);
/*     */       
/* 434 */       if (xQuery != null && xQuery.getDataSource() != null) {
/*     */ 
/*     */ 
/*     */         
/* 438 */         String str = xQuery.getDataSource().getName() + "." + xQuery.getName();
/* 439 */         this.qtree.add(str);
/* 440 */         this.qtree.setEditable(str, true);
/*     */         
/* 442 */         if (image != null) {
/* 443 */           this.qtree.setIcon(str, new ImageIcon(image));
/*     */         }
/*     */       } 
/*     */     } 
/* 447 */     this.qtree.expandAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setEnabled() {
/* 454 */     STree.Node node1 = this.dxtree.getSelectedNode();
/* 455 */     STree.Node node2 = this.qtree.getSelectedNode();
/*     */     
/* 457 */     this.varB.setVisible((this.xquery != null));
/* 458 */     this.setB.setVisible((this.currpane != null));
/* 459 */     this.setB.setEnabled((this.currpane != null && this.currpane.isValueChanged()));
/* 460 */     this.deleteB.setEnabled(((node1 != null && node1.isLeaf()) || (node2 != null && node2.isLeaf())));
/*     */     
/* 462 */     this.newB.setEnabled((this.folder.getSelectedIndex() != 1 || this.dxnames.length > 0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 467 */   TreeSelectionListener dxtreeListener = new TreeSelectionListener(this) { private final XBuildPane this$0;
/*     */       
/*     */       public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
/* 470 */         if (param1TreeSelectionEvent.isAddedPath()) {
/* 471 */           this.this$0.xquery = null;
/* 472 */           this.this$0.qtree.clearSelection();
/*     */         } 
/*     */ 
/*     */         
/* 476 */         if (param1TreeSelectionEvent.isAddedPath() && this.this$0.currpane != null && this.this$0.currpane.isValueChanged()) {
/* 477 */           int i = JOptionPane.showConfirmDialog(this.this$0, XBuildPane.msg1, Catalog.getString("Confirm"), 0);
/*     */ 
/*     */           
/* 480 */           if (i == 0) {
/* 481 */             this.this$0.save();
/*     */           }
/*     */         } 
/*     */         
/* 485 */         STree.Node node = this.this$0.dxtree.getSelectedNode();
/* 486 */         if (node != null && node.isLeaf()) {
/*     */           try {
/* 488 */             String str = node.getLabel();
/* 489 */             this.this$0.xds = this.this$0.repository.getDataSource(str);
/*     */             
/* 491 */             if (this.this$0.xds == null) {
/* 492 */               XBuildPane.showMessage("Data source not supported: " + str);
/*     */               
/*     */               return;
/*     */             } 
/* 496 */             DataSourceProperty dataSourceProperty = (DataSourceProperty)this.this$0.dsmap.get(this.this$0.xds.getType());
/*     */             
/* 498 */             if (dataSourceProperty == null) {
/* 499 */               XBuildPane.showMessage("Internal Error: data source editor missing: " + this.this$0.xds.getType());
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/* 505 */             while (this.this$0.qcommand.getComponentCount() > 0) {
/* 506 */               this.this$0.qcommand.remove(0);
/*     */             }
/*     */             
/* 509 */             dataSourceProperty.setDataSource(this.this$0.xds);
/* 510 */             this.this$0.contentLO.show(this.this$0.content, "ds_" + this.this$0.xds.getType());
/* 511 */             this.this$0.currpane = dataSourceProperty;
/*     */             
/* 513 */             if (this.this$0.xds.getDescription() != null) {
/* 514 */               this.this$0.status.setText(this.this$0.xds.getDescription().replace('\n', ' '));
/*     */             }
/*     */           } catch (RemoteException remoteException) {
/* 517 */             remoteException.printStackTrace();
/* 518 */             XBuildPane.showMessage(remoteException.toString());
/*     */           } 
/*     */         }
/*     */         
/* 522 */         this.this$0.setEnabled();
/*     */       } }
/*     */   ;
/*     */ 
/*     */   
/* 527 */   PropertyChangeListener dxmodelListener = new PropertyChangeListener(this) { private final XBuildPane this$0;
/*     */       public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/* 529 */         if (param1PropertyChangeEvent.getPropertyName().equals("nodeLabel")) {
/* 530 */           String str1 = (String)param1PropertyChangeEvent.getNewValue();
/* 531 */           String str2 = (String)param1PropertyChangeEvent.getOldValue();
/*     */           
/* 533 */           int i = str1.indexOf('.');
/* 534 */           str1 = (i >= 0) ? str1.substring(i + 1) : str1;
/* 535 */           i = str2.indexOf('.');
/* 536 */           str2 = (i >= 0) ? str2.substring(i + 1) : str2;
/*     */ 
/*     */ 
/*     */           
/* 540 */           if (this.this$0.xds != null && this.this$0.xds.getName().equals(str2)) {
/* 541 */             this.this$0.xds.setName(str1);
/*     */             try {
/* 543 */               this.this$0.repository.updateDataSource(this.this$0.xds, str2);
/* 544 */               this.this$0.refreshQueries();
/*     */             } catch (Exception exception) {
/* 546 */               exception.printStackTrace();
/* 547 */               XBuildPane.showMessage(exception.toString());
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } }
/*     */   ;
/*     */ 
/*     */   
/* 555 */   TreeSelectionListener qtreeListener = new TreeSelectionListener(this) { private final XBuildPane this$0;
/*     */       
/*     */       public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
/* 558 */         if (param1TreeSelectionEvent.isAddedPath()) {
/* 559 */           this.this$0.xds = null;
/* 560 */           this.this$0.dxtree.clearSelection();
/*     */         } 
/*     */ 
/*     */         
/* 564 */         if (param1TreeSelectionEvent.isAddedPath() && this.this$0.currpane != null && this.this$0.currpane.isValueChanged()) {
/* 565 */           int i = JOptionPane.showConfirmDialog(this.this$0, XBuildPane.msg1, Catalog.getString("Confirm"), 0);
/*     */ 
/*     */           
/* 568 */           if (i == 0) {
/* 569 */             this.this$0.save();
/*     */           }
/*     */         } 
/*     */         
/* 573 */         STree.Node node = this.this$0.qtree.getSelectedNode();
/* 574 */         if (node != null && node.getParent() != null && node.getParent().toString().length() > 0)
/*     */         {
/* 576 */           this.this$0.showQuery(node.getLabel());
/*     */         }
/*     */         
/* 579 */         this.this$0.setEnabled();
/*     */       } }
/*     */   ;
/*     */ 
/*     */   
/* 584 */   PropertyChangeListener qmodelListener = new PropertyChangeListener(this) { private final XBuildPane this$0;
/*     */       public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/* 586 */         if (param1PropertyChangeEvent.getPropertyName().equals("nodeLabel")) {
/* 587 */           String str1 = (String)param1PropertyChangeEvent.getNewValue();
/* 588 */           String str2 = (String)param1PropertyChangeEvent.getOldValue();
/*     */           
/* 590 */           int i = str1.indexOf('.');
/* 591 */           str1 = (i >= 0) ? str1.substring(i + 1) : str1;
/* 592 */           i = str2.indexOf('.');
/* 593 */           str2 = (i >= 0) ? str2.substring(i + 1) : str2;
/*     */ 
/*     */ 
/*     */           
/* 597 */           if (this.this$0.xquery != null && this.this$0.xquery.getName().equals(str2)) {
/* 598 */             this.this$0.xquery.setName(str1);
/*     */             try {
/* 600 */               this.this$0.repository.updateQuery(this.this$0.xquery, str2);
/*     */             } catch (Exception exception) {
/* 602 */               exception.printStackTrace();
/* 603 */               JOptionPane.showMessageDialog(this.this$0, exception.toString());
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } }
/*     */   ;
/*     */   
/* 610 */   ChangeListener changeListener = new ChangeListener(this) { private final XBuildPane this$0;
/*     */       
/* 612 */       public void stateChanged(ChangeEvent param1ChangeEvent) { this.this$0.setEnabled(); } }
/*     */   ;
/*     */ 
/*     */ 
/*     */   
/* 617 */   ActionListener setListener = new ActionListener(this) { private final XBuildPane this$0;
/*     */       
/* 619 */       public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.save(); } }
/*     */   ;
/*     */ 
/*     */ 
/*     */   
/* 624 */   ActionListener newListener = new ActionListener(this) { private final XBuildPane this$0;
/*     */       
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 627 */         if (this.this$0.folder.getSelectedIndex() == 0) {
/* 628 */           String str = this.this$0.dxtree.getSelectedPath();
/*     */           
/* 630 */           if (str != null) {
/* 631 */             int i = str.indexOf('.');
/* 632 */             if (i > 0) {
/* 633 */               str = str.substring(0, i);
/*     */             }
/*     */           } 
/*     */           
/* 637 */           this.this$0.newDataSource(str);
/*     */         
/*     */         }
/* 640 */         else if (this.this$0.folder.getSelectedIndex() == 1) {
/* 641 */           String str1 = null, str2 = null;
/*     */           
/* 643 */           String str3 = this.this$0.qtree.getSelectedPath();
/*     */           
/* 645 */           if (str3 != null) {
/* 646 */             int i = str3.indexOf('.');
/* 647 */             if (i > 0) {
/* 648 */               str1 = str3.substring(0, i);
/* 649 */               str2 = str3.substring(i + 1);
/*     */             } else {
/*     */               
/* 652 */               str1 = str3;
/*     */             } 
/*     */           } 
/*     */           
/* 656 */           this.this$0.newQuery(str1, str2);
/*     */         } 
/*     */       } }
/*     */   ;
/*     */ 
/*     */   
/* 662 */   ActionListener deleteListener = new ActionListener(this) { private final XBuildPane this$0;
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 664 */         STree.Node node1 = this.this$0.dxtree.getSelectedNode();
/* 665 */         STree.Node node2 = this.this$0.qtree.getSelectedNode();
/*     */         
/* 667 */         int i = JOptionPane.showConfirmDialog(this.this$0, (node1 != null) ? XBuildPane.msg_dx : XBuildPane.msg_q, Catalog.getString("Confirm"), 0);
/*     */ 
/*     */ 
/*     */         
/* 671 */         if (i != 0) {
/*     */           return;
/*     */         }
/*     */         
/*     */         try {
/* 676 */           if (node1 != null && node1.isLeaf()) {
/* 677 */             this.this$0.repository.removeDataSource(node1.getLabel());
/*     */           }
/* 679 */           else if (node2 != null && node2.isLeaf()) {
/* 680 */             this.this$0.repository.removeQuery(node2.getLabel());
/*     */           } 
/*     */           
/* 683 */           this.this$0.currpane = null;
/* 684 */           this.this$0.refresh();
/*     */         } catch (IOException iOException) {
/* 686 */           JOptionPane.showMessageDialog(this.this$0, iOException.getMessage());
/*     */         } catch (Exception exception) {
/* 688 */           exception.printStackTrace();
/* 689 */           JOptionPane.showMessageDialog(this.this$0, exception.toString());
/*     */         } 
/*     */       } }
/*     */   ;
/*     */ 
/*     */   
/* 695 */   ActionListener varListener = new ActionListener(this) { private final XBuildPane this$0;
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 697 */         VariableDialog variableDialog = new VariableDialog(this.this$0.repository, this.this$0.xquery);
/* 698 */         variableDialog.pack();
/* 699 */         variableDialog.setVisible(true);
/*     */       } }
/*     */   ;
/*     */   class RenameListener implements ActionListener { JTree tree; TreePath path; private final XBuildPane this$0;
/*     */     
/*     */     public RenameListener(XBuildPane this$0, JTree param1JTree, TreePath param1TreePath) {
/* 705 */       this.this$0 = this$0;
/* 706 */       this.tree = param1JTree;
/* 707 */       this.path = param1TreePath;
/*     */     }
/*     */ 
/*     */     
/* 711 */     public void actionPerformed(ActionEvent param1ActionEvent) { this.tree.startEditingAtPath(this.path); } }
/*     */ 
/*     */   
/*     */   class DescListener implements ActionListener {
/*     */     String name;
/*     */     boolean isquery;
/*     */     private final XBuildPane this$0;
/*     */     
/*     */     public DescListener(XBuildPane this$0, String param1String, boolean param1Boolean) {
/* 720 */       this.this$0 = this$0;
/* 721 */       this.name = param1String;
/* 722 */       this.isquery = param1Boolean;
/*     */     }
/*     */     
/*     */     public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */       try {
/* 727 */         boolean bool = DescriptionDialog.show(this.isquery ? this.this$0.repository.getQuery(this.name) : this.this$0.repository.getDataSource(this.name));
/*     */ 
/*     */         
/* 730 */         if (bool) {
/* 731 */           this.this$0.currpane.setValueChanged(true);
/* 732 */           this.this$0.setEnabled();
/*     */         } 
/*     */       } catch (Exception exception) {
/* 735 */         XBuildPane.showMessage(exception.toString());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 744 */   MouseListener menuListener = new MouseAdapter(this) { private final XBuildPane this$0;
/*     */       public void mousePressed(MouseEvent param1MouseEvent) {
/* 746 */         if (param1MouseEvent.isPopupTrigger()) {
/* 747 */           STree sTree = (STree)param1MouseEvent.getSource();
/* 748 */           TreePath treePath = sTree.getSelectionPath();
/* 749 */           String str = sTree.getSelectedLabel();
/*     */           
/* 751 */           if (treePath != null && ((this.this$0.xquery != null && this.this$0.xquery.getName().equals(str)) || (this.this$0.xds != null && this.this$0.xds.getName().equals(str)))) {
/*     */ 
/*     */             
/* 754 */             JPopupMenu jPopupMenu = new JPopupMenu();
/*     */             
/*     */             JMenuItem jMenuItem;
/* 757 */             jPopupMenu.add(jMenuItem = new JMenuItem(Catalog.getString("Rename")));
/* 758 */             jMenuItem.addActionListener(new XBuildPane.RenameListener(this.this$0, sTree, treePath));
/* 759 */             jPopupMenu.add(jMenuItem = new JMenuItem(Catalog.getString("Description...")));
/*     */             
/* 761 */             jMenuItem.addActionListener(new XBuildPane.DescListener(this.this$0, str, (sTree == this.this$0.qtree)));
/*     */             
/* 763 */             jPopupMenu.show(sTree, param1MouseEvent.getX(), param1MouseEvent.getY());
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 769 */       public void mouseReleased(MouseEvent param1MouseEvent) { mousePressed(param1MouseEvent); } }
/*     */   ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 777 */   public static void showMessage(String paramString) { JOptionPane.showMessageDialog(null, paramString, Catalog.getString("Error"), 0); }
/*     */ 
/*     */ 
/*     */   
/* 781 */   static final String msg1 = Catalog.getString("Valued changed for the current selection. Save before changing selection?");
/* 782 */   static final String msg_dx = Catalog.getString("Remove the selected DataSource?");
/* 783 */   static final String msg_q = Catalog.getString("Remove the selected Query?");
/* 784 */   static final String msg2 = Catalog.getString("Datasource exists") + ": ";
/* 785 */   static final String msg3 = Catalog.getString("Query exists") + ": ";
/*     */   
/*     */   JPanel cmdPane;
/* 788 */   STree dxtree = new STree();
/* 789 */   STree qtree = new STree();
/* 790 */   JPanel content = new JPanel();
/* 791 */   CardLayout contentLO = new CardLayout();
/* 792 */   JTabbedPane folder = new JTabbedPane();
/*     */   JSplitPane spliter;
/* 794 */   JLabel status = new JLabel(" ");
/* 795 */   JButton setB = new JButton(Catalog.getString("Set"));
/* 796 */   JButton newB = new JButton(Catalog.getString("New"));
/* 797 */   JButton deleteB = new JButton(Catalog.getString("Delete"));
/* 798 */   JButton varB = new JButton(Catalog.getString("Variables") + "...");
/* 799 */   JPanel qcommand = new JPanel();
/*     */   
/* 801 */   String[] dxnames = null;
/* 802 */   PropertyPane currpane = null;
/*     */   
/*     */   XRepository repository;
/*     */   XDataSource xds;
/*     */   XQuery xquery;
/*     */   Object session;
/* 808 */   Hashtable dsmap = new Hashtable();
/* 809 */   Hashtable qmap = new Hashtable();
/*     */ 
/*     */   
/*     */   public XBuildPane(XRepository paramXRepository) {
/*     */     try {
/* 814 */       Enumeration enumeration1 = Config.getDataSourceTypes();
/* 815 */       while (enumeration1.hasMoreElements()) {
/* 816 */         String str1 = (String)enumeration1.nextElement();
/*     */         
/* 818 */         String str2 = Config.getDataSourcePane(str1); PropertyPane propertyPane1;
/* 819 */         this.dsmap.put(str1, propertyPane1 = (PropertyPane)Class.forName(str2).newInstance());
/*     */         
/* 821 */         propertyPane1.addChangeListener(this.changeListener);
/*     */         
/* 823 */         String str3 = Config.getQueryPane(str1);
/* 824 */         this.qmap.put(str1, propertyPane1 = (PropertyPane)Class.forName(str3).newInstance());
/*     */         
/* 826 */         propertyPane1.addChangeListener(this.changeListener);
/*     */       } 
/*     */       
/* 829 */       String str = Config.getQueryPane("derived"); PropertyPane propertyPane;
/* 830 */       this.qmap.put("derived", propertyPane = (PropertyPane)Class.forName(str).newInstance());
/*     */       
/* 832 */       propertyPane.addChangeListener(this.changeListener);
/*     */     } catch (Exception exception) {
/* 834 */       XLog.print(exception);
/*     */     } 
/*     */     setLayout(new BorderLayout());
/*     */     this.folder.add(new JScrollPane(this.dxtree), Catalog.getString("Datasource"));
/*     */     this.folder.add(new JScrollPane(this.qtree), Catalog.getString("Query"));
/*     */     this.folder.setSelectedIndex(1);
/*     */     JPanel jPanel1 = new JPanel();
/*     */     jPanel1.setLayout(new BorderLayout(5, 5));
/*     */     jPanel1.add(this.folder, "Center");
/*     */     JPanel jPanel2 = new JPanel();
/*     */     jPanel2.add(this.newB);
/*     */     jPanel2.add(this.deleteB);
/*     */     jPanel1.add(jPanel2, "South");
/*     */     this.content.setLayout(this.contentLO);
/*     */     this.content.setPreferredSize(new Dimension(450, 400));
/*     */     this.content.setMinimumSize(new Dimension(400, 400));
/*     */     this.content.add(new JLabel(""), "__null__");
/*     */     Enumeration enumeration = this.dsmap.keys();
/*     */     while (enumeration.hasMoreElements()) {
/*     */       String str = (String)enumeration.nextElement();
/*     */       Component component = (Component)this.dsmap.get(str);
/*     */       this.content.add(component, "ds_" + str);
/*     */     } 
/*     */     enumeration = this.qmap.keys();
/*     */     while (enumeration.hasMoreElements()) {
/*     */       String str = (String)enumeration.nextElement();
/*     */       Component component = (Component)this.qmap.get(str);
/*     */       this.content.add(component, "q_" + str);
/*     */     } 
/*     */     JPanel jPanel3 = new JPanel();
/*     */     jPanel3.setLayout(new BorderLayout(5, 5));
/*     */     jPanel3.add(this.content, "Center");
/*     */     this.cmdPane = new JPanel();
/*     */     this.cmdPane.setLayout(new FlowLayout(2, 10, 5));
/*     */     this.qcommand.setLayout(new FlowLayout(2, 0, 0));
/*     */     this.cmdPane.add(this.qcommand);
/*     */     this.cmdPane.add(this.varB);
/*     */     this.cmdPane.add(this.setB);
/*     */     this.cmdPane.add(new JLabel(" "));
/*     */     jPanel3.add(this.cmdPane, "South");
/*     */     this.spliter = new JSplitPane(1, jPanel1, jPanel3);
/*     */     this.spliter.setPreferredSize(new Dimension(700, 450));
/*     */     this.spliter.setDividerLocation(200);
/*     */     add(this.spliter, "Center");
/*     */     this.status.setBorder(new EtchedBorder());
/*     */     add(this.status, "South");
/*     */     this.dxtree.setSorting(1);
/*     */     this.qtree.setSorting(1);
/*     */     try {
/*     */       if (paramXRepository == null) {
/*     */         this.repository = XFactory.getRepository();
/*     */       } else {
/*     */         this.repository = paramXRepository;
/*     */       } 
/*     */       this.session = this.repository.bind(System.getProperty("user.name"));
/*     */       refresh();
/*     */     } catch (Exception exception) {
/*     */       XLog.print(exception);
/*     */       JOptionPane.showMessageDialog(this, exception.toString());
/*     */     } 
/*     */     this.dxtree.getSelectionModel().setSelectionMode(1);
/*     */     this.qtree.getSelectionModel().setSelectionMode(1);
/*     */     this.folder.addChangeListener(this.changeListener);
/*     */     this.dxtree.addTreeSelectionListener(this.dxtreeListener);
/*     */     this.dxtree.addPropertyChangeListener(this.dxmodelListener);
/*     */     this.dxtree.addMouseListener(this.menuListener);
/*     */     this.qtree.addTreeSelectionListener(this.qtreeListener);
/*     */     this.qtree.addPropertyChangeListener(this.qmodelListener);
/*     */     this.qtree.addMouseListener(this.menuListener);
/*     */     this.setB.addActionListener(this.setListener);
/*     */     this.newB.addActionListener(this.newListener);
/*     */     this.deleteB.addActionListener(this.deleteListener);
/*     */     this.varB.addActionListener(this.varListener);
/*     */     setEnabled();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\XBuildPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */