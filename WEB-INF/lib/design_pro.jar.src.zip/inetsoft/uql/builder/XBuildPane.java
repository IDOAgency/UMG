package inetsoft.uql.builder;

import inetsoft.uql.XDataSource;
import inetsoft.uql.XFactory;
import inetsoft.uql.XLog;
import inetsoft.uql.XQuery;
import inetsoft.uql.XRepository;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.util.Config;
import inetsoft.uql.util.gui.VariableDialog;
import inetsoft.widget.STree;
import java.awt.AWTEventMulticaster;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTree;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;

public class XBuildPane extends JPanel {
  public XBuildPane() { this(null); }
  
  public XRepository getRepository() { return this.repository; }
  
  public Object getSession() { return this.session; }
  
  public void showQuery(String paramString) {
    try {
      this.xquery = this.repository.getQuery(paramString);
      if (this.xquery == null) {
        showMessage("Query not defined: " + paramString);
        return;
      } 
      QueryProperty queryProperty = (QueryProperty)this.qmap.get(this.xquery.getType());
      if (queryProperty == null) {
        showMessage("Internal Error: query editor missing: " + this.xquery.getType());
        return;
      } 
      queryProperty.setSession(this.session);
      queryProperty.setQuery(this.xquery);
      while (this.qcommand.getComponentCount() > 0)
        this.qcommand.remove(0); 
      if (queryProperty.getCommandPane() != null)
        this.qcommand.add(queryProperty.getCommandPane()); 
      this.contentLO.show(this.content, "q_" + this.xquery.getType());
      this.currpane = queryProperty;
      this.currpane.setValueChanged(false);
      this.qtree.removeTreeSelectionListener(this.qtreeListener);
      this.qtree.setSelected(this.xquery.getDataSource().getName() + "." + this.xquery.getName(), true);
      this.qtree.addTreeSelectionListener(this.qtreeListener);
      setEnabled();
      if (this.xquery.getDescription() != null) {
        this.status.setText(this.xquery.getDescription().replace('\n', ' '));
      } else {
        this.status.setText(" ");
      } 
    } catch (RemoteException remoteException) {
      remoteException.printStackTrace();
      showMessage(remoteException.toString());
    } 
  }
  
  public XDataSource newDataSource(String paramString) {
    XDataSource xDataSource = DataSourceDialog.prompt(paramString);
    if (xDataSource != null)
      try {
        if (this.repository.getDataSource(xDataSource.getName()) != null) {
          JOptionPane.showMessageDialog(this, msg2 + xDataSource.getName());
          return null;
        } 
        String str = Config.getDataSourceWizard(xDataSource.getType());
        if (str != null) {
          DataSourceWizard dataSourceWizard = (DataSourceWizard)Class.forName(str).newInstance();
          dataSourceWizard.setDataSource(xDataSource);
          dataSourceWizard.show(new ActionListener(this, dataSourceWizard) {
                private final DataSourceWizard val$win;
                
                private final XBuildPane this$0;
                
                public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.addDataSource(this.val$win.getDataSource()); }
              });
        } else {
          addDataSource(xDataSource);
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
        JOptionPane.showMessageDialog(this, exception.toString());
      }  
    return xDataSource;
  }
  
  public void addDataSource(XDataSource paramXDataSource) {
    try {
      this.repository.updateDataSource(paramXDataSource, null);
      refresh();
      this.folder.setSelectedIndex(0);
      this.dxtree.setSelected(paramXDataSource.getType() + "." + paramXDataSource.getName(), true);
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(this, exception.toString());
    } 
  }
  
  public XQuery newQuery(String paramString1, String paramString2) {
    XQuery xQuery = QueryDialog.prompt(this.dxnames, this.repository, paramString1, paramString2);
    if (xQuery != null)
      try {
        if (this.repository.getQuery(xQuery.getName()) != null) {
          JOptionPane.showMessageDialog(this, msg3 + xQuery.getName());
          return null;
        } 
        this.repository.updateQuery(xQuery, null);
        refresh();
        this.folder.setSelectedIndex(1);
        this.qtree.setSelected(xQuery.getDataSource().getName() + "." + xQuery.getName(), true);
      } catch (Exception exception) {
        exception.printStackTrace();
        JOptionPane.showMessageDialog(this, exception.toString());
      }  
    return xQuery;
  }
  
  protected ActionListener actionListener = null;
  
  public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
  
  protected void fireActionEvent(String paramString) {
    if (this.actionListener != null)
      this.actionListener.actionPerformed(new ActionEvent(this, 1001, paramString)); 
  }
  
  public boolean isValueChanged() { return (this.currpane != null && this.currpane.isValueChanged()); }
  
  public boolean save() {
    if (this.currpane != null) {
      try {
        this.currpane.verify();
      } catch (Exception exception) {
        showMessage(exception.getMessage());
        return false;
      } 
      try {
        if (this.currpane instanceof DataSourceProperty) {
          this.repository.updateDataSource(((DataSourceProperty)this.currpane).getDataSource(), null);
        } else if (this.currpane instanceof QueryProperty) {
          this.repository.updateQuery(((QueryProperty)this.currpane).getQuery(), null);
        } 
        fireActionEvent("save");
        this.currpane.setValueChanged(false);
        setEnabled();
      } catch (Exception exception) {
        exception.printStackTrace();
        showMessage(exception.toString());
        return false;
      } 
    } 
    return true;
  }
  
  private void refresh() {
    refreshDataSources();
    refreshQueries();
  }
  
  private void refreshDataSources() {
    this.dxnames = this.repository.getDataSourceNames();
    this.dxtree.removeAll();
    for (byte b = 0; b < this.dxnames.length; b++) {
      XDataSource xDataSource = this.repository.getDataSource(this.dxnames[b]);
      String str = xDataSource.getType() + "." + xDataSource.getName();
      this.dxtree.add(str);
      this.dxtree.setEditable(str, true);
      Image image = Config.getIcon(xDataSource.getType());
      if (image != null) {
        this.dxtree.setIcon(str, new ImageIcon(image));
        this.qtree.setIcon(xDataSource.getName(), new ImageIcon(image));
      } 
    } 
    this.dxtree.expandAll();
  }
  
  private void refreshQueries() {
    String[] arrayOfString = this.repository.getQueryNames();
    this.qtree.removeAll();
    this.dxnames = this.repository.getDataSourceNames();
    for (byte b1 = 0; b1 < this.dxnames.length; b1++) {
      XDataSource xDataSource = this.repository.getDataSource(this.dxnames[b1]);
      Image image1 = Config.getIcon(xDataSource.getType());
      if (image1 != null)
        this.qtree.setIcon(xDataSource.getName(), new ImageIcon(image1)); 
    } 
    Image image = Config.getQueryIcon();
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      XQuery xQuery = this.repository.getQuery(arrayOfString[b2]);
      if (xQuery != null && xQuery.getDataSource() != null) {
        String str = xQuery.getDataSource().getName() + "." + xQuery.getName();
        this.qtree.add(str);
        this.qtree.setEditable(str, true);
        if (image != null)
          this.qtree.setIcon(str, new ImageIcon(image)); 
      } 
    } 
    this.qtree.expandAll();
  }
  
  private void setEnabled() {
    STree.Node node1 = this.dxtree.getSelectedNode();
    STree.Node node2 = this.qtree.getSelectedNode();
    this.varB.setVisible((this.xquery != null));
    this.setB.setVisible((this.currpane != null));
    this.setB.setEnabled((this.currpane != null && this.currpane.isValueChanged()));
    this.deleteB.setEnabled(((node1 != null && node1.isLeaf()) || (node2 != null && node2.isLeaf())));
    this.newB.setEnabled((this.folder.getSelectedIndex() != 1 || this.dxnames.length > 0));
  }
  
  TreeSelectionListener dxtreeListener = new TreeSelectionListener(this) {
      private final XBuildPane this$0;
      
      public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
        if (param1TreeSelectionEvent.isAddedPath()) {
          this.this$0.xquery = null;
          this.this$0.qtree.clearSelection();
        } 
        if (param1TreeSelectionEvent.isAddedPath() && this.this$0.currpane != null && this.this$0.currpane.isValueChanged()) {
          int i = JOptionPane.showConfirmDialog(this.this$0, XBuildPane.msg1, Catalog.getString("Confirm"), 0);
          if (i == 0)
            this.this$0.save(); 
        } 
        STree.Node node = this.this$0.dxtree.getSelectedNode();
        if (node != null && node.isLeaf())
          try {
            String str = node.getLabel();
            this.this$0.xds = this.this$0.repository.getDataSource(str);
            if (this.this$0.xds == null) {
              XBuildPane.showMessage("Data source not supported: " + str);
              return;
            } 
            DataSourceProperty dataSourceProperty = (DataSourceProperty)this.this$0.dsmap.get(this.this$0.xds.getType());
            if (dataSourceProperty == null) {
              XBuildPane.showMessage("Internal Error: data source editor missing: " + this.this$0.xds.getType());
              return;
            } 
            while (this.this$0.qcommand.getComponentCount() > 0)
              this.this$0.qcommand.remove(0); 
            dataSourceProperty.setDataSource(this.this$0.xds);
            this.this$0.contentLO.show(this.this$0.content, "ds_" + this.this$0.xds.getType());
            this.this$0.currpane = dataSourceProperty;
            if (this.this$0.xds.getDescription() != null)
              this.this$0.status.setText(this.this$0.xds.getDescription().replace('\n', ' ')); 
          } catch (RemoteException remoteException) {
            remoteException.printStackTrace();
            XBuildPane.showMessage(remoteException.toString());
          }  
        this.this$0.setEnabled();
      }
    };
  
  PropertyChangeListener dxmodelListener = new PropertyChangeListener(this) {
      private final XBuildPane this$0;
      
      public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
        if (param1PropertyChangeEvent.getPropertyName().equals("nodeLabel")) {
          String str1 = (String)param1PropertyChangeEvent.getNewValue();
          String str2 = (String)param1PropertyChangeEvent.getOldValue();
          int i = str1.indexOf('.');
          str1 = (i >= 0) ? str1.substring(i + 1) : str1;
          i = str2.indexOf('.');
          str2 = (i >= 0) ? str2.substring(i + 1) : str2;
          if (this.this$0.xds != null && this.this$0.xds.getName().equals(str2)) {
            this.this$0.xds.setName(str1);
            try {
              this.this$0.repository.updateDataSource(this.this$0.xds, str2);
              this.this$0.refreshQueries();
            } catch (Exception exception) {
              exception.printStackTrace();
              XBuildPane.showMessage(exception.toString());
            } 
          } 
        } 
      }
    };
  
  TreeSelectionListener qtreeListener = new TreeSelectionListener(this) {
      private final XBuildPane this$0;
      
      public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
        if (param1TreeSelectionEvent.isAddedPath()) {
          this.this$0.xds = null;
          this.this$0.dxtree.clearSelection();
        } 
        if (param1TreeSelectionEvent.isAddedPath() && this.this$0.currpane != null && this.this$0.currpane.isValueChanged()) {
          int i = JOptionPane.showConfirmDialog(this.this$0, XBuildPane.msg1, Catalog.getString("Confirm"), 0);
          if (i == 0)
            this.this$0.save(); 
        } 
        STree.Node node = this.this$0.qtree.getSelectedNode();
        if (node != null && node.getParent() != null && node.getParent().toString().length() > 0)
          this.this$0.showQuery(node.getLabel()); 
        this.this$0.setEnabled();
      }
    };
  
  PropertyChangeListener qmodelListener = new PropertyChangeListener(this) {
      private final XBuildPane this$0;
      
      public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
        if (param1PropertyChangeEvent.getPropertyName().equals("nodeLabel")) {
          String str1 = (String)param1PropertyChangeEvent.getNewValue();
          String str2 = (String)param1PropertyChangeEvent.getOldValue();
          int i = str1.indexOf('.');
          str1 = (i >= 0) ? str1.substring(i + 1) : str1;
          i = str2.indexOf('.');
          str2 = (i >= 0) ? str2.substring(i + 1) : str2;
          if (this.this$0.xquery != null && this.this$0.xquery.getName().equals(str2)) {
            this.this$0.xquery.setName(str1);
            try {
              this.this$0.repository.updateQuery(this.this$0.xquery, str2);
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString());
            } 
          } 
        } 
      }
    };
  
  ChangeListener changeListener = new ChangeListener(this) {
      private final XBuildPane this$0;
      
      public void stateChanged(ChangeEvent param1ChangeEvent) { this.this$0.setEnabled(); }
    };
  
  ActionListener setListener = new ActionListener(this) {
      private final XBuildPane this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.save(); }
    };
  
  ActionListener newListener = new ActionListener(this) {
      private final XBuildPane this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        if (this.this$0.folder.getSelectedIndex() == 0) {
          String str = this.this$0.dxtree.getSelectedPath();
          if (str != null) {
            int i = str.indexOf('.');
            if (i > 0)
              str = str.substring(0, i); 
          } 
          this.this$0.newDataSource(str);
        } else if (this.this$0.folder.getSelectedIndex() == 1) {
          String str1 = null, str2 = null;
          String str3 = this.this$0.qtree.getSelectedPath();
          if (str3 != null) {
            int i = str3.indexOf('.');
            if (i > 0) {
              str1 = str3.substring(0, i);
              str2 = str3.substring(i + 1);
            } else {
              str1 = str3;
            } 
          } 
          this.this$0.newQuery(str1, str2);
        } 
      }
    };
  
  ActionListener deleteListener = new ActionListener(this) {
      private final XBuildPane this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        STree.Node node1 = this.this$0.dxtree.getSelectedNode();
        STree.Node node2 = this.this$0.qtree.getSelectedNode();
        int i = JOptionPane.showConfirmDialog(this.this$0, (node1 != null) ? XBuildPane.msg_dx : XBuildPane.msg_q, Catalog.getString("Confirm"), 0);
        if (i != 0)
          return; 
        try {
          if (node1 != null && node1.isLeaf()) {
            this.this$0.repository.removeDataSource(node1.getLabel());
          } else if (node2 != null && node2.isLeaf()) {
            this.this$0.repository.removeQuery(node2.getLabel());
          } 
          this.this$0.currpane = null;
          this.this$0.refresh();
        } catch (IOException iOException) {
          JOptionPane.showMessageDialog(this.this$0, iOException.getMessage());
        } catch (Exception exception) {
          exception.printStackTrace();
          JOptionPane.showMessageDialog(this.this$0, exception.toString());
        } 
      }
    };
  
  ActionListener varListener = new ActionListener(this) {
      private final XBuildPane this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        VariableDialog variableDialog = new VariableDialog(this.this$0.repository, this.this$0.xquery);
        variableDialog.pack();
        variableDialog.setVisible(true);
      }
    };
  
  class RenameListener implements ActionListener {
    JTree tree;
    
    TreePath path;
    
    private final XBuildPane this$0;
    
    public RenameListener(XBuildPane this$0, JTree param1JTree, TreePath param1TreePath) {
      this.this$0 = this$0;
      this.tree = param1JTree;
      this.path = param1TreePath;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) { this.tree.startEditingAtPath(this.path); }
  }
  
  class DescListener implements ActionListener {
    String name;
    
    boolean isquery;
    
    private final XBuildPane this$0;
    
    public DescListener(XBuildPane this$0, String param1String, boolean param1Boolean) {
      this.this$0 = this$0;
      this.name = param1String;
      this.isquery = param1Boolean;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) {
      try {
        boolean bool = DescriptionDialog.show(this.isquery ? this.this$0.repository.getQuery(this.name) : this.this$0.repository.getDataSource(this.name));
        if (bool) {
          this.this$0.currpane.setValueChanged(true);
          this.this$0.setEnabled();
        } 
      } catch (Exception exception) {
        XBuildPane.showMessage(exception.toString());
      } 
    }
  }
  
  MouseListener menuListener = new MouseAdapter(this) {
      private final XBuildPane this$0;
      
      public void mousePressed(MouseEvent param1MouseEvent) {
        if (param1MouseEvent.isPopupTrigger()) {
          STree sTree = (STree)param1MouseEvent.getSource();
          TreePath treePath = sTree.getSelectionPath();
          String str = sTree.getSelectedLabel();
          if (treePath != null && ((this.this$0.xquery != null && this.this$0.xquery.getName().equals(str)) || (this.this$0.xds != null && this.this$0.xds.getName().equals(str)))) {
            JPopupMenu jPopupMenu = new JPopupMenu();
            JMenuItem jMenuItem;
            jPopupMenu.add(jMenuItem = new JMenuItem(Catalog.getString("Rename")));
            jMenuItem.addActionListener(new XBuildPane.RenameListener(this.this$0, sTree, treePath));
            jPopupMenu.add(jMenuItem = new JMenuItem(Catalog.getString("Description...")));
            jMenuItem.addActionListener(new XBuildPane.DescListener(this.this$0, str, (sTree == this.this$0.qtree)));
            jPopupMenu.show(sTree, param1MouseEvent.getX(), param1MouseEvent.getY());
          } 
        } 
      }
      
      public void mouseReleased(MouseEvent param1MouseEvent) { mousePressed(param1MouseEvent); }
    };
  
  public static void showMessage(String paramString) { JOptionPane.showMessageDialog(null, paramString, Catalog.getString("Error"), 0); }
  
  static final String msg1 = Catalog.getString("Valued changed for the current selection. Save before changing selection?");
  
  static final String msg_dx = Catalog.getString("Remove the selected DataSource?");
  
  static final String msg_q = Catalog.getString("Remove the selected Query?");
  
  static final String msg2 = Catalog.getString("Datasource exists") + ": ";
  
  static final String msg3 = Catalog.getString("Query exists") + ": ";
  
  JPanel cmdPane;
  
  STree dxtree = new STree();
  
  STree qtree = new STree();
  
  JPanel content = new JPanel();
  
  CardLayout contentLO = new CardLayout();
  
  JTabbedPane folder = new JTabbedPane();
  
  JSplitPane spliter;
  
  JLabel status = new JLabel(" ");
  
  JButton setB = new JButton(Catalog.getString("Set"));
  
  JButton newB = new JButton(Catalog.getString("New"));
  
  JButton deleteB = new JButton(Catalog.getString("Delete"));
  
  JButton varB = new JButton(Catalog.getString("Variables") + "...");
  
  JPanel qcommand = new JPanel();
  
  String[] dxnames = null;
  
  PropertyPane currpane = null;
  
  XRepository repository;
  
  XDataSource xds;
  
  XQuery xquery;
  
  Object session;
  
  Hashtable dsmap = new Hashtable();
  
  Hashtable qmap = new Hashtable();
  
  public XBuildPane(XRepository paramXRepository) {
    try {
      Enumeration enumeration1 = Config.getDataSourceTypes();
      while (enumeration1.hasMoreElements()) {
        String str1 = (String)enumeration1.nextElement();
        String str2 = Config.getDataSourcePane(str1);
        PropertyPane propertyPane1;
        this.dsmap.put(str1, propertyPane1 = (PropertyPane)Class.forName(str2).newInstance());
        propertyPane1.addChangeListener(this.changeListener);
        String str3 = Config.getQueryPane(str1);
        this.qmap.put(str1, propertyPane1 = (PropertyPane)Class.forName(str3).newInstance());
        propertyPane1.addChangeListener(this.changeListener);
      } 
      String str = Config.getQueryPane("derived");
      PropertyPane propertyPane;
      this.qmap.put("derived", propertyPane = (PropertyPane)Class.forName(str).newInstance());
      propertyPane.addChangeListener(this.changeListener);
    } catch (Exception exception) {
      XLog.print(exception);
    } 
    setLayout(new BorderLayout());
    this.folder.add(new JScrollPane(this.dxtree), Catalog.getString("Datasource"));
    this.folder.add(new JScrollPane(this.qtree), Catalog.getString("Query"));
    this.folder.setSelectedIndex(1);
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout(5, 5));
    jPanel1.add(this.folder, "Center");
    JPanel jPanel2 = new JPanel();
    jPanel2.add(this.newB);
    jPanel2.add(this.deleteB);
    jPanel1.add(jPanel2, "South");
    this.content.setLayout(this.contentLO);
    this.content.setPreferredSize(new Dimension(450, 400));
    this.content.setMinimumSize(new Dimension(400, 400));
    this.content.add(new JLabel(""), "__null__");
    Enumeration enumeration = this.dsmap.keys();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      Component component = (Component)this.dsmap.get(str);
      this.content.add(component, "ds_" + str);
    } 
    enumeration = this.qmap.keys();
    while (enumeration.hasMoreElements()) {
      String str = (String)enumeration.nextElement();
      Component component = (Component)this.qmap.get(str);
      this.content.add(component, "q_" + str);
    } 
    JPanel jPanel3 = new JPanel();
    jPanel3.setLayout(new BorderLayout(5, 5));
    jPanel3.add(this.content, "Center");
    this.cmdPane = new JPanel();
    this.cmdPane.setLayout(new FlowLayout(2, 10, 5));
    this.qcommand.setLayout(new FlowLayout(2, 0, 0));
    this.cmdPane.add(this.qcommand);
    this.cmdPane.add(this.varB);
    this.cmdPane.add(this.setB);
    this.cmdPane.add(new JLabel(" "));
    jPanel3.add(this.cmdPane, "South");
    this.spliter = new JSplitPane(1, jPanel1, jPanel3);
    this.spliter.setPreferredSize(new Dimension(700, 450));
    this.spliter.setDividerLocation(200);
    add(this.spliter, "Center");
    this.status.setBorder(new EtchedBorder());
    add(this.status, "South");
    this.dxtree.setSorting(1);
    this.qtree.setSorting(1);
    try {
      if (paramXRepository == null) {
        this.repository = XFactory.getRepository();
      } else {
        this.repository = paramXRepository;
      } 
      this.session = this.repository.bind(System.getProperty("user.name"));
      refresh();
    } catch (Exception exception) {
      XLog.print(exception);
      JOptionPane.showMessageDialog(this, exception.toString());
    } 
    this.dxtree.getSelectionModel().setSelectionMode(1);
    this.qtree.getSelectionModel().setSelectionMode(1);
    this.folder.addChangeListener(this.changeListener);
    this.dxtree.addTreeSelectionListener(this.dxtreeListener);
    this.dxtree.addPropertyChangeListener(this.dxmodelListener);
    this.dxtree.addMouseListener(this.menuListener);
    this.qtree.addTreeSelectionListener(this.qtreeListener);
    this.qtree.addPropertyChangeListener(this.qmodelListener);
    this.qtree.addMouseListener(this.menuListener);
    this.setB.addActionListener(this.setListener);
    this.newB.addActionListener(this.newListener);
    this.deleteB.addActionListener(this.deleteListener);
    this.varB.addActionListener(this.varListener);
    setEnabled();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\XBuildPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */