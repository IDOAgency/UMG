/*     */ package inetsoft.uql.builder;
/*     */ 
/*     */ import inetsoft.uql.XDataSource;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.util.Config;
/*     */ import inetsoft.util.internal.Property2Panel;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataSourceDialog
/*     */   extends JDialog
/*     */ {
/*     */   ActionListener okListener;
/*     */   XDataSource datasource;
/*     */   JTextField nameTF;
/*     */   JComboBox typeCB;
/*     */   JTextArea descTF;
/*     */   JButton okB;
/*     */   JButton cancelB;
/*     */   
/*     */   public static XDataSource prompt(String paramString) {
/*  37 */     DataSourceDialog dataSourceDialog = new DataSourceDialog();
/*  38 */     dataSourceDialog.setType(paramString);
/*  39 */     dataSourceDialog.pack();
/*     */     
/*  41 */     Dimension dimension1 = Toolkit.getDefaultToolkit().getScreenSize();
/*  42 */     Dimension dimension2 = dataSourceDialog.getPreferredSize();
/*  43 */     dataSourceDialog.setLocation((dimension1.width - dimension2.width) / 2, (dimension1.height - dimension2.height) / 2);
/*     */     
/*  45 */     dataSourceDialog.setVisible(true);
/*     */     
/*  47 */     return dataSourceDialog.getDataSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSourceDialog() {
/* 104 */     this.okListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */           try {
/* 107 */             String str1 = (String)this.this$0.typeCB.getSelectedItem();
/* 108 */             if (str1 == null) {
/* 109 */               JOptionPane.showMessageDialog(this.this$0, Catalog.getString("Select a data source type!"));
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/* 114 */             String str2 = Config.getDataSourceClass(str1);
/* 115 */             String str3 = this.this$0.descTF.getText();
/*     */             
/* 117 */             this.this$0.datasource = (XDataSource)Class.forName(str2).newInstance();
/* 118 */             this.this$0.datasource.setName(this.this$0.nameTF.getText());
/* 119 */             this.this$0.datasource.setDescription((str3.length() > 0) ? str3 : null);
/*     */             
/* 121 */             this.this$0.dispose();
/*     */           } catch (Exception exception) {
/* 123 */             exception.printStackTrace();
/* 124 */             JOptionPane.showMessageDialog(this.this$0, exception.toString());
/*     */           } 
/*     */         }
/*     */         private final DataSourceDialog this$0;
/*     */       };
/* 129 */     this.datasource = null;
/* 130 */     this.nameTF = new JTextField(12);
/*     */     
/* 132 */     this.descTF = new JTextArea();
/* 133 */     this.okB = new JButton(Catalog.getString("OK"));
/* 134 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*     */     setModal(true);
/*     */     getContentPane().setLayout(new BorderLayout());
/*     */     Enumeration enumeration = Config.getDataSourceTypes();
/*     */     Vector vector = new Vector();
/*     */     while (enumeration.hasMoreElements())
/*     */       vector.addElement(enumeration.nextElement()); 
/*     */     this.typeCB = new JComboBox(vector);
/*     */     this.typeCB.setSelectedIndex(0);
/*     */     JScrollPane jScrollPane = new JScrollPane(this.descTF);
/*     */     jScrollPane.setPreferredSize(new Dimension(300, 80));
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     property2Panel.add(Catalog.getString("Data Source"), new Object[][] { { Catalog.getString("Name") + ":", this.nameTF, this.typeCB }, { Catalog.getString("Description") + ":", "" }, { jScrollPane } });
/*     */     getContentPane().add(property2Panel, "Center");
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.add(this.okB);
/*     */     jPanel.add(this.cancelB);
/*     */     getContentPane().add(jPanel, "South");
/*     */     this.nameTF.addActionListener(this.okListener);
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.cancelB.addActionListener(new ActionListener(this) {
/*     */           private final DataSourceDialog this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */         });
/*     */   }
/*     */   
/*     */   public void setType(String paramString) { this.typeCB.setSelectedItem(paramString); }
/*     */   
/*     */   public XDataSource getDataSource() { return this.datasource; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\DataSourceDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */