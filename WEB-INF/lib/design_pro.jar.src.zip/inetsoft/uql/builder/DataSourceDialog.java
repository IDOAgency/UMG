package inetsoft.uql.builder;

import inetsoft.uql.XDataSource;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.util.Config;
import inetsoft.util.internal.Property2Panel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class DataSourceDialog extends JDialog {
  ActionListener okListener;
  
  XDataSource datasource;
  
  JTextField nameTF;
  
  JComboBox typeCB;
  
  JTextArea descTF;
  
  JButton okB;
  
  JButton cancelB;
  
  public static XDataSource prompt(String paramString) {
    DataSourceDialog dataSourceDialog = new DataSourceDialog();
    dataSourceDialog.setType(paramString);
    dataSourceDialog.pack();
    Dimension dimension1 = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension dimension2 = dataSourceDialog.getPreferredSize();
    dataSourceDialog.setLocation((dimension1.width - dimension2.width) / 2, (dimension1.height - dimension2.height) / 2);
    dataSourceDialog.setVisible(true);
    return dataSourceDialog.getDataSource();
  }
  
  public DataSourceDialog() {
    this.okListener = new ActionListener(this) {
        private final DataSourceDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            String str1 = (String)this.this$0.typeCB.getSelectedItem();
            if (str1 == null) {
              JOptionPane.showMessageDialog(this.this$0, Catalog.getString("Select a data source type!"));
              return;
            } 
            String str2 = Config.getDataSourceClass(str1);
            String str3 = this.this$0.descTF.getText();
            this.this$0.datasource = (XDataSource)Class.forName(str2).newInstance();
            this.this$0.datasource.setName(this.this$0.nameTF.getText());
            this.this$0.datasource.setDescription((str3.length() > 0) ? str3 : null);
            this.this$0.dispose();
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, exception.toString());
          } 
        }
      };
    this.datasource = null;
    this.nameTF = new JTextField(12);
    this.descTF = new JTextArea();
    this.okB = new JButton(Catalog.getString("OK"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    setModal(true);
    getContentPane().setLayout(new BorderLayout());
    Enumeration enumeration = Config.getDataSourceTypes();
    Vector vector = new Vector();
    while (enumeration.hasMoreElements())
      vector.addElement(enumeration.nextElement()); 
    this.typeCB = new JComboBox(vector);
    this.typeCB.setSelectedIndex(0);
    JScrollPane jScrollPane = new JScrollPane(this.descTF);
    jScrollPane.setPreferredSize(new Dimension(300, 80));
    Property2Panel property2Panel = new Property2Panel();
    property2Panel.add(Catalog.getString("Data Source"), new Object[][] { { Catalog.getString("Name") + ":", this.nameTF, this.typeCB }, { Catalog.getString("Description") + ":", "" }, { jScrollPane } });
    getContentPane().add(property2Panel, "Center");
    JPanel jPanel = new JPanel();
    jPanel.add(this.okB);
    jPanel.add(this.cancelB);
    getContentPane().add(jPanel, "South");
    this.nameTF.addActionListener(this.okListener);
    this.okB.addActionListener(this.okListener);
    this.cancelB.addActionListener(new ActionListener(this) {
          private final DataSourceDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
        });
  }
  
  public void setType(String paramString) { this.typeCB.setSelectedItem(paramString); }
  
  public XDataSource getDataSource() { return this.datasource; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\DataSourceDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */