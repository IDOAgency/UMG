/*    */ package inetsoft.uql.builder;
/*    */ 
/*    */ import inetsoft.uql.XQuery;
/*    */ import java.awt.Component;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class QueryProperty
/*    */   extends PropertyPane
/*    */ {
/*    */   Object session;
/*    */   
/*    */   public abstract void setQuery(XQuery paramXQuery);
/*    */   
/*    */   public abstract XQuery getQuery();
/*    */   
/* 43 */   public Component getCommandPane() { return null; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public void setSession(Object paramObject) { this.session = paramObject; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   public Object getSession() { return this.session; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\QueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */