/*    */ package inetsoft.uql.builder;
/*    */ 
/*    */ import inetsoft.uql.XDataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DataSourceWizard
/*    */   extends WizardDialog
/*    */ {
/*    */   public DataSourceWizard() {}
/*    */   
/* 40 */   protected DataSourceWizard(String[] paramArrayOfString) throws Exception { super(paramArrayOfString); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public XDataSource getDataSource() {
/* 48 */     DataSourceWizard dataSourceWizard = (DataSourceWizard)findRoot();
/* 49 */     if (dataSourceWizard == this) {
/* 50 */       throw new RuntimeException("Internal Error: Datasource wizard not implemented!");
/*    */     }
/*    */     
/* 53 */     return dataSourceWizard.getDataSource();
/*    */   }
/*    */   
/*    */   public void setDataSource(XDataSource paramXDataSource) {}
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\DataSourceWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */