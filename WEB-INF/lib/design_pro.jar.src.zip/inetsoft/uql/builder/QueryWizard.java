package inetsoft.uql.builder;

import inetsoft.uql.XQuery;
import java.awt.event.ActionListener;

public interface QueryWizard {
  void show(ActionListener paramActionListener);
  
  XQuery getQuery();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\QueryWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */