/*     */ package inetsoft.uql.builder;
/*     */ 
/*     */ import inetsoft.uql.VariableTable;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.schema.UserVariable;
/*     */ import inetsoft.util.internal.NumField;
/*     */ import inetsoft.util.internal.Property2Panel;
/*     */ import inetsoft.widget.DateCombo;
/*     */ import inetsoft.widget.DateTimeCombo;
/*     */ import inetsoft.widget.TimeSpinner;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableEntry
/*     */   extends JPanel
/*     */ {
/*     */   static JDialog win;
/*     */   static VariableEntry pane;
/*     */   
/*     */   public static VariableTable show(UserVariable[] paramArrayOfUserVariable) {
/*  42 */     win = new JDialog();
/*  43 */     pane = new VariableEntry(paramArrayOfUserVariable);
/*  44 */     win.getContentPane().add(pane, "Center");
/*     */     
/*  46 */     JButton jButton1 = new JButton(Catalog.getString("OK"));
/*  47 */     JButton jButton2 = new JButton(Catalog.getString("Cancel"));
/*     */     
/*  49 */     JPanel jPanel = new JPanel();
/*  50 */     jPanel.add(jButton1);
/*  51 */     jPanel.add(jButton2);
/*  52 */     win.getContentPane().add(jPanel, "South");
/*     */     
/*  54 */     jButton1.addActionListener(okListener);
/*     */     
/*  56 */     jButton2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*  58 */             VariableEntry.win.dispose();
/*     */           }
/*     */         });
/*     */     
/*  62 */     win.setModal(true);
/*  63 */     win.pack();
/*  64 */     win.setVisible(true);
/*     */     
/*  66 */     return pane.getVariableTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VariableEntry(UserVariable[] paramArrayOfUserVariable) {
/* 270 */     this.names = new Vector();
/* 271 */     this.types = new Vector();
/*     */     setLayout(new BorderLayout(5, 5));
/*     */     Vector vector = new Vector();
/*     */     for (byte b = 0; b < paramArrayOfUserVariable.length; b++) {
/*     */       String str1 = paramArrayOfUserVariable[b].getName();
/*     */       String str2 = paramArrayOfUserVariable[b].getAlias();
/*     */       Object object = (paramArrayOfUserVariable[b].getValueNode() == null) ? null : paramArrayOfUserVariable[b].getValueNode().getValue();
/*     */       UserVariable userVariable = paramArrayOfUserVariable[b];
/*     */       TimeSpinner timeSpinner = null;
/*     */       String str3 = userVariable.getTypeNode().getType();
/*     */       if (str3.equals("string")) {
/*     */         JTextField jTextField;
/*     */         if (userVariable.isHidden()) {
/*     */           timeSpinner = new JPasswordField(10);
/*     */         } else {
/*     */           jTextField = new JTextField(10);
/*     */         } 
/*     */         ((JTextField)jTextField).addActionListener(okListener);
/*     */         if (object != null)
/*     */           ((JTextField)jTextField).setText((String)object); 
/*     */       } else if (str3.equals("boolean")) {
/*     */         JCheckBox jCheckBox = new JCheckBox("");
/*     */         if (object != null)
/*     */           ((JCheckBox)jCheckBox).setSelected(((Boolean)object).booleanValue()); 
/*     */       } else if (str3.equals("float")) {
/*     */         NumField numField = new NumField(5, false);
/*     */         if (object != null)
/*     */           ((NumField)numField).setValue(((Number)object).floatValue()); 
/*     */       } else if (str3.equals("double")) {
/*     */         NumField numField = new NumField(5, false);
/*     */         if (object != null)
/*     */           ((NumField)numField).setValue(((Number)object).doubleValue()); 
/*     */       } else if (str3.equals("char")) {
/*     */         JTextField jTextField = new JTextField(1);
/*     */         ((JTextField)jTextField).addActionListener(okListener);
/*     */         if (object != null)
/*     */           ((JTextField)jTextField).setText(object.toString()); 
/*     */       } else if (str3.equals("byte")) {
/*     */         NumField numField = new NumField(5, true);
/*     */         if (object != null)
/*     */           ((NumField)numField).setValue(((Number)object).intValue()); 
/*     */       } else if (str3.equals("short")) {
/*     */         NumField numField = new NumField(5, true);
/*     */         if (object != null)
/*     */           ((NumField)numField).setValue(((Number)object).intValue()); 
/*     */       } else if (str3.equals("integer")) {
/*     */         NumField numField = new NumField(5, true);
/*     */         if (object != null)
/*     */           ((NumField)numField).setValue(((Number)object).intValue()); 
/*     */       } else if (str3.equals("long")) {
/*     */         NumField numField = new NumField(5, true);
/*     */         if (object != null)
/*     */           ((NumField)numField).setValue((float)((Number)object).longValue()); 
/*     */       } else if (str3.equals("timeInstant")) {
/*     */         DateTimeCombo dateTimeCombo = new DateTimeCombo();
/*     */         if (object != null)
/*     */           ((DateTimeCombo)dateTimeCombo).setDate((Date)object); 
/*     */       } else if (str3.equals("date")) {
/*     */         DateCombo dateCombo = new DateCombo();
/*     */         if (object != null)
/*     */           ((DateCombo)dateCombo).setDate((Date)object); 
/*     */       } else if (str3.equals("time")) {
/*     */         timeSpinner = new TimeSpinner();
/*     */         if (object != null)
/*     */           ((TimeSpinner)timeSpinner).setDate((Date)object); 
/*     */       } 
/*     */       if (timeSpinner != null) {
/*     */         vector.addElement(new Object[] { str2, timeSpinner });
/*     */         this.names.addElement(str1);
/*     */         this.types.addElement(str3);
/*     */       } 
/*     */     } 
/*     */     this.rows = new Object[vector.size()][];
/*     */     vector.copyInto(this.rows);
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     property2Panel.add(Catalog.getString("Query Parameters"), this.rows);
/*     */     VarScrollPane varScrollPane = new VarScrollPane(this, property2Panel);
/*     */     add(varScrollPane, "Center");
/*     */   }
/*     */   
/*     */   public VariableTable getVariableTable() { return this.table; }
/*     */   
/*     */   public void createVariableTable() {
/*     */     this.table = new VariableTable();
/*     */     for (byte b = 0; b < this.rows.length; b++) {
/*     */       Date date = null;
/*     */       Object object = this.rows[b][1];
/*     */       String str = (String)this.types.elementAt(b);
/*     */       if (str.equals("boolean")) {
/*     */         date = new Boolean(((JCheckBox)object).isSelected());
/*     */       } else if (str.equals("date")) {
/*     */         Date date1 = ((DateCombo)object).getDate();
/*     */       } else if (str.equals("double")) {
/*     */         Double double = new Double(((NumField)object).doubleValue());
/*     */       } else if (str.equals("float")) {
/*     */         Float float = new Float(((NumField)object).floatValue());
/*     */       } else if (str.equals("char")) {
/*     */         String str1 = ((JTextField)object).getText();
/*     */         Character character = new Character((str1.length() > 0) ? str1.charAt(0) : 0);
/*     */       } else if (str.equals("byte")) {
/*     */         Byte byte = new Byte((byte)((NumField)object).intValue());
/*     */       } else if (str.equals("short")) {
/*     */         Short short = new Short((short)((NumField)object).intValue());
/*     */       } else if (str.equals("integer")) {
/*     */         Integer integer = new Integer(((NumField)object).intValue());
/*     */       } else if (str.equals("long")) {
/*     */         Long long = new Long(((NumField)object).longValue());
/*     */       } else if (str.equals("string")) {
/*     */         String str1 = ((JTextField)object).getText();
/*     */       } else if (str.equals("timeInstant")) {
/*     */         Date date1 = ((DateTimeCombo)object).getDate();
/*     */       } else if (str.equals("time")) {
/*     */         date = ((TimeSpinner)object).getDate();
/*     */       } 
/*     */       if (date != null)
/*     */         this.table.put((String)this.names.elementAt(b), date); 
/*     */     } 
/*     */   }
/*     */   
/*     */   class VarScrollPane extends JScrollPane {
/*     */     Component comp;
/*     */     private final VariableEntry this$0;
/*     */     
/*     */     public VarScrollPane(VariableEntry this$0, Component param1Component) {
/*     */       super(param1Component);
/*     */       this.this$0 = this$0;
/*     */       this.comp = param1Component;
/*     */     }
/*     */     
/*     */     public Dimension getPreferredSize() {
/*     */       Dimension dimension = this.comp.getPreferredSize();
/*     */       return new Dimension(Math.max(200, dimension.width + 5), 240);
/*     */     }
/*     */   }
/*     */   
/*     */   static ActionListener okListener = new ActionListener() {
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */         VariableEntry.pane.createVariableTable();
/*     */         VariableEntry.win.dispose();
/*     */       }
/*     */     };
/*     */   
/*     */   Object[][] rows;
/*     */   Vector names;
/*     */   Vector types;
/*     */   VariableTable table;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\VariableEntry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */