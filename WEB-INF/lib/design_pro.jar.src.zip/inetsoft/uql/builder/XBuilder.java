/*     */ package inetsoft.uql.builder;
/*     */ 
/*     */ import inetsoft.uql.XDataSource;
/*     */ import inetsoft.uql.XFactory;
/*     */ import inetsoft.uql.XQuery;
/*     */ import inetsoft.uql.XRepository;
/*     */ import inetsoft.uql.corba.CorbaHandler;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JToolBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XBuilder
/*     */   extends JFrame
/*     */ {
/*     */   CloseListener closeListener;
/*     */   
/*  43 */   public XBuilder() { this(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XBuilder(XRepository paramXRepository) {
/* 202 */     this.closeListener = new CloseListener(this); setTitle(Catalog.getString("Query Builder")); getContentPane().setLayout(new BorderLayout()); getContentPane().add(this.pane = new XBuildPane(paramXRepository), "Center"); if (isMain) { JMenuBar jMenuBar = new JMenuBar(); setJMenuBar(jMenuBar); JMenu jMenu = new JMenu(Catalog.getString("File")); JMenuItem jMenuItem; jMenu.add(jMenuItem = new JMenuItem(Catalog.getString("Close"))); jMenuItem.addActionListener(this.closeListener); jMenuBar.add(jMenu); JToolBar jToolBar = new JToolBar(); getContentPane().add(jToolBar, "North"); } else { JButton jButton = new JButton(Catalog.getString("Close")); jButton.addActionListener(this.closeListener); this.pane.cmdPane.add(jButton); this.pane.cmdPane.add(new JLabel("")); }  addWindowListener(this.closeListener);
/* 203 */   } public XRepository getRepository() { return this.pane.getRepository(); } public Object getSession() { return this.pane.getSession(); } public void restart() { XFactory.clear(); getContentPane().remove(this.pane); getContentPane().add(this.pane = new XBuildPane(null), "Center"); } public void showQuery(String paramString) { this.pane.showQuery(paramString); } public XDataSource newDataSource(String paramString) { return this.pane.newDataSource(paramString); } public XQuery newQuery(String paramString1, String paramString2) { return this.pane.newQuery(paramString1, paramString2); } public void addActionListener(ActionListener paramActionListener) { this.pane.addActionListener(paramActionListener); } public void removeActionListener(ActionListener paramActionListener) { this.pane.removeActionListener(paramActionListener); } public boolean isValueChanged() { return this.pane.isValueChanged(); } public void save() { this.pane.save(); } public boolean close() { if (this.pane.isValueChanged()) switch (JOptionPane.showConfirmDialog(this, exitMsg)) { case 0: if (!this.pane.save()) return false;  break;case 2: return false; }   setVisible(false); return true; } public static void main(String[] paramArrayOfString) { for (byte b = 0; b < paramArrayOfString.length; b++) { if (paramArrayOfString[b].startsWith("-ORB")) { CorbaHandler.init(paramArrayOfString, null); break; }  }  isMain = true; XBuilder xBuilder = new XBuilder(); xBuilder.pack(); xBuilder.setVisible(true); } class CloseListener extends WindowAdapter implements ActionListener { CloseListener(XBuilder this$0) { this.this$0 = this$0; }
/*     */     private final XBuilder this$0;
/* 205 */     public void windowClosing(WindowEvent param1WindowEvent) { actionPerformed(null); }
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent param1ActionEvent) {
/* 209 */       if (this.this$0.close() && XBuilder.isMain) {
/* 210 */         System.exit(0);
/*     */       }
/*     */     } }
/*     */ 
/*     */   
/* 215 */   static final String exitMsg = Catalog.getString("Unsaved changes. Save before closing?");
/*     */   static boolean isMain = false;
/*     */   XBuildPane pane;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\XBuilder.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */