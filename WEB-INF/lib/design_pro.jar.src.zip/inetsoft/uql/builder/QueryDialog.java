/*     */ package inetsoft.uql.builder;
/*     */ 
/*     */ import inetsoft.uql.XDataSource;
/*     */ import inetsoft.uql.XQuery;
/*     */ import inetsoft.uql.XRepository;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.util.Config;
/*     */ import inetsoft.uql.xml.DerivedQuery;
/*     */ import inetsoft.util.internal.Property2Panel;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class QueryDialog
/*     */   extends JDialog
/*     */ {
/*     */   ActionListener okListener;
/*     */   ItemListener deriveListener;
/*     */   
/*     */   public static XQuery prompt(String[] paramArrayOfString, XRepository paramXRepository, String paramString1, String paramString2) {
/*  42 */     QueryDialog queryDialog = new QueryDialog(paramArrayOfString, paramXRepository, paramString1, paramString2);
/*  43 */     queryDialog.setDataSource(paramString1);
/*  44 */     queryDialog.pack();
/*  45 */     queryDialog.setVisible(true);
/*     */     
/*  47 */     return queryDialog.getQuery();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QueryDialog(String[] paramArrayOfString, XRepository paramXRepository, String paramString1, String paramString2) {
/* 106 */     this.okListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */           try {
/* 109 */             String str1 = (String)this.this$0.typeCB.getSelectedItem();
/* 110 */             if (str1 == null) {
/* 111 */               JOptionPane.showMessageDialog(this.this$0, QueryDialog.msg2);
/*     */               
/*     */               return;
/*     */             } 
/* 115 */             XDataSource xDataSource = null;
/* 116 */             String str2 = null;
/*     */             
/* 118 */             if (this.this$0.deriveCB.isSelected()) {
/* 119 */               str2 = Config.getQueryClass("derived");
/*     */             } else {
/*     */               
/* 122 */               xDataSource = this.this$0.repository.getDataSource(str1);
/* 123 */               str2 = Config.getQueryClass(xDataSource.getType());
/*     */             } 
/*     */             
/* 126 */             Class clazz = (str2 != null) ? Class.forName(str2) : null;
/* 127 */             if (clazz == null) {
/* 128 */               JOptionPane.showMessageDialog(this.this$0, QueryDialog.msg1 + " " + str1);
/*     */             }
/*     */             
/* 131 */             String str3 = this.this$0.descTF.getText();
/*     */             
/* 133 */             this.this$0.query = (XQuery)clazz.newInstance();
/* 134 */             this.this$0.query.setName(this.this$0.nameTF.getText());
/* 135 */             this.this$0.query.setDataSource(xDataSource);
/* 136 */             this.this$0.query.setDescription((str3.length() > 0) ? str3 : null);
/*     */             
/* 138 */             if (this.this$0.deriveCB.isSelected()) {
/* 139 */               String str = (String)this.this$0.typeCB.getSelectedItem();
/* 140 */               ((DerivedQuery)this.this$0.query).setBaseQuery(this.this$0.repository.getQuery(str));
/*     */             } 
/*     */             
/* 143 */             this.this$0.dispose();
/*     */           } catch (Exception exception) {
/* 145 */             exception.printStackTrace();
/* 146 */             JOptionPane.showMessageDialog(this.this$0, exception.toString());
/*     */           } 
/*     */         }
/*     */         private final QueryDialog this$0;
/*     */       };
/* 151 */     this.deriveListener = new ItemListener(this)
/*     */       {
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) {
/*     */           try {
/*     */             String[] arrayOfString;
/* 156 */             if (this.this$0.deriveCB.isSelected()) {
/* 157 */               this.this$0.typeLB.setText(Catalog.getString("Base Query") + ":");
/* 158 */               arrayOfString = this.this$0.repository.getQueryNames();
/*     */             } else {
/*     */               
/* 161 */               this.this$0.typeLB.setText(Catalog.getString("Data Source") + ":");
/* 162 */               arrayOfString = this.this$0.dxnames;
/*     */             } 
/*     */             
/* 165 */             this.this$0.typeCB.setModel(new DefaultComboBoxModel(arrayOfString));
/* 166 */             this.this$0.typeCB.setSelectedItem((this.this$0.qname != null) ? this.this$0.qname : ((arrayOfString.length > 0) ? arrayOfString[0] : null));
/*     */             
/* 168 */             this.this$0.pack();
/*     */           } catch (Exception exception) {
/* 170 */             exception.printStackTrace();
/* 171 */             JOptionPane.showMessageDialog(this.this$0, exception.toString());
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final QueryDialog this$0;
/*     */       };
/* 183 */     this.query = null;
/* 184 */     this.nameTF = new JTextField(15);
/* 185 */     this.typeLB = new JLabel(Catalog.getString("Data Source") + ":");
/*     */     
/* 187 */     this.deriveCB = new JCheckBox(Catalog.getString("Derive Query"));
/* 188 */     this.descTF = new JTextArea();
/* 189 */     this.okB = new JButton(Catalog.getString("OK"));
/* 190 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*     */     setModal(true);
/*     */     getContentPane().setLayout(new BorderLayout());
/*     */     this.dxnames = paramArrayOfString;
/*     */     this.repository = paramXRepository;
/*     */     this.dxname = paramString1;
/*     */     this.qname = paramString2;
/*     */     this.typeCB = new JComboBox(paramArrayOfString);
/*     */     this.typeCB.setSelectedIndex(0);
/*     */     JScrollPane jScrollPane = new JScrollPane(this.descTF);
/*     */     jScrollPane.setPreferredSize(new Dimension(300, 80));
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     property2Panel.add(Catalog.getString("Query"), new Object[][] { { Catalog.getString("Name") + ":", this.nameTF }, { this.typeLB, this.typeCB, this.deriveCB }, { Catalog.getString("Description") + ":", "" }, { jScrollPane } });
/*     */     getContentPane().add(property2Panel, "Center");
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.add(this.okB);
/*     */     jPanel.add(this.cancelB);
/*     */     getContentPane().add(jPanel, "South");
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.nameTF.addActionListener(this.okListener);
/*     */     this.cancelB.addActionListener(new ActionListener(this) {
/*     */           private final QueryDialog this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */         });
/*     */     this.deriveCB.addItemListener(this.deriveListener);
/*     */   }
/*     */   
/*     */   public void setDataSource(String paramString) { this.typeCB.setSelectedItem(paramString); }
/*     */   
/*     */   public XQuery getQuery() { return this.query; }
/*     */   
/*     */   static final String msg1 = Catalog.getString("Query type not supported:");
/*     */   static final String msg2 = Catalog.getString("Must select a type/query!");
/*     */   String[] dxnames;
/*     */   String dxname;
/*     */   String qname;
/*     */   XRepository repository;
/*     */   XQuery query;
/*     */   JTextField nameTF;
/*     */   JLabel typeLB;
/*     */   JComboBox typeCB;
/*     */   JCheckBox deriveCB;
/*     */   JTextArea descTF;
/*     */   JButton okB;
/*     */   JButton cancelB;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\QueryDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */