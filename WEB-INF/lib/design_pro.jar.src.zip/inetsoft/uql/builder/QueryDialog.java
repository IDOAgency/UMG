package inetsoft.uql.builder;

import inetsoft.uql.XDataSource;
import inetsoft.uql.XQuery;
import inetsoft.uql.XRepository;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.util.Config;
import inetsoft.uql.xml.DerivedQuery;
import inetsoft.util.internal.Property2Panel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class QueryDialog extends JDialog {
  ActionListener okListener;
  
  ItemListener deriveListener;
  
  public static XQuery prompt(String[] paramArrayOfString, XRepository paramXRepository, String paramString1, String paramString2) {
    QueryDialog queryDialog = new QueryDialog(paramArrayOfString, paramXRepository, paramString1, paramString2);
    queryDialog.setDataSource(paramString1);
    queryDialog.pack();
    queryDialog.setVisible(true);
    return queryDialog.getQuery();
  }
  
  public QueryDialog(String[] paramArrayOfString, XRepository paramXRepository, String paramString1, String paramString2) {
    this.okListener = new ActionListener(this) {
        private final QueryDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            String str1 = (String)this.this$0.typeCB.getSelectedItem();
            if (str1 == null) {
              JOptionPane.showMessageDialog(this.this$0, QueryDialog.msg2);
              return;
            } 
            XDataSource xDataSource = null;
            String str2 = null;
            if (this.this$0.deriveCB.isSelected()) {
              str2 = Config.getQueryClass("derived");
            } else {
              xDataSource = this.this$0.repository.getDataSource(str1);
              str2 = Config.getQueryClass(xDataSource.getType());
            } 
            Class clazz = (str2 != null) ? Class.forName(str2) : null;
            if (clazz == null)
              JOptionPane.showMessageDialog(this.this$0, QueryDialog.msg1 + " " + str1); 
            String str3 = this.this$0.descTF.getText();
            this.this$0.query = (XQuery)clazz.newInstance();
            this.this$0.query.setName(this.this$0.nameTF.getText());
            this.this$0.query.setDataSource(xDataSource);
            this.this$0.query.setDescription((str3.length() > 0) ? str3 : null);
            if (this.this$0.deriveCB.isSelected()) {
              String str = (String)this.this$0.typeCB.getSelectedItem();
              ((DerivedQuery)this.this$0.query).setBaseQuery(this.this$0.repository.getQuery(str));
            } 
            this.this$0.dispose();
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, exception.toString());
          } 
        }
      };
    this.deriveListener = new ItemListener(this) {
        private final QueryDialog this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          try {
            String[] arrayOfString;
            if (this.this$0.deriveCB.isSelected()) {
              this.this$0.typeLB.setText(Catalog.getString("Base Query") + ":");
              arrayOfString = this.this$0.repository.getQueryNames();
            } else {
              this.this$0.typeLB.setText(Catalog.getString("Data Source") + ":");
              arrayOfString = this.this$0.dxnames;
            } 
            this.this$0.typeCB.setModel(new DefaultComboBoxModel(arrayOfString));
            this.this$0.typeCB.setSelectedItem((this.this$0.qname != null) ? this.this$0.qname : ((arrayOfString.length > 0) ? arrayOfString[0] : null));
            this.this$0.pack();
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, exception.toString());
          } 
        }
      };
    this.query = null;
    this.nameTF = new JTextField(15);
    this.typeLB = new JLabel(Catalog.getString("Data Source") + ":");
    this.deriveCB = new JCheckBox(Catalog.getString("Derive Query"));
    this.descTF = new JTextArea();
    this.okB = new JButton(Catalog.getString("OK"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    setModal(true);
    getContentPane().setLayout(new BorderLayout());
    this.dxnames = paramArrayOfString;
    this.repository = paramXRepository;
    this.dxname = paramString1;
    this.qname = paramString2;
    this.typeCB = new JComboBox(paramArrayOfString);
    this.typeCB.setSelectedIndex(0);
    JScrollPane jScrollPane = new JScrollPane(this.descTF);
    jScrollPane.setPreferredSize(new Dimension(300, 80));
    Property2Panel property2Panel = new Property2Panel();
    property2Panel.add(Catalog.getString("Query"), new Object[][] { { Catalog.getString("Name") + ":", this.nameTF }, { this.typeLB, this.typeCB, this.deriveCB }, { Catalog.getString("Description") + ":", "" }, { jScrollPane } });
    getContentPane().add(property2Panel, "Center");
    JPanel jPanel = new JPanel();
    jPanel.add(this.okB);
    jPanel.add(this.cancelB);
    getContentPane().add(jPanel, "South");
    this.okB.addActionListener(this.okListener);
    this.nameTF.addActionListener(this.okListener);
    this.cancelB.addActionListener(new ActionListener(this) {
          private final QueryDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
        });
    this.deriveCB.addItemListener(this.deriveListener);
  }
  
  public void setDataSource(String paramString) { this.typeCB.setSelectedItem(paramString); }
  
  public XQuery getQuery() { return this.query; }
  
  static final String msg1 = Catalog.getString("Query type not supported:");
  
  static final String msg2 = Catalog.getString("Must select a type/query!");
  
  String[] dxnames;
  
  String dxname;
  
  String qname;
  
  XRepository repository;
  
  XQuery query;
  
  JTextField nameTF;
  
  JLabel typeLB;
  
  JComboBox typeCB;
  
  JCheckBox deriveCB;
  
  JTextArea descTF;
  
  JButton okB;
  
  JButton cancelB;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\QueryDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */