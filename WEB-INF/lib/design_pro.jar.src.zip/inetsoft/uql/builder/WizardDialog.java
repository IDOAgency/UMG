/*     */ package inetsoft.uql.builder;
/*     */ 
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WizardDialog
/*     */   extends JDialog
/*     */ {
/*     */   public void show(ActionListener paramActionListener) {
/*  38 */     this.listener = paramActionListener;
/*  39 */     pack();
/*     */     
/*  41 */     Dimension dimension1 = Toolkit.getDefaultToolkit().getScreenSize();
/*  42 */     Dimension dimension2 = getPreferredSize();
/*  43 */     setLocation((dimension1.width - dimension2.width) / 2, (dimension1.height - dimension2.height) / 2);
/*     */     
/*  45 */     setVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WizardDialog(String[] paramArrayOfString) throws Exception {
/*  60 */     WizardDialog wizardDialog1 = this, wizardDialog2 = null;
/*     */     
/*  62 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*  63 */       WizardDialog wizardDialog = (WizardDialog)Class.forName(paramArrayOfString[b]).newInstance();
/*     */       
/*  65 */       wizardDialog1.init(wizardDialog2, wizardDialog);
/*  66 */       wizardDialog2 = wizardDialog1;
/*  67 */       wizardDialog1 = wizardDialog;
/*     */     } 
/*     */     
/*  70 */     wizardDialog1.init(wizardDialog2, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(WizardDialog paramWizardDialog1, WizardDialog paramWizardDialog2) {
/*  77 */     this.prev = paramWizardDialog1;
/*  78 */     this.next = paramWizardDialog2;
/*     */     
/*  80 */     getContentPane().setLayout(new BorderLayout());
/*     */     
/*  82 */     JPanel jPanel = new JPanel();
/*  83 */     jPanel.setLayout(new FlowLayout(1, 8, 5));
/*  84 */     getContentPane().add(jPanel, "South");
/*     */     
/*  86 */     getMainPane().setBorder(new EmptyBorder(2, 2, 2, 2));
/*  87 */     getContentPane().add(getMainPane(), "Center");
/*     */     
/*  89 */     if (paramWizardDialog1 != null) {
/*  90 */       jPanel.add(this.prevB);
/*  91 */       this.prevB.addActionListener(this.prevListener);
/*     */     } 
/*     */     
/*  94 */     if (paramWizardDialog2 != null) {
/*  95 */       jPanel.add(this.nextB);
/*  96 */       this.nextB.addActionListener(this.nextListener);
/*     */     } else {
/*     */       
/*  99 */       jPanel.add(this.finishB);
/* 100 */       this.finishB.addActionListener(this.finishListener);
/*     */     } 
/*     */     
/* 103 */     jPanel.add(this.cancelB);
/* 104 */     this.cancelB.addActionListener(this.cancelListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JPanel getMainPane() {
/* 113 */     if (this.mainPane == null) {
/* 114 */       this.mainPane = new JPanel();
/* 115 */       this.mainPane.setLayout(new BorderLayout(5, 5));
/*     */     } 
/*     */     
/* 118 */     return this.mainPane;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WizardDialog findRoot() {
/* 142 */     WizardDialog wizardDialog1 = this;
/* 143 */     WizardDialog wizardDialog2 = this.prev;
/*     */     
/* 145 */     while (wizardDialog2 != null) {
/* 146 */       wizardDialog1 = wizardDialog2;
/* 147 */       wizardDialog2 = wizardDialog1.prev;
/*     */     } 
/*     */     
/* 150 */     return wizardDialog1;
/*     */   }
/*     */   
/* 153 */   ActionListener prevListener = new ActionListener(this) {
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 155 */         this.this$0.setVisible(false);
/* 156 */         this.this$0.prev.setVisible(true);
/*     */       }
/*     */       private final WizardDialog this$0;
/*     */     };
/* 160 */   ActionListener nextListener = new ActionListener(this) {
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 162 */         String str = this.this$0.complete();
/* 163 */         if (str != null) {
/* 164 */           JOptionPane.showMessageDialog(null, str, Catalog.getString("Error"), 0);
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 169 */         this.this$0.setVisible(false);
/* 170 */         this.this$0.next.show(this.this$0.listener);
/* 171 */         this.this$0.next.populate();
/*     */       }
/*     */       private final WizardDialog this$0;
/*     */     };
/* 175 */   ActionListener cancelListener = new ActionListener(this) { private final WizardDialog this$0;
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 177 */         this.this$0.dispose();
/*     */         
/* 179 */         for (; this.this$0.prev != null; this.this$0.prev = this.this$0.prev.prev) {
/* 180 */           this.this$0.prev.dispose();
/*     */         }
/*     */         
/* 183 */         for (; this.this$0.next != null; this.this$0.next = this.this$0.next.next) {
/* 184 */           this.this$0.next.dispose();
/*     */         }
/*     */       } }
/*     */   ;
/*     */   
/* 189 */   ActionListener finishListener = new ActionListener(this) { private final WizardDialog this$0;
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 191 */         String str = this.this$0.complete();
/* 192 */         if (str != null) {
/* 193 */           JOptionPane.showMessageDialog(null, str, Catalog.getString("Error"), 0);
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 198 */         this.this$0.cancelListener.actionPerformed(param1ActionEvent);
/* 199 */         (this.this$0.findRoot()).listener.actionPerformed(param1ActionEvent);
/*     */       } }
/*     */   ;
/*     */   
/* 203 */   private JButton prevB = new JButton(Catalog.getString("<<Previous"));
/* 204 */   private JButton nextB = new JButton(Catalog.getString("Next>>"));
/* 205 */   private JButton cancelB = new JButton(Catalog.getString("Cancel"));
/* 206 */   private JButton finishB = new JButton(Catalog.getString("Finish"));
/*     */   private WizardDialog prev;
/*     */   private WizardDialog next;
/*     */   private JPanel mainPane;
/*     */   private ActionListener listener;
/*     */   
/*     */   public WizardDialog() {}
/*     */   
/*     */   public abstract String complete();
/*     */   
/*     */   public abstract void populate();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\WizardDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */