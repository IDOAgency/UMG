package inetsoft.uql.builder;

import inetsoft.uql.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public abstract class WizardDialog extends JDialog {
  public void show(ActionListener paramActionListener) {
    this.listener = paramActionListener;
    pack();
    Dimension dimension1 = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension dimension2 = getPreferredSize();
    setLocation((dimension1.width - dimension2.width) / 2, (dimension1.height - dimension2.height) / 2);
    setVisible(true);
  }
  
  public WizardDialog(String[] paramArrayOfString) throws Exception {
    WizardDialog wizardDialog1 = this, wizardDialog2 = null;
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      WizardDialog wizardDialog = (WizardDialog)Class.forName(paramArrayOfString[b]).newInstance();
      wizardDialog1.init(wizardDialog2, wizardDialog);
      wizardDialog2 = wizardDialog1;
      wizardDialog1 = wizardDialog;
    } 
    wizardDialog1.init(wizardDialog2, null);
  }
  
  private void init(WizardDialog paramWizardDialog1, WizardDialog paramWizardDialog2) {
    this.prev = paramWizardDialog1;
    this.next = paramWizardDialog2;
    getContentPane().setLayout(new BorderLayout());
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(1, 8, 5));
    getContentPane().add(jPanel, "South");
    getMainPane().setBorder(new EmptyBorder(2, 2, 2, 2));
    getContentPane().add(getMainPane(), "Center");
    if (paramWizardDialog1 != null) {
      jPanel.add(this.prevB);
      this.prevB.addActionListener(this.prevListener);
    } 
    if (paramWizardDialog2 != null) {
      jPanel.add(this.nextB);
      this.nextB.addActionListener(this.nextListener);
    } else {
      jPanel.add(this.finishB);
      this.finishB.addActionListener(this.finishListener);
    } 
    jPanel.add(this.cancelB);
    this.cancelB.addActionListener(this.cancelListener);
  }
  
  public JPanel getMainPane() {
    if (this.mainPane == null) {
      this.mainPane = new JPanel();
      this.mainPane.setLayout(new BorderLayout(5, 5));
    } 
    return this.mainPane;
  }
  
  protected WizardDialog findRoot() {
    WizardDialog wizardDialog1 = this;
    WizardDialog wizardDialog2 = this.prev;
    while (wizardDialog2 != null) {
      wizardDialog1 = wizardDialog2;
      wizardDialog2 = wizardDialog1.prev;
    } 
    return wizardDialog1;
  }
  
  ActionListener prevListener = new ActionListener(this) {
      private final WizardDialog this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        this.this$0.setVisible(false);
        this.this$0.prev.setVisible(true);
      }
    };
  
  ActionListener nextListener = new ActionListener(this) {
      private final WizardDialog this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        String str = this.this$0.complete();
        if (str != null) {
          JOptionPane.showMessageDialog(null, str, Catalog.getString("Error"), 0);
          return;
        } 
        this.this$0.setVisible(false);
        this.this$0.next.show(this.this$0.listener);
        this.this$0.next.populate();
      }
    };
  
  ActionListener cancelListener = new ActionListener(this) {
      private final WizardDialog this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        this.this$0.dispose();
        for (; this.this$0.prev != null; this.this$0.prev = this.this$0.prev.prev)
          this.this$0.prev.dispose(); 
        for (; this.this$0.next != null; this.this$0.next = this.this$0.next.next)
          this.this$0.next.dispose(); 
      }
    };
  
  ActionListener finishListener = new ActionListener(this) {
      private final WizardDialog this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        String str = this.this$0.complete();
        if (str != null) {
          JOptionPane.showMessageDialog(null, str, Catalog.getString("Error"), 0);
          return;
        } 
        this.this$0.cancelListener.actionPerformed(param1ActionEvent);
        (this.this$0.findRoot()).listener.actionPerformed(param1ActionEvent);
      }
    };
  
  private JButton prevB = new JButton(Catalog.getString("<<Previous"));
  
  private JButton nextB = new JButton(Catalog.getString("Next>>"));
  
  private JButton cancelB = new JButton(Catalog.getString("Cancel"));
  
  private JButton finishB = new JButton(Catalog.getString("Finish"));
  
  private WizardDialog prev;
  
  private WizardDialog next;
  
  private JPanel mainPane;
  
  private ActionListener listener;
  
  public WizardDialog() {}
  
  public abstract String complete();
  
  public abstract void populate();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\builder\WizardDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */