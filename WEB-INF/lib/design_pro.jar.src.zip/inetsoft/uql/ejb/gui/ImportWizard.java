/*     */ package inetsoft.uql.ejb.gui;
/*     */ 
/*     */ import inetsoft.uql.builder.DataSourceWizard;
/*     */ import inetsoft.uql.ejb.EJBDataSource;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.widget.Grid2Layout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportWizard
/*     */   extends DataSourceWizard
/*     */ {
/*     */   public ImportWizard() throws Exception {
/*  38 */     JPanel jPanel1 = getMainPane();
/*     */     
/*  40 */     jPanel1.setBorder(new EmptyBorder(2, 2, 5, 2));
/*     */     
/*  42 */     JPanel jPanel2 = new JPanel();
/*  43 */     Grid2Layout grid2Layout = new Grid2Layout(new Insets(2, 5, 2, 5));
/*  44 */     jPanel2.setLayout(grid2Layout);
/*     */     
/*  46 */     jPanel2.add(new JLabel(Catalog.getString("EJB Home Class") + ":"), grid2Layout.at(0, 0));
/*     */     
/*  48 */     jPanel2.add(this.homeTF, grid2Layout.at(0, 1));
/*  49 */     jPanel2.add(new JLabel(Catalog.getString("Entity EJB Interface") + ":"), grid2Layout.at(1, 0));
/*     */     
/*  51 */     jPanel2.add(this.entityTF, grid2Layout.at(1, 1));
/*  52 */     jPanel2.add(this.getterCB, grid2Layout.at(2, 0));
/*  53 */     jPanel2.add(this.fieldCB, grid2Layout.at(2, 1));
/*     */     
/*  55 */     jPanel1.add(jPanel2, "North");
/*  56 */     this.descTF.setEditable(false);
/*  57 */     this.descTF.setLineWrap(true);
/*  58 */     this.descTF.setWrapStyleWord(true);
/*  59 */     this.descTF.setBackground(jPanel1.getBackground());
/*  60 */     jPanel1.add(this.descTF, "Center");
/*     */     
/*  62 */     jPanel1.setPreferredSize(new Dimension(280, 200));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populate() throws Exception {
/*  70 */     EJBDataSource eJBDataSource = (EJBDataSource)getDataSource();
/*  71 */     this.homeTF.setText(eJBDataSource.getEJBHome());
/*  72 */     this.entityTF.setText(eJBDataSource.getEJBEntity());
/*  73 */     this.getterCB.setSelected(eJBDataSource.isIncludeGetters());
/*  74 */     this.fieldCB.setSelected(eJBDataSource.isIncludeFields());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String complete() {
/*  81 */     if (this.homeTF.getText().length() == 0) {
/*  82 */       return Catalog.getString("EJB home class must be specified!");
/*     */     }
/*     */     
/*  85 */     if (this.entityTF.getText().length() == 0) {
/*  86 */       return Catalog.getString("EJB entity interface must be specified!");
/*     */     }
/*     */     
/*     */     try {
/*  90 */       EJBDataSource eJBDataSource = (EJBDataSource)getDataSource();
/*  91 */       Class clazz1 = Class.forName(this.homeTF.getText());
/*  92 */       Class clazz2 = Class.forName(this.entityTF.getText());
/*     */       
/*  94 */       eJBDataSource.setIncludeGetters(this.getterCB.isSelected());
/*  95 */       eJBDataSource.setIncludeFields(this.fieldCB.isSelected());
/*  96 */       eJBDataSource.importEJB(clazz1, clazz2);
/*     */     } catch (Exception exception) {
/*     */       
/*  99 */       return exception.toString();
/*     */     } 
/*     */     
/* 102 */     return null;
/*     */   }
/*     */   
/* 105 */   JTextField homeTF = new JTextField("", 20);
/* 106 */   JTextField entityTF = new JTextField("", 20);
/* 107 */   JCheckBox getterCB = new JCheckBox(Catalog.getString("Getter Methods"));
/* 108 */   JCheckBox fieldCB = new JCheckBox(Catalog.getString("Public Fields"));
/* 109 */   JTextArea descTF = new JTextArea(Catalog.getString("Please enter the EJB home and entity bean class names to import the data definition."));
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\ejb\gui\ImportWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */