package inetsoft.uql.ejb.gui;

import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.ejb.EJBDataSource;
import inetsoft.uql.locale.Catalog;
import inetsoft.widget.Grid2Layout;
import java.awt.Dimension;
import java.awt.Insets;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ImportWizard extends DataSourceWizard {
  public ImportWizard() throws Exception {
    JPanel jPanel1 = getMainPane();
    jPanel1.setBorder(new EmptyBorder(2, 2, 5, 2));
    JPanel jPanel2 = new JPanel();
    Grid2Layout grid2Layout = new Grid2Layout(new Insets(2, 5, 2, 5));
    jPanel2.setLayout(grid2Layout);
    jPanel2.add(new JLabel(Catalog.getString("EJB Home Class") + ":"), grid2Layout.at(0, 0));
    jPanel2.add(this.homeTF, grid2Layout.at(0, 1));
    jPanel2.add(new JLabel(Catalog.getString("Entity EJB Interface") + ":"), grid2Layout.at(1, 0));
    jPanel2.add(this.entityTF, grid2Layout.at(1, 1));
    jPanel2.add(this.getterCB, grid2Layout.at(2, 0));
    jPanel2.add(this.fieldCB, grid2Layout.at(2, 1));
    jPanel1.add(jPanel2, "North");
    this.descTF.setEditable(false);
    this.descTF.setLineWrap(true);
    this.descTF.setWrapStyleWord(true);
    this.descTF.setBackground(jPanel1.getBackground());
    jPanel1.add(this.descTF, "Center");
    jPanel1.setPreferredSize(new Dimension(280, 200));
  }
  
  public void populate() throws Exception {
    EJBDataSource eJBDataSource = (EJBDataSource)getDataSource();
    this.homeTF.setText(eJBDataSource.getEJBHome());
    this.entityTF.setText(eJBDataSource.getEJBEntity());
    this.getterCB.setSelected(eJBDataSource.isIncludeGetters());
    this.fieldCB.setSelected(eJBDataSource.isIncludeFields());
  }
  
  public String complete() {
    if (this.homeTF.getText().length() == 0)
      return Catalog.getString("EJB home class must be specified!"); 
    if (this.entityTF.getText().length() == 0)
      return Catalog.getString("EJB entity interface must be specified!"); 
    try {
      EJBDataSource eJBDataSource = (EJBDataSource)getDataSource();
      Class clazz1 = Class.forName(this.homeTF.getText());
      Class clazz2 = Class.forName(this.entityTF.getText());
      eJBDataSource.setIncludeGetters(this.getterCB.isSelected());
      eJBDataSource.setIncludeFields(this.fieldCB.isSelected());
      eJBDataSource.importEJB(clazz1, clazz2);
    } catch (Exception exception) {
      return exception.toString();
    } 
    return null;
  }
  
  JTextField homeTF = new JTextField("", 20);
  
  JTextField entityTF = new JTextField("", 20);
  
  JCheckBox getterCB = new JCheckBox(Catalog.getString("Getter Methods"));
  
  JCheckBox fieldCB = new JCheckBox(Catalog.getString("Public Fields"));
  
  JTextArea descTF = new JTextArea(Catalog.getString("Please enter the EJB home and entity bean class names to import the data definition."));
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\ejb\gui\ImportWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */