package inetsoft.uql.ejb.gui;

import inetsoft.uql.XDataSource;
import inetsoft.uql.XNode;
import inetsoft.uql.builder.DataSourceProperty;
import inetsoft.uql.ejb.EJBDataSource;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.schema.XTypeNode;
import inetsoft.uql.util.gui.XEditPane;
import inetsoft.uql.util.gui.XTypeTree;
import inetsoft.widget.Grid2Layout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Hashtable;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class EJBDataSourceProperty extends DataSourceProperty {
  ListSelectionListener itemListener;
  
  ValueChangeListener changeListener;
  
  ActionListener importListener;
  
  ItemListener choiceListener;
  
  public EJBDataSourceProperty() {
    this.itemListener = new ListSelectionListener(this) {
        private final EJBDataSourceProperty this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
          String str = (String)this.this$0.itemLT.getSelectedValue();
          if (str != null) {
            XNode xNode = this.this$0.xds.getRequestParameters(str);
            XTypeNode xTypeNode1 = this.this$0.xds.getRequestInputType(str);
            XTypeNode xTypeNode2 = this.this$0.xds.getRequestOutputType(str);
            if (xNode == null)
              xNode = this.this$0.xds.getRequestInputType(str).newInstance(); 
            this.this$0.xedit.setType(xTypeNode1);
            this.this$0.xedit.setValue(xNode);
            this.this$0.xtree.setEnabled(true);
            this.this$0.xtree.setType(xTypeNode2);
          } 
          this.this$0.setEnabled();
        }
      };
    this.changeListener = new ValueChangeListener(this);
    this.importListener = new ActionListener(this) {
        private final EJBDataSourceProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            String str1 = this.this$0.homeTF.getText();
            String str2 = this.this$0.entityTF.getText();
            this.this$0.xds.importEJB(Class.forName(str1), Class.forName(str2));
            this.this$0.itemLT.setModel(new EJBDataSourceProperty.ItemModel(this.this$0));
            this.this$0.valueChanged();
          } catch (Throwable throwable) {
            throwable.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, throwable.toString());
          } 
        }
      };
    this.choiceListener = new ItemListener(this) {
        private final EJBDataSourceProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          this.this$0.xds.setIncludeGetters(this.this$0.getterCB.isSelected());
          this.this$0.xds.setIncludeFields(this.this$0.fieldCB.isSelected());
        }
      };
    this.xds = null;
    this.jndinameTF = new JTextField(20);
    this.homeTF = new JTextField(15);
    this.entityTF = new JTextField(15);
    this.getterCB = new JCheckBox(Catalog.getString("Getter Methods"));
    this.fieldCB = new JCheckBox(Catalog.getString("Public Fields"));
    this.importB = new JButton(Catalog.getString("Import EJB"));
    this.itemLT = new JList();
    this.xedit = new XEditPane();
    this.xtree = new XTypeTree();
    this.folder = new JTabbedPane();
    this.outpane = new OutputPane(this);
    this.context = new ContextPane(this);
    setLayout(new BorderLayout());
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout(5, 5));
    add(jPanel1, "North");
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout(5, 5));
    jPanel1.add(jPanel2, "North");
    JPanel jPanel3 = new JPanel();
    jPanel3.add(new JLabel(Catalog.getString("EJB Home JNDI Name")));
    jPanel3.add(this.jndinameTF);
    jPanel2.add(jPanel3, "North");
    jPanel3 = new JPanel();
    jPanel3.setBorder(new TitledBorder(Catalog.getString("EJB")));
    jPanel3.setLayout(new BorderLayout(5, 5));
    jPanel1.add(jPanel3, "Center");
    JPanel jPanel4 = new JPanel();
    Grid2Layout grid2Layout = new Grid2Layout(new Insets(2, 5, 2, 5));
    jPanel4.setLayout(grid2Layout);
    jPanel4.add(new JLabel(Catalog.getString("EJB Home Class") + ":"), grid2Layout.at(0, 0));
    jPanel4.add(this.homeTF, grid2Layout.at(0, 1, 1, 2));
    jPanel4.add(new JLabel(Catalog.getString("Entity EJB Interface") + ":"), grid2Layout.at(1, 0));
    jPanel4.add(this.entityTF, grid2Layout.at(1, 1, 1, 2));
    jPanel4.add(this.getterCB, grid2Layout.at(2, 0));
    jPanel4.add(this.fieldCB, grid2Layout.at(2, 1));
    jPanel4.add(this.importB, grid2Layout.at(2, 2));
    jPanel3.add(jPanel4, "East");
    JScrollPane jScrollPane = new JScrollPane(this.itemLT);
    jScrollPane.setPreferredSize(new Dimension(140, 60));
    jPanel3.add(jScrollPane, "Center");
    this.folder.add(this.xedit, Catalog.getString("Parameters"));
    this.folder.add(this.outpane, Catalog.getString("Output"));
    this.folder.add(new JScrollPane(this.context), Catalog.getString("Context"));
    add(this.folder, "Center");
    this.getterCB.setSelected(true);
    this.fieldCB.setSelected(true);
    this.itemLT.addListSelectionListener(this.itemListener);
    this.xedit.addChangeListener(this.changeListener);
    this.jndinameTF.getDocument().addDocumentListener(this.changeListener);
    this.homeTF.getDocument().addDocumentListener(this.changeListener);
    this.entityTF.getDocument().addDocumentListener(this.changeListener);
    this.importB.addActionListener(this.importListener);
    this.getterCB.addItemListener(this.choiceListener);
    this.fieldCB.addItemListener(this.choiceListener);
    setEnabled();
  }
  
  public void setDataSource(XDataSource paramXDataSource) {
    this.xds = (EJBDataSource)paramXDataSource;
    this.jndinameTF.setText(this.xds.getJNDIName());
    this.homeTF.setText(this.xds.getEJBHome());
    this.entityTF.setText(this.xds.getEJBEntity());
    this.itemLT.setModel(new ItemModel(this));
    this.getterCB.setSelected(this.xds.isIncludeGetters());
    this.fieldCB.setSelected(this.xds.isIncludeFields());
    if (this.xds.getRequestCount() > 0)
      this.itemLT.setSelectedIndex(0); 
    this.context.setDataSource();
    setValueChanged(false);
    setEnabled();
  }
  
  public XDataSource getDataSource() {
    this.context.update();
    return this.xds;
  }
  
  private void setEnabled() {
    this.xedit.setEnabled((this.itemLT.getSelectedIndex() >= 0));
    this.xtree.setEnabled((this.itemLT.getSelectedIndex() >= 0));
    this.outpane.setEnabled((this.itemLT.getSelectedIndex() >= 0));
    this.importB.setEnabled((this.homeTF.getText().trim().length() > 0 && this.entityTF.getText().trim().length() > 0));
  }
  
  public void verify() {
    if (this.jndinameTF.getText().trim().length() == 0)
      throw new Exception(Catalog.getString("JNDI name can not be empty!")); 
    if (this.xds.getEJBHome() == null || this.xds.getEJBEntity() == null)
      throw new Exception(Catalog.getString("EJB home and entity classes must be imported!")); 
    if (this.xds.getRequestCount() == 0)
      throw new Exception(Catalog.getString("No finder method defined in EJB home!")); 
  }
  
  class ItemModel extends AbstractListModel {
    private final EJBDataSourceProperty this$0;
    
    ItemModel(EJBDataSourceProperty this$0) { this.this$0 = this$0; }
    
    public int getSize() { return this.this$0.xds.getRequestCount(); }
    
    public Object getElementAt(int param1Int) { return this.this$0.xds.getRequest(param1Int); }
    
    public void valueAdded() {
      fireIntervalAdded(this, getSize() - 1, getSize() - 1);
      this.this$0.valueChanged();
    }
    
    public void valueRemoved(int param1Int) {
      fireIntervalRemoved(this, param1Int, param1Int);
      this.this$0.valueChanged();
    }
  }
  
  class ValueChangeListener implements ItemListener, DocumentListener, ChangeListener, ActionListener {
    private final EJBDataSourceProperty this$0;
    
    ValueChangeListener(EJBDataSourceProperty this$0) { this.this$0 = this$0; }
    
    public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.valueChanged(); }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.valueChanged(); }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) {
      if (param1ChangeEvent.getSource() == this.this$0.xedit) {
        String str = (String)this.this$0.itemLT.getSelectedValue();
        if (str != null) {
          this.this$0.xds.setRequestParameters(str, this.this$0.xedit.getValue());
          this.this$0.xedit.setValueChanged(false);
        } 
      } 
      this.this$0.valueChanged();
    }
    
    public void insertUpdate(DocumentEvent param1DocumentEvent) {
      if (param1DocumentEvent.getDocument() == this.this$0.jndinameTF.getDocument())
        this.this$0.xds.setJNDIName(this.this$0.jndinameTF.getText()); 
      this.this$0.valueChanged();
      this.this$0.setEnabled();
    }
    
    public void removeUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
    
    public void changedUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
  }
  
  class OutputPane extends JPanel {
    private final EJBDataSourceProperty this$0;
    
    public OutputPane(EJBDataSourceProperty this$0) {
      this.this$0 = this$0;
      setLayout(new BorderLayout(10, 10));
      add(new JScrollPane(this$0.xtree), "Center");
    }
  }
  
  class ContextPane extends JPanel {
    JTextField[] fields;
    
    private final EJBDataSourceProperty this$0;
    
    public ContextPane(EJBDataSourceProperty this$0) {
      this.this$0 = this$0;
      this.fields = new JTextField[EJBDataSourceProperty.CONTEXT_PROPERTIES.length];
      GridBagLayout gridBagLayout = new GridBagLayout();
      setLayout(gridBagLayout);
      for (byte b = 0; b < this.fields.length; b++) {
        GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
        gridBagConstraints1.anchor = 13;
        gridBagConstraints1.insets = new Insets(0, 0, 0, 5);
        add(new JLabel(EJBDataSourceProperty.CONTEXT_NAMES[b]), gridBagConstraints1);
        GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
        gridBagConstraints2.gridwidth = 0;
        add(this.fields[b] = new JTextField(15), gridBagConstraints2);
        this.fields[b].getDocument().addDocumentListener(this$0.changeListener);
      } 
    }
    
    public void setDataSource() {
      if (this.this$0.xds == null)
        return; 
      Hashtable hashtable = this.this$0.xds.getContextProperties();
      for (byte b = 0; b < this.fields.length; b++) {
        String str = (String)hashtable.get(EJBDataSourceProperty.CONTEXT_PROPERTIES[b]);
        if (str != null)
          this.fields[b].setText(str); 
      } 
    }
    
    public void update() {
      Hashtable hashtable = new Hashtable();
      for (byte b = 0; b < this.fields.length; b++) {
        String str = this.fields[b].getText();
        if (str.length() > 0)
          hashtable.put(EJBDataSourceProperty.CONTEXT_PROPERTIES[b], str); 
      } 
      this.this$0.xds.setContextProperties(hashtable);
    }
  }
  
  static final String[] CONTEXT_PROPERTIES = { 
      "java.naming.applet", "java.naming.authoritative", "java.naming.batchsize", "java.naming.dns.url", "java.naming.factory.initial", "java.naming.language", "java.naming.factory.object", "java.naming.provider.url", "java.naming.referral", "java.naming.security.authentication", 
      "java.naming.security.credentials", "java.naming.security.principal", "java.naming.security.protocol", "java.naming.factory.state", "java.naming.factory.url.pkgs" };
  
  static final String[] CONTEXT_NAMES = { 
      "APPLET", "AUTHORITATIVE", "BATCHSIZE", "DNS_URL", "INITIAL_CONTEXT_FACTORY", "LANGUAGE", "OBJECT_FACTORIES", "PROVIDER_URL", "REFERRAL", "SECURITY_AUTHENTICATION", 
      "SECURITY_CREDENTIALS", "SECURITY_PRINCIPAL", "SECURITY_PROTOCOL", "STATE_FACTORIES", "URL_PKG_PREFIXES" };
  
  EJBDataSource xds;
  
  ItemModel itemModel;
  
  JTextField jndinameTF;
  
  JTextField homeTF;
  
  JTextField entityTF;
  
  JCheckBox getterCB;
  
  JCheckBox fieldCB;
  
  JButton importB;
  
  JList itemLT;
  
  XEditPane xedit;
  
  XTypeTree xtree;
  
  JTabbedPane folder;
  
  OutputPane outpane;
  
  ContextPane context;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\ejb\gui\EJBDataSourceProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */