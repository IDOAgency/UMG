package inetsoft.uql.ejb.gui;

import inetsoft.uql.xml.gui.XMLQueryProperty;

public class EJBQueryProperty extends XMLQueryProperty {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\ejb\gui\EJBQueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */