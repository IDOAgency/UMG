/*    */ package inetsoft.uql.ejb.gui;
/*    */ 
/*    */ import inetsoft.uql.XDataSource;
/*    */ import inetsoft.uql.builder.DataSourceWizard;
/*    */ import inetsoft.uql.ejb.EJBDataSource;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EJBDataSourceWizard
/*    */   extends DataSourceWizard
/*    */ {
/*    */   public EJBDataSourceWizard() throws Exception {
/* 37 */     super(dialogs);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 95 */     this.xds = new EJBDataSource();
/* 96 */     this.jndiTF = new JTextField("", 20);
/* 97 */     this.descTF = new JTextArea(Catalog.getString("Please enter the EJB home JNDI name."));
/*    */     JPanel jPanel1 = getMainPane();
/*    */     JPanel jPanel2 = new JPanel();
/*    */     jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
/*    */     jPanel2.setLayout(new BorderLayout(2, 2));
/*    */     jPanel2.add(new JLabel(Catalog.getString("EJB Home JNDI") + ":"), "West");
/*    */     jPanel2.add(this.jndiTF, "Center");
/*    */     jPanel1.add(jPanel2, "North");
/*    */     this.descTF.setEditable(false);
/*    */     this.descTF.setLineWrap(true);
/*    */     this.descTF.setWrapStyleWord(true);
/*    */     this.descTF.setBackground(jPanel1.getBackground());
/*    */     jPanel1.add(this.descTF, "Center");
/*    */     jPanel1.setPreferredSize(new Dimension(280, 200));
/*    */   }
/*    */   
/*    */   public XDataSource getDataSource() { return this.xds; }
/*    */   
/*    */   public void setDataSource(XDataSource paramXDataSource) { this.xds = (EJBDataSource)paramXDataSource; }
/*    */   
/*    */   public void populate() throws Exception { this.jndiTF.setText(this.xds.getJNDIName()); }
/*    */   
/*    */   public String complete() {
/*    */     if (this.jndiTF.getText().length() == 0)
/*    */       return Catalog.getString("EJB home JNDI must be specified!"); 
/*    */     this.xds.setJNDIName(this.jndiTF.getText());
/*    */     return null;
/*    */   }
/*    */   
/*    */   static final String[] dialogs = { "inetsoft.uql.ejb.gui.ImportWizard" };
/*    */   EJBDataSource xds;
/*    */   JTextField jndiTF;
/*    */   JTextArea descTF;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\ejb\gui\EJBDataSourceWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */