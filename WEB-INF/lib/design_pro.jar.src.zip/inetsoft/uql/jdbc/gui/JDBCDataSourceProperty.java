package inetsoft.uql.jdbc.gui;

import inetsoft.uql.XDataSource;
import inetsoft.uql.builder.DataSourceProperty;
import inetsoft.uql.jdbc.JDBCDataSource;
import inetsoft.uql.locale.Catalog;
import inetsoft.util.internal.Property2Panel;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class JDBCDataSourceProperty extends DataSourceProperty {
  ValueChangeListener changeListener;
  
  JDBCDataSource xds;
  
  JTextField urlTF;
  
  JTextField driverTF;
  
  JTextField defaultTF;
  
  JCheckBox defaultCB;
  
  JCheckBox loginCB;
  
  JCheckBox userCB;
  
  JTextField userTF;
  
  JPasswordField passwordTF;
  
  public JDBCDataSourceProperty() {
    this.changeListener = new ValueChangeListener(this);
    this.xds = null;
    this.urlTF = new JTextField(25);
    this.driverTF = new JTextField(25);
    this.defaultTF = new JTextField(13);
    this.defaultCB = new JCheckBox(Catalog.getString("Change Default DB"), false);
    this.loginCB = new JCheckBox(Catalog.getString("Requires Login"));
    this.userCB = new JCheckBox(Catalog.getString("Save User/Password"));
    this.userTF = new JTextField(15);
    this.passwordTF = new JPasswordField(15);
    setLayout(new BorderLayout());
    Property2Panel property2Panel = new Property2Panel();
    add(property2Panel, "Center");
    property2Panel.add(Catalog.getString("Data Source"), new Object[][] { { Catalog.getString("JDBC URL") + ":", this.urlTF }, { Catalog.getString("Driver") + ":", this.driverTF }, { "", { this.defaultCB, this.defaultTF } }, { "", this.loginCB }, { "", this.userCB }, { "", this.userTF }, { "", this.passwordTF } });
    this.urlTF.getDocument().addDocumentListener(this.changeListener);
    this.driverTF.getDocument().addDocumentListener(this.changeListener);
    this.defaultTF.getDocument().addDocumentListener(this.changeListener);
    this.userTF.getDocument().addDocumentListener(this.changeListener);
    this.passwordTF.getDocument().addDocumentListener(this.changeListener);
    this.loginCB.addItemListener(this.changeListener);
    this.defaultCB.addItemListener(this.changeListener);
    this.userCB.addItemListener(this.changeListener);
    setEnabled();
  }
  
  public void setDataSource(XDataSource paramXDataSource) {
    this.xds = (JDBCDataSource)paramXDataSource;
    this.urlTF.setText(this.xds.getURL());
    this.driverTF.setText(this.xds.getDriver());
    this.loginCB.setSelected(this.xds.isRequireLogin());
    if (this.xds.getDefaultDatabase() != null) {
      this.defaultTF.setText(this.xds.getDefaultDatabase());
      this.defaultCB.setSelected(true);
    } 
    if (this.xds.getUser() != null) {
      this.userTF.setText(this.xds.getUser());
      this.passwordTF.setText(this.xds.getPassword());
      this.userCB.setSelected(true);
    } 
    setValueChanged(false);
  }
  
  public XDataSource getDataSource() {
    this.xds.setRequireLogin(this.loginCB.isSelected());
    String str = this.defaultTF.getText();
    this.xds.setDefaultDatabase((this.defaultCB.isSelected() && str.length() > 0) ? str : null);
    if (this.userCB.isSelected()) {
      String str1 = this.userTF.getText();
      String str2 = this.passwordTF.getText();
      this.xds.setUser(str1);
      this.xds.setPassword(str2);
    } else {
      this.xds.setUser(null);
      this.xds.setPassword("");
    } 
    return this.xds;
  }
  
  private void setEnabled() {
    this.defaultTF.setEnabled(this.defaultCB.isSelected());
    this.userCB.setEnabled(this.loginCB.isSelected());
    this.userTF.setEnabled((this.loginCB.isSelected() && this.userCB.isSelected()));
    this.passwordTF.setEnabled((this.loginCB.isSelected() && this.userCB.isSelected()));
  }
  
  public void verify() {
    if (this.urlTF.getText().trim().length() == 0)
      throw new Exception(Catalog.getString("URL can not be empty!")); 
    String str = this.driverTF.getText().trim();
    if (str.length() == 0)
      throw new Exception(Catalog.getString("JDBC driver is not defined!")); 
    try {
      Class.forName(str);
    } catch (ClassNotFoundException classNotFoundException) {
      throw new Exception(Catalog.getString("JDBC driver not available!"));
    } 
  }
  
  class ValueChangeListener implements ItemListener, DocumentListener, ChangeListener, ActionListener {
    private final JDBCDataSourceProperty this$0;
    
    ValueChangeListener(JDBCDataSourceProperty this$0) { this.this$0 = this$0; }
    
    public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.valueChanged(); }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) {
      this.this$0.setEnabled();
      this.this$0.valueChanged();
    }
    
    public void stateChanged(ChangeEvent param1ChangeEvent) { this.this$0.valueChanged(); }
    
    public void insertUpdate(DocumentEvent param1DocumentEvent) {
      if (param1DocumentEvent.getDocument() == this.this$0.urlTF.getDocument()) {
        this.this$0.xds.setURL(this.this$0.urlTF.getText());
      } else if (param1DocumentEvent.getDocument() == this.this$0.driverTF.getDocument()) {
        this.this$0.xds.setDriver(this.this$0.driverTF.getText());
      } 
      this.this$0.valueChanged();
    }
    
    public void removeUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
    
    public void changedUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\jdbc\gui\JDBCDataSourceProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */