package inetsoft.uql.jdbc.gui;

import inetsoft.uql.XDataSource;
import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.jdbc.JDBCDataSource;
import inetsoft.uql.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class JDBCDataSourceWizard extends DataSourceWizard {
  public JDBCDataSourceWizard() throws Exception {
    super(dialogs);
    this.xds = new JDBCDataSource();
    this.driverTF = new JTextField(this.xds.getDriver(), 20);
    this.descTF = new JTextArea(Catalog.getString("Please enter the fully qualified class name of the JDBC driver for this database."));
    JPanel jPanel1 = getMainPane();
    JPanel jPanel2 = new JPanel();
    jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel2.setLayout(new BorderLayout(2, 2));
    jPanel2.add(new JLabel(Catalog.getString("JDBC Driver") + ":"), "West");
    jPanel2.add(this.driverTF, "Center");
    jPanel1.add(jPanel2, "North");
    this.descTF.setEditable(false);
    this.descTF.setLineWrap(true);
    this.descTF.setWrapStyleWord(true);
    this.descTF.setBackground(jPanel1.getBackground());
    jPanel1.add(this.descTF, "Center");
    jPanel1.setPreferredSize(new Dimension(280, 200));
  }
  
  public XDataSource getDataSource() { return this.xds; }
  
  public void setDataSource(XDataSource paramXDataSource) { this.xds = (JDBCDataSource)paramXDataSource; }
  
  public void populate() throws Exception { this.driverTF.setText(this.xds.getDriver()); }
  
  public String complete() {
    if (this.driverTF.getText().length() == 0)
      return Catalog.getString("JDBC Driver must be specified!"); 
    try {
      Class.forName(this.driverTF.getText());
    } catch (Exception exception) {
      return Catalog.getString("The JDBC driver class can't be found. Please make sure the class is on the CLASSPATH!");
    } 
    this.xds.setDriver(this.driverTF.getText());
    return null;
  }
  
  static final String[] dialogs = { "inetsoft.uql.jdbc.gui.URLWizard" };
  
  JDBCDataSource xds;
  
  JTextField driverTF;
  
  JTextArea descTF;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\jdbc\gui\JDBCDataSourceWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */