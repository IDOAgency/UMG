package inetsoft.uql.jdbc.gui;

import inetsoft.grid.Grid;
import inetsoft.grid.editor.BooleanEditor;
import inetsoft.grid.editor.ComboEditor;
import inetsoft.grid.editor.TextAreaEditor;
import inetsoft.grid.event.GridModelEvent;
import inetsoft.grid.event.GridModelListener;
import inetsoft.grid.model.DefaultGridModel;
import inetsoft.uql.jdbc.ProcedureSQL;
import inetsoft.uql.jdbc.StructuredSQL;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.path.XSelection;
import inetsoft.uql.schema.XTypeNode;
import inetsoft.uql.util.rgraph.TableNode;
import java.util.Hashtable;

class SelectionTable extends Grid {
  GridModelListener selectTbListener;
  
  boolean full;
  
  Hashtable tbcolCBs;
  
  Hashtable lengthmap;
  
  GridModelListener listener;
  
  public SelectionTable(boolean paramBoolean) {
    this.selectTbListener = new GridModelListener(this) {
        private final SelectionTable this$0;
        
        public void valueChanged(GridModelEvent param1GridModelEvent) {
          if (param1GridModelEvent != null && param1GridModelEvent.getID() == 1 && param1GridModelEvent.getRow() == 1) {
            Object object = this.this$0.getModel().getObject(1, param1GridModelEvent.getCol());
            if (object != null) {
              ComboEditor comboEditor = (ComboEditor)this.this$0.tbcolCBs.get(object);
              this.this$0.setEditor(0, param1GridModelEvent.getCol(), comboEditor);
            } 
          } 
        }
      };
    this.full = false;
    this.tbcolCBs = new Hashtable();
    this.lengthmap = new Hashtable();
    this.full = paramBoolean;
    DefaultGridModel defaultGridModel = (DefaultGridModel)getModel();
    defaultGridModel.setHeaderColCount(1);
    defaultGridModel.setHeaderRowCount(1);
    defaultGridModel.setRowCount(paramBoolean ? 6 : 4);
    defaultGridModel.setColCount(20);
    defaultGridModel.setObject(0, -1, Catalog.getString("Field"));
    defaultGridModel.setObject(1, -1, Catalog.getString("Table"));
    defaultGridModel.setObject(2, -1, Catalog.getString("Alias"));
    defaultGridModel.setObject(3, -1, Catalog.getString("Show"));
    if (paramBoolean) {
      defaultGridModel.setObject(4, -1, Catalog.getString("Sort"));
      defaultGridModel.setObject(5, -1, Catalog.getString("Criteria"));
    } 
    setFrozenRow(1);
    setEditable(0, -99, true);
    setRowHeight(-1, 6);
    setMinColWidth(-99, 120);
    setMinColWidth(-1, 20);
    setAlignment(-99, -1, 4);
    setEditable(2, -99, true);
    setRenderer(3, -99, new BooleanEditor());
    setEditor(3, -99, new BooleanEditor());
    setAlignment(3, -99, 2);
    setRowSelectable(false);
    setReorderable(2);
    if (paramBoolean) {
      setEditor(5, -99, new TextAreaEditor(10, 3));
      setMinRowHeight(5, 40);
      setEditor(4, -99, new ComboEditor(sortopts));
    } else {
      setRowVisible(1, false);
    } 
    getModel().addGridModelListener(this.selectTbListener);
  }
  
  public void setModelListener(GridModelListener paramGridModelListener) { getModel().addGridModelListener(this.listener = paramGridModelListener); }
  
  public void populateColumns(StructuredSQL paramStructuredSQL, TableNode[] paramArrayOfTableNode, boolean paramBoolean) {
    DefaultGridModel defaultGridModel = (DefaultGridModel)getModel();
    XSelection xSelection = paramStructuredSQL.getSelection();
    Hashtable hashtable1 = new Hashtable();
    defaultGridModel.removeGridModelListener(this.listener);
    defaultGridModel.removeGridModelListener(this.selectTbListener);
    setSuspended(true);
    Hashtable hashtable2 = new Hashtable();
    hashtable1.clear();
    if (paramBoolean) {
      clear();
    } else {
      for (byte b = 0; b < defaultGridModel.getColCount(); b++) {
        if (defaultGridModel.getObject(false, b) != null && (defaultGridModel.getObject(3, b) == null || !((Boolean)defaultGridModel.getObject(3, b)).booleanValue()))
          hashtable2.put(defaultGridModel.getObject(0, b), Boolean.TRUE); 
      } 
    } 
    this.tbcolCBs.clear();
    for (byte b1 = 0; b1 < paramArrayOfTableNode.length; b1++) {
      String[] arrayOfString1 = new String[paramArrayOfTableNode[b1].getColumnCount()];
      for (byte b = 0; b < arrayOfString1.length; b++)
        arrayOfString1[b] = paramArrayOfTableNode[b1].getColumn(b); 
      ComboEditor comboEditor = new ComboEditor(arrayOfString1);
      comboEditor.setEditable(true);
      this.tbcolCBs.put(paramArrayOfTableNode[b1].getName(), comboEditor);
    } 
    clear();
    byte b2 = 0;
    for (byte b3 = 0; b3 < paramArrayOfTableNode.length; b3++) {
      String str = paramArrayOfTableNode[b3].getName();
      for (byte b = 0; b < paramArrayOfTableNode[b3].getColumnCount(); b++, b2++) {
        String str1 = paramArrayOfTableNode[b3].getColumn(b);
        String str2 = str + "." + str1;
        XTypeNode xTypeNode = (XTypeNode)paramArrayOfTableNode[b3].getUserObject(b);
        String str3 = (paramStructuredSQL != null) ? paramStructuredSQL.getCondition(str2) : null;
        String str4 = (paramStructuredSQL != null) ? paramStructuredSQL.getSorting(str2) : null;
        if (b2 >= defaultGridModel.getColCount())
          defaultGridModel.insertCol(defaultGridModel.getColCount(), 1); 
        defaultGridModel.setObject(0, b2, str1);
        defaultGridModel.setObject(1, b2, str);
        defaultGridModel.setObject(3, b2, new Boolean((!paramBoolean && hashtable2.get(str1) == null)));
        defaultGridModel.setObject(4, b2, str4);
        defaultGridModel.setObject(5, b2, str3);
        hashtable2.put(str1, Boolean.TRUE);
        hashtable1.put(str2, new Integer(b2));
        if (xTypeNode instanceof inetsoft.uql.schema.StringType && xTypeNode.getAttribute("length") != null)
          this.lengthmap.put(str2, xTypeNode.getAttribute("length")); 
        ComboEditor comboEditor = (ComboEditor)this.tbcolCBs.get(str);
        setEditor(0, b2, comboEditor);
      } 
    } 
    for (byte b4 = 0; xSelection != null && b4 < xSelection.getColumnCount(); b4++) {
      String str1 = xSelection.getColumn(b4);
      String str2 = xSelection.getAlias(str1);
      String str3 = null;
      int i = str1.lastIndexOf('.');
      if (i >= 0) {
        str3 = str1.substring(0, i);
        str1 = str1.substring(i + 1);
      } 
      Integer integer = (Integer)hashtable1.get(str3 + "." + str1);
      int j = defaultGridModel.getColCount();
      if (integer == null) {
        if (b2 >= defaultGridModel.getColCount())
          defaultGridModel.insertCol(defaultGridModel.getColCount(), 1); 
        j = b2++;
      } else {
        j = integer.intValue();
      } 
      defaultGridModel.setObject(0, j, str1);
      defaultGridModel.setObject(1, j, str3);
      defaultGridModel.setObject(2, j, str2);
      defaultGridModel.setObject(3, j, Boolean.TRUE);
    } 
    String[] arrayOfString = new String[paramArrayOfTableNode.length];
    for (byte b5 = 0; b5 < arrayOfString.length; b5++)
      arrayOfString[b5] = paramArrayOfTableNode[b5].getName(); 
    setEditor(1, -99, new ComboEditor(arrayOfString));
    defaultGridModel.addGridModelListener(this.listener);
    defaultGridModel.addGridModelListener(this.selectTbListener);
    setSuspended(false);
  }
  
  public void populateColumns(ProcedureSQL paramProcedureSQL) {
    DefaultGridModel defaultGridModel = (DefaultGridModel)getModel();
    XSelection xSelection = paramProcedureSQL.getSelection();
    Hashtable hashtable = new Hashtable();
    defaultGridModel.removeGridModelListener(this.listener);
    defaultGridModel.removeGridModelListener(this.selectTbListener);
    setSuspended(true);
    clear();
    byte b1 = 0;
    for (byte b2 = 0; b2 < paramProcedureSQL.getColumnCount(); b2++) {
      String str1 = paramProcedureSQL.getColumnName(b2);
      String str2 = paramProcedureSQL.getColumnType(b2);
      int i = paramProcedureSQL.getColumnLength(b2);
      if (b1 >= defaultGridModel.getColCount())
        defaultGridModel.insertCol(defaultGridModel.getColCount(), 1); 
      defaultGridModel.setObject(0, b1, str1);
      defaultGridModel.setObject(3, b1, Boolean.TRUE);
      hashtable.put(str1, new Integer(b1));
      if (str2 != null && str2.equals("string") && i > 0)
        this.lengthmap.put(str1, new Integer(i)); 
    } 
    for (byte b3 = 0; xSelection != null && b3 < xSelection.getColumnCount(); b3++) {
      String str1 = xSelection.getColumn(b3);
      String str2 = xSelection.getAlias(str1);
      Integer integer = (Integer)hashtable.get(str1);
      int i = defaultGridModel.getColCount();
      if (integer == null) {
        if (b1 >= defaultGridModel.getColCount())
          defaultGridModel.insertCol(defaultGridModel.getColCount(), 1); 
        i = b1++;
      } else {
        i = integer.intValue();
      } 
      defaultGridModel.setObject(0, i, str1);
      defaultGridModel.setObject(2, i, str2);
      defaultGridModel.setObject(3, i, Boolean.TRUE);
    } 
    String[] arrayOfString = new String[b1];
    for (byte b4 = 0; b4 < arrayOfString.length; b4++)
      arrayOfString[b4] = (String)defaultGridModel.getObject(0, b4); 
    ComboEditor comboEditor = new ComboEditor(arrayOfString);
    comboEditor.setEditable(true);
    setEditor(0, -99, comboEditor);
    defaultGridModel.addGridModelListener(this.listener);
    defaultGridModel.addGridModelListener(this.selectTbListener);
    setSuspended(false);
  }
  
  public void clear() {
    DefaultGridModel defaultGridModel = (DefaultGridModel)getModel();
    for (byte b = 0; b < defaultGridModel.getRowCount(); b++) {
      for (byte b1 = 0; b1 < defaultGridModel.getColCount(); b1++)
        defaultGridModel.setObject(b, b1, null); 
    } 
    this.lengthmap.clear();
  }
  
  public void createSelection(StructuredSQL paramStructuredSQL) {
    XSelection xSelection = paramStructuredSQL.getSelection();
    xSelection.clear();
    for (byte b = 0; b < getColCount(); b++) {
      String str = (String)getObject(0, b);
      if (str != null && str.length() != 0) {
        String str1 = getObject(1, b) + "." + str;
        Boolean bool = (Boolean)getObject(3, b);
        if (bool != null && bool.booleanValue()) {
          String str3 = (String)getObject(2, b);
          xSelection.addColumn(str1);
          xSelection.setAlias(str1, (str3 != null && str3.length() > 0) ? str3 : null);
          Integer integer = (Integer)this.lengthmap.get(str1);
          if (integer != null)
            xSelection.setConversion(str1, "string", integer.toString()); 
        } 
        String str2 = (String)getObject(5, b);
        if (str2 != null && str2.length() > 0)
          paramStructuredSQL.setCondition(str1, str2); 
        paramStructuredSQL.setSorting(str1, (String)getObject(4, b));
      } 
    } 
  }
  
  public void createSelection(ProcedureSQL paramProcedureSQL) {
    XSelection xSelection = paramProcedureSQL.getSelection();
    xSelection.clear();
    for (byte b = 0; b < getColCount(); b++) {
      String str = (String)getObject(0, b);
      if (str != null && str.length() != 0) {
        Boolean bool = (Boolean)getObject(3, b);
        if (bool != null && bool.booleanValue()) {
          String str1 = (String)getObject(2, b);
          xSelection.addColumn(str);
          xSelection.setAlias(str, (str1 != null && str1.length() > 0) ? str1 : null);
          Integer integer = (Integer)this.lengthmap.get(str);
          if (integer != null)
            xSelection.setConversion(str, "string", integer.toString()); 
        } 
      } 
    } 
  }
  
  static final String[] sortopts = { Catalog.getString("(not sorted)"), "Ascending", "Descending" };
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\jdbc\gui\SelectionTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */