/*    */ package inetsoft.uql.jdbc.gui;
/*    */ 
/*    */ import inetsoft.uql.builder.DataSourceWizard;
/*    */ import inetsoft.uql.jdbc.JDBCDataSource;
/*    */ import inetsoft.uql.locale.Catalog;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class URLWizard
/*    */   extends DataSourceWizard
/*    */ {
/*    */   public URLWizard() {
/* 37 */     JPanel jPanel1 = getMainPane();
/*    */     
/* 39 */     JPanel jPanel2 = new JPanel();
/* 40 */     jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
/* 41 */     jPanel2.setLayout(new BorderLayout(2, 2));
/* 42 */     jPanel2.add(new JLabel(Catalog.getString("JDBC URL") + ":"), "West");
/* 43 */     jPanel2.add(this.urlTF, "Center");
/*    */     
/* 45 */     jPanel1.add(jPanel2, "North");
/*    */     
/* 47 */     this.descTF.setEditable(false);
/* 48 */     this.descTF.setLineWrap(true);
/* 49 */     this.descTF.setWrapStyleWord(true);
/* 50 */     this.descTF.setBackground(jPanel1.getBackground());
/* 51 */     jPanel1.add(this.descTF, "Center");
/*    */     
/* 53 */     jPanel1.setPreferredSize(new Dimension(280, 200));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public void populate() { this.urlTF.setText(((JDBCDataSource)getDataSource()).getURL()); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String complete() {
/* 68 */     if (this.urlTF.getText().length() == 0) {
/* 69 */       return Catalog.getString("JDBC URL must be specified!");
/*    */     }
/*    */     
/* 72 */     ((JDBCDataSource)getDataSource()).setURL(this.urlTF.getText());
/* 73 */     return null;
/*    */   }
/*    */   
/* 76 */   JTextField urlTF = new JTextField(20);
/* 77 */   JTextArea descTF = new JTextArea(Catalog.getString("Please enter the JDBC URL of the database."));
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\jdbc\gui\URLWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */