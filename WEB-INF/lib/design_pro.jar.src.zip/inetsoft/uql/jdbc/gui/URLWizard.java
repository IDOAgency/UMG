package inetsoft.uql.jdbc.gui;

import inetsoft.uql.builder.DataSourceWizard;
import inetsoft.uql.jdbc.JDBCDataSource;
import inetsoft.uql.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class URLWizard extends DataSourceWizard {
  public URLWizard() {
    JPanel jPanel1 = getMainPane();
    JPanel jPanel2 = new JPanel();
    jPanel2.setBorder(new EmptyBorder(2, 2, 5, 2));
    jPanel2.setLayout(new BorderLayout(2, 2));
    jPanel2.add(new JLabel(Catalog.getString("JDBC URL") + ":"), "West");
    jPanel2.add(this.urlTF, "Center");
    jPanel1.add(jPanel2, "North");
    this.descTF.setEditable(false);
    this.descTF.setLineWrap(true);
    this.descTF.setWrapStyleWord(true);
    this.descTF.setBackground(jPanel1.getBackground());
    jPanel1.add(this.descTF, "Center");
    jPanel1.setPreferredSize(new Dimension(280, 200));
  }
  
  public void populate() { this.urlTF.setText(((JDBCDataSource)getDataSource()).getURL()); }
  
  public String complete() {
    if (this.urlTF.getText().length() == 0)
      return Catalog.getString("JDBC URL must be specified!"); 
    ((JDBCDataSource)getDataSource()).setURL(this.urlTF.getText());
    return null;
  }
  
  JTextField urlTF = new JTextField(20);
  
  JTextArea descTF = new JTextArea(Catalog.getString("Please enter the JDBC URL of the database."));
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\jdbc\gui\URLWizard.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */