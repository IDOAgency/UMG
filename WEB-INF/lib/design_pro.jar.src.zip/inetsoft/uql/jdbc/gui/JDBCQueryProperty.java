package inetsoft.uql.jdbc.gui;

import inetsoft.grid.Grid;
import inetsoft.grid.MultiSheet;
import inetsoft.grid.event.GridModelEvent;
import inetsoft.grid.event.GridModelListener;
import inetsoft.uql.VariableTable;
import inetsoft.uql.XDataService;
import inetsoft.uql.XFactory;
import inetsoft.uql.XNode;
import inetsoft.uql.XQuery;
import inetsoft.uql.XRepository;
import inetsoft.uql.XTableNode;
import inetsoft.uql.builder.QueryProperty;
import inetsoft.uql.builder.VariableEntry;
import inetsoft.uql.jdbc.FreeformSQL;
import inetsoft.uql.jdbc.JDBCDataSource;
import inetsoft.uql.jdbc.JDBCQuery;
import inetsoft.uql.jdbc.ProcedureSQL;
import inetsoft.uql.jdbc.SQLDefinition;
import inetsoft.uql.jdbc.StructuredSQL;
import inetsoft.uql.locale.Catalog;
import inetsoft.uql.schema.UserVariable;
import inetsoft.uql.schema.XTypeNode;
import inetsoft.uql.util.gui.XNodeTree;
import inetsoft.uql.util.gui.XTableNodeModel;
import inetsoft.uql.util.rgraph.TableColumn;
import inetsoft.uql.util.rgraph.TableGraph;
import inetsoft.uql.util.rgraph.TableNode;
import inetsoft.widget.VFlowLayout;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

public class JDBCQueryProperty extends QueryProperty {
  ActionListener addListener;
  
  TreeSelectionListener treeListener;
  
  ItemListener typeListener;
  
  ActionListener prevListener;
  
  ActionListener genListener;
  
  ChangeListener graphListener;
  
  GridModelListener selectTbListener;
  
  DocumentListener changeListener;
  
  ComponentListener orderListener;
  
  XRepository repository;
  
  XNodeTree tree;
  
  TableGraph graph;
  
  JTextArea sqlTF;
  
  MultiSheet tables;
  
  ProcedurePane xedit;
  
  SelectionTable selectTb;
  
  SelectionTable procTb;
  
  Grid prevTb;
  
  JRadioButton freeCB;
  
  JRadioButton structCB;
  
  JRadioButton procCB;
  
  JButton addB;
  
  JButton previewB;
  
  JButton genB;
  
  JPanel midPane;
  
  CardLayout midLO;
  
  JDBCDataSource xds;
  
  JDBCQuery xquery;
  
  StructuredSQL structSQL;
  
  ProcedureSQL procSQL;
  
  Hashtable tablemeta;
  
  public JDBCQueryProperty() {
    this.addListener = new ActionListener(this) {
        private final JDBCQueryProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          XNode xNode = this.this$0.tree.getSelectedNode();
          if (xNode.getAttribute("type").equals("PROCEDURE")) {
            this.this$0.procCB.setSelected(true);
            this.this$0.setEnabled();
            try {
              this.this$0.procSQL = new ProcedureSQL();
              XNode xNode1 = this.this$0.repository.getMetaData(this.this$0.getSession(), this.this$0.xds, xNode);
              this.this$0.procSQL.setMetaData(xNode1);
              this.this$0.xedit.setProcedure(this.this$0.procSQL);
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString());
            } 
          } else {
            this.this$0.structCB.setSelected(true);
            this.this$0.setEnabled();
            XNode[] arrayOfXNode1 = this.this$0.tree.getSelectedNodes();
            TableNode[] arrayOfTableNode = this.this$0.graph.getTables();
            Vector vector = new Vector();
            if (arrayOfTableNode != null)
              for (byte b1 = 0; b1 < arrayOfTableNode.length; b1++)
                vector.addElement(arrayOfTableNode[b1].getUserObject());  
            for (byte b = 0; b < arrayOfXNode1.length; b++) {
              if (vector.indexOf(arrayOfXNode1[b]) < 0)
                vector.addElement(arrayOfXNode1[b]); 
            } 
            XNode[] arrayOfXNode2 = new XNode[vector.size()];
            vector.copyInto(arrayOfXNode2);
            try {
              TableNode[] arrayOfTableNode1 = this.this$0.createTableNodes(arrayOfXNode2);
              this.this$0.graph.setTables(arrayOfTableNode1);
              this.this$0.selectTb.populateColumns(this.this$0.structSQL, this.this$0.graph.getTables(), false);
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString());
            } 
          } 
          this.this$0.valueChanged();
          this.this$0.updateQuery();
        }
      };
    this.treeListener = new TreeSelectionListener(this) {
        private final JDBCQueryProperty this$0;
        
        public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) { this.this$0.setEnabled(); }
      };
    this.typeListener = new ItemListener(this) {
        private final JDBCQueryProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          if (((JRadioButton)param1ItemEvent.getSource()).isSelected()) {
            SQLDefinition sQLDefinition = this.this$0.xquery.getSQLDefinition();
            if (this.this$0.freeCB.isSelected() && this.this$0.sqlTF.getText().length() == 0 && sQLDefinition instanceof StructuredSQL)
              this.this$0.sqlTF.setText(sQLDefinition.toString()); 
            this.this$0.updateQuery();
            this.this$0.valueChanged();
            this.this$0.setEnabled();
          } 
        }
      };
    this.prevListener = new ActionListener(this) {
        private final JDBCQueryProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            XDataService xDataService = XFactory.getDataService();
            UserVariable[] arrayOfUserVariable = xDataService.getQueryParameters(this.this$0.getSession(), this.this$0.xquery.getName(), true);
            VariableTable variableTable = null;
            if (arrayOfUserVariable != null && arrayOfUserVariable.length > 0) {
              variableTable = VariableEntry.show(arrayOfUserVariable);
              if (variableTable == null)
                return; 
            } 
            XNode xNode = xDataService.execute(this.this$0.getSession(), this.this$0.xquery.getName(), variableTable);
            if (xNode != null)
              this.this$0.prevTb.setModel(new XTableNodeModel((XTableNode)xNode)); 
            this.this$0.tables.toFront(1);
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, exception.toString());
          } 
        }
      };
    this.genListener = new ActionListener(this) {
        private final JDBCQueryProperty this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          SQLDefinition sQLDefinition = this.this$0.xquery.getSQLDefinition();
          if (sQLDefinition instanceof StructuredSQL)
            this.this$0.sqlTF.setText(sQLDefinition.toString()); 
        }
      };
    this.graphListener = new ChangeListener(this) {
        private final JDBCQueryProperty this$0;
        
        public void stateChanged(ChangeEvent param1ChangeEvent) {
          this.this$0.selectTb.populateColumns(this.this$0.structSQL, this.this$0.graph.getTables(), false);
          this.this$0.valueChanged();
          this.this$0.updateQuery();
        }
      };
    this.selectTbListener = new GridModelListener(this) {
        private final JDBCQueryProperty this$0;
        
        public void valueChanged(GridModelEvent param1GridModelEvent) {
          this.this$0.valueChanged();
          this.this$0.updateQuery();
        }
      };
    this.changeListener = new DocumentListener(this) {
        private final JDBCQueryProperty this$0;
        
        public void insertUpdate(DocumentEvent param1DocumentEvent) {
          this.this$0.updateQuery();
          this.this$0.valueChanged();
        }
        
        public void removeUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
        
        public void changedUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
      };
    this.orderListener = new ComponentAdapter(this) {
        private final JDBCQueryProperty this$0;
        
        public void componentMoved(ComponentEvent param1ComponentEvent) { this.this$0.selectTbListener.valueChanged(null); }
      };
    this.tree = new XNodeTree();
    this.graph = new TableGraph();
    this.sqlTF = new JTextArea(5, 40);
    this.tables = new MultiSheet();
    this.xedit = new ProcedurePane();
    this.selectTb = new SelectionTable(true);
    this.procTb = new SelectionTable(false);
    this.prevTb = new Grid();
    this.freeCB = new JRadioButton(Catalog.getString("SQL View"));
    this.structCB = new JRadioButton(Catalog.getString("Design View"));
    this.procCB = new JRadioButton(Catalog.getString("Procedure View"));
    this.addB = new JButton(Catalog.getString("Add Table"));
    this.previewB = new JButton(Catalog.getString("Preview"));
    this.genB = new JButton(Catalog.getString("Generate SQL from Selection Table"));
    this.midPane = new JPanel();
    this.midLO = new CardLayout();
    this.tablemeta = new Hashtable();
    setLayout(new BorderLayout(5, 5));
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout(5, 5));
    add(jPanel1, "North");
    JScrollPane jScrollPane = new JScrollPane(this.tree);
    jScrollPane.setPreferredSize(new Dimension(150, 100));
    jPanel1.add(jScrollPane, "Center");
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout(2, 0));
    jPanel1.add(jPanel2, "East");
    JPanel jPanel3 = new JPanel();
    jPanel3.setLayout(new VFlowLayout(0, 0, 0));
    this.freeCB.setFont(new Font("Dialog", 0, 10));
    this.structCB.setFont(new Font("Dialog", 0, 10));
    this.procCB.setFont(new Font("Dialog", 0, 10));
    jPanel3.add(this.freeCB);
    jPanel3.add(this.structCB);
    jPanel3.add(this.procCB);
    jPanel2.add(jPanel3, "North");
    JPanel jPanel4 = new JPanel();
    jPanel4.add(this.addB);
    jPanel2.add(jPanel4, "Center");
    this.midPane.setLayout(this.midLO);
    this.midPane.add(new JScrollPane(this.graph), "graph");
    JPanel jPanel5 = new JPanel();
    this.sqlTF.setLineWrap(true);
    this.sqlTF.setWrapStyleWord(true);
    jPanel5.setBorder(new TitledBorder(Catalog.getString("SQL")));
    jPanel5.setLayout(new BorderLayout(0, 0));
    jPanel5.add(new JScrollPane(this.sqlTF, 22, 31), "Center");
    JPanel jPanel6 = new JPanel();
    jPanel6.setLayout(new FlowLayout(2, 5, 5));
    jPanel6.add(this.genB);
    jPanel5.add(jPanel6, "South");
    this.midPane.add(jPanel5, "sql");
    this.midPane.add(this.xedit, "proc");
    this.midPane.setPreferredSize(new Dimension(400, 250));
    this.midLO.show(this.midPane, "graph");
    add(this.midPane, "Center");
    this.tables.add(this.selectTb, Catalog.getString("Selection"));
    this.tables.add(this.prevTb, Catalog.getString("Preview"));
    this.tables.setPreferredSize(new Dimension(350, 100));
    this.tables.toFront(0);
    add(this.tables, "South");
    this.prevTb.setGap(-99, -99, new Insets(0, 4, 0, 4));
    this.prevTb.setRowSelectable(false);
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(this.freeCB);
    buttonGroup.add(this.structCB);
    buttonGroup.add(this.procCB);
    this.structCB.setSelected(true);
    this.graph.addChangeListener(this.graphListener);
    this.freeCB.addItemListener(this.typeListener);
    this.structCB.addItemListener(this.typeListener);
    this.procCB.addItemListener(this.typeListener);
    this.tree.addTreeSelectionListener(this.treeListener);
    this.addB.addActionListener(this.addListener);
    this.selectTb.setModelListener(this.selectTbListener);
    this.selectTb.addComponentListener(this.orderListener);
    this.procTb.setModelListener(this.selectTbListener);
    this.procTb.addComponentListener(this.orderListener);
    this.previewB.addActionListener(this.prevListener);
    this.sqlTF.getDocument().addDocumentListener(this.changeListener);
    this.genB.addActionListener(this.genListener);
    setEnabled();
  }
  
  public void setQuery(XQuery paramXQuery) {
    this.xquery = (JDBCQuery)paramXQuery;
    this.xds = (JDBCDataSource)paramXQuery.getDataSource();
    this.freeCB.removeItemListener(this.typeListener);
    this.structCB.removeItemListener(this.typeListener);
    this.procCB.removeItemListener(this.typeListener);
    this.sqlTF.getDocument().removeDocumentListener(this.changeListener);
    SQLDefinition sQLDefinition = this.xquery.getSQLDefinition();
    this.freeCB.setSelected(sQLDefinition instanceof FreeformSQL);
    this.structCB.setSelected((sQLDefinition == null || sQLDefinition instanceof StructuredSQL));
    this.procCB.setSelected(sQLDefinition instanceof ProcedureSQL);
    this.sqlTF.setText("");
    try {
      if (this.repository == null)
        this.repository = XFactory.getRepository(); 
      UserVariable[] arrayOfUserVariable = this.repository.getConnectionParameters(getSession(), paramXQuery.getName());
      if (arrayOfUserVariable != null && arrayOfUserVariable.length > 0) {
        VariableTable variableTable = VariableEntry.show(arrayOfUserVariable);
        if (variableTable == null)
          return; 
        this.repository.connect(getSession(), paramXQuery.getName(), variableTable);
      } else {
        this.repository.connect(getSession(), paramXQuery.getName(), null);
      } 
      this.tree.setRoot(this.repository.getMetaData(getSession(), this.xds, null));
      this.tree.expandAll();
      if (sQLDefinition instanceof ProcedureSQL) {
        populateProcedureSQL((ProcedureSQL)sQLDefinition);
      } else if (sQLDefinition instanceof FreeformSQL) {
        populateFreeformSQL((FreeformSQL)sQLDefinition);
      } else {
        populateStructuredSQL((StructuredSQL)sQLDefinition);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(this, exception.toString());
    } 
    this.freeCB.addItemListener(this.typeListener);
    this.structCB.addItemListener(this.typeListener);
    this.procCB.addItemListener(this.typeListener);
    this.sqlTF.getDocument().addDocumentListener(this.changeListener);
    setEnabled();
  }
  
  public XQuery getQuery() { return this.xquery; }
  
  public Component getCommandPane() { return this.previewB; }
  
  private void updateQuery() {
    this.selectTb.popdownEditor();
    this.procTb.popdownEditor();
    if (this.freeCB.isSelected()) {
      this.xquery.setSQLDefinition(createFreeformSQL());
    } else if (this.procCB.isSelected()) {
      this.xquery.setSQLDefinition(createProcedureSQL());
    } else {
      this.xquery.setSQLDefinition(createStructuredSQL());
    } 
  }
  
  private void setEnabled() {
    if (this.structCB.isSelected()) {
      this.midLO.show(this.midPane, "graph");
      this.tables.add(this.selectTb, Catalog.getString("Selection"));
    } else if (this.procCB.isSelected()) {
      this.midLO.show(this.midPane, "proc");
      this.tables.add(this.procTb, Catalog.getString("Selection"));
    } else {
      this.midLO.show(this.midPane, "sql");
      this.tables.add(this.selectTb, Catalog.getString("Selection"));
    } 
    this.addB.setEnabled(((this.structCB.isSelected() && this.tree.getSelectedNode() != null) || this.procCB.isSelected()));
    this.selectTb.setEnabled(this.structCB.isSelected());
    this.procTb.setEnabled(this.procCB.isSelected());
    this.previewB.setEnabled((this.xquery != null));
  }
  
  private XTypeNode getTableColumns(XNode paramXNode) throws Exception {
    XTypeNode xTypeNode = (XTypeNode)this.tablemeta.get(paramXNode);
    if (xTypeNode == null) {
      xTypeNode = (XTypeNode)this.repository.getMetaData(getSession(), this.xds, paramXNode);
      xTypeNode = (XTypeNode)xTypeNode.getNode("this.Result");
      this.tablemeta.put(paramXNode, xTypeNode);
    } 
    return xTypeNode;
  }
  
  private TableNode[] createTableNodes(XNode[] paramArrayOfXNode) throws Exception {
    TableNode[] arrayOfTableNode = new TableNode[paramArrayOfXNode.length];
    Hashtable hashtable = new Hashtable();
    for (byte b1 = 0; b1 < paramArrayOfXNode.length; b1++) {
      String str1 = paramArrayOfXNode[b1].getName();
      String str2 = (String)paramArrayOfXNode[b1].getAttribute("schema");
      String str3 = (String)paramArrayOfXNode[b1].getAttribute("catalog");
      if (str2 != null && str2.length() > 0)
        str1 = str2 + "." + str1; 
      if (str3 != null && str3.length() > 0)
        str1 = str3 + "." + str1; 
      arrayOfTableNode[b1] = new TableNode(str1);
      arrayOfTableNode[b1].setUserObject(paramArrayOfXNode[b1]);
      XTypeNode xTypeNode = getTableColumns(paramArrayOfXNode[b1]);
      for (byte b = 0; b < xTypeNode.getChildCount(); b++) {
        XNode xNode = xTypeNode.getChild(b);
        String str = xNode.getName();
        arrayOfTableNode[b1].addColumn(str, xNode);
        Vector vector = (Vector)hashtable.get(str);
        if (vector == null)
          hashtable.put(str, vector = new Vector()); 
        vector.addElement(arrayOfTableNode[b1]);
      } 
    } 
    for (byte b2 = 0; b2 < arrayOfTableNode.length; b2++) {
      for (byte b = 0; b < arrayOfTableNode[b2].getColumnCount(); b++) {
        String str = arrayOfTableNode[b2].getColumn(b);
        Vector vector = (Vector)hashtable.get(str);
        if (vector != null) {
          for (int i = vector.size() - 1; i >= 0; i--) {
            TableNode tableNode = (TableNode)vector.elementAt(i);
            if (tableNode != arrayOfTableNode[b2])
              arrayOfTableNode[b2].addRelation(str, new TableColumn(tableNode, str)); 
          } 
          hashtable.remove(str);
        } 
      } 
    } 
    return arrayOfTableNode;
  }
  
  private void populateFreeformSQL(FreeformSQL paramFreeformSQL) { this.sqlTF.setText(paramFreeformSQL.getSQL()); }
  
  private FreeformSQL createFreeformSQL() { return new FreeformSQL(this.sqlTF.getText()); }
  
  private void populateStructuredSQL(StructuredSQL paramStructuredSQL) throws Exception {
    this.structSQL = paramStructuredSQL;
    if (this.structSQL == null) {
      this.selectTb.clear();
      this.graph.setTables(new TableNode[0]);
      return;
    } 
    XNode xNode = this.tree.getRoot();
    if (this.structSQL != null) {
      Vector vector = new Vector();
      for (byte b = 0; b < this.structSQL.getTableCount(); b++) {
        String str = this.structSQL.getTable(b);
        String[] arrayOfString = { "TABLE", "VIEW" };
        for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
          XNode xNode1 = xNode.getNode(xNode.getName() + "." + arrayOfString[b1] + "." + str);
          if (xNode1 != null) {
            vector.addElement(xNode1);
            this.tree.addSelectedNode(xNode1);
            break;
          } 
        } 
      } 
      XNode[] arrayOfXNode = new XNode[vector.size()];
      vector.copyInto(arrayOfXNode);
      TableNode[] arrayOfTableNode = createTableNodes(arrayOfXNode);
      this.graph.setTables(arrayOfTableNode);
    } 
    this.selectTb.populateColumns(this.structSQL, this.graph.getTables(), true);
  }
  
  private StructuredSQL createStructuredSQL() {
    TableNode[] arrayOfTableNode = this.graph.getTables();
    if (arrayOfTableNode == null)
      return null; 
    this.structSQL = new StructuredSQL();
    for (byte b = 0; b < arrayOfTableNode.length; b++) {
      String str = arrayOfTableNode[b].getName();
      this.structSQL.addTable(str);
      for (byte b1 = 0; b1 < arrayOfTableNode[b].getColumnCount(); b1++) {
        String str1 = arrayOfTableNode[b].getColumn(b1);
        TableColumn[] arrayOfTableColumn = arrayOfTableNode[b].getRelations(str1);
        for (byte b2 = 0; b2 < arrayOfTableColumn.length; b2++)
          this.structSQL.addJoin(str, str1, arrayOfTableColumn[b2].getTable().getName(), arrayOfTableColumn[b2].getColumn()); 
      } 
    } 
    this.selectTb.createSelection(this.structSQL);
    return (this.structSQL.getSelection().getColumnCount() == 0) ? null : this.structSQL;
  }
  
  private ProcedureSQL createProcedureSQL() {
    if (this.procSQL != null) {
      this.procSQL.setInputValue(this.xedit.getInputValue());
      this.procTb.createSelection(this.procSQL);
    } 
    return this.procSQL;
  }
  
  private void populateProcedureSQL(ProcedureSQL paramProcedureSQL) throws Exception {
    this.procSQL = paramProcedureSQL;
    XNode xNode = this.tree.getRoot();
    if (this.procSQL != null) {
      Vector vector = new Vector();
      String str = this.procSQL.getName();
      XNode xNode1 = xNode.getNode(xNode.getName() + ".PROCEDURE" + "." + str);
      if (xNode1 != null)
        this.tree.addSelectedNode(xNode1); 
    } 
    this.xedit.setProcedure(this.procSQL);
    this.procTb.populateColumns(this.procSQL);
  }
  
  public void verify() {
    if (this.freeCB.isSelected()) {
      if (this.sqlTF.getText().trim().length() == 0)
        throw new Exception(Catalog.getString("SQL is missing!")); 
    } else if (this.procCB.isSelected()) {
      this.xedit.verify();
    } else {
      TableNode[] arrayOfTableNode = this.graph.getTables();
      if (arrayOfTableNode == null || arrayOfTableNode.length == 0)
        throw new Exception(Catalog.getString("Not table selected!")); 
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\jdbc\gui\JDBCQueryProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */