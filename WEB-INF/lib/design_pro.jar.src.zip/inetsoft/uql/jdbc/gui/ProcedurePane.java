/*     */ package inetsoft.uql.jdbc.gui;
/*     */ 
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.jdbc.ProcedureSQL;
/*     */ import inetsoft.uql.locale.Catalog;
/*     */ import inetsoft.uql.util.gui.XEditPane;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.FlowLayout;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ProcedurePane
/*     */   extends JPanel
/*     */ {
/*     */   ProcedureSQL sql;
/*     */   JLabel nameLB;
/*     */   XEditPane xedit;
/*     */   
/*     */   public ProcedurePane() {
/* 102 */     this.nameLB = new JLabel();
/* 103 */     this.xedit = new XEditPane();
/*     */     setLayout(new BorderLayout(0, 0));
/*     */     this.xedit.setEnableStructureChange(false);
/*     */     add(this.xedit, "Center");
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setLayout(new FlowLayout(0, 0, 0));
/*     */     add(jPanel, "North");
/*     */     jPanel.add(this.nameLB);
/*     */     jPanel.add(new JLabel(" Input Parameters:"));
/*     */   }
/*     */   
/*     */   public void setProcedure(ProcedureSQL paramProcedureSQL) {
/*     */     this.sql = paramProcedureSQL;
/*     */     this.nameLB.setText("{" + paramProcedureSQL.getName() + "}");
/*     */     this.xedit.setType(paramProcedureSQL.getInputType());
/*     */     XNode xNode = paramProcedureSQL.getInputValue();
/*     */     if (xNode == null) {
/*     */       xNode = paramProcedureSQL.getInputType().newInstance();
/*     */       paramProcedureSQL.setInputValue(xNode);
/*     */     } 
/*     */     this.xedit.setValue(xNode);
/*     */   }
/*     */   
/*     */   public XNode getInputValue() { return this.xedit.getValue(); }
/*     */   
/*     */   public void verify() {
/*     */     if (this.sql == null || this.sql.getName() == null)
/*     */       throw new Exception(Catalog.getString("Procedure not specified!")); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsof\\uql\jdbc\gui\ProcedurePane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */