/*    */ package inetsoft.report.beans;
/*    */ 
/*    */ import inetsoft.report.Margin;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.io.Builder;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportBase
/*    */   extends BaseBean
/*    */ {
/* 34 */   private StyleSheet sheet = StyleSheet.createStyleSheet();
/*    */ 
/*    */ 
/*    */   
/* 38 */   public StyleSheet getReport() { return this.sheet; }
/*    */ 
/*    */ 
/*    */   
/* 42 */   public void setMargin(Margin paramMargin) { this.sheet.setMargin(paramMargin); }
/*    */ 
/*    */ 
/*    */   
/* 46 */   public Margin getMargin() { return this.sheet.getMargin(); }
/*    */ 
/*    */ 
/*    */   
/* 50 */   public void setHeaderFromEdge(double paramDouble) { this.sheet.setHeaderFromEdge(paramDouble); }
/*    */ 
/*    */ 
/*    */   
/* 54 */   public double getHeaderFromEdge() { return this.sheet.getHeaderFromEdge(); }
/*    */ 
/*    */ 
/*    */   
/* 58 */   public void setFooterFromEdge(double paramDouble) { this.sheet.setFooterFromEdge(paramDouble); }
/*    */ 
/*    */ 
/*    */   
/* 62 */   public double getFooterFromEdge() { return this.sheet.getFooterFromEdge(); }
/*    */ 
/*    */ 
/*    */   
/* 66 */   public void setPageNumberingStart(int paramInt) { this.sheet.setPageNumberingStart(paramInt); }
/*    */ 
/*    */ 
/*    */   
/* 70 */   public int getPageNumberingStart() { return this.sheet.getPageNumberingStart(); }
/*    */ 
/*    */   
/*    */   public void input(String paramString) throws IOException {
/* 74 */     File file = new File(paramString);
/* 75 */     String str = file.getParent();
/*    */     
/* 77 */     if (str == null) {
/* 78 */       str = (getRootDirectory() == null) ? "." : getRootDirectory();
/*    */     }
/*    */     
/* 81 */     FileInputStream fileInputStream = new FileInputStream(file);
/* 82 */     Builder builder = Builder.getBuilder(2, fileInputStream);
/* 83 */     this.sheet = builder.read(str);
/* 84 */     fileInputStream.close();
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\ReportBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */