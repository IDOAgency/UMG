package inetsoft.report.beans;

import inetsoft.report.Margin;
import inetsoft.report.StyleSheet;
import inetsoft.report.io.Builder;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class ReportBase extends BaseBean {
  private StyleSheet sheet = StyleSheet.createStyleSheet();
  
  public StyleSheet getReport() { return this.sheet; }
  
  public void setMargin(Margin paramMargin) { this.sheet.setMargin(paramMargin); }
  
  public Margin getMargin() { return this.sheet.getMargin(); }
  
  public void setHeaderFromEdge(double paramDouble) { this.sheet.setHeaderFromEdge(paramDouble); }
  
  public double getHeaderFromEdge() { return this.sheet.getHeaderFromEdge(); }
  
  public void setFooterFromEdge(double paramDouble) { this.sheet.setFooterFromEdge(paramDouble); }
  
  public double getFooterFromEdge() { return this.sheet.getFooterFromEdge(); }
  
  public void setPageNumberingStart(int paramInt) { this.sheet.setPageNumberingStart(paramInt); }
  
  public int getPageNumberingStart() { return this.sheet.getPageNumberingStart(); }
  
  public void input(String paramString) throws IOException {
    File file = new File(paramString);
    String str = file.getParent();
    if (str == null)
      str = (getRootDirectory() == null) ? "." : getRootDirectory(); 
    FileInputStream fileInputStream = new FileInputStream(file);
    Builder builder = Builder.getBuilder(2, fileInputStream);
    this.sheet = builder.read(str);
    fileInputStream.close();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\ReportBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */