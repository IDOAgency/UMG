/*    */ package inetsoft.report.beans;
/*    */ 
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import java.net.URL;
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreviewButton
/*    */   extends BaseButton
/*    */ {
/*    */   public PreviewButton() {
/*    */     try {
/* 29 */       URL uRL = getClass().getResource("/inetsoft/report/images/preview.gif");
/*    */       
/* 31 */       setIcon(new ImageIcon(uRL));
/*    */     } catch (Exception exception) {
/* 33 */       exception.printStackTrace();
/* 34 */       setText(Catalog.getString("Preview"));
/*    */     } 
/*    */     
/* 37 */     setToolTipText(Catalog.getString("Print Preview"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public void process(StyleSheet paramStyleSheet) { BaseBean.preview(paramStyleSheet); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\PreviewButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */