package inetsoft.report.beans;

import inetsoft.report.locale.Catalog;
import inetsoft.widget.util.Tool;
import java.awt.BorderLayout;
import java.awt.FileDialog;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Vector;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PrompterBase extends JPanel {
  public static final int OK = 1;
  
  public static final int CANCEL = 2;
  
  public static final int ALL = 3;
  
  public static final int NONE = 0;
  
  public void show(String paramString) {
    JDialog jDialog = new JDialog();
    this.window = jDialog;
    jDialog.setTitle(paramString = Catalog.getString(paramString));
    jDialog.getContentPane().add(this, "Center");
    jDialog.setModal(true);
    jDialog.pack();
    jDialog.setVisible(true);
  }
  
  public void init(String paramString, boolean paramBoolean, int paramInt) {
    setLayout(new BorderLayout(5, 5));
    this.load = paramBoolean;
    this.mask = paramInt;
    this.dir = getProjectDirectory();
    String[] arrayOfString = getProjectFiles();
    Vector vector = new Vector();
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (isTemplate(arrayOfString[b]))
        vector.addElement(arrayOfString[b]); 
    } 
    this.files = new String[vector.size()];
    vector.copyInto(this.files);
    this.list = new JList(new AbstractListModel(this) {
          private final PrompterBase this$0;
          
          public int getSize() { return this.this$0.files.length; }
          
          public Object getElementAt(int param1Int) {
            String str = this.this$0.files[param1Int];
            return this.this$0.getRelativePath(str);
          }
        });
    JPanel jPanel1 = new JPanel();
    add(jPanel1, "South");
    if ((paramInt & true) != 0) {
      jPanel1.add(this.okB);
      if (paramBoolean) {
        this.okB.setText(Catalog.getString("Open"));
      } else {
        this.okB.setText(Catalog.getString("Save"));
      } 
      this.okB.addActionListener(this.okListener);
    } 
    if ((paramInt & 0x2) != 0) {
      jPanel1.add(this.cancelB);
      this.cancelB.addActionListener(this.cancelListener);
    } 
    this.input.addActionListener(this.okListener);
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout());
    jPanel2.setBorder(new TitledBorder(paramString));
    add(jPanel2, "Center");
    jPanel2.add(new JScrollPane(this.list), "Center");
    jPanel1 = new JPanel();
    jPanel1.add(this.input);
    jPanel1.add(this.browseB);
    jPanel2.add(jPanel1, "North");
    this.input.setEnabled(!paramBoolean);
    this.browseB.addActionListener(this.browseListener);
    this.list.addListSelectionListener(this.listListener);
    this.list.addMouseListener(new MouseAdapter(this) {
          private final PrompterBase this$0;
          
          public void mouseClicked(MouseEvent param1MouseEvent) {
            if (param1MouseEvent.getClickCount() == 2)
              this.this$0.okListener.actionPerformed(null); 
          }
        });
  }
  
  public File getFile() { return this.file; }
  
  public void setFile(File paramFile) { this.file = paramFile; }
  
  public void setFilename(String paramString) { this.input.setText(getRelativePath(paramString)); }
  
  public boolean isTemplate(String paramString) {
    try {
      File file1 = new File(getProjectDirectory(), paramString);
      if (file1.exists()) {
        FileInputStream fileInputStream = new FileInputStream(file1);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
        String str = bufferedReader.readLine();
        fileInputStream.close();
        if (str.trim().startsWith("<?xml"))
          return true; 
      } 
    } catch (Exception exception) {}
    return false;
  }
  
  public void dispose() {
    if (this.window != null) {
      this.window.dispose();
      this.window = null;
    } 
  }
  
  public String getRelativePath(String paramString) {
    if (paramString.startsWith(this.dir))
      paramString = paramString.substring(this.dir.length() + 1); 
    return paramString;
  }
  
  public void setSelection() {
    if (this.input.getText().trim().length() > 0) {
      File file1 = new File(this.input.getText());
      if (!file1.isAbsolute())
        file1 = new File(this.dir, file1.toString()); 
      setFile(file1);
    } 
  }
  
  public String getProjectDirectory() { return "."; }
  
  public String[] getProjectFiles() { return new String[0]; }
  
  ActionListener okListener = new ActionListener(this) {
      private final PrompterBase this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        if (this.this$0.input.getText().trim().length() > 0) {
          this.this$0.setSelection();
          this.this$0.dispose();
        } 
      }
    };
  
  ActionListener cancelListener = new ActionListener(this) {
      private final PrompterBase this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
    };
  
  ActionListener browseListener = new ActionListener(this) {
      private final PrompterBase this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        FileDialog fileDialog = new FileDialog(Tool.findFrame(this.this$0), Catalog.getString("Report Template"), this.this$0.load ? 0 : 1);
        fileDialog.setDirectory(this.this$0.dir);
        fileDialog.setVisible(true);
        if (fileDialog.getFile() != null) {
          String str = fileDialog.getDirectory() + File.separator + fileDialog.getFile();
          if (str.startsWith(this.this$0.dir)) {
            str = str.substring(this.this$0.dir.length() + 1);
            if (str.charAt(0) == File.separatorChar)
              str = str.substring(1); 
          } 
          this.this$0.input.setText(str);
        } 
      }
    };
  
  ListSelectionListener listListener = new ListSelectionListener(this) {
      private final PrompterBase this$0;
      
      public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
        Object object = this.this$0.list.getSelectedValue();
        if (object != null)
          this.this$0.input.setText(object.toString()); 
        if (this.this$0.mask == 0)
          this.this$0.setSelection(); 
      }
    };
  
  JList list;
  
  JTextField input = new JTextField(15);
  
  JButton okB = new JButton(Catalog.getString("OK"));
  
  JButton cancelB = new JButton(Catalog.getString("Cancel"));
  
  JButton browseB = new JButton(Catalog.getString("Browse"));
  
  String[] files = null;
  
  String dir = null;
  
  boolean load = true;
  
  File file = null;
  
  Window window = null;
  
  int mask = 3;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\PrompterBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */