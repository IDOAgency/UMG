/*     */ package inetsoft.report.beans;
/*     */ 
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.util.Tool;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.FileDialog;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Vector;
/*     */ import javax.swing.AbstractListModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.TitledBorder;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ 
/*     */ 
/*     */ public class PrompterBase
/*     */   extends JPanel
/*     */ {
/*     */   public static final int OK = 1;
/*     */   public static final int CANCEL = 2;
/*     */   public static final int ALL = 3;
/*     */   public static final int NONE = 0;
/*     */   
/*     */   public void show(String paramString) {
/*  38 */     JDialog jDialog = new JDialog();
/*  39 */     this.window = jDialog;
/*     */     
/*  41 */     jDialog.setTitle(paramString = Catalog.getString(paramString));
/*  42 */     jDialog.getContentPane().add(this, "Center");
/*  43 */     jDialog.setModal(true);
/*  44 */     jDialog.pack();
/*  45 */     jDialog.setVisible(true);
/*     */   }
/*     */   
/*     */   public void init(String paramString, boolean paramBoolean, int paramInt) {
/*  49 */     setLayout(new BorderLayout(5, 5));
/*     */     
/*  51 */     this.load = paramBoolean;
/*  52 */     this.mask = paramInt;
/*  53 */     this.dir = getProjectDirectory();
/*     */     
/*  55 */     String[] arrayOfString = getProjectFiles();
/*  56 */     Vector vector = new Vector();
/*  57 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  58 */       if (isTemplate(arrayOfString[b])) {
/*  59 */         vector.addElement(arrayOfString[b]);
/*     */       }
/*     */     } 
/*  62 */     this.files = new String[vector.size()];
/*  63 */     vector.copyInto(this.files);
/*     */     
/*  65 */     this.list = new JList(new AbstractListModel(this) {
/*  66 */           public int getSize() { return this.this$0.files.length; } private final PrompterBase this$0;
/*     */           public Object getElementAt(int param1Int) {
/*  68 */             String str = this.this$0.files[param1Int];
/*  69 */             return this.this$0.getRelativePath(str);
/*     */           }
/*     */         });
/*     */     
/*  73 */     JPanel jPanel1 = new JPanel();
/*  74 */     add(jPanel1, "South");
/*     */     
/*  76 */     if ((paramInt & true) != 0) {
/*  77 */       jPanel1.add(this.okB);
/*     */       
/*  79 */       if (paramBoolean) {
/*  80 */         this.okB.setText(Catalog.getString("Open"));
/*     */       } else {
/*     */         
/*  83 */         this.okB.setText(Catalog.getString("Save"));
/*     */       } 
/*     */       
/*  86 */       this.okB.addActionListener(this.okListener);
/*     */     } 
/*     */     
/*  89 */     if ((paramInt & 0x2) != 0) {
/*  90 */       jPanel1.add(this.cancelB);
/*  91 */       this.cancelB.addActionListener(this.cancelListener);
/*     */     } 
/*     */     
/*  94 */     this.input.addActionListener(this.okListener);
/*     */     
/*  96 */     JPanel jPanel2 = new JPanel();
/*  97 */     jPanel2.setLayout(new BorderLayout());
/*  98 */     jPanel2.setBorder(new TitledBorder(paramString));
/*  99 */     add(jPanel2, "Center");
/*     */     
/* 101 */     jPanel2.add(new JScrollPane(this.list), "Center");
/*     */     
/* 103 */     jPanel1 = new JPanel();
/* 104 */     jPanel1.add(this.input);
/* 105 */     jPanel1.add(this.browseB);
/* 106 */     jPanel2.add(jPanel1, "North");
/*     */     
/* 108 */     this.input.setEnabled(!paramBoolean);
/* 109 */     this.browseB.addActionListener(this.browseListener);
/* 110 */     this.list.addListSelectionListener(this.listListener);
/* 111 */     this.list.addMouseListener(new MouseAdapter(this) { private final PrompterBase this$0;
/*     */           public void mouseClicked(MouseEvent param1MouseEvent) {
/* 113 */             if (param1MouseEvent.getClickCount() == 2) {
/* 114 */               this.this$0.okListener.actionPerformed(null);
/*     */             }
/*     */           } }
/*     */       );
/*     */   }
/*     */ 
/*     */   
/* 121 */   public File getFile() { return this.file; }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void setFile(File paramFile) { this.file = paramFile; }
/*     */ 
/*     */ 
/*     */   
/* 129 */   public void setFilename(String paramString) { this.input.setText(getRelativePath(paramString)); }
/*     */ 
/*     */   
/*     */   public boolean isTemplate(String paramString) {
/*     */     try {
/* 134 */       File file1 = new File(getProjectDirectory(), paramString);
/* 135 */       if (file1.exists()) {
/* 136 */         FileInputStream fileInputStream = new FileInputStream(file1);
/* 137 */         BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
/*     */         
/* 139 */         String str = bufferedReader.readLine();
/* 140 */         fileInputStream.close();
/*     */         
/* 142 */         if (str.trim().startsWith("<?xml")) {
/* 143 */           return true;
/*     */         }
/*     */       } 
/* 146 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 149 */     return false;
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 153 */     if (this.window != null) {
/* 154 */       this.window.dispose();
/* 155 */       this.window = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getRelativePath(String paramString) {
/* 160 */     if (paramString.startsWith(this.dir)) {
/* 161 */       paramString = paramString.substring(this.dir.length() + 1);
/*     */     }
/*     */     
/* 164 */     return paramString;
/*     */   }
/*     */   
/*     */   public void setSelection() {
/* 168 */     if (this.input.getText().trim().length() > 0) {
/* 169 */       File file1 = new File(this.input.getText());
/* 170 */       if (!file1.isAbsolute()) {
/* 171 */         file1 = new File(this.dir, file1.toString());
/*     */       }
/*     */       
/* 174 */       setFile(file1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 179 */   public String getProjectDirectory() { return "."; }
/*     */ 
/*     */ 
/*     */   
/* 183 */   public String[] getProjectFiles() { return new String[0]; }
/*     */ 
/*     */   
/* 186 */   ActionListener okListener = new ActionListener(this) { private final PrompterBase this$0;
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 188 */         if (this.this$0.input.getText().trim().length() > 0) {
/* 189 */           this.this$0.setSelection();
/* 190 */           this.this$0.dispose();
/*     */         } 
/*     */       } }
/*     */   ;
/*     */   
/* 195 */   ActionListener cancelListener = new ActionListener(this) { private final PrompterBase this$0;
/*     */       
/* 197 */       public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); } }
/*     */   ;
/*     */ 
/*     */   
/* 201 */   ActionListener browseListener = new ActionListener(this) { private final PrompterBase this$0;
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 203 */         FileDialog fileDialog = new FileDialog(Tool.findFrame(this.this$0), Catalog.getString("Report Template"), this.this$0.load ? 0 : 1);
/*     */ 
/*     */         
/* 206 */         fileDialog.setDirectory(this.this$0.dir);
/* 207 */         fileDialog.setVisible(true);
/*     */         
/* 209 */         if (fileDialog.getFile() != null) {
/* 210 */           String str = fileDialog.getDirectory() + File.separator + fileDialog.getFile();
/* 211 */           if (str.startsWith(this.this$0.dir)) {
/* 212 */             str = str.substring(this.this$0.dir.length() + 1);
/* 213 */             if (str.charAt(0) == File.separatorChar) {
/* 214 */               str = str.substring(1);
/*     */             }
/*     */           } 
/*     */           
/* 218 */           this.this$0.input.setText(str);
/*     */         } 
/*     */       } }
/*     */   ;
/*     */   
/* 223 */   ListSelectionListener listListener = new ListSelectionListener(this) { private final PrompterBase this$0;
/*     */       public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
/* 225 */         Object object = this.this$0.list.getSelectedValue();
/* 226 */         if (object != null) {
/* 227 */           this.this$0.input.setText(object.toString());
/*     */         }
/*     */         
/* 230 */         if (this.this$0.mask == 0) {
/* 231 */           this.this$0.setSelection();
/*     */         }
/*     */       } }
/*     */   ;
/*     */   
/*     */   JList list;
/* 237 */   JTextField input = new JTextField(15);
/* 238 */   JButton okB = new JButton(Catalog.getString("OK"));
/* 239 */   JButton cancelB = new JButton(Catalog.getString("Cancel"));
/* 240 */   JButton browseB = new JButton(Catalog.getString("Browse"));
/*     */   
/* 242 */   String[] files = null;
/* 243 */   String dir = null;
/*     */   boolean load = true;
/* 245 */   File file = null;
/* 246 */   Window window = null;
/* 247 */   int mask = 3;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\PrompterBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */