package inetsoft.report.beans;

import java.beans.MethodDescriptor;

public class TemplateBaseInfo extends BaseBeanInfo {
  public TemplateBaseInfo() { this(TemplateBase.class); }
  
  public TemplateBaseInfo(Class paramClass) {
    super(paramClass);
    setImage("/inetsoft/report/beans/images/TemplateBean.gif");
    setImage32("/inetsoft/report/beans/images/TemplateBean32.gif");
  }
  
  public MethodDescriptor[] getMethodDescriptors() {
    MethodDescriptor[] arrayOfMethodDescriptor = super.getMethodDescriptors();
    try {
      MethodDescriptor[] arrayOfMethodDescriptor1 = new MethodDescriptor[arrayOfMethodDescriptor.length + 1];
      System.arraycopy(arrayOfMethodDescriptor, 0, arrayOfMethodDescriptor1, 0, arrayOfMethodDescriptor.length);
      int i = arrayOfMethodDescriptor.length;
      Class[] arrayOfClass = { String.class, Object.class };
      arrayOfMethodDescriptor1[i] = new MethodDescriptor(this.beanClass.getMethod("setElement", arrayOfClass));
      setMethodAttribute("setElement", arrayOfMethodDescriptor1[i]);
      return arrayOfMethodDescriptor1;
    } catch (Exception exception) {
      exception.printStackTrace();
      return arrayOfMethodDescriptor;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\TemplateBaseInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */