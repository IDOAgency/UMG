/*    */ package inetsoft.report.beans;
/*    */ 
/*    */ import java.beans.MethodDescriptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TemplateBaseInfo
/*    */   extends BaseBeanInfo
/*    */ {
/* 29 */   public TemplateBaseInfo() { this(TemplateBase.class); }
/*    */ 
/*    */   
/*    */   public TemplateBaseInfo(Class paramClass) {
/* 33 */     super(paramClass);
/* 34 */     setImage("/inetsoft/report/beans/images/TemplateBean.gif");
/* 35 */     setImage32("/inetsoft/report/beans/images/TemplateBean32.gif");
/*    */   }
/*    */   
/*    */   public MethodDescriptor[] getMethodDescriptors() {
/* 39 */     MethodDescriptor[] arrayOfMethodDescriptor = super.getMethodDescriptors();
/*    */     
/*    */     try {
/* 42 */       MethodDescriptor[] arrayOfMethodDescriptor1 = new MethodDescriptor[arrayOfMethodDescriptor.length + 1];
/* 43 */       System.arraycopy(arrayOfMethodDescriptor, 0, arrayOfMethodDescriptor1, 0, arrayOfMethodDescriptor.length);
/* 44 */       int i = arrayOfMethodDescriptor.length;
/*    */       
/* 46 */       Class[] arrayOfClass = { String.class, Object.class };
/* 47 */       arrayOfMethodDescriptor1[i] = new MethodDescriptor(this.beanClass.getMethod("setElement", arrayOfClass));
/*    */       
/* 49 */       setMethodAttribute("setElement", arrayOfMethodDescriptor1[i]);
/*    */       
/* 51 */       return arrayOfMethodDescriptor1;
/*    */     } catch (Exception exception) {
/* 53 */       exception.printStackTrace();
/*    */ 
/*    */       
/* 56 */       return arrayOfMethodDescriptor;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\TemplateBaseInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */