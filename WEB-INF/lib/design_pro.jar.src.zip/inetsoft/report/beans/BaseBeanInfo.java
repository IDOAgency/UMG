/*     */ package inetsoft.report.beans;
/*     */ 
/*     */ import inetsoft.beans.AutoBeanInfo;
/*     */ import inetsoft.beans.IntegerEditorSupport;
/*     */ import java.beans.MethodDescriptor;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseBeanInfo
/*     */   extends AutoBeanInfo
/*     */ {
/*     */   protected Class beanClass;
/*     */   private Hashtable attrids;
/*     */   private Hashtable attrmap;
/*     */   
/*     */   public BaseBeanInfo(Class paramClass) {
/*  31 */     super(paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     this.beanClass = null;
/* 100 */     this.attrids = new Hashtable();
/* 101 */     this.attrmap = new Hashtable();
/*     */     this.beanClass = paramClass;
/*     */     registerEditor("orientation", OrientationEditor.class);
/*     */   }
/*     */   
/*     */   public void addMethodAttribute(String paramString1, String paramString2, Object paramObject) {
/*     */     this.attrids.put(paramString1, paramString2);
/*     */     this.attrmap.put(paramString1, paramObject);
/*     */   }
/*     */   
/*     */   public MethodDescriptor[] getMethodDescriptors() {
/*     */     try {
/*     */       MethodDescriptor[] arrayOfMethodDescriptor = new MethodDescriptor[3];
/*     */       Class[] arrayOfClass = new Class[0];
/*     */       arrayOfMethodDescriptor[0] = new MethodDescriptor(this.beanClass.getMethod("print", arrayOfClass));
/*     */       setMethodAttribute("print", arrayOfMethodDescriptor[0]);
/*     */       arrayOfMethodDescriptor[1] = new MethodDescriptor(this.beanClass.getMethod("preview", arrayOfClass));
/*     */       setMethodAttribute("preview", arrayOfMethodDescriptor[1]);
/*     */       arrayOfMethodDescriptor[2] = new MethodDescriptor(this.beanClass.getMethod("export", arrayOfClass));
/*     */       setMethodAttribute("export", arrayOfMethodDescriptor[2]);
/*     */       return arrayOfMethodDescriptor;
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setMethodAttribute(String paramString, MethodDescriptor paramMethodDescriptor) {
/*     */     String str;
/*     */     if ((str = (String)this.attrids.get(paramString)) != null)
/*     */       paramMethodDescriptor.setValue(str, this.attrmap.get(paramString)); 
/*     */   }
/*     */   
/*     */   public static String escape(String paramString) {
/*     */     StringBuffer stringBuffer = new StringBuffer();
/*     */     for (byte b = 0; b < paramString.length(); b++) {
/*     */       switch (paramString.charAt(b)) {
/*     */         case '\\':
/*     */           stringBuffer.append("\\\\");
/*     */           break;
/*     */         default:
/*     */           if (paramString.charAt(b) > '') {
/*     */             stringBuffer.append("\\" + Integer.toString(paramString.charAt(b), 7));
/*     */             break;
/*     */           } 
/*     */           stringBuffer.append(paramString.charAt(b));
/*     */           break;
/*     */       } 
/*     */     } 
/*     */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public static class OrientationEditor extends IntegerEditorSupport {
/*     */     public OrientationEditor() { setValues(new String[] { "Portrait", "Landscape" }, new int[] { 1, 0 }); }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\BaseBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */