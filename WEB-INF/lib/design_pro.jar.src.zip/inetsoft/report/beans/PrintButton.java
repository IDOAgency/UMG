/*    */ package inetsoft.report.beans;
/*    */ 
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import java.net.URL;
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PrintButton
/*    */   extends BaseButton
/*    */ {
/*    */   public PrintButton() {
/*    */     try {
/* 29 */       URL uRL = getClass().getResource("/inetsoft/report/images/printer16.gif");
/*    */       
/* 31 */       setIcon(new ImageIcon(uRL));
/*    */     } catch (Exception exception) {
/* 33 */       exception.printStackTrace();
/* 34 */       setText(Catalog.getString("Print"));
/*    */     } 
/*    */     
/* 37 */     setToolTipText(Catalog.getString("Print Print"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void process(StyleSheet paramStyleSheet) {
/*    */     try {
/* 45 */       BaseBean.print(paramStyleSheet);
/*    */     } catch (Exception exception) {
/* 47 */       exception.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\PrintButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */