package inetsoft.report.beans;

import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;
import java.net.URL;
import javax.swing.ImageIcon;

public class PrintButton extends BaseButton {
  public PrintButton() {
    try {
      URL uRL = getClass().getResource("/inetsoft/report/images/printer16.gif");
      setIcon(new ImageIcon(uRL));
    } catch (Exception exception) {
      exception.printStackTrace();
      setText(Catalog.getString("Print"));
    } 
    setToolTipText(Catalog.getString("Print Print"));
  }
  
  public void process(StyleSheet paramStyleSheet) {
    try {
      BaseBean.print(paramStyleSheet);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\PrintButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */