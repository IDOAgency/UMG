/*     */ package inetsoft.report.beans;
/*     */ 
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.XStyleSheet;
/*     */ import inetsoft.report.design.Designer;
/*     */ import inetsoft.report.internal.PaperSize;
/*     */ import inetsoft.report.io.Builder;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateBase
/*     */   extends BaseBean
/*     */ {
/*     */   protected XStyleSheet sheet;
/*     */   private String fname;
/*     */   
/*     */   public StyleSheet getReport() {
/*  39 */     loadTemplate();
/*  40 */     return this.sheet;
/*     */   }
/*     */   
/*     */   public void setTemplate(String paramString) {
/*  44 */     this.fname = paramString;
/*  45 */     this.sheet = null;
/*     */   }
/*     */ 
/*     */   
/*  49 */   public String getTemplate() { return this.fname; }
/*     */ 
/*     */ 
/*     */   
/*  53 */   public void setResource(String paramString) { this.resource = paramString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getResource() {
/*  60 */     if (this.resource == null && this.fname != null) {
/*  61 */       int i = this.fname.lastIndexOf(File.separatorChar);
/*  62 */       return (i >= 0) ? this.fname.substring(i + 1) : this.fname;
/*     */     } 
/*     */     
/*  65 */     return this.resource;
/*     */   }
/*     */ 
/*     */   
/*  69 */   public void setElement(String paramString, Object paramObject) { this.sheet.setElement(paramString, paramObject); }
/*     */ 
/*     */   
/*     */   public void setElement(Object[][] paramArrayOfObject) {
/*  73 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/*  74 */       setElement((String)paramArrayOfObject[b][0], paramArrayOfObject[b][1]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void edit() {
/*  79 */     Designer designer = new Designer();
/*     */     
/*     */     try {
/*  82 */       File file = new File(this.fname);
/*  83 */       designer.open((file.isAbsolute() || getRootDirectory() == null) ? file : new File(getRootDirectory(), this.fname));
/*     */       
/*  85 */       designer.setTitle(Catalog.getString("Report Designer") + " - " + this.fname);
/*     */     } catch (Exception exception) {
/*  87 */       exception.printStackTrace();
/*  88 */       JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  93 */     designer.pack();
/*  94 */     designer.setVisible(true);
/*     */   }
/*     */   
/*     */   protected void loadTemplate() {
/*  98 */     if (this.sheet == null) {
/*     */       try {
/* 100 */         InputStream inputStream = null;
/* 101 */         String str1 = ".";
/*     */         
/*     */         try {
/* 104 */           if (this.fname != null) {
/* 105 */             File file = new File(this.fname);
/* 106 */             inputStream = new FileInputStream((file.isAbsolute() || getRootDirectory() == null) ? file : new File(getRootDirectory(), this.fname));
/*     */ 
/*     */             
/* 109 */             str1 = file.getParent();
/*     */           } 
/* 111 */         } catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */         
/* 115 */         if (inputStream == null && getResource() != null) {
/* 116 */           inputStream = getClass().getResourceAsStream(getResource());
/*     */         }
/*     */         
/* 119 */         if (inputStream == null) {
/* 120 */           throw new IOException("Template input does not exist.");
/*     */         }
/*     */         
/* 123 */         Builder builder = Builder.getBuilder(1, inputStream);
/* 124 */         this.sheet = (XStyleSheet)builder.read(str1);
/* 125 */         inputStream.close();
/*     */         
/* 127 */         String str2 = this.sheet.getProperty("Orientation");
/* 128 */         setOrientation(PaperSize.getOrientation(str2));
/*     */       } catch (Exception exception) {
/* 130 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getElementType(String paramString) {
/* 139 */     ReportElement reportElement = this.sheet.getElement(paramString);
/* 140 */     return (reportElement != null) ? reportElement.getType() : "Unknown";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 145 */   private String resource = null;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\TemplateBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */