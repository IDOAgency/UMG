package inetsoft.report.beans;

import inetsoft.report.ReportElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.XStyleSheet;
import inetsoft.report.design.Designer;
import inetsoft.report.internal.PaperSize;
import inetsoft.report.io.Builder;
import inetsoft.report.locale.Catalog;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.swing.JOptionPane;

public class TemplateBase extends BaseBean {
  protected XStyleSheet sheet;
  
  private String fname;
  
  public StyleSheet getReport() {
    loadTemplate();
    return this.sheet;
  }
  
  public void setTemplate(String paramString) {
    this.fname = paramString;
    this.sheet = null;
  }
  
  public String getTemplate() { return this.fname; }
  
  public void setResource(String paramString) { this.resource = paramString; }
  
  public String getResource() {
    if (this.resource == null && this.fname != null) {
      int i = this.fname.lastIndexOf(File.separatorChar);
      return (i >= 0) ? this.fname.substring(i + 1) : this.fname;
    } 
    return this.resource;
  }
  
  public void setElement(String paramString, Object paramObject) { this.sheet.setElement(paramString, paramObject); }
  
  public void setElement(Object[][] paramArrayOfObject) {
    for (byte b = 0; b < paramArrayOfObject.length; b++)
      setElement((String)paramArrayOfObject[b][0], paramArrayOfObject[b][1]); 
  }
  
  public void edit() {
    Designer designer = new Designer();
    try {
      File file = new File(this.fname);
      designer.open((file.isAbsolute() || getRootDirectory() == null) ? file : new File(getRootDirectory(), this.fname));
      designer.setTitle(Catalog.getString("Report Designer") + " - " + this.fname);
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
    } 
    designer.pack();
    designer.setVisible(true);
  }
  
  protected void loadTemplate() {
    if (this.sheet == null)
      try {
        InputStream inputStream = null;
        String str1 = ".";
        try {
          if (this.fname != null) {
            File file = new File(this.fname);
            inputStream = new FileInputStream((file.isAbsolute() || getRootDirectory() == null) ? file : new File(getRootDirectory(), this.fname));
            str1 = file.getParent();
          } 
        } catch (IOException iOException) {}
        if (inputStream == null && getResource() != null)
          inputStream = getClass().getResourceAsStream(getResource()); 
        if (inputStream == null)
          throw new IOException("Template input does not exist."); 
        Builder builder = Builder.getBuilder(1, inputStream);
        this.sheet = (XStyleSheet)builder.read(str1);
        inputStream.close();
        String str2 = this.sheet.getProperty("Orientation");
        setOrientation(PaperSize.getOrientation(str2));
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
  }
  
  protected String getElementType(String paramString) {
    ReportElement reportElement = this.sheet.getElement(paramString);
    return (reportElement != null) ? reportElement.getType() : "Unknown";
  }
  
  private String resource = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\TemplateBase.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */