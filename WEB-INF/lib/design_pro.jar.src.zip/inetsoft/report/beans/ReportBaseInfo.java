/*     */ package inetsoft.report.beans;
/*     */ 
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.internal.j2d.NumField;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.TextListener;
/*     */ import java.beans.MethodDescriptor;
/*     */ import java.beans.PropertyEditorSupport;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReportBaseInfo
/*     */   extends BaseBeanInfo
/*     */ {
/*     */   public ReportBaseInfo() {
/*  31 */     this(ReportBase.class);
/*     */     
/*  33 */     registerEditor("margin", MarginEditor.class);
/*     */   }
/*     */   
/*     */   public ReportBaseInfo(Class paramClass) {
/*  37 */     super(paramClass);
/*  38 */     setImage("/inetsoft/report/beans/images/ReportBean.gif");
/*  39 */     setImage32("/inetsoft/report/beans/images/ReportBean32.gif");
/*  40 */     registerEditor("margin", MarginEditor.class);
/*     */   }
/*     */   
/*     */   public MethodDescriptor[] getMethodDescriptors() {
/*  44 */     MethodDescriptor[] arrayOfMethodDescriptor = super.getMethodDescriptors();
/*     */     
/*     */     try {
/*  47 */       MethodDescriptor[] arrayOfMethodDescriptor1 = new MethodDescriptor[arrayOfMethodDescriptor.length + 1];
/*  48 */       System.arraycopy(arrayOfMethodDescriptor, 0, arrayOfMethodDescriptor1, 0, arrayOfMethodDescriptor.length);
/*  49 */       int i = arrayOfMethodDescriptor.length;
/*     */       
/*  51 */       Class[] arrayOfClass = { String.class };
/*  52 */       arrayOfMethodDescriptor1[i] = new MethodDescriptor(this.beanClass.getMethod("input", arrayOfClass));
/*     */       
/*  54 */       setMethodAttribute("input", arrayOfMethodDescriptor1[i]);
/*     */       
/*  56 */       return arrayOfMethodDescriptor1;
/*     */     } catch (Exception exception) {
/*  58 */       exception.printStackTrace();
/*     */ 
/*     */       
/*  61 */       return arrayOfMethodDescriptor;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class MarginEditor extends PropertyEditorSupport {
/*  66 */     public boolean isPaintable() { return true; }
/*     */ 
/*     */     
/*     */     public void paintValue(Graphics param1Graphics, Rectangle param1Rectangle) {
/*  70 */       Margin margin = (Margin)getValue();
/*     */       
/*  72 */       if (margin != null) {
/*  73 */         Graphics graphics = param1Graphics.create(param1Rectangle.x, param1Rectangle.y, param1Rectangle.width, param1Rectangle.height);
/*  74 */         FontMetrics fontMetrics = graphics.getFontMetrics();
/*  75 */         String str = margin.top + "," + margin.left + "," + margin.bottom + "," + margin.right;
/*     */         
/*  77 */         graphics.drawString(str, 1, param1Rectangle.height / 2 + fontMetrics.getMaxDescent());
/*  78 */         graphics.dispose();
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getJavaInitializationString() {
/*  83 */       Margin margin = (Margin)getValue();
/*  84 */       return (margin == null) ? "null" : ("new inetsoft.report.Margin(" + margin.top + "," + margin.left + "," + margin.bottom + "," + margin.right + ")");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     public boolean supportsCustomEditor() { return true; }
/*     */ 
/*     */ 
/*     */     
/*  94 */     public Component getCustomEditor() { return new Editor(this); }
/*     */     
/*     */     class Editor
/*     */       extends JPanel {
/*     */       public Editor(ReportBaseInfo.MarginEditor this$0) {
/*  99 */         this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 181 */         this.listener = new ReportBaseInfo$1(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 192 */         this.jLabel1 = new JLabel();
/* 193 */         this.topTF = new NumField(5, false);
/* 194 */         this.jLabel2 = new JLabel();
/* 195 */         this.leftTF = new NumField(5, false);
/* 196 */         this.jLabel3 = new JLabel();
/* 197 */         this.rightTF = new NumField(5, false);
/* 198 */         this.jLabel4 = new JLabel();
/* 199 */         this.bottomTF = new NumField(5, false);
/* 200 */         this.jPanel1 = new JPanel();
/* 201 */         this.jLabel5 = new JLabel();
/*     */         setLayout(new GridBagLayout());
/*     */         this.jLabel1.setText(Catalog.getString("Top") + ":");
/*     */         this.jLabel2.setText(Catalog.getString("Left") + ":");
/*     */         this.jLabel3.setText(Catalog.getString("Right:"));
/*     */         this.jLabel4.setText(Catalog.getString("Bottom:"));
/*     */         this.jPanel1.setPreferredSize(new Dimension(50, 80));
/*     */         this.jLabel5.setFont(new Font("Dialog", 1, 12));
/*     */         this.jLabel5.setText(Catalog.getString("Enter margin in inches") + ":");
/*     */         GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 3;
/*     */         gridBagConstraints.gridy = 1;
/*     */         add(this.topTF, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 4;
/*     */         gridBagConstraints.gridy = 3;
/*     */         gridBagConstraints.anchor = 13;
/*     */         add(this.jLabel3, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 5;
/*     */         gridBagConstraints.gridy = 3;
/*     */         gridBagConstraints.insets = new Insets(0, 0, 0, 10);
/*     */         add(this.rightTF, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 2;
/*     */         gridBagConstraints.gridy = 1;
/*     */         gridBagConstraints.anchor = 13;
/*     */         add(this.jLabel1, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 3;
/*     */         gridBagConstraints.gridy = 4;
/*     */         add(this.bottomTF, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 2;
/*     */         gridBagConstraints.gridy = 4;
/*     */         gridBagConstraints.anchor = 13;
/*     */         add(this.jLabel4, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 1;
/*     */         gridBagConstraints.gridy = 3;
/*     */         add(this.leftTF, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 0;
/*     */         gridBagConstraints.gridy = 3;
/*     */         gridBagConstraints.insets = new Insets(0, 10, 0, 0);
/*     */         gridBagConstraints.anchor = 13;
/*     */         add(this.jLabel2, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 2;
/*     */         gridBagConstraints.gridy = 3;
/*     */         add(this.jPanel1, gridBagConstraints);
/*     */         gridBagConstraints = new GridBagConstraints();
/*     */         gridBagConstraints.gridx = 0;
/*     */         gridBagConstraints.gridy = 0;
/*     */         gridBagConstraints.gridwidth = 3;
/*     */         gridBagConstraints.insets = new Insets(0, 0, 10, 0);
/*     */         add(this.jLabel5, gridBagConstraints);
/*     */         Margin margin = (Margin)this$0.getValue();
/*     */         this.topTF.setValue(margin.top);
/*     */         this.leftTF.setValue(margin.left);
/*     */         this.bottomTF.setValue(margin.bottom);
/*     */         this.rightTF.setValue(margin.right);
/*     */         this.topTF.addTextListener(this.listener);
/*     */         this.leftTF.addTextListener(this.listener);
/*     */         this.bottomTF.addTextListener(this.listener);
/*     */         this.rightTF.addTextListener(this.listener);
/*     */       }
/*     */       
/*     */       TextListener listener;
/*     */       JLabel jLabel1;
/*     */       NumField topTF;
/*     */       JLabel jLabel2;
/*     */       NumField leftTF;
/*     */       JLabel jLabel3;
/*     */       NumField rightTF;
/*     */       JLabel jLabel4;
/*     */       NumField bottomTF;
/*     */       JPanel jPanel1;
/*     */       JLabel jLabel5;
/*     */       private final ReportBaseInfo.MarginEditor this$0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\ReportBaseInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */