package inetsoft.report.beans;

import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;
import java.net.URL;
import javax.swing.ImageIcon;

public class ExportButton extends BaseButton {
  public ExportButton() {
    try {
      URL uRL = getClass().getResource("/inetsoft/report/images/export.gif");
      setIcon(new ImageIcon(uRL));
    } catch (Exception exception) {
      exception.printStackTrace();
      setText(Catalog.getString("Export"));
    } 
    setToolTipText(Catalog.getString("Export Report"));
  }
  
  public void process(StyleSheet paramStyleSheet) { BaseBean.export(paramStyleSheet); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\ExportButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */