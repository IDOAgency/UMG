package inetsoft.report.beans;

import inetsoft.report.Common;
import inetsoft.report.PSPrinter;
import inetsoft.report.PreviewView;
import inetsoft.report.Previewer;
import inetsoft.report.Size;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.PaperSize;
import inetsoft.report.io.Builder;
import inetsoft.report.locale.Catalog;
import java.awt.FileDialog;
import java.io.FileOutputStream;
import java.io.Serializable;
import java.lang.reflect.Method;

public abstract class BaseBean implements Serializable {
  public void setOrientation(int paramInt) { this.orient = paramInt; }
  
  public int getOrientation() { return this.orient; }
  
  public void print() {
    StyleSheet styleSheet = getReport();
    if (styleSheet == null)
      return; 
    styleSheet.setProperty("Orientation", (this.orient == 1) ? "Portrait" : "Landscape");
    try {
      print(styleSheet);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static void print(StyleSheet paramStyleSheet) throws Exception { Common.print(paramStyleSheet); }
  
  public void preview() {
    StyleSheet styleSheet = getReport();
    if (styleSheet == null)
      return; 
    styleSheet.setProperty("Orientation", (this.orient == 1) ? "Portrait" : "Landscape");
    preview(styleSheet);
  }
  
  public static void preview(StyleSheet paramStyleSheet) throws Exception {
    PreviewView previewView = Previewer.createPreviewer();
    String str = paramStyleSheet.getProperty("Orientation");
    if (PaperSize.getOrientation(str) == 0) {
      previewView.setOrientation(0);
      double d1 = previewView.getPageWidth();
      double d2 = previewView.getPageHeight();
      previewView.setPageWidth(d2);
      previewView.setPageHeight(d1);
    } 
    previewView.print(paramStyleSheet);
    previewView.pack();
    previewView.setVisible(true);
  }
  
  public void export() {
    StyleSheet styleSheet = getReport();
    if (styleSheet == null)
      return; 
    styleSheet.setProperty("Orientation", (this.orient == 1) ? "Portrait" : "Landscape");
    export(styleSheet);
  }
  
  public static void export(StyleSheet paramStyleSheet) throws Exception {
    FileDialog fileDialog = new FileDialog(Common.getInvisibleFrame(), Catalog.getString("Save Report"), 1);
    fileDialog.setVisible(true);
    String str = paramStyleSheet.getProperty("Orientation");
    boolean bool = (PaperSize.getOrientation(str) == 0) ? 1 : 0;
    if (fileDialog.getFile() != null)
      try {
        String str1 = fileDialog.getDirectory() + fileDialog.getFile();
        FileOutputStream fileOutputStream = new FileOutputStream(str1);
        str1 = str1.toLowerCase();
        if (str1.endsWith(".pdf")) {
          try {
            Class clazz = Class.forName("inetsoft.report.pdf.PDF3Generator");
            Class[] arrayOfClass = { java.io.OutputStream.class };
            Method method = clazz.getMethod("getPDFGenerator", arrayOfClass);
            Object object = method.invoke(null, new Object[] { fileOutputStream });
            method = clazz.getMethod("generate", new Class[] { StyleSheet.class });
            if (bool) {
              Method method1 = clazz.getMethod("getPageSize", new Class[0]);
              Size size = (Size)method1.invoke(object, new Object[0]);
              method1 = clazz.getMethod("setPageSize", new Class[] { Size.class });
              method1.invoke(object, new Object[] { size.rotate() });
            } 
            method.invoke(object, new Object[] { paramStyleSheet });
          } catch (Exception exception) {
            exception.printStackTrace();
            System.err.println("PDF supporting file is missing");
          } 
        } else if (str1.endsWith(".ps")) {
          PSPrinter pSPrinter = new PSPrinter(fileOutputStream);
          if (bool)
            pSPrinter.setPageSize(pSPrinter.getPageSize().rotate()); 
          pSPrinter.setOrientation(bool ? 0 : 1);
          paramStyleSheet.print(pSPrinter.getPrintJob());
          pSPrinter.close();
        } else {
          Builder builder = null;
          if (str1.endsWith(".rtf")) {
            builder = Builder.getBuilder(4, fileOutputStream);
          } else if (str1.endsWith(".csv")) {
            builder = Builder.getBuilder(3, fileOutputStream);
          } else {
            builder = Builder.getBuilder(5, fileOutputStream, fileDialog.getDirectory());
          } 
          builder.write(paramStyleSheet);
          fileOutputStream.close();
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
      }  
  }
  
  public void setRootDirectory(String paramString) { this.rootdir = paramString; }
  
  protected String getRootDirectory() { return this.rootdir; }
  
  int orient = 1;
  
  private String rootdir = null;
  
  public abstract StyleSheet getReport();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\BaseBean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */