/*     */ package inetsoft.report.beans;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.PSPrinter;
/*     */ import inetsoft.report.PreviewView;
/*     */ import inetsoft.report.Previewer;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.PaperSize;
/*     */ import inetsoft.report.io.Builder;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.FileDialog;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseBean
/*     */   implements Serializable
/*     */ {
/*  34 */   public void setOrientation(int paramInt) { this.orient = paramInt; }
/*     */ 
/*     */ 
/*     */   
/*  38 */   public int getOrientation() { return this.orient; }
/*     */ 
/*     */   
/*     */   public void print() {
/*  42 */     StyleSheet styleSheet = getReport();
/*  43 */     if (styleSheet == null) {
/*     */       return;
/*     */     }
/*     */     
/*  47 */     styleSheet.setProperty("Orientation", (this.orient == 1) ? "Portrait" : "Landscape");
/*     */     
/*     */     try {
/*  50 */       print(styleSheet);
/*     */     } catch (Exception exception) {
/*  52 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  57 */   public static void print(StyleSheet paramStyleSheet) throws Exception { Common.print(paramStyleSheet); }
/*     */ 
/*     */   
/*     */   public void preview() {
/*  61 */     StyleSheet styleSheet = getReport();
/*  62 */     if (styleSheet == null) {
/*     */       return;
/*     */     }
/*     */     
/*  66 */     styleSheet.setProperty("Orientation", (this.orient == 1) ? "Portrait" : "Landscape");
/*     */     
/*  68 */     preview(styleSheet);
/*     */   }
/*     */   
/*     */   public static void preview(StyleSheet paramStyleSheet) throws Exception {
/*  72 */     PreviewView previewView = Previewer.createPreviewer();
/*     */     
/*  74 */     String str = paramStyleSheet.getProperty("Orientation");
/*  75 */     if (PaperSize.getOrientation(str) == 0) {
/*  76 */       previewView.setOrientation(0);
/*  77 */       double d1 = previewView.getPageWidth();
/*  78 */       double d2 = previewView.getPageHeight();
/*  79 */       previewView.setPageWidth(d2);
/*  80 */       previewView.setPageHeight(d1);
/*     */     } 
/*     */     
/*  83 */     previewView.print(paramStyleSheet);
/*  84 */     previewView.pack();
/*  85 */     previewView.setVisible(true);
/*     */   }
/*     */   
/*     */   public void export() {
/*  89 */     StyleSheet styleSheet = getReport();
/*  90 */     if (styleSheet == null) {
/*     */       return;
/*     */     }
/*     */     
/*  94 */     styleSheet.setProperty("Orientation", (this.orient == 1) ? "Portrait" : "Landscape");
/*     */     
/*  96 */     export(styleSheet);
/*     */   }
/*     */   
/*     */   public static void export(StyleSheet paramStyleSheet) throws Exception {
/* 100 */     FileDialog fileDialog = new FileDialog(Common.getInvisibleFrame(), Catalog.getString("Save Report"), 1);
/*     */ 
/*     */ 
/*     */     
/* 104 */     fileDialog.setVisible(true);
/*     */     
/* 106 */     String str = paramStyleSheet.getProperty("Orientation");
/* 107 */     boolean bool = (PaperSize.getOrientation(str) == 0) ? 1 : 0;
/*     */ 
/*     */     
/* 110 */     if (fileDialog.getFile() != null) {
/*     */       try {
/* 112 */         String str1 = fileDialog.getDirectory() + fileDialog.getFile();
/* 113 */         FileOutputStream fileOutputStream = new FileOutputStream(str1);
/* 114 */         str1 = str1.toLowerCase();
/*     */         
/* 116 */         if (str1.endsWith(".pdf")) {
/*     */           try {
/* 118 */             Class clazz = Class.forName("inetsoft.report.pdf.PDF3Generator");
/*     */             
/* 120 */             Class[] arrayOfClass = { java.io.OutputStream.class };
/* 121 */             Method method = clazz.getMethod("getPDFGenerator", arrayOfClass);
/* 122 */             Object object = method.invoke(null, new Object[] { fileOutputStream });
/* 123 */             method = clazz.getMethod("generate", new Class[] { StyleSheet.class });
/*     */ 
/*     */             
/* 126 */             if (bool) {
/* 127 */               Method method1 = clazz.getMethod("getPageSize", new Class[0]);
/* 128 */               Size size = (Size)method1.invoke(object, new Object[0]);
/* 129 */               method1 = clazz.getMethod("setPageSize", new Class[] { Size.class });
/* 130 */               method1.invoke(object, new Object[] { size.rotate() });
/*     */             } 
/*     */             
/* 133 */             method.invoke(object, new Object[] { paramStyleSheet });
/*     */           } catch (Exception exception) {
/*     */             
/* 136 */             exception.printStackTrace();
/* 137 */             System.err.println("PDF supporting file is missing");
/*     */           }
/*     */         
/* 140 */         } else if (str1.endsWith(".ps")) {
/* 141 */           PSPrinter pSPrinter = new PSPrinter(fileOutputStream);
/*     */           
/* 143 */           if (bool) {
/* 144 */             pSPrinter.setPageSize(pSPrinter.getPageSize().rotate());
/*     */           }
/*     */           
/* 147 */           pSPrinter.setOrientation(bool ? 0 : 1);
/*     */           
/* 149 */           paramStyleSheet.print(pSPrinter.getPrintJob());
/* 150 */           pSPrinter.close();
/*     */         } else {
/*     */           
/* 153 */           Builder builder = null;
/*     */           
/* 155 */           if (str1.endsWith(".rtf")) {
/* 156 */             builder = Builder.getBuilder(4, fileOutputStream);
/*     */           }
/* 158 */           else if (str1.endsWith(".csv")) {
/* 159 */             builder = Builder.getBuilder(3, fileOutputStream);
/*     */           } else {
/*     */             
/* 162 */             builder = Builder.getBuilder(5, fileOutputStream, fileDialog.getDirectory());
/*     */           } 
/*     */ 
/*     */           
/* 166 */           builder.write(paramStyleSheet);
/*     */           
/* 168 */           fileOutputStream.close();
/*     */         } 
/*     */       } catch (Exception exception) {
/* 171 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 177 */   public void setRootDirectory(String paramString) { this.rootdir = paramString; }
/*     */ 
/*     */ 
/*     */   
/* 181 */   protected String getRootDirectory() { return this.rootdir; }
/*     */ 
/*     */   
/* 184 */   int orient = 1;
/* 185 */   private String rootdir = null;
/*     */   
/*     */   public abstract StyleSheet getReport();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\BaseBean.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */