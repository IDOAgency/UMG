/*    */ package inetsoft.report.beans;
/*    */ 
/*    */ import inetsoft.report.StyleSheet;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.util.Locale;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.JButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseButton
/*    */   extends JButton
/*    */ {
/*    */   StyleSheet report;
/*    */   
/*    */   public Locale getLocale() {
/*    */     try {
/* 33 */       return super.getLocale();
/* 34 */     } catch (Exception exception) {
/*    */ 
/*    */       
/* 37 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void setText(String paramString) {}
/*    */   
/* 44 */   public String getText() { return ""; }
/*    */ 
/*    */ 
/*    */   
/* 48 */   public void setReport(StyleSheet paramStyleSheet) { this.report = paramStyleSheet; }
/*    */ 
/*    */   
/*    */   protected void fireActionPerformed(ActionEvent paramActionEvent) {
/* 52 */     super.fireActionPerformed(paramActionEvent);
/*    */     
/* 54 */     if (this.report != null) {
/* 55 */       process(this.report);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract void process(StyleSheet paramStyleSheet);
/*    */ 
/*    */   
/*    */   public Dimension getPreferredSize() {
/* 65 */     Icon icon = getIcon();
/* 66 */     if (icon == null) {
/* 67 */       return super.getPreferredSize();
/*    */     }
/*    */     
/* 70 */     Dimension dimension = new Dimension(icon.getIconWidth(), icon.getIconHeight());
/*    */     
/* 72 */     dimension.width += 4;
/* 73 */     dimension.height += 4;
/*    */     
/* 75 */     if (dimension.width % 2 == 0) dimension.width++; 
/* 76 */     if (dimension.height % 2 == 0) dimension.height++;
/*    */     
/* 78 */     return dimension;
/*    */   }
/*    */ 
/*    */   
/* 82 */   public Dimension getMaximumSize() { return getPreferredSize(); }
/*    */ 
/*    */ 
/*    */   
/* 86 */   public Dimension getMinimumSize() { return getPreferredSize(); }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\BaseButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */