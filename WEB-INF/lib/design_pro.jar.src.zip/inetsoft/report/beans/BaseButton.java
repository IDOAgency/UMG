package inetsoft.report.beans;

import inetsoft.report.StyleSheet;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.util.Locale;
import javax.swing.Icon;
import javax.swing.JButton;

public abstract class BaseButton extends JButton {
  StyleSheet report;
  
  public Locale getLocale() {
    try {
      return super.getLocale();
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public void setText(String paramString) {}
  
  public String getText() { return ""; }
  
  public void setReport(StyleSheet paramStyleSheet) { this.report = paramStyleSheet; }
  
  protected void fireActionPerformed(ActionEvent paramActionEvent) {
    super.fireActionPerformed(paramActionEvent);
    if (this.report != null)
      process(this.report); 
  }
  
  public abstract void process(StyleSheet paramStyleSheet);
  
  public Dimension getPreferredSize() {
    Icon icon = getIcon();
    if (icon == null)
      return super.getPreferredSize(); 
    Dimension dimension = new Dimension(icon.getIconWidth(), icon.getIconHeight());
    dimension.width += 4;
    dimension.height += 4;
    if (dimension.width % 2 == 0)
      dimension.width++; 
    if (dimension.height % 2 == 0)
      dimension.height++; 
    return dimension;
  }
  
  public Dimension getMaximumSize() { return getPreferredSize(); }
  
  public Dimension getMinimumSize() { return getPreferredSize(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\BaseButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */