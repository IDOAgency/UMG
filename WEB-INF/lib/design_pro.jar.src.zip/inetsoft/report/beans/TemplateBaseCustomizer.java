/*     */ package inetsoft.report.beans;
/*     */ 
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.util.Tool;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.beans.Customizer;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.Vector;
/*     */ import javax.swing.AbstractListModel;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.TitledBorder;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TemplateBaseCustomizer
/*     */   extends JPanel
/*     */   implements Customizer, ActionListener
/*     */ {
/*     */   TemplateBase bean;
/*     */   PropertyChangeSupport listener;
/*     */   Binding[] bindings;
/*     */   JPanel bindPane;
/*     */   JLabel nameL;
/*     */   JRadioButton editRB;
/*     */   JRadioButton bindRB;
/*     */   JButton custB;
/*     */   protected JTable table;
/*     */   
/*     */   public TemplateBaseCustomizer() {
/* 393 */     this.listener = null;
/* 394 */     this.bindings = null;
/*     */     
/* 396 */     this.bindPane = new JPanel();
/* 397 */     this.nameL = new JLabel();
/* 398 */     this.editRB = new JRadioButton(Catalog.getString("Edit Template"));
/* 399 */     this.bindRB = new JRadioButton(Catalog.getString("Edit Binding"));
/* 400 */     this.custB = new JButton(Catalog.getString("Customize") + "...");
/*     */     setLayout(new BorderLayout(15, 15));
/*     */     setBorder(new TitledBorder(Catalog.getString("Template Customizer")));
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setLayout(new BorderLayout(15, 15));
/*     */     jPanel.add(new JLabel(Catalog.getString("Template") + ":"));
/*     */     jPanel.add(this.nameL);
/*     */     add(jPanel, "North");
/*     */     jPanel = new JPanel();
/*     */     jPanel.setBorder(new TitledBorder(Catalog.getString("Options")));
/*     */     jPanel.setLayout(new GridLayout(2, 1, 15, 5));
/*     */     jPanel.add(this.editRB);
/*     */     jPanel.add(this.bindRB);
/*     */     add(jPanel, "Center");
/*     */     ButtonGroup buttonGroup = new ButtonGroup();
/*     */     buttonGroup.add(this.editRB);
/*     */     buttonGroup.add(this.bindRB);
/*     */     this.bindRB.setSelected(true);
/*     */     jPanel = new JPanel();
/*     */     jPanel.setLayout(new GridBagLayout());
/*     */     this.custB.addActionListener(this);
/*     */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*     */     gridBagConstraints.insets = new Insets(0, 5, 0, 20);
/*     */     jPanel.add(this.custB, gridBagConstraints);
/*     */     add(jPanel, "East");
/*     */     this.table = new JTable();
/*     */     JScrollPane jScrollPane = new JScrollPane(this.table);
/*     */     jScrollPane.setPreferredSize(new Dimension(600, 300));
/*     */     this.bindPane.setLayout(new BorderLayout());
/*     */     this.bindPane.setBorder(new TitledBorder(Catalog.getString("Report Elements Binding")));
/*     */     this.bindPane.add(jScrollPane, "Center");
/*     */     this.custB.requestFocus();
/*     */   }
/*     */   
/*     */   public void setObject(Object paramObject) {
/*     */     this.bean = (TemplateBase)paramObject;
/*     */     this.listener = new PropertyChangeSupport(this.bean);
/*     */     init();
/*     */   }
/*     */   
/*     */   public void init() {
/*     */     this.table.setModel(new ElemModel(this));
/*     */     this.table.setAutoResizeMode(0);
/*     */     this.table.createDefaultColumnsFromModel();
/*     */     TableColumnModel tableColumnModel = this.table.getColumnModel();
/*     */     tableColumnModel.getColumn(0).setPreferredWidth(120);
/*     */     tableColumnModel.getColumn(1).setPreferredWidth(50);
/*     */     tableColumnModel.getColumn(2).setPreferredWidth(50);
/*     */     tableColumnModel.getColumn(3).setPreferredWidth(360);
/*     */     tableColumnModel.getColumn(3).setCellEditor(new SourceEditor(this));
/*     */     boolean bool = (this.bean.getTemplate() != null);
/*     */     this.editRB.setEnabled(bool);
/*     */     this.bindRB.setEnabled(bool);
/*     */     this.custB.requestFocus();
/*     */   }
/*     */   
/*     */   public void setBindingSource(String paramString1, String paramString2) {
/*     */     for (byte b = 0; b < this.bindings.length; b++) {
/*     */       if ((this.bindings[b]).id.equals(paramString1)) {
/*     */         (this.bindings[b]).source = paramString2;
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addPropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) { this.listener.addPropertyChangeListener(paramPropertyChangeListener); }
/*     */   
/*     */   public void removePropertyChangeListener(PropertyChangeListener paramPropertyChangeListener) { this.listener.removePropertyChangeListener(paramPropertyChangeListener); }
/*     */   
/*     */   protected boolean isSupported(String paramString) { return true; }
/*     */   
/*     */   protected Object[] getSources(String paramString) { return new Object[0]; }
/*     */   
/*     */   protected void updateBinding(Binding[] paramArrayOfBinding) {}
/*     */   
/*     */   protected void setRootDirectory(String paramString) { this.bean.setRootDirectory(paramString); }
/*     */   
/*     */   public void actionPerformed(ActionEvent paramActionEvent) {
/*     */     if (this.editRB.isSelected()) {
/*     */       this.bean.edit();
/*     */     } else if (this.bindRB.isSelected()) {
/*     */       JDialog jDialog = createDialog();
/*     */       jDialog.setTitle(Catalog.getString("Elements Binding"));
/*     */       jDialog.getContentPane().add(this.bindPane, "Center");
/*     */       jDialog.addWindowListener(new WindowAdapter(this, jDialog) {
/*     */             private final JDialog val$win;
/*     */             private final TemplateBaseCustomizer this$0;
/*     */             
/*     */             public void windowClosing(WindowEvent param1WindowEvent) { this.val$win.dispose(); }
/*     */           });
/*     */       JPanel jPanel = new JPanel();
/*     */       JButton jButton = new JButton(Catalog.getString("OK"));
/*     */       jButton.addActionListener(new ActionListener(this, jDialog) {
/*     */             private final JDialog val$win;
/*     */             private final TemplateBaseCustomizer this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */               this.this$0.updateBinding(this.this$0.bindings);
/*     */               this.val$win.dispose();
/*     */             }
/*     */           });
/*     */       jPanel.add(jButton);
/*     */       jButton = new JButton(Catalog.getString("Cancel"));
/*     */       jButton.addActionListener(new ActionListener(this, jDialog) {
/*     */             private final JDialog val$win;
/*     */             private final TemplateBaseCustomizer this$0;
/*     */             
/*     */             public void actionPerformed(ActionEvent param1ActionEvent) { this.val$win.dispose(); }
/*     */           });
/*     */       jPanel.add(jButton);
/*     */       jDialog.getContentPane().add(jPanel, "South");
/*     */       jDialog.pack();
/*     */       jDialog.setVisible(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class Binding {
/*     */     public String id;
/*     */     public String area;
/*     */     public String type;
/*     */     public String source;
/*     */     
/*     */     public String toString() { return "[Binding: " + this.id + "," + this.area + "," + this.type + "," + this.source + "]"; }
/*     */   }
/*     */   
/*     */   protected JDialog createDialog() {
/*     */     try {
/*     */       Class clazz = Class.forName("javax.swing.JDialog");
/*     */       Constructor constructor = null;
/*     */       Object[] arrayOfObject = { null };
/*     */       try {
/*     */         constructor = clazz.getConstructor(new Class[] { java.awt.Dialog.class });
/*     */         arrayOfObject[0] = Tool.findWindow(this);
/*     */       } catch (Exception exception) {
/*     */         constructor = clazz.getConstructor(new Class[] { java.awt.Frame.class });
/*     */         arrayOfObject[0] = Tool.findFrame(this);
/*     */       } 
/*     */       return (JDialog)constructor.newInstance(arrayOfObject);
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   class ElemModel extends AbstractTableModel {
/*     */     private final TemplateBaseCustomizer this$0;
/*     */     
/*     */     public ElemModel(TemplateBaseCustomizer this$0) {
/*     */       this.this$0 = this$0;
/*     */       StyleSheet styleSheet = this$0.bean.getReport();
/*     */       if (styleSheet == null) {
/*     */         this$0.bindings = new TemplateBaseCustomizer.Binding[0];
/*     */         return;
/*     */       } 
/*     */       Vector[] arrayOfVector = { styleSheet.getElements(256), styleSheet.getElements(0), styleSheet.getElements(512) };
/*     */       String[] arrayOfString = { "Header", "Body", "Footer" };
/*     */       Vector vector = new Vector();
/*     */       for (byte b = 0; b < arrayOfVector.length; b++) {
/*     */         Vector vector1 = arrayOfVector[b];
/*     */         for (byte b1 = 0; b1 < vector1.size(); b1++) {
/*     */           ReportElement reportElement = (ReportElement)vector1.elementAt(b1);
/*     */           String str = reportElement.getType();
/*     */           if (this$0.isSupported(str)) {
/*     */             TemplateBaseCustomizer.Binding binding = new TemplateBaseCustomizer.Binding();
/*     */             binding.id = reportElement.getID();
/*     */             binding.area = arrayOfString[b];
/*     */             binding.type = str;
/*     */             vector.addElement(binding);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       this$0.bindings = new TemplateBaseCustomizer.Binding[vector.size()];
/*     */       vector.copyInto(this$0.bindings);
/*     */     }
/*     */     
/*     */     public int getRowCount() { return this.this$0.bindings.length; }
/*     */     
/*     */     public int getColumnCount() { return 4; }
/*     */     
/*     */     public Object getValueAt(int param1Int1, int param1Int2) {
/*     */       TemplateBaseCustomizer.Binding binding = this.this$0.bindings[param1Int1];
/*     */       switch (param1Int2) {
/*     */         case 0:
/*     */           return binding.id;
/*     */         case 1:
/*     */           return binding.area;
/*     */         case 2:
/*     */           return binding.type;
/*     */         case 3:
/*     */           return binding.source;
/*     */       } 
/*     */       return "";
/*     */     }
/*     */     
/*     */     public String getColumnName(int param1Int) {
/*     */       switch (param1Int) {
/*     */         case 0:
/*     */           return Catalog.getString("Element");
/*     */         case 1:
/*     */           return Catalog.getString("Area");
/*     */         case 2:
/*     */           return Catalog.getString("Type");
/*     */         case 3:
/*     */           return Catalog.getString("Source");
/*     */       } 
/*     */       return "";
/*     */     }
/*     */     
/*     */     public boolean isCellEditable(int param1Int1, int param1Int2) { return (param1Int2 == 3); }
/*     */   }
/*     */   
/*     */   public class SourceEditor extends DefaultCellEditor {
/*     */     Object current;
/*     */     Object[] sources;
/*     */     Object other;
/*     */     int row;
/*     */     JComboBox combo;
/*     */     Model model;
/*     */     private final TemplateBaseCustomizer this$0;
/*     */     
/*     */     public SourceEditor(TemplateBaseCustomizer this$0) {
/*     */       super(new JComboBox());
/*     */       this.this$0 = this$0;
/*     */       this.current = null;
/*     */       this.sources = new Object[0];
/*     */       this.other = "";
/*     */       this.row = 0;
/*     */       this.combo = (JComboBox)getComponent();
/*     */       this.combo.setLightWeightPopupEnabled(false);
/*     */       this.combo.setEditable(true);
/*     */       this.combo.setModel(this.model = new Model(this));
/*     */       addCellEditorListener(new TemplateBaseCustomizer$4(this));
/*     */     }
/*     */     
/*     */     public Component getTableCellEditorComponent(JTable param1JTable, Object param1Object, boolean param1Boolean, int param1Int1, int param1Int2) {
/*     */       this.row = param1Int1;
/*     */       this.sources = this.this$0.getSources((this.this$0.bindings[param1Int1]).type);
/*     */       this.current = null;
/*     */       this.combo.setModel(this.model = new Model(this));
/*     */       this.combo.setSelectedItem((this.this$0.bindings[param1Int1]).source);
/*     */       this.other = (this.this$0.bindings[param1Int1]).source;
/*     */       if (this.other != null) {
/*     */         if (((String)this.other).length() == 0)
/*     */           this.other = null; 
/*     */         for (byte b = 0; this.other != null && b < this.sources.length; b++) {
/*     */           if (this.sources[b].equals(this.other))
/*     */             this.other = null; 
/*     */         } 
/*     */       } 
/*     */       return super.getTableCellEditorComponent(param1JTable, param1Object, param1Boolean, param1Int1, param1Int2);
/*     */     }
/*     */     
/*     */     class Model extends AbstractListModel implements ComboBoxModel {
/*     */       static final String NONE = "(none)";
/*     */       private final TemplateBaseCustomizer.SourceEditor this$1;
/*     */       
/*     */       Model(TemplateBaseCustomizer.SourceEditor this$0) { this.this$1 = this$0; }
/*     */       
/*     */       public void setSelectedItem(Object param2Object) {
/*     */         this.this$1.current = (param2Object == "(none)") ? "" : param2Object;
/*     */         fireContentsChanged(this, -1, -1);
/*     */       }
/*     */       
/*     */       public Object getSelectedItem() { return this.this$1.current; }
/*     */       
/*     */       public int getSize() { return this.this$1.sources.length + ((this.this$1.other == null) ? 0 : 1) + 1; }
/*     */       
/*     */       public Object getElementAt(int param2Int) { return (param2Int == 0) ? "(none)" : ((param2Int - 1 < this.this$1.sources.length) ? this.this$1.sources[param2Int - 1] : this.this$1.other); }
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\beans\TemplateBaseCustomizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */