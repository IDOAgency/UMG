package inetsoft.report.design;

import inetsoft.report.locale.Catalog;
import javax.swing.JComboBox;

class AlignCombo extends JComboBox {
  public static final int HORIZONTAL = 1;
  
  public static final int VERTICAL = 2;
  
  public static final int ALL = 3;
  
  int direct;
  
  String[] halign_names;
  
  int[] halign_opts;
  
  String[] valign_names;
  
  int[] valign_opts;
  
  String[] align_names;
  
  int[] align_opts;
  
  public AlignCombo(int paramInt) {
    this.halign_names = new String[] { Catalog.getString("Left"), Catalog.getString("Center"), Catalog.getString("Right") };
    this.halign_opts = new int[] { 1, 2, 4 };
    this.valign_names = new String[] { Catalog.getString("Baseline"), Catalog.getString("Top"), Catalog.getString("Center"), Catalog.getString("Bottom") };
    this.valign_opts = new int[] { 64, 8, 16, 32 };
    this.align_names = new String[] { Catalog.getString("Fill"), Catalog.getString("Top"), Catalog.getString("Top-Left"), Catalog.getString("Left"), Catalog.getString("Bottom-Left"), Catalog.getString("Bottom"), Catalog.getString("Bottom-Right"), Catalog.getString("Right"), Catalog.getString("Top-Right"), Catalog.getString("Center") };
    this.align_opts = new int[] { 0, 8, 9, 1, 33, 32, 36, 4, 12, 18 };
    this.direct = paramInt;
    switch (paramInt) {
      case 1:
        this.align_names = this.halign_names;
        this.align_opts = this.halign_opts;
        break;
      case 2:
        this.align_names = this.valign_names;
        this.align_opts = this.valign_opts;
        break;
    } 
    for (byte b = 0; b < this.align_names.length; b++)
      addItem(this.align_names[b]); 
    setLightWeightPopupEnabled(false);
  }
  
  public AlignCombo(int paramInt1, int paramInt2) {
    this(paramInt1);
    selectOption(paramInt2);
  }
  
  public void selectOption(Integer paramInteger) { selectOption((paramInteger == null) ? 0 : paramInteger.intValue()); }
  
  public void selectOption(int paramInt) {
    for (byte b = 0; b < this.align_opts.length; b++) {
      if ((this.direct == 1 && (paramInt & this.align_opts[b] & 0x7) != 0) || (this.direct == 2 && (paramInt & this.align_opts[b] & 0x38) != 0) || paramInt == this.align_opts[b])
        setSelectedIndex(b); 
    } 
  }
  
  public int getSelectedOption() {
    int i = getSelectedIndex();
    return (i < 0) ? 0 : this.align_opts[i];
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\AlignCombo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */