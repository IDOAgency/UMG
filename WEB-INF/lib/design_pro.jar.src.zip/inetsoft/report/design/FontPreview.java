package inetsoft.report.design;

import inetsoft.report.Common;
import inetsoft.report.StyleFont;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

class FontPreview extends Component {
  Font font;
  
  public void setPreferredSize(Dimension paramDimension) { this.psize = paramDimension; }
  
  public Dimension getPreferredSize() { return this.psize; }
  
  public Dimension getMinimumSize() { return this.psize; }
  
  public void setDisplayFont(Font paramFont) {
    this.font = paramFont;
    repaint(100L);
  }
  
  public void paint(Graphics paramGraphics) {
    Dimension dimension = getSize();
    if (this.font == null) {
      this.font = paramGraphics.getFont();
    } else {
      paramGraphics.setFont(this.font);
    } 
    paramGraphics.setColor(Color.black);
    paramGraphics.drawRect(0, 0, dimension.width - 1, dimension.height - 1);
    String str = StyleFont.toString(this.font);
    FontMetrics fontMetrics = paramGraphics.getFontMetrics(this.font);
    float f1 = Common.stringWidth(str, this.font);
    float f2 = Common.getHeight(this.font, fontMetrics);
    Common.drawString(paramGraphics, str, (dimension.width - f1) / 2.0F, (dimension.height - f2) / 2.0F + fontMetrics.getAscent());
  }
  
  Dimension psize = new Dimension(150, 100);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FontPreview.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */