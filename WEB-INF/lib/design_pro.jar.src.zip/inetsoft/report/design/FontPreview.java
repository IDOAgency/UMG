/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.Common;
/*    */ import inetsoft.report.StyleFont;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Font;
/*    */ import java.awt.FontMetrics;
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FontPreview
/*    */   extends Component
/*    */ {
/*    */   Font font;
/*    */   
/* 38 */   public void setPreferredSize(Dimension paramDimension) { this.psize = paramDimension; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public Dimension getPreferredSize() { return this.psize; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public Dimension getMinimumSize() { return this.psize; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDisplayFont(Font paramFont) {
/* 59 */     this.font = paramFont;
/* 60 */     repaint(100L);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paint(Graphics paramGraphics) {
/* 67 */     Dimension dimension = getSize();
/*    */     
/* 69 */     if (this.font == null) {
/* 70 */       this.font = paramGraphics.getFont();
/*    */     } else {
/*    */       
/* 73 */       paramGraphics.setFont(this.font);
/*    */     } 
/*    */     
/* 76 */     paramGraphics.setColor(Color.black);
/* 77 */     paramGraphics.drawRect(0, 0, dimension.width - 1, dimension.height - 1);
/*    */     
/* 79 */     String str = StyleFont.toString(this.font);
/* 80 */     FontMetrics fontMetrics = paramGraphics.getFontMetrics(this.font);
/* 81 */     float f1 = Common.stringWidth(str, this.font);
/* 82 */     float f2 = Common.getHeight(this.font, fontMetrics);
/*    */     
/* 84 */     Common.drawString(paramGraphics, str, (dimension.width - f1) / 2.0F, (dimension.height - f2) / 2.0F + fontMetrics.getAscent());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 89 */   Dimension psize = new Dimension(150, 100);
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FontPreview.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */