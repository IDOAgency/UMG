/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.TabElement;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TabProperty
/*    */   extends TextProperty
/*    */ {
/*    */   TabPane pnl;
/*    */   
/*    */   public TabProperty(DesignView paramDesignView) {
/* 33 */     super(paramDesignView, TabElement.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     this.pnl = new TabPane(true);
/*    */     setTitle(Catalog.getString("Tab Properties"));
/*    */     this.folder.insertTab(Catalog.getString("Tab"), null, this.pnl, Catalog.getString("Tab"), 0);
/*    */   }
/*    */   
/*    */   public void setElement(ReportElement paramReportElement) {
/*    */     this.elem = (TabElement)paramReportElement;
/*    */     super.setElement(paramReportElement);
/*    */     this.pnl.setElement(paramReportElement);
/*    */   }
/*    */   
/*    */   public boolean populateElement() {
/*    */     if (!super.populateElement())
/*    */       return false; 
/*    */     this.pnl.populateElement();
/*    */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TabProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */