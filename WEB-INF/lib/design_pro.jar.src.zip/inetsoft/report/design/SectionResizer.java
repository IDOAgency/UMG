package inetsoft.report.design;

import inetsoft.report.Common;
import inetsoft.report.SectionBand;
import inetsoft.report.internal.SectionElementDef;
import inetsoft.report.internal.SectionPaintable;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

class SectionResizer {
  SectionElementDef elem;
  
  SectionPaintable paintable;
  
  SectionBand band;
  
  int[] ys;
  
  int oloc;
  
  Integer loc;
  
  boolean resized;
  
  boolean atResize;
  
  Cursor resizeCursor;
  
  Cursor defaultCursor;
  
  public SectionResizer(SectionPaintable paramSectionPaintable) {
    this.oloc = 0;
    this.loc = null;
    this.resized = false;
    this.atResize = false;
    this.resizeCursor = new Cursor(9);
    this.defaultCursor = new Cursor(0);
    this.paintable = paramSectionPaintable;
    this.elem = (SectionElementDef)paramSectionPaintable.getElement();
    int i = (paramSectionPaintable.getBounds()).y;
    this.ys = new int[paramSectionPaintable.getSectionBandCount()];
    for (byte b = 0; b < this.ys.length; b++) {
      i = (int)(i + paramSectionPaintable.getSectionBand(b).getHeight() * 72.0F);
      this.ys[b] = i;
    } 
  }
  
  public boolean isResized() { return this.resized; }
  
  public boolean isAtResizeLocation() { return this.atResize; }
  
  public boolean isResizing() { return (this.loc != null); }
  
  public void processMouseEvent(MouseEvent paramMouseEvent) {
    Component component = (Component)paramMouseEvent.getSource();
    if (paramMouseEvent.getID() == 501) {
      if (this.band != null) {
        this.oloc = paramMouseEvent.getY();
        this.loc = new Integer(this.oloc);
      } 
    } else if (paramMouseEvent.getID() == 506) {
      if (this.band != null)
        this.loc = new Integer(paramMouseEvent.getY()); 
    } else if (paramMouseEvent.getID() == 503) {
      this.band = null;
      for (byte b = 0; b < this.ys.length; b++) {
        if (Math.abs(this.ys[b] - paramMouseEvent.getY()) < 4) {
          this.band = this.paintable.getSectionBand(b);
          break;
        } 
        if (paramMouseEvent.getY() < this.ys[b])
          break; 
      } 
      if (this.band != null) {
        component.setCursor(this.resizeCursor);
        this.atResize = true;
      } else {
        component.setCursor(this.defaultCursor);
        this.atResize = false;
      } 
    } else if (paramMouseEvent.getID() == 502 && this.loc != null) {
      int i = this.loc.intValue() - this.oloc;
      this.band.setHeight(this.band.getHeight() + i / 72.0F);
      this.loc = null;
      this.band = null;
      this.resized = true;
    } 
  }
  
  public void paint(Graphics paramGraphics) {
    if (this.loc != null) {
      Rectangle rectangle = this.paintable.getBounds();
      paramGraphics.setColor(Color.black);
      Common.drawHLine(paramGraphics, this.loc.intValue(), rectangle.x, (rectangle.x + rectangle.width), 4113, 0, 0);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionResizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */