/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.FlowLayout;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JOptionPane;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SectionOptionDialog
/*    */   extends JDialog
/*    */ {
/*    */   SectionOptionPane pane;
/*    */   
/*    */   public static void show(ReportElement paramReportElement, DesignFrame paramDesignFrame) {
/* 32 */     SectionOptionDialog sectionOptionDialog = new SectionOptionDialog(paramReportElement, paramDesignFrame);
/* 33 */     sectionOptionDialog.pack();
/* 34 */     sectionOptionDialog.setVisible(true);
/*    */   }
/*    */   
/*    */   public SectionOptionDialog(ReportElement paramReportElement, DesignFrame paramDesignFrame) {
/* 38 */     this.pane = new SectionOptionPane(paramReportElement, paramDesignFrame);
/* 39 */     this.pane.setPreferredSize(new Dimension(250, 150));
/* 40 */     getContentPane().add(this.pane, "Center");
/*    */     
/* 42 */     JPanel jPanel = new JPanel();
/* 43 */     jPanel.setLayout(new FlowLayout(1, 15, 5));
/*    */     
/* 45 */     JButton jButton1 = new JButton(Catalog.getString("OK"));
/* 46 */     jPanel.add(jButton1);
/* 47 */     jButton1.addActionListener(new ActionListener(this) {
/*    */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*    */             try {
/* 50 */               this.this$0.pane.process();
/*    */             } catch (Exception exception) {
/* 52 */               JOptionPane.showMessageDialog(null, exception.toString());
/*    */             } 
/*    */             
/* 55 */             this.this$0.dispose();
/*    */           }
/*    */           private final SectionOptionDialog this$0;
/*    */         });
/* 59 */     JButton jButton2 = new JButton(Catalog.getString("Cancel"));
/* 60 */     jPanel.add(jButton2);
/* 61 */     jButton2.addActionListener(new ActionListener(this)
/*    */         {
/* 63 */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*    */           
/*    */           private final SectionOptionDialog this$0;
/*    */         });
/* 67 */     getContentPane().add(jPanel, "South");
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionOptionDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */