package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.locale.Catalog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

class SectionOptionDialog extends JDialog {
  SectionOptionPane pane;
  
  public static void show(ReportElement paramReportElement, DesignFrame paramDesignFrame) {
    SectionOptionDialog sectionOptionDialog = new SectionOptionDialog(paramReportElement, paramDesignFrame);
    sectionOptionDialog.pack();
    sectionOptionDialog.setVisible(true);
  }
  
  public SectionOptionDialog(ReportElement paramReportElement, DesignFrame paramDesignFrame) {
    this.pane = new SectionOptionPane(paramReportElement, paramDesignFrame);
    this.pane.setPreferredSize(new Dimension(250, 150));
    getContentPane().add(this.pane, "Center");
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(1, 15, 5));
    JButton jButton1 = new JButton(Catalog.getString("OK"));
    jPanel.add(jButton1);
    jButton1.addActionListener(new ActionListener(this) {
          private final SectionOptionDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            try {
              this.this$0.pane.process();
            } catch (Exception exception) {
              JOptionPane.showMessageDialog(null, exception.toString());
            } 
            this.this$0.dispose();
          }
        });
    JButton jButton2 = new JButton(Catalog.getString("Cancel"));
    jPanel.add(jButton2);
    jButton2.addActionListener(new ActionListener(this) {
          private final SectionOptionDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
        });
    getContentPane().add(jPanel, "South");
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionOptionDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */