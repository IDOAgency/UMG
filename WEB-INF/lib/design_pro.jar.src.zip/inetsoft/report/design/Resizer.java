/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.TextBoxElement;
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Resizer
/*     */ {
/*     */   static final int HW = 4;
/*     */   static final int NORTH = 1;
/*     */   static final int WEST = 2;
/*     */   static final int SOUTH = 4;
/*     */   static final int EAST = 8;
/*     */   public static final int NW = 3;
/*     */   public static final int W = 2;
/*     */   public static final int SW = 6;
/*     */   public static final int S = 4;
/*     */   public static final int SE = 12;
/*     */   public static final int E = 8;
/*     */   public static final int NE = 9;
/*     */   public static final int N = 1;
/*     */   public static final int MOVE = 256;
/*     */   int type;
/*     */   int resolution;
/*     */   int vUnit;
/*     */   int vMargin;
/*     */   Rectangle box;
/*     */   Rectangle bbox;
/*     */   Rectangle obox;
/*     */   Rectangle[] boxes;
/*     */   Rectangle[] bboxes;
/*     */   Rectangle[] runboxes;
/*     */   Insets insets;
/*     */   Point oloc;
/*     */   boolean dragged;
/*     */   boolean negative;
/*     */   
/*     */   public Resizer(ResizeBox paramResizeBox, Vector paramVector, int paramInt, Insets paramInsets) {
/* 474 */     this.vUnit = 0;
/* 475 */     this.vMargin = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 487 */     this.dragged = false;
/* 488 */     this.negative = false; this.type = paramResizeBox.type; this.box = paramResizeBox.bounds; this.bbox = paramResizeBox.bbox; this.resolution = paramInt; this.insets = paramInsets; this.obox = new Rectangle(this.box); this.boxes = new Rectangle[(paramVector != null && paramVector.size() > 0) ? (paramVector.size() - 1) : 0]; this.bboxes = new Rectangle[this.boxes.length]; this.runboxes = new Rectangle[this.boxes.length]; if (paramVector != null) for (byte b1 = 0, b2 = 0; b1 < paramVector.size(); b1++) { Rectangle rectangle = ((ResizeBox)paramVector.elementAt(b1)).bounds; if (rectangle != paramResizeBox.bounds) { if (b2 >= this.boxes.length) { this.boxes = new Rectangle[0]; break; }  this.boxes[b2] = rectangle; this.bboxes[b2] = ((ResizeBox)paramVector.elementAt(b1)).bbox; this.runboxes[b2] = new Rectangle(this.boxes[b2]); b2++; }  }  
/*     */   }
/* 490 */   public void setVUnit(ReportElement paramReportElement) { float f = Common.getHeight(paramReportElement.getFont(), null); f += paramReportElement.getSpacing(); this.vMargin = 0; if (paramReportElement instanceof TextBoxElement) { TextBoxElement textBoxElement = (TextBoxElement)paramReportElement; Insets insets1; if ((insets1 = textBoxElement.getMargin()) != null) this.vMargin += insets1.top + insets1.bottom;  if ((insets1 = textBoxElement.getPadding()) != null) this.vMargin += insets1.top + insets1.bottom;  Insets insets2 = textBoxElement.getBorders(); if (insets2 != null) { this.vMargin = (int)(this.vMargin + Common.getLineWidth(insets2.top) + Common.getLineWidth(insets2.bottom)); } else { int i = textBoxElement.getBorder(); this.vMargin += 2 * (int)Math.ceil(Common.getLineWidth(i)); }  }  this.vUnit = (int)f; } public static void setSnapToGrid(boolean paramBoolean) { snapGrid = paramBoolean; } public static boolean isSnapToGrid() { return snapGrid; } public void setAllowNegative(boolean paramBoolean) { this.negative = paramBoolean; } public boolean isLocationChanged() { return (this.box.x != this.obox.x || this.box.y != this.obox.y); } public boolean isSizeChanged() { return (this.box.width != this.obox.width || this.box.height != this.obox.height); } public boolean isStarted() { return this.dragged; } public Rectangle getNormalized() { int i = this.box.x, j = this.box.y, k = this.box.width, m = this.box.height; if (k < 0) { i += k; k = -k; }  if (m < 0) { j += m; m = -m; }  return new Rectangle(i, j, k, m); } public void paint(Graphics paramGraphics) { Color color = paramGraphics.getColor(); paramGraphics.setColor(Color.gray); Rectangle rectangle = getNormalized(); paramGraphics.drawRect(rectangle.x, rectangle.y, rectangle.width - 1, rectangle.height - 1); paramGraphics.setColor(color); } static Cursor nwCursor = new Cursor(6);
/*     */   public void processMouseEvent(MouseEvent paramMouseEvent) { int i = paramMouseEvent.getX() - this.insets.left; int j = paramMouseEvent.getY() - this.insets.top; Rectangle rectangle = new Rectangle(this.box); boolean bool = false; if (paramMouseEvent.getID() == 501) { this.oloc = new Point(i, j); this.obox = new Rectangle(this.box); this.dragged = false; } else if (paramMouseEvent.getID() == 506) { this.dragged = true; bool = true; if (this.type == 256) { this.box.x = this.obox.x + i - this.oloc.x; this.box.y = this.obox.y + j - this.oloc.y; } else { if ((this.type & true) != 0) { this.box.y = j; this.box.height = this.obox.y + this.obox.height - this.box.y; }  if ((this.type & 0x2) != 0) { this.box.x = i; this.box.width = this.obox.x + this.obox.width - this.box.x; }  if ((this.type & 0x4) != 0) this.box.height = j - this.obox.y;  if ((this.type & 0x8) != 0) this.box.width = i - this.obox.x;  if (!this.negative) { this.box.width = Math.max(1, this.box.width); this.box.height = Math.max(1, this.box.height); }  }  } else if (paramMouseEvent.getID() == 502 && snapGrid && this.dragged) { this.dragged = false; bool = true; if (this.type == 256) { this.box.x = snapToGrid(this.box.x); this.box.y = snapToGrid(this.box.y); } else { if ((this.type & true) != 0) { this.box.y = snapToGrid(this.box.y); } else if ((this.type & 0x4) != 0 && this.vUnit == 0) { this.box.height = snapToGrid(this.box.y + this.box.height) - this.box.y; if (!this.negative) this.box.height = Math.max(1, this.box.height);  }  if ((this.type & 0x2) != 0) { this.box.x = snapToGrid(this.box.x); } else if ((this.type & 0x8) != 0) { this.box.width = snapToGrid(this.box.x + this.box.width) - this.box.x; if (!this.negative) this.box.width = Math.max(1, this.box.width);  }  }  }  if (bool) { if ((paramMouseEvent.getID() == 502 || paramMouseEvent.getID() == 506) && (this.type & 0x4) != 0 && this.vUnit > 0) this.box.height = Math.max(1, this.box.height / this.vUnit) * this.vUnit + this.vMargin;  postProcess(rectangle, (paramMouseEvent.getID() == 502 || paramMouseEvent.getID() == 506)); }  } public void move(int paramInt1, int paramInt2) { Rectangle rectangle = new Rectangle(this.box); int i = this.type; this.type = 256; this.box.x += paramInt1; this.box.y += paramInt2; postProcess(rectangle, true); this.type = i; } private void postProcess(Rectangle paramRectangle, boolean paramBoolean) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield bbox : Ljava/awt/Rectangle;
/*     */     //   4: ifnull -> 23
/*     */     //   7: iload_2
/*     */     //   8: ifeq -> 23
/*     */     //   11: aload_0
/*     */     //   12: aload_0
/*     */     //   13: getfield box : Ljava/awt/Rectangle;
/*     */     //   16: aload_0
/*     */     //   17: getfield bbox : Ljava/awt/Rectangle;
/*     */     //   20: invokespecial checkBBox : (Ljava/awt/Rectangle;Ljava/awt/Rectangle;)V
/*     */     //   23: aload_0
/*     */     //   24: getfield type : I
/*     */     //   27: sipush #256
/*     */     //   30: if_icmpne -> 173
/*     */     //   33: aload_0
/*     */     //   34: getfield boxes : [Ljava/awt/Rectangle;
/*     */     //   37: ifnull -> 173
/*     */     //   40: aload_0
/*     */     //   41: getfield box : Ljava/awt/Rectangle;
/*     */     //   44: getfield x : I
/*     */     //   47: aload_1
/*     */     //   48: getfield x : I
/*     */     //   51: isub
/*     */     //   52: istore_3
/*     */     //   53: aload_0
/*     */     //   54: getfield box : Ljava/awt/Rectangle;
/*     */     //   57: getfield y : I
/*     */     //   60: aload_1
/*     */     //   61: getfield y : I
/*     */     //   64: isub
/*     */     //   65: istore #4
/*     */     //   67: iconst_0
/*     */     //   68: istore #5
/*     */     //   70: goto -> 163
/*     */     //   73: aload_0
/*     */     //   74: getfield boxes : [Ljava/awt/Rectangle;
/*     */     //   77: iload #5
/*     */     //   79: aaload
/*     */     //   80: aload_0
/*     */     //   81: getfield runboxes : [Ljava/awt/Rectangle;
/*     */     //   84: iload #5
/*     */     //   86: aaload
/*     */     //   87: dup
/*     */     //   88: getfield x : I
/*     */     //   91: iload_3
/*     */     //   92: iadd
/*     */     //   93: dup_x1
/*     */     //   94: putfield x : I
/*     */     //   97: putfield x : I
/*     */     //   100: aload_0
/*     */     //   101: getfield boxes : [Ljava/awt/Rectangle;
/*     */     //   104: iload #5
/*     */     //   106: aaload
/*     */     //   107: aload_0
/*     */     //   108: getfield runboxes : [Ljava/awt/Rectangle;
/*     */     //   111: iload #5
/*     */     //   113: aaload
/*     */     //   114: dup
/*     */     //   115: getfield y : I
/*     */     //   118: iload #4
/*     */     //   120: iadd
/*     */     //   121: dup_x1
/*     */     //   122: putfield y : I
/*     */     //   125: putfield y : I
/*     */     //   128: aload_0
/*     */     //   129: getfield bboxes : [Ljava/awt/Rectangle;
/*     */     //   132: iload #5
/*     */     //   134: aaload
/*     */     //   135: ifnull -> 160
/*     */     //   138: iload_2
/*     */     //   139: ifeq -> 160
/*     */     //   142: aload_0
/*     */     //   143: aload_0
/*     */     //   144: getfield boxes : [Ljava/awt/Rectangle;
/*     */     //   147: iload #5
/*     */     //   149: aaload
/*     */     //   150: aload_0
/*     */     //   151: getfield bboxes : [Ljava/awt/Rectangle;
/*     */     //   154: iload #5
/*     */     //   156: aaload
/*     */     //   157: invokespecial checkBBox : (Ljava/awt/Rectangle;Ljava/awt/Rectangle;)V
/*     */     //   160: iinc #5, 1
/*     */     //   163: iload #5
/*     */     //   165: aload_0
/*     */     //   166: getfield boxes : [Ljava/awt/Rectangle;
/*     */     //   169: arraylength
/*     */     //   170: if_icmplt -> 73
/*     */     //   173: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #318	-> 0
/*     */     //   #319	-> 11
/*     */     //   #323	-> 23
/*     */     //   #324	-> 40
/*     */     //   #325	-> 53
/*     */     //   #327	-> 67
/*     */     //   #328	-> 73
/*     */     //   #329	-> 100
/*     */     //   #331	-> 128
/*     */     //   #332	-> 142
/*     */     //   #327	-> 160
/* 491 */     //   #336	-> 173 } private void checkBBox(Rectangle paramRectangle1, Rectangle paramRectangle2) { if (this.type == 256) { paramRectangle1.x = Math.max(paramRectangle1.x, paramRectangle2.x); paramRectangle1.y = Math.max(paramRectangle1.y, paramRectangle2.y); paramRectangle1.x = Math.min(paramRectangle1.x + paramRectangle1.width, paramRectangle2.x + paramRectangle2.width) - paramRectangle1.width; paramRectangle1.y = Math.min(paramRectangle1.y + paramRectangle1.height, paramRectangle2.y + paramRectangle2.height) - paramRectangle1.height; } else { paramRectangle1.x = Math.max(paramRectangle1.x, paramRectangle2.x); paramRectangle1.y = Math.max(paramRectangle1.y, paramRectangle2.y); paramRectangle1.x = Math.min(paramRectangle1.x, paramRectangle2.x + paramRectangle2.width); paramRectangle1.y = Math.min(paramRectangle1.y, paramRectangle2.y + paramRectangle2.height); paramRectangle1.width = Math.min(paramRectangle2.x + paramRectangle2.width - paramRectangle1.x, paramRectangle1.width); paramRectangle1.height = Math.min(paramRectangle2.y + paramRectangle2.height - paramRectangle1.y, paramRectangle1.height); }  } public int snapToGrid(int paramInt) { return (int)(Math.round(paramInt / this.resolution / 8.0D) * this.resolution / 8.0D); } public int getType() { return this.type; } public static Cursor getCursor(int paramInt) { switch (paramInt) { case 3: return nwCursor;case 2: return wCursor;case 6: return swCursor;case 4: return sCursor;case 12: return seCursor;case 8: return eCursor;case 9: return neCursor;case 1: return nCursor;case 256: return moveCursor; }  return defaultCursor; } public static int getResizeType(Rectangle paramRectangle, int paramInt1, int paramInt2) { int i = (paramRectangle.width > 18) ? 4 : Math.max(1, paramRectangle.width / 4); int j = (paramRectangle.height > 18) ? 4 : Math.max(1, paramRectangle.height / 4); int k = paramRectangle.x + (paramRectangle.width - i) / 2; int m = paramRectangle.y + (paramRectangle.height - j) / 2; int n = paramRectangle.x + paramRectangle.width; int i1 = paramRectangle.y + paramRectangle.height; if (paramInt1 >= paramRectangle.x && paramInt1 <= paramRectangle.x + i) { if (paramInt2 >= paramRectangle.y && paramInt2 <= paramRectangle.y + j) return 3;  if (paramInt2 <= i1 && paramInt2 >= i1 - j) return 6;  return 2; }  if (paramInt1 <= n && paramInt1 >= n - i) { if (paramInt2 >= paramRectangle.y && paramInt2 <= paramRectangle.y + j) return 9;  if (paramInt2 <= i1 && paramInt2 >= i1 - j) return 12;  return 8; }  if (paramInt2 >= paramRectangle.y && paramInt2 <= paramRectangle.y + j) return 1;  if (paramInt2 <= i1 && paramInt2 >= i1 - j) return 4;  if (paramRectangle.contains(paramInt1, paramInt2)) return 256;  return -1; } static boolean snapGrid = false; static Cursor wCursor = new Cursor(10);
/* 492 */   static Cursor swCursor = new Cursor(4);
/* 493 */   static Cursor sCursor = new Cursor(9);
/* 494 */   static Cursor seCursor = new Cursor(5);
/* 495 */   static Cursor eCursor = new Cursor(11);
/* 496 */   static Cursor neCursor = new Cursor(7);
/* 497 */   static Cursor nCursor = new Cursor(8);
/* 498 */   static Cursor moveCursor = new Cursor(13);
/* 499 */   static Cursor defaultCursor = new Cursor(0);
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\Resizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */