package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.TabElement;
import inetsoft.report.internal.TabSupport;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListModel;

class TabPane extends JPanel {
  ActionListener setListener;
  
  TabSupport elem;
  
  NumField pos;
  
  JList stops;
  
  JButton setB;
  
  JButton clearB;
  
  JButton clearAllB;
  
  LineCombo line;
  
  JCheckBox rightCB;
  
  DefaultListModel model;
  
  public TabPane(boolean paramBoolean) {
    this.setListener = new ActionListener(this) {
        private final TabPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.pos.getText().length() == 0)
            return; 
          double d = Double.valueOf(this.this$0.pos.getText()).doubleValue();
          for (byte b = 0; b < this.this$0.model.getSize(); b++) {
            if (d < Double.valueOf(this.this$0.model.getElementAt(b).toString()).doubleValue()) {
              this.this$0.model.insertElementAt(this.this$0.pos.getText(), b);
              return;
            } 
          } 
          this.this$0.model.addElement(this.this$0.pos.getText());
          this.this$0.pos.setText("");
        }
      };
    this.pos = new NumField(10, false);
    this.stops = new JList();
    this.setB = new JButton(Catalog.getString("Set"));
    this.clearB = new JButton(Catalog.getString("Clear"));
    this.clearAllB = new JButton(Catalog.getString("Clear All"));
    this.line = new LineCombo(true);
    this.rightCB = new JCheckBox(Catalog.getString("Right Aligned"));
    this.model = new DefaultListModel();
    setLayout(new BorderLayout());
    Property2Panel property2Panel = new Property2Panel();
    JScrollPane jScrollPane = new JScrollPane(this.stops);
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new BorderLayout(5, 10));
    jPanel.add(this.clearB, "North");
    jPanel.add(this.clearAllB, "South");
    jScrollPane.setPreferredSize(new Dimension(100, 100));
    property2Panel.add(Catalog.getString("Tab Stops"), new Object[][] { { this.pos, this.setB }, { jScrollPane, jPanel } });
    if (paramBoolean) {
      property2Panel.add(Catalog.getString("Tab Style"), new Object[][] { { Catalog.getString("Fill") + ":", this.line, this.rightCB } });
    } else {
      property2Panel.add(Catalog.getString("Tab Style"), new Object[][] { { Catalog.getString("Fill") + ":", this.line } });
    } 
    add(property2Panel, "Center");
    this.clearAllB.addActionListener(new ActionListener(this) {
          private final TabPane this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.model.removeAllElements(); }
        });
    this.clearB.addActionListener(new ActionListener(this) {
          private final TabPane this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            int[] arrayOfInt = this.this$0.stops.getSelectedIndices();
            for (int i = arrayOfInt.length - 1; i >= 0; i--)
              this.this$0.model.removeElementAt(arrayOfInt[i]); 
          }
        });
    this.pos.addActionListener(this.setListener);
    this.setB.addActionListener(this.setListener);
  }
  
  public void setElement(ReportElement paramReportElement) {
    this.elem = (TabSupport)paramReportElement;
    this.model.removeAllElements();
    double[] arrayOfDouble = this.elem.getTabStops();
    for (byte b = 0; b < arrayOfDouble.length; b++)
      this.model.addElement(Double.toString(arrayOfDouble[b])); 
    this.stops.setModel(this.model);
    this.line.setSelectedLineStyle(this.elem.getFillStyle());
    if (paramReportElement instanceof TabElement)
      this.rightCB.setSelected(((TabElement)paramReportElement).isRightTab()); 
  }
  
  public void populateElement() {
    ListModel listModel = this.stops.getModel();
    double[] arrayOfDouble = new double[listModel.getSize()];
    for (byte b = 0; b < arrayOfDouble.length; b++)
      arrayOfDouble[b] = Double.valueOf((String)listModel.getElementAt(b)).doubleValue(); 
    this.elem.setTabStops(arrayOfDouble);
    this.elem.setFillStyle(this.line.getSelectedLineStyle());
    currStyle = this.elem.getFillStyle();
    if (this.elem instanceof TabElement)
      ((TabElement)this.elem).setRightTab(this.rightCB.isSelected()); 
  }
  
  public static int getCurrentStyle() { return currStyle; }
  
  static int currStyle = 0;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TabPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */