/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.CondPageBreakElement;
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.internal.j2d.NumField;
/*    */ import inetsoft.report.internal.j2d.Property2Panel;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CondPageBreakProperty
/*    */   extends PropertyDialog
/*    */ {
/*    */   CondPageBreakElement elem;
/*    */   NumField num;
/*    */   
/*    */   public CondPageBreakProperty(DesignView paramDesignView) {
/* 35 */     super(paramDesignView);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 72 */     this.num = new NumField(5, false);
/*    */     setTitle(Catalog.getString("Conditional Page Break Properties"));
/*    */     Property2Panel property2Panel = new Property2Panel();
/*    */     property2Panel.add(Catalog.getString("Condition"), new Object[][] { { Catalog.getString("Inches from bottom") + ":", this.num } });
/*    */     this.folder.addTab(Catalog.getString("Page Break"), null, property2Panel, Catalog.getString("Page Break"));
/*    */   }
/*    */   
/*    */   public void setElement(ReportElement paramReportElement) {
/*    */     this.elem = (CondPageBreakElement)paramReportElement;
/*    */     super.setElement(paramReportElement);
/*    */     this.num.setValue(this.elem.getCondHeight());
/*    */   }
/*    */   
/*    */   public boolean populateElement() {
/*    */     if (!super.populateElement())
/*    */       return false; 
/*    */     this.elem.setCondHeight(this.num.doubleValue());
/*    */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\CondPageBreakProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */