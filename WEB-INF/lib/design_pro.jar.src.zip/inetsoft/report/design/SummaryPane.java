package inetsoft.report.design;

import inetsoft.report.TableFilter;
import inetsoft.report.TableLens;
import inetsoft.report.internal.SummaryAttr;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.Grid2Layout;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

class SummaryPane extends JPanel {
  ListSelectionListener selListener;
  
  ListSelectionListener groupListener;
  
  ListSelectionListener sumListener;
  
  ActionListener leftGroupListener;
  
  ActionListener rightGroupListener;
  
  ActionListener leftSumListener;
  
  ActionListener rightSumListener;
  
  ItemListener sortedListener;
  
  ItemListener orderListener;
  
  ItemListener formulaListener;
  
  public SummaryPane(boolean paramBoolean) {
    this.selListener = new ListSelectionListener(this) {
        private final SummaryPane this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) { this.this$0.setEnabled(); }
      };
    this.groupListener = new ListSelectionListener(this) {
        private final SummaryPane this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
          String str = (String)this.this$0.groupLT.getSelectedValue();
          if (str != null)
            this.this$0.orderCB.setSelected((this.this$0.group.getOrder(str) != 2)); 
          this.this$0.setEnabled();
        }
      };
    this.sumListener = new ListSelectionListener(this) {
        private final SummaryPane this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
          String str = (String)this.this$0.sumLT.getSelectedValue();
          if (str != null) {
            String str1 = this.this$0.group.getFormula(str);
            this.this$0.sumCB.setSelectedItem((str1 == null) ? Catalog.getString("(none)") : str1);
          } 
          this.this$0.setEnabled();
        }
      };
    this.leftGroupListener = new ActionListener(this) {
        private final SummaryPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int[] arrayOfInt = this.this$0.groupLT.getSelectedIndices();
          for (int i = arrayOfInt.length - 1; i >= 0; i--) {
            this.this$0.colMD.addElement(this.this$0.groupMD.elementAt(arrayOfInt[i]));
            this.this$0.groupMD.removeElementAt(arrayOfInt[i]);
          } 
          this.this$0.setEnabled();
        }
      };
    this.rightGroupListener = new ActionListener(this) {
        private final SummaryPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int[] arrayOfInt = this.this$0.colLT.getSelectedIndices();
          for (int i = arrayOfInt.length - 1; i >= 0; i--) {
            this.this$0.groupMD.addElement(this.this$0.colMD.elementAt(arrayOfInt[i]));
            this.this$0.colMD.removeElementAt(arrayOfInt[i]);
          } 
          this.this$0.setEnabled();
        }
      };
    this.leftSumListener = new ActionListener(this) {
        private final SummaryPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int[] arrayOfInt = this.this$0.sumLT.getSelectedIndices();
          for (int i = arrayOfInt.length - 1; i >= 0; i--) {
            this.this$0.colMD.addElement(this.this$0.sumMD.elementAt(arrayOfInt[i]));
            this.this$0.sumMD.removeElementAt(arrayOfInt[i]);
          } 
          this.this$0.setEnabled();
        }
      };
    this.rightSumListener = new ActionListener(this) {
        private final SummaryPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int[] arrayOfInt = this.this$0.colLT.getSelectedIndices();
          for (int i = arrayOfInt.length - 1; i >= 0; i--) {
            this.this$0.sumMD.addElement(this.this$0.colMD.elementAt(arrayOfInt[i]));
            this.this$0.colMD.removeElementAt(arrayOfInt[i]);
          } 
          this.this$0.setEnabled();
        }
      };
    this.sortedListener = new ItemListener(this) {
        private final SummaryPane this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setEnabled(); }
      };
    this.orderListener = new ItemListener(this) {
        private final SummaryPane this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          String str = (String)this.this$0.groupLT.getSelectedValue();
          if (str != null)
            this.this$0.group.setOrder(str, this.this$0.orderCB.isSelected() ? 1 : 2); 
        }
      };
    this.formulaListener = new ItemListener(this) {
        private final SummaryPane this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          String str = (String)this.this$0.sumLT.getSelectedValue();
          if (str != null) {
            String str1 = (String)this.this$0.sumCB.getSelectedItem();
            this.this$0.group.setFormula(str, str1.equals(Catalog.getString("(none)")) ? null : str1);
          } 
        }
      };
    this.colMD = new DefaultListModel();
    this.groupMD = new DefaultListModel();
    this.sumMD = new DefaultListModel();
    this.colLT = new JList(this.colMD);
    this.groupLT = new JList(this.groupMD);
    this.sumLT = new JList(this.sumMD);
    this.orderCB = new JCheckBox(Catalog.getString("Ascending"));
    this.sortedCB = new JCheckBox(Catalog.getString("Already Sorted"));
    this.sumCB = new JComboBox(paramBoolean ? sum_strs : none_sum_strs);
    JScrollPane jScrollPane1 = new JScrollPane(this.colLT);
    JScrollPane jScrollPane2 = new JScrollPane(this.groupLT);
    JScrollPane jScrollPane3 = new JScrollPane(this.sumLT);
    jScrollPane1.setPreferredSize(new Dimension(120, 160));
    jScrollPane2.setPreferredSize(new Dimension(120, 60));
    jScrollPane3.setPreferredSize(new Dimension(120, 60));
    try {
      this.leftGroupB = new JButton(new ImageIcon(getClass().getResource("images/leftarrow.gif")));
      this.rightGroupB = new JButton(new ImageIcon(getClass().getResource("images/rightarrow.gif")));
      this.leftSumB = new JButton(new ImageIcon(getClass().getResource("images/leftarrow.gif")));
      this.rightSumB = new JButton(new ImageIcon(getClass().getResource("images/rightarrow.gif")));
      this.leftGroupB.setPreferredSize(new Dimension(25, 25));
      this.rightGroupB.setPreferredSize(new Dimension(25, 25));
      this.leftSumB.setPreferredSize(new Dimension(25, 25));
      this.rightSumB.setPreferredSize(new Dimension(25, 25));
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    Grid2Layout grid2Layout = new Grid2Layout();
    setLayout(grid2Layout);
    byte b1 = 17;
    byte b2 = 20;
    byte b3 = 18;
    Insets insets = new Insets(5, 5, 5, 5);
    add(new JLabel(Catalog.getString("Columns") + ":"), grid2Layout.at(0, 0));
    add(jScrollPane1, grid2Layout.at(1, 0, 8, 1));
    add(this.rightGroupB, grid2Layout.at(1, 1, 1, 1, b3, insets));
    add(this.leftGroupB, grid2Layout.at(3, 1, 1, 1, b3, insets));
    add(this.rightSumB, grid2Layout.at(6, 1, 1, 1, b3, insets));
    add(this.leftSumB, grid2Layout.at(8, 1, 1, 1, b3, insets));
    add(new JLabel(Catalog.getString("Grouping") + ":"), grid2Layout.at(0, 2));
    add(jScrollPane2, grid2Layout.at(1, 2, 3, 1));
    add(this.orderCB, grid2Layout.at(1, 3, 1, 1, b1, insets));
    add(this.sortedCB, grid2Layout.at(3, 3, 1, 1, b1, insets));
    add(new JLabel(Catalog.getString("Summary") + ":"), grid2Layout.at(5, 2));
    add(jScrollPane3, grid2Layout.at(6, 2, 3, 1));
    add(this.sumCB, grid2Layout.at(6, 3, 1, 1, b1, insets));
    this.colLT.addListSelectionListener(this.selListener);
    this.groupLT.addListSelectionListener(this.groupListener);
    this.sumLT.addListSelectionListener(this.sumListener);
    this.leftGroupB.addActionListener(this.leftGroupListener);
    this.rightGroupB.addActionListener(this.rightGroupListener);
    this.leftSumB.addActionListener(this.leftSumListener);
    this.rightSumB.addActionListener(this.rightSumListener);
    this.sortedCB.addItemListener(this.sortedListener);
    this.orderCB.addItemListener(this.orderListener);
    this.sumCB.addItemListener(this.formulaListener);
    setEnabled();
  }
  
  void setEnabled() {
    boolean bool1 = (this.groupLT.getSelectedIndex() >= 0);
    boolean bool2 = (this.sumLT.getSelectedIndex() >= 0);
    this.leftGroupB.setEnabled(bool1);
    this.rightGroupB.setEnabled((this.colLT.getSelectedIndex() >= 0));
    this.leftSumB.setEnabled(bool2);
    this.rightSumB.setEnabled((this.colLT.getSelectedIndex() >= 0));
    this.orderCB.setEnabled((!this.sortedCB.isSelected() && bool1));
    this.sumCB.setEnabled(bool2);
  }
  
  public void populate(TableLens paramTableLens, SummaryAttr paramSummaryAttr) {
    this.table = paramTableLens;
    this.group = paramSummaryAttr;
    if (paramTableLens != null) {
      TableLens tableLens = getRootTable(paramTableLens);
      for (int i = tableLens.getHeaderColCount(); i < tableLens.getColCount(); i++)
        this.colMD.addElement(tableLens.getObject(0, i)); 
    } 
    String[] arrayOfString = this.group.getGroupCols();
    for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
      this.groupMD.addElement(arrayOfString[b1]);
      this.colMD.removeElement(arrayOfString[b1]);
    } 
    arrayOfString = this.group.getSummaryCols();
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      this.sumMD.addElement(arrayOfString[b2]);
      this.colMD.removeElement(arrayOfString[b2]);
    } 
    this.sortedCB.setSelected(this.group.isSorted());
  }
  
  public void update() {
    this.group.removeAllGroupCols();
    this.group.removeAllSummaryCols();
    for (byte b1 = 0; b1 < this.groupMD.size(); b1++)
      this.group.addGroupCol((String)this.groupMD.elementAt(b1)); 
    for (byte b2 = 0; b2 < this.sumMD.size(); b2++)
      this.group.addSummaryCol((String)this.sumMD.elementAt(b2)); 
    this.group.setSorted(this.sortedCB.isSelected());
  }
  
  static TableLens getRootTable(TableLens paramTableLens) {
    while (paramTableLens instanceof TableFilter)
      paramTableLens = ((TableFilter)paramTableLens).getTable(); 
    return paramTableLens;
  }
  
  static final String[] sum_strs = { "Sum", "Average", "Max", "Min", "Count", "DistinctCount", "Product", "StandardDeviation" };
  
  static final String[] none_sum_strs = { Catalog.getString("(none)"), "Sum", "Average", "Max", "Min", "Count", "DistinctCount", "Product", "StandardDeviation" };
  
  DefaultListModel colMD;
  
  DefaultListModel groupMD;
  
  DefaultListModel sumMD;
  
  JList colLT;
  
  JList groupLT;
  
  JList sumLT;
  
  JButton leftGroupB;
  
  JButton rightGroupB;
  
  JButton leftSumB;
  
  JButton rightSumB;
  
  JCheckBox orderCB;
  
  JCheckBox sortedCB;
  
  JComboBox sumCB;
  
  TableLens table;
  
  SummaryAttr group;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SummaryPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */