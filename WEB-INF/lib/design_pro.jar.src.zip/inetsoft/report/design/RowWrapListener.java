package inetsoft.report.design;

import inetsoft.report.internal.TableXElement;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;

class RowWrapListener implements ActionListener {
  DesignPane pane;
  
  TableXElement xtable;
  
  int index;
  
  public RowWrapListener(DesignPane paramDesignPane, TableXElement paramTableXElement, int paramInt) {
    this.pane = paramDesignPane;
    this.xtable = paramTableXElement;
    this.index = paramInt;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    this.xtable.setRowLineWrap(this.index, ((JMenuItem)paramActionEvent.getSource()).isSelected());
    this.pane.reprint(this.xtable);
    this.pane.setChanged(true);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\RowWrapListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */