package inetsoft.report.design;

import java.awt.event.ActionEvent;
import javax.swing.AbstractButton;
import javax.swing.JToggleButton;

class RadioModel extends JToggleButton.ToggleButtonModel {
  AbstractButton button;
  
  public RadioModel(AbstractButton paramAbstractButton) { this.button = paramAbstractButton; }
  
  public void setPressed(boolean paramBoolean) {
    super.setPressed(paramBoolean);
    if (isPressed() || !isArmed())
      fireActionPerformed(new ActionEvent(this.button, 1001, "force")); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\RadioModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */