package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public abstract class PropertyDialog extends JDialog {
  public PropertyDialog(DesignView paramDesignView) {
    super((Frame)null, false);
    this.folder = new JTabbedPane();
    this.id = new JTextField(15);
    this.changed = false;
    this.ok = true;
    this.pane = paramDesignView;
    getContentPane().setLayout(new BorderLayout(5, 10));
    getContentPane().add(this.folder, "Center");
    this.idPnl = new JPanel();
    this.idPnl.setLayout(new FlowLayout(0, 10, 5));
    this.idPnl.add(new JLabel(Catalog.getString("ID") + ":"));
    this.idPnl.add(this.id);
    getContentPane().add(this.idPnl, "North");
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(1, 25, 5));
    JButton jButton;
    jPanel.add(jButton = new JButton(Catalog.getString("OK")));
    jButton.addActionListener(new ActionListener(this) {
          private final PropertyDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            if (this.this$0.populateElement()) {
              this.this$0.dispose();
              if (this.this$0.listener != null)
                this.this$0.listener.actionPerformed(param1ActionEvent); 
            } 
          }
        });
    jPanel.add(jButton = new JButton(Catalog.getString("Cancel")));
    jButton.addActionListener(new ActionListener(this) {
          private final PropertyDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.ok = false;
            this.this$0.dispose();
          }
        });
    getContentPane().add(jPanel, "South");
  }
  
  public void showTab(String paramString) { this.folder.setSelectedIndex(this.folder.indexOfTab(paramString)); }
  
  public void show(ReportElement paramReportElement, String paramString, ActionListener paramActionListener) {
    this.listener = paramActionListener;
    setElement(paramReportElement);
    if (paramString != null)
      showTab(paramString); 
    pack();
    setVisible(true);
  }
  
  public void setActionListener(ActionListener paramActionListener) { this.listener = paramActionListener; }
  
  public void setElement(ReportElement paramReportElement) {
    this.elem = paramReportElement;
    if (paramReportElement != null) {
      this.id.setText(paramReportElement.getID());
    } else {
      getContentPane().remove(this.idPnl);
    } 
  }
  
  public boolean populateElement() {
    if (this.elem != null) {
      ReportElement reportElement = this.pane.getElement(this.id.getText());
      if (reportElement != null && reportElement != this.elem) {
        JOptionPane.showMessageDialog(null, dup_id, Catalog.getString("Error"), 0);
        return false;
      } 
      this.elem.setID(this.id.getText());
    } 
    return true;
  }
  
  public boolean isOK() { return this.ok; }
  
  public boolean isChanged() { return this.changed; }
  
  public void setChanged(boolean paramBoolean) { this.changed = paramBoolean; }
  
  static final String dup_id = Catalog.getString("The ID is already used by another element in the report!");
  
  protected JTabbedPane folder;
  
  JPanel idPnl;
  
  JTextField id;
  
  boolean changed;
  
  boolean ok;
  
  ReportElement elem;
  
  ActionListener listener;
  
  DesignView pane;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\PropertyDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */