package inetsoft.report.design;

import inetsoft.report.lens.AbstractChartLens;
import inetsoft.uql.XNode;
import inetsoft.uql.schema.XTypeNode;

class XNodeMetaChart extends AbstractChartLens {
  String[] header;
  
  Number[] row;
  
  public XNodeMetaChart(XTypeNode paramXTypeNode) {
    this.header = new String[paramXTypeNode.getChildCount()];
    this.row = new Number[paramXTypeNode.getChildCount()];
    for (byte b = 0; b < this.row.length; b++) {
      XNode xNode = paramXTypeNode.getChild(b);
      this.header[b] = (String)xNode.getAttribute("alias");
      if (this.header[b] == null)
        this.header[b] = xNode.getName(); 
      this.row[b] = new Double(b);
    } 
    if (this.row.length == 0) {
      this.header = new String[] { "Unknown" };
      this.row = new Number[] { new Double(0.0D) };
    } 
  }
  
  public int getDatasetCount() { return this.row.length; }
  
  public int getDatasetSize() { return 10; }
  
  public Number getData(int paramInt1, int paramInt2) { return this.row[paramInt1]; }
  
  public String getDatasetLabel(int paramInt) { return this.header[paramInt]; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\XNodeMetaChart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */