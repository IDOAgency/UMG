/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.lens.AbstractChartLens;
/*    */ import inetsoft.uql.XNode;
/*    */ import inetsoft.uql.schema.XTypeNode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class XNodeMetaChart
/*    */   extends AbstractChartLens
/*    */ {
/*    */   String[] header;
/*    */   Number[] row;
/*    */   
/*    */   public XNodeMetaChart(XTypeNode paramXTypeNode) {
/* 32 */     this.header = new String[paramXTypeNode.getChildCount()];
/* 33 */     this.row = new Number[paramXTypeNode.getChildCount()];
/*    */     
/* 35 */     for (byte b = 0; b < this.row.length; b++) {
/* 36 */       XNode xNode = paramXTypeNode.getChild(b);
/* 37 */       this.header[b] = (String)xNode.getAttribute("alias");
/* 38 */       if (this.header[b] == null) {
/* 39 */         this.header[b] = xNode.getName();
/*    */       }
/*    */       
/* 42 */       this.row[b] = new Double(b);
/*    */     } 
/*    */     
/* 45 */     if (this.row.length == 0) {
/* 46 */       this.header = new String[] { "Unknown" };
/* 47 */       this.row = new Number[] { new Double(0.0D) };
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   public int getDatasetCount() { return this.row.length; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 65 */   public int getDatasetSize() { return 10; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 75 */   public Number getData(int paramInt1, int paramInt2) { return this.row[paramInt1]; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 82 */   public String getDatasetLabel(int paramInt) { return this.header[paramInt]; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\XNodeMetaChart.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */