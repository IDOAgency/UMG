package inetsoft.report.design;

import inetsoft.report.TableLens;
import inetsoft.report.internal.CrosstabAttr;
import inetsoft.report.internal.TableXElement;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.Grid2Layout;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

class CrosstabDialog extends JDialog {
  ListSelectionListener selListener;
  
  ActionListener leftRowListener;
  
  ActionListener rightRowListener;
  
  ActionListener upColListener;
  
  ActionListener downColListener;
  
  ActionListener downSumListener;
  
  ActionListener upSumListener;
  
  ActionListener okListener;
  
  ActionListener removeListener;
  
  ActionListener cancelListener;
  
  public static boolean show(TableXElement paramTableXElement) {
    CrosstabDialog crosstabDialog = new CrosstabDialog(paramTableXElement);
    crosstabDialog.setModal(true);
    crosstabDialog.pack();
    crosstabDialog.setVisible(true);
    return crosstabDialog.changed;
  }
  
  public CrosstabDialog(TableXElement paramTableXElement) {
    this.selListener = new ListSelectionListener(this) {
        private final CrosstabDialog this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) { this.this$0.setEnabled(); }
      };
    this.leftRowListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int[] arrayOfInt = this.this$0.colLT.getSelectedIndices();
          for (int i = arrayOfInt.length - 1; i >= 0; i--) {
            this.this$0.rowHeaderMD.addElement(this.this$0.colMD.elementAt(arrayOfInt[i]));
            this.this$0.colMD.removeElementAt(arrayOfInt[i]);
          } 
          this.this$0.setEnabled();
        }
      };
    this.rightRowListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int[] arrayOfInt = this.this$0.rowHeaderLT.getSelectedIndices();
          for (int i = arrayOfInt.length - 1; i >= 0; i--) {
            this.this$0.colMD.addElement(this.this$0.rowHeaderMD.elementAt(arrayOfInt[i]));
            this.this$0.rowHeaderMD.removeElementAt(arrayOfInt[i]);
          } 
          this.this$0.setEnabled();
        }
      };
    this.upColListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int i = this.this$0.colLT.getSelectedIndex();
          this.this$0.colHeaderTF.setText((String)this.this$0.colMD.elementAt(i));
          this.this$0.colMD.removeElementAt(i);
          this.this$0.setEnabled();
        }
      };
    this.downColListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.colMD.addElement(this.this$0.colHeaderTF.getText());
          this.this$0.colHeaderTF.setText("");
          this.this$0.setEnabled();
        }
      };
    this.downSumListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int i = this.this$0.colLT.getSelectedIndex();
          this.this$0.sumTF.setText((String)this.this$0.colMD.elementAt(i));
          this.this$0.colMD.removeElementAt(i);
          this.this$0.setEnabled();
        }
      };
    this.upSumListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.colMD.addElement(this.this$0.sumTF.getText());
          this.this$0.sumTF.setText("");
          this.this$0.setEnabled();
        }
      };
    this.okListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.sumTF.getText().length() == 0) {
            JOptionPane.showMessageDialog(this.this$0, CrosstabDialog.sum_missing, Catalog.getString("Error"), 0);
            return;
          } 
          this.this$0.xtable.setFilter(this.this$0.createAttr());
          this.this$0.changed = true;
          this.this$0.dispose();
        }
      };
    this.removeListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.xtable.setFilter(null);
          this.this$0.changed = true;
          this.this$0.dispose();
        }
      };
    this.cancelListener = new ActionListener(this) {
        private final CrosstabDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.colMD = new DefaultListModel();
    this.rowHeaderMD = new DefaultListModel();
    this.colLT = new JList(this.colMD);
    this.rowHeaderLT = new JList(this.rowHeaderMD);
    this.colHeaderTF = new JTextField(10);
    this.sumTF = new JTextField(10);
    this.sumCB = new JComboBox(sum_strs);
    this.sortColCB = new JComboBox(sort_strs);
    this.sortRowCB = new JComboBox(sort_strs);
    this.keepCB = new JCheckBox(Catalog.getString("Keep Original Column Headers"));
    this.okB = new JButton(Catalog.getString("OK"));
    this.removeB = new JButton(Catalog.getString("Remove Crosstab"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.changed = false;
    this.xtable = paramTableXElement;
    setTitle(Catalog.getString("Crosstab"));
    getContentPane().setLayout(new BorderLayout(5, 5));
    JTabbedPane jTabbedPane = new JTabbedPane();
    JScrollPane jScrollPane1 = new JScrollPane(this.colLT);
    JScrollPane jScrollPane2 = new JScrollPane(this.rowHeaderLT);
    jScrollPane1.setPreferredSize(new Dimension(160, 120));
    jScrollPane2.setPreferredSize(new Dimension(100, 60));
    try {
      this.leftRowB = new JButton(new ImageIcon(getClass().getResource("images/leftarrow.gif")));
      this.rightRowB = new JButton(new ImageIcon(getClass().getResource("images/rightarrow.gif")));
      this.upColB = new JButton(new ImageIcon(getClass().getResource("images/uparrow.gif")));
      this.downColB = new JButton(new ImageIcon(getClass().getResource("images/downarrow.gif")));
      this.upSumB = new JButton(new ImageIcon(getClass().getResource("images/uparrow.gif")));
      this.downSumB = new JButton(new ImageIcon(getClass().getResource("images/downarrow.gif")));
      this.leftRowB.setPreferredSize(new Dimension(25, 25));
      this.rightRowB.setPreferredSize(new Dimension(25, 25));
      this.upColB.setPreferredSize(new Dimension(25, 25));
      this.downColB.setPreferredSize(new Dimension(25, 25));
      this.upSumB.setPreferredSize(new Dimension(25, 25));
      this.downSumB.setPreferredSize(new Dimension(25, 25));
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    Grid2Layout grid2Layout = new Grid2Layout(new Insets(5, 5, 5, 5));
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(grid2Layout);
    byte b1 = 17;
    byte b2 = 20;
    byte b3 = 18;
    jPanel1.add(new JLabel(Catalog.getString("Column Header Column") + ":"), grid2Layout.at(0, 0, 1, 2, b2));
    jPanel1.add(this.colHeaderTF, grid2Layout.at(0, 2, 1, 2));
    jPanel1.add(new JLabel(Catalog.getString("Row Header Columns") + ":"), grid2Layout.at(1, 0, 1, 1, b2));
    jPanel1.add(this.upColB, grid2Layout.at(1, 2, 1, 1, b3));
    jPanel1.add(this.downColB, grid2Layout.at(1, 3, 1, 1, b3));
    jPanel1.add(jScrollPane2, grid2Layout.at(2, 0, 2, 1));
    jPanel1.add(this.leftRowB, grid2Layout.at(2, 1, 1, 1, b3));
    jPanel1.add(this.rightRowB, grid2Layout.at(3, 1, 1, 1, b3));
    jPanel1.add(jScrollPane1, grid2Layout.at(2, 2, 2, 2));
    jPanel1.add(this.downSumB, grid2Layout.at(4, 2, 1, 1, b3));
    jPanel1.add(this.upSumB, grid2Layout.at(4, 3, 1, 1, b3));
    jPanel1.add(new JLabel(Catalog.getString("Summary Column") + ":"), grid2Layout.at(5, 0, 1, 2, b2));
    jPanel1.add(this.sumTF, grid2Layout.at(5, 2, 1, 2));
    jPanel1.add(new JLabel(Catalog.getString("Formula") + ":"), grid2Layout.at(6, 0, 1, 2, b2));
    jPanel1.add(this.sumCB, grid2Layout.at(6, 2, 1, 2, b1));
    jTabbedPane.add(jPanel1, Catalog.getString("Crosstab"));
    jPanel1 = new JPanel();
    jPanel1.setLayout(grid2Layout = new Grid2Layout(new Insets(5, 5, 5, 5)));
    jPanel1.add(new JLabel(Catalog.getString("Row Order") + ":"), grid2Layout.at(0, 0, 1, 1, b2));
    jPanel1.add(this.sortRowCB, grid2Layout.at(0, 1, 1, 2, b1));
    jPanel1.add(new JLabel(Catalog.getString("Column Order") + ":"), grid2Layout.at(1, 0, 1, 1, b2));
    jPanel1.add(this.sortColCB, grid2Layout.at(1, 2, 1, 2, b1));
    jPanel1.add(this.keepCB, grid2Layout.at(2, 0, 1, 3, b1));
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout());
    jPanel2.add(jPanel1, "North");
    jTabbedPane.add(jPanel2, Catalog.getString("Style"));
    getContentPane().add(jTabbedPane, "Center");
    jPanel1 = new JPanel();
    jPanel1.add(this.okB);
    jPanel1.add(this.removeB);
    jPanel1.add(this.cancelB);
    getContentPane().add(jPanel1, "South");
    populate();
    this.colHeaderTF.setEditable(false);
    this.sumTF.setEditable(false);
    this.colHeaderTF.setBackground(Color.white);
    this.sumTF.setBackground(Color.white);
    this.okB.addActionListener(this.okListener);
    this.removeB.addActionListener(this.removeListener);
    this.cancelB.addActionListener(this.cancelListener);
    this.rowHeaderLT.addListSelectionListener(this.selListener);
    this.colLT.addListSelectionListener(this.selListener);
    this.leftRowB.addActionListener(this.leftRowListener);
    this.rightRowB.addActionListener(this.rightRowListener);
    this.upColB.addActionListener(this.upColListener);
    this.downColB.addActionListener(this.downColListener);
    this.upSumB.addActionListener(this.upSumListener);
    this.downSumB.addActionListener(this.downSumListener);
    addWindowListener(new WindowAdapter(this) {
          private final CrosstabDialog this$0;
          
          public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.dispose(); }
        });
    setEnabled();
  }
  
  private void setEnabled() {
    this.rightRowB.setEnabled((this.rowHeaderLT.getSelectedIndex() >= 0));
    this.leftRowB.setEnabled((this.colLT.getSelectedIndex() >= 0));
    this.upColB.setEnabled((this.colLT.getSelectedIndex() >= 0 && this.colHeaderTF.getText().length() == 0));
    this.downColB.setEnabled((this.colHeaderTF.getText().length() > 0));
    this.downSumB.setEnabled((this.colLT.getSelectedIndex() >= 0));
    this.upSumB.setEnabled((this.sumTF.getText().length() > 0));
  }
  
  private void populate() {
    TableLens tableLens = this.xtable.getRootTable();
    if (tableLens != null)
      for (int i = tableLens.getHeaderColCount(); i < tableLens.getColCount(); i++)
        this.colMD.addElement(tableLens.getObject(0, i));  
    CrosstabAttr crosstabAttr = (this.xtable.getFilter() instanceof CrosstabAttr) ? (CrosstabAttr)this.xtable.getFilter() : new CrosstabAttr();
    String[] arrayOfString = crosstabAttr.getRowHeaders();
    for (byte b = 0; b < arrayOfString.length; b++) {
      this.rowHeaderMD.addElement(arrayOfString[b]);
      this.colMD.removeElement(arrayOfString[b]);
    } 
    this.colHeaderTF.setText((crosstabAttr.getColHeader() != null) ? crosstabAttr.getColHeader() : "");
    this.sumTF.setText((crosstabAttr.getSummaryCol() != null) ? crosstabAttr.getSummaryCol() : "");
    this.sumCB.setSelectedItem(crosstabAttr.getFormula());
    this.sortColCB.setSelectedIndex(crosstabAttr.getColOrder());
    this.sortRowCB.setSelectedIndex(crosstabAttr.getRowOrder());
    this.keepCB.setSelected(crosstabAttr.isKeepColHeader());
  }
  
  private CrosstabAttr createAttr() {
    CrosstabAttr crosstabAttr = new CrosstabAttr();
    for (byte b = 0; b < this.rowHeaderMD.size(); b++)
      crosstabAttr.addRowHeader((String)this.rowHeaderMD.elementAt(b)); 
    crosstabAttr.setColOrder(this.sortColCB.getSelectedIndex());
    crosstabAttr.setRowOrder(this.sortRowCB.getSelectedIndex());
    crosstabAttr.setColHeader((this.colHeaderTF.getText().length() > 0) ? this.colHeaderTF.getText() : null);
    crosstabAttr.setSummaryCol((this.sumTF.getText().length() > 0) ? this.sumTF.getText() : null);
    crosstabAttr.setFormula((String)this.sumCB.getSelectedItem());
    crosstabAttr.setKeepColHeader(this.keepCB.isSelected());
    return crosstabAttr;
  }
  
  static final String[] sum_strs = { "Average", "Count", "DistinctCount", "Max", "Min", "Product", "StandardDeviation", "Sum" };
  
  static final String[] sort_strs = { Catalog.getString("(none)"), Catalog.getString("Ascend"), Catalog.getString("Descend") };
  
  static final String sum_missing = Catalog.getString("Must select a summary column!");
  
  DefaultListModel colMD;
  
  DefaultListModel rowHeaderMD;
  
  JList colLT;
  
  JList rowHeaderLT;
  
  JTextField colHeaderTF;
  
  JTextField sumTF;
  
  JButton leftRowB;
  
  JButton rightRowB;
  
  JButton upColB;
  
  JButton downColB;
  
  JButton upSumB;
  
  JButton downSumB;
  
  JComboBox sumCB;
  
  JComboBox sortColCB;
  
  JComboBox sortRowCB;
  
  JCheckBox keepCB;
  
  JButton okB;
  
  JButton removeB;
  
  JButton cancelB;
  
  TableXElement xtable;
  
  boolean changed;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\CrosstabDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */