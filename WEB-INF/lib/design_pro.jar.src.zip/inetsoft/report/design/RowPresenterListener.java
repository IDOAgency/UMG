package inetsoft.report.design;

import inetsoft.report.internal.TableXElement;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;

class RowPresenterListener implements ActionListener {
  DesignPane pane;
  
  TableXElement xtable;
  
  int index;
  
  String presenter;
  
  public RowPresenterListener(DesignPane paramDesignPane, TableXElement paramTableXElement, int paramInt, String paramString) {
    this.pane = paramDesignPane;
    this.xtable = paramTableXElement;
    this.index = paramInt;
    this.presenter = paramString;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (((JMenuItem)paramActionEvent.getSource()).isSelected()) {
      this.xtable.setRowPresenter(this.index, this.presenter);
      this.pane.reprint(this.xtable);
      this.pane.setChanged(true);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\RowPresenterListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */