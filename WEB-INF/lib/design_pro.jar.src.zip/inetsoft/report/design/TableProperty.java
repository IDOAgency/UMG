package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.internal.TableXElement;
import inetsoft.report.internal.Tabular;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.report.style.TableStyle;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class TableProperty extends TextProperty {
  TableXElement elem;
  
  TablePane datapane;
  
  JRadioButton fit_page;
  
  JRadioButton fit_content;
  
  JRadioButton fit_content_1pp;
  
  JRadioButton fit_content_page;
  
  JRadioButton eq_width;
  
  JCheckBox fix_width;
  
  JCheckBox orphanCB;
  
  ButtonGroup layoutGroup;
  
  JTextField styleTF;
  
  JButton styleB;
  
  JButton clearB;
  
  NumField top;
  
  NumField left;
  
  NumField bottom;
  
  NumField right;
  
  NumField tableadv;
  
  TableStyle style;
  
  public TableProperty(DesignView paramDesignView) {
    super(paramDesignView, inetsoft.report.TableElement.class);
    this.datapane = new TablePane(1);
    this.fit_page = new JRadioButton(Catalog.getString("Fit Page"));
    this.fit_content = new JRadioButton(Catalog.getString("Fit Content"));
    this.fit_content_1pp = new JRadioButton(Catalog.getString("Fit Content (Wrap One Table Region Per Page)"));
    this.fit_content_page = new JRadioButton(Catalog.getString("Fit Content and Page"));
    this.eq_width = new JRadioButton(Catalog.getString("Equal Width"));
    this.fix_width = new JCheckBox(Catalog.getString("Embed Column Widths"));
    this.orphanCB = new JCheckBox(Catalog.getString("Widow/Orphan Control"));
    this.layoutGroup = new ButtonGroup();
    this.styleTF = new JTextField(15);
    this.styleB = new JButton(Catalog.getString("Select Style"));
    this.clearB = new JButton(Catalog.getString("Clear"));
    this.top = new NumField(3, true);
    this.left = new NumField(3, true);
    this.bottom = new NumField(3, true);
    this.right = new NumField(3, true);
    this.tableadv = new NumField(3, true);
    setTitle(Catalog.getString("Table Properties"));
    Property2Panel property2Panel = new Property2Panel();
    this.styleTF.setEditable(false);
    property2Panel.add(Catalog.getString("Layout"), new Object[][] { { this.fit_page, this.fit_content }, { this.fit_content_page, this.eq_width }, { this.fit_content_1pp }, { this.fix_width }, { this.orphanCB, { Catalog.getString("Trailing Advance") + ":", this.tableadv } } });
    property2Panel.add(Catalog.getString("Style"), new Object[][] { { this.styleTF, this.styleB, this.clearB } });
    property2Panel.add(Catalog.getString("Cell Padding"), new Object[][] { { Catalog.getString("Top") + ":", this.top, Catalog.getString("Left") + ":", this.left, Catalog.getString("Bottom") + ":", this.bottom, Catalog.getString("Right") + ":", this.right } });
    this.folder.insertTab(Catalog.getString("Table"), null, property2Panel, Catalog.getString("Table Layout"), 0);
    this.folder.insertTab(Catalog.getString("Headers and Data"), null, this.datapane, Catalog.getString("Table Headers and Data"), 1);
    this.styleB.addActionListener(new ActionListener(this) {
          private final TableProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            TableStyle tableStyle = StyleViewer.show(null, this.this$0.elem.getStyle());
            if (tableStyle != null)
              this.this$0.styleTF.setText((this.this$0.style = tableStyle).getName()); 
          }
        });
    this.clearB.addActionListener(new ActionListener(this) {
          private final TableProperty this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.style = null;
            this.this$0.styleTF.setText("");
          }
        });
    this.layoutGroup.add(this.fit_page);
    this.layoutGroup.add(this.fit_content);
    this.layoutGroup.add(this.fit_content_1pp);
    this.layoutGroup.add(this.fit_content_page);
    this.layoutGroup.add(this.eq_width);
  }
  
  public void setElement(ReportElement paramReportElement) {
    this.elem = (TableXElement)paramReportElement;
    super.setElement(paramReportElement);
    TableXElement tableXElement = (TableXElement)paramReportElement;
    if (paramReportElement.getProperty("query") != null) {
      this.folder.setEnabledAt(1, false);
    } else {
      this.folder.setEnabledAt(1, true);
      this.datapane.setElement((Tabular)paramReportElement);
    } 
    switch (tableXElement.getLayout()) {
      case 1:
        this.fit_page.setSelected(true);
        break;
      case 3:
        this.fit_content_1pp.setSelected(true);
        break;
      case 4:
        this.fit_content_page.setSelected(true);
        break;
      case 0:
        this.fit_content.setSelected(true);
        break;
      case 2:
        this.eq_width.setSelected(true);
        break;
    } 
    this.fix_width.setSelected(tableXElement.isEmbedWidth());
    this.orphanCB.setSelected(tableXElement.isOrphanControl());
    this.tableadv.setValue(tableXElement.getTableAdvance());
    this.style = tableXElement.getStyle();
    this.styleTF.setText((this.style == null) ? "" : this.style.getName());
    Insets insets = tableXElement.getPadding();
    this.top.setValue(insets.top);
    this.left.setValue(insets.left);
    this.bottom.setValue(insets.bottom);
    this.right.setValue(insets.right);
  }
  
  public boolean populateElement() {
    if (!super.populateElement())
      return false; 
    if (this.folder.isEnabledAt(1))
      this.datapane.populateElement(); 
    TableXElement tableXElement = this.elem;
    if (this.fit_page.isSelected()) {
      tableXElement.setLayout(1);
    } else if (this.fit_content.isSelected()) {
      tableXElement.setLayout(0);
    } else if (this.fit_content_1pp.isSelected()) {
      tableXElement.setLayout(3);
    } else if (this.fit_content_page.isSelected()) {
      tableXElement.setLayout(4);
    } else if (this.eq_width.isSelected()) {
      tableXElement.setLayout(2);
    } 
    tableXElement.setEmbedWidth(this.fix_width.isSelected());
    tableXElement.setOrphanControl(this.orphanCB.isSelected());
    tableXElement.setTableAdvance(this.tableadv.intValue());
    tableXElement.setStyle(this.style);
    Insets insets = new Insets(this.top.intValue(), this.left.intValue(), this.bottom.intValue(), this.right.intValue());
    tableXElement.setPadding(insets);
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TableProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */