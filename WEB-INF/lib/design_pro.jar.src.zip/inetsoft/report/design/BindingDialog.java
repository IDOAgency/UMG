package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.TableXElement;
import inetsoft.report.locale.Catalog;
import inetsoft.uql.XQuery;
import inetsoft.uql.XRepository;
import inetsoft.uql.builder.XBuilder;
import inetsoft.uql.path.XNodePath;
import inetsoft.uql.schema.UserVariable;
import inetsoft.uql.util.Config;
import inetsoft.uql.util.gui.XNodePathEditor;
import inetsoft.widget.STree;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.tree.TreePath;

class BindingDialog extends JDialog {
  ItemListener qtreeListener;
  
  ActionListener editListener;
  
  ActionListener newListener;
  
  ActionListener okListener;
  
  ActionListener cancelListener;
  
  private JComboBox aggregateCB;
  
  private XNodePathEditor editor;
  
  SectionOptionPane sectionPane;
  
  private STree qtree;
  
  private JScrollPane treescr;
  
  private DesignSession xsession;
  
  private XRepository repository;
  
  private ReportElement table;
  
  private DesignFrame frame;
  
  private StyleSheet report;
  
  private XNodePath xpath;
  
  private XBuilder builder;
  
  private Hashtable descmap;
  
  private ActionListener action;
  
  private Image icon;
  
  private JTextArea descTF;
  
  private JButton okB;
  
  private JButton editB;
  
  private JButton newB;
  
  private JButton cancelB;
  
  public static void show(DesignSession paramDesignSession, ReportElement paramReportElement, DesignFrame paramDesignFrame, XBuilder paramXBuilder, ActionListener paramActionListener) {
    BindingDialog bindingDialog = new BindingDialog(paramDesignSession, paramReportElement, paramDesignFrame, paramXBuilder, paramActionListener);
    bindingDialog.pack();
    bindingDialog.setVisible(true);
    TreePath treePath = bindingDialog.qtree.getSelectionPath();
    if (treePath != null) {
      Rectangle rectangle = bindingDialog.qtree.getPathBounds(treePath);
      bindingDialog.treescr.getViewport().scrollRectToVisible(rectangle);
    } 
  }
  
  public BindingDialog(DesignSession paramDesignSession, ReportElement paramReportElement, DesignFrame paramDesignFrame, XBuilder paramXBuilder, ActionListener paramActionListener) {
    this.qtreeListener = new ItemListener(this) {
        private final BindingDialog this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          String str1 = this.this$0.qtree.getSelectedPath();
          String str2 = null;
          if (str1 != null) {
            str2 = (String)this.this$0.descmap.get(str1);
            try {
              String str = this.this$0.qtree.getSelectedLabel();
              XQuery xQuery = this.this$0.repository.getQuery(str);
              if (xQuery != null)
                this.this$0.editor.setTree(xQuery.getOutputType(), this.this$0.xpath); 
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString());
            } 
          } 
          this.this$0.descTF.setText((str2 != null) ? str2 : "");
          this.this$0.setEnabled();
        }
      };
    this.editListener = new ActionListener(this) {
        private final BindingDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          String str = this.this$0.qtree.getSelectedLabel();
          if (str != null) {
            this.this$0.builder.showQuery(str);
            this.this$0.builder.pack();
            this.this$0.builder.setVisible(true);
          } 
        }
      };
    this.newListener = new ActionListener(this) {
        private final BindingDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          String str1 = null, str2 = null;
          String str3 = this.this$0.qtree.getSelectedPath();
          if (str3 != null) {
            int i = str3.indexOf('/');
            if (i > 0) {
              str1 = str3.substring(0, i);
              str2 = str3.substring(i + 1);
            } else {
              str1 = str3;
            } 
          } 
          this.this$0.builder.pack();
          this.this$0.builder.setVisible(true);
          XQuery xQuery = this.this$0.builder.newQuery(str1, str2);
          if (xQuery != null) {
            str3 = xQuery.getDataSource().getName() + "/" + xQuery.getName();
            this.this$0.qtree.add(str3);
            this.this$0.qtree.setIcon(str3, new ImageIcon(this.this$0.icon));
          } 
        }
      };
    this.okListener = new ActionListener(this) {
        private final BindingDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.table.setProperty("query", this.this$0.qtree.getSelectedLabel());
          if (this.this$0.table instanceof TableXElement)
            ((TableXElement)this.this$0.table).setFilter(null); 
          String str = (String)this.this$0.aggregateCB.getSelectedItem();
          this.this$0.table.setProperty("aggregate", (str == null || str.equals("(none)")) ? null : str);
          this.this$0.xpath = this.this$0.editor.getNodePath();
          this.this$0.table.setProperty("xnodepath", (this.this$0.xpath == null) ? null : this.this$0.xpath.toString());
          try {
            this.this$0.frame.refresh();
            this.this$0.sectionPane.process();
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, exception.toString());
          } 
          this.this$0.frame.setChanged(true);
          this.this$0.dispose();
          this.this$0.action.actionPerformed(null);
        }
      };
    this.cancelListener = new ActionListener(this) {
        private final BindingDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.aggregateCB = new JComboBox(new Object[] { "(none)", "sum", "avg", "min", "max", "count", "distinct_count" });
    this.editor = new XNodePathEditor();
    this.qtree = new STree();
    this.descmap = new Hashtable();
    this.descTF = new JTextArea();
    this.okB = new JButton(Catalog.getString("OK"));
    this.editB = new JButton(Catalog.getString("Edit"));
    this.newB = new JButton(Catalog.getString("New"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.xsession = paramDesignSession;
    this.table = paramReportElement;
    this.frame = paramDesignFrame;
    this.report = paramDesignFrame.getStyleSheet();
    this.builder = paramXBuilder;
    this.action = paramActionListener;
    getContentPane().setLayout(new BorderLayout(5, 5));
    this.treescr = new JScrollPane(this.qtree);
    this.treescr.setPreferredSize(new Dimension(300, 150));
    setTitle(Catalog.getString("Data Binding"));
    this.repository = (XRepository)paramDesignSession.getDataService();
    try {
      String[] arrayOfString = this.repository.getQueryNames();
      String str = paramReportElement.getProperty("query");
      this.qtree.setSorting(1);
      this.qtree.setSeparator('/');
      this.qtree.removeAll();
      this.icon = Config.getQueryIcon();
      for (byte b = 0; b < arrayOfString.length; b++) {
        XQuery xQuery = this.repository.getQuery(arrayOfString[b]);
        String str1 = xQuery.getDataSource().getName() + "/" + xQuery.getName();
        this.qtree.add(str1);
        if (str != null && arrayOfString[b].equals(str))
          this.qtree.setSelected(str1, true); 
        if (this.icon != null)
          this.qtree.setIcon(str1, new ImageIcon(this.icon)); 
        if (xQuery.getDescription() != null)
          this.descmap.put(str1, xQuery.getDescription()); 
      } 
      if (paramReportElement.getType().equals("Table")) {
        Vector vector = this.report.getAllElements();
        for (byte b1 = 0; b1 < vector.size(); b1++) {
          Vector vector1 = (Vector)vector.elementAt(b1);
          for (byte b2 = 0; b2 < vector1.size(); b2++) {
            ReportElement reportElement = (ReportElement)vector1.elementAt(b2);
            if (reportElement instanceof inetsoft.report.ChartElement) {
              String str1 = "chart table/chart::" + reportElement.getID();
              this.qtree.add(str1);
              if (str != null && str.equals("chart::" + reportElement.getID()))
                this.qtree.setSelected(str1, true); 
              if (this.icon != null)
                this.qtree.setIcon(str1, new ImageIcon(this.icon)); 
            } 
          } 
        } 
      } else if (paramReportElement instanceof inetsoft.report.TextElement || paramReportElement instanceof inetsoft.report.TextBoxElement) {
        UserVariable[] arrayOfUserVariable = paramDesignSession.getQueryParameters(this.report, false);
        if (arrayOfUserVariable != null)
          for (byte b1 = 0; b1 < arrayOfUserVariable.length; b1++) {
            String str1 = "parameter/variable::" + arrayOfUserVariable[b1].getName();
            this.qtree.add(str1);
            if (str != null && str.equals("variable::" + arrayOfUserVariable[b1].getName()))
              this.qtree.setSelected(str1, true); 
            if (this.icon != null)
              this.qtree.setIcon(str1, new ImageIcon(this.icon)); 
          }  
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(null, exception.toString());
    } 
    JScrollPane jScrollPane = new JScrollPane(this.descTF);
    jScrollPane.setPreferredSize(new Dimension(300, 60));
    this.descTF.setEditable(false);
    this.descTF.setBackground(getBackground());
    getContentPane().add(jScrollPane, "Center");
    this.sectionPane = new SectionOptionPane(paramReportElement, paramDesignFrame);
    if (paramReportElement instanceof inetsoft.report.TextElement || paramReportElement instanceof inetsoft.report.TextBoxElement) {
      JTabbedPane jTabbedPane = new JTabbedPane();
      jTabbedPane.setPreferredSize(new Dimension(450, 250));
      jTabbedPane.add(this.treescr, Catalog.getString("Query"));
      jTabbedPane.add(this.editor, Catalog.getString("Selection"));
      this.editor.addControl(this.aggregateCB);
      String str = paramReportElement.getProperty("aggregate");
      this.aggregateCB.setSelectedItem((str == null) ? "(none)" : str);
      try {
        String str1 = paramReportElement.getProperty("xnodepath");
        if (str1 != null)
          this.xpath = XNodePath.parse(str1); 
        this.qtreeListener.itemStateChanged(null);
      } catch (Exception exception) {
        exception.printStackTrace();
        JOptionPane.showMessageDialog(this, exception.toString());
      } 
      getContentPane().add(jTabbedPane, "North");
    } else if (paramReportElement instanceof inetsoft.report.SectionElement) {
      JTabbedPane jTabbedPane = new JTabbedPane();
      jTabbedPane.setPreferredSize(new Dimension(300, 180));
      jTabbedPane.add(this.treescr, Catalog.getString("Query"));
      jTabbedPane.add(this.sectionPane, Catalog.getString("Generation"));
      getContentPane().add(jTabbedPane, "North");
    } else {
      getContentPane().add(this.treescr, "North");
    } 
    JPanel jPanel = new JPanel();
    jPanel.add(this.editB);
    jPanel.add(this.newB);
    jPanel.add(this.okB);
    jPanel.add(this.cancelB);
    getContentPane().add(jPanel, "South");
    this.qtree.addItemListener(this.qtreeListener);
    this.editB.addActionListener(this.editListener);
    this.newB.addActionListener(this.newListener);
    this.okB.addActionListener(this.okListener);
    this.cancelB.addActionListener(this.cancelListener);
    this.qtreeListener.itemStateChanged(null);
  }
  
  public void setActionListener(ActionListener paramActionListener) { this.action = paramActionListener; }
  
  public boolean isRemoveExistingFields() { return this.sectionPane.isRemoveExistingFields(); }
  
  public boolean isUseTextBox() { return this.sectionPane.isUseTextBox(); }
  
  private void setEnabled() { this.editB.setEnabled((this.qtree.getSelectionPath() != null)); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\BindingDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */