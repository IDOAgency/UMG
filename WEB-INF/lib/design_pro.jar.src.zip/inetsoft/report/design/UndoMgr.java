/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.FixedContainer;
/*     */ import inetsoft.report.PageArea;
/*     */ import inetsoft.report.PainterElement;
/*     */ import inetsoft.report.Position;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.BaseElement;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UndoMgr
/*     */ {
/*     */   int limit;
/*     */   Vector acts;
/*     */   DesignPane pane;
/*     */   StyleSheet sheet;
/*     */   
/*     */   public UndoMgr(DesignPane paramDesignPane, StyleSheet paramStyleSheet) {
/* 430 */     this.limit = 100;
/* 431 */     this.acts = new Vector();
/*     */     this.pane = paramDesignPane;
/*     */     this.sheet = paramStyleSheet;
/*     */   }
/*     */   
/*     */   public void undo() {
/*     */     if (this.acts.size() > 0) {
/*     */       int i = this.acts.size() - 1;
/*     */       ((Undo)this.acts.elementAt(i)).undo();
/*     */       if (i < this.acts.size())
/*     */         this.acts.removeElementAt(i); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getCount() { return this.acts.size(); }
/*     */   
/*     */   public void undoN(int paramInt) {
/*     */     if (paramInt > 1)
/*     */       addUndo(new UndoN(this, paramInt)); 
/*     */   }
/*     */   
/*     */   public void undoInsert(ReportElement paramReportElement, int paramInt) { addUndo(new InsertUndo(this, paramReportElement, paramInt)); }
/*     */   
/*     */   public void undoInsert(ReportElement paramReportElement, FixedContainer paramFixedContainer) { addUndo(new ContainerInsertUndo(this, paramReportElement, paramFixedContainer)); }
/*     */   
/*     */   public void undoProperty(ReportElement paramReportElement1, ReportElement paramReportElement2, int paramInt) { addUndo(new PropertyUndo(this, paramReportElement1, paramReportElement2, paramInt)); }
/*     */   
/*     */   public void undoProperty(ReportElement paramReportElement1, ReportElement paramReportElement2, FixedContainer paramFixedContainer) { addUndo(new ContainerPropertyUndo(this, paramReportElement1, paramReportElement2, paramFixedContainer)); }
/*     */   
/*     */   public void undoRemove(int paramInt1, ReportElement paramReportElement, int paramInt2) { addUndo(new RemoveUndo(this, paramInt1, paramReportElement, paramInt2)); }
/*     */   
/*     */   public void undoRemove(ReportElement paramReportElement, FixedContainer paramFixedContainer) { addUndo(new ContainerRemoveUndo(this, paramReportElement, paramFixedContainer)); }
/*     */   
/*     */   public void undoMove(ReportElement paramReportElement, Position paramPosition) { addUndo(new MoveUndo(this, paramReportElement, paramPosition)); }
/*     */   
/*     */   public void undoResize(ReportElement paramReportElement, Size paramSize) { addUndo(new ResizeUndo(this, paramReportElement, paramSize)); }
/*     */   
/*     */   public void undoBounds(ReportElement paramReportElement, Rectangle paramRectangle) { addUndo(new BoundsUndo(this, paramReportElement, paramRectangle)); }
/*     */   
/*     */   public void undoOnPageBreak(String paramString) { addUndo(new OnPageBreakUndo(this, paramString)); }
/*     */   
/*     */   public void undoPageArea(DesignPane.DesignPage paramDesignPage, String paramString, PageArea[] paramArrayOfPageArea) { addUndo(new PageAreaUndo(this, paramDesignPage, paramString, paramArrayOfPageArea)); }
/*     */   
/*     */   protected void addUndo(Undo paramUndo) {
/*     */     this.acts.addElement(paramUndo);
/*     */     if (this.acts.size() > this.limit)
/*     */       this.acts.removeElementAt(0); 
/*     */   }
/*     */   
/*     */   static interface Undo {
/*     */     void undo();
/*     */   }
/*     */   
/*     */   class InsertUndo implements Undo {
/*     */     ReportElement elem;
/*     */     int target;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public InsertUndo(UndoMgr this$0, ReportElement param1ReportElement, int param1Int) {
/*     */       this.this$0 = this$0;
/*     */       this.elem = param1ReportElement;
/*     */       this.target = param1Int;
/*     */     }
/*     */     
/*     */     public void undo() {
/*     */       int i = this.this$0.sheet.getElements(this.target).indexOf(this.elem);
/*     */       if (i >= 0) {
/*     */         if (this.this$0.pane.getCurrent() == this.elem)
/*     */           this.this$0.pane.setCurrent(null, null); 
/*     */         this.this$0.sheet.getElements(this.target).removeElementAt(i);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class ContainerInsertUndo implements Undo {
/*     */     ReportElement elem;
/*     */     FixedContainer container;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public ContainerInsertUndo(UndoMgr this$0, ReportElement param1ReportElement, FixedContainer param1FixedContainer) {
/*     */       this.this$0 = this$0;
/*     */       this.elem = param1ReportElement;
/*     */       this.container = param1FixedContainer;
/*     */     }
/*     */     
/*     */     public void undo() {
/*     */       int i = this.container.getElementIndex(this.elem);
/*     */       if (i >= 0) {
/*     */         if (this.this$0.pane.getCurrent() == this.elem)
/*     */           this.this$0.pane.setCurrent(null, null); 
/*     */         this.container.removeElement(i);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class PropertyUndo implements Undo {
/*     */     ReportElement oelem;
/*     */     ReportElement elem;
/*     */     int target;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public PropertyUndo(UndoMgr this$0, ReportElement param1ReportElement1, ReportElement param1ReportElement2, int param1Int) {
/*     */       this.this$0 = this$0;
/*     */       this.oelem = param1ReportElement1;
/*     */       this.elem = param1ReportElement2;
/*     */       this.target = param1Int;
/*     */     }
/*     */     
/*     */     public void undo() {
/*     */       int i = this.this$0.sheet.getElements(this.target).indexOf(this.elem);
/*     */       if (i >= 0) {
/*     */         this.this$0.sheet.getElements(this.target).removeElementAt(i);
/*     */         this.this$0.sheet.getElements(this.target).insertElementAt(this.oelem, i);
/*     */         if (this.this$0.pane.getCurrent() == this.elem)
/*     */           this.this$0.pane.setCurrent(this.oelem, null); 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class ContainerPropertyUndo implements Undo {
/*     */     ReportElement oelem;
/*     */     ReportElement elem;
/*     */     FixedContainer container;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public ContainerPropertyUndo(UndoMgr this$0, ReportElement param1ReportElement1, ReportElement param1ReportElement2, FixedContainer param1FixedContainer) {
/*     */       this.this$0 = this$0;
/*     */       this.oelem = param1ReportElement1;
/*     */       this.elem = param1ReportElement2;
/*     */       this.container = param1FixedContainer;
/*     */     }
/*     */     
/*     */     public void undo() {
/*     */       int i = this.container.getElementIndex(this.elem);
/*     */       if (i >= 0) {
/*     */         Rectangle rectangle = this.container.getBounds(i);
/*     */         this.container.removeElement(i);
/*     */         this.container.addElement(this.oelem, rectangle);
/*     */         if (this.this$0.pane.getCurrent() == this.elem)
/*     */           this.this$0.pane.setCurrent(this.oelem, null); 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class RemoveUndo implements Undo {
/*     */     int idx;
/*     */     ReportElement elem;
/*     */     int target;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public RemoveUndo(UndoMgr this$0, int param1Int1, ReportElement param1ReportElement, int param1Int2) {
/*     */       this.this$0 = this$0;
/*     */       this.idx = param1Int1;
/*     */       this.elem = param1ReportElement;
/*     */       this.target = param1Int2;
/*     */     }
/*     */     
/*     */     public void undo() { this.this$0.sheet.getElements(this.target).insertElementAt(this.elem, this.idx); }
/*     */   }
/*     */   
/*     */   class ContainerRemoveUndo implements Undo {
/*     */     ReportElement elem;
/*     */     FixedContainer container;
/*     */     Rectangle bounds;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public ContainerRemoveUndo(UndoMgr this$0, ReportElement param1ReportElement, FixedContainer param1FixedContainer) {
/*     */       this.this$0 = this$0;
/*     */       this.elem = param1ReportElement;
/*     */       this.container = param1FixedContainer;
/*     */       int i = param1FixedContainer.getElementIndex(param1ReportElement);
/*     */       if (i >= 0)
/*     */         this.bounds = param1FixedContainer.getBounds(i); 
/*     */     }
/*     */     
/*     */     public void undo() { this.container.addElement(this.elem, this.bounds); }
/*     */   }
/*     */   
/*     */   class MoveUndo implements Undo {
/*     */     ReportElement elem;
/*     */     Position anchor;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public MoveUndo(UndoMgr this$0, ReportElement param1ReportElement, Position param1Position) {
/*     */       this.this$0 = this$0;
/*     */       this.elem = param1ReportElement;
/*     */       this.anchor = param1Position;
/*     */     }
/*     */     
/*     */     public void undo() { ((PainterElement)this.elem).setAnchor(this.anchor); }
/*     */   }
/*     */   
/*     */   class ResizeUndo implements Undo {
/*     */     ReportElement elem;
/*     */     Size size;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public ResizeUndo(UndoMgr this$0, ReportElement param1ReportElement, Size param1Size) {
/*     */       this.this$0 = this$0;
/*     */       this.elem = param1ReportElement;
/*     */       this.size = param1Size;
/*     */     }
/*     */     
/*     */     public void undo() { ((PainterElement)this.elem).setSize(this.size); }
/*     */   }
/*     */   
/*     */   class BoundsUndo implements Undo {
/*     */     ReportElement elem;
/*     */     Rectangle bounds;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public BoundsUndo(UndoMgr this$0, ReportElement param1ReportElement, Rectangle param1Rectangle) {
/*     */       this.this$0 = this$0;
/*     */       this.elem = param1ReportElement;
/*     */       this.bounds = param1Rectangle;
/*     */     }
/*     */     
/*     */     public void undo() {
/*     */       FixedContainer fixedContainer = (FixedContainer)((BaseElement)this.elem).getParent();
/*     */       if (fixedContainer != null) {
/*     */         int i = fixedContainer.getElementIndex(this.elem);
/*     */         if (i >= 0)
/*     */           fixedContainer.setBounds(i, this.bounds); 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class OnPageBreakUndo implements Undo {
/*     */     String cmd;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public OnPageBreakUndo(UndoMgr this$0, String param1String) {
/*     */       this.this$0 = this$0;
/*     */       this.cmd = param1String;
/*     */     }
/*     */     
/*     */     public void undo() { this.this$0.sheet.setOnPageBreak(this.cmd); }
/*     */   }
/*     */   
/*     */   class PageAreaUndo implements Undo {
/*     */     String editID;
/*     */     DesignPane.DesignPage page;
/*     */     PageArea[] pageareas;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public PageAreaUndo(UndoMgr this$0, DesignPane.DesignPage param1DesignPage, String param1String, PageArea[] param1ArrayOfPageArea) {
/*     */       this.this$0 = this$0;
/*     */       this.page = param1DesignPage;
/*     */       this.editID = param1String;
/*     */       if (param1ArrayOfPageArea != null) {
/*     */         this.pageareas = new PageArea[param1ArrayOfPageArea.length];
/*     */         for (byte b = 0; b < param1ArrayOfPageArea.length; b++) {
/*     */           try {
/*     */             this.pageareas[b] = (PageArea)param1ArrayOfPageArea[b].clone();
/*     */           } catch (Exception exception) {
/*     */             this.pageareas[b] = param1ArrayOfPageArea[b];
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public void undo() {
/*     */       if (this.editID != null) {
/*     */         this.this$0.sheet.setPageAreas(this.pageareas, this.editID);
/*     */       } else {
/*     */         this.page.setAreas(this.pageareas);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   class UndoN implements Undo {
/*     */     int n;
/*     */     private final UndoMgr this$0;
/*     */     
/*     */     public UndoN(UndoMgr this$0, int param1Int) {
/*     */       this.this$0 = this$0;
/*     */       this.n = param1Int;
/*     */     }
/*     */     
/*     */     public void undo() {
/*     */       this.this$0.acts.removeElementAt(this.this$0.acts.size() - 1);
/*     */       for (byte b = 0; b < this.n && this.this$0.acts.size() > 0; b++)
/*     */         this.this$0.undo(); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\UndoMgr.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */