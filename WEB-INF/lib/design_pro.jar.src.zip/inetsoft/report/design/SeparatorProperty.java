package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.SeparatorElement;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;

public class SeparatorProperty extends PropertyDialog {
  SeparatorElement elem;
  
  LineCombo line;
  
  NumField sepadv;
  
  public SeparatorProperty(DesignView paramDesignView) {
    super(paramDesignView);
    this.line = new LineCombo(false);
    this.sepadv = new NumField(3, true);
    setTitle(Catalog.getString("Separator Properties"));
    Property2Panel property2Panel = new Property2Panel();
    property2Panel.add(Catalog.getString("Style"), new Object[][] { { Catalog.getString("Line") + ":", this.line }, { Catalog.getString("Trailing Advance") + ":", this.sepadv } });
    this.folder.addTab(Catalog.getString("Separator"), null, property2Panel, Catalog.getString("Separator"));
  }
  
  public void setElement(ReportElement paramReportElement) {
    this.elem = (SeparatorElement)paramReportElement;
    super.setElement(paramReportElement);
    this.line.setSelectedLineStyle(this.elem.getStyle());
    this.sepadv.setValue(this.elem.getSeparatorAdvance());
  }
  
  public boolean populateElement() {
    if (!super.populateElement())
      return false; 
    int i = this.line.getSelectedLineStyle();
    this.elem.setStyle(i);
    this.elem.setSeparatorAdvance(this.sepadv.intValue());
    DesignEnv.setProperty("separator.style", Integer.toString(i));
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SeparatorProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */