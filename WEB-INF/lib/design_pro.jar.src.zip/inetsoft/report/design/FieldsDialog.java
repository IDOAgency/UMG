package inetsoft.report.design;

import inetsoft.report.TableLens;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

class FieldsDialog extends JDialog {
  ActionListener okListener;
  
  ActionListener cancelListener;
  
  public static Object show(TableLens paramTableLens) {
    if (paramTableLens == null) {
      JOptionPane.showMessageDialog(null, no_binding, Catalog.getString("Warning"), 2);
      return null;
    } 
    FieldsDialog fieldsDialog = new FieldsDialog(paramTableLens);
    fieldsDialog.setModal(true);
    fieldsDialog.pack();
    fieldsDialog.setVisible(true);
    return fieldsDialog.field;
  }
  
  public FieldsDialog(TableLens paramTableLens) {
    this.okListener = new ActionListener(this) {
        private final FieldsDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.field = this.this$0.list.getSelectedValue();
          this.this$0.dispose();
        }
      };
    this.cancelListener = new ActionListener(this) {
        private final FieldsDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.okB = new JButton(Catalog.getString("OK"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.field = null;
    setTitle(Catalog.getString("Fields"));
    getContentPane().setLayout(new BorderLayout(5, 5));
    Object[] arrayOfObject = new Object[paramTableLens.getColCount()];
    for (byte b = 0; b < arrayOfObject.length; b++)
      arrayOfObject[b] = paramTableLens.getObject(0, b); 
    this.list = new JList(arrayOfObject);
    JScrollPane jScrollPane = new JScrollPane(this.list);
    jScrollPane.setPreferredSize(new Dimension(100, 150));
    getContentPane().add(jScrollPane, "Center");
    JPanel jPanel = new JPanel();
    jPanel.add(this.okB);
    jPanel.add(this.cancelB);
    getContentPane().add(jPanel, "South");
    this.okB.addActionListener(this.okListener);
    this.cancelB.addActionListener(this.cancelListener);
    addWindowListener(new WindowAdapter(this) {
          private final FieldsDialog this$0;
          
          public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.dispose(); }
        });
  }
  
  static final String no_binding = Catalog.getString("No binding assigned to this element!");
  
  JButton okB;
  
  JButton cancelB;
  
  JList list;
  
  Object field;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FieldsDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */