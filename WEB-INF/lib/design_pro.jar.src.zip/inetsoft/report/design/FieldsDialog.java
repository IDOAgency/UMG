/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FieldsDialog
/*     */   extends JDialog
/*     */ {
/*     */   ActionListener okListener;
/*     */   ActionListener cancelListener;
/*     */   
/*     */   public static Object show(TableLens paramTableLens) {
/*  34 */     if (paramTableLens == null) {
/*  35 */       JOptionPane.showMessageDialog(null, no_binding, Catalog.getString("Warning"), 2);
/*     */ 
/*     */       
/*  38 */       return null;
/*     */     } 
/*     */     
/*  41 */     FieldsDialog fieldsDialog = new FieldsDialog(paramTableLens);
/*  42 */     fieldsDialog.setModal(true);
/*  43 */     fieldsDialog.pack();
/*  44 */     fieldsDialog.setVisible(true);
/*     */     
/*  46 */     return fieldsDialog.field;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldsDialog(TableLens paramTableLens) {
/*  81 */     this.okListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*  83 */           this.this$0.field = this.this$0.list.getSelectedValue();
/*  84 */           this.this$0.dispose();
/*     */         }
/*     */         private final FieldsDialog this$0;
/*     */       };
/*  88 */     this.cancelListener = new ActionListener(this)
/*     */       {
/*  90 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */ 
/*     */ 
/*     */         
/*     */         private final FieldsDialog this$0;
/*     */       };
/*  96 */     this.okB = new JButton(Catalog.getString("OK"));
/*  97 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*     */ 
/*     */     
/* 100 */     this.field = null;
/*     */     setTitle(Catalog.getString("Fields"));
/*     */     getContentPane().setLayout(new BorderLayout(5, 5));
/*     */     Object[] arrayOfObject = new Object[paramTableLens.getColCount()];
/*     */     for (byte b = 0; b < arrayOfObject.length; b++)
/*     */       arrayOfObject[b] = paramTableLens.getObject(0, b); 
/*     */     this.list = new JList(arrayOfObject);
/*     */     JScrollPane jScrollPane = new JScrollPane(this.list);
/*     */     jScrollPane.setPreferredSize(new Dimension(100, 150));
/*     */     getContentPane().add(jScrollPane, "Center");
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.add(this.okB);
/*     */     jPanel.add(this.cancelB);
/*     */     getContentPane().add(jPanel, "South");
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.cancelB.addActionListener(this.cancelListener);
/*     */     addWindowListener(new WindowAdapter(this) {
/*     */           private final FieldsDialog this$0;
/*     */           
/*     */           public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.dispose(); }
/*     */         });
/*     */   }
/*     */   
/*     */   static final String no_binding = Catalog.getString("No binding assigned to this element!");
/*     */   JButton okB;
/*     */   JButton cancelB;
/*     */   JList list;
/*     */   Object field;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FieldsDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */