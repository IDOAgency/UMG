package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.STree;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

public class SectionProperty extends PropertyDialog {
  TreeSelectionListener treeListener;
  
  ChangedListener changedListener;
  
  SectionElement elem;
  
  SectionBand currband;
  
  JCheckBox hideCB;
  
  JCheckBox shrinkCB;
  
  JCheckBox pageBeforeCB;
  
  JCheckBox pageAfterCB;
  
  LineCombo topBorderCB;
  
  LineCombo leftBorderCB;
  
  LineCombo bottomBorderCB;
  
  LineCombo rightBorderCB;
  
  NumField heightTF;
  
  SectionTree tree;
  
  public SectionProperty(DesignView paramDesignView) {
    super(paramDesignView);
    this.treeListener = new TreeSelectionListener(this) {
        private final SectionProperty this$0;
        
        public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
          STree.Node node = this.this$0.tree.getSelectedNode();
          this.this$0.updateChanges();
          this.this$0.currband = (node != null) ? (SectionBand)node.getUserData() : null;
          this.this$0.populateOptions();
          this.this$0.setEnabled();
        }
      };
    this.changedListener = new ChangedListener(this);
    this.hideCB = new JCheckBox(Catalog.getString("Hide Band"));
    this.shrinkCB = new JCheckBox(Catalog.getString("Shrink to fit"));
    this.pageBeforeCB = new JCheckBox(Catalog.getString("New Page Before"));
    this.pageAfterCB = new JCheckBox(Catalog.getString("New Page After"));
    this.topBorderCB = new LineCombo();
    this.leftBorderCB = new LineCombo();
    this.bottomBorderCB = new LineCombo();
    this.rightBorderCB = new LineCombo();
    this.heightTF = new NumField(3, false);
    this.tree = new SectionTree();
    setTitle(Catalog.getString("Section Properties"));
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout(5, 5));
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout(5, 5));
    JScrollPane jScrollPane = new JScrollPane(this.tree);
    jScrollPane.setPreferredSize(new Dimension(180, 160));
    jPanel2.add(jScrollPane, "Center");
    Property2Panel property2Panel = new Property2Panel();
    property2Panel.add(Catalog.getString("Format"), new Object[][] { { this.hideCB, this.pageBeforeCB }, { this.shrinkCB, this.pageAfterCB }, { { Catalog.getString("Height") + '"', this.heightTF } } });
    property2Panel.add(Catalog.getString("Border"), new Object[][] { { Catalog.getString("Top") + ":", this.topBorderCB, Catalog.getString("Left") + ":", this.leftBorderCB }, { Catalog.getString("Bottom") + ":", this.bottomBorderCB, Catalog.getString("Right") + ":", this.rightBorderCB } });
    jPanel1.add(jPanel2, "West");
    jPanel1.add(property2Panel, "Center");
    getContentPane().add(jPanel1, "Center");
    this.tree.addTreeSelectionListener(this.treeListener);
    this.hideCB.addItemListener(this.changedListener);
    this.shrinkCB.addItemListener(this.changedListener);
    this.heightTF.getDocument().addDocumentListener(this.changedListener);
    this.pageBeforeCB.addItemListener(this.changedListener);
    this.pageAfterCB.addItemListener(this.changedListener);
    this.topBorderCB.addItemListener(this.changedListener);
    this.leftBorderCB.addItemListener(this.changedListener);
    this.bottomBorderCB.addItemListener(this.changedListener);
    this.rightBorderCB.addItemListener(this.changedListener);
  }
  
  private void setEnabled() {
    this.hideCB.setEnabled((this.currband != null));
    this.shrinkCB.setEnabled((this.currband != null));
    this.heightTF.setEnabled((this.currband != null));
    this.pageBeforeCB.setEnabled((this.currband != null));
    this.pageAfterCB.setEnabled((this.currband != null));
    this.topBorderCB.setEnabled((this.currband != null));
    this.leftBorderCB.setEnabled((this.currband != null));
    this.bottomBorderCB.setEnabled((this.currband != null));
    this.rightBorderCB.setEnabled((this.currband != null));
  }
  
  public void setElement(ReportElement paramReportElement) {
    this.elem = (SectionElement)paramReportElement;
    super.setElement(paramReportElement);
    this.tree.setSection(this.elem);
    this.currband = null;
    populateOptions();
    setEnabled();
    setChanged(false);
  }
  
  public boolean populateElement() {
    if (!super.populateElement())
      return false; 
    updateChanges();
    return true;
  }
  
  private void populateOptions() {
    this.hideCB.setSelected((this.currband == null || !this.currband.isVisible()));
    this.shrinkCB.setSelected((this.currband != null && this.currband.isShrinkToFit()));
    this.heightTF.setValue((this.currband == null) ? 0.0F : this.currband.getHeight());
    this.pageBeforeCB.setSelected((this.currband != null && this.currband.isPageBefore()));
    this.pageAfterCB.setSelected((this.currband != null && this.currband.isPageAfter()));
    this.topBorderCB.setSelectedLineStyle((this.currband != null) ? this.currband.getTopBorder() : 0);
    this.leftBorderCB.setSelectedLineStyle((this.currband != null) ? this.currband.getLeftBorder() : 0);
    this.bottomBorderCB.setSelectedLineStyle((this.currband != null) ? this.currband.getBottomBorder() : 0);
    this.rightBorderCB.setSelectedLineStyle((this.currband != null) ? this.currband.getRightBorder() : 0);
  }
  
  public void updateChanges() {
    if (this.currband != null && isChanged()) {
      this.currband.setVisible(!this.hideCB.isSelected());
      this.currband.setShrinkToFit(this.shrinkCB.isSelected());
      this.currband.setHeight(this.heightTF.floatValue());
      this.currband.setPageBefore(this.pageBeforeCB.isSelected());
      this.currband.setPageAfter(this.pageAfterCB.isSelected());
      this.currband.setTopBorder(this.topBorderCB.getSelectedLineStyle());
      this.currband.setLeftBorder(this.leftBorderCB.getSelectedLineStyle());
      this.currband.setBottomBorder(this.bottomBorderCB.getSelectedLineStyle());
      this.currband.setRightBorder(this.rightBorderCB.getSelectedLineStyle());
      setChanged(false);
    } 
  }
  
  class ChangedListener implements ItemListener, DocumentListener {
    private final SectionProperty this$0;
    
    ChangedListener(SectionProperty this$0) { this.this$0 = this$0; }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setChanged(true); }
    
    public void insertUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setChanged(true); }
    
    public void removeUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setChanged(true); }
    
    public void changedUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setChanged(true); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */