package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import inetsoft.report.StyleSheet;
import inetsoft.report.XStyleSheet;
import inetsoft.report.internal.Util;
import inetsoft.report.io.Builder;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.tree.TreeModel;

public class DesignFrame extends JInternalFrame implements DesignView {
  public DesignFrame() {
    this.filename = null;
    this.filedir = ".";
    getContentPane().setLayout(new BorderLayout());
    setDefaultCloseOperation(0);
    setClosable(true);
    setMaximizable(true);
    setIconifiable(true);
    setResizable(true);
    this.pane = createDesignPane();
    getContentPane().add(this.pane, "Center");
    addInternalFrameListener(new InternalFrameListener(this) {
          private final DesignFrame this$0;
          
          public void internalFrameOpened(InternalFrameEvent param1InternalFrameEvent) {}
          
          public void internalFrameClosing(InternalFrameEvent param1InternalFrameEvent) {
            if (this.this$0.isChanged())
              switch (JOptionPane.showConfirmDialog(this.this$0, DesignFrame.exitMsg)) {
                case 0:
                  if (this.this$0.save() == null)
                    return; 
                  break;
                case 2:
                  return;
              }  
            this.this$0.dispose();
          }
          
          public void internalFrameClosed(InternalFrameEvent param1InternalFrameEvent) {}
          
          public void internalFrameIconified(InternalFrameEvent param1InternalFrameEvent) {}
          
          public void internalFrameDeiconified(InternalFrameEvent param1InternalFrameEvent) {}
          
          public void internalFrameActivated(InternalFrameEvent param1InternalFrameEvent) {}
          
          public void internalFrameDeactivated(InternalFrameEvent param1InternalFrameEvent) {}
        });
  }
  
  protected DesignPane createDesignPane() { return new DesignPane(); }
  
  public StyleSheet getStyleSheet() { return this.pane.getStyleSheet(); }
  
  public void setDesignSession(DesignSession paramDesignSession) { this.xsession = paramDesignSession; }
  
  public void refresh() {
    refreshMetaData(getStyleSheet());
    print(getStyleSheet());
  }
  
  public void refreshMetaData(StyleSheet paramStyleSheet) throws Exception { this.xsession.populateMetaData(paramStyleSheet); }
  
  public void setPageWidth(double paramDouble) { this.pane.setPageWidth(paramDouble); }
  
  public double getPageWidth() { return this.pane.getPageWidth(); }
  
  public void setPageHeight(double paramDouble) { this.pane.setPageHeight(paramDouble); }
  
  public double getPageHeight() { return this.pane.getPageHeight(); }
  
  public void setPageSize(Size paramSize) { this.pane.setPageSize(paramSize); }
  
  public void setOrientation(int paramInt) { this.pane.setOrientation(paramInt); }
  
  public int getOrientation() { return this.pane.getOrientation(); }
  
  public void setPageResolution(int paramInt) { this.pane.setPageResolution(paramInt); }
  
  public int getPageResolution() { return this.pane.getPageResolution(); }
  
  public void setShowGrid(boolean paramBoolean) { this.pane.setShowGrid(paramBoolean); }
  
  public boolean isShowGrid() { return this.pane.isShowGrid(); }
  
  public void setShowRuler(boolean paramBoolean) { this.pane.setShowRuler(paramBoolean); }
  
  public boolean isShowRuler() { return this.pane.isShowRuler(); }
  
  public void setCurrentFont(Font paramFont) { this.pane.setCurrentFont(paramFont); }
  
  public void setCurrentAlignment(int paramInt) { this.pane.setCurrentAlignment(paramInt); }
  
  public void setCurrentJustify(boolean paramBoolean) { this.pane.setCurrentJustify(paramBoolean); }
  
  public void align(int paramInt) { this.pane.align(paramInt); }
  
  public void distribute(int paramInt) { this.pane.distribute(paramInt); }
  
  public void changeSizes(int paramInt1, int paramInt2) { this.pane.changeSizes(paramInt1, paramInt2); }
  
  public void setTextMode(boolean paramBoolean) { this.pane.setTextMode(paramBoolean); }
  
  public boolean isTextMode() { return this.pane.isTextMode(); }
  
  public int getUndoCount() { return this.pane.getUndoCount(); }
  
  public void undo() { this.pane.undo(); }
  
  public void setEditArea(boolean paramBoolean) { this.pane.setEditArea(paramBoolean); }
  
  public void setEditArea(String paramString) { this.pane.setEditArea(paramString); }
  
  public boolean isEditArea() { return this.pane.isEditArea(); }
  
  public void setTarget(int paramInt) { this.pane.setTarget(paramInt); }
  
  public int getTarget() { return this.pane.getTarget(); }
  
  public void print(StyleSheet paramStyleSheet) throws Exception {
    try {
      if (paramStyleSheet != getStyleSheet())
        refreshMetaData(paramStyleSheet); 
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(this, exception.toString());
    } 
    this.pane.print(paramStyleSheet);
  }
  
  public boolean isChanged() { return this.pane.isChanged(); }
  
  public void setChanged(boolean paramBoolean) { this.pane.setChanged(paramBoolean); }
  
  public UndoMgr getUndoMgr() { return this.pane.getUndoMgr(); }
  
  public void insertTable(int paramInt1, int paramInt2, boolean paramBoolean) { this.pane.insertTable(paramInt1, paramInt2, paramBoolean); }
  
  public void insertText(boolean paramBoolean) { this.pane.insertText(paramBoolean); }
  
  public void insertTextBox(boolean paramBoolean) { this.pane.insertTextBox(paramBoolean); }
  
  public void insertSection(boolean paramBoolean) { this.pane.insertSection(paramBoolean); }
  
  public void insertChart(int paramInt, boolean paramBoolean) { this.pane.insertChart(paramInt, paramBoolean); }
  
  public void insertImage(boolean paramBoolean) { this.pane.insertImage(paramBoolean); }
  
  public void insertPainter(boolean paramBoolean) { this.pane.insertPainter(paramBoolean); }
  
  public void insertContainer(boolean paramBoolean) { this.pane.insertContainer(paramBoolean); }
  
  public void insertTOC(boolean paramBoolean) { this.pane.insertTOC(paramBoolean); }
  
  public void insertHeading(int paramInt, boolean paramBoolean) { this.pane.insertHeading(paramInt, paramBoolean); }
  
  public void insertSeparator(boolean paramBoolean) { this.pane.insertSeparator(paramBoolean); }
  
  public void insertBullet(boolean paramBoolean) { this.pane.insertBullet(paramBoolean); }
  
  public void insertTab(boolean paramBoolean) { this.pane.insertTab(paramBoolean); }
  
  public void insertLinefeed(boolean paramBoolean) { this.pane.insertLinefeed(paramBoolean); }
  
  public void insertBreak(boolean paramBoolean) { this.pane.insertBreak(paramBoolean); }
  
  public void insertSpace(boolean paramBoolean) { this.pane.insertSpace(paramBoolean); }
  
  public void insertPageBreak(boolean paramBoolean) { this.pane.insertPageBreak(paramBoolean); }
  
  public void insertCondPageBreak(boolean paramBoolean) { this.pane.insertCondPageBreak(paramBoolean); }
  
  public void insertAreaBreak(boolean paramBoolean) { this.pane.insertAreaBreak(paramBoolean); }
  
  public void insertArea(boolean paramBoolean) { this.pane.insertArea(paramBoolean); }
  
  public void insert(ReportElement paramReportElement, boolean paramBoolean) { this.pane.insert(paramReportElement, paramBoolean); }
  
  public void copy() { this.pane.copy(); }
  
  public void cut() { this.pane.cut(); }
  
  public void paste() { this.pane.paste(); }
  
  public boolean isPasteable() { return this.pane.isPasteable(); }
  
  public void orderAreas(boolean paramBoolean) { this.pane.orderAreas(paramBoolean); }
  
  public void setColumns(int paramInt) { this.pane.setColumns(paramInt); }
  
  public ReportElement getCurrent() { return this.pane.getCurrent(); }
  
  public ReportElement[] getSelectedElements() { return this.pane.getSelectedElements(); }
  
  public void setSelectedElements(ReportElement[] paramArrayOfReportElement) { this.pane.setSelectedElements(paramArrayOfReportElement); }
  
  public boolean isAlignable() { return this.pane.isAlignable(); }
  
  public boolean isDistributable() { return this.pane.isDistributable(); }
  
  public DesignPane.DesignPage getCurrentPage() { return this.pane.getCurrentPage(); }
  
  public JPopupMenu getPopupMenu(Point paramPoint) { return this.pane.getPopupMenu(paramPoint); }
  
  public void showProperty() { this.pane.showProperty(); }
  
  public void editScript() { this.pane.editScript(); }
  
  public void showPageNumber(int paramInt) { this.pane.showPageNumber(paramInt); }
  
  public void showPageSize(Size paramSize) { this.pane.showPageSize(paramSize); }
  
  public void showStatus(String paramString) { this.pane.showStatus(paramString); }
  
  public void reprint(ReportElement paramReportElement) { this.pane.reprint(paramReportElement); }
  
  public int getPageCount() { return this.pane.getPageCount(); }
  
  public ReportElement getElement(String paramString) { return this.pane.getElement(paramString); }
  
  public TreeModel getTreeModel(JTree paramJTree) { return this.pane.getTreeModel(paramJTree); }
  
  public Object[] getSelectedObjects() { return this.pane.getSelectedObjects(); }
  
  public void addItemListener(ItemListener paramItemListener) { this.pane.addItemListener(paramItemListener); }
  
  public void removeItemListener(ItemListener paramItemListener) { this.pane.removeItemListener(paramItemListener); }
  
  public void fireEvent() { this.pane.fireEvent(); }
  
  public void setFileName(String paramString) {
    this.filename = paramString;
    setTitle((this.filename == null) ? "" : this.filename);
  }
  
  public String getFileName() { return this.filename; }
  
  public void setDirectory(String paramString) {
    this.filedir = paramString;
    if (this.filedir != null)
      DesignEnv.setProperty("work.directory", this.filedir); 
  }
  
  public void rename(String paramString1, String paramString2) { this.pane.rename(paramString1, paramString2); }
  
  public String save() {
    if (this.filename == null)
      return saveAs(); 
    return save(this.filename) ? this.filename : null;
  }
  
  public String saveAs() {
    File file = promptFile("Save Template", false);
    if (file != null)
      try {
        boolean bool = save(file.getPath());
        setTitle(Catalog.getString("Report Designer") + " - " + this.filename);
        return file.getPath();
      } catch (Exception exception) {
        exception.printStackTrace();
        JOptionPane.showMessageDialog(this, exception.toString(), Catalog.getString("Error"), 0);
      }  
    return null;
  }
  
  public boolean save(String paramString) {
    String str = Util.findDuplicate(this.pane.getStyleSheet(), false);
    if (str != null)
      switch (JOptionPane.showConfirmDialog(this, dupMsg + str)) {
        case 0:
          Util.findDuplicate(this.pane.getStyleSheet(), true);
          this.pane.reprint(null);
          break;
        default:
          return false;
      }  
    File file = new File(paramString + "." + (System.currentTimeMillis() % 1000L));
    FileOutputStream fileOutputStream = null;
    this.filename = paramString;
    this.filedir = file.getParent();
    if (this.filedir == null)
      this.filedir = "."; 
    DesignEnv.setProperty("work.directory", this.filedir);
    try {
      fileOutputStream = new FileOutputStream(file);
      Builder builder = Builder.getBuilder(1, fileOutputStream);
      builder.setEmbeddedStyles(StyleTree.getUserStyles());
      ((XStyleSheet)this.pane.getStyleSheet()).setDirectory((this.filedir == null) ? "." : this.filedir);
      this.pane.getStyleSheet().setProperty("TextMode", "" + this.pane.isTextMode());
      builder.write(this.pane.getStyleSheet());
      this.pane.setChanged(false);
      fileOutputStream.close();
      File file1 = new File(paramString);
      file1.delete();
      if (!file.renameTo(file1)) {
        String str1 = "Failed to save template to " + file1 + ". File may be in use!";
        JOptionPane.showMessageDialog(this, str1, Catalog.getString("Error"), 0);
        file.delete();
        return false;
      } 
    } catch (Exception exception) {
      if (fileOutputStream != null)
        try {
          fileOutputStream.close();
        } catch (IOException iOException) {} 
      file.delete();
      exception.printStackTrace();
      JOptionPane.showMessageDialog(this, exception.toString(), Catalog.getString("Error"), 0);
      return false;
    } 
    return true;
  }
  
  public File promptFile(String paramString, boolean paramBoolean) { return promptFile(paramString, paramBoolean, this.filedir); }
  
  public static File promptFile(String paramString1, boolean paramBoolean, String paramString2) {
    JFileChooser jFileChooser = new JFileChooser();
    jFileChooser.setDialogTitle(Catalog.getString(paramString1));
    if (paramString2 == null)
      paramString2 = DesignEnv.getProperty("work.directory"); 
    if (paramString2 != null)
      jFileChooser.setCurrentDirectory(new File(paramString2)); 
    int i = paramBoolean ? jFileChooser.showOpenDialog(null) : jFileChooser.showSaveDialog(null);
    return (i != 0) ? null : jFileChooser.getSelectedFile();
  }
  
  static String exitMsg = Catalog.getString("Unsaved changes. Save before closing?");
  
  static String dupMsg = Catalog.getString("Duplicate ReportElement ID, automatically fix? - ");
  
  String filename;
  
  String filedir;
  
  DesignPane pane;
  
  DesignSession xsession;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DesignFrame.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */