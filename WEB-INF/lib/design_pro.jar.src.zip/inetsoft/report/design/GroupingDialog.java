/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.internal.GroupAttr;
/*     */ import inetsoft.report.internal.Groupable;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.Grid2Layout;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.TitledBorder;
/*     */ 
/*     */ class GroupingDialog
/*     */   extends JDialog {
/*     */   ActionListener cbListener;
/*     */   ActionListener okListener;
/*     */   ActionListener removeListener;
/*     */   ActionListener cancelListener;
/*     */   JCheckBox grandCB;
/*     */   JCheckBox groupHeaderCB;
/*     */   JCheckBox groupColumnCB;
/*     */   JRadioButton inplaceCB;
/*     */   JRadioButton headerRowCB;
/*     */   
/*     */   public static void show(Groupable paramGroupable, ActionListener paramActionListener) {
/*  38 */     GroupingDialog groupingDialog = new GroupingDialog(paramGroupable);
/*  39 */     groupingDialog.setActionListener(paramActionListener);
/*  40 */     groupingDialog.pack();
/*  41 */     groupingDialog.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   JCheckBox breakCB;
/*     */   JTextField grandTF;
/*     */   
/*     */   public static boolean show(Groupable paramGroupable) {
/*  49 */     GroupingDialog groupingDialog = new GroupingDialog(paramGroupable);
/*  50 */     groupingDialog.setModal(true);
/*  51 */     groupingDialog.pack();
/*  52 */     groupingDialog.setVisible(true);
/*     */     
/*  54 */     return groupingDialog.changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JButton okB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JButton removeB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JButton cancelB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SummaryPane summary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ActionListener listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Groupable xtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   GroupAttr group;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean changed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GroupingDialog(Groupable paramGroupable) {
/* 172 */     this.cbListener = new ActionListener(this)
/*     */       {
/* 174 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.setEnabled(); }
/*     */         
/*     */         private final GroupingDialog this$0;
/*     */       };
/* 178 */     this.okListener = new ActionListener(this) { private final GroupingDialog this$0;
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 180 */           this.this$0.update();
/*     */           
/* 182 */           if (this.this$0.group.getGroupCols().length > 0) {
/* 183 */             this.this$0.xtable.setFilter(this.this$0.group);
/* 184 */             this.this$0.changed = true;
/*     */           } 
/*     */           
/* 187 */           if (this.this$0.listener != null) {
/* 188 */             this.this$0.listener.actionPerformed(param1ActionEvent);
/*     */           }
/*     */           
/* 191 */           this.this$0.dispose();
/*     */         } }
/*     */       ;
/*     */     
/* 195 */     this.removeListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 197 */           this.this$0.xtable.setFilter(null);
/* 198 */           this.this$0.changed = true;
/* 199 */           this.this$0.dispose();
/*     */         }
/*     */         private final GroupingDialog this$0;
/*     */       };
/* 203 */     this.cancelListener = new ActionListener(this) { private final GroupingDialog this$0;
/*     */         
/* 205 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */          }
/*     */       ;
/*     */     
/* 209 */     this.grandCB = new JCheckBox(Catalog.getString("Grand Total"));
/* 210 */     this.groupHeaderCB = new JCheckBox(Catalog.getString("Add Group Header"));
/*     */     
/* 212 */     this.groupColumnCB = new JCheckBox(Catalog.getString("Show Group Column"));
/*     */     
/* 214 */     this.inplaceCB = new JRadioButton(Catalog.getString("In-place"));
/* 215 */     this.headerRowCB = new JRadioButton(Catalog.getString("Add Header Row"));
/*     */     
/* 217 */     this.breakCB = new JCheckBox(Catalog.getString("Page Break After Section"));
/*     */     
/* 219 */     this.grandTF = new JTextField(10);
/*     */     
/* 221 */     this.okB = new JButton(Catalog.getString("OK"));
/* 222 */     this.removeB = new JButton(Catalog.getString("Remove Grouping"));
/* 223 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*     */     
/* 225 */     this.summary = new SummaryPane(false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     this.changed = false;
/*     */     this.xtable = paramGroupable;
/*     */     setTitle(Catalog.getString("Table Grouping"));
/*     */     getContentPane().setLayout(new BorderLayout(5, 5));
/*     */     JTabbedPane jTabbedPane = new JTabbedPane();
/*     */     jTabbedPane.add(this.summary, Catalog.getString("Grouping"));
/*     */     JPanel jPanel1 = new JPanel();
/*     */     Grid2Layout grid2Layout = new Grid2Layout();
/*     */     jPanel1.setLayout(grid2Layout);
/*     */     jPanel1.setBorder(new TitledBorder(Catalog.getString("Header Style")));
/*     */     jPanel1.add(this.inplaceCB, grid2Layout.at(0, 0));
/*     */     jPanel1.add(this.headerRowCB, grid2Layout.at(1, 0));
/*     */     byte b1 = 17;
/*     */     byte b2 = 20;
/*     */     byte b3 = 18;
/*     */     Insets insets = new Insets(5, 5, 5, 5);
/*     */     JPanel jPanel2 = new JPanel();
/*     */     jPanel2.setLayout(grid2Layout = new Grid2Layout());
/*     */     jPanel2.add(this.groupHeaderCB, grid2Layout.at(0, 0));
/*     */     jPanel2.add(this.groupColumnCB, grid2Layout.at(1, 0));
/*     */     jPanel2.add(jPanel1, grid2Layout.at(0, 1, 2, 2, b3));
/*     */     jPanel2.add(this.breakCB, grid2Layout.at(2, 0, 1, 2));
/*     */     jPanel2.add(this.grandCB, grid2Layout.at(3, 0));
/*     */     jPanel2.add(new JLabel(Catalog.getString("Grand Total Label") + ":"), grid2Layout.at(3, 1, 1, 1, b2, insets));
/*     */     jPanel2.add(this.grandTF, grid2Layout.at(3, 2, 1, 1, b1));
/*     */     if (!(paramGroupable instanceof inetsoft.report.internal.SectionXElement))
/*     */       jTabbedPane.add(jPanel2, Catalog.getString("Style")); 
/*     */     getContentPane().add(jTabbedPane, "Center");
/*     */     jPanel2 = new JPanel();
/*     */     jPanel2.add(this.okB);
/*     */     jPanel2.add(this.removeB);
/*     */     jPanel2.add(this.cancelB);
/*     */     getContentPane().add(jPanel2, "South");
/*     */     ButtonGroup buttonGroup = new ButtonGroup();
/*     */     buttonGroup.add(this.inplaceCB);
/*     */     buttonGroup.add(this.headerRowCB);
/*     */     populate();
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.removeB.addActionListener(this.removeListener);
/*     */     this.cancelB.addActionListener(this.cancelListener);
/*     */     this.groupHeaderCB.addActionListener(this.cbListener);
/*     */     setEnabled();
/*     */     addWindowListener(new WindowAdapter(this) {
/*     */           private final GroupingDialog this$0;
/*     */           
/*     */           public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.dispose(); }
/*     */         });
/*     */   }
/*     */   
/*     */   public void setActionListener(ActionListener paramActionListener) { this.listener = paramActionListener; }
/*     */   
/*     */   private void setEnabled() {
/*     */     this.inplaceCB.setEnabled(this.groupHeaderCB.isSelected());
/*     */     this.headerRowCB.setEnabled(this.groupHeaderCB.isSelected());
/*     */   }
/*     */   
/*     */   private void populate() {
/*     */     TableLens tableLens = this.xtable.getRootTable();
/*     */     this.group = (this.xtable.getFilter() instanceof GroupAttr) ? (GroupAttr)this.xtable.getFilter() : new GroupAttr();
/*     */     this.summary.populate(tableLens, this.group);
/*     */     this.grandCB.setSelected(this.group.isGrandTotal());
/*     */     this.groupHeaderCB.setSelected(this.group.isShowHeader());
/*     */     this.groupColumnCB.setSelected(this.group.isShowGroupCols());
/*     */     this.inplaceCB.setSelected(this.group.isInPlaceHeader());
/*     */     this.headerRowCB.setSelected(!this.inplaceCB.isSelected());
/*     */     this.breakCB.setSelected(this.group.isBreakAfter());
/*     */     this.grandTF.setText((this.group.getGrandLabel() != null) ? this.group.getGrandLabel() : "");
/*     */   }
/*     */   
/*     */   private void update() {
/*     */     this.summary.update();
/*     */     this.group.setGrandTotal(this.grandCB.isSelected());
/*     */     this.group.setShowHeader(this.groupHeaderCB.isSelected());
/*     */     this.group.setShowGroupCols(this.groupColumnCB.isSelected());
/*     */     this.group.setInPlaceHeader(this.inplaceCB.isSelected());
/*     */     this.group.setBreakAfter(this.breakCB.isSelected());
/*     */     this.group.setGrandLabel((this.grandTF.getText().length() > 0) ? this.grandTF.getText() : null);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\GroupingDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */