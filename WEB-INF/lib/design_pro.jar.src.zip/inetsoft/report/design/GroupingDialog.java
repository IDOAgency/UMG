package inetsoft.report.design;

import inetsoft.report.TableLens;
import inetsoft.report.internal.GroupAttr;
import inetsoft.report.internal.Groupable;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.Grid2Layout;
import java.awt.BorderLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

class GroupingDialog extends JDialog {
  ActionListener cbListener;
  
  ActionListener okListener;
  
  ActionListener removeListener;
  
  ActionListener cancelListener;
  
  JCheckBox grandCB;
  
  JCheckBox groupHeaderCB;
  
  JCheckBox groupColumnCB;
  
  JRadioButton inplaceCB;
  
  JRadioButton headerRowCB;
  
  JCheckBox breakCB;
  
  JTextField grandTF;
  
  JButton okB;
  
  JButton removeB;
  
  JButton cancelB;
  
  SummaryPane summary;
  
  ActionListener listener;
  
  Groupable xtable;
  
  GroupAttr group;
  
  boolean changed;
  
  public static void show(Groupable paramGroupable, ActionListener paramActionListener) {
    GroupingDialog groupingDialog = new GroupingDialog(paramGroupable);
    groupingDialog.setActionListener(paramActionListener);
    groupingDialog.pack();
    groupingDialog.setVisible(true);
  }
  
  public static boolean show(Groupable paramGroupable) {
    GroupingDialog groupingDialog = new GroupingDialog(paramGroupable);
    groupingDialog.setModal(true);
    groupingDialog.pack();
    groupingDialog.setVisible(true);
    return groupingDialog.changed;
  }
  
  public GroupingDialog(Groupable paramGroupable) {
    this.cbListener = new ActionListener(this) {
        private final GroupingDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.setEnabled(); }
      };
    this.okListener = new ActionListener(this) {
        private final GroupingDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.update();
          if (this.this$0.group.getGroupCols().length > 0) {
            this.this$0.xtable.setFilter(this.this$0.group);
            this.this$0.changed = true;
          } 
          if (this.this$0.listener != null)
            this.this$0.listener.actionPerformed(param1ActionEvent); 
          this.this$0.dispose();
        }
      };
    this.removeListener = new ActionListener(this) {
        private final GroupingDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.xtable.setFilter(null);
          this.this$0.changed = true;
          this.this$0.dispose();
        }
      };
    this.cancelListener = new ActionListener(this) {
        private final GroupingDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.grandCB = new JCheckBox(Catalog.getString("Grand Total"));
    this.groupHeaderCB = new JCheckBox(Catalog.getString("Add Group Header"));
    this.groupColumnCB = new JCheckBox(Catalog.getString("Show Group Column"));
    this.inplaceCB = new JRadioButton(Catalog.getString("In-place"));
    this.headerRowCB = new JRadioButton(Catalog.getString("Add Header Row"));
    this.breakCB = new JCheckBox(Catalog.getString("Page Break After Section"));
    this.grandTF = new JTextField(10);
    this.okB = new JButton(Catalog.getString("OK"));
    this.removeB = new JButton(Catalog.getString("Remove Grouping"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.summary = new SummaryPane(false);
    this.changed = false;
    this.xtable = paramGroupable;
    setTitle(Catalog.getString("Table Grouping"));
    getContentPane().setLayout(new BorderLayout(5, 5));
    JTabbedPane jTabbedPane = new JTabbedPane();
    jTabbedPane.add(this.summary, Catalog.getString("Grouping"));
    JPanel jPanel1 = new JPanel();
    Grid2Layout grid2Layout = new Grid2Layout();
    jPanel1.setLayout(grid2Layout);
    jPanel1.setBorder(new TitledBorder(Catalog.getString("Header Style")));
    jPanel1.add(this.inplaceCB, grid2Layout.at(0, 0));
    jPanel1.add(this.headerRowCB, grid2Layout.at(1, 0));
    byte b1 = 17;
    byte b2 = 20;
    byte b3 = 18;
    Insets insets = new Insets(5, 5, 5, 5);
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(grid2Layout = new Grid2Layout());
    jPanel2.add(this.groupHeaderCB, grid2Layout.at(0, 0));
    jPanel2.add(this.groupColumnCB, grid2Layout.at(1, 0));
    jPanel2.add(jPanel1, grid2Layout.at(0, 1, 2, 2, b3));
    jPanel2.add(this.breakCB, grid2Layout.at(2, 0, 1, 2));
    jPanel2.add(this.grandCB, grid2Layout.at(3, 0));
    jPanel2.add(new JLabel(Catalog.getString("Grand Total Label") + ":"), grid2Layout.at(3, 1, 1, 1, b2, insets));
    jPanel2.add(this.grandTF, grid2Layout.at(3, 2, 1, 1, b1));
    if (!(paramGroupable instanceof inetsoft.report.internal.SectionXElement))
      jTabbedPane.add(jPanel2, Catalog.getString("Style")); 
    getContentPane().add(jTabbedPane, "Center");
    jPanel2 = new JPanel();
    jPanel2.add(this.okB);
    jPanel2.add(this.removeB);
    jPanel2.add(this.cancelB);
    getContentPane().add(jPanel2, "South");
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(this.inplaceCB);
    buttonGroup.add(this.headerRowCB);
    populate();
    this.okB.addActionListener(this.okListener);
    this.removeB.addActionListener(this.removeListener);
    this.cancelB.addActionListener(this.cancelListener);
    this.groupHeaderCB.addActionListener(this.cbListener);
    setEnabled();
    addWindowListener(new WindowAdapter(this) {
          private final GroupingDialog this$0;
          
          public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.dispose(); }
        });
  }
  
  public void setActionListener(ActionListener paramActionListener) { this.listener = paramActionListener; }
  
  private void setEnabled() {
    this.inplaceCB.setEnabled(this.groupHeaderCB.isSelected());
    this.headerRowCB.setEnabled(this.groupHeaderCB.isSelected());
  }
  
  private void populate() {
    TableLens tableLens = this.xtable.getRootTable();
    this.group = (this.xtable.getFilter() instanceof GroupAttr) ? (GroupAttr)this.xtable.getFilter() : new GroupAttr();
    this.summary.populate(tableLens, this.group);
    this.grandCB.setSelected(this.group.isGrandTotal());
    this.groupHeaderCB.setSelected(this.group.isShowHeader());
    this.groupColumnCB.setSelected(this.group.isShowGroupCols());
    this.inplaceCB.setSelected(this.group.isInPlaceHeader());
    this.headerRowCB.setSelected(!this.inplaceCB.isSelected());
    this.breakCB.setSelected(this.group.isBreakAfter());
    this.grandTF.setText((this.group.getGrandLabel() != null) ? this.group.getGrandLabel() : "");
  }
  
  private void update() {
    this.summary.update();
    this.group.setGrandTotal(this.grandCB.isSelected());
    this.group.setShowHeader(this.groupHeaderCB.isSelected());
    this.group.setShowGroupCols(this.groupColumnCB.isSelected());
    this.group.setInPlaceHeader(this.inplaceCB.isSelected());
    this.group.setBreakAfter(this.breakCB.isSelected());
    this.group.setGrandLabel((this.grandTF.getText().length() > 0) ? this.grandTF.getText() : null);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\GroupingDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */