/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.Common;
/*    */ import inetsoft.report.PreviewPane;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.XSessionManager;
/*    */ import java.awt.BorderLayout;
/*    */ import javax.swing.JInternalFrame;
/*    */ import javax.swing.JOptionPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PreviewFrame
/*    */   extends JInternalFrame
/*    */ {
/*    */   PreviewPane pane;
/*    */   XSessionManager xsession;
/*    */   
/*    */   public PreviewFrame(XSessionManager paramXSessionManager) {
/* 68 */     this.pane = null;
/*    */     this.xsession = paramXSessionManager;
/*    */     setClosable(true);
/*    */     setMaximizable(true);
/*    */     setIconifiable(true);
/*    */     setResizable(true);
/*    */     if (Common.isJava2())
/*    */       try {
/*    */         this.pane = (PreviewPane)Class.forName("inetsoft.report.j2d.PreviewPane2D").newInstance();
/*    */       } catch (Exception exception) {
/*    */         exception.printStackTrace();
/*    */       }  
/*    */     if (this.pane == null)
/*    */       this.pane = new PreviewPane(); 
/*    */     getContentPane().setLayout(new BorderLayout());
/*    */     getContentPane().add(this.pane, "Center");
/*    */   }
/*    */   
/*    */   public void print(StyleSheet paramStyleSheet) {
/*    */     try {
/*    */       if (!this.xsession.execute(paramStyleSheet))
/*    */         return; 
/*    */     } catch (Exception exception) {
/*    */       exception.printStackTrace();
/*    */       JOptionPane.showMessageDialog(this, exception.toString());
/*    */     } 
/*    */     this.pane.print(paramStyleSheet);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\PreviewFrame.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */