/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.TOC;
/*     */ import inetsoft.report.internal.TOCElementDef;
/*     */ import inetsoft.report.internal.j2d.PropertyPanel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import javax.swing.JComboBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TOCProperty
/*     */   extends PropertyDialog
/*     */ {
/*     */   FontCanvas font;
/*     */   JComboBox style;
/*     */   TOCElementDef elem;
/*     */   
/*     */   public TOCProperty(DesignView paramDesignView) {
/*  35 */     super(paramDesignView);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     this.font = new FontCanvas();
/* 101 */     this.style = new JComboBox(stylestr); setTitle(Catalog.getString("TOC Properties"));
/*     */     PropertyPanel propertyPanel = new PropertyPanel();
/*     */     Object[][] arrayOfObject = { { Catalog.getString("Font") + ":", this.font }, { Catalog.getString("Style") + ":", this.style } };
/*     */     propertyPanel.setFields(arrayOfObject);
/* 105 */     this.folder.addTab(Catalog.getString("Table Of Contents"), null, propertyPanel, Catalog.getString("Table Of Contents")); } static final String[] stylestr = { Catalog.getString("Default"), Catalog.getString("Classic"), Catalog.getString("Distinctive"), Catalog.getString("Fancy"), Catalog.getString("Modern"), Catalog.getString("Formal"), Catalog.getString("Simple") };
/*     */   public void setElement(ReportElement paramReportElement) { this.elem = (TOCElementDef)paramReportElement; super.setElement(paramReportElement); this.font.setDisplayFont(paramReportElement.getFont()); TOC tOC = this.elem.getTOC(); byte b = 0; if (tOC instanceof TOC.Default)
/*     */       b = 0;  if (tOC instanceof TOC.Classic)
/*     */       b = 1;  if (tOC instanceof TOC.Distinctive)
/*     */       b = 2;  if (tOC instanceof TOC.Fancy)
/*     */       b = 3;  if (tOC instanceof TOC.Modern)
/*     */       b = 4;  if (tOC instanceof TOC.Formal)
/*     */       b = 5;  if (tOC instanceof TOC.Simple)
/*     */       b = 6;  this.style.setSelectedIndex(b); }
/*     */   public boolean populateElement() { if (!super.populateElement())
/* 115 */       return false;  this.elem.setFont(this.font.getDisplayFont()); this.elem.setTOC(styleobjs[this.style.getSelectedIndex()]); return true; } static final TOC[] styleobjs = { TOC.DEFAULT, TOC.CLASSIC, TOC.DISTINCTIVE, TOC.FANCY, TOC.MODERN, TOC.FORMAL, TOC.SIMPLE };
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TOCProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */