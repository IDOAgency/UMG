package inetsoft.report.design;

import inetsoft.report.internal.TableXElement;
import inetsoft.report.locale.Catalog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ColFormatListener implements ActionListener {
  DesignPane pane;
  
  TableXElement xtable;
  
  int index;
  
  String format;
  
  String spec;
  
  public ColFormatListener(DesignPane paramDesignPane, TableXElement paramTableXElement, int paramInt, String paramString1, String paramString2) {
    this.pane = paramDesignPane;
    this.xtable = paramTableXElement;
    this.index = paramInt;
    this.format = paramString1;
    this.spec = paramString2;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (this.format != null && (this.format.equals("DateFormat") || this.format.equals("DecimalFormat")))
      this.spec = InputDialog.show(Catalog.getString("Format") + ":", this.spec); 
    this.xtable.setColFormat(this.index, this.format, (this.spec != null && this.spec.length() > 0) ? this.spec : null);
    this.pane.reprint(this.xtable);
    this.pane.setChanged(true);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ColFormatListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */