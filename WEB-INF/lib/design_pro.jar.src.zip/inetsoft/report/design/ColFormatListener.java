/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.internal.TableXElement;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ColFormatListener
/*     */   implements ActionListener
/*     */ {
/*     */   DesignPane pane;
/*     */   TableXElement xtable;
/*     */   int index;
/*     */   String format;
/*     */   String spec;
/*     */   
/*     */   public ColFormatListener(DesignPane paramDesignPane, TableXElement paramTableXElement, int paramInt, String paramString1, String paramString2) {
/* 112 */     this.pane = paramDesignPane;
/* 113 */     this.xtable = paramTableXElement;
/* 114 */     this.index = paramInt;
/* 115 */     this.format = paramString1;
/* 116 */     this.spec = paramString2;
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent paramActionEvent) {
/* 120 */     if (this.format != null && (this.format.equals("DateFormat") || this.format.equals("DecimalFormat")))
/*     */     {
/* 122 */       this.spec = InputDialog.show(Catalog.getString("Format") + ":", this.spec);
/*     */     }
/*     */     
/* 125 */     this.xtable.setColFormat(this.index, this.format, (this.spec != null && this.spec.length() > 0) ? this.spec : null);
/*     */     
/* 127 */     this.pane.reprint(this.xtable);
/* 128 */     this.pane.setChanged(true);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ColFormatListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */