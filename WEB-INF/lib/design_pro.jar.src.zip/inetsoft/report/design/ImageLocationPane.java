/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.internal.ImageLocation;
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.io.File;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ImageLocationPane
/*     */   extends Property2Panel
/*     */ {
/*     */   ImageLocation iloc;
/*     */   JRadioButton resource;
/*     */   JRadioButton url;
/*     */   JRadioButton relpath;
/*     */   JRadioButton fullpath;
/*     */   ButtonGroup group;
/*     */   JCheckBox embed;
/*     */   JTextField path;
/*     */   JButton browseB;
/*     */   File filedir;
/*     */   
/*     */   public ImageLocationPane() {
/* 138 */     this.resource = new JRadioButton(Catalog.getString("Resource"));
/* 139 */     this.url = new JRadioButton(Catalog.getString("URL"));
/* 140 */     this.relpath = new JRadioButton(Catalog.getString("Relative Path"));
/* 141 */     this.fullpath = new JRadioButton(Catalog.getString("Full Path"));
/* 142 */     this.group = new ButtonGroup();
/* 143 */     this.embed = new JCheckBox(Catalog.getString("Embed Image"));
/* 144 */     this.path = new JTextField(20);
/* 145 */     this.browseB = new JButton(Catalog.getString("Browse"));
/* 146 */     this.filedir = null;
/*     */     this.filedir = new File(DesignEnv.getProperty("image.dir", "."));
/*     */     add(Catalog.getString("Image"), new Object[][] { { this.path, this.browseB } });
/*     */     add(Catalog.getString("Source"), new Object[][] { { this.resource, this.url, this.relpath, this.fullpath }, { this.embed } });
/*     */     this.group.add(this.resource);
/*     */     this.group.add(this.url);
/*     */     this.group.add(this.relpath);
/*     */     this.group.add(this.fullpath);
/*     */     ItemListener itemListener = new ItemListener(this) {
/*     */         private final ImageLocationPane this$0;
/*     */         
/*     */         public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.browseB.setEnabled((!this.this$0.resource.isSelected() && !this.this$0.url.isSelected())); }
/*     */       };
/*     */     this.resource.addItemListener(itemListener);
/*     */     this.url.addItemListener(itemListener);
/*     */     this.browseB.addActionListener(new ActionListener(this) {
/*     */           private final ImageLocationPane this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */             JFileChooser jFileChooser = new JFileChooser();
/*     */             jFileChooser.setDialogTitle(Catalog.getString("Find Image"));
/*     */             if (this.this$0.filedir != null)
/*     */               jFileChooser.setCurrentDirectory(this.this$0.filedir); 
/*     */             if (jFileChooser.showOpenDialog(null) == 0) {
/*     */               File file = jFileChooser.getSelectedFile();
/*     */               this.this$0.filedir = new File(file.getParent());
/*     */               DesignEnv.setProperty("image.dir", this.this$0.filedir.getAbsolutePath());
/*     */               this.this$0.path.setText(file.getPath());
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public void setImageLocation(ImageLocation paramImageLocation) {
/*     */     this.iloc = paramImageLocation;
/*     */     if (paramImageLocation != null) {
/*     */       switch (paramImageLocation.getPathType()) {
/*     */         case 1:
/*     */           this.fullpath.setSelected(true);
/*     */           break;
/*     */         case 2:
/*     */           this.relpath.setSelected(true);
/*     */           break;
/*     */         case 3:
/*     */           this.resource.setSelected(true);
/*     */           break;
/*     */         case 4:
/*     */           this.url.setSelected(true);
/*     */           break;
/*     */       } 
/*     */       this.embed.setSelected(paramImageLocation.isEmbedded());
/*     */       this.path.setText(paramImageLocation.getPath());
/*     */     } 
/*     */   }
/*     */   
/*     */   public ImageLocation getImageLocation() {
/*     */     populateImageLocation();
/*     */     return this.iloc;
/*     */   }
/*     */   
/*     */   public boolean populateImageLocation() {
/*     */     if (this.iloc == null)
/*     */       this.iloc = new ImageLocation("."); 
/*     */     if (this.fullpath.isSelected()) {
/*     */       this.iloc.setPathType(1);
/*     */     } else if (this.relpath.isSelected()) {
/*     */       this.iloc.setPathType(2);
/*     */     } else if (this.resource.isSelected()) {
/*     */       this.iloc.setPathType(3);
/*     */     } else if (this.url.isSelected()) {
/*     */       this.iloc.setPathType(4);
/*     */     } 
/*     */     this.iloc.setEmbedded(this.embed.isSelected());
/*     */     this.iloc.setPath(this.path.getText());
/*     */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ImageLocationPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */