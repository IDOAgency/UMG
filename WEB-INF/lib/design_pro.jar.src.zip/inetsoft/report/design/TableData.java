/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.ChartLens;
/*     */ import inetsoft.report.FormLens;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.util.Vector;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TableData
/*     */   extends DefaultTableModel
/*     */ {
/*  33 */   public TableData() { super(6, 6); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public TableData(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDimension(int paramInt1, int paramInt2) {
/*  51 */     Vector vector1 = getDataVector();
/*  52 */     vector1.setSize(paramInt1);
/*     */     
/*  54 */     for (byte b1 = 0; b1 < vector1.size(); b1++) {
/*  55 */       Vector vector = (Vector)vector1.elementAt(b1);
/*     */       
/*  57 */       if (vector == null) {
/*  58 */         vector = new Vector();
/*  59 */         vector1.setElementAt(vector, b1);
/*     */       } 
/*     */       
/*  62 */       vector.setSize(paramInt2);
/*     */     } 
/*     */     
/*  65 */     Vector vector2 = new Vector();
/*  66 */     for (byte b2 = 0; b2 < paramInt2; b2++) {
/*  67 */       vector2.addElement(Integer.toString(b2 + true));
/*     */     }
/*     */     
/*  70 */     setDataVector(vector1, vector2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableData getData() {
/*     */     try {
/*  78 */       TableData tableData = new TableData(getRowCount(), getColumnCount());
/*     */       
/*  80 */       for (byte b1 = 0; b1 < getRowCount(); b1++) {
/*  81 */         for (byte b = 0; b < getColumnCount(); b++) {
/*  82 */           tableData.setValueAt(getValueAt(b1, b), b1, b);
/*     */         }
/*     */       } 
/*     */       
/*  86 */       Vector vector = new Vector();
/*  87 */       for (byte b2 = 0; b2 < tableData.getColumnCount(); b2++) {
/*  88 */         vector.addElement(tableData.getColumnName(b2));
/*     */       }
/*     */       
/*  91 */       tableData.setColumnIdentifiers(vector);
/*  92 */       return tableData;
/*  93 */     } catch (Exception exception) {
/*     */ 
/*     */       
/*  96 */       return this;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(TableLens paramTableLens) {
/* 104 */     setDimension(paramTableLens.getRowCount(), paramTableLens.getColCount());
/* 105 */     for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
/* 106 */       for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++) {
/* 107 */         setValueAt(paramTableLens.getObject(b, b1), b, b1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(ChartLens paramChartLens) {
/* 117 */     setDimension(paramChartLens.getDatasetCount() + 1, paramChartLens.getDatasetSize() + 1);
/*     */     
/* 119 */     for (byte b = 0; b < paramChartLens.getDatasetCount(); b++) {
/* 120 */       setValueAt(paramChartLens.getDatasetLabel(b), b + 1, 0);
/* 121 */       for (byte b1 = 0; b1 < paramChartLens.getDatasetSize(); b1++) {
/* 122 */         if (b == 0) {
/* 123 */           setValueAt(paramChartLens.getLabel(b1), 0, b1 + 1);
/*     */         }
/*     */         
/* 126 */         setValueAt(paramChartLens.getData(b, b1), b + 1, b1 + 1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(FormLens paramFormLens) {
/* 136 */     setDimension(paramFormLens.getFieldCount(), 2);
/*     */     
/* 138 */     for (byte b = 0; b < paramFormLens.getFieldCount(); b++) {
/* 139 */       setValueAt(paramFormLens.getLabel(b), b, 0);
/* 140 */       setValueAt(paramFormLens.getField(b), b, 1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TableData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */