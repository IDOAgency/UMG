package inetsoft.report.design;

import inetsoft.report.ChartLens;
import inetsoft.report.FormLens;
import inetsoft.report.TableLens;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

class TableData extends DefaultTableModel {
  public TableData() { super(6, 6); }
  
  public TableData(int paramInt1, int paramInt2) { super(paramInt1, paramInt2); }
  
  public void setDimension(int paramInt1, int paramInt2) {
    Vector vector1 = getDataVector();
    vector1.setSize(paramInt1);
    for (byte b1 = 0; b1 < vector1.size(); b1++) {
      Vector vector = (Vector)vector1.elementAt(b1);
      if (vector == null) {
        vector = new Vector();
        vector1.setElementAt(vector, b1);
      } 
      vector.setSize(paramInt2);
    } 
    Vector vector2 = new Vector();
    for (byte b2 = 0; b2 < paramInt2; b2++)
      vector2.addElement(Integer.toString(b2 + true)); 
    setDataVector(vector1, vector2);
  }
  
  public TableData getData() {
    try {
      TableData tableData = new TableData(getRowCount(), getColumnCount());
      for (byte b1 = 0; b1 < getRowCount(); b1++) {
        for (byte b = 0; b < getColumnCount(); b++)
          tableData.setValueAt(getValueAt(b1, b), b1, b); 
      } 
      Vector vector = new Vector();
      for (byte b2 = 0; b2 < tableData.getColumnCount(); b2++)
        vector.addElement(tableData.getColumnName(b2)); 
      tableData.setColumnIdentifiers(vector);
      return tableData;
    } catch (Exception exception) {
      return this;
    } 
  }
  
  public void setData(TableLens paramTableLens) {
    setDimension(paramTableLens.getRowCount(), paramTableLens.getColCount());
    for (byte b = 0; b < paramTableLens.getRowCount(); b++) {
      for (byte b1 = 0; b1 < paramTableLens.getColCount(); b1++)
        setValueAt(paramTableLens.getObject(b, b1), b, b1); 
    } 
  }
  
  public void setData(ChartLens paramChartLens) {
    setDimension(paramChartLens.getDatasetCount() + 1, paramChartLens.getDatasetSize() + 1);
    for (byte b = 0; b < paramChartLens.getDatasetCount(); b++) {
      setValueAt(paramChartLens.getDatasetLabel(b), b + 1, 0);
      for (byte b1 = 0; b1 < paramChartLens.getDatasetSize(); b1++) {
        if (b == 0)
          setValueAt(paramChartLens.getLabel(b1), 0, b1 + 1); 
        setValueAt(paramChartLens.getData(b, b1), b + 1, b1 + 1);
      } 
    } 
  }
  
  public void setData(FormLens paramFormLens) {
    setDimension(paramFormLens.getFieldCount(), 2);
    for (byte b = 0; b < paramFormLens.getFieldCount(); b++) {
      setValueAt(paramFormLens.getLabel(b), b, 0);
      setValueAt(paramFormLens.getField(b), b, 1);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TableData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */