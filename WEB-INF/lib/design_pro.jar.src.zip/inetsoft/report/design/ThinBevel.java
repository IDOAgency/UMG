package inetsoft.report.design;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.BevelBorder;

class ThinBevel extends BevelBorder {
  public ThinBevel(int paramInt) { super(paramInt); }
  
  public ThinBevel(int paramInt, Color paramColor1, Color paramColor2) { super(paramInt, paramColor1, paramColor1, paramColor2, paramColor2); }
  
  public Insets getBorderInsets(Component paramComponent) { return new Insets(1, 1, 1, 1); }
  
  public Insets getBorderInsets(Component paramComponent, Insets paramInsets) {
    paramInsets.left = paramInsets.top = paramInsets.right = paramInsets.bottom = 1;
    return paramInsets;
  }
  
  protected void paintRaisedBevel(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Color color = paramGraphics.getColor();
    int i = paramInt4;
    int j = paramInt3;
    paramGraphics.translate(paramInt1, paramInt2);
    paramGraphics.setColor(getHighlightOuterColor(paramComponent));
    paramGraphics.drawLine(0, 0, 0, i - 1);
    paramGraphics.drawLine(1, 0, j - 1, 0);
    paramGraphics.setColor(getShadowOuterColor(paramComponent));
    paramGraphics.drawLine(1, i - 1, j - 1, i - 1);
    paramGraphics.drawLine(j - 1, 1, j - 1, i - 2);
    paramGraphics.translate(-paramInt1, -paramInt2);
    paramGraphics.setColor(color);
  }
  
  protected void paintLoweredBevel(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Color color = paramGraphics.getColor();
    int i = paramInt4;
    int j = paramInt3;
    paramGraphics.translate(paramInt1, paramInt2);
    paramGraphics.setColor(getShadowInnerColor(paramComponent));
    paramGraphics.drawLine(0, 0, 0, i - 1);
    paramGraphics.drawLine(1, 0, j - 1, 0);
    paramGraphics.setColor(getHighlightOuterColor(paramComponent));
    paramGraphics.drawLine(1, i - 1, j - 1, i - 1);
    paramGraphics.drawLine(j - 1, 1, j - 1, i - 2);
    paramGraphics.translate(-paramInt1, -paramInt2);
    paramGraphics.setColor(color);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ThinBevel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */