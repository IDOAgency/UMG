/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.border.BevelBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ThinBevel
/*    */   extends BevelBorder
/*    */ {
/* 15 */   public ThinBevel(int paramInt) { super(paramInt); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 26 */   public ThinBevel(int paramInt, Color paramColor1, Color paramColor2) { super(paramInt, paramColor1, paramColor1, paramColor2, paramColor2); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public Insets getBorderInsets(Component paramComponent) { return new Insets(1, 1, 1, 1); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Insets getBorderInsets(Component paramComponent, Insets paramInsets) {
/* 43 */     paramInsets.left = paramInsets.top = paramInsets.right = paramInsets.bottom = 1;
/* 44 */     return paramInsets;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void paintRaisedBevel(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 49 */     Color color = paramGraphics.getColor();
/* 50 */     int i = paramInt4;
/* 51 */     int j = paramInt3;
/*    */     
/* 53 */     paramGraphics.translate(paramInt1, paramInt2);
/*    */     
/* 55 */     paramGraphics.setColor(getHighlightOuterColor(paramComponent));
/* 56 */     paramGraphics.drawLine(0, 0, 0, i - 1);
/* 57 */     paramGraphics.drawLine(1, 0, j - 1, 0);
/*    */     
/* 59 */     paramGraphics.setColor(getShadowOuterColor(paramComponent));
/* 60 */     paramGraphics.drawLine(1, i - 1, j - 1, i - 1);
/* 61 */     paramGraphics.drawLine(j - 1, 1, j - 1, i - 2);
/*    */     
/* 63 */     paramGraphics.translate(-paramInt1, -paramInt2);
/* 64 */     paramGraphics.setColor(color);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void paintLoweredBevel(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 70 */     Color color = paramGraphics.getColor();
/* 71 */     int i = paramInt4;
/* 72 */     int j = paramInt3;
/*    */     
/* 74 */     paramGraphics.translate(paramInt1, paramInt2);
/*    */     
/* 76 */     paramGraphics.setColor(getShadowInnerColor(paramComponent));
/* 77 */     paramGraphics.drawLine(0, 0, 0, i - 1);
/* 78 */     paramGraphics.drawLine(1, 0, j - 1, 0);
/*    */     
/* 80 */     paramGraphics.setColor(getHighlightOuterColor(paramComponent));
/* 81 */     paramGraphics.drawLine(1, i - 1, j - 1, i - 1);
/* 82 */     paramGraphics.drawLine(j - 1, 1, j - 1, i - 2);
/*    */     
/* 84 */     paramGraphics.translate(-paramInt1, -paramInt2);
/* 85 */     paramGraphics.setColor(color);
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ThinBevel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */