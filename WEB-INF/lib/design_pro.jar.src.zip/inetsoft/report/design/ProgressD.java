/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ 
/*     */ class ProgressD
/*     */   extends JFrame {
/*     */   JProgressBar bar;
/*     */   JLabel text;
/*     */   
/*     */   public ProgressD(Class paramClass, int paramInt1, int paramInt2) {
/*  24 */     super(Catalog.getString("Style Report"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 108 */     this.bar = new JProgressBar();
/* 109 */     this.text = new JLabel(" ");
/*     */     getContentPane().setBackground(Color.white);
/*     */     getContentPane().setLayout(new GridBagLayout());
/*     */     ImageIcon imageIcon1 = new ImageIcon(getClass().getResource("images/logo.gif"));
/*     */     ImageIcon imageIcon2 = new ImageIcon(getClass().getResource("images/title.gif"));
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setBackground(Color.white);
/*     */     jPanel.add(new JLabel(imageIcon2));
/*     */     jPanel.add(new JLabel(imageIcon1));
/*     */     this.text.setHorizontalAlignment(0);
/*     */     this.text.setFont(new Font("Dialog", 0, 10));
/*     */     this.bar.setPreferredSize(new Dimension(350, 12));
/*     */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/*     */     gridBagConstraints.weightx = gridBagConstraints.weighty = 1.0D;
/*     */     gridBagConstraints.gridwidth = 0;
/*     */     gridBagConstraints.fill = 1;
/*     */     getContentPane().add(jPanel, gridBagConstraints);
/*     */     gridBagConstraints = new GridBagConstraints();
/*     */     gridBagConstraints.gridwidth = 0;
/*     */     gridBagConstraints.weightx = 1.0D;
/*     */     gridBagConstraints.insets = new Insets(10, 10, 5, 10);
/*     */     gridBagConstraints.fill = 1;
/*     */     String str1 = paramClass.getName();
/*     */     String str2 = "Professional Edition";
/*     */     if (str1.endsWith("Designer2"))
/*     */       str2 = "Enterprise Edition"; 
/*     */     str2 = str2 + ", Version " + StyleSheet.getVersion();
/*     */     getContentPane().add(new JLabel(str2, 0), gridBagConstraints);
/*     */     gridBagConstraints = new GridBagConstraints();
/*     */     gridBagConstraints.gridwidth = 0;
/*     */     gridBagConstraints.weightx = 1.0D;
/*     */     gridBagConstraints.insets = new Insets(30, 10, 5, 10);
/*     */     gridBagConstraints.fill = 1;
/*     */     getContentPane().add(this.text, gridBagConstraints);
/*     */     gridBagConstraints = new GridBagConstraints();
/*     */     gridBagConstraints.gridwidth = 0;
/*     */     gridBagConstraints.weightx = 1.0D;
/*     */     gridBagConstraints.insets = new Insets(5, 10, 30, 10);
/*     */     gridBagConstraints.fill = 1;
/*     */     getContentPane().add(this.bar, gridBagConstraints);
/*     */     this.bar.setBorderPainted(true);
/*     */     this.bar.setMinimum(paramInt1);
/*     */     this.bar.setMaximum(paramInt2);
/*     */     setDefaultCloseOperation(0);
/*     */   }
/*     */   
/*     */   public void setProgress(int paramInt) { this.bar.setValue(paramInt); }
/*     */   
/*     */   public void setText(String paramString) { this.text.setText(paramString); }
/*     */   
/*     */   public void processWindowEvent(WindowEvent paramWindowEvent) {
/*     */     if (paramWindowEvent.getID() == 201)
/*     */       System.exit(0); 
/*     */     super.processWindowEvent(paramWindowEvent);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ProgressD.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */