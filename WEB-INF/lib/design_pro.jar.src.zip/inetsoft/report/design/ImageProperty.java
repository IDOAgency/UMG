package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.internal.ImageXElement;
import inetsoft.report.locale.Catalog;
import javax.swing.JOptionPane;

public class ImageProperty extends PainterProperty {
  ImageXElement elem;
  
  ImageLocationPane pane;
  
  public ImageProperty(DesignView paramDesignView) {
    super(paramDesignView);
    this.pane = new ImageLocationPane();
    setTitle(Catalog.getString("Image Properties"));
    this.folder.insertTab(Catalog.getString("Image"), null, this.pane, Catalog.getString("Image Source"), 0);
  }
  
  public void setElement(ReportElement paramReportElement) {
    this.elem = (ImageXElement)paramReportElement;
    super.setElement(paramReportElement);
    this.pane.setImageLocation(this.elem.getImageLocation());
  }
  
  public boolean populateElement() {
    if (!super.populateElement())
      return false; 
    this.pane.populateImageLocation();
    try {
      this.elem.updateImage();
    } catch (Exception exception) {
      JOptionPane.showMessageDialog(null, exception.toString());
    } 
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ImageProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */