/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.TextElement;
/*     */ import inetsoft.report.internal.TextBased;
/*     */ import inetsoft.report.internal.j2d.NumField;
/*     */ import inetsoft.report.internal.j2d.PropertyPanel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.ColorComboBox;
/*     */ import java.awt.Color;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextProperty
/*     */   extends PropertyDialog
/*     */ {
/*     */   AlignCombo halign;
/*     */   AlignCombo valign;
/*     */   NumField indent;
/*     */   FontCanvas font;
/*     */   ColorComboBox fg;
/*     */   NumField spacing;
/*     */   ColorComboBox bg;
/*     */   JTextArea text;
/*     */   JCheckBox justify;
/*     */   TabPane tab;
/*     */   NumField textadv;
/*     */   JCheckBox orphan;
/*     */   JCheckBox keep;
/*     */   ReportElement elem;
/*     */   
/*     */   public TextProperty(DesignView paramDesignView) {
/*  37 */     this(paramDesignView, inetsoft.report.internal.TextElementDef.class);
/*  38 */     setTitle(Catalog.getString("Text Properties"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextProperty(DesignView paramDesignView, Class paramClass) {
/*  46 */     super(paramDesignView);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 180 */     this.halign = new AlignCombo(1);
/* 181 */     this.valign = new AlignCombo(2);
/* 182 */     this.indent = new NumField(3, false);
/* 183 */     this.font = new FontCanvas();
/* 184 */     this.fg = new ColorComboBox();
/* 185 */     this.spacing = new NumField(3, true);
/* 186 */     this.bg = new ColorComboBox();
/* 187 */     this.text = new JTextArea(10, 30);
/* 188 */     this.justify = new JCheckBox(Catalog.getString("Justify"));
/* 189 */     this.tab = new TabPane(false);
/* 190 */     this.textadv = new NumField(3, true);
/* 191 */     this.orphan = new JCheckBox(Catalog.getString("Widow/Orphan Control"));
/* 192 */     this.keep = new JCheckBox(Catalog.getString("Keep With Next"));
/*     */     PropertyPanel propertyPanel = new PropertyPanel();
/*     */     Object[][] arrayOfObject = null;
/*     */     this.text.setBackground(Color.white);
/*     */     if (TextBased.class.isAssignableFrom(paramClass)) {
/*     */       if (TextElement.class.isAssignableFrom(paramClass)) {
/*     */         arrayOfObject = new Object[][] { { Catalog.getString("Alignment") + ":", this.halign, "", this.justify }, { Catalog.getString("Vertical Alignment") + ":", this.valign, Catalog.getString("Foreground") + ":", this.fg }, { Catalog.getString("Font") + ":", this.font, Catalog.getString("Background") + ":", this.bg }, { Catalog.getString("Indent") + "\":", this.indent, Catalog.getString("Spacing") + ":", this.spacing }, { "", this.orphan, Catalog.getString("Text Advance") + ":", this.textadv }, { "", this.keep } };
/*     */       } else {
/*     */         arrayOfObject = new Object[][] { { Catalog.getString("Alignment") + ":", this.halign, "", this.justify }, { Catalog.getString("Vertical Alignment") + ":", this.valign, Catalog.getString("Foreground") + ":", this.fg }, { Catalog.getString("Font") + ":", this.font, Catalog.getString("Background") + ":", this.bg }, { Catalog.getString("Indent") + "\":", this.indent, Catalog.getString("Spacing") + ":", this.spacing }, { "", this.keep } };
/*     */       } 
/*     */       propertyPanel.setFields(arrayOfObject);
/*     */       this.folder.addTab(Catalog.getString("Attributes"), null, propertyPanel, Catalog.getString("Text Attributes"));
/*     */       this.text.setLineWrap(true);
/*     */       JScrollPane jScrollPane = new JScrollPane(this.text, 22, 31);
/*     */       this.folder.addTab(Catalog.getString("Contents"), null, jScrollPane, Catalog.getString("Text Contents"));
/*     */       if (inetsoft.report.internal.TabSupport.class.isAssignableFrom(paramClass))
/*     */         this.folder.addTab(Catalog.getString("Tab"), null, this.tab, Catalog.getString("Tab")); 
/*     */     } else {
/*     */       arrayOfObject = new Object[][] { { Catalog.getString("Alignment") + ":", this.halign, Catalog.getString("Foreground") + ":", this.fg }, { Catalog.getString("Vertical Alignment") + ":", this.valign, Catalog.getString("Background") + ":", this.bg }, { Catalog.getString("Font") + ":", this.font, Catalog.getString("Indent") + "\":", this.indent } };
/*     */       propertyPanel.setFields(arrayOfObject);
/*     */       this.folder.addTab(Catalog.getString("Attributes"), null, propertyPanel, Catalog.getString("Default Attributes"));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setElement(ReportElement paramReportElement) {
/*     */     this.elem = paramReportElement;
/*     */     super.setElement(paramReportElement);
/*     */     this.halign.selectOption(paramReportElement.getAlignment());
/*     */     this.valign.selectOption(paramReportElement.getAlignment());
/*     */     this.indent.setValue(paramReportElement.getIndent());
/*     */     this.font.setDisplayFont(paramReportElement.getFont());
/*     */     this.fg.setSelectedColor(paramReportElement.getForeground());
/*     */     this.bg.setSelectedColor(paramReportElement.getBackground());
/*     */     this.keep.setSelected(paramReportElement.isKeepWithNext());
/*     */     if (paramReportElement instanceof TextBased) {
/*     */       this.spacing.setValue(paramReportElement.getSpacing());
/*     */       this.text.setText(((TextBased)paramReportElement).getText());
/*     */       this.justify.setSelected(((TextBased)paramReportElement).isJustify());
/*     */     } 
/*     */     if (paramReportElement instanceof TextElement) {
/*     */       this.textadv.setValue(((TextElement)paramReportElement).getTextAdvance());
/*     */       this.orphan.setSelected(((TextElement)paramReportElement).isOrphanControl());
/*     */     } 
/*     */     if (paramReportElement instanceof inetsoft.report.internal.TabSupport)
/*     */       this.tab.setElement(paramReportElement); 
/*     */   }
/*     */   
/*     */   public boolean populateElement() {
/*     */     if (!super.populateElement())
/*     */       return false; 
/*     */     this.elem.setAlignment(this.halign.getSelectedOption() | this.valign.getSelectedOption());
/*     */     this.elem.setIndent(this.indent.floatValue());
/*     */     this.elem.setFont(this.font.getDisplayFont());
/*     */     this.elem.setForeground(this.fg.getSelectedColor());
/*     */     this.elem.setBackground(this.bg.getSelectedColor());
/*     */     this.elem.setKeepWithNext(this.keep.isSelected());
/*     */     if (this.elem instanceof TextBased) {
/*     */       this.elem.setSpacing(this.spacing.intValue());
/*     */       ((TextBased)this.elem).setText(this.text.getText());
/*     */       ((TextBased)this.elem).setJustify(this.justify.isSelected());
/*     */     } 
/*     */     if (this.elem instanceof TextElement) {
/*     */       ((TextElement)this.elem).setTextAdvance(this.textadv.intValue());
/*     */       ((TextElement)this.elem).setOrphanControl(this.orphan.isSelected());
/*     */     } 
/*     */     if (this.elem instanceof inetsoft.report.internal.TabSupport)
/*     */       this.tab.populateElement(); 
/*     */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TextProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */