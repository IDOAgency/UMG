/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.ReportElement;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.event.EventListenerList;
/*     */ import javax.swing.event.TreeModelEvent;
/*     */ import javax.swing.event.TreeModelListener;
/*     */ import javax.swing.tree.TreeModel;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReportTreeModel
/*     */   implements TreeModel
/*     */ {
/*     */   protected EventListenerList listenerList;
/*     */   DesignPane pane;
/*     */   JTree tree;
/*     */   
/*     */   public Object getRoot() {
/*     */     switch (this.pane.getTarget()) {
/*     */       case 256:
/*     */       case 512:
/*     */         return this.pane.getStyleSheet();
/*     */       case 0:
/*     */         return this.pane;
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public Object getChild(Object paramObject, int paramInt) {
/*     */     if (this.pane.getTarget() == 256)
/*     */       return (paramObject instanceof inetsoft.report.StyleSheet) ? this.pane.getStyleSheet().getHeaderElement(paramInt) : null; 
/*     */     if (this.pane.getTarget() == 512)
/*     */       return (paramObject instanceof inetsoft.report.StyleSheet) ? this.pane.getStyleSheet().getFooterElement(paramInt) : null; 
/*     */     if (paramObject instanceof DesignPane)
/*     */       return this.pane.getPage(paramInt); 
/*     */     if (paramObject instanceof DesignPane.DesignPage)
/*     */       return ((DesignPane.DesignPage)paramObject).getElement(paramInt); 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public ReportTreeModel(DesignPane paramDesignPane, JTree paramJTree) {
/* 127 */     this.listenerList = new EventListenerList();
/*     */     this.pane = paramDesignPane;
/* 129 */     this.tree = paramJTree; } public void addTreeModelListener(TreeModelListener paramTreeModelListener) { this.listenerList.add(TreeModelListener.class, paramTreeModelListener); }
/*     */   public int getChildCount(Object paramObject) { if (this.pane.getTarget() == 256) return (paramObject instanceof inetsoft.report.StyleSheet) ? this.pane.getStyleSheet().getHeaderElementCount() : 0;  if (this.pane.getTarget() == 512)
/*     */       return (paramObject instanceof inetsoft.report.StyleSheet) ? this.pane.getStyleSheet().getFooterElementCount() : 0;  if (paramObject instanceof DesignPane)
/*     */       return this.pane.getPageCount();  if (paramObject instanceof DesignPane.DesignPage)
/* 133 */       return ((DesignPane.DesignPage)paramObject).getElementCount();  return 0; } public boolean isLeaf(Object paramObject) { return paramObject instanceof ReportElement; } public void removeTreeModelListener(TreeModelListener paramTreeModelListener) { this.listenerList.remove(TreeModelListener.class, paramTreeModelListener); }
/*     */   
/*     */   public void valueForPathChanged(TreePath paramTreePath, Object paramObject) {}
/*     */   
/* 137 */   public void targetChanged() { treeChanged(); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void treeChanged() {
/* 142 */     Object[] arrayOfObject = this.listenerList.getListenerList();
/* 143 */     TreeModelEvent treeModelEvent = null;
/*     */ 
/*     */     
/* 146 */     for (int i = arrayOfObject.length - 2; i >= 0; i -= 2) {
/* 147 */       if (arrayOfObject[i] == TreeModelListener.class) {
/*     */         
/* 149 */         if (treeModelEvent == null) {
/* 150 */           treeModelEvent = new TreeModelEvent(this, new Object[] { this.pane }, null, null);
/*     */         }
/*     */ 
/*     */         
/* 154 */         ((TreeModelListener)arrayOfObject[i + 1]).treeStructureChanged(treeModelEvent);
/*     */       } 
/*     */     } 
/*     */     
/* 158 */     if (this.pane.getTarget() == 0 && this.pane.getCurrentPage() != null)
/* 159 */       this.tree.expandPath(new TreePath(new Object[] { this.pane, this.pane.getCurrentPage() })); 
/*     */   }
/*     */   
/*     */   public int getIndexOfChild(Object paramObject1, Object paramObject2) {
/*     */     if (this.pane.getTarget() == 256)
/*     */       return (paramObject1 instanceof inetsoft.report.StyleSheet && paramObject2 instanceof ReportElement) ? this.pane.getStyleSheet().getHeaderElementIndex((ReportElement)paramObject2) : -1; 
/*     */     if (this.pane.target == 512)
/*     */       return (paramObject1 instanceof inetsoft.report.StyleSheet && paramObject2 instanceof ReportElement) ? this.pane.getStyleSheet().getFooterElementIndex((ReportElement)paramObject2) : -1; 
/*     */     if (paramObject1 instanceof DesignPane) {
/*     */       for (byte b = 0; b < this.pane.getPageCount(); b++) {
/*     */         if (paramObject2 == this.pane.getPage(b))
/*     */           return b; 
/*     */       } 
/*     */     } else if (paramObject1 instanceof DesignPane.DesignPage) {
/*     */       byte b = 0;
/*     */       for (; b < ((DesignPane.DesignPage)paramObject1).getElementCount(); b++) {
/*     */         if (paramObject2 == ((DesignPane.DesignPage)paramObject1).getElement(b))
/*     */           return b; 
/*     */       } 
/*     */     } 
/*     */     return 0;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ReportTreeModel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */