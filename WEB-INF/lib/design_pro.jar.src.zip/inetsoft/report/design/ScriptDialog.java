package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.TableElement;
import inetsoft.report.internal.ScriptEnv;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

public class ScriptDialog extends JDialog {
  JTabbedPane folder;
  
  JSTextArea scriptTF;
  
  JSTextArea onClickTF;
  
  JSTextArea onLoadTF;
  
  JSTextArea onPageBreakTF;
  
  OnClickRangePane rangepane;
  
  boolean changed;
  
  boolean ok;
  
  ReportElement elem;
  
  StyleSheet report;
  
  ActionListener listener;
  
  ScriptEnv scriptenv;
  
  public ScriptDialog(boolean paramBoolean) {
    super((Frame)null, false);
    this.folder = new JTabbedPane();
    this.scriptTF = new JSTextArea();
    this.onClickTF = new JSTextArea();
    this.onLoadTF = new JSTextArea();
    this.onPageBreakTF = new JSTextArea();
    this.rangepane = new OnClickRangePane();
    this.changed = false;
    this.ok = true;
    this.scriptenv = null;
    if (paramBoolean) {
      this.folder.add(this.scriptTF, "Script");
      if (Designer.sree) {
        this.folder.add(this.onClickTF, "onClick");
        this.folder.add(this.rangepane, "onClick Range");
      } 
    } else {
      this.folder.add(this.onLoadTF, "onLoad");
      this.folder.add(this.onPageBreakTF, "onPageBreak");
    } 
    this.folder.setPreferredSize(new Dimension(550, 350));
    getContentPane().setLayout(new BorderLayout(5, 10));
    getContentPane().add(this.folder, "Center");
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(1, 25, 5));
    JButton jButton;
    jPanel.add(jButton = new JButton(Catalog.getString("Check")));
    jButton.addActionListener(new ActionListener(this) {
          private final ScriptDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            try {
              ScriptDialog.JSTextArea jSTextArea = (ScriptDialog.JSTextArea)this.this$0.folder.getSelectedComponent();
              this.this$0.scriptenv.compile(jSTextArea.getText());
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
            } 
          }
        });
    jPanel.add(jButton = new JButton(Catalog.getString("OK")));
    jButton.addActionListener(new ActionListener(this) {
          private final ScriptDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            if (this.this$0.populateElement()) {
              this.this$0.dispose();
              if (this.this$0.listener != null)
                this.this$0.listener.actionPerformed(param1ActionEvent); 
            } 
          }
        });
    jPanel.add(jButton = new JButton(Catalog.getString("Cancel")));
    jButton.addActionListener(new ActionListener(this) {
          private final ScriptDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.ok = false;
            this.this$0.dispose();
          }
        });
    getContentPane().add(jPanel, "South");
  }
  
  public void show(ReportElement paramReportElement, StyleSheet paramStyleSheet, ActionListener paramActionListener) {
    this.listener = paramActionListener;
    setElement(paramReportElement, paramStyleSheet);
    pack();
    setLocation(200, 200);
    setVisible(true);
  }
  
  public void setActionListener(ActionListener paramActionListener) { this.listener = paramActionListener; }
  
  public void setElement(ReportElement paramReportElement, StyleSheet paramStyleSheet) {
    this.elem = paramReportElement;
    this.report = paramStyleSheet;
    if (paramReportElement == null) {
      String str1 = paramStyleSheet.getOnLoad();
      this.onLoadTF.setText((str1 == null) ? "" : str1);
      String str2 = paramStyleSheet.getOnPageBreak();
      this.onPageBreakTF.setText((str2 == null) ? "" : str2);
      if (str1 == null && str2 != null)
        this.folder.setSelectedIndex(1); 
    } else {
      String str1 = paramReportElement.getScript();
      this.scriptTF.setText((str1 == null) ? "" : str1);
      String str2 = paramReportElement.getOnClick();
      this.onClickTF.setText((str2 == null) ? "" : str2);
      if (Designer.sree) {
        this.folder.setEnabledAt(2, paramReportElement instanceof TableElement);
        if (str1 == null && str2 != null)
          this.folder.setSelectedIndex(1); 
      } 
      if (paramReportElement instanceof TableElement)
        this.rangepane.setElement((TableElement)paramReportElement); 
    } 
    this.scriptenv = ScriptEnv.getScriptEnv(paramStyleSheet);
  }
  
  public boolean populateElement() {
    if (this.elem != null) {
      if (this.elem instanceof TableElement)
        this.rangepane.populateElement(); 
      String str = this.scriptTF.getText();
      if (str.trim().length() == 0) {
        this.elem.setScript(null);
      } else {
        try {
          this.scriptenv.compile(str);
        } catch (Exception exception) {
          JOptionPane.showMessageDialog(null, exception.toString(), "Script", 0);
          return false;
        } 
        this.elem.setScript(str);
      } 
      str = this.onClickTF.getText();
      if (str.trim().length() == 0) {
        this.elem.setOnClick(null);
      } else {
        try {
          this.scriptenv.compile(str);
        } catch (Exception exception) {
          JOptionPane.showMessageDialog(null, exception.toString(), "onClick", 0);
          return false;
        } 
        this.elem.setOnClick(str);
      } 
    } else {
      String str = this.onLoadTF.getText();
      if (str.trim().length() == 0) {
        this.report.setOnLoad(null);
      } else {
        try {
          this.scriptenv.compile(str);
        } catch (Exception exception) {
          JOptionPane.showMessageDialog(null, exception.toString(), "onLoad", 0);
          return false;
        } 
        this.report.setOnLoad(str);
      } 
      str = this.onPageBreakTF.getText();
      if (str.trim().length() == 0) {
        this.report.setOnPageBreak(null);
      } else {
        try {
          this.scriptenv.compile(str);
        } catch (Exception exception) {
          JOptionPane.showMessageDialog(null, exception.toString(), "onPageBreak", 0);
          return false;
        } 
        this.report.setOnPageBreak(str);
      } 
    } 
    return true;
  }
  
  public boolean isOK() { return this.ok; }
  
  public boolean isChanged() { return this.changed; }
  
  public void setChanged(boolean paramBoolean) { this.changed = paramBoolean; }
  
  static class JSTextArea extends JPanel {
    MouseListener mouseListener;
    
    JTextArea text;
    
    public JSTextArea() {
      this.mouseListener = new ScriptDialog$4(this);
      this.text = new JTextArea(6, 30);
      setLayout(new BorderLayout());
      JPanel jPanel = new JPanel();
      jPanel.setLayout(new GridLayout(1, 3));
      try {
        JSTree jSTree = new JSTree(Catalog.getString("Properties"), new String[] { "/inetsoft/report/design/jsProperties.tree" });
        jSTree.addMouseListener(this.mouseListener);
        JScrollPane jScrollPane1 = new JScrollPane(jSTree);
        jScrollPane1.setPreferredSize(new Dimension(150, 150));
        jScrollPane1.setBorder(new TitledBorder(Catalog.getString("Properties")));
        jPanel.add(jScrollPane1);
        jSTree = new JSTree(Catalog.getString("Functions"), new String[] { "/inetsoft/report/design/jsFunctions.tree", "/inetsoft/sree/design/jsFunctions.tree" });
        jSTree.addMouseListener(this.mouseListener);
        jScrollPane1 = new JScrollPane(jSTree);
        jScrollPane1.setPreferredSize(new Dimension(150, 150));
        jScrollPane1.setBorder(new TitledBorder(Catalog.getString("Functions")));
        jPanel.add(jScrollPane1);
        jSTree = new JSTree(Catalog.getString("Operators"), new String[] { "/inetsoft/report/design/jsOperators.tree" });
        jSTree.addMouseListener(this.mouseListener);
        jScrollPane1 = new JScrollPane(jSTree);
        jScrollPane1.setPreferredSize(new Dimension(150, 150));
        jScrollPane1.setBorder(new TitledBorder(Catalog.getString("Operators")));
        jPanel.add(jScrollPane1);
        add(jPanel, "North");
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
      JScrollPane jScrollPane = new JScrollPane(this.text);
      this.text.setFont(new Font("Dialog", 0, 10));
      add(jScrollPane, "Center");
    }
    
    public String getText() { return this.text.getText(); }
    
    public void setText(String param1String) { this.text.setText(param1String); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ScriptDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */