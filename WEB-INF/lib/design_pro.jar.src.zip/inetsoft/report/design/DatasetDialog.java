package inetsoft.report.design;

import inetsoft.report.TableLens;
import inetsoft.report.internal.ChartXElement;
import inetsoft.report.internal.DatasetAttr;
import inetsoft.report.lens.AttributeChartLens;
import inetsoft.report.lens.TableChartLens;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.Grid2Layout;
import java.awt.BorderLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

class DatasetDialog extends JDialog {
  ActionListener cbListener;
  
  ActionListener okListener;
  
  ActionListener removeListener;
  
  ActionListener cancelListener;
  
  JRadioButton rowCB;
  
  JRadioButton colCB;
  
  JComboBox labelCB;
  
  JCheckBox fmtCB;
  
  JTextField fmtTF;
  
  JButton okB;
  
  JButton removeB;
  
  JButton cancelB;
  
  SummaryPane summary;
  
  ChartXElement xchart;
  
  DatasetAttr group;
  
  boolean changed;
  
  public static boolean show(ChartXElement paramChartXElement) {
    DatasetDialog datasetDialog = new DatasetDialog(paramChartXElement);
    datasetDialog.setModal(true);
    datasetDialog.pack();
    datasetDialog.setVisible(true);
    return datasetDialog.changed;
  }
  
  public DatasetDialog(ChartXElement paramChartXElement) {
    this.cbListener = new ActionListener(this) {
        private final DatasetDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.setEnabled(); }
      };
    this.okListener = new ActionListener(this) {
        private final DatasetDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.update();
          this.this$0.xchart.setDataset(this.this$0.group);
          this.this$0.changed = true;
          this.this$0.dispose();
        }
      };
    this.removeListener = new ActionListener(this) {
        private final DatasetDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.xchart.setDataset(null);
          this.this$0.changed = true;
          this.this$0.dispose();
        }
      };
    this.cancelListener = new ActionListener(this) {
        private final DatasetDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.rowCB = new JRadioButton(Catalog.getString("Row"));
    this.colCB = new JRadioButton(Catalog.getString("Column"));
    this.labelCB = new JComboBox();
    this.fmtCB = new JCheckBox(Catalog.getString("As Date"));
    this.fmtTF = new JTextField(10);
    this.okB = new JButton(Catalog.getString("OK"));
    this.removeB = new JButton(Catalog.getString("Remove Binding"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.summary = new SummaryPane(true);
    this.changed = false;
    this.xchart = paramChartXElement;
    setTitle(Catalog.getString("Chart Dataset"));
    getContentPane().setLayout(new BorderLayout(5, 5));
    JTabbedPane jTabbedPane = new JTabbedPane();
    jTabbedPane.add(this.summary, Catalog.getString("Summary"));
    JPanel jPanel1 = new JPanel();
    Grid2Layout grid2Layout = new Grid2Layout(new Insets(5, 5, 5, 5));
    jPanel1.setLayout(grid2Layout);
    jPanel1.setBorder(new TitledBorder(Catalog.getString("Dataset As")));
    jPanel1.add(this.rowCB, grid2Layout.at(0, 0));
    jPanel1.add(this.colCB, grid2Layout.at(0, 1));
    byte b1 = 17;
    byte b2 = 20;
    byte b3 = 18;
    Insets insets = new Insets(5, 5, 5, 5);
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(grid2Layout = new Grid2Layout());
    jPanel2.add(new JLabel(Catalog.getString("Label Column") + ":"), grid2Layout.at(0, 0, 1, 1, b2));
    jPanel2.add(this.labelCB, grid2Layout.at(0, 1, 1, 1, b3));
    jPanel2.add(this.fmtCB, grid2Layout.at(0, 2));
    jPanel2.add(this.fmtTF, grid2Layout.at(0, 3, 1, 1, b1));
    jPanel2.add(jPanel1, grid2Layout.at(1, 0, 1, 3, b3));
    jTabbedPane.add(jPanel2, Catalog.getString("Dataset"));
    getContentPane().add(jTabbedPane, "Center");
    jPanel2 = new JPanel();
    jPanel2.add(this.okB);
    jPanel2.add(this.removeB);
    jPanel2.add(this.cancelB);
    getContentPane().add(jPanel2, "South");
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(this.rowCB);
    buttonGroup.add(this.colCB);
    populate();
    this.okB.addActionListener(this.okListener);
    this.removeB.addActionListener(this.removeListener);
    this.cancelB.addActionListener(this.cancelListener);
    setEnabled();
    addWindowListener(new WindowAdapter(this) {
          private final DatasetDialog this$0;
          
          public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.dispose(); }
        });
  }
  
  private void setEnabled() {}
  
  private void populate() {
    AttributeChartLens attributeChartLens = (AttributeChartLens)this.xchart.getChart();
    TableChartLens tableChartLens = (TableChartLens)attributeChartLens.getChart();
    this.group = this.xchart.getDataset();
    if (this.group == null)
      this.group = new DatasetAttr(); 
    TableLens tableLens1 = tableChartLens.getTable();
    this.summary.populate(tableLens1, this.group);
    DefaultComboBoxModel defaultComboBoxModel = new DefaultComboBoxModel();
    TableLens tableLens2 = SummaryPane.getRootTable(tableLens1);
    for (int i = tableLens2.getHeaderColCount(); i < tableLens2.getColCount(); i++)
      defaultComboBoxModel.addElement(tableLens2.getObject(0, i)); 
    this.labelCB.setModel(defaultComboBoxModel);
    this.labelCB.setSelectedItem(this.group.getLabelColumn());
    this.fmtCB.setSelected((this.group.getLabelDateFormat() != null));
    this.rowCB.setSelected(this.group.isRowMajor());
    this.colCB.setSelected(!this.group.isRowMajor());
    if (this.fmtCB.isSelected())
      this.fmtTF.setText(this.group.getLabelDateFormat()); 
  }
  
  private void update() {
    this.summary.update();
    this.group.setRowMajor(this.rowCB.isSelected());
    this.group.setLabelColumn((String)this.labelCB.getSelectedItem());
    this.group.setLabelDateFormat(this.fmtCB.isSelected() ? this.fmtTF.getText() : null);
    this.xchart.setDataset(this.group);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DatasetDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */