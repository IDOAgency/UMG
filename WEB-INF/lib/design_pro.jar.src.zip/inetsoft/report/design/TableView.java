/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.Margin;
/*     */ import inetsoft.report.PreviewPage;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.internal.TablePaintable;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableView
/*     */   extends PreviewPage
/*     */ {
/*     */   StyleSheet report;
/*     */   TablePaintable area;
/*     */   TableLens table;
/*     */   double width;
/*     */   
/*  33 */   public TableView() { this(6.0D); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TableView(double paramDouble) {
/*  41 */     super(paramDouble, 11.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     this.report = new StyleSheet();
/*     */     setDrawBorder(false);
/*     */     this.width = paramDouble;
/*     */   }
/*     */   
/*     */   public void setTable(TableLens paramTableLens) {
/*     */     this.report.clear();
/*     */     Margin margin = StyleSheet.getPrinterMargin();
/*     */     this.report.setMargin(new Margin(margin.top, margin.left, 0.1D, 0.1D));
/*     */     this.report.setCurrentTableLayout(1);
/*     */     this.report.addTable(this.table = paramTableLens);
/*     */     reprint();
/*     */     invalidate();
/*     */   }
/*     */   
/*     */   public TableLens getTable() { return this.table; }
/*     */   
/*     */   public void reprint() {
/*     */     setPageSize(new Dimension((int)(this.width * 72.0D), 792));
/*     */     this.report.reset();
/*     */     getStylePage().reset();
/*     */     this.report.printNext(getStylePage());
/*     */     this.area = (TablePaintable)getStylePage().getPaintable(0);
/*     */     Rectangle rectangle = this.area.getBounds();
/*     */     int i = (int)Math.ceil(Common.getLineWidth(this.table.getRowBorder(this.table.getRowCount() - 1, 0)));
/*     */     int j = (int)Math.ceil(Common.getLineWidth(this.table.getColBorder(0, this.table.getColCount() - 1)));
/*     */     Margin margin = StyleSheet.getPrinterMargin();
/*     */     setPageSize(new Dimension(rectangle.width + j + (int)(1.1D * margin.left * 72.0D) + 3, rectangle.height + i + (int)(1.1D * margin.top * 72.0D)));
/*     */     invalidate();
/*     */   }
/*     */   
/*     */   public Point locateCell(int paramInt1, int paramInt2) { return this.area.locate(paramInt1, paramInt2); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TableView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */