package inetsoft.report.design;

import inetsoft.report.Common;
import inetsoft.report.StyleFont;
import inetsoft.report.internal.Util;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.Serializable;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class FontChooser extends JDialog {
  boolean ignore;
  
  Listener listener;
  
  JPanel fontPnl;
  
  JLabel fontL;
  
  JLabel styleL;
  
  JLabel sizeL;
  
  JPanel linePnl;
  
  JLabel underlineL;
  
  JLabel strikeL;
  
  JLabel effectsL;
  
  JPanel effectPnl;
  
  JPanel previewPnl;
  
  JLabel previewL;
  
  JPanel cmdPnl;
  
  JTextField fontTF;
  
  JTextField styleTF;
  
  JTextField sizeTF;
  
  JList fontLT;
  
  JList styleLT;
  
  JList sizeLT;
  
  LineCombo underlineCH;
  
  LineCombo strikethroughCH;
  
  JCheckBox smallcapCK;
  
  JCheckBox allcapCK;
  
  JCheckBox subscriptCK;
  
  JCheckBox superscriptCK;
  
  JCheckBox shadowCK;
  
  FontPreview preview;
  
  JButton okB;
  
  JButton cancelB;
  
  StyleFont font;
  
  String[] styles;
  
  int[] sizes;
  
  public static Font showDialog(Component paramComponent, String paramString, Font paramFont) {
    FontChooser fontChooser = new FontChooser(Util.findFrame(paramComponent), paramString);
    fontChooser.setSelectedFont(paramFont);
    fontChooser.pack();
    fontChooser.setVisible(true);
    return fontChooser.getSelectedFont();
  }
  
  public FontChooser(Frame paramFrame, String paramString) {
    super(paramFrame, true);
    this.ignore = false;
    this.listener = new Listener(this);
    this.styles = new String[] { Catalog.getString("PLAIN"), Catalog.getString("Bold"), Catalog.getString("Italic"), Catalog.getString("Bold-Italic") };
    this.sizes = new int[] { 
        6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 
        20, 22, 24, 26, 28, 36, 48, 72 };
    setFont(new Font("SansSerif", 0, 10));
    GridBagLayout gridBagLayout = new GridBagLayout();
    getContentPane().setLayout(gridBagLayout);
    this.fontPnl = new JPanel();
    gridBagLayout = new GridBagLayout();
    this.fontPnl.setLayout(gridBagLayout);
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 5, 10, 0);
    getContentPane().add(this.fontPnl, gridBagConstraints);
    this.fontL = new JLabel(Catalog.getString("Font") + ":");
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.anchor = 17;
    this.fontPnl.add(this.fontL, gridBagConstraints);
    this.styleL = new JLabel(Catalog.getString("Font style") + ":");
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.anchor = 17;
    gridBagConstraints.insets = new Insets(0, 5, 0, 0);
    this.fontPnl.add(this.styleL, gridBagConstraints);
    this.sizeL = new JLabel(Catalog.getString("Size") + ":");
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.anchor = 17;
    gridBagConstraints.insets = new Insets(0, 5, 0, 5);
    this.fontPnl.add(this.sizeL, gridBagConstraints);
    this.fontTF = new JTextField(10);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.fill = 1;
    this.fontPnl.add(this.fontTF, gridBagConstraints);
    this.styleTF = new JTextField(10);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 5, 0, 0);
    this.fontPnl.add(this.styleTF, gridBagConstraints);
    this.sizeTF = new JTextField(10);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 5, 0, 5);
    this.fontPnl.add(this.sizeTF, gridBagConstraints);
    this.fontLT = new JList(Common.getAllFonts());
    this.fontLT.setVisibleRowCount(5);
    this.fontLT.setPreferredSize(new Dimension(150, (this.fontLT.getPreferredSize()).height));
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.anchor = 12;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 10, 0, 0);
    this.fontPnl.add(new JScrollPane(this.fontLT), gridBagConstraints);
    this.styleLT = new JList(this.styles);
    this.styleLT.setVisibleRowCount(5);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.anchor = 12;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 15, 0, 0);
    this.fontPnl.add(new JScrollPane(this.styleLT), gridBagConstraints);
    Vector vector = new Vector();
    for (byte b = 0; b < this.sizes.length; b++)
      vector.addElement(Integer.toString(this.sizes[b])); 
    this.sizeLT = new JList(vector);
    this.sizeLT.setVisibleRowCount(5);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.anchor = 12;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 15, 0, 5);
    this.fontPnl.add(new JScrollPane(this.sizeLT), gridBagConstraints);
    this.linePnl = new JPanel();
    gridBagLayout = new GridBagLayout();
    this.linePnl.setLayout(gridBagLayout);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 5, 10, 0);
    getContentPane().add(this.linePnl, gridBagConstraints);
    this.underlineL = new JLabel(Catalog.getString("Underline") + ":");
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.fill = 1;
    this.linePnl.add(this.underlineL, gridBagConstraints);
    this.strikeL = new JLabel(Catalog.getString("Strikethrough") + ":");
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 20, 0, 10);
    this.linePnl.add(this.strikeL, gridBagConstraints);
    this.underlineCH = new LineCombo(true);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.anchor = 11;
    gridBagConstraints.fill = 1;
    this.linePnl.add(this.underlineCH, gridBagConstraints);
    this.strikethroughCH = new LineCombo(true);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 20, 0, 10);
    this.linePnl.add(this.strikethroughCH, gridBagConstraints);
    this.effectsL = new JLabel(Catalog.getString("Effects") + ":");
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.anchor = 17;
    gridBagConstraints.insets = new Insets(0, 5, 0, 0);
    getContentPane().add(this.effectsL, gridBagConstraints);
    this.effectPnl = new JPanel();
    this.effectPnl.setLayout(new GridLayout(2, 3, 0, 0));
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 20, 10, 0);
    getContentPane().add(this.effectPnl, gridBagConstraints);
    this.smallcapCK = new JCheckBox(Catalog.getString("Small Caps"));
    this.effectPnl.add(this.smallcapCK);
    this.allcapCK = new JCheckBox(Catalog.getString("All Caps"));
    this.effectPnl.add(this.allcapCK);
    this.subscriptCK = new JCheckBox(Catalog.getString("Subscript"));
    this.effectPnl.add(this.subscriptCK);
    this.superscriptCK = new JCheckBox(Catalog.getString("Superscript"));
    this.effectPnl.add(this.superscriptCK);
    this.shadowCK = new JCheckBox(Catalog.getString("Shadow"));
    this.effectPnl.add(this.shadowCK);
    this.previewPnl = new JPanel();
    this.previewPnl.setLayout(new BorderLayout(0, 0));
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.weighty = 1.0D;
    gridBagConstraints.fill = 1;
    gridBagConstraints.insets = new Insets(0, 5, 0, 5);
    getContentPane().add(this.previewPnl, gridBagConstraints);
    this.previewL = new JLabel(Catalog.getString("Preview") + ":");
    this.previewPnl.add(this.previewL, "North");
    this.preview = new FontPreview();
    this.previewPnl.add(this.preview, "Center");
    this.cmdPnl = new JPanel();
    this.cmdPnl.setLayout(new FlowLayout(2, 20, 15));
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.gridwidth = 0;
    gridBagConstraints.fill = 1;
    getContentPane().add(this.cmdPnl, gridBagConstraints);
    this.okB = new JButton();
    this.okB.setLabel("    " + Catalog.getString("OK") + "    ");
    this.cmdPnl.add(this.okB);
    this.cancelB = new JButton();
    this.cancelB.setLabel("  " + Catalog.getString("Cancel") + "  ");
    this.cmdPnl.add(this.cancelB);
    setTitle(paramString);
    this.fontTF.setEditable(false);
    this.styleTF.setEditable(false);
    this.sizeTF.setEditable(false);
    this.fontLT.addListSelectionListener(this.listener);
    this.styleLT.addListSelectionListener(this.listener);
    this.sizeLT.addListSelectionListener(this.listener);
    this.underlineCH.addItemListener(this.listener);
    this.strikethroughCH.addItemListener(this.listener);
    this.smallcapCK.addItemListener(this.listener);
    this.allcapCK.addItemListener(this.listener);
    this.subscriptCK.addItemListener(this.listener);
    this.superscriptCK.addItemListener(this.listener);
    this.shadowCK.addItemListener(this.listener);
    addWindowListener(new WindowAdapter(this) {
          private final FontChooser this$0;
          
          public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.close(); }
        });
    this.okB.addActionListener(new ActionListener(this) {
          private final FontChooser this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.updateValue();
            this.this$0.dispose();
          }
        });
    this.cancelB.addActionListener(new ActionListener(this) {
          private final FontChooser this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            this.this$0.font = null;
            this.this$0.dispose();
          }
        });
  }
  
  public void setSelectedFont(Font paramFont) {
    this.font = new StyleFont(paramFont);
    showValue();
  }
  
  public Font getSelectedFont() { return this.font; }
  
  public void close() { System.exit(0); }
  
  public void showValue() {
    this.ignore = true;
    this.fontLT.setSelectedIndex(0);
    for (byte b1 = 0; b1 < this.fontLT.getModel().getSize(); b1++) {
      if (this.font.getName().equals(this.fontLT.getModel().getElementAt(b1)))
        this.fontLT.setSelectedIndex(b1); 
    } 
    this.fontTF.setText((String)this.fontLT.getSelectedValue());
    this.styleLT.setSelectedIndex(this.font.getStyle() & 0x3);
    this.styleTF.setText((String)this.styleLT.getSelectedValue());
    this.sizeLT.setSelectedIndex(0);
    for (byte b2 = 0; b2 < this.sizes.length; b2++) {
      if (this.sizes[b2] == this.font.getSize())
        this.sizeLT.setSelectedIndex(b2); 
    } 
    this.sizeTF.setText((String)this.sizeLT.getSelectedValue());
    if ((this.font.getStyle() & 0x10) != 0)
      this.underlineCH.setSelectedLineStyle(this.font.getLineStyle()); 
    if ((this.font.getStyle() & 0x20) != 0)
      this.strikethroughCH.setSelectedLineStyle(this.font.getLineStyle()); 
    if ((this.font.getStyle() & 0x200) != 0)
      this.smallcapCK.setSelected(true); 
    if ((this.font.getStyle() & 0x400) != 0)
      this.allcapCK.setSelected(true); 
    if ((this.font.getStyle() & 0x80) != 0)
      this.subscriptCK.setSelected(true); 
    if ((this.font.getStyle() & 0x40) != 0)
      this.superscriptCK.setSelected(true); 
    if ((this.font.getStyle() & 0x100) != 0)
      this.shadowCK.setSelected(true); 
    this.preview.setDisplayFont(this.font);
    this.ignore = false;
  }
  
  public void updateValue() {
    int i = 0, j = 0, k = 0;
    String str = (String)this.fontLT.getSelectedValue();
    i |= this.styleLT.getSelectedIndex();
    j = Integer.parseInt((String)this.sizeLT.getSelectedValue());
    if (this.underlineCH.getSelectedLineStyle() != 0) {
      i |= 0x10;
      k = this.underlineCH.getSelectedLineStyle();
    } 
    if (this.strikethroughCH.getSelectedLineStyle() != 0) {
      i |= 0x20;
      k = this.strikethroughCH.getSelectedLineStyle();
    } 
    if (this.smallcapCK.isSelected())
      i |= 0x200; 
    if (this.allcapCK.isSelected())
      i |= 0x400; 
    if (this.subscriptCK.isSelected())
      i |= 0x80; 
    if (this.superscriptCK.isSelected())
      i |= 0x40; 
    if (this.shadowCK.isSelected())
      i |= 0x100; 
    this.font = new StyleFont(str, i, j, k);
  }
  
  public void refresh() {
    updateValue();
    this.preview.setDisplayFont(this.font);
  }
  
  class Listener implements ListSelectionListener, ItemListener, Serializable {
    private final FontChooser this$0;
    
    Listener(FontChooser this$0) { this.this$0 = this$0; }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) { valueChanged(null); }
    
    public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
      if (!this.this$0.ignore) {
        this.this$0.fontTF.setText((String)this.this$0.fontLT.getSelectedValue());
        this.this$0.styleTF.setText((String)this.this$0.styleLT.getSelectedValue());
        this.this$0.sizeTF.setText((String)this.this$0.sizeLT.getSelectedValue());
        this.this$0.refresh();
      } 
    }
  }
  
  public static void main(String[] paramArrayOfString) {
    Frame frame = new Frame("");
    frame.setVisible(true);
    Font font1 = showDialog(frame, "test", new Font("Serif", 1, 10));
    System.exit(0);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FontChooser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */