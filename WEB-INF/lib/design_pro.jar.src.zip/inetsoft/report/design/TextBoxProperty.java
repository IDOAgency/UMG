package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.internal.PainterElementDef;
import inetsoft.report.internal.TextBoxElementDef;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;

public class TextBoxProperty extends TextProperty {
  ItemListener selectListener;
  
  ItemListener borderListener;
  
  ItemListener bordersListener;
  
  TextBoxElementDef elem;
  
  FixedPane fixed;
  
  LineCombo border;
  
  LineCombo topBorder;
  
  LineCombo leftBorder;
  
  LineCombo bottomBorder;
  
  LineCombo rightBorder;
  
  NumField top;
  
  NumField left;
  
  NumField bottom;
  
  NumField right;
  
  AlignCombo thalign;
  
  AlignCombo tvalign;
  
  JCheckBox rounded;
  
  public TextBoxProperty(DesignView paramDesignView) {
    super(paramDesignView, TextBoxElementDef.class);
    this.selectListener = new ItemListener(this) {
        private final TextBoxProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setEnabled(); }
      };
    this.borderListener = new ItemListener(this) {
        private final TextBoxProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          if (this.this$0.border.getSelectedIndex() > 0) {
            this.this$0.topBorder.removeItemListener(this.this$0.bordersListener);
            this.this$0.leftBorder.removeItemListener(this.this$0.bordersListener);
            this.this$0.bottomBorder.removeItemListener(this.this$0.bordersListener);
            this.this$0.rightBorder.removeItemListener(this.this$0.bordersListener);
            this.this$0.topBorder.setSelectedIndex(0);
            this.this$0.leftBorder.setSelectedIndex(0);
            this.this$0.bottomBorder.setSelectedIndex(0);
            this.this$0.rightBorder.setSelectedIndex(0);
            this.this$0.topBorder.addItemListener(this.this$0.bordersListener);
            this.this$0.leftBorder.addItemListener(this.this$0.bordersListener);
            this.this$0.bottomBorder.addItemListener(this.this$0.bordersListener);
            this.this$0.rightBorder.addItemListener(this.this$0.bordersListener);
          } 
        }
      };
    this.bordersListener = new ItemListener(this) {
        private final TextBoxProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          this.this$0.border.removeItemListener(this.this$0.borderListener);
          this.this$0.border.setSelectedIndex(0);
          this.this$0.border.addItemListener(this.this$0.borderListener);
        }
      };
    this.fixed = new FixedPane();
    this.border = new LineCombo();
    this.topBorder = new LineCombo();
    this.leftBorder = new LineCombo();
    this.bottomBorder = new LineCombo();
    this.rightBorder = new LineCombo();
    this.top = new NumField(3, true);
    this.left = new NumField(3, true);
    this.bottom = new NumField(3, true);
    this.right = new NumField(3, true);
    this.thalign = new AlignCombo(1);
    this.tvalign = new AlignCombo(2);
    this.rounded = new JCheckBox(Catalog.getString("Rounded Box"));
    setTitle(Catalog.getString("TextBox Properties"));
    Property2Panel property2Panel = new Property2Panel();
    property2Panel.add(Catalog.getString("Border"), new Object[][] { { Catalog.getString("Box Border") + ":", this.border, Catalog.getString("Top") + ":", this.topBorder, Catalog.getString("Right") + ":", this.rightBorder }, { "", this.rounded, Catalog.getString("Left") + ":", this.leftBorder, Catalog.getString("Bottom") + ":", this.bottomBorder } });
    property2Panel.add(Catalog.getString("Padding Space"), new Object[][] { { Catalog.getString("Top") + ":", this.top, Catalog.getString("Left") + ":", this.left, Catalog.getString("Bottom") + ":", this.bottom, Catalog.getString("Right") + ":", this.right } });
    property2Panel.add(Catalog.getString("Text Alignment"), new Object[][] { { Catalog.getString("Horizontal") + ":", this.thalign, Catalog.getString("Vertical") + ":", this.tvalign } });
    this.folder.insertTab(Catalog.getString("Layout"), null, this.fixed, Catalog.getString("Size and Wrapping"), 0);
    this.folder.insertTab(Catalog.getString("Text Box"), null, property2Panel, Catalog.getString("Text Box Border"), 0);
    this.rounded.addItemListener(this.selectListener);
    this.border.addItemListener(this.borderListener);
    this.topBorder.addItemListener(this.bordersListener);
    this.leftBorder.addItemListener(this.bordersListener);
    this.bottomBorder.addItemListener(this.bordersListener);
    this.rightBorder.addItemListener(this.bordersListener);
  }
  
  private void setEnabled() {
    if (this.rounded.isSelected()) {
      this.border.setEnabled(false);
      this.topBorder.setEnabled(false);
      this.leftBorder.setEnabled(false);
      this.bottomBorder.setEnabled(false);
      this.rightBorder.setEnabled(false);
    } else {
      this.border.setEnabled(true);
      this.topBorder.setEnabled(true);
      this.leftBorder.setEnabled(true);
      this.bottomBorder.setEnabled(true);
      this.rightBorder.setEnabled(true);
    } 
  }
  
  public void setElement(ReportElement paramReportElement) {
    super.setElement(paramReportElement);
    this.fixed.setElement((PainterElementDef)paramReportElement);
    this.elem = (TextBoxElementDef)paramReportElement;
    this.border.setSelectedLineStyle(this.elem.getBorder());
    this.rounded.setSelected((this.elem.getShape() == 2));
    Insets insets1 = this.elem.getPadding();
    if (insets1 != null) {
      this.top.setValue(insets1.top);
      this.left.setValue(insets1.left);
      this.bottom.setValue(insets1.bottom);
      this.right.setValue(insets1.right);
    } 
    Insets insets2 = this.elem.getBorders();
    if (insets2 != null) {
      this.topBorder.setSelectedLineStyle(insets2.top);
      this.leftBorder.setSelectedLineStyle(insets2.left);
      this.bottomBorder.setSelectedLineStyle(insets2.bottom);
      this.rightBorder.setSelectedLineStyle(insets2.right);
    } 
    this.thalign.selectOption(this.elem.getTextAlignment());
    this.tvalign.selectOption(this.elem.getTextAlignment());
  }
  
  public boolean populateElement() {
    if (!super.populateElement())
      return false; 
    this.fixed.populateElement();
    this.elem.setBorder(this.border.getSelectedLineStyle());
    this.elem.setShape(this.rounded.isSelected() ? 2 : 1);
    Insets insets1 = new Insets(this.top.intValue(), this.left.intValue(), this.bottom.intValue(), this.right.intValue());
    this.elem.setPadding(insets1);
    Insets insets2 = new Insets(this.topBorder.getSelectedLineStyle(), this.leftBorder.getSelectedLineStyle(), this.bottomBorder.getSelectedLineStyle(), this.rightBorder.getSelectedLineStyle());
    this.elem.setBorders((insets2.top != -1 || insets2.left != -1 || insets2.bottom != -1 || insets2.right != -1) ? insets2 : null);
    this.elem.setTextAlignment(this.thalign.getSelectedOption() | this.tvalign.getSelectedOption());
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TextBoxProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */