package inetsoft.report.design;

import inetsoft.report.internal.TableXElement;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;

class RowAlignmentListener implements ActionListener {
  DesignPane pane;
  
  TableXElement xtable;
  
  int index;
  
  int align;
  
  public RowAlignmentListener(DesignPane paramDesignPane, TableXElement paramTableXElement, int paramInt1, int paramInt2) {
    this.pane = paramDesignPane;
    this.xtable = paramTableXElement;
    this.index = paramInt1;
    this.align = paramInt2;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (((JMenuItem)paramActionEvent.getSource()).isSelected()) {
      this.xtable.setRowAlignment(this.index, this.align);
      this.pane.reprint(this.xtable);
      this.pane.setChanged(true);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\RowAlignmentListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */