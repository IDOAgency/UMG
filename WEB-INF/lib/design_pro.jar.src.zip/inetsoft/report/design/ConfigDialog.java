package inetsoft.report.design;

import inetsoft.report.ReportEnv;
import inetsoft.report.XSessionManager;
import inetsoft.report.locale.Catalog;
import inetsoft.uql.builder.XBuilder;
import inetsoft.widget.Grid2Layout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

class ConfigDialog extends JDialog {
  ActionListener okListener;
  
  ActionListener cancelListener;
  
  ActionListener queryListener;
  
  ActionListener datasourceListener;
  
  JButton okB;
  
  JButton cancelB;
  
  JComboBox lafCB;
  
  boolean ok;
  
  JTabbedPane folder;
  
  public static boolean show(XBuilder paramXBuilder, XSessionManager paramXSessionManager, String paramString) {
    ConfigDialog configDialog = new ConfigDialog(paramXBuilder, paramXSessionManager, paramString);
    configDialog.folder.setSelectedIndex(1);
    configDialog.setModal(true);
    configDialog.pack();
    configDialog.setLocation(80, 80);
    configDialog.setVisible(true);
    return configDialog.isOK();
  }
  
  public ConfigDialog(XBuilder paramXBuilder, XSessionManager paramXSessionManager, String paramString) {
    this.okListener = new ActionListener(this) {
        private final ConfigDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.setConfigInfo()) {
            this.this$0.ok = true;
            this.this$0.dispose();
          } 
        }
      };
    this.cancelListener = new ActionListener(this) {
        private final ConfigDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.queryListener = new ActionListener(this) {
        private final ConfigDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          File file = DesignFrame.promptFile(Catalog.getString("Query Registry"), true, null);
          if (file != null)
            this.this$0.queryTF.setText(file.getAbsolutePath()); 
        }
      };
    this.datasourceListener = new ActionListener(this) {
        private final ConfigDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          File file = DesignFrame.promptFile(Catalog.getString("Datasource Registry"), true, null);
          if (file != null)
            this.this$0.datasourceTF.setText(file.getAbsolutePath()); 
        }
      };
    this.okB = new JButton(Catalog.getString("OK"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.ok = false;
    this.folder = new JTabbedPane();
    this.queryTF = new JTextField(20);
    this.datasourceTF = new JTextField(20);
    this.queryB = new JButton("...");
    this.datasourceB = new JButton("...");
    this.builder = paramXBuilder;
    this.xsession = paramXSessionManager;
    setTitle(Catalog.getString("Designer Configuration"));
    getContentPane().setLayout(new BorderLayout(5, 5));
    JPanel jPanel1 = new JPanel();
    jPanel1.add(this.okB);
    jPanel1.add(this.cancelB);
    getContentPane().add(jPanel1, "South");
    this.folder.setPreferredSize(new Dimension(400, 200));
    getContentPane().add(this.folder, "Center");
    Grid2Layout grid2Layout = new Grid2Layout();
    jPanel1 = new JPanel();
    jPanel1.setLayout(grid2Layout);
    UIManager.LookAndFeelInfo[] arrayOfLookAndFeelInfo = UIManager.getInstalledLookAndFeels();
    String[] arrayOfString = new String[arrayOfLookAndFeelInfo.length];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = arrayOfLookAndFeelInfo[b].getName(); 
    this.lafCB = new JComboBox(arrayOfString);
    this.lafCB.setSelectedItem(DesignEnv.getProperty("report.designer.laf"));
    jPanel1.add(new JLabel(Catalog.getString("Look & Feel") + ":"), grid2Layout.at(0, 0));
    jPanel1.add(this.lafCB, grid2Layout.at(0, 1));
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout());
    jPanel2.add(jPanel1, "North");
    this.folder.add(jPanel2, Catalog.getString("Look & Feel"));
    this.okB.addActionListener(this.okListener);
    this.cancelB.addActionListener(this.cancelListener);
    jPanel1 = new JPanel();
    grid2Layout = new Grid2Layout(new Insets(1, 1, 1, 1));
    jPanel1.setLayout(grid2Layout);
    this.queryB.setPreferredSize(new Dimension(20, 20));
    this.datasourceB.setPreferredSize(new Dimension(20, 20));
    jPanel1.add(new JLabel(Catalog.getString("Query Registry") + ":"), grid2Layout.at(0, 0, 1, 1, 4));
    jPanel1.add(this.queryTF, grid2Layout.at(0, 1, 1, 1, 16));
    jPanel1.add(this.queryB, grid2Layout.at(0, 2, 1, 1, 16));
    jPanel1.add(new JLabel(Catalog.getString("Datasource Registry") + ":"), grid2Layout.at(1, 0, 1, 1, 4));
    jPanel1.add(this.datasourceTF, grid2Layout.at(1, 1, 1, 1, 16));
    jPanel1.add(this.datasourceB, grid2Layout.at(1, 2, 1, 1, 16));
    jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout());
    jPanel2.add(jPanel1, "North");
    this.folder.add(jPanel2, "Datasource");
    if (paramString == null) {
      jPanel2.add(Box.createRigidArea(new Dimension(5, 30)), "Center");
    } else {
      JTextArea jTextArea = new JTextArea(paramString);
      jTextArea.setEditable(false);
      jTextArea.setBackground(getBackground());
      jTextArea.setFont(new Font("Serif", 1, 12));
      jTextArea.setBorder(new EmptyBorder(5, 5, 5, 5));
      jPanel2.add(jTextArea, "Center");
    } 
    this.queryB.addActionListener(this.queryListener);
    this.datasourceB.addActionListener(this.datasourceListener);
    String str = DesignEnv.getProperty("query.registry.file");
    if (str == null)
      str = ReportEnv.getProperty("user.dir", ".") + File.separator + "query.xml"; 
    this.queryTF.setText(str);
    str = DesignEnv.getProperty("datasource.registry.file");
    if (str == null)
      str = ReportEnv.getProperty("user.dir", ".") + File.separator + "datasource.xml"; 
    this.datasourceTF.setText(str);
  }
  
  public boolean setConfigInfo() {
    String str = (String)this.lafCB.getSelectedItem();
    if (str != null)
      DesignEnv.setProperty("report.designer.laf", str); 
    if (this.queryTF.getText().length() == 0) {
      JOptionPane.showMessageDialog(this, msg_q);
      return false;
    } 
    if (this.datasourceTF.getText().length() == 0) {
      JOptionPane.showMessageDialog(this, msg_d);
      return false;
    } 
    boolean bool = (!DesignEnv.getProperty("query.registry.file", "").equals(this.queryTF.getText()) || !DesignEnv.getProperty("datasource.registry.file", "").equals(this.datasourceTF.getText())) ? 1 : 0;
    if (bool) {
      DesignEnv.setProperty("query.registry.file", this.queryTF.getText());
      DesignEnv.setProperty("datasource.registry.file", this.datasourceTF.getText());
      if (this.builder != null) {
        this.builder.restart();
        this.xsession.setDataService(this.builder.getRepository());
        this.xsession.setSession(this.builder.getSession());
      } 
    } 
    return true;
  }
  
  public boolean isOK() { return this.ok; }
  
  static final String msg_q = Catalog.getString("Query registry file must be specified!");
  
  static final String msg_d = Catalog.getString("Datasource registry file must be specified!");
  
  JTextField queryTF;
  
  JTextField datasourceTF;
  
  JButton queryB;
  
  JButton datasourceB;
  
  XBuilder builder;
  
  XSessionManager xsession;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ConfigDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */