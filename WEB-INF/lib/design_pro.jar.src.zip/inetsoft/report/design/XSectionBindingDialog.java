/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.TableLens;
/*     */ import java.awt.Component;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import javax.swing.JComboBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XSectionBindingDialog
/*     */   extends SectionBindingDialog
/*     */ {
/*     */   ItemListener changeListener;
/*     */   Object[] fieldlist;
/*     */   
/*     */   public XSectionBindingDialog(Frame paramFrame, DesignView paramDesignView) {
/*  35 */     super(paramFrame, paramDesignView);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.changeListener = new ItemListener(this)
/*     */       {
/*  97 */         public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setChanged(true); }
/*     */         
/*     */         private final XSectionBindingDialog this$0;
/*     */       };
/* 101 */     this.fieldlist = null;
/*     */   }
/*     */   
/*     */   public void setSection(SectionElement paramSectionElement) {
/*     */     TableLens tableLens = paramSectionElement.getTable();
/*     */     if (tableLens != null) {
/*     */       this.fieldlist = new Object[tableLens.getColCount()];
/*     */       for (byte b = 0; b < this.fieldlist.length; b++)
/*     */         this.fieldlist[b] = tableLens.getObject(0, b); 
/*     */     } 
/*     */     super.setSection(paramSectionElement);
/*     */   }
/*     */   
/*     */   protected Component createBindingComponent() { return (this.fieldlist == null) ? super.createBindingComponent() : new JComboBox(this.fieldlist); }
/*     */   
/*     */   protected void addChangeListener(Component paramComponent) {
/*     */     if (this.fieldlist == null) {
/*     */       super.addChangeListener(paramComponent);
/*     */     } else {
/*     */       ((JComboBox)paramComponent).addItemListener(this.changeListener);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setBindingValue(Component paramComponent, String paramString) {
/*     */     if (this.fieldlist == null) {
/*     */       super.setBindingValue(paramComponent, paramString);
/*     */     } else {
/*     */       ((JComboBox)paramComponent).setSelectedItem(paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected String getBindingValue(Component paramComponent) { return (this.fieldlist == null) ? super.getBindingValue(paramComponent) : (String)((JComboBox)paramComponent).getSelectedItem(); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\XSectionBindingDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */