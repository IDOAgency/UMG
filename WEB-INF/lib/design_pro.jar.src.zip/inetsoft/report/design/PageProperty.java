package inetsoft.report.design;

import inetsoft.report.Margin;
import inetsoft.report.Size;
import inetsoft.report.StyleSheet;
import inetsoft.report.XStyleSheet;
import inetsoft.report.internal.PaperSize;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.ColorComboBox;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.TextEvent;
import java.awt.event.TextListener;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class PageProperty extends PropertyDialog {
  ItemListener unitListener;
  
  ItemListener sizeListener;
  
  ItemListener bgListener;
  
  TextListener customListener;
  
  XStyleSheet page;
  
  NumField top;
  
  NumField left;
  
  NumField bottom;
  
  NumField right;
  
  NumField header;
  
  NumField footer;
  
  JRadioButton std;
  
  JRadioButton custom;
  
  JComboBox size;
  
  NumField width;
  
  NumField height;
  
  JComboBox unit;
  
  JRadioButton portrait;
  
  JRadioButton landscape;
  
  ButtonGroup sizegroup;
  
  ButtonGroup orientgroup;
  
  JRadioButton bgnoneRB;
  
  JRadioButton bgcolorRB;
  
  JRadioButton bgimageRB;
  
  ColorComboBox bgcolor;
  
  ImageLocationPane bgimage;
  
  int currUnit;
  
  public PageProperty(DesignView paramDesignView) {
    super(paramDesignView);
    this.unitListener = new ItemListener(this) {
        private final PageProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          int i = this.this$0.unit.getSelectedIndex();
          if (this.this$0.currUnit != i) {
            double d1 = this.this$0.width.doubleValue();
            double d2 = this.this$0.height.doubleValue();
            this.this$0.width.setValue(d1 * PageProperty.unitratios[i] / PageProperty.unitratios[this.this$0.currUnit]);
            this.this$0.height.setValue(d2 * PageProperty.unitratios[i] / PageProperty.unitratios[this.this$0.currUnit]);
            this.this$0.currUnit = i;
          } 
        }
      };
    this.sizeListener = new ItemListener(this) {
        private final PageProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          Size size = PaperSize.getSize((String)this.this$0.size.getSelectedItem());
          this.this$0.width.setValue(size.width / PageProperty.unitratios[this.this$0.currUnit]);
          this.this$0.height.setValue(size.height / PageProperty.unitratios[this.this$0.currUnit]);
          this.this$0.std.setSelected(true);
        }
      };
    this.bgListener = new ItemListener(this) {
        private final PageProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          this.this$0.bgimage.setEnabled(this.this$0.bgimageRB.isSelected());
          this.this$0.bgcolor.setEnabled(this.this$0.bgcolorRB.isSelected());
        }
      };
    this.customListener = new TextListener(this) {
        private final PageProperty this$0;
        
        public void textValueChanged(TextEvent param1TextEvent) { this.this$0.custom.setSelected((this.this$0.width.getText().length() > 0 && this.this$0.height.getText().length() > 0)); }
      };
    this.top = new NumField(3, false);
    this.left = new NumField(3, false);
    this.bottom = new NumField(3, false);
    this.right = new NumField(3, false);
    this.header = new NumField(3, false);
    this.footer = new NumField(3, false);
    this.std = new JRadioButton(Catalog.getString("Standard") + ":");
    this.custom = new JRadioButton(Catalog.getString("Custom") + ":");
    this.size = new JComboBox(PaperSize.getList());
    this.width = new NumField(5, false);
    this.height = new NumField(5, false);
    this.unit = new JComboBox(unitstrs);
    this.portrait = new JRadioButton(Catalog.getString("Portrait"));
    this.landscape = new JRadioButton(Catalog.getString("Landscape"));
    this.sizegroup = new ButtonGroup();
    this.orientgroup = new ButtonGroup();
    this.bgnoneRB = new JRadioButton(Catalog.getString("(none)"));
    this.bgcolorRB = new JRadioButton(Catalog.getString("Color"));
    this.bgimageRB = new JRadioButton(Catalog.getString("Image"));
    this.bgcolor = new ColorComboBox();
    this.bgimage = new ImageLocationPane();
    this.currUnit = 0;
    setTitle(Catalog.getString("Page Properties"));
    Property2Panel property2Panel = new Property2Panel();
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(0, 0, 0));
    jPanel.add(this.width);
    jPanel.add(new JLabel(" " + Catalog.getString("by") + " "));
    jPanel.add(this.height);
    jPanel.add(new JLabel("  "));
    jPanel.add(this.unit);
    this.unit.setFont(new Font("Dialog", 0, 10));
    property2Panel.add(Catalog.getString("Page Size"), new Object[][] { { this.std, this.size }, { this.custom, jPanel } });
    property2Panel.add(Catalog.getString("Orientation"), new Object[][] { { this.portrait, this.landscape } });
    property2Panel.add(Catalog.getString("Margin"), new Object[][] { { Catalog.getString("Top") + "\":", this.top, Catalog.getString("Left") + "\":", this.left, Catalog.getString("Bottom") + "\":", this.bottom, Catalog.getString("Right") + "\":", this.right } });
    property2Panel.add(Catalog.getString("From Edge"), new Object[][] { { Catalog.getString("Header") + "\":", this.header, Catalog.getString("Footer") + "\":", this.footer } });
    this.folder.addTab(Catalog.getString("Page Layout"), null, property2Panel, Catalog.getString("Page Layout"));
    property2Panel = new Property2Panel();
    property2Panel.add(Catalog.getString("Background"), new Object[][] { { this.bgnoneRB, this.bgcolorRB, this.bgimageRB }, { { Catalog.getString("Color") + ":", this.bgcolor } }, { this.bgimage } });
    this.folder.addTab(Catalog.getString("Background"), null, property2Panel, Catalog.getString("Background"));
    this.sizegroup.add(this.std);
    this.sizegroup.add(this.custom);
    this.std.setSelected(true);
    this.size.setSelectedIndex(0);
    this.orientgroup.add(this.portrait);
    this.orientgroup.add(this.landscape);
    this.portrait.setSelected(true);
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(this.bgnoneRB);
    buttonGroup.add(this.bgcolorRB);
    buttonGroup.add(this.bgimageRB);
    this.unit.addItemListener(this.unitListener);
    this.size.addItemListener(this.sizeListener);
    this.bgnoneRB.addItemListener(this.bgListener);
    this.bgcolorRB.addItemListener(this.bgListener);
    this.bgimageRB.addItemListener(this.bgListener);
  }
  
  public void setElement(StyleSheet paramStyleSheet) {
    this.page = (XStyleSheet)paramStyleSheet;
    setElement(null);
    Margin margin = this.page.getMargin();
    this.top.setValue(margin.top);
    this.left.setValue(margin.left);
    this.bottom.setValue(margin.bottom);
    this.right.setValue(margin.right);
    this.header.setValue(this.page.getHeaderFromEdge());
    this.footer.setValue(this.page.getFooterFromEdge());
    String str1 = this.page.getProperty("PageSize");
    if (str1 != null) {
      int i = PaperSize.getIndex(str1);
      if (i >= 0) {
        this.std.setSelected(true);
        this.size.setSelectedIndex(i);
      } else {
        this.custom.setSelected(true);
        Size size1 = PaperSize.getSize(str1);
        this.width.setValue(size1.width);
        this.height.setValue(size1.height);
      } 
    } else {
      this.size.setSelectedIndex(0);
    } 
    String str2 = this.page.getProperty("Orientation");
    this.landscape.setSelected((PaperSize.getOrientation(str2) == 0));
    this.width.addTextListener(this.customListener);
    this.height.addTextListener(this.customListener);
    Object object = paramStyleSheet.getBackground();
    if (object == null) {
      this.bgnoneRB.setSelected(true);
    } else if (object instanceof Color) {
      this.bgcolorRB.setSelected(true);
      this.bgcolor.setSelectedColor((Color)object);
    } else if (object instanceof java.awt.Image) {
      this.bgimageRB.setSelected(true);
      this.bgimage.setImageLocation(this.page.getBackgroundImageLocation());
    } 
  }
  
  public boolean populateElement() {
    Margin margin = new Margin(this.top.doubleValue(), this.left.doubleValue(), this.bottom.doubleValue(), this.right.doubleValue());
    this.page.setMargin(margin);
    this.page.setHeaderFromEdge(this.header.doubleValue());
    this.page.setFooterFromEdge(this.footer.doubleValue());
    if (this.std.isSelected()) {
      this.page.setProperty("PageSize", (String)this.size.getSelectedItem());
    } else {
      double d1 = this.width.doubleValue();
      double d2 = this.height.doubleValue();
      d1 *= unitratios[0] / unitratios[this.currUnit];
      d2 *= unitratios[0] / unitratios[this.currUnit];
      this.page.setProperty("PageSize", d1 + "x" + d2);
    } 
    this.page.setProperty("Orientation", this.portrait.isSelected() ? "Portrait" : "Landscape");
    if (this.bgnoneRB.isSelected()) {
      this.page.setBackground(null);
      this.page.setBackgroundImageLocation(null);
    } else if (this.bgcolorRB.isSelected()) {
      this.page.setBackground(this.bgcolor.getSelectedColor());
    } else if (this.bgimageRB.isSelected()) {
      this.page.setBackgroundImageLocation(this.bgimage.getImageLocation());
    } 
    return true;
  }
  
  static final String[] unitstrs = { Catalog.getString("inches"), Catalog.getString("mm"), Catalog.getString("points") };
  
  static final double[] unitratios = { 1.0D, 25.39882D, 72.0D };
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\PageProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */