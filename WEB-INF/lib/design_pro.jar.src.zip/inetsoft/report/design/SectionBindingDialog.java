package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.Grid2Layout;
import inetsoft.widget.STree;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

public class SectionBindingDialog extends JDialog {
  TreeSelectionListener treeListener;
  
  DocumentListener changeListener;
  
  FocusListener focusListener;
  
  DesignView view;
  
  boolean changed;
  
  SectionElement elem;
  
  SectionBand currband;
  
  String[] ids;
  
  Component[] fields;
  
  JPanel pane;
  
  JScrollPane paneCR;
  
  Grid2Layout paneLO;
  
  JScrollPane treeCR;
  
  SectionTree tree;
  
  JButton closeB;
  
  public SectionBindingDialog(Frame paramFrame, DesignView paramDesignView) {
    super(paramFrame);
    this.treeListener = new TreeSelectionListener(this) {
        private final SectionBindingDialog this$0;
        
        public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
          STree.Node node = this.this$0.tree.getSelectedNode();
          this.this$0.updateBinding();
          this.this$0.currband = (node != null) ? (SectionBand)node.getUserData() : null;
          this.this$0.populateFields();
        }
      };
    this.changeListener = new DocumentListener(this) {
        private final SectionBindingDialog this$0;
        
        public void insertUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setChanged(true); }
        
        public void removeUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setChanged(true); }
        
        public void changedUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setChanged(true); }
      };
    this.focusListener = new FocusAdapter(this) {
        private final SectionBindingDialog this$0;
        
        public void focusGained(FocusEvent param1FocusEvent) { this.this$0.paneCR.getViewport().scrollRectToVisible(((Component)param1FocusEvent.getSource()).getBounds()); }
      };
    this.changed = false;
    this.pane = new JPanel();
    this.paneLO = new Grid2Layout();
    this.tree = new SectionTree();
    this.closeB = new JButton(Catalog.getString("OK"));
    setTitle(Catalog.getString("Section Binding"));
    this.view = paramDesignView;
    getContentPane().setLayout(new BorderLayout(5, 5));
    this.treeCR = new JScrollPane(this.tree);
    this.treeCR.setPreferredSize(new Dimension(200, 200));
    getContentPane().add(this.treeCR, "West");
    this.pane.setLayout(this.paneLO);
    this.paneCR = new JScrollPane(this.pane);
    this.paneCR.setPreferredSize(new Dimension(250, 200));
    getContentPane().add(this.paneCR, "Center");
    this.tree.addTreeSelectionListener(this.treeListener);
    JPanel jPanel = new JPanel();
    jPanel.add(this.closeB);
    getContentPane().add(jPanel, "South");
    this.closeB.addActionListener(new ActionListener(this) {
          private final SectionBindingDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
        });
    setDefaultCloseOperation(2);
  }
  
  public void setSection(SectionElement paramSectionElement) {
    this.tree.setSection(paramSectionElement);
    this.currband = null;
    populateFields();
  }
  
  public void setSectionBand(SectionBand paramSectionBand) {
    this.treeCR.setVisible(false);
    this.currband = paramSectionBand;
    populateFields();
  }
  
  public void dispose() {
    updateBinding();
    super.dispose();
  }
  
  private void populateFields() {
    while (this.pane.getComponentCount() > 0)
      this.pane.remove(0); 
    if (this.currband == null)
      return; 
    this.ids = new String[this.currband.getElementCount()];
    this.fields = new Component[this.currband.getElementCount()];
    for (byte b = 0; b < this.currband.getElementCount(); b++) {
      ReportElement reportElement = this.currband.getElement(b);
      this.ids[b] = reportElement.getID();
      this.fields[b] = createBindingComponent();
      String str = this.currband.getBinding(reportElement.getID());
      if (str != null)
        setBindingValue(this.fields[b], str); 
      addChangeListener(this.fields[b]);
      this.fields[b].addFocusListener(this.focusListener);
      this.pane.add(new JLabel(this.ids[b]), this.paneLO.at(b, 0));
      this.pane.add(this.fields[b], this.paneLO.at(b, 1));
    } 
    Grid2Layout.Constraints constraints = this.paneLO.at(this.ids.length, 0);
    constraints.weighty = 2.147483647E9D;
    constraints.gridwidth = 0;
    JLabel jLabel = new JLabel("");
    this.pane.add(jLabel, constraints);
    getContentPane().validate();
  }
  
  protected Component createBindingComponent() { return new JTextField(10); }
  
  protected void addChangeListener(Component paramComponent) { ((JTextField)paramComponent).getDocument().addDocumentListener(this.changeListener); }
  
  protected void setBindingValue(Component paramComponent, String paramString) { ((JTextField)paramComponent).setText(paramString); }
  
  protected String getBindingValue(Component paramComponent) { return ((JTextField)paramComponent).getText(); }
  
  public void setChanged(boolean paramBoolean) { this.changed = paramBoolean; }
  
  private void updateBinding() {
    if (this.currband != null && this.ids != null) {
      for (byte b = 0; b < this.ids.length; b++) {
        String str = getBindingValue(this.fields[b]);
        this.currband.setBinding(this.ids[b], (str.length() == 0) ? null : str);
      } 
      this.view.setChanged(true);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionBindingDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */