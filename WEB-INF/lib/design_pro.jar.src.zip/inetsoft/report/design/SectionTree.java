package inetsoft.report.design;

import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.SectionLens;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.STree;
import java.awt.Font;

class SectionTree extends STree {
  public SectionTree() {
    setFont(new Font("Dialog", 0, 10));
    setSelectLeafOnly(true);
  }
  
  public void setSection(SectionElement paramSectionElement) {
    removeAll();
    populateTree(paramSectionElement.getSection(), 0, "Section");
    expandAll();
  }
  
  private void populateTree(SectionLens paramSectionLens, int paramInt, String paramString) {
    String str = (paramInt == 0) ? "Section" : "Group";
    SectionBand sectionBand;
    if ((sectionBand = paramSectionLens.getSectionHeader()) != null) {
      String str1 = paramString + "." + Catalog.getString(str + "Header");
      findNode(str1, true).setUserData(sectionBand);
    } 
    Object object = paramSectionLens.getSectionContent();
    if (object instanceof SectionLens) {
      paramInt++;
      populateTree((SectionLens)object, paramInt, paramString + "." + Catalog.getString("Group") + " #" + paramInt);
    } else {
      String str1 = paramString + "." + Catalog.getString(str + " Content");
      findNode(str1, true).setUserData(object);
    } 
    if ((sectionBand = paramSectionLens.getSectionFooter()) != null) {
      String str1 = paramString + "." + Catalog.getString(str + " Footer");
      findNode(str1, true).setUserData(sectionBand);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */