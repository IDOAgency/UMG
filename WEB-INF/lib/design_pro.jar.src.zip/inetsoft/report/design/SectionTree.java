/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.SectionBand;
/*    */ import inetsoft.report.SectionElement;
/*    */ import inetsoft.report.SectionLens;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import inetsoft.widget.STree;
/*    */ import java.awt.Font;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SectionTree
/*    */   extends STree
/*    */ {
/*    */   public SectionTree() {
/* 33 */     setFont(new Font("Dialog", 0, 10));
/* 34 */     setSelectLeafOnly(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSection(SectionElement paramSectionElement) {
/* 41 */     removeAll();
/* 42 */     populateTree(paramSectionElement.getSection(), 0, "Section");
/* 43 */     expandAll();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void populateTree(SectionLens paramSectionLens, int paramInt, String paramString) {
/* 51 */     String str = (paramInt == 0) ? "Section" : "Group";
/*    */     SectionBand sectionBand;
/* 53 */     if ((sectionBand = paramSectionLens.getSectionHeader()) != null) {
/* 54 */       String str1 = paramString + "." + Catalog.getString(str + "Header");
/* 55 */       findNode(str1, true).setUserData(sectionBand);
/*    */     } 
/*    */     
/* 58 */     Object object = paramSectionLens.getSectionContent();
/*    */     
/* 60 */     if (object instanceof SectionLens) {
/* 61 */       paramInt++;
/* 62 */       populateTree((SectionLens)object, paramInt, paramString + "." + Catalog.getString("Group") + " #" + paramInt);
/*    */     }
/*    */     else {
/*    */       
/* 66 */       String str1 = paramString + "." + Catalog.getString(str + " Content");
/* 67 */       findNode(str1, true).setUserData(object);
/*    */     } 
/*    */     
/* 70 */     if ((sectionBand = paramSectionLens.getSectionFooter()) != null) {
/* 71 */       String str1 = paramString + "." + Catalog.getString(str + " Footer");
/* 72 */       findNode(str1, true).setUserData(sectionBand);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */