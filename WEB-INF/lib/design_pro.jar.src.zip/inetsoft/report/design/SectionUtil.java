/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.SectionBand;
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.SectionLens;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.TextBoxElement;
/*     */ import inetsoft.report.internal.GroupAttr;
/*     */ import inetsoft.report.internal.SectionElementDef;
/*     */ import inetsoft.report.internal.SectionXElement;
/*     */ import inetsoft.report.lens.DefaultSectionLens;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SectionUtil
/*     */ {
/*     */   static final int GAP = 4;
/*     */   
/*     */   public static void generateFields(SectionXElement paramSectionXElement, boolean paramBoolean) throws Exception {
/*  36 */     TableLens tableLens = paramSectionXElement.getTable();
/*  37 */     if (tableLens == null) {
/*     */       return;
/*     */     }
/*     */     
/*  41 */     Hashtable hashtable1 = new Hashtable();
/*  42 */     Hashtable hashtable2 = new Hashtable();
/*     */ 
/*     */     
/*  45 */     for (byte b = 0; b < tableLens.getColCount(); b++) {
/*  46 */       Object object1 = tableLens.getObject(0, b);
/*     */       
/*  48 */       if (object1 != null) {
/*  49 */         hashtable2.put(object1, tableLens.getObject(1, b));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  54 */     SectionBand sectionBand1 = paramSectionXElement.getSection().getSectionHeader();
/*  55 */     Object object = paramSectionXElement.getSection().getSectionContent();
/*     */ 
/*     */     
/*  58 */     if (!sectionBand1.isVisible() && paramSectionXElement.getFilter() == null && object instanceof SectionBand) {
/*     */       
/*  60 */       addForm(paramSectionXElement, (SectionBand)object, hashtable2, paramBoolean);
/*     */       
/*     */       return;
/*     */     } 
/*  64 */     addFields(paramSectionXElement, sectionBand1, hashtable2, hashtable1, paramBoolean);
/*     */ 
/*     */ 
/*     */     
/*  68 */     SectionBand sectionBand2 = null;
/*  69 */     for (; object != null; object = ((SectionLens)object).getSectionContent()) {
/*  70 */       if (object instanceof SectionBand) {
/*  71 */         sectionBand2 = (SectionBand)object;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  76 */     addFields(paramSectionXElement, sectionBand2, hashtable2, null, paramBoolean);
/*     */ 
/*     */     
/*  79 */     if (paramSectionXElement.getFilter() instanceof GroupAttr) {
/*  80 */       DefaultSectionLens defaultSectionLens = (DefaultSectionLens)paramSectionXElement.getSection();
/*  81 */       Font font = paramSectionXElement.getFont();
/*  82 */       FontMetrics fontMetrics = Common.getFontMetrics(font);
/*  83 */       int i = (int)Common.getHeight(font, fontMetrics);
/*  84 */       byte b1 = 0;
/*     */ 
/*     */       
/*  87 */       while (defaultSectionLens.getSectionContent() instanceof SectionLens) {
/*  88 */         defaultSectionLens = (DefaultSectionLens)defaultSectionLens.getSectionContent();
/*  89 */         b1++;
/*     */       } 
/*     */       
/*  92 */       SectionBand sectionBand = (SectionBand)defaultSectionLens.getSectionContent();
/*  93 */       GroupAttr groupAttr = (GroupAttr)paramSectionXElement.getFilter();
/*  94 */       String[] arrayOfString1 = groupAttr.getGroupCols();
/*  95 */       String[] arrayOfString2 = groupAttr.getSummaryCols();
/*     */       
/*  97 */       if (arrayOfString1.length > b1) {
/*  98 */         for (; arrayOfString1.length > b1; b1++) {
/*  99 */           sectionBand1 = new SectionBand(sectionBand.getStyleSheet());
/* 100 */           SectionBand sectionBand3 = new SectionBand(sectionBand.getStyleSheet());
/* 101 */           DefaultSectionLens defaultSectionLens1 = new DefaultSectionLens(sectionBand1, sectionBand, sectionBand3);
/*     */           
/* 103 */           Rectangle rectangle = new Rectangle(4, 0, (int)Common.stringWidth(arrayOfString1[b1], font, fontMetrics), i);
/*     */ 
/*     */ 
/*     */           
/* 107 */           addText(sectionBand1, arrayOfString1[b1], arrayOfString1[b1], rectangle, paramBoolean);
/*     */ 
/*     */ 
/*     */           
/* 111 */           int j = 0;
/*     */           
/* 113 */           for (byte b2 = 0; b2 < arrayOfString2.length; b2++) {
/* 114 */             rectangle = (Rectangle)hashtable1.get(arrayOfString2[b2]);
/* 115 */             if (rectangle != null) {
/* 116 */               j = Math.max(j, rectangle.y + rectangle.height);
/* 117 */               addText(sectionBand3, arrayOfString2[b2], "999.99", rectangle, paramBoolean);
/*     */             } 
/*     */           } 
/*     */           
/* 121 */           sectionBand3.setHeight(Math.max(j / 72.0F, sectionBand3.getHeight()));
/*     */           
/* 123 */           defaultSectionLens.setSectionContent(defaultSectionLens1);
/* 124 */           defaultSectionLens = defaultSectionLens1;
/*     */         } 
/*     */       }
/*     */       
/* 128 */       sectionBand2 = paramSectionXElement.getSection().getSectionFooter();
/* 129 */       if (groupAttr.isGrandTotal() && sectionBand2.getElementCount() == 0) {
/*     */         
/* 131 */         int j = 0;
/*     */         
/* 133 */         for (byte b2 = 0; b2 < arrayOfString2.length; b2++) {
/* 134 */           Rectangle rectangle = (Rectangle)hashtable1.get(arrayOfString2[b2]);
/* 135 */           if (rectangle != null) {
/* 136 */             j = Math.max(j, rectangle.y + rectangle.height);
/* 137 */             addText(sectionBand2, arrayOfString2[b2], "999.99", rectangle, paramBoolean);
/*     */           } 
/*     */         } 
/*     */         
/* 141 */         sectionBand2.setHeight(Math.max(j / 72.0F, sectionBand2.getHeight()));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addFields(SectionElement paramSectionElement, SectionBand paramSectionBand, Hashtable paramHashtable1, Hashtable paramHashtable2, boolean paramBoolean) {
/* 154 */     TableLens tableLens = paramSectionElement.getTable();
/* 155 */     Hashtable hashtable = (Hashtable)paramHashtable1.clone();
/* 156 */     int i = 0;
/* 157 */     SectionElementDef sectionElementDef = (SectionElementDef)paramSectionElement;
/* 158 */     int j = (sectionElementDef.getFrame() != null) ? (sectionElementDef.getFrame()).width : 468;
/*     */ 
/*     */     
/* 161 */     for (byte b1 = 0; b1 < paramSectionBand.getElementCount(); b1++) {
/* 162 */       ReportElement reportElement = paramSectionBand.getElement(b1);
/* 163 */       Rectangle rectangle = paramSectionBand.getBounds(b1);
/*     */       
/* 165 */       if (paramHashtable2 != null) {
/*     */         
/* 167 */         String str = reportElement.getProperty("__column__");
/* 168 */         if (str != null) {
/* 169 */           hashtable.remove(str);
/* 170 */           paramHashtable2.put(str, rectangle);
/*     */         } 
/*     */       } else {
/*     */         
/* 174 */         String str = paramSectionBand.getBinding(reportElement.getID());
/* 175 */         if (str != null) {
/* 176 */           hashtable.remove(str);
/*     */         }
/*     */       } 
/*     */       
/* 180 */       i = Math.max(i, rectangle.y + rectangle.height);
/*     */     } 
/*     */ 
/*     */     
/* 184 */     Font font = paramSectionElement.getFont();
/* 185 */     FontMetrics fontMetrics = Common.getFontMetrics(font);
/* 186 */     int k = (int)Common.getHeight(font, fontMetrics);
/* 187 */     int m = 4;
/*     */ 
/*     */     
/* 190 */     for (byte b2 = 0; b2 < tableLens.getColCount(); b2++) {
/* 191 */       String str = (String)tableLens.getObject(0, b2);
/* 192 */       if (str != null && hashtable.get(str) != null) {
/*     */ 
/*     */ 
/*     */         
/* 196 */         String str1 = hashtable.get(str).toString();
/* 197 */         Rectangle rectangle = new Rectangle(m, i, (int)Common.stringWidth(str1, font, fontMetrics), k);
/*     */ 
/*     */         
/* 200 */         rectangle.width = Math.max(rectangle.width, (int)Common.stringWidth(str, font, fontMetrics));
/*     */ 
/*     */         
/* 203 */         if (m + rectangle.width > j && m > 4) {
/* 204 */           rectangle.y = i += k;
/* 205 */           rectangle.x = m = 4;
/*     */         } 
/*     */         
/* 208 */         String str2 = addText(paramSectionBand, null, str, rectangle, paramBoolean);
/*     */         
/* 210 */         if (paramHashtable2 != null) {
/* 211 */           paramSectionBand.getElement(str2).setProperty("__column__", str);
/* 212 */           paramHashtable2.put(str, rectangle);
/*     */         } else {
/*     */           
/* 215 */           paramSectionBand.setBinding(str2, str);
/*     */         } 
/*     */         
/* 218 */         m += rectangle.width + 4;
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     i += k;
/* 223 */     if (paramSectionBand.getHeight() < i / 72.0F) {
/* 224 */       paramSectionBand.setHeight(i / 72.0F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addForm(SectionElement paramSectionElement, SectionBand paramSectionBand, Hashtable paramHashtable, boolean paramBoolean) {
/* 235 */     Hashtable hashtable = (Hashtable)paramHashtable.clone();
/* 236 */     int i = 0;
/* 237 */     SectionElementDef sectionElementDef = (SectionElementDef)paramSectionElement;
/* 238 */     int j = (sectionElementDef.getFrame() != null) ? (sectionElementDef.getFrame()).width : 468;
/*     */ 
/*     */     
/* 241 */     for (byte b1 = 0; b1 < paramSectionBand.getElementCount(); b1++) {
/* 242 */       ReportElement reportElement = paramSectionBand.getElement(b1);
/* 243 */       Rectangle rectangle = paramSectionBand.getBounds(b1);
/*     */       
/* 245 */       String str = paramSectionBand.getBinding(reportElement.getID());
/* 246 */       if (str != null) {
/* 247 */         hashtable.remove(str);
/*     */       }
/*     */       
/* 250 */       i = Math.max(i, rectangle.y + rectangle.height);
/*     */     } 
/*     */ 
/*     */     
/* 254 */     TableLens tableLens = paramSectionElement.getTable();
/* 255 */     Font font = paramSectionElement.getFont();
/* 256 */     FontMetrics fontMetrics = Common.getFontMetrics(font);
/* 257 */     int k = (int)Common.getHeight(font, fontMetrics);
/* 258 */     Enumeration enumeration = hashtable.keys();
/* 259 */     int m = 4;
/*     */ 
/*     */     
/* 262 */     for (byte b2 = 0; b2 < tableLens.getColCount(); b2++) {
/* 263 */       String str = (String)tableLens.getObject(0, b2);
/* 264 */       if (str != null) {
/*     */ 
/*     */ 
/*     */         
/* 268 */         String str1 = hashtable.get(str).toString();
/* 269 */         Rectangle rectangle1 = new Rectangle(m, i, (int)Common.stringWidth(str, font, fontMetrics), k);
/*     */ 
/*     */         
/* 272 */         Rectangle rectangle2 = new Rectangle(m + rectangle1.width + 4, i, (int)Common.stringWidth(str1, font, fontMetrics), k);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 277 */         if (rectangle2.x + rectangle2.width + 4 > j && m > 4) {
/* 278 */           rectangle1.y = i += k;
/* 279 */           rectangle1.x = m = 4;
/* 280 */           rectangle2.y = rectangle1.y;
/* 281 */           rectangle2.x = rectangle1.x + rectangle1.width + 4;
/*     */         } 
/*     */         
/* 284 */         addText(paramSectionBand, null, str, rectangle1, paramBoolean);
/* 285 */         addText(paramSectionBand, str, str1, rectangle2, paramBoolean);
/*     */         
/* 287 */         m += rectangle2.width + rectangle1.width + 8;
/*     */       } 
/*     */     } 
/*     */     
/* 291 */     i += k;
/* 292 */     if (paramSectionBand.getHeight() < i / 72.0F) {
/* 293 */       paramSectionBand.setHeight(i / 72.0F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String addText(SectionBand paramSectionBand, String paramString1, String paramString2, Rectangle paramRectangle, boolean paramBoolean) {
/* 302 */     if (paramBoolean) {
/* 303 */       String str = paramSectionBand.addTextBox(paramString1, paramString2, 0, 65, paramRectangle);
/*     */ 
/*     */       
/* 306 */       TextBoxElement textBoxElement = (TextBoxElement)paramSectionBand.getElement(str);
/* 307 */       textBoxElement.setPadding(new Insets(0, 0, 0, 0));
/* 308 */       textBoxElement.setMargin(new Insets(0, 0, 0, 0));
/* 309 */       return str;
/*     */     } 
/*     */     
/* 312 */     return paramSectionBand.addText(paramString1, paramString2, paramRectangle);
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */