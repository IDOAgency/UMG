package inetsoft.report.design;

import inetsoft.report.Common;
import inetsoft.report.ReportElement;
import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.SectionLens;
import inetsoft.report.TableLens;
import inetsoft.report.TextBoxElement;
import inetsoft.report.internal.GroupAttr;
import inetsoft.report.internal.SectionElementDef;
import inetsoft.report.internal.SectionXElement;
import inetsoft.report.lens.DefaultSectionLens;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.util.Enumeration;
import java.util.Hashtable;

class SectionUtil {
  static final int GAP = 4;
  
  public static void generateFields(SectionXElement paramSectionXElement, boolean paramBoolean) throws Exception {
    TableLens tableLens = paramSectionXElement.getTable();
    if (tableLens == null)
      return; 
    Hashtable hashtable1 = new Hashtable();
    Hashtable hashtable2 = new Hashtable();
    for (byte b = 0; b < tableLens.getColCount(); b++) {
      Object object1 = tableLens.getObject(0, b);
      if (object1 != null)
        hashtable2.put(object1, tableLens.getObject(1, b)); 
    } 
    SectionBand sectionBand1 = paramSectionXElement.getSection().getSectionHeader();
    Object object = paramSectionXElement.getSection().getSectionContent();
    if (!sectionBand1.isVisible() && paramSectionXElement.getFilter() == null && object instanceof SectionBand) {
      addForm(paramSectionXElement, (SectionBand)object, hashtable2, paramBoolean);
      return;
    } 
    addFields(paramSectionXElement, sectionBand1, hashtable2, hashtable1, paramBoolean);
    SectionBand sectionBand2 = null;
    for (; object != null; object = ((SectionLens)object).getSectionContent()) {
      if (object instanceof SectionBand) {
        sectionBand2 = (SectionBand)object;
        break;
      } 
    } 
    addFields(paramSectionXElement, sectionBand2, hashtable2, null, paramBoolean);
    if (paramSectionXElement.getFilter() instanceof GroupAttr) {
      DefaultSectionLens defaultSectionLens = (DefaultSectionLens)paramSectionXElement.getSection();
      Font font = paramSectionXElement.getFont();
      FontMetrics fontMetrics = Common.getFontMetrics(font);
      int i = (int)Common.getHeight(font, fontMetrics);
      byte b1 = 0;
      while (defaultSectionLens.getSectionContent() instanceof SectionLens) {
        defaultSectionLens = (DefaultSectionLens)defaultSectionLens.getSectionContent();
        b1++;
      } 
      SectionBand sectionBand = (SectionBand)defaultSectionLens.getSectionContent();
      GroupAttr groupAttr = (GroupAttr)paramSectionXElement.getFilter();
      String[] arrayOfString1 = groupAttr.getGroupCols();
      String[] arrayOfString2 = groupAttr.getSummaryCols();
      if (arrayOfString1.length > b1)
        for (; arrayOfString1.length > b1; b1++) {
          sectionBand1 = new SectionBand(sectionBand.getStyleSheet());
          SectionBand sectionBand3 = new SectionBand(sectionBand.getStyleSheet());
          DefaultSectionLens defaultSectionLens1 = new DefaultSectionLens(sectionBand1, sectionBand, sectionBand3);
          Rectangle rectangle = new Rectangle(4, 0, (int)Common.stringWidth(arrayOfString1[b1], font, fontMetrics), i);
          addText(sectionBand1, arrayOfString1[b1], arrayOfString1[b1], rectangle, paramBoolean);
          int j = 0;
          for (byte b2 = 0; b2 < arrayOfString2.length; b2++) {
            rectangle = (Rectangle)hashtable1.get(arrayOfString2[b2]);
            if (rectangle != null) {
              j = Math.max(j, rectangle.y + rectangle.height);
              addText(sectionBand3, arrayOfString2[b2], "999.99", rectangle, paramBoolean);
            } 
          } 
          sectionBand3.setHeight(Math.max(j / 72.0F, sectionBand3.getHeight()));
          defaultSectionLens.setSectionContent(defaultSectionLens1);
          defaultSectionLens = defaultSectionLens1;
        }  
      sectionBand2 = paramSectionXElement.getSection().getSectionFooter();
      if (groupAttr.isGrandTotal() && sectionBand2.getElementCount() == 0) {
        int j = 0;
        for (byte b2 = 0; b2 < arrayOfString2.length; b2++) {
          Rectangle rectangle = (Rectangle)hashtable1.get(arrayOfString2[b2]);
          if (rectangle != null) {
            j = Math.max(j, rectangle.y + rectangle.height);
            addText(sectionBand2, arrayOfString2[b2], "999.99", rectangle, paramBoolean);
          } 
        } 
        sectionBand2.setHeight(Math.max(j / 72.0F, sectionBand2.getHeight()));
      } 
    } 
  }
  
  private static void addFields(SectionElement paramSectionElement, SectionBand paramSectionBand, Hashtable paramHashtable1, Hashtable paramHashtable2, boolean paramBoolean) {
    TableLens tableLens = paramSectionElement.getTable();
    Hashtable hashtable = (Hashtable)paramHashtable1.clone();
    int i = 0;
    SectionElementDef sectionElementDef = (SectionElementDef)paramSectionElement;
    int j = (sectionElementDef.getFrame() != null) ? (sectionElementDef.getFrame()).width : 468;
    for (byte b1 = 0; b1 < paramSectionBand.getElementCount(); b1++) {
      ReportElement reportElement = paramSectionBand.getElement(b1);
      Rectangle rectangle = paramSectionBand.getBounds(b1);
      if (paramHashtable2 != null) {
        String str = reportElement.getProperty("__column__");
        if (str != null) {
          hashtable.remove(str);
          paramHashtable2.put(str, rectangle);
        } 
      } else {
        String str = paramSectionBand.getBinding(reportElement.getID());
        if (str != null)
          hashtable.remove(str); 
      } 
      i = Math.max(i, rectangle.y + rectangle.height);
    } 
    Font font = paramSectionElement.getFont();
    FontMetrics fontMetrics = Common.getFontMetrics(font);
    int k = (int)Common.getHeight(font, fontMetrics);
    int m = 4;
    for (byte b2 = 0; b2 < tableLens.getColCount(); b2++) {
      String str = (String)tableLens.getObject(0, b2);
      if (str != null && hashtable.get(str) != null) {
        String str1 = hashtable.get(str).toString();
        Rectangle rectangle = new Rectangle(m, i, (int)Common.stringWidth(str1, font, fontMetrics), k);
        rectangle.width = Math.max(rectangle.width, (int)Common.stringWidth(str, font, fontMetrics));
        if (m + rectangle.width > j && m > 4) {
          rectangle.y = i += k;
          rectangle.x = m = 4;
        } 
        String str2 = addText(paramSectionBand, null, str, rectangle, paramBoolean);
        if (paramHashtable2 != null) {
          paramSectionBand.getElement(str2).setProperty("__column__", str);
          paramHashtable2.put(str, rectangle);
        } else {
          paramSectionBand.setBinding(str2, str);
        } 
        m += rectangle.width + 4;
      } 
    } 
    i += k;
    if (paramSectionBand.getHeight() < i / 72.0F)
      paramSectionBand.setHeight(i / 72.0F); 
  }
  
  private static void addForm(SectionElement paramSectionElement, SectionBand paramSectionBand, Hashtable paramHashtable, boolean paramBoolean) {
    Hashtable hashtable = (Hashtable)paramHashtable.clone();
    int i = 0;
    SectionElementDef sectionElementDef = (SectionElementDef)paramSectionElement;
    int j = (sectionElementDef.getFrame() != null) ? (sectionElementDef.getFrame()).width : 468;
    for (byte b1 = 0; b1 < paramSectionBand.getElementCount(); b1++) {
      ReportElement reportElement = paramSectionBand.getElement(b1);
      Rectangle rectangle = paramSectionBand.getBounds(b1);
      String str = paramSectionBand.getBinding(reportElement.getID());
      if (str != null)
        hashtable.remove(str); 
      i = Math.max(i, rectangle.y + rectangle.height);
    } 
    TableLens tableLens = paramSectionElement.getTable();
    Font font = paramSectionElement.getFont();
    FontMetrics fontMetrics = Common.getFontMetrics(font);
    int k = (int)Common.getHeight(font, fontMetrics);
    Enumeration enumeration = hashtable.keys();
    int m = 4;
    for (byte b2 = 0; b2 < tableLens.getColCount(); b2++) {
      String str = (String)tableLens.getObject(0, b2);
      if (str != null) {
        String str1 = hashtable.get(str).toString();
        Rectangle rectangle1 = new Rectangle(m, i, (int)Common.stringWidth(str, font, fontMetrics), k);
        Rectangle rectangle2 = new Rectangle(m + rectangle1.width + 4, i, (int)Common.stringWidth(str1, font, fontMetrics), k);
        if (rectangle2.x + rectangle2.width + 4 > j && m > 4) {
          rectangle1.y = i += k;
          rectangle1.x = m = 4;
          rectangle2.y = rectangle1.y;
          rectangle2.x = rectangle1.x + rectangle1.width + 4;
        } 
        addText(paramSectionBand, null, str, rectangle1, paramBoolean);
        addText(paramSectionBand, str, str1, rectangle2, paramBoolean);
        m += rectangle2.width + rectangle1.width + 8;
      } 
    } 
    i += k;
    if (paramSectionBand.getHeight() < i / 72.0F)
      paramSectionBand.setHeight(i / 72.0F); 
  }
  
  public static String addText(SectionBand paramSectionBand, String paramString1, String paramString2, Rectangle paramRectangle, boolean paramBoolean) {
    if (paramBoolean) {
      String str = paramSectionBand.addTextBox(paramString1, paramString2, 0, 65, paramRectangle);
      TextBoxElement textBoxElement = (TextBoxElement)paramSectionBand.getElement(str);
      textBoxElement.setPadding(new Insets(0, 0, 0, 0));
      textBoxElement.setMargin(new Insets(0, 0, 0, 0));
      return str;
    } 
    return paramSectionBand.addText(paramString1, paramString2, paramRectangle);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionUtil.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */