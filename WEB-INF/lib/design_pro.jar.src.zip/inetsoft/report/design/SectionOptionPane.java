/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.SectionBand;
/*    */ import inetsoft.report.StyleSheet;
/*    */ import inetsoft.report.internal.SectionXElement;
/*    */ import inetsoft.report.lens.DefaultSectionLens;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import inetsoft.widget.Grid2Layout;
/*    */ import java.awt.event.ItemEvent;
/*    */ import java.awt.event.ItemListener;
/*    */ import javax.swing.JCheckBox;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SectionOptionPane
/*    */   extends JPanel
/*    */ {
/*    */   JCheckBox sectionGenCB;
/*    */   JCheckBox textboxCB;
/*    */   JCheckBox sectionRemoveCB;
/*    */   ReportElement table;
/*    */   DesignFrame frame;
/*    */   
/*    */   public SectionOptionPane(ReportElement paramReportElement, DesignFrame paramDesignFrame) {
/* 88 */     this.sectionGenCB = new JCheckBox(Catalog.getString("Generate section fields"), true);
/*    */     
/* 90 */     this.textboxCB = new JCheckBox(Catalog.getString("Use TextBox for fields"));
/*    */     
/* 92 */     this.sectionRemoveCB = new JCheckBox(Catalog.getString("Remove all existing fields"));
/*    */     this.table = paramReportElement;
/*    */     this.frame = paramDesignFrame;
/*    */     Grid2Layout grid2Layout = new Grid2Layout();
/*    */     setLayout(grid2Layout);
/*    */     add(new JLabel(" "), grid2Layout.at(0, 0));
/*    */     add(this.sectionGenCB, grid2Layout.at(1, 0, 1, 2));
/*    */     add(new JLabel(" "), grid2Layout.at(2, 0));
/*    */     add(this.textboxCB, grid2Layout.at(2, 1));
/*    */     add(this.sectionRemoveCB, grid2Layout.at(3, 1));
/*    */     Grid2Layout.Constraints constraints = grid2Layout.at(4, 0);
/*    */     constraints.weighty = 100.0D;
/*    */     add(new JLabel(" "), constraints);
/*    */     this.sectionGenCB.addItemListener(new ItemListener(this) {
/*    */           private final SectionOptionPane this$0;
/*    */           
/*    */           public void itemStateChanged(ItemEvent param1ItemEvent) {
/*    */             if (!this.this$0.sectionGenCB.isSelected())
/*    */               this.this$0.sectionRemoveCB.setSelected(false); 
/*    */             this.this$0.sectionRemoveCB.setEnabled(this.this$0.sectionGenCB.isSelected());
/*    */             this.this$0.textboxCB.setEnabled(this.this$0.sectionGenCB.isSelected());
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public boolean isRemoveExistingFields() { return this.sectionRemoveCB.isSelected(); }
/*    */   
/*    */   public boolean isUseTextBox() { return this.textboxCB.isSelected(); }
/*    */   
/*    */   public void process() throws Exception {
/*    */     if (this.table instanceof inetsoft.report.SectionElement && this.sectionGenCB.isSelected()) {
/*    */       SectionXElement sectionXElement = (SectionXElement)this.table;
/*    */       if (this.sectionRemoveCB.isSelected()) {
/*    */         StyleSheet styleSheet = sectionXElement.getStyleSheet();
/*    */         sectionXElement.setSection(new DefaultSectionLens(new SectionBand(styleSheet), new SectionBand(styleSheet), new SectionBand(styleSheet)));
/*    */       } 
/*    */       SectionUtil.generateFields(sectionXElement, this.textboxCB.isSelected());
/*    */       this.frame.reprint(null);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionOptionPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */