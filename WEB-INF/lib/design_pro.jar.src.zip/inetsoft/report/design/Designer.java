package inetsoft.report.design;

import inetsoft.report.Common;
import inetsoft.report.Margin;
import inetsoft.report.ReportElement;
import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.StyleFont;
import inetsoft.report.StyleSheet;
import inetsoft.report.XStyleSheet;
import inetsoft.report.internal.BaseElement;
import inetsoft.report.internal.ChartXElement;
import inetsoft.report.internal.Groupable;
import inetsoft.report.internal.PagesMenu;
import inetsoft.report.internal.SectionXElement;
import inetsoft.report.internal.TableXElement;
import inetsoft.report.internal.TextBased;
import inetsoft.report.internal.ToolBar;
import inetsoft.report.internal.Util;
import inetsoft.report.internal.j2d.Common2D;
import inetsoft.report.io.Builder;
import inetsoft.report.locale.Catalog;
import inetsoft.report.style.XTableStyle;
import inetsoft.uql.XEnv;
import inetsoft.uql.builder.XBuilder;
import inetsoft.uql.corba.CorbaHandler;
import inetsoft.widget.ToggleMenuButton;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

public class Designer extends JFrame {
  ActionListener openListener;
  
  ActionListener closeListener;
  
  ActionListener lastOpenListener;
  
  ActionListener newListener;
  
  ActionListener saveListener;
  
  ActionListener saveAsListener;
  
  ActionListener tableListener;
  
  ActionListener tableListener2;
  
  ActionListener textListener;
  
  ActionListener textboxListener;
  
  ActionListener sectionListener;
  
  ActionListener chartListener;
  
  ActionListener chartListener2;
  
  ActionListener imageListener;
  
  ActionListener painterListener;
  
  ActionListener bulletListener;
  
  ActionListener tocListener;
  
  ActionListener headingListener;
  
  ActionListener heading2Listener;
  
  ActionListener containerListener;
  
  ActionListener tabListener;
  
  ActionListener separatorListener;
  
  ActionListener linefeedListener;
  
  ActionListener breakListener;
  
  ActionListener spaceListener;
  
  ActionListener pagebreakListener;
  
  ActionListener condpagebreakListener;
  
  ActionListener areabreakListener;
  
  ActionListener viewListener;
  
  ActionListener rulerListener;
  
  ActionListener gridListener;
  
  ActionListener snapListener;
  
  ActionListener targetListener;
  
  ActionListener layoutListener;
  
  ActionListener areaListener;
  
  ActionListener orderListener;
  
  ActionListener columnsListener;
  
  ItemListener selectListener;
  
  boolean ignore;
  
  AlignListener alignListener;
  
  JustifyListener justifyListener;
  
  FontListener fontListener;
  
  ActionListener leftListener;
  
  ActionListener rightListener;
  
  ActionListener newStyleListener;
  
  ActionListener viewStyleListener;
  
  ActionListener pageListener;
  
  ActionListener tabDefListener;
  
  ActionListener cursorListener;
  
  ActionListener exitListener;
  
  ActionListener editHeaderListener;
  
  ActionListener editFooterListener;
  
  ActionListener editLayoutListener;
  
  ActionListener idListener;
  
  ItemListener horFlowListener;
  
  public ActionListener undoListener;
  
  public ActionListener copyListener;
  
  public ActionListener cutListener;
  
  public ActionListener pasteListener;
  
  public ActionListener scriptListener;
  
  public ActionListener propertyListener;
  
  public KeyListener keyListener;
  
  ActionListener closeAllListener;
  
  ActionListener cascadeListener;
  
  TreeSelectionListener treeListener;
  
  ActionListener sectionAlignListener;
  
  ActionListener sectionDistListener;
  
  ActionListener sectionSizeListener;
  
  ActionListener sectionGenListener;
  
  ActionListener sectionBindingListener;
  
  ActionListener sectionEditListener;
  
  ActionListener optionListener;
  
  ActionListener previewListener;
  
  ActionListener refreshListener;
  
  ActionListener queryListener;
  
  ActionListener bindListener;
  
  ActionListener groupListener;
  
  ActionListener crosstabListener;
  
  ActionListener datasetListener;
  
  ComponentListener builderListener;
  
  ActionListener modifyListener;
  
  ActionListener tableWizardListener;
  
  ActionListener sectionWizardListener;
  
  public Designer() { this(Catalog.getString("Report Designer")); }
  
  public Designer(String paramString) {
    super(paramString);
    this.openListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          File file = this.this$0.promptFile("Open Template", true);
          if (file != null)
            try {
              this.this$0.open(file);
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString(), Catalog.getString("Error"), 0);
            }  
        }
      };
    this.closeListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.currpane != null)
            this.this$0.currpane.dispose(); 
        }
      };
    this.lastOpenListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            this.this$0.open(new File(param1ActionEvent.getActionCommand()));
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, exception.toString(), Catalog.getString("Error"), 0);
          } 
        }
      };
    this.newListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.close(false);
          this.this$0.addWindow(null, this.this$0.filedir, new XStyleSheet());
          this.this$0.currpane.setTextMode(false);
        }
      };
    this.saveListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          String str = this.this$0.currpane.save();
          if (str != null) {
            this.this$0.addToFileMenu(str, false);
            this.this$0.resetFrameName(this.this$0.currpane, str);
          } 
        }
      };
    this.saveAsListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          String str = this.this$0.currpane.saveAs();
          if (str != null) {
            this.this$0.addToFileMenu(str, false);
            this.this$0.resetFrameName(this.this$0.currpane, str);
          } 
        }
      };
    this.tableListener = new ActionListener(this) {
        PagesMenu menu;
        
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Component component = (Component)param1ActionEvent.getSource();
          if (this.menu == null) {
            this.menu = new PagesMenu(this.this$0, 6, 6, "/inetsoft/report/design/images/rect.gif");
            this.menu.show(component);
            this.menu.addWindowListener(new Designer$12(this));
            this.menu.addActionListener(new Designer$13(this));
          } else {
            this.menu.dispose();
            this.menu = null;
          } 
        }
      };
    this.tableListener2 = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertTable(5, 5, false); }
      };
    this.textListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertText(false); }
      };
    this.textboxListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertTextBox(false); }
      };
    this.sectionListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertSection(false); }
      };
    this.chartListener = new ActionListener(this) {
        ListMenu menu;
        
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Component component = (Component)param1ActionEvent.getSource();
          if (this.menu == null) {
            JList jList = new JList(ChartProperty.getStyleNames());
            this.menu = new ListMenu(this.this$0, jList);
            this.menu.show(component);
            this.menu.addWindowListener(new Designer$19(this));
            this.menu.addActionListener(new Designer$20(this));
          } else {
            this.menu.dispose();
            this.menu = null;
          } 
        }
      };
    this.chartListener2 = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertChart(5, false); }
      };
    this.imageListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertImage(false); }
      };
    this.painterListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertPainter(false); }
      };
    this.bulletListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertBullet(false); }
      };
    this.tocListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertTOC(false); }
      };
    this.headingListener = new ActionListener(this) {
        ListMenu menu;
        
        String[] levelstrs;
        
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Component component = (Component)param1ActionEvent.getSource();
          if (this.menu == null) {
            JList jList = new JList(this.levelstrs);
            jList.setVisibleRowCount(this.levelstrs.length + 1);
            this.menu = new ListMenu(this.this$0, jList);
            this.menu.show(component);
            this.menu.addWindowListener(new Designer$27(this));
            this.menu.addActionListener(new Designer$28(this, jList));
          } else {
            this.menu.dispose();
            this.menu = null;
          } 
        }
      };
    this.heading2Listener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertHeading(1, false); }
      };
    this.containerListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertContainer(false); }
      };
    this.tabListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertTab(false); }
      };
    this.separatorListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertSeparator(false); }
      };
    this.linefeedListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertLinefeed(false); }
      };
    this.breakListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertBreak(false); }
      };
    this.spaceListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertSpace(false); }
      };
    this.pagebreakListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertPageBreak(false); }
      };
    this.condpagebreakListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertCondPageBreak(false); }
      };
    this.areabreakListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.insertAreaBreak(false); }
      };
    this.viewListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          boolean bool = ((param1ActionEvent.getSource() == this.this$0.elemmapB && this.this$0.elemmapB.isSelected()) || (param1ActionEvent.getSource() == this.this$0.elemmapM && this.this$0.elemmapM.isSelected()));
          double d = bool ? 0.18D : 0.0D;
          this.this$0.spliter.setDividerLocation(d);
          this.this$0.currpane.setEditArea(param1ActionEvent.getActionCommand().equals(Catalog.getString("Master Layout")));
          this.this$0.layoutB.setSelected(this.this$0.currpane.isEditArea());
          this.this$0.elemmapB.setSelected(bool);
          this.this$0.elemmapM.setSelected(bool);
          this.this$0.setEnabled();
        }
      };
    this.rulerListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignEnv.setProperty("show.ruler", this.this$0.rulerV.isSelected() + "");
          this.this$0.currpane.setShowRuler(this.this$0.rulerV.isSelected());
        }
      };
    this.gridListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignEnv.setProperty("show.grid", this.this$0.gridV.isSelected() + "");
          this.this$0.currpane.setShowGrid(this.this$0.gridV.isSelected());
        }
      };
    this.snapListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignEnv.setProperty("snap.grid", this.this$0.snapGridM.isSelected() + "");
          Resizer.setSnapToGrid(this.this$0.snapGridM.isSelected());
        }
      };
    this.targetListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (param1ActionEvent != null) {
            int i = Integer.parseInt(param1ActionEvent.getActionCommand());
            if (this.this$0.currpane.getTarget() != i)
              this.this$0.currpane.setTarget(i); 
          } 
          switch (this.this$0.currpane.getTarget()) {
            case 256:
              this.this$0.headerM.setSelected(true);
              this.this$0.headerB.setSelected(true);
              break;
            case 0:
              this.this$0.bodyM.setSelected(true);
              this.this$0.bodyB.setSelected(true);
              break;
            case 512:
              this.this$0.footerM.setSelected(true);
              this.this$0.footerB.setSelected(true);
              break;
          } 
        }
      };
    this.layoutListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.currpane.setEditArea(this.this$0.layoutB.isSelected());
          if (this.this$0.layoutB.isSelected()) {
            this.this$0.masterM.setSelected(true);
          } else {
            this.this$0.pageM.setSelected(true);
          } 
          this.this$0.setEnabled();
        }
      };
    this.areaListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.areaB.isSelected()) {
            (new Designer$46(this)).start();
          } else {
            this.this$0.currpane.insertArea(false);
            this.this$0.setStatus("");
          } 
        }
      };
    this.orderListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.orderB.isSelected()) {
            (new Designer$48(this)).start();
          } else {
            this.this$0.currpane.orderAreas(false);
            this.this$0.setStatus("");
          } 
        }
      };
    this.columnsListener = new ActionListener(this) {
        PagesMenu menu;
        
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Component component = (Component)param1ActionEvent.getSource();
          if (this.menu == null) {
            this.menu = new PagesMenu(this.this$0, 1, 4, "/inetsoft/report/design/images/col.gif");
            this.menu.show(component);
            this.menu.addWindowListener(new Designer$50(this));
            this.menu.addActionListener(new Designer$51(this));
          } else {
            this.menu.dispose();
            this.menu = null;
          } 
        }
      };
    this.selectListener = new ItemListener(this) {
        private final Designer this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          Font font;
          int i;
          this.this$0.ignore = true;
          BaseElement baseElement = (BaseElement)this.this$0.currpane.getCurrent();
          ReportElement[] arrayOfReportElement = this.this$0.currpane.getSelectedElements();
          StyleSheet styleSheet = this.this$0.getStyleSheet();
          if (styleSheet == null)
            return; 
          this.this$0.tree.removeTreeSelectionListener(this.this$0.treeListener);
          if (baseElement == null) {
            i = styleSheet.getCurrentAlignment();
            font = styleSheet.getCurrentFont();
            this.this$0.fillB.setSelected(styleSheet.isCurrentJustify());
            this.this$0.tree.clearSelection();
            this.this$0.setStatus("Report");
            this.this$0.idTF.setText("");
            this.this$0.idTF.setEnabled(false);
          } else {
            i = baseElement.getAlignment();
            font = baseElement.getFont();
            if (baseElement instanceof TextBased)
              this.this$0.fillB.setSelected(((TextBased)baseElement).isJustify()); 
            this.this$0.idTF.setText(baseElement.getID());
            this.this$0.idTF.setEnabled(true);
            this.this$0.idTF.setEditable(true);
            TreeModel treeModel = this.this$0.tree.getModel();
            TreePath[] arrayOfTreePath = new TreePath[arrayOfReportElement.length];
            for (byte b = 0; b < arrayOfReportElement.length; b++) {
              arrayOfTreePath[b] = new TreePath(new Object[] { treeModel.getRoot(), this.this$0.currpane.getCurrentPage(), arrayOfReportElement[b] });
            } 
            this.this$0.tree.setSelectionPaths(arrayOfTreePath);
            String str = Catalog.getString("Element") + "  -  " + baseElement.toString();
            if (baseElement.getParent() instanceof SectionBand) {
              String str1 = ((SectionBand)baseElement.getParent()).getBinding(baseElement.getID());
              if (str1 != null)
                str = str + " => " + str1; 
            } 
            this.this$0.setStatus(str);
          } 
          this.this$0.tree.addTreeSelectionListener(this.this$0.treeListener);
          if (this.this$0.currpane.getCurrentPage() != null) {
            DesignPane.DesignPage designPage = this.this$0.currpane.getCurrentPage();
            this.this$0.setPageInfo(designPage.getPageNumber() + 1, this.this$0.currpane.getPageCount(), designPage.getElementCount());
          } else {
            this.this$0.setPageInfo(0, 0, 0);
          } 
          this.this$0.leftB.setSelected(((i & true) != 0));
          this.this$0.centerB.setSelected(((i & 0x2) != 0));
          this.this$0.rightB.setSelected(((i & 0x4) != 0));
          this.this$0.fontCombo.setSelectedItem(font.getName());
          this.this$0.sizeCombo.setSelectedItem(Integer.toString(font.getSize()));
          int j = font.getStyle();
          this.this$0.boldB.setSelected(((j & true) != 0));
          this.this$0.italicB.setSelected(((j & 0x2) != 0));
          this.this$0.underlineB.setSelected(((j & 0x10) != 0));
          this.this$0.ignore = false;
          this.this$0.picktoolB.setSelected(!this.this$0.currpane.isTextMode());
          this.this$0.texttoolB.setSelected(this.this$0.currpane.isTextMode());
          this.this$0.headerB.setSelected((this.this$0.currpane.getTarget() == 256));
          this.this$0.footerB.setSelected((this.this$0.currpane.getTarget() == 512));
          this.this$0.bodyB.setSelected((this.this$0.currpane.getTarget() == 0));
          this.this$0.headerM.setSelected(this.this$0.headerB.isSelected());
          this.this$0.footerM.setSelected(this.this$0.footerB.isSelected());
          this.this$0.bodyM.setSelected(this.this$0.bodyB.isSelected());
          this.this$0.setEnabled();
        }
      };
    this.ignore = false;
    this.alignListener = new AlignListener(this);
    this.justifyListener = new JustifyListener(this);
    this.fontListener = new FontListener(this);
    this.leftListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          ReportElement reportElement = this.this$0.currpane.getCurrent();
          if (reportElement != null) {
            double d1 = reportElement.getIndent();
            double d2 = d1;
            double[] arrayOfDouble = this.this$0.getStyleSheet().getCurrentTabStops();
            for (int i = arrayOfDouble.length - 1; i >= 0; i--) {
              if (d1 > arrayOfDouble[i]) {
                d2 = arrayOfDouble[i];
                break;
              } 
            } 
            if (d2 == d1)
              d2 = 0.0D; 
            reportElement.setIndent(d2);
            this.this$0.currpane.reprint(reportElement);
          } 
        }
      };
    this.rightListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          ReportElement reportElement = this.this$0.currpane.getCurrent();
          if (reportElement != null) {
            double d = reportElement.getIndent();
            double[] arrayOfDouble = this.this$0.getStyleSheet().getCurrentTabStops();
            for (byte b = 0; b < arrayOfDouble.length; b++) {
              if (d < arrayOfDouble[b]) {
                reportElement.setIndent(arrayOfDouble[b]);
                this.this$0.currpane.reprint(reportElement);
                break;
              } 
            } 
          } 
        }
      };
    this.newStyleListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          XTableStyle xTableStyle = StyleDesigner.show(this.this$0, null);
          if (xTableStyle != null) {
            StyleTree.put(xTableStyle.getName(), xTableStyle);
            this.this$0.currpane.setChanged(true);
          } 
        }
      };
    this.viewStyleListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          StyleViewer.show(this.this$0, null);
          this.this$0.currpane.setChanged(true);
        }
      };
    this.pageListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          PageProperty pageProperty = new PageProperty(this.this$0.currpane);
          StyleSheet styleSheet = this.this$0.getStyleSheet();
          pageProperty.setElement(styleSheet);
          pageProperty.setActionListener(new Designer$58(this, styleSheet));
          pageProperty.pack();
          pageProperty.setVisible(true);
        }
      };
    this.tabDefListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          TabDefProperty tabDefProperty = new TabDefProperty(this.this$0.currpane);
          tabDefProperty.setElement(this.this$0.getStyleSheet());
          tabDefProperty.pack();
          tabDefProperty.setVisible(true);
        }
      };
    this.cursorListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.setTextMode(this.this$0.texttoolB.isSelected()); }
      };
    this.exitListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.close(true); }
      };
    this.editHeaderListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Designer.HeaderHeaderDialog headerHeaderDialog = new Designer.HeaderHeaderDialog(this.this$0);
          headerHeaderDialog.pack();
          headerHeaderDialog.setLocation(this.this$0.headerB.getLocation());
          headerHeaderDialog.setVisible(true);
        }
      };
    this.editFooterListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Designer.FooterHeaderDialog footerHeaderDialog = new Designer.FooterHeaderDialog(this.this$0);
          footerHeaderDialog.pack();
          footerHeaderDialog.setLocation(this.this$0.headerB.getLocation());
          footerHeaderDialog.setVisible(true);
        }
      };
    this.editLayoutListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Designer.LayoutDialog layoutDialog = new Designer.LayoutDialog(this.this$0);
          layoutDialog.pack();
          layoutDialog.setLocation(this.this$0.headerB.getLocation());
          layoutDialog.setVisible(true);
        }
      };
    this.idListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          ReportElement reportElement = this.this$0.currpane.getCurrent();
          if (reportElement != null && this.this$0.idTF.getText().length() > 0) {
            ReportElement reportElement1 = this.this$0.currpane.getElement(this.this$0.idTF.getText());
            if (reportElement1 != null && reportElement1 != reportElement) {
              JOptionPane.showMessageDialog(this.this$0, Designer.dup_id, Catalog.getString("Error"), 0);
              return;
            } 
            String str = reportElement.getID();
            this.this$0.currpane.setChanged(true);
            this.this$0.currpane.rename(str, this.this$0.idTF.getText());
            this.this$0.selectListener.itemStateChanged(null);
          } 
        }
      };
    this.horFlowListener = new ItemListener(this) {
        private final Designer this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          StyleSheet styleSheet = this.this$0.getStyleSheet();
          if (styleSheet != null && styleSheet.isHorizontalWrap() != this.this$0.horFlowM.isSelected()) {
            styleSheet.setHorizontalWrap(this.this$0.horFlowM.isSelected());
            this.this$0.currpane.reprint(null);
          } 
        }
      };
    this.undoListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.undo(); }
      };
    this.copyListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.copy(); }
      };
    this.cutListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.cut(); }
      };
    this.pasteListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.paste(); }
      };
    this.scriptListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.editScript(); }
      };
    this.propertyListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currpane.showProperty(); }
      };
    this.keyListener = new KeyAdapter(this) {
        private final Designer this$0;
        
        public void keyPressed(KeyEvent param1KeyEvent) {
          if (param1KeyEvent.getKeyCode() == 127 && this.this$0.currpane != null)
            this.this$0.currpane.cut(); 
        }
      };
    this.closeAllListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          for (int i = this.this$0.mdi.getComponentCount() - 1; i >= 0; i--) {
            try {
              ((JInternalFrame)this.this$0.mdi.getComponent(i)).dispose();
            } catch (Exception exception) {}
          } 
        }
      };
    this.cascadeListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Rectangle rectangle = new Rectangle(1, 1, 0, 0);
          rectangle.width = Math.max(400, (this.this$0.mdi.getSize()).width - 25 * this.this$0.mdi.getComponentCount());
          rectangle.height = Math.max(350, (this.this$0.mdi.getSize()).height - 25 * this.this$0.mdi.getComponentCount());
          for (byte b = 0; b < this.this$0.mdi.getComponentCount(); b++) {
            try {
              JInternalFrame jInternalFrame = (JInternalFrame)this.this$0.mdi.getComponent(b);
              jInternalFrame.setMaximum(false);
              jInternalFrame.reshape(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
              rectangle.x += 25;
              rectangle.y += 25;
            } catch (Exception exception) {
              exception.printStackTrace();
            } 
          } 
        }
      };
    this.treeListener = new TreeSelectionListener(this) {
        private final Designer this$0;
        
        public void valueChanged(TreeSelectionEvent param1TreeSelectionEvent) {
          TreePath[] arrayOfTreePath = this.this$0.tree.getSelectionPaths();
          if (this.this$0.currpane != null && arrayOfTreePath != null) {
            Vector vector = new Vector();
            for (byte b = 0; b < arrayOfTreePath.length; b++) {
              Object object = arrayOfTreePath[b].getLastPathComponent();
              if (object instanceof ReportElement)
                vector.addElement(object); 
            } 
            ReportElement[] arrayOfReportElement = new ReportElement[vector.size()];
            vector.copyInto(arrayOfReportElement);
            this.this$0.currpane.removeItemListener(this.this$0.selectListener);
            this.this$0.currpane.setSelectedElements(arrayOfReportElement);
            this.this$0.currpane.addItemListener(this.this$0.selectListener);
          } 
        }
      };
    this.sectionAlignListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          AlignmentDialog alignmentDialog = new AlignmentDialog(this.this$0, this.this$0.currpane);
          alignmentDialog.pack();
          alignmentDialog.setVisible(true);
        }
      };
    this.sectionDistListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DistributeDialog distributeDialog = new DistributeDialog(this.this$0, this.this$0.currpane);
          distributeDialog.pack();
          distributeDialog.setVisible(true);
        }
      };
    this.sectionSizeListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          SizingDialog sizingDialog = new SizingDialog(this.this$0, this.this$0.currpane);
          sizingDialog.pack();
          sizingDialog.setVisible(true);
        }
      };
    this.sectionGenListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            SectionXElement sectionXElement = (SectionXElement)this.this$0.currpane.getCurrent();
            if (sectionXElement.getTable() != null) {
              SectionOptionDialog.show(sectionXElement, this.this$0.currpane);
            } else {
              SectionGenDialog.show(this.this$0.currpane, sectionXElement);
            } 
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(null, exception.toString());
          } 
        }
      };
    this.sectionBindingListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          BaseElement baseElement = (BaseElement)this.this$0.currpane.getCurrent();
          SectionBindingDialog sectionBindingDialog = createDialog(baseElement);
          if (baseElement instanceof SectionElement) {
            sectionBindingDialog.setSection((SectionElement)this.this$0.currpane.getCurrent());
          } else {
            sectionBindingDialog.setSectionBand((SectionBand)baseElement.getParent());
          } 
          sectionBindingDialog.pack();
          sectionBindingDialog.setVisible(true);
        }
        
        protected SectionBindingDialog createDialog(ReportElement param1ReportElement) {
          if (param1ReportElement instanceof SectionElement && ((SectionElement)param1ReportElement).getTable() != null)
            return new XSectionBindingDialog(this.this$0, this.this$0.currpane); 
          return new SectionBindingDialog(this.this$0, this.this$0.currpane);
        }
      };
    this.sectionEditListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          SectionEditDialog sectionEditDialog = new SectionEditDialog(this.this$0, this.this$0.currpane);
          sectionEditDialog.setSection((SectionElement)this.this$0.currpane.getCurrent());
          sectionEditDialog.pack();
          sectionEditDialog.setVisible(true);
        }
      };
    this.optionListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          ConfigDialog configDialog = this.this$0.createConfigDialog();
          configDialog.setModal(true);
          configDialog.pack();
          configDialog.setLocation(80, 80);
          configDialog.setVisible(true);
        }
      };
    this.previewListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          try {
            DesignFrame designFrame = this.this$0.getCurrentFrame();
            if (designFrame != null && 
              designFrame.save() != null) {
              File file = new File(designFrame.getFileName());
              FileInputStream fileInputStream = new FileInputStream(file);
              Builder builder = Builder.getBuilder(1, fileInputStream);
              StyleSheet styleSheet = builder.read(file.getParent());
              fileInputStream.close();
              PreviewFrame previewFrame = new PreviewFrame(this.this$0.xsession);
              String str = Catalog.getString("Preview") + ": " + file.toString();
              previewFrame.setTitle(str);
              this.this$0.addWindow(str, previewFrame);
              previewFrame.print(styleSheet);
            } 
          } catch (Exception exception) {
            exception.printStackTrace();
            JOptionPane.showMessageDialog(this.this$0, exception.toString());
          } 
        }
      };
    this.refreshListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          if (designFrame != null)
            try {
              designFrame.refresh();
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString());
            }  
        }
      };
    this.queryListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          if (designFrame != null && designFrame.getCurrent() != null) {
            ReportElement reportElement = designFrame.getCurrent();
            this.this$0.editquery = reportElement.getProperty("query");
            if (this.this$0.editquery != null)
              this.this$0.builder.showQuery(this.this$0.editquery); 
          } 
          this.this$0.builder.pack();
          this.this$0.builder.setVisible(true);
        }
      };
    this.bindListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          ReportElement reportElement = designFrame.getCurrent();
          if (reportElement != null)
            BindingDialog.show(this.this$0.xsession, reportElement, designFrame, this.this$0.builder, new Designer$89(this)); 
        }
      };
    this.groupListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          ReportElement reportElement = designFrame.getCurrent();
          if (GroupingDialog.show((Groupable)reportElement)) {
            try {
              if (reportElement instanceof SectionXElement)
                SectionUtil.generateFields((SectionXElement)reportElement, true); 
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString());
            } 
            designFrame.reprint(reportElement);
          } 
        }
      };
    this.crosstabListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          ReportElement reportElement = designFrame.getCurrent();
          TableXElement tableXElement = (TableXElement)reportElement;
          if (CrosstabDialog.show(tableXElement))
            designFrame.reprint(reportElement); 
        }
      };
    this.datasetListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          ReportElement reportElement = designFrame.getCurrent();
          ChartXElement chartXElement = (ChartXElement)reportElement;
          if (DatasetDialog.show(chartXElement))
            try {
              designFrame.refresh();
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString());
            }  
        }
      };
    this.builderListener = new ComponentAdapter(this) {
        private final Designer this$0;
        
        public void componentHidden(ComponentEvent param1ComponentEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          if (designFrame != null && this.this$0.editquery != null && this.this$0.queryChanged)
            try {
              designFrame.refresh();
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(this.this$0, exception.toString());
            }  
          this.this$0.editquery = null;
          this.this$0.queryChanged = false;
        }
      };
    this.modifyListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.queryChanged = true; }
      };
    this.tableWizardListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          TableXElement tableXElement = new TableXElement(designFrame.getStyleSheet());
          BindingDialog.show(this.this$0.xsession, tableXElement, designFrame, this.this$0.builder, new Designer$96(this, tableXElement, designFrame));
        }
      };
    this.sectionWizardListener = new ActionListener(this) {
        private final Designer this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignFrame designFrame = this.this$0.getCurrentFrame();
          SectionXElement sectionXElement = new SectionXElement(designFrame.getStyleSheet());
          BindingDialog bindingDialog = new BindingDialog(this.this$0.xsession, sectionXElement, designFrame, this.this$0.builder, null);
          bindingDialog.setActionListener(new Designer$99(this, sectionXElement, designFrame, bindingDialog));
          bindingDialog.pack();
          bindingDialog.setVisible(true);
        }
      };
    this.currpane = null;
    this.lastFileM = 0;
    this.openmap = new Hashtable();
    this.filedir = null;
    this.mdi = new DesignMDI(this);
    this.lastFiles = new Vector();
    this.winmap = new Hashtable();
    this.editHeaderM = new JMenuItem(Catalog.getString("Edit..."));
    this.editFooterM = new JMenuItem(Catalog.getString("Edit..."));
    this.editLayoutM = new JMenuItem(Catalog.getString("Edit..."));
    this.headerTargetMap = new Hashtable();
    this.footerTargetMap = new Hashtable();
    this.layoutTypeMap = new Hashtable();
    this.headerGroupMap = new Hashtable();
    this.footerGroupMap = new Hashtable();
    this.layoutGroupMap = new Hashtable();
    this.alignGroup = new ButtonGroup();
    this.targetGroup = new ButtonGroup();
    this.targetMGroup = new ButtonGroup();
    this.viewGroup = new ButtonGroup();
    this.cursorGroup = new ButtonGroup();
    this.idTF = new JTextField(this, 15) {
        private final Designer this$0;
        
        public Dimension getMaximumSize() {
          Dimension dimension = super.getMaximumSize();
          return new Dimension(150, dimension.height);
        }
      };
    this.queryChanged = false;
    this.editquery = null;
    setProgress(15);
    setDefaultCloseOperation(0);
    getContentPane().setLayout(new BorderLayout());
    this.stdbar = new JToolBar();
    this.stdbar.setBorder(new EtchedBorder(1));
    this.stdbar.setFloatable(false);
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout());
    JButton jButton;
    this.stdbar.add(jButton = Common2D.createToolButton(Designer.class, "images/new.gif"));
    jButton.setToolTipText(Catalog.getString("New Report"));
    jButton.addActionListener(this.newListener);
    this.stdbar.add(jButton = Common2D.createToolButton(Designer.class, "images/open.gif"));
    jButton.setToolTipText(Catalog.getString("Open Report"));
    jButton.addActionListener(this.openListener);
    this.stdbar.add(this.saveB = Common2D.createToolButton(Designer.class, "images/save.gif"));
    this.saveB.setToolTipText(Catalog.getString("Save Report"));
    this.saveB.addActionListener(this.saveListener);
    this.stdbar.add(new ToolBar.Separator());
    this.stdbar.add(this.picktoolB = Common2D.createToolButton(Designer.class, "images/arrow.gif", true));
    this.picktoolB.setToolTipText(Catalog.getString("Pick tool"));
    this.cursorGroup.add(this.picktoolB);
    this.stdbar.add(this.texttoolB = Common2D.createToolButton(Designer.class, "images/texttool.gif", false));
    this.texttoolB.setToolTipText(Catalog.getString("Text tool"));
    this.cursorGroup.add(this.texttoolB);
    this.stdbar.add(new ToolBar.Separator());
    this.stdbar.add(this.headerB = createMenuButton(Designer.class, "images/Header.gif", false));
    this.targetGroup.add(this.headerB);
    this.headerB.setToolTipText(Catalog.getString("Select Header"));
    this.headerB.setActionCommand(Integer.toString(256));
    this.headerB.addActionListener(this.targetListener);
    this.editHeaderM.addActionListener(this.editHeaderListener);
    this.stdbar.add(this.bodyB = Common2D.createToolButton(Designer.class, "images/Body.gif", true));
    this.targetGroup.add(this.bodyB);
    this.bodyB.setToolTipText(Catalog.getString("Select Body"));
    this.bodyB.setActionCommand(Integer.toString(0));
    this.bodyB.addActionListener(this.targetListener);
    this.stdbar.add(this.footerB = createMenuButton(Designer.class, "images/Footer.gif", false));
    this.targetGroup.add(this.footerB);
    this.footerB.setToolTipText(Catalog.getString("Select Footer"));
    this.footerB.setActionCommand(Integer.toString(512));
    this.footerB.addActionListener(this.targetListener);
    this.editFooterM.addActionListener(this.editFooterListener);
    this.stdbar.add(new ToolBar.Separator());
    this.stdbar.add(this.elemmapB = Common2D.createToolButton(Designer.class, "images/elemmap.gif", false));
    this.elemmapB.setActionCommand(Catalog.getString("Element Map"));
    this.elemmapB.setToolTipText(Catalog.getString("Element Map View"));
    this.elemmapB.addActionListener(this.viewListener);
    this.stdbar.add(this.layoutB = createMenuButton(Designer.class, "images/layout.gif", false));
    this.layoutB.setToolTipText(Catalog.getString("Select Layout Type"));
    this.layoutB.addActionListener(this.layoutListener);
    this.stdbar.add(new ToolBar.Separator());
    this.stdbar.add(this.areaB = Common2D.createToolButton(Designer.class, "images/area.gif", false));
    this.areaB.setToolTipText(Catalog.getString("Insert Area"));
    this.areaB.addActionListener(this.areaListener);
    this.stdbar.add(this.orderB = Common2D.createToolButton(Designer.class, "images/order.gif", false));
    this.orderB.setToolTipText(Catalog.getString("Order Areas"));
    this.orderB.addActionListener(this.orderListener);
    this.stdbar.add(new ToolBar.Separator());
    this.stdbar.add(this.columnB = Common2D.createToolButton(Designer.class, "images/column.gif"));
    this.columnB.setToolTipText(Catalog.getString("Columns"));
    this.columnB.addActionListener(this.columnsListener);
    this.combar = new JToolBar(1);
    this.combar.setBorder(new EmptyBorder(0, 0, 0, 0));
    this.combar.setFloatable(false);
    this.combar.add(this.tableWizardB = Common2D.createToolButton(Designer.class, "images/tablewizard.gif"));
    this.tableWizardB.setToolTipText(Catalog.getString("Table Wizard"));
    this.tableWizardB.addActionListener(this.tableWizardListener);
    this.combar.add(this.tableB = Common2D.createToolButton(Designer.class, "images/table.gif"));
    this.tableB.setToolTipText(Catalog.getString("Insert Table"));
    this.tableB.addActionListener(this.tableListener);
    this.combar.add(this.textB = Common2D.createToolButton(Designer.class, "images/text.gif"));
    this.textB.setToolTipText(Catalog.getString("Insert Text"));
    this.textB.addActionListener(this.textListener);
    this.combar.add(this.textboxB = Common2D.createToolButton(Designer.class, "images/textbox.gif"));
    this.textboxB.setToolTipText(Catalog.getString("Insert Text Box"));
    this.textboxB.addActionListener(this.textboxListener);
    this.combar.add(this.sectionWizardB = Common2D.createToolButton(Designer.class, "images/sectionwizard.gif"));
    this.sectionWizardB.setToolTipText(Catalog.getString("Section Wizard"));
    this.sectionWizardB.addActionListener(this.sectionWizardListener);
    this.combar.add(this.sectionB = Common2D.createToolButton(Designer.class, "images/section.gif"));
    this.sectionB.setToolTipText(Catalog.getString("Insert Section"));
    this.sectionB.addActionListener(this.sectionListener);
    this.combar.add(this.chartB = Common2D.createToolButton(Designer.class, "images/chart.gif"));
    this.chartB.setToolTipText(Catalog.getString("Insert Chart"));
    this.chartB.addActionListener(this.chartListener);
    this.combar.add(this.imageB = Common2D.createToolButton(Designer.class, "images/image.gif"));
    this.imageB.setToolTipText(Catalog.getString("Insert Image"));
    this.imageB.addActionListener(this.imageListener);
    this.combar.add(this.painterB = Common2D.createToolButton(Designer.class, "images/painter.gif"));
    this.painterB.setToolTipText(Catalog.getString("Insert Painter/Component"));
    this.painterB.addActionListener(this.painterListener);
    this.combar.add(this.separatorB = Common2D.createToolButton(Designer.class, "images/separator.gif"));
    this.separatorB.setToolTipText(Catalog.getString("Insert Separator"));
    this.separatorB.addActionListener(this.separatorListener);
    this.combar.add(this.bulletB = Common2D.createToolButton(Designer.class, "images/bullet.gif"));
    this.bulletB.setToolTipText(Catalog.getString("Insert Bullet Item"));
    this.bulletB.addActionListener(this.bulletListener);
    this.combar.add(this.tocB = Common2D.createToolButton(Designer.class, "images/toc.gif"));
    this.tocB.setToolTipText(Catalog.getString("Insert Table Of Contents"));
    this.tocB.addActionListener(this.tocListener);
    this.combar.add(this.headingB = Common2D.createToolButton(Designer.class, "images/heading.gif"));
    this.headingB.setToolTipText(Catalog.getString("Insert Heading"));
    this.headingB.addActionListener(this.headingListener);
    this.combar.add(this.containerB = Common2D.createToolButton(Designer.class, "images/container.gif"));
    this.containerB.setToolTipText(Catalog.getString("Insert Container"));
    this.containerB.addActionListener(this.containerListener);
    this.combar.add(this.tabB = Common2D.createToolButton(Designer.class, "images/tab.gif"));
    this.tabB.setToolTipText(Catalog.getString("Insert Tab"));
    this.tabB.addActionListener(this.tabListener);
    this.combar.add(this.enterB = Common2D.createToolButton(Designer.class, "images/enter.gif"));
    this.enterB.setToolTipText(Catalog.getString("Insert Newline"));
    this.enterB.addActionListener(this.linefeedListener);
    this.combar.add(this.spaceB = Common2D.createToolButton(Designer.class, "images/space.gif"));
    this.spaceB.setToolTipText(Catalog.getString("Insert Space"));
    this.spaceB.addActionListener(this.spaceListener);
    setProgress(20);
    this.fmtbar = new JToolBar();
    this.fmtbar.setBorder(new EtchedBorder(1));
    this.fmtbar.setFloatable(false);
    this.fmtbar.add(this.cutB = Common2D.createToolButton(Designer.class, "images/cut.gif"));
    this.cutB.setToolTipText(Catalog.getString("Cut"));
    this.cutB.addActionListener(this.cutListener);
    this.fmtbar.add(this.copyB = Common2D.createToolButton(Designer.class, "images/copy.gif"));
    this.copyB.setToolTipText(Catalog.getString("Copy"));
    this.copyB.addActionListener(this.copyListener);
    this.fmtbar.add(this.pasteB = Common2D.createToolButton(Designer.class, "images/paste.gif"));
    this.pasteB.setToolTipText(Catalog.getString("Paste"));
    this.pasteB.addActionListener(this.pasteListener);
    this.fmtbar.add(new ToolBar.Separator());
    this.fmtbar.add(this.fontCombo = new ComboBox(this, Common.getAllFonts()));
    Dimension dimension = this.fontCombo.getPreferredSize();
    dimension.width = 150;
    this.fontCombo.setPreferredSize(dimension);
    this.fontCombo.setToolTipText(Catalog.getString("Select Font"));
    this.fontCombo.setSelectedIndex(0);
    this.fmtbar.add(this.sizeCombo = new ComboBox(this, fnSize));
    this.sizeCombo.setToolTipText(Catalog.getString("Font Size"));
    this.sizeCombo.setSelectedItem("10");
    this.fmtbar.add(new ToolBar.Separator());
    this.fmtbar.add(this.boldB = Common2D.createToolButton(Designer.class, "images/bold.gif", false));
    this.boldB.setToolTipText(Catalog.getString("Bold"));
    this.fmtbar.add(this.italicB = Common2D.createToolButton(Designer.class, "images/italic.gif", false));
    this.italicB.setToolTipText(Catalog.getString("Italic"));
    this.fmtbar.add(this.underlineB = Common2D.createToolButton(Designer.class, "images/underline.gif", false));
    this.underlineB.setToolTipText(Catalog.getString("Underline"));
    this.fmtbar.add(new ToolBar.Separator());
    this.fmtbar.add(this.leftB = Common2D.createToolButton(Designer.class, "images/left.gif", true));
    this.alignGroup.add(this.leftB);
    this.leftB.setToolTipText(Catalog.getString("Left Alignment"));
    this.fmtbar.add(this.centerB = Common2D.createToolButton(Designer.class, "images/center.gif", false));
    this.alignGroup.add(this.centerB);
    this.centerB.setToolTipText(Catalog.getString("Center Alignment"));
    this.fmtbar.add(this.rightB = Common2D.createToolButton(Designer.class, "images/right.gif", false));
    this.alignGroup.add(this.rightB);
    this.rightB.setToolTipText(Catalog.getString("Right Alignment"));
    this.fmtbar.add(this.fillB = Common2D.createToolButton(Designer.class, "images/fill.gif", false));
    this.fillB.setToolTipText(Catalog.getString("Fill"));
    this.fmtbar.add(new ToolBar.Separator());
    this.fmtbar.add(this.lshiftB = Common2D.createToolButton(Designer.class, "images/lshift.gif"));
    this.lshiftB.setToolTipText(Catalog.getString("Decrease Indent"));
    this.lshiftB.addActionListener(this.leftListener);
    this.fmtbar.add(this.rshiftB = Common2D.createToolButton(Designer.class, "images/rshift.gif"));
    this.rshiftB.setToolTipText(Catalog.getString("Increase Indent"));
    this.rshiftB.addActionListener(this.rightListener);
    setProgress(25);
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout());
    jPanel2.add(this.stdbar, "North");
    jPanel1.add(jPanel2, "North");
    jPanel2 = new JPanel();
    jPanel2.setLayout(new BorderLayout());
    jPanel2.add(this.fmtbar, "North");
    jPanel1.add(jPanel2, "South");
    getContentPane().add(jPanel1, "North");
    this.sidebar = new JPanel();
    this.sidebar.setBorder(new EtchedBorder(1));
    this.sidebar.setLayout(new BorderLayout());
    this.sidebar.add(this.combar, "West");
    getContentPane().add(this.sidebar, "West");
    this.menubar = new JMenuBar();
    this.sectionInsertM = new SectionInsertMenu(this) {
        private final Designer this$0;
        
        public DesignView getDesignView() { return this.this$0.currpane; }
      };
    this.fileM = new JMenu(Catalog.getString("File"));
    this.fileM.setMnemonic('F');
    JMenuItem jMenuItem;
    this.fileM.add(jMenuItem = new JMenuItem(Catalog.getString("New")));
    jMenuItem.setMnemonic('N');
    jMenuItem.setAccelerator(KeyStroke.getKeyStroke(78, 2));
    jMenuItem.addActionListener(this.newListener);
    this.fileM.add(jMenuItem = new JMenuItem(Catalog.getString("Open") + "..."));
    jMenuItem.setMnemonic('O');
    jMenuItem.setAccelerator(KeyStroke.getKeyStroke(79, 2));
    jMenuItem.addActionListener(this.openListener);
    this.fileM.add(this.closeM = new JMenuItem(Catalog.getString("Close")));
    this.closeM.setMnemonic('C');
    this.closeM.addActionListener(this.closeListener);
    this.fileM.addSeparator();
    this.fileM.add(this.saveM = new JMenuItem(Catalog.getString("Save")));
    this.saveM.setAccelerator(KeyStroke.getKeyStroke(83, 2));
    this.saveM.setMnemonic('S');
    this.saveM.addActionListener(this.saveListener);
    this.fileM.add(this.saveAsM = new JMenuItem(Catalog.getString("Save As") + "..."));
    this.saveAsM.setMnemonic('A');
    this.saveAsM.addActionListener(this.saveAsListener);
    this.fileM.addSeparator();
    this.fileM.add(this.pageSetupM = new JMenuItem(Catalog.getString("Page Setup") + "..."));
    this.pageSetupM.setMnemonic('P');
    this.pageSetupM.addActionListener(this.pageListener);
    this.fileM.add(jMenuItem = new JMenuItem(Catalog.getString("Configure") + "..."));
    jMenuItem.setMnemonic('f');
    jMenuItem.addActionListener(this.optionListener);
    this.fileM.addSeparator();
    this.lastFileM = this.fileM.getItemCount();
    setProgress(30);
    for (byte b = 1;; b++) {
      String str = DesignEnv.getProperty("last" + b);
      if (str == null)
        break; 
      addToFileMenu(str, true);
    } 
    this.fileM.addSeparator();
    this.fileM.add(jMenuItem = new JMenuItem(isMain ? Catalog.getString("Exit") : Catalog.getString("Close")));
    jMenuItem.setMnemonic('x');
    jMenuItem.addActionListener(this.exitListener);
    this.menubar.add(this.fileM);
    this.editM = new JMenu(Catalog.getString("Edit"));
    this.editM.setMnemonic('E');
    this.editM.add(this.undoM = new JMenuItem(Catalog.getString("Undo")));
    this.undoM.setMnemonic('U');
    this.undoM.setAccelerator(KeyStroke.getKeyStroke(90, 2));
    this.undoM.addActionListener(this.undoListener);
    this.editM.add(this.copyM = new JMenuItem(Catalog.getString("Copy")));
    this.copyM.setMnemonic('C');
    this.copyM.setAccelerator(KeyStroke.getKeyStroke(67, 2));
    this.copyM.addActionListener(this.copyListener);
    this.editM.add(this.cutM = new JMenuItem(Catalog.getString("Cut")));
    this.cutM.setMnemonic('t');
    this.cutM.setAccelerator(KeyStroke.getKeyStroke(88, 2));
    this.cutM.addActionListener(this.cutListener);
    this.editM.add(this.pasteM = new JMenuItem(Catalog.getString("Paste")));
    this.pasteM.setMnemonic('P');
    this.pasteM.setAccelerator(KeyStroke.getKeyStroke(86, 2));
    this.pasteM.addActionListener(this.pasteListener);
    this.editM.addSeparator();
    this.editM.add(this.scriptM = new JMenuItem(Catalog.getString("Script") + "..."));
    this.scriptM.setMnemonic('S');
    this.scriptM.addActionListener(this.scriptListener);
    this.menubar.add(this.editM);
    JMenu jMenu = new JMenu(Catalog.getString("View"));
    jMenu.setMnemonic('V');
    jMenu.add(this.pageM = new JCheckBoxMenuItem(Catalog.getString("Page Layout"), true));
    this.pageM.setMnemonic('L');
    this.pageM.addActionListener(this.viewListener);
    this.viewGroup.add(this.pageM);
    jMenu.add(this.elemmapM = new JCheckBoxMenuItem(Catalog.getString("Element Map"), false));
    this.elemmapM.setMnemonic('E');
    this.elemmapM.addActionListener(this.viewListener);
    this.viewGroup.add(this.elemmapM);
    jMenu.add(this.masterM = new JCheckBoxMenuItem(Catalog.getString("Master Layout"), false));
    this.masterM.setMnemonic('M');
    this.masterM.addActionListener(this.viewListener);
    this.viewGroup.add(this.masterM);
    jMenu.addSeparator();
    jMenu.add(this.rulerV = new JCheckBoxMenuItem(Catalog.getString("Ruler"), true));
    this.rulerV.setMnemonic('R');
    this.rulerV.addActionListener(this.rulerListener);
    jMenu.add(this.gridV = new JCheckBoxMenuItem(Catalog.getString("Grid"), false));
    this.gridV.setMnemonic('G');
    this.gridV.addActionListener(this.gridListener);
    jMenu.add(this.snapGridM = new JCheckBoxMenuItem(Catalog.getString("Snap to Grid"), Resizer.isSnapToGrid()));
    this.snapGridM.setMnemonic('S');
    this.snapGridM.addActionListener(this.snapListener);
    jMenu.addSeparator();
    jMenu.add(this.propertyM = new JMenuItem(Catalog.getString("Properties") + "..."));
    this.propertyM.setMnemonic('P');
    this.propertyM.addActionListener(this.propertyListener);
    this.menubar.add(jMenu);
    setProgress(35);
    jMenu = new JMenu(Catalog.getString("Insert"));
    jMenu.setMnemonic('I');
    jMenu.add(this.headerM = new JCheckBoxMenuItem(Catalog.getString("Header")));
    this.headerM.setMnemonic('h');
    this.headerM.setActionCommand(Integer.toString(256));
    this.headerM.addActionListener(this.targetListener);
    this.targetMGroup.add(this.headerM);
    jMenu.add(this.bodyM = new JCheckBoxMenuItem(Catalog.getString("Body")));
    this.bodyM.setSelected(true);
    this.bodyM.setMnemonic('o');
    this.bodyM.setActionCommand(Integer.toString(0));
    this.bodyM.addActionListener(this.targetListener);
    this.targetMGroup.add(this.bodyM);
    jMenu.add(this.footerM = new JCheckBoxMenuItem(Catalog.getString("Footer")));
    this.footerM.setMnemonic('r');
    this.footerM.setActionCommand(Integer.toString(512));
    this.footerM.addActionListener(this.targetListener);
    this.targetMGroup.add(this.footerM);
    jMenu.addSeparator();
    jMenu.add(this.enterM = new JMenuItem(Catalog.getString("Newline")));
    this.enterM.setMnemonic('L');
    this.enterM.addActionListener(this.linefeedListener);
    jMenu.add(this.breakM = new JMenuItem(Catalog.getString("Break")));
    this.breakM.setMnemonic('e');
    this.breakM.addActionListener(this.breakListener);
    jMenu.add(this.spaceM = new JMenuItem(Catalog.getString("Space")));
    this.spaceM.setMnemonic('a');
    this.spaceM.addActionListener(this.spaceListener);
    jMenu.add(this.pagebreakM = new JMenuItem(Catalog.getString("Page Break")));
    this.pagebreakM.setMnemonic('k');
    this.pagebreakM.addActionListener(this.pagebreakListener);
    jMenu.add(this.condpagebreakM = new JMenuItem(Catalog.getString("Conditional Page Break")));
    this.condpagebreakM.setMnemonic('o');
    this.condpagebreakM.addActionListener(this.condpagebreakListener);
    jMenu.add(this.areabreakM = new JMenuItem(Catalog.getString("Area Break")));
    this.areabreakM.setMnemonic('r');
    this.areabreakM.addActionListener(this.areabreakListener);
    jMenu.addSeparator();
    setProgress(40);
    jMenu.add(this.tocM = new JMenuItem(Catalog.getString("Table Of Contents")));
    this.tocM.setMnemonic('C');
    this.tocM.addActionListener(this.tocListener);
    jMenu.add(this.headingM = new JMenuItem(Catalog.getString("Heading")));
    this.headingM.setMnemonic('i');
    this.headingM.addActionListener(this.heading2Listener);
    jMenu.add(this.containerM = new JMenuItem(Catalog.getString("Container")));
    this.containerM.setMnemonic('C');
    this.containerM.addActionListener(this.containerListener);
    jMenu.addSeparator();
    jMenu.add(this.tableM = new JMenuItem(Catalog.getString("Table")));
    this.tableM.setMnemonic('a');
    this.tableM.addActionListener(this.tableListener2);
    jMenu.add(this.textM = new JMenuItem(Catalog.getString("Text")));
    this.textM.setMnemonic('T');
    this.textM.addActionListener(this.textListener);
    jMenu.add(this.textboxM = new JMenuItem(Catalog.getString("Text Box")));
    this.textboxM.setMnemonic('x');
    this.textboxM.addActionListener(this.textboxListener);
    jMenu.add(this.sectionM = new JMenuItem(Catalog.getString("Section")));
    this.sectionM.setMnemonic('S');
    this.sectionM.addActionListener(this.sectionListener);
    jMenu.add(this.imageM = new JMenuItem(Catalog.getString("Image")));
    this.imageM.setMnemonic('I');
    this.imageM.addActionListener(this.imageListener);
    jMenu.add(this.chartM = new JMenuItem(Catalog.getString("Chart")));
    this.chartM.setMnemonic('C');
    this.chartM.addActionListener(this.chartListener2);
    jMenu.add(this.painterM = new JMenuItem(Catalog.getString("Painter") + "/" + Catalog.getString("Component")));
    this.painterM.setMnemonic('P');
    this.painterM.addActionListener(this.painterListener);
    jMenu.add(this.tabM = new JMenuItem(Catalog.getString("Tab")));
    this.tabM.setMnemonic('b');
    this.tabM.addActionListener(this.tabListener);
    jMenu.add(this.bulletM = new JMenuItem(Catalog.getString("Bullet")));
    this.bulletM.setMnemonic('u');
    this.bulletM.addActionListener(this.bulletListener);
    jMenu.add(this.separatorM = new JMenuItem(Catalog.getString("Separator")));
    this.separatorM.setMnemonic('S');
    this.separatorM.addActionListener(this.separatorListener);
    this.menubar.add(jMenu);
    setProgress(45);
    this.sectionMenu = new JMenu(Catalog.getString("Section"));
    this.sectionMenu.setMnemonic('S');
    this.sectionMenu.add(this.sectionInsertM);
    this.sectionMenu.add(this.sectionBindM = new JMenuItem(Catalog.getString("Binding") + "..."));
    this.sectionBindM.setMnemonic('B');
    this.sectionBindM.addActionListener(this.sectionBindingListener);
    this.sectionMenu.add(this.sectionEditM = new JMenuItem(Catalog.getString("Edit") + "..."));
    this.sectionEditM.setMnemonic('E');
    this.sectionEditM.addActionListener(this.sectionEditListener);
    jMenu = new JMenu(Catalog.getString("Arrange"));
    jMenu.setMnemonic('A');
    this.sectionMenu.add(jMenu);
    jMenu.add(this.sectionAlignM = new JMenuItem(Catalog.getString("Align") + "..."));
    this.sectionAlignM.setMnemonic('A');
    this.sectionAlignM.addActionListener(this.sectionAlignListener);
    jMenu.add(this.sectionDistM = new JMenuItem(Catalog.getString("Distribute") + "..."));
    this.sectionDistM.setMnemonic('D');
    this.sectionDistM.addActionListener(this.sectionDistListener);
    jMenu.add(this.sectionSizeM = new JMenuItem(Catalog.getString("Change Sizes") + "..."));
    this.sectionSizeM.setMnemonic('S');
    this.sectionSizeM.addActionListener(this.sectionSizeListener);
    this.sectionMenu.addSeparator();
    this.sectionMenu.add(this.sectionGenM = new JMenuItem(Catalog.getString("Generate Fields") + "..."));
    this.sectionGenM.setMnemonic('G');
    this.sectionGenM.addActionListener(this.sectionGenListener);
    this.menubar.add(this.sectionMenu);
    jMenu = new JMenu(Catalog.getString("Format"));
    jMenu.setMnemonic('F');
    jMenu.add(this.tabDefM = new JMenuItem(Catalog.getString("Tab Stops") + "..."));
    this.tabDefM.setMnemonic('T');
    this.tabDefM.addActionListener(this.tabDefListener);
    this.horFlowM = new JCheckBoxMenuItem(Catalog.getString("Horizontal Wrapping"), false);
    jMenu.add(this.horFlowM);
    this.horFlowM.setMnemonic('H');
    this.horFlowM.addItemListener(this.horFlowListener);
    jMenu.addSeparator();
    jMenu.add(this.areaM = new JMenuItem(Catalog.getString("Insert Area")));
    this.areaM.setMnemonic('I');
    this.areaM.addActionListener(this.areaListener);
    jMenu.add(this.orderM = new JMenuItem(Catalog.getString("Order Areas")));
    this.orderM.setMnemonic('O');
    this.orderM.addActionListener(this.orderListener);
    jMenu.addSeparator();
    jMenu.add(this.newStyleM = new JMenuItem(Catalog.getString("Create Table Style") + "..."));
    this.newStyleM.setMnemonic('C');
    this.newStyleM.addActionListener(this.newStyleListener);
    jMenu.add(this.viewStyleM = new JMenuItem(Catalog.getString("View Table Styles") + "..."));
    this.viewStyleM.setMnemonic('V');
    this.viewStyleM.addActionListener(this.viewStyleListener);
    this.menubar.add(jMenu);
    this.windowM = new JMenu(Catalog.getString("Window"));
    this.windowM.setMnemonic('W');
    this.menubar.add(this.windowM);
    this.windowM.add(this.cascadeM = new JMenuItem(Catalog.getString("Cascade")));
    this.cascadeM.setMnemonic('C');
    this.cascadeM.addActionListener(this.cascadeListener);
    this.windowM.add(this.closeAllM = new JMenuItem(Catalog.getString("Close All")));
    this.closeAllM.setMnemonic('A');
    this.closeAllM.addActionListener(this.closeAllListener);
    this.windowM.addSeparator();
    setJMenuBar(this.menubar);
    setProgress(50);
    this.tree = new JTree();
    this.tree.getSelectionModel().setSelectionMode(4);
    this.tree.addKeyListener(this.keyListener);
    JScrollPane jScrollPane = new JScrollPane(this.tree);
    jScrollPane.setMinimumSize(new Dimension(0, 0));
    jScrollPane.setPreferredSize(new Dimension(0, 0));
    this.mdi.setMinimumSize(new Dimension(0, 0));
    this.mdi.setPreferredSize(new Dimension(0, 0));
    this.spliter = new JSplitPane(1, false, jScrollPane, this.mdi);
    this.spliter.setDividerLocation(0);
    getContentPane().add(this.spliter, "Center");
    setProgress(60);
    addWindowListener(new WindowAdapter(this) {
          private final Designer this$0;
          
          public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.close(true); }
        });
    this.tree.addTreeSelectionListener(this.treeListener);
    this.tree.addMouseListener(new MouseAdapter(this) {
          private final Designer this$0;
          
          public void mousePressed(MouseEvent param1MouseEvent) {
            if (this.this$0.currpane != null && this.this$0.currpane.getCurrent() != null) {
              TreePath treePath = this.this$0.tree.getPathForLocation(param1MouseEvent.getX(), param1MouseEvent.getY());
              if (treePath != null && treePath.getLastPathComponent() == this.this$0.currpane.getCurrent())
                if (param1MouseEvent.isPopupTrigger()) {
                  this.this$0.currpane.getPopupMenu(null).show((Component)param1MouseEvent.getSource(), param1MouseEvent.getX(), param1MouseEvent.getY());
                } else if (param1MouseEvent.getClickCount() == 2) {
                  this.this$0.currpane.showProperty();
                }  
            } 
          }
          
          public void mouseReleased(MouseEvent param1MouseEvent) {
            if (this.this$0.currpane != null && this.this$0.currpane.getCurrent() != null && param1MouseEvent.isPopupTrigger()) {
              TreePath treePath = this.this$0.tree.getPathForLocation(param1MouseEvent.getX(), param1MouseEvent.getY());
              if (treePath != null && treePath.getLastPathComponent() == this.this$0.currpane.getCurrent())
                this.this$0.currpane.getPopupMenu(null).show((Component)param1MouseEvent.getSource(), param1MouseEvent.getX(), param1MouseEvent.getY()); 
            } 
          }
        });
    this.leftB.addActionListener(this.alignListener);
    this.centerB.addActionListener(this.alignListener);
    this.rightB.addActionListener(this.alignListener);
    this.fillB.addActionListener(this.justifyListener);
    this.boldB.addActionListener(this.fontListener);
    this.italicB.addActionListener(this.fontListener);
    this.underlineB.addActionListener(this.fontListener);
    this.fontCombo.addItemListener(this.fontListener);
    this.sizeCombo.addItemListener(this.fontListener);
    this.picktoolB.addActionListener(this.cursorListener);
    this.texttoolB.addActionListener(this.cursorListener);
    setProgress(65);
    JPanel jPanel3 = new JPanel();
    jPanel3.setLayout(new GridBagLayout());
    this.pginfo = new JLabel(" ");
    this.status = new JLabel(" ");
    jPanel3.setBorder(new EmptyBorder(1, 0, 0, 0));
    this.pginfo.setBorder(new CompoundBorder(new EmptyBorder(0, 0, 0, 0), new BevelBorder(1)));
    this.status.setBorder(new CompoundBorder(new EmptyBorder(0, 0, 0, 0), new BevelBorder(1)));
    GridBagConstraints gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.weightx = 1.0D;
    gridBagConstraints.fill = 1;
    jPanel3.add(this.pginfo, gridBagConstraints);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.weightx = 0.0D;
    gridBagConstraints.fill = 1;
    jPanel3.add(this.idTF, gridBagConstraints);
    this.idTF.setToolTipText(Catalog.getString("Edit Element ID"));
    this.idTF.addActionListener(this.idListener);
    this.idTF.setBackground(Color.white);
    gridBagConstraints = new GridBagConstraints();
    gridBagConstraints.weightx = 5.0D;
    gridBagConstraints.fill = 1;
    jPanel3.add(this.status, gridBagConstraints);
    getContentPane().add(jPanel3, "South");
    setProgress(70);
    addNotify();
    setProgress(75);
    this.stdbar.add(new ToolBar.Separator());
    this.stdbar.add(this.previewB = Common2D.createToolButton(Designer.class, "images/preview.gif"));
    this.previewB.setToolTipText(Catalog.getString("Preview Report"));
    this.previewB.addActionListener(this.previewListener);
    this.stdbar.add(this.refreshB = Common2D.createToolButton(Designer.class, "images/refresh.gif"));
    this.refreshB.setToolTipText(Catalog.getString("Refresh Report"));
    this.refreshB.addActionListener(this.refreshListener);
    this.stdbar.add(this.builderB = Common2D.createToolButton(Designer.class, "images/qbuilder.gif"));
    this.builderB.setToolTipText(Catalog.getString("Query Builder"));
    this.builderB.addActionListener(this.queryListener);
    this.stdbar.add(this.bindB = Common2D.createToolButton(Designer.class, "images/tableq.gif"));
    this.bindB.setToolTipText(Catalog.getString("Data Binding"));
    this.bindB.addActionListener(this.bindListener);
    this.stdbar.add(this.groupB = Common2D.createToolButton(Designer.class, "images/group.gif"));
    this.groupB.setToolTipText(Catalog.getString("Grouping"));
    this.groupB.addActionListener(this.groupListener);
    this.stdbar.add(this.crosstabB = Common2D.createToolButton(Designer.class, "images/crosstab.gif"));
    this.crosstabB.setToolTipText(Catalog.getString("Crosstab"));
    this.crosstabB.addActionListener(this.crosstabListener);
    this.stdbar.add(this.datasetB = Common2D.createToolButton(Designer.class, "images/dataset.gif"));
    this.datasetB.setToolTipText(Catalog.getString("Chart Summarization"));
    this.datasetB.addActionListener(this.datasetListener);
    jMenu = new JMenu(Catalog.getString("Query"));
    jMenu.setMnemonic('Q');
    jMenu.add(this.previewM = new JMenuItem(Catalog.getString("Preview")));
    this.previewM.setMnemonic('P');
    this.previewM.addActionListener(this.previewListener);
    jMenu.add(this.refreshM = new JMenuItem(Catalog.getString("Refresh")));
    this.refreshM.setMnemonic('R');
    this.refreshM.addActionListener(this.refreshListener);
    jMenu.add(this.builderM = new JMenuItem(Catalog.getString("Query Builder")));
    this.builderM.setMnemonic('B');
    this.builderM.addActionListener(this.queryListener);
    jMenu.add(this.bindM = new JMenuItem(Catalog.getString("Data Binding")));
    this.bindM.setMnemonic('D');
    this.bindM.addActionListener(this.bindListener);
    jMenu.add(this.groupM = new JMenuItem(Catalog.getString("Grouping")));
    this.groupM.setMnemonic('G');
    this.groupM.addActionListener(this.groupListener);
    jMenu.add(this.crosstabM = new JMenuItem(Catalog.getString("Crosstab")));
    this.crosstabM.setMnemonic('C');
    this.crosstabM.addActionListener(this.crosstabListener);
    jMenu.add(this.datasetM = new JMenuItem(Catalog.getString("Chart Summarization")));
    this.datasetM.setMnemonic('s');
    this.datasetM.addActionListener(this.datasetListener);
    jMenu.addSeparator();
    jMenu.add(this.tableWizardM = new JMenuItem(Catalog.getString("Table Wizard") + "..."));
    jMenu.setMnemonic('T');
    jMenu.addActionListener(this.tableWizardListener);
    this.menubar.add(jMenu, this.menubar.getMenuCount() - 1);
    this.sectionMenu.add(this.sectionWizardM = new JMenuItem(Catalog.getString("Section Wizard") + "..."));
    this.sectionWizardM.setMnemonic('W');
    this.sectionWizardM.addActionListener(this.sectionWizardListener);
    this.sectionInsertM.addSeparator();
    this.sectionInsertM.add(this.fieldM = new JMenuItem(Catalog.getString("Data Field") + "..."));
    this.fieldM.setMnemonic('D');
    this.fieldM.addActionListener(this.sectionInsertM.getFieldListener());
    XEnv.init(DesignEnv.getProperties());
    String str1 = XEnv.getProperty("datasource.registry.file");
    String str2 = XEnv.getProperty("query.registry.file");
    if (str1 == null || str2 == null) {
      if (!ConfigDialog.show(null, null, init_msg))
        close(true); 
    } else if ((str1 != null && !(new File(str1)).exists()) || (str2 != null && !(new File(str2)).exists())) {
      JOptionPane.showMessageDialog(this, registry_not_found, Catalog.getString("Warning"), 2);
    } 
    (new Thread(this) {
        private final Designer this$0;
        
        public void run() {
          this.this$0.builder = new XBuilder();
          this.this$0.xsession = new DesignSession(this.this$0.builder.getRepository(), this.this$0.builder.getSession());
          this.this$0.builder.addComponentListener(this.this$0.builderListener);
          this.this$0.builder.addActionListener(this.this$0.modifyListener);
          this.this$0.setEnabled();
          synchronized (this.this$0) {
            this.this$0.notifyAll();
          } 
        }
      }).start();
    setEnabled();
  }
  
  public Designer(String paramString, int paramInt1, int paramInt2) {
    this(paramString);
    this.psize = new Dimension(paramInt1, paramInt2);
  }
  
  protected DesignFrame createDesignFrame() {
    synchronized (this) {
      while (this.xsession == null) {
        try {
          wait();
        } catch (Exception exception) {}
      } 
      DesignFrame designFrame = new DesignFrame();
      designFrame.setDesignSession(this.xsession);
      return designFrame;
    } 
  }
  
  public Dimension getPreferredSize() {
    if (this.psize != null)
      return this.psize; 
    Dimension dimension = new Dimension(getToolkit().getScreenSize());
    dimension.width = Math.min(dimension.width, 850);
    dimension.height = Math.min(dimension.height, 680);
    return dimension;
  }
  
  public void setPreferredSize(Dimension paramDimension) { this.psize = new Dimension(paramDimension); }
  
  public void setPageWidth(double paramDouble) { this.currpane.setPageWidth(paramDouble); }
  
  public double getPageWidth() { return (this.currpane == null) ? 8.5D : this.currpane.getPageWidth(); }
  
  public void setPageHeight(double paramDouble) { this.currpane.setPageHeight(paramDouble); }
  
  public double getPageHeight() { return (this.currpane == null) ? 11.0D : this.currpane.getPageHeight(); }
  
  public void setPageResolution(int paramInt) {
    if (this.currpane != null)
      this.currpane.setPageResolution(paramInt); 
  }
  
  public int getPageResolution() { return (this.currpane == null) ? 72 : this.currpane.getPageResolution(); }
  
  public DesignFrame getCurrentFrame() { return this.currpane; }
  
  public DesignFrame addWindow(String paramString1, String paramString2, StyleSheet paramStyleSheet) {
    this.currpane = createDesignFrame();
    this.currpane.addItemListener(this.selectListener);
    this.currpane.setFileName(paramString1);
    this.currpane.setDirectory(paramString2);
    paramStyleSheet.setOverrideHeader(paramStyleSheet.getElements(256));
    paramStyleSheet.setOverrideFooter(paramStyleSheet.getElements(512));
    this.currpane.print(paramStyleSheet);
    JCheckBoxMenuItem jCheckBoxMenuItem1 = new JCheckBoxMenuItem(Catalog.getString("Default"), true);
    jCheckBoxMenuItem1.addItemListener(new HeaderTargetListener(this, 256));
    JCheckBoxMenuItem jCheckBoxMenuItem2 = new JCheckBoxMenuItem(Catalog.getString("First Page"), false);
    jCheckBoxMenuItem2.addItemListener(new HeaderTargetListener(this, 257));
    JCheckBoxMenuItem jCheckBoxMenuItem3 = new JCheckBoxMenuItem(Catalog.getString("Even Page"), false);
    jCheckBoxMenuItem3.addItemListener(new HeaderTargetListener(this, 258));
    JCheckBoxMenuItem jCheckBoxMenuItem4 = new JCheckBoxMenuItem(Catalog.getString("Odd Page"), false);
    jCheckBoxMenuItem4.addItemListener(new HeaderTargetListener(this, 259));
    JCheckBoxMenuItem jCheckBoxMenuItem5 = new JCheckBoxMenuItem(Catalog.getString("Default"), true);
    jCheckBoxMenuItem5.addItemListener(new FooterTargetListener(this, 512));
    JCheckBoxMenuItem jCheckBoxMenuItem6 = new JCheckBoxMenuItem(Catalog.getString("First Page"), false);
    jCheckBoxMenuItem6.addItemListener(new FooterTargetListener(this, 513));
    JCheckBoxMenuItem jCheckBoxMenuItem7 = new JCheckBoxMenuItem(Catalog.getString("Even Page"), false);
    jCheckBoxMenuItem7.addItemListener(new FooterTargetListener(this, 514));
    JCheckBoxMenuItem jCheckBoxMenuItem8 = new JCheckBoxMenuItem(Catalog.getString("Odd Page"), false);
    jCheckBoxMenuItem8.addItemListener(new FooterTargetListener(this, 515));
    JCheckBoxMenuItem jCheckBoxMenuItem9 = new JCheckBoxMenuItem(Catalog.getString("Default"), true);
    jCheckBoxMenuItem9.addItemListener(new LayoutTypeListener(this, null));
    JPopupMenu jPopupMenu1 = new JPopupMenu();
    this.headerTargetMap.put(this.currpane, jPopupMenu1);
    jPopupMenu1.add(jCheckBoxMenuItem1);
    jPopupMenu1.add(jCheckBoxMenuItem2);
    jPopupMenu1.add(jCheckBoxMenuItem3);
    jPopupMenu1.add(jCheckBoxMenuItem4);
    ButtonGroup buttonGroup1 = new ButtonGroup();
    this.headerGroupMap.put(this.currpane, buttonGroup1);
    buttonGroup1.add(jCheckBoxMenuItem1);
    buttonGroup1.add(jCheckBoxMenuItem2);
    buttonGroup1.add(jCheckBoxMenuItem3);
    buttonGroup1.add(jCheckBoxMenuItem4);
    Hashtable hashtable1 = paramStyleSheet.getElementHeaders();
    if (hashtable1 != null) {
      jPopupMenu1.addSeparator();
      Enumeration enumeration = hashtable1.keys();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        JCheckBoxMenuItem jCheckBoxMenuItem;
        jPopupMenu1.add(jCheckBoxMenuItem = new JCheckBoxMenuItem(str, false));
        jCheckBoxMenuItem.addItemListener(new HeaderTargetListener(this, str));
        buttonGroup1.add(jCheckBoxMenuItem);
      } 
    } 
    jPopupMenu1.addSeparator();
    jPopupMenu1.add(this.editHeaderM);
    JPopupMenu jPopupMenu2 = new JPopupMenu();
    this.footerTargetMap.put(this.currpane, jPopupMenu2);
    jPopupMenu2.add(jCheckBoxMenuItem5);
    jPopupMenu2.add(jCheckBoxMenuItem6);
    jPopupMenu2.add(jCheckBoxMenuItem7);
    jPopupMenu2.add(jCheckBoxMenuItem8);
    ButtonGroup buttonGroup2 = new ButtonGroup();
    this.footerGroupMap.put(this.currpane, buttonGroup2);
    buttonGroup2.add(jCheckBoxMenuItem5);
    buttonGroup2.add(jCheckBoxMenuItem6);
    buttonGroup2.add(jCheckBoxMenuItem7);
    buttonGroup2.add(jCheckBoxMenuItem8);
    Hashtable hashtable2 = paramStyleSheet.getElementFooters();
    if (hashtable2 != null) {
      jPopupMenu2.addSeparator();
      Enumeration enumeration = hashtable2.keys();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        JCheckBoxMenuItem jCheckBoxMenuItem;
        jPopupMenu2.add(jCheckBoxMenuItem = new JCheckBoxMenuItem(str, false));
        jCheckBoxMenuItem.addItemListener(new FooterTargetListener(this, str));
        buttonGroup2.add(jCheckBoxMenuItem);
      } 
    } 
    jPopupMenu2.addSeparator();
    jPopupMenu2.add(this.editFooterM);
    JPopupMenu jPopupMenu3 = new JPopupMenu();
    this.layoutTypeMap.put(this.currpane, jPopupMenu3);
    jPopupMenu3.add(jCheckBoxMenuItem9);
    this.editLayoutM.addActionListener(this.editLayoutListener);
    ButtonGroup buttonGroup3 = new ButtonGroup();
    this.layoutGroupMap.put(this.currpane, buttonGroup3);
    buttonGroup3.add(jCheckBoxMenuItem9);
    Hashtable hashtable3 = paramStyleSheet.getElementAreas();
    if (hashtable3 != null && hashtable3.size() > 0) {
      jPopupMenu3.addSeparator();
      Enumeration enumeration = hashtable3.keys();
      while (enumeration.hasMoreElements()) {
        String str = (String)enumeration.nextElement();
        JCheckBoxMenuItem jCheckBoxMenuItem;
        jPopupMenu3.add(jCheckBoxMenuItem = new JCheckBoxMenuItem(str, false));
        jCheckBoxMenuItem.addItemListener(new LayoutTypeListener(this, str));
        buttonGroup3.add(jCheckBoxMenuItem);
      } 
    } 
    jPopupMenu3.addSeparator();
    jPopupMenu3.add(this.editLayoutM);
    addWindow(paramString1, this.currpane);
    if (paramString1 != null)
      addToFileMenu(paramString1, false); 
    setEnabled();
    return this.currpane;
  }
  
  public void addWindow(String paramString, JInternalFrame paramJInternalFrame) { this.mdi.addWindow(paramString, paramJInternalFrame); }
  
  public void removeWindow(JInternalFrame paramJInternalFrame) {
    JMenuItem jMenuItem = (JMenuItem)this.winmap.get(paramJInternalFrame);
    this.windowM.remove(jMenuItem);
    this.winmap.remove(paramJInternalFrame);
    Enumeration enumeration1 = this.openmap.keys();
    Enumeration enumeration2 = this.openmap.elements();
    while (enumeration2.hasMoreElements()) {
      Object object1 = enumeration1.nextElement();
      Object object2 = enumeration2.nextElement();
      if (object2 == paramJInternalFrame) {
        this.openmap.remove(object1);
        break;
      } 
    } 
  }
  
  public void close(boolean paramBoolean) {
    if (paramBoolean && this.builder != null && !this.builder.close())
      return; 
    if (this.mdi.close() && paramBoolean) {
      dispose();
      for (byte b = 0; b < this.lastFiles.size(); b++)
        DesignEnv.setProperty("last" + (b + true), (String)this.lastFiles.elementAt(b)); 
      DesignEnv.save();
      if (isMain) {
        Point point = getLocation();
        Dimension dimension = getSize();
        DesignEnv.setProperty("window.bounds", point.x + "," + point.y + "," + dimension.width + "," + dimension.height);
        DesignEnv.save();
        System.exit(0);
      } 
    } 
  }
  
  public StyleSheet getStyleSheet() { return (this.currpane != null) ? this.currpane.getStyleSheet() : null; }
  
  public boolean open(File paramFile) throws FileNotFoundException {
    this.filedir = paramFile.getParent();
    if (this.filedir == null)
      this.filedir = "."; 
    DesignFrame designFrame = (DesignFrame)this.openmap.get(paramFile);
    if (designFrame != null) {
      designFrame.toFront();
      return true;
    } 
    try {
      XStyleSheet xStyleSheet = null;
      if (paramFile.exists()) {
        FileInputStream fileInputStream = new FileInputStream(paramFile);
        Builder builder1 = Builder.getBuilder(1, fileInputStream);
        xStyleSheet = builder1.read(this.filedir);
        fileInputStream.close();
        StyleTree.addUserStyles(builder1.getEmbeddedStyles());
      } else {
        xStyleSheet = new XStyleSheet();
      } 
      designFrame = addWindow(paramFile.getPath(), this.filedir, xStyleSheet);
      String str = getStyleSheet().getProperty("TextMode");
      this.openmap.put(paramFile, designFrame);
      designFrame.setTextMode((str != null && str.equals("true")));
      return true;
    } catch (FileNotFoundException fileNotFoundException) {
      throw fileNotFoundException;
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(this, exception.toString(), Catalog.getString("Error"), 0);
      return false;
    } 
  }
  
  public void setStatus(String paramString) { this.status.setText("  " + paramString); }
  
  public void setPageInfo(int paramInt1, int paramInt2, int paramInt3) { this.pginfo.setText((paramInt1 > 0) ? ("  Page " + paramInt1 + " of " + paramInt2 + "            [Elements] " + paramInt3) : " "); }
  
  public File promptFile(String paramString, boolean paramBoolean) {
    if (this.filedir == null)
      this.filedir = DesignEnv.getProperty("work.directory", "."); 
    DesignFrame designFrame = this.currpane;
    if (this.currpane == null) {
      designFrame = createDesignFrame();
      designFrame.setDirectory(this.filedir);
    } 
    return designFrame.promptFile(paramString, paramBoolean);
  }
  
  protected ConfigDialog createConfigDialog() { return new ConfigDialog(this.builder, this.xsession, null); }
  
  protected void setEnabled() {
    boolean bool1 = (this.currpane != null && this.currpane.getCurrent() != null);
    boolean bool2 = (this.currpane != null && this.currpane.isEditArea());
    boolean bool3 = (this.currpane != null && !this.currpane.isEditArea());
    boolean bool4 = (this.currpane != null && this.currpane.getCurrent() instanceof SectionElement);
    boolean bool5 = (bool1 && (bool4 || ((BaseElement)this.currpane.getCurrent()).getParent() instanceof SectionBand));
    boolean bool6 = (this.currpane != null && this.currpane.isAlignable());
    boolean bool7 = (this.currpane != null && this.currpane.isDistributable());
    boolean bool8 = (this.currpane != null && this.currpane.getSelectedElements().length > 0);
    boolean bool9 = (this.xsession != null);
    boolean bool10 = (bool9 && this.currpane != null);
    boolean bool11 = (bool10 && this.currpane.getCurrent() instanceof inetsoft.report.TableElement && !(this.currpane.getCurrent() instanceof inetsoft.report.FormElement)) ? 1 : 0;
    boolean bool12 = (bool10 && this.currpane.getCurrent() instanceof SectionElement) ? 1 : 0;
    boolean bool13 = (bool10 && this.currpane.getCurrent() instanceof inetsoft.report.ChartElement) ? 1 : 0;
    boolean bool14 = ((bool11 || bool12) && this.currpane.getCurrent().getProperty("query") != null);
    boolean bool15 = (bool11 && this.currpane.getCurrent().getProperty("query") != null);
    boolean bool16 = (bool13 && this.currpane.getCurrent().getProperty("query") != null);
    this.editHeaderM.setEnabled((this.currpane != null));
    this.editFooterM.setEnabled((this.currpane != null));
    this.editLayoutM.setEnabled((this.currpane != null));
    this.tabDefM.setEnabled((this.currpane != null));
    this.elemmapB.setEnabled((this.currpane != null));
    this.layoutB.setEnabled((this.currpane != null));
    this.saveB.setEnabled((this.currpane != null));
    this.saveM.setEnabled((this.currpane != null));
    this.saveAsM.setEnabled((this.currpane != null));
    this.pageSetupM.setEnabled((this.currpane != null));
    this.pageM.setEnabled((this.currpane != null));
    this.elemmapM.setEnabled((this.currpane != null));
    this.masterM.setEnabled((this.currpane != null));
    this.rulerV.setEnabled((this.currpane != null));
    this.gridV.setEnabled((this.currpane != null));
    this.horFlowM.setEnabled((this.currpane != null));
    this.cutM.setEnabled(bool1);
    this.copyM.setEnabled(bool8);
    this.pasteM.setEnabled((this.currpane != null && this.currpane.isPasteable()));
    this.cutB.setEnabled(bool1);
    this.copyB.setEnabled(bool1);
    this.pasteB.setEnabled(this.pasteM.isEnabled());
    this.boldB.setEnabled((this.currpane != null));
    this.italicB.setEnabled((this.currpane != null));
    this.underlineB.setEnabled((this.currpane != null));
    this.fontCombo.setEnabled((this.currpane != null));
    this.sizeCombo.setEnabled((this.currpane != null));
    this.leftB.setEnabled((this.currpane != null));
    this.centerB.setEnabled((this.currpane != null));
    this.rightB.setEnabled((this.currpane != null));
    this.fillB.setEnabled((this.currpane != null));
    this.headerB.setEnabled(bool3);
    this.footerB.setEnabled(bool3);
    this.bodyB.setEnabled(bool3);
    this.tableB.setEnabled(bool3);
    this.tableWizardB.setEnabled(bool3);
    this.textB.setEnabled(bool3);
    this.textboxB.setEnabled(bool3);
    this.chartB.setEnabled(bool3);
    this.sectionB.setEnabled(bool3);
    this.sectionWizardB.setEnabled(bool3);
    this.imageB.setEnabled(bool3);
    this.painterB.setEnabled(bool3);
    this.separatorB.setEnabled(bool3);
    this.bulletB.setEnabled(bool3);
    this.tabB.setEnabled(bool3);
    this.enterB.setEnabled(bool3);
    this.spaceB.setEnabled(bool3);
    this.areaB.setEnabled(bool2);
    this.orderB.setEnabled(bool2);
    this.columnB.setEnabled(bool3);
    this.lshiftB.setEnabled(bool1);
    this.rshiftB.setEnabled(bool1);
    this.headerM.setEnabled(bool3);
    this.footerM.setEnabled(bool3);
    this.bodyM.setEnabled(bool3);
    this.tableM.setEnabled(bool3);
    this.tableWizardM.setEnabled(bool3);
    this.textM.setEnabled(bool3);
    this.textboxM.setEnabled(bool3);
    this.sectionM.setEnabled(bool3);
    this.sectionWizardM.setEnabled(bool3);
    this.chartM.setEnabled(bool3);
    this.imageM.setEnabled(bool3);
    this.painterM.setEnabled(bool3);
    this.separatorM.setEnabled(bool3);
    this.bulletM.setEnabled(bool3);
    this.tabM.setEnabled(bool3);
    this.enterM.setEnabled(bool3);
    this.spaceM.setEnabled(bool3);
    this.breakM.setEnabled(bool3);
    this.pagebreakM.setEnabled(bool3);
    this.condpagebreakM.setEnabled(bool3);
    this.areabreakM.setEnabled(bool3);
    this.areaM.setEnabled(bool2);
    this.orderM.setEnabled(bool2);
    this.propertyM.setEnabled(bool1);
    this.undoM.setEnabled((this.currpane != null && this.currpane.getUndoCount() > 0));
    this.picktoolB.setEnabled(bool3);
    this.texttoolB.setEnabled(bool3);
    this.tocM.setEnabled(bool3);
    this.headingM.setEnabled(bool3);
    this.containerM.setEnabled(bool3);
    this.tocB.setEnabled(bool3);
    this.headingB.setEnabled(bool3);
    this.containerB.setEnabled(bool3);
    this.scriptM.setEnabled((this.currpane != null));
    this.closeM.setEnabled((this.currpane != null));
    this.sectionInsertM.setPopupMenuVisible(false);
    this.sectionInsertM.setEnabled(bool4);
    this.sectionAlignM.setEnabled(bool6);
    this.sectionSizeM.setEnabled(bool6);
    this.sectionDistM.setEnabled(bool7);
    this.sectionEditM.setEnabled(bool4);
    this.sectionBindM.setEnabled(bool5);
    this.sectionGenM.setEnabled(bool4);
    this.builderB.setEnabled(bool9);
    this.builderM.setEnabled(this.builderB.isEnabled());
    this.bindB.setEnabled((bool10 && isBindable(this.currpane.getCurrent())));
    this.bindM.setEnabled(this.bindB.isEnabled());
    this.previewB.setEnabled(bool10);
    this.previewM.setEnabled(bool10);
    this.refreshB.setEnabled(bool10);
    this.refreshM.setEnabled(bool10);
    this.groupB.setEnabled(bool14);
    this.groupM.setEnabled(this.groupB.isEnabled());
    this.crosstabB.setEnabled(bool15);
    this.crosstabM.setEnabled(this.crosstabB.isEnabled());
    this.datasetB.setEnabled(bool16);
    this.datasetM.setEnabled(bool16);
    this.fieldM.setEnabled(bool14);
  }
  
  private void addToFileMenu(String paramString, boolean paramBoolean) {
    int i = this.lastFiles.indexOf(paramString);
    if (i < 0) {
      JMenuItem jMenuItem = new JMenuItem("1 " + paramString);
      jMenuItem.setActionCommand(paramString);
      jMenuItem.addActionListener(this.lastOpenListener);
      if (paramBoolean) {
        this.fileM.insert(jMenuItem, this.lastFileM + this.lastFiles.size());
        this.lastFiles.addElement(paramString);
      } else {
        this.fileM.insert(jMenuItem, this.lastFileM);
        this.lastFiles.insertElementAt(paramString, 0);
      } 
      if (this.lastFiles.size() > 9) {
        this.lastFiles.removeElementAt(9);
        this.fileM.remove(this.lastFileM + 9);
      } 
    } else if (i > 0) {
      this.lastFiles.insertElementAt(this.lastFiles.elementAt(i), 0);
      this.lastFiles.removeElementAt(i + 1);
      JMenuItem jMenuItem = this.fileM.getItem(this.lastFileM + i);
      this.fileM.remove(this.lastFileM + i);
      this.fileM.insert(jMenuItem, this.lastFileM);
    } 
    for (int j = 0; j < this.lastFiles.size(); j++) {
      JMenuItem jMenuItem = this.fileM.getItem(j + this.lastFileM);
      if (jMenuItem == null)
        break; 
      int k = j + 1;
      String str = jMenuItem.getActionCommand();
      int m = str.lastIndexOf(File.separator);
      int n = (m > 0) ? str.lastIndexOf(File.separator, m - 1) : -1;
      jMenuItem.setText(k + " " + ((n >= 0) ? str.substring(n + 1) : ((m >= 0) ? str.substring(m + 1) : str)));
      jMenuItem.setMnemonic(Integer.toString(k).charAt(0));
    } 
  }
  
  public static ToggleMenuButton createMenuButton(Object paramObject, String paramString, boolean paramBoolean) {
    ToggleMenuButton toggleMenuButton = new ToggleMenuButton(new ImageIcon(Common.getImage(paramObject, paramString)));
    toggleMenuButton.setAlignmentY(0.5F);
    toggleMenuButton.setPreferredSize(new Dimension(25, 25));
    toggleMenuButton.setMinimumSize(new Dimension(25, 25));
    toggleMenuButton.setMaximumSize(new Dimension(25, 25));
    toggleMenuButton.setSelected(paramBoolean);
    toggleMenuButton.setBorderPainted(paramBoolean);
    toggleMenuButton.setRequestFocusEnabled(false);
    toggleMenuButton.setMargin(new Insets(1, 1, 1, 1));
    toggleMenuButton.addMouseListener(Common2D.armListener);
    toggleMenuButton.addItemListener(Common2D.itemListener);
    return toggleMenuButton;
  }
  
  private boolean isBindable(ReportElement paramReportElement) { return (paramReportElement instanceof inetsoft.report.TableElement || paramReportElement instanceof inetsoft.report.ChartElement || paramReportElement instanceof inetsoft.report.FormElement || paramReportElement instanceof inetsoft.report.TextElement || paramReportElement instanceof inetsoft.report.TextBoxElement || paramReportElement instanceof SectionElement); }
  
  private void resetFrameName(DesignFrame paramDesignFrame, String paramString) {
    JMenuItem jMenuItem = (JMenuItem)this.winmap.get(paramDesignFrame);
    String str = jMenuItem.getText();
    int i = str.indexOf(' ');
    jMenuItem.setText(str.substring(0, i + 1) + paramString);
    File file = new File(paramString);
    Enumeration enumeration1 = this.openmap.keys();
    Enumeration enumeration2 = this.openmap.elements();
    while (enumeration2.hasMoreElements()) {
      Object object1 = enumeration1.nextElement();
      Object object2 = enumeration2.nextElement();
      if (object2 == paramDesignFrame) {
        if (!object1.equals(file))
          this.openmap.remove(object1); 
        break;
      } 
    } 
    this.openmap.put(file, paramDesignFrame);
  }
  
  class ComboBox extends JComboBox {
    private final Designer this$0;
    
    public ComboBox(Designer this$0, Object[] param1ArrayOfObject) {
      super(param1ArrayOfObject);
      this.this$0 = this$0;
    }
    
    public Dimension getMaximumSize() { return getPreferredSize(); }
  }
  
  class AlignListener implements ActionListener, ItemListener {
    private final Designer this$0;
    
    AlignListener(Designer this$0) { this.this$0 = this$0; }
    
    public void actionPerformed(ActionEvent param1ActionEvent) { itemStateChanged(null); }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) {
      if (this.this$0.ignore)
        return; 
      byte b = 0;
      if (this.this$0.leftB.isSelected()) {
        b = 1;
      } else if (this.this$0.centerB.isSelected()) {
        b = 2;
      } else if (this.this$0.rightB.isSelected()) {
        b = 4;
      } 
      this.this$0.currpane.setCurrentAlignment(b);
    }
  }
  
  class JustifyListener implements ActionListener, ItemListener {
    private final Designer this$0;
    
    JustifyListener(Designer this$0) { this.this$0 = this$0; }
    
    public void actionPerformed(ActionEvent param1ActionEvent) { itemStateChanged(null); }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) {
      if (this.this$0.ignore)
        return; 
      this.this$0.currpane.setCurrentJustify(this.this$0.fillB.isSelected());
    }
  }
  
  class FontListener implements ActionListener, ItemListener {
    private final Designer this$0;
    
    FontListener(Designer this$0) { this.this$0 = this$0; }
    
    public void actionPerformed(ActionEvent param1ActionEvent) { itemStateChanged(null); }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) {
      if (this.this$0.ignore)
        return; 
      StyleSheet styleSheet = this.this$0.getStyleSheet();
      ReportElement reportElement = (this.this$0.currpane == null) ? null : this.this$0.currpane.getCurrent();
      Font font = (reportElement == null) ? styleSheet.getCurrentFont() : reportElement.getFont();
      int i = font.getStyle() & 0xFFF0;
      i &= 0xFFFFFFEF;
      int j = (font instanceof StyleFont) ? ((StyleFont)font).getLineStyle() : 4097;
      if (this.this$0.boldB.isSelected())
        i |= 0x1; 
      if (this.this$0.italicB.isSelected())
        i |= 0x2; 
      if (this.this$0.underlineB.isSelected())
        i |= 0x10; 
      StyleFont styleFont = new StyleFont((String)this.this$0.fontCombo.getSelectedItem(), i, Integer.parseInt((String)this.this$0.sizeCombo.getSelectedItem()), j);
      this.this$0.currpane.setCurrentFont(styleFont);
    }
  }
  
  class HeaderTargetListener implements ItemListener {
    int target;
    
    StyleSheet sheet;
    
    String id;
    
    private final Designer this$0;
    
    public HeaderTargetListener(Designer this$0, int param1Int) {
      this.this$0 = this$0;
      this.target = 256;
      this.id = null;
      this.target = param1Int;
      this.sheet = this$0.getStyleSheet();
    }
    
    public HeaderTargetListener(Designer this$0, String param1String) {
      this.this$0 = this$0;
      this.target = 256;
      this.id = null;
      this.id = param1String;
    }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) {
      if (param1ItemEvent.getStateChange() != 1)
        return; 
      if (this.id != null) {
        Vector vector = (Vector)this.sheet.getElementHeaders().get(this.id);
        if (vector == null)
          this.sheet.getElementHeaders().put(this.id, vector = new Vector()); 
        this.sheet.setOverrideHeader(vector);
        this.sheet.setCurrentHeader(this.id);
      } else {
        this.sheet.setOverrideHeader(this.sheet.getElements(this.target));
        this.sheet.setCurrentHeader(this.target);
      } 
      this.this$0.currpane.reprint(null);
    }
  }
  
  class FooterTargetListener implements ItemListener {
    int target;
    
    StyleSheet sheet;
    
    String id;
    
    private final Designer this$0;
    
    public FooterTargetListener(Designer this$0, int param1Int) {
      this.this$0 = this$0;
      this.target = 512;
      this.id = null;
      this.target = param1Int;
      this.sheet = this$0.getStyleSheet();
    }
    
    public FooterTargetListener(Designer this$0, String param1String) {
      this.this$0 = this$0;
      this.target = 512;
      this.id = null;
      this.id = param1String;
    }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) {
      if (param1ItemEvent.getStateChange() != 1)
        return; 
      if (this.id != null) {
        Vector vector = (Vector)this.sheet.getElementFooters().get(this.id);
        if (vector == null)
          this.sheet.getElementFooters().put(this.id, vector = new Vector()); 
        this.sheet.setOverrideFooter(vector);
        this.sheet.setCurrentFooter(this.id);
      } else {
        this.sheet.setOverrideFooter(this.sheet.getElements(this.target));
        this.sheet.setCurrentFooter(this.target);
      } 
      this.this$0.currpane.reprint(null);
    }
  }
  
  class LayoutTypeListener implements ItemListener {
    String id;
    
    private final Designer this$0;
    
    public LayoutTypeListener(Designer this$0, String param1String) {
      this.this$0 = this$0;
      this.id = null;
      this.id = param1String;
    }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) {
      if (param1ItemEvent.getStateChange() != 1)
        return; 
      this.this$0.currpane.setEditArea(this.id);
    }
  }
  
  class HeaderHeaderDialog extends HeaderDialog {
    JPopupMenu headerTargetM;
    
    ButtonGroup headerGroup;
    
    private final Designer this$0;
    
    public HeaderHeaderDialog(Designer this$0) {
      super(this$0, this$0.getStyleSheet(), this$0.getStyleSheet().getElementHeaders());
      this.this$0 = this$0;
      this.headerTargetM = (JPopupMenu)this$0.headerTargetMap.get(this$0.currpane);
      this.headerGroup = (ButtonGroup)this$0.headerGroupMap.get(this$0.currpane);
      setMenu(this.headerTargetM);
      setTitle(Catalog.getString("Header List Edit Dialog"));
    }
    
    public void add(String param1String) {
      int i = this.headerTargetM.getComponentCount() - 2;
      JCheckBoxMenuItem jCheckBoxMenuItem;
      this.headerTargetM.insert(jCheckBoxMenuItem = new JCheckBoxMenuItem(param1String, false), i);
      jCheckBoxMenuItem.addItemListener(new Designer.HeaderTargetListener(this.this$0, param1String));
      this.headerGroup.add(jCheckBoxMenuItem);
    }
    
    public void remove(String param1String) {
      for (byte b = 0; b < this.headerTargetM.getComponentCount(); b++) {
        Component component = this.headerTargetM.getComponent(b);
        if (component instanceof JCheckBoxMenuItem && ((JMenuItem)component).getText().equals(param1String)) {
          if (((JCheckBoxMenuItem)component).isSelected())
            ((JCheckBoxMenuItem)this.headerTargetM.getComponent(0)).setSelected(true); 
          this.headerGroup.remove((JMenuItem)component);
          this.headerTargetM.remove(b);
          this.sheet.getElementHeaders().remove(param1String);
          break;
        } 
      } 
    }
  }
  
  class FooterHeaderDialog extends HeaderDialog {
    JPopupMenu footerTargetM;
    
    ButtonGroup footerGroup;
    
    private final Designer this$0;
    
    public FooterHeaderDialog(Designer this$0) {
      super(this$0, this$0.getStyleSheet(), this$0.getStyleSheet().getElementFooters());
      this.this$0 = this$0;
      this.footerTargetM = (JPopupMenu)this$0.footerTargetMap.get(this$0.currpane);
      this.footerGroup = (ButtonGroup)this$0.footerGroupMap.get(this$0.currpane);
      setMenu(this.footerTargetM);
      setTitle(Catalog.getString("Footer List Edit Dialog"));
    }
    
    public void add(String param1String) {
      int i = this.footerTargetM.getComponentCount() - 2;
      JCheckBoxMenuItem jCheckBoxMenuItem;
      this.footerTargetM.insert(jCheckBoxMenuItem = new JCheckBoxMenuItem(param1String, false), i);
      jCheckBoxMenuItem.addItemListener(new Designer.FooterTargetListener(this.this$0, param1String));
      this.footerGroup.add(jCheckBoxMenuItem);
    }
    
    public void remove(String param1String) {
      for (byte b = 0; b < this.footerTargetM.getComponentCount(); b++) {
        Component component = this.footerTargetM.getComponent(b);
        if (component instanceof JCheckBoxMenuItem && ((JMenuItem)component).getText().equals(param1String)) {
          if (((JCheckBoxMenuItem)component).isSelected())
            ((JCheckBoxMenuItem)this.footerTargetM.getComponent(0)).setSelected(true); 
          this.footerGroup.remove((JMenuItem)component);
          this.footerTargetM.remove(b);
          this.sheet.getElementFooters().remove(param1String);
          break;
        } 
      } 
    }
  }
  
  class LayoutDialog extends HeaderDialog {
    JPopupMenu layoutTypeM;
    
    ButtonGroup layoutGroup;
    
    private final Designer this$0;
    
    public LayoutDialog(Designer this$0) {
      super(this$0, this$0.getStyleSheet(), this$0.getStyleSheet().getElementAreas());
      this.this$0 = this$0;
      this.layoutTypeM = (JPopupMenu)this$0.layoutTypeMap.get(this$0.currpane);
      this.layoutGroup = (ButtonGroup)this$0.layoutGroupMap.get(this$0.currpane);
      setMenu(this.layoutTypeM);
      setTitle(Catalog.getString("Layout Element List"));
    }
    
    public void add(String param1String) {
      int i = this.layoutTypeM.getComponentCount() - 2;
      JCheckBoxMenuItem jCheckBoxMenuItem;
      this.layoutTypeM.insert(jCheckBoxMenuItem = new JCheckBoxMenuItem(param1String, false), i);
      jCheckBoxMenuItem.addItemListener(new Designer.LayoutTypeListener(this.this$0, param1String));
      this.layoutGroup.add(jCheckBoxMenuItem);
    }
    
    public void remove(String param1String) {
      for (byte b = 0; b < this.layoutTypeM.getComponentCount(); b++) {
        Component component = this.layoutTypeM.getComponent(b);
        if (component instanceof JCheckBoxMenuItem && ((JMenuItem)component).getText().equals(param1String)) {
          if (((JCheckBoxMenuItem)component).isSelected())
            ((JCheckBoxMenuItem)this.layoutTypeM.getComponent(0)).setSelected(true); 
          this.layoutGroup.remove((JMenuItem)component);
          this.layoutTypeM.remove(b);
          this.sheet.setPageAreas(null, param1String);
          this.this$0.currpane.reprint(null);
          break;
        } 
      } 
    }
  }
  
  class DesignMDI extends JDesktopPane implements InternalFrameListener {
    private final Designer this$0;
    
    public DesignMDI(Designer this$0) { this.this$0 = this$0; }
    
    public boolean close() {
      JInternalFrame[] arrayOfJInternalFrame = getAllFramesInLayer(0);
      for (byte b = 0; b < arrayOfJInternalFrame.length; b++) {
        if (arrayOfJInternalFrame[b] instanceof DesignFrame) {
          DesignFrame designFrame = (DesignFrame)arrayOfJInternalFrame[b];
          if (designFrame.isChanged())
            switch (JOptionPane.showConfirmDialog(this.this$0, Designer.exitMsg)) {
              case 0:
                if (designFrame.save() == null)
                  return false; 
                break;
              case 2:
                return false;
            }  
        } 
      } 
      return true;
    }
    
    public void addWindow(String param1String, JInternalFrame param1JInternalFrame) {
      synchronized (getTreeLock()) {
        int i = getComponentCountInLayer(0);
        Dimension dimension = getSize();
        param1JInternalFrame.setBounds(0, 0, Math.max(dimension.width, 600), Math.max(dimension.height, 500));
        param1JInternalFrame.addInternalFrameListener(this);
        add(param1JInternalFrame, JLayeredPane.DEFAULT_LAYER);
        param1JInternalFrame.show();
        int j = 1;
        JMenuItem jMenuItem;
        if (this.this$0.windowM.getItemCount() > 0 && (jMenuItem = this.this$0.windowM.getItem(this.this$0.windowM.getItemCount() - true)) != null) {
          String str1 = jMenuItem.getText();
          int k = str1.indexOf(' ');
          if (k > 0)
            j = Integer.parseInt(str1.substring(0, k)) + 1; 
        } 
        String str = j + " " + ((param1String == null) ? "" : param1String);
        jMenuItem = new JMenuItem(str);
        jMenuItem.setMnemonic(str.charAt(0));
        jMenuItem.addActionListener(new Designer$62(this, param1JInternalFrame));
        this.this$0.windowM.add(jMenuItem);
        this.this$0.winmap.put(param1JInternalFrame, jMenuItem);
      } 
    }
    
    public void internalFrameOpened(InternalFrameEvent param1InternalFrameEvent) { internalFrameActivated(param1InternalFrameEvent); }
    
    public void internalFrameClosing(InternalFrameEvent param1InternalFrameEvent) {}
    
    public void internalFrameClosed(InternalFrameEvent param1InternalFrameEvent) {
      if (this.this$0.currpane == param1InternalFrameEvent.getSource()) {
        this.this$0.tree.setModel(new DefaultTreeModel(new DefaultMutableTreeNode()));
        this.this$0.currpane = null;
      } 
      this.this$0.removeWindow((JInternalFrame)param1InternalFrameEvent.getSource());
      this.this$0.setEnabled();
    }
    
    public void internalFrameIconified(InternalFrameEvent param1InternalFrameEvent) {}
    
    public void internalFrameDeiconified(InternalFrameEvent param1InternalFrameEvent) {}
    
    public void internalFrameActivated(InternalFrameEvent param1InternalFrameEvent) {
      if (param1InternalFrameEvent.getSource() instanceof DesignFrame) {
        this.this$0.currpane = (DesignFrame)param1InternalFrameEvent.getSource();
        XStyleSheet xStyleSheet = (XStyleSheet)this.this$0.getStyleSheet();
        this.this$0.headerB.setMenu((JPopupMenu)this.this$0.headerTargetMap.get(this.this$0.currpane));
        this.this$0.footerB.setMenu((JPopupMenu)this.this$0.footerTargetMap.get(this.this$0.currpane));
        this.this$0.layoutB.setMenu((JPopupMenu)this.this$0.layoutTypeMap.get(this.this$0.currpane));
        this.this$0.layoutB.setSelected(this.this$0.currpane.isEditArea());
        this.this$0.horFlowM.setSelected((xStyleSheet != null && xStyleSheet.isHorizontalWrap()));
        this.this$0.rulerV.setSelected(this.this$0.currpane.isShowRuler());
        this.this$0.gridV.setSelected(this.this$0.currpane.isShowGrid());
        this.this$0.tree.setModel(this.this$0.currpane.getTreeModel(this.this$0.tree));
        this.this$0.targetListener.actionPerformed(null);
        this.this$0.selectListener.itemStateChanged(null);
      } else {
        this.this$0.tree.setModel(new DefaultTreeModel(new DefaultMutableTreeNode()));
        this.this$0.currpane = null;
      } 
      this.this$0.setEnabled();
    }
    
    public void internalFrameDeactivated(InternalFrameEvent param1InternalFrameEvent) {
      this.this$0.currpane = null;
      this.this$0.tree.setModel(new DefaultTreeModel(new DefaultMutableTreeNode()));
      this.this$0.setEnabled();
    }
  }
  
  public static void main(String[] paramArrayOfString) {
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramArrayOfString[b].startsWith("-ORB")) {
        CorbaHandler.init(paramArrayOfString, null);
        break;
      } 
    } 
    run(paramArrayOfString, Designer.class);
  }
  
  public static void run(String[] paramArrayOfString, Class paramClass) {
    sree = paramClass.getName().endsWith("Designer2");
    if (DesignEnv.getProperty("report.designer.laf") != null)
      Common2D.setLookAndFeel(DesignEnv.getProperty("report.designer.laf")); 
    Resizer.setSnapToGrid(DesignEnv.getProperty("snap.grid", "true").equals("true"));
    progressD = new ProgressD(paramClass, 0, 100);
    progressD.setText(Catalog.getString("Initializing Style Report Designer") + " ...");
    setProgress(5);
    StyleSheet.setPrinterMargin(new Margin());
    progressD.pack();
    progressD.setLocation(200, 200);
    progressD.setVisible(true);
    isMain = true;
    try {
      Designer designer = (Designer)paramClass.newInstance();
      progressD.setProgress(85);
      progressD.setText(Catalog.getString("Loading template file") + " ...");
      designer.pack();
      progressD.setProgress(95);
      String str = DesignEnv.getProperty("window.bounds");
      if (str != null) {
        String[] arrayOfString = Util.split(str, ',');
        if (arrayOfString.length == 4) {
          designer.setLocation(new Point(Integer.parseInt(arrayOfString[0]), Integer.parseInt(arrayOfString[1])));
          designer.setSize(Integer.parseInt(arrayOfString[2]), Integer.parseInt(arrayOfString[3]));
        } 
      } else {
        designer.pack();
      } 
      designer.setVisible(true);
      if (paramArrayOfString.length > 0)
        for (byte b = 0; b < paramArrayOfString.length; b++) {
          if (paramArrayOfString[b].startsWith("-ORBInitialPort")) {
            b++;
          } else if (!paramArrayOfString[b].startsWith("-ORB")) {
            File file = new File(paramArrayOfString[b]);
            try {
              designer.open(file);
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
            } 
          } 
        }  
      setProgress(100);
      progressD.dispose();
      synchronized (designer) {
        while (designer.builder == null)
          designer.wait(); 
      } 
      if (designer.builder.getRepository().getDataSourceNames().length == 0) {
        str = DesignEnv.getProperty("xdatasource.init");
        if (str == null && JOptionPane.showConfirmDialog(designer, Catalog.getString("Setup datasources now?"), Catalog.getString("Setup"), 0) == 0) {
          designer.builder.pack();
          designer.builder.setVisible(true);
          designer.builder.newDataSource(null);
        } 
        DesignEnv.setProperty("xdatasource.init", "true");
      } 
    } catch (Exception exception) {
      JOptionPane.showMessageDialog(null, exception.toString());
      exception.printStackTrace();
    } 
  }
  
  static void setProgress(int paramInt) {
    if (progressD != null)
      progressD.setProgress(paramInt); 
  }
  
  static String exitMsg = Catalog.getString("Unsaved changes. Save before closing?");
  
  static String msg1 = Catalog.getString("Failed to open file!");
  
  static final String dup_id = Catalog.getString("The ID is already used by another element in the report!");
  
  protected JMenuBar menubar;
  
  protected JToolBar stdbar;
  
  protected JToolBar combar;
  
  protected JToolBar fmtbar;
  
  protected JPanel sidebar;
  
  protected DesignFrame currpane;
  
  protected JMenu fileM;
  
  protected JMenu editM;
  
  protected JMenu sectionMenu;
  
  protected SectionInsertMenu sectionInsertM;
  
  protected int lastFileM;
  
  Hashtable openmap;
  
  String filedir;
  
  Dimension psize;
  
  DesignMDI mdi;
  
  JTree tree;
  
  JSplitPane spliter;
  
  JComboBox fontCombo;
  
  JComboBox sizeCombo;
  
  Vector lastFiles;
  
  JMenu windowM;
  
  JMenuItem cascadeM;
  
  JMenuItem closeAllM;
  
  Hashtable winmap;
  
  JToggleButton leftB;
  
  JToggleButton centerB;
  
  JToggleButton rightB;
  
  JToggleButton fillB;
  
  JToggleButton boldB;
  
  JToggleButton italicB;
  
  JToggleButton underlineB;
  
  JToggleButton picktoolB;
  
  JToggleButton texttoolB;
  
  ToggleMenuButton headerB;
  
  ToggleMenuButton footerB;
  
  ToggleMenuButton layoutB;
  
  JToggleButton bodyB;
  
  JToggleButton areaB;
  
  JToggleButton orderB;
  
  JToggleButton elemmapB;
  
  JButton saveB;
  
  JButton cutB;
  
  JButton copyB;
  
  JButton pasteB;
  
  JButton tableWizardB;
  
  JButton tableB;
  
  JButton textB;
  
  JButton textboxB;
  
  JButton sectionB;
  
  JButton chartB;
  
  JButton sectionWizardB;
  
  JButton imageB;
  
  JButton painterB;
  
  JButton tocB;
  
  JButton headingB;
  
  JButton containerB;
  
  JButton separatorB;
  
  JButton bulletB;
  
  JButton tabB;
  
  JButton columnB;
  
  JButton lshiftB;
  
  JButton rshiftB;
  
  JButton enterB;
  
  JButton spaceB;
  
  JCheckBoxMenuItem rulerV;
  
  JCheckBoxMenuItem gridV;
  
  JCheckBoxMenuItem snapGridM;
  
  JCheckBoxMenuItem headerM;
  
  JCheckBoxMenuItem bodyM;
  
  JCheckBoxMenuItem footerM;
  
  JMenuItem saveM;
  
  JMenuItem saveAsM;
  
  JMenuItem tableM;
  
  JMenuItem textM;
  
  JMenuItem textboxM;
  
  JMenuItem imageM;
  
  JMenuItem sectionM;
  
  JMenuItem closeM;
  
  JMenuItem chartM;
  
  JMenuItem undoM;
  
  JMenuItem scriptM;
  
  JMenuItem pageSetupM;
  
  JMenuItem painterM;
  
  JMenuItem tabM;
  
  JMenuItem bulletM;
  
  JMenuItem separatorM;
  
  JMenuItem enterM;
  
  JMenuItem pagebreakM;
  
  JMenuItem condpagebreakM;
  
  JMenuItem spaceM;
  
  JMenuItem areaM;
  
  JMenuItem orderM;
  
  JMenuItem breakM;
  
  JMenuItem areabreakM;
  
  JMenuItem copyM;
  
  JMenuItem cutM;
  
  JMenuItem pasteM;
  
  JMenuItem pageM;
  
  JMenuItem elemmapM;
  
  JMenuItem masterM;
  
  JMenuItem propertyM;
  
  JMenuItem newStyleM;
  
  JMenuItem viewStyleM;
  
  JMenuItem tabDefM;
  
  JMenuItem tocM;
  
  JMenuItem headingM;
  
  JMenuItem containerM;
  
  JMenuItem editHeaderM;
  
  JMenuItem editFooterM;
  
  JMenuItem editLayoutM;
  
  JCheckBoxMenuItem horFlowM;
  
  JMenuItem sectionAlignM;
  
  JMenuItem sectionDistM;
  
  JMenuItem sectionEditM;
  
  JMenuItem sectionBindM;
  
  JMenuItem sectionSizeM;
  
  JMenuItem sectionGenM;
  
  Hashtable headerTargetMap;
  
  Hashtable footerTargetMap;
  
  Hashtable layoutTypeMap;
  
  Hashtable headerGroupMap;
  
  Hashtable footerGroupMap;
  
  Hashtable layoutGroupMap;
  
  ButtonGroup alignGroup;
  
  ButtonGroup targetGroup;
  
  ButtonGroup targetMGroup;
  
  ButtonGroup viewGroup;
  
  ButtonGroup cursorGroup;
  
  JLabel status;
  
  JLabel pginfo;
  
  JTextField idTF;
  
  static String[] fnSize = { 
      "6", "7", "8", "9", "10", "11", "12", "14", "16", "18", 
      "20", "22", "24", "26", "28", "36", "48", "72" };
  
  static boolean isMain = false;
  
  static ProgressD progressD;
  
  static final int MAX_LAST_OPEN = 9;
  
  static boolean sree = false;
  
  static final String init_msg = Catalog.getString("Designer configuration has not been done.") + "\n" + Catalog.getString("Please specify the full paths of the registry files.") + "\n" + Catalog.getString("If the files don't exist, they will be created automatically");
  
  static final String registry_not_found = Catalog.getString("Datasource registry files not found. Will be created...");
  
  protected DesignSession xsession;
  
  JButton builderB;
  
  JButton bindB;
  
  JButton previewB;
  
  JButton groupB;
  
  JButton crosstabB;
  
  JButton refreshB;
  
  JButton datasetB;
  
  JMenuItem builderM;
  
  JMenuItem bindM;
  
  JMenuItem previewM;
  
  JMenuItem groupM;
  
  JMenuItem crosstabM;
  
  JMenuItem refreshM;
  
  JMenuItem datasetM;
  
  JMenuItem tableWizardM;
  
  JMenuItem sectionWizardM;
  
  JMenuItem fieldM;
  
  XBuilder builder;
  
  boolean queryChanged;
  
  String editquery;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\Designer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */