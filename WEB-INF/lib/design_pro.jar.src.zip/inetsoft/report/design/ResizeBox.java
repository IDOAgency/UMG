/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.Paintable;
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.internal.BaseElement;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ResizeBox
/*    */ {
/*    */   public ResizeBox() {}
/*    */   
/*    */   public ResizeBox(DesignPane.DesignPage paramDesignPage, ReportElement paramReportElement, Paintable paramPaintable) {
/* 31 */     this.page = paramDesignPage;
/* 32 */     this.bounds = paramDesignPage.getElementBounds(paramReportElement);
/* 33 */     this.element = (BaseElement)paramReportElement;
/* 34 */     this.paintable = paramPaintable;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResizeBox(DesignPane.DesignPage paramDesignPage, Rectangle paramRectangle1, Rectangle paramRectangle2, int paramInt) {
/* 39 */     this.type = paramInt;
/* 40 */     this.page = paramDesignPage;
/* 41 */     this.bounds = paramRectangle1;
/* 42 */     this.bbox = paramRectangle2;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 47 */   public boolean isSameGroup(ResizeBox paramResizeBox) { return (this.element.getParent() instanceof inetsoft.report.FixedContainer && paramResizeBox.element.getParent() instanceof inetsoft.report.FixedContainer); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public boolean equals(Object paramObject) { return (paramObject instanceof ReportElement) ? ((this.element != null && this.element.equals(paramObject))) : super.equals(paramObject); }
/*    */ 
/*    */ 
/*    */   
/*    */   public void copy(ResizeBox paramResizeBox) {
/* 57 */     this.type = paramResizeBox.type;
/* 58 */     this.page = paramResizeBox.page;
/* 59 */     this.bounds = paramResizeBox.bounds;
/* 60 */     this.bbox = paramResizeBox.bbox;
/* 61 */     this.element = paramResizeBox.element;
/* 62 */     this.paintable = paramResizeBox.paintable;
/*    */   }
/*    */   
/* 65 */   public int type = -1;
/*    */   public DesignPane.DesignPage page;
/*    */   public Rectangle bounds;
/*    */   public Rectangle bbox;
/*    */   public BaseElement element;
/*    */   public Paintable paintable;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ResizeBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */