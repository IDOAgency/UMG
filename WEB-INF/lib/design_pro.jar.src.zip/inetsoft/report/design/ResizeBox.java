package inetsoft.report.design;

import inetsoft.report.Paintable;
import inetsoft.report.ReportElement;
import inetsoft.report.internal.BaseElement;
import java.awt.Rectangle;

class ResizeBox {
  public ResizeBox() {}
  
  public ResizeBox(DesignPane.DesignPage paramDesignPage, ReportElement paramReportElement, Paintable paramPaintable) {
    this.page = paramDesignPage;
    this.bounds = paramDesignPage.getElementBounds(paramReportElement);
    this.element = (BaseElement)paramReportElement;
    this.paintable = paramPaintable;
  }
  
  public ResizeBox(DesignPane.DesignPage paramDesignPage, Rectangle paramRectangle1, Rectangle paramRectangle2, int paramInt) {
    this.type = paramInt;
    this.page = paramDesignPage;
    this.bounds = paramRectangle1;
    this.bbox = paramRectangle2;
  }
  
  public boolean isSameGroup(ResizeBox paramResizeBox) { return (this.element.getParent() instanceof inetsoft.report.FixedContainer && paramResizeBox.element.getParent() instanceof inetsoft.report.FixedContainer); }
  
  public boolean equals(Object paramObject) { return (paramObject instanceof ReportElement) ? ((this.element != null && this.element.equals(paramObject))) : super.equals(paramObject); }
  
  public void copy(ResizeBox paramResizeBox) {
    this.type = paramResizeBox.type;
    this.page = paramResizeBox.page;
    this.bounds = paramResizeBox.bounds;
    this.bbox = paramResizeBox.bbox;
    this.element = paramResizeBox.element;
    this.paintable = paramResizeBox.paintable;
  }
  
  public int type = -1;
  
  public DesignPane.DesignPage page;
  
  public Rectangle bounds;
  
  public Rectangle bbox;
  
  public BaseElement element;
  
  public Paintable paintable;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ResizeBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */