/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.lens.AbstractTableLens;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XNodeMetaTable
/*     */   extends AbstractTableLens
/*     */ {
/*     */   int ncol;
/*     */   
/*     */   public XNodeMetaTable(XTypeNode paramXTypeNode) {
/*  34 */     Object[] arrayOfObject1 = new Object[this.ncol = paramXTypeNode.getChildCount()];
/*  35 */     Object[] arrayOfObject2 = new Object[this.ncol];
/*     */     
/*  37 */     for (byte b = 0; b < arrayOfObject2.length; b++) {
/*  38 */       XNode xNode = paramXTypeNode.getChild(b);
/*  39 */       arrayOfObject1[b] = xNode.getAttribute("alias");
/*  40 */       if (arrayOfObject1[b] == null) {
/*  41 */         arrayOfObject1[b] = xNode.getName();
/*     */       }
/*     */       
/*  44 */       arrayOfObject2[b] = getExampler((String)arrayOfObject1[b], (XTypeNode)paramXTypeNode.getChild(b));
/*     */     } 
/*     */     
/*  47 */     if (this.ncol == 0) {
/*  48 */       arrayOfObject1 = new Object[] { "Unknown" };
/*  49 */       arrayOfObject2 = new Object[] { "XXXXX" };
/*  50 */       this.ncol = 1;
/*     */     } 
/*     */     
/*  53 */     this.rows.addElement(arrayOfObject1);
/*  54 */     this.rows.addElement(arrayOfObject2);
/*     */   }
/*     */ 
/*     */   
/*  58 */   public int getRowCount() { return this.rows.size(); }
/*     */ 
/*     */ 
/*     */   
/*  62 */   public int getColCount() { return this.ncol; }
/*     */ 
/*     */ 
/*     */   
/*  66 */   public int getHeaderRowCount() { return 1; }
/*     */ 
/*     */ 
/*     */   
/*  70 */   public int getHeaderColCount() { return 0; }
/*     */ 
/*     */ 
/*     */   
/*  74 */   public Object getObject(int paramInt1, int paramInt2) { return (Object[])this.rows.elementAt(paramInt1)[paramInt2]; }
/*     */ 
/*     */   
/*     */   protected Object getExampler(String paramString, XTypeNode paramXTypeNode) {
/*  78 */     String str = paramXTypeNode.getType();
/*     */     
/*  80 */     if (str.equals("string")) {
/*  81 */       Integer integer = (Integer)paramXTypeNode.getAttribute("length");
/*  82 */       int i = Math.min(8, paramString.length());
/*  83 */       if (integer != null) {
/*  84 */         i = Math.max(i, integer.intValue());
/*     */       }
/*     */       
/*  87 */       return getString('X', Math.min(30, i));
/*     */     } 
/*  89 */     if (str.equals("boolean")) {
/*  90 */       return Boolean.TRUE;
/*     */     }
/*  92 */     if (str.equals("float")) {
/*  93 */       return new Float(99999.99D);
/*     */     }
/*  95 */     if (str.equals("double")) {
/*  96 */       return new Double(99999.99D);
/*     */     }
/*  98 */     if (str.equals("char")) {
/*  99 */       return "X";
/*     */     }
/* 101 */     if (str.equals("byte")) {
/* 102 */       return new Byte((byte)99);
/*     */     }
/* 104 */     if (str.equals("short")) {
/* 105 */       return new Short((short)999);
/*     */     }
/* 107 */     if (str.equals("integer")) {
/* 108 */       return new Integer(99999);
/*     */     }
/* 110 */     if (str.equals("long")) {
/* 111 */       return new Long(99999L);
/*     */     }
/* 113 */     if (str.equals("timeInstant")) {
/* 114 */       return new Date();
/*     */     }
/* 116 */     if (str.equals("date")) {
/* 117 */       return new Date();
/*     */     }
/* 119 */     if (str.equals("time")) {
/* 120 */       return new Date();
/*     */     }
/*     */     
/* 123 */     return getString('X', Math.min(5, paramString.length()));
/*     */   }
/*     */   
/*     */   String getString(char paramChar, int paramInt) {
/* 127 */     StringBuffer stringBuffer = new StringBuffer();
/* 128 */     for (byte b = 0; b < paramInt; b++) {
/* 129 */       stringBuffer.append(paramChar);
/*     */     }
/*     */     
/* 132 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */   
/* 136 */   Vector rows = new Vector();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\XNodeMetaTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */