package inetsoft.report.design;

import inetsoft.report.lens.AbstractTableLens;
import inetsoft.uql.XNode;
import inetsoft.uql.schema.XTypeNode;
import java.util.Date;
import java.util.Vector;

class XNodeMetaTable extends AbstractTableLens {
  int ncol;
  
  public XNodeMetaTable(XTypeNode paramXTypeNode) {
    Object[] arrayOfObject1 = new Object[this.ncol = paramXTypeNode.getChildCount()];
    Object[] arrayOfObject2 = new Object[this.ncol];
    for (byte b = 0; b < arrayOfObject2.length; b++) {
      XNode xNode = paramXTypeNode.getChild(b);
      arrayOfObject1[b] = xNode.getAttribute("alias");
      if (arrayOfObject1[b] == null)
        arrayOfObject1[b] = xNode.getName(); 
      arrayOfObject2[b] = getExampler((String)arrayOfObject1[b], (XTypeNode)paramXTypeNode.getChild(b));
    } 
    if (this.ncol == 0) {
      arrayOfObject1 = new Object[] { "Unknown" };
      arrayOfObject2 = new Object[] { "XXXXX" };
      this.ncol = 1;
    } 
    this.rows.addElement(arrayOfObject1);
    this.rows.addElement(arrayOfObject2);
  }
  
  public int getRowCount() { return this.rows.size(); }
  
  public int getColCount() { return this.ncol; }
  
  public int getHeaderRowCount() { return 1; }
  
  public int getHeaderColCount() { return 0; }
  
  public Object getObject(int paramInt1, int paramInt2) { return (Object[])this.rows.elementAt(paramInt1)[paramInt2]; }
  
  protected Object getExampler(String paramString, XTypeNode paramXTypeNode) {
    String str = paramXTypeNode.getType();
    if (str.equals("string")) {
      Integer integer = (Integer)paramXTypeNode.getAttribute("length");
      int i = Math.min(8, paramString.length());
      if (integer != null)
        i = Math.max(i, integer.intValue()); 
      return getString('X', Math.min(30, i));
    } 
    if (str.equals("boolean"))
      return Boolean.TRUE; 
    if (str.equals("float"))
      return new Float(99999.99D); 
    if (str.equals("double"))
      return new Double(99999.99D); 
    if (str.equals("char"))
      return "X"; 
    if (str.equals("byte"))
      return new Byte((byte)99); 
    if (str.equals("short"))
      return new Short((short)999); 
    if (str.equals("integer"))
      return new Integer(99999); 
    if (str.equals("long"))
      return new Long(99999L); 
    if (str.equals("timeInstant"))
      return new Date(); 
    if (str.equals("date"))
      return new Date(); 
    if (str.equals("time"))
      return new Date(); 
    return getString('X', Math.min(5, paramString.length()));
  }
  
  String getString(char paramChar, int paramInt) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramInt; b++)
      stringBuffer.append(paramChar); 
    return stringBuffer.toString();
  }
  
  Vector rows = new Vector();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\XNodeMetaTable.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */