/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.Grid2Layout;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ class DistributeDialog
/*     */   extends JDialog {
/*     */   ActionListener okListener;
/*     */   ActionListener cancelListener;
/*     */   JCheckBox leftRB;
/*     */   
/*     */   public DistributeDialog(Frame paramFrame, DesignView paramDesignView) {
/*  25 */     super(paramFrame);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     this.okListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 107 */           char c = Character.MIN_VALUE;
/*     */           
/* 109 */           if (this.this$0.leftRB.isSelected()) {
/* 110 */             c |= true;
/*     */           }
/* 112 */           else if (this.this$0.centerRB.isSelected()) {
/* 113 */             c |= 0x2;
/*     */           }
/* 115 */           else if (this.this$0.rightRB.isSelected()) {
/* 116 */             c |= 0x4;
/*     */           }
/* 118 */           else if (this.this$0.hspaceRB.isSelected()) {
/* 119 */             c |= 0x100;
/*     */           } 
/*     */           
/* 122 */           if (this.this$0.topRB.isSelected()) {
/* 123 */             c |= 0x8;
/*     */           }
/* 125 */           else if (this.this$0.middleRB.isSelected()) {
/* 126 */             c |= 0x10;
/*     */           }
/* 128 */           else if (this.this$0.bottomRB.isSelected()) {
/* 129 */             c |= 0x20;
/*     */           }
/* 131 */           else if (this.this$0.vspaceRB.isSelected()) {
/* 132 */             c |= 0x200;
/*     */           } 
/*     */           
/* 135 */           this.this$0.view.distribute(c);
/*     */           
/* 137 */           this.this$0.dispose();
/*     */         }
/*     */         private final DistributeDialog this$0;
/*     */       };
/* 141 */     this.cancelListener = new ActionListener(this)
/*     */       {
/* 143 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */ 
/*     */ 
/*     */         
/*     */         private final DistributeDialog this$0;
/*     */       };
/* 149 */     this.hgroup = new ButtonGroup(); this.vgroup = new ButtonGroup();
/* 150 */     this.okB = new JButton(Catalog.getString("OK"));
/* 151 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*     */     setModal(true);
/*     */     this.view = paramDesignView;
/*     */     ImageIcon imageIcon1 = new ImageIcon(getClass().getResource("images/left-dist.gif"));
/*     */     ImageIcon imageIcon2 = new ImageIcon(getClass().getResource("images/center-dist.gif"));
/*     */     ImageIcon imageIcon4 = new ImageIcon(getClass().getResource("images/hspace-dist.gif"));
/*     */     ImageIcon imageIcon3 = new ImageIcon(getClass().getResource("images/right-dist.gif"));
/*     */     ImageIcon imageIcon5 = new ImageIcon(getClass().getResource("images/top-dist.gif"));
/*     */     ImageIcon imageIcon6 = new ImageIcon(getClass().getResource("images/middle-dist.gif"));
/*     */     ImageIcon imageIcon8 = new ImageIcon(getClass().getResource("images/vspace-dist.gif"));
/*     */     ImageIcon imageIcon7 = new ImageIcon(getClass().getResource("images/bottom-dist.gif"));
/*     */     this.leftRB = new JCheckBox(Catalog.getString("Left"));
/*     */     this.centerRB = new JCheckBox(Catalog.getString("Center"));
/*     */     this.hspaceRB = new JCheckBox(Catalog.getString("Spacing"));
/*     */     this.rightRB = new JCheckBox(Catalog.getString("Right"));
/*     */     this.topRB = new JCheckBox(Catalog.getString("Top"));
/*     */     this.middleRB = new JCheckBox(Catalog.getString("Center"));
/*     */     this.vspaceRB = new JCheckBox(Catalog.getString("Spacing"));
/*     */     this.bottomRB = new JCheckBox(Catalog.getString("Bottom"));
/*     */     getContentPane().setLayout(new BorderLayout(5, 5));
/*     */     JPanel jPanel = new JPanel();
/*     */     Grid2Layout grid2Layout = new Grid2Layout();
/*     */     jPanel.setLayout(grid2Layout);
/*     */     jPanel.add(new JLabel(imageIcon1), grid2Layout.at(0, 1, 1, 1, 4));
/*     */     jPanel.add(this.leftRB, grid2Layout.at(0, 2));
/*     */     jPanel.add(new JLabel(imageIcon2), grid2Layout.at(0, 3));
/*     */     jPanel.add(this.centerRB, grid2Layout.at(0, 4));
/*     */     jPanel.add(new JLabel(imageIcon4), grid2Layout.at(0, 5));
/*     */     jPanel.add(this.hspaceRB, grid2Layout.at(0, 6));
/*     */     jPanel.add(new JLabel(imageIcon3), grid2Layout.at(0, 7));
/*     */     jPanel.add(this.rightRB, grid2Layout.at(0, 8));
/*     */     jPanel.add(new JLabel(imageIcon5), grid2Layout.at(1, 0));
/*     */     jPanel.add(this.topRB, grid2Layout.at(1, 1));
/*     */     jPanel.add(new JLabel(imageIcon6), grid2Layout.at(2, 0));
/*     */     jPanel.add(this.middleRB, grid2Layout.at(2, 1));
/*     */     jPanel.add(new JLabel(imageIcon8), grid2Layout.at(3, 0));
/*     */     jPanel.add(this.vspaceRB, grid2Layout.at(3, 1));
/*     */     jPanel.add(new JLabel(imageIcon7), grid2Layout.at(4, 0));
/*     */     jPanel.add(this.bottomRB, grid2Layout.at(4, 1));
/*     */     getContentPane().add(jPanel, "Center");
/*     */     jPanel = new JPanel();
/*     */     jPanel.setLayout(new FlowLayout());
/*     */     jPanel.add(this.okB);
/*     */     jPanel.add(this.cancelB);
/*     */     getContentPane().add(jPanel, "South");
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.cancelB.addActionListener(this.cancelListener);
/*     */     this.hgroup.add(this.leftRB);
/*     */     this.hgroup.add(this.centerRB);
/*     */     this.hgroup.add(this.hspaceRB);
/*     */     this.hgroup.add(this.rightRB);
/*     */     this.vgroup.add(this.topRB);
/*     */     this.vgroup.add(this.middleRB);
/*     */     this.vgroup.add(this.vspaceRB);
/*     */     this.vgroup.add(this.bottomRB);
/*     */   }
/*     */   
/*     */   JCheckBox centerRB;
/*     */   JCheckBox rightRB;
/*     */   JCheckBox hspaceRB;
/*     */   JCheckBox topRB;
/*     */   JCheckBox middleRB;
/*     */   JCheckBox bottomRB;
/*     */   JCheckBox vspaceRB;
/*     */   ButtonGroup hgroup;
/*     */   ButtonGroup vgroup;
/*     */   JButton okB;
/*     */   JButton cancelB;
/*     */   DesignView view;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DistributeDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */