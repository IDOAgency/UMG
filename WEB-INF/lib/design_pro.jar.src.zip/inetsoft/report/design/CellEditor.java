/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.FormElement;
/*     */ import inetsoft.report.FormLens;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.internal.TableElementDef;
/*     */ import inetsoft.report.internal.TablePaintable;
/*     */ import inetsoft.report.lens.AttributeFormLens;
/*     */ import inetsoft.report.lens.DefaultFormLens;
/*     */ import inetsoft.report.lens.DefaultTableLens;
/*     */ import inetsoft.report.style.TableStyle;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CellEditor
/*     */   extends JTextArea
/*     */ {
/*     */   FocusListener editorListener;
/*     */   DocumentListener resizeListener;
/*     */   KeyListener keyListener;
/*     */   TableElementDef elem;
/*     */   TablePaintable paintable;
/*     */   int row;
/*     */   int col;
/*     */   TableLens table;
/*     */   FormLens form;
/*     */   String otext;
/*     */   Rectangle bounds;
/*     */   boolean otextmode;
/*     */   Point initpt;
/*     */   DesignPane pane;
/*     */   
/*     */   public CellEditor(DesignPane paramDesignPane) {
/* 203 */     this.editorListener = new FocusAdapter(this) {
/*     */         public void focusLost(FocusEvent param1FocusEvent) {
/* 205 */           if (!param1FocusEvent.isTemporary()) {
/* 206 */             this.this$0.stop();
/*     */           }
/*     */         }
/*     */         
/*     */         private final CellEditor this$0;
/*     */       };
/* 212 */     this.resizeListener = new DocumentListener(this)
/*     */       {
/* 214 */         public void insertUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setBounds(); }
/*     */ 
/*     */         
/*     */         private final CellEditor this$0;
/*     */         
/*     */         public void removeUpdate(DocumentEvent param1DocumentEvent) {}
/*     */         
/*     */         public void changedUpdate(DocumentEvent param1DocumentEvent) {}
/*     */       };
/* 223 */     this.keyListener = new KeyAdapter(this) {
/*     */         public void keyPressed(KeyEvent param1KeyEvent) {
/* 225 */           if (param1KeyEvent.getKeyCode() == 9) {
/* 226 */             param1KeyEvent.consume();
/* 227 */             this.this$0.stop();
/*     */             
/* 229 */             Rectangle rectangle = this.this$0.paintable.getTableRegion();
/*     */             
/* 231 */             if (param1KeyEvent.isShiftDown()) {
/* 232 */               this.this$0.col--;
/*     */               
/* 234 */               if (this.this$0.col < rectangle.x) {
/* 235 */                 this.this$0.row--;
/* 236 */                 this.this$0.col = rectangle.x + rectangle.width - 1;
/*     */               } 
/*     */               
/* 239 */               if (this.this$0.row < rectangle.y) {
/* 240 */                 this.this$0.row = rectangle.y + rectangle.height - 1;
/*     */               }
/*     */             } else {
/*     */               
/* 244 */               this.this$0.col++;
/*     */               
/* 246 */               if (this.this$0.col >= rectangle.x + rectangle.width) {
/* 247 */                 this.this$0.row++;
/* 248 */                 this.this$0.col = rectangle.x;
/*     */               } 
/*     */               
/* 251 */               if (this.this$0.row >= rectangle.y + rectangle.height) {
/* 252 */                 this.this$0.row = rectangle.y;
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 257 */             this.this$0.pane.getCurrentPage().showEditor(this.this$0.elem, this.this$0.row, this.this$0.col, this.this$0.paintable, null);
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final CellEditor this$0;
/*     */       };
/* 267 */     this.otext = "";
/* 268 */     this.bounds = new Rectangle(0, 0, 72, 72);
/* 269 */     this.otextmode = false;
/* 270 */     this.initpt = null;
/*     */     this.pane = paramDesignPane;
/*     */     setBorder(new ThinBevel(1, new Color(150, 150, 150), new Color(80, 80, 80)));
/*     */     setLineWrap(true);
/*     */     setWrapStyleWord(false);
/*     */     setBackground(new Color(240, 240, 240));
/*     */     setCaret(new ThickCaret());
/*     */     addFocusListener(this.editorListener);
/*     */     getDocument().addDocumentListener(this.resizeListener);
/*     */     addKeyListener(this.keyListener);
/*     */   }
/*     */   
/*     */   public void setParam(TableElementDef paramTableElementDef, int paramInt1, int paramInt2, TablePaintable paramTablePaintable, Point paramPoint) {
/*     */     this.elem = paramTableElementDef;
/*     */     this.table = paramTableElementDef.getTable();
/*     */     this.paintable = paramTablePaintable;
/*     */     this.row = paramInt1;
/*     */     this.col = paramInt2;
/*     */     this.bounds = paramTablePaintable.getPrintBounds(paramInt1, paramInt2, false).getRectangle();
/*     */     this.form = (paramTableElementDef instanceof FormElement) ? ((FormElement)paramTableElementDef).getForm() : null;
/*     */     this.otextmode = this.pane.isTextMode();
/*     */     if (!this.pane.textmode) {
/*     */       this.pane.textmode = true;
/*     */       this.pane.fireEvent();
/*     */     } 
/*     */     Font font = this.table.getFont(paramInt1, paramInt2);
/*     */     Object object = this.table.getObject(paramInt1, paramInt2);
/*     */     String str = (object == null) ? "" : object.toString();
/*     */     if (str.length() == 0) {
/*     */       setText(" ");
/*     */       setCaretPosition(1);
/*     */     } 
/*     */     setText(str);
/*     */     setFont((font == null) ? paramTableElementDef.getFont() : font);
/*     */     this.otext = getText();
/*     */     setBounds();
/*     */     setCaretPosition(getText().length());
/*     */     this.initpt = (paramPoint == null) ? null : new Point(paramPoint.x - this.bounds.x - this.pane.insets.left, paramPoint.y - this.bounds.y - this.pane.insets.top);
/*     */   }
/*     */   
/*     */   public void setBounds() {
/*     */     setSize(this.bounds.width, this.bounds.height);
/*     */     setLocation(this.bounds.x + this.pane.insets.left, this.bounds.y + this.pane.insets.top);
/*     */     Dimension dimension = getPreferredSize();
/*     */     dimension.height = Math.max(dimension.height, this.bounds.height);
/*     */     setSize(dimension);
/*     */   }
/*     */   
/*     */   public void resetTextMode(boolean paramBoolean) { this.otextmode = paramBoolean; }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     if (this.initpt != null) {
/*     */       int i = viewToModel(this.initpt);
/*     */       if (i >= 0) {
/*     */         this.initpt = null;
/*     */         setCaretPosition(i);
/*     */       } 
/*     */     } 
/*     */     super.paint(paramGraphics);
/*     */   }
/*     */   
/*     */   void setValue(String paramString) {
/*     */     if (this.form == null) {
/*     */       if (this.table instanceof DefaultTableLens) {
/*     */         ((DefaultTableLens)this.table).setObject(this.row, this.col, paramString);
/*     */       } else {
/*     */         ((DefaultTableLens)((TableStyle)this.table).getTable()).setObject(this.row, this.col, paramString);
/*     */       } 
/*     */     } else {
/*     */       DefaultFormLens defaultFormLens = (DefaultFormLens)((AttributeFormLens)this.form).getForm();
/*     */       int i = (this.row * this.table.getColCount() + this.col) / 2;
/*     */       if (this.col % 2 == 0) {
/*     */         defaultFormLens.setLabel(i, paramString);
/*     */       } else {
/*     */         defaultFormLens.setField(i, paramString);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void stop() {
/*     */     if (!this.pane.editing || !isVisible() || this.table == null)
/*     */       return; 
/*     */     String str = getText();
/*     */     setValue(str);
/*     */     if (this.pane.textmode != this.otextmode) {
/*     */       this.pane.textmode = this.otextmode;
/*     */       this.pane.fireEvent();
/*     */     } 
/*     */     setVisible(false);
/*     */     Container container = getParent();
/*     */     if (container != null)
/*     */       container.remove(this); 
/*     */     if (!this.otext.equals(str)) {
/*     */       this.pane.setChanged(true);
/*     */       int[] arrayOfInt = this.elem.getFixedWidths();
/*     */       if (arrayOfInt == null) {
/*     */         int[] arrayOfInt1 = new int[this.table.getColCount()];
/*     */         for (byte b = 0; b < arrayOfInt1.length; b++)
/*     */           arrayOfInt1[b] = (int)this.elem.getColWidth(b); 
/*     */         this.elem.setFixedWidths(arrayOfInt1);
/*     */       } 
/*     */       this.pane.reprint(this.pane.getCurrent());
/*     */       this.elem.setFixedWidths(arrayOfInt);
/*     */       this.pane.reprintLater = true;
/*     */     } else if (this.pane.getCurrentPage() != null) {
/*     */       this.pane.getCurrentPage().repaint(100L);
/*     */     } 
/*     */     this.pane.editing = false;
/*     */     this.table = null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\CellEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */