/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.FormLens;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.internal.FormXElement;
/*     */ import inetsoft.report.internal.j2d.NumField;
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.lens.AttributeFormLens;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.ColorComboBox;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JRadioButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormProperty
/*     */   extends TextProperty
/*     */ {
/*     */   FormXElement elem;
/*     */   TablePane data;
/*     */   JRadioButton fit_page;
/*     */   JRadioButton fit_content;
/*     */   JRadioButton eq_width;
/*     */   JRadioButton fix_width;
/*     */   ButtonGroup layoutGroup;
/*     */   FontCanvas lfont;
/*     */   ColorComboBox lfg;
/*     */   ColorComboBox lbg;
/*     */   FontCanvas ffont;
/*     */   ColorComboBox ffg;
/*     */   ColorComboBox fbg;
/*     */   NumField perrow;
/*     */   LineCombo line;
/*     */   
/*     */   public FormProperty(DesignView paramDesignView) {
/*  39 */     super(paramDesignView, inetsoft.report.TableElement.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     this.data = new TablePane(3);
/* 146 */     this.fit_page = new JRadioButton(Catalog.getString("Fit Page"));
/* 147 */     this.fit_content = new JRadioButton(Catalog.getString("Fit Content"));
/*     */     
/* 149 */     this.eq_width = new JRadioButton(Catalog.getString("Equal Width"));
/* 150 */     this.fix_width = new JRadioButton(Catalog.getString("Embed Field Widths"));
/*     */     
/* 152 */     this.layoutGroup = new ButtonGroup();
/* 153 */     this.lfont = new FontCanvas();
/* 154 */     this.lfg = new ColorComboBox();
/* 155 */     this.lbg = new ColorComboBox();
/* 156 */     this.ffont = new FontCanvas();
/* 157 */     this.ffg = new ColorComboBox();
/* 158 */     this.fbg = new ColorComboBox();
/* 159 */     this.perrow = new NumField(3, true);
/* 160 */     this.line = new LineCombo(false);
/*     */     setTitle(Catalog.getString("Form Properties"));
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     property2Panel.add(Catalog.getString("Layout"), new Object[][] { { this.fit_page, this.fit_content, this.eq_width }, { this.fix_width }, { Catalog.getString("Fields Per Row") + ":", this.perrow } });
/*     */     property2Panel.add(Catalog.getString("Label"), new Object[][] { { Catalog.getString("Font") + ":", this.lfont }, { Catalog.getString("Foreground") + ":", this.lfg, Catalog.getString("Background") + ":", this.lbg } });
/*     */     property2Panel.add(Catalog.getString("Field"), new Object[][] { { Catalog.getString("Font") + ":", this.ffont }, { Catalog.getString("Foreground") + ":", this.ffg, Catalog.getString("Background") + ":", this.fbg }, { Catalog.getString("Underline") + ":", this.line } });
/*     */     this.folder.insertTab(Catalog.getString("Form"), null, property2Panel, Catalog.getString("Table Layout"), 0);
/*     */     this.folder.insertTab(Catalog.getString("Labels and Data"), null, this.data, Catalog.getString("Form Labels and Data"), 1);
/*     */     this.layoutGroup.add(this.fit_page);
/*     */     this.layoutGroup.add(this.fit_content);
/*     */     this.layoutGroup.add(this.eq_width);
/*     */     this.layoutGroup.add(this.fix_width);
/*     */   }
/*     */   
/*     */   public void setElement(ReportElement paramReportElement) {
/*     */     this.elem = (FormXElement)paramReportElement;
/*     */     super.setElement(paramReportElement);
/*     */     this.data.setElement(this.elem);
/*     */     switch (this.elem.getLayout()) {
/*     */       case 1:
/*     */         this.fit_page.setSelected(true);
/*     */         break;
/*     */       case 0:
/*     */       case 3:
/*     */       case 4:
/*     */         this.fit_content.setSelected(true);
/*     */         break;
/*     */       case 2:
/*     */         this.eq_width.setSelected(true);
/*     */         break;
/*     */     } 
/*     */     this.fix_width.setSelected(this.elem.isEmbedWidth());
/*     */     FormLens formLens = this.elem.getForm();
/*     */     this.lfont.setDisplayFont(formLens.getLabelFont(0));
/*     */     this.lfg.setSelectedColor(formLens.getLabelForeground(0));
/*     */     this.lbg.setSelectedColor(formLens.getLabelBackground(0));
/*     */     this.ffont.setDisplayFont(formLens.getFont(0));
/*     */     this.ffg.setSelectedColor(formLens.getForeground(0));
/*     */     this.fbg.setSelectedColor(formLens.getBackground(0));
/*     */     this.perrow.setValue(formLens.getFieldPerRow());
/*     */     this.line.setSelectedLineStyle(formLens.getUnderline());
/*     */   }
/*     */   
/*     */   public boolean populateElement() {
/*     */     if (!super.populateElement())
/*     */       return false; 
/*     */     this.data.populateElement();
/*     */     if (this.fit_page.isSelected()) {
/*     */       this.elem.setLayout(1);
/*     */     } else if (this.fit_content.isSelected()) {
/*     */       this.elem.setLayout(0);
/*     */     } else if (this.eq_width.isSelected()) {
/*     */       this.elem.setLayout(2);
/*     */     } 
/*     */     this.elem.setEmbedWidth(this.fix_width.isSelected());
/*     */     if (this.elem.isEmbedWidth())
/*     */       this.elem.setLayout(0); 
/*     */     AttributeFormLens attributeFormLens = (AttributeFormLens)this.elem.getForm();
/*     */     attributeFormLens.setLabelFont(this.lfont.getDisplayFont());
/*     */     attributeFormLens.setLabelForeground(this.lfg.getSelectedColor());
/*     */     attributeFormLens.setLabelBackground(this.lbg.getSelectedColor());
/*     */     attributeFormLens.setFont(this.ffont.getDisplayFont());
/*     */     attributeFormLens.setForeground(this.ffg.getSelectedColor());
/*     */     attributeFormLens.setBackground(this.fbg.getSelectedColor());
/*     */     attributeFormLens.setFieldPerRow(this.perrow.intValue());
/*     */     attributeFormLens.setUnderline(this.line.getSelectedLineStyle());
/*     */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FormProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */